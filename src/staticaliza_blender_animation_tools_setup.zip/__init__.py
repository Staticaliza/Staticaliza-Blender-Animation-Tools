bl_info = {
    "name": "Staticaliza's Blender Animation Tools",
    "author": "Staticaliza",
    "version": (1, 0, 0),
    "blender": (4, 2, 0),
    "location": "Preferences > Add-ons",
    "description": "Downloads and installs the latest Roblox Animator tool bundle",
    "category": "Animation",
}

import json
import importlib
import os
import tempfile
import time
import tomllib
import urllib.error
import urllib.request
import zipfile

import addon_utils
import bpy


STATICALIZA_ADDON_ID = "staticaliza_blender_animation_tools_utils"
STATICALIZA_PACKAGE_FILENAME = "staticaliza_blender_animation_tools_utils.zip"
STATICALIZA_RAW_EXTENSION = (
    "https://raw.githubusercontent.com/Staticaliza/"
    "Staticaliza-Blender-Animation-Tools/main/src/"
    f"{STATICALIZA_PACKAGE_FILENAME}"
)

IMPACT_ADDON_ID = "staticaliza_blender_animation_tools_impact"
IMPACT_PACKAGE_FILENAME = "staticaliza_blender_animation_tools_impact.zip"
IMPACT_RAW_EXTENSION = (
    "https://raw.githubusercontent.com/Staticaliza/"
    "Staticaliza-Blender-Animation-Tools/main/src/"
    f"{IMPACT_PACKAGE_FILENAME}"
)

LEGACY_IMPACTION_ADDON_ID = "impaction_impact_frames"
LEGACY_IMPACTION_UPDATE_TIMER_KEY = "impaction_impact_frames.self_update_timer"

ROBLOX_ADDON_ID = "roblox_animations_importer_exporter"
ROBLOX_RELEASE_API = (
    "https://api.github.com/repos/Cautioned/Blender-Animations-Plugin/releases/latest"
)

_status = "Ready to install the latest Roblox Animator tool bundle."
_versions = {
    ROBLOX_ADDON_ID: "Not checked",
    STATICALIZA_ADDON_ID: "Not checked",
    IMPACT_ADDON_ID: "Not checked",
}
_auto_install_lock_waits = 0


def _github_request(url):
    separator = "&" if "?" in url else "?"
    return urllib.request.Request(
        f"{url}{separator}_staticaliza_cache_bust={time.time_ns()}",
        headers={
            "Accept": "application/vnd.github+json",
            "Cache-Control": "no-cache, no-store, max-age=0",
            "Pragma": "no-cache",
            "User-Agent": "Staticaliza-Blender-Tools-Setup",
            "X-GitHub-Api-Version": "2022-11-28",
        },
    )


def _download_json(url):
    with urllib.request.urlopen(_github_request(url), timeout=30) as response:
        return json.load(response)


def _staticaliza_download():
    separator = "&" if "?" in STATICALIZA_RAW_EXTENSION else "?"
    url = f"{STATICALIZA_RAW_EXTENSION}{separator}_staticaliza_cache_bust={time.time_ns()}"
    return "latest main branch", url


def _impact_download():
    separator = "&" if "?" in IMPACT_RAW_EXTENSION else "?"
    url = f"{IMPACT_RAW_EXTENSION}{separator}_staticaliza_cache_bust={time.time_ns()}"
    return "latest main branch", url


def _roblox_download():
    release = _download_json(ROBLOX_RELEASE_API)
    candidates = []

    for asset in release.get("assets", []):
        name = asset.get("name", "")
        lowered = name.casefold()
        if not lowered.endswith(".zip") or "legacy" in lowered or "source" in lowered:
            continue
        url = asset.get("browser_download_url")
        if url:
            candidates.append((name, url))

    if not candidates:
        raise RuntimeError("The latest Roblox Animator release has no regular Blender ZIP asset.")

    candidates.sort(key=lambda item: (not item[0].casefold().startswith("rbx_anims_"), item[0]))
    return release.get("tag_name", "latest release"), candidates[0][1]


def _download_zip(url, prefix):
    handle, destination = tempfile.mkstemp(prefix=prefix, suffix=".zip")
    os.close(handle)

    try:
        request = urllib.request.Request(
            url,
            headers={
                "Accept": "application/octet-stream",
                "Cache-Control": "no-cache, no-store, max-age=0",
                "Pragma": "no-cache",
                "User-Agent": "Staticaliza-Blender-Tools-Setup",
            },
        )
        with urllib.request.urlopen(request, timeout=60) as response, open(destination, "wb") as output:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                output.write(chunk)

        with zipfile.ZipFile(destination) as package:
            if package.testzip() is not None:
                raise RuntimeError("The downloaded ZIP failed its integrity check.")
        return destination
    except Exception:
        try:
            os.remove(destination)
        except OSError:
            pass
        raise


def _package_version(filepath, fallback):
    try:
        with zipfile.ZipFile(filepath) as package:
            manifest_names = [
                name for name in package.namelist()
                if name.replace("\\", "/").endswith("blender_manifest.toml")
            ]
            if not manifest_names:
                return str(fallback)

            manifest_name = min(manifest_names, key=lambda name: name.count("/"))
            manifest = tomllib.loads(package.read(manifest_name).decode("utf-8"))
            return str(manifest.get("version", fallback))
    except (KeyError, UnicodeDecodeError, ValueError, zipfile.BadZipFile):
        return str(fallback)


def _format_version(version):
    text = str(version).strip()
    if not text or text in {"Not checked", "Checking...", "Unavailable"}:
        return text or "Unknown"
    return text if text.casefold().startswith("v") else f"v{text}"


def _find_addon_module(addon_id, refresh=False):
    for module in addon_utils.modules(refresh=refresh):
        module_name = getattr(module, "__name__", "")
        if module_name == addon_id or module_name.endswith(f".{addon_id}"):
            return module_name
    return None


def _installed_version(addon_id):
    module_name = _find_addon_module(addon_id)
    if module_name is None:
        return None

    for module in addon_utils.modules():
        if getattr(module, "__name__", "") != module_name:
            continue
        version = getattr(module, "bl_info", {}).get("version")
        if isinstance(version, (tuple, list)):
            return ".".join(str(part) for part in version)
        if version:
            return str(version)
    return None


def _display_version(addon_id):
    version = _versions.get(addon_id, "Not checked")
    if version != "Not checked":
        return _format_version(version)

    installed = _installed_version(addon_id)
    if installed:
        return f"Installed {_format_version(installed)}"
    return "Not installed / not checked"


def _replace_manifest_display_name(data, display_name):
    text = data.decode("utf-8")
    lines = text.splitlines(keepends=True)

    for index, line in enumerate(lines):
        if not line.lstrip().startswith("name ="):
            continue
        indent = line[:len(line) - len(line.lstrip())]
        newline = "\r\n" if line.endswith("\r\n") else "\n" if line.endswith("\n") else ""
        lines[index] = f'{indent}name = "{display_name}"{newline}'
        return "".join(lines).encode("utf-8")

    raise RuntimeError("Downloaded Blender manifest has no name field.")


def _replace_bl_info_display_name(data, display_name):
    text = data.decode("utf-8")
    lines = text.splitlines(keepends=True)
    in_bl_info = False

    for index, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith("bl_info") and "{" in stripped:
            in_bl_info = True
            continue
        if not in_bl_info:
            continue
        if stripped == "}":
            break
        if not (stripped.startswith('"name"') or stripped.startswith("'name'")):
            continue

        indent = line[:len(line) - len(line.lstrip())]
        newline = "\r\n" if line.endswith("\r\n") else "\n" if line.endswith("\n") else ""
        lines[index] = f'{indent}"name": "{display_name}",{newline}'
        return "".join(lines).encode("utf-8")

    raise RuntimeError("Downloaded add-on metadata has no name field.")


def _replace_roblox_panel_display_name(data):
    text = data.decode("utf-8")
    text = text.replace(
        'bl_label = "Rbx Animations"',
        'bl_label = f"Roblox Animator (v{ADDON_VERSION_TEXT})"',
    )
    text = text.replace(
        "bl_label = 'Rbx Animations'",
        "bl_label = f'Roblox Animator (v{ADDON_VERSION_TEXT})'",
    )
    text = text.replace('"Rbx Animations"', '"Roblox Animator"')
    text = text.replace("'Rbx Animations'", "'Roblox Animator'")
    text = text.replace('text="Bake (Clipboard)"', 'text="Export"')
    text = text.replace("text='Bake (Clipboard)'", "text='Export'")
    version_block = (
        "        version_row = layout.row()\n"
        "        version_row.alignment = \"RIGHT\"\n"
        "        version_row.label(text=f\"v{ADDON_VERSION_TEXT}\")\n\n"
    )
    text = text.replace(version_block, "")
    text = text.replace(version_block.replace("\n", "\r\n"), "")
    return text.encode("utf-8")


def _replace_roblox_export_metadata(data):
    text = data.decode("utf-8")
    text = text.replace(
        'class OBJECT_OT_Bake(bpy.types.Operator):\n'
        '    bl_label = "Bake"\n'
        '    bl_idname = "object.rbxanims_bake"\n'
        '    bl_description = "Bake animation for export to clipboard"',
        'class OBJECT_OT_Bake(bpy.types.Operator):\n'
        '    bl_label = "Export"\n'
        '    bl_idname = "object.rbxanims_bake"\n'
        '    bl_description = "Export animation to clipboard"',
    )
    text = text.replace(
        'bl_description = "Bake animation for export to clipboard"',
        'bl_description = "Export animation to clipboard"',
    )
    return text.encode("utf-8")


def _rewrite_package_display_name(filepath, display_name):
    handle, destination = tempfile.mkstemp(prefix="renamed_blender_extension_", suffix=".zip")
    os.close(handle)

    try:
        with zipfile.ZipFile(filepath) as source:
            infos = [info for info in source.infolist() if info.filename]
            normalized_names = []
            for info in infos:
                normalized = info.filename.replace("\\", "/").lstrip("/")
                parts = [part for part in normalized.split("/") if part]
                if not parts or ".." in parts:
                    raise RuntimeError("Downloaded ZIP contains an unsafe path.")
                normalized_names.append(normalized)
            manifest_names = [
                name for name in normalized_names if name.endswith("blender_manifest.toml")
            ]
            if not manifest_names:
                raise RuntimeError("Downloaded ZIP has no Blender manifest.")
            manifest_name = min(manifest_names, key=lambda name: name.count("/"))
            manifest_parent = manifest_name.rsplit("/", 1)[0] if "/" in manifest_name else ""
            package_init_name = f"{manifest_parent}/__init__.py" if manifest_parent else "__init__.py"
            if package_init_name not in normalized_names:
                raise RuntimeError("Downloaded ZIP has no package __init__.py beside its manifest.")

            with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED) as output:
                for info, normalized in zip(infos, normalized_names):
                    data = b"" if info.is_dir() else source.read(info)
                    if normalized == manifest_name:
                        data = _replace_manifest_display_name(data, display_name)
                    elif normalized == package_init_name:
                        data = _replace_bl_info_display_name(data, display_name)
                    elif normalized.endswith("ui/panels.py"):
                        data = _replace_roblox_panel_display_name(data)
                    elif normalized.endswith("operators/animation_ops.py"):
                        data = _replace_roblox_export_metadata(data)
                    output.writestr(info, data)
        return destination
    except Exception:
        try:
            os.remove(destination)
        except OSError:
            pass
        raise


def _disable_existing_addon(addon_id):
    module_name = _find_addon_module(addon_id, refresh=True)
    if module_name and addon_utils.check(module_name)[1]:
        addon_utils.disable(module_name, default_set=True)


def _disable_legacy_impaction():
    """Disable, but never remove, the standalone Impaction extension."""
    callback = None
    try:
        callback = bpy.app.driver_namespace.pop(
            LEGACY_IMPACTION_UPDATE_TIMER_KEY,
            None,
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        pass

    if callable(callback):
        try:
            if bpy.app.timers.is_registered(callback):
                bpy.app.timers.unregister(callback)
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            pass

    _disable_existing_addon(LEGACY_IMPACTION_ADDON_ID)


def _enable_installed_addon(addon_id):
    module_name = _find_addon_module(addon_id, refresh=True)
    if module_name is None:
        raise RuntimeError(f"Blender installed {addon_id} but could not find its module.")
    if not addon_utils.check(module_name)[1]:
        addon_utils.enable(module_name, default_set=True, persistent=True)
    if not addon_utils.check(module_name)[1]:
        raise RuntimeError(f"Blender could not enable {addon_id}.")


def _prepare_legacy_zip(filepath, addon_id):
    handle, destination = tempfile.mkstemp(prefix=f"{addon_id}_", suffix=".zip")
    os.close(handle)

    try:
        with zipfile.ZipFile(filepath) as source, zipfile.ZipFile(
            destination, "w", compression=zipfile.ZIP_DEFLATED
        ) as output:
            infos = [info for info in source.infolist() if info.filename]
            normalized_names = []

            for info in infos:
                normalized = info.filename.replace("\\", "/").lstrip("/")
                parts = [part for part in normalized.split("/") if part]
                if not parts or ".." in parts:
                    raise RuntimeError("Downloaded ZIP contains an unsafe path.")
                normalized_names.append(normalized)

            if "__init__.py" not in normalized_names:
                raise RuntimeError("Downloaded ZIP does not contain a top-level __init__.py.")

            for info, normalized in zip(infos, normalized_names):
                target = f"{addon_id}/{normalized}"
                if info.is_dir():
                    output.writestr(f"{target.rstrip('/')}/", b"")
                else:
                    output.writestr(target, source.read(info))

        return destination
    except Exception:
        try:
            os.remove(destination)
        except OSError:
            pass
        raise


def _install_with_extension_api(filepath):
    extension_ops = getattr(bpy.ops, "extensions", None)
    install = getattr(extension_ops, "package_install_files", None)
    if install is None:
        return False

    try:
        try:
            result = install(
                "EXEC_DEFAULT",
                filepath=filepath,
                repo="user_default",
                enable_on_install=True,
            )
        except TypeError:
            result = install("EXEC_DEFAULT", filepath=filepath, repo="user_default")
    except (RuntimeError, TypeError):
        return False

    return "FINISHED" in result


def _extension_repository_is_locked():
    try:
        from bl_pkg import cookie_from_session
        from bl_pkg.bl_extension_utils import repo_lock_directory_query
    except ImportError:
        return False

    extensions = getattr(bpy.context.preferences, "extensions", None)
    repositories = getattr(extensions, "repos", ())
    repository = next(
        (repo for repo in repositories if repo.module == "user_default"),
        None,
    )
    if repository is None:
        return False

    return repo_lock_directory_query(
        repository.directory,
        cookie_from_session(),
    ) is not None


def _install_with_legacy_api(filepath, addon_id):
    prepared = _prepare_legacy_zip(filepath, addon_id)
    try:
        install = getattr(bpy.ops.preferences, "addon_install", None)
        if install is None:
            install = getattr(bpy.ops.wm, "addon_install", None)
        if install is None:
            raise RuntimeError("Blender does not expose an add-on installer API.")

        try:
            result = install(overwrite=True, target="DEFAULT", filepath=prepared)
        except TypeError:
            result = install(overwrite=True, filepath=prepared)
        if "FINISHED" not in result:
            raise RuntimeError("Blender's add-on installer did not finish.")
    finally:
        try:
            os.remove(prepared)
        except OSError:
            pass


def _install_package(filepath, addon_id):
    renamed_package = None
    install_filepath = filepath

    try:
        if addon_id == ROBLOX_ADDON_ID:
            renamed_package = _rewrite_package_display_name(filepath, "Roblox Animator")
            install_filepath = renamed_package

        if addon_id == IMPACT_ADDON_ID:
            _disable_legacy_impaction()
        _disable_existing_addon(addon_id)
        if not _install_with_extension_api(install_filepath):
            _install_with_legacy_api(install_filepath, addon_id)
        _enable_installed_addon(addon_id)

        module_name = _find_addon_module(addon_id)
        if module_name and addon_id == ROBLOX_ADDON_ID:
            module = importlib.import_module(module_name)
            if isinstance(getattr(module, "bl_info", None), dict):
                module.bl_info["name"] = "Roblox Animator"
    finally:
        if renamed_package and os.path.exists(renamed_package):
            try:
                os.remove(renamed_package)
            except OSError:
                pass


def _install_latest_extensions():
    global _status

    if not getattr(bpy.app, "online_access", True):
        raise RuntimeError("Blender online access is disabled in Preferences.")
    if _extension_repository_is_locked():
        raise RuntimeError(
            "The User Default extension repository is busy. Wait for the current "
            "installation to finish, then try again."
        )

    completed = []
    failures = []
    jobs = (
        ("Roblox Animator", ROBLOX_ADDON_ID, _roblox_download, "roblox_animator_"),
        ("Roblox Animator Utils", STATICALIZA_ADDON_ID, _staticaliza_download, "staticaliza_"),
        ("Roblox Animator Impact", IMPACT_ADDON_ID, _impact_download, "staticaliza_impact_"),
    )

    for label, addon_id, resolver, prefix in jobs:
        downloaded = None
        _versions[addon_id] = "Checking..."
        try:
            version_hint, url = resolver()
            downloaded = _download_zip(url, prefix)
            version = _package_version(downloaded, version_hint)
            _install_package(downloaded, addon_id)
            _versions[addon_id] = version
            completed.append(f"{label} ({version})")
        except Exception as exc:
            _versions[addon_id] = "Unavailable"
            failures.append(f"{label}: {exc}")
        finally:
            if downloaded and os.path.exists(downloaded):
                try:
                    os.remove(downloaded)
                except OSError:
                    pass

    if failures:
        installed = f" Installed: {', '.join(completed)}." if completed else ""
        raise RuntimeError(f"{' | '.join(failures)}.{installed}")

    _status = f"Installed latest: {', '.join(completed)}."
    return True


def _install_or_update_children():
    """Compatibility entry point used by Roblox Animator Utils."""
    return _install_latest_extensions()


def _auto_install():
    global _auto_install_lock_waits, _status

    if _extension_repository_is_locked():
        _auto_install_lock_waits += 1
        if _auto_install_lock_waits <= 20:
            _status = "Waiting for Blender to finish installing the setup extension..."
            return 0.5
        _status = (
            "Automatic setup paused because the extension repository remains locked. "
            "Use Force Unlock Repository if no installation is running."
        )
        return None

    _auto_install_lock_waits = 0
    try:
        _install_latest_extensions()
    except Exception as exc:
        _status = f"Automatic setup failed: {exc}"
        print(f"[Staticaliza Setup] {_status}")
    return None


class STATICALIZA_SETUP_OT_install_latest_extensions(bpy.types.Operator):
    bl_idname = "staticaliza_setup.install_latest_extensions"
    bl_label = "Install / Update All Three Extensions"
    bl_description = "Download, install, and enable Roblox Animator, Utils, and Impact"

    def execute(self, context):
        global _status
        try:
            _install_latest_extensions()
        except Exception as exc:
            _status = f"Setup failed: {exc}"
            self.report({"ERROR"}, _status)
            return {"CANCELLED"}

        self.report({"INFO"}, _status)
        return {"FINISHED"}


class STATICALIZA_SETUP_preferences(bpy.types.AddonPreferences):
    bl_idname = __package__ or __name__

    def draw(self, context):
        layout = self.layout
        versions = layout.box()
        versions.label(text="Versions")
        versions.label(text=f"Roblox Animator: {_display_version(ROBLOX_ADDON_ID)}")
        versions.label(text=f"Roblox Animator Utils: {_display_version(STATICALIZA_ADDON_ID)}")
        versions.label(text=f"Roblox Animator Impact: {_display_version(IMPACT_ADDON_ID)}")
        layout.label(text=_status)
        layout.operator("staticaliza_setup.install_latest_extensions")


_classes = (
    STATICALIZA_SETUP_OT_install_latest_extensions,
    STATICALIZA_SETUP_preferences,
)


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)
    bpy.app.timers.register(_auto_install, first_interval=0.5)


def unregister():
    if bpy.app.timers.is_registered(_auto_install):
        bpy.app.timers.unregister(_auto_install)
    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
