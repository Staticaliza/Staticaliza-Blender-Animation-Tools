"""Transient 3D ribbon transport while an exact direction solve is pending.

Never writes the canonical path/ribbon caches. Contacts and stroke population
stay fixed; wind rotation bends only released ink. Exact geometry is deferred
during direction gestures and is mandatory at release/export.
"""
import numpy as np
from .impaction_linear import dome_direction


def source_ribbons(geometry, path_key, width, height):
    cache = getattr(geometry, '_linear_ribbon_cache', {})
    exact = (path_key, int(width), int(height))
    if exact in cache:
        return exact, cache[exact], 1.0
    matrix = geometry.view_projection
    target = np.asarray(dome_direction(path_key[1], (.5, .5), width / height,
                                       path_key[2], matrix))
    best = None
    for key, data in cache.items():
        old = key[0]
        # Direction currently also changes the authored style salt. Freeze
        # that realization during transport; the exact solve still applies
        # the new salt. Explicit reseeding without a direction edit is exact.
        comparable = lambda value: value[:1] + value[2:4] + value[5:]
        if (key[1:] != exact[1:] or comparable(old) != comparable(path_key)
                or (old[1] == path_key[1] and old[4] != path_key[4])):
            continue
        wind = np.asarray(dome_direction(old[1], (.5, .5), width / height, old[2], matrix))
        agreement = float(wind @ target)
        # Angle alone must never block a held gesture on the exact solver.
        if best is None or agreement > best[2]:
            best = key, data, agreement
    return best


def prepare_transport(geometry, path_key, width, height):
    source = source_ribbons(geometry, path_key, width, height)
    if source is None:
        return None
    source_key, (arrays, triangles), _ = source
    if not len(triangles):
        return None
    cached = getattr(geometry, '_direction_preview_transport', None)
    token = (source_key, id(arrays))
    matrix = np.asarray(geometry.view_projection, dtype=np.float32)
    if cached is None or cached['token'] != token:
        clips = np.asarray(arrays['clipPosition'], dtype=np.float32)
        homogeneous = clips @ np.linalg.inv(matrix).T
        world = homogeneous[:, :3] / homogeneous[:, 3:4]
        params = np.asarray(arrays['strokeParams'])
        uv = np.asarray(arrays['strokeUV'])
        starts = np.r_[0, np.flatnonzero(params[1:, 1] != params[:-1, 1]) + 1]
        ends = np.r_[starts[1:], len(world)]
        pivot = np.empty_like(world)
        for start, end in zip(starts, ends):
            # The canonical ribbon contains nine lanes, including its center.
            centers = np.arange(start + 4, end, 9)
            nearest = centers[np.argmin(abs(uv[centers, 0] - params[centers, 2]))]
            pivot[start:end] = world[nearest]
        phase = np.clip((uv[:, 0] - params[:, 2]) /
                        np.maximum((1. - params[:, 2]) * .20, .001), 0., 1.)
        weight = (phase * phase * (3. - 2. * phase)).astype(np.float32)
        axis = matrix[2, :3] / np.linalg.norm(matrix[2, :3])
        cached = dict(token=token, world=world, pivot=pivot,
                      weight=weight, axis=axis, source=source_key[0][1], result=None,
                      starts=starts, counts=ends-starts)
        # A per-stroke sphere bounds all possible rotated positions. The
        # GPU uses this conservative clip-W guard without a CPU vertex walk.
        radii = np.maximum.reduceat(np.linalg.norm(world-pivot, axis=1), starts)
        min_w = np.minimum.reduceat(clips[:, 3], starts)
        safety = .95 * np.maximum(min_w, 0.) / np.maximum(2.*radii*np.linalg.norm(matrix[3,:3]), 1.e-8)
        safety = np.repeat(safety, ends-starts)
        attributes = dict(arrays)
        attributes['previewWorld'] = np.column_stack((world,safety)).astype(np.float32)
        attributes['previewPivot'] = np.column_stack((pivot,weight)).astype(np.float32)
        cached['gpu_data'] = attributes, triangles
        geometry._direction_preview_transport = cached
    return cached


def transport_state(geometry, path_key, width, height):
    cached = prepare_transport(geometry, path_key, width, height)
    if cached is None:
        return None
    matrix = np.asarray(geometry.view_projection, dtype=np.float32)
    old = np.asarray(dome_direction(cached['source'], (.5, .5), width / height,
                                    path_key[2], matrix), dtype=np.float32)
    new = np.asarray(dome_direction(path_key[1], (.5, .5), width / height,
                                    path_key[2], matrix), dtype=np.float32)
    turn_axis = np.cross(old, new)
    sine = float(np.linalg.norm(turn_axis))
    cosine = float(np.clip(old @ new, -1., 1.))
    if sine < 1.e-6 and cosine < 0.:
        # A half turn has no unique shortest axis. Use a stable perpendicular
        # axis instead of dividing by zero in Rodrigues' formula.
        basis = np.eye(3, dtype=np.float32)[np.argmin(np.abs(old))]
        turn_axis = np.cross(old, basis)
        turn_axis /= np.linalg.norm(turn_axis)
    else:
        turn_axis /= max(sine, 1.e-8)
    return cached, turn_axis, float(np.arctan2(sine, cosine))


def transport_ribbons(geometry, path_key, width, height):
    """CPU reference of the GPU preview deformation, used by validation."""
    source = source_ribbons(geometry,path_key,width,height)
    if source is None:return None
    if source[0][0] == path_key or not len(source[1][1]):return source[1]
    cached, turn_axis, angle = transport_state(geometry,path_key,width,height)
    arrays, triangles = source[1]
    matrix = np.asarray(geometry.view_projection, dtype=np.float32)
    phase = (angle * cached['weight'])[:, None]
    relative = cached['world'] - cached['pivot']
    cos_phase = np.cos(phase)
    delta = relative * (cos_phase - 1.) + np.cross(turn_axis, relative) * np.sin(phase)
    delta += (relative @ turn_axis)[:, None] * turn_axis * (1. - cos_phase)
    clips = np.asarray(arrays['clipPosition'], dtype=np.float32).copy()
    clip_delta = delta @ matrix[:, :3].T
    scale = np.minimum(1.,cached['gpu_data'][0]['previewWorld'][:,3] / max(float(np.sin(angle*.5)),1.e-8))
    delta *= scale[:, None]
    clips += clip_delta * scale[:, None]
    transported = dict(arrays)
    transported['clipPosition'] = clips
    transported['linearDepth'] = np.asarray(arrays['linearDepth'], dtype=np.float32) + delta @ cached['axis']
    cached['result_key'] = path_key
    cached['result'] = transported, triangles
    return cached['result']
