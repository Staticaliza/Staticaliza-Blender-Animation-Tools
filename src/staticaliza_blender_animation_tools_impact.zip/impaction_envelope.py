"""Ordered exterior stream families, independent of triangle adjacency.

Material and depth compositing remain independent of the casting geometry.
"""
import math
from functools import lru_cache
import numpy as np
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from mathutils.kdtree import KDTree
from .impaction_linear import iter_mesh_packets, dome_direction, SurfaceStroke
from .impaction_spatial import owner_indices

_CONTACT_STATIONS=np.linspace(0.,1.,8)
_STATIC_TAIL_STATIONS=np.linspace(1./12.,1.,12)
_MOTION_TAIL_STATIONS=np.linspace(1./24.,1.,24)


def _channel_opening(t, spread, facing):
    """Finite side escape; downstream tangents settle into the shared wind."""
    return max(0.,spread)*(.143-.078*facing*facing)*(1.-np.exp(-4.*t))


@lru_cache(maxsize=4096)
def _contact_basis(normal):
    n=Vector(normal).normalized()
    tangent=n.orthogonal().normalized()
    cross=n.cross(tangent)
    ring=tuple(tangent*math.cos(j*math.pi/4.)+cross*math.sin(j*math.pi/4.) for j in range(8))
    cone=(n,)+tuple((n+v*1.5).normalized() for v in ring)
    return n,ring,cone


def _closed_seam_mouth(surface, point, normal, distance, epsilon, heading=None, travel_limit=None,
                       owners=None, source_owner=None):
    """Reject an outlet beside a narrow crack, including coplanar front lips.

    Rays start just inside the supporting shell. Its nearby exit must be
    followed by another wall within the local gap budget. Open wedges are
    admitted locally; no owner-wide or projected silhouette mask is used.
    """
    n,directions,_=_contact_basis(tuple(normal))
    # Bevel gaps and disconnected face islands can let a ray slip through a
    # nominally sealed joint. Test finite opposing faces as well as rays.
    for nearby,other,near_face,separation in surface.find_nearest_range(Vector(point),distance):
        if heading is not None and owners is not None and owners[near_face]==source_owner:continue
        if separation>epsilon and other.dot(n)<-.35:
            delta=nearby-Vector(point)
            if delta.dot(n)>-epsilon*2.:return True
    origin=Vector(point)-n*max(epsilon*4.,distance*.65)
    if heading is not None:
        direction=Vector(heading)-n*Vector(heading).dot(n)
        if direction.length<epsilon:return False
        directions=[direction.normalized()]
    for direction in directions:
        hit,wall,face,travel=surface.ray_cast(origin,direction,travel_limit or distance)
        if hit is None:continue
        # Entering another wall before leaving the supporting shell is overlap.
        if wall.dot(direction)<-.25:
            return owners is None or heading is None or owners[face]!=source_owner
        if wall.dot(direction)<.25:continue
        beyond=hit+direction*epsilon*2.
        cap,cap_normal,cap_face,_=surface.ray_cast(beyond,n,distance*.85)
        if cap is not None and cap_normal.dot(n)>.5 and (
                owners is None or owners[cap_face]!=source_owner):return True
        next_hit,next_wall,next_face,gap=surface.ray_cast(beyond,direction,distance)
        if next_hit is None:continue
        if heading is not None and owners is not None and owners[next_face]==source_owner:continue
        # Entry means a narrow empty crack. A second nearby exit means the
        # source was inside overlapping solids. Both close this local mouth.
        if abs(next_wall.dot(direction))>.25 and gap+(travel if heading is None else 0.)<distance:
            return True
    return False


def _sealed_contact(surface, owners, owner, point, normal, distance, epsilon):
    """Test the outlet cone, including gaps beside a chamfer's slanted normal."""
    n,_,directions=_contact_basis(tuple(normal))
    origin=Vector(point)+n*epsilon
    # An exit as the first outward hit means the supporting face is embedded
    # in another closed shell. Do not allow a later tail to emerge from it.
    hit,other,_,travel=surface.ray_cast(origin,n)
    if hit is not None and other.dot(n)>.25:
        return True
    # The cone starts with this same normal ray. Reuse its exact result.
    if hit is None or travel>distance or other.dot(n)>=-.25:
        return False
    # One neighbouring wall does not seal the entire outlet cone. Admit
    # a supported contact if it has an open escape; the actual ribbon lanes
    # still resolve foreign occlusion along their chosen paths.
    for direction in directions[1:]:
        hit,other,face,_=surface.ray_cast(origin,direction,distance)
        if hit is None or other.dot(direction)>=-.25:
            return False
    return True



def _exposure_history(stored, local_offset=None):
    samples=np.asarray(stored,dtype=float)
    positions=samples[:,1:4].copy()
    if samples.shape[1]>=13 and local_offset is not None:
        positions+=np.einsum('i,nij->nj',local_offset,samples[:,4:13].reshape((-1,3,3)))
    # Keep the complete gesture intact. Its owner ages the drawing budget once;
    # weighting individual older segments erases the bend before the limb stops.
    return positions-positions[0]



def _motion_settling(movement_age):
    """Ease out after the incoming exposure, then catch up over eight frames."""
    t=max(0.,min(1.,(movement_age-1.)/8.))
    return 1.-t*t*(3.-2.*t)


def _recent_motion_history(stored,size):
    """Expire old samples from the tail of a eight-frame exposure."""
    rows=np.asarray(stored,dtype=float)
    if len(rows)<2:return stored
    rows=rows[np.r_[True,np.abs(np.diff(rows[:,0]))>1.e-6]]
    ages=-rows[:,0]
    lifetime=8.
    if ages[0]>=lifetime:return rows[:1].tolist()
    stop=int(np.searchsorted(ages,lifetime,side='right'))
    clipped=rows[:stop].copy()
    if 0<stop<len(rows) and ages[stop-1]<lifetime:
        t=(lifetime-ages[stop-1])/(ages[stop]-ages[stop-1])
        clipped=np.vstack((clipped,rows[stop-1]*(1.-t)+rows[stop]*t))
    return clipped.tolist()



def _relative_motion_history(stored,owner,geometry):
    """Separate local action from the rigid motion shared by most of a rig."""
    histories=getattr(geometry,'motion_history',{})
    rows=np.asarray(stored,dtype=float).copy()
    if len(histories)<3 or rows.shape[1]<13:return stored
    cached=getattr(geometry,'_linear_relative_motion_data',None)
    if cached is None:
        partitions=owner_indices(geometry.owner_ids)
        keys=[key for key in histories if int(key) in partitions]
        world=np.asarray(geometry.world_positions)
        centers_by_owner={key:world[index].mean(axis=0) for key,index in partitions.items()}
        centers=np.asarray([centers_by_owner[int(key)] for key in keys])
        sources=[np.asarray(histories[key],dtype=float) for key in keys]
        cached=(keys,centers_by_owner,centers,sources,{})
        geometry._linear_relative_motion_data=cached
    keys,centers_by_owner,centers,sources,common=cached
    if len(keys)<3 or owner not in centers_by_owner:return stored
    if any(source.shape[1]<13 for source in sources):return stored
    center=np.median(centers,axis=0)
    own_center=centers_by_owner[owner]
    times=tuple(rows[:,0])
    if times not in common:
        sampled=[]
        for source in sources:
            ages=-source[:,0]
            sampled.append(np.column_stack([np.interp(-rows[:,0],ages,source[:,j]) for j in range(1,13)]))
        sampled=np.asarray(sampled)
        rotations=np.median(sampled[:,:,3:],axis=0).reshape((-1,3,3))
        orbital=np.einsum('oi,tij->otj',centers-center,rotations)
        translation=np.median(sampled[:,:,:3]-orbital,axis=0)
        if len(common)>=16:common.pop(next(iter(common)))
        common[times]=(rotations,translation)
    rotations,translation=common[times]
    own_orbit=np.einsum('i,tij->tj',own_center-center,rotations)
    rows[:,1:4]-=.85*(translation+own_orbit)
    rows[:,4:13]-=.85*rotations.reshape((-1,9))
    return rows.tolist()


def _motion_event_strength(stored, offsets, size, age_decay=True):
    """Measure surface travel per frame, not total travel across a long charge."""
    samples=np.asarray(stored,dtype=float)
    if len(samples)<2:return 0.
    dt=np.abs(np.diff(samples[:,0]))
    rates=[]
    for offset in offsets:
        history=_exposure_history(stored,offset)
        rates.append(np.linalg.norm(np.diff(history,axis=0),axis=1)/np.maximum(dt,1.e-6)/max(size,1.e-6))
    rates=np.asarray(rates)
    if not rates.size:return 0.
    rate=np.percentile(rates,75,axis=0)
    response=rate*rate/(rate*rate+.06*.06)
    # Keep recent action alive when its newest interval slows down. Age the
    # energy rather than instantly replacing it with the settling velocity.
    ages=np.abs((samples[1:,0]+samples[:-1,0])*.5)
    decay=np.asarray([_motion_settling(age) for age in ages]) if age_decay else np.ones_like(ages)
    return float(np.max(response*response*decay))



def _motion_return_weight(settling):
    """Keep the arc's direction until only its final third remains."""
    t=max(0.,min(1.,settling/.35))
    return t*t*(3.-2.*t)


def _motion_authority(confidence, influence):
    """Favor the recorded direction while retaining continuous artist steering."""
    amount=max(0.,min(1.,influence))
    return amount+(1.-amount)*amount


def _motion_shape_weight(influence):
    """Full recorded gesture from halfway up; smoothly static below halfway."""
    amount=max(0.,min(1.,2.*influence))
    return amount*amount*(3.-2.*amount)


def _hemisphere_motion(trail, casting, camera_axis):
    """Motion owns bearing; Cast Behind owns the camera-depth hemisphere."""
    trail=np.asarray(trail,dtype=float).copy()
    depth=float(trail@camera_axis)
    cast_depth=float(casting@camera_axis)
    if abs(cast_depth)>1.e-7:
        # A planar moving arm still needs the authored depth cue. Reflect
        # only depth; never reverse the measured screen-motion polarity.
        signed=math.copysign(max(abs(depth),abs(cast_depth)*.35),cast_depth)
        trail+=camera_axis*(signed-depth)
    return trail/max(float(np.linalg.norm(trail)),1.e-8)


def _history_wake(velocity, acceleration, wind, reach, stations, influence):
    """Integrate past local tangents with a fixed arc-length budget.

    Captured derivatives approximate recent history quadratically. Acceleration
    changes bearing, not the distance budget specified by Intensity.
    """
    fractions=np.diff(np.r_[0.,stations])
    ages=(stations-fractions*.5)*3.
    velocity=np.asarray(velocity)
    acceleration=np.asarray(acceleration)
    # A quadratic estimate is trustworthy only locally. Extrapolating an
    # impact acceleration for three full frames can reverse the wake and
    # fold it back onto the fist. Bound its change of tangent over the window.
    acceleration=acceleration*min(1.,np.linalg.norm(velocity)*.24/
                                  max(np.linalg.norm(acceleration),1.e-8))
    past=-velocity[None,:]+ages[:,None]*acceleration[None,:]
    speed=np.linalg.norm(past,axis=1)
    directions=np.divide(past,np.maximum(speed[:,None],1.e-8))
    directions[speed<1.e-8]=wind
    mix=max(0.,min(1.,influence))
    directions=np.asarray(wind)[None,:]*(1.-mix)+directions*mix
    lengths=np.linalg.norm(directions,axis=1)
    directions[lengths<1.e-8]=wind
    directions/=np.maximum(np.linalg.norm(directions,axis=1)[:,None],1.e-8)
    return np.cumsum(directions*(reach*fractions[:,None]),axis=0)


def _sampled_wake(offsets, wind, reach, stations, influence, history=None):
    """Arc-length resampling of the evaluated key-interval bend."""
    if history is not None and len(history)>1:
        curve=np.asarray(history,dtype=float)
    else:
        before,mid_before,mid_after,after=np.asarray(offsets)
        # At the first authored pose there is no incoming history. Use the
        # reversed outgoing arc, rather than amplifying a zero-speed derivative.
        middle,end=(mid_before,before) if np.linalg.norm(before)>1.e-5 else (-mid_after,-after)
        if np.linalg.norm(end)<1.e-7:return np.asarray(wind)*reach*stations[:,None]
        control=2.*middle-.5*end
        t=np.linspace(0.,1.,65)[:,None]
        curve=2.*t*(1.-t)*control+t*t*end
    distance=np.r_[0.,np.cumsum(np.linalg.norm(np.diff(curve,axis=0),axis=1))]
    if distance[-1]<1.e-7:
        return (np.zeros((len(stations),3)) if history is not None else
                np.asarray(wind)*reach*stations[:,None])
    if history is not None:
        # Consume only the requested spatial extent, never compress every
        # earlier key into one short stroke.
        reach=min(reach,float(distance[-1]))
        sample_distance=stations*reach
    else:sample_distance=stations*distance[-1]
    sampled=np.column_stack([np.interp(sample_distance,distance,curve[:,i]) for i in range(3)])
    if history is not None and influence>=1.-1.e-8:
        return sampled
    if history is None:sampled*=reach/distance[-1]
    # Partial Motion steers the measured tangents toward the pin while
    # preserving their length; full Motion retains the captured trajectory.
    # Blend headings, then integrate the captured arc length. Linear point
    # mixing cancels opposing pin/motion vectors and distorts the bend before
    # its final normalization, especially on the next punch exposure.
    segments=np.diff(np.vstack((np.zeros(3),sampled)),axis=0)
    lengths=np.linalg.norm(segments,axis=1)
    # Preserve sampled arc length. Renormalizing a short chord to the
    # entire budget amplified small rotations at a settling pose.
    direction=np.asarray(wind,dtype=float)
    direction/=max(np.linalg.norm(direction),1.e-8)
    tangents=segments/np.maximum(lengths[:,None],1.e-8)
    cosine=np.clip(tangents@direction,-1.,1.)
    angle=np.arccos(cosine)
    transverse=tangents-cosine[:,None]*direction
    magnitude=np.linalg.norm(transverse,axis=1)
    fallback=np.cross(direction,np.eye(3)[int(np.argmin(abs(direction)))])
    fallback/=max(np.linalg.norm(fallback),1.e-8)
    transverse=np.where((magnitude>1.e-7)[:,None],
        transverse/np.maximum(magnitude[:,None],1.e-8),fallback)
    blended=direction*np.cos(angle*influence)[:,None]+transverse*np.sin(angle*influence)[:,None]
    return np.cumsum(blended*lengths[:,None],axis=0)



def _motion_wake(offsets, wind, reach, stations, influence, history):
    """Fit retained motion to the normal brush family's bounded drawing reach."""
    gain=1.+.75*max(0.,min(1.,influence))
    if history is None:
        return _sampled_wake(offsets,wind,reach/gain,stations,influence,history)*gain
    length=float(np.linalg.norm(np.diff(history,axis=0),axis=1).sum())
    if length<1.e-8:return np.zeros((len(stations),3))
    # Preserve historical positions. Rescaling the complete curve around a
    # new root moves all surviving points when the next impact key is shown.
    sampled=_sampled_wake(offsets,wind,min(reach,length),stations,1.,history)
    if length<reach:
        # The static length floor is independent of history lifetime. Extend
        # beyond the historical tail, rather than stretching its old points.
        distance=stations*reach
        arc=np.r_[0.,np.cumsum(np.linalg.norm(np.diff(history,axis=0),axis=1))]
        sampled=np.column_stack([np.interp(np.minimum(distance,length),arc,history[:,i]) for i in range(3)])
        tangent=np.asarray(history[-1])-np.asarray(history[-2])
        tangent/=max(float(np.linalg.norm(tangent)),1.e-8)
        sampled+=np.maximum(distance-length,0.)[:,None]*tangent
    return sampled


def _surface_wake_history(geometry, point):
    # Captured affine transforms already include every parent bone and object
    # transform. Evaluate the SAME material point through those transforms;
    # never replace its path with a corner sweep or reverse its tangents.
    history=_exposure_history(geometry._linear_history_samples,
                             point-geometry._linear_history_origin)
    if not hasattr(geometry,'_linear_gesture_reference'):
        geometry._linear_gesture_reference=_exposure_history(geometry._linear_history_samples)
    return history


def _steered_surface_history(geometry, point, influence):
    """Turn one owner's captured sweep coherently, preserving its local bend."""
    history=_surface_wake_history(geometry,point)
    # Owner steering is constant across all its surface samples. Cache the
    # frame/pin transform, never the point-dependent articulated history.
    steering_key=(tuple(geometry._linear_casting_wind),
        float(getattr(geometry,'_linear_motion_amount',influence)),
        float(getattr(geometry,'_linear_shape_strength',getattr(geometry,'_linear_event_strength',1.))),
        id(geometry._linear_history_samples),tuple(tuple(row) for row in geometry.view_projection))
    cached=getattr(geometry,'_linear_steering_cache',None)
    if cached is not None and cached[0]==steering_key:
        camera_axis,angle,target,shape=cached[1]
    else:
        reference=np.asarray(geometry._linear_gesture_reference)
        lengths=np.linalg.norm(reference,axis=1)
        active=np.flatnonzero(lengths>1.e-7)
        if not len(active):
            # Pure rotation has no center translation. Pick a stable moving
            # surface sample once for the owner, not a different axis per brush.
            reference=getattr(geometry,'_linear_rotation_reference',None)
            if reference is None:
                candidates=[_surface_wake_history(geometry,p) for p in np.asarray(geometry.world_positions)[::max(1,len(geometry.world_positions)//16)]]
                reference=max(candidates,key=lambda h:float(np.linalg.norm(h,axis=1).max()))
                geometry._linear_rotation_reference=reference
            lengths=np.linalg.norm(reference,axis=1);active=np.flatnonzero(lengths>1.e-7)
        if not len(active):return history
        target=np.array(geometry._linear_casting_wind,dtype=float,copy=True)
        target/=max(np.linalg.norm(target),1.e-8)
        matrix=np.asarray(geometry.view_projection)
        camera_axis=np.cross(matrix[0,:3],matrix[1,:3])
        camera_axis/=max(np.linalg.norm(camera_axis),1.e-8)
        # Turn the complete visible gesture by the literal pin share. A 3D
        # shortest-axis rotation rolls a broad arc through the subject at half
        # influence, destroying its visible shape even if its length survives.
        planar_reference=reference-(reference@camera_axis)[:,None]*camera_axis
        planar_lengths=np.linalg.norm(planar_reference,axis=1)
        source_index=int(active[-1])
        if planar_lengths[source_index]<1.e-7:source_index=int(np.argmax(planar_lengths))
        source=planar_reference[source_index]/max(planar_lengths[source_index],1.e-8)
        target_flat=target-camera_axis*float(target@camera_axis)
        target_length=float(np.linalg.norm(target_flat))
        if target_length>1.e-7 and planar_lengths[source_index]>1.e-7:
            target_flat/=target_length
            # Activity controls the bend budget, not the artist's pin share.
            # A slow motion must not silently turn Motion=1 into full pin steering.
            steering=getattr(geometry,'_linear_motion_amount',influence)
            angle=math.atan2(float(camera_axis@np.cross(source,target_flat)),
                             float(source@target_flat))
            angle=max(-math.pi/6.,min(math.pi/6.,angle))*(1.-steering)
        else:angle=0.
        shape=(_motion_shape_weight(getattr(geometry,"_linear_motion_amount",influence))*
               getattr(geometry,"_linear_shape_strength",getattr(geometry,"_linear_event_strength",1.))**2)
        geometry._linear_steering_cache=(steering_key,(camera_axis,angle,target,shape))
    geometry._linear_steering=(camera_axis.copy(),angle,target.copy(),shape)
    rotated=(history*math.cos(angle)+np.cross(camera_axis,history)*math.sin(angle)+
             (history@camera_axis)[:,None]*camera_axis*(1.-math.cos(angle)))
    lengths=np.linalg.norm(np.diff(history,axis=0),axis=1)
    distance=np.r_[0.,np.cumsum(lengths)]
    curve=rotated*shape+distance[:,None]*target*(1.-shape)
    segments=np.diff(curve,axis=0)
    segment_lengths=np.linalg.norm(segments,axis=1)
    headings=np.divide(segments,segment_lengths[:,None],
        out=np.broadcast_to(target,segments.shape).copy(),where=segment_lengths[:,None]>1.e-8)
    return np.vstack((np.zeros(3),np.cumsum(headings*lengths[:,None],axis=0)))


def _cross3(a,b):
    return np.array((a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]))


def _surface_history_heading(geometry, point, wind, influence):
    stored=getattr(geometry,'_linear_history_samples',None)
    if not stored:return np.asarray(wind)
    steering=getattr(geometry,'_linear_steering',None)
    if steering is None:
        history=_steered_surface_history(geometry,point,influence)
        steering=getattr(geometry,'_linear_steering',None)
        if steering is None:return np.asarray(wind)
    coefficients=getattr(geometry,'_linear_launch_coefficients',None)
    if coefficients is None:
        samples=np.asarray(stored,dtype=float)
        coefficients=samples[:,1:]-samples[0,1:]
        geometry._linear_launch_coefficients=coefficients
    offset=np.asarray(point)-geometry._linear_history_origin
    for row in coefficients[1:]:
        first=row[:3]+offset@row[3:].reshape((3,3))
        length=math.sqrt(float(first@first))
        if length>1.e-7:break
    else:return np.asarray(wind)
    axis,angle,target,shape=steering
    # Only the first nonzero segment determines launch. No need to rebuild
    # and resample every old segment for each surface admission test.
    rotated=(first*math.cos(angle)+_cross3(axis,first)*math.sin(angle)+
             axis*float(first@axis)*(1.-math.cos(angle)))
    heading=rotated*shape+target*(length*(1.-shape))
    return heading/max(math.sqrt(float(heading@heading)),1.e-8)


def _surface_history_headings(geometry, points, wind, influence):
    """Evaluate contact launch directions in one batch, with identical history selection."""
    result = np.broadcast_to(wind, points.shape).copy()
    stored = getattr(geometry, '_linear_history_samples', None)
    if not stored or not len(points):
        return result
    # Initialize the same steering/coefficient cache used by the scalar endpoint.
    _surface_history_heading(geometry, points[0], wind, influence)
    steering = getattr(geometry, '_linear_steering', None)
    coefficients = getattr(geometry, '_linear_launch_coefficients', None)
    if steering is None or coefficients is None:
        return result
    offsets = points - geometry._linear_history_origin
    unresolved = np.ones(len(points), dtype=bool)
    axis, angle, target, shape = steering
    cosine, sine = math.cos(angle), math.sin(angle)
    for row in coefficients[1:]:
        indices = np.flatnonzero(unresolved)
        if not len(indices):
            break
        first = row[:3] + offsets[indices] @ row[3:].reshape((3, 3))
        lengths = np.linalg.norm(first, axis=1)
        valid = lengths > 1.e-7
        if not np.any(valid):
            continue
        chosen = indices[valid]
        vectors = first[valid]
        rotated = (vectors * cosine + np.cross(axis, vectors) * sine +
                   (vectors @ axis)[:, None] * axis * (1. - cosine))
        heading = rotated * shape + lengths[valid, None] * target * (1. - shape)
        result[chosen] = heading / np.maximum(np.linalg.norm(heading, axis=1)[:, None], 1.e-8)
        unresolved[chosen] = False
    return result


def _noise(x, seed):
    """Continuous family variation, not a new random length for every mark."""
    k = math.floor(x)
    t = x-k
    t = t*t*(3.-2.*t)
    def value(i):
        return (math.sin(i*127.1+seed*311.7)*43758.5453) % 1.
    return value(k)*(1.-t)+value(k+1)*t


def _walk_surface_inlet(surface, anchor, heading, diagonal, clearance, owners):
    """Short backward surface walk; no projected plane or distant mesh snap."""
    hit,normal,face,distance=surface.find_nearest(anchor,diagonal*.04)
    if hit is None or distance>diagonal*.04:
        return [],[],[]
    points=[];normals=[];labels=[]
    heading=Vector(heading).normalized()
    step=diagonal*.015
    for _ in range(9):
        point=hit+normal*clearance
        other,other_normal,_,_=surface.ray_cast(point+normal*clearance,normal,diagonal*.025)
        if other is not None and other_normal.dot(normal)<-.5:
            break
        points.append(point);normals.append(tuple(normal));labels.append(owners[face])
        tangent=-heading+normal*heading.dot(normal)
        if tangent.length<.1:break
        target=point+tangent.normalized()*step
        next_hit,next_normal,next_face,_=surface.find_nearest(target,step*1.5)
        if next_hit is None or next_normal.dot(normal)<.5:break
        delta=next_hit+next_normal*clearance-point
        if delta.length>step*1.8 or delta.length<clearance:break
        obstruction,obstruction_normal,_,_=surface.ray_cast(point,delta.normalized(),delta.length)
        if obstruction is not None and obstruction_normal.dot(delta)<-1.e-8:break
        hit,normal,face=next_hit,next_normal,next_face
    return points[::-1],normals[::-1],labels[::-1]


def _build_group_paths(*args, **kwargs):
    return [stroke for stroke in _iter_group_paths(*args, **kwargs) if stroke is not None]


def _clearance_route(surface, probes, preferred, cross, across, projected_wind,
                     group_diagonal, clearance):
    """Choose a short exterior route, rather than a remote cap of the rig.

    Every candidate is transverse to the 3D travel. Its support is measured
    against the actual assembled collision mesh, not a source-part normal.
    A small directional preference resolves near ties deterministically.
    """
    candidates=[preferred]
    candidates.extend(cross*math.cos(i*math.pi/4.)+across*math.sin(i*math.pi/4.)
                      for i in range(8))
    best=None
    for direction in candidates:
        if float(direction@projected_wind)<-1.e-6:continue
        offsets=[]
        query=Vector(-direction)
        for point in probes:
            hit=surface.ray_cast(Vector(point+direction*group_diagonal*2.),
                                 query,group_diagonal*4.)[0]
            offsets.append(max(0.,float((np.asarray(hit)-point)@direction)+clearance*2.)
                           if hit is not None else 0.)
        amount=max(offsets,default=0.)
        score=amount*(1.+.12*(1.-float(direction@preferred)))
        if best is None or score<best[0]:best=(score,direction,np.asarray(offsets))
    return (best[1],best[2]) if best is not None else (preferred,np.zeros(len(probes)))


def _iter_group_paths(geometry, focus, behind, aspect, spread, salt,
                      motion_influence=0., background_motion=(0., 0.),
                      background_acceleration=(0., 0.), velocity_scale=1., strength=.72,
                      thickness=.62, _wind_override=None, _excluded_owners=(), _action_influence=0., _density=1., _preview=False):
    if strength <= 0. or thickness <= 0.:
        return []
    # Contact and collision samples decide whether a stroke exists. Keep
    # these identical to Apply; raster quality must not change stroke topology.
    contact_stations = _CONTACT_STATIONS
    refinement_passes = 3
    packets = yield from iter_mesh_packets(geometry)
    if not packets:
        return []
    collision_context=getattr(geometry,'_linear_collision_context',geometry)
    collision_packets=yield from iter_mesh_packets(collision_context)
    # A camera ray outside the projected scene bounds cannot hit this BVH.
    # Compute once on the immutable capture, then reject those queries in bulk.
    if not hasattr(collision_context, '_linear_ray_bounds'):
        clips = np.column_stack((np.asarray(collision_context.world_positions),
                                 np.ones(len(collision_context.world_positions)))) @ np.asarray(collision_context.view_projection).T
        screen_bounds = None
        if len(clips) and np.all(clips[:, 3] > 1.e-6):
            projected = clips[:, :2] / clips[:, 3:4] * .5 + .5
            screen_bounds = (projected.min(0) - 1.e-6, projected.max(0) + 1.e-6)
        collision_context._linear_ray_bounds = screen_bounds
    if not hasattr(collision_context, '_linear_owner_ray_bounds'):
        # Conservative perspective bounds of each immutable owner. A ribbon
        # cannot be occluded by a foreign owner outside its projected bounds.
        # Near-plane crossings keep the unbounded fallback.
        owner_bounds = {}
        if collision_context._linear_ray_bounds is not None:
            clips = np.column_stack((np.asarray(collision_context.world_positions),
                                     np.ones(len(collision_context.world_positions)))) @ np.asarray(collision_context.view_projection).T
            projected = clips[:, :2] / clips[:, 3:4] * .5 + .5
            owner_ids = np.asarray(collision_context.owner_ids)
            for owner, indices in owner_indices(owner_ids).items():
                pixels = projected[indices]
                owner_bounds[int(owner)] = (pixels.min(0)-1.e-6, pixels.max(0)+1.e-6)
        collision_context._linear_owner_ray_bounds = owner_bounds
    # Drawing groups organize gestures; they must never partition collision
    # visibility. Small open gaps can place neighbouring legs in two groups.
    scene_collision=getattr(collision_context,'_linear_scene_collision',None)
    if scene_collision is None:
        all_points=[];all_faces=[];all_owners=[]
        for member_owner,_,member_points,member_faces,_ in collision_packets:
            all_faces.extend((member_faces+len(all_points)).tolist())
            all_owners.extend([member_owner]*len(member_faces))
            all_points.extend(member_points.tolist())
        bounds=np.asarray(all_points)
        scene_collision=(BVHTree.FromPolygons(all_points,all_faces,all_triangles=True),
                         all_owners,bounds.min(0),bounds.max(0))
        collision_context._linear_scene_collision=scene_collision
        yield None
    if _excluded_owners:
        packets=[packet for packet in packets if packet[0] not in _excluded_owners]
        if not packets:return
    if collision_context is not geometry:
        # One owner can contain several disconnected islands. Owner-only
        # lookup assigned every island the last component's collision group.
        def island_key(owner,points):return (owner,tuple(np.round(points.mean(axis=0),7)))
        owner_groups={island_key(packet[0],packet[2]):packet[1] for packet in collision_packets}
        packets=[(owner,owner_groups[island_key(owner,points)],points,faces,surface)
                 for owner,_,points,faces,surface in packets]
    screen = np.asarray(geometry.positions)
    center = (screen[:, :2].min(0)+screen[:, :2].max(0))*.5
    matrix = np.asarray(geometry.view_projection, dtype=float)
    inverse_matrix = np.linalg.inv(matrix)
    wind = np.asarray(dome_direction(focus, center, aspect, behind, matrix))
    if _wind_override is not None:
        wind = np.asarray(_wind_override,dtype=float)
    right = matrix[0, :3]/np.linalg.norm(matrix[0, :3])
    up = matrix[1, :3]/np.linalg.norm(matrix[1, :3])
    camera_axis = np.cross(right, up)
    receding = float(wind@camera_axis) < 0.
    action_bias=np.zeros(3)
    velocities_world=np.asarray(getattr(collision_context,'world_velocities',()))
    if _wind_override is None and _action_influence>0. and len(velocities_world):
        speeds=np.linalg.norm(velocities_world,axis=1)
        active=velocities_world[speeds>max(1.e-7,float(speeds.max())*.25)]
        if len(active):
            action=-np.mean(active,axis=0)
            projected=action-camera_axis*float(action@camera_axis)
            if np.linalg.norm(projected)>.08*max(np.linalg.norm(action),1.e-8):
                action_bias=projected/np.linalg.norm(projected)*min(1.,_action_influence*2.)
    camera_h=inverse_matrix[:,2]
    perspective_camera=Vector(camera_h[:3]/camera_h[3]) if abs(camera_h[3])>1.e-8 else None
    projected_wind=wind-camera_axis*np.dot(wind,camera_axis)
    planar_speed=float(np.linalg.norm(projected_wind))
    projected_length2=float(projected_wind@projected_wind)
    screen_cross=np.cross(camera_axis,projected_wind)
    if planar_speed>1.e-8:screen_cross/=np.linalg.norm(screen_cross)
    direction_mix=min(1.,planar_speed/.4)
    direction_mix=direction_mix*direction_mix*(3.-2.*direction_mix)
    facing=min(1.,abs(float(wind@camera_axis)))
    intensity=max(0.,min(1.,strength))
    old_085=.85**1.25*(.8+1.4*.85**3)/(.72**1.25*(.8+1.4*.72**3))
    length_gain=intensity*(old_085/.5)
    fill = max(0., min(1., (float(thickness)-.08)/.72))
    fill = fill*fill*(3.-2.*fill)
    # Transport a frame from the camera pole. Projecting camera-up onto the
    # wind plane became singular at the exact top/bottom and swapped axes.
    reference = camera_axis if np.dot(wind,camera_axis)>0. else -camera_axis
    rotation = np.cross(reference,wind)
    cross = up+np.cross(rotation,up)+np.cross(rotation,np.cross(rotation,up))/(1.+np.dot(reference,wind))
    cross /= np.linalg.norm(cross)
    across = np.cross(wind, cross)
    groups = getattr(collision_context, '_linear_collision_groups', None)
    if groups is None:
        groups = {}
        for packet in collision_packets:
            groups.setdefault(packet[1], []).append(packet)
        group_bounds = {}
        for group, members in groups.items():
            points = np.concatenate([packet[2] for packet in members])
            lo, hi = points.min(0), points.max(0)
            group_bounds[group] = (float(np.linalg.norm(hi-lo)), (lo+hi)*.5)
            yield None
        collision_context._linear_group_bounds = group_bounds
        collision_context._linear_collision_groups = groups
    # Scene collision bounds must not set a rig's artistic dimensions.
    drawing_context=getattr(geometry,'_linear_drawing_context',geometry)
    drawing_sizes=getattr(drawing_context, '_linear_drawing_sizes', None)
    if drawing_sizes is None:
        drawing_owners=set(int(owner) for owner in drawing_context.owner_ids)
        drawing_sizes={}
        for group_id,members in groups.items():
            local=[packet[2] for packet in members if int(packet[0]) in drawing_owners]
            if local:
                drawing_sizes[group_id]=float(np.linalg.norm(np.ptp(np.concatenate(local),axis=0)))
        drawing_context._linear_drawing_sizes = drawing_sizes
    motion = {}
    motion_shape=_motion_shape_weight(motion_influence)
    moving_samples=(motion_influence > 1.e-6 and geometry.velocities and geometry.accelerations)
    if moving_samples:
        velocities = np.asarray(geometry.velocities)-background_motion
        accelerations = np.asarray(geometry.accelerations)-background_acceleration
        world_velocities=np.asarray(getattr(geometry,'world_velocities',()))
        world_accelerations=np.asarray(getattr(geometry,'world_accelerations',()))
        moving_samples=bool(np.any(velocities) or np.any(accelerations) or
                            np.any(world_velocities) or np.any(world_accelerations) or
                            len(getattr(geometry,'_linear_history',())))
    if moving_samples:
        # Pack the channels once. Each brush uses the same eight neighbours
        # and weights for velocity, acceleration and four history samples.
        # One weighted product avoids eight independent average validations
        # and rebuilding the complete history arrays inside every brush.
        motion_channels=[velocities,accelerations]
        world_motion=len(world_accelerations)==len(geometry.positions)
        history_motion=world_motion and len(getattr(geometry,'world_before',()))==len(geometry.positions)
        if world_motion:motion_channels.extend((world_accelerations,world_velocities))
        if history_motion:
            history_arrays=[np.asarray(getattr(geometry,name)) for name in
                ('world_before','world_before_mid','world_after_mid','world_after')]
            history_means=np.array([values.mean(axis=0) for values in history_arrays])
            motion_channels.extend(history_arrays)
        channel_edges=np.cumsum([0]+[values.shape[1] for values in motion_channels])
        motion_channels=np.concatenate(motion_channels,axis=1)
        ids = np.asarray(geometry.owner_ids)
        trees = getattr(geometry, '_linear_motion_trees', None)
        if trees is None:
            trees = geometry._linear_motion_trees = {}
            world = np.asarray(geometry.world_positions)
            for owner, indices in owner_indices(ids).items():
                tree = KDTree(len(indices))
                for index in indices:
                    tree.insert(Vector(world[index]), int(index))
                tree.balance()
                trees[owner] = tree
        motion = trees
    strokes = []
    # Surface quadrature stays part-local so a non-convex rig cannot jump
    # between distant surfaces. Composition and channel closure belong to
    # the assembled group; owners supply real contact support, not separate
    # independent fan centers.
    sources={}
    for packet in packets:
        sources.setdefault((packet[1],packet[0]),[]).append(packet)
    source_cache=getattr(geometry,'_linear_source_geometry',None)
    if source_cache is None:
        source_cache=geometry._linear_source_geometry={}
    for source_index, ((group, source_owner), members) in enumerate(sorted(sources.items())):
        source_data=source_cache.get((group,source_owner))
        if source_data is None:
            vertices, faces, owners = [], [], []
            for owner, _, points, triangles, _ in members:
                faces.extend((triangles+len(vertices)).tolist())
                vertices.extend(points.tolist())
                owners.extend([owner]*len(triangles))
            vertices = np.asarray(vertices)
            origin = (vertices.min(0)+vertices.max(0))*.5
            diagonal = float(np.linalg.norm(vertices.max(0)-vertices.min(0)))
            triangles=np.asarray(faces)
            edges=np.unique(np.sort(np.stack((triangles[:,(0,1,2)],triangles[:,(1,2,0)]),axis=-1).reshape(-1,2),axis=1),axis=0)
            source_data=(vertices,faces,owners,origin,diagonal,edges)
            source_cache[(group,source_owner)]=source_data
        vertices,faces,owners,origin,diagonal,edges=source_data
        if diagonal < 1.e-7:
            continue
        # A pin/spread edit does not change captured geometry. Retain the
        # acceleration structure with that capture, not in a global live cache.
        bvhs = getattr(geometry, '_linear_envelope_bvhs', None)
        if bvhs is None:
            bvhs = geometry._linear_envelope_bvhs = {}
        source_key = ('source',group,source_owner)
        bvh = bvhs.get(source_key)
        if bvh is None:
            bvh = bvhs[source_key] = BVHTree.FromPolygons(vertices.tolist(), faces, all_triangles=True)
        group_diagonal, group_origin = collision_context._linear_group_bounds[group]
        drawing_diagonal=drawing_sizes.get(group,diagonal)
        collision_bvh,collision_owners,collision_lo,collision_hi=scene_collision
        distance = diagonal*2.
        clearance=diagonal*.004
        def camera_hidden(point):
            origin_camera=perspective_camera if perspective_camera is not None else point+Vector(camera_axis)*group_diagonal*4.
            ray=point-origin_camera;length=ray.length
            if length<1.e-8:return False
            hit=collision_bvh.ray_cast(origin_camera,ray/length,max(0.,length-clearance*.25))[0]
            return hit is not None
        query_origin=Vector(origin)
        query_wind=Vector(wind)
        along = (vertices-origin)@wind
        lo, hi = float(along.min()), float(along.max())
        axial_radius=max((hi-lo)*.5,diagonal*.01)
        # All meridians share the wind and a cyclic ordering. A nearby facet
        # can change the outer radius but can never rotate a stroke azimuth.
        local = vertices-origin
        transverse_vertices = np.column_stack((local@cross, local@across))
        # Only projected silhouette/boundary edges can maximize a meridian
        # radius. Interior edges shared by consistently wound faces with the
        # same strict facing sign cannot bound the projected union. Keep all
        # grazing, open, non-manifold and inconsistent-winding cases.
        topology_key=('silhouette_topology',group,source_owner)
        topology=source_cache.get(topology_key)
        if topology is None:
            triangles=np.asarray(faces,dtype=np.int32)
            directed=np.stack((triangles[:,(0,1,2)],triangles[:,(1,2,0)]),axis=-1).reshape(-1,2)
            unique,inverse,counts=np.unique(np.sort(directed,axis=1),axis=0,return_inverse=True,return_counts=True)
            order=np.argsort(inverse,kind='stable');offset=np.cumsum(counts)-counts
            first=order[offset];last=order[offset+counts-1]
            paired=(counts==2)&(directed[first,0]==directed[last,1])&(directed[first,1]==directed[last,0])
            face_points=vertices[triangles]
            normals=np.cross(face_points[:,1]-face_points[:,0],face_points[:,2]-face_points[:,0])
            topology=(normals,np.linalg.norm(normals,axis=1)*1.e-10,first//3,last//3,paired)
            source_cache[topology_key]=topology
        normals,epsilon,left,right_face,paired=topology
        facing_value=normals@wind
        sign=np.where(facing_value>epsilon,1,np.where(facing_value < -epsilon,-1,0))
        contour_edges=edges[~(paired&(sign[left]!=0)&(sign[left]==sign[right_face]))]
        edge_a = transverse_vertices[contour_edges[:,0]]
        edge_b = transverse_vertices[contour_edges[:,1]]
        edge_delta = edge_b-edge_a
        axial_a = along[contour_edges[:,0]]
        axial_delta = along[contour_edges[:,1]]-axial_a
        radius_numerator = -(edge_a[:,0]*edge_delta[:,1]-edge_a[:,1]*edge_delta[:,0])
        def exterior_radius(phi):
            d = np.array((math.cos(phi), math.sin(phi)))
            den = edge_delta[:,0]*d[1]-edge_delta[:,1]*d[0]
            numerator = -(edge_a[:,0]*d[1]-edge_a[:,1]*d[0])
            t = np.divide(numerator, den, out=np.full_like(den,-1.), where=abs(den)>1.e-10)
            # Same line intersection in determinant form. Avoid rebuilding
            # and projecting a full E-by-2 point array for every meridian.
            radius = np.divide(radius_numerator, den, out=np.zeros_like(den), where=abs(den)>1.e-10)
            valid = (t>=0.)&(t<=1.)&(radius>0.)
            return float(radius[valid].max()) if valid.any() else diagonal*.025
        rim_cache = getattr(geometry,"_linear_rim_cache",None)
        if rim_cache is None:
            rim_cache=geometry._linear_rim_cache={}
        rim_key=(source_key,tuple(wind))
        cached_rim=rim_cache.get(rim_key)
        if cached_rim is None:
            phis = np.linspace(0., 2.*math.pi, 385)
            radial = np.cos(phis)[:, None]*cross+np.sin(phis)[:, None]*across
            sampled_radii = []
            for sample_index in range(0,len(phis),32):
                angles_chunk=phis[sample_index:sample_index+32]
                dx,dy=np.cos(angles_chunk),np.sin(angles_chunk)
                den=edge_delta[:,0,None]*dy-edge_delta[:,1,None]*dx
                numerator=-(edge_a[:,0,None]*dy-edge_a[:,1,None]*dx)
                ratios=np.divide(numerator,den,out=np.full_like(den,-1.),where=abs(den)>1.e-10)
                lengths=np.divide(radius_numerator[:,None],den,out=np.zeros_like(den),where=abs(den)>1.e-10)
                valid=(ratios>=0.)&(ratios<=1.)&(lengths>0.)
                values=np.max(np.where(valid,lengths,0.),axis=0)
                sampled_radii.extend(np.where(values>0.,values,diagonal*.025))
                yield None  # One bounded vectorized rim chunk.
            radii = np.asarray(sampled_radii)
            ring = radial*radii[:,None]
            arc = np.r_[0., np.cumsum(np.linalg.norm(np.diff(ring, axis=0), axis=1))]
            if len(rim_cache)>=8:rim_cache.pop(next(iter(rim_cache)))
            rim_cache[rim_key]=(phis,radii,arc)
        else:
            phis,radii,arc=cached_rim
        count=min(144,max(48,int(arc[-1]/(diagonal*.044))))
        count=max(16,int(count*_density))
        # Nonuniform sub-spacing avoids a raster-row comb while preserving
        # the ordering and shared family envelope.
        index = np.arange(count)
        # Positive correlated spacing gathers neighboring carriers into
        # bundles. Thickness closes their internal gaps without painting a
        # separate opaque band on the subject's surface.
        spacing = np.exp((.25 + .35*min(1., thickness)) *
                         (np.sin(index*.43)+.45*np.sin(index*.17+group)))
        spacing*=np.array([.30+1.60*_noise(i*1.83,group+71.2)**1.3 for i in index])
        targets = (np.cumsum(spacing)-spacing*.5)*arc[-1]/spacing.sum()
        angles = np.interp(targets, arc, phis)
        candidates=[(i,phi,False) for i,phi in enumerate(angles)]
        # Interleave shorter, lighter carriers in the actual surface gaps.
        # Keep parent identities unchanged and use stable, uneven offsets;
        # these pass the same mesh-contact/seal/depth checks as every parent.
        for i,start in enumerate(targets):
            end=targets[i+1] if i+1<len(targets) else targets[0]+arc[-1]
            hand_gap=_noise(i*1.71,group+37.2)
            # Narrow spaces already overlap at the heel. Spend tracing work
            # on wider channels and leave occasional breathing gaps.
            if end-start<arc[-1]/count*.55:continue
            fractions=(.30+.40*hand_gap,)
            if end-start>arc[-1]/count*1.6:
                fractions=(.20+.15*hand_gap,.63+.16*hand_gap)
            for j,fraction in enumerate(fractions):
                target=(start+(end-start)*fraction)%arc[-1]
                candidates.append((i+.31+j*.27,float(np.interp(target,arc,phis)),True))
        for i, phi, gap_fill in candidates:
            # Preview and final share all primary and gap-fill carriers.
            # Adapt raster/effect sampling, never the authored stroke population.
            yield None
            outward = cross*math.cos(phi)+across*math.sin(phi)
            radius = float(np.interp(phi,phis,radii))
            # Opposite sides of a body share the same bundle at side views.
            # Independent front/rear length envelopes reveal rectangular
            # occlusion cuts when the long rear member emerges from a mesh.
            # Family identity belongs to the cyclic source, not a crossfade
            # between unrelated noise coordinates as the pin faces camera.
            if planar_speed>1.e-8:
                planar_family=float((origin+outward*radius-group_origin)@screen_cross)/group_diagonal*18.
            else:
                planar_family=0.
            group_radial=origin+outward*radius-group_origin
            group_phi=math.atan2(float(group_radial@across),float(group_radial@cross))
            # Near the camera axis, organize a few unequal gesture groups;
            # many equal angular lobes read as a decorative radial fan.
            family=planar_family*direction_mix+(group_phi*3./math.pi)*(1.-direction_mix)
            if _wind_override is not None:
                # End-on motion must not collapse a whole limb onto one
                # projected noise coordinate. Carry the existing mass/peak
                # hierarchy around its actual surface circumference.
                family=family*(1.-motion_shape)+(phi*3./math.pi)*motion_shape
            mass = _noise(family, group+.17)
            peak = _noise(family*1.71, group+2.31)**2
            hand = _noise(i*1.31, group+5.7)
            # Numerical clearance is not a random artistic displacement.
            # Stagger heels over the downstream half of the side face, where
            # the loaded action begins. Upstream cap pickups were the stray
            # black wedges on the otherwise white leading torso/leg faces.
            # Moving strokes keep the same full surface pickup as static
            # strokes. Only their own released path is motion-shaped.
            begin = .18+.12*_noise(family*.63,group+8.3)+.12*(hand-.5)
            # Supporting strokes pick up at staggered positions on the face,
            # filling the channels between long roots without longer fans.
            if gap_fill:begin-=.12+.16*_noise(i*.97,group+28.1)
            # Compact parts need face travel before release; seeding only
            # their downstream bevel leaves a few thin hanging strands.
            compact=max(0.,min(1.,(.34-diagonal/max(group_diagonal,1.e-8))/.14))
            begin-=.30*compact
            if receding:
                # A receding pole must pick up the camera-facing cap before
                # walking to its outlet. Starting beyond the midpoint seeds
                # only the hidden rear face and deletes the entire channel.
                cap_weight=facing**8
                begin=begin*(1.-cap_weight)+(.24+.12*hand)*cap_weight
            departure = .72+.10*_noise(family*.51,group+9.7)
            if _wind_override is not None:
                # A long limb's side can remain parallel to its trajectory
                # past the static contact interval. Reach the trailing cap
                # before requiring a positive departure normal.
                departure=departure*(1.-motion_shape)+.98*motion_shape
            # Trace the upstream face AND the side with one meridian at every
            # dome direction. Axial side-only rays cannot ever hit a flat cap;
            # at the camera pole that omitted the entire readable channel.
            # Elliptical query directions account for a limb's aspect ratio.
            # begin is an axial fraction, not a polar angle. The previous
            # affine conversion moved the heel onto the upstream cap and
            # painted disconnected, sideways contact blobs at joints.
            # Compact-part, filler and motion offsets can add up to a
            # negative axial fraction. Bound the physical interval before
            # converting it to polar angles; acos cannot accept that value.
            departure=max(0.,min(1.,departure))
            begin=max(0.,min(departure,begin))
            theta_begin=math.acos(1.-2.*begin)
            theta_end=math.acos(1.-2.*departure)
            angles_contact=theta_begin+(theta_end-theta_begin)*contact_stations
            query_outward=Vector(outward)
            def contact_sample(theta):
                ray_direction=(query_wind*(-axial_radius*math.cos(theta))+
                               query_outward*(radius*math.sin(theta)))
                ray_direction.normalize()
                hit,normal,face,_=bvh.ray_cast(query_origin+ray_direction*distance,
                                             -ray_direction,distance*2.)
                if hit is None:return None
                # A distant mesh along the sampling ray does not seal this
                # contact. Local embedded/seam tests below admit the support;
                # actual outgoing segments and raster depth resolve occlusion.
                normal=np.asarray(normal)
                # Offset from the actual supporting face, not just sideways.
                point=np.asarray(hit)+normal*clearance
                # A sub-brush-width opposing face seals this contact channel.
                # Test the assembled group, not a camera-facing hole mask.
                seal=min(diagonal*.045,group_diagonal*.012)
                seal_origin=Vector(np.asarray(hit)+normal*diagonal*1.e-5)
                opposite,opposite_normal,_,_=collision_bvh.ray_cast(
                    seal_origin,Vector(normal),seal)
                if opposite is not None and float(np.dot(opposite_normal,normal))<-.25:
                    return None
                if _sealed_contact(collision_bvh,collision_owners,int(owners[face]),
                        hit,normal,seal,diagonal*1.e-5):
                    return None
                return (theta,point,normal,int(owners[face]))
            samples=[];runs=[]
            # A sealed early interval must not hide a later exterior interval
            # on the same meridian. Keep one contiguous run, never bridge gaps.
            for theta in angles_contact:
                sample=contact_sample(theta)
                if sample is None:
                    if len(samples)>=2:runs.append(samples)
                    samples=[]
                else:samples.append(sample)
            if len(samples)>=2:runs.append(samples)
            samples=max(runs,key=lambda run:(run[-1][0]-run[0][0],run[-1][0]),default=[])
            if len(samples)<2:continue
            # A disconnected depth jump is not a channel across the body.
            # Release before the jump and let the collision stage route the
            # outgoing gesture; never join two distant visible surfaces.
            for sample_index in range(1,len(samples)):
                if samples[sample_index][3]!=samples[sample_index-1][3] and np.linalg.norm(
                        samples[sample_index][1]-samples[sample_index-1][1])>diagonal*.025:
                    samples=samples[:sample_index]
                    break
            if len(samples)<2:continue
            for _ in range(refinement_passes):
                refined=[];refined_runs=[]
                for left,right_sample in zip(samples[:-1],samples[1:]):
                    refined.append(left)
                    if float(left[2]@right_sample[2])<.98:
                        midpoint=contact_sample((left[0]+right_sample[0])*.5)
                        if midpoint is None:
                            # Refinement found a closed bevel between two
                            # coarse hits. Split there; do not erase the valid
                            # face on either side or bridge the closed interval.
                            if len(refined)>=2:refined_runs.append(refined)
                            refined=[]
                        else:refined.append(midpoint)
                refined.append(samples[-1])
                if len(refined)>=2:refined_runs.append(refined)
                samples=max(refined_runs,key=lambda run:run[-1][0]-run[0][0],default=[])
                if len(samples)<2:break
            if len(samples)<2:continue
            points=np.asarray([sample[1] for sample in samples])
            longitudinal=(points-origin)@wind
            transverse=(points-origin)@outward
            contact_normals=[sample[2] for sample in samples]
            labels=[sample[3] for sample in samples]
            release_headings=(_surface_history_headings(geometry,points,wind,motion_influence)
                if _wind_override is not None else np.broadcast_to(wind,points.shape))
            separating=np.flatnonzero(np.einsum('ij,ij->i',np.asarray(contact_normals),release_headings)>.12)
            if len(separating):
                release=max(2,int(separating[0])+1)
                longitudinal=longitudinal[:release]
                transverse=transverse[:release]
                contact_normals=contact_normals[:release]
                labels=labels[:release]
            # Smooth outward only: do not carve through a bevel to smooth it.
            # Retain ray-hit contact, including bevels. Outward smoothing
            # inflated the root away from the actual supporting surface.
            # Keep the true hit and its full normal clearance. Reconstructing
            # in only two meridian axes dropped the normal's third component
            # and buried contact centers at oblique faces/bevels.
            points=points[:len(transverse)]
            raw_transverse=(points-origin)@outward
            points=points+outward*(transverse-raw_transverse)[:,None]
            # Keep rear sources too. Their own geometry is depth-tested; when
            # they clear the silhouette they must remain eligible to emerge.
            owner = int(labels[-1])
            if _wind_override is not None and not len(separating):
                # A motion bundle leaves the trailing surface, not every
                # meridian around the fist (the radial tooth/eyelash pattern).
                continue
            if _wind_override is not None:
                # Reconstruct the loaded inlet along the same heading as its
                # recorded tail. A radial meridian joined to a rotated history
                # made a sideways elbow even when the history itself was smooth.
                heading=_surface_history_heading(geometry,points[-1],wind,motion_influence)
                inlet,inlet_normals,inlet_owners=_walk_surface_inlet(
                    bvh,Vector(points[-1]),heading,diagonal,clearance,owners)
                if len(inlet)<2:
                    continue
                if len(inlet)>=2:
                    points=np.asarray(inlet)
                    contact_normals=inlet_normals
                    labels=inlet_owners
                    longitudinal=(points-origin)@wind
                    transverse=(points-origin)@outward
            # Opposing nearby surfaces close an internal seam. Do not emit
            # a wake out of that crack merely because the source packet's
            # own boundary ends there. Spatially separate components are not
            # included in this collision BVH and keep independent outlets.
            seam_normal=Vector(contact_normals[-1]).normalized()
            seam_origin=Vector(points[-1])+seam_normal*clearance
            seam_hit,seam_other,seam_face,_=collision_bvh.ray_cast(
                seam_origin,seam_normal,max(clearance*2.,diagonal*.025))
            if seam_hit is not None and seam_other.dot(seam_normal)<-.5:
                continue
            # Unequal runs of accents and supporting marks, not a repeating
            # long/medium/short comb along every mesh contour.
            role=_noise(i*.79,group+21.4)
            tier = 1 if gap_fill else (0 if role>.61 else (1 if role>.23 else 2))
            # Linear response: default .5 now matches former .25 reach.
            # Broad short carriers build mass; only selected accents get a
            # long release. Not every member is a full-length tapered spike.
            lengths = (.045+.085*mass+.22*peak,
                       .028+.060*mass+.13*peak,
                       .013+.025*mass+(.12*peak if hand>.94 else .010))
            reach_scale=(drawing_diagonal*(1.-motion_influence)+
                         min(drawing_diagonal,diagonal*1.15)*motion_influence
                         if _wind_override is not None else drawing_diagonal)
            reach = reach_scale*lengths[tier]*length_gain*(.60+.80*hand)
            if gap_fill:
                reach*=.22+.56*_noise(i*2.13,group+43.1)
            static_reach=reach
            motion_profile=1.
            if _wind_override is not None:
                # Captured travel sets a moving limb's budget. Small face
                # islands and static accent tiers must not erase a punch arc.
                captured_reach=getattr(geometry,'_linear_motion_reach',0.)
                motion_amount=getattr(geometry,'_linear_motion_amount',motion_influence)
                # History already loses spatial reach as the limb settles.
                # Do not multiply that decay by directional confidence again.
                motion_reach=(2./3.)*captured_reach*motion_shape*(intensity/.25)*(1.+.75*motion_shape)
                # Preserve the normal length hierarchy. Motion can extend
                # its own brush, but cannot collapse it below the static reach.
                # Static accent lengths are not motion exposure fractions:
                # dividing them by .30 reduced most complete sweeps to tiny
                # disconnected tips. Keep a broad parent and shorter companions.
                motion_profile=(.80+.20*hand,.48+.32*hand,.22+.24*hand)[tier]
                if gap_fill:motion_profile*=.55+.35*_noise(i*2.13,group+43.1)
                reach=max(static_reach,motion_reach*motion_profile)
            # Length is a world-space budget, independent of pin latitude.
            # Thickness fills the heel via overlap, not by making every short
            # carrier as long as the primary family (the previous slab floor).
            # Keep approaching geometry safely away from the camera plane.
            # A near-pole tail crossing it explodes into a giant radial spike.
            if perspective_camera is not None and float(wind@camera_axis)>1.e-6:
                camera_distance=float((np.asarray(perspective_camera)-points[-1])@camera_axis)
                reach=min(reach,max(clearance*4.,camera_distance*.42/float(wind@camera_axis)))
            tangent = points[-1]-points[-min(3,len(points))]
            tangent /= max(np.linalg.norm(tangent), 1.e-8)
            # One ordered fan, with a common downstream axis. Discard any
            # contact tangent that points upstream instead of creating a hook.
            # Spread follows the supporting mesh side, not the azimuth of an
            # imaginary cylinder. Flat facets share a heading; bevels vary it
            # continuously, instead of sending neighbouring carriers across
            # each other through unrelated radial directions.
            flow_outward=np.mean(contact_normals[-3:],axis=0)
            flow_outward-=wind*float(flow_outward@wind)
            flow_length=float(np.linalg.norm(flow_outward))
            flow_outward=flow_outward/flow_length if flow_length>1.e-6 else outward.copy()
            # The assembled subject supplies the large-scale escape heading.
            # A head and a torso must not each create their own rectangular
            # starburst at the camera pole. Local face normals still guide
            # contact; the released family opens away from its group's axis.
            group_outward=points[-1]-group_origin
            group_outward-=wind*float(group_outward@wind)
            group_length=float(np.linalg.norm(group_outward))
            if group_length>diagonal*1.e-5:
                group_outward/=group_length
                # The assembled-body fan may guide a local outlet, but must
                # never reverse it. Opposing head/shoulder normals previously
                # folded the contact-to-tail join into a tight V or triangle.
                agreement=float(group_outward@flow_outward)
                group_blend=min(.65,.45/max(1.-agreement,1.e-6))
                flow_outward=group_blend*group_outward+(1.-group_blend)*flow_outward
                flow_outward/=max(np.linalg.norm(flow_outward),1.e-8)
            # Outward escape may oppose the pin's projected drift. Removing
            # that component deletes the upper halo for a downward pin.
            lateral = flow_outward*min(.35,max(0., float(tangent@outward)))
            bend = np.zeros(3)
            history_velocity=None
            history_offsets=None
            if owner in motion:
                samples = motion[owner].find_n(Vector(points[0]), 8)
                indices = [sample[1] for sample in samples]
                weights = 1./np.maximum([sample[2] for sample in samples], diagonal*.01)
                channels=(weights@motion_channels[indices])/weights.sum()
                v = channels[channel_edges[0]:channel_edges[1]]/max(velocity_scale, 1.e-6)
                a = channels[channel_edges[1]:channel_edges[2]]/max(velocity_scale, 1.e-6)
                # Backward trajectory: -v*t + .5*a*t^2. Local samples retain
                # opposing limb motion that an object-wide average cancels.
                cue = np.clip(-v*.30+a*.12, - .6, .6)*min(1., motion_influence)
                bend = (right*cue[0]+up*cue[1])*reach
                if world_motion:
                    acceleration = channels[channel_edges[2]:channel_edges[3]]
                    velocity = channels[channel_edges[3]:channel_edges[4]]
                    history_velocity=velocity
                    bend=np.zeros(3)
                    if history_motion:
                        history_offsets=channels[channel_edges[4]:].reshape((4,3))
                        # A coherent bone arc leads the bundle; retain a
                        # smaller local rotational offset across its surface.
                        history_offsets=.75*history_means+.25*history_offsets
            t = _MOTION_TAIL_STATIONS if owner in motion else _STATIC_TAIL_STATIONS
            # Do not add a body-height minimum to every vertical member:
            # that erases the short layers and creates a solid curtain.
            tail = points[-1]+wind*(reach*t[:, None])
            if history_offsets is not None:
                history=getattr(geometry,'_linear_history',None)
                stored=getattr(geometry,'_linear_history_samples',None)
                if stored:
                    history=_steered_surface_history(geometry,points[-1],motion_influence)
                # Retain the whole incoming bend while this family catches
                # up. The static family sets its own reach; the captured
                # history adds a decaying extension instead of a shared cap.
                wake_reach=reach
                tail=points[-1]+_motion_wake(history_offsets,
                    getattr(geometry,'_linear_casting_wind',wind),wake_reach,t,
                    1. if stored else motion_influence,history)
                # Catch-up changes reach first. The owner-level return weight
                # relaxes steering/shape only near the end; applying a second
                # per-family bend fade here prematurely straightened short arcs.
                # The recorded surface history supplies the bend. A second
                # curvature multiplier created an isolated hook beside the
                # otherwise coherent bundle.
                departure=tail[0]-points[-1]
                if float(departure@contact_normals[-1]) < -1.e-5*np.linalg.norm(departure):
                    # Surface rotation changes the local trailing side. A
                    # leading face whose past position lies inside today's
                    # limb must not launch a folded loop through its volume.
                    continue
            elif history_velocity is not None:
                tail=points[-1]+_history_wake(history_velocity,acceleration,
                    wind,reach,t,motion_influence)
            # The pin supplies one copied world direction. Only explicit
            # spread may open static trajectories away from that direction.
            tail += lateral*(reach*max(0.,spread)*.039*(1.-np.exp(-4.*t))[:,None])
            # Open around the supporting form, then settle into shared wind;
            # an accelerating transverse fan creates a spiky-ball silhouette.
            fan=_channel_opening(t,spread,facing)
            if history_offsets is not None:
                fan*=1.-.65*motion_shape
            projected_fan=flow_outward-camera_axis*float(flow_outward@camera_axis)
            fan_scale=1./max(.55,float(np.linalg.norm(projected_fan)))
            tail += flow_outward*(reach*fan*fan_scale)[:,None]+bend*(t*t)[:,None]
            # The regular channel opening above is the entire spread budget.
            # Do not add a pole-facing halo or a second axial opening: those
            # amplified centered pins beyond the authored Spread value.
            azimuth_tangent = -cross*math.sin(phi)+across*math.cos(phi)
            tail += azimuth_tangent*(reach*max(0.,spread)*(hand-.5)*.0015*t*(2.-t))[:,None]
            if history_velocity is None:
                # Linear subject gestures leave the mesh along a straight
                # world-space ray. Only captured motion supplies an arc.
                tail=points[-1]+(tail[-1]-points[-1])*t[:,None]
            # The casting wind selects the hemisphere. Retain the actual
            # 3D opening and motion offsets instead of flattening all free
            # stations onto a shared camera-depth ramp (flat at the rim).
            # Projection happens only in ribbon generation. Do not stretch
            # short tails in NDC or relocate them across a camera silhouette.
            # Opening and curvature consume the same length budget, rather
            # than adding unchecked travel on top of the requested reach.
            displacement=tail-points[-1]
            arc=float(np.linalg.norm(np.diff(np.vstack((np.zeros(3),displacement)),axis=0),axis=1).sum())
            if arc>reach:
                if history_offsets is not None:
                    # Remove excess from the old end; do not retime every
                    # retained point merely because this frame has a new root.
                    path=np.vstack((points[-1],tail))
                    distances=np.r_[0.,np.cumsum(np.linalg.norm(np.diff(path,axis=0),axis=1))]
                    tail=np.column_stack([np.interp(t*reach,distances,path[:,k]) for k in range(3)])
                else:
                    tail=points[-1]+displacement*(reach/arc)
            # Extend only outward along this meridian; disconnected groups
            # never contribute a collision surface or pull a trail sideways.
            # Preserve the world-space path and its natural foreshortening.
            # No screen-length compensation for depth-facing trails.
            joined=np.vstack((points,tail))
            # Use the local supporting face's escape normal. A meridian's
            # radial axis can point along a visible leg and lift a collision
            # into a long, unrelated vertical stripe.
            escape=np.mean(contact_normals[-3:],axis=0)
            escape-=wind*np.dot(escape,wind)
            # Clearance must not visibly reverse a directed stroke. Keep the
            # supporting normal's depth/lateral components, but remove an
            # upstream projected component before resolving the obstacle.
            # Translation of camera framing has no effect on these vectors.
            if projected_length2>1.e-4:
                escape-=projected_wind*min(0.,float(escape@projected_wind)/projected_length2)
            escape/=max(np.linalg.norm(escape),1.e-8)
            if np.linalg.norm(escape)<.5: escape=outward
            radial_position=(joined-origin)@escape
            deflection=np.zeros(len(joined))
            check_start=max(0,len(points)-3)
            # A nearest face's signed distance is not an inside test at joints
            # or disconnected shells. Require an actual entering segment hit.
            blocked=[]
            deltas=np.diff(joined,axis=0)
            step_lengths=np.linalg.norm(deltas,axis=1)
            step_axes=deltas/np.maximum(step_lengths[:,None],1.e-8)
            for sample in range(max(1,check_start),len(points)):
                delta=deltas[sample-1]
                length=float(step_lengths[sample-1])
                if length<1.e-8: continue
                hit,normal,_,_=collision_bvh.ray_cast(
                    Vector(joined[sample-1]),Vector(step_axes[sample-1]),length)
                if hit is not None and np.dot(normal,delta)<-1.e-8:
                    blocked.append(sample)
            # A blocked surface inlet is sealed, not an invitation to lift
            # the brush onto another mesh. Retain the sampled face contact
            # or reject it; translating this band caused the offset bleed.
            if blocked:
                continue
            contact=len(points)
            normals=np.asarray(contact_normals+[contact_normals[-1]]*(contact-len(contact_normals)))
            path_coordinates=np.vstack((points, tail))
            # Released ink cannot route around a blocking mesh. Such a
            # detour moved a sealed-joint trail sideways and let it emerge
            # as an offset stripe. Clip at the first solid entry below.
            free_route_verified=False
            # Collision routing may move in all three dimensions. Validate
            # its final geometry without overwriting the clearance depth.
            path = list(map(Vector,path_coordinates.tolist()))
            departure_axis=path[contact]-path[contact-1]
            if _wind_override is None and departure_axis.length>1.e-8:
                first_hit,first_normal,_,_=collision_bvh.ray_cast(
                    path[contact-1],departure_axis.normalized())
                if first_hit is not None and first_normal.dot(departure_axis)>1.e-8:
                    # A source embedded in a closed neighbouring shell has no
                    # visible free-air outlet. Do not let its hidden tail exit
                    # the shell later as a detached stripe.
                    path=[]
            # A released gesture cannot tunnel through a closed neighbour and
            # reappear on its far side. Stop on first entry; never glue the
            # free trail back onto the rear surface or draw a second fragment.
            # Reuse the exact segment checks above when no subsequent
            # deflection changed the coordinates. Only a changed last route
            # needs this second pass; ordinary free wakes need no duplicate
            # BVH walk on every pin update.
            for sample in (() if free_route_verified else range(contact,len(path))):
                delta=path[sample]-path[sample-1]
                length=delta.length
                if length<1.e-8:continue
                collision_direction=delta/length
                collision_origin=path[sample-1]
                collision_remaining=length
                entry=None
                # Motion may cross its source's current volume while tracing
                # its past pose. That exemption never applies to other meshes.
                for crossing in range(16):
                    hit,normal,hit_face,_=collision_bvh.ray_cast(collision_origin,collision_direction,collision_remaining)
                    if hit is None:break
                    if normal.dot(delta)<-1.e-8 and (
                            _wind_override is None or int(collision_owners[hit_face])!=owner):
                        entry=hit
                        break
                    advance=(hit-collision_origin).length+max(clearance*.05,1.e-7)
                    collision_remaining-=advance
                    if collision_remaining<=0.:break
                    collision_origin+=collision_direction*advance
                if entry is not None:
                    contact_distance=(entry-path[sample-1]).length
                    margin=min(clearance,contact_distance*.25)
                    path=path[:sample]+[entry-collision_direction*margin]
                    break
            # An occluded outlet is not a short impact gesture. Keeping its
            # full-width contact patch produced isolated shoulder/hip blobs.
            support_only=False
            if len(path)<contact or contact<2:
                continue
            free_length=sum((b-a).length for a,b in zip(path[contact-1:-1],path[contact:]))
            if free_length<min(reach*.12,diagonal*.025):
                if _wind_override is not None:continue
                support_only=True
                path=path[:contact]
            # Require a readable run under physical scene depth. A trail in
            # front of a projected mesh is visible; ownership alone cannot
            # erase one half of the hemisphere at the control's rim.
            visible_run=longest_run=0
            foreign_outlet=False
            cropped_tip=False
            exterior_samples=0
            # Motion paths retain historical visibility; this loop's results
            # are consumed only by static outlet clipping. Skip dead queries,
            # while the physical segment collisions and ribbon depth remain.
            for free_index,point in (() if _wind_override is not None else enumerate(path[contact:],contact)):
                eye=(perspective_camera if perspective_camera is not None else
                     point+Vector(camera_axis)*group_diagonal*4.)
                ray=point-eye
                hit,_,face,distance_to_face=collision_bvh.ray_cast(eye,ray.normalized())
                if hit is None:exterior_samples+=1
                if (_wind_override is None and hit is not None and int(collision_owners[face])!=owner
                        and distance_to_face<ray.length-clearance*.25):
                    cropped_tip=True
                    if free_index-contact>=3:
                        path=path[:free_index]
                    else:foreign_outlet=True
                    break
                visible=(hit is None or distance_to_face>=ray.length-clearance*.25 or
                         _wind_override is not None)
                visible_run=visible_run+1 if visible else 0
                longest_run=max(longest_run,visible_run)
            # Finite brush coverage can be visible even when its center is hidden.
            # Let the depth-tested footprint resolve it at every angle.
            if foreign_outlet:
                # A blocked free outlet does not erase its supported rim.
                # Keep only actual surface contact; per-lane foreign depth
                # still rejects hidden roots and prevents detached re-entry.
                support_only=True
                path=path[:contact]
            # Shared bundle weight + small member variation; same brush atlas.
            tier_weight = (1., .82+.12*fill, .36+.44*fill)[tier]
            weight = 1.5*(3.0+2.1*mass)*tier_weight*(.9+.2*hand)*(.5/.72)**.6
            weight *= .85+.15*(diagonal/max(group_diagonal,1.e-8))
            # Brush loading is independent of hemisphere latitude.
            sector = max(0., min(1., (mass-.12)/.5))
            sector_floor = .24+.70*fill
            weight *= sector_floor+(1.-sector_floor)*sector*sector*(3.-2.*sector)
            if gap_fill:weight*=.38+.28*_noise(i*1.93,group+49.7)
            if tier==2:weight*=.64+.24*hand
            # Reject isolated static marks that never connect to the outer
            # silhouette. End-on brush footprints are retained: this tests
            # lateral travel relative to the physical brush diameter.
            projected_travel=np.array(path[-1]-path[contact-1],copy=True)
            projected_travel-=camera_axis*float(projected_travel@camera_axis)
            # Perspective can reverse a receding path in screen space while
            # its world-space travel remains downstream. Do not reject a
            # valid hemisphere from the projected pin bearing; finite brush
            # coverage and actual scene occlusion decide visibility below.
            # Sparse centerline/outline probes cannot establish that a finite
            # ribbon is fully occluded. Preserve it for exact lane + GPU depth.
            # Keep the physical surface path and let depth determine its
            # visibility. Rebuilding a hidden outlet as a visible-face inlet
            # flattened hemisphere differences and rejected receding wakes.
            trimmed_contact=False
            drawn_inlet=False
            # Only trim an actual upstream traversal on the supporting
            # geometry. A rear-hemisphere meridian can reverse in projection
            # as it rounds a bevel; comparing that screen tangent with its
            # free tail collapsed valid contacts to a single discarded point.
            if _wind_override is None and not behind and contact>1:
                cp=np.asarray(path[:contact+1])
                steps=np.diff(cp,axis=0)
                progress=steps@wind
                reversals=np.flatnonzero(progress[:-1] < -max(clearance*.01,1.e-8))
                if len(reversals):
                    first=int(reversals[-1])+1
                    path=path[first:]
                    normals=normals[first:]
                    labels=labels[first:]
                    contact-=first
                    trimmed_contact=True
            if _wind_override is None and not behind and contact>2:
                facing_contacts=np.flatnonzero(np.asarray(normals[:contact])@camera_axis>.5)
                if len(facing_contacts) and int(facing_contacts[0])>0:
                    first=int(facing_contacts[0])
                    path=path[first:];normals=normals[first:];labels=labels[first:]
                    contact-=first
                    trimmed_contact=True
            # Trimming can leave a single bevel point. It has no supported
            # brush run and becomes a detached cap stamp after rasterization.
            if contact<2:continue
            # Carry this same root upstream on its actual supporting face.
            # Stop at the first owner, normal or seal boundary; never bridge
            # a joint or flatten the prefix onto a camera plane.
            if _wind_override is None and len(normals):
                root_point=Vector(path[0]);root_n=Vector(normals[0]).normalized()
                # Continue the actual supported inlet tangent. Projecting
                # the global wind onto a new face introduced a right-angle
                # elbow between the rebuilt prefix and the original contact.
                upstream=Vector(path[0]-path[1]) if contact>1 else -Vector(wind)
                upstream-=root_n*upstream.dot(root_n)
                prefix=[]
                if upstream.length>1.e-6:
                    upstream.normalize()
                    current=root_point;current_n=root_n
                    for step in range(25):
                        tangent=upstream-current_n*upstream.dot(current_n)
                        if tangent.length<1.e-6:break
                        tangent.normalize()
                        target=current+tangent*(diagonal*.02)
                        hit,hn,hface,_=collision_bvh.ray_cast(
                            target+current_n*diagonal*.03,-current_n,diagonal*.06)
                        if (hit is None or int(collision_owners[hface])!=owner or
                                hn.dot(current_n)<.85 or hn.dot(root_n)<.97 or hn.dot(Vector(wind))<-.65 or
                                _sealed_contact(collision_bvh,collision_owners,owner,
                                hit,hn,diagonal*.045,diagonal*1.e-5)):
                            break
                        current=hit+hn*clearance;current_n=hn
                        prefix.append((current,np.asarray(hn)))
                if prefix:
                    prefix.reverse()
                    path=[p for p,n in prefix]+path
                    normals=np.vstack(([n for p,n in prefix],normals))
                    labels=[owner]*len(prefix)+list(labels)
                    contact+=len(prefix)
            # Reject tiny front-face remnants left after contact trimming;
            # they are isolated cap launches, not supported side channels.
            if (_wind_override is None and contact<=3 and
                    float(np.asarray(normals[0])@camera_axis)>.8 and
                    float(np.asarray(normals[0])@wind)>.25):
                continue
            # A blocked outlet retains its original supported side path.
            # Relocating it with camera rays to the upstream face edge created
            # artificial top-cap/shoulder stamps when the pin was vertical.
            if support_only and np.linalg.norm(projected_wind)>1.e-6:
                # An occluded wake leaves pigment on its supporting SIDE,
                # not on the upwind cap or a front-face meridian. Select by
                # surface normals in the camera/wind basis, for every owner.
                side_axis=np.cross(camera_axis,projected_wind)
                side_axis/=max(np.linalg.norm(side_axis),1.e-8)
                side_contact=(np.abs(np.asarray(normals)@side_axis)>.30) & (np.abs(np.asarray(normals)@wind)<.55)
                candidates=np.flatnonzero(side_contact)
                if not len(candidates):continue
                runs=np.split(candidates,np.flatnonzero(np.diff(candidates)>1)+1)
                run=max(runs,key=len)
                if len(run)<3:continue
                first,last=int(run[0]),int(run[-1])+1
                path=path[first:last];normals=normals[first:last];labels=labels[first:last]
                contact=len(path)
            contour_inlet=False
            if support_only or (_wind_override is None and contact>3):
                # A supported gesture is admitted only when its upstream
                # pickup reaches the visible outer contour. This excludes
                # isolated stamps in the middle of a mesh or a sealed joint.
                contact_arc=sum((b-a).length for a,b in zip(path[:-1],path[1:]))
                if support_only and contact_arc<diagonal*.07:continue
                attached=False
                side_axis=np.cross(camera_axis,projected_wind)
                side_length=np.linalg.norm(side_axis)
                probe_axes=(side_axis/side_length,) if side_length>1.e-6 else (right,up)
                for axis in probe_axes:
                    for sign in (-1.,1.):
                        probe=path[0]+Vector(axis*(sign*diagonal*.10))
                        eye=perspective_camera if perspective_camera is not None else probe+Vector(camera_axis)*group_diagonal*4.
                        if collision_bvh.ray_cast(eye,(probe-eye).normalized())[0] is None:
                            attached=True;break
                    if attached:break
                if support_only and not attached:continue
                contour_inlet=attached
            # Stop on the first closed contact, preserving its valid inlet.
            # A blocked lower cap must not erase the exposed upper face.
            sealed=False
            for sample in range(contact):
                n=Vector(normals[sample])
                if n.length<.5:continue
                blocked=_sealed_contact(collision_bvh,collision_owners,owner,
                    path[sample]-n*clearance,n,diagonal*.045,diagonal*1.e-5)
                other,other_normal,_,_=collision_bvh.ray_cast(
                    path[sample]-n*(clearance-diagonal*1.e-5),n,diagonal*.045)
                blocked=blocked or (other is not None and other_normal.dot(n)<-.5)
                if blocked:
                    if _wind_override is None and contour_inlet and sample>=3:
                        path=path[:sample];normals=normals[:sample];labels=labels[:sample]
                        contact=sample;support_only=True
                    else:sealed=True
                    break
            if sealed:continue
            root_normal=Vector(normals[0])
            if not support_only and root_normal.length>.5 and _closed_seam_mouth(
                    collision_bvh,path[0]-root_normal*clearance,root_normal,
                    diagonal*.045,diagonal*1.e-5,
                    heading=path[min(contact,len(path)-1)]-path[0],
                    travel_limit=min(diagonal*1.5,free_length+float(np.linalg.norm(points[-1]-points[0]))),
                    owners=collision_owners,source_owner=owner):
                continue
            if receding and drawn_inlet:
                # More visible source faces now participate. They need
                # readable paper channels, not the old hidden-side mass
                # budget stacked over every newly admitted front face.
                weight *= .52
            seed = float((int(salt)%65521)+group*173+i*1.61803398875)
            stroke = SurfaceStroke(owner, group, seed, float((longitudinal[0]-lo)/(hi-lo)), path, weight)
            stroke.diagonal, stroke.contact_count = diagonal, contact
            stroke.brush_world_scale = drawing_diagonal
            stroke.rear_cast=receding
            stroke.cast_behind=bool(behind)
            stroke.launch_count = contact
            stroke.trimmed_contact=trimmed_contact
            stroke.drawn_inlet=drawn_inlet
            # Fill the supported heel using the existing ribbon, not another
            # BVH-traced candidate. The gain decays before the free tail.
            # Visible front-side families now participate too. Do not stack
            # an extra broad root slab across all their mesh contacts.
            stroke.root_scale=(.65+.25*hand) if contour_inlet else (1.05+.35*hand if gap_fill else 1.0)
            stroke.family, stroke.family_seed = i, _noise(family, group+.63)
            stroke.primary, stroke.gap = tier == 0, tier == 1
            # View-facing side packets own the readable launch. Hidden-side
            # packets must not return as blunt floating fragments beyond a
            # limb. Frontal/rear dome views retain the complete circumference;
            # this is continuous visibility weighting, not a different field.
            # Occlusion decides visibility; grazing normals must not turn the
            # same loaded brush into a hairline when the pin rotates.
            stroke.normals = normals.tolist()
            stroke.contact_owners=labels
            stroke.surface, stroke.epsilon = collision_bvh, diagonal*1.e-5
            stroke.surface_owners=collision_owners
            stroke.surface_screen_bounds=collision_context._linear_ray_bounds
            stroke.surface_owner_screen_bounds=collision_context._linear_owner_ray_bounds
            stroke.contour_inlet=contour_inlet
            stroke.support_only=support_only
            stroke.cropped_tip=cropped_tip
            stroke.motion_path=_wind_override is not None
            stroke.motion_authority=motion_shape if _wind_override is not None else 0.
            stroke.trail_action_strength=getattr(geometry,"_linear_action_strength",0.)
            stroke.casting_facing=facing
            stroke.gap_fill=gap_fill
            yield stroke
    # No extra front-surface pickup pass: it produced thick rig outlines.
    return


def _extend_surface_channel(stroke, origin, wind, camera_axis, hand):
    """Attach a finite visible-surface inlet to an existing trailing gesture.

    The inlet is staggered inside the mesh, not aligned along its silhouette.
    A single depth plane keeps bevels from distorting the drawn centerline.
    Ray queries use only this proximity group, preserving separate islands.
    """
    root = np.asarray(stroke.points[0])
    projected = wind-camera_axis*np.dot(wind, camera_axis)
    if np.linalg.norm(projected) < .05:
        projected = root-origin
        projected -= camera_axis*np.dot(projected, camera_axis)
    projected /= max(np.linalg.norm(projected), 1.e-8)
    # Follow this trail's local heading rather than joining every stroke to
    # the group center (which makes a conspicuous triangular fan).
    inlet = root-projected*stroke.diagonal*(.045+.045*hand)
    inlet -= camera_axis*np.dot(inlet-origin, camera_axis)
    ray_origin = inlet+camera_axis*stroke.diagonal*3.
    hit = stroke.surface.ray_cast(Vector(ray_origin), Vector(-camera_axis),
                                 stroke.diagonal*6.)[0]
    if hit is None:
        return
    first = np.asarray(hit)+camera_axis*stroke.diagonal*.001
    # Keep the original cap and tail. Only the leading part of this same
    # brush crosses the visible face; no additional outline strokes exist.
    t = np.linspace(0., 1., 7)
    prefix = first+(root-first)*t[:, None]
    depths = []
    for point in prefix[:-1]:
        hit = stroke.surface.ray_cast(Vector(point+camera_axis*stroke.diagonal*3.),
                                     Vector(-camera_axis), stroke.diagonal*6.)[0]
        if hit is not None:
            depths.append(float(np.dot(hit, camera_axis)))
    if not depths:
        return
    depth = max(depths)+stroke.diagonal*.001
    prefix[:-1] += camera_axis*(depth-prefix[:-1]@camera_axis)[:, None]
    contact = np.asarray(stroke.points[:stroke.contact_count])
    contact += camera_axis*np.maximum(0., depth-contact@camera_axis)[:, None]
    stroke.points[:stroke.contact_count] = [Vector(p) for p in contact]
    stroke.points = [Vector(p) for p in prefix[:-1]]+stroke.points
    stroke.normals = [camera_axis.tolist()]*(len(prefix)-1)+stroke.normals
    stroke.contact_count += len(prefix)-1
    stroke.channel = True


def _surface_pickups(packets, wind, camera_axis, strength, thickness, salt):
    """Short face-owned marks fill leading surfaces, not a whole-body dome.

    Slice each connected packet across projected flow. Its visible depth is
    estimated on the same slice; a single plane holds each short gesture so
    bevels cannot rubber-warp individual centerline points.
    """
    projected=wind-camera_axis*np.dot(wind,camera_axis)
    amount=float(np.linalg.norm(projected))
    if amount<.05: return []
    along=projected/amount
    across=np.cross(camera_axis,along)
    result=[]
    # Imported hard normals can split every face into a topology island.
    # Rejoin only packets already assigned to the same proximity component;
    # never issue a complete pickup layer per bevel face.
    merged={}
    for owner,group,vertices,faces,bvh in packets:
        points,triangles=merged.setdefault((owner,group),([],[]))
        triangles.extend((faces+len(points)).tolist())
        points.extend(vertices.tolist())
    for (owner,group),(points,triangles) in merged.items():
        vertices=np.asarray(points);faces=np.asarray(triangles,dtype=int)
        bvh=None # Pickup normals carry their plane; no nearest-surface query.
        diagonal=float(np.linalg.norm(np.ptp(vertices,axis=0)))
        sideways=vertices@across
        lo,hi=float(sideways.min()),float(sideways.max())
        count=min(96,max(12,int((hi-lo)/max(diagonal*.012,1.e-8))))
        edge_a=vertices[faces[:,(0,1,2)]].reshape((-1,3))
        edge_b=vertices[faces[:,(1,2,0)]].reshape((-1,3))
        side_a,side_b=edge_a@across,edge_b@across
        for i in range(count):
            hand=_noise(i*1.37,owner+37.3)
            offset=lo+(i+.25+.5*hand)*(hi-lo)/count
            # Batched triangle-plane intersections. Each crossed triangle
            # contributes exactly two endpoints, without Python edge loops.
            selected=(side_a<offset)!=(side_b<offset)
            if not selected.any(): continue
            t=(offset-side_a[selected])/(side_b[selected]-side_a[selected])
            endpoints=(edge_a[selected]+(edge_b[selected]-edge_a[selected])*t[:,None]).reshape((-1,2,3))
            axis=endpoints@along
            start=float(axis.min())
            span=float(axis.max()-start)
            if span<diagonal*.01: continue
            family=_noise(i*.19,owner+71.2)
            extent=min(span*.46,diagonal*(.055+.11*family+.05*hand))*strength/.5
            # Query the front face a little inside its silhouette, avoiding
            # ambiguous top/bevel edges. The mark still begins at the true tip.
            probes=start+np.array((.015,.06,.14,.26))*min(span,extent*3.)
            depths=[]
            for probe in probes:
                denominator=axis[:,1]-axis[:,0]
                t=np.divide(probe-axis[:,0],denominator,out=np.full_like(denominator,-1.),where=abs(denominator)>1.e-8)
                valid=(t>=0.)&(t<=1.)
                if valid.any():
                    hits=endpoints[valid,0]+(endpoints[valid,1]-endpoints[valid,0])*t[valid,None]
                    depths.append(float((hits@camera_axis).max()))
            if not depths: continue
            depth=max(depths)+diagonal*.002
            root=across*offset+along*(start-diagonal*.004)+camera_axis*depth
            # Finite overlapping strokes: no shared full-length white channel.
            t=np.linspace(0.,1.,8)
            points=root+along*(extent*t[:,None])
            points+=across*(diagonal*(hand-.5)*.006*t*t)[:,None]
            weight=(.65+.40*family+.15*hand)*(strength/.5)**.6
            stroke=SurfaceStroke(owner,group,float(salt+owner*173+i),0.,[Vector(p) for p in points],weight)
            stroke.diagonal,stroke.contact_count=diagonal,len(points)
            stroke.family,stroke.family_seed=i+.417,hand
            stroke.primary,stroke.gap=False,True
            stroke.normals=[camera_axis.tolist()]*len(points)
            stroke.surface,stroke.epsilon=bvh,diagonal*1.e-5
            stroke.pickup=True
            result.append(stroke)
    return result


def build_group_paths(*args, **kwargs):
    return [stroke for stroke in iter_group_paths(*args, **kwargs) if stroke is not None]


def _iter_primary_paths(geometry, focus, behind, aspect, spread, salt,
                      motion_influence=0., background_motion=(0.,0.),
                      background_acceleration=(0.,0.),velocity_scale=1.,
                      strength=.72,thickness=.62, _skip_owners=(), _preview=False):
    """Blend independently moving owners into the same exterior constructor."""
    common=dict(focus=focus,behind=behind,aspect=aspect,spread=spread,salt=salt,
                background_motion=background_motion,background_acceleration=background_acceleration,
                velocity_scale=velocity_scale,strength=strength,thickness=thickness,
                _action_influence=motion_influence, _preview=_preview)
    world_velocity=getattr(geometry,"world_velocities",())
    if motion_influence<=1.e-6 or len(world_velocity)!=len(geometry.positions) or not world_velocity:
        yield from _iter_group_paths(geometry,motion_influence=motion_influence,_excluded_owners=_skip_owners,**common)
        return
    ids=np.asarray(geometry.owner_ids,dtype=int)
    world=np.asarray(geometry.world_positions)
    velocity=np.asarray(world_velocity)
    matrix=np.asarray(geometry.view_projection)
    base_wind=np.asarray(dome_direction(focus,(.5,.5),aspect,behind,matrix))
    camera_axis=np.cross(matrix[0,:3]/np.linalg.norm(matrix[0,:3]),
                         matrix[1,:3]/np.linalg.norm(matrix[1,:3]))
    parts=getattr(geometry,"_linear_motion_parts",None)
    if parts is None:
        parts={}
        faces=np.asarray(geometry.triangles,dtype=int)
        partitions=owner_indices(ids)
        face_partitions=owner_indices(ids[faces[:,0]])
        remap=np.full(len(ids),-1,dtype=int)
        from .impaction_capture import CaptureGeometry
        for owner, indices in partitions.items():
            yield None
            if not getattr(geometry,'motion_history',{}).get(str(int(owner))):
                continue
            size=float(np.linalg.norm(np.ptp(world[indices],axis=0)))
            v=np.median(velocity[indices],axis=0)
            # At a keyed turnaround, central velocity can be zero while the
            # incoming punch arc remains strong. Estimate its incoming tangent
            # from the same before/current/after acceleration, not a random axis.
            accelerations=getattr(geometry,'world_accelerations',())
            acceleration=(np.asarray(accelerations)[indices].mean(axis=0)
                if len(accelerations)==len(geometry.positions) else np.zeros(3))
            incoming=v-acceleration*1.5
            if np.linalg.norm(v)<np.linalg.norm(acceleration)*.25:
                v=incoming
            if np.linalg.norm(v)<size*.001:
                history=getattr(geometry,'motion_history',{}).get(str(int(owner)),())
                for sample in history:
                    offset=np.asarray(sample[1:4],dtype=float)
                    if len(sample)>=13:
                        local=world[indices[0]]-world[indices].mean(axis=0)
                        offset=offset+local@np.asarray(sample[4:13]).reshape((3,3))
                    if np.linalg.norm(offset)>size*.001:
                        v=-offset/max(abs(float(sample[0])),1.e-5)
                        break
            speed=float(np.linalg.norm(v))
            # A static or slowly settling bone stays in its assembled group.
            confidence=np.clip((speed/max(size,1.e-6)-.001)/.008,0.,1.)
            confidence=float(confidence*confidence*(3.-2.*confidence))
            stored_history=_recent_motion_history(getattr(geometry,'motion_history',{}).get(str(int(owner)),()),size)
            movement_age=0.
            retained=0.
            event_strength=0.
            shape_strength=0.
            if stored_history:
                # A stopped center is not a spent wake. Measure remaining
                # surface travel, including rotation, before relaxing it.
                offsets=world[indices[np.linspace(0,len(indices)-1,min(8,len(indices)),dtype=int)]]-world[indices].mean(axis=0)
                remaining=max(float(np.linalg.norm(np.diff(_exposure_history(stored_history,offset),axis=0),axis=1).sum())
                              for offset in offsets)
                retained=float(np.clip((remaining/max(size,1.e-6)-.001)/.25,0.,1.))
                retained=retained*retained*(3.-2.*retained)
                world_strength=_motion_event_strength(stored_history,offsets,size)
                local_strength=_motion_event_strength(
                    _relative_motion_history(stored_history,int(owner),geometry),offsets,size)
                # Shared body motion contributes a restrained accent. Independent
                # limb action can use the full response. Both draw the complete
                # world-space trajectory, including every parent transform.
                event_strength=min(world_strength,.20*world_strength+.80*local_strength)
                world_peak=_motion_event_strength(stored_history,offsets,size,age_decay=False)
                local_peak=_motion_event_strength(
                    _relative_motion_history(stored_history,int(owner),geometry),offsets,size,age_decay=False)
                shape_strength=min(world_peak,.20*world_peak+.80*local_peak)
            if event_strength<=1.e-8:continue
            if stored_history:
                movement_age=next((abs(float(row[0])) for row in stored_history
                    if (np.linalg.norm(row[1:4])+size*.25*np.linalg.norm(row[4:13]))>size*.001),float('inf'))
            # Start with zero catch-up speed, then ease through the retained
            # exposure. Spatial reach and return-to-static direction are separate.
            settling=_motion_settling(movement_age)
            confidence=max(confidence*settling,retained)
            if confidence<=1.e-6: continue
            remap[indices]=np.arange(len(indices))
            local_faces=remap[faces[face_partitions.get(owner,np.empty(0,dtype=int))]]
            def subset(name):return [getattr(geometry,name)[i] for i in indices]
            part=CaptureGeometry(subset('positions'),subset('normals'),subset('velocities'),
                subset('accelerations'),subset('owner_ids'),local_faces.tolist(),
                subset('spread_group_ids'),subset('spread_group_weights'),subset('world_positions'),
                geometry.view_projection,subset('world_velocities'),subset('world_accelerations'))
            part._linear_drawing_context=getattr(geometry,'_linear_drawing_context',geometry)
            for name in ('world_before','world_before_mid','world_after_mid','world_after'):
                if len(getattr(geometry,name,()))==len(ids):setattr(part,name,subset(name))
            if len(getattr(part,'world_before',())):
                before,mid_before,mid_after,after=[np.mean(np.asarray(getattr(part,name)),axis=0)
                    for name in ('world_before','world_before_mid','world_after_mid','world_after')]
                # Read the complete keyed action on both sides. A punch
                # accelerating out of this frame must not inherit only the
                # tiny preceding settle, even though its trail points back.
                before_arc=np.linalg.norm(mid_before)+np.linalg.norm(before-mid_before)
                after_arc=np.linalg.norm(mid_after)+np.linalg.norm(after-mid_after)
                part._linear_motion_reach=min(size,float(before_arc if before_arc>1.e-5 else after_arc))
            stored=stored_history
            if stored:
                part._linear_history_samples=stored
                part._linear_history_origin=world[indices].mean(axis=0)
                part._linear_history=_exposure_history(stored)
                history_length=np.linalg.norm(np.diff(part._linear_history,axis=0),axis=1).sum()
                if len(stored[0])>=13:
                    # Include angular surface travel in the bounded budget;
                    # a rotating limb can have an entirely stationary center.
                    corner=world[indices[0]]-part._linear_history_origin
                    surface_history=_exposure_history(stored,corner)
                    history_length=max(history_length,np.linalg.norm(np.diff(surface_history,axis=0),axis=1).sum())
                part._linear_motion_reach=min(size,float(history_length))*settling*event_strength
                part._linear_settling=settling
                part._linear_event_strength=event_strength
                part._linear_shape_strength=shape_strength
                part._linear_action_strength=local_peak
            # Motion steering stays owner-local; collision/launch admission
            # still sees the assembled rig rather than an isolated limb.
            part._linear_collision_context=geometry
            parts[int(owner)]=(part,-v/speed,confidence,speed/max(size,1.e-6))
        geometry._linear_motion_parts=parts
    if not parts:
        common['_action_influence']=0.
        yield from _iter_group_paths(geometry,motion_influence=0.,_excluded_owners=_skip_owners,**common)
        return
    weights={owner:_motion_authority(confidence,motion_influence)*getattr(part,"_linear_event_strength",1.)*_motion_return_weight(getattr(part,"_linear_settling",1.))
             for owner,(part,_,confidence,_) in parts.items()}
    active_owners=tuple(owner for owner,weight in weights.items() if weight>.02)
    # Each owner is drawn once by the normal stroke constructor. Moving
    # owners use that constructor with measured history below; they must not
    # also retain an uncurved static copy of their strokes.
    yield from _iter_group_paths(geometry,motion_influence=0.,
        _excluded_owners=tuple(set(active_owners)|set(_skip_owners)),**common)
    for owner,(part,trail,confidence,speed) in parts.items():
        weight=weights[owner]
        if owner not in active_owners or owner in _skip_owners:continue
        part._linear_casting_wind=base_wind
        part._linear_motion_amount=motion_influence
        # A full animation setting must not inherit the pin hemisphere.
        # The interpolation below brings the pin back as influence falls.
        trail=np.asarray(trail,dtype=float)
        # Directed velocity has polarity: do not sign-flip a punch trajectory
        # merely because it opposes the artist's default pin direction.
        cosine=float(np.clip(np.dot(base_wind,trail),-1.,1.))
        angle=math.acos(cosine)
        tangent=trail-base_wind*cosine
        if np.linalg.norm(tangent)<1.e-6:
            # An exact reversal has no unique rotation plane. Choose a stable
            # perpendicular instead of flipping abruptly at half influence.
            axis=np.eye(3)[int(np.argmin(np.abs(base_wind)))]
            tangent=np.cross(base_wind,axis)
        tangent/=max(np.linalg.norm(tangent),1.e-8)
        wind=(trail.copy() if weight>=1.-1.e-8 else
            base_wind*math.cos(angle*weight)+tangent*math.sin(angle*weight))
        wind/=np.linalg.norm(wind)
        if len(getattr(part,'world_before',())):
            # Launch and travel must use the same trajectory. Mirroring the
            # velocity into the pin hemisphere chose the opposite mesh side
            # while the sampled history still travelled into that mesh.
            offsets=[np.mean(np.asarray(getattr(part,name)),axis=0)
                for name in ('world_before','world_before_mid','world_after_mid','world_after')]
            if getattr(part,'_linear_history_samples',None):
                launch_history=_steered_surface_history(part,part._linear_history_origin,weight)
                active=np.flatnonzero(np.linalg.norm(launch_history,axis=1)>1.e-8)
                initial=launch_history[int(active[0])] if len(active) else np.zeros(3)
            else:
                initial=_sampled_wake(offsets,base_wind,1.,np.array((.015,.03)),weight,None)[0]
            if np.linalg.norm(initial)>1.e-8:
                wind=initial/np.linalg.norm(initial)
        # Keep the normal family widths and complete surface pickup. The
        # sampled past trajectory bends its own tail, without a second set or
        # a special four-stroke overlay that strips away normal coverage.
        motion_common=dict(common)
        # Owner/group identity selects the family. Frame and pin changes must
        # not reroll a live motion trail's brush identity.
        motion_common['salt']=0.
        yield from _iter_group_paths(part,motion_influence=weight,
            _wind_override=wind,**motion_common)



def _carry_trail_strokes(geometry, previous, strokes):
    """Transport source contacts; retain old free points in world space."""
    from copy import copy
    now=float(geometry._trail_frame)
    then=float(previous._trail_frame)
    if now<=then or now-then>=8.:return []
    ids=np.asarray(geometry.owner_ids);old_ids=np.asarray(previous.owner_ids)
    world=np.asarray(geometry.world_positions);old_world=np.asarray(previous.world_positions)
    transforms={};carried=[]
    collision=getattr(geometry,'_linear_scene_collision',None)
    for source in strokes:
        if (not getattr(source,'motion_path',False)
                or getattr(source,'trail_action_strength',0.)<.65
                or getattr(source,'support_only',False)):continue
        owner=source.owner
        if owner not in transforms:
            old=old_world[old_ids==owner];new=world[ids==owner]
            if old.shape!=new.shape or len(old)<3:
                transforms[owner]=None
            else:
                a=old.mean(0);b=new.mean(0)
                u,_,vt=np.linalg.svd((old-a).T@(new-b))
                parity=np.eye(3);parity[2,2]=np.linalg.det(u@vt)
                rotation=u@parity@vt
                error=np.max(np.linalg.norm((old-a)@rotation+b-new,axis=1))
                transforms[owner]=(a,b,rotation) if error<source.diagonal*.01 else None
        transform=transforms[owner]
        if transform is None:continue
        a,b,rotation=transform
        points=np.asarray(source.points,dtype=float)
        contact=min(source.contact_count,len(points)-1)
        if contact<1:continue
        old_tail=points[contact:]
        if not len(old_tail):continue
        births=getattr(source,'_trail_births',None)
        if births is None:
            lengths=np.linalg.norm(np.diff(points[contact-1:],axis=0),axis=1)
            distance=np.cumsum(lengths)
            births=then-8.*distance/max(float(distance[-1]),1.e-8)
        births=np.asarray(births)
        cutoff=now-8.
        keep=int(np.sum(births>cutoff))
        if keep==0:continue
        retained=old_tail[:keep].copy();times=births[:keep].copy()
        if keep<len(old_tail):
            t=(births[keep-1]-cutoff)/max(births[keep-1]-births[keep],1.e-8)
            retained=np.vstack((retained,old_tail[keep-1]*(1.-t)+old_tail[keep]*t))
            times=np.r_[times,cutoff]
        contacts=(points[:contact]-a)@rotation+b
        release=contacts[-1]
        history=getattr(geometry,'motion_history',{}).get(str(int(owner)),())
        count=max(2,int(math.ceil((now-then)*4.)))
        ages=np.linspace(0.,now-then,count+1)[1:]
        if history and len(history)>1:
            samples=np.asarray(history)
            offsets=_exposure_history(samples,release-b)
            connector=release+np.column_stack([np.interp(ages,-samples[:,0],offsets[:,k]) for k in range(3)])
        else:
            connector=release+(points[contact-1]-release)*(ages/(now-then))[:,None]
        # The connector's final sample belongs to the inherited source.
        connector[-1]=points[contact-1]
        moving=np.linalg.norm(np.diff(np.vstack((release,connector)),axis=0),axis=1)>source.diagonal*1.e-6
        connector=connector[moving];ages=ages[moving]
        result=copy(source)
        result.points=[Vector(p) for p in np.vstack((contacts,connector,retained))]
        result.normals=(np.asarray(source.normals)[:contact]@rotation).tolist()
        result.contact_count=contact
        result.launch_count=min(source.launch_count,contact)
        result.contact_owners=[owner]*contact
        result._trail_births=np.r_[now-ages,times].tolist()
        if collision is not None:
            result.surface,result.surface_owners=collision[:2]
            result.surface_screen_bounds=getattr(geometry, '_linear_ray_bounds', None)
        carried.append(result)
    return carried


def iter_group_paths(geometry, focus, behind, aspect, spread, salt,
                     motion_influence=0., background_motion=(0.,0.),
                     background_acceleration=(0.,0.), velocity_scale=1.,
                     strength=.72, thickness=.62, *, preview=False):
    arguments=(focus,behind,aspect,spread,salt,motion_influence,
               background_motion,background_acceleration,velocity_scale,strength,thickness)
    predecessor=getattr(geometry,'_trail_predecessor',None)
    lineage=[];link=predecessor
    while link is not None:
        parent,values=link
        lineage.append((id(parent),repr(values)))
        link=getattr(parent,'_trail_predecessor',None)
    key=(repr(arguments),float(getattr(geometry,'_trail_frame',0.)),tuple(lineage),float(preview))
    cache=getattr(geometry,'_trail_results',None)
    if cache is None:cache=geometry._trail_results={}
    if key in cache:
        yield from cache[key]
        return
    retained=[]
    # Temporal carry may reuse paths only while their authored shape agrees.
    # Otherwise retaining an owner's old strokes suppresses every new stroke
    # for that owner, making current-key sliders appear completely inert.
    same_style=(predecessor is not None and all(
        repr(arguments[i])==repr(predecessor[1][i]) for i in (0,1,3,5,9,10)))
    if same_style and motion_influence>1.e-6:
        previous,prior_arguments=predecessor
        prior=[]
        for stroke in iter_group_paths(previous,*prior_arguments,preview=preview):
            if stroke is not None:prior.append(stroke)
            yield None
        retained=_carry_trail_strokes(geometry,previous,prior)
        yield None
    owners={stroke.owner for stroke in retained}
    result=[]
    for stroke in _iter_primary_paths(geometry,*arguments,_skip_owners=owners,_preview=preview):
        if stroke is not None and stroke.owner not in owners:result.append(stroke)
        # Yield during construction, not only after the complete list exists.
        yield None
    result.extend(retained)
    if len(cache)>=2:cache.pop(next(iter(cache)))
    # Material weathering changes with the exposure; geometry and emitter
    # identity remain persistent. Copies keep predecessor caches immutable.
    from copy import copy
    textured=[]
    for source in result:
        stroke=copy(source)
        stroke.brush_phase=float(getattr(geometry,'_trail_frame',0.))
        textured.append(stroke)
    cache[key]=textured
    yield from textured
