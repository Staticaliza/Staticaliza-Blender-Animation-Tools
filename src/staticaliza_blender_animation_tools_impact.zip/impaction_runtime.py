"""Preview drawing, marker synchronization, and cache invalidation."""

import bpy
import math
import sys
import time
from bpy.app.handlers import persistent

from .impaction_action import (
    impact_grid_frame, impact_grid_interval, marker_fcurves,
    rebuild_marker_exposure, salt_value,
)
from .impaction_discovery import camera_bone_binding, viewed_camera
from .impaction_renderer import draw_cached_image, warm_interactive_resources

_draw_handle = None
_animator_pixel_handle_token = None
_syncing = False
_propagating = False
_live_suspended = False
_rendering_live = False
_pending_live = {}
_pending_marker_cameras = set()
_marker_sync_deadline = 0.0
_marker_signatures = {}
_deleted_records = {}
_gradient_signatures = {}
_exclusive_edit_pointer = None
_warmup_attempts = 0
_live_render_ema = 0.0
_draw_priority_checked_at = 0.0
_fps_values = {}
_fps_layouts = {}
_interactive_selection_cache = {}


def _fps_layout(camera):
    return tuple((int(record.salt), int(record.frame))
                 for record in camera.impaction_frames)


def fps_property_changed(camera):
    """Remember both marker layouts so native FPS undo/redo restores spacing."""
    name = camera.name_full
    current = int(camera.impaction_fps)
    previous = _fps_values.get(name)
    if previous is not None and previous != current:
        _fps_layouts[(name, previous)] = _fps_layout(camera)
    _fps_values[name] = current
    schedule_marker_sync(camera)


def _restore_fps_layout(camera):
    """Restore the record/marker positions belonging to the undone FPS."""
    name = camera.name_full
    current = int(camera.impaction_fps)
    previous = _fps_values.get(name)
    if previous is None:
        _fps_values[name] = current
        return False
    if previous == current:
        return False
    _fps_layouts[(name, previous)] = _fps_layout(camera)
    layout = _fps_layouts.get((name, current))
    _fps_values[name] = current
    if not layout:
        return False
    frames = {salt: frame for salt, frame in layout}
    from .impaction_renderer import retime_capture
    changed = False
    for record in camera.impaction_frames:
        target = frames.get(int(record.salt))
        if target is None or int(record.frame) == target:
            continue
        old_frame = int(record.frame)
        record.frame = target
        retime_capture(camera, record, old_frame)
        cancel_live_render(camera, record)
        changed = True
    if changed:
        armature, _bone = camera_bone_binding(camera)
        if armature is not None:
            rebuild_marker_exposure(armature, camera)
    return changed

_LIVE_PREVIEW_INTERVAL = 1.0 / 60.0
_LIVE_PREVIEW_SETTLE_MIN = 0.12
_LIVE_PREVIEW_SETTLE_MAX = 0.35
_INTERACTIVE_SELECTION_TTL = 0.05
_DELETED_RECORD_BUDGET = 64
_DELETED_RECORD_BYTE_BUDGET = 256 * 1024 * 1024
_DRAW_HANDLE_KEY = "staticaliza_blender_animation_tools_impact.draw_handle"
_TIMER_CALLBACKS_KEY = "staticaliza_blender_animation_tools_impact.timer_callbacks"
_LABEL_OCCLUSION_QUERY_KEY = (
    "staticaliza_blender_animation_tools.impact_hides_viewport_labels"
)


def _warm_renderer_resources():
    """Idle-time GPU warmup; never captures or invalidates an Impact Frame."""
    global _warmup_attempts
    try:
        if warm_interactive_resources():
            _warmup_attempts = 0
            return None
    except (ReferenceError, RuntimeError, SystemError, TypeError):
        pass
    _warmup_attempts += 1
    return 0.5 if _warmup_attempts < 3 else None


def frame_record(camera, frame):
    if camera is None or not hasattr(camera, "impaction_frames"):
        return None
    return next((record for record in camera.impaction_frames if record.frame == int(frame)), None)


def grid_frame_record(scene, camera, frame):
    """Record occupying the grid slot nearest to the requested frame."""
    if camera is None or not getattr(camera, "impaction_frames", None):
        return None
    target = impact_grid_frame(scene, camera, frame, initialize=False)
    return frame_record(camera, target)


def held_frame_record(scene, camera, frame):
    """Record exposed from its key through one complete Impact interval."""
    if camera is None or not getattr(camera, "impaction_frames", None):
        return None
    current = int(frame)
    interval = impact_grid_interval(scene, camera)
    return next(
        (record for record in camera.impaction_frames
         if int(record.frame) <= current < int(record.frame) + interval),
        None,
    )


def request_redraw(camera=None):
    """Redraw only camera-view areas that can display an Impact overlay."""
    for area, viewed in _camera_viewport_areas():
        if camera is None or viewed == camera:
            area.tag_redraw()


def _camera_viewport_areas():
    """Yield (area, camera) pairs for active 3D camera views."""
    window_manager = getattr(bpy.context, "window_manager", None)
    for window in getattr(window_manager, "windows", ()) if window_manager else ():
        screen = getattr(window, "screen", None)
        scene = getattr(window, "scene", None)
        if screen is None or scene is None:
            continue
        for area in screen.areas:
            if area.type != "VIEW_3D":
                continue
            space = area.spaces.active
            region_3d = getattr(space, "region_3d", None)
            if region_3d is None or region_3d.view_perspective != "CAMERA":
                continue
            camera = getattr(space, "camera", None) or scene.camera
            if camera is not None and camera.type == "CAMERA":
                yield area, camera


def _camera_viewports():
    """Yield cameras currently displayed through a 3D View camera viewport."""
    for _area, camera in _camera_viewport_areas():
        yield camera


def _preview_display_active(camera=None):
    """True only while an enabled Impact preview is actually on screen."""
    scene = getattr(bpy.context, "scene", None)
    state = getattr(scene, "impaction", None) if scene else None
    if state is None or state.preview_opacity <= 0.0:
        return False
    return any(candidate == camera for candidate in _camera_viewports()) if camera else any(_camera_viewports())


def cancel_all_live_renders():
    """Stop queued GPU work and discard only transient (unapplied) previews."""
    states = tuple(_pending_live.values())
    _pending_live.clear()
    for state in states:
        camera, record = _live_state_record(state)
        if camera is not None and record is not None:
            try:
                from .impaction_renderer import clear_record_preview
                clear_record_preview(camera, record)
            except (ImportError, ReferenceError, RuntimeError):
                pass


def preview_mode_changed(_context=None):
    if not _preview_display_active():
        cancel_all_live_renders()
    else:
        _ensure_marker_polling()
    request_redraw()


def _animator_utils_pixel_handle():
    """Find Animator Utils' POST_PIXEL handle without importing/reloading it."""
    for module_name, module in tuple(sys.modules.items()):
        if not module_name.endswith("staticaliza_blender_animation_tools.viewport.overlay_runtime"):
            continue
        state = getattr(module, "_state", None)
        if isinstance(state, dict):
            return state.get("handle_pixel")
    return None


def _raise_draw_handler_after_animator_labels():
    """Keep the opaque Impact replacement above Animator Utils HUD labels."""
    global _draw_handle, _animator_pixel_handle_token
    animator_handle = _animator_utils_pixel_handle()
    token = id(animator_handle) if animator_handle is not None else None
    if token is None:
        _animator_pixel_handle_token = None
        return
    if token == _animator_pixel_handle_token:
        return
    _animator_pixel_handle_token = token
    if _draw_handle is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_draw_handle, "WINDOW")
    _draw_handle = bpy.types.SpaceView3D.draw_handler_add(
        _draw, (), "WINDOW", "POST_PIXEL",
    )
    bpy.app.driver_namespace[_DRAW_HANDLE_KEY] = _draw_handle
    request_redraw()


def _deferred_draw_priority():
    _raise_draw_handler_after_animator_labels()
    return None


def animation_playing(context=None):
    context = context or bpy.context
    window_manager = getattr(context, "window_manager", None)
    return bool(window_manager and any(
        window.screen.is_animation_playing
        for window in window_manager.windows
        if getattr(window, "screen", None) is not None
    ))


def _transform_operator_active(context=None):
    context = context or bpy.context
    window_manager = getattr(context, "window_manager", None)
    for window in getattr(window_manager, "windows", ()) if window_manager else ():
        try:
            for operator in window.modal_operators:
                identifier = str(getattr(operator, "bl_idname", ""))
                if (identifier.upper().startswith("TRANSFORM_OT_")
                        or identifier.lower().startswith("transform.")):
                    return True
        except (AttributeError, ReferenceError, RuntimeError):
            continue
    return False


def selected_records(camera):
    armature, _bone = camera_bone_binding(camera) if camera else (None, "")
    curves = marker_fcurves(armature, camera) if armature else ()
    if not curves:
        if camera is not None:
            _interactive_selection_cache[camera.name_full] = (
                time.monotonic(), (),
            )
        return []
    selected_values = [
        point.co.y for curve in curves for point in curve.keyframe_points
        if getattr(point, "type", "") != "GENERATED"
        and (point.select_control_point or point.select_left_handle or point.select_right_handle)
    ]
    # FCurve Y values are stored as float32, so reconstructing the original
    # 31-bit salt can differ by dozens of integer units. Bucket in the same
    # tolerance space used by marker identity, then inspect adjacent buckets.
    tolerance = 1.0e-5
    bucket_scale = 1.0 / tolerance
    records_by_bucket = {}
    for record in camera.impaction_frames:
        bucket = int(math.floor(salt_value(record.salt) * bucket_scale))
        records_by_bucket.setdefault(bucket, []).append(record)
    result = []
    seen = set()
    for value in selected_values:
        bucket = int(math.floor(float(value) * bucket_scale))
        candidates = (
            record
            for candidate_bucket in (bucket - 1, bucket, bucket + 1)
            for record in records_by_bucket.get(candidate_bucket, ())
        )
        match = min(
            candidates,
            key=lambda item: abs(salt_value(item.salt) - float(value)),
            default=None,
        )
        pointer = match.as_pointer() if match is not None else None
        if (match is not None
                and abs(salt_value(match.salt) - value) < tolerance
                and pointer not in seen):
            seen.add(pointer)
            result.append(match)
    _interactive_selection_cache[camera.name_full] = (
        time.monotonic(), tuple(int(record.salt) for record in result),
    )
    return result


def _interactive_selected_salts(camera):
    """Reuse one native key-selection scan across draw/gizmo callbacks."""
    now = time.monotonic()
    cached = _interactive_selection_cache.get(camera.name_full)
    if cached is not None and now - float(cached[0]) <= _INTERACTIVE_SELECTION_TTL:
        return cached[1]
    return tuple(int(record.salt) for record in selected_records(camera))


def _record_owner(target):
    owner = getattr(target, "id_data", None)
    if (owner is not None and getattr(owner, "type", None) == "CAMERA"
            and hasattr(owner, "impaction_frames")):
        return owner
    pointer = target.as_pointer()
    for camera in (obj for obj in bpy.data.objects if obj.type == "CAMERA"):
        for record in getattr(camera, "impaction_frames", ()):
            if record.as_pointer() == pointer:
                return camera
    return None


def _live_state_record(state):
    """Resolve a queued preview without retaining invalid RNA references."""
    camera = bpy.data.objects.get(state["camera_name"])
    record = next(
        (item for item in getattr(camera, "impaction_frames", ())
         if int(item.salt) == int(state["salt"])),
        None,
    ) if camera else None
    return camera, record


def _live_state_is_visible(scene, state):
    """A held exposure is visible even when the playhead is after its key."""
    camera, record = _live_state_record(state)
    return (
        record is not None
        and held_frame_record(scene, camera, scene.frame_current) == record
    )


def _resolve_live_states(scene):
    """Resolve every queued key and visible exposure once per timer tick."""
    cameras = {}
    records_by_camera = {}
    visible_salts = {}
    resolved = {}
    for state in _pending_live.values():
        camera_name = state["camera_name"]
        if camera_name not in cameras:
            camera = bpy.data.objects.get(camera_name)
            cameras[camera_name] = camera
            records_by_camera[camera_name] = {
                int(record.salt): record
                for record in getattr(camera, "impaction_frames", ())
            } if camera is not None else {}
            held = held_frame_record(
                scene, camera, scene.frame_current,
            ) if camera is not None else None
            visible_salts[camera_name] = (
                int(held.salt) if held is not None else None
            )
        camera = cameras[camera_name]
        record = records_by_camera[camera_name].get(int(state["salt"]))
        resolved[state["key"]] = (
            camera, record,
            record is not None
            and int(record.salt) == visible_salts[camera_name],
        )
    return resolved


def _live_settle_interval():
    """Adapt only debounce/backpressure to measured hardware throughput."""
    measured = _live_render_ema * 1.5 if _live_render_ema > 0.0 else 0.0
    return max(
        _LIVE_PREVIEW_SETTLE_MIN,
        min(_LIVE_PREVIEW_SETTLE_MAX, measured),
    )


def _next_live_timer_delay(scene, resolved=None):
    if not _pending_live:
        return None
    now = time.monotonic()
    settle = _live_settle_interval()
    resolved = resolved if resolved is not None else _resolve_live_states(scene)
    delays = []
    for state in _pending_live.values():
        if resolved.get(state["key"], (None, None, False))[2]:
            if state.get("dirty", True):
                delays.append(max(
                    0.005,
                    _LIVE_PREVIEW_INTERVAL -
                    (now - float(state.get("last_render_at", 0.0))),
                ))
            else:
                delays.append(max(
                    0.005,
                    settle - (now - float(state.get("last_input_at", now))),
                ))
        else:
            delays.append(max(
                0.01,
                settle - (now - float(state.get("last_input_at", now))),
            ))
    return min(0.05, min(delays, default=0.05))


def _render_pending_live():
    global _rendering_live, _live_render_ema
    context = bpy.context
    scene = getattr(context, "scene", None)
    if scene is None:
        return None
    if not _preview_display_active():
        cancel_all_live_renders()
        return None
    if animation_playing(context):
        # Playback only draws completed caches. Never evaluate geometry or
        # upload replacement images while Blender is trying to advance frames.
        return 0.12
    if not _pending_live:
        return None

    now = time.monotonic()
    resolved = _resolve_live_states(scene)
    active_by_camera = {}
    for state in tuple(_pending_live.values()):
        camera, record, _visible = resolved.get(
            state["key"], (None, None, False),
        )
        if state["camera_name"] not in active_by_camera:
            active_by_camera[state["camera_name"]] = bool(
                camera is not None and _preview_display_active(camera)
            )
        camera_active = active_by_camera[state["camera_name"]]
        if camera is None or record is None or not camera_active:
            cancel_live_render(camera, record)
            _pending_live.pop(state["key"], None)
            resolved.pop(state["key"], None)
    if not _pending_live:
        return None
    from .impaction_renderer import (
        cache_matches_record, has_cached_capture, preview_matches_record,
        promote_record_preview, render_record,
    )
    states = tuple(_pending_live.values())
    settle = _live_settle_interval()

    # A visible record owns the interactive budget. Hidden selected records
    # remain coalesced until input has gone quiet, then apply once each.
    candidates = {"visible_dirty": [], "visible_settled": [], "hidden_settled": []}
    for candidate in states:
        visible = resolved.get(candidate["key"], (None, None, False))[2]
        dirty = candidate.get("dirty", True)
        if (visible and dirty
                and now - float(candidate.get("last_render_at", 0.0))
                >= _LIVE_PREVIEW_INTERVAL):
            candidates["visible_dirty"].append(candidate)
        elif (visible and not dirty
                and now - float(candidate.get("last_input_at", now)) >= settle):
            candidates["visible_settled"].append(candidate)
        elif (not visible and dirty
                and now - float(candidate.get("last_input_at", now)) >= settle):
            candidates["hidden_settled"].append(candidate)
    state_kind = next(
        (kind for kind in ("visible_dirty", "visible_settled", "hidden_settled")
         if candidates[kind]),
        None,
    )
    state = candidates[state_kind][0] if state_kind is not None else None
    if state is None:
        return _next_live_timer_delay(scene, resolved)

    original_frame = scene.frame_current
    original_subframe = scene.frame_subframe
    moved_frame = False
    _rendering_live = True
    try:
        camera, record, _visible = resolved.get(
            state["key"], (None, None, False),
        )
        if record is None:
            _pending_live.pop(state["key"], None)
        elif state_kind == "visible_settled":
            if promote_record_preview(camera, record, scene) is not None:
                _pending_live.pop(state["key"], None)
            elif cache_matches_record(record, scene):
                _pending_live.pop(state["key"], None)
            else:
                # The transient was invalidated by a newer unserviced input.
                state["dirty"] = True
        else:
            if (not has_cached_capture(camera, record)
                    and (scene.frame_current != record.frame or scene.frame_subframe)):
                scene.frame_set(record.frame)
                moved_frame = True
            try:
                if state_kind == "hidden_settled" and cache_matches_record(record, scene):
                    _pending_live.pop(state["key"], None)
                    return _next_live_timer_delay(scene, resolved)
                started = time.monotonic()
                visible = state_kind == "visible_dirty"
                render_record(
                    context, camera, record,
                    preview=True, apply_preview=not visible,
                    retain_gpu_preview=visible,
                )
                elapsed = max(0.0, time.monotonic() - started)
                _live_render_ema = (
                    elapsed if _live_render_ema <= 0.0
                    else _live_render_ema * 0.82 + elapsed * 0.18
                )
                if visible:
                    state["failures"] = 0
                    state["dirty"] = False
                    state["last_render_at"] = time.monotonic()
                    # A click or isolated edit may already be quiet by the
                    # time the GPU completes. Promote that exact image now.
                    if (time.monotonic() - float(state["last_input_at"])
                            >= _live_settle_interval()
                            and preview_matches_record(camera, record, scene)):
                        if promote_record_preview(camera, record, scene) is not None:
                            _pending_live.pop(state["key"], None)
                else:
                    if cache_matches_record(record, scene):
                        state["failures"] = 0
                        _pending_live.pop(state["key"], None)
                    else:
                        raise RuntimeError("applied preview did not become current")
            except Exception as error:
                state["failures"] = int(state.get("failures", 0)) + 1
                state["last_input_at"] = time.monotonic()
                state["dirty"] = True
                if state["failures"] >= 3:
                    _pending_live.pop(state["key"], None)
                print(f"Impaction live preview failed at frame {record.frame}: {error}")
    finally:
        if moved_frame:
            scene.frame_set(original_frame, subframe=original_subframe)
        _rendering_live = False
        request_redraw()
    return _next_live_timer_delay(scene, resolved)


def schedule_live_render(camera, record, *, input_change=False):
    if camera is None or record is None:
        return
    if input_change:
        # Collection and node-tree edits do not emit an RNA property callback.
        # Keep signature invalidation at the scheduler authority boundary so a
        # newly rendered preview can never be stamped with an older signature.
        from .impaction_renderer import invalidate_record_signature
        invalidate_record_signature(record)
    if _live_suspended or not _preview_display_active(camera):
        return
    key = (camera.name_full, int(record.salt))
    now = time.monotonic()
    state = _pending_live.get(key)
    if state is None:
        state = {
            "key": key,
            "camera_name": camera.name_full,
            "salt": int(record.salt),
            "frame": int(record.frame),
            "queued_at": now,
            "last_input_at": now,
            "last_render_at": 0.0,
            "dirty": True,
            "failures": 0,
        }
        _pending_live[key] = state
    else:
        state["frame"] = int(record.frame)
        if input_change:
            state["queued_at"] = now
            state["last_input_at"] = now
            state["dirty"] = True
            state["failures"] = 0
    if not bpy.app.timers.is_registered(_render_pending_live):
        bpy.app.timers.register(_render_pending_live, first_interval=0.01)


def cancel_live_render(camera, record):
    if camera is not None and record is not None:
        _pending_live.pop((camera.name_full, int(record.salt)), None)
        try:
            from .impaction_renderer import clear_record_preview
            clear_record_preview(camera, record)
        except (ImportError, ReferenceError, RuntimeError):
            pass


def cancel_pending_live_render(camera, record):
    """Drop queued work without discarding an already promoted live image."""
    if camera is not None and record is not None:
        _pending_live.pop((camera.name_full, int(record.salt)), None)


def schedule_marker_sync(camera=None, immediate=False):
    """Defer FCurve writes until Blender releases any active key transform."""
    global _marker_sync_deadline
    if camera is not None:
        _pending_marker_cameras.add(camera.name_full)
    else:
        scene = getattr(bpy.context, "scene", None)
        for candidate in getattr(scene, "objects", ()) if scene else ():
            if candidate.type == "CAMERA" and getattr(candidate, "impaction_frames", None):
                _pending_marker_cameras.add(candidate.name_full)
    _marker_sync_deadline = time.monotonic() + (0.0 if immediate else 0.08)
    if not bpy.app.timers.is_registered(_sync_pending_markers):
        bpy.app.timers.register(_sync_pending_markers, first_interval=0.0 if immediate else 0.08)


def _sync_pending_markers():
    if not _pending_marker_cameras:
        return None
    if animation_playing() or _transform_operator_active():
        return 0.08
    remaining = _marker_sync_deadline - time.monotonic()
    if remaining > 0.0:
        return max(0.01, remaining)
    names = tuple(_pending_marker_cameras)
    _pending_marker_cameras.clear()
    for name in names:
        camera = bpy.data.objects.get(name)
        if camera is not None:
            sync_camera_markers(camera)
    return 0.01 if _pending_marker_cameras else None


def selected_property_records(camera, record):
    """Return the selected edit set only when it contains the source record."""
    if _exclusive_edit_pointer == record.as_pointer():
        # Modal viewport tools author one visible record while they run. This
        # also keeps nested shape callbacks (not just frame RNA callbacks)
        # frame-local for drag and doodle operations.
        return [record]
    targets = selected_records(camera)
    source_pointer = record.as_pointer()
    if any(target.as_pointer() == source_pointer for target in targets):
        return targets
    return [record]


def property_changed(record, context, property_name):
    global _propagating
    if _propagating:
        return
    if _live_suspended:
        try:
            from .impaction_renderer import invalidate_record_signature
            invalidate_record_signature(record)
        except (AttributeError, ImportError, ReferenceError, RuntimeError):
            pass
        return
    camera = _record_owner(record)
    if camera is None:
        return
    value = getattr(record, property_name)
    if property_name in {
        "strength", "line_thickness", "band_transition", "motion_blur", "contrast", "grayscale", "bloom", "chromatic_aberration",
        "grain", "grain_overlay_intensity", "halftone", "pixelate",
        "light_radius", "bleed", "angle",
    }:
        if property_name == "angle":
            # Angle controls are intentionally unbounded while dragging and
            # typing. Store one canonical turn so 270 degrees becomes -90,
            # cache signatures stay stable, and crossing +/-180 flips the
            # authored axis instead of clamping against an artificial wall.
            degrees = math.degrees(float(value))
            normalized = (degrees + 180.0) % 360.0 - 180.0
            quantized = math.radians(round(normalized, 2))
        else:
            quantized = round(float(value), 2)
        if abs(float(value) - quantized) > 1.0e-7:
            _propagating = True
            try:
                setattr(record, property_name, quantized)
            finally:
                _propagating = False
        value = quantized
    alias_name = str(record.get("_property_alias", ""))
    alias_component = int(record.get("_property_alias_component", -1))
    if _exclusive_edit_pointer == record.as_pointer():
        targets = [record]
    else:
        targets = selected_property_records(camera, record)
    _propagating = True
    try:
        from .impaction_renderer import invalidate_record_signature
        for target in targets:
            if target.as_pointer() != record.as_pointer():
                if alias_name and 0 <= alias_component < len(value):
                    target_value = list(getattr(target, property_name))
                    target_value[alias_component] = value[alias_component]
                    setattr(target, property_name, target_value)
                else:
                    setattr(target, property_name, value)
            invalidate_record_signature(target)
            if not _live_suspended:
                schedule_live_render(camera, target, input_change=True)
    finally:
        _propagating = False
    request_redraw()


def suspend_live_render(enabled):
    global _live_suspended
    _live_suspended = bool(enabled)


def live_render_suspended():
    return _live_suspended


def set_exclusive_property_edit(record=None):
    """Limit modal viewport edits to one visible record, not all selected keys."""
    global _exclusive_edit_pointer
    _exclusive_edit_pointer = record.as_pointer() if record is not None else None


def commit_exclusive_property_edit(record, context, property_name):
    """Commit one finished modal value to hidden selected records.

    The source remains exclusive throughout modal motion and cancellation.  A
    successful operator settles the source image first, then calls this helper
    once so hidden records receive only the final canonical property value.
    """
    global _exclusive_edit_pointer, _propagating
    _exclusive_edit_pointer = None
    camera = _record_owner(record)
    if camera is None:
        return
    value = getattr(record, property_name)
    source_pointer = record.as_pointer()
    _propagating = True
    try:
        from .impaction_renderer import invalidate_record_signature
        for target in selected_property_records(camera, record):
            if target.as_pointer() == source_pointer:
                continue
            setattr(target, property_name, value)
            invalidate_record_signature(target)
            schedule_live_render(camera, target, input_change=True)
    finally:
        _propagating = False
    request_redraw(camera)


def _playing_or_previewing(context):
    return context.scene.impaction.preview_opacity > 0.0


def interactive_frame_record(context, camera=None):
    """Return the selected held record only in an interactive camera viewport."""
    record = displayed_frame_record(context, camera)
    if record is None:
        return None
    workspace = getattr(getattr(context, "window", None), "workspace", None)
    workspace_name = str(getattr(workspace, "name", "")).casefold()
    if workspace_name.startswith(("preview", "audio")):
        return None
    camera = viewed_camera(context)
    return record if int(record.salt) in _interactive_selected_salts(camera) else None


def displayed_frame_record(context, camera=None):
    """Return the held record only while its opaque camera overlay is visible."""
    if context is None or not _playing_or_previewing(context):
        return None
    viewed = viewed_camera(context)
    if viewed is None or (camera is not None and viewed != camera):
        return None
    camera = viewed
    if camera_bone_binding(camera)[0] is None:
        return None
    held = held_frame_record(context.scene, camera, context.scene.frame_current)
    if held is None:
        return None
    from .impaction_renderer import display_image, display_surface
    return held if (
        display_surface(camera, held, prefer_preview=True) is not None
        or display_image(camera, held, prefer_preview=True) is not None
    ) else None


def impact_hides_viewport_labels(context=None):
    """Tell sibling UI modules when the Impact image owns the camera frame."""
    return displayed_frame_record(context or bpy.context) is not None


def interactive_radial_record(context, camera=None):
    """Return the selected radial record only while its image is interactive."""
    record = interactive_frame_record(context, camera)
    return record if (
        record is not None and bool(record.radial_enabled)
    ) else None


def interactive_light_record(context, camera=None):
    """Return the selected held record whose camera-space light can be dragged."""
    return interactive_frame_record(context, camera)


def interactive_direction_record(context, camera=None):
    """Return the selected record using the shared magenta field dragger."""
    return interactive_frame_record(context, camera)


def _draw():
    context = bpy.context
    if not context.area or context.area.type != "VIEW_3D" or not _playing_or_previewing(context):
        return
    camera = viewed_camera(context)
    if camera is None or camera_bone_binding(camera)[0] is None:
        return
    playing = animation_playing(context)
    if not playing:
        _ensure_marker_polling()
    record = held_frame_record(context.scene, camera, context.scene.frame_current)
    if record is not None:
        # Install the RMB image guard per visible camera area, including every
        # workspace/window where the same current Impact frame is displayed.
        if not playing:
            from .impaction_operators import ensure_viewport_input_shield
            ensure_viewport_input_shield(context)
        opacity = max(0.0, min(1.0, context.scene.impaction.preview_opacity / 100.0))
        drawn = draw_cached_image(
            context, camera, record, opacity=opacity,
            prefer_preview=not playing,
        )
        if not playing:
            from .impaction_renderer import display_matches_record
            if not drawn or not display_matches_record(camera, record, context.scene):
                # Missing, invalid, stale-after-undo, and renderer-version-old
                # frames recover lazily. The queue deduplicates draw callbacks.
                schedule_live_render(camera, record)
        interactive = interactive_frame_record(context, camera) if not playing else None
        if interactive is not None:
            from .impaction_renderer import draw_camera_pin_overlays
            draw_camera_pin_overlays(context, camera, interactive)


_FRAME_PROPERTIES = (
    "mode", "linear_enabled", "radial_enabled",
    "direction_focus", "direction_cast_behind", "halo_spread",
    "motion_curve_influence",
    "angle", "focus",
    "strength", "line_thickness", "radial_threshold", "radial_spiral",
    "foreground", "background",
    "background_intensity", "background_motion", "invert",
    "band_transition", "motion_blur", "contrast", "grayscale", "bloom", "chromatic_aberration", "aberration_preset", "aberration_blur_smoothing",
    "aberration_color_a", "aberration_color_b", "grain",
    "grain_overlay_intensity", "halftone",
    "halftone_size", "pixelate", "pixelate_size",
    "light_focus", "light_radius", "bleed", "light_cast_behind",
    "light_color_source", "light_color",
)


def _clone_timeline_record(camera, source, frame):
    """Clone settings and completed pixels for a native Dope Sheet paste."""
    global _live_suspended
    from .impaction_renderer import duplicate_record_cache
    from .impaction_gradient import copy_aberration_ramp
    target = camera.impaction_frames.add()
    target.initialize(frame)
    previous = _live_suspended
    _live_suspended = True
    try:
        for name in _FRAME_PROPERTIES:
            value = getattr(source, name)
            setattr(target, name, tuple(value) if hasattr(value, "__len__") and not isinstance(value, str) else value)
    finally:
        _live_suspended = previous
    copy_aberration_ramp(source, target)
    from .impaction_operators import _shape_values, _replace_shapes
    _replace_shapes(target, [_shape_values(shape) for shape in source.shapes])
    duplicate_record_cache(camera, source, target)
    return target


def _record_snapshot(camera, record):
    from .impaction_renderer import detach_record_cache
    from .impaction_gradient import ensure_aberration_ramp
    from .impaction_operators import _shape_values
    ensure_aberration_ramp(record)
    values = {}
    for name in _FRAME_PROPERTIES:
        value = getattr(record, name)
        values[name] = tuple(value) if hasattr(value, "__len__") and not isinstance(value, str) else value
    snapshot = {
        "salt": int(record.salt),
        "frame": int(record.frame),
        "values": values,
        "shapes": [_shape_values(shape) for shape in record.shapes],
        "ramp_name": str(record.aberration_ramp),
        "cache": detach_record_cache(camera, record),
    }
    snapshot["estimated_bytes"] = _deleted_snapshot_byte_weight(snapshot)
    return snapshot


def _deleted_snapshot_byte_weight(snapshot):
    """Estimate native Image/Mesh memory retained solely for timeline Undo."""
    cache = snapshot.get("cache") if snapshot else None
    total = 4096 + len(snapshot.get("shapes", ())) * 2048 if snapshot else 1
    image_name = cache[1] if cache else ""
    image = bpy.data.images.get(image_name) if image_name else None
    if image is not None:
        channels = max(1, int(getattr(image, "channels", 4)))
        component_bytes = 4 if bool(getattr(image, "is_float", True)) else 1
        total += int(image.size[0]) * int(image.size[1]) * channels * component_bytes
    capture_names = cache[4:6] if cache and len(cache) >= 6 else ()
    for name in capture_names:
        mesh = bpy.data.meshes.get(name) if name else None
        if mesh is not None:
            total += len(mesh.vertices) * 64
            total += len(mesh.loops) * 8
            total += len(mesh.polygons) * 32
    return max(1, int(total))


def _stash_deleted_record(camera, record):
    key = (camera.name_full, int(record.salt))
    old = _deleted_records.pop(key, None)
    if old is not None:
        _purge_snapshot(old)
    _deleted_records[key] = _record_snapshot(camera, record)
    total = sum(
        int(snapshot.get("estimated_bytes", 1))
        for snapshot in _deleted_records.values()
    )
    while (len(_deleted_records) > 1 and (
            len(_deleted_records) > _DELETED_RECORD_BUDGET
            or total > _DELETED_RECORD_BYTE_BUDGET)):
        oldest_key = next(iter(_deleted_records))
        oldest = _deleted_records.pop(oldest_key)
        total -= int(oldest.get("estimated_bytes", 1))
        _purge_snapshot(oldest)


def _purge_snapshot(snapshot):
    cache = snapshot.get("cache") if snapshot else None
    image_name = cache[1] if cache else ""
    image = bpy.data.images.get(image_name) if image_name else None
    active = any(
        record.cache_image == image_name
        for camera in (obj for obj in bpy.data.objects if obj.type == "CAMERA")
        for record in getattr(camera, "impaction_frames", ())
    )
    if image is not None and not active:
        image.use_fake_user = False
        if image.users == 0:
            bpy.data.images.remove(image)
    if cache and len(cache) >= 6:
        capture_names = cache[4:6]
    elif cache and len(cache) >= 5:
        capture_names = cache[3:5]
    else:
        capture_names = ()
    active_captures = {
        name
        for camera in (obj for obj in bpy.data.objects if obj.type == "CAMERA")
        for record in getattr(camera, "impaction_frames", ())
        for name in (record.capture_subject, record.capture_floor)
        if name
    }
    for name in capture_names:
        mesh = bpy.data.meshes.get(name) if name else None
        if mesh is not None and name not in active_captures:
            mesh.use_fake_user = False
            if mesh.users == 0:
                bpy.data.meshes.remove(mesh)
    ramp_name = snapshot.get("ramp_name", "") if snapshot else ""
    ramp = bpy.data.node_groups.get(ramp_name) if ramp_name else None
    ramp_active = any(
        record.aberration_ramp == ramp_name
        for camera in (obj for obj in bpy.data.objects if obj.type == "CAMERA")
        for record in getattr(camera, "impaction_frames", ())
    )
    if ramp is not None and not ramp_active:
        bpy.data.node_groups.remove(ramp)


def _deleted_snapshot(camera, value):
    return next(
        (snapshot for (camera_name, _salt), snapshot in _deleted_records.items()
         if camera_name == camera.name_full
         and abs(salt_value(snapshot["salt"]) - float(value)) <= 1.0e-5),
        None,
    )


def _restore_deleted_record(camera, snapshot, frame):
    global _live_suspended
    from .impaction_renderer import restore_record_cache
    target = camera.impaction_frames.add()
    previous = _live_suspended
    _live_suspended = True
    try:
        target.frame = int(frame)
        target.salt = int(snapshot["salt"])
        target.aberration_ramp = snapshot.get("ramp_name", "")
        for name, value in snapshot["values"].items():
            setattr(target, name, value)
        from .impaction_operators import _replace_shapes
        _replace_shapes(target, snapshot.get("shapes", ()))
    finally:
        _live_suspended = previous
    restore_record_cache(camera, target, snapshot["cache"])
    _deleted_records.pop((camera.name_full, int(snapshot["salt"])), None)
    return target


def _marker_signature(camera):
    armature, _bone = camera_bone_binding(camera)
    curves = marker_fcurves(armature, camera) if armature else ()
    if not curves:
        return ()
    return tuple(
        (curve.data_path, round(float(point.co.x), 4), round(float(point.co.y), 9),
         getattr(point, "type", ""))
        for curve in curves for point in curve.keyframe_points
    )


def _deselect_generated_tails(camera):
    armature, _bone = camera_bone_binding(camera)
    for curve in marker_fcurves(armature, camera) if armature else ():
        for point in curve.keyframe_points:
            if getattr(point, "type", "") == "GENERATED":
                point.select_control_point = False
                point.select_left_handle = False
                point.select_right_handle = False


def _actual_marker_count(signature):
    return sum(1 for item in signature if len(item) > 3 and item[3] != "GENERATED")


def _schedule_signature_change(camera, previous, current):
    """Delete immediately; debounce coordinate edits until transform release."""
    deleted = _actual_marker_count(current) < _actual_marker_count(previous)
    schedule_marker_sync(camera, immediate=deleted)


def remember_gradient_signatures(camera, records):
    """Mark deliberate ramp operations as observed by the polling bridge."""
    from .impaction_gradient import aberration_ramp_signature
    for record in records:
        _gradient_signatures[(camera.name_full, int(record.salt))] = (
            aberration_ramp_signature(record)
        )


def _gradient_changed_color_indices(previous, current):
    """Return logical stop indices changed by a direct color-picker edit."""
    if (previous is None or len(previous) < 5 or len(current) < 5
            or previous[:4] != current[:4]):
        return ()
    previous_stops, current_stops = previous[4], current[4]
    if (len(previous_stops) != len(current_stops)
            or any(old[0] != new[0]
                   for old, new in zip(previous_stops, current_stops))):
        return ()
    return tuple(
        index for index, (old, new) in enumerate(
            zip(previous_stops, current_stops)
        )
        if old[1] != new[1]
    )


def sync_aberration_ramp_edits(camera, records):
    """Propagate direct ramp-stop color edits by logical index."""
    from .impaction_gradient import (
        aberration_ramp_signature, set_aberration_color,
    )
    from .impaction_renderer import invalidate_record_signature

    unique_records = {
        record.as_pointer(): record for record in records if record is not None
    }
    changed_records = {}
    for record in tuple(unique_records.values()):
        key = (camera.name_full, int(record.salt))
        current = aberration_ramp_signature(record)
        previous = _gradient_signatures.get(key)
        _gradient_signatures[key] = current
        if previous is None or previous == current:
            continue
        changed_records[record.as_pointer()] = record
        indices = _gradient_changed_color_indices(previous, current)
        if not indices:
            continue
        source_pointer = record.as_pointer()
        for target in selected_property_records(camera, record):
            if target.as_pointer() == source_pointer:
                continue
            target_changed = False
            for index in indices:
                target_changed = set_aberration_color(
                    target, index, current[4][index][1],
                ) or target_changed
            if target_changed:
                changed_records[target.as_pointer()] = target
                _gradient_signatures[
                    (camera.name_full, int(target.salt))
                ] = aberration_ramp_signature(target)

    for record in changed_records.values():
        invalidate_record_signature(record)
        schedule_live_render(camera, record, input_change=True)
    if changed_records:
        request_redraw(camera)
    return tuple(changed_records.values())


def _poll_marker_changes():
    """Catch native copy/paste/delete operations that emit no reliable handler."""
    if not _preview_display_active():
        # A recurring Blender timer can contend with gizmo hover/hit-testing.
        # Stop it completely whenever no Impact preview is on screen.
        return None
    if animation_playing():
        # The draw handler restarts polling when playback stops. Avoid waking
        # a 20 Hz edit-state timer while Blender is advancing cached frames.
        return None
    if not _transform_operator_active():
        scene = getattr(bpy.context, "scene", None)
        for camera in (obj for obj in getattr(scene, "objects", ()) if obj.type == "CAMERA"):
            if not getattr(camera, "impaction_frames", None):
                continue
            _deselect_generated_tails(camera)
            signature = _marker_signature(camera)
            if camera.name_full not in _marker_signatures:
                _marker_signatures[camera.name_full] = signature
            elif _marker_signatures.get(camera.name_full) != signature:
                previous = _marker_signatures[camera.name_full]
                _marker_signatures[camera.name_full] = signature
                _schedule_signature_change(camera, previous, signature)
            visible = held_frame_record(
                scene, camera, scene.frame_current,
            ) if scene is not None else None
            gradient_records = selected_records(camera)
            if (visible is not None and not any(
                    record.as_pointer() == visible.as_pointer()
                    for record in gradient_records)):
                gradient_records.append(visible)
            sync_aberration_ramp_edits(camera, gradient_records)
    return 0.05


def _ensure_marker_polling():
    if (_preview_display_active()
            and not bpy.app.timers.is_registered(_poll_marker_changes)):
        bpy.app.timers.register(_poll_marker_changes, first_interval=0.05)


def sync_camera_markers(camera):
    global _syncing
    if _syncing:
        return
    armature, _bone = camera_bone_binding(camera)
    if armature is None:
        return
    curves = marker_fcurves(armature, camera)
    if not curves:
        # Deleting the complete Impact Frames channel removes every marker
        # FCurve in one operation. Treat the records and images as deleted too.
        for index in range(len(camera.impaction_frames) - 1, -1, -1):
            record = camera.impaction_frames[index]
            cancel_live_render(camera, record)
            _stash_deleted_record(camera, record)
            camera.impaction_frames.remove(index)
        camera.impaction_grid_initialized = False
        _marker_signatures[camera.name_full] = ()
        request_redraw()
        return
    _syncing = True
    try:
        records = list(camera.impaction_frames)
        unmatched = set(range(len(records)))
        used_frames = set()
        interval = impact_grid_interval(bpy.context.scene, camera)
        curve_changed = False
        invalid_points = []
        changed_curves = set()
        actual_points = [
            (curve, point) for curve in curves for point in curve.keyframe_points
            if getattr(point, "type", "") != "GENERATED"
        ]
        for owner_curve, point in actual_points:
            best = min(
                unmatched,
                key=lambda index: abs(salt_value(records[index].salt) - point.co.y),
                default=None,
            )
            if best is not None and abs(salt_value(records[best].salt) - point.co.y) <= 1.0e-5:
                record = records[best]
                unmatched.remove(best)
                snapshot = _deleted_records.get((camera.name_full, int(record.salt)))
                if snapshot is not None:
                    from .impaction_renderer import restore_record_cache
                    restore_record_cache(camera, record, snapshot["cache"])
                    _deleted_records.pop(
                        (camera.name_full, int(record.salt)), None,
                    )
            else:
                # Native Dope Sheet copy/paste duplicates only the FCurve point.
                # Recreate the extension record and clone its finished pixels.
                source = next(
                    (item for item in records if abs(salt_value(item.salt) - point.co.y) <= 1.0e-5),
                    None,
                )
                if source is None:
                    snapshot = _deleted_snapshot(camera, point.co.y)
                    if snapshot is None:
                        invalid_points.append((owner_curve, point))
                        continue
                    provisional = impact_grid_frame(bpy.context.scene, camera, point.co.x)
                    record = _restore_deleted_record(camera, snapshot, provisional)
                    records.append(record)
                else:
                    provisional = impact_grid_frame(bpy.context.scene, camera, point.co.x)
                    record = _clone_timeline_record(camera, source, provisional)
                    point.co.y = salt_value(record.salt)
                    curve_changed = True
                    changed_curves.add(owner_curve.as_pointer())
            moved_frame = impact_grid_frame(bpy.context.scene, camera, point.co.x)
            while moved_frame in used_frames:
                moved_frame += interval
            used_frames.add(moved_frame)
            if abs(point.co.x - moved_frame) > 0.0001:
                point.co.x = float(moved_frame)
                curve_changed = True
                changed_curves.add(owner_curve.as_pointer())
            if record.frame != moved_frame:
                from .impaction_renderer import retime_capture
                old_frame = int(record.frame)
                record.frame = moved_frame
                retime_capture(camera, record, old_frame)
                cancel_live_render(camera, record)
        for owner_curve, point in invalid_points:
            owner_curve.keyframe_points.remove(point, fast=True)
            curve_changed = True
            changed_curves.add(owner_curve.as_pointer())
        # Marker deletion removes its settings; records on another camera sharing
        # the owner armature are retained because their salts do not match.
        for index in sorted(unmatched, reverse=True):
            stale = records[index]
            _stash_deleted_record(camera, stale)
            collection_index = next(
                (i for i, item in enumerate(camera.impaction_frames) if item.as_pointer() == stale.as_pointer()),
                None,
            )
            if collection_index is not None:
                camera.impaction_frames.remove(collection_index)
        if curve_changed:
            for curve in curves:
                if curve.as_pointer() in changed_curves:
                    curve.update()
        rebuild_marker_exposure(armature, camera)
        _marker_signatures[camera.name_full] = _marker_signature(camera)
        if not camera.impaction_frames:
            camera.impaction_grid_initialized = False
    finally:
        _syncing = False


@persistent
def frame_change_post(scene, _depsgraph=None):
    if _rendering_live or _live_suspended or not _preview_display_active():
        return
    if not animation_playing():
        from .impaction_renderer import cache_matches_record
        cameras = {camera.name_full: camera for camera in _camera_viewports()}
        for camera in cameras.values():
            record = held_frame_record(scene, camera, scene.frame_current)
            if record is not None and not cache_matches_record(record, scene):
                schedule_live_render(camera, record)
    request_redraw()


@persistent
def depsgraph_update_post(scene, _depsgraph=None):
    global _draw_priority_checked_at
    if not _preview_display_active():
        return
    if _syncing or _rendering_live or _live_suspended or animation_playing():
        return
    now = time.monotonic()
    if now - _draw_priority_checked_at >= 0.5:
        _draw_priority_checked_at = now
        _raise_draw_handler_after_animator_labels()
    for camera in (obj for obj in scene.objects if obj.type == "CAMERA"):
        if hasattr(camera, "impaction_frames") and camera.impaction_frames:
            _deselect_generated_tails(camera)
            signature = _marker_signature(camera)
            if camera.name_full not in _marker_signatures:
                _marker_signatures[camera.name_full] = signature
            elif _marker_signatures[camera.name_full] != signature:
                previous = _marker_signatures[camera.name_full]
                _marker_signatures[camera.name_full] = signature
                _schedule_signature_change(camera, previous, signature)


@persistent
def undo_post(_scene):
    global _rendering_live
    from .impaction_renderer import (
        clear_transient_previews, invalidate_display_uploads,
    )
    clear_transient_previews()
    # Undo can restore an older Image datablock name while Blender retains a
    # managed GPU handle for the newer pixels. Force the first returning frame
    # to upload its packed CPU pixels; otherwise that valid cache can display
    # as a full black rectangle until an explicit Update replaces it.
    invalidate_display_uploads()
    for camera in (obj for obj in bpy.data.objects if obj.type == "CAMERA"):
        # Image pixels are not RNA undo data. Mark every record stale so an
        # off-screen edited frame cannot later reuse post-undo pixels under a
        # restored pre-edit signature. The visible record is rebuilt below.
        for record in getattr(camera, "impaction_frames", ()):
            record.cache_signature = ""
        restored_fps = _restore_fps_layout(camera)
        armature, _bone = camera_bone_binding(camera)
        curves = marker_fcurves(armature, camera) if armature else ()
        has_snapshot = any(key[0] == camera.name_full for key in _deleted_records)
        if (not restored_fps and
                (getattr(camera, "impaction_frames", None) or curves or has_snapshot)):
            sync_camera_markers(camera)
    # Blender restores RNA values during undo/redo, but GPU-generated pixels
    # are not undo data. Never render synchronously inside Blender's undo
    # handler: nested GPU/RNA work there makes rapid property undo unreliable.
    # Queue the restored visible record for the next safe main-loop timer.
    context = bpy.context
    camera = viewed_camera(context)
    scene = getattr(context, "scene", None)
    record = (
        held_frame_record(scene, camera, scene.frame_current)
        if scene is not None and camera is not None else None
    )
    if record is not None:
        key = (camera.name_full, int(record.salt))
        schedule_live_render(camera, record, input_change=True)
        state = _pending_live.get(key)
        if state is not None:
            state["last_render_at"] = 0.0
    request_redraw()


@persistent
def redo_post(_scene):
    undo_post(_scene)


@persistent
def save_pre(_dummy):
    # Applied previews are already packed. Reconcile once more at the save
    # boundary and discard any abandoned extension preview from older builds.
    try:
        from .impaction_renderer import pack_record_images
        pack_record_images()
    except (AttributeError, ImportError, ReferenceError, RuntimeError, TypeError):
        pass


@persistent
def load_post(_dummy):
    global _live_render_ema
    _pending_live.clear()
    _pending_marker_cameras.clear()
    _marker_signatures.clear()
    _gradient_signatures.clear()
    _deleted_records.clear()
    _fps_values.clear()
    _fps_layouts.clear()
    _interactive_selection_cache.clear()
    _live_render_ema = 0.0
    from .impaction_renderer import clear_session_caches
    clear_session_caches()
    # During extension registration Blender exposes _RestrictData, which
    # intentionally has no .objects collection. The real load_post handler
    # will initialize signatures once normal file data is available.
    try:
        objects = bpy.data.objects
    except (AttributeError, RuntimeError):
        return
    # v0.1.50 normalized the three effects from 0..100 to 0..1. Preserve the
    # visual strength of records saved by older extension builds.
    for owner in objects:
        for record in getattr(owner, "impaction_frames", ()):
            # 0.3.27 removes the legacy 2D/3D selector. Every composition now
            # consumes the camera-space direction field.
            if "direction_source" in record:
                del record["direction_source"]
            if "direction_cast_behind" not in record:
                record["direction_cast_behind"] = False
            # An absent legacy value is not an authored None frame. Match the
            # explicit Linear initialization used by every newly created key.
            if "mode" not in record:
                record["mode"] = "LINEAR"
            if "linear_enabled" not in record and "radial_enabled" not in record:
                legacy_mode = str(record.mode)
                record["linear_enabled"] = legacy_mode == "LINEAR"
                record["radial_enabled"] = legacy_mode == "RADIAL"
            # 0.2.1 replaces the ambiguous Paper light preset with explicit
            # Foreground/Background choices. The former Paper preset was the
            # automatic paper endpoint, which is now named Background.
            if record.get("light_color_source") == "PAPER":
                record["light_color_source"] = "BACKGROUND"
            # 0.3.63 replaces the source chooser with one direct color box.
            # Resolve the old endpoint selection once, then use Custom from
            # here onward so saved appearances survive the UI simplification.
            legacy_light_source = str(record.light_color_source)
            if legacy_light_source != "CUSTOM":
                record.light_color = (
                    tuple(record.foreground) if legacy_light_source == "FOREGROUND"
                    else tuple(record.background)
                )
                record.light_color_source = "CUSTOM"
            # v0.1.87 initializes a never-edited Custom ramp as red/cyan when
            # the user first switches modes. Preserve any authored ramp from
            # older files, including a deliberate single-color setup.
            if "aberration_custom_initialized" not in record:
                from .impaction_gradient import aberration_colors
                colors = aberration_colors(record)
                default_unedited = (
                    len(colors) == 1 and
                    all(abs(colors[0][index] - expected) < 1.0e-5
                        for index, expected in enumerate((1.0, 0.0, 0.0, 1.0)))
                )
                record["aberration_custom_initialized"] = not default_unedited
            # v0.1.84 split the former endpoint-swapping Invert into Flip and
            # redefined Invert as a final-frame photographic negative. Migrate
            # old records without changing their saved appearance.
            if int(getattr(record, "color_semantics_version", 0)) < 2:
                record["flip"] = bool(record.invert)
                record["invert"] = False
                record["color_semantics_version"] = 2
            # 0.3.80 simplifies Band to one 0..1 strength. The old negative
            # half only phase-shifted the same material erosion, so preserve
            # its authored strength rather than clamping legacy files to Off.
            if int(getattr(record, "band_semantics_version", 0)) < 1:
                legacy_band = float(record.get(
                    "band_transition", getattr(record, "band_transition", 0.0),
                ))
                record["band_transition"] = min(1.0, abs(legacy_band))
                record["band_semantics_version"] = 1
            # 0.3.81 materializes Flip into the two stored color values so the
            # UI boxes truthfully show the active endpoints. Preserve the old
            # rendered appearance exactly once when loading older records.
            if int(getattr(record, "flip_semantics_version", 0)) < 1:
                if bool(record.flip):
                    foreground = tuple(record.foreground)
                    background = tuple(record.background)
                    record["foreground"] = background
                    record["background"] = foreground
                record["flip_semantics_version"] = 1
            # 0.3.88 turns Flip into a stateless action. The two materialized
            # color values already represent the visible palette, so retire
            # the legacy toggle without replaying another swap.
            if int(getattr(record, "flip_semantics_version", 0)) < 2:
                record["flip"] = False
                record["flip_semantics_version"] = 2
            # 0.3.59 adds independent Burst end shaping. Older blend files do
            # not own this RNA value yet; initialize it without disturbing
            # any authored Star dimensions.
            for shape in record.shapes:
                if "burst_end" not in shape:
                    shape["burst_end"] = 0.0
                if "effect_influence" not in shape:
                    shape["effect_influence"] = 0.5
            for property_name in ("bloom", "chromatic_aberration", "grain"):
                value = float(getattr(record, property_name, 0.0))
                if value > 1.0:
                    setattr(record, property_name, min(1.0, value / 100.0))
            image = bpy.data.images.get(record.cache_image) if record.cache_image else None
            if image is None:
                record.cache_valid = False
            elif record.cache_valid:
                image.use_fake_user = True
            for name in (record.capture_subject, record.capture_floor):
                mesh = bpy.data.meshes.get(name) if name else None
                if mesh is not None:
                    mesh.use_fake_user = True
    for camera in (obj for obj in objects if obj.type == "CAMERA"):
        if getattr(camera, "impaction_frames", None):
            _marker_signatures[camera.name_full] = _marker_signature(camera)
    # Registration calls load_post too, so upgrading an existing session also
    # clears the single orphan dirty preview left by earlier extension builds.
    try:
        from .impaction_renderer import pack_record_images
        pack_record_images()
    except (AttributeError, ImportError, ReferenceError, RuntimeError, TypeError):
        pass


def register_runtime():
    global _draw_handle
    stale_handle = bpy.app.driver_namespace.pop(_DRAW_HANDLE_KEY, None)
    if stale_handle is not None and stale_handle is not _draw_handle:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(stale_handle, "WINDOW")
        except (ReferenceError, RuntimeError, ValueError):
            pass
    stale_timers = bpy.app.driver_namespace.pop(_TIMER_CALLBACKS_KEY, ())
    for callback in stale_timers:
        try:
            if bpy.app.timers.is_registered(callback):
                bpy.app.timers.unregister(callback)
        except (ReferenceError, RuntimeError, ValueError):
            pass
    if _draw_handle is None:
        _draw_handle = bpy.types.SpaceView3D.draw_handler_add(_draw, (), "WINDOW", "POST_PIXEL")
    bpy.app.driver_namespace[_DRAW_HANDLE_KEY] = _draw_handle
    bpy.app.driver_namespace[_LABEL_OCCLUSION_QUERY_KEY] = (
        impact_hides_viewport_labels
    )
    bpy.app.driver_namespace[_TIMER_CALLBACKS_KEY] = (
        _render_pending_live, _deferred_draw_priority, _sync_pending_markers,
        _poll_marker_changes, _warm_renderer_resources,
    )
    if frame_change_post not in bpy.app.handlers.frame_change_post:
        bpy.app.handlers.frame_change_post.append(frame_change_post)
    if depsgraph_update_post not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(depsgraph_update_post)
    if undo_post not in bpy.app.handlers.undo_post:
        bpy.app.handlers.undo_post.append(undo_post)
    if redo_post not in bpy.app.handlers.redo_post:
        bpy.app.handlers.redo_post.append(redo_post)
    if save_pre not in bpy.app.handlers.save_pre:
        bpy.app.handlers.save_pre.append(save_pre)
    if load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(load_post)
    load_post(None)
    if not bpy.app.timers.is_registered(_deferred_draw_priority):
        bpy.app.timers.register(_deferred_draw_priority, first_interval=0.25)
    if not bpy.app.background and not bpy.app.timers.is_registered(
        _warm_renderer_resources
    ):
        bpy.app.timers.register(_warm_renderer_resources, first_interval=0.35)


def unregister_runtime():
    global _draw_handle, _animator_pixel_handle_token, _exclusive_edit_pointer
    global _warmup_attempts, _live_render_ema, _draw_priority_checked_at
    _pending_live.clear()
    _pending_marker_cameras.clear()
    _marker_signatures.clear()
    _gradient_signatures.clear()
    _exclusive_edit_pointer = None
    _warmup_attempts = 0
    _live_render_ema = 0.0
    _draw_priority_checked_at = 0.0
    _fps_values.clear()
    _fps_layouts.clear()
    _interactive_selection_cache.clear()
    for snapshot in tuple(_deleted_records.values()):
        _purge_snapshot(snapshot)
    _deleted_records.clear()
    if bpy.app.timers.is_registered(_render_pending_live):
        bpy.app.timers.unregister(_render_pending_live)
    if bpy.app.timers.is_registered(_deferred_draw_priority):
        bpy.app.timers.unregister(_deferred_draw_priority)
    if bpy.app.timers.is_registered(_sync_pending_markers):
        bpy.app.timers.unregister(_sync_pending_markers)
    if bpy.app.timers.is_registered(_poll_marker_changes):
        bpy.app.timers.unregister(_poll_marker_changes)
    if bpy.app.timers.is_registered(_warm_renderer_resources):
        bpy.app.timers.unregister(_warm_renderer_resources)
    if _draw_handle is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(_draw_handle, "WINDOW")
        except (ReferenceError, RuntimeError, ValueError):
            # Blender can invalidate the capsule first while replacing or
            # shutting down an extension. Treat that null native handle as
            # already removed instead of crashing unregister/reload.
            pass
        _draw_handle = None
    bpy.app.driver_namespace.pop(_DRAW_HANDLE_KEY, None)
    bpy.app.driver_namespace.pop(_TIMER_CALLBACKS_KEY, None)
    if (
        bpy.app.driver_namespace.get(_LABEL_OCCLUSION_QUERY_KEY)
        is impact_hides_viewport_labels
    ):
        bpy.app.driver_namespace.pop(_LABEL_OCCLUSION_QUERY_KEY, None)
    _animator_pixel_handle_token = None
    if frame_change_post in bpy.app.handlers.frame_change_post:
        bpy.app.handlers.frame_change_post.remove(frame_change_post)
    if depsgraph_update_post in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(depsgraph_update_post)
    if undo_post in bpy.app.handlers.undo_post:
        bpy.app.handlers.undo_post.remove(undo_post)
    if redo_post in bpy.app.handlers.redo_post:
        bpy.app.handlers.redo_post.remove(redo_post)
    if save_pre in bpy.app.handlers.save_pre:
        bpy.app.handlers.save_pre.remove(save_pre)
    if load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(load_post)
