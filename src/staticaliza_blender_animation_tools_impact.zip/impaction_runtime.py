"""Preview drawing, marker synchronization, and cache invalidation."""

import bpy
import math
import sys
import time
from bpy.app.handlers import persistent

from .impaction_action import (
    impact_grid_frame, impact_grid_interval, marker_fcurves,
    rebuild_marker_exposure, salt_value,
)
from .impaction_discovery import camera_bone_binding, viewed_camera
from .impaction_renderer import draw_cached_image, warm_interactive_resources

_draw_handle = None
_animator_pixel_handle_token = None
_syncing = False
_propagating = False
_live_suspended = False
_rendering_live = False
_pending_live = {}
_pending_marker_cameras = set()
_marker_sync_deadline = 0.0
_marker_signatures = {}
_camera_view_signatures = {}
_camera_move_fade_until = {}
_camera_move_fade_timer_running = False
_deleted_records = {}
_gradient_signatures = {}
_exclusive_edit_pointer = None
_warmup_attempts = 0
_live_render_ema = 0.0
_LIVE_PREVIEW_RELEASE_FALLBACK = 0.22
_preview_release_deadline = 0.0
_preview_pointer_held = False
_preview_diagnostic_counts = {
    "scheduled_inputs": 0,
    "interactive_renders": 0,
    "full_release_renders": 0,
    "release_events": 0,
    "release_fallbacks": 0,
    "geometry_slices": 0,
}
_preview_last_render_seconds = 0.0
_preview_max_render_seconds = 0.0
_draw_priority_checked_at = 0.0
_fps_values = {}
_fps_layouts = {}
_interactive_selection_cache = {}
_shape_selection_salts = {}
_shape_selection_clear_pending = set()


def _fps_layout(camera):
    return tuple((int(record.salt), int(record.frame))
                 for record in camera.impaction_frames)


def fps_property_changed(camera):
    """Remember both marker layouts so native FPS undo/redo restores spacing."""
    name = camera.name_full
    current = int(camera.impaction_fps)
    previous = _fps_values.get(name)
    if previous is not None and previous != current:
        _fps_layouts[(name, previous)] = _fps_layout(camera)
    _fps_values[name] = current
    schedule_marker_sync(camera)


def _restore_fps_layout(camera):
    """Restore the record/marker positions belonging to the undone FPS."""
    name = camera.name_full
    current = int(camera.impaction_fps)
    previous = _fps_values.get(name)
    if previous is None:
        _fps_values[name] = current
        return False
    if previous == current:
        return False
    _fps_layouts[(name, previous)] = _fps_layout(camera)
    layout = _fps_layouts.get((name, current))
    _fps_values[name] = current
    if not layout:
        return False
    frames = {salt: frame for salt, frame in layout}
    from .impaction_renderer import retime_capture
    changed = False
    for record in camera.impaction_frames:
        target = frames.get(int(record.salt))
        if target is None or int(record.frame) == target:
            continue
        old_frame = int(record.frame)
        record.frame = target
        retime_capture(camera, record, old_frame)
        cancel_live_render(camera, record)
        changed = True
    if changed:
        armature, _bone = camera_bone_binding(camera)
        if armature is not None:
            rebuild_marker_exposure(armature, camera)
    return changed

_LIVE_PREVIEW_INTERVAL = 1.0 / 60.0
_LIVE_PREVIEW_MIN_QUALITY = 0.20
_LIVE_PREVIEW_INITIAL_QUALITY = 1.0
_LIVE_PREVIEW_SETTLE_MIN = 0.12
_LIVE_PREVIEW_SETTLE_MAX = 0.35
_INTERACTIVE_SELECTION_TTL = 0.05
_DELETED_RECORD_BUDGET = 64
_DELETED_RECORD_BYTE_BUDGET = 256 * 1024 * 1024
_DRAW_HANDLE_KEY = "staticaliza_blender_animation_tools_impact.draw_handle"
_TIMER_CALLBACKS_KEY = "staticaliza_blender_animation_tools_impact.timer_callbacks"
_LABEL_OCCLUSION_QUERY_KEY = (
    "staticaliza_blender_animation_tools.impact_hides_viewport_labels"
)


def _preview_quality_cap(scene):
    """Legacy manual value is retained in RNA; interaction is automatic."""
    return 1.0


def _adapt_preview_quality(state, gpu_seconds, geometry_seconds, target_fps, now):
    """Adapt real raster and geometric sampling to measured live workload."""
    quality = float(state.get("adaptive_quality", _LIVE_PREVIEW_INITIAL_QUALITY))
    # Reserve time for event dispatch, viewport presentation and redraw.
    budget = .55 / max(1.0, float(target_fps))
    samples = state.setdefault("quality_samples", [])
    samples.append(max(0.0, float(gpu_seconds)) + max(0.0, float(geometry_seconds)))
    del samples[:-3]
    if len(samples) < 2:
        return
    measured = sorted(samples)[len(samples)//2]
    # A single compilation, allocation or driver stall is not steady load.
    slow = all(value > budget * 1.08 for value in samples)
    healthy = measured < budget * .75
    recovered = int(state.get("stable_quality_frames", 0)) + 1 if healthy else 0
    state["stable_quality_frames"] = recovered
    if now - float(state.get("quality_changed_at", -1.e9)) < (.12 if slow else .6):
        return
    if slow:
        quality = max(_LIVE_PREVIEW_MIN_QUALITY, round(max(quality - .10, quality * (budget / max(measured, 1.e-6)) ** .5), 2))
    elif recovered >= 6:
        quality = min(1.0, round(quality + .05, 2))
    else:
        return
    if quality != state.get("adaptive_quality", _LIVE_PREVIEW_INITIAL_QUALITY):
        state["adaptive_quality"] = quality
        state["quality_changed_at"] = now
        state["stable_quality_frames"] = 0
        samples.clear()


def _warm_renderer_resources():
    """Idle-time GPU warmup; never captures or invalidates an Impact Frame."""
    global _warmup_attempts
    if _preview_pointer_held or _rendering_live or _pending_live:
        return 0.25
    try:
        if warm_interactive_resources():
            _warmup_attempts = 0
            return None
        return 0.05
    except (ReferenceError, RuntimeError, SystemError, TypeError):
        pass
    _warmup_attempts += 1
    return 0.5 if _warmup_attempts < 3 else None


def frame_record(camera, frame):
    if camera is None or not hasattr(camera, "impaction_frames"):
        return None
    return next((record for record in camera.impaction_frames if record.frame == int(frame)), None)


def grid_frame_record(scene, camera, frame):
    """Record occupying the grid slot nearest to the requested frame."""
    if camera is None or not getattr(camera, "impaction_frames", None):
        return None
    target = impact_grid_frame(scene, camera, frame, initialize=False)
    return frame_record(camera, target)


def held_frame_record(scene, camera, frame):
    """Record exposed from its key through one complete Impact interval."""
    if camera is None or not getattr(camera, "impaction_frames", None):
        return None
    current = int(frame)
    interval = impact_grid_interval(scene, camera)
    # Newer keys interrupt the preceding hold, including overlapping intervals.
    return max(
        (record for record in camera.impaction_frames
         if int(record.frame) <= current < int(record.frame) + interval),
        key=lambda record: int(record.frame), default=None,
    )


def request_redraw(camera=None):
    """Redraw every area that can display an Impact overlay.

    Preview and Audio deliberately keep an exact-fit presentation fallback:
    they can display the scene camera while RegionView3D is temporarily not
    in Blender's literal CAMERA state.  Treating only CAMERA regions as
    redraw targets left those workspaces showing the image from before an
    Update performed in Animate or Graph.
    """
    for area, viewed in _camera_viewport_areas():
        if camera is None or viewed == camera:
            area.tag_redraw()


_camera_mmb_gestures = set()


def _native_middle_button_down():
    try:
        import ctypes
        return bool(ctypes.windll.user32.GetAsyncKeyState(0x04) & 0x8000)
    except (AttributeError, OSError):
        return False


def begin_camera_navigation(context, event):
    """Start presentation fading from the viewport press, before native orbit."""
    if (event.type != "MIDDLEMOUSE" or event.value != "PRESS" or
            getattr(context.area, "type", None) != "VIEW_3D" or
            getattr(context.region, "type", None) != "WINDOW" or
            not getattr(context.space_data, "lock_camera", False)):
        return
    camera = getattr(context.space_data, "camera", None) or context.scene.camera
    if camera is None:
        return
    _camera_mmb_gestures.add(camera.name_full)
    _fade_camera_during_movement(camera)
    request_redraw(camera)


_navigation_fade_keymaps = []


class IMPACTION_OT_navigation_fade(bpy.types.Operator):
    """Observe zoom before native navigation consumes it; never capture input."""
    bl_idname = "impaction.navigation_fade"
    bl_label = "Impact Camera Navigation Fade"
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        space = context.space_data
        region_3d = getattr(space, "region_3d", None)
        if (getattr(context.area, "type", None) == "VIEW_3D" and
                getattr(context.region, "type", None) == "WINDOW" and
                getattr(space, "lock_camera", False) and
                getattr(region_3d, "view_perspective", "") == "CAMERA"):
            camera = getattr(space, "camera", None) or context.scene.camera
            if camera is not None and camera.impaction_frames:
                _fade_camera_during_movement(camera)
                request_redraw(camera)
        return {'PASS_THROUGH'}


def _register_navigation_fade():
    bpy.utils.register_class(IMPACTION_OT_navigation_fade)
    config = getattr(bpy.context.window_manager.keyconfigs, "addon", None)
    if config is None:
        return
    keymap = config.keymaps.new(name="3D View", space_type="VIEW_3D")
    for event_type in ("WHEELUPMOUSE", "WHEELDOWNMOUSE", "WHEELINMOUSE",
                       "WHEELOUTMOUSE", "TRACKPADZOOM", "MOUSEROTATE"):
        item = keymap.keymap_items.new("impaction.navigation_fade",
            event_type, "ANY", any=True, head=True)
        _navigation_fade_keymaps.append((keymap, item))


def _unregister_navigation_fade():
    for keymap, item in _navigation_fade_keymaps:
        keymap.keymap_items.remove(item)
    _navigation_fade_keymaps.clear()
    bpy.utils.unregister_class(IMPACTION_OT_navigation_fade)


def _camera_navigation_faded(camera, now=None):
    now = time.monotonic() if now is None else now
    if camera.name_full in _camera_mmb_gestures:
        if _native_middle_button_down():
            return True
        _camera_mmb_gestures.discard(camera.name_full)
        _camera_move_fade_until.pop(camera.name_full, None)
        return False
    return _camera_move_fade_until.get(camera.name_full, 0.) > now


def _camera_move_fade_tick():
    """Redraw until every transient camera-movement fade has restored."""
    global _camera_move_fade_timer_running
    now = time.monotonic()
    expired = [name for name, deadline in _camera_move_fade_until.items()
               if deadline <= now]
    for name in expired:
        _camera_move_fade_until.pop(name, None)
    request_redraw()
    if _camera_move_fade_until or _camera_mmb_gestures:
        if not _native_middle_button_down():
            for name in tuple(_camera_mmb_gestures):
                _camera_move_fade_until.pop(name, None)
            _camera_mmb_gestures.clear()
        else:
            return 0.05
    if _camera_move_fade_until:
        return 0.05
    _camera_move_fade_timer_running = False
    return None


def _fade_camera_during_movement(camera):
    global _camera_move_fade_timer_running
    area = getattr(bpy.context, "area", None)
    region = getattr(bpy.context, "region", None)
    if area is not None and (area.type != "VIEW_3D" or
            (region is not None and region.type != "WINDOW")):
        return
    # The depsgraph can report a native wheel/dolly after Blender has left
    # the event's WINDOW context. Its caller already verifies a changed camera
    # transform and a locked camera viewport; do not discard that movement.
    # Only latch a held MMB gesture when the originating region is known.
    if (getattr(bpy.context.area, "type", None) == "VIEW_3D" and
            getattr(bpy.context.region, "type", None) == "WINDOW" and
            _native_middle_button_down()):
        _camera_mmb_gestures.add(camera.name_full)
    _camera_move_fade_until[camera.name_full] = time.monotonic() + 0.25
    if not _camera_move_fade_timer_running:
        _camera_move_fade_timer_running = True
        if not bpy.app.timers.is_registered(_camera_move_fade_tick):
            bpy.app.timers.register(_camera_move_fade_tick, first_interval=0.05)


def acknowledge_camera_view(camera):
    """Accept an authored camera transform without presenting it as navigation."""
    if camera is None:
        return
    _camera_view_signatures[camera.name_full] = _camera_view_signature(camera)
    _camera_move_fade_until.pop(camera.name_full, None)
    request_redraw(camera)


def _presentation_workspace(workspace):
    """Return whether a workspace owns an exact-fit Impact presentation."""
    try:
        name = str(workspace.name).strip().casefold()
    except (AttributeError, ReferenceError, TypeError, ValueError):
        return False
    if name.rsplit(".", 1)[-1].isdigit():
        name = name.rsplit(".", 1)[0]
    return name in {"preview", "audio"}


def _area_display_camera(area, scene, *, presentation=False):
    """Resolve the camera that the draw handler may use in one VIEW_3D."""
    try:
        space = area.spaces.active
    except (AttributeError, ReferenceError, TypeError):
        return None
    region_3d = getattr(space, "region_3d", None)
    in_camera = bool(
        region_3d is not None
        and getattr(region_3d, "view_perspective", "") == "CAMERA"
    )
    if not in_camera and not presentation:
        return None
    camera = getattr(space, "camera", None) or getattr(scene, "camera", None)
    return camera if camera is not None and camera.type == "CAMERA" else None


def _camera_viewport_areas():
    """Yield (area, camera) pairs for every drawable Impact viewport."""
    window_manager = getattr(bpy.context, "window_manager", None)
    for window in getattr(window_manager, "windows", ()) if window_manager else ():
        screen = getattr(window, "screen", None)
        scene = getattr(window, "scene", None)
        if screen is None or scene is None:
            continue
        presentation = _presentation_workspace(
            getattr(window, "workspace", None)
        )
        for area in screen.areas:
            if area.type != "VIEW_3D":
                continue
            camera = _area_display_camera(
                area, scene, presentation=presentation,
            )
            if camera is not None:
                yield area, camera


def _camera_viewports():
    """Yield cameras currently displayed through a 3D View camera viewport."""
    for _area, camera in _camera_viewport_areas():
        yield camera


def _preview_display_active(camera=None):
    """True only while an enabled Impact preview is actually on screen."""
    scene = getattr(bpy.context, "scene", None)
    state = getattr(scene, "impaction", None) if scene else None
    if state is None or state.preview_opacity <= 0.0:
        return False
    return any(candidate == camera for candidate in _camera_viewports()) if camera else any(_camera_viewports())


def cancel_all_live_renders():
    """Stop queued GPU work and discard only transient (unapplied) previews."""
    states = tuple(_pending_live.values())
    _pending_live.clear()
    for state in states:
        camera, record = _live_state_record(state)
        if camera is not None and record is not None:
            try:
                from .impaction_renderer import clear_record_preview
                clear_record_preview(camera, record)
            except (ImportError, ReferenceError, RuntimeError):
                pass


def preview_mode_changed(_context=None):
    if not _preview_display_active():
        cancel_all_live_renders()
    else:
        _ensure_marker_polling()
    request_redraw()


def preview_quality_changed(context=None):
    """Discard reduced interactive surfaces and queue the visible frame."""
    context = context or bpy.context
    scene = getattr(context, "scene", None)
    camera = viewed_camera(context)
    if camera is None or not _preview_display_active(camera):
        request_redraw()
        return
    cancel_all_live_renders()
    record = (
        held_frame_record(scene, camera, scene.frame_current)
        if scene is not None and camera is not None else None
    )
    if camera is not None and record is not None:
        schedule_live_render(
            camera, record, input_change=False, reduced_quality=True,
        )
    request_redraw()


def _animator_utils_pixel_handle():
    """Find Animator Utils' POST_PIXEL handle without importing/reloading it."""
    for module_name, module in tuple(sys.modules.items()):
        if not module_name.endswith("staticaliza_blender_animation_tools.viewport.overlay_runtime"):
            continue
        state = getattr(module, "_state", None)
        if isinstance(state, dict):
            return state.get("handle_pixel")
    return None


def _raise_draw_handler_after_animator_labels():
    """Keep the opaque Impact replacement above Animator Utils HUD labels."""
    global _draw_handle, _animator_pixel_handle_token
    animator_handle = _animator_utils_pixel_handle()
    token = id(animator_handle) if animator_handle is not None else None
    if token is None:
        _animator_pixel_handle_token = None
        return
    if token == _animator_pixel_handle_token:
        return
    _animator_pixel_handle_token = token
    if _draw_handle is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_draw_handle, "WINDOW")
    _draw_handle = bpy.types.SpaceView3D.draw_handler_add(
        _draw, (), "WINDOW", "POST_PIXEL",
    )
    bpy.app.driver_namespace[_DRAW_HANDLE_KEY] = _draw_handle
    request_redraw()


def _deferred_draw_priority():
    _raise_draw_handler_after_animator_labels()
    return None


def animation_playing(context=None):
    context = context or bpy.context
    window_manager = getattr(context, "window_manager", None)
    return bool(window_manager and any(
        window.screen.is_animation_playing
        for window in window_manager.windows
        if getattr(window, "screen", None) is not None
    ))


def _transform_operator_active(context=None):
    context = context or bpy.context
    window_manager = getattr(context, "window_manager", None)
    for window in getattr(window_manager, "windows", ()) if window_manager else ():
        try:
            for operator in window.modal_operators:
                identifier = str(getattr(operator, "bl_idname", ""))
                if (identifier.upper().startswith("TRANSFORM_OT_")
                        or identifier.lower().startswith("transform.")):
                    return True
        except (AttributeError, ReferenceError, RuntimeError):
            continue
    return False


def selected_records(camera):
    armature, _bone = camera_bone_binding(camera) if camera else (None, "")
    curves = marker_fcurves(armature, camera) if armature else ()
    if not curves:
        if camera is not None:
            _interactive_selection_cache[camera.name_full] = (
                time.monotonic(), (),
            )
        return []
    selected_values = [
        point.co.y for curve in curves for point in curve.keyframe_points
        if getattr(point, "type", "") != "GENERATED"
        and (point.select_control_point or point.select_left_handle or point.select_right_handle)
    ]
    # FCurve Y values are stored as float32, so reconstructing the original
    # 31-bit salt can differ by dozens of integer units. Bucket in the same
    # tolerance space used by marker identity, then inspect adjacent buckets.
    tolerance = 1.0e-5
    bucket_scale = 1.0 / tolerance
    records_by_bucket = {}
    for record in camera.impaction_frames:
        bucket = int(math.floor(salt_value(record.salt) * bucket_scale))
        records_by_bucket.setdefault(bucket, []).append(record)
    result = []
    seen = set()
    for value in selected_values:
        bucket = int(math.floor(float(value) * bucket_scale))
        candidates = (
            record
            for candidate_bucket in (bucket - 1, bucket, bucket + 1)
            for record in records_by_bucket.get(candidate_bucket, ())
        )
        match = min(
            candidates,
            key=lambda item: abs(salt_value(item.salt) - float(value)),
            default=None,
        )
        pointer = match.as_pointer() if match is not None else None
        if (match is not None
                and abs(salt_value(match.salt) - value) < tolerance
                and pointer not in seen):
            seen.add(pointer)
            result.append(match)
    # The visible selected key owns the panel and operator source. FCurve
    # storage order is chronological, not Blender's active edit order.
    held=held_frame_record(bpy.context.scene,camera,bpy.context.scene.frame_current)
    if held is not None:
        held_pointer=held.as_pointer()
        result.sort(key=lambda item: item.as_pointer()!=held_pointer)
    _interactive_selection_cache[camera.name_full] = (
        time.monotonic(), tuple(int(record.salt) for record in result),
    )
    return result


def _flush_shape_selection_clears():
    names = tuple(_shape_selection_clear_pending)
    _shape_selection_clear_pending.clear()
    from .impaction_properties import clear_shape_selection
    for name in names:
        camera = bpy.data.cameras.get(name)
        # A deferred timer can outlive the Impact registration state or the
        # camera that queued it.  Plain Camera data-blocks do not own our RNA
        # collection, so never assume the property still exists here.
        if camera is None or not hasattr(camera, "impaction_frames"):
            continue
        for record in camera.impaction_frames:
            clear_shape_selection(record)
    if names:
        request_redraw()
    return None


def _clear_shapes_after_timeline_selection(camera, salts):
    salts = tuple(salts)
    previous = _shape_selection_salts.get(camera.name_full)
    if previous != salts:
        _shape_selection_salts[camera.name_full] = salts
        _shape_selection_clear_pending.add(camera.name_full)
        if not bpy.app.timers.is_registered(_flush_shape_selection_clears):
            bpy.app.timers.register(_flush_shape_selection_clears, first_interval=0.0)
    return salts


def _interactive_selected_salts(camera):
    """Reuse one native key-selection scan across draw/gizmo callbacks."""
    now = time.monotonic()
    cached = _interactive_selection_cache.get(camera.name_full)
    if cached is not None and now - float(cached[0]) <= _INTERACTIVE_SELECTION_TTL:
        return _clear_shapes_after_timeline_selection(camera, cached[1])
    return _clear_shapes_after_timeline_selection(
        camera, tuple(int(record.salt) for record in selected_records(camera)),
    )


def _record_owner(target):
    owner = getattr(target, "id_data", None)
    if (owner is not None and getattr(owner, "type", None) == "CAMERA"
            and hasattr(owner, "impaction_frames")):
        return owner
    pointer = target.as_pointer()
    for camera in (obj for obj in bpy.data.objects if obj.type == "CAMERA"):
        for record in getattr(camera, "impaction_frames", ()):
            if record.as_pointer() == pointer:
                return camera
    return None


def _live_state_record(state):
    """Resolve a queued preview without retaining invalid RNA references."""
    camera = bpy.data.objects.get(state["camera_name"])
    record = next(
        (item for item in getattr(camera, "impaction_frames", ())
         if int(item.salt) == int(state["salt"])),
        None,
    ) if camera else None
    return camera, record


def _live_state_is_visible(scene, state):
    """A held exposure is visible even when the playhead is after its key."""
    camera, record = _live_state_record(state)
    return (
        record is not None
        and held_frame_record(scene, camera, scene.frame_current) == record
    )


def _resolve_live_states(scene):
    """Resolve every queued key and visible exposure once per timer tick."""
    cameras = {}
    records_by_camera = {}
    visible_salts = {}
    resolved = {}
    for state in _pending_live.values():
        camera_name = state["camera_name"]
        if camera_name not in cameras:
            camera = bpy.data.objects.get(camera_name)
            cameras[camera_name] = camera
            records_by_camera[camera_name] = {
                int(record.salt): record
                for record in getattr(camera, "impaction_frames", ())
            } if camera is not None else {}
            held = held_frame_record(
                scene, camera, scene.frame_current,
            ) if camera is not None else None
            visible_salts[camera_name] = (
                int(held.salt) if held is not None else None
            )
        camera = cameras[camera_name]
        record = records_by_camera[camera_name].get(int(state["salt"]))
        resolved[state["key"]] = (
            camera, record,
            record is not None
            and int(record.salt) == visible_salts[camera_name],
        )
    return resolved


def _live_settle_interval():
    """Adapt only debounce/backpressure to measured hardware throughput."""
    measured = _live_render_ema * 1.5 if _live_render_ema > 0.0 else 0.0
    return max(
        _LIVE_PREVIEW_SETTLE_MIN,
        min(_LIVE_PREVIEW_SETTLE_MAX, measured),
    )


def _live_interactive_interval(camera=None):
    """Start-to-start cadence caps preview at the authored Impact FPS."""
    camera = camera or getattr(bpy.context.scene, "camera", None)
    return 1.0 / max(1.0, float(getattr(camera, "impaction_fps", 24.0)))


def _next_live_timer_delay(scene, resolved=None):
    if not _pending_live:
        return None
    now = time.monotonic()
    settle = _live_settle_interval()
    resolved = resolved if resolved is not None else _resolve_live_states(scene)
    delays = []
    for state in _pending_live.values():
        if state.get("awaiting_release", False):
            idle = now - float(state.get("last_input_at", now))
            if not _preview_pointer_held and idle >= _LIVE_PREVIEW_RELEASE_FALLBACK:
                # RNA updates can be dispatched from Blender's release event,
                # after the modal monitor had a chance to observe it. Never
                # leave that final update stranded at interactive resolution.
                _arm_full_quality_release(state, now)
                _preview_diagnostic_counts["release_fallbacks"] += 1
                delays.append(0.005)
                continue
            delays.append(0.005 if state.get("dirty", True) else 0.05)
            continue
        if resolved.get(state["key"], (None, None, False))[2]:
            if state.get("dirty", True):
                delays.append(max(
                    0.005,
                    float(state.get("next_render_at", 0.0)) - now,
                ))
            else:
                delays.append(max(
                    0.005,
                    settle - (now - float(state.get("last_input_at", now))),
                ))
        else:
            delays.append(max(
                0.01,
                settle - (now - float(state.get("last_input_at", now))),
            ))
    return min(0.05, min(delays, default=0.05))


def _native_primary_button_down():
    """Independent release evidence when a native slider consumes mouse-up."""
    if sys.platform != "win32":
        return None
    try:
        import ctypes
        user32 = ctypes.windll.user32
        # GetAsyncKeyState reports physical buttons, so honor swapped mapping.
        button = 2 if user32.GetSystemMetrics(23) else 1
        return bool(user32.GetAsyncKeyState(button) & 0x8000)
    except (AttributeError, OSError):
        return None


def _preview_release_watchdog():
    """Finalize reduced previews even when native UI swallows mouse release."""
    if (_preview_pointer_held and _exclusive_edit_pointer is None
            and _native_primary_button_down() is False):
        set_preview_pointer_held(False)
        release_reduced_live_previews()
    if not _pending_live:
        return None
    now = time.monotonic()
    awaiting = False
    released = False
    for state in _pending_live.values():
        if not state.get("awaiting_release", False):
            continue
        idle = now - float(state.get("last_input_at", now))
        if _preview_pointer_held or idle < _LIVE_PREVIEW_RELEASE_FALLBACK:
            awaiting = True
            continue
        _arm_full_quality_release(state, now)
        _preview_diagnostic_counts["release_fallbacks"] += 1
        released = True
    if released and not bpy.app.timers.is_registered(_render_pending_live):
        bpy.app.timers.register(_render_pending_live, first_interval=0.005)
    return 0.03 if awaiting else None


def _render_pending_live():
    global _rendering_live, _live_render_ema
    global _preview_last_render_seconds, _preview_max_render_seconds
    # Operators/scene evaluation may pump callbacks. Never enter another GPU
    # render while one is active or a bulk operation owns the renderer.
    if _rendering_live or _live_suspended:
        return 0.05
    context = bpy.context
    scene = getattr(context, "scene", None)
    if scene is None:
        return None
    if not _preview_display_active():
        cancel_all_live_renders()
        return None
    if animation_playing(context):
        # Playback only draws completed caches. Never evaluate geometry or
        # upload replacement images while Blender is trying to advance frames.
        return 0.12
    if not _pending_live:
        return None

    now = time.monotonic()
    resolved = _resolve_live_states(scene)
    active_by_camera = {}
    for state in tuple(_pending_live.values()):
        camera, record, _visible = resolved.get(
            state["key"], (None, None, False),
        )
        if state["camera_name"] not in active_by_camera:
            active_by_camera[state["camera_name"]] = bool(
                camera is not None and _preview_display_active(camera)
            )
        camera_active = active_by_camera[state["camera_name"]]
        if camera is None or record is None or not camera_active:
            cancel_live_render(camera, record)
            _pending_live.pop(state["key"], None)
            resolved.pop(state["key"], None)
    if not _pending_live:
        return None
    from .impaction_renderer import (
        cache_matches_record, clear_record_preview, has_cached_capture,
        preview_matches_record, promote_record_preview, render_record,
        begin_linear_preview, advance_linear_preview, _current_render_signature,
    )
    states = tuple(_pending_live.values())
    settle = _live_settle_interval()

    # A visible record owns the interactive budget. Hidden selected records
    # remain coalesced until input has gone quiet, then apply once each.
    candidates = {
        "visible_dirty": [],
        "visible_recapture_settled": [],
        "visible_settled": [],
        "hidden_settled": [],
    }
    for candidate in states:
        # Throttle from the last draw start, never from the last mouse
        # move: continuous input must not starve preview indefinitely.
        visible = resolved.get(candidate["key"], (None, None, False))[2]
        dirty = candidate.get("dirty", True)
        if (visible and dirty and not candidate.get("settle_only", False)
                and now >= float(candidate.get("next_render_at", 0.0))):
            candidates["visible_dirty"].append(candidate)
        elif (visible and dirty
                and not candidate.get("awaiting_release", False)
                and now - float(candidate.get("last_input_at", now)) >= settle):
            candidates["visible_recapture_settled"].append(candidate)
        elif (visible and not dirty
                and not candidate.get("awaiting_release", False)
                and now - float(candidate.get("last_input_at", now)) >= settle):
            candidates["visible_settled"].append(candidate)
        elif (not visible and dirty and not _preview_pointer_held
                and not candidate.get("awaiting_release", False)
                and now - float(candidate.get("last_input_at", now)) >= settle):
            candidates["hidden_settled"].append(candidate)
    state_kind = next(
        (kind for kind in (
            "visible_dirty", "visible_recapture_settled",
            "visible_settled", "hidden_settled",
        )
         if candidates[kind]),
        None,
    )
    state = candidates[state_kind][0] if state_kind is not None else None
    if state is None:
        return _next_live_timer_delay(scene, resolved)

    from . import impaction_renderer as renderer_state
    previous_exposure = renderer_state._exposure_frame_override
    original_frame = scene.frame_current
    original_subframe = scene.frame_subframe
    moved_frame = False
    _rendering_live = True
    cycle_started = now
    try:
        camera, record, _visible = resolved.get(
            state["key"], (None, None, False),
        )
        if state_kind == "hidden_settled" and record is not None:
            renderer_state._exposure_frame_override = int(record.frame)
        render_input = record
        rendered_signature = None
        geometry_quality = None
        if (record is not None and not state.get("shape_only",False) and not state.get("effects_only",False) and (state_kind == "visible_dirty" or (
                state_kind in {"hidden_settled", "visible_recapture_settled"}
                and has_cached_capture(camera, record)))
                and (bool(record.linear_enabled) or bool(record.get("_rig_profiles", "")))):
            job = state.get("geometry_job")
            exposure=(int(record.frame),renderer_state._held_motion_age(record,scene))
            if job is not None and state.get("geometry_exposure")!=exposure:
                state.pop("geometry_job",None)
                job=None
            # Finish held snapshots, but discard stale work immediately on release.
            if (job is not None and not state.get("reduced_quality", False)
                    and ((job.get("interactive", False) and float(job["interactive"]) < 1.) or
                         job["signature"] != _current_render_signature(record, scene))):
                state.pop("geometry_job", None)
                job = None
            if job is None or job["record"].frame != record.frame:
                job = state["geometry_job"] = begin_linear_preview(
                    context, camera, record, recapture=bool(state.get("recapture", False)),
                    interactive=(float(state.get("adaptive_quality", .65))
                                 if state.get("reduced_quality", False) else False),
                )
                state["geometry_exposure"] = exposure
                state["recapture"] = False
            _preview_diagnostic_counts["geometry_slices"] += 1
            # Blender services short app timers on UI ticks, not at their
            # requested 1 ms delay. Eight-ms chunks spent more time waiting
            # than computing. Use most of one authored frame period while
            # reserving time for input/display, without changing geometry.
            geometry_budget = min(.030, .70 / max(1., float(camera.impaction_fps)))
            slice_started = time.monotonic()
            # Same contact/path solver, with sampling precision tied to quality.
            completed = advance_linear_preview(job, budget=geometry_budget)
            state["last_geometry_slice"] = time.monotonic() - slice_started
            if not completed:
                if state.get("reduced_quality", False):
                    # Slow CPU work must drive adaptation even before any draw
                    # completes. Finish this snapshot; the next job uses the
                    # lower tier, avoiding perpetual restart/starvation.
                    _adapt_preview_quality(state, 0., job.get("work_seconds", 0.),
                                           camera.impaction_fps, time.monotonic())
                return .001
            else:
                state.pop("geometry_job", None)
                state["geometry_seconds"] = float(job.get("work_seconds", 0.0))
                if state.get("reduced_quality", False):
                    render_input = job["record"]
                    geometry_quality = float(job.get("interactive", 1.)) or 1.
                    rendered_signature = job["signature"]
                elif job["signature"] != _current_render_signature(record, scene):
                    return .001
        if record is None:
            _pending_live.pop(state["key"], None)
        elif state_kind == "visible_settled":
            if bool(state.get("last_render_reduced", False)):
                clear_record_preview(camera, record)
                render_record(
                    context, camera, record,
                    preview=True, apply_preview=True,
                    retain_gpu_preview=False, interactive_quality=False,
                    recapture=False,
                )
                state["last_render_reduced"] = False
                _pending_live.pop(state["key"], None)
            elif promote_record_preview(camera, record, scene) is not None:
                _pending_live.pop(state["key"], None)
            elif cache_matches_record(record, scene):
                _pending_live.pop(state["key"], None)
            else:
                # The transient was invalidated by a newer unserviced input.
                state["dirty"] = True
        else:
            if ((not has_cached_capture(camera, record))
                    and (scene.frame_current != record.frame or scene.frame_subframe)):
                scene.frame_set(record.frame)
                moved_frame = True
            try:
                if state_kind == "hidden_settled" and cache_matches_record(record, scene):
                    _pending_live.pop(state["key"], None)
                    return _next_live_timer_delay(scene, resolved)
                started = time.monotonic()
                state["last_render_started_at"] = cycle_started
                # Preserve cadence phase across coarse Blender UI ticks.
                # Restarting a 41.7 ms wait after each late tick rounds a
                # 24 FPS request down to 20 FPS on a 60 Hz event loop.
                interval = _live_interactive_interval(camera)
                planned = float(state.get("next_render_at", cycle_started))
                if planned <= 0. or cycle_started - planned > interval:
                    planned = cycle_started
                state["next_render_at"] = planned + interval
                visible = state_kind == "visible_dirty"
                rendered_reduced = bool(
                    visible and state.get("reduced_quality", False)
                )
                applying_release = bool(
                    visible and not rendered_reduced
                    and state.get("release_final", False)
                )
                render_record(
                    context, camera, render_input,
                    preview=True, apply_preview=(not visible or applying_release),
                    retain_gpu_preview=(visible and not applying_release),
                    interactive_quality=rendered_reduced,
                    interactive_scale=(
                        (geometry_quality if geometry_quality is not None else
                         float(state.get("adaptive_quality", 1.0)))
                        if rendered_reduced else None
                    ),
                    recapture=bool(state.get("recapture", False)),
                )
                state["recapture"] = False
                state["settle_only"] = False
                if rendered_reduced:
                    state["timing_samples"] = int(state.get("timing_samples", 0)) + 1
                    # Submission time alone hides GPU saturation. Sample actual
                    # completion at tier changes and on each completed adaptive update.
                    # One pixel avoids full-frame readback/packing during input.
                    tier = (state.get("adaptive_quality", 1.0),
                            float(record.chromatic_aberration) > 0.,
                            float(record.motion_blur) > 0.,
                            float(record.aberration_glitch) > 0.)
                    warming = state.get("timed_tier") != tier
                    renderer_state.synchronize_preview(camera, render_input)
                    state["timed_tier"] = tier
                    state["gpu_timing_sample"] = True
                    state["timing_warmup"] = warming and state.get("timing_samples", 0) <= 1
                    if not warming:
                        state["last_gpu_seconds"] = max(0., time.monotonic() - started)
                    if warming:
                        state["stable_quality_frames"] = 0
                elapsed = max(0.0, time.monotonic() - started)
                _preview_last_render_seconds = elapsed
                _preview_max_render_seconds = max(
                    _preview_max_render_seconds, elapsed,
                )
                if rendered_reduced:
                    _preview_diagnostic_counts["interactive_renders"] += 1
                geometry_seconds = float(state.pop("geometry_seconds", 0.0))
                if (rendered_reduced and state.get("gpu_timing_sample", False)
                        and (not state.get("timing_warmup", False) or state.get("quality_samples"))):
                    _adapt_preview_quality(state, time.monotonic() - cycle_started, geometry_seconds,
                                           camera.impaction_fps, time.monotonic())
                elif applying_release:
                    _preview_diagnostic_counts["full_release_renders"] += 1
                # Release restores full geometry sampling, pixels and optical
                # integration through the same rendering algorithms.
                _live_render_ema = (
                    elapsed if _live_render_ema <= 0.0
                    else _live_render_ema * 0.82 + elapsed * 0.18
                )
                if visible:
                    state["failures"] = 0
                    # An unfinished exact solve does not make the displayed
                    # current-input draft stale. Redrawing it consumes another
                    # frame budget without showing any new pin movement.
                    state["dirty"] = bool(
                        (rendered_signature is not None and
                         rendered_signature != _current_render_signature(record, scene))
                    )
                    state["last_render_at"] = time.monotonic()
                    state["last_render_reduced"] = rendered_reduced
                    if applying_release:
                        _pending_live.pop(state["key"], None)
                        return _next_live_timer_delay(scene, resolved)
                    # A click or isolated edit may already be quiet by the
                    # time the GPU completes. Promote that exact image now.
                    if ((not state["last_render_reduced"])
                            and time.monotonic() - float(state["last_input_at"])
                            >= _live_settle_interval()
                            and preview_matches_record(camera, record, scene)):
                        if promote_record_preview(camera, record, scene) is not None:
                            _pending_live.pop(state["key"], None)
                else:
                    if cache_matches_record(record, scene):
                        state["failures"] = 0
                        _pending_live.pop(state["key"], None)
                    else:
                        raise RuntimeError("applied preview did not become current")
            except Exception as error:
                state["failures"] = int(state.get("failures", 0)) + 1
                state["last_input_at"] = time.monotonic()
                state["dirty"] = True
                if state["failures"] >= 3:
                    _pending_live.pop(state["key"], None)
                print(f"Impaction live preview failed at frame {record.frame}: {error}")
    except Exception as error:
        # Geometry preparation is cooperative too; a failed slice must not
        # unregister the timer and leave a drag permanently pending.
        state.pop("geometry_job", None)
        state["failures"] = int(state.get("failures", 0)) + 1
        state["last_input_at"] = time.monotonic()
        state["dirty"] = True
        if state["failures"] >= 3:
            _pending_live.pop(state["key"], None)
        print(f"Impaction live preparation failed: {error}")
    finally:
        renderer_state._exposure_frame_override = previous_exposure
        if moved_frame:
            scene.frame_set(original_frame, subframe=original_subframe)
        _rendering_live = False
        request_redraw()
    return _next_live_timer_delay(scene, resolved)


def schedule_live_render(
    camera, record, *, input_change=False, recapture=False, settle_only=False,
    reduced_quality=False, shape_only=False, effects_only=False, monitor_pointer=True,
):
    if camera is None or record is None:
        return
    # Every editing family can adapt, starting at full project resolution.
    # Export and explicit recapture never inherit an interactive tier.
    if input_change and not recapture:
        reduced_quality = True
    if input_change:
        _preview_diagnostic_counts["scheduled_inputs"] += 1
        # Collection and node-tree edits do not emit an RNA property callback.
        # Keep signature invalidation at the scheduler authority boundary so a
        # newly rendered preview can never be stamped with an older signature.
        from .impaction_renderer import invalidate_record_signature
        invalidate_record_signature(record)
    if _live_suspended or not _preview_display_active(camera):
        return
    native_held = _native_primary_button_down() if input_change and reduced_quality else None
    if native_held is True:
        set_preview_pointer_held(True)
    key = (camera.name_full, int(record.salt))
    now = time.monotonic()
    state = _pending_live.get(key)
    if state is None:
        state = {
            "key": key,
            "camera_name": camera.name_full,
            "salt": int(record.salt),
            "frame": int(record.frame),
            "queued_at": now,
            "last_input_at": now,
            "last_render_at": 0.0,
            "dirty": True,
            "failures": 0,
            "recapture": bool(recapture),
            "settle_only": bool(settle_only),
            "reduced_quality": bool(reduced_quality),
            "shape_only": bool(shape_only),
            "effects_only": bool(effects_only),
            "awaiting_release": bool(input_change and reduced_quality),
            "last_render_reduced": False,
            "release_final": False,
            "adaptive_quality": _LIVE_PREVIEW_INITIAL_QUALITY,
            "interaction_started_at": now,
            "interaction_inputs": 0,
            "stable_quality_frames": 0,
        }
        _pending_live[key] = state
    else:
        state["frame"] = int(record.frame)
        if input_change:
            state["shape_only"] = bool(shape_only)
            state["effects_only"] = bool(effects_only)
        if input_change:
            state["queued_at"] = now
            state["last_input_at"] = now
            state["dirty"] = True
            state["failures"] = 0
        # Viewport recovery calls carry no input intent. They must not turn
        # an active drag into a full-quality apply or invalidate its snapshot.
        if input_change or reduced_quality:
            state["reduced_quality"] = bool(reduced_quality)
        if input_change and reduced_quality:
            state["awaiting_release"] = True
            state["release_final"] = False
        state["recapture"] = bool(state.get("recapture", False) or recapture)
        state["settle_only"] = bool(
            state.get("settle_only", False) or settle_only
        )
    if input_change and reduced_quality:
        state["interaction_inputs"] = int(state.get("interaction_inputs", 0)) + 1
    if input_change and not reduced_quality:
        if shape_only or effects_only:
            # Full-quality does not mean an applied image on every pointer
            # event. Keep the transient on the GPU, then promote when quiet.
            state["awaiting_release"] = False
            state["release_final"] = False
            state["settle_only"] = False
        else:
            # Discrete edits supersede a previous reduced drag, including its
            # release latch and partially prepared geometry.
            _arm_full_quality_release(state, now)
        state.pop("geometry_job", None)
    if not bpy.app.timers.is_registered(_render_pending_live):
        bpy.app.timers.register(_render_pending_live, first_interval=0.01)
    if input_change and reduced_quality:
        if not bpy.app.timers.is_registered(_preview_release_watchdog):
            bpy.app.timers.register(
                _preview_release_watchdog, first_interval=0.03,
            )
        # INVOKE_DEFAULT requires a real window/event context. Property setup,
        # file loading, and headless validation can legitimately queue a live
        # render without one; invoking here only logs an invalid-operator error
        # (and used to surface a relaunch error dialog). The watchdog remains
        # authoritative for those non-pointer updates.
        context = bpy.context
        if (
            monitor_pointer and native_held is not False and not bpy.app.background
            and _exclusive_edit_pointer is None
            and getattr(context, "window", None) is not None
            and getattr(context, "area", None) is not None
            and getattr(context, "region", None) is not None
        ):
            try:
                bpy.ops.impaction.preview_release_monitor("INVOKE_DEFAULT")
            except (AttributeError, RuntimeError):
                pass


def _arm_full_quality_release(state, now):
    """Turn one reduced interaction into one authoritative applied render."""
    state["awaiting_release"] = False
    state["reduced_quality"] = False
    state["release_final"] = True
    state["dirty"] = True
    state["last_input_at"] = now
    state["last_render_at"] = 0.0
    state["last_render_started_at"] = 0.0


def queue_final_live_render(camera, record):
    """Publish a release render after the native modal/undo operation returns."""
    schedule_live_render(camera, record, input_change=True, reduced_quality=False)
    state = _pending_live.get((camera.name_full, int(record.salt)))
    if state is not None:
        state["awaiting_release"] = False
        state["last_render_reduced"] = False
        state["release_final"] = True
        state["dirty"] = True


def set_preview_pointer_held(held):
    """Track native pointer ownership; idle time is never mouse release."""
    global _preview_pointer_held, _preview_release_deadline
    if held:
        _preview_release_deadline = 0.0
        if bpy.app.timers.is_registered(_finalize_preview_release):
            bpy.app.timers.unregister(_finalize_preview_release)
    if held and not _preview_pointer_held:
        for state in _pending_live.values():
            state["geometry_draft"] = False
            state["adaptive_quality"] = _LIVE_PREVIEW_INITIAL_QUALITY
            state["quality_samples"] = []
            state["stable_quality_frames"] = 0
            state.pop("timed_tier", None)
            state["interaction_started_at"] = time.monotonic()
            state["interaction_inputs"] = 0
    _preview_pointer_held = bool(held)


def _finalize_preview_release():
    """Run after Blender's trailing slider RNA callback for mouse release."""
    global _preview_release_deadline, _preview_pointer_held
    if _preview_pointer_held and _native_primary_button_down() is True:
        _preview_release_deadline = 0.0
        return None
    remaining = _preview_release_deadline - time.monotonic()
    if remaining > 0.0:
        return max(0.001, remaining)
    now = time.monotonic()
    # Recover a transient orphaned by a cancelled queue as well. Display
    # signatures intentionally omit quality; a matching GPU preview alone
    # must never prevent release/apply from producing project pixels.
    from . import impaction_renderer as renderer
    transient_keys=set(renderer._preview_surfaces)|set(renderer._preview_images)
    for camera_name,salt in transient_keys:
        if (camera_name,salt) in _pending_live:
            continue
        camera=bpy.data.objects.get(camera_name)
        if camera is None:continue
        record=next((r for r in camera.impaction_frames if int(r.salt)==salt),None)
        if record is not None and renderer.preview_matches_record(camera,record,bpy.context.scene):
            queue_final_live_render(camera,record)
    released = False
    for state in _pending_live.values():
        if not (
            state.get("awaiting_release", False)
            or state.get("reduced_quality", False)
            or state.get("last_render_reduced", False)
        ):
            continue
        _arm_full_quality_release(state, now)
        released = True
    _preview_release_deadline = 0.0
    _preview_pointer_held = False
    if released and not bpy.app.timers.is_registered(_render_pending_live):
        bpy.app.timers.register(_render_pending_live, first_interval=0.001)
    return None


def release_reduced_live_previews():
    """Commit full quality after the release event's final RNA update."""
    global _preview_release_deadline
    _preview_diagnostic_counts["release_events"] += 1
    _preview_release_deadline = time.monotonic() + 0.035
    if not bpy.app.timers.is_registered(_finalize_preview_release):
        bpy.app.timers.register(
            _finalize_preview_release, first_interval=0.035,
        )
    return any(
        state.get("awaiting_release", False)
        or state.get("reduced_quality", False)
        or state.get("last_render_reduced", False)
        for state in _pending_live.values()
    )


def preview_diagnostics():
    """Return a low-cost snapshot for the temporary isolated recorder."""
    try:
        from .impaction_renderer import surface_cache_stats
        cache_stats = surface_cache_stats()
    except (AttributeError, ImportError, ReferenceError, RuntimeError):
        cache_stats = {}
    return {
        **_preview_diagnostic_counts,
        "pending": len(_pending_live),
        "awaiting_release": sum(
            bool(state.get("awaiting_release", False))
            for state in _pending_live.values()
        ),
        "reduced": sum(
            bool(state.get("reduced_quality", False))
            or bool(state.get("last_render_reduced", False))
            for state in _pending_live.values()
        ),
        "release_final": sum(
            bool(state.get("release_final", False))
            for state in _pending_live.values()
        ),
        "pointer_held": bool(_preview_pointer_held),
        "adaptive_quality": [
            float(state.get("adaptive_quality", 1.0))
            for state in _pending_live.values()
        ],
        "render_ema_seconds": round(float(_live_render_ema), 6),
        "last_render_seconds": round(float(_preview_last_render_seconds), 6),
        "max_render_seconds": round(float(_preview_max_render_seconds), 6),
        "renderer_cache": cache_stats,
    }


def cancel_live_render(camera, record):
    if camera is not None and record is not None:
        _pending_live.pop((camera.name_full, int(record.salt)), None)
        try:
            from .impaction_renderer import clear_record_preview
            clear_record_preview(camera, record)
        except (ImportError, ReferenceError, RuntimeError):
            pass


def cancel_pending_live_render(camera, record):
    """Drop queued work without discarding an already promoted live image."""
    if camera is not None and record is not None:
        _pending_live.pop((camera.name_full, int(record.salt)), None)


def schedule_marker_sync(camera=None, immediate=False):
    """Defer FCurve writes until Blender releases any active key transform."""
    global _marker_sync_deadline
    if camera is not None:
        _pending_marker_cameras.add(camera.name_full)
    else:
        scene = getattr(bpy.context, "scene", None)
        for candidate in getattr(scene, "objects", ()) if scene else ():
            if candidate.type == "CAMERA" and getattr(candidate, "impaction_frames", None):
                _pending_marker_cameras.add(candidate.name_full)
    _marker_sync_deadline = time.monotonic() + (0.0 if immediate else 0.08)
    if not bpy.app.timers.is_registered(_sync_pending_markers):
        bpy.app.timers.register(_sync_pending_markers, first_interval=0.0 if immediate else 0.08)


def _sync_pending_markers():
    if not _pending_marker_cameras:
        return None
    if animation_playing() or _transform_operator_active():
        return 0.08
    remaining = _marker_sync_deadline - time.monotonic()
    if remaining > 0.0:
        return max(0.01, remaining)
    names = tuple(_pending_marker_cameras)
    _pending_marker_cameras.clear()
    for name in names:
        camera = bpy.data.objects.get(name)
        if camera is not None:
            sync_camera_markers(camera)
    return 0.01 if _pending_marker_cameras else None


def selected_property_records(camera, record):
    """Return the selected edit set only when it contains the source record."""
    if _exclusive_edit_pointer == record.as_pointer():
        # Modal viewport tools author one visible record while they run. This
        # also keeps nested shape callbacks (not just frame RNA callbacks)
        # frame-local for drag and doodle operations.
        return [record]
    targets = selected_records(camera)
    source_pointer = record.as_pointer()
    if any(target.as_pointer() == source_pointer for target in targets):
        return targets
    return [record]


_EFFECT_PREVIEW_PROPERTIES = frozenset({
    "bloom", "motion_blur", "chromatic_aberration", "aberration_glitch", "glitch_size",
    "grain", "grain_overlay_intensity", "halftone", "halftone_size", "pixelate", "pixelate_size",
    "contrast", "grayscale", "invert", "bloom_invert",
})


def _property_is_effect(property_name):
    return (property_name in _EFFECT_PREVIEW_PROPERTIES or
            str(property_name).startswith("aberration_"))


_REDUCED_PREVIEW_PROPERTIES = frozenset({
    # Direction/focus and generated line or hatch structure.
    "mode", "linear_enabled", "radial_enabled", "direction_focus",
    "direction_x", "direction_y", "direction_cast_behind", "halo_spread",
    "motion_curve_influence", "angle", "focus", "focus_x", "focus_y",
    "strength", "line_thickness", "radial_threshold", "radial_spiral",
    "band_transition", "background_intensity", "background_layer", "background_focus",
    "background_x", "background_y",
    "background_depth", "background_motion", "background_depth_2d",
    "background_flip_depth_2d", "background_shaped",
    # Lighting geometry/energy changes generated line illumination. Palette
    # selection and Custom color are deliberately full-resolution composite
    # edits: reducing the entire target while dragging a color made the live
    # preview visibly blurry even when the expensive mask was already cached.
    "light_focus", "light_x", "light_y", "light_radius",
    "light_cast_behind",
})


def _property_uses_reduced_preview(property_name):
    """Return whether an interactive edit needs a reduced line-work rebuild."""
    return True


def _property_values_equal(left, right):
    """Compare scalar and Blender vector RNA values without coercion noise."""
    if isinstance(left, str) or isinstance(right, str):
        return left == right
    try:
        left_values = tuple(left)
        right_values = tuple(right)
    except TypeError:
        try:
            return abs(float(left) - float(right)) <= 1.0e-7
        except (TypeError, ValueError):
            return left == right
    if len(left_values) != len(right_values):
        return False
    try:
        return all(
            abs(float(a) - float(b)) <= 1.0e-7
            for a, b in zip(left_values, right_values)
        )
    except (TypeError, ValueError):
        return left_values == right_values


def property_changed(record, context, property_name):
    global _propagating
    if _propagating:
        return
    if _live_suspended:
        try:
            from .impaction_renderer import invalidate_record_signature
            invalidate_record_signature(record)
        except (AttributeError, ImportError, ReferenceError, RuntimeError):
            pass
        return
    camera = _record_owner(record)
    if camera is None:
        return
    value = getattr(record, property_name)
    if property_name in {
        "strength", "line_thickness", "band_transition", "motion_blur", "contrast", "grayscale", "bloom", "chromatic_aberration", "aberration_glitch",
        "grain", "grain_overlay_intensity", "halftone", "pixelate",
        "light_radius", "bleed", "angle",
    }:
        if property_name == "angle":
            # Angle controls are intentionally unbounded while dragging and
            # typing. Store one canonical turn so 270 degrees becomes -90,
            # cache signatures stay stable, and crossing +/-180 flips the
            # authored axis instead of clamping against an artificial wall.
            degrees = math.degrees(float(value))
            normalized = (degrees + 180.0) % 360.0 - 180.0
            quantized = math.radians(round(normalized, 2))
        else:
            # Preserve the continuous onset of foreground controls. UI display
            # precision must not silently round a small authored value to zero.
            quantized = round(float(value), 6 if property_name in {"strength", "line_thickness"} else 2)
        if abs(float(value) - quantized) > 1.0e-7:
            _propagating = True
            try:
                setattr(record, property_name, quantized)
            finally:
                _propagating = False
        value = quantized
    from .impaction_properties import property_alias_context
    alias_name, alias_component = property_alias_context(record)
    if _exclusive_edit_pointer == record.as_pointer():
        targets = [record]
    else:
        targets = selected_property_records(camera, record)

    def target_already_matches(target):
        target_value = getattr(target, property_name)
        if alias_name and 0 <= alias_component < len(value):
            return _property_values_equal(
                target_value[alias_component], value[alias_component],
            )
        return _property_values_equal(target_value, value)

    # Blender may dispatch an RNA update when a slider is clicked and released
    # at its original value, or when the selected enum button is clicked again.
    # Such a confirmation must not invalidate line work or flash an interactive
    # resolution.  A cache match also covers moving away and returning exactly
    # to the already-applied value before release.
    try:
        from .impaction_renderer import fresh_display_match_kind
        match_kind = fresh_display_match_kind(camera, record, context.scene)
    except (AttributeError, ImportError, ReferenceError, RuntimeError):
        match_kind = None
    if match_kind and all(target_already_matches(target) for target in targets):
        if match_kind == "cache":
            cancel_live_render(camera, record)
        else:
            # A matching transient proves the VALUE, not applied quality.
            # Native sliders repeat their value on release (and while mouse
            # movement rounds to the same value). Never cancel its final job.
            still_dragging = (_preview_pointer_held and
                (_exclusive_edit_pointer is not None or
                 _native_primary_button_down() is not False))
            key = (camera.name_full, int(record.salt))
            if still_dragging:
                if key not in _pending_live:
                    schedule_live_render(camera,record,input_change=True,
                        reduced_quality=_property_uses_reduced_preview(property_name),
                        effects_only=_property_is_effect(property_name))
                    _pending_live[key]["dirty"] = False
                    _pending_live[key]["last_render_reduced"] = _property_uses_reduced_preview(property_name)
            else:
                queue_final_live_render(camera, record)
        request_redraw()
        return

    from .impaction_properties import clear_shape_selection
    for item in camera.impaction_frames:
        clear_shape_selection(item)
    _propagating = True
    try:
        from .impaction_renderer import invalidate_record_signature
        for target in targets:
            if target.as_pointer() != record.as_pointer():
                if alias_name and 0 <= alias_component < len(value):
                    target_value = list(getattr(target, property_name))
                    target_value[alias_component] = value[alias_component]
                    setattr(target, property_name, target_value)
                else:
                    setattr(target, property_name, value)
            if target.get('_rig_profiles',''):
                from .impaction_multirig import ensure
                ensure(target,camera,context.scene)
            invalidate_record_signature(target)
            if not _live_suspended:
                schedule_live_render(
                    camera, target, input_change=True,
                    # Numeric aliases may adapt too. Their nested RNA setter
                    # uses the release watchdog instead of invoking a modal.
                    monitor_pointer=not bool(alias_name),
                    reduced_quality=(target.as_pointer()==record.as_pointer() and _property_uses_reduced_preview(property_name)),
                    effects_only=_property_is_effect(property_name),
                )
    finally:
        _propagating = False
    request_redraw()


def suspend_live_render(enabled):
    global _live_suspended
    _live_suspended = bool(enabled)


def live_render_suspended():
    return _live_suspended


def set_exclusive_property_edit(record=None):
    """Limit modal viewport edits to one visible record, not all selected keys."""
    global _exclusive_edit_pointer, _exclusive_edit_salts
    if record is not None:
        camera=_record_owner(record)
        _exclusive_edit_salts=tuple(int(r.salt) for r in selected_records(camera)) if camera else ()
    _exclusive_edit_pointer = record.as_pointer() if record is not None else None


def commit_exclusive_property_edit(record, context, property_name):
    """Commit one finished modal value to hidden selected records.

    The source remains exclusive throughout modal motion and cancellation.  A
    successful operator settles the source image first, then calls this helper
    once so hidden records receive only the final canonical property value.
    """
    global _exclusive_edit_pointer, _exclusive_edit_salts, _propagating
    _exclusive_edit_pointer = None
    camera = _record_owner(record)
    if camera is None:
        return
    value = getattr(record, property_name)
    source_pointer = record.as_pointer()
    _propagating = True
    try:
        from .impaction_renderer import invalidate_record_signature
        selected_salts=set(globals().get('_exclusive_edit_salts',()))
        targets=([r for r in camera.impaction_frames if int(r.salt) in selected_salts]
                 if int(record.salt) in selected_salts else selected_property_records(camera,record))
        for target in targets:
            if target.as_pointer() == source_pointer:
                continue
            setattr(target, property_name, value)
            invalidate_record_signature(target)
            schedule_live_render(camera, target, input_change=True)
    finally:
        _propagating = False
        _exclusive_edit_salts = ()
    request_redraw(camera)


def _playing_or_previewing(context):
    return context.scene.impaction.preview_opacity > 0.0


def _display_camera(context):
    """Resolve the camera that owns the replacement image in this viewport."""
    camera = viewed_camera(context)
    if camera is not None:
        return camera
    from .impaction_renderer import _workspace_is_presentation
    if not _workspace_is_presentation(context):
        return None
    space = getattr(context, "space_data", None)
    camera = getattr(space, "camera", None) or getattr(context.scene, "camera", None)
    return camera if camera is not None and camera.type == "CAMERA" else None


def interactive_frame_record(context, camera=None):
    """Return the selected held record only in an interactive camera viewport."""
    record = displayed_frame_record(context, camera)
    if record is None:
        return None
    workspace = getattr(getattr(context, "window", None), "workspace", None)
    workspace_name = str(getattr(workspace, "name", "")).casefold()
    if workspace_name.startswith(("preview", "audio")):
        return None
    camera = viewed_camera(context)
    return record if int(record.salt) in _interactive_selected_salts(camera) else None


def displayed_frame_record(context, camera=None):
    """Return the held record only while its opaque camera overlay is visible."""
    if context is None or not _playing_or_previewing(context):
        return None
    viewed = _display_camera(context)
    if viewed is None or (camera is not None and viewed != camera):
        return None
    camera = viewed
    if camera_bone_binding(camera)[0] is None and not any(r.get("_rig_profiles", "") for r in camera.impaction_frames):
        return None
    held = held_frame_record(context.scene, camera, context.scene.frame_current)
    if held is None:
        return None
    from .impaction_renderer import display_image, display_surface
    return held if (
        display_surface(camera, held, prefer_preview=True) is not None
        or display_image(camera, held, prefer_preview=True) is not None
    ) else None


def impact_hides_viewport_labels(context=None):
    """Tell sibling UI modules when the Impact image owns the camera frame."""
    return displayed_frame_record(context or bpy.context) is not None


def interactive_radial_record(context, camera=None):
    """Return the selected radial record only while its image is interactive."""
    record = interactive_frame_record(context, camera)
    return record if (
        record is not None and bool(record.radial_enabled)
    ) else None


def interactive_light_record(context, camera=None):
    """Return the selected held record whose camera-space light can be dragged."""
    return interactive_frame_record(context, camera)


def interactive_direction_record(context, camera=None):
    """Return the selected record using the shared magenta field dragger."""
    return interactive_frame_record(context, camera)


def _draw():
    context = bpy.context
    if not context.area or context.area.type != "VIEW_3D" or not _playing_or_previewing(context):
        return
    camera = _display_camera(context)
    if camera is None or (camera_bone_binding(camera)[0] is None and not any(r.get("_rig_profiles", "") for r in camera.impaction_frames)):
        return
    playing = animation_playing(context)
    if not playing:
        _ensure_marker_polling()
    record = held_frame_record(context.scene, camera, context.scene.frame_current)
    if record is not None:
        # Install the RMB image guard per visible camera area, including every
        # workspace/window where the same current Impact frame is displayed.
        if not playing:
            from .impaction_operators import ensure_viewport_input_shield
            ensure_viewport_input_shield(context)
        opacity = max(0.0, min(1.0, context.scene.impaction.preview_opacity / 100.0))
        if _camera_navigation_faded(camera):
            opacity *= 0.5
        drawn = draw_cached_image(
            context, camera, record, opacity=opacity,
            prefer_preview=not playing,
        )
        if not playing:
            from .impaction_renderer import display_matches_record
            if not drawn or not display_matches_record(camera, record, context.scene):
                # Missing, invalid, stale-after-undo, and renderer-version-old
                # frames recover lazily. The queue deduplicates draw callbacks.
                schedule_live_render(camera, record)
        interactive = interactive_frame_record(context, camera) if not playing else None
        if interactive is not None:
            from .impaction_renderer import draw_camera_pin_overlays
            draw_camera_pin_overlays(context, camera, interactive)


_FRAME_PROPERTIES = (
    "mode", "linear_enabled", "radial_enabled",
    "direction_focus", "direction_cast_behind", "direction_seed_offset", "halo_spread",
    "motion_curve_influence",
    "angle", "focus",
    "strength", "line_thickness", "radial_threshold", "radial_spiral",
    "foreground", "background", "background_line_color",
    "background_intensity", "background_layer", "background_space",
    "background_2d_enabled", "background_3d_enabled", "background_focus",
    "background_depth", "background_motion", "background_depth_2d",
    "background_flip_depth_2d", "background_shaped", "invert",
    "band_transition", "motion_blur", "contrast", "grayscale", "bloom", "bloom_invert", "chromatic_aberration", "aberration_glitch", "glitch_size", "aberration_preset", "aberration_blur_smoothing",
    "aberration_color_a", "aberration_color_b", "grain",
    "grain_overlay_intensity", "halftone",
    "halftone_size", "pixelate", "pixelate_size",
    "light_focus", "light_radius", "bleed", "light_cast_behind",
    "light_color_source", "light_color",
)


def _clone_timeline_record(camera, source, frame):
    """Clone settings and completed pixels for a native Dope Sheet paste."""
    global _live_suspended
    from .impaction_renderer import duplicate_record_cache
    from .impaction_gradient import copy_aberration_ramp
    target = camera.impaction_frames.add()
    target.initialize(frame)
    previous = _live_suspended
    _live_suspended = True
    try:
        for name in _FRAME_PROPERTIES:
            value = getattr(source, name)
            setattr(target, name, tuple(value) if hasattr(value, "__len__") and not isinstance(value, str) else value)
    finally:
        _live_suspended = previous
    copy_aberration_ramp(source, target)
    from .impaction_operators import _shape_values, _replace_shapes
    _replace_shapes(target, [_shape_values(shape) for shape in source.shapes])
    from .impaction_multirig import clone_profiles
    clone_profiles(source, target)
    duplicate_record_cache(camera, source, target)
    return target


def _record_snapshot(camera, record):
    from .impaction_renderer import detach_record_cache
    from .impaction_gradient import ensure_aberration_ramp
    from .impaction_operators import _shape_values
    ensure_aberration_ramp(record)
    values = {}
    for name in _FRAME_PROPERTIES:
        value = getattr(record, name)
        values[name] = tuple(value) if hasattr(value, "__len__") and not isinstance(value, str) else value
    snapshot = {
        "salt": int(record.salt),
        "frame": int(record.frame),
        "values": values,
        "shapes": [_shape_values(shape) for shape in record.shapes],
        "ramp_name": str(record.aberration_ramp),
        "cache": detach_record_cache(camera, record),
    }
    snapshot["estimated_bytes"] = _deleted_snapshot_byte_weight(snapshot)
    return snapshot


def _deleted_snapshot_byte_weight(snapshot):
    """Estimate native Image/Mesh memory retained solely for timeline Undo."""
    cache = snapshot.get("cache") if snapshot else None
    total = 4096 + len(snapshot.get("shapes", ())) * 2048 if snapshot else 1
    image_name = cache[1] if cache else ""
    image = bpy.data.images.get(image_name) if image_name else None
    if image is not None:
        channels = max(1, int(getattr(image, "channels", 4)))
        component_bytes = 4 if bool(getattr(image, "is_float", True)) else 1
        total += int(image.size[0]) * int(image.size[1]) * channels * component_bytes
    capture_names = cache[4:6] if cache and len(cache) >= 6 else ()
    for name in capture_names:
        mesh = bpy.data.meshes.get(name) if name else None
        if mesh is not None:
            total += len(mesh.vertices) * 64
            total += len(mesh.loops) * 8
            total += len(mesh.polygons) * 32
    return max(1, int(total))


def _stash_deleted_record(camera, record):
    key = (camera.name_full, int(record.salt))
    old = _deleted_records.pop(key, None)
    if old is not None:
        _purge_snapshot(old)
    _deleted_records[key] = _record_snapshot(camera, record)
    total = sum(
        int(snapshot.get("estimated_bytes", 1))
        for snapshot in _deleted_records.values()
    )
    while (len(_deleted_records) > 1 and (
            len(_deleted_records) > _DELETED_RECORD_BUDGET
            or total > _DELETED_RECORD_BYTE_BUDGET)):
        oldest_key = next(iter(_deleted_records))
        oldest = _deleted_records.pop(oldest_key)
        total -= int(oldest.get("estimated_bytes", 1))
        _purge_snapshot(oldest)


def _purge_snapshot(snapshot):
    cache = snapshot.get("cache") if snapshot else None
    image_name = cache[1] if cache else ""
    image = bpy.data.images.get(image_name) if image_name else None
    active = any(
        record.cache_image == image_name
        for camera in (obj for obj in bpy.data.objects if obj.type == "CAMERA")
        for record in getattr(camera, "impaction_frames", ())
    )
    if image is not None and not active:
        image.use_fake_user = False
        if image.users == 0:
            bpy.data.images.remove(image)
    if cache and len(cache) >= 6:
        capture_names = cache[4:6]
    elif cache and len(cache) >= 5:
        capture_names = cache[3:5]
    else:
        capture_names = ()
    active_captures = {
        name
        for camera in (obj for obj in bpy.data.objects if obj.type == "CAMERA")
        for record in getattr(camera, "impaction_frames", ())
        for name in (record.capture_subject, record.capture_floor)
        if name
    }
    for name in capture_names:
        mesh = bpy.data.meshes.get(name) if name else None
        if mesh is not None and name not in active_captures:
            mesh.use_fake_user = False
            if mesh.users == 0:
                bpy.data.meshes.remove(mesh)
    ramp_name = snapshot.get("ramp_name", "") if snapshot else ""
    ramp = bpy.data.node_groups.get(ramp_name) if ramp_name else None
    ramp_active = any(
        record.aberration_ramp == ramp_name
        for camera in (obj for obj in bpy.data.objects if obj.type == "CAMERA")
        for record in getattr(camera, "impaction_frames", ())
    )
    if ramp is not None and not ramp_active:
        bpy.data.node_groups.remove(ramp)


def _deleted_snapshot(camera, value):
    return next(
        (snapshot for (camera_name, _salt), snapshot in _deleted_records.items()
         if camera_name == camera.name_full
         and abs(salt_value(snapshot["salt"]) - float(value)) <= 1.0e-5),
        None,
    )


def _restore_deleted_record(camera, snapshot, frame):
    global _live_suspended
    from .impaction_renderer import restore_record_cache
    target = camera.impaction_frames.add()
    previous = _live_suspended
    _live_suspended = True
    try:
        target.frame = int(frame)
        target.salt = int(snapshot["salt"])
        target.aberration_ramp = snapshot.get("ramp_name", "")
        for name, value in snapshot["values"].items():
            setattr(target, name, value)
        from .impaction_operators import _replace_shapes
        _replace_shapes(target, snapshot.get("shapes", ()))
    finally:
        _live_suspended = previous
    restore_record_cache(camera, target, snapshot["cache"])
    _deleted_records.pop((camera.name_full, int(snapshot["salt"])), None)
    return target


def _marker_signature(camera):
    armature, _bone = camera_bone_binding(camera)
    curves = marker_fcurves(armature, camera) if armature else ()
    if not curves:
        return ()
    return tuple(
        (curve.data_path, round(float(point.co.x), 4), round(float(point.co.y), 9),
         getattr(point, "type", ""))
        for curve in curves for point in curve.keyframe_points
    )


def _deselect_generated_tails(camera):
    armature, _bone = camera_bone_binding(camera)
    for curve in marker_fcurves(armature, camera) if armature else ():
        for point in curve.keyframe_points:
            if getattr(point, "type", "") == "GENERATED":
                point.select_control_point = False
                point.select_left_handle = False
                point.select_right_handle = False


def _actual_marker_count(signature):
    return sum(1 for item in signature if len(item) > 3 and item[3] != "GENERATED")


def _schedule_signature_change(camera, previous, current):
    """Delete immediately; debounce coordinate edits until transform release."""
    deleted = _actual_marker_count(current) < _actual_marker_count(previous)
    schedule_marker_sync(camera, immediate=deleted)


def remember_gradient_signatures(camera, records):
    """Mark deliberate ramp operations as observed by the polling bridge."""
    from .impaction_gradient import aberration_ramp_signature
    for record in records:
        _gradient_signatures[(camera.name_full, int(record.salt))] = (
            aberration_ramp_signature(record)
        )


def _gradient_changed_color_indices(previous, current):
    """Return logical stop indices changed by a direct color-picker edit."""
    if (previous is None or len(previous) < 5 or len(current) < 5
            or previous[:4] != current[:4]):
        return ()
    previous_stops, current_stops = previous[4], current[4]
    if (len(previous_stops) != len(current_stops)
            or any(old[0] != new[0]
                   for old, new in zip(previous_stops, current_stops))):
        return ()
    return tuple(
        index for index, (old, new) in enumerate(
            zip(previous_stops, current_stops)
        )
        if old[1] != new[1]
    )


def sync_aberration_ramp_edits(camera, records):
    """Propagate direct ramp-stop color edits by logical index."""
    from .impaction_gradient import (
        aberration_ramp_signature, set_aberration_color,
    )
    from .impaction_renderer import invalidate_record_signature

    unique_records = {
        record.as_pointer(): record for record in records if record is not None
    }
    changed_records = {}
    for record in tuple(unique_records.values()):
        key = (camera.name_full, int(record.salt))
        current = aberration_ramp_signature(record)
        previous = _gradient_signatures.get(key)
        _gradient_signatures[key] = current
        if previous is None or previous == current:
            continue
        changed_records[record.as_pointer()] = record
        indices = _gradient_changed_color_indices(previous, current)
        if not indices:
            continue
        source_pointer = record.as_pointer()
        for target in selected_property_records(camera, record):
            if target.as_pointer() == source_pointer:
                continue
            target_changed = False
            for index in indices:
                target_changed = set_aberration_color(
                    target, index, current[4][index][1],
                ) or target_changed
            if target_changed:
                changed_records[target.as_pointer()] = target
                _gradient_signatures[
                    (camera.name_full, int(target.salt))
                ] = aberration_ramp_signature(target)

    for record in changed_records.values():
        invalidate_record_signature(record)
        schedule_live_render(camera, record, input_change=True, effects_only=True)
    if changed_records:
        request_redraw(camera)
    return tuple(changed_records.values())


def _recover_visible_display(scene, camera):
    """Recover a lost/stale held image without a frame-change event."""
    if _rendering_live or _live_suspended or not _preview_display_active(camera):
        return False
    record=held_frame_record(scene,camera,scene.frame_current)
    if record is None:
        return False
    from .impaction_renderer import display_matches_record
    if display_matches_record(camera,record,scene):
        return False
    schedule_live_render(camera,record)
    request_redraw(camera)
    return True


def _poll_marker_changes():
    """Catch native copy/paste/delete operations that emit no reliable handler."""
    if not _preview_display_active():
        # A recurring Blender timer can contend with gizmo hover/hit-testing.
        # Stop it completely whenever no Impact preview is on screen.
        return None
    if animation_playing():
        # The draw handler restarts polling when playback stops. Avoid waking
        # a 20 Hz edit-state timer while Blender is advancing cached frames.
        return None
    if _rendering_live or _live_suspended:
        return 0.05
    if not _transform_operator_active():
        scene = getattr(bpy.context, "scene", None)
        for camera in (obj for obj in getattr(scene, "objects", ()) if obj.type == "CAMERA"):
            if not getattr(camera, "impaction_frames", None):
                continue
            _deselect_generated_tails(camera)
            signature = _marker_signature(camera)
            if camera.name_full not in _marker_signatures:
                _marker_signatures[camera.name_full] = signature
            elif _marker_signatures.get(camera.name_full) != signature:
                previous = _marker_signatures[camera.name_full]
                _marker_signatures[camera.name_full] = signature
                _schedule_signature_change(camera, previous, signature)
            visible = held_frame_record(
                scene, camera, scene.frame_current,
            ) if scene is not None else None
            gradient_records = selected_records(camera)
            if (visible is not None and not any(
                    record.as_pointer() == visible.as_pointer()
                    for record in gradient_records)):
                gradient_records.append(visible)
            if not _preview_pointer_held and not _rendering_live and not _live_suspended:
                from .impaction_multirig import sync_edit_record
                for edit_record in gradient_records:
                    if sync_edit_record(edit_record,camera,scene):
                        schedule_live_render(camera,edit_record)
                        request_redraw(camera)
            sync_aberration_ramp_edits(camera, gradient_records)
            _recover_visible_display(scene, camera)
    return 0.05


def _ensure_marker_polling():
    if (_preview_display_active()
            and not bpy.app.timers.is_registered(_poll_marker_changes)):
        bpy.app.timers.register(_poll_marker_changes, first_interval=0.05)


def sync_camera_markers(camera):
    global _syncing
    if _syncing:
        return
    armature, _bone = camera_bone_binding(camera)
    if armature is None and not any(record.get('_rig_profiles', '') for record in camera.impaction_frames):
        return
    curves = marker_fcurves(armature, camera)
    if not curves:
        # Deleting the complete Impact Frames channel removes every marker
        # FCurve in one operation. Treat the records and images as deleted too.
        for index in range(len(camera.impaction_frames) - 1, -1, -1):
            record = camera.impaction_frames[index]
            cancel_live_render(camera, record)
            _stash_deleted_record(camera, record)
            camera.impaction_frames.remove(index)
        camera.impaction_grid_initialized = False
        _marker_signatures[camera.name_full] = ()
        request_redraw()
        return
    _syncing = True
    try:
        records = list(camera.impaction_frames)
        unmatched = set(range(len(records)))
        used_frames = set()
        interval = impact_grid_interval(bpy.context.scene, camera)
        curve_changed = False
        invalid_points = []
        changed_curves = set()
        actual_points = [
            (curve, point) for curve in curves for point in curve.keyframe_points
            if getattr(point, "type", "") != "GENERATED"
        ]
        for owner_curve, point in actual_points:
            best = min(
                unmatched,
                key=lambda index: abs(salt_value(records[index].salt) - point.co.y),
                default=None,
            )
            if best is not None and abs(salt_value(records[best].salt) - point.co.y) <= 1.0e-5:
                record = records[best]
                unmatched.remove(best)
                snapshot = _deleted_records.get((camera.name_full, int(record.salt)))
                if snapshot is not None:
                    from .impaction_renderer import restore_record_cache
                    restore_record_cache(camera, record, snapshot["cache"])
                    _deleted_records.pop(
                        (camera.name_full, int(record.salt)), None,
                    )
            else:
                # Native Dope Sheet copy/paste duplicates only the FCurve point.
                # Recreate the extension record and clone its finished pixels.
                source = next(
                    (item for item in records if abs(salt_value(item.salt) - point.co.y) <= 1.0e-5),
                    None,
                )
                if source is None:
                    snapshot = _deleted_snapshot(camera, point.co.y)
                    if snapshot is None:
                        invalid_points.append((owner_curve, point))
                        continue
                    provisional = impact_grid_frame(bpy.context.scene, camera, point.co.x)
                    record = _restore_deleted_record(camera, snapshot, provisional)
                    records.append(record)
                else:
                    provisional = impact_grid_frame(bpy.context.scene, camera, point.co.x)
                    record = _clone_timeline_record(camera, source, provisional)
                    point.co.y = salt_value(record.salt)
                    curve_changed = True
                    changed_curves.add(owner_curve.as_pointer())
            moved_frame = impact_grid_frame(bpy.context.scene, camera, point.co.x)
            while moved_frame in used_frames:
                moved_frame += interval
            used_frames.add(moved_frame)
            if abs(point.co.x - moved_frame) > 0.0001:
                point.co.x = float(moved_frame)
                curve_changed = True
                changed_curves.add(owner_curve.as_pointer())
            if record.frame != moved_frame:
                from .impaction_renderer import retime_capture
                old_frame = int(record.frame)
                record.frame = moved_frame
                retime_capture(camera, record, old_frame)
                cancel_live_render(camera, record)
        for owner_curve, point in invalid_points:
            owner_curve.keyframe_points.remove(point, fast=True)
            curve_changed = True
            changed_curves.add(owner_curve.as_pointer())
        # Marker deletion removes its settings; records on another camera sharing
        # the owner armature are retained because their salts do not match.
        for index in sorted(unmatched, reverse=True):
            stale = records[index]
            _stash_deleted_record(camera, stale)
            collection_index = next(
                (i for i, item in enumerate(camera.impaction_frames) if item.as_pointer() == stale.as_pointer()),
                None,
            )
            if collection_index is not None:
                camera.impaction_frames.remove(collection_index)
        if curve_changed:
            for curve in curves:
                if curve.as_pointer() in changed_curves:
                    curve.update()
        rebuild_marker_exposure(armature, camera)
        _marker_signatures[camera.name_full] = _marker_signature(camera)
        if not camera.impaction_frames:
            camera.impaction_grid_initialized = False
    finally:
        _syncing = False


@persistent
def frame_change_post(scene, _depsgraph=None):
    if _rendering_live or _live_suspended:
        return
    _interactive_selection_cache.clear()
    from .impaction_properties import clear_shape_selection
    for camera in (obj for obj in scene.objects if obj.type == "CAMERA"):
        for record in getattr(camera, "impaction_frames", ()):
            clear_shape_selection(record)
    if not _preview_display_active():
        request_redraw()
        return
    if not animation_playing():
        from .impaction_renderer import cache_matches_record
        cameras = {camera.name_full: camera for camera in _camera_viewports()}
        for camera in cameras.values():
            record = held_frame_record(scene, camera, scene.frame_current)
            if record is not None and not cache_matches_record(record, scene):
                schedule_live_render(camera, record)
    request_redraw()


def _camera_view_signature(camera):
    try:
        return tuple(round(float(value), 7) for row in camera.matrix_world for value in row)
    except (AttributeError, ReferenceError, TypeError, ValueError):
        return ()


def _camera_locked_in_view(camera):
    window_manager = getattr(bpy.context, "window_manager", None)
    for window in tuple(getattr(window_manager, "windows", ())):
        screen = getattr(window, "screen", None)
        for area in tuple(getattr(screen, "areas", ())):
            if getattr(area, "type", "") != "VIEW_3D":
                continue
            for space in tuple(getattr(area, "spaces", ())):
                region_data = getattr(space, "region_3d", None)
                viewed = (
                    getattr(space, "camera", None)
                    or getattr(getattr(window, "scene", None), "camera", None)
                )
                if (
                    bool(getattr(space, "lock_camera", False))
                    and getattr(region_data, "view_perspective", "") == "CAMERA"
                    and viewed is camera
                ):
                    return True
    return False


@persistent
def depsgraph_update_post(scene, _depsgraph=None):
    from .impaction_multirig import scene_changed
    if not _syncing and not _rendering_live and not _live_suspended:
        scene_changed(scene)
    global _draw_priority_checked_at
    if not _preview_display_active():
        return
    if _syncing or _rendering_live or _live_suspended or animation_playing():
        return
    now = time.monotonic()
    if now - _draw_priority_checked_at >= 0.5:
        _draw_priority_checked_at = now
        _raise_draw_handler_after_animator_labels()
    for camera in (obj for obj in scene.objects if obj.type == "CAMERA"):
        if hasattr(camera, "impaction_frames") and camera.impaction_frames:
            view_signature = _camera_view_signature(camera)
            previous_view = _camera_view_signatures.get(camera.name_full)
            _camera_view_signatures[camera.name_full] = view_signature
            # Camera navigation only changes the live Blender view. A saved
            # Impact Frame is an authored snapshot, so the explicit Update
            # operator is the sole authority allowed to recapture it.
            if (
                previous_view is not None
                and previous_view != view_signature
                and _camera_locked_in_view(camera)
            ):
                _fade_camera_during_movement(camera)
                request_redraw()
            _deselect_generated_tails(camera)
            signature = _marker_signature(camera)
            if camera.name_full not in _marker_signatures:
                _marker_signatures[camera.name_full] = signature
            elif _marker_signatures[camera.name_full] != signature:
                previous = _marker_signatures[camera.name_full]
                _marker_signatures[camera.name_full] = signature
                _schedule_signature_change(camera, previous, signature)


@persistent
def undo_pre(_scene):
    global _preview_pointer_held, _preview_release_deadline, _exclusive_edit_pointer
    # Drop all generators/release jobs before Blender frees their backing data.
    _pending_live.clear()
    _interactive_selection_cache.clear()
    _preview_pointer_held=False;_preview_release_deadline=0.0
    _exclusive_edit_pointer=None
    from .impaction_renderer import collect_abandoned_previews
    for callback in (_render_pending_live,_preview_release_watchdog,collect_abandoned_previews):
        if bpy.app.timers.is_registered(callback):bpy.app.timers.unregister(callback)


@persistent
def undo_post(_scene):
    global _rendering_live, _preview_pointer_held, _preview_release_deadline
    from .impaction_renderer import (
        clear_transient_previews, invalidate_display_uploads, invalidate_undo_display,
        prepare_undo_display,
    )
    from .impaction_renderer import invalidate_history_geometry
    invalidate_history_geometry()
    from .impaction_renderer import schedule_preview_cleanup
    schedule_preview_cleanup()
    # Jobs and release latches describe the pre-undo RNA state.
    _pending_live.clear()
    _preview_pointer_held = False
    _preview_release_deadline = 0.0
    clear_transient_previews()
    invalidate_undo_display()
    if not bpy.app.timers.is_registered(prepare_undo_display):
        bpy.app.timers.register(prepare_undo_display, first_interval=0.0)
    # Undo can restore an older Image datablock name while Blender retains a
    # managed GPU handle for the newer pixels. Force the first returning frame
    # to upload its packed CPU pixels; otherwise that valid cache can display
    # as a full black rectangle until an explicit Update replaces it.
    invalidate_display_uploads()
    for camera in (obj for obj in bpy.data.objects if obj.type == "CAMERA"):
        # Image pixels are not RNA undo data. Mark every record stale so an
        # off-screen edited frame cannot later reuse post-undo pixels under a
        # restored pre-edit signature. The visible record is rebuilt below.
        for record in getattr(camera, "impaction_frames", ()):
            record.cache_signature = ""
        restored_fps = _restore_fps_layout(camera)
        armature, _bone = camera_bone_binding(camera)
        curves = marker_fcurves(armature, camera) if armature else ()
        has_snapshot = any(key[0] == camera.name_full for key in _deleted_records)
        if (not restored_fps and
                (getattr(camera, "impaction_frames", None) or curves or has_snapshot)):
            sync_camera_markers(camera)
    # Blender restores RNA values during undo/redo, but GPU-generated pixels
    # are not undo data. Never render synchronously inside Blender's undo
    # handler: nested GPU/RNA work there makes rapid property undo unreliable.
    # Queue the restored visible record for the next safe main-loop timer.
    context = bpy.context
    camera = viewed_camera(context)
    scene = getattr(context, "scene", None)
    record = (
        held_frame_record(scene, camera, scene.frame_current)
        if scene is not None and camera is not None else None
    )
    if record is not None:
        key = (camera.name_full, int(record.salt))
        from .impaction_renderer import display_matches_record
        if not display_matches_record(camera, record, scene):
            schedule_live_render(camera, record, input_change=True)
        state = _pending_live.get(key)
        if state is not None:
            state["last_render_at"] = 0.0
    request_redraw()


@persistent
def redo_post(_scene):
    undo_post(_scene)


@persistent
def save_pre(_dummy):
    # Applied previews are already packed. Reconcile once more at the save
    # boundary and discard any abandoned extension preview from older builds.
    try:
        from .impaction_renderer import pack_record_images
        pack_record_images()
    except (AttributeError, ImportError, ReferenceError, RuntimeError, TypeError):
        pass


@persistent
def load_post(_dummy):
    global _live_render_ema, _camera_move_fade_timer_running
    _pending_live.clear()
    _pending_marker_cameras.clear()
    _marker_signatures.clear()
    _camera_view_signatures.clear()
    _camera_move_fade_until.clear()
    _camera_mmb_gestures.clear()
    _camera_move_fade_timer_running = False
    _gradient_signatures.clear()
    _deleted_records.clear()
    _fps_values.clear()
    _fps_layouts.clear()
    _interactive_selection_cache.clear()
    _live_render_ema = 0.0
    from .impaction_renderer import clear_session_caches, schedule_preview_cleanup
    clear_session_caches()
    schedule_preview_cleanup()
    # During extension registration Blender exposes _RestrictData, which
    # intentionally has no .objects collection. The real load_post handler
    # will initialize signatures once normal file data is available.
    try:
        objects = bpy.data.objects
    except (AttributeError, RuntimeError):
        return
    # v0.1.50 normalized the three effects from 0..100 to 0..1. Preserve the
    # visual strength of records saved by older extension builds.
    for owner in objects:
        for record in getattr(owner, "impaction_frames", ()):
            if "background_line_color" not in record:
                record["background_line_color"] = tuple(record.foreground)
            # 0.3.27 removes the legacy 2D/3D selector. Every composition now
            # consumes the camera-space direction field.
            if "direction_source" in record:
                del record["direction_source"]
            if "direction_cast_behind" not in record:
                record["direction_cast_behind"] = False
            # An absent legacy value is not an authored None frame. Match the
            # explicit Linear initialization used by every newly created key.
            if "mode" not in record:
                record["mode"] = "LINEAR"
            if "linear_enabled" not in record and "radial_enabled" not in record:
                legacy_mode = str(record.mode)
                record["linear_enabled"] = legacy_mode == "LINEAR"
                record["radial_enabled"] = legacy_mode == "RADIAL"
            # Migrate the former Background Space controls.  Version 1 briefly
            # allowed both layers; version 2 restores one exclusive None/2D/3D
            # choice.  Prefer 3D when both were stored because that combined
            # state was normally created by enabling 3D over the default 2D.
            background_modes_version = int(getattr(
                record, "background_modes_version", 0,
            ))
            if background_modes_version < 1:
                legacy_background = str(getattr(
                    record, "background_space", "2D",
                ))
                record["background_2d_enabled"] = legacy_background != "3D"
                record["background_3d_enabled"] = legacy_background == "3D"
            if background_modes_version < 2:
                if (bool(getattr(record, "background_2d_enabled", True)) and
                        bool(getattr(record, "background_3d_enabled", False))):
                    record["background_2d_enabled"] = False
                record["background_modes_version"] = 2
            if "background_focus" not in record:
                record["background_focus"] = (0.625, 0.5)
            # 0.2.1 replaces the ambiguous Paper light preset with explicit
            # Foreground/Background choices. The former Paper preset was the
            # automatic paper endpoint, which is now named Background.
            if record.get("light_color_source") == "PAPER":
                record["light_color_source"] = "BACKGROUND"
            # 0.3.63 replaces the source chooser with one direct color box.
            # Resolve the old endpoint selection once, then use Custom from
            # here onward so saved appearances survive the UI simplification.
            legacy_light_source = str(record.light_color_source)
            if legacy_light_source != "CUSTOM":
                record.light_color = (
                    tuple(record.foreground) if legacy_light_source == "FOREGROUND"
                    else tuple(record.background)
                )
                record.light_color_source = "CUSTOM"
            # v0.1.87 initializes a never-edited Custom ramp as red/cyan when
            # the user first switches modes. Preserve any authored ramp from
            # older files, including a deliberate single-color setup.
            if "aberration_custom_initialized" not in record:
                from .impaction_gradient import aberration_colors
                colors = aberration_colors(record)
                default_unedited = (
                    len(colors) == 1 and
                    all(abs(colors[0][index] - expected) < 1.0e-5
                        for index, expected in enumerate((1.0, 0.0, 0.0, 1.0)))
                )
                record["aberration_custom_initialized"] = not default_unedited
            # v0.1.84 split the former endpoint-swapping Invert into Flip and
            # redefined Invert as a final-frame photographic negative. Migrate
            # old records without changing their saved appearance.
            if int(getattr(record, "color_semantics_version", 0)) < 2:
                record["flip"] = bool(record.invert)
                record["invert"] = False
                record["color_semantics_version"] = 2
            # 0.3.80 simplifies Band to one 0..1 strength. The old negative
            # half only phase-shifted the same material erosion, so preserve
            # its authored strength rather than clamping legacy files to Off.
            if int(getattr(record, "band_semantics_version", 0)) < 1:
                legacy_band = float(record.get(
                    "band_transition", getattr(record, "band_transition", 0.0),
                ))
                record["band_transition"] = min(1.0, abs(legacy_band))
                record["band_semantics_version"] = 1
            # 0.3.81 materializes Flip into the two stored color values so the
            # UI boxes truthfully show the active endpoints. Preserve the old
            # rendered appearance exactly once when loading older records.
            if int(getattr(record, "flip_semantics_version", 0)) < 1:
                if bool(record.flip):
                    foreground = tuple(record.foreground)
                    background = tuple(record.background)
                    record["foreground"] = background
                    record["background"] = foreground
                record["flip_semantics_version"] = 1
            # 0.3.88 turns Flip into a stateless action. The two materialized
            # color values already represent the visible palette, so retire
            # the legacy toggle without replaying another swap.
            if int(getattr(record, "flip_semantics_version", 0)) < 2:
                record["flip"] = False
                record["flip_semantics_version"] = 2
            # 0.3.59 adds independent Burst end shaping. Older blend files do
            # not own this RNA value yet; initialize it without disturbing
            # any authored Star dimensions.
            for shape in record.shapes:
                if "burst_end" not in shape:
                    shape["burst_end"] = 0.0
                if "effect_influence" not in shape:
                    shape["effect_influence"] = 0.5
            for property_name in ("bloom", "chromatic_aberration", "aberration_glitch", "grain"):
                value = float(getattr(record, property_name, 0.0))
                if value > 1.0:
                    setattr(record, property_name, min(1.0, value / 100.0))
            image = bpy.data.images.get(record.cache_image) if record.cache_image else None
            if image is None:
                record.cache_valid = False
            elif record.cache_valid:
                image.use_fake_user = True
            for name in (record.capture_subject, record.capture_floor):
                mesh = bpy.data.meshes.get(name) if name else None
                if mesh is not None:
                    mesh.use_fake_user = True
    for camera in (obj for obj in objects if obj.type == "CAMERA"):
        if getattr(camera, "impaction_frames", None):
            _marker_signatures[camera.name_full] = _marker_signature(camera)
            _camera_view_signatures[camera.name_full] = _camera_view_signature(camera)
    # Registration calls load_post too, so upgrading an existing session also
    # clears the single orphan dirty preview left by earlier extension builds.
    try:
        from .impaction_renderer import pack_record_images
        pack_record_images()
    except (AttributeError, ImportError, ReferenceError, RuntimeError, TypeError):
        pass


def register_runtime():
    _register_navigation_fade()
    bpy.app.driver_namespace["impaction_begin_camera_navigation"] = begin_camera_navigation
    global _draw_handle
    from .impaction_renderer import collect_abandoned_previews, schedule_preview_cleanup
    stale_handle = bpy.app.driver_namespace.pop(_DRAW_HANDLE_KEY, None)
    if stale_handle is not None and stale_handle is not _draw_handle:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(stale_handle, "WINDOW")
        except (ReferenceError, RuntimeError, ValueError):
            pass
    stale_timers = bpy.app.driver_namespace.pop(_TIMER_CALLBACKS_KEY, ())
    for callback in stale_timers:
        try:
            if bpy.app.timers.is_registered(callback):
                bpy.app.timers.unregister(callback)
        except (ReferenceError, RuntimeError, ValueError):
            pass
    if _draw_handle is None:
        _draw_handle = bpy.types.SpaceView3D.draw_handler_add(_draw, (), "WINDOW", "POST_PIXEL")
    bpy.app.driver_namespace[_DRAW_HANDLE_KEY] = _draw_handle
    bpy.app.driver_namespace[_LABEL_OCCLUSION_QUERY_KEY] = (
        impact_hides_viewport_labels
    )
    bpy.app.driver_namespace[_TIMER_CALLBACKS_KEY] = (
        _render_pending_live, _deferred_draw_priority, _sync_pending_markers,
        _poll_marker_changes, _warm_renderer_resources,
        _flush_shape_selection_clears, _camera_move_fade_tick,
        _preview_release_watchdog, _finalize_preview_release,
        collect_abandoned_previews,
    )
    schedule_preview_cleanup()
    if frame_change_post not in bpy.app.handlers.frame_change_post:
        bpy.app.handlers.frame_change_post.append(frame_change_post)
    if depsgraph_update_post not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(depsgraph_update_post)
    for handlers in (bpy.app.handlers.undo_pre,bpy.app.handlers.redo_pre):
        if undo_pre not in handlers:handlers.append(undo_pre)
    if undo_post not in bpy.app.handlers.undo_post:
        bpy.app.handlers.undo_post.append(undo_post)
    if redo_post not in bpy.app.handlers.redo_post:
        bpy.app.handlers.redo_post.append(redo_post)
    if save_pre not in bpy.app.handlers.save_pre:
        bpy.app.handlers.save_pre.append(save_pre)
    if load_post not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(load_post)
    load_post(None)
    if not bpy.app.timers.is_registered(_deferred_draw_priority):
        bpy.app.timers.register(_deferred_draw_priority, first_interval=0.25)
    if not bpy.app.background and not bpy.app.timers.is_registered(
        _warm_renderer_resources
    ):
        bpy.app.timers.register(_warm_renderer_resources, first_interval=0.35)


def unregister_runtime():
    _unregister_navigation_fade()
    bpy.app.driver_namespace.pop("impaction_begin_camera_navigation", None)
    from .impaction_renderer import collect_abandoned_previews
    if bpy.app.timers.is_registered(collect_abandoned_previews):
        bpy.app.timers.unregister(collect_abandoned_previews)
    global _draw_handle, _animator_pixel_handle_token, _exclusive_edit_pointer
    global _warmup_attempts, _live_render_ema, _draw_priority_checked_at
    global _camera_move_fade_timer_running
    global _preview_release_deadline, _preview_pointer_held
    global _preview_last_render_seconds, _preview_max_render_seconds
    _pending_live.clear()
    _pending_marker_cameras.clear()
    _marker_signatures.clear()
    _camera_view_signatures.clear()
    _camera_move_fade_until.clear()
    _camera_mmb_gestures.clear()
    _camera_move_fade_timer_running = False
    _gradient_signatures.clear()
    _exclusive_edit_pointer = None
    _warmup_attempts = 0
    _live_render_ema = 0.0
    _preview_release_deadline = 0.0
    _preview_pointer_held = False
    _preview_last_render_seconds = 0.0
    _preview_max_render_seconds = 0.0
    for name in _preview_diagnostic_counts:
        _preview_diagnostic_counts[name] = 0
    _draw_priority_checked_at = 0.0
    _fps_values.clear()
    _fps_layouts.clear()
    _interactive_selection_cache.clear()
    _shape_selection_clear_pending.clear()
    for snapshot in tuple(_deleted_records.values()):
        _purge_snapshot(snapshot)
    _deleted_records.clear()
    if bpy.app.timers.is_registered(_render_pending_live):
        bpy.app.timers.unregister(_render_pending_live)
    if bpy.app.timers.is_registered(_deferred_draw_priority):
        bpy.app.timers.unregister(_deferred_draw_priority)
    if bpy.app.timers.is_registered(_sync_pending_markers):
        bpy.app.timers.unregister(_sync_pending_markers)
    if bpy.app.timers.is_registered(_poll_marker_changes):
        bpy.app.timers.unregister(_poll_marker_changes)
    if bpy.app.timers.is_registered(_warm_renderer_resources):
        bpy.app.timers.unregister(_warm_renderer_resources)
    if bpy.app.timers.is_registered(_flush_shape_selection_clears):
        bpy.app.timers.unregister(_flush_shape_selection_clears)
    if bpy.app.timers.is_registered(_camera_move_fade_tick):
        bpy.app.timers.unregister(_camera_move_fade_tick)
    if bpy.app.timers.is_registered(_preview_release_watchdog):
        bpy.app.timers.unregister(_preview_release_watchdog)
    if bpy.app.timers.is_registered(_finalize_preview_release):
        bpy.app.timers.unregister(_finalize_preview_release)
    if _draw_handle is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(_draw_handle, "WINDOW")
        except (ReferenceError, RuntimeError, ValueError):
            # Blender can invalidate the capsule first while replacing or
            # shutting down an extension. Treat that null native handle as
            # already removed instead of crashing unregister/reload.
            pass
        _draw_handle = None
    bpy.app.driver_namespace.pop(_DRAW_HANDLE_KEY, None)
    bpy.app.driver_namespace.pop(_TIMER_CALLBACKS_KEY, None)
    if (
        bpy.app.driver_namespace.get(_LABEL_OCCLUSION_QUERY_KEY)
        is impact_hides_viewport_labels
    ):
        bpy.app.driver_namespace.pop(_LABEL_OCCLUSION_QUERY_KEY, None)
    _animator_pixel_handle_token = None
    if frame_change_post in bpy.app.handlers.frame_change_post:
        bpy.app.handlers.frame_change_post.remove(frame_change_post)
    if depsgraph_update_post in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(depsgraph_update_post)
    for handlers in (bpy.app.handlers.undo_pre,bpy.app.handlers.redo_pre):
        if undo_pre in handlers:handlers.remove(undo_pre)
    if undo_post in bpy.app.handlers.undo_post:
        bpy.app.handlers.undo_post.remove(undo_post)
    if redo_post in bpy.app.handlers.redo_post:
        bpy.app.handlers.redo_post.remove(redo_post)
    if save_pre in bpy.app.handlers.save_pre:
        bpy.app.handlers.save_pre.remove(save_pre)
    if load_post in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(load_post)
