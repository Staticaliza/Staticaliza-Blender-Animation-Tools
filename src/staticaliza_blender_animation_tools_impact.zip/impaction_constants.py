"""Stable identifiers for Roblox Animator Impact."""

ADDON_ID = "staticaliza_blender_animation_tools_impact"
ADDON_VERSION = (1, 0, 0)
ADDON_VERSION_TEXT = ".".join(map(str, ADDON_VERSION))

STATICALIZA_CAMERA_BONE = "Staticaliza Camera Bone"
STATICALIZA_CAMERA_OWNER_SESSION_UID = "Staticaliza Camera Owner Session UID"
STATICALIZA_CAMERA_OWNER = "Staticaliza Camera Owner"
STATICALIZA_CAMERA_OWNER_UID = "Staticaliza Camera Bone Owner UID"
STATICALIZA_CAMERA_OWNER_NAME = "Staticaliza Camera Bone Owner Name"

MARKER_PROPERTY = "impaction_marker"
MARKER_GROUP = "Impact Frames"
MARKER_HOST = "Impact Frames"
CACHE_PREFIX = ".Impaction Cache - "

SUBJECT = "SUBJECT"
FLOOR = "FLOOR"
