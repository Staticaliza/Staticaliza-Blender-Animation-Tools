"""Depth-bearing Linear paths. No screen-space center-pin special case.

This stage owns centerlines only; brush deposition remains in the renderer.
All work operates on detached capture arrays on Blender's main thread.
"""
from dataclasses import dataclass
import math

import numpy as np
from mathutils import Vector, Matrix
from mathutils.bvhtree import BVHTree
from .impaction_spatial import nearby_pairs, owner_indices


@dataclass
class SurfaceStroke:
    owner: int
    group: int
    seed: float
    root_fraction: float
    points: list
    width: float


def dome_direction(focus, center, aspect, behind, projection):
    """Travel away from the emitting pin on the selected 3D hemisphere."""
    # Stored coordinates are an orbit control, not an image-space light.
    # Camera framing/aspect must not change a group's casting direction.
    x = (float(focus[0]) - 0.5) * 2.0
    y = (float(focus[1]) - 0.5) * 2.0
    radius = math.hypot(x, y)
    if radius > 1.0:
        x, y = x / radius, y / radius
    z = math.sqrt(max(0.0, 1.0 - min(1.0, radius) ** 2))
    # Projection rows provide camera right/up; their cross is camera forward's
    # opposite. Use the actual capture camera, not the currently selected view.
    right = Vector(projection[0][:3]).normalized()
    up = Vector(projection[1][:3]).normalized()
    toward_camera = right.cross(up).normalized()
    # The switch selects the emitting PIN hemisphere, not the trail's.
    # A front pin has positive camera-depth; pin-to-center travel negates
    # all three components. A rear pin reverses only that source depth.
    return (-right*x - up*y + toward_camera*(z if behind else -z)).normalized()



def _unit(value, fallback):
    return value.normalized() if value.length_squared > 1e-14 else fallback.copy()


def _mesh_packets(geometry):
    iterator = iter_mesh_packets(geometry)
    while True:
        try:
            next(iterator)
        except StopIteration as done:
            return done.value


def iter_mesh_packets(geometry):
    cached = getattr(geometry, "_linear_mesh_packets", None)
    if cached is not None:
        return cached
    if len(geometry.world_positions) != len(geometry.positions):
        raise ValueError("Linear surface drawing requires a fresh world-space capture")
    vertices = np.asarray(geometry.world_positions, dtype=np.float64)
    owners = np.asarray(geometry.owner_ids, dtype=np.int32)
    triangles = np.asarray(geometry.triangles, dtype=np.int32).reshape((-1, 3))
    packets = []
    vertex_groups = owner_indices(owners)
    face_groups = owner_indices(owners[triangles[:, 0]])
    remap = np.full(len(vertices), -1, dtype=np.int32)
    for owner, indices in vertex_groups.items():
        remap[indices] = np.arange(len(indices))
        faces = remap[triangles[face_groups.get(owner, np.empty(0, dtype=int))]]
        points = vertices[indices]
        if not len(faces):
            continue
        group = int(geometry.spread_group_ids[indices[0]]) if geometry.spread_group_ids else int(owner)
        # An owner may contain disconnected bone-driven islands. Split by
        # topology first, then rejoin only spatially neighbouring islands.
        parents = list(range(len(points)))
        def find(index):
            while parents[index] != index:
                parents[index] = parents[parents[index]]
                index = parents[index]
            return index
        for face_index, (a, b, c) in enumerate(faces):
            root = find(int(a))
            parents[find(int(b))] = root
            parents[find(int(c))] = root
            if face_index % 2048 == 2047:
                yield None
        components = {}
        for face_index, face in enumerate(faces):
            components.setdefault(find(int(face[0])), []).append(face)
            if face_index % 2048 == 2047:
                yield None
        remap_local = np.full(len(points), -1, dtype=np.int32)
        for component in components.values():
            component = np.asarray(component, dtype=np.int32)
            used = np.unique(component)
            remap_local[used] = np.arange(len(used))
            island_points, island_faces = points[used], remap_local[component]
            bvh = BVHTree.FromPolygons(island_points.tolist(), island_faces.tolist(), all_triangles=True)
            packets.append((int(owner), group, island_points, island_faces, bvh))
            yield None
    parents = list(range(len(packets)))
    def root(index):
        while parents[index] != index:
            parents[index] = parents[parents[index]]
            index = parents[index]
        return index
    bounds = [(p[2].min(0), p[2].max(0)) for p in packets]
    radii = [max(1.e-5, float(np.linalg.norm(hi-lo))*.025) for lo, hi in bounds]
    for i, j in nearby_pairs([b[0] for b in bounds], [b[1] for b in bounds], radii):
        packet = packets[i]
        lo, hi = bounds[i]
        other_lo, other_hi = bounds[j]
        gap = np.linalg.norm(np.maximum(np.maximum(lo-other_hi, other_lo-hi), 0.))
        tolerance = min(radii[i], radii[j])
        if gap>tolerance:
            continue
        # Broad-phase rejection preserves the exact touching-surface test.
        if packet[4].overlap(packets[j][4]) or _packet_gap(packet,packets[j],tolerance):
            parents[root(i)] = root(j)
        yield None
    group_ids = {}
    packets = [(owner, group_ids.setdefault(root(i), len(group_ids)+1), points, faces, bvh)
               for i, (owner, _group, points, faces, bvh) in enumerate(packets)]
    # CPU-only immutable geometry follows the existing bounded capture cache.
    geometry._linear_mesh_packets = packets
    return packets


def _packet_gap(first, second, tolerance):
    """Conservative narrow-phase contact check for near-closed mesh seams."""
    for source,target in ((first,second),(second,first)):
        points,faces=source[2],source[3]
        # Vertices catch corners; face centroids catch face-to-face closures.
        # Bound work for detailed meshes; overlap handles intersecting faces.
        probes=np.concatenate((points[::max(1,len(points)//64)],
            points[faces[::max(1,len(faces)//64)]].mean(axis=1)))
        for probe in probes:
            hit=target[4].find_nearest(Vector(probe),tolerance)
            if hit[0] is not None and hit[3]<=tolerance:
                return True
    return False


def _section(points, faces, direction, plane):
    """Triangle-plane intersection; includes every side, with no facing cull."""
    signed = points @ np.asarray(direction) - plane
    selected = faces[(signed[faces].min(axis=1) < 0) & (signed[faces].max(axis=1) >= 0)]
    segments = []
    for triangle in selected:
        hits = []
        for a, b in ((triangle[0], triangle[1]), (triangle[1], triangle[2]), (triangle[2], triangle[0])):
            if (signed[a] < 0) != (signed[b] < 0):
                t = signed[a] / (signed[a] - signed[b])
                hits.append(Vector(points[a] + t*(points[b]-points[a])))
        if len(hits) == 2 and (hits[1]-hits[0]).length > 1e-7:
            segments.append((hits[0], hits[1], (hits[1]-hits[0]).length))
    return segments


def build_paths(geometry, focus, behind, aspect, spread, salt):
    """Same surface integrator for side, diagonal and dome-pole directions."""
    if not geometry.positions:
        return []
    screen = np.asarray(geometry.positions)
    center = (screen[:, :2].min(axis=0) + screen[:, :2].max(axis=0)) * .5
    direction = dome_direction(focus, center, aspect, behind, geometry.view_projection)
    result = []
    for owner, group, points, faces, bvh in _mesh_packets(geometry):
        along = points @ np.asarray(direction)
        lo, hi = float(along.min()), float(along.max())
        span = hi-lo
        if span < 1e-7:
            continue
        sections = _section(points, faces, direction, (lo+hi)*.5)
        perimeter = sum(s[2] for s in sections)
        diagonal = float(np.linalg.norm(points.max(axis=0)-points.min(axis=0)))
        # Sample the complete section by arc length rather than triangle count.
        # Paired sides have equal density even with asymmetric triangulation.
        count = min(240, max(24, int(perimeter/max(diagonal*.032, 1e-7))))
        if not sections:
            continue
        cursor, consumed = 0, 0.0
        for i in range(count):
            target = (i+.5)*perimeter/count
            while cursor+1 < len(sections) and consumed+sections[cursor][2] < target:
                consumed += sections[cursor][2]
                cursor += 1
            a, b, length = sections[cursor]
            root = a.lerp(b, (target-consumed)/length)
            seed = float((int(salt) % 65521) + owner*173 + i*1.61803398875)
            # Equal statistics under orientation flips, bounded to half-span.
            fraction = .5 + .055*math.sin(i*2.3999632297 + owner*.71)
            shifted = root + direction*((fraction-.5)*span)
            hit, normal, _, _ = bvh.find_nearest(shifted)
            if hit is None:
                continue
            root = hit
            actual_fraction = (root.dot(direction)-lo)/span
            step = max(span/28.0, diagonal/120.0)
            epsilon = diagonal*1e-5
            path = [root + normal*epsilon]
            point = root.copy()
            tangent = _unit(direction-normal*direction.dot(normal), direction)
            # Follow the actual local surface until its downstream edge. Never
            # substitute the group's rectangular projected bounding envelope.
            for _ in range(48):
                if (point.dot(direction)-lo)/span >= .985 or normal.dot(direction) > .72:
                    break
                field = _unit(direction-normal*direction.dot(normal), tangent)
                mid, mid_n, _, _ = bvh.find_nearest(point + field*(step*.5))
                if mid is None:
                    break
                field = _unit(direction-mid_n*direction.dot(mid_n), field)
                candidate, new_n, _, _ = bvh.find_nearest(point+field*step)
                if candidate is None or (candidate-point).length < step*.08:
                    break
                point, normal, tangent = candidate, new_n, field
                path.append(point+normal*epsilon)
            # A bounded smooth release gives one bend, not oscillatory waves.
            reach = diagonal*(.5 + max(0.0, spread)*1.6)*(.35+.65*(.5+.5*math.sin(i*1.713)))
            start = path[-1]
            outward = _unit(tangent + normal*.7, direction)
            for j in range(1, 25):
                t = j/24.0
                # Integrate an exponentially relaxing tangent. Unlike
                # t*(1-t), its sideways travel never reverses near the tail.
                relaxed = (1.0-math.exp(-3.0*t))/3.0
                displacement = direction*(t-relaxed) + outward*relaxed
                path.append(start + displacement*reach)
            width = .65 + .65*(.5+.5*math.sin(i*.83 + owner))
            result.append(SurfaceStroke(owner, group, seed, actual_fraction, path, width))
    return result


def ribbon_arrays(strokes, projection, width, height, thickness):
    """Project every point's real depth, then expand only the brush footprint."""
    matrix = np.asarray(projection, dtype=np.float64)
    positions, coordinates, parameters, depths, triangles = [], [], [], [], []
    depth_axis = matrix[2, :3] / np.linalg.norm(matrix[2, :3])
    for stroke in strokes:
        world = np.asarray([tuple(p) for p in stroke.points])
        clip = np.column_stack((world, np.ones(len(world)))) @ matrix.T
        if np.any(clip[:, 3] <= 1e-7):
            continue
        ndc = clip[:, :3]/clip[:, 3:4]
        uv = ndc[:, :2]*.5+.5
        pixel = uv*np.array((width, height))
        lengths = np.linalg.norm(np.diff(pixel, axis=0), axis=1)
        distance = np.concatenate(([0.0], np.cumsum(lengths)))
        if distance[-1] < 2.0:
            continue
        tangents = np.gradient(pixel, axis=0)
        normal = np.column_stack((-tangents[:, 1], tangents[:, 0]))
        normal /= np.maximum(np.linalg.norm(normal, axis=1)[:, None], 1e-6)
        half_width = min(width, height)*(.0018+.0045*thickness)*stroke.width
        base = len(positions)
        for i in range(len(pixel)):
            for sign in (-1, 1):
                edge = uv[i] + normal[i]*sign*half_width*2.2/np.array((width, height))
                positions.append(((edge[0]*2-1)*clip[i, 3], (edge[1]*2-1)*clip[i, 3], clip[i, 2], clip[i, 3]))
                depths.append(float(world[i] @ depth_axis))
                coordinates.append((distance[i]/distance[-1], sign*2.2))
                parameters.append((half_width, stroke.seed, float(stroke.owner), 1.0/distance[-1]))
        for i in range(len(pixel)-1):
            a = base+i*2
            triangles.extend(((a, a+1, a+2), (a+1, a+3, a+2)))
    return dict(clipPosition=positions, strokeUV=coordinates, strokeParams=parameters, linearDepth=depths), triangles
