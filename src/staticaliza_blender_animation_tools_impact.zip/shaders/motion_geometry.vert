in vec3 position;
in vec2 velocity;
in vec2 acceleration;

out vec2 vVelocity;
out vec2 vAcceleration;

void main()
{
    vVelocity = velocity;
    vAcceleration = acceleration;
    gl_Position = vec4(position.xy * 2.0 - 1.0, position.z, 1.0);
}
