uniform sampler2D impactTex;
uniform vec2 resolution;

in vec2 uv;
out vec4 fragColor;

void main()
{
    vec2 px = 1.0 / max(resolution, vec2(1.0));
    vec4 centerData = texture(impactTex, uv);
    float center = centerData.r;
    float north = texture(impactTex, uv + vec2(0.0, px.y)).r;
    float south = texture(impactTex, uv - vec2(0.0, px.y)).r;
    float east = texture(impactTex, uv + vec2(px.x, 0.0)).r;
    float west = texture(impactTex, uv - vec2(px.x, 0.0)).r;
    float northEast = texture(impactTex, uv + px).r;
    float northWest = texture(impactTex, uv + vec2(-px.x, px.y)).r;
    float southEast = texture(impactTex, uv + vec2(px.x, -px.y)).r;
    float southWest = texture(impactTex, uv - px).r;

    float minimumInk = min(center, min(min(north, south), min(east, west)));
    float maximumInk = max(center, max(max(north, south), max(east, west)));
    float localRange = maximumInk - minimumInk;
    float crossSum = north + south + east + west;
    float diagonalSum = northEast + northWest + southEast + southWest;
    float gaussianMean = (center * 4.0 + crossSum * 2.0 + diagonalSum) / 16.0;

    // Resolve only high-contrast one-pixel coverage. Broad pigment, paper,
    // tonal channels, and deterministic brush placement remain exact. This
    // removes staircase/dot quantization without blurring the full image.
    float edgeGate = smoothstep(0.10, 0.82, localRange);
    float isolated = smoothstep(0.10, 0.58, abs(center - gaussianMean));
    float resolveWeight = edgeGate * mix(0.28, 0.62, isolated);
    float resolvedInk = mix(center, gaussianMean, resolveWeight);
    fragColor = vec4(clamp(resolvedInk, 0.0, 1.0), centerData.gba);
}
