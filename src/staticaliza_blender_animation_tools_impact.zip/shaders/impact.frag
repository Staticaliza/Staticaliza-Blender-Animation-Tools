uniform sampler2D subjectTex;
uniform sampler2D floorTex;
uniform sampler2D brushTex;
uniform sampler2D motionTex;
uniform sampler2D backgroundMotionTex;
uniform vec2 resolution;
uniform int mode;
uniform int layerOnly;
uniform int hybridMode;
uniform float angle;
uniform vec2 focus;
uniform float strength;
uniform float lineThickness;
uniform vec2 subjectMotion;
uniform vec2 backgroundMotion;
uniform vec2 subjectAcceleration;
uniform float salt;
uniform float velocityScale;
uniform float motionCurveInfluence;
uniform float backgroundIntensity;
uniform float backgroundMotionInfluence;
uniform float bandTransition;
uniform float radialThreshold;
uniform float radialSpiral;
uniform float contrast;
uniform float lightIntensity;
// 2D: xy is a unit tangent and w=0. 3D: xy is the projected wind-source
// position, z selects the front/rear hemisphere, and w=1.
uniform vec4 flowSource;
uniform float haloSpread;
uniform vec4 subjectBounds;
uniform vec4 backgroundAffineX;
uniform vec4 backgroundAffineY;

in vec2 uv;
out vec4 fragColor;

/*
 * The line image is synthesized in screen space.  Geometry contributes tone,
 * depth ownership, lighting and motion, but never acts as a hard drawing clip.
 * Analytic gesture trajectories sample a cached deterministic bristle atlas.
 * This replaces the old polar cells, hatch rows, shifted silhouettes, and
 * independently truncated procedural segments.
 */

float hash21(vec2 p)
{
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float valueNoise(vec2 p, float seed)
{
    vec2 cell = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    vec2 s = vec2(seed * 0.071, seed * 0.113);
    float a = hash21(cell + s);
    float b = hash21(cell + vec2(1.0, 0.0) + s);
    float c = hash21(cell + vec2(0.0, 1.0) + s);
    float d = hash21(cell + vec2(1.0, 1.0) + s);
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float sourceMask(vec2 p)
{
    return max(texture(subjectTex, p).r, texture(floorTex, p).r);
}

float sourceCoverage(vec2 p)
{
    // Derivative-aware reconstruction of the binary geometry raster. The
    // transition exists only on pixels whose quad crosses a boundary, giving
    // sub-pixel coverage without additional texture reads or a blur pass.
    float center = sourceMask(p);
    float filterWidth = clamp(fwidth(center) * 0.62, 0.02, 0.62);
    return smoothstep(0.5 - filterWidth, 0.5 + filterWidth, center);
}

float internalSeamSupport(vec2 p)
{
    // A bevel/material split can leave a narrow zero-ownership channel even
    // though captured subject exists on both sides. Bridge only bilateral
    // gaps: a real outer silhouette has ownership on one side and stays open.
    vec2 px = 1.0 / max(resolution, vec2(1.0));
    float horizontal = max(
        min(sourceMask(p - vec2(px.x * 3.0, 0.0)),
            sourceMask(p + vec2(px.x * 3.0, 0.0))),
        max(min(sourceMask(p - vec2(px.x * 7.0, 0.0)),
                sourceMask(p + vec2(px.x * 7.0, 0.0))),
            min(sourceMask(p - vec2(px.x * 12.0, 0.0)),
                sourceMask(p + vec2(px.x * 12.0, 0.0)))));
    float vertical = max(
        min(sourceMask(p - vec2(0.0, px.y * 3.0)),
            sourceMask(p + vec2(0.0, px.y * 3.0))),
        max(min(sourceMask(p - vec2(0.0, px.y * 7.0)),
                sourceMask(p + vec2(0.0, px.y * 7.0))),
            min(sourceMask(p - vec2(0.0, px.y * 12.0)),
                sourceMask(p + vec2(0.0, px.y * 12.0)))));
    vec2 diagonal = px * 8.0;
    float corners = max(
        min(sourceMask(p - diagonal), sourceMask(p + diagonal)),
        min(sourceMask(p - vec2(diagonal.x, -diagonal.y)),
            sourceMask(p + vec2(diagonal.x, -diagonal.y))));
    return smoothstep(0.08, 0.64, max(max(horizontal, vertical), corners));
}

float sourceTone(vec2 p)
{
    vec4 subject = texture(subjectTex, p);
    vec4 floorData = texture(floorTex, p);
    float selected = step(floorData.r, subject.r);
    float tone = mix(floorData.g * floorData.r,
                     subject.g * subject.r, selected);
    float factor = 1.0 + clamp(contrast, 0.0, 1.0) * 3.0;
    return clamp((tone - 0.5) * factor + 0.5, 0.0, 1.0);
}

float keyLightField(vec2 p)
{
    vec4 subject = texture(subjectTex, p);
    vec4 floorData = texture(floorTex, p);
    float selected = step(floorData.r, subject.r);
    return clamp(mix(floorData.g, subject.g, selected), 0.0, 1.0);
}

vec2 sourceMaskAndKey(vec2 p)
{
    vec4 subject = texture(subjectTex, p);
    vec4 floorData = texture(floorTex, p);
    float selected = step(floorData.r, subject.r);
    return vec2(max(subject.r, floorData.r),
        clamp(mix(floorData.g, subject.g, selected), 0.0, 1.0));
}

float toneFromMaskAndKey(vec2 state)
{
    float factor = 1.0 + clamp(contrast, 0.0, 1.0) * 3.0;
    float tone = state.y * state.x;
    return clamp((tone - 0.5) * factor + 0.5, 0.0, 1.0);
}

// Most hero gestures should be loaded from the rear/shadow drawing mass. Two
// low-discrepancy candidates are compared in captured light space; a smaller
// minority keeps the original sample so the result remains asymmetric rather
// than collapsing into one uniformly dark launch edge.
vec4 shadowBiasedSeed(vec2 candidate, float selector, out float role,
                      out vec2 localMotion, out vec2 localNormal)
{
    vec2 boundsSpan = max(subjectBounds.zw - subjectBounds.xy, vec2(1.0e-5));
    vec2 alternate = subjectBounds.xy + boundsSpan * fract(
        (candidate - subjectBounds.xy) / boundsSpan +
        vec2(0.381966011, 0.618033989));
    vec4 subjectA = texture(subjectTex, candidate);
    vec4 floorA = texture(floorTex, candidate);
    vec4 subjectB = texture(subjectTex, alternate);
    vec4 floorB = texture(floorTex, alternate);
    float selectedA = step(floorA.r, subjectA.r);
    float selectedB = step(floorB.r, subjectB.r);
    vec2 normalA = mix(floorA.ba, subjectA.ba, selectedA) * 2.0 - 1.0;
    vec2 normalB = mix(floorB.ba, subjectB.ba, selectedB) * 2.0 - 1.0;
    vec2 stateA = vec2(
        max(subjectA.r, floorA.r),
        clamp(mix(floorA.g, subjectA.g, selectedA), 0.0, 1.0));
    vec2 stateB = vec2(
        max(subjectB.r, floorB.r),
        clamp(mix(floorB.g, subjectB.g, selectedB), 0.0, 1.0));
    float darknessA = 1.0 - toneFromMaskAndKey(stateA);
    float darknessB = 1.0 - toneFromMaskAndKey(stateB);
    float centeredRear = step(0.5, flowSource.w) *
        (1.0 - smoothstep(0.04, 0.42,
            length((flowSource.xy - vec2(0.5)) * 2.0))) *
        (1.0 - step(0.0, flowSource.z));
    float edgeA = smoothstep(0.02, 0.52, length(normalA));
    float edgeB = smoothstep(0.02, 0.52, length(normalB));
    // Main-stroke placement is geometric. Lighting may shade hatching, but
    // must not move a loaded brush family to a different body part or delete
    // it when the artist turns the light. Edge evidence is useful for the
    // centered depth halo, while ordinary views use stable owned coverage.
    float scoreA = stateA.x * mix(1.0, mix(0.24, 1.18, edgeA), centeredRear);
    float scoreB = stateB.x * mix(1.0, mix(0.24, 1.18, edgeB), centeredRear);
    float chooseB = step(0.18, selector) * step(scoreA, scoreB);
    float totalA = subjectA.r + floorA.r;
    float totalB = subjectB.r + floorB.r;
    float roleA = totalA > 0.001 ? subjectA.r / totalA : 0.5;
    float roleB = totalB > 0.001 ? subjectB.r / totalB : 0.5;
    vec2 velocityA = mix(
        backgroundMotion, texture(motionTex, candidate).rg, roleA);
    vec2 velocityB = mix(
        backgroundMotion, texture(motionTex, alternate).rg, roleB);
    role = mix(roleA, roleB, chooseB);
    localMotion = mix(velocityA, velocityB, chooseB);
    localNormal = mix(normalA, normalB, chooseB);
    // W is graphic brush load for this path, not captured luminance. Keeping
    // it constant makes light edits preserve family length and width.
    return mix(vec4(candidate, stateA.x, 1.0),
               vec4(alternate, stateB.x, 1.0), chooseB);
}

vec4 shiftSeedTowardTrailing(vec4 seedData, vec2 flow, float familySeed)
{
    vec2 seedUV = seedData.xy;
    vec4 shifted = seedData;
    float bestScore = 0.0;
    // Walk from the selected form sample in the directed casting direction.
    // The farthest still-owned upstream probe becomes the launch heel, so the
    // family starts on the windward surface that faces the pink source.
    // Give each hand family a different heel spacing. Shared fixed probes
    // aligned diagonal silhouettes into visible stair steps.
    float firstDistance = mix(7.0, 16.0,
        hash21(vec2(familySeed * 127.1 + 19.0, salt * 0.113)));
    float stride = mix(17.0, 39.0,
        hash21(vec2(familySeed * 191.7 + 43.0, salt * 0.071)));
    for (int i = 0; i < 5; ++i) {
        float distancePixels = firstDistance + stride * float(i);
        vec2 probeUV = seedUV - flow * distancePixels / resolution;
        vec2 state = sourceMaskAndKey(probeUV);
        if (state.x <= 0.12) break;
        float trailingScore = (float(i) + 1.0) / 5.0;
        if (state.x > 0.12 && trailingScore > bestScore) {
            shifted = vec4(probeUV, state.x, 1.0);
            bestScore = trailingScore;
        }
    }
    return shifted;
}

vec4 shiftSeedTowardSilhouette(vec4 seedData, float familySeed)
{
    vec2 subjectCenter = 0.5 * (subjectBounds.xy + subjectBounds.zw);
    vec2 aspect = vec2(resolution.x / max(resolution.y, 1.0), 1.0);
    vec2 radial = (seedData.xy - subjectCenter) * aspect;
    float radialLength = length(radial);
    radial = radialLength > 1.0e-5 ? radial / radialLength : vec2(1.0, 0.0);
    radial /= aspect;
    vec4 shifted = seedData;
    float firstDistance = mix(7.0, 15.0,
        hash21(vec2(familySeed * 157.1 + 23.0, salt * 0.097)));
    float stride = mix(14.0, 27.0,
        hash21(vec2(familySeed * 211.7 + 59.0, salt * 0.061)));
    // Walk along the projected volume radius and retain the last owned sample.
    // This is the same seed family, repositioned to where rear wind becomes
    // visible around the silhouette rather than through the front face.
    for (int i = 0; i < 6; ++i) {
        vec2 probeUV = seedData.xy + radial *
            (firstDistance + stride * float(i)) / resolution;
        vec2 state = sourceMaskAndKey(probeUV);
        if (state.x <= 0.12) break;
        shifted = vec4(
            probeUV, state.x, 1.0 - toneFromMaskAndKey(state));
    }
    return shifted;
}

float stylizedKeyAt(vec2 p, float transitionWidth)
{
    float key = keyLightField(clamp(p, vec2(0.0), vec2(1.0)));
    // Broad and medium pressure variation bends the cel boundary like a dry
    // painted pass. It is deterministic per frame and deliberately excludes
    // pixel-frequency noise, so the light remains a coherent authored shape.
    float paintedOffset =
        (valueNoise((p - vec2(0.5)) * vec2(4.7, 4.1), salt + 1171.0) - 0.5) * 0.070 +
        (valueNoise((p - vec2(0.5)) * vec2(12.1, 10.7), salt + 1193.0) - 0.5) * 0.024;
    key = clamp(key + paintedOffset, 0.0, 1.0);
    float width = max(transitionWidth, 0.004);
    float mid = smoothstep(0.36 - width, 0.36 + width, key);
    float high = smoothstep(0.76 - width, 0.76 + width, key);
    return mid * 0.72 + high * 0.28;
}

vec2 sourceVelocity(vec2 p)
{
    vec4 subject = texture(subjectTex, p);
    vec4 floorData = texture(floorTex, p);
    float total = subject.r + floorData.r;
    float role = total > 0.001 ? subject.r / total : 0.5;
    return mix(backgroundMotion, texture(motionTex, p).rg, role);
}

vec2 sourceAcceleration(vec2 p)
{
    float role = smoothstep(0.04, 0.72, texture(subjectTex, p).r);
    vec2 local = texture(motionTex, p).ba;
    return mix(subjectAcceleration, local, role);
}

float perspectiveScaleAt(vec2 p)
{
    // Motion BA now stores evaluated local acceleration. Perspective remains
    // represented by the projected geometry itself rather than sharing this
    // packed trajectory texture.
    return 1.0;
}

vec2 sourceSurfaceNormalXY(vec2 p)
{
    vec4 subject = texture(subjectTex, clamp(p, vec2(0.0), vec2(1.0)));
    vec4 floorData = texture(floorTex, clamp(p, vec2(0.0), vec2(1.0)));
    vec2 encoded = subject.r >= floorData.r ? subject.ba : floorData.ba;
    return encoded * 2.0 - 1.0;
}

vec2 localOwnedSpan(vec2 seedUV, vec2 flow)
{
    float negative = 0.0;
    float positive = 0.0;
    float stepPixels = max(5.0, min(resolution.x, resolution.y) * 0.014);
    for (int i = 1; i <= 12; ++i) {
        float distancePixels = stepPixels * float(i);
        if (sourceCoverage(seedUV - flow * distancePixels / resolution) > 0.10)
            negative = distancePixels;
        if (sourceCoverage(seedUV + flow * distancePixels / resolution) > 0.10)
            positive = distancePixels;
    }
    return vec2(negative, positive);
}

vec2 rotateVector(vec2 v, float radians);
vec2 safeDirection(vec2 value, vec2 fallback);
vec2 blendDirection(vec2 fromDirection, vec2 toDirection, float amount);

float radialTwirlOffset(float radius)
{
    if (abs(radialSpiral) <= 0.0001) return 0.0;
    // One isotropic radius contract drives loaded ribbons, hairlines,
    // hatching and background gestures. Normalizing against the rectangular
    // frame edge imprinted its corners into the curl at high Twirl values.
    vec2 focusPixel = focus * resolution;
    float reach = max(max(
        max(length(focusPixel), length(focusPixel - vec2(resolution.x, 0.0))),
        max(length(focusPixel - vec2(0.0, resolution.y)),
            length(focusPixel - resolution))), 1.0) * 1.02;
    float t = clamp(radius / reach, 0.0, 1.0);
    float smoothT = t * t * (3.0 - 2.0 * t);
    float envelope = smoothT * (0.18 + 0.82 * t);
    // The signed endpoint now produces a decisive authored curl while the
    // cubic envelope still keeps the convergence pocket coherent.
    return radialSpiral * 3.35 * envelope;
}

vec2 radialUntwirlPoint(vec2 p)
{
    if ((mode != 1 && hybridMode == 0) ||
        abs(radialSpiral) <= 0.0001) return p;
    vec2 delta = (p - focus) * resolution;
    float turn = -radialTwirlOffset(length(delta));
    float c = cos(turn);
    float s = sin(turn);
    vec2 untwirled = vec2(
        c * delta.x - s * delta.y,
        s * delta.x + c * delta.y);
    return focus + untwirled / max(resolution, vec2(1.0));
}

float radialTwirlTangent(float radius)
{
    if (abs(radialSpiral) <= 0.0001) return 0.0;
    float sampleStep = 2.0;
    float derivative = (
        radialTwirlOffset(radius + sampleStep) -
        radialTwirlOffset(max(0.0, radius - sampleStep))) /
        (sampleStep * 2.0);
    return atan(radius * derivative, 1.0);
}

vec2 baseFlow(vec2 p)
{
    vec2 authored = vec2(cos(angle), sin(angle));
    if (mode != 1 && hybridMode == 0) return authored;

    // A radial impact has a finite luminous pocket rather than a singular
    // mathematical center. Pixel-space evaluation keeps the burst circular at
    // every render aspect ratio, while the authored angle supplies a stable
    // direction inside the otherwise undefined core.
    vec2 delta = (p - focus) * resolution;
    float radius = length(delta);
    vec2 radial = safeDirection(delta, authored);
    float coreBlend = smoothstep(7.0, 54.0, radius);
    vec2 flow = blendDirection(authored, radial, coreBlend);
    if (mode != 1) {
        // Hybrid is one coupled composition, not two opaque pictures.
        if (dot(radial, authored) < 0.0) radial = -radial;
        float interaction = smoothstep(28.0, 360.0, radius) * 0.34;
        flow = blendDirection(authored, radial, interaction);
        return rotateVector(
            flow, radialTwirlTangent(radius) * interaction * 0.46);
    }
    float coherentTurn =
        (valueNoise((p - focus) * vec2(3.7, 3.1), salt + 53.0) - 0.5) *
        mix(0.025, 0.095, smoothstep(40.0, 420.0, radius));
    return rotateVector(flow, coherentTurn + radialTwirlTangent(radius));
}

vec2 rotateVector(vec2 v, float radians)
{
    float c = cos(radians);
    float s = sin(radians);
    return vec2(c * v.x - s * v.y, s * v.x + c * v.y);
}

vec2 safeDirection(vec2 value, vec2 fallback)
{
    float magnitude = length(value);
    return magnitude > 1.0e-7 ? value / magnitude : normalize(fallback + vec2(1.0e-7));
}

float subjectCenteredSourceAmount()
{
    vec2 subjectCenter = 0.5 * (subjectBounds.xy + subjectBounds.zw);
    float distanceFromSubject = length((flowSource.xy - subjectCenter) * 2.0);
    return step(0.5, flowSource.w) *
        (1.0 - smoothstep(0.04, 0.22, distanceFromSubject));
}

vec2 blendDirection(vec2 fromDirection, vec2 toDirection, float amount)
{
    vec2 fromUnit = safeDirection(fromDirection, vec2(1.0, 0.0));
    vec2 toUnit = safeDirection(toDirection, fromUnit);
    float fromAngle = atan(fromUnit.y, fromUnit.x);
    float toAngle = atan(toUnit.y, toUnit.x);
    float delta = atan(sin(toAngle - fromAngle), cos(toAngle - fromAngle));
    float blended = fromAngle + delta * clamp(amount, 0.0, 1.0);
    return vec2(cos(blended), sin(blended));
}

vec2 alignLineAxis(vec2 candidate, vec2 reference)
{
    vec2 aligned = safeDirection(candidate, reference);
    vec2 stable = safeDirection(reference, vec2(1.0, 0.0));
    return dot(aligned, stable) < 0.0 ? -aligned : aligned;
}

float castBehindAmount()
{
    return step(0.5, flowSource.w) * (1.0 - step(0.0, flowSource.z));
}

vec2 aerodynamicSurfaceFlow(vec2 p, vec2 normalXY, vec2 fallback,
                            out float confidence, out vec2 directedFlow)
{
    vec2 boundedXY = normalXY;
    float xyLength = length(boundedXY);
    if (xyLength > 0.999) boundedXY *= 0.999 / xyLength;
    vec3 surfaceNormal = vec3(
        boundedXY, sqrt(max(0.0, 1.0 - dot(boundedXY, boundedXY))));
    float pointSource = step(0.5, flowSource.w);
    vec2 aspectScale = vec2(
        resolution.x / max(resolution.y, 1.0), 1.0);
    // Parallel camera-space rays, like window light. The pin selects a
    // hemisphere direction; it is not a point attractor inside the image.
    vec2 directionXY = (flowSource.xy - vec2(0.5)) * 2.0 * aspectScale;
    vec3 sourceRay = vec3(-directionXY, flowSource.z);
    vec2 toSource = -directionXY;
    vec3 authoredWind = vec3(flowSource.xy, 0.0);
    vec3 wind = normalize(mix(authoredWind, sourceRay, pointSource) +
                          vec3(1.0e-7));
    vec3 surfaceTrail = wind - surfaceNormal * dot(wind, surfaceNormal);
    float projectedLength = length(surfaceTrail.xy);
    vec2 pinFacing = safeDirection(toSource, fallback);
    vec2 subjectCenter = 0.5 * (subjectBounds.xy + subjectBounds.zw);
    vec2 silhouetteEscape = safeDirection(
        boundedXY, safeDirection((p - subjectCenter) * aspectScale, fallback));
    vec2 surfaceFan = safeDirection(
        silhouetteEscape * sign(flowSource.z + 1.0e-6), fallback);
    float centeredSource = pointSource *
        (1.0 - smoothstep(0.04, 0.42, length(directionXY)));
    // Looking down the depth ray does not erase the shot's authored brush
    // axis. Perspective is carried by foreshortening, width/taper polarity,
    // and a restrained normal-dependent correction—not by rotating every
    // face toward its silhouette tangent.
    vec2 depthFormAxis = alignLineAxis(silhouetteEscape, fallback);
    confidence = pointSource > 0.5
        ? smoothstep(0.008, 0.20, max(projectedLength, length(boundedXY)))
        : smoothstep(0.025, 0.34, projectedLength);
    // A front/back source has no screen-space tangent on a front-facing face.
    // Falling back to the pin vector makes every family collapse into a star.
    // The projected surface/silhouette direction preserves perspective and
    // emits from the visible form instead.
    // Preserve the projected 3D travel sign separately from the line axis.
    // At a centered pin the XY component comes from the captured surface
    // normal; reversing the source hemisphere reverses heel/release ownership
    // without selecting another renderer or inventing a new screen angle.
    directedFlow = safeDirection(
        surfaceTrail.xy,
        fallback * sign(flowSource.z + 1.0e-6));
    directedFlow = blendDirection(
        directedFlow, depthFormAxis,
        centeredSource * smoothstep(0.06, 0.72, length(boundedXY)) * 0.18);
    vec2 projected = alignLineAxis(directedFlow, fallback);
    if (pointSource < 0.5) return projected;
    // Surface projection establishes the central aerodynamic axis. Spread is
    // applied once at family level as cone aperture; it must not steer this
    // axis toward the pin or toward a perpendicular field.
    if (centeredSource > 0.5) {
        return blendDirection(
            safeDirection(fallback, vec2(1.0, 0.0)),
            alignLineAxis(projected, fallback),
            smoothstep(0.08, 0.72, length(boundedXY)) * 0.22);
    }
    vec2 surfacePrior = blendDirection(
        alignLineAxis(pinFacing, projected), projected, 0.90);
    return surfacePrior;
}

vec2 hatchAerodynamicFlow(vec2 p, vec2 normalXY, vec2 fallback,
                          out float confidence)
{
    // Hatching is a collection of finite pencil actions, not a continuous
    // vector-field visualization. Project the emitter wind onto the sampled
    // face once per action. When front/back wind has no stable screen tangent,
    // retain the authored drafting direction instead of falling back to a
    // silhouette-radial vector that makes nested black-hole rings.
    vec2 boundedXY = normalXY;
    float xyLength = length(boundedXY);
    if (xyLength > 0.999) boundedXY *= 0.999 / xyLength;
    vec3 surfaceNormal = vec3(
        boundedXY, sqrt(max(0.0, 1.0 - dot(boundedXY, boundedXY))));
    vec2 aspectScale = vec2(
        resolution.x / max(resolution.y, 1.0), 1.0);
    vec2 directionXY = (flowSource.xy - vec2(0.5)) * 2.0 * aspectScale;
    vec3 sourceRay = vec3(-directionXY, flowSource.z);
    vec3 wind = normalize(sourceRay + vec3(1.0e-7));
    vec3 surfaceTrail = wind - surfaceNormal * dot(wind, surfaceNormal);
    float projectedLength = length(surfaceTrail.xy);
    confidence = smoothstep(0.035, 0.30, projectedLength);
    vec2 projected = safeDirection(surfaceTrail.xy, fallback);
    if (dot(projected, fallback) < 0.0) projected = -projected;
    float maximumTurn = 0.61086524; // 35 degrees per independent action.
    float delta = atan(
        fallback.x * projected.y - fallback.y * projected.x,
        dot(fallback, projected));
    return rotateVector(
        safeDirection(fallback, vec2(1.0, 0.0)),
        clamp(delta, -maximumTurn, maximumTurn) * confidence);
}

float hemisphereStrokeScale(vec2 p, vec2 normalXY)
{
    if (flowSource.w < 0.5) return 1.0;
    vec2 boundedXY = normalXY;
    float xyLength = length(boundedXY);
    if (xyLength > 0.999) boundedXY *= 0.999 / xyLength;
    vec3 surfaceNormal = vec3(
        boundedXY, sqrt(max(0.0, 1.0 - dot(boundedXY, boundedXY))));
    vec2 aspectScale = vec2(
        resolution.x / max(resolution.y, 1.0), 1.0);
    vec2 directionXY = (flowSource.xy - vec2(0.5)) * 2.0 * aspectScale;
    vec3 sourceRay = normalize(vec3(-directionXY, flowSource.z) +
                               vec3(1.0e-7));
    float facing = dot(surfaceNormal, sourceRay);
    // Windward/front-facing planes receive compact pressure marks. Leeward
    // and rear-facing planes carry longer imperfect release strokes. Flipping
    // Cast Behind changes this ownership without rotating the 2D line axis.
    return mix(1.34, 0.76, smoothstep(-0.38, 0.48, facing));
}

float sketchOutlineField(vec2 p, float center, float seamSupport)
{
    vec2 px = 1.0 / max(resolution, vec2(1.0));
    float hand = valueNoise(
        (p - vec2(0.5)) * vec2(19.0, 16.0), salt + 2371.0);
    vec2 warp = vec2(
        valueNoise((p - vec2(0.5)) * vec2(11.0, 9.0), salt + 2381.0),
        valueNoise((p - vec2(0.5)) * vec2(9.0, 12.0), salt + 2393.0));
    float outlineThickness = pow(clamp(lineThickness, 0.0, 1.0), 0.72);
    vec2 q = p + (warp - vec2(0.5)) * px *
        mix(1.8, 4.8, outlineThickness);
    float radius = mix(0.65, 2.80, hand) *
        mix(0.45, 1.0, outlineThickness);
    // Correlated angular drift keeps the construction edge directional while
    // avoiding a mechanically uniform outline around separate faces.
    float angleDrift = (valueNoise(
        (p - vec2(0.5)) * vec2(6.7, 8.3), salt + 2411.0) - 0.5) * 0.34;
    float probeAngle = hand * 6.28318531 + angleDrift;
    vec2 probeDirection = vec2(cos(probeAngle), sin(probeAngle));
    float probeA = sourceCoverage(q + probeDirection * px * radius);
    float probeB = sourceCoverage(q - probeDirection * px * radius);
    float silhouette = max(
        smoothstep(0.10, 0.72,
            max(abs(center - probeA), abs(center - probeB))),
        smoothstep(0.018, 0.16, fwidth(center)));
    // The subject outline is the external construction silhouette. Feeding
    // every internal part/bevel seam into the same contour created stacked
    // U/lens lines on rounded and layered geometry.
    float seam = 0.0;
    float paper = valueNoise(
        (p - vec2(0.5)) * resolution * 0.075, salt + 2341.0);
    float pressure = mix(0.68, 1.0, hand) * mix(0.74, 1.0, paper);
    // This is an inked construction contour, not an exact vector edge. It
    // covers narrow bevel/part seams and gives the hatch field a deliberate
    // hand-drawn boundary while retaining dry pressure variation.
    float outlineLift = smoothstep(
        0.38, 0.68, paper * 0.62 + hand * 0.38);
    // A contour is redrawn as short, separate construction actions. The
    // transverse band owns an independent phase, so adjacent bevel/seam lines
    // do not form nested continuous lenses or share one cut plane.
    vec2 actionAxis = vec2(cos(angle), sin(angle));
    vec2 actionNormal = vec2(-actionAxis.y, actionAxis.x);
    vec2 actionPixel = (p - vec2(0.5)) * resolution;
    float transverseBand = floor(dot(actionPixel, actionNormal) / 19.0);
    float actionPhase = valueNoise(
        vec2(transverseBand * 0.37, salt * 0.19), salt + 2459.0) * 23.0;
    float actionCoordinate =
        (dot(actionPixel, actionAxis) + actionPhase) / 27.0;
    float actionIndex = floor(actionCoordinate);
    float actionT = fract(actionCoordinate);
    float actionStart = mix(0.03, 0.22, valueNoise(
        vec2(actionIndex, transverseBand), salt + 2473.0));
    float actionEnd = mix(0.68, 0.98, valueNoise(
        vec2(actionIndex, transverseBand), salt + 2503.0));
    actionEnd = max(actionEnd, actionStart + 0.38);
    float finiteActionGate = smoothstep(
        actionStart, actionStart + 0.075, actionT) *
        (1.0 - smoothstep(actionEnd - 0.10, actionEnd, actionT));
    float primary = max(
        silhouette * 0.82 * mix(0.14, 1.0, outlineLift),
        seam * 0.72) * pressure * finiteActionGate;
    // A displaced duplicate contour reads as a smooth lens, not as another
    // finite pencil action, so the construction outline has one centerline.
    return clamp(primary * outlineThickness, 0.0, 1.0);
}

vec2 surfaceFormFlow(vec2 p, vec2 anchor, out float confidence)
{
    vec2 base = safeDirection(anchor, vec2(1.0, 0.0));
    float subjectCenter = texture(
        subjectTex, clamp(p, vec2(0.0), vec2(1.0))).r;
    // Preserve the established background/floor field. Cross-part
    // regularization is only needed for the assembled character; spreading it
    // over the full floor over-draws the composition and raises bloom energy.
    if (subjectCenter < 0.08) {
        vec2 normalXY = sourceSurfaceNormalXY(p);
        float normalReach = length(normalXY);
        float ownership = smoothstep(0.18, 0.88, sourceMask(p));
        confidence = ownership * smoothstep(0.08, 0.82, normalReach);
        if (confidence <= 0.0001) return base;
        vec2 formTangent = safeDirection(
            vec2(-normalXY.y, normalXY.x), base);
        if (dot(formTangent, base) < 0.0) formTangent = -formTangent;
        float delta = atan(
            base.x * formTangent.y - base.y * formTangent.x,
            dot(base, formTangent));
        float limited = clamp(delta, -0.52359878, 0.52359878);
        return rotateVector(base, limited * confidence * 0.84);
    }
    // Treat the assembled character as one drawing surface. A raw normal at
    // p changes discontinuously where neighboring mesh parts meet, making the
    // hatch family visibly stop and restart. Three tangent-aligned samples are
    // blended as an *undirected* (double-angle) field, so opposite tangent
    // signs agree and a narrow inter-part gap cannot split the pencil gesture.
    vec2 sampleStep = base * 10.0 / resolution;
    vec2 normal0 = sourceSurfaceNormalXY(p);
    vec2 normalA = sourceSurfaceNormalXY(p - sampleStep);
    vec2 normalB = sourceSurfaceNormalXY(p + sampleStep);
    vec2 tangent0 = safeDirection(vec2(-normal0.y, normal0.x), base);
    vec2 tangentA = safeDirection(vec2(-normalA.y, normalA.x), base);
    vec2 tangentB = safeDirection(vec2(-normalB.y, normalB.x), base);
    float weight0 = smoothstep(0.18, 0.88, subjectCenter) *
                    smoothstep(0.08, 0.82, length(normal0));
    float weightA = smoothstep(0.10, 0.78, texture(
                        subjectTex, clamp(p - sampleStep,
                        vec2(0.0), vec2(1.0))).r) *
                    smoothstep(0.08, 0.82, length(normalA)) * 0.72;
    float weightB = smoothstep(0.10, 0.78, texture(
                        subjectTex, clamp(p + sampleStep,
                        vec2(0.0), vec2(1.0))).r) *
                    smoothstep(0.08, 0.82, length(normalB)) * 0.72;
    vec2 doubled =
        vec2(tangent0.x * tangent0.x - tangent0.y * tangent0.y,
             2.0 * tangent0.x * tangent0.y) * weight0 +
        vec2(tangentA.x * tangentA.x - tangentA.y * tangentA.y,
             2.0 * tangentA.x * tangentA.y) * weightA +
        vec2(tangentB.x * tangentB.x - tangentB.y * tangentB.y,
             2.0 * tangentB.x * tangentB.y) * weightB;
    float support = (weight0 + weightA + weightB) / 2.44;
    confidence = smoothstep(0.08, 0.76, support);
    if (confidence <= 0.0001) return base;

    float tangentAngle = 0.5 * atan(doubled.y, doubled.x);
    vec2 formTangent = vec2(cos(tangentAngle), sin(tangentAngle));
    if (dot(formTangent, base) < 0.0) formTangent = -formTangent;
    float delta = atan(
        base.x * formTangent.y - base.y * formTangent.x,
        dot(base, formTangent));
    // Twenty degrees is enough to describe form without the long, smooth
    // U-turns that read as a computer distortion rather than pencil phrasing.
    float limited = clamp(delta, -0.34906585, 0.34906585);
    return rotateVector(base, limited * confidence * 0.68);
}

float sourceRole(vec2 p)
{
    vec4 subject = texture(subjectTex, clamp(p, vec2(0.0), vec2(1.0)));
    vec4 floorData = texture(floorTex, clamp(p, vec2(0.0), vec2(1.0)));
    float total = subject.r + floorData.r;
    return total > 0.001 ? subject.r / total : 0.5;
}

vec2 motionAwareDirection(vec2 authoredDirection, float subjectWeight,
                          vec2 localMotion, float influenceScale,
                          out float response)
{
    float role = clamp(subjectWeight, 0.0, 1.0);
    vec2 roleMotion = mix(backgroundMotion, subjectMotion, role);
    float scale = max(velocityScale, 1.0e-6);
    float roleSpeed = length(roleMotion) / scale;
    float localSpeed = length(localMotion) / scale;
    float localConfidence = smoothstep(0.025, 0.82, localSpeed);
    vec2 roleDirection = safeDirection(roleMotion, authoredDirection);
    vec2 localDirection = safeDirection(localMotion, roleDirection);
    // The robust role estimate supplies stable camera/limb intent. The sampled
    // velocity then adds local rotational and articulated flow without allowing
    // one malformed raster velocity to steer an entire stroke family.
    vec2 motionDirection = blendDirection(
        roleDirection, localDirection,
        localConfidence * mix(0.72, 0.58, role));
    float normalizedSpeed = max(roleSpeed, localSpeed * 0.92);
    float speedResponse = smoothstep(0.015, 1.10, normalizedSpeed);
    // Animation-driven curvature belongs to stroke geometry, not the optional
    // post Motion Blur effect. The canonical mask has no blur dependency, so
    // coupling these values would silently disable keyed-bone
    // trails.  Zero captured velocity still produces an exact static bypass.
    float artistInfluence = clamp(motionCurveInfluence, 0.0, 1.0);
    response = influenceScale * speedResponse * artistInfluence;
    if (response <= 0.00001) {
        return safeDirection(authoredDirection, vec2(1.0, 0.0));
    }
    return motionDirection;
}

float paperTone(vec2 p)
{
    float mask = sourceMask(p);
    return mix(1.0, sourceTone(p), smoothstep(0.02, 0.55, mask));
}

vec2 toneGuidedFlow(vec2 p, vec2 localMotion, out float structureEnergy)
{
    vec2 flow = baseFlow(p);
    float formConfidence;
    flow = surfaceFormFlow(p, flow, formConfidence);
    structureEnergy = formConfidence;

    float motionResponse;
    vec2 motionFlow = motionAwareDirection(
        flow, sourceRole(p), localMotion, 0.38, motionResponse);
    flow = blendDirection(flow, motionFlow, motionResponse);

    // Broad, correlated correction models a hand steering one gesture. The
    // highest frequency remains well below a pixel, avoiding procedural teeth.
    float bendA = valueNoise(p * vec2(5.1, 4.3), salt + 19.0) - 0.5;
    float bendB = valueNoise(p * vec2(17.7, 14.1), salt + 71.0) - 0.5;
    float bend = bendA * 0.22 + bendB * 0.06;
    return safeDirection(rotateVector(flow, bend * 0.42), flow);
}

vec2 hatchPacketFlow(vec2 p, vec2 anchor, out float packetGate,
                     out float formEnergy)
{
    vec2 base = safeDirection(anchor, vec2(1.0, 0.0));
    // Do not steer or gate an implicit lane from the normal at every output
    // pixel. That turns one pencil trace into a rubber contour and inserts a
    // visible seam wherever a mesh face changes normal. hatchFamily samples
    // form once at each finite gesture anchor and holds that angle constant.
    packetGate = 1.0;
    formEnergy = 0.0;
    return base;
}

float hash11(float p)
{
    return hash21(vec2(p, p * 1.61803398875));
}

float quinticEase(float t)
{
    t = clamp(t, 0.0, 1.0);
    return t * t * t * (t * (t * 6.0 - 15.0) + 10.0);
}

float angleDifference(float a, float b)
{
    return atan(sin(a - b), cos(a - b));
}

float directionalEdgeEnergy(vec2 p, vec2 flow)
{
    vec2 pixel = p * resolution;
    vec2 px = 1.6 / resolution;
    float bgx = sourceMask(p + vec2(px.x, 0.0)) -
                sourceMask(p - vec2(px.x, 0.0));
    float bgy = sourceMask(p + vec2(0.0, px.y)) -
                sourceMask(p - vec2(0.0, px.y));
    vec2 baseGradient = vec2(bgx, bgy);
    vec2 edgeNormal = normalize(baseGradient + vec2(1e-6));
    // Displace in the actual silhouette normal.  The old flow-normal offset
    // was constant on many box edges, leaving a perfect stamped outline.
    float contourDrift =
        (valueNoise(pixel * 0.0107, salt + 311.0) - 0.5) * 10.5 +
        (valueNoise(pixel * 0.0311, salt + 419.0) - 0.5) * 3.4 +
        (valueNoise(pixel * 0.0793, salt + 443.0) - 0.5) * 3.8;
    p += edgeNormal * (contourDrift / resolution);
    // A hand-drawn construction edge does not keep one nib width around an
    // entire box face. Vary the sampling footprint slowly along the contour;
    // this changes deposited thickness without adding pixel-frequency teeth.
    float nibSpan = mix(1.15, 2.65, valueNoise(
        vec2(dot(pixel, vec2(-edgeNormal.y, edgeNormal.x)) * 0.021,
             salt * 0.17), salt + 461.0));
    vec2 nibPx = nibSpan / resolution;
    float gx = sourceMask(p + vec2(nibPx.x, 0.0)) -
               sourceMask(p - vec2(nibPx.x, 0.0));
    float gy = sourceMask(p + vec2(0.0, nibPx.y)) -
               sourceMask(p - vec2(0.0, nibPx.y));
    vec2 gradient = vec2(gx, gy);
    vec2 tangent = normalize(vec2(-gradient.y, gradient.x) + vec2(1e-6));
    float alignment = abs(dot(tangent, flow));
    // The captured silhouette is guidance, not a vector outline. Correlated
    // pressure fragments it into restrained sketch passes so hatching and
    // gesture bundles describe the subject instead of a perfect mesh border.
    float arc = dot(pixel, tangent);
    float contourMacro = valueNoise(
        vec2(arc * 0.014 + salt * 0.31,
             dot(pixel, edgeNormal) * 0.006), salt + 1201.0);
    float contourMeso = valueNoise(
        vec2(arc * 0.046 + salt * 0.17,
             dot(pixel, edgeNormal) * 0.019), salt + 1277.0);
    float pressure = smoothstep(
        0.24, 0.66, contourMacro * 0.68 + contourMeso * 0.32);
    float paperContact = valueNoise(pixel * 0.23, salt + 1327.0);
    // Correlated pencil lifts fragment long ruler-like runs. The floor is
    // deliberately non-zero so the limb remains readable as one construction
    // drawing rather than dissolving into unrelated dashes.
    float pencilLift = smoothstep(0.28, 0.66, valueNoise(
        vec2(arc * 0.031 + salt * 0.23,
             dot(pixel, edgeNormal) * 0.011), salt + 1361.0));
    float contourBand = floor(dot(pixel, edgeNormal) / 18.0);
    float actionPhase = valueNoise(
        vec2(contourBand * 0.41, salt * 0.13), salt + 1373.0) * 25.0;
    float actionCoordinate = (arc + actionPhase) / 31.0;
    float actionIndex = floor(actionCoordinate);
    float actionT = fract(actionCoordinate);
    float actionStart = mix(0.02, 0.20, valueNoise(
        vec2(actionIndex, contourBand), salt + 1379.0));
    float actionEnd = mix(0.66, 0.98, valueNoise(
        vec2(actionIndex, contourBand), salt + 1399.0));
    actionEnd = max(actionEnd, actionStart + 0.40);
    float finiteActionGate = smoothstep(
        actionStart, actionStart + 0.07, actionT) *
        (1.0 - smoothstep(actionEnd - 0.10, actionEnd, actionT));
    float deposited = mix(0.10, 1.0, pressure) *
                      mix(0.68, 1.06, paperContact) *
                      mix(0.40, 1.0, pencilLift) * finiteActionGate;
    return length(gradient) * deposited * mix(0.24, 1.0,
        smoothstep(0.24, 0.82, alignment));
}

float looseToneStructure(vec2 p)
{
    vec2 pixel = p * resolution;
    vec2 px = 1.5 / resolution;
    float axp = paperTone(p + vec2(px.x, 0.0));
    float axm = paperTone(p - vec2(px.x, 0.0));
    float ayp = paperTone(p + vec2(0.0, px.y));
    float aym = paperTone(p - vec2(0.0, px.y));
    vec2 firstGradient = vec2(axp - axm, ayp - aym);
    vec2 edgeNormal = normalize(firstGradient + vec2(1e-6));
    vec2 edgeTangent = vec2(-edgeNormal.y, edgeNormal.x);
    float arc = dot(pixel, edgeTangent);
    float drift =
        (valueNoise(vec2(arc * 0.012, salt * 0.19),
                    salt + 1381.0) - 0.5) * 6.2 +
        (valueNoise(vec2(arc * 0.043, salt * 0.31),
                    salt + 1409.0) - 0.5) * 2.1;
    vec2 q = p + edgeNormal * drift / resolution;
    float txp = paperTone(q + vec2(px.x, 0.0));
    float txm = paperTone(q - vec2(px.x, 0.0));
    float typ = paperTone(q + vec2(0.0, px.y));
    float tym = paperTone(q - vec2(0.0, px.y));
    vec2 gradient = vec2(txp - txm, typ - tym);
    float neighborhood = min(
        min(sourceMask(q + vec2(px.x, 0.0)),
            sourceMask(q - vec2(px.x, 0.0))),
        min(sourceMask(q + vec2(0.0, px.y)),
            sourceMask(q - vec2(0.0, px.y))));
    float energy = smoothstep(0.012, 0.19, length(gradient)) *
                   smoothstep(0.12, 0.72, neighborhood);
    float pressure = smoothstep(0.30, 0.70, valueNoise(
        vec2(arc * 0.027 + salt * 0.11,
             dot(pixel, edgeNormal) * 0.013), salt + 1433.0));
    return energy * mix(0.18, 1.0, pressure);
}

/*
 * A stroke is created before any graphite breakup is applied.  The center is
 * deliberately coherent and dark; correlated bristle channels only scrape the
 * outer half.  This prevents both the dotted texture and the shredded-rig look
 * produced by thresholding convolved scene pixels.
 */
float brushRibbonDeposit(float across, float halfWidth, float along01,
                         float alongPixelWidth, float familySeed)
{
    // Most candidate families cannot affect a given fragment. Reject their
    // conservative footprint before atlas lookup/noise work; the bound also
    // includes the two escaping companion filaments below.
    if (along01 < -0.09 || along01 > 1.09 ||
        abs(across) > halfWidth * 1.62 + 1.4) {
        return 0.0;
    }
    // Pressure changes once across the gesture; it must not turn the brush
    // silhouette into a repeating water-wave pattern.
    float widthDrift = 1.0 +
        0.045 * sin(along01 * 3.2 + familySeed * 9.7) +
        0.018 * sin(along01 * 9.1 + familySeed * 3.9);
    // Impact strokes emit from a loaded base and exhaust into a pointed fiber
    // tail. The source stays near full width; only the travel end collapses.
    float travelT = clamp(along01, 0.0, 1.0);
    float pressureShape = mix(0.82, 1.0, quinticEase(travelT / 0.14));
    float tipSeed = hash11(familySeed * 71.3 + 19.0);
    // Thick strokes retain more of their loaded end. The taper is a shallow
    // pressure release, not a rocket spike or a sudden triangular cut.
    float sizeClass = smoothstep(3.0, 28.0, halfWidth);
    float terminalWidth = mix(0.90, 0.98, sizeClass) *
                          mix(0.985, 1.015, tipSeed);
    // Keep the body loaded until the terminal brush region. An earlier taper
    // exposes a long analytic triangle as Thickness grows; the final comb and
    // atlas deposition provide the visible release instead.
    float bodyTaper = mix(1.0, terminalWidth,
        quinticEase((travelT - 0.965) / 0.035));
    float fiberTerminal = mix(0.86, 0.97,
        hash11(familySeed * 97.1 + 43.0));
    float fiberTaper = mix(1.0, fiberTerminal,
        quinticEase((travelT - 0.95) / 0.05));
    // A loaded heel remains broad, but not a ruler-cut rectangle. This small
    // geometric pickup combines with the atlas pressure attack to round and
    // feather the emitter-side end without turning it into a symmetric spike.
    float heelPickup = mix(0.56, 1.0, quinticEase(travelT / 0.12));
    float bodyHalfWidth = max(
        halfWidth * widthDrift * pressureShape * bodyTaper * heelPickup, 0.38);
    float fiberHalfWidth = max(
        halfWidth * widthDrift * mix(0.86, 1.0, pressureShape) * fiberTaper,
        0.32);
    float bodyAcross = across / bodyHalfWidth;
    float fiberAcross = across / fiberHalfWidth;
    float variant = floor(hash11(familySeed * 83.17 + 17.0) * 4.0);
    float bodyLocal = bodyAcross * 0.5 + 0.5;
    float fiberLocal = fiberAcross * 0.5 + 0.5;
    // The brush does not end on one geometric plane. Continuous correlated
    // bristle lengths avoid both a flat cap and the visible stair-steps caused
    // by assigning an entire transverse strip one endpoint.
    // The center bristles travel beyond the outer bristles, but correlated
    // breakup keeps the pressure crown from becoming a clean vector point.
    float bodyTipBase = clamp(1.0 - abs(bodyAcross), 0.0, 1.0);
    float fiberTipBase = clamp(1.0 - abs(fiberAcross), 0.0, 1.0);
    float bodyTipCrown = sqrt(bodyTipBase) *
        mix(0.86, 1.0, bodyTipBase) * 0.018;
    float fiberTipCrown = sqrt(sqrt(fiberTipBase)) *
        mix(0.82, 1.0, fiberTipBase) * 0.055;
    float bodyEndShape = bodyTipCrown +
        (valueNoise(vec2(bodyLocal * 9.7, familySeed * 13.1),
                    familySeed + 1871.0) - 0.5) * 0.13 +
        (valueNoise(vec2(bodyLocal * 27.3, familySeed * 7.9),
                    familySeed + 1907.0) - 0.5) * 0.055;
    float fiberEndShape = fiberTipCrown +
        (valueNoise(vec2(fiberLocal * 13.1, familySeed * 17.3),
                    familySeed + 1933.0) - 0.5) * 0.18 +
        (valueNoise(vec2(fiberLocal * 35.7, familySeed * 5.7),
                    familySeed + 1973.0) - 0.5) * 0.07;
    float bodyEnd = 0.985 + bodyEndShape;
    float fiberEnd = 0.995 + fiberEndShape;
    float bodyStartShape =
        (valueNoise(vec2(bodyLocal * 8.1, familySeed * 11.7),
                    familySeed + 1997.0) - 0.5) * 0.060 +
        (valueNoise(vec2(bodyLocal * 24.9, familySeed * 6.3),
                    familySeed + 2011.0) - 0.5) * 0.025;
    float fiberStartShape =
        (valueNoise(vec2(fiberLocal * 12.7, familySeed * 15.1),
                    familySeed + 2039.0) - 0.5) * 0.085 +
        (valueNoise(vec2(fiberLocal * 33.1, familySeed * 4.9),
                    familySeed + 2063.0) - 0.5) * 0.035;
    float bodyStart = -0.008 + bodyStartShape;
    float fiberStart = -0.014 + fiberStartShape;
    vec2 bodyUV = vec2(
        clamp((along01 - bodyStart) /
              max(bodyEnd - bodyStart, 0.1), 0.0, 1.0),
        (variant + clamp(bodyLocal, 0.0, 1.0)) * 0.25
    );
    vec2 fiberUV = vec2(
        // Keep atlas contact into the analytic staggered end instead of
        // multiplying two coincident release envelopes.
        clamp((along01 - fiberStart) /
              max(fiberEnd - fiberStart, 0.1) * 0.88, 0.0, 1.0),
        (variant + clamp(fiberLocal, 0.0, 1.0)) * 0.25
    );
    // Derivative-sized transition bands replace binary step clipping. They
    // cover approximately one output pixel at any angle or preview scale.
    float alongAA = clamp(alongPixelWidth, 0.0015, 0.08);
    float bodyAlong = smoothstep(bodyStart - alongAA,
                                 bodyStart + alongAA, along01) *
        (1.0 - smoothstep(bodyEnd - alongAA,
                          bodyEnd + alongAA, along01));
    float fiberAlong = smoothstep(fiberStart - alongAA,
                                  fiberStart + alongAA, along01) *
        (1.0 - smoothstep(fiberEnd - alongAA,
                          fiberEnd + alongAA, along01));
    // Across is measured in output pixels, so its reciprocal half-width is
    // the exact normalized coverage change per pixel. Avoid evaluating two
    // more derivatives for every candidate stroke.
    float bodyAA = clamp(0.78 / bodyHalfWidth, 0.006, 0.32);
    float fiberAA = clamp(0.78 / fiberHalfWidth, 0.006, 0.32);
    float bodyClip = 1.0 - smoothstep(1.04 - bodyAA,
                                      1.04 + bodyAA, abs(bodyAcross));
    float fiberClip = 1.0 - smoothstep(1.04 - fiberAA,
                                       1.04 + fiberAA, abs(fiberAcross));
    float body = texture(brushTex, bodyUV).r * bodyClip * bodyAlong;
    float fibers = texture(brushTex, fiberUV).g * fiberClip * fiberAlong;
    // Resolve the travel end into the atlas' independently staggered bristle
    // endpoints. The coherent body remains loaded through most of the swipe,
    // then yields to its comb instead of presenting one shared flat cutoff.
    float terminalBreakup = quinticEase((travelT - 0.84) / 0.16);
    body *= mix(1.0, 0.06 + fibers * 0.94, terminalBreakup);
    // Fibers may break through the loaded body, but cannot become a second
    // full-strength parallel silhouette. The transverse envelope keeps the
    // outermost bristles attached to the gesture and removes the dark rail /
    // halo visible around otherwise smooth strokes.
    float fiberEnvelope = 1.0 - smoothstep(
        0.58, 0.98, abs(fiberAcross));
    float fiberDeposit = fibers * fiberEnvelope * 0.72;
    float deposit = 1.0 - (1.0 - body) * (1.0 - fiberDeposit);

    // Broad parents are dragged charcoal bundles, not opaque vector slabs.
    // This low-frequency transverse field cuts several persistent bristle
    // channels through the belly while keeping the heel and terminal comb
    // connected. The field is stroke-local, so it bends with the gesture.
    float combDrift = (travelT - 0.5) * mix(-0.42, 0.42,
        hash11(familySeed * 107.9 + 53.0));
    float combTooth = valueNoise(vec2(
        bodyAcross * 5.4 + combDrift,
        familySeed * 11.3), familySeed + 2111.0);
    float combGap = smoothstep(0.48, 0.67, combTooth) *
        smoothstep(0.09, 0.22, travelT) *
        (1.0 - smoothstep(0.78, 0.96, travelT));
    deposit *= 1.0 - sizeClass * combGap * 0.68;

    // Some loaded marks preserve a single longitudinal scrape where one
    // charcoal filament lost contact.  Its start, end and transverse drift
    // belong to the parent gesture; this creates a white bristle opening
    // without the repeated parallel rails of an exposed multi-line stamp.
    float scrapePresence = step(mix(0.76, 0.28, sizeClass),
        hash11(familySeed * 113.7 + 61.0));
    float scrapeCenter = mix(-0.66, 0.66,
        hash11(familySeed * 127.1 + 73.0));
    float scrapeStart = mix(0.26, 0.50,
        hash11(familySeed * 149.3 + 83.0));
    float scrapeEnd = mix(0.56, 0.80,
        hash11(familySeed * 163.9 + 97.0));
    float scrapeDrift = (travelT - 0.5) *
        mix(-0.12, 0.12, hash11(familySeed * 173.3 + 101.0));
    float scrapeWidth = mix(0.022, 0.058,
        hash11(familySeed * 193.1 + 109.0));
    float scrapeLane = exp(-0.5 * pow(
        (bodyAcross - scrapeCenter - scrapeDrift) / scrapeWidth, 2.0));
    float scrapeWindow = smoothstep(scrapeStart - 0.055, scrapeStart, travelT) *
        (1.0 - smoothstep(scrapeEnd, scrapeEnd + 0.055, travelT));
    float scrapeDepth = mix(0.18, 0.44,
        hash11(familySeed * 211.7 + 127.0));
    deposit *= 1.0 - scrapePresence * scrapeLane * scrapeWindow * scrapeDepth;

    // Loaded mass strokes may carry one shorter secondary dry channel. It is
    // restricted to broad parents and staggered independently, so the result
    // reads as a scraped brush belly rather than parallel bacon stripes.
    float secondaryPresence = sizeClass * step(0.56,
        hash11(familySeed * 227.3 + 131.0));
    float secondaryCenter = mix(-0.72, 0.72,
        hash11(familySeed * 239.9 + 137.0));
    float secondaryStart = mix(0.34, 0.58,
        hash11(familySeed * 251.1 + 149.0));
    float secondaryEnd = mix(0.66, 0.88,
        hash11(familySeed * 263.7 + 157.0));
    float secondaryLane = exp(-0.5 * pow(
        (bodyAcross - secondaryCenter) / mix(0.025, 0.060,
            hash11(familySeed * 277.1 + 163.0)), 2.0));
    float secondaryWindow = smoothstep(
        secondaryStart - 0.04, secondaryStart, travelT) *
        (1.0 - smoothstep(secondaryEnd, secondaryEnd + 0.04, travelT));
    deposit *= 1.0 - secondaryPresence * secondaryLane *
               secondaryWindow * 0.42;
    // Loaded charcoal may scrape and granulate, but its central belly should
    // not open into a perfectly white ruler-line across a limb. Preserve a
    // low optical-density core; edge combs and pointed terminals stay broken.
    float loadedCore = bodyClip * bodyAlong *
        (1.0 - smoothstep(0.48, 0.82, abs(bodyAcross)));
    deposit = max(deposit, loadedCore * sizeClass * 0.24);
    return deposit;
}

// A gesture family shares one macro trajectory and pressure event. Individual
// passes receive only correlated transverse/endpoint variation. This is the
// compact GPU equivalent of an animator repeating the same fast hand action;
// independent per-line randomness would read as procedural debris instead.
float companionSwipeDeposit(float across, float halfWidth, float along01,
                            float familySeed)
{
    if (along01 < -0.08 || along01 > 1.08 ||
        abs(across) > halfWidth * 1.35 + 1.2) return 0.0;
    float t = clamp(along01, 0.0, 1.0);
    float attackEnd = mix(0.018, 0.075,
        hash11(familySeed * 41.7 + 3.0));
    float releaseStart = mix(0.72, 0.91,
        hash11(familySeed * 59.3 + 11.0));
    float attackStagger = (valueNoise(
        vec2(across / max(halfWidth, 0.35) * 2.7, familySeed * 0.23),
        familySeed + 1583.0) - 0.5) * 0.11;
    // Both ends vary continuously across the brush bundle. A shared release
    // plane makes nested companions stop as visible density shelves.
    float releaseStagger = (valueNoise(
        vec2(across / max(halfWidth, 0.35) * 4.3, familySeed * 0.29),
        familySeed + 1597.0) - 0.5) * 0.16;
    releaseStart = clamp(releaseStart + releaseStagger * 0.34, 0.66, 0.94);
    float releaseEnd = max(releaseStart + 0.045, 1.035 + releaseStagger);
    float pressure = smoothstep(-0.025 + attackStagger,
                                attackEnd + attackStagger, along01) *
        (1.0 - smoothstep(releaseStart, releaseEnd, along01));
    float terminal = mix(0.78, 0.96,
        hash11(familySeed * 73.1 + 17.0));
    float taper = mix(1.0, terminal,
        quinticEase((t - 0.84) / 0.16));
    float handPressure = valueNoise(
        vec2(t * 4.7, familySeed * 0.31), familySeed + 1613.0);
    float width = max(0.34, halfWidth * taper *
        mix(0.88, 1.10, handPressure));
    float edgeAA = max(0.82, fwidth(across) * 0.78);
    float coverage = 1.0 - smoothstep(
        width, width + edgeAA, abs(across));
    float fiber = valueNoise(
        vec2(t * 11.0, across / max(width, 0.35) * 1.7),
        familySeed + 1667.0);
    float contact = mix(0.58, 1.0, fiber) *
        mix(0.76, 1.06, handPressure);
    return coverage * pressure * contact;
}

float filamentSwipeDeposit(float across, float halfWidth, float along01,
                           float familySeed)
{
    if (along01 < -0.10 || along01 > 1.12 ||
        abs(across) > halfWidth + 1.4) return 0.0;
    float t = clamp(along01, 0.0, 1.0);
    float attackStagger = (valueNoise(
        vec2(across / max(halfWidth, 0.30) * 3.1, familySeed * 0.19),
        familySeed + 1769.0) - 0.5) * 0.14;
    float attack = smoothstep(-0.035 + attackStagger,
                              0.055 + attackStagger, along01);
    float releaseStart = mix(0.74, 0.94,
        hash11(familySeed * 47.3 + 7.0));
    float releaseStagger = (valueNoise(
        vec2(across / max(halfWidth, 0.30) * 5.1, familySeed * 0.37),
        familySeed + 1777.0) - 0.5) * 0.18;
    releaseStart = clamp(releaseStart + releaseStagger * 0.30, 0.68, 0.96);
    float releaseEnd = max(releaseStart + 0.040, 1.055 + releaseStagger);
    float release = 1.0 - smoothstep(releaseStart, releaseEnd, along01);
    float widthDrift = mix(0.78, 1.18, valueNoise(
        vec2(t * 3.7, familySeed * 0.19), familySeed + 1789.0));
    float width = max(0.24, halfWidth * widthDrift);
    float edgeAA = max(0.84, fwidth(across) * 0.78);
    float coverage = 1.0 - smoothstep(width, width + edgeAA, abs(across));
    float contact = mix(0.34, 0.72, valueNoise(
        vec2(t * 8.3, across * 0.17), familySeed + 1823.0));
    return coverage * attack * release * contact;
}

float motionFamilyDeposit(float across, float halfWidth, float along01,
                          float alongPixelWidth, float familySeed,
                          float blurAmount)
{
    if (along01 < -0.20 || along01 > 1.20 ||
        abs(across) > halfWidth * 2.75 + 1.8) return 0.0;

    float parent = brushRibbonDeposit(
        across, halfWidth, along01, alongPixelWidth, familySeed);
    float familyPresence = smoothstep(0.9, 4.5, halfWidth);
    float a = hash11(familySeed * 103.7 + 19.0);
    float b = hash11(familySeed * 139.1 + 31.0);
    float c = hash11(familySeed * 181.3 + 47.0);

    float passA = companionSwipeDeposit(
        across - halfWidth * mix(0.78, 1.40, a),
        halfWidth * mix(0.32, 0.58, b),
        (along01 + mix(0.012, 0.052, b)) / mix(0.93, 1.04, a),
        familySeed + 17.0) * familyPresence * mix(0.50, 0.80, a);
    float passB = companionSwipeDeposit(
        across + halfWidth * mix(0.70, 1.32, b),
        halfWidth * mix(0.27, 0.52, c),
        (along01 - mix(0.008, 0.045, c)) / mix(0.91, 1.02, b),
        familySeed + 37.0) * familyPresence * mix(0.42, 0.72, b);
    float mini = companionSwipeDeposit(
        across - halfWidth * mix(1.05, 1.70, c),
        halfWidth * mix(0.13, 0.25, a) + 0.14,
        (along01 + mix(0.045, 0.13, c)) / mix(0.82, 1.02, a),
        familySeed + 67.0) * familyPresence * mix(0.26, 0.48, b);
    float hair = filamentSwipeDeposit(
        across + halfWidth * mix(1.38, 2.30, c),
        halfWidth * mix(0.06, 0.13, a) + 0.10,
        (along01 - mix(0.01, 0.08, b)) / mix(0.88, 1.07, c),
        familySeed + 109.0) * familyPresence * mix(0.16, 0.36, b);

    float family = 1.0 - (1.0 - parent) * (1.0 - passA) *
                   (1.0 - passB) * (1.0 - mini) * (1.0 - hair);

    // Compact three-sample exposure integral: the parent plus two trailing
    // pressure-correlated deposits. This remains line-native, not a post blur.
    float blur = clamp(blurAmount, 0.0, 1.0);
    if (blur > 0.0001) {
        float trailA = companionSwipeDeposit(
            across, halfWidth * mix(0.86, 0.72, blur),
            (along01 + blur * 0.075) / (1.0 + blur * 0.13),
            familySeed + 227.0) * blur * 0.36;
        float trailB = companionSwipeDeposit(
            across, halfWidth * mix(0.72, 0.56, blur),
            (along01 + blur * 0.150) / (1.0 + blur * 0.23),
            familySeed + 263.0) * blur * 0.20;
        family = 1.0 - (1.0 - family) * (1.0 - trailA) * (1.0 - trailB);
    }
    return family;
}

float trajectorySupport(vec2 p, vec2 flow)
{
    float shortEdge = max(1.0, min(resolution.x, resolution.y));
    float reach = shortEdge * mix(0.10, 0.58, strength);
    vec2 normal = vec2(-flow.y, flow.x);
    float accumulated = sourceCoverage(p);
    float normalization = 1.0;

    // Integrate a one-sided exposure envelope instead of taking a maximum of
    // four shifted binary silhouettes. The old max produced visible saw teeth
    // at diagonal angles because each probe exposed another rectangular step.
    // Six correlated quadrature samples are smooth enough for a continuous
    // envelope while remaining much cheaper than a full image-space blur.
    for (int i = 1; i <= 6; ++i) {
        float t = (float(i) - 0.32) / 6.0;
        float weight = exp(-2.35 * t);
        float handArc =
            (valueNoise(vec2(t * 2.7, salt * 0.071), salt + 1733.0) - 0.5) *
            mix(0.7, 4.8, strength) * (0.35 + t);
        vec2 sampleUV = p - flow * (reach * t / resolution) +
                        normal * (handArc / resolution);
        accumulated += sourceCoverage(sampleUV) * weight;
        normalization += weight;
    }
    float integrated = accumulated / normalization;
    return smoothstep(0.018, 0.31, integrated);
}

float heroInteriorGuard(vec2 p, vec2 flow, float passVariant)
{
    // Broad impact masses may leave the silhouette, but while they pass over
    // the captured subject they respect deliberate light/negative-space
    // openings. This prevents a long ribbon from bridging two bright planes
    // as if the character were merely behind a screen-space stripe.
    vec2 normal = vec2(-flow.y, flow.x);
    float groupPhase = valueNoise(
        vec2(passVariant * 17.3, salt * 0.037 + passVariant * 9.1),
        salt + 2093.0);
    float edgeWobble =
        (valueNoise((p - vec2(0.5)) * vec2(4.1, 3.7) +
                    vec2(passVariant * 2.9),
                    salt + 2101.0 + passVariant * 53.0) - 0.5) * 9.0;
    float phasePixels = mix(4.0, 24.0, groupPhase) + edgeWobble;
    float sidePhase = mix(-7.5, 7.5,
        hash11(passVariant * 113.7 + salt * 0.071 + 17.0));
    vec2 guardP = p - flow * phasePixels / resolution +
                  normal * sidePhase / resolution;
    // Ownership and tone are sampled at the hand-group phase, not at the
    // exact projected mesh pixel. Consequently no family shares the original
    // rectangle edge, while all four strokes in a group still feel authored
    // by the same pass.
    vec2 localState = sourceMaskAndKey(guardP);
    float localMask = localState.x;
    float localDarkness = localState.x *
        (1.0 - toneFromMaskAndKey(localState));
    float darkAcceptance = smoothstep(0.025, 0.28, localDarkness);
    float interiorOwnership = smoothstep(0.32, 0.90, localMask);
    // Lay down the gesture through the value boundary, then let pressure run
    // out at a pass-specific distance. Animators do not stop every brush at
    // the cel-light mask; several loaded passes overshoot while others lift
    // early, leaving an irregular fringe around the protected light plane.
    float bleedPatch = valueNoise(
        (p - vec2(0.5)) * vec2(13.7, 11.9) +
        vec2(passVariant * 5.3, passVariant * 7.1),
        salt + 2081.0 + passVariant * 97.0);
    // Each hand group carries its own boundary phase. The previous guard
    // changed directly from 1.0 outside the captured silhouette to a weak
    // value inside it, exposing the rectangular raster as one shared wall
    // even though the bristle tips themselves differed.
    float reach = mix(10.0, 48.0, bleedPatch) *
                  mix(0.82, 1.22, groupPhase) *
                  mix(0.86, 1.10, strength);
    vec2 trailingStep = flow * reach / resolution;
    vec2 sideStep = normal * mix(-9.0, 9.0,
        valueNoise((p - vec2(0.5)) * vec2(8.3, 7.1) +
                   vec2(passVariant * 3.7),
                   salt + 2111.0 + passVariant * 71.0)) /
        resolution;
    vec2 farStateA = sourceMaskAndKey(p - trailingStep);
    vec2 farStateB = sourceMaskAndKey(
        p - trailingStep * 0.58 + sideStep);
    float nearbyDarkness = max(
        farStateA.x * (1.0 - toneFromMaskAndKey(farStateA)),
        farStateB.x * (1.0 - toneFromMaskAndKey(farStateB)));
    // A shorter probe supplies a pressure shoulder rather than a binary
    // on/off decision at the source-mask contour. The longer probe still
    // limits how far ink may enter protected light.
    vec2 shoulderStateA = sourceMaskAndKey(p - trailingStep * 0.24);
    vec2 shoulderStateB = sourceMaskAndKey(
        p - trailingStep * 0.42 - sideStep * 0.45);
    float shoulderDarkness = max(
        shoulderStateA.x * (1.0 - toneFromMaskAndKey(shoulderStateA)),
        shoulderStateB.x * (1.0 - toneFromMaskAndKey(shoulderStateB)));
    float boundaryEvidence = max(
        smoothstep(0.055, 0.48, nearbyDarkness),
        smoothstep(0.10, 0.56, shoulderDarkness) * 0.86);
    float overrunPressure = mix(0.76, 0.98,
        smoothstep(0.24, 0.78, bleedPatch));
    float bristleOverrun = boundaryEvidence * overrunPressure;
    float paintedAcceptance = max(darkAcceptance, bristleOverrun);
    return mix(1.0, paintedAcceptance, interiorOwnership);
}

float heroReadabilityGate(vec2 p, vec2 strokeFlow, float seedRole,
                          float detailClass, float familySeed)
{
    // Ownership supplies brush pressure; it is not a clipping stencil. Carry
    // that pressure along the persistent family so both broad swipes and fine
    // traces cross the silhouette by unequal distances before lifting.
    vec2 flow = safeDirection(strokeFlow, vec2(1.0, 0.0));
    vec2 flowNormal = vec2(-flow.y, flow.x);
    float reach = mix(8.0, 36.0, familySeed * familySeed);
    float sideBias = (hash11(familySeed * 193.17 + salt * 0.11) - 0.5) * 7.0;
    vec2 travel = (flow * reach + flowNormal * sideBias) / resolution;
    vec2 backUV = clamp(p - travel * 0.72, vec2(0.0), vec2(1.0));
    vec2 frontUV = clamp(p + travel * 0.58, vec2(0.0), vec2(1.0));
    vec4 subject = texture(subjectTex, clamp(p, vec2(0.0), vec2(1.0)));
    float carriedSubject = max(subject.r, max(
        texture(subjectTex, backUV).r * 0.84,
        texture(subjectTex, frontUV).r * 0.70));
    float subjectSupport = smoothstep(0.018, 0.74, carriedSubject);
    float subjectInterior = smoothstep(0.10, 0.86, subject.r);
    // Background gestures may enter the character as faint construction
    // pressure. They no longer terminate on the exact segmented silhouette.
    float backgroundFloor = mix(0.12, 0.42,
                                clamp(detailClass, 0.0, 1.0));
    float backgroundPass = mix(1.0, backgroundFloor, subjectInterior);
    vec2 localState = sourceMaskAndKey(p);
    vec2 backState = sourceMaskAndKey(backUV);
    vec2 frontState = sourceMaskAndKey(frontUV);
    float localDarkness = localState.x * (1.0 - toneFromMaskAndKey(localState));
    float carriedDarkness = max(localDarkness, max(
        backState.x * (1.0 - toneFromMaskAndKey(backState)) * 0.84,
        frontState.x * (1.0 - toneFromMaskAndKey(frontState)) * 0.70));
    // Broad loaded strokes obey the local value structure; only finer
    // construction marks may transport neighboring darkness across a plane.
    // This prevents one remote shadow from blacking out an entire face.
    // Broad gestures carry the value loaded at their source through and past
    // the form. If they fall back to local tone at the silhouette they become
    // exact black Roblox rectangles; fine construction marks remain more
    // locally owned so they still describe the character.
    float structuralDarkness = mix(
        localDarkness, carriedDarkness,
        mix(0.58, 0.82, clamp(detailClass, 0.0, 1.0)));
    float shadowMass = smoothstep(0.075, 0.62, structuralDarkness);
    // Repeated broad families must not accumulate into an opaque slab across
    // a lit face. Hero parents reserve that plane; medium and fine traces can
    // still describe it while genuine shadow masses remain fully available.
    float litDetail = mix(0.12, 0.34, clamp(detailClass, 0.0, 1.0));
    // Geometric pressure and taper own the endpoint. Multiplying loaded
    // swipes by subjectSupport here was the remaining thick-stroke cut.
    float subjectPass = mix(litDetail, 1.0, shadowMass);
    float role = smoothstep(0.24, 0.76, seedRole);
    // Broad/support subject strokes are graphic construction, not a light
    // response. Fine marks retain the tonal gate; hatching has its own fully
    // light-aware stage below.
    float graphicSubjectPass = mix(1.0, subjectPass,
        clamp(detailClass, 0.0, 1.0));
    return mix(backgroundPass, graphicSubjectPass, role);
}

float linearRibbonField(vec2 p, vec2 authoredFlow, out float rearResult)
{
    if (strength <= 0.0001 || lineThickness <= 0.0001) return 0.0;
    vec2 pixel = (p - vec2(0.5)) * resolution;
    float result = 0.0;
    rearResult = 0.0;
    float support = trajectorySupport(p, authoredFlow);
    float softSupport = mix(0.54, 1.0, support);
    float localSubjectCoverage = sourceCoverage(p);
    vec2 boundsCenter = 0.5 * (subjectBounds.xy + subjectBounds.zw);
    vec2 radialProbe = safeDirection(p - boundsCenter, authoredFlow);
    float inwardCoverage = max(
        sourceCoverage(p - radialProbe * 18.0 / resolution),
        max(sourceCoverage(p - radialProbe * 42.0 / resolution),
            sourceCoverage(p - radialProbe * 78.0 / resolution) * 0.72));
    // Rear strokes live on paper that can see inward to the captured body.
    // They may trail a useful distance beyond any side of the silhouette, but
    // never deposit through the white subject mass itself.
    float rearSilhouetteVisibility = (1.0 - smoothstep(
        0.04, 0.72, localSubjectCoverage)) *
        smoothstep(0.04, 0.62, inwardCoverage);

    // Four correlated passes form one hand-action bundle. More bundles are
    // retained than the rejected sparse center topology, but only a minority
    // own broad loaded parents; the rest remain readable medium/fine marks.
    for (int i = 0; i < 96; ++i) {
        float fi = float(i);
        float activeFamilies = mix(72.0, 84.0, smoothstep(
            240.0, 760.0, min(resolution.x, resolution.y)));
        if (fi >= activeFamilies) continue;

        float group = floor(fi * 0.25);
        float pass = mod(fi, 4.0);
        float familySeed = hash11(fi * 19.17 + salt * 0.071 + 5.0);
        float groupSeed = hash11(group * 59.31 + salt * 0.151 + 37.0);
        float passSeed = hash11(fi * 73.17 + salt * 0.181 + 43.0);
        float packet = hash11(group * 31.73 + salt * 0.277 + 191.0);
        // A hero is one loaded pass inside a minority of bundles, rather than
        // all four members of that bundle becoming broad cloned ribbons.
        float heroClass = (1.0 - step(0.34, groupSeed)) *
                          (1.0 - step(0.5, pass));
        // Needle marks are accents, not the default morphology. Keep only a
        // small keyed subset; the remaining passes retain loaded brush width.
        float fineClass = step(2.5, pass) * step(0.78, groupSeed);
        float supportClass = max(0.0, 1.0 - heroClass - fineClass);
        // Reserve a few complete paper corridors. Randomly deleting members
        // inside every packet creates noise; omitting subordinate bundles as
        // a unit creates the large negative shapes used by drawn impact art.
        float quietFamily = step(0.86, hash11(
            group * 113.71 + salt * 0.117 + 227.0));
        if (quietFamily > 0.5 && heroClass < 0.5) continue;
        // White subject windows are authored between coherent brush groups.
        // Filling every skipped packet produced procedural clutter and erased
        // the reference's large readable negative shapes.
        if (packet < 0.06 && fineClass > 0.5) continue;

        vec2 gesturePrior = authoredFlow;
        float sourceScreen = length((flowSource.xy - vec2(0.5)) * 2.0);
        if (flowSource.w > 0.5 && sourceScreen > 0.04) {
            // The pink control is a source, never a destination. Establish
            // ray polarity before seed relocation so the heel, release and
            // silhouette search all agree: a source left of the subject
            // produces rays travelling right.
            vec2 sourceTrail = safeDirection(
                boundsCenter - flowSource.xy, authoredFlow);
            gesturePrior = sourceTrail;
        }
        vec2 anchorUnit = fract(vec2(
            0.5 + group * 0.754877666 + salt * 0.0137,
            0.5 + group * 0.569840296 + salt * 0.0191));
        vec2 anchorUV = mix(subjectBounds.xy, subjectBounds.zw, anchorUnit);
        vec2 anchorNormal = vec2(-gesturePrior.y, gesturePrior.x);
        float passOffset = (pass - 1.5) * mix(4.0, 13.0, groupSeed);
        float passAdvance = (pass - 1.5) * mix(-3.0, 7.0, passSeed);
        vec2 candidate = clamp(anchorUV +
            (anchorNormal * passOffset + authoredFlow * passAdvance) / resolution,
            subjectBounds.xy, subjectBounds.zw);
        float seedRole;
        vec2 seedMotion;
        vec2 seedNormal;
        vec4 seedData = shadowBiasedSeed(
            candidate, hash11(fi * 47.13 + salt * 0.231 + 181.0),
            seedRole, seedMotion, seedNormal);
        float pointSource = step(0.5, flowSource.w);
        float centeredSourceAmount = subjectCenteredSourceAmount();
        // Centered depth wind uses the same captured face anchor as ordinary
        // wind. Its 3D projection below changes perspective; relocating it to
        // the silhouette would switch to a separate halo topology.
        float roleMotionResponse;
        vec2 roleMotionTarget = motionAwareDirection(
            gesturePrior, seedRole, seedMotion, 1.0, roleMotionResponse);
        // Orientation is undirected; polarity is not. Sign-align the motion
        // axis before steering, then apply the history direction only after
        // the line axis is stable. This removes arbitrary 180-degree turns.
        vec2 directedTrail = -safeDirection(roleMotionTarget, gesturePrior);
        vec2 motionAxis = alignLineAxis(directedTrail, gesturePrior);
        float coherentMotionTurn = atan(
            gesturePrior.x * motionAxis.y -
            gesturePrior.y * motionAxis.x,
            dot(gesturePrior, motionAxis));
        motionAxis = rotateVector(
            gesturePrior, clamp(coherentMotionTurn, -0.43633231, 0.43633231));
        vec2 roleGesture = blendDirection(
            gesturePrior, motionAxis, roleMotionResponse * 0.20);

        // Project the camera-space aerodynamic direction onto the captured
        // surface once per loaded family. Subject motion remains the explicit
        // prior above, while this shapes one deliberate face-anchored gesture.
        float windConfidence;
        vec2 surfaceDirected;
        vec2 seedForm = aerodynamicSurfaceFlow(
            seedData.xy, seedNormal, roleGesture,
            windConfidence, surfaceDirected);
        // Surface flow is an undirected line orientation. Align its sign to
        // the existing gesture instead of flipping the directed trail: the
        // latter made rear-hemisphere edits reverse arbitrary families.
        if (dot(seedForm, roleGesture) < 0.0) seedForm = -seedForm;
        float seedFormDelta = atan(
            roleGesture.x * seedForm.y - roleGesture.y * seedForm.x,
            dot(roleGesture, seedForm));
        seedFormDelta = clamp(seedFormDelta, -0.41887902, 0.41887902);
        vec2 surfaceGesture = rotateVector(
            roleGesture, seedFormDelta * windConfidence *
            smoothstep(0.24, 0.82, seedRole) * 0.18);
        // A 3D pin is a spatial wind source, not a rotated global ruler.
        // Each loaded family takes one source-to-face direction and keeps it
        // for the full stroke; subject motion can bias it without replacing it.
        roleGesture = blendDirection(
            surfaceGesture, motionAxis, roleMotionResponse * 0.20);

        // Families share a bundle turn, then receive a restrained local error.
        // Fine construction passes may diverge farther than loaded mass passes.
        float turnSpan = heroClass * 0.014 + supportClass * 0.030 + fineClass * 0.055;
        float groupTurn = (hash11(group * 83.17 + salt * 0.123) - 0.5) * turnSpan;
        float localTurn = (passSeed - 0.5) * mix(0.008, 0.022, fineClass);
        vec2 familyFlow = rotateVector(roleGesture, groupTurn + localTurn);
        vec2 aerodynamicIntent = mix(
            surfaceDirected, directedTrail,
            smoothstep(0.18, 0.82, roleMotionResponse));
        vec2 directedIntent = mix(
            gesturePrior, aerodynamicIntent,
            max(pointSource * 0.98,
                max(windConfidence,
                    smoothstep(0.02, 0.55, roleMotionResponse))));
        if (dot(familyFlow, directedIntent) < 0.0) familyFlow = -familyFlow;
        // Main impact masses need one readable composition axis. Surface
        // projection contributes a restrained form correction, but may not
        // make each captured face invent an unrelated screen-space heading.
        vec2 sharedAxis = alignLineAxis(gesturePrior, familyFlow);
        familyFlow = blendDirection(
            sharedAxis, alignLineAxis(familyFlow, sharedAxis),
            mix(0.03, 0.08, windConfidence));
        if (centeredSourceAmount > 0.5) {
            // Depth-facing wind is projected independently at every captured
            // anchor. Rear cast converges into the hidden impact; front cast
            // exits through the visible face. This must not collapse back to
            // the shared screen-space ruler used by an off-centre source.
            vec2 localRay = safeDirection(
                seedData.xy - boundsCenter, surfaceDirected);
            localRay *= mix(1.0, -1.0, castBehindAmount());
            vec2 projectedRay = alignLineAxis(surfaceDirected, localRay);
            if (dot(projectedRay, localRay) < 0.0) projectedRay = -projectedRay;
            familyFlow = blendDirection(
                localRay, projectedRay,
                mix(0.42, 0.76, windConfidence));
        }
        vec2 familyNormal = vec2(-familyFlow.y, familyFlow.x);

        float horizontalCap = smoothstep(
            0.08, 0.42, abs(seedNormal.y) - abs(seedNormal.x));
        seedData = shiftSeedTowardTrailing(
            seedData, familyFlow, familySeed);
        if (centeredSourceAmount > 0.5 &&
                (castBehindAmount() > 0.5 || pass >= 1.5)) {
            // A depth halo launches at the last owned radial sample. Rays may
            // cross in front later. In front-cast mode only the rear pair is
            // moved out; the front pair keeps its torso hit before curving
            // into the halo. Rear-cast mode moves every heel behind the form.
            seedData = shiftSeedTowardSilhouette(seedData, familySeed);
        }
        vec2 seedUV = seedData.xy;
        float seedMask = seedData.z;
        float seedDarkness = seedData.w;
        // Main impact gestures are graphic ink, not shaded material. Lighting
        // remains available to hatching, but may never delete or thin the
        // loaded stroke that establishes the action silhouette.
        float seedWeight = seedMask;
        float seedEdgeFacing = smoothstep(0.015, 0.46, length(seedNormal));
        // Rear-axis wind is seen primarily where it wraps the silhouette;
        // front-axis wind may still launch across the visible face.
        seedWeight *= mix(
            1.0, mix(0.48, 1.52, pow(seedEdgeFacing, 1.20)),
            centeredSourceAmount * castBehindAmount());
        if (seedWeight < 0.018) continue;
        float launchChance = mix(0.93, 0.995,
            heroClass + supportClass * 0.72);
        if (hash11(fi * 89.71 + salt * 0.193 + 151.0) > launchChance) continue;

        // Spread is cone aperture only. Preserve the same aerodynamic axis at
        // every value; order the fan by the family's transverse body position
        // so upper/lower strokes open coherently instead of rotating randomly.
        float spreadValue = clamp(haloSpread, 0.0, 1.0);
        float spreadAperture = smoothstep(0.0, 1.0, spreadValue);
        // One coherent sun-ray field owns main-stroke heading. Surface and
        // camera data may change width and depth, never the ray axis. Spread
        // monotonically opens that field: 0 narrow, 0.5 moderate, 1 wide.
        vec2 sideRayAxis = safeDirection(
            boundsCenter - flowSource.xy, gesturePrior);
        // A screen-centered pin still has a depth direction. Project that 3D
        // ray through each sampled surface anchor to construct one halo field.
        vec2 centeredRayAxis = safeDirection(
            (seedUV - boundsCenter) * vec2(
                resolution.x / max(resolution.y, 1.0), 1.0),
            gesturePrior);
        // The radial silhouette supplies topology; the captured surface
        // projection supplies perspective. This is a virtual hemisphere, not
        // a flat screen-space star, so curved head/limb faces turn neighboring
        // families coherently without losing the common sun-ray source.
        vec2 centeredSurfaceAxis = alignLineAxis(seedForm, centeredRayAxis);
        centeredRayAxis = blendDirection(
            centeredRayAxis, centeredSurfaceAxis,
            smoothstep(0.035, 0.72, length(seedNormal)) * 0.68);
        vec2 centeredChannelAxis = alignLineAxis(
            blendDirection(gesturePrior, motionAxis,
                roleMotionResponse * 0.62), gesturePrior);
        // Centered families share a terminal channel, but their captured face
        // projection contributes a restrained launch tangent.  This prevents
        // the whole body collapsing into one screen-space swipe while the
        // low blend keeps separate faces from becoming radial spikes.
        vec2 centeredLaunchAxis = blendDirection(
            centeredChannelAxis,
            alignLineAxis(centeredSurfaceAxis, centeredChannelAxis),
            smoothstep(0.05, 0.72, length(seedNormal)) * 0.38);
        vec2 rayAxis = safeDirection(mix(
            sideRayAxis, centeredLaunchAxis, centeredSourceAmount),
            gesturePrior);
        vec2 rayNormal = vec2(-rayAxis.y, rayAxis.x);
        vec2 boundsHalf = max(
            (subjectBounds.zw - subjectBounds.xy) * 0.5, vec2(1.0e-4));
        float fanHalfSpan = max(
            dot(abs(rayNormal), boundsHalf), 1.0e-4);
        float fanCoordinate = clamp(
            dot(seedUV - boundsCenter, rayNormal) / fanHalfSpan,
            -1.0, 1.0);
        // Spread is a signed perpendicular fan, not a screen-Y rotation.
        // 0.5 deliberately preserves the former 0.0 near-parallel result;
        // 0 converges and 1 opens strongly without reversing into an arrow.
        float spreadLow = smoothstep(0.0, 0.5, spreadValue);
        float spreadHigh = smoothstep(0.5, 1.0, spreadValue);
        float fanSlope = spreadValue < 0.5
            ? mix(-0.12, 0.035, spreadLow)
            : mix(0.035, 0.68, spreadHigh);
        familyFlow = safeDirection(
            rayAxis + rayNormal * fanCoordinate * fanSlope, rayAxis);
        familyFlow = rotateVector(familyFlow,
            groupTurn * 0.18 + localTurn * 0.10);
        // Final local sun-ray lock.  The seed-to-source vector gives every
        // limb the same causal rule while retaining perspective divergence.
        vec2 awayFromPin = safeDirection(mix(
            seedUV - flowSource.xy, centeredChannelAxis,
            centeredSourceAmount), gesturePrior);
        if (dot(familyFlow, awayFromPin) < 0.0) familyFlow = -familyFlow;
        familyNormal = vec2(-familyFlow.y, familyFlow.x);

        vec2 seedPixel = (seedUV - vec2(0.5)) * resolution;
        vec2 relative = pixel - seedPixel;
        float along = dot(relative, familyFlow);
        float across = dot(relative, familyNormal);
        float shortEdge = max(1.0, min(resolution.x, resolution.y));
        float lengthClass = hash11(fi * 17.83 + salt * 0.163 + 9.0);
        float classLength = heroClass * 1.38 + supportClass * 0.96 + fineClass * 0.54;
        float roleLength = mix(1.22, 0.92, seedRole);
        float keyedSubjectResponse = roleMotionResponse *
            smoothstep(0.34, 0.84, seedRole);
        float motionStretch = 1.0 + keyedSubjectResponse *
            mix(0.42, 1.18, lengthClass);
        float depthScale = perspectiveScaleAt(seedUV);
        float forwardLength = shortEdge * mix(0.11, 0.69, strength) *
                              mix(0.70, 1.27, lengthClass) * classLength *
                              roleLength * motionStretch * depthScale;
        float provisionalRear = step(1.5, pass);
        float spreadExpansion = smoothstep(0.5, 1.0, spreadValue);
        forwardLength *= mix(1.0, 1.30, spreadExpansion);
        forwardLength *= mix(0.72, 1.12, provisionalRear);
        forwardLength *= mix(1.0, 0.56, horizontalCap);
        float pinScreenAmount = clamp(length(
            (flowSource.xy - vec2(0.5)) * 2.0), 0.0, 1.0);
        // Depth-facing wind is represented through surface projection,
        // pressure and perspective width. It must not erase eighty percent of
        // the line length merely because its raw XY vector is near zero.
        float directionForeshorten = mix(
            0.72, 1.0, smoothstep(0.04, 0.82, pinScreenAmount));
        forwardLength *= mix(1.0, directionForeshorten, pointSource);
        // Centered depth rays must overlap outside the silhouette; shortening
        // every family here produced the giant empty wedges in the old halo.
        forwardLength *= mix(
            1.0, mix(1.14, 1.24, castBehindAmount()),
            centeredSourceAmount);
        float heelLength = mix(8.0, 30.0, lineThickness) *
                           mix(0.76, 1.20, passSeed) *
                           mix(1.0, 1.46, pow(seedDarkness, 0.70)) *
                           mix(0.82, 1.18, strength);
        vec2 ownedSpan = localOwnedSpan(seedUV, familyFlow);
        // Rear geometry crosses the complete projected body. Compositing hides
        // its middle segment, so it disappears behind the subject and then
        // reappears beyond the opposite silhouette instead of ending there.
        float rearOvershoot = shortEdge * mix(0.035, 0.085, passSeed);
        heelLength = mix(heelLength,
            mix(4.0, 13.0, passSeed), provisionalRear);
        forwardLength = mix(forwardLength,
            max(ownedSpan.y + ownedSpan.x +
                    rearOvershoot * mix(0.82, 1.24, passSeed),
                shortEdge * mix(0.30, 0.52, strength)),
            provisionalRear);
        float gestureLength = max(forwardLength + heelLength, 1.0);
        float strokeT = (along + heelLength) / gestureLength;

        // Brush bristles have deliberately staggered releases beyond t=1.
        // Continue the family centerline through that entire release; clamping
        // at 1 made the final fibers leave a curved body on a straight tangent
        // and created the visible elbow/hook at tapered ends.
        float curveT = clamp(strokeT, 0.0, 1.20);
        // One evaluated trajectory owns the complete local family. Velocity
        // selects its tangent and stretch; signed local acceleration supplies
        // a single quadratic arc. Random families may vary pressure, never
        // invent another large curve or reverse its direction.
        vec2 localVelocity = sourceVelocity(seedUV) - backgroundMotion;
        vec2 localAcceleration = sourceAcceleration(seedUV);
        vec2 coherentVelocity = subjectMotion - backgroundMotion;
        vec2 coherentAcceleration = subjectAcceleration;
        float trajectorySpeed =
            length(localVelocity) / max(velocityScale, 1.0e-6);
        // Preserve the authored motion of the body region that emitted this
        // family.  The old global-average tangent cancelled a punching arm's
        // turn against the slower torso and left long marks almost straight.
        float localTrajectoryWeight = smoothstep(
            0.10, 0.48, length(localVelocity) / max(velocityScale, 1.0e-6));
        vec2 trajectoryVelocity = mix(
            coherentVelocity, localVelocity, localTrajectoryWeight);
        vec2 blendedTrajectoryAcceleration = mix(
            coherentAcceleration, localAcceleration, localTrajectoryWeight);
        vec2 trajectoryTangent = safeDirection(
            trajectoryVelocity, motionAxis);
        vec2 trajectoryNormal = vec2(
            -trajectoryTangent.y, trajectoryTangent.x);
        float lateralAcceleration = dot(
            blendedTrajectoryAcceleration, trajectoryNormal);
        float signedTurn = sign(lateralAcceleration);
        float lateralTurn = abs(lateralAcceleration) /
            max(length(trajectoryVelocity), velocityScale * 0.045);
        float accelerationResponse = smoothstep(0.0025, 0.085, lateralTurn);
        float trajectoryResponse = smoothstep(
            0.035, 0.50, trajectorySpeed) * accelerationResponse *
            smoothstep(0.18, 0.72, seedRole);
        // One quadratic trajectory is shared by the loaded parent and every
        // companion filament. Its handedness comes from v x a, so changing
        // the wind cannot accidentally collapse or reverse a keyed punch arc.
        float trajectoryAlignment = dot(trajectoryNormal, familyNormal);
        float artistMotionInfluence = clamp(
            motionCurveInfluence, 0.0, 1.0);
        // A quadratic centerline keeps increasing its tangent through the
        // release, unlike the former smoothstep envelope whose zero end slope
        // made the brush straighten again.  Scale by actual stroke length so
        // long loaded swipes visibly carry the keyed arc.
        // Curvature is a family-level decision. A weak/noisy motion sample
        // produces a straight gesture; a confident sample bends the complete
        // loaded swipe and all of its bristles on one quadratic centerline.
        // This removes the short hooked release that appeared when a nearly
        // straight body acquired curvature only inside its tapered tip.
        float curveDecision = step(
            0.16, trajectoryResponse * artistMotionInfluence);
        float trajectoryEnvelope = curveT * curveT;
        float trajectoryArc = signedTurn * trajectoryAlignment * gestureLength *
            mix(0.26, 0.52, clamp(trajectorySpeed, 0.0, 1.0)) *
            curveDecision * artistMotionInfluence * trajectoryEnvelope;
        // Projected 3D winding is part of the same family trajectory. At a
        // centered spatial pin, visible-surface normals bend front strokes
        // across the form and rear strokes around the silhouette instead of
        // merely changing a 2D taper.
        vec2 surfaceOutward = safeDirection(
            seedNormal, seedUV - 0.5 * (subjectBounds.xy + subjectBounds.zw));
        float surfaceBendAlignment = dot(familyNormal, surfaceOutward);
        float windingT = clamp((curveT + 0.22) / 1.22, 0.0, 1.0);
        // A face wrap is a mid-span bow: it leaves and rejoins the shared
        // channel. A monotone envelope made every family finish in the same
        // large hook and read as one global direction.
        float windingEnvelope = 4.0 * windingT * (1.0 - windingT);
        float frontWinding = mix(0.52, 1.0, seedEdgeFacing);
        float rearWinding = seedEdgeFacing * 1.24;
        float hemisphereBend = mix(-1.0, 1.0, castBehindAmount());
        float surfaceWindingArc = surfaceBendAlignment * hemisphereBend *
            shortEdge * mix(0.018, 0.055, strength) *
            centeredSourceAmount * mix(
                frontWinding, rearWinding, castBehindAmount()) *
            windingEnvelope;
        float familyArc = trajectoryArc + surfaceWindingArc;
        float sketchT = clamp(curveT, 0.0, 1.0);
        float sketchDeviation = (
            valueNoise(vec2(curveT * 5.1, group * 0.17), salt + 2141.0) -
            0.5) * mix(0.06, 0.44, fineClass + supportClass * 0.45) *
            4.0 * sketchT * (1.0 - sketchT) *
            mix(1.0, 0.22,
                trajectoryResponse * artistMotionInfluence);

        // Spread bends the centerline laterally after launch; it never rotates
        // the whole stroke. The cubic Hermite envelope has zero slope at the
        // heel, so every family leaves on the same aerodynamic tangent before
        // upper/lower anchors peel apart toward their endpoints.
        float spreadEnvelope = curveT * curveT * (3.0 - 2.0 * curveT);
        float screenUpSign = familyNormal.y < 0.0 ? -1.0 : 1.0;
        float fanVariation = mix(0.82, 1.18, groupSeed);
        float fanBend = fanCoordinate * screenUpSign * gestureLength * 0.055 *
            spreadExpansion * fanVariation * spreadEnvelope;
        float familySeparation = passOffset * spreadExpansion *
            mix(0.18, 0.34, groupSeed) * spreadEnvelope;

        float widthSeed = hash11(fi * 67.21 + salt * 0.173 + 29.0);
        float groupWidth = mix(0.84, 1.18,
            hash11(group * 109.31 + salt * 0.137 + 73.0));
        float passWidth = pass < 0.5 ? 1.0 :
                          pass < 1.5 ? 0.84 :
                          pass < 2.5 ? 0.70 : 0.56;
        float classWidth = heroClass * mix(1.12, 1.52, widthSeed) +
                           supportClass * mix(0.72, 1.04, widthSeed) +
                           fineClass * mix(0.30, 0.52, widthSeed);
        float centeredLoad = centeredSourceAmount *
            (1.0 - step(0.62, groupSeed)) * (1.0 - step(2.5, pass));
        classWidth *= mix(1.0, 1.38, centeredLoad);
        float baseWidth = mix(0.56, 25.0, pow(lineThickness, 1.08));
        float shadowMass = 1.12;
        float roleWidth = mix(1.16, 0.96, seedRole);
        float motionLoading = mix(1.0, 1.16, roleMotionResponse);
        float halfWidth = max(0.28, baseWidth * classWidth * groupWidth *
                              passWidth * shadowMass * roleWidth * motionLoading *
                              pow(depthScale, 0.62));
        float castBehind = castBehindAmount();
        float depthPerspective = mix(
            mix(1.16, 0.70, curveT),
            mix(0.70, 1.34, curveT), castBehind);
        halfWidth *= mix(1.0, depthPerspective, pointSource);
        halfWidth *= mix(
            1.0, mix(0.82, 0.92, castBehind), centeredSourceAmount);
        // A broad swipe must remain a swipe. Bounding half-width by gesture
        // length prevents short candidates from becoming black rectangles on
        // heads, shoulders, and blocky limbs.
        halfWidth *= mix(1.0, 0.72, horizontalCap);
        halfWidth = min(halfWidth, max(
            mix(1.8, 3.4, supportClass + heroClass),
            gestureLength * mix(0.062, 0.086, heroClass)));
        // familyFlow already owns the directed 3D polarity. Reversing the
        // pressure parameter again would cancel the front/rear distinction.
        float pressureT = strokeT;
        float stroke = motionFamilyDeposit(
            across - familyArc - sketchDeviation - fanBend - familySeparation,
            halfWidth, pressureT,
            0.78 / gestureLength, passSeed, keyedSubjectResponse * 0.18);
        // Shorter low-pressure companions occupy the paper gaps left between
        // loaded swipes. They share the family intent but have unique length,
        // offset and tooth, producing a dense hierarchy rather than clones.
        float fillLength = gestureLength * mix(0.34, 0.64,
            hash11(fi * 131.17 + salt * 0.157 + 409.0));
        float fillT = (along + heelLength * 0.42) / max(fillLength, 1.0);
        float fillOffset = (hash11(fi * 149.31 + salt * 0.181 + 431.0) - 0.5) *
            max(1.2, halfWidth * 1.35);
        float fill = filamentSwipeDeposit(
            across - familyArc - sketchDeviation * 0.46 -
            fanBend * 0.92 - familySeparation * 0.78 +
            fillOffset,
            max(0.26, halfWidth * mix(0.055, 0.16, passSeed)),
            fillT, passSeed + 433.0);
        float fillBLength = gestureLength * mix(0.22, 0.48,
            hash11(fi * 167.11 + salt * 0.193 + 457.0));
        float fillBT = (along + heelLength * 0.24) /
            max(fillBLength, 1.0);
        float fillBOffset = -sign(fillOffset + 1.0e-4) *
            max(1.0, halfWidth * mix(0.72, 1.62, passSeed));
        float fillB = filamentSwipeDeposit(
            across - familyArc - sketchDeviation * 0.31 -
            fanBend * 0.86 - familySeparation * 0.62 +
            fillBOffset,
            max(0.22, halfWidth * mix(0.035, 0.095, passSeed)),
            fillBT, passSeed + 461.0);
        // Compact loaded passes occupy the white shelves between long hero
        // releases. They inherit the final away-from-pin flow and depth owner.
        float compactLength = gestureLength * mix(0.24, 0.46,
            hash11(fi * 181.73 + salt * 0.167 + 479.0));
        float compactT = (along + heelLength * 0.58) /
            max(compactLength, 1.0);
        float compactOffset = (hash11(
            fi * 197.11 + salt * 0.191 + 491.0) - 0.5) *
            halfWidth * 1.55;
        float compact = motionFamilyDeposit(
            across - familyArc - fanBend * 0.72 + compactOffset,
            max(0.80, halfWidth * mix(0.34, 0.52, passSeed)),
            compactT, 0.78 / max(compactLength, 1.0),
            passSeed + 487.0, keyedSubjectResponse * 0.10);
        stroke = 1.0 - (1.0 - stroke) *
            (1.0 - fill * 0.58) *
            (1.0 - fillB * 0.46) *
            (1.0 - compact * 0.74);

        float detailClass = clamp(fineClass + supportClass * 0.46, 0.0, 1.0);
        float readability = heroReadabilityGate(
            p, familyFlow, seedRole, detailClass, familySeed);
        readability = 1.0;
        float centeredReadability = mix(0.46, 0.94, detailClass);
        readability = mix(
            readability, max(readability, centeredReadability),
            centeredSourceAmount);
        // Rear-centered trajectories are revealed in the paper immediately
        // outside the captured silhouette. The ordinary subject readability
        // gate correctly protects empty background elsewhere, but must not
        // classify this designed corona as stray background detail.
        float coronaReadability = mix(0.54, 0.96, detailClass) *
            rearSilhouetteVisibility;
        readability = mix(
            readability, max(readability, coronaReadability),
            centeredSourceAmount * castBehindAmount());
        float depthGuard = mix(0.76, 1.0, support) * readability;
        float familyOpacity = heroClass * mix(0.70, 0.92, passSeed) +
                              supportClass * mix(0.40, 0.72, passSeed) +
                              fineClass * mix(0.22, 0.50, passSeed);
        familyOpacity = mix(
            familyOpacity, max(familyOpacity, 0.78), centeredLoad);
        float intensityDeposit = mix(0.24, 1.0, pow(strength, 0.62));
        float rearOcclusion = mix(
            1.0,
            mix(0.12, 1.0, rearSilhouetteVisibility),
            centeredSourceAmount * castBehind);
        stroke *= familyOpacity * intensityDeposit *
                  mix(0.68, 1.0, seedWeight) *
                  mix(depthGuard * softSupport * rearOcclusion,
                      1.0, provisionalRear) *
                  mix(1.0, 1.42, centeredSourceAmount * castBehind);
        // Depth ownership is assigned once at the emitter anchor. Families
        // launched from the trailing/outward face belong below the subject;
        // interior and camera-facing families remain above it. This preserves
        // simultaneous front ink and rear trails instead of flattening the
        // entire drawing into the selected Cast Behind state.
        float trailingFace = smoothstep(
            -0.04, 0.38, -dot(seedNormal, familyFlow));
        float pairedRear = step(1.5, pass);
        float rearFamily = mix(
            pairedRear, 1.0, centeredSourceAmount * castBehindAmount());
        rearResult = 1.0 - (1.0 - rearResult) *
            (1.0 - stroke * rearFamily);
        result = 1.0 - (1.0 - result) *
            (1.0 - stroke * (1.0 - rearFamily));
    }
    return clamp(result, 0.0, 1.0);
}

float silhouetteTrailAccentField(vec2 p, vec2 flow, out float frontResult)
{
    if (strength <= 0.0001 || lineThickness <= 0.0001) return 0.0;
    vec2 pixel = (p - vec2(0.5)) * resolution;
    float result = 0.0;
    frontResult = 0.0;
    float shortEdge = max(1.0, min(resolution.x, resolution.y));
    vec2 subjectCenter = 0.5 * (subjectBounds.xy + subjectBounds.zw);
    vec2 boundsSpan = subjectBounds.zw - subjectBounds.xy;
    for (int i = 0; i < 56; ++i) {
        float fi = float(i);
        float group = floor(fi * 0.5);
        float member = mod(fi, 2.0);
        float accentSeed = hash11(fi * 43.17 + salt * 0.127 + 601.0);
        vec2 seedUV = subjectCenter;
        float found = 0.0;
        float horizontalScan = 1.0 - step(38.0, fi);
        // Irrational low-discrepancy placement covers the full silhouette
        // without twelve shared horizontal shelves or barcode gutters.
        float laneT = clamp(fract(
            0.5 + group * 0.618033989 + salt * 0.00731), 0.025, 0.975);
        float side = member < 0.5 ? 1.0 : -1.0;
        // Alternating left/right and top/bottom scans guarantee the annotated
        // silhouette bands instead of relying on radial rays from the torso.
        for (int j = 0; j < 12; ++j) {
            float scanT = (float(j) + 0.35) / 12.0;
            vec2 horizontalProbe = vec2(
                mix(subjectCenter.x, side > 0.0 ? subjectBounds.x : subjectBounds.z,
                    scanT),
                subjectBounds.y + boundsSpan.y * laneT);
            vec2 verticalProbe = vec2(
                subjectBounds.x + boundsSpan.x * laneT,
                mix(subjectCenter.y, side > 0.0 ? subjectBounds.y : subjectBounds.w,
                    scanT));
            vec2 probe = mix(verticalProbe, horizontalProbe, horizontalScan);
            if (sourceCoverage(probe) > 0.075) {
                seedUV = probe;
                found = 1.0;
            }
        }
        if (found < 0.5) continue;
        vec2 seedNormal = sourceSurfaceNormalXY(seedUV);
        vec2 accentFlow = safeDirection(
            subjectCenter - flowSource.xy, safeDirection(flow, vec2(-1.0, 0.0)));
        float windConfidence;
        vec2 directedFlow;
        vec2 projected = aerodynamicSurfaceFlow(
            seedUV, seedNormal, accentFlow, windConfidence, directedFlow);
        // The pin owns travel direction. Face data selects cap aspect and
        // depth ownership but may not rotate rear strokes onto the torso.
        float topBottomFace = 1.0 - horizontalScan;
        float spreadValue = clamp(haloSpread, 0.0, 1.0);
        float centeredSourceAmount = subjectCenteredSourceAmount();
        accentFlow = safeDirection(mix(
            subjectCenter - flowSource.xy,
            (seedUV - subjectCenter) * vec2(
                resolution.x / max(resolution.y, 1.0), 1.0),
            centeredSourceAmount), flow);
        vec2 accentFanNormal = vec2(-accentFlow.y, accentFlow.x);
        float accentFanSpan = max(
            dot(abs(accentFanNormal), boundsSpan * 0.5), 1.0e-5);
        float faceCoordinate = clamp(dot(
            seedUV - subjectCenter, accentFanNormal) / accentFanSpan,
            -1.0, 1.0);
        float spreadLow = smoothstep(0.0, 0.5, spreadValue);
        float spreadHigh = smoothstep(0.5, 1.0, spreadValue);
        float fanSlope = spreadValue < 0.5
            ? mix(-0.12, 0.035, spreadLow)
            : mix(0.035, 0.68, spreadHigh);
        accentFlow = safeDirection(accentFlow + accentFanNormal *
            faceCoordinate * fanSlope, accentFlow);
        accentFlow = rotateVector(accentFlow,
            (accentSeed - 0.5) * 0.032);
        vec2 accentAway = safeDirection(
            seedUV - flowSource.xy, vec2(1.0, 0.0));
        if (dot(accentFlow, accentAway) < 0.0) accentFlow = -accentFlow;
        // Preserve one line axis, but choose the polarity that exits this
        // particular silhouette face. The loaded heel remains just inside
        // the subject and the tapered fibers occupy the blue-marked paper.
        vec2 accentNormal = vec2(-accentFlow.y, accentFlow.x);
        vec2 relative = pixel - (seedUV - vec2(0.5)) * resolution;
        float along = dot(relative, accentFlow);
        float across = dot(relative, accentNormal);
        // Do not align every contact/release point on the same scan column.
        // Independent longitudinal phase and length destroy the barcode-like
        // white gutters while keeping the family directions coherent.
        float longitudinalPhase = (hash11(
            fi * 157.37 + salt * 0.173 + 751.0) - 0.5) *
            shortEdge * 0.105;
        along += longitudinalPhase;
        float lengthPixels = shortEdge * mix(0.15, 0.36,
            hash11(fi * 71.31 + salt * 0.181 + 613.0)) *
            mix(0.72, 1.0, strength);
        float heel = mix(7.0, 18.0, lineThickness) *
            mix(0.84, 1.12, accentSeed);
        float rearOwner = step(0.5, member);
        vec2 ownedSpan = localOwnedSpan(seedUV, accentFlow);
        float rearOvershoot = shortEdge * mix(0.035, 0.078, accentSeed);
        heel = mix(heel, mix(4.0, 11.0, accentSeed), rearOwner);
        lengthPixels = mix(lengthPixels,
            ownedSpan.y + ownedSpan.x +
                rearOvershoot * mix(0.84, 1.18, accentSeed),
            rearOwner);
        float gestureLength = max(lengthPixels + heel, 1.0);
        float strokeT = (along + heel) / gestureLength;
        float memberLoad = member < 0.5 ? 1.0 : 0.68;
        float halfWidth = mix(1.5, 12.8, pow(lineThickness, 0.82)) *
            memberLoad *
            mix(0.82, 1.16, accentSeed);
        halfWidth *= mix(1.0, 0.48, topBottomFace);
        halfWidth = min(halfWidth, gestureLength * 0.145);
        float loaded = motionFamilyDeposit(
            across, halfWidth, strokeT,
            0.78 / gestureLength, accentSeed + 617.0, 0.0);
        float filament = filamentSwipeDeposit(
            across + halfWidth * mix(-0.62, 0.62, accentSeed),
            max(0.34, halfWidth * 0.28),
            strokeT / mix(0.72, 0.90, accentSeed), accentSeed + 641.0);
        float accent = 1.0 - (1.0 - loaded) *
            (1.0 - filament * mix(0.42, 0.68, memberLoad));
        // The anchor and polarity already establish backside ownership.
        // Re-clipping every output pixel against the raster silhouette chops
        // a tapered brush into square mask fragments. Keep the complete hand
        // gesture and use its pressure envelope as the only endpoint shape.
        accent *= mix(0.88, 1.0, strength);
        accent *= mix(0.46, 0.68, strength);
        float frontOwner = (1.0 - step(0.5, member)) *
            (1.0 - centeredSourceAmount * castBehindAmount());
        frontResult = 1.0 - (1.0 - frontResult) *
            (1.0 - accent * frontOwner);
        result = 1.0 - (1.0 - result) *
            (1.0 - accent * (1.0 - frontOwner));
    }
    return clamp(result, 0.0, 1.0);
}

float frontNookFillField(vec2 p, vec2 flow)
{
    vec2 pixel = (p - vec2(0.5)) * resolution;
    vec2 boundsSpan = subjectBounds.zw - subjectBounds.xy;
    vec2 center = 0.5 * (subjectBounds.xy + subjectBounds.zw);
    float result = 0.0;
    float shortEdge = max(1.0, min(resolution.x, resolution.y));
    for (int i = 0; i < 48; ++i) {
        float fi = float(i);
        float column = mod(fi, 6.0);
        float row = floor(fi / 6.0);
        vec2 cell = (vec2(column, row) + vec2(0.5)) / vec2(6.0, 8.0);
        vec2 jitter = vec2(
            hash11(fi * 37.17 + salt * 0.113 + 811.0),
            hash11(fi * 61.73 + salt * 0.157 + 823.0)) - vec2(0.5);
        vec2 seedUV = subjectBounds.xy + boundsSpan *
            clamp(cell + jitter * vec2(0.085, 0.060), vec2(0.02), vec2(0.98));
        float owned = sourceCoverage(seedUV);
        if (owned < 0.10) continue;
        float seed = hash11(fi * 79.31 + salt * 0.181 + 839.0);
        float edgeFamily = step(0.46, seed);
        vec4 edgeSeed = shiftSeedTowardSilhouette(
            vec4(seedUV, owned, 0.72), seed);
        seedUV = mix(seedUV, edgeSeed.xy, edgeFamily);
        // Curved faces need both rim-loaded and interior-loaded actions. The
        // projected normal changes pressure only; it never rotates the ray.
        float normalReach = length(sourceSurfaceNormalXY(seedUV));
        float edgeEvidence = mix(
            mix(0.58, 0.92, smoothstep(0.0, 0.42, normalReach)),
            smoothstep(0.025, 0.42, normalReach), edgeFamily);
        float centeredSourceAmount = subjectCenteredSourceAmount();
        vec2 familyFlow = safeDirection(mix(
            center - flowSource.xy,
            (seedUV - center) * vec2(
                resolution.x / max(resolution.y, 1.0), 1.0),
            centeredSourceAmount), flow);
        vec2 fillFanNormal = vec2(-familyFlow.y, familyFlow.x);
        float fillFanSpan = max(
            dot(abs(fillFanNormal), boundsSpan * 0.5), 1.0e-5);
        float fanCoordinate = clamp(dot(seedUV - center, fillFanNormal) /
            fillFanSpan, -1.0, 1.0);
        float spreadValue = clamp(haloSpread, 0.0, 1.0);
        float spreadLow = smoothstep(0.0, 0.5, spreadValue);
        float spreadHigh = smoothstep(0.5, 1.0, spreadValue);
        float fanSlope = spreadValue < 0.5
            ? mix(-0.12, 0.035, spreadLow)
            : mix(0.035, 0.68, spreadHigh);
        familyFlow = safeDirection(familyFlow + fillFanNormal *
            fanCoordinate * fanSlope, familyFlow);
        familyFlow = rotateVector(familyFlow, (seed - 0.5) * 0.018);
        vec2 normal = vec2(-familyFlow.y, familyFlow.x);
        vec2 relative = pixel - (seedUV - vec2(0.5)) * resolution;
        float along = dot(relative, familyFlow);
        float across = dot(relative, normal);
        float lengthPixels = shortEdge * mix(0.055, 0.135, seed);
        float heel = mix(7.0, 17.0, lineThickness);
        float strokeT = (along + heel) / max(lengthPixels + heel, 1.0);
        float halfWidth = mix(2.6, 11.8, pow(lineThickness, 0.92)) *
            mix(0.78, 1.22, seed) * mix(1.08, 0.94, edgeFamily);
        float stroke = motionFamilyDeposit(
            across, halfWidth, strokeT,
            0.78 / max(lengthPixels + heel, 1.0), seed + 853.0, 0.0);
        result = 1.0 - (1.0 - result) *
            (1.0 - stroke * mix(0.62, 0.92, strength) * edgeEvidence);
    }
    return clamp(result, 0.0, 1.0);
}

float silhouetteEmitterMode()
{
    float pointSource = step(0.5, flowSource.w);
    vec2 pin = clamp(flowSource.xy, vec2(0.0), vec2(1.0));
    vec2 neighborhood = vec2(34.0) / max(resolution, vec2(1.0));
    float nearbySubject = texture(subjectTex, pin).r;
    nearbySubject = max(nearbySubject, texture(subjectTex,
        clamp(pin + vec2(neighborhood.x, 0.0), vec2(0.0), vec2(1.0))).r);
    nearbySubject = max(nearbySubject, texture(subjectTex,
        clamp(pin - vec2(neighborhood.x, 0.0), vec2(0.0), vec2(1.0))).r);
    nearbySubject = max(nearbySubject, texture(subjectTex,
        clamp(pin + vec2(0.0, neighborhood.y), vec2(0.0), vec2(1.0))).r);
    nearbySubject = max(nearbySubject, texture(subjectTex,
        clamp(pin - vec2(0.0, neighborhood.y), vec2(0.0), vec2(1.0))).r);
    vec2 centerDelta = (flowSource.xy - vec2(0.5)) *
        vec2(resolution.x / max(resolution.y, 1.0), 1.0);
    float centeredPin = 1.0 - smoothstep(0.10, 0.30, length(centerDelta));
    // The blocked halo is a deliberate center-source topology. A pin merely
    // passing near a limb must keep the aerodynamic linear field; otherwise
    // ordinary side/behind edits unexpectedly explode into a radial drawing.
    return pointSource * step(0.62, centeredPin);
}

float silhouetteEmitterRibbonField(vec2 p, out float edgeHatching)
{
    edgeHatching = 0.0;
    if (strength <= 0.0001 || lineThickness <= 0.0001) return 0.0;
    vec2 pixel = (p - vec2(0.5)) * resolution;
    float shortEdge = max(1.0, min(resolution.x, resolution.y));
    float searchRadius = length(resolution) * 0.58;
    float result = 0.0;

    // A pin over the subject emits clustered families from the captured
    // silhouette. Group centers cover the full boundary while four related
    // members provide a broad/support/fine hierarchy instead of equal spikes.
    for (int i = 0; i < 32; ++i) {
        float fi = float(i);
        float activeRays = mix(24.0, 32.0, smoothstep(
            240.0, 760.0, min(resolution.x, resolution.y)));
        if (fi >= activeRays) continue;
        float group = floor(fi * 0.25);
        float member = mod(fi, 4.0);
        float groupSeed = hash11(group * 83.17 + salt * 0.151 + 197.0);
        float familySeed = hash11(fi * 41.17 + salt * 0.173 + 223.0);
        float memberAngle = (member - 1.5) * mix(0.026, 0.068, groupSeed);
        float theta = group * 2.39996323 + salt * 0.013 +
                      (groupSeed - 0.5) * 0.18 + memberAngle;
        vec2 radialFlow = vec2(cos(theta), sin(theta));
        vec2 edgeUV = flowSource.xy;
        float found = 0.0;
        float stepPixels = searchRadius / 10.0;
        for (int j = 0; j < 10; ++j) {
            float radius = (float(j) + 0.42) * stepPixels;
            vec2 probe = flowSource.xy + radialFlow * radius / resolution;
            float owned = texture(subjectTex,
                clamp(probe, vec2(0.0), vec2(1.0))).r;
            if (owned > 0.075) {
                edgeUV = probe;
                found = 1.0;
            }
        }
        if (found < 0.5) continue;
        // Two bounded refinements place the heel near the outermost owned
        // sample rather than a coarse ray-march shelf.
        vec2 refineA = edgeUV + radialFlow * stepPixels * 0.50 / resolution;
        if (texture(subjectTex, clamp(refineA, vec2(0.0), vec2(1.0))).r > 0.075)
            edgeUV = refineA;
        vec2 refineB = edgeUV + radialFlow * stepPixels * 0.25 / resolution;
        if (texture(subjectTex, clamp(refineB, vec2(0.0), vec2(1.0))).r > 0.075)
            edgeUV = refineB;

        // The silhouette blocks a spatial wind source in both hemispheres.
        // Cast Behind changes depth ownership and pressure, not the projected
        // radial axis, so the halo cannot implode or reverse at the center.
        vec2 travelFlow = radialFlow;
        float passTurn = (hash11(fi * 73.31 + salt * 0.191) - 0.5) * 0.070;
        vec2 familyFlow = rotateVector(travelFlow, passTurn);
        vec2 familyNormal = vec2(-familyFlow.y, familyFlow.x);
        vec2 seedPixel = (edgeUV - vec2(0.5)) * resolution;
        vec2 relative = pixel - seedPixel;
        float along = dot(relative, familyFlow);
        float across = dot(relative, familyNormal);

        float motionResponse;
        vec2 motionTarget = motionAwareDirection(
            familyFlow, 1.0, subjectMotion, 1.0, motionResponse);
        float motionTurn = angleDifference(
            atan(familyFlow.y, familyFlow.x),
            atan(motionTarget.y, motionTarget.x));
        float lengthSeed = hash11(fi * 17.83 + salt * 0.163 + 9.0);
        float depthScale = hemisphereStrokeScale(
            edgeUV, sourceSurfaceNormalXY(edgeUV));
        float forwardLength = shortEdge * mix(0.10, 0.54, strength) *
            mix(0.58, 1.34, lengthSeed) *
            (1.0 + motionResponse * mix(0.24, 0.78, lengthSeed)) *
            depthScale;
        float heelLength = mix(5.0, 18.0, lineThickness) *
            mix(0.72, 1.24, familySeed);
        float gestureLength = max(forwardLength + heelLength, 1.0);
        float strokeT = (along + heelLength) / gestureLength;
        float curveT = clamp(strokeT, 0.0, 1.0);
        float curveEnvelope = curveT * curveT * (3.0 - 2.0 * curveT);
        float keyedMotionArc = sin(motionTurn) * motionResponse * shortEdge *
            mix(0.030, 0.072, familySeed) * curveEnvelope;
        float handArc = (hash11(fi * 97.13 + salt * 0.109) - 0.5) *
            mix(0.35, 2.8, strength) * curveEnvelope;
        float spreadSigned = clamp(haloSpread, 0.0, 1.0) * 2.0 - 1.0;
        float spreadOffset = along * tan(
            memberAngle * spreadSigned * 0.92) * curveEnvelope;

        float widthSeed = hash11(fi * 67.21 + salt * 0.173 + 29.0);
        float heroClass = 1.0 - step(0.5, member);
        float fineClass = step(2.5, member);
        float supportClass = max(0.0, 1.0 - heroClass - fineClass);
        float classWidth = heroClass * mix(1.18, 1.62, widthSeed) +
                           supportClass * mix(0.54, 1.02, widthSeed) +
                           fineClass * mix(0.18, 0.38, widthSeed);
        float halfWidth = mix(0.42, 18.5, pow(lineThickness, 1.08)) *
            classWidth;
        float castBehind = castBehindAmount();
        float depthPerspective = mix(
            mix(1.18, 0.64, curveT),
            mix(0.62, 1.42, curveT), castBehind);
        halfWidth *= depthPerspective;
        float pressureT = mix(strokeT, 1.0 - strokeT, castBehind);
        float stroke = motionFamilyDeposit(
            across - handArc - keyedMotionArc - spreadOffset,
            halfWidth, pressureT,
            0.78 / gestureLength, familySeed, motionResponse * 0.14);
        // The same edge anchor emits a shorter, lighter pencil trace. This is
        // the 3D-following hatch/feather layer; it does not reuse the global
        // linear lane frame or bend one hatch continuously around the body.
        float accentLength = forwardLength * mix(0.30, 0.64,
            hash11(fi * 127.17 + salt * 0.157 + 367.0));
        float accentGesture = max(accentLength + heelLength * 0.55, 1.0);
        float accentT = (along + heelLength * 0.55) / accentGesture;
        accentT = mix(accentT, 1.0 - accentT, castBehind);
        float accentOffset = mix(-1.8, 1.8,
            hash11(fi * 149.11 + salt * 0.181 + 389.0));
        float edgeTrace = filamentSwipeDeposit(
            across - handArc * 0.42 - keyedMotionArc * 0.58 -
            spreadOffset * 0.72 + accentOffset,
            mix(0.28, 1.18, familySeed), accentT, familySeed + 401.0);
        edgeHatching = 1.0 - (1.0 - edgeHatching) *
            (1.0 - edgeTrace * mix(0.34, 0.68, familySeed));
        float familyOpacity = mix(0.58, 0.98,
            hash11(fi * 23.11 + salt * 0.223 + 41.0));
        stroke *= familyOpacity * mix(0.28, 1.0, pow(strength, 0.62));
        result = 1.0 - (1.0 - result) * (1.0 - stroke);
    }
    return clamp(result, 0.0, 1.0);
}

float frameEdgeDistance(vec2 outward)
{
    vec2 focusPixel = focus * resolution;
    vec2 safeRay = safeDirection(outward, vec2(1.0, 0.0));
    float tx = safeRay.x > 0.0
        ? (resolution.x - focusPixel.x) / max(safeRay.x, 1.0e-6)
        : -focusPixel.x / min(safeRay.x, -1.0e-6);
    float ty = safeRay.y > 0.0
        ? (resolution.y - focusPixel.y) / max(safeRay.y, 1.0e-6)
        : -focusPixel.y / min(safeRay.y, -1.0e-6);
    return max(1.0, min(tx, ty));
}

float radialCoreGate(vec2 delta)
{
    float shortEdge = max(1.0, min(resolution.x, resolution.y));
    float radius = length(delta);
    float a = atan(delta.y, delta.x);
    float primaryLobes = pow(abs(cos(a * 2.0)), 7.0);
    float irregular = valueNoise(
        vec2(cos(a), sin(a)) * 3.7 + vec2(salt * 0.013),
        salt + 2861.0);
    float threshold = clamp(radialThreshold, 0.0, 1.0);
    float thresholdResponse = threshold * threshold * (3.0 - 2.0 * threshold);
    float baseRadius = shortEdge * mix(0.006, 0.168, thresholdResponse);
    float boundary = baseRadius * mix(0.72, 1.34, primaryLobes) *
        mix(0.86, 1.14, irregular);
    float feather = max(4.0, shortEdge * mix(0.026, 0.108,
        thresholdResponse));
    // Deposit ink gradually outside the protected burst.  The broad band
    // avoids a pasted-on white star with a hard black ring.
    float pressure = smoothstep(boundary - feather * 0.36,
                                boundary + feather * 1.72, radius);
    float graphiteFeather = mix(0.70, 1.0, valueNoise(
        vec2(a * 2.7, radius * 0.026), salt + 2879.0));
    return pow(pressure, 1.12) * mix(0.82, 1.0, graphiteFeather);
}

float radialVoidGate(vec2 delta)
{
    float shortEdge = max(1.0, min(resolution.x, resolution.y));
    float radius = length(delta);
    float a = atan(delta.y, delta.x) - radialTwirlOffset(radius);
    float threshold = clamp(radialThreshold, 0.0, 1.0);
    float response = threshold * threshold * (3.0 - 2.0 * threshold);
    // Threshold moves the heels of individual sunray families away from the
    // emitter.  It no longer merely inflates one four-lobed white plate.
    float wrapped = fract((a + 3.14159265) / 6.28318531);
    float cells = 23.0;
    float cellCoord = wrapped * cells;
    float cell = floor(cellCoord);
    float local = fract(cellCoord) - 0.5;
    float cellSeed = hash11(mod(cell, cells) * 47.31 + salt * 0.071);
    float rayProfile = 1.0 - smoothstep(
        mix(0.08, 0.22, cellSeed), mix(0.25, 0.48, cellSeed), abs(local));
    float heel = shortEdge * response * mix(0.055, 0.27, cellSeed) *
        rayProfile;
    float heelFeather = max(2.0, shortEdge * mix(0.010, 0.035, response));
    float rayGate = smoothstep(heel - heelFeather,
                               heel + heelFeather, radius);
    return radialCoreGate(delta) * rayGate;
}

float radialHairlineLayer(vec2 delta, float radius, float polarAngle,
                          float lineCount, float layerSeed,
                          float widthScale)
{
    float shortEdge = max(1.0, min(resolution.x, resolution.y));
    // Invert the twirl before choosing an angular cell.  Selecting the cell
    // from the already-twirled angle made high values miss most cells on one
    // side of the frame.  This coordinate transform keeps the complete ray
    // field populated while bending every ray coherently.
    float lookupTwirl = radialTwirlOffset(radius);
    float lookupAngle = polarAngle - lookupTwirl;
    // Wrap before cell selection so the same +/-PI ray cannot expose a
    // straight family discontinuity at strong Twirl values.
    float wrappedAngle = fract(
        (lookupAngle + 3.14159265) / 6.28318531);
    float angularCell = floor(wrappedAngle * lineCount);
    float cellSeed = hash11(angularCell * 37.17 + layerSeed + salt * 0.071);
    float centerAngle = (angularCell + 0.5) / lineCount * 6.28318531 -
        3.14159265 + (cellSeed - 0.5) * 4.6 / lineCount;
    vec2 baseRay = vec2(cos(centerAngle), sin(centerAngle));
    float edgeRadius = frameEdgeDistance(baseRay);
    float pathT = clamp(radius / max(edgeRadius, 1.0), 0.0, 1.0);
    vec2 guideUV = clamp(focus + baseRay * min(radius, shortEdge * 0.26) /
        resolution, vec2(0.0), vec2(1.0));
    float motionResponse;
    vec2 target = motionAwareDirection(
        baseRay, sourceRole(guideUV), sourceVelocity(guideUV), 0.88,
        motionResponse);
    float coherentTurn = angleDifference(centerAngle, atan(target.y, target.x));
    float curveEnvelope = pathT * pathT * (3.0 - 2.0 * pathT);
    centerAngle += coherentTurn * motionResponse * curveEnvelope *
        clamp(motionCurveInfluence, 0.0, 1.0);
    centerAngle += lookupTwirl;
    float across = abs(angleDifference(polarAngle, centerAngle)) *
        max(radius, 1.0);
    float widthSeed = hash11(angularCell * 71.31 + layerSeed * 1.91);
    float width = mix(0.34, 2.25, widthSeed * widthSeed) * widthScale *
        mix(0.62, 1.38, pow(lineThickness, 0.72));
    float aa = max(0.72, fwidth(across) * 0.82);
    float line = 1.0 - smoothstep(width, width + aa, across);
    float radialT = radius / max(length(resolution), 1.0);
    float start = mix(0.0, 0.095, hash11(
        angularCell * 19.73 + layerSeed * 3.17));
    float pressure = smoothstep(start, start + 0.028, radialT) *
        (1.0 - smoothstep(0.91, 1.12, radialT));
    float reversedPressure = smoothstep(start, start + 0.028, 1.0 - radialT) *
        (1.0 - smoothstep(0.91, 1.12, 1.0 - radialT));
    pressure = mix(pressure, reversedPressure, castBehindAmount());
    float handContact = valueNoise(
        vec2(radialT * mix(11.0, 29.0, cellSeed), angularCell * 0.17),
        layerSeed + salt + 2203.0);
    float core = smoothstep(shortEdge * 0.002, shortEdge * 0.025, radius);
    float sectorRhythm = 0.58 + 0.20 * sin(centerAngle * 3.0 + salt * 0.019) +
        0.13 * sin(centerAngle * 7.0 - salt * 0.011);
    float sectorContact = smoothstep(0.30, 0.76,
        sectorRhythm + (cellSeed - 0.5) * 0.32);
    return line * pressure * core * mix(0.42, 1.0, handContact) *
        mix(0.34, 1.0, sectorContact) * radialVoidGate(delta);
}

float radialHairlineField(vec2 delta, float radius, float polarAngle)
{
    float fine = radialHairlineLayer(
        delta, radius, polarAngle, 233.0, 1301.0, 0.52);
    float medium = radialHairlineLayer(
        delta, radius, polarAngle, 149.0, 1459.0, 0.86);
    float loaded = radialHairlineLayer(
        delta, radius, polarAngle, 89.0, 1601.0, 1.45);
    float field = 1.0 - (1.0 - fine * 0.62) *
        (1.0 - medium * 0.74) * (1.0 - loaded * 0.58);
    // The fine family must inherit the character morphology too. Without
    // this support gate, hairlines rebuild a uniform polar cage after the
    // loaded ribbons have already been shaped by the silhouette.
    vec2 p = focus + delta / max(resolution, vec2(1.0));
    vec2 radial = safeDirection(delta, vec2(cos(polarAngle), sin(polarAngle)));
    // Seed directions still inherit the captured subject topology, but final
    // rays are not clipped by its dilated support field. Clipping here drew
    // an obvious character-radius ring in the surrounding paper.
    return field * 0.96 * pow(clamp(strength, 0.0, 1.0), 0.86);
}

float radialLegacyPolarField(vec2 p)
{
    if (strength <= 0.0001 || lineThickness <= 0.0001) return 0.0;
    vec2 delta = (p - focus) * resolution;
    float radius = length(delta);
    float polarAngle = atan(delta.y, delta.x);
    float shortEdge = max(1.0, min(resolution.x, resolution.y));
    float coreRadius = max(1.0, shortEdge * 0.0022);
    float result = 0.0;
    for (int i = 0; i < 96; ++i) {
        float fi = float(i);
        float activeCount = mix(72.0, 96.0, smoothstep(
            240.0, 760.0, min(resolution.x, resolution.y)));
        if (fi >= activeCount) continue;
        float group = floor(fi * 0.25);
        float pass = mod(fi, 4.0);
        float groupSeed = hash11(group * 61.37 + salt * 0.139 + 17.0);
        float passSeed = hash11(fi * 43.11 + salt * 0.097 + 13.0);
        float heroClass = 1.0 - step(0.18, groupSeed);
        float fineClass = step(0.72, groupSeed);
        float baseAngle = group * 2.39996323 + salt * 0.011;
        float passSpread = (pass - 1.5) * mix(0.008, 0.024, fineClass);
        float handTurn = (groupSeed - 0.5) * mix(0.035, 0.095, fineClass);
        float centerAngle = baseAngle + passSpread + handTurn;
        vec2 outward = vec2(cos(centerAngle), sin(centerAngle));
        float edgeRadius = frameEdgeDistance(outward);
        float outerOverrun = mix(3.0, 18.0, passSeed);
        float radialT = (radius - coreRadius) /
            max(edgeRadius + outerOverrun - coreRadius, 1.0);
        float pathT = clamp(radialT, 0.0, 1.0);
        vec2 motionSampleUV = clamp(
            focus + outward * min(edgeRadius * 0.42, shortEdge * 0.30) /
                    resolution,
            vec2(0.0), vec2(1.0));
        vec2 localMotion = sourceVelocity(motionSampleUV);
        float motionResponse;
        vec2 motionTarget = motionAwareDirection(
            outward, sourceRole(motionSampleUV), localMotion, 0.72,
            motionResponse);
        float motionTurn = angleDifference(
            centerAngle, atan(motionTarget.y, motionTarget.x));
        float bendEnvelope = pathT * pathT * (3.0 - 2.0 * pathT);
        float pathAngle = centerAngle + motionTurn * motionResponse *
            bendEnvelope * 0.34 + radialTwirlOffset(radius);
        float across = angleDifference(polarAngle, pathAngle) * max(radius, 1.0);
        float widthSeed = hash11(fi * 67.21 + salt * 0.173 + 29.0);
        float passWidth = pass < 0.5 ? 1.0 :
                          pass < 1.5 ? 0.70 :
                          pass < 2.5 ? 0.43 : 0.24;
        float classWidth = heroClass * mix(1.65, 2.35, widthSeed) +
                           (1.0 - heroClass) * mix(0.28, 1.08, widthSeed);
        float perspective = mix(0.035, 1.0,
            smoothstep(0.0, 0.18, pathT));
        float halfWidth = max(0.22,
            mix(0.42, 15.5, pow(lineThickness, 1.08)) * passWidth *
            classWidth * perspective);
        float directedT = mix(radialT, 1.0 - radialT, castBehindAmount());
        float stroke = motionFamilyDeposit(
            across, halfWidth, directedT,
            0.78 / max(edgeRadius, 1.0), passSeed, motionResponse * 0.12);
        float opacity = mix(0.42, 0.98, widthSeed) *
            pow(clamp(strength, 0.0, 1.0), 0.86);
        result = 1.0 - (1.0 - result) * (1.0 - stroke * opacity);
    }
    float hairlines = radialHairlineField(delta, radius, polarAngle);
    return clamp(1.0 - (1.0 - result) * (1.0 - hairlines), 0.0, 1.0);
}

float radialRibbonField(vec2 p)
{
    if (strength <= 0.0001 || lineThickness <= 0.0001) return 0.0;
    vec2 delta = (p - focus) * resolution;
    float radius = length(delta);
    float polarAngle = atan(delta.y, delta.x);
    float diagonal = length(resolution);
    float shortEdge = max(1.0, min(resolution.x, resolution.y));
    float result = 0.0;
    vec2 radialAtPixel = safeDirection(delta, vec2(cos(angle), sin(angle)));
    // Subject samples author launch angles and depth ownership; the finished
    // strokes themselves must continue uninterrupted to the camera crop.
    float softSupport = 1.0;
    // Every family shares one sub-pixel-scale emitter. Width grows only after
    // leaving it, so all centerlines visibly converge without forming a plug.
    float coreRadius = max(1.0, shortEdge * 0.0025);
    float focalGate = radialVoidGate(delta);

    for (int i = 0; i < 56; ++i) {
        float fi = float(i);
        float activeFamilies = mix(32.0, 48.0, smoothstep(
            240.0, 760.0, min(resolution.x, resolution.y)));
        if (fi >= activeFamilies) continue;
        float group = floor(fi * 0.25);
        float pass = mod(fi, 4.0);
        float groupSeed = hash11(group * 61.37 + salt * 0.139 + 17.0);
        float passSeed = hash11(fi * 43.11 + salt * 0.097 + 13.0);
        float heroClass = 1.0 - step(0.16, groupSeed);
        float supportClass = step(0.16, groupSeed) * (1.0 - step(0.76, groupSeed));
        float fineClass = step(0.76, groupSeed);
        float angularPacket = hash11(group * 97.13 + salt * 0.211 + 139.0);
        if (angularPacket < 0.40 && heroClass < 0.5) continue;

        vec2 anchorUV = fract(vec2(
            0.5 + group * 0.754877666 + salt * 0.0137,
            0.5 + group * 0.569840296 + salt * 0.0191));
        float seedRole;
        vec2 seedMotion;
        vec2 seedNormal;
        vec4 seedData = shadowBiasedSeed(
            anchorUV, hash11(fi * 43.71 + salt * 0.247 + 173.0),
            seedRole, seedMotion, seedNormal);
        vec2 seedUV = seedData.xy;
        float seedMask = seedData.z;
        float seedDarkness = seedData.w;
        // Radial hero strokes obey the same graphic-ink contract as linear
        // families. Do not let lighting thin or cull the burst.
        float seedWeight = seedMask;
        if (seedWeight < 0.022) continue;
        float launchChance = mix(0.92, 0.995,
            heroClass + supportClass * 0.72);
        if (hash11(fi * 79.13 + salt * 0.211 + 139.0) > launchChance) continue;

        vec2 seedDelta = (seedUV - focus) * resolution;
        float seedRadius = length(seedDelta);
        vec2 seedRadial = safeDirection(seedDelta, vec2(cos(angle), sin(angle)));
        float motionResponse;
        vec2 motionTarget = motionAwareDirection(
            seedRadial, seedRole, seedMotion, 1.0, motionResponse);
        float baseAngle = atan(seedRadial.y, seedRadial.x);
        float targetAngle = atan(motionTarget.y, motionTarget.x);
        float motionDeflection = atan(
            sin(targetAngle - baseAngle), cos(targetAngle - baseAngle));

        float passSpread = (pass - 1.5) *
            (heroClass * 0.010 + supportClass * 0.020 + fineClass * 0.034);
        float groupTurn = (hash11(group * 53.73 + salt * 0.127) - 0.5) *
                          (heroClass * 0.045 + supportClass * 0.105 + fineClass * 0.195);
        float centerAngle = baseAngle + passSpread + groupTurn;
        // Loaded hero gestures reach the protected burst. Support and graphite
        // gestures begin nearer their sampled silhouette anchor, preserving
        // the character-shaped negative wedges instead of making a uniform
        // polar cage across the whole frame.
        float silhouetteStart = max(coreRadius, seedRadius * mix(
            0.46, 0.78, hash11(group * 89.17 + salt * 0.113 + 211.0)));
        float startRadius = mix(coreRadius, silhouetteStart,
            supportClass * 0.72 + fineClass * 0.92);
        float classLength = heroClass * 1.34 + supportClass * 0.94 + fineClass * 0.62;
        float motionStretch = 1.0 + motionResponse * mix(1.10, 2.10, passSeed);
        float outwardReach = mix(shortEdge * 0.18, diagonal * 0.54, strength) *
                             mix(0.72, 1.20, passSeed) * classLength *
                             motionStretch;
        float endRadius = max(diagonal * 1.08,
                              max(seedRadius, startRadius + 8.0) + outwardReach);
        float radialT = (radius - startRadius) /
                        max(endRadius - startRadius, 1.0);
        float pathT = clamp(radialT, 0.0, 1.0);

        // Every path is exactly radial inside the luminous pocket. Motion and
        // hand correction are introduced progressively outward, producing a
        // curved burst that still unmistakably converges on one impact point.
        float deflectionEnvelope = pathT * pathT * (3.0 - 2.0 * pathT);
        float handBend = (hash11(group * 37.13 + salt * 0.149 + 17.0) - 0.5) *
                         mix(0.025, 0.135, strength) * deflectionEnvelope;
        float pathAngle = centerAngle + motionDeflection * motionResponse *
                          deflectionEnvelope + handBend +
                          radialTwirlOffset(radius);
        float across = angleDifference(polarAngle, pathAngle) * max(radius, 1.0);

        float widthSeed = hash11(fi * 67.21 + salt * 0.173 + 29.0);
        float groupWidth = mix(0.86, 1.16,
            hash11(group * 107.17 + salt * 0.149 + 67.0));
        float passWidth = pass < 0.5 ? 1.0 :
                          pass < 1.5 ? 0.74 :
                          pass < 2.5 ? 0.50 : 0.32;
        float classWidth = heroClass * mix(1.48, 2.05, widthSeed) +
                           supportClass * mix(0.66, 1.22, widthSeed) +
                           fineClass * mix(0.15, 0.39, widthSeed);
        float baseWidth = mix(0.40, 13.8, pow(lineThickness, 1.08));
        float focalPerspective = mix(0.055, 1.0,
            smoothstep(0.0, 0.24, pathT));
        float radialExpansion = 1.0 + max(radius - startRadius, 0.0) *
                                mix(0.0005, 0.0022, widthSeed);
        float centerWidthRelease = mix(0.10, 1.0, pow(focalGate, 0.58));
        float halfWidth = max(0.10, baseWidth * classWidth * groupWidth * passWidth *
                              mix(1.04, 1.20, passSeed) *
                              focalPerspective * radialExpansion *
                              mix(1.0, 0.78, motionResponse) * centerWidthRelease);
        float stroke = motionFamilyDeposit(
            across, halfWidth, radialT,
            0.78 / max(endRadius - startRadius, 1.0),
            passSeed, motionResponse);
        float detailClass = clamp(fineClass + supportClass * 0.46, 0.0, 1.0);
        float readability = heroReadabilityGate(
            p, vec2(cos(pathAngle), sin(pathAngle)), seedRole,
            detailClass, passSeed);
        readability = 1.0;
        float gestureContact = valueNoise(
            vec2(group * 0.37, pathT * mix(5.0, 11.0, passSeed)),
            salt + 2917.0 + pass * 13.0);
        stroke *= focalGate * softSupport * readability *
                  pow(clamp(strength, 0.0, 1.0), 0.82) *
                  mix(0.52, 1.0, gestureContact) *
                  mix(0.70, 1.0, seedWeight) *
                  (heroClass * mix(0.72, 0.94, passSeed) +
                   supportClass * mix(0.44, 0.74, passSeed) +
                   fineClass * mix(0.20, 0.46, passSeed));
        result = 1.0 - (1.0 - result) * (1.0 - stroke);
    }
    // Thin graphite belongs to the same curved field as the loaded brushes.
    // It therefore reinforces the silhouette-conditioned burst instead of
    // drawing an unrelated straight polar ruler over it.
    float hairlines = radialHairlineField(delta, radius, polarAngle);
    return clamp((1.0 - (1.0 - result) * (1.0 - hairlines)) * focalGate,
        0.0, 1.0);
}

float hatchDrawingSalt()
{
    // Hatching is redrawn only when the authored 3D direction enters a new
    // anime pose. Main brush families retain their semantic IDs; this local
    // salt deliberately changes the pencil actions instead of smoothly
    // rotating yesterday's hatch lattice under the subject.
    vec2 pose = floor(flowSource.xy * 24.0 + vec2(0.5));
    float hemisphere = step(0.0, -flowSource.z);
    return salt + hash11(dot(pose, vec2(37.17, 91.73)) +
                         hemisphere * 173.31) * 997.0;
}

/*
 * Nested tonal hatching: darker tones add stable lanes instead of replacing
 * a smooth gray fill.  The first family follows the same coherent field as
 * the subject drawing; a second, oblique family appears only in deeper shade.
 * Each lane has one persistent identity derived from frame salt and lane ID,
 * so changing light intensity reveals more of the same drawing rather than
 * sliding a procedural screen over the rig.
 */
float hatchFamily(vec2 p, vec2 flow, float spacing, float halfWidth,
                  float density, float familySeed)
{
    float drawingSalt = hatchDrawingSalt();
    vec2 tangent = normalize(flow + vec2(1e-6));
    vec2 normal = vec2(-tangent.y, tangent.x);
    vec2 pixel = (p - vec2(0.5)) * resolution;
    float along = dot(pixel, tangent);
    float across = dot(pixel, normal);
    if (density <= 0.0001) return 0.0;
    // Monotone jittered boundaries vary the actual space available to every
    // trace. Unlike the old smooth coordinate warp, they cannot fold several
    // lanes into a clean empty band or create evenly repeated clone gaps.
    float lane = floor(across / spacing);
    float lowerBoundary = lane * spacing +
        (hash11(lane * 41.17 + familySeed * 17.31 + drawingSalt * 0.071) - 0.5) *
        spacing * 0.34;
    float upperBoundary = (lane + 1.0) * spacing +
        (hash11((lane + 1.0) * 41.17 + familySeed * 17.31 + drawingSalt * 0.071) - 0.5) *
        spacing * 0.34;
    if (across < lowerBoundary) lane -= 1.0;
    else if (across >= upperBoundary) lane += 1.0;
    lowerBoundary = lane * spacing +
        (hash11(lane * 41.17 + familySeed * 17.31 + drawingSalt * 0.071) - 0.5) *
        spacing * 0.34;
    upperBoundary = (lane + 1.0) * spacing +
        (hash11((lane + 1.0) * 41.17 + familySeed * 17.31 + drawingSalt * 0.071) - 0.5) *
        spacing * 0.34;
    float laneSpan = max(0.58, (upperBoundary - lowerBoundary) / spacing);
    // Four neighboring passes belong to one hand-action neighborhood. They
    // share slant, pressure and timing bias, then receive a smaller local
    // variation. That produces recognizable repeated intent without a ruler
    // grid or unrelated noise on every line.
    float laneGroup = floor(lane * 0.25);
    float groupSeed = hash11(
        laneGroup * 21.17 + familySeed * 91.73 + drawingSalt * 0.13);
    float localLaneSeed = hash11(
        lane * 37.17 + familySeed * 61.31 + drawingSalt * 0.17);
    float laneSeed = mix(groupSeed, localLaneSeed, 0.78);

    // Tonal-art-map nesting: raising density only admits additional stable
    // lanes. Existing lanes keep their position, width and graphite phase.
    // A line remembers its pressure through a tone transition.  Stable
    // segment/lane bias means neighboring gestures do not all terminate on
    // the same cel-light contour, while zero-density regions still remain
    // empty. This is the tonal-art-map equivalent of a hand overshooting a
    // highlight by a different amount on every pass.
    float laneCenter = 0.5 * (lowerBoundary + upperBoundary);
    laneCenter += (localLaneSeed - 0.5) * spacing * 0.16 +
                  (groupSeed - 0.5) * spacing * 0.08;

    // Each lane is a sequence of pressure gestures, not a periodic dash row.
    // Correlated longitudinal drift changes the gesture duration gradually;
    // neighboring pixels never choose unrelated segment boundaries.
    float groupLength = mix(58.0, 188.0, groupSeed * groupSeed);
    float independentLength = mix(46.0, 214.0, pow(hash11(
        lane * 59.17 + familySeed * 17.31 + drawingSalt * 0.07), 1.35));
    float segmentLength = mix(groupLength, independentLength, 0.72);
    float groupPhase = hash11(laneGroup * 47.31 + familySeed * 29.17);
    // Neighboring lanes must lift at different longitudinal positions. A
    // mostly shared phase makes separately angled actions meet into repeated
    // U/V lenses even though each action is individually straight.
    float segmentPhase = fract(groupPhase + localLaneSeed * 0.78) *
                         segmentLength;
    float longitudinalDrift = (valueNoise(
        vec2(along * 0.0067 + familySeed * 2.1, lane * 0.091),
        familySeed + 463.0) - 0.5) * segmentLength * 0.16;
    float segmentCoordinate =
        (along + segmentPhase + longitudinalDrift) / segmentLength;
    float segmentIndex = floor(segmentCoordinate);
    float segmentT = fract(segmentCoordinate);
    float segmentSeed = hash11(segmentIndex * 31.73 + lane * 13.91 +
                               familySeed * 7.17);
    // Sample projected form once at the center of this finite pencil action.
    // The resulting slope stays constant for the complete segment: a limb
    // face can steer the trace, but a normal change cannot bend that same
    // trace into a computer-generated contour. The next segment samples its
    // own face and therefore redraws at a separately authored angle.
    float segmentCenterAlong =
        (segmentIndex + 0.5) * segmentLength - segmentPhase;
    vec2 segmentAnchorUV = clamp(
        vec2(0.5) + (tangent * segmentCenterAlong +
                     normal * laneCenter) / resolution,
        vec2(0.0), vec2(1.0));
    vec2 anchorNormalXY = sourceSurfaceNormalXY(segmentAnchorUV);
    // Hatch actions keep their authored length. Hemisphere perspective is a
    // hero-stroke control; per-segment scaling reconnects adjacent hatches
    // into synchronized nested turns on rounded parts.
    float pointSource = step(0.5, flowSource.w);
    // Hatching is a sequence of separately lifted straight pencil actions.
    // Sampling a new surface tangent for every adjacent segment reconnects
    // them into the forbidden U/lens contour. Character form is carried by
    // ownership, tone and finite overshoot; only hand-angle error turns a
    // hatch action.
    float groupSlope = (groupSeed - 0.5) * 0.040;
    // A lane is one straight pencil axis. Segment identity may change its
    // pressure and lift timing, never its direction; otherwise consecutive
    // actions reconnect as a hooked algorithmic polyline.
    float pencilSlope = groupSlope + (localLaneSeed - 0.5) * 0.060;
    float maxSlopeTurn = mix(0.34906585, 0.61086524, pointSource);
    float aerodynamicSlope = tan(clamp(
        atan(pencilSlope), -maxSlopeTurn, maxSlopeTurn));
    vec2 strokeTangent = safeDirection(
        tangent + normal * aerodynamicSlope, tangent);
    vec2 strokeNormal = vec2(-strokeTangent.y, strokeTangent.x);
    vec2 segmentAnchorPixel = (segmentAnchorUV - vec2(0.5)) * resolution;
    vec2 localRelative = pixel - segmentAnchorPixel;
    float localAlong = dot(localRelative, strokeTangent);
    float localAcross = dot(localRelative, strokeNormal);
    float strokeT = localAlong / max(segmentLength, 1.0) + 0.5;
    // A real lift gap separates consecutive actions. Overlapping pressure
    // windows reconnect independently angled segments into a fake lens.
    float strokeWindow = smoothstep(0.040, 0.105, strokeT) *
        (1.0 - smoothstep(0.840, 0.920, strokeT));
    // Each lane probes a different position across the lit boundary. This
    // gives every gesture its own continuation distance instead of clipping a
    // whole group against the same flat tone contour.
    float laneContinuation = 0.0;
    // Fully shaded pixels already admit the complete nested set. Only tone
    // transitions need the displaced probe, avoiding redundant texture work
    // across the dense shadow masses.
    if (density < 0.985) {
        float reachSeed = hash11(
            lane * 17.71 + segmentIndex * 23.19 + familySeed * 5.3);
        float laneReach = mix(4.0, 46.0, reachSeed * reachSeed);
        float lanePolarity = hash11(
            lane * 31.17 + segmentIndex * 7.13 + familySeed) < 0.5 ? -1.0 : 1.0;
        float laneSide = mix(-10.0, 10.0,
            hash11(lane * 43.09 + segmentIndex * 13.51 + familySeed * 2.1));
        vec2 laneNearOffset =
            (strokeTangent * laneReach * lanePolarity * 0.34 +
             strokeNormal * laneSide * 0.26) / resolution;
        vec2 nearState = sourceMaskAndKey(p - laneNearOffset);
        float nearOwner = smoothstep(0.08, 0.72, nearState.x);
        float nearKey = smoothstep(0.335, 0.385, nearState.y) * 0.72 +
                        smoothstep(0.735, 0.785, nearState.y) * 0.28;
        float nearShade = (1.0 - clamp(lightIntensity, 0.0, 1.0) * nearKey) *
                          nearOwner;
        // One transported sample is enough because reach is strongly
        // nonlinear per gesture. Avoiding a divergent far branch is faster on
        // the supported viewport GPUs and still gives staggered protrusions.
        laneContinuation = nearShade * mix(0.18, 0.52, segmentSeed);
    }
    float densityMemory = clamp(max(
        density * mix(0.84, 1.18, localLaneSeed) +
        (groupSeed - 0.5) * 0.12,
        laneContinuation), 0.0, 1.0);
    float admissionThreshold = mix(0.07, 0.91, densityMemory);
    float admission = 1.0 - smoothstep(
        admissionThreshold, admissionThreshold + 0.13, laneSeed);

    // Each hatch is a finite straight hand action. Persistent group/lane/action
    // offsets keep neighboring strokes irregular without bending any single
    // centerline into a digital U or lens.
    float actionSeed = hash11(segmentIndex * 17.91 + lane * 43.07 +
                              familySeed * 3.19);
    float groupOffset = (groupSeed - 0.5) * min(0.72, spacing * 0.11);
    float laneOffset = (localLaneSeed - 0.5) * min(0.58, spacing * 0.09);
    // Keep the complete lane on one centerline. Segment-specific transverse
    // offsets made straight pieces meet as repeated U/S curves.
    float actionOffset = 0.0;
    float drift = groupOffset + laneOffset;
    // Pressure shapes geometry as well as opacity. The previous uniform-width
    // cells merely faded at their ends and therefore looked like transparent
    // digital dashes with identical gaps.
    float attackEnd = mix(0.018, 0.095,
        hash11(segmentIndex * 61.13 + lane * 7.91 + familySeed));
    float releaseStart = mix(0.62, 0.96,
        hash11(segmentIndex * 29.27 + lane * 51.31 + familySeed));
    float attack = smoothstep(0.00, attackEnd, strokeT);
    // Narrow hatch lanes do not have enough transverse pixels for a second
    // silhouette field. Stagger their end pressure by persistent lane and
    // segment identity so clustered hatches protrude at unequal distances.
    float hatchTipJitter = (hash11(
        lane * 71.17 + segmentIndex * 17.09 + familySeed * 11.3) - 0.5) * 0.055;
    float releaseEnd = min(
        0.985, max(releaseStart + 0.035, 0.955 + hatchTipJitter * 0.45));
    float release = 1.0 - smoothstep(releaseStart, releaseEnd, strokeT);
    // Asymmetric action-unit pressure: individual pencil traces do not press
    // and lift with mirrored timing even when their geometric span is equal.
    float pressureSkew = mix(0.72, 1.48, hash11(
        lane * 83.11 + segmentIndex * 19.73 + familySeed * 7.9));
    float segmentPressure = pow(attack, pressureSkew) *
                            pow(release, 2.05 - pressureSkew);
    float pressureWidth = pow(segmentPressure, 0.52);
    float widthVariation = mix(0.62, 1.58,
        mix(groupSeed, hash11(
            lane * 19.41 + segmentIndex * 5.17 + familySeed * 53.11), 0.55));
    // Selected dark-family gestures become medium graphite marks using the
    // same lane identity and form direction. This fills the missing meso scale
    // without evaluating a third full hatching family per output pixel.
    float formEmphasis = step(0.78, hash11(
        laneGroup * 89.17 + segmentIndex * 7.31 + familySeed * 19.0)) *
        smoothstep(0.58, 0.92, density);
    widthVariation *= mix(1.0, 2.22, formEmphasis);
    float widthPressure = valueNoise(
        vec2(along * 0.018 + familySeed * 2.3, lane * 0.29),
        familySeed + 661.0);
    float width = halfWidth * widthVariation * mix(0.84, 1.16,
                  clamp((laneSpan - 0.66) / 0.68, 0.0, 1.0)) *
                  mix(0.72, 1.24, widthPressure) * pressureWidth;
    float edgeAA = max(0.92, fwidth(across) * 0.82);
    float distanceToLane = abs(localAcross - drift);
    float coverage = (1.0 - smoothstep(width, width + edgeAA, distanceToLane)) *
                     strokeWindow;
    // Use the same cached physical-tool atlas as the hero strokes, sampled in
    // segment coordinates. This adds continuous graphite fibers and pressure
    // breakup inside an anti-aliased analytic footprint instead of painting a
    // translucent vector line and sprinkling screen noise over it.
    float hatchAcross = (localAcross - drift) / max(width, 0.22);
    float hatchVariant = floor(hash11(
        lane * 11.37 + segmentIndex * 29.11 + familySeed * 5.7) * 4.0);
    vec2 hatchUV = vec2(
        clamp(strokeT, 0.0, 1.0),
        (hatchVariant + clamp(hatchAcross * 0.5 + 0.5, 0.0, 1.0)) * 0.25);
    float hatchDeposit = 0.0;
    if (coverage > 0.0001) {
        vec2 hatchMaterial = texture(brushTex, hatchUV).rg;
        hatchDeposit = coverage * clamp(
            hatchMaterial.r * 0.44 + hatchMaterial.g * 0.92, 0.0, 1.0);
    }

    // A minority of gestures carry a faint adjacent graphite filament. The
    // companion shares the same pressure and endpoint, making a clustered
    // hand stroke rather than a second regular hatch grid.
    float companionChance = step(
        mix(0.72, 0.38, density),
        hash11(laneGroup * 73.31 + segmentIndex * 11.07 + familySeed));
    float companionOffset = mix(1.15, 2.65, segmentSeed) *
                            (hash11(lane * 9.7 + familySeed) < 0.5 ? -1.0 : 1.0);
    float companionDistance = abs(localAcross - drift - companionOffset);
    float companion = (1.0 - smoothstep(width * 0.34,
                                         width * 0.34 + edgeAA,
                                         companionDistance)) *
                      companionChance * mix(0.46, 0.78, density);

    // Pressure is deposited as graphite contact, not a smooth gray fill.
    // Screen-fixed paper tooth and stroke-locked grain are continuous fields:
    // they soften and break pigment without displacing the stroke silhouette
    // or producing isolated pin dots.
    float slowPressure = valueNoise(
        vec2(along * 0.012 + familySeed * 5.1, lane * 0.23),
        familySeed + 719.0);
    float paperCoarse = valueNoise(pixel * 0.13 + vec2(lane * 0.07),
                                   familySeed + 887.0);
    float paperFine = valueNoise(pixel * 0.49 + vec2(lane * 0.11),
                                 familySeed + 929.0);
    float strokeGrain = valueNoise(
        vec2(along * 0.16 + familySeed * 3.1,
             (across - laneCenter) * 0.58), familySeed + 953.0);
    float graphiteContact = paperCoarse * 0.44 +
                            paperFine * 0.26 + strokeGrain * 0.30;
    float pressure = mix(0.42, 1.18, density) *
                     mix(0.70, 1.14, slowPressure) *
                     mix(0.48, 1.12, graphiteContact) *
                     mix(0.82, 1.12, segmentSeed);

    // Transport subject ownership along each individual graphite gesture.
    // A binary center mask (and the old two-probe approximation) makes every
    // lane terminate on the same projected contour. Four decreasing-pressure
    // samples instead describe how far this specific hand pass can continue
    // beyond the capture. Probe chains remain straight so ownership cannot
    // manufacture a curved hatch that was absent from the action centerline.
    float forwardSeed = hash11(
        lane * 41.73 + segmentIndex * 19.13 + familySeed);
    float backwardSeed = hash11(
        lane * 29.17 + segmentIndex * 37.11 + familySeed * 1.7);
    float continuationClass = step(0.56, hash11(
        lane * 73.17 + segmentIndex * 41.13 + familySeed * 5.9));
    float extensionForward = mix(
        mix(7.0, 54.0, forwardSeed * forwardSeed),
        mix(36.0, 128.0, pow(forwardSeed, 1.35)), continuationClass);
    float extensionBackward = mix(
        mix(6.0, 48.0, backwardSeed * backwardSeed),
        mix(30.0, 112.0, pow(backwardSeed, 1.35)), continuationClass);
    float terminalSideOffset = (hash11(
        lane * 67.13 + segmentIndex * 23.41 + familySeed * 3.7) - 0.5) *
        mix(1.0, 5.0, segmentSeed);
    // A captured silhouette is a launch surface, not a hard clipping stencil.
    // Short axial/normal probes bridge the 1-8 px white moat left by raster
    // coverage at subject/background and beveled-part boundaries. The much
    // longer per-stroke transport below still owns the irregular overshoot.
    vec2 seamStepT = strokeTangent / resolution;
    vec2 seamStepN = strokeNormal / resolution;
    float edgeBridgeSupport = max(max(
        sourceCoverage(p - seamStepT * 3.0),
        sourceCoverage(p + seamStepT * 3.0)), max(
        sourceCoverage(p - seamStepN * 3.0),
        sourceCoverage(p + seamStepN * 3.0)));
    edgeBridgeSupport = max(edgeBridgeSupport * 0.82, max(max(
        sourceCoverage(p - seamStepT * 7.0),
        sourceCoverage(p + seamStepT * 7.0)), max(
        sourceCoverage(p - seamStepN * 7.0),
        sourceCoverage(p + seamStepN * 7.0))) * 0.56);
    float centerSupport = max(
        max(sourceCoverage(p), internalSeamSupport(p)),
        edgeBridgeSupport);
    float transportedSupport = 0.0;
    // Interior pixels need no ownership transport. Restrict the extra mask
    // taps to the narrow capture transition where an endpoint can exist.
    if (centerSupport < 0.985) {
        vec2 forwardSide = strokeNormal * terminalSideOffset;
        vec2 backwardSide = -forwardSide;
        vec2 f1 = (strokeTangent * extensionForward * 0.18 + forwardSide) / resolution;
        vec2 f2 = (strokeTangent * extensionForward * 0.40 + forwardSide) / resolution;
        vec2 f3 = (strokeTangent * extensionForward * 0.68 + forwardSide) / resolution;
        vec2 f4 = (strokeTangent * extensionForward + forwardSide) / resolution;
        vec2 b1 = (strokeTangent * extensionBackward * 0.18 + backwardSide) / resolution;
        vec2 b2 = (strokeTangent * extensionBackward * 0.40 + backwardSide) / resolution;
        vec2 b3 = (strokeTangent * extensionBackward * 0.68 + backwardSide) / resolution;
        vec2 b4 = (strokeTangent * extensionBackward + backwardSide) / resolution;
        float forwardEnergy = sourceMask(p - f1) * 1.00 +
            sourceMask(p - f2) * 0.64 + sourceMask(p - f3) * 0.34 +
            sourceMask(p - f4) * 0.14;
        float backwardEnergy = sourceMask(p + b1) * 1.00 +
            sourceMask(p + b2) * 0.64 + sourceMask(p + b3) * 0.34 +
            sourceMask(p + b4) * 0.14;
        transportedSupport = 1.0 - exp(
            -max(forwardEnergy, backwardEnergy) *
            mix(0.58, 1.08, segmentSeed));
    }
    float support = max(centerSupport, transportedSupport);
    float releasePressure = mix(0.76, 1.24, hash11(
        lane * 53.91 + segmentIndex * 11.27 + familySeed * 2.3));
    float supportGate = pow(
        smoothstep(0.006, 0.52, support), releasePressure);
    float deposited = 1.0 - (1.0 - hatchDeposit) * (1.0 - companion);
    // Optical-density accumulation lets overlapping dark passes approach
    // opaque pencil while light pressure remains visibly granular.
    float graphiteAlpha = 1.0 - exp(
        -1.72 * deposited * pressure * mix(0.58, 1.0, segmentPressure));
    return graphiteAlpha * admission * supportGate;
}

float subjectHatching(vec2 p, vec2 flow, float shade)
{
    if (lineThickness <= 0.0001) return 0.0;
    float density = clamp(shade, 0.0, 1.0);
    // None is a composition choice, not a request to discard the subject's
    // drawing. Keep hatching at its neutral pencil width even if a previous
    // Linear/Radial key stored zero hero thickness.
    float hatchThickness = lineThickness;
    float thicknessResponse = pow(clamp(hatchThickness, 0.0, 1.0), 0.72);
    // Tonal-art-map nesting requires one immutable geometric lattice. Shade
    // may admit more persistent strokes and increase graphite pressure, but
    // it must never compress spacing or widen lanes per pixel: doing so bends
    // straight hatches around tone contours into algorithmic lenses.
    float spacing = mix(12.4, 6.2, thicknessResponse) * 0.78;
    float width = mix(0.48, 1.24, thicknessResponse) * 1.02;

    // Broad packet admission creates areas of concentrated drawing and areas
    // where the paper is allowed to breathe. It modulates stable lane IDs, so
    // changing light reveals more of the same hatching instead of re-rolling it.
    float drawingSalt = hatchDrawingSalt();
    float packetMacro = valueNoise(
        (p - vec2(0.5)) * vec2(4.1, 3.5), drawingSalt + 941.0);
    float packetMeso = valueNoise(
        (p - vec2(0.5)) * vec2(10.7, 8.9), drawingSalt + 977.0);
    float packet = packetMacro * 0.72 + packetMeso * 0.28;
    float packetWeight = mix(0.62, 1.10, smoothstep(0.24, 0.82, packet));
    float primaryDensity = pow(smoothstep(
        0.10, 0.90, clamp(density * packetWeight, 0.0, 1.0)), 1.42);
    primaryDensity = max(primaryDensity,
        smoothstep(0.72, 0.96, density) * mix(0.82, 1.0, packet));

    // Packet direction was chosen before lane construction. Do not bend it
    // again with a continuous noise field: that reconnects separate pencil
    // actions into the nested contour worms visible around rounded corners.
    vec2 primaryFlow = flow;
    float primary = hatchFamily(
        p, primaryFlow, spacing, width, primaryDensity, 211.0);

    // Cross-hatching appears only in deep shade and selected hand packets.
    // Its base angle is chosen once for the drawing. A direction calculated
    // from output pixel position bends one logical lane as it crosses packet
    // cells, producing the conspicuous nested lens/cylinder pattern.
    float crossPacket = smoothstep(0.58, 0.86, valueNoise(
        (p - vec2(0.5)) * vec2(5.3, 4.7), drawingSalt + 1091.0));
    float crossDensity = smoothstep(0.60, 0.88, density) *
                         mix(0.26, 1.0, crossPacket) *
                         mix(0.72, 1.0, packetMacro);
    float crossShapeSignal = hash11(drawingSalt * 0.173 + 1063.0);
    float crossFamilyShape =
        (floor(crossShapeSignal * 5.0) + 0.5) / 5.0;
    float crossTurnSignal = hash11(drawingSalt * 0.219 + 1129.0);
    float crossAngleOffset =
        (floor(crossTurnSignal * 5.0) - 2.0) * 0.045;
    vec2 crossFlow = rotateVector(
        primaryFlow, mix(0.80, 1.19, crossFamilyShape) + crossAngleOffset);
    float crossing = hatchFamily(
        p, crossFlow, spacing * 1.14,
        width * mix(0.78, 1.02, 1.0 - crossFamilyShape),
        crossDensity, 431.0);
    return 1.0 - (1.0 - primary) * (1.0 - crossing);
}

float subjectContourField(vec2 p, vec2 flow)
{
    vec2 pixel = p * resolution;
    float structureMacro = valueNoise(
        pixel * 0.015 + vec2(salt * 0.17), salt + 1511.0);
    float structureMeso = valueNoise(
        pixel * 0.061 + vec2(salt * 0.29), salt + 1567.0);
    float structureAdmission = smoothstep(
        0.43, 0.70, structureMacro * 0.72 + structureMeso * 0.28);
    float handStructure = looseToneStructure(p);
    // The displaced construction sample is the only structural guide. There
    // is deliberately no exact mesh/tone floor capable of reconstructing a
    // perfect projected square around a front-facing limb.
    float structureGuide = handStructure;
    float structureDeposit = structureGuide * structureAdmission *
        mix(0.08, 0.38, structureMacro) *
        mix(0.48, 1.0, structureMeso);
    // Treat the captured mesh edge as a loose construction guide. A
    // correlated hand pass samples it with normal displacement and angle
    // correction; it never traces the exact projected silhouette.
    // Hatching is accumulated after this field, so its graphite naturally
    // draws across and over the broken guide rather than stopping beneath it.
    vec2 guideNormal = vec2(-flow.y, flow.x);
    float guideTurn =
        (valueNoise(pixel * 0.0087, salt + 1601.0) - 0.5) * 0.24 +
        (valueNoise(pixel * 0.0271, salt + 1627.0) - 0.5) * 0.08;
    float guideDriftA =
        (valueNoise(pixel * 0.0093, salt + 1657.0) - 0.5) * 7.0 +
        (valueNoise(pixel * 0.0361, salt + 1669.0) - 0.5) * 2.2;
    vec2 guideFlowA = rotateVector(flow, guideTurn);
    float guideA = directionalEdgeEnergy(
        p + guideNormal * guideDriftA / resolution, guideFlowA);
    float guidePressure = mix(0.010, 0.020,
        valueNoise(pixel * 0.0181, salt + 1693.0));
    // A restrained correction pass sits slightly off the first construction
    // line. It shares the same macro gesture but not its exact pressure or
    // angle, which removes the single perfect rectangle without producing a
    // noisy multi-outline effect.
    float guideDriftB = guideDriftA * 0.34 +
        (valueNoise(pixel * 0.0247, salt + 1721.0) - 0.5) * 3.4;
    float guideTurnB = guideTurn * 0.46 +
        (valueNoise(pixel * 0.0163, salt + 1747.0) - 0.5) * 0.11;
    float guideB = directionalEdgeEnergy(
        p + guideNormal * guideDriftB / resolution,
        rotateVector(flow, guideTurnB));
    float redrawPatch = smoothstep(0.42, 0.72,
        valueNoise(pixel * 0.0129, salt + 1777.0));
    float guide = guideA * guidePressure +
                  guideB * guidePressure * redrawPatch * 0.28;
    float directionalWrap = directionalEdgeEnergy(p, flow) *
        mix(0.030, 0.18, lineThickness) *
        mix(0.42, 1.0, pow(max(strength, 0.0), 0.58));
    return guide + structureDeposit + directionalWrap;
}

float backgroundSingleGraphiteLayer(vec2 p, float amount)
{
    float result = 0.0;
    float shortEdge = max(1.0, min(resolution.x, resolution.y));
    vec2 geometryP = radialUntwirlPoint(p);
    vec2 authored = baseFlow(vec2(0.5));
    float centeredBackground = step(0.5, flowSource.w) *
        (1.0 - smoothstep(0.045, 0.22,
            length((flowSource.xy - vec2(0.5)) * 2.0)));
    for (int index = 0; index < 288; ++index) {
        float fi = float(index);
        float seed = hash11(fi * 83.17 + salt * 0.073 + 4001.0);
        // This seed set is independent of the three-pass brush packets. These
        // marks occupy otherwise quiet paper instead of hiding inside bundles.
        vec2 anchor = vec2(
            hash11(fi * 127.13 + salt * 0.041 + 4013.0),
            hash11(fi * 179.17 + salt * 0.037 + 4027.0));
        vec2 globalAway = safeDirection(vec2(0.5) - flowSource.xy, authored);
        vec2 localAway = safeDirection(anchor - flowSource.xy, globalAway);
        vec2 centeredAway = safeDirection(vec2(0.5) - anchor, globalAway) *
            mix(-1.0, 1.0, castBehindAmount());
        // Side-source shots share one dominant speed-line axis. Only a small
        // local component breaks mechanical parallelism. A centered source
        // deliberately switches to the projected radial/hemisphere field.
        vec2 sideFlow = blendDirection(globalAway, localAway, 0.16);
        vec2 flow = safeDirection(mix(sideFlow, centeredAway,
            centeredBackground), authored);
        float sourceTravel = max(0.0, dot(
            (anchor - flowSource.xy) * resolution, flow));
        float travelT = 1.0 - smoothstep(
            shortEdge * 0.04, shortEdge * 0.92, sourceTravel);
        // The visible trail begins opposite the pin: births are crowded at
        // the incoming/start edge, then both frequency and deposition fade
        // as the gesture approaches its terminal/source side.
        float localAmount = amount * mix(1.0, 0.28, travelT);
        // Birth probability falls much faster than brush pressure. This
        // produces a crowded graphite pickup near the source and genuinely
        // sparse construction marks at the travel end, instead of a uniform
        // field whose only change is opacity.
        float birthProbability = mix(0.06, 0.94,
            pow(clamp(localAmount, 0.0, 1.0), 0.72));
        if (seed > birthProbability) continue;
        vec2 normal = vec2(-flow.y, flow.x);
        float lengthSeed = hash11(fi * 211.31 + salt * 0.029 + 4049.0);
        float strokeLength = shortEdge * mix(0.15, 0.40, lengthSeed);
        float heel = strokeLength * mix(0.08, 0.30,
            hash11(fi * 239.11 + salt * 0.023 + 4057.0));
        vec2 delta = (geometryP - anchor) * resolution;
        float along = dot(delta, flow);
        float across = dot(delta, normal);
        float strokeT = (along + heel) / max(strokeLength + heel, 1.0);

        vec2 anchorCentered = anchor - vec2(0.5);
        vec2 localCamera = vec2(
            backgroundAffineX.x + backgroundAffineX.y * anchorCentered.x +
                backgroundAffineX.z * anchorCentered.y,
            backgroundAffineY.x + backgroundAffineY.y * anchorCentered.x +
                backgroundAffineY.z * anchorCentered.y);
        vec2 cameraAxis = alignLineAxis(
            safeDirection(localCamera, flow), flow);
        float cameraTurn = atan(
            flow.x * cameraAxis.y - flow.y * cameraAxis.x,
            dot(flow, cameraAxis));
        float bend = clamp(backgroundMotionInfluence, 0.0, 1.0);
        // Zero is mathematically straight. One gives a single coherent arc;
        // there is no spatial lens warp or repeated spline segmentation.
        float curveT = clamp(strokeT, 0.0, 1.0);
        float fallbackSign = mix(-1.0, 1.0,
            step(0.5, hash11(salt * 0.071 + 4111.0)));
        float cameraSign = sign(cameraTurn);
        float coherentSign = mix(fallbackSign, cameraSign,
            step(0.025, abs(cameraTurn)));
        float authoredTurn = coherentSign * mix(0.012, 0.060,
            hash11(fi * 307.11 + salt * 0.017 + 4127.0));
        float curveAngle = clamp(cameraTurn * 0.22 + authoredTurn,
            -0.24, 0.24);
        across -= tan(curveAngle) * strokeLength * 0.34 *
            curveT * curveT * bend;
        float width = mix(0.16, 0.43,
            hash11(fi * 271.73 + salt * 0.019 + 4073.0));
        float body = 1.0 - smoothstep(width, width + 0.82, abs(across));
        float window = smoothstep(-0.015, 0.035, strokeT) *
            (1.0 - smoothstep(0.91, 1.015, strokeT));
        float endFade = mix(1.0, 0.055,
            smoothstep(0.16, 1.0, clamp(strokeT, 0.0, 1.0)));
        float tooth = mix(0.62, 1.0, valueNoise(
            vec2(along * 0.052, across * 0.37), seed + salt + 4091.0));
        // These are graphite construction lines, not miniature ink swipes.
        // Density creates the dark source value; frequency and pressure both
        // fall away down-trail.
        float stroke = body * window * endFade * tooth *
            mix(0.035, 0.18, amount) * mix(1.0, 0.28, travelT);
        result = 1.0 - (1.0 - result) * (1.0 - stroke);
    }
    float paperOnly = 1.0 - smoothstep(0.015, 0.28, sourceCoverage(p));
    return result * paperOnly;
}

float backgroundStrokeLayer(vec2 p)
{
    float amount = clamp(backgroundIntensity, 0.0, 1.0);
    if (amount <= 0.0001) return 0.0;
    vec2 geometryP = radialUntwirlPoint(p);
    float familyInk = 0.0;
    {
        float accumulated = 0.0;
        const int BACKGROUND_FAMILY_COUNT = 240;
        for (int index = 0; index < BACKGROUND_FAMILY_COUNT; ++index) {
            float fi = float(index);
            float cluster = floor(fi / 3.0);
            float member = mod(fi, 3.0) - 1.0;
            float familySeed = hash11(fi * 37.17 + salt * 0.127 + 3203.0);
            float clusterSeed = hash11(
                cluster * 71.31 + salt * 0.091 + 3229.0);
            vec2 anchor = vec2(
                hash11(cluster * 97.13 + salt * 0.071 + 3251.0),
                hash11(cluster * 131.71 + salt * 0.053 + 3271.0));
            // Let families enter from outside the crop instead of beginning
            // at one artificial full-frame boundary.
            anchor = mix(vec2(-0.015), vec2(1.015), anchor);

            vec2 anchorCentered = anchor - vec2(0.5);
            vec2 anchorAffine = vec2(
                backgroundAffineX.x + backgroundAffineX.y * anchorCentered.x +
                    backgroundAffineX.z * anchorCentered.y,
                backgroundAffineY.x + backgroundAffineY.y * anchorCentered.x +
                    backgroundAffineY.z * anchorCentered.y);
            vec2 anchorMotion = mix(
                backgroundMotion, anchorAffine,
                min(backgroundAffineX.w, backgroundAffineY.w));
            vec2 authored = baseFlow(vec2(0.5));
            float motionStrength = smoothstep(
                0.015, 0.82,
                length(anchorMotion) / max(velocityScale, 1.0e-6));
            // Captured camera flow already has the directed paper displacement.
            // Negating it made the backdrop travel against the punch. Preserve
            // that polarity, then loosely converge fine families toward the
            // pink source without turning the background into a rigid radial fan.
            vec2 globalAway = safeDirection(
                vec2(0.5) - flowSource.xy, authored);
            vec2 localAway = safeDirection(anchor - flowSource.xy, globalAway);
            float centeredBackground = step(0.5, flowSource.w) *
                (1.0 - smoothstep(0.045, 0.22,
                    length((flowSource.xy - vec2(0.5)) * 2.0)));
            // A centered 3D source is a projected sun-ray field. Cast Behind
            // sends paper marks away from the hidden source; front cast
            // reverses that pressure direction so the wind appears to enter
            // the visible body before trailing through it.
            vec2 centeredAway = safeDirection(
                vec2(0.5) - anchor, globalAway);
            // Rear cast converges toward the hidden central impact, matching
            // the authored inward arrows. Front cast reverses and exits from
            // the visible hit toward the frame edge.
            centeredAway *= mix(-1.0, 1.0, castBehindAmount());
            // Project the camera-space source ray onto a virtual paper
            // hemisphere. At dead center this is an inward rear-cast field
            // and an outward front-cast field; away from center it rotates in
            // perspective instead of shearing a 2D radial texture.
            vec2 virtualXY = (anchor - vec2(0.5)) * vec2(
                resolution.x / max(resolution.y, 1.0), 1.0) / 0.78;
            float virtualRadius = length(virtualXY);
            vec2 boundedVirtualXY = virtualXY /
                max(1.0, virtualRadius * 1.001);
            vec3 virtualNormal = vec3(
                boundedVirtualXY,
                sqrt(max(0.0, 1.0 - dot(boundedVirtualXY, boundedVirtualXY))));
            vec2 sourceXY = (flowSource.xy - vec2(0.5)) * 2.0 * vec2(
                resolution.x / max(resolution.y, 1.0), 1.0);
            vec3 paperWind = normalize(vec3(-sourceXY, flowSource.z) +
                vec3(1.0e-7));
            vec3 paperTangent = paperWind - virtualNormal *
                dot(paperWind, virtualNormal);
            vec2 hemisphereFlow = safeDirection(
                -paperTangent.xy, centeredAway);
            if (dot(hemisphereFlow, centeredAway) < 0.0)
                hemisphereFlow = -hemisphereFlow;
            centeredAway = blendDirection(
                centeredAway, hemisphereFlow,
                smoothstep(0.025, 0.92, virtualRadius) * 0.82);
            vec2 awayFromPin = safeDirection(mix(
                blendDirection(globalAway, localAway, 0.18),
                centeredAway, centeredBackground), centeredAway);
            vec2 cameraFlow = alignLineAxis(
                safeDirection(backgroundMotion, awayFromPin), awayFromPin);
            if (dot(cameraFlow, awayFromPin) < 0.0) cameraFlow = -cameraFlow;
            vec2 relativeSubjectMotion = subjectMotion - backgroundMotion;
            float centeredMotionResponse = smoothstep(
                0.015, 1.10,
                length(relativeSubjectMotion) / max(velocityScale, 1.0e-6)) *
                clamp(motionCurveInfluence, 0.0, 1.0);
            vec2 centeredMotionAxis = alignLineAxis(
                safeDirection(relativeSubjectMotion, authored), authored);
            vec2 centeredChannel = blendDirection(
                authored, centeredMotionAxis, centeredMotionResponse * 0.62);
            // Preserve a centered 3D fan while sharing the keyed channel.
            // A full replacement by centeredChannel made every background
            // family choose the same up/down/left/right screen direction.
            vec2 centeredPinAxis = blendDirection(
                awayFromPin, centeredChannel, 0.54);
            vec2 pinAxis = safeDirection(mix(
                awayFromPin, centeredPinAxis, centeredBackground), authored);
            vec2 guidedFlow = blendDirection(pinAxis, cameraFlow,
                clamp(backgroundMotionInfluence, 0.0, 1.0) *
                motionStrength * 0.30);
            vec2 familyFlow = blendDirection(
                awayFromPin, guidedFlow, 0.82);
            // At the camera axis, loaded brush packets and graphite must use
            // the same projected 3D hemisphere tangent. Without this final
            // lock, camera motion could pull only the broad packet back toward
            // the arbitrary 2D fallback while thin construction stayed radial.
            familyFlow = blendDirection(
                familyFlow, pinAxis, centeredBackground * 0.52);
            float radialFan = mix(0.035, 0.30,
                smoothstep(0.0, 1.0, haloSpread));
            float handTurn = (hash11(
                cluster * 193.17 + salt * 0.061 + 3419.0) - 0.5) * 0.08;
            handTurn *= mix(1.0, radialFan / 0.08, centeredBackground);
            familyFlow = rotateVector(familyFlow, handTurn);
            familyFlow = alignLineAxis(familyFlow, awayFromPin);
            if (dot(familyFlow, awayFromPin) < 0.0) familyFlow = -familyFlow;
            float directedTravel = max(0.0, dot(
                (anchor - flowSource.xy) * resolution, familyFlow));
            float sourceDistance = length(
                (anchor - flowSource.xy) * resolution);
            float edgeSource = smoothstep(0.48, 0.92,
                length((flowSource.xy - vec2(0.5)) * 2.0));
            float familyTravel = mix(directedTravel, sourceDistance,
                max(centeredBackground, edgeSource));
            float familyGradient = smoothstep(
                min(resolution.x, resolution.y) * 0.018,
                min(resolution.x, resolution.y) * 0.72,
                familyTravel);
            float familyAmount = amount * mix(0.31, 1.0,
                pow(familyGradient, 0.72));
            float familyBirth = mix(0.16, 0.985,
                pow(familyGradient, 0.56)) *
                mix(0.42, 1.0, sqrt(amount));
            familyAmount = mix(familyAmount,
                max(familyAmount, amount * 0.72), centeredBackground);
            familyBirth = mix(familyBirth,
                max(familyBirth, 0.90 * sqrt(amount)), centeredBackground);
            if (clusterSeed > familyBirth) continue;
            vec2 familyNormal = vec2(-familyFlow.y, familyFlow.x);
            // Three repeated hand passes share one macro gesture. Their
            // transverse separation is correlated, producing brush packets
            // and quiet paper gaps instead of uniformly scattered rain.
            anchor += familyNormal * member * mix(3.2, 8.8, familySeed) /
                max(resolution, vec2(1.0));

            float shortEdge = min(resolution.x, resolution.y);
            float lengthSeed = hash11(fi * 157.11 + salt * 0.043 + 3299.0);
            // Graphite construction marks coexist with the loaded brush
            // packets. They remain a secondary family, but are common enough
            // to read as drawn directional scaffolding rather than rare rain.
            float thinClass = step(0.38, familySeed);
            float strokeLength = shortEdge * mix(0.050, 0.18, lengthSeed) *
                mix(1.0, mix(1.85, 2.75, lengthSeed), centeredBackground);
            float broadClass = (1.0 - step(0.24, clusterSeed)) *
                smoothstep(0.20, 0.76, amount);
            strokeLength *= mix(0.82, 1.16, broadClass) *
                mix(0.82, 1.08, 1.0 - abs(member));
            strokeLength = mix(strokeLength,
                shortEdge * mix(0.040, 0.125, lengthSeed), thinClass);
            float heel = strokeLength * mix(0.18, 0.48,
                hash11(fi * 181.37 + salt * 0.039 + 3313.0));

            vec2 delta = (geometryP - anchor) * resolution;
            float along = dot(delta, familyFlow);
            float rawAcross = dot(delta, familyNormal);

            // Sample how the affine camera field turns farther along this
            // gesture. Its signed angular change supplies one restrained arc,
            // so rolls/orbits curve coherently without per-pixel lens rings.
            vec2 probe = clamp(
                anchor + familyFlow * strokeLength / max(resolution, vec2(1.0)),
                vec2(-0.15), vec2(1.15));
            vec2 probeCentered = probe - vec2(0.5);
            vec2 probeMotion = vec2(
                backgroundAffineX.x + backgroundAffineX.y * probeCentered.x +
                    backgroundAffineX.z * probeCentered.y,
                backgroundAffineY.x + backgroundAffineY.y * probeCentered.x +
                    backgroundAffineY.z * probeCentered.y);
            vec2 probeFlow = safeDirection(probeMotion, familyFlow);
            probeFlow = alignLineAxis(probeFlow, familyFlow);
            float turn = atan(
                familyFlow.x * probeFlow.y - familyFlow.y * probeFlow.x,
                dot(familyFlow, probeFlow));
            float turnDecision = step(0.055, abs(turn) * motionStrength);
            // Background gesture bends only slightly as a whole. Large local
            // affine turns recreate the black-hole/lens rings that belong to
            // neither graphite construction nor directional speed lines.
            turn = clamp(turn, -0.52, 0.52) *
                clamp(backgroundMotionInfluence, 0.0, 1.0) * motionStrength;
            turn *= mix(1.0, 0.20, centeredBackground);
            float curveT = clamp((along + heel) /
                max(strokeLength + heel, 1.0), 0.0, 1.0);
            float curveEnvelope = curveT * curveT * (3.0 - 2.0 * curveT);
            float across = rawAcross - tan(turn) * strokeLength * 0.25 *
                curveEnvelope;

            float strokeT = (along + heel) /
                max(strokeLength + heel, 1.0);
            float widthSeed = hash11(fi * 211.17 + salt * 0.031 + 3343.0);
            float halfWidth = mix(1.10, 3.40, widthSeed) *
                mix(0.78, 1.12, amount);
            halfWidth = mix(halfWidth, mix(3.2, 5.8, widthSeed), broadClass);
            halfWidth = mix(halfWidth, mix(0.52, 1.08, widthSeed), thinClass);
            float stroke = brushRibbonDeposit(
                across, halfWidth, strokeT,
                0.72 / max(strokeLength, 1.0), familySeed + 3371.0);
            float centerMember = 1.0 - step(0.5, abs(member));
            stroke *= mix(1.0, mix(0.72, 1.0, centerMember), thinClass);
            // A second, explicitly finite construction pass restores the long
            // thin graphite marks without reviving the old full-frame lane
            // field. It shares this exact familyFlow, so broad brush packets
            // and pencil scaffolding can never point in opposing directions.
            float graphiteClass = step(0.04, hash11(
                fi * 241.71 + salt * 0.027 + 3359.0));
            // One construction trace per three-pass brush packet; the packet
            // members must not turn a pencil line into a technical-pen triplet.
            graphiteClass *= centerMember;
            float graphiteOffset = member * mix(1.2, 3.8, widthSeed) +
                (hash11(fi * 239.17 + salt * 0.029 + 3361.0) - 0.5) * 2.4;
            float graphiteLength = strokeLength * mix(1.85, 3.45,
                hash11(fi * 269.31 + salt * 0.023 + 3363.0));
            float graphiteHeel = heel * mix(0.72, 1.38,
                hash11(fi * 277.13 + salt * 0.021 + 3365.0));
            float graphiteT = (along + graphiteHeel) /
                max(graphiteLength + graphiteHeel, 1.0);
            float graphiteCurveT = clamp(graphiteT, 0.0, 1.0);
            float graphiteCurveEnvelope = graphiteCurveT * graphiteCurveT *
                (3.0 - 2.0 * graphiteCurveT);
            float graphiteAcross = rawAcross - tan(turn) * graphiteLength *
                0.25 * graphiteCurveEnvelope;
            float graphiteWidth = mix(0.32, 0.68, widthSeed);
            float centeredTaper = mix(1.18, 0.10,
                smoothstep(0.10, 1.0, clamp(graphiteT, 0.0, 1.0)));
            graphiteWidth *= mix(1.0, centeredTaper, centeredBackground);
            float graphiteEdge = 0.72;
            float graphiteBody = 1.0 - smoothstep(
                graphiteWidth, graphiteWidth + graphiteEdge,
                abs(graphiteAcross + graphiteOffset));
            float graphiteWindow = smoothstep(-0.015, 0.055, graphiteT) *
                (1.0 - smoothstep(0.935, 1.025, graphiteT));
            float graphitePressure = 0.72 + 0.18 * sin(
                graphiteT * 17.0 + familySeed * 29.0) + 0.10 * sin(
                graphiteT * 43.0 + familySeed * 61.0);
            float graphiteTooth = 0.72 + 0.28 * valueNoise(
                vec2(along * 0.065 + familySeed * 3.0,
                     (graphiteAcross + graphiteOffset) * 0.41),
                familySeed + 3373.0);
            float graphite = graphiteBody * graphiteWindow *
                graphitePressure * graphiteTooth * graphiteClass;
            // Apply density over every fragment, not only when the family is
            // born. A long far-side packet can cross toward the pin, so its
            // later section must fade too instead of staying uniformly black.
            float sampleTravel = max(0.0, dot(
                (geometryP - flowSource.xy) * resolution, familyFlow));
            float sampleGradient = smoothstep(
                min(resolution.x, resolution.y) * 0.025,
                min(resolution.x, resolution.y) * 0.82,
                sampleTravel);
            float spatialPressure = mix(0.14, 1.0,
                pow(sampleGradient, 0.74));
            float pressure = mix(0.10, 0.78, familyAmount) *
                mix(0.72, 1.0, widthSeed);
            pressure = mix(pressure, mix(0.14, 0.82, familyAmount), broadClass);
            pressure *= mix(1.0, 1.34, centeredBackground);
            pressure *= spatialPressure;
            accumulated = 1.0 - (1.0 - accumulated) *
                (1.0 - stroke * pressure) *
                (1.0 - graphite * mix(0.22, 0.74, familyAmount) *
                    spatialPressure);
        }

        // Sample the exact subject silhouette. Expanding this blocker, even by
        // one pixel, exposes a paper-colored seam beside colored subject fill.
        vec2 blockerStep = vec2(0.0);
        float blocker = sourceCoverage(p);
        blocker = max(blocker, sourceCoverage(
            p + vec2(blockerStep.x, 0.0)));
        blocker = max(blocker, sourceCoverage(
            p - vec2(blockerStep.x, 0.0)));
        blocker = max(blocker, sourceCoverage(
            p + vec2(0.0, blockerStep.y)));
        blocker = max(blocker, sourceCoverage(
            p - vec2(0.0, blockerStep.y)));
        float paperOnly = 1.0 - smoothstep(0.015, 0.28, blocker);
        // Finite gesture families are the complete background. A former
        // full-frame lane field created lens contours, hard cut lines and
        // accidental four-point intersections unrelated to the brush flow.
        familyInk = clamp(accumulated * paperOnly, 0.0, 1.0);
    }

    float singles = backgroundSingleGraphiteLayer(p, amount);
    return clamp(1.0 - (1.0 - familyInk) * (1.0 - singles), 0.0, 1.0);

    vec2 centered = p - vec2(0.5);
    vec2 affineMotion = vec2(
        backgroundAffineX.x + backgroundAffineX.y * centered.x +
            backgroundAffineX.z * centered.y,
        backgroundAffineY.x + backgroundAffineY.y * centered.x +
            backgroundAffineY.z * centered.y);
    vec2 capturedMotion = texture(
        backgroundMotionTex, clamp(p, vec2(0.0), vec2(1.0))).rg;
    float environmentSurface = texture(
        floorTex, clamp(p, vec2(0.0), vec2(1.0))).r;
    float affineConfidence = min(backgroundAffineX.w, backgroundAffineY.w);
    vec2 cameraField = mix(
        mix(backgroundMotion, affineMotion, affineConfidence),
        capturedMotion, smoothstep(0.06, 0.72, environmentSurface));

    float motionStrength = smoothstep(
        0.015, 0.82, length(cameraField) / max(velocityScale, 1.0e-6));
    // Background construction uses one frame-level gesture. Evaluating a new
    // orientation at every pixel bends parallel lanes into concentric lens
    // rings. Camera motion may bias this common axis, never replace it with a
    // spatially varying per-pixel tangent.
    vec2 authored = baseFlow(vec2(0.5));
    vec2 awayFromPin = safeDirection(
        vec2(0.5) - flowSource.xy, authored);
    vec2 globalCameraFlow = alignLineAxis(
        safeDirection(backgroundMotion, awayFromPin), awayFromPin);
    if (dot(globalCameraFlow, awayFromPin) < 0.0)
        globalCameraFlow = -globalCameraFlow;
    vec2 motionFlow = globalCameraFlow;
    vec2 flow = blendDirection(
        authored, motionFlow,
        clamp(backgroundMotionInfluence, 0.0, 1.0) * motionStrength);
    flow = alignLineAxis(flow, awayFromPin);
    if (dot(flow, awayFromPin) < 0.0) flow = -flow;
    vec2 normal = vec2(-flow.y, flow.x);
    vec2 pixel = (p - vec2(0.5)) * resolution;
    float along = dot(pixel, flow);
    float across = dot(pixel, normal);

    float laneDrift = (valueNoise(
        vec2(along * 0.0021, salt * 0.11), salt + 3203.0) - 0.5) * 1.2;
    float fineSpacing = mix(13.0, 18.0,
        hash11(salt * 0.13 + 3221.0));
    float fineLane = floor((across + laneDrift) / fineSpacing);
    float fineAcross = abs(fract((across + laneDrift) / fineSpacing) - 0.5) *
        fineSpacing;
    float fineSeed = hash11(fineLane * 17.13 + salt * 0.071 + 3251.0);
    float fineWidth = mix(0.34, 0.92, fineSeed) * mix(0.72, 1.22, amount);
    float fineAA = max(fwidth(fineAcross), 0.42);
    float fineLine = 1.0 - smoothstep(
        fineWidth - fineAA, fineWidth + fineAA, fineAcross);
    float fineCluster = smoothstep(0.30, 0.70,
        valueNoise(vec2(fineLane * 0.091, along * 0.0067), salt + 3271.0));
    float fineBreak = smoothstep(0.24, 0.60,
        valueNoise(vec2(along * 0.021, fineLane * 0.173), salt + 3299.0));
    fineLine *= mix(0.42, 1.0, fineCluster) *
        mix(0.50, 1.0, fineBreak);

    float mediumSpacing = mix(32.0, 50.0, hash11(
        floor(across / 12.0) * 9.31 + salt * 0.11 + 3313.0));
    float mediumLane = floor((across - laneDrift * 0.43) / mediumSpacing);
    float mediumAcross = abs(
        fract((across - laneDrift * 0.43) / mediumSpacing) - 0.5) *
        mediumSpacing;
    float mediumSeed = hash11(mediumLane * 29.17 + salt * 0.097 + 3343.0);
    float mediumWidth = mix(0.72, 1.85, mediumSeed) *
        mix(0.55, 1.0, amount);
    float mediumAA = max(fwidth(mediumAcross), 0.48);
    float mediumLine = 1.0 - smoothstep(
        mediumWidth - mediumAA, mediumWidth + mediumAA, mediumAcross);
    float mediumSegment = smoothstep(0.46, 0.72,
        valueNoise(vec2(along * 0.0103, mediumLane * 0.137), salt + 3371.0));
    mediumLine *= mix(0.34, 1.0, mediumSegment) *
        smoothstep(0.18, 0.58, amount);

    float accentSpacing = 92.0;
    float accentLane = floor((across + laneDrift * 0.21) / accentSpacing);
    float accentAcross = abs(
        fract((across + laneDrift * 0.21) / accentSpacing) - 0.5) *
        accentSpacing;
    float accentSeed = hash11(accentLane * 41.03 + salt * 0.083 + 3407.0);
    float accentWidth = mix(1.25, 3.10, accentSeed);
    float accentAA = max(fwidth(accentAcross), 0.55);
    float accentLine = 1.0 - smoothstep(
        accentWidth - accentAA, accentWidth + accentAA, accentAcross);
    float accentSegment = smoothstep(0.59, 0.76,
        valueNoise(vec2(along * 0.0051, accentLane * 0.19), salt + 3433.0));
    accentLine *= mix(0.28, 1.0, accentSegment) * motionStrength *
        smoothstep(0.48, 0.88, amount);

    float backgroundInk = 1.0 - (1.0 - fineLine * mix(0.14, 0.34, amount)) *
        (1.0 - mediumLine * mix(0.12, 0.30, amount)) *
        (1.0 - accentLine * mix(0.14, 0.32, amount));

    vec2 blockerStep = vec2(0.0);
    float blocker = sourceCoverage(p);
    blocker = max(blocker, sourceCoverage(p + vec2(blockerStep.x, 0.0)));
    blocker = max(blocker, sourceCoverage(p - vec2(blockerStep.x, 0.0)));
    blocker = max(blocker, sourceCoverage(p + vec2(0.0, blockerStep.y)));
    blocker = max(blocker, sourceCoverage(p - vec2(0.0, blockerStep.y)));
    float paperOnly = 1.0 - smoothstep(0.015, 0.28, blocker);
    float packetA = smoothstep(0.34, 0.72,
        valueNoise(vec2(along * 0.0037 + fineLane * 0.071,
                        fineLane * 0.113), salt + 3491.0));
    float packetB = smoothstep(0.40, 0.76,
        valueNoise(vec2(along * 0.0061 - mediumLane * 0.053,
                        mediumLane * 0.149), salt + 3517.0));
    float graphitePackets = fineLine * packetA * mix(0.16, 0.31, amount);
    graphitePackets = 1.0 - (1.0 - graphitePackets) *
        (1.0 - mediumLine * packetB * mix(0.13, 0.27, amount));
    graphitePackets = 1.0 - (1.0 - graphitePackets) *
        (1.0 - accentLine * packetA * packetB * mix(0.12, 0.24, amount));
    graphitePackets *= paperOnly;
    return clamp(1.0 - (1.0 - familyInk) *
                 (1.0 - graphitePackets), 0.0, 1.0);
}

float physicalBandCoverage(float coverage, vec2 p, vec2 flow,
                           float seedOffset)
{
    float amount = clamp(bandTransition, 0.0, 1.0);
    if (amount <= 0.0001 || coverage <= 0.0001) return coverage;
    vec2 pixel = (p - vec2(0.5)) * resolution;
    vec2 radialPixel = (p - focus) * resolution;
    vec2 axis = safeDirection(flow, vec2(cos(angle), sin(angle)));
    vec2 normal = vec2(-axis.y, axis.x);
    float linearAlongPixels = dot(pixel, axis);
    float linearAcrossPixels = dot(pixel, normal);
    float radialAngle = atan(radialPixel.y, radialPixel.x);
    float radialRadius = length(radialPixel);
    float untwirledAngle = radialAngle - radialTwirlOffset(radialRadius);
    float response = pow(amount, 0.72);
    float densityResponse = pow(amount, 0.86);
    float materialResponse = pow(amount, 0.38);
    // Band is a macro negative-space rhythm shared by a whole force field.
    // In Hybrid both passes use the radial coordinate, so their union cannot
    // fill each other's white cuts. Small lane offsets roughen boundaries but
    // never replace the coherent ring/stripe with unrelated dash cells.
    float radialDriven = (mode == 1 || hybridMode != 0) ? 1.0 : 0.0;
    float alongPixels = mix(linearAlongPixels, radialRadius, radialDriven);
    float acrossSignal = linearAcrossPixels /
        max(min(resolution.x, resolution.y), 1.0);
    float wrappedAngle = fract(
        (untwirledAngle + 3.14159265) / 6.28318531);
    // Low Band values produce a few long white breathing intervals. Raising
    // Band packs shorter rests more densely instead of merely increasing the
    // opacity of the same mathematical rings.
    float periodPixels = mix(310.0, 62.0, densityResponse);
    // Radial Band samples noise on a closed circle.  Using raw atan as a
    // noise coordinate exposed its -PI/+PI edge as the Twirl+Band separator.
    vec2 periodicAngle = vec2(cos(untwirledAngle), sin(untwirledAngle));
    vec2 noiseDomain = mix(
        vec2(alongPixels * 0.0047, acrossSignal * 1.7),
        periodicAngle * 2.17 + vec2(alongPixels * 0.0019), radialDriven);
    float macroDrift = valueNoise(noiseDomain, salt + 251.0);
    float boundaryWave = valueNoise(
        noiseDomain * vec2(1.7, 2.3) + seedOffset * 0.013,
        salt + 269.0);
    float boundaryRipple = valueNoise(
        noiseDomain * vec2(5.1, 4.3) + alongPixels * 0.0013,
        salt + 277.0);
    float angularLobe = sin(untwirledAngle * mix(2.0, 5.0, response) +
        floor(alongPixels / periodPixels) * 1.731 + salt * 0.017);
    float angularBreak = smoothstep(0.48, 0.72, valueNoise(
        periodicAngle * mix(2.4, 5.8, response) +
            floor(alongPixels / periodPixels) * 0.17,
        salt + 281.0));
    float boundaryDisplacement =
        (boundaryWave - 0.5) * mix(28.0, 92.0, response) +
        (boundaryRipple - 0.5) * mix(9.0, 31.0, response) +
        angularLobe * mix(8.0, 46.0, response) +
        (angularBreak - 0.5) * mix(12.0, 58.0, response);
    float coordinate = (alongPixels + boundaryDisplacement) / periodPixels +
        (macroDrift - 0.5) * mix(0.06, 0.22, response);
    float bandCell = floor(coordinate);
    float localBand = fract(coordinate);
    float bandSeed = hash11(bandCell * 71.31 + salt * 0.083);
    float laneCoordinate = radialDriven > 0.5
        ? wrappedAngle * mix(83.0, 181.0, response)
        : linearAcrossPixels / mix(17.0, 8.0, response);
    float lane = floor(laneCoordinate);
    float laneSeed = hash11(
        lane * 41.73 + salt * 0.071 + seedOffset * 0.019);
    // A band event is owned by a periodic angular sector, not a full ring.
    // Neighboring sectors interpolate, giving broad hand-timed fragments
    // with smooth transparency rather than binary checker cells.
    float sectorCount = 17.0;
    float sectorCoordinate = wrappedAngle * sectorCount;
    float sectorIndex = floor(sectorCoordinate);
    float sectorT = fract(sectorCoordinate);
    float sectorA = hash11(mod(sectorIndex, sectorCount) * 61.73 +
        bandCell * 19.17 + salt * 0.037 + seedOffset * 0.013);
    float sectorB = hash11(mod(sectorIndex + 1.0, sectorCount) * 61.73 +
        bandCell * 19.17 + salt * 0.037 + seedOffset * 0.013);
    float sectorValue = mix(sectorA, sectorB,
        sectorT * sectorT * (3.0 - 2.0 * sectorT));
    float sectorVariation = mix(valueNoise(
        vec2(acrossSignal * 7.3, bandCell * 0.37), salt + 293.0),
        sectorValue, radialDriven);
    float center = 0.5 + (bandSeed - 0.5) * 0.12 +
        (sectorVariation - 0.5) * mix(0.08, 0.25, response) +
        (laneSeed - 0.5) * mix(0.018, 0.075, response);
    float edgeWear = valueNoise(mix(
        vec2(alongPixels * 0.019, lane * 0.113),
        periodicAngle * 5.7 + vec2(bandCell * 0.31), radialDriven),
        salt + 317.0 + seedOffset * 0.071);
    float halfWidth = clamp(mix(0.34, 0.235, densityResponse) *
        mix(0.72, 1.28, bandSeed) * mix(0.84, 1.16, edgeWear),
        0.10, 0.46);
    float bandDistance = abs(localBand - center);
    // The reference is a pressure fade across a bundle, not a binary stencil.
    // Give the whole interval a broad heel/feather in normalized band space.
    float bandAA = max(fwidth(coordinate) * 1.45,
        mix(0.026, 0.072, response));
    float retained = smoothstep(
        halfWidth - bandAA, halfWidth + bandAA, bandDistance);
    retained = clamp(retained + (edgeWear - 0.5) *
        mix(0.05, 0.18, response), 0.0, 1.0);

    float sectorCut = mix(mix(0.78, 0.38, response), 1.0, smoothstep(
        mix(0.58, 0.30, response), 0.90, sectorValue));
    float gradedStrength = mix(0.18, 1.0,
        smoothstep(0.16, 0.92, sectorValue + (edgeWear - 0.5) * 0.24));
    float fragmentedRetained = 1.0 -
        (1.0 - retained) * mix(1.0, sectorCut * gradedStrength,
            radialDriven);

    // Band changes deposited line material: the coverage profile is eroded
    // toward its centerline and its remaining graphite is made translucent.
    // This is not a white color overlay and exact zero returns unchanged.
    float widthScale = mix(
        1.0, mix(0.16, 1.0, fragmentedRetained), materialResponse);
    float opacityScale = mix(1.0,
        mix(mix(0.20, 0.52, 1.0 - gradedStrength), 1.0,
            fragmentedRetained), materialResponse);
    float inner = clamp((1.0 - widthScale) * 0.68, 0.0, 0.94);
    float outer = min(1.0, inner + max(0.028, widthScale * 0.48));
    float eroded = smoothstep(inner, outer, coverage);
    return eroded * opacityScale;
}

vec2 impactField(vec2 p, out float mask, out float tone, out float lightCarrier)
{
    mask = sourceCoverage(p);
    // Radial flow is valid for generated rays, not for the subject drawing
    // coordinate. Feeding it into the mesh warp creates a lens around focus.
    vec2 authoredSubjectFlow = mode == 1
        ? vec2(cos(angle), sin(angle)) : baseFlow(p);
    vec2 relativeDrawingMotion = subjectMotion - backgroundMotion;
    float drawingMotionResponse = smoothstep(
        0.015, 1.10,
        length(relativeDrawingMotion) / max(velocityScale, 1.0e-6)) *
        clamp(motionCurveInfluence, 0.0, 1.0);
    vec2 drawingMotionAxis = alignLineAxis(
        safeDirection(relativeDrawingMotion, authoredSubjectFlow),
        authoredSubjectFlow);
    vec2 drawingChannel = blendDirection(
        authoredSubjectFlow, drawingMotionAxis, drawingMotionResponse * 0.62);
    vec2 drawingNormal = vec2(-drawingChannel.y, drawingChannel.x);
    vec2 capturedNormalXY = sourceSurfaceNormalXY(p);
    float capturedNormalZ = sqrt(max(
        0.0, 1.0 - min(dot(capturedNormalXY, capturedNormalXY), 1.0)));
    float hemisphereSign = sign(flowSource.z + 1.0e-6);
    float faceDepth = capturedNormalZ * hemisphereSign;
    vec2 subjectPixel = (p - vec2(0.5)) * resolution;
    float faceWarpMacro = valueNoise(
        subjectPixel / 74.0, salt + 4201.0) - 0.5;
    float faceWarpMeso = valueNoise(
        subjectPixel / 27.0, salt + 4219.0) - 0.5;
    float faceWarpPixels = (faceWarpMacro * 8.5 + faceWarpMeso * 3.2 +
        faceDepth * 5.5) *
        (1.0 - step(1.5, float(mode)));
    vec2 drawingDisplacement = drawingChannel * faceWarpPixels +
        drawingNormal * faceWarpMeso * 2.2;
    vec2 drawingP = clamp(p + drawingDisplacement /
        max(resolution, vec2(1.0)), vec2(0.0), vec2(1.0));
    tone = sourceTone(drawingP);
    float keyLight = keyLightField(drawingP);
    float keyAA = max(fwidth(keyLight) * 1.30, 0.025);
    float stylizedKey = stylizedKeyAt(p, keyAA);
    float drawnShade = 1.0 - clamp(lightIntensity, 0.0, 1.0) * stylizedKey;

    vec2 authoredFlow = baseFlow(p);
    vec2 localMotion = sourceVelocity(drawingP);
    float structureEnergy;
    vec2 contourFlow = toneGuidedFlow(p, localMotion, structureEnergy);
    // Lighting selects nested tone families only. Geometry comes from a
    // quantized, light-independent form packet so dragging the light cannot
    // bend the lines and corners terminate rather than turn as one contour.
    // The pin may be a point emitter, but hatching is made from finite pencil
    // actions, not implicit polar coordinates around that point. Start every
    // action family from one authored axis; hatchFamily then samples form and
    // aerodynamic steering once at each action anchor. This preserves the
    // centered 3D trail while preventing concentric U/lens hatches.
    vec2 hatchAnchor = vec2(cos(angle), sin(angle));
    float centeredDrawing = subjectCenteredSourceAmount();
    hatchAnchor = blendDirection(
        hatchAnchor, baseFlow(p), centeredDrawing * 0.48 *
        (1.0 - step(0.5, float(mode))));
    // Do not pre-warp this direction per output pixel. hatchFamily samples
    // the face and emitter once at each finite gesture anchor; pre-warping
    // here made adjacent lanes converge continuously into nested rings.
    float hatchPacketGate;
    float hatchFormEnergy;
    vec2 hatchFlow = hatchPacketFlow(
        p, hatchAnchor, hatchPacketGate, hatchFormEnergy);
    // Motion remains available to hero action strokes. Hatching holds the
    // artist's composition angle here; hatchFamily adds a fixed, anchored
    // surface slope per finite trace instead of a per-pixel velocity warp.

    // Local tonal evidence owns every hatch. Neighboring shadow samples may
    // not leak graphite into a lit plane.
    // Strength scales the key before tone classification. Reducing Intensity
    // or using a darker Custom color therefore restores shade and hatching.
    // The ramp preserves a visible light-hatch transition before a small
    // fully lit core reaches clean paper.
    // Use continuous captured light for tonal falloff. stylizedKey is useful
    // for the broad cel carrier, but feeding its two plateaus into hatch
    // admission collapses the drawing to white-or-dark with no midtone phase.
    float continuousKey = clamp(keyLight +
        (valueNoise((p - vec2(0.5)) * vec2(4.7, 4.1), salt + 1171.0) - 0.5) *
        0.040, 0.0, 1.0);
    float effectiveKey = clamp(lightIntensity, 0.0, 1.0) * continuousKey;
    float hatchShade = pow(1.0 - smoothstep(0.08, 0.96, effectiveKey), 0.82);
    float cleanHighlight = smoothstep(0.965, 0.998, effectiveKey);
    hatchShade *= 1.0 - cleanHighlight;

    float heroActive = (mode != 2 && strength > 0.0001 &&
                        lineThickness > 0.0001) ? 1.0 : 0.0;
    float ribbons = 0.0;
    float edgeHatching = 0.0;
    if (heroActive > 0.5) {
        if (mode == 0) {
            float rearRibbons = 0.0;
            ribbons = linearRibbonField(p, authoredFlow, rearRibbons);
            float frontAccent = 0.0;
            float accents = silhouetteTrailAccentField(
                p, authoredFlow, frontAccent);
            frontAccent = 1.0 - (1.0 - frontAccent) *
                (1.0 - frontNookFillField(p, authoredFlow));
            float centeredRearCast = step(0.5, flowSource.w) *
                (1.0 - smoothstep(0.04, 0.22,
                    length((flowSource.xy - vec2(0.5)) * 2.0))) *
                castBehindAmount();
            float centeredLinear = step(0.5, flowSource.w) *
                (1.0 - smoothstep(0.04, 0.22,
                    length((flowSource.xy - vec2(0.5)) * 2.0)));
            // Centered depth shots use the face-channel families themselves.
            // The old silhouette accent is an independent radial emitter and
            // recreates the explosion topology even after the hero field is
            // corrected.
            accents *= 1.0 - centeredLinear;
            frontAccent *= 1.0 - centeredLinear;
            frontAccent *= 1.0 - centeredRearCast;
            // Perimeter accents always describe the rear silhouette mass.
            // The approximately even depth split applies to main families.
            float rearAccent = accents;
            rearRibbons = 1.0 - (1.0 - rearRibbons) * (1.0 - rearAccent);
            ribbons = 1.0 - (1.0 - ribbons) * (1.0 - frontAccent);
            vec2 blockerStep = vec2(0.0);
            float subjectBlocker = max(texture(subjectTex, p).r,
                max(max(texture(subjectTex, clamp(p + vec2(blockerStep.x, 0.0), vec2(0.0), vec2(1.0))).r,
                        texture(subjectTex, clamp(p - vec2(blockerStep.x, 0.0), vec2(0.0), vec2(1.0))).r),
                    max(texture(subjectTex, clamp(p + vec2(0.0, blockerStep.y), vec2(0.0), vec2(1.0))).r,
                        texture(subjectTex, clamp(p - vec2(0.0, blockerStep.y), vec2(0.0), vec2(1.0))).r)));
            float rearSubjectOcclusion =
                1.0 - smoothstep(0.015, 0.34, subjectBlocker);
            float subjectSurface = smoothstep(0.08, 0.72, mask);
            // Preserve the dense pre-depth-fix drawing on the visible form:
            // every family may deposit on the subject surface. Outside that
            // surface, only rear-owned families survive. This produces the
            // requested front + rear combination and prevents front strokes
            // from protruding as detached bars into empty paper.
            vec2 compositionCenter = 0.5 *
                (subjectBounds.xy + subjectBounds.zw);
            float centeredSourceAmount = subjectCenteredSourceAmount();
            vec2 sideRayAxis = safeDirection(
                compositionCenter - flowSource.xy, authoredFlow);
            vec2 radialRayAxis = safeDirection(
                (p - compositionCenter) * vec2(
                    resolution.x / max(resolution.y, 1.0), 1.0),
                authoredFlow);
            vec2 rayAxis = safeDirection(mix(
                sideRayAxis, radialRayAxis, centeredSourceAmount),
                authoredFlow);
            // A directional, multi-distance support replaces the old binary
            // mask dilation. Front pigment now feathers past the leeward edge
            // in the same direction as the sunray instead of accumulating on
            // one vertical subject-border wall.
            float raySupport = max(subjectSurface,
                max(sourceCoverage(p - rayAxis * 10.0 / resolution) * 0.94,
                max(sourceCoverage(p - rayAxis * 24.0 / resolution) * 0.76,
                    sourceCoverage(p - rayAxis * 46.0 / resolution) * 0.42)));
            // Never multiply every stroke by one shared silhouette envelope:
            // that creates a flat vertical cut. The generated brush pressure
            // owns each endpoint; this support only modulates opacity softly.
            float frontEnvelope = smoothstep(0.02, 0.44, raySupport);
            float frontSurface = ribbons * mix(0.72, 1.0, frontEnvelope);
            frontSurface *= 1.0 - centeredRearCast;
            vec2 coreStep = vec2(14.0) / max(resolution, vec2(1.0));
            float interiorCore = min(
                min(sourceCoverage(p + vec2(coreStep.x, 0.0)),
                    sourceCoverage(p - vec2(coreStep.x, 0.0))),
                min(sourceCoverage(p + vec2(0.0, coreStep.y)),
                    sourceCoverage(p - vec2(0.0, coreStep.y))));
            float silhouetteBand = 1.0 - smoothstep(0.62, 0.96, interiorCore);
            frontSurface *= mix(
                mix(0.38, 1.0, silhouetteBand), 1.0,
                centeredSourceAmount);
            float rearExterior = rearRibbons * rearSubjectOcclusion;
            ribbons = 1.0 - (1.0 - frontSurface) *
                (1.0 - rearExterior);
        }
        else {
            ribbons = radialRibbonField(p);
            float ownedSurface = smoothstep(0.18, 0.86, sourceCoverage(p));
            vec2 focusRay = safeDirection(
                (p - focus) * resolution, vec2(cos(angle), sin(angle)));
            float channelPattern = smoothstep(0.54, 0.88, valueNoise(
                vec2(atan(focusRay.y, focusRay.x) * 5.3,
                     length((p - focus) * resolution) * 0.0041),
                salt + 2897.0));
            // Rear cast is mostly occluded by the character, with selected
            // 3D channels entering the focus. Front cast is intentionally
            // stronger across the face, but still leaves the silhouette and
            // hatching readable instead of painting a solid polar cage.
            float rearChannel = mix(0.035, 0.24, channelPattern);
            float frontChannel = mix(0.16, 0.46, channelPattern);
            float surfaceChannel = mix(
                frontChannel, rearChannel, castBehindAmount());
            ribbons *= mix(1.0, surfaceChannel, ownedSurface);
        }
    }
    // Continuous contour tracing reconnects adjacent bevels into lens/ring
    // distortions. Character construction now comes only from finite hatch
    // actions and the pressure-shaped hero families.
    float seamSupport = internalSeamSupport(p);
    float contour = 0.0;
    float ink = physicalBandCoverage(
        max(contour, ribbons), p, authoredFlow, 0.0);
    // Band belongs to hero/background stroke material, not tonal drawing.
    float surfaceHatching = subjectHatching(
        drawingP, hatchFlow, hatchShade) * hatchPacketGate;
    if (mode == 1) {
        // A rear-cast emitter is behind the captured form. Its star may clear
        // paper, but it may not erase foreground subject construction.
        float pocketOwnership = 1.0 - castBehindAmount();
        surfaceHatching *= mix(1.0,
            radialCoreGate((p - focus) * resolution), pocketOwnership);
    }
    float outlineTone = mix(0.34, 1.0, hatchShade);
    // A sampled mesh contour is only a faint construction guide. Keeping it
    // prominent reconstructs rounded part edges as repeated lens curves—the
    // exact artifact cross-hatching is meant to replace.
    // Restore construction readability with short directional edge accents.
    // This field samples edge energy along the authored hatch axis and never
    // traces the rounded silhouette as a continuous curve.
    float outlineInk = subjectContourField(drawingP, hatchFlow) *
        mix(0.34, 0.86, hatchShade);
    float hatchField = 1.0 - (1.0 - surfaceHatching) *
        (1.0 - edgeHatching * 0.72) * (1.0 - outlineInk * 0.84);
    ink = 1.0 - (1.0 - ink) * (1.0 - outlineInk * 0.92);
    if (mode == 1) {
        float protectedCenter = radialCoreGate((p - focus) * resolution);
        // Cast Behind changes subject depth ownership, not the existence of
        // the impact emitter. Rear-cast construction still thins and fades
        // into the same white center star instead of ending as a hard plug.
        float pocketOwnership = 1.0 - castBehindAmount();
        // Hero/background rays already own radialVoidGate. Do not cut the
        // subject outline with its long sunray heels; that made lens contours
        // and bright ruler lines across the lit mesh.
        hatchField *= mix(1.0, protectedCenter, pocketOwnership);
    }

    float subjectInterior = smoothstep(0.78, 0.995, mask);
    float litFace = subjectInterior * stylizedKey;
    float lightWashMacro = valueNoise(
        (p - vec2(0.5)) * vec2(4.1, 3.7), salt + 1289.0);
    float lightWashMeso = valueNoise(
        (p - vec2(0.5)) * vec2(12.7, 10.9), salt + 1307.0);
    float lightWash = mix(0.68, 1.0,
        lightWashMacro * 0.72 + lightWashMeso * 0.28);
    float hatchResist = mix(1.0, 0.72,
        smoothstep(0.08, 0.72, hatchField));
    lightCarrier = clamp(litFace * lightWash * hatchResist, 0.0, 1.0);

    // Radial mode exposes a real luminous impact pocket. This is a light
    // carrier, not a post-effect change; Bloom and color continue to consume the
    // same canonical line/light channels as before.
    if (mode == 1) {
        float shortEdge = max(1.0, min(resolution.x, resolution.y));
        float focalRadius = length((p - focus) * resolution);
        float focalCore = 1.0 - smoothstep(
            shortEdge * 0.008, shortEdge * 0.060, focalRadius);
        float focalTexture = mix(0.82, 1.0, valueNoise(
            (p - focus) * vec2(18.0, 15.0), salt + 1847.0));
        float rearOcclusion = mix(1.0, 1.0 - subjectInterior,
            castBehindAmount());
        lightCarrier = max(lightCarrier,
            focalCore * focalTexture * 0.94 * rearOcclusion);
    }
    return clamp(vec2(ink, hatchField), 0.0, 1.0);
}

void main()
{
    float mask, tone, lightCarrier;
    vec2 fields;
    if (layerOnly != 0) {
        mask = sourceCoverage(uv);
        tone = sourceTone(uv);
        lightCarrier = 0.0;
        float hybridGate = 1.0;
        if (hybridMode != 0) {
            vec2 radialAxis = safeDirection(
                (uv - focus) * resolution, vec2(cos(angle), sin(angle)));
            float alignment = abs(dot(
                radialAxis, vec2(cos(angle), sin(angle))));
            float handVariation = valueNoise(vec2(
                atan(radialAxis.y, radialAxis.x) * 1.35,
                salt * 0.0031), salt + 3907.0);
            // Admit coherent radial wedges along the linear action axis and
            // reserve the orthogonal sectors as paper. A low nonzero union
            // floor would still print every saturated ribbon as black.
            float sector = smoothstep(0.20, 0.88,
                alignment + (handVariation - 0.5) * 0.12);
            hybridGate = mix(0.42, 0.84, sector) *
                mix(0.86, 1.0, handVariation);
        }
        float radialLayer = radialRibbonField(uv) * hybridGate;
        // The layer-only Radial pass bypasses impactField(), where Band is
        // normally applied. Apply the same material cut here so Hybrid does
        // not leave its Radial strokes solid while only Linear is banded.
        radialLayer = physicalBandCoverage(
            radialLayer, uv, baseFlow(uv), 0.0);
        fields = vec2(radialLayer, 0.0);
    }
    else {
        fields = impactField(uv, mask, tone, lightCarrier);
    }
    float field = fields.x;
    float hatchField = fields.y;
    // Background pigment is composited first and explicitly masked off every
    // captured surface, so subject strokes and hatching always own the front.
    float backgroundField = physicalBandCoverage(
        backgroundStrokeLayer(uv), uv, baseFlow(uv), 53.0);
    if (mode == 1) {
        backgroundField *= radialVoidGate((uv - focus) * resolution);
        if (hybridMode != 0) {
            vec2 radialAxis = safeDirection(
                (uv - focus) * resolution, vec2(cos(angle), sin(angle)));
            float alignment = abs(dot(
                radialAxis, vec2(cos(angle), sin(angle))));
            float sector = smoothstep(0.20, 0.88, alignment);
            backgroundField *= mix(0.44, 0.80, sector);
        }
    }
    field = 1.0 - (1.0 - backgroundField) * (1.0 - field);
    // Atlas deposition already resolves pressure into coverage. A low print
    // floor preserves graphite strands instead of thresholding them away.
    float fieldAA = clamp(fwidth(field) * 0.72, 0.008, 0.16);
    float printThreshold = mix(0.075, 0.035,
                               clamp(contrast, 0.0, 1.0));
    float baseInk = smoothstep(printThreshold - fieldAA,
                               printThreshold + fieldAA, field);
    // Reconstruct the tone marks independently so their derivatives cannot
    // soften or brighten a pre-existing opaque impact stroke. This preserves
    // pigment ownership while still giving every hatch its own sub-pixel AA.
    float hatchAA = clamp(fwidth(hatchField) * 0.72, 0.006, 0.16);
    float hatchEdge = smoothstep(0.012, 0.012 + hatchAA, hatchField);
    float hatchInk = clamp(hatchField * 1.12, 0.0, 1.0) * hatchEdge;
    float centerInk = 1.0 - (1.0 - baseInk) * (1.0 - hatchInk);
    // This smoothstep is the sole final edge reconstruction. A second
    // pressure-based opacity veil created a visible gray fringe around the
    // already anti-aliased pigment boundary.
    // G stores either the positive subject-light carrier or, on paper-only
    // pixels, negative background ownership. Keeping this signed ownership
    // channel alive lets every later effect attenuate and camera-steer the
    // background without a second impact render pass. B remains the rig mask
    // and A the captured key tone.
    // These channels are internal data; exported opacity remains unchanged.
    float backgroundOwner = smoothstep(0.012, 0.18, backgroundField) *
        (1.0 - smoothstep(0.015, 0.28, sourceCoverage(uv)));
    fragColor = vec4(centerInk,
        backgroundOwner > 0.0001 ? -backgroundOwner : lightCarrier,
        mask, tone);
}
