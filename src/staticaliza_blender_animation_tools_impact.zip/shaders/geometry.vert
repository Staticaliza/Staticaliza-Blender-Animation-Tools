in vec3 position;
in vec3 normal;
out vec3 vNormal;
void main() {
    vNormal=normal;
    gl_Position=vec4(position.xy*2.0-1.0,position.z,1.0);
}
