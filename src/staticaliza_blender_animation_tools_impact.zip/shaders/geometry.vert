in vec3 position;
in vec3 normal;
uniform vec2 lightFocus;
uniform float lightCastBehind;

out float vLight;
out vec2 vSurfaceNormal;

void main()
{
    // Orthographic projection of a camera-facing hemisphere: center is a
    // frontal key, while dragging toward an edge orbits around the subject.
    vec2 orbit = clamp((lightFocus - vec2(0.5)) * 2.0,
                       vec2(-1.0), vec2(1.0));
    float orbitLength = length(orbit);
    if (orbitLength > 1.0) orbit /= orbitLength;
    // At the boundary Z reaches zero, allowing genuinely side-on light.
    float orbitZ = sqrt(max(0.0, 1.0 - dot(orbit, orbit)));
    orbitZ *= mix(1.0, -1.0, step(0.5, lightCastBehind));
    vec3 keyDirection = normalize(vec3(orbit, orbitZ));
    // Evaluated meshes may use mirrored transforms or inconsistent winding.
    // Face the visible shading normal toward the camera before applying the
    // stylized key so front/side lighting remains stable across rig parts.
    vec3 shadingNormal = normalize(normal);
    if (shadingNormal.z < 0.0) shadingNormal = -shadingNormal;
    float front = clamp(shadingNormal.z, 0.0, 1.0);
    float lambert = max(dot(shadingNormal, keyDirection), 0.0);
    float rim = pow(1.0 - front, 3.0);
    // Store a stable directional carrier only. Light intensity belongs to the
    // composite pass; feeding it into this geometry/tone buffer changed line
    // seeding and made 0.2/0.5 Custom black reveal unrelated white anatomy.
    float angularAlignment = dot(shadingNormal, keyDirection);
    float reachEdge = -0.35;
    float reach = smoothstep(reachEdge - 0.35, reachEdge + 0.35,
                             angularAlignment);
    float directional = lambert * mix(0.42, 1.0, reach);
    float illumination = 0.16 + directional * 0.79 + rim * reach * 0.05;
    vLight = clamp(illumination, 0.0, 1.0);
    // Motion Blur is now a color-stage effect, so the two spare geometry
    // channels carry the view-facing surface normal. The drawing shader uses
    // this light-independent field to bend hatching gently around volume.
    vSurfaceNormal = shadingNormal.xy;
    gl_Position = vec4(position.xy * 2.0 - 1.0, position.z, 1.0);
}
