uniform sampler2D brushTex;
uniform sampler2D loadedBrushTex;
uniform sampler2D ownershipTex;
uniform float strokeStrength;
uniform float strokeBandAmount;
in float vLinearBandCoordinate;
in vec4 vStrokeStyle;
in vec2 vStrokeUV;
in vec4 vStrokeParams;
in vec2 uv;
in float vLinearDepth;
in vec4 vStrokeContact;
in float vStrokeVisibility;
in float vSourceOwner;
in float vContactOwner;
in float vContactVisible;
out vec4 fragColor;

float hash21(vec2 p)
{
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float hash11(float p)
{
    return hash21(vec2(p, p * 1.61803398875));
}

float valueNoise(vec2 p, float seed)
{
    vec2 cell = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    vec2 s = vec2(seed * 0.071, seed * 0.113);
    float a = hash21(cell + s);
    float b = hash21(cell + vec2(1.0, 0.0) + s);
    float c = hash21(cell + vec2(0.0, 1.0) + s);
    float d = hash21(cell + vec2(1.0, 1.0) + s);
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

float quinticEase(float t)
{
    t = clamp(t, 0.0, 1.0);
    return t * t * t * (t * (t * 6.0 - 15.0) + 10.0);
}
float brushRibbonDeposit(float across, float halfWidth, float along01,
                         float alongPixelWidth, float familySeed)
{
    // Most candidate families cannot affect a given fragment. Reject their
    // conservative footprint before atlas lookup/noise work; the bound also
    // includes the two escaping companion filaments below.
    if (along01 < -0.09 || along01 > 1.09 ||
        abs(across) > halfWidth * 1.62 + 1.4) {
        return 0.0;
    }
    // Pressure changes once across the gesture; it must not turn the brush
    // silhouette into a repeating water-wave pattern.
    float widthDrift = 1.0;
    // Impact strokes emit from a loaded base and exhaust into a pointed fiber
    // tail. The source stays near full width; only the travel end collapses.
    float travelT = clamp(along01, 0.0, 1.0);
    float pressureShape = mix(0.82, 1.0, quinticEase(travelT / 0.14));
    float tipSeed = hash11(familySeed * 71.3 + 19.0);
    // Thick strokes retain more of their loaded end. The taper is a shallow
    // pressure release, not a rocket spike or a sudden triangular cut.
    float terminalWidth = mix(0.18, 0.52, tipSeed);
    float sizeClass = smoothstep(3.0, 28.0, halfWidth);
    // Individual pressure-release lengths make wedges and loaded shoulders
    // instead of identical rods. The centerline remains straight.
    float taperStart = mix(0.30, 0.66, hash11(familySeed * 89.3 + 31.0));
    float bodyTaper = mix(1.0, terminalWidth,
        quinticEase((travelT - taperStart) / (1.0-taperStart)));
    float fiberTerminal = mix(0.20, 0.50,
        hash11(familySeed * 97.1 + 43.0));
    float fiberTaper = mix(1.0, fiberTerminal,
        quinticEase((travelT - taperStart) / (1.0-taperStart)));
    // A loaded heel remains broad, but not a ruler-cut rectangle. This small
    // geometric pickup combines with the atlas pressure attack to round and
    // feather the emitter-side end without turning it into a symmetric spike.
    float heelPickup = mix(0.82, 1.0, quinticEase(travelT / 0.055));
    float bodyHalfWidth = max(
        halfWidth * widthDrift * pressureShape * bodyTaper * heelPickup, 0.38);
    float fiberHalfWidth = max(
        halfWidth * widthDrift * mix(0.86, 1.0, pressureShape) * fiberTaper,
        0.32);
    float bodyAcross = across / bodyHalfWidth;
    float fiberAcross = across / fiberHalfWidth;
    float variant = floor(hash11(familySeed * 83.17 + 17.0) * 4.0);
    float bodyLocal = bodyAcross * 0.5 + 0.5;
    float fiberLocal = fiberAcross * 0.5 + 0.5;
    // The brush does not end on one geometric plane. Continuous correlated
    // bristle lengths avoid both a flat cap and the visible stair-steps caused
    // by assigning an entire transverse strip one endpoint.
    // The center bristles travel beyond the outer bristles, but correlated
    // breakup keeps the pressure crown from becoming a clean vector point.
    float bodyTipBase = clamp(1.0 - abs(bodyAcross), 0.0, 1.0);
    float fiberTipBase = clamp(1.0 - abs(fiberAcross), 0.0, 1.0);
    float bodyTipCrown = sqrt(bodyTipBase) *
        mix(0.86, 1.0, bodyTipBase) * 0.018;
    float fiberTipCrown = sqrt(sqrt(fiberTipBase)) *
        mix(0.82, 1.0, fiberTipBase) * 0.055;
    float bodyEndShape = bodyTipCrown +
        (valueNoise(vec2(bodyLocal * 9.7, familySeed * 13.1),
                    familySeed + 1871.0) - 0.5) * 0.13 +
        (valueNoise(vec2(bodyLocal * 27.3, familySeed * 7.9),
                    familySeed + 1907.0) - 0.5) * 0.055;
    float fiberEndShape = fiberTipCrown +
        (valueNoise(vec2(fiberLocal * 13.1, familySeed * 17.3),
                    familySeed + 1933.0) - 0.5) * 0.18 +
        (valueNoise(vec2(fiberLocal * 35.7, familySeed * 5.7),
                    familySeed + 1973.0) - 0.5) * 0.07;
    float bodyEnd = 0.985 + bodyEndShape;
    float fiberEnd = 0.995 + fiberEndShape;
    float bodyStartShape =
        (valueNoise(vec2(bodyLocal * 8.1, familySeed * 11.7),
                    familySeed + 1997.0) - 0.5) * 0.060 +
        (valueNoise(vec2(bodyLocal * 24.9, familySeed * 6.3),
                    familySeed + 2011.0) - 0.5) * 0.025;
    float fiberStartShape =
        (valueNoise(vec2(fiberLocal * 12.7, familySeed * 15.1),
                    familySeed + 2039.0) - 0.5) * 0.085 +
        (valueNoise(vec2(fiberLocal * 33.1, familySeed * 4.9),
                    familySeed + 2063.0) - 0.5) * 0.035;
    float bodyStart = -0.008 + bodyStartShape;
    float fiberStart = -0.014 + fiberStartShape;
    vec2 bodyUV = vec2(
        clamp((along01 - bodyStart) /
              max(bodyEnd - bodyStart, 0.1), 0.0, 1.0),
        (variant + clamp(bodyLocal, 0.0, 1.0)) * 0.25
    );
    vec2 fiberUV = vec2(
        // Keep atlas contact into the analytic staggered end instead of
        // multiplying two coincident release envelopes.
        clamp((along01 - fiberStart) /
              max(fiberEnd - fiberStart, 0.1) * 0.88, 0.0, 1.0),
        (variant + clamp(fiberLocal, 0.0, 1.0)) * 0.25
    );
    // Derivative-sized transition bands replace binary step clipping. They
    // cover approximately one output pixel at any angle or preview scale.
    float alongAA = clamp(alongPixelWidth * 1.18, 0.0015, 0.08);
    float bodyAlong = smoothstep(bodyStart - alongAA,
                                 bodyStart + alongAA, along01) *
        (1.0 - smoothstep(bodyEnd - alongAA,
                          bodyEnd + alongAA, along01));
    float fiberAlong = smoothstep(fiberStart - alongAA,
                                  fiberStart + alongAA, along01) *
        (1.0 - smoothstep(fiberEnd - alongAA,
                          fiberEnd + alongAA, along01));
    // A diagonal pixel spans more of the perpendicular coordinate than an
    // axis-aligned pixel. Derivative-aware coverage keeps 45-degree swipes
    // crisp without post-process blur.
    float acrossFootprint = max(fwidth(across), 0.75);
    float bodyAA = clamp(acrossFootprint / bodyHalfWidth, 0.006, 0.32);
    float fiberAA = clamp(acrossFootprint / fiberHalfWidth, 0.006, 0.32);
    float bodyClip = 1.0 - smoothstep(1.04 - bodyAA,
                                      1.04 + bodyAA, abs(bodyAcross));
    float fiberClip = 1.0 - smoothstep(1.04 - fiberAA,
                                       1.04 + fiberAA, abs(fiberAcross));
    float body = texture(loadedBrushTex, bodyUV).r * bodyClip * bodyAlong;
    float fibers = texture(brushTex, fiberUV).g * fiberClip * fiberAlong;
    // Resolve the travel end into the atlas' independently staggered bristle
    // endpoints. The coherent body remains loaded through most of the swipe,
    // then yields to its comb instead of presenting one shared flat cutoff.
    float terminalBreakup = quinticEase((travelT - 0.84) / 0.16);
    body *= mix(1.0, 0.06 + fibers * 0.94, terminalBreakup);
    // Fibers may break through the loaded body, but cannot become a second
    // full-strength parallel silhouette. The transverse envelope keeps the
    // outermost bristles attached to the gesture and removes the dark rail /
    // halo visible around otherwise smooth strokes.
    float fiberEnvelope = 1.0 - smoothstep(
        0.58, 0.98, abs(fiberAcross));
    float fiberDeposit = fibers * fiberEnvelope * 0.72;
    float deposit = 1.0 - (1.0 - body) * (1.0 - fiberDeposit);

    // Broad parents are dragged charcoal bundles, not opaque vector slabs.
    // This low-frequency transverse field cuts several persistent bristle
    // channels through the belly while keeping the heel and terminal comb
    // connected. The field is stroke-local, so it bends with the gesture.
    float combDrift = (travelT - 0.5) * mix(-0.14, 0.14,
        hash11(familySeed * 107.9 + 53.0));
    float combTooth = valueNoise(vec2(
        bodyAcross * 5.4 + combDrift,
        familySeed * 11.3), familySeed + 2111.0);
    float combGap = smoothstep(0.48, 0.67, combTooth) *
        smoothstep(0.09, 0.22, travelT) *
        (1.0 - smoothstep(0.78, 0.96, travelT));
    deposit *= 1.0 - sizeClass * combGap * 0.16;

    // Some loaded marks preserve a single longitudinal scrape where one
    // charcoal filament lost contact.  Its start, end and transverse drift
    // belong to the parent gesture; this creates a white bristle opening
    // without the repeated parallel rails of an exposed multi-line stamp.
    float scrapePresence = step(mix(0.76, 0.28, sizeClass),
        hash11(familySeed * 113.7 + 61.0));
    float scrapeCenter = mix(-0.66, 0.66,
        hash11(familySeed * 127.1 + 73.0));
    float scrapeStart = mix(0.26, 0.50,
        hash11(familySeed * 149.3 + 83.0));
    float scrapeEnd = mix(0.56, 0.80,
        hash11(familySeed * 163.9 + 97.0));
    float scrapeDrift = (travelT - 0.5) *
        mix(-0.04, 0.04, hash11(familySeed * 173.3 + 101.0));
    float scrapeWidth = mix(0.022, 0.058,
        hash11(familySeed * 193.1 + 109.0));
    float scrapeLane = exp(-0.5 * pow(
        (bodyAcross - scrapeCenter - scrapeDrift) / scrapeWidth, 2.0));
    float scrapeWindow = smoothstep(scrapeStart - 0.055, scrapeStart, travelT) *
        (1.0 - smoothstep(scrapeEnd, scrapeEnd + 0.055, travelT));
    float scrapeDepth = mix(0.04, 0.10,
        hash11(familySeed * 211.7 + 127.0));
    deposit *= 1.0 - scrapePresence * scrapeLane * scrapeWindow * scrapeDepth;

    // Loaded mass strokes may carry one shorter secondary dry channel. It is
    // restricted to broad parents and staggered independently, so the result
    // reads as a scraped brush belly rather than parallel bacon stripes.
    float secondaryPresence = sizeClass * step(0.56,
        hash11(familySeed * 227.3 + 131.0));
    float secondaryCenter = mix(-0.72, 0.72,
        hash11(familySeed * 239.9 + 137.0));
    float secondaryStart = mix(0.34, 0.58,
        hash11(familySeed * 251.1 + 149.0));
    float secondaryEnd = mix(0.66, 0.88,
        hash11(familySeed * 263.7 + 157.0));
    float secondaryLane = exp(-0.5 * pow(
        (bodyAcross - secondaryCenter) / mix(0.025, 0.060,
            hash11(familySeed * 277.1 + 163.0)), 2.0));
    float secondaryWindow = smoothstep(
        secondaryStart - 0.04, secondaryStart, travelT) *
        (1.0 - smoothstep(secondaryEnd, secondaryEnd + 0.04, travelT));
    deposit *= 1.0 - secondaryPresence * secondaryLane *
               secondaryWindow * 0.10;
    // Loaded charcoal may scrape and granulate, but its central belly should
    // not open into a perfectly white ruler-line across a limb. Preserve a
    // low optical-density core; edge combs and pointed terminals stay broken.
    float loadedCore = bodyClip * bodyAlong *
        (1.0 - smoothstep(0.30, 0.68, abs(bodyAcross)));
    // Connected pigment exists even on small carriers. Keep the material
    // tooth near the boundary, not as ruler-long holes through the belly.
    float tooth = mix(0.16, 0.24, valueNoise(
        vec2(travelT * 47.0, bodyAcross * 17.0), familySeed + 2903.0));
    deposit = max(deposit, loadedCore * tooth * (1.0-terminalBreakup));
    return deposit;
}

void main() {
 vec3 scene = texelFetch(ownershipTex, ivec2(gl_FragCoord.xy), 0).rgb;
 // Other meshes always occlude a deeper brush, including its loaded rim.
 bool sameSource = scene.y > 0.5 && abs(scene.z-vSourceOwner)<0.25;
 bool foreignSurface = scene.y > 0.5 && !sameSource;
 if (foreignSurface && vLinearDepth >= scene.x - 0.00005) discard;
 bool ownMotion = mod(floor(vStrokeStyle.w / 2.0), 2.0) > 0.5 && sameSource;
 // Cast Behind retains the supported charcoal buildup on its source rim.
 // The connected brush stays loaded across release on this same surface.
 // Foreign meshes still occlude it; Cast Behind off keeps physical self-depth.
 bool ownRim = vStrokeStyle.w >= 4.0 && sameSource;
 if (scene.y > 0.5 && vLinearDepth > scene.x + 0.00005 && !ownMotion && !ownRim) discard;
 float familySeed = vStrokeStyle.x;
 float familyF = vStrokeStyle.y;
 float primary = vStrokeStyle.z;
 float gap = mod(vStrokeStyle.w, 2.0);
 float bodyWidth = vStrokeParams.x;
 float familyWakeT = vStrokeUV.x;
 float localAcross = vStrokeUV.y * bodyWidth;
 // Compress the carrier while preserving finer material strands.
 bodyWidth *= mix(1.0,0.48,pow(clamp(strokeBandAmount,0.0,1.0),1.25));
 float heelStagger = (valueNoise(vec2(vStrokeUV.y*3.7,familySeed),familySeed+811.0)-0.5)*0.035;
 float contactAttack = smoothstep(-0.045+heelStagger,
     min(0.055,max(0.018,vStrokeParams.z*.20))+heelStagger,familyWakeT);
            float releaseStart = primary > 0.5
                ? mix(0.48, 0.68, hash11(familySeed * 401.3 + 131.0))
                : (gap > 0.5
                    ? mix(0.40, 0.60,
                        hash11(familySeed * 409.7 + 139.0))
                    : mix(0.34, 0.54,
                        hash11(familySeed * 419.9 + 149.0)));
            float releaseT = quinticEase(
                (familyWakeT - releaseStart) / max(1.0 - releaseStart, 0.08));
            float wakeWidth = bodyWidth * mix(
                primary > 0.5 ? 0.94 : (gap > 0.5 ? 0.86 : 0.78),
                primary > 0.5 ? 0.86 : (gap > 0.5 ? 0.80 : 0.72),
                releaseT);
            // Load the face-contact band without thickening every free tip.
            // The transition is measured in the same arclength as the brush.
            float faceLoad = 1.0 - smoothstep(
                vStrokeParams.z * 0.65, vStrokeParams.z + 0.06, familyWakeT);
            wakeWidth *= 1.0 + 0.10 * faceLoad;
            // The inlet acquires pressure across the supporting face. A
            // full-width stamp at its first point makes a new hard slab
            // boundary even when the geometry starts at staggered depths.
            wakeWidth *= mix(0.38, 1.0, sqrt(contactAttack));
            // A surface-only heel starts at the silhouette and lifts over a
            // short distance. A long trail's constant-width pressure makes
            // this finite contact look like a row of little hanging rods.
            bool shortPickup = vStrokeContact.x < -0.5;
            if (shortPickup) wakeWidth = bodyWidth * 1.65 *
                pow(max(0.0,1.0-clamp(familyWakeT,0.0,1.0)),0.85);
            float rearAcross = localAcross;
            float rearShape = brushRibbonDeposit(
                rearAcross, max(wakeWidth, 0.55), familyWakeT,
                vStrokeParams.w * 0.82,
                familySeed + familyF * 101.0 + 6337.0);
            // Short companion bristles share this surface-owned ribbon and
            // its depth test. They load gaps near the heel, then terminate
            // independently well before the primary tip. No extra tracing,
            // detached pickup layer, or whole-body opaque fill is involved.
            float rootSide = localAcross < 0.0 ? -1.0 : 1.0;
            float rootSeed = hash11(familyF * 41.7 + familySeed * 83.1 + rootSide * 7.3);
            float rootStart = mix(-0.025, 0.045, rootSeed);
            float rootEnd = mix(0.18, 0.38, rootSeed) *
                (1.0 - vStrokeParams.z) + vStrokeParams.z;
            float rootT = (familyWakeT-rootStart)/max(rootEnd-rootStart,0.08);
            if (!shortPickup && rootT > -0.05 && rootT < 1.08) {
                float rootWidth = bodyWidth * mix(0.62,0.42,rootSeed) *
                    mix(1.0,0.12,quinticEase(clamp(rootT,0.0,1.0)));
                // Bristles belong inside the parent shoulder, not on a
                // detached parallel track that survives as a stray hairline.
                float rootOffset = rootSide * wakeWidth * mix(0.35,0.55,rootSeed);
                float rootInk = brushRibbonDeposit(localAcross-rootOffset,
                    max(rootWidth,0.4),rootT,
                    vStrokeParams.w/max(rootEnd-rootStart,0.08),
                    familySeed+familyF*101.0+ rootSide*43.0+7193.0);
                float attached = 1.0-smoothstep(0.85,1.12,
                    abs(localAcross)/max(wakeWidth,0.55));
                rearShape=max(rearShape,rootInk*attached*0.92);
            }
            float rearPresence = 1.0;
            float rearLoad = primary > 0.5
                ? mix(0.34, 0.56, familySeed)
                : (gap > 0.5
                    ? mix(0.26, 0.44, familySeed)
                    : mix(0.22, 0.38, familySeed));

 // Pressure shapes width and edge tooth; it must not tint a loaded black
 // stroke gray. Core and fringe share pigment, but retain distinct coverage.
 // A loaded root is a soft contact band, not merely the already-black
 // stroke pixels. Pressure rises through the supporting face, then the
 // existing release separates into bristles. The compositor consumes this
 // exact visible support so hatch and white plate recede progressively.
 float rootPickup = quinticEase(clamp(familyWakeT /
     max(vStrokeParams.z, 0.06), 0.0, 1.0));
 // Support follows the deposited brush. An independent filled cross-strip
 // merges newly visible front contacts into opaque horizontal bands.
 // Pressure reveals fixed charcoal clumps rather than fading a solid
 // ribbon through gray. Stroke-local coordinates keep tooth attached to
 // the supported face as the pin moves; no extra geometry or blur pass.
 // Size the loading distance from the brush itself, even when the
 // supported face projects to almost zero arclength. A contact-fraction
 // minimum made grazing heels become square, fully loaded stamps.
 float pickupSpan=clamp(bodyWidth*vStrokeParams.w*
     mix(1.8,3.4,hash11(familySeed*193.7+familyF*17.3)),0.035,0.30);
 float bristleStart=pickupSpan*0.40*valueNoise(
     vec2(vStrokeUV.y*2.1,familyF),familySeed+8351.0);
 float pickupPressure=clamp((familyWakeT-bristleStart)/pickupSpan+0.30,0.0,1.0);
 vec2 toothCoord=vec2(familyWakeT/max(vStrokeParams.w,0.000001),localAcross);
 float pickupTooth=mix(
     valueNoise(toothCoord*vec2(0.16,0.70),familySeed+8231.0),
     valueNoise(toothCoord*vec2(0.45,1.20),familySeed+8293.0),0.28);
 float pickupCoverage=smoothstep(pickupTooth*0.78+0.06,
     pickupTooth*0.78+0.16,pickupPressure);
 rearShape *= shortPickup ? 1.0 : pickupCoverage;
 // Coverage follows the brush's supported path and tapered material.
 // A screen-space distance-to-outline mask cut those paths into dirty rails
 // and tiny fragments at the source border. Foreign ownership and physical
 // depth are still resolved above.
 // Refresh only fine pigment breakup on motion exposures. The family's
 // outline, taper and trajectory keep their existing identity.
 if (mod(floor(vStrokeStyle.w / 2.0), 2.0) > 0.5) {
     float paperTooth = valueNoise(vec2(familyWakeT * 73.0, vStrokeUV.y * 19.0),
                                   vStrokeParams.y + 9017.0);
     rearShape *= mix(0.84, 1.0, smoothstep(0.20, 0.65, paperTooth));
 }
 // Split deposited bristles in their 3D path coordinates, never by a
 // transverse image stencil. Increased Band adds stagger and compression.
 if (strokeBandAmount > 0.0001) {
     float amount=clamp(strokeBandAmount,0.0,1.0);
     float irregular=pow(amount,1.25);
     float period=mix(0.75,0.27,pow(amount,0.8));
     float bristle=localAcross*0.52+31.0;
     float lane=floor(bristle);

     float family=vStrokeStyle.y+vSourceOwner*91.7;
     float coordinate=vLinearBandCoordinate/period;
     coordinate+=hash11(vSourceOwner*51.3)*0.8;
     coordinate+=(valueNoise(vec2(lane*0.23,family),83.0)-0.5)*irregular*1.4;
     coordinate+=(hash11(lane*11.7+family)-0.5)*mix(0.04,0.50,irregular);
     float cell=floor(coordinate);
     float pressure=1.0;
     for (int j=-1;j<=1;++j) {
         float k=cell+float(j);
         float event=hash11(k*47.1+vSourceOwner*19.3);
         float center=k+0.5+(event-0.5)*irregular*0.65;
         float halfGap=mix(0.004,0.19,amount)*mix(0.48,1.55,event);
         float tip=mix(0.06,0.32,hash11(k*29.3+lane*7.1+family));
         float d=abs(coordinate-center)-halfGap;
         pressure=min(pressure,clamp(d/tip,0.0,1.0));
     }
     // Strand spacing lives in physical across-stroke pixels, not normalized
     // width coordinates that magnified changing pressure into wavy channels.
     // Pressure narrows each strand and fades its pigment at every break.
     float lateral=abs(localAcross)/(max(wakeWidth,0.55)*1.62+1.4);
     float aa=max(fwidth(lateral)*0.70,0.006);
     float strandDistance=abs(fract(bristle)-0.5)*2.0;
     float strandWidth=mix(0.80,0.38,irregular)*pow(pressure,0.65);
     float strandAA=max(fwidth(bristle)*0.8,0.035);
     float strand=1.0-smoothstep(strandWidth-strandAA,strandWidth+strandAA,strandDistance);
     float gate=(1.0-smoothstep(pressure-aa,pressure+aa,lateral))*strand*pow(pressure,0.45);
     rearShape*=mix(1.0,gate,smoothstep(0.0,0.08,amount));
 }
 rearShape *= smoothstep(0.0, 1.0, vStrokeVisibility);
 float rootSupport = faceLoad * rootPickup * rearShape;
 float ink = rearShape * rearLoad *
     (strokeStrength > 0.0 ? 0.857 : 0.0);
 gl_FragDepth = 1.0 - clamp(ink, 0.0, 1.0);
 // G carries only visible root pigment. The subject drawing consumes this
 // same depth-tested support for its hatch/light transition.
 fragColor = vec4(ink, max(ink * faceLoad, rootSupport * 0.24), vLinearDepth, vSourceOwner);
}
