uniform sampler2D colorTex;
uniform sampler2D grainTex;
uniform sampler2D shapeMaskTex;
uniform vec4 foreground;
in vec2 uv;
out vec4 fragColor;
void main()
{
    vec4 color = texture(colorTex, uv);
    vec2 shape = texture(shapeMaskTex, uv).rg;
    float influence = shape.g > .0001 ? clamp(shape.r / shape.g, 0., 1.) : 1.;
    vec3 grain = texture(grainTex, uv).rgb;
    color.rgb = mix(color.rgb, foreground.rgb, clamp(grain.g * influence, 0., 1.));
    color.rgb = mix(color.rgb, vec3(1.) - color.rgb, clamp(grain.b * influence, 0., .96));
    fragColor = color;
}
