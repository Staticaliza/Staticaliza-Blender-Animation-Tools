in float vLinearDepth;
in float vSurfaceOwner;
out vec4 fragColor;
void main() {
 fragColor = vec4(vLinearDepth, 1.0, vSurfaceOwner, 1.0);
}
