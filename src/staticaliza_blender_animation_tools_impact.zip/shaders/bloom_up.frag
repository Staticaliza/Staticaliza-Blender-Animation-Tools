uniform sampler2D lowTex;
uniform sampler2D highTex;
uniform vec2 lowResolution;
uniform float lowWeight;
uniform float highWeight;

in vec2 uv;
out vec4 fragColor;

void main()
{
    vec2 texel = 1.0 / lowResolution;
    vec3 low = texture(lowTex, uv).rgb * 0.25;
    low += (texture(lowTex, uv + vec2( texel.x, 0.0)).rgb +
            texture(lowTex, uv + vec2(-texel.x, 0.0)).rgb +
            texture(lowTex, uv + vec2(0.0,  texel.y)).rgb +
            texture(lowTex, uv + vec2(0.0, -texel.y)).rgb) * 0.125;
    low += (texture(lowTex, uv + vec2( texel.x,  texel.y)).rgb +
            texture(lowTex, uv + vec2(-texel.x,  texel.y)).rgb +
            texture(lowTex, uv + vec2( texel.x, -texel.y)).rgb +
            texture(lowTex, uv + vec2(-texel.x, -texel.y)).rgb) * 0.0625;
    vec3 high = texture(highTex, uv).rgb;
    // Progressive additive reconstruction: deeper mips are smoothly activated
    // by Bloom amount, so the point-spread radius grows instead of merely
    // brightening a fixed blur footprint.
    fragColor = vec4(high * highWeight + low * lowWeight, 1.0);
}
