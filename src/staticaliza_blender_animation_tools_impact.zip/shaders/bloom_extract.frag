uniform sampler2D colorTex;
uniform sampler2D impactTex;
uniform sampler2D grainTex;
uniform sampler2D shapeMaskTex;
uniform vec2 resolution;
uniform vec4 foreground;
uniform vec4 background;
uniform float aberrationActive;
uniform float grainActive;
uniform float grainBloomMix;

in vec2 uv;
out vec4 fragColor;

float cleanInkAt(vec2 p)
{
    return step(0.5, texture(impactTex, clamp(p, vec2(0.0), vec2(1.0))).r);
}

float fringeDistance(vec3 color)
{
    return min(length(color - foreground.rgb), length(color - background.rgb));
}

void main()
{
    vec3 sourceColor = texture(colorTex, uv).rgb;
    float centerInk = cleanInkAt(uv);
    float backgroundOwner = clamp(-texture(impactTex, uv).g, 0.0, 1.0);
    vec2 shapeData = texture(shapeMaskTex, uv).rg;
    float shapeOwner = shapeData.r;
    float shapeCoverage = shapeData.g;
    float fgLum = dot(foreground.rgb, vec3(0.2126, 0.7152, 0.0722));
    float bgLum = dot(background.rgb, vec3(0.2126, 0.7152, 0.0722));
    bool foregroundIsLight = fgLum > bgLum;
    float lightMask = foregroundIsLight ? centerInk : (1.0 - centerInk);

    float resolutionScale = max(0.25, min(resolution.x, resolution.y) / 720.0);
    vec2 edgePx = vec2(1.75 * resolutionScale) / resolution;
    float opposite = 0.0;
    opposite = max(opposite, abs(cleanInkAt(uv + vec2(edgePx.x, 0.0)) - centerInk));
    opposite = max(opposite, abs(cleanInkAt(uv - vec2(edgePx.x, 0.0)) - centerInk));
    opposite = max(opposite, abs(cleanInkAt(uv + vec2(0.0, edgePx.y)) - centerInk));
    opposite = max(opposite, abs(cleanInkAt(uv - vec2(0.0, edgePx.y)) - centerInk));

    vec2 spectralPx = edgePx * 2.4;
    vec3 spectralColor = sourceColor;
    float localDistance = fringeDistance(sourceColor);
    vec3 neighbor = texture(colorTex, uv + vec2(spectralPx.x, 0.0)).rgb;
    float neighborDistance = fringeDistance(neighbor);
    if (neighborDistance > localDistance) { spectralColor = neighbor; localDistance = neighborDistance; }
    neighbor = texture(colorTex, uv - vec2(spectralPx.x, 0.0)).rgb;
    neighborDistance = fringeDistance(neighbor);
    if (neighborDistance > localDistance) { spectralColor = neighbor; localDistance = neighborDistance; }
    neighbor = texture(colorTex, uv + vec2(0.0, spectralPx.y)).rgb;
    neighborDistance = fringeDistance(neighbor);
    if (neighborDistance > localDistance) { spectralColor = neighbor; localDistance = neighborDistance; }
    neighbor = texture(colorTex, uv - vec2(0.0, spectralPx.y)).rgb;
    neighborDistance = fringeDistance(neighbor);
    if (neighborDistance > localDistance) { spectralColor = neighbor; localDistance = neighborDistance; }

    // Exact duotone regions do not become full-area emitters merely because
    // their endpoint is saturated. Only the canonical edge and colors added
    // by aberration seed the glow pyramid.
    float spectralChroma = max(spectralColor.r,
                           max(spectralColor.g, spectralColor.b)) -
                           min(spectralColor.r,
                           min(spectralColor.g, spectralColor.b));
    float spectralSeed = max(smoothstep(0.012, 0.30, localDistance),
                             smoothstep(0.008, 0.24, spectralChroma)) *
                         aberrationActive;
    float boundarySeed = opposite * mix(0.46, 1.0, lightMask);
    // When dispersion is active, its wavelength-resolved radiance must remain
    // the dominant bloom emitter. A full-strength neutral boundary source
    // averages the prism back to white in the mip pyramid and makes colored
    // glow disappear over light paper.
    float neutralBoundary = boundarySeed * mix(1.0, 0.28, aberrationActive);
    float baseEmitter = clamp(max(neutralBoundary, spectralSeed), 0.0, 1.0);
    float grainCoverage = texture(grainTex, uv).r * grainActive;
    vec2 grainPx = vec2(1.35 * resolutionScale) / resolution;
    float grainNeighbor = 0.0;
    grainNeighbor = max(grainNeighbor, texture(grainTex, uv + vec2(grainPx.x, 0.0)).r);
    grainNeighbor = max(grainNeighbor, texture(grainTex, uv - vec2(grainPx.x, 0.0)).r);
    grainNeighbor = max(grainNeighbor, texture(grainTex, uv + vec2(0.0, grainPx.y)).r);
    grainNeighbor = max(grainNeighbor, texture(grainTex, uv - vec2(0.0, grainPx.y)).r);
    grainNeighbor *= grainActive;
    float grainBoundary = abs(grainNeighbor - grainCoverage);
    float grainOuterRing = grainNeighbor * (1.0 - grainCoverage);
    float foregroundLightAdvantage = smoothstep(
        0.01, 0.55, fgLum - bgLum);
    float backgroundLightAdvantage = smoothstep(
        0.01, 0.55, bgLum - fgLum);
    float brightGrainEmitter = grainCoverage * foregroundLightAdvantage;
    // A dark deposit does not emit, but the bright paper immediately around
    // its boundary does. Seed that boundary so neutral Bloom can bleed across
    // grain exactly as the spectral branch already does when aberration is on.
    float darkGrainEmitter = max(grainOuterRing,
                                 grainBoundary * 0.65) *
                             backgroundLightAdvantage;
    float grainEmitter = max(brightGrainEmitter, darkGrainEmitter) *
                         grainBloomMix * mix(1.0, 0.35, aberrationActive);

    vec3 lightEndpoint = foregroundIsLight ? foreground.rgb : background.rgb;
    // Shapes emit their authored color. Treating their binary ownership mask
    // as neutral endpoint light made every saturated shape converge to white
    // at strong Bloom.
    vec3 shapeColor = sourceColor;
    vec3 baseEmission = mix(lightEndpoint, spectralColor,
                            clamp(spectralSeed * 1.35, 0.0, 1.0));
    // Shapes seed bloom at their luminous boundary. Treating the complete
    // fill as an emitter produced a flat colored duplicate, not diffusion.
    float shapeEdge = 0.0;
    shapeEdge = max(shapeEdge, abs(texture(shapeMaskTex, uv + vec2(edgePx.x, 0.0)).r - shapeOwner));
    shapeEdge = max(shapeEdge, abs(texture(shapeMaskTex, uv - vec2(edgePx.x, 0.0)).r - shapeOwner));
    shapeEdge = max(shapeEdge, abs(texture(shapeMaskTex, uv + vec2(0.0, edgePx.y)).r - shapeOwner));
    shapeEdge = max(shapeEdge, abs(texture(shapeMaskTex, uv - vec2(0.0, edgePx.y)).r - shapeOwner));
    float shapeEmitter = max(shapeEdge, shapeOwner * 0.075);
    float graphicEmitter = max(baseEmitter, shapeEmitter * 0.72);
    float layerAttenuation =
        mix(mix(1.0, 0.20, backgroundOwner), 0.72, shapeOwner);
    float emissionWeight = (graphicEmitter + grainEmitter) * layerAttenuation;
    vec3 grainLightColor = foregroundIsLight ? foreground.rgb : background.rgb;
    vec3 graphicColor = mix(baseEmission, shapeColor, shapeCoverage);
    vec3 emissionColor = (
        graphicColor * graphicEmitter + grainLightColor * grainEmitter
    ) / max(0.0001, graphicEmitter + grainEmitter);
    fragColor = vec4(emissionColor * clamp(emissionWeight, 0.0, 1.0), 1.0);
}
