uniform sampler2D colorTex;
uniform sampler2D impactTex;
uniform sampler2D shapeMaskTex;
uniform vec2 resolution;
uniform int mode;
uniform float angle;
uniform vec2 focus;
uniform float amount;
uniform float directionPolarity;
uniform vec2 cameraMotion;

in vec2 uv;
out vec4 fragColor;

vec2 blurDirection(vec2 p)
{
    vec2 linear = vec2(cos(angle), sin(angle));
    if (mode == 0)
        return normalize(linear + vec2(1e-7)) * directionPolarity;
    vec2 radialPixels = (p - focus) * resolution;
    float radius = length(radialPixels);
    vec2 radial = radius > 1.0 ? radialPixels / radius
                               : normalize(linear + vec2(1e-7));
    // Spatial 3D modes use the pink pin as the wind source. The visible trail
    // moves away from that source, matching the canonical ink polarity.
    return radial * directionPolarity;
}

float backgroundOwner(vec2 p)
{
    return clamp(-texture(impactTex,
        clamp(p, vec2(0.0), vec2(1.0))).g, 0.0, 1.0);
}

vec2 resolvedDirection(vec2 p, float ownership)
{
    vec2 subjectDirection = blurDirection(p);
    vec2 fallback = subjectDirection;
    vec2 cameraDirection = length(cameraMotion) > 0.00001
        ? normalize(-cameraMotion) : fallback;
    if (dot(cameraDirection, fallback) < 0.0) cameraDirection *= -1.0;
    return normalize(mix(fallback, cameraDirection, ownership * 0.88) +
                     vec2(1e-7));
}

vec4 sampleColor(vec2 p)
{
    return texture(colorTex, clamp(p, vec2(0.0), vec2(1.0)));
}

void main()
{
    float ownership = backgroundOwner(uv);
    vec2 shapeData = texture(shapeMaskTex, uv).rg;
    float shapeOwner = shapeData.r;
    float shapeCoverage = shapeData.g;
    float shapeInfluence = shapeCoverage > 0.0001
        ? clamp(shapeOwner / shapeCoverage, 0.0, 1.0) : 1.0;
    float blur = clamp(amount, 0.0, 1.0) *
        mix(mix(1.0, 0.24, ownership),
            0.68 * shapeInfluence, shapeCoverage);
    vec4 core = sampleColor(uv);
    if (blur <= 0.0001) {
        fragColor = core;
        return;
    }

    // A normalized one-sided shutter integral replaces the former seven
    // visibly separated copies. Samples are dense enough that maximum blur
    // reads as one continuous dragged exposure rather than stacked layers.
    // The sharp core is composited back afterward to retain graphic edges.
    float shortEdge = max(1.0, min(resolution.x, resolution.y));
    // Keep low values controllable but let 1.0 reach a full-impact shutter.
    float extentPixels = shortEdge * 0.235 * pow(blur, 0.72);
    vec2 stepUV = resolvedDirection(uv, ownership) *
        extentPixels / resolution;
    vec4 integrated = vec4(0.0);
    float weightSum = 0.0;
    const int shutterSamples = 33;
    for (int sampleIndex = 0; sampleIndex < shutterSamples; ++sampleIndex) {
        float t = (float(sampleIndex) + 0.5) / float(shutterSamples);
        float window = pow(max(0.0, 1.0 - t), 1.32);
        // A very small continuous bow prevents perfectly parallel digital
        // shelves without turning the blur into a wavy distortion.
        float bow = sin(t * 3.14159265) * (t - 0.5) * 0.012;
        vec2 perpendicular = vec2(-stepUV.y, stepUV.x);
        integrated += sampleColor(
            uv - stepUV * t + perpendicular * bow) * window;
        weightSum += window;
    }
    vec4 exposure = integrated / max(weightSum, 0.0001);
    // Influence changes shutter extent.  Shape pixels use the integrated
    // exposure once, avoiding a second sharp shape beneath the effected one.
    float exposureMix = mix(min(1.0, 1.08 * pow(blur, 0.62)),
                            1.0, shapeCoverage);
    vec3 color = mix(core.rgb, exposure.rgb, exposureMix);
    fragColor = vec4(clamp(color, 0.0, 1.0), core.a);
}
