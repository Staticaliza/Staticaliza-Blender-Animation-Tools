uniform sampler2D colorTex;
uniform sampler2D impactTex;
uniform sampler2D shapeMaskTex;
uniform sampler2D underShapeTex;
uniform sampler2D shapeInfluencesTex;
uniform sampler2D directionTex;
uniform sampler2D fieldOwnerTex;
uniform vec2 backgroundFocus;
uniform vec2 backgroundFlow;
uniform vec4 backgroundShape;
uniform vec2 resolution;
uniform float amount;
uniform int sampleCount;
uniform vec4 background;

in vec2 uv;
out vec4 fragColor;

float backgroundOwner(vec2 p)
{
    return clamp(-texture(impactTex,
        clamp(p, vec2(0.0), vec2(1.0))).g, 0.0, 1.0);
}


// Finite homogeneous translation through the captured camera. The same
// world-space dome vector drives the Linear ribbons and this shutter path.
vec2 opticalNumerator;
float opticalW;
float opticalDepth;

void prepareProjectedTravel(vec2 p)
{
    vec4 field = texture(directionTex, clamp(p, vec2(0.), vec2(1.)));
    float guideFamily = mod(round(abs(texture(fieldOwnerTex, clamp(p, vec2(0.), vec2(1.))).a)), 4.);

    if (guideFamily > 1.5) {
        // Background families recede from the cyan vanishing point. This
        // virtual depth translation also gives their radial perspective speed.
        float family = -guideFamily;
        if (family > -2.5 && family < -1.5) {
            // Match background2DPerspectiveFlow's signed transverse field.
            vec2 axis = normalize(backgroundFlow * resolution);
            vec2 normal = vec2(-axis.y, axis.x);
            float lane = dot((p-backgroundFocus)*resolution, normal);
            float shortEdge = min(resolution.x,resolution.y);
            float spread = clamp(abs(backgroundShape.x),0.,1.);
            spread = spread*spread*(3.-2.*spread);
            float response = spread*1.05/(1.+.55*spread);
            float transverse = lane/sqrt(lane*lane+shortEdge*shortEdge*.2116);
            vec2 flow = normalize(axis+normal*transverse*sign(backgroundShape.x)*
                response*mix(1.,.62,backgroundShape.y));
            field = vec4(flow*shortEdge*.9/resolution,0.,1.);
        } else {
            field = vec4(-(backgroundFocus * 2. - 1.) * .8, -.8, 1.);
        }
    }
    opticalW = max(.001, field.w);
    opticalDepth = field.z;
    opticalNumerator = .5 * (field.xy - (p * 2. - 1.) * field.z);
}

vec2 projectedTravel(float travel)
{
    // Exact projection of P + travel * V, relative to projection(P).
    // CPU bounds the rig shutter against its nearest captured camera depth.
    return travel * opticalNumerator / max(.05 * opticalW, opticalW + travel * opticalDepth);
}

// Continue a stroke through the crop along its optical tangent. Clamping
// X/Y independently repeats the rectangular border; replacing missing samples
// with paper instead creates shifted copies of that border. Intersect the
// ray with the valid pixel-center rectangle so its cross-section is retained.
// Per-destination values are invariant across all shutter/spectral taps.
vec4 destinationData;
vec4 destinationOwner;
float destinationFamily;
vec2 samplingOrigin;
vec2 samplingAxis;
float samplingInverseLength;
vec2 samplingLimits;
int samplingShapeCount;

void prepareOpticalSampling(vec2 axis)
{
    destinationData=texture(impactTex,uv);
    destinationOwner=texture(fieldOwnerTex,uv);
    destinationFamily=mod(round(abs(destinationOwner.a)),4.);
    samplingShapeCount=textureSize(shapeInfluencesTex,0).x;
    if(texelFetch(shapeInfluencesTex,ivec2(0,0),0).r<0.) samplingShapeCount=0;
    vec2 lo=.5/resolution, hi=vec2(1.)-lo;
    samplingOrigin=clamp(uv,lo,hi);
    samplingAxis=axis;
    samplingInverseLength=1./max(dot(axis,axis),1.e-30);
    samplingLimits=vec2(-1.e20,1.e20);
    if(abs(axis.x)>1.e-20){
        vec2 bounds=(vec2(lo.x,hi.x)-samplingOrigin.x)/axis.x;
        samplingLimits.x=max(samplingLimits.x,min(bounds.x,bounds.y));
        samplingLimits.y=min(samplingLimits.y,max(bounds.x,bounds.y));
    }
    if(abs(axis.y)>1.e-20){
        vec2 bounds=(vec2(lo.y,hi.y)-samplingOrigin.y)/axis.y;
        samplingLimits.x=max(samplingLimits.x,min(bounds.x,bounds.y));
        samplingLimits.y=min(samplingLimits.y,max(bounds.x,bounds.y));
    }
}

vec2 opticalSourceCoordinate(vec2 origin,vec2 offset)
{
    // Every tap lies on the same tangent. Clip its scalar distance using
    // the one precomputed ray/rectangle intersection, not four divides/tap.
    float distance=dot(offset,samplingAxis)*samplingInverseLength;
    return samplingOrigin+samplingAxis*clamp(distance,samplingLimits.x,samplingLimits.y);
}

bool foreignOpticalSource(vec2 origin,vec2 source)
{
    vec4 incomingOwner=texture(fieldOwnerTex,clamp(source,vec2(0.),vec2(1.)));
    float sourceFamily=mod(round(abs(incomingOwner.a)),4.);
    if(abs(destinationFamily-sourceFamily)>.5)return true;
    vec4 incoming=texture(impactTex,clamp(source,vec2(0.),vec2(1.)));
    if(max(destinationData.r,destinationData.b)<.01 || max(incoming.r,incoming.b)<.01)return false;
    bool destinationBackground=destinationData.g<-.0001;
    bool incomingBackground=incoming.g<-.0001;
    if(destinationBackground!=incomingBackground)return incomingBackground;
    if(destinationBackground)return false;
    return abs(destinationOwner.r-incomingOwner.r)>.25 && incomingOwner.b>=destinationOwner.b-.001;
}

vec4 sampleColor(vec2 p)
{
    // Clamp-to-edge turns the final source texel into a long vertical or
    // horizontal stripe whenever a shutter trail leaves the camera frame.
    // Outside-camera exposure is authored background, not repeated edge ink.
    bvec2 below = lessThan(p, vec2(0.0));
    bvec2 above = greaterThan(p, vec2(1.0));
    if (any(below) || any(above))
        return background;
    return texture(colorTex, p);
}

float sourceShapeInfluence(vec2 p)
{
    vec2 sourceShape = texture(shapeMaskTex,
        clamp(p, vec2(0.0), vec2(1.0))).rg;
    float influence = sourceShape.g > 0.0001
        ? clamp(sourceShape.r / sourceShape.g, 0.0, 1.0) : 1.0;
    return influence < 0.001 ? 0.0 : influence;
}

vec4 effectAwareSample(vec2 origin, vec2 offset, float destinationShape)
{
    vec2 source=opticalSourceCoordinate(origin,offset);
    if(foreignOpticalSource(origin,source))source=origin;
    vec4 base=texture(underShapeTex,source);
    float bestCoverage=0.;
    vec4 shapeColor=base;
    for(int i=0;i<samplingShapeCount;++i){
        float influence=texelFetch(shapeInfluencesTex,ivec2(i,0),0).r;
        if(influence<0.0)break; // No shapes: bypass all shape sampling.
        vec2 shapeSource=origin+offset*influence;
        if(any(lessThan(shapeSource,vec2(0.)))||any(greaterThan(shapeSource,vec2(1.)))) continue;
        vec2 mask=texture(shapeMaskTex,shapeSource).rg;
        float actual=mask.g>.0001?mask.r/mask.g:-1.;
        if(abs(actual-influence)<.002 && mask.g>bestCoverage){
            bestCoverage=mask.g;
            shapeColor=texture(colorTex,shapeSource);
        }
    }
    return mix(base,shapeColor,clamp(bestCoverage,0.,1.));
}


// Stratified jitter is genuine reduced integration work, not display grain.
// Stable authored-pixel coordinates avoid crawling with slider values.
float previewSampleNoise(vec2 pixel, float index)
{
    vec3 p=fract(vec3(pixel,index)*vec3(.1031,.1030,.0973));
    p+=dot(p,p.yzx+33.33);
    return fract((p.x+p.y)*p.z);
}
void main()
{
    float ownership = backgroundOwner(uv);
    vec2 shapeData = texture(shapeMaskTex, uv).rg;
    float shapeOwner = shapeData.r;
    float shapeCoverage = shapeData.g;
    float shapeInfluence = shapeCoverage > 0.0001
        ? clamp(shapeOwner / shapeCoverage, 0.0, 1.0) : 1.0;
    float shapePresence = step(0.0001, shapeCoverage);
    // Background hatch remains directionally distinct through camera motion,
    // but should receive nearly the same shutter exposure as subject ink.
    // The former 0.24 multiplier made background lines look almost sharp.
    const float backgroundBlurRetention = 0.86;
    float blur = clamp(amount, 0.0, 1.0) *
        mix(1.0, backgroundBlurRetention, ownership);
    vec4 core = sampleColor(uv);
    if (blur <= 0.0001) {
        fragColor = core;
        return;
    }

    // A normalized one-sided shutter integral replaces the former seven
    // visibly separated copies. Samples are dense enough that maximum blur
    // reads as one continuous dragged exposure rather than stacked layers.
    // The sharp core is composited back afterward to retain graphic edges.
    float travel = pow(blur, .72);
    vec4 integrated = vec4(0.0);
    float weightSum = 0.0;
    const int shutterSamples = 65;
    int activeSamples = clamp(sampleCount, 9, shutterSamples);
    prepareProjectedTravel(uv);
    vec2 shutterTravel = projectedTravel(-travel);
    prepareOpticalSampling(shutterTravel);
    vec2 sourceFilterUV = shutterTravel / max(length(shutterTravel * resolution), .00001) * 1.35;
    for (int sampleIndex = 0; sampleIndex < shutterSamples; ++sampleIndex) {
        if (sampleIndex >= activeSamples) break;
        bool reduced = activeSamples < shutterSamples;
        float jitter = reduced ? previewSampleNoise(floor(uv*resolution),float(sampleIndex)) : .5;
        float t = (float(sampleIndex) + jitter) / float(activeSamples);
        float window = pow(max(0.0, 1.0 - t), 1.32);
        // Backtrace the 3D shutter; positive wind is the visible trail.
        vec2 sampleOffset = projectedTravel(-travel * t);
        vec4 group;
        if (reduced) {
            // Sample the same four-tap source filter by its normalized PMF.
            float r=previewSampleNoise(floor(uv*resolution)+vec2(71.,19.),float(sampleIndex)+113.);
            float tap=r<.125 ? -1.5 : r<.5 ? -.5 : r<.875 ? .5 : 1.5;
            group=effectAwareSample(uv,sampleOffset+sourceFilterUV*tap,shapePresence);
        } else {
        group = effectAwareSample(
            uv, sampleOffset - sourceFilterUV * 1.5, shapePresence) * 0.125;
        group += effectAwareSample(
            uv, sampleOffset - sourceFilterUV * 0.5, shapePresence) * 0.375;
        group += effectAwareSample(
            uv, sampleOffset + sourceFilterUV * 0.5, shapePresence) * 0.375;
        group += effectAwareSample(
            uv, sampleOffset + sourceFilterUV * 1.5, shapePresence) * 0.125;
        }
        integrated += group * window;
        weightSum += window;
    }
    vec4 exposure = integrated / max(weightSum, 0.0001);
    // Influence changes shutter extent.  Shape pixels use the integrated
    // exposure once, avoiding a second sharp shape beneath the effected one.
    float exposureMix = mix(min(1.0, 1.08 * pow(blur, 0.62)),
                            1.0, shapeCoverage);
    vec3 color = mix(core.rgb, exposure.rgb, exposureMix);
    fragColor = vec4(clamp(color, 0.0, 1.0), core.a);
}
