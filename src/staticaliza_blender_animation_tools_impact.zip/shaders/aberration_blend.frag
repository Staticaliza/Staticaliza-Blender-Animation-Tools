uniform sampler2D colorTex;
uniform sampler2D grainTex;
uniform sampler2D impactTex;
uniform sampler2D shapeMaskTex;
uniform sampler2D gradientTex;
uniform vec2 resolution;
uniform int mode;
uniform float angle;
uniform vec2 focus;
uniform float aberration;
uniform float halftone;
uniform float aberrationBlur;
uniform float aberrationIntensity;
uniform float aberrationTaper;
uniform float grainActive;
uniform float directionPolarity;
uniform vec2 cameraMotion;
uniform vec4 foreground;
uniform vec4 background;
uniform float singleColorActive;
uniform vec4 singleColor;
uniform float blurSmoothing;

in vec2 uv;
out vec4 fragColor;

vec2 effectDirection(vec2 p)
{
    if (mode == 0)
        return vec2(cos(angle), sin(angle)) * directionPolarity;
    vec2 radial = (p - focus) * resolution;
    vec2 direction = length(radial) > 0.00001
        ? normalize(radial) : vec2(1.0, 0.0);
    return direction * directionPolarity;
}

float backgroundOwner(vec2 p)
{
    return clamp(-texture(impactTex,
        clamp(p, vec2(0.0), vec2(1.0))).g, 0.0, 1.0);
}

vec3 gradientAt(float position)
{
    float coordinate = (0.5 + clamp(position, 0.0, 1.0) * 16.0) / 19.0;
    return texture(gradientTex, vec2(coordinate, 0.5)).rgb;
}

float inkFromColor(vec3 value)
{
    vec3 paletteSpan = foreground.rgb - background.rgb;
    float denominator = max(dot(paletteSpan, paletteSpan), 1.0e-5);
    return clamp(dot(value - background.rgb, paletteSpan) / denominator,
                 0.0, 1.0);
}

void main()
{
    vec4 centerSample = texture(colorTex, uv);
    vec3 center = centerSample.rgb;
    float ownership = backgroundOwner(uv);
    vec2 shapeData = texture(shapeMaskTex, uv).rg;
    float shapeOwner = shapeData.r;
    float shapeCoverage = shapeData.g;
    float shapeInfluence = shapeCoverage > 0.0001
        ? clamp(shapeOwner / shapeCoverage, 0.0, 1.0) : 1.0;
    // The complete already-composited frame enters one spectral pass. There
    // is no sharp subject/background/shape copy left underneath it.
    float strength = clamp(aberration, 0.0, 100.0) *
        mix(1.0, shapeInfluence, shapeCoverage);
    float normalizedStrength = strength / 100.0;
    float extremeStrength = pow(normalizedStrength, 4.0);
    float resolutionScale = max(0.25, min(resolution.x, resolution.y) / 720.0);
    float radiusPixels = (0.20 + 0.12 * sqrt(strength) +
                          0.045 * strength +
                          27.0 * extremeStrength) * resolutionScale *
                         aberrationBlur;
    // Halftone already contains a deliberate high-frequency carrier. Keep
    // spectral displacement visible but sharply reduce only the shutter blur
    // so dots and line gaps remain readable through the aberration pass.
    radiusPixels *= mix(1.0, 0.24, clamp(halftone, 0.0, 1.0));
    vec2 direction = effectDirection(uv);
    if (ownership > 0.0001 && length(cameraMotion) > 0.00001) {
        vec2 cameraDirection = normalize(-cameraMotion);
        if (dot(cameraDirection, direction) < 0.0) cameraDirection *= -1.0;
        direction = normalize(mix(direction, cameraDirection,
            ownership * 0.88) + vec2(1e-7));
    }
    float layerScale = mix(1.0, 0.48, ownership);
    layerScale = mix(layerScale, 0.72, shapeOwner);
    vec2 spectralUv = direction / resolution * radiusPixels * layerScale;
    // Integrate the selected artist ramp after every drawable layer has
    // joined the frame. Blur Smoothing changes wavelength integration only;
    // disabling it retains crisp separated color rails.
    vec3 sensorInk = vec3(0.0);
    vec3 sensorNorm = vec3(0.0);
    vec3 degenerateSensor = vec3(0.0);
    float scalarInk = 0.0;
    float centerInk = inkFromColor(center);
    const int spectralSamples = 17;
    int activeSamples = blurSmoothing > 0.5 ? spectralSamples : 5;
    for (int sampleIndex = 0; sampleIndex < spectralSamples; ++sampleIndex) {
        if (sampleIndex >= activeSamples) break;
        float samplePosition = (float(sampleIndex) + 0.5) /
                               float(activeSamples);
        // Both modes use the identical wavelength positions and displacement.
        // Smoothing only integrates a small spatial shoulder, so toggling it
        // softens spectral rails without changing their composition/polarity.
        float opticalPosition = samplePosition;
        float dispersion = (opticalPosition - 0.5) * 2.0;
        vec2 sampleUv = uv - spectralUv * dispersion;
        vec3 shifted = texture(colorTex,
            clamp(sampleUv, vec2(0.0), vec2(1.0))).rgb;
        if (blurSmoothing > 0.5) {
            vec2 shoulder = spectralUv * 0.22;
            shifted = shifted * 0.36 +
                texture(colorTex, clamp(sampleUv - shoulder,
                    vec2(0.0), vec2(1.0))).rgb * 0.22 +
                texture(colorTex, clamp(sampleUv + shoulder,
                    vec2(0.0), vec2(1.0))).rgb * 0.22 +
                texture(colorTex, clamp(sampleUv - shoulder * 2.0,
                    vec2(0.0), vec2(1.0))).rgb * 0.10 +
                texture(colorTex, clamp(sampleUv + shoulder * 2.0,
                    vec2(0.0), vec2(1.0))).rgb * 0.10;
        }
        float shiftedInk = inkFromColor(shifted);
        vec3 response = gradientAt(opticalPosition);
        sensorInk += response * shiftedInk;
        sensorNorm += response;
        // When Foreground and Background are the same (especially black),
        // palette projection has no invertible axis.  Preserve actual emitted
        // color/lighting/shape energy and disperse that energy through the
        // chosen spectral response instead of reconstructing a black frame.
        float shiftedEnergy = max(shifted.r, max(shifted.g, shifted.b));
        degenerateSensor += response * shiftedEnergy;
        scalarInk += shiftedInk;
    }
    vec3 coverage;
    coverage.r = sensorNorm.r > 1.0e-4 ? sensorInk.r / sensorNorm.r : centerInk;
    coverage.g = sensorNorm.g > 1.0e-4 ? sensorInk.g / sensorNorm.g : centerInk;
    coverage.b = sensorNorm.b > 1.0e-4 ? sensorInk.b / sensorNorm.b : centerInk;
    vec3 paletteCenter = background.rgb * (1.0 - centerInk) +
                         foreground.rgb * centerInk;
    vec3 paletteDispersed = background.rgb * (vec3(1.0) - coverage) +
                            foreground.rgb * coverage;
    // Preserve the complete composited center (especially custom light RGB)
    // and add only wavelength-dependent neighbor displacement. Rebuilding
    // the whole pixel from the two ink colors turned every lit subject gray.
    vec3 dispersed = center + (paletteDispersed - paletteCenter);
    float paletteEnergy = dot(foreground.rgb - background.rgb,
                              foreground.rgb - background.rgb);
    if (paletteEnergy < 1.0e-5) {
        vec3 spectralEnergy;
        spectralEnergy.r = sensorNorm.r > 1.0e-4
            ? degenerateSensor.r / sensorNorm.r : max(center.r, max(center.g, center.b));
        spectralEnergy.g = sensorNorm.g > 1.0e-4
            ? degenerateSensor.g / sensorNorm.g : max(center.r, max(center.g, center.b));
        spectralEnergy.b = sensorNorm.b > 1.0e-4
            ? degenerateSensor.b / sensorNorm.b : max(center.r, max(center.g, center.b));
        float centerEnergy = max(center.r, max(center.g, center.b));
        // Preserve the authored/lighted center pixel exactly. Aberration adds
        // only the wavelength-dependent neighbor delta, so a black paper
        // palette cannot swallow a red/blue/custom light source.
        dispersed = center + (spectralEnergy - vec3(centerEnergy)) * 1.35;
    }
    if (singleColorActive > 0.5) {
        float displacedInk = scalarInk / float(activeSamples);
        float fringe = smoothstep(0.002, 0.22,
            abs(displacedInk - centerInk));
        dispersed = mix(center, singleColor.rgb, fringe);
    }
    // Work from the normalized artist control. The former exponential used
    // 0..100 strength and saturated at nearly any nonzero value, so low and
    // high settings both replaced the complete frame.
    float onset = clamp(pow(normalizedStrength, 0.72) * 0.62 *
        aberrationIntensity, 0.0, 1.0);
    vec3 grainSample = texture(grainTex, uv).rgb;
    float dustPresence = smoothstep(0.002, 0.18, grainSample.g);
    float overlayPresence = smoothstep(0.0005, 0.08, grainSample.b);
    // Keep full spectral color on grain, reducing only the trailing blur.
    float grainSuppression = max(dustPresence * 0.18,
                                 overlayPresence * 0.40) * grainActive;
    onset *= 1.0 - grainSuppression;
    dispersed = mix(center, dispersed, onset);
    // Activity is only an internal integration weight. The applied Impact
    // Frame is an opaque camera replacement, so it must never escape through
    // alpha and reveal the live 3D scene behind the generated background.
    fragColor = vec4(clamp(dispersed, 0.0, 1.0), 1.0);
}
