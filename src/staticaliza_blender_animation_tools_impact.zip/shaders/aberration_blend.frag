uniform sampler2D colorTex;
uniform sampler2D grainTex;
uniform sampler2D impactTex;
uniform sampler2D shapeMaskTex;
uniform sampler2D underShapeTex;
uniform sampler2D shapeInfluencesTex;
uniform sampler2D gradientTex;
uniform sampler2D spectralTex;
uniform sampler2D directionTex;
uniform sampler2D fieldOwnerTex;
uniform vec2 backgroundFocus;
uniform vec2 backgroundFlow;
uniform vec4 backgroundShape;
uniform vec2 resolution;
uniform float aberration;
uniform float halftone;
uniform float aberrationIntensity;
uniform float aberrationTaper;
uniform float grainActive;
uniform vec4 foreground;
uniform vec4 background;
uniform float singleColorActive;
uniform vec4 singleColor;
uniform float blurSmoothing;
uniform int sampleCount;

in vec2 uv;
out vec4 fragColor;

float backgroundOwner(vec2 p)
{
    return clamp(-texture(impactTex,
        clamp(p, vec2(0.0), vec2(1.0))).g, 0.0, 1.0);
}


// Finite homogeneous translation through the captured camera. The same
// world-space dome vector drives the Linear ribbons and this shutter path.
vec2 opticalNumerator;
float opticalW;
float opticalDepth;

void prepareProjectedTravel(vec2 p)
{
    vec4 field = texture(directionTex, clamp(p, vec2(0.), vec2(1.)));
    float guideFamily = mod(round(abs(texture(fieldOwnerTex, clamp(p, vec2(0.), vec2(1.))).a)), 4.);

    if (guideFamily > 1.5) {
        // Background families recede from the cyan vanishing point. This
        // virtual depth translation also gives their radial perspective speed.
        float family = -guideFamily;
        if (family > -2.5 && family < -1.5) {
            // Match background2DPerspectiveFlow's signed transverse field.
            vec2 axis = normalize(backgroundFlow * resolution);
            vec2 normal = vec2(-axis.y, axis.x);
            float lane = dot((p-backgroundFocus)*resolution, normal);
            float shortEdge = min(resolution.x,resolution.y);
            float spread = clamp(abs(backgroundShape.x),0.,1.);
            spread = spread*spread*(3.-2.*spread);
            float response = spread*1.05/(1.+.55*spread);
            float transverse = lane/sqrt(lane*lane+shortEdge*shortEdge*.2116);
            vec2 flow = normalize(axis+normal*transverse*sign(backgroundShape.x)*
                response*mix(1.,.62,backgroundShape.y));
            field = vec4(flow*shortEdge*.9/resolution,0.,1.);
        } else {
            field = vec4(-(backgroundFocus * 2. - 1.) * .8, -.8, 1.);
        }
    }
    opticalW = max(.001, field.w);
    opticalDepth = field.z;
    opticalNumerator = .5 * (field.xy - (p * 2. - 1.) * field.z);
}

vec2 projectedTravel(float travel)
{
    // Exact projection of P + travel * V, relative to projection(P).
    // CPU bounds the rig shutter against its nearest captured camera depth.
    return travel * opticalNumerator / max(.05 * opticalW, opticalW + travel * opticalDepth);
}

// Continue a stroke through the crop along its optical tangent. Clamping
// X/Y independently repeats the rectangular border; replacing missing samples
// with paper instead creates shifted copies of that border. Intersect the
// ray with the valid pixel-center rectangle so its cross-section is retained.
// Per-destination values are invariant across all shutter/spectral taps.
vec4 destinationData;
vec4 destinationOwner;
float destinationFamily;
vec2 samplingOrigin;
vec2 samplingAxis;
float samplingInverseLength;
vec2 samplingLimits;
int samplingShapeCount;

void prepareOpticalSampling(vec2 axis)
{
    destinationData=texture(impactTex,uv);
    destinationOwner=texture(fieldOwnerTex,uv);
    destinationFamily=mod(round(abs(destinationOwner.a)),4.);
    samplingShapeCount=textureSize(shapeInfluencesTex,0).x;
    if(texelFetch(shapeInfluencesTex,ivec2(0,0),0).r<0.) samplingShapeCount=0;
    vec2 lo=.5/resolution, hi=vec2(1.)-lo;
    samplingOrigin=clamp(uv,lo,hi);
    samplingAxis=axis;
    samplingInverseLength=1./max(dot(axis,axis),1.e-30);
    samplingLimits=vec2(-1.e20,1.e20);
    if(abs(axis.x)>1.e-20){
        vec2 bounds=(vec2(lo.x,hi.x)-samplingOrigin.x)/axis.x;
        samplingLimits.x=max(samplingLimits.x,min(bounds.x,bounds.y));
        samplingLimits.y=min(samplingLimits.y,max(bounds.x,bounds.y));
    }
    if(abs(axis.y)>1.e-20){
        vec2 bounds=(vec2(lo.y,hi.y)-samplingOrigin.y)/axis.y;
        samplingLimits.x=max(samplingLimits.x,min(bounds.x,bounds.y));
        samplingLimits.y=min(samplingLimits.y,max(bounds.x,bounds.y));
    }
}

vec2 opticalSourceCoordinate(vec2 origin,vec2 offset)
{
    // Every tap lies on the same tangent. Clip its scalar distance using
    // the one precomputed ray/rectangle intersection, not four divides/tap.
    float distance=dot(offset,samplingAxis)*samplingInverseLength;
    return samplingOrigin+samplingAxis*clamp(distance,samplingLimits.x,samplingLimits.y);
}

bool foreignOpticalSource(vec2 origin,vec2 source)
{
    vec4 incomingOwner=texture(fieldOwnerTex,clamp(source,vec2(0.),vec2(1.)));
    float sourceFamily=mod(round(abs(incomingOwner.a)),4.);
    if(abs(destinationFamily-sourceFamily)>.5)return true;
    vec4 incoming=texture(impactTex,clamp(source,vec2(0.),vec2(1.)));
    if(max(destinationData.r,destinationData.b)<.01 || max(incoming.r,incoming.b)<.01)return false;
    bool destinationBackground=destinationData.g<-.0001;
    bool incomingBackground=incoming.g<-.0001;
    if(destinationBackground!=incomingBackground)return incomingBackground;
    if(destinationBackground)return false;
    return abs(destinationOwner.r-incomingOwner.r)>.25 && incomingOwner.b>=destinationOwner.b-.001;
}

vec3 gradientAt(float position)
{
    float coordinate = (0.5 + clamp(position, 0.0, 1.0) * 16.0) / 19.0;
    return texture(gradientTex, vec2(coordinate, 0.5)).rgb;
}

vec3 spectralResponseAt(float position)
{
    return pow(max(gradientAt(position),vec3(0.)),vec3(3.0));
}

float inkFromColor(vec3 value)
{
    vec3 paletteSpan = foreground.rgb - background.rgb;
    float denominator = max(dot(paletteSpan, paletteSpan), 1.0e-5);
    vec3 difference=abs(value-background.rgb);
    float peak=max(abs(paletteSpan.r),max(abs(paletteSpan.g),abs(paletteSpan.b)));
    return clamp(max(difference.r,max(difference.g,difference.b))/max(peak,.00001),0.,1.);
}

float sourceShapeInfluence(vec2 p)
{
    vec2 sourceShape = texture(shapeMaskTex,
        clamp(p, vec2(0.0), vec2(1.0))).rg;
    float influence = sourceShape.g > 0.0001
        ? clamp(sourceShape.r / sourceShape.g, 0.0, 1.0) : 1.0;
    return influence < 0.001 ? 0.0 : influence;
}

vec3 effectAwareSpectralSample(vec2 origin, vec2 offset, float destinationShape)
{
    vec2 source=opticalSourceCoordinate(origin,offset);
    if(foreignOpticalSource(origin,source))source=origin;
    vec3 base=texture(underShapeTex,source).rgb;
    float bestCoverage=0.;
    vec3 shapeColor=base;
    for(int i=0;i<samplingShapeCount;++i){
        float influence=texelFetch(shapeInfluencesTex,ivec2(i,0),0).r;
        if(influence<0.0)break; // No shapes: bypass all shape sampling.
        vec2 shapeSource=origin+offset*influence;
        if(any(lessThan(shapeSource,vec2(0.)))||any(greaterThan(shapeSource,vec2(1.)))) continue;
        vec2 mask=texture(shapeMaskTex,shapeSource).rg;
        float actual=mask.g>.0001?mask.r/mask.g:-1.;
        if(abs(actual-influence)<.002 && mask.g>bestCoverage){
            bestCoverage=mask.g;
            shapeColor=texture(spectralTex,shapeSource).rgb;
        }
    }
    return mix(base,shapeColor,clamp(bestCoverage,0.,1.));
}



// Stratified jitter is genuine reduced integration work, not display grain.
// Stable authored-pixel coordinates avoid crawling with slider values.
float previewSampleNoise(vec2 pixel, float index)
{
    vec3 p=fract(vec3(pixel,index)*vec3(.1031,.1030,.0973));
    p+=dot(p,p.yzx+33.33);
    return fract((p.x+p.y)*p.z);
}
void main()
{
    vec4 centerSample = texture(colorTex, uv);
    vec3 center = centerSample.rgb;
    vec3 spectralCenter = texture(spectralTex, uv).rgb;
    float ownership = backgroundOwner(uv);
    vec2 shapeData = texture(shapeMaskTex, uv).rg;
    float shapeOwner = shapeData.r;
    float shapeCoverage = shapeData.g;
    float shapeInfluence = shapeCoverage > 0.0001
        ? clamp(shapeOwner / shapeCoverage, 0.0, 1.0) : 1.0;
    float shapePresence = step(0.0001, shapeCoverage);
    if(shapeCoverage>0.999 && shapeInfluence<0.001) {
        fragColor=vec4(center,1.0);
        return;
    }
    // The complete already-composited frame enters one spectral pass. There
    // is no sharp subject/background/shape copy left underneath it.
    float strength = clamp(aberration, 0.0, 100.0);
    float normalizedStrength = strength / 100.0;
    if(aberration<=.0001) {
        fragColor=vec4(center,1.0);
        return;
    }
    float opticalTravel = .65 * pow(normalizedStrength, .66) *
        mix(1., .24, clamp(halftone, 0., 1.));
    // Integrate the selected artist ramp after every drawable layer has
    // joined the frame. Blur Smoothing changes wavelength integration only;
    // disabling it retains crisp separated color rails.
    vec3 sensorInk = vec3(0.0);
    vec3 sensorNorm = vec3(0.0);
    vec3 degenerateSensor = vec3(0.0);
    float scalarInk = 0.0;
    float centerInk = inkFromColor(spectralCenter);
    const int spectralSamples = 97;
    int activeSamples = blurSmoothing > .5 ? clamp(sampleCount,7,spectralSamples) : 5;
    prepareProjectedTravel(uv);
    vec2 unitTravel = opticalNumerator / opticalW;
    prepareOpticalSampling(unitTravel);
    for (int sampleIndex = 0; sampleIndex < spectralSamples; ++sampleIndex) {
        if (sampleIndex >= activeSamples) break;
        bool reduced=blurSmoothing>.5 && activeSamples<spectralSamples;
        float jitter=reduced ? previewSampleNoise(floor(uv*resolution),float(sampleIndex)) : .5;
        float samplePosition=(float(sampleIndex)+jitter)/float(activeSamples);
        // Both modes use the same wavelength axis and displacement.
        // Smoothing integrates sub-wavelength positions so spectral rails
        // soften without changing their composition or polarity.
        float opticalPosition = samplePosition;
        float dispersion = (opticalPosition - 0.5) * 2.0;
        vec2 sampleOffset = projectedTravel(-opticalTravel * dispersion);
        vec3 shifted = effectAwareSpectralSample(
            uv, sampleOffset, shapePresence);
        vec3 response = spectralResponseAt(opticalPosition);
        float shiftedInk = inkFromColor(shifted);
        float shiftedEnergy = max(shifted.r, max(shifted.g, shifted.b));
        if (blurSmoothing > 0.5 && !reduced) {
            // Integrate between adjacent wavelengths rather than sampling
            // spatial shoulders proportional to the complete dispersion
            // radius. The former method separated large-radius shoulders
            // into visible jagged rails.
            float subStep = .48 / float(activeSamples);
            float lowPosition = clamp(opticalPosition - subStep, 0.0, 1.0);
            float highPosition = clamp(opticalPosition + subStep, 0.0, 1.0);
            vec2 lowOffset = projectedTravel(-opticalTravel * ((lowPosition - .5) * 2.));
            vec2 highOffset = projectedTravel(-opticalTravel * ((highPosition - .5) * 2.));
            vec3 lowShifted = effectAwareSpectralSample(
                uv, lowOffset, shapePresence);
            vec3 highShifted = effectAwareSpectralSample(
                uv, highOffset, shapePresence);
            vec3 lowResponse = response;
            vec3 highResponse = response;
            float lowInk = inkFromColor(lowShifted);
            float highInk = inkFromColor(highShifted);
            float lowEnergy = max(lowShifted.r,
                                  max(lowShifted.g, lowShifted.b));
            float highEnergy = max(highShifted.r,
                                   max(highShifted.g, highShifted.b));
            sensorInk += lowResponse * lowInk * 0.25;
            sensorInk += response * shiftedInk * 0.50;
            sensorInk += highResponse * highInk * 0.25;
            sensorNorm += lowResponse * 0.25 + response * 0.50 +
                          highResponse * 0.25;
            degenerateSensor += lowResponse * lowEnergy * 0.25;
            degenerateSensor += response * shiftedEnergy * 0.50;
            degenerateSensor += highResponse * highEnergy * 0.25;
            scalarInk += lowInk * 0.25 + shiftedInk * 0.50 +
                         highInk * 0.25;
        } else {
            sensorInk += response * shiftedInk;
            sensorNorm += response;
            degenerateSensor += response * shiftedEnergy;
            scalarInk += shiftedInk;
        }
        // When Foreground and Background are the same (especially black),
        // palette projection has no invertible axis.  Preserve actual emitted
        // color/lighting/shape energy and disperse that energy through the
        // chosen spectral response instead of reconstructing a black frame.
    }
    vec3 coverage;
    coverage.r = sensorNorm.r > 1.0e-4 ? sensorInk.r / sensorNorm.r : centerInk;
    coverage.g = sensorNorm.g > 1.0e-4 ? sensorInk.g / sensorNorm.g : centerInk;
    coverage.b = sensorNorm.b > 1.0e-4 ? sensorInk.b / sensorNorm.b : centerInk;
    vec3 paletteCenter = background.rgb * (1.0 - centerInk) +
                         foreground.rgb * centerInk;
    vec3 paletteDispersed = background.rgb * (vec3(1.0) - coverage) +
                            foreground.rgb * coverage;
    // Preserve the complete composited center (especially custom light RGB)
    // and add only wavelength-dependent neighbor displacement. Rebuilding
    // the whole pixel from the two ink colors turned every lit subject gray.
    vec3 dispersed = center + (paletteDispersed - paletteCenter);
    float paletteEnergy = dot(foreground.rgb - background.rgb,
                              foreground.rgb - background.rgb);
    if (paletteEnergy < 1.0e-5) {
        vec3 spectralEnergy;
        spectralEnergy.r = sensorNorm.r > 1.0e-4
            ? degenerateSensor.r / sensorNorm.r : max(spectralCenter.r, max(spectralCenter.g, spectralCenter.b));
        spectralEnergy.g = sensorNorm.g > 1.0e-4
            ? degenerateSensor.g / sensorNorm.g : max(spectralCenter.r, max(spectralCenter.g, spectralCenter.b));
        spectralEnergy.b = sensorNorm.b > 1.0e-4
            ? degenerateSensor.b / sensorNorm.b : max(spectralCenter.r, max(spectralCenter.g, spectralCenter.b));
        float centerEnergy = max(spectralCenter.r, max(spectralCenter.g, spectralCenter.b));
        // Preserve the authored/lighted center pixel exactly. Aberration adds
        // only the wavelength-dependent neighbor delta, so a black paper
        // palette cannot swallow a red/blue/custom light source.
        dispersed = center + (spectralEnergy - vec3(centerEnergy)) * 1.35;
    }
    if (singleColorActive > 0.5) {
        float displacedInk = scalarInk / float(activeSamples);
        float fringe = smoothstep(0.002, 0.22,
            abs(displacedInk - centerInk));
        dispersed = mix(center, singleColor.rgb, fringe);
    }
    // Work from the normalized artist control. The former exponential used
    // 0..100 strength and saturated at nearly any nonzero value, so low and
    // high settings both replaced the complete frame.
    float onset = smoothstep(0.0, .008, normalizedStrength) *
        clamp(aberrationIntensity * .5, 0., 1.);
    vec3 grainSample = texture(grainTex, uv).rgb;
    float dustPresence = smoothstep(0.002, 0.18, grainSample.g);
    float overlayPresence = smoothstep(0.0005, 0.08, grainSample.b);
    // Keep full spectral color on grain, reducing only the trailing blur.
    float grainSuppression = max(dustPresence * 0.18,
                                 overlayPresence * 0.40) * grainActive;
    onset *= 1.0 - grainSuppression;
    dispersed = mix(center, dispersed, onset);
    // Dense wavelength integration should smooth rails, not desaturate them.
    // Restore bounded chroma around the same luminance after the optical mix.
    float dispersedLuma = dot(dispersed, vec3(0.2126, 0.7152, 0.0722));
    // Motion integration lowers local saturation before this spectral pass.
    // Restore that lost chroma without changing abbreviation-only artwork.
    float chromaGain = 1.0 + normalizedStrength *
        mix(0.65, 3.00, clamp(aberrationTaper, 0.0, 1.0));
    dispersed = vec3(dispersedLuma) +
        (dispersed - vec3(dispersedLuma)) * chromaGain;
    // Activity is only an internal integration weight. The applied Impact
    // Frame is an opaque camera replacement, so it must never escape through
    // alpha and reveal the live 3D scene behind the generated background.
    fragColor = vec4(clamp(dispersed, 0.0, 1.0), 1.0);
}
