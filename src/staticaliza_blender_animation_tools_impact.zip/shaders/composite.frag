uniform sampler2D impactTex;
uniform sampler2D subjectTex;
uniform vec2 resolution;
uniform int mode;
uniform float angle;
uniform vec2 focus;
uniform float aberration;
uniform vec4 foreground;
uniform vec4 background;
uniform float bleedAmount;
uniform sampler2D gradientTex;
uniform sampler2D grainTex;
uniform float grainActive;
uniform float singleColorActive;
uniform vec4 singleColor;
uniform float halftone;
uniform float halftoneSize;
uniform float aberrationSpread;
uniform float aberrationIntensity;
uniform float directionPolarity;
uniform vec2 cameraMotion;

in vec2 uv;
out vec4 fragColor;

const float PI = 3.141592653589793;

vec2 effectDirection(vec2 p)
{
    if (mode == 0)
        return vec2(cos(angle), sin(angle)) * directionPolarity;
    // Work in pixel space so radial dispersion remains circular at every
    // camera aspect ratio.
    vec2 radial = (p - focus) * resolution;
    vec2 direction = length(radial) > 0.00001
        ? normalize(radial) : vec2(1.0, 0.0);
    // Spatial 3D modes disperse away from the pink wind source, exactly like
    // the canonical stroke and motion-blur branches.
    return direction * directionPolarity;
}

float hash21(vec2 value)
{
    vec3 p = fract(vec3(value.xyx) * vec3(0.1031, 0.1030, 0.0973));
    p += dot(p, p.yzx + 33.33);
    return fract((p.x + p.y) * p.z);
}

float handValueNoise(vec2 pixel, float scale, vec2 offset)
{
    vec2 coordinate = pixel / max(scale, 1.0) + offset;
    vec2 cell = floor(coordinate);
    vec2 local = fract(coordinate);
    local = local * local * (3.0 - 2.0 * local);
    float a = hash21(cell);
    float b = hash21(cell + vec2(1.0, 0.0));
    float c = hash21(cell + vec2(0.0, 1.0));
    float d = hash21(cell + vec2(1.0, 1.0));
    return mix(mix(a, b, local.x), mix(c, d, local.x), local.y);
}

float resolvedInkAt(vec2 p, float dustWeight, float overlayWeight)
{
    p = clamp(p, vec2(0.0), vec2(1.0));
    vec4 impact = texture(impactTex, p);
    float backgroundOwner = clamp(-impact.g, 0.0, 1.0);
    // Background marks keep a quieter, finer screen. This preserves their
    // hierarchy beneath the subject instead of letting a global print effect
    // turn both branches into one equally loud layer.
    float halftoneAmount = clamp(halftone, 0.0, 1.0) *
        mix(1.0, 0.28, backgroundOwner);
    // Preserve analytic sub-pixel coverage for the clean line view.  A true
    // halftone print still resolves to binary dots below.
    // Stroke and mask coverage is already analytically reconstructed in the
    // impact pass. Preserve it directly here; a second image-space filter
    // would add taps, soften pigment twice, and create pale edge halos.
    float filteredCoverage = impact.r;
    float cleanInk = halftoneAmount <= 0.0001
        ? clamp(filteredCoverage, 0.0, 1.0)
        : step(0.5, impact.r);
    float resolvedInk = cleanInk;
    if (halftoneAmount <= 0.0001) {
        vec3 grainSample = texture(grainTex, p).rgb;
        float scatter = grainSample.g * dustWeight * grainActive;
        float film = clamp(grainSample.b * overlayWeight * grainActive,
                           0.0, 0.96);
        resolvedInk = max(resolvedInk, scatter * (1.0 - resolvedInk));
        return mix(resolvedInk, 1.0 - resolvedInk, film);
    }

    // Screen the generated ink together with the captured headlight tone.
    // The result is a genuine black/white clustered-dot drawing; subsequent
    // aberration, bloom and grain sample this exact resolved mask.
    float sourceDarkness = impact.b * (1.0 - impact.a);
    float printTone = clamp(max(impact.r * 0.80,
                                sourceDarkness * 0.94 + impact.g * 0.16),
                            0.0, 0.985);
    float screenAngle = 0.39269908169;
    mat2 rotation = mat2(cos(screenAngle), -sin(screenAngle),
                         sin(screenAngle),  cos(screenAngle));
    float sizeFactor = sqrt(clamp((halftoneSize - 1.0) / 99.0, 0.0, 1.0));
    float cellPixels = mix(3.25, 30.0, sizeFactor);
    vec2 screen = rotation * (p * resolution - resolution * 0.5) / cellPixels;
    vec2 cell = floor(screen);
    vec2 local = fract(screen) - 0.5;
    float threshold = 0.5 - 0.25 *
        (cos(local.x * 6.28318530718) + cos(local.y * 6.28318530718));
    // A tiny high-frequency perturbation prevents long-range moire while
    // retaining the recognizable regular print screen.
    float center = hash21(cell + vec2(37.0, 109.0));
    float neighbors = (hash21(cell + vec2(38.0, 109.0)) +
                       hash21(cell + vec2(36.0, 109.0)) +
                       hash21(cell + vec2(37.0, 110.0)) +
                       hash21(cell + vec2(37.0, 108.0))) * 0.25;
    threshold = clamp(threshold + (center - neighbors) * 0.025, 0.0, 1.0);
    float screenedInk = step(threshold, printTone) * step(0.005, printTone);
    // Never screen the empty paper/background. Halftone belongs to captured
    // anatomy planes and generated ink, not a full-frame texture overlay.
    screenedInk *= step(0.005, max(impact.b, cleanInk));
    // Progressively replace clean ink with screened ink using an independent
    // stable coverage mask. Every setting remains an exact two-color print;
    // intermediate slider values never introduce gray pixels.
    vec2 outputPixel = floor(p * resolution);
    float adoption = step(hash21(outputPixel + vec2(211.0, 67.0)), halftoneAmount);
    resolvedInk = mix(cleanInk, screenedInk, adoption);
    vec3 grainSample = texture(grainTex, p).rgb;
    float scatter = grainSample.g * dustWeight * grainActive;
    float film = clamp(grainSample.b * overlayWeight * grainActive,
                       0.0, 0.96);
    resolvedInk = max(resolvedInk, scatter * (1.0 - resolvedInk));
    return mix(resolvedInk, 1.0 - resolvedInk, film);
}

float inkAt(vec2 p)
{
    return resolvedInkAt(p, 1.0, 1.0);
}

float structuralInkAt(vec2 p)
{
    return texture(impactTex, clamp(p, vec2(0.0), vec2(1.0))).r;
}

float mangaBleedAt(vec2 p, float centerInk)
{
    float amount = clamp(bleedAmount, 0.0, 1.0);
    if (amount <= 0.0001) return 0.0;
    vec2 px = 1.0 / max(resolution, vec2(1.0));
    vec2 tangent = effectDirection(p);
    vec2 normal = vec2(-tangent.y, tangent.x);
    vec2 pixel = p * resolution;
    float macro = handValueNoise(pixel, 43.0, vec2(7.3, 19.1));
    float meso = handValueNoise(pixel, 16.0, vec2(31.7, 5.9));
    float profile = macro * 0.72 + meso * 0.28;
    // Keep the separation close to the pigment and vary it slowly like an
    // inconsistently loaded light brush, rather than a symmetric vector
    // outline. Positive and negative edges receive different reach.
    float radius = mix(1.0, 5.6, pow(amount, 0.72)) *
        mix(0.76, 1.15, profile);
    float sideA = mix(0.78, 1.18,
        handValueNoise(pixel, 29.0, vec2(11.0, 47.0)));
    float sideB = mix(0.74, 1.12,
        handValueNoise(pixel, 35.0, vec2(53.0, 13.0)));
    vec2 nA = normal * px * radius * sideA;
    vec2 nB = normal * px * radius * sideB;
    vec2 t = tangent * px * radius * mix(0.38, 0.62, macro);
    float surround = 0.0;
    surround = max(surround, structuralInkAt(p + nA));
    surround = max(surround, structuralInkAt(p - nB));
    surround = max(surround, structuralInkAt(p + t));
    surround = max(surround, structuralInkAt(p - t));
    surround = max(surround, structuralInkAt(p + nA * 0.70 + t * 0.54));
    surround = max(surround, structuralInkAt(p - nB * 0.68 + t * 0.47));
    surround = max(surround, structuralInkAt(p + nA * 0.66 - t * 0.42));
    surround = max(surround, structuralInkAt(p - nB * 0.73 - t * 0.51));
    // Dilation minus the original ink is a genuine separation rim. It never
    // paints the line itself and cannot become a full-frame bloom.
    float rim = max(0.0, surround - centerInk);
    float imperfectLoad = mix(0.66, 1.0,
        handValueNoise(pixel, 21.0, vec2(71.0, 23.0)));
    return smoothstep(0.035, 0.76, rim) *
        mix(0.30, 0.76, amount) * imperfectLoad;
}

float subjectAt(vec2 p)
{
    return texture(subjectTex, clamp(p, vec2(0.0), vec2(1.0))).r;
}

vec3 gradientAt(float position)
{
    // The first 17 texels contain the spectrum; texels 17 and 18 carry light
    // parameters. Address only the spectral span here.
    float coordinate = (0.5 + clamp(position, 0.0, 1.0) * 16.0) / 19.0;
    return texture(gradientTex, vec2(coordinate, 0.5)).rgb;
}

vec4 lightParameters()
{
    return texelFetch(gradientTex, ivec2(17, 0), 0);
}

float lightSourceMode()
{
    return texelFetch(gradientTex, ivec2(18, 0), 0).r;
}

float glassDispersion(float wavelength)
{
    // Cauchy's first-order wavelength dependence. Normalize around 550 nm so
    // violet separates farther than red, as it does through ordinary glass.
    const float reference = 550.0;
    float raw = 1.0 / (wavelength * wavelength) -
                1.0 / (reference * reference);
    float violet = 1.0 / (400.0 * 400.0) -
                   1.0 / (reference * reference);
    float red = 1.0 / (700.0 * 700.0) -
                1.0 / (reference * reference);
    return raw >= 0.0 ? raw / violet : 0.52 * raw / abs(red);
}

void main()
{
    vec2 px = 1.0 / resolution;
    // The clean impact frame preserves only sub-pixel analytic coverage; the
    // artistic palette is still exactly Foreground/Background. Bloom,
    // aberration and grain
    // remain the only stages that introduce wider intermediate-color regions.
    float centerInk = inkAt(uv);
    vec4 light = lightParameters();
    vec4 impactCenter = texture(impactTex, uv);
    float centerBackgroundOwner = clamp(-impactCenter.g, 0.0, 1.0);
    vec2 outputPixel = uv * resolution;
    float litAmount = 0.0;
    if (light.a > 0.0001) {
        // None keeps the neutral pre-0.3.76 light plate. With no action-line
        // composition there is no force field for directional paint marks to
        // share, so imposing one produces unrelated stripes across the model.
        if (mode == 2) {
            float subjectPlate = smoothstep(0.015, 0.22, subjectAt(uv));
            float capturedKey = clamp(impactCenter.g, 0.0, 1.0);
            float lightMacro = handValueNoise(
                outputPixel, 67.0, vec2(17.0, 43.0));
            float lightMeso = handValueNoise(
                outputPixel, 23.0, vec2(61.0, 7.0));
            float paintedKey = clamp(capturedKey +
                (lightMacro - 0.5) * 0.30 +
                (lightMeso - 0.5) * 0.12, 0.0, 1.0);
            float graphicPlate = smoothstep(0.12, 0.78, paintedKey);
            float plateLoad = mix(
                0.68, 1.0, lightMacro * 0.70 + lightMeso * 0.30);
            litAmount = subjectPlate * mix(0.12, 0.78, graphicPlate) *
                plateLoad;
        }
        else {
        // Convert the captured key into a drawing region before coloring it.
        // Widely spaced taps merge tiny polygon planes into a few readable
        // masses; directionally correlated marks then break those masses like
        // an inconsistently loaded pencil rather than preserving a CGI mesh.
        vec2 lightDirection = effectDirection(uv);
        vec2 lightNormal = vec2(-lightDirection.y, lightDirection.x);
        float silhouetteWobble =
            (handValueNoise(outputPixel, 71.0, vec2(13.0, 37.0)) - 0.5) * 7.0 +
            (handValueNoise(outputPixel, 29.0, vec2(47.0, 11.0)) - 0.5) * 2.0;
        vec2 roughUv = uv + lightNormal * px * silhouetteWobble;
        float subjectPlate = smoothstep(0.035, 0.34, subjectAt(roughUv));

        vec2 alongTap = lightDirection * px * 10.0;
        vec2 acrossTap = lightNormal * px * 14.0;
        float keyCenter = clamp(texture(impactTex, roughUv).g, 0.0, 1.0);
        float keyAlongA = clamp(texture(impactTex,
            clamp(roughUv + alongTap, vec2(0.0), vec2(1.0))).g, 0.0, 1.0);
        float keyAlongB = clamp(texture(impactTex,
            clamp(roughUv - alongTap, vec2(0.0), vec2(1.0))).g, 0.0, 1.0);
        float keyAcrossA = clamp(texture(impactTex,
            clamp(roughUv + acrossTap, vec2(0.0), vec2(1.0))).g, 0.0, 1.0);
        float keyAcrossB = clamp(texture(impactTex,
            clamp(roughUv - acrossTap, vec2(0.0), vec2(1.0))).g, 0.0, 1.0);
        float simplifiedKey = (keyCenter * 2.0 + keyAlongA + keyAlongB +
            keyAcrossA + keyAcrossB) / 6.0;

        // Stretch the noise domain along the force direction. The result is
        // a hierarchy of finite, imperfect drawing marks, not regular stripes
        // and not image-space speckle pasted over every polygon.
        float along = dot(outputPixel, lightDirection);
        float across = dot(outputPixel, lightNormal);
        vec2 markDomain = vec2(along * 0.16, across);
        float markMacro = handValueNoise(
            markDomain, 53.0, vec2(19.0, 41.0));
        float markMeso = handValueNoise(
            markDomain, 19.0, vec2(59.0, 7.0));
        float regionNoise = handValueNoise(
            outputPixel, 83.0, vec2(5.0, 71.0));
        float drawnRegion = smoothstep(0.10, 0.64,
            simplifiedKey + (regionNoise - 0.5) * 0.22);
        float drawingSignal = markMacro * 0.62 + markMeso * 0.28 +
            regionNoise * 0.10 + drawnRegion * 0.12;
        float markLoad = smoothstep(0.34, 0.70, drawingSignal);
        // Preserve actual paper between deposits. Merely modulating an opaque
        // captured plate reads as noisy CGI; this sparse load makes lighting
        // participate in the same mark-and-gap language as the line drawing.
        float brokenLoad = mix(0.025, 0.86, markLoad) *
            mix(0.62, 1.0, regionNoise);
        litAmount = subjectPlate * drawnRegion * brokenLoad;
        }
    }
    // Porter-Duff source-over order: illuminate the substrate first, then lay
    // foreground pigment over it using analytic stroke coverage. Applying
    // light after pigment tinted fractional AA pixels and produced the pale
    // halo visible around black strokes on gray or colored subjects.
    vec3 illuminatedSubstrate = mix(
        background.rgb, light.rgb, clamp(litAmount, 0.0, 1.0));
    vec3 color = mix(illuminatedSubstrate, foreground.rgb, centerInk);
    float bleed = mangaBleedAt(uv, structuralInkAt(uv));
    color = mix(color, light.rgb, bleed * (1.0 - centerInk));

    if (aberration > 0.0001) {
        vec2 direction = effectDirection(uv);
        if (centerBackgroundOwner > 0.0001 &&
                length(cameraMotion) > 0.00001) {
            vec2 cameraDirection = normalize(-cameraMotion);
            if (dot(cameraDirection, direction) < 0.0)
                cameraDirection *= -1.0;
            direction = normalize(mix(direction, cameraDirection,
                centerBackgroundOwner * 0.88) + vec2(1e-7));
        }
        float strength = clamp(aberration, 0.0, 100.0) *
            mix(1.0, 0.22, centerBackgroundOwner);
        float rootStrength = sqrt(strength);
        // Express the effect in camera-relative units. A reduced live target
        // therefore produces the same on-screen displacement as the applied
        // full-resolution image instead of looking artificially stronger.
        float resolutionScale = max(0.25, min(resolution.x, resolution.y) / 720.0);
        float normalizedStrength = strength / 100.0;
        // Reserve a deliberately exaggerated prism range for the top of the
        // artist control without making the useful lower half jumpy.
        float extremeStrength = pow(normalizedStrength, 4.0);
        float halftoneSharpness = mix(1.0, 0.62,
                                      clamp(halftone, 0.0, 1.0));
        float probePixels = (0.30 + 0.68 * rootStrength +
                             0.010 * strength +
                             30.0 * extremeStrength) * resolutionScale *
                            halftoneSharpness * aberrationSpread;
        vec2 probe = direction * px * probePixels;

        // The subject raster is a compact two-plane depth proxy. Preserve the
        // interior while increasing dispersion and longitudinal blur where the
        // nearer subject crosses the farther background.
        float subjectCenter = subjectAt(uv);
        float subjectForward = subjectAt(uv + probe);
        float subjectBackward = subjectAt(uv - probe);
        float depthEdge = max(abs(subjectForward - subjectCenter),
                              abs(subjectBackward - subjectCenter));
        float depthScale = mix(0.70, 1.20, clamp(depthEdge * 2.2, 0.0, 1.0));
        float pixels = probePixels * depthScale;
        vec3 sensorInk = vec3(0.0);
        vec3 sensorNorm = vec3(0.0);
        float scalarInk = 0.0;
        float scalarInkMinimum = 1.0;
        float scalarInkMaximum = 0.0;
        // Midpoint-stratified wavelength integration gives the interpolated
        // 17-texel response enough spatial samples that extreme dispersion
        // does not reveal it as a stack of separate color layers.
        const int spectralSamples = 25;
        for (int sampleIndex = 0; sampleIndex < spectralSamples; ++sampleIndex) {
            float samplePosition = (float(sampleIndex) + 0.5) /
                                   float(spectralSamples);
            float wavelength = mix(400.0, 700.0, samplePosition);
            float dispersion = glassDispersion(wavelength);
            // Texture lookup is inverse mapping: subtract the physical
            // displacement so short wavelengths appear farther along the
            // artist's positive effect direction (90 degrees = upward).
            vec2 mainPosition = uv - direction * px * pixels * dispersion;
            float shiftedBase = resolvedInkAt(mainPosition, 0.0, 0.0);
            // Scatter stays bound to linework while Film Grain remains a
            // full-frame overlay. Both use a smaller aberration spread than
            // the main generated drawing.
            vec3 shiftedDustSample = texture(
                grainTex,
                clamp(uv - direction * px * pixels * dispersion * 0.45,
                      vec2(0.0), vec2(1.0))).rgb;
            vec3 shiftedOverlaySample = texture(
                grainTex,
                clamp(uv - direction * px * pixels * dispersion * 0.18,
                      vec2(0.0), vec2(1.0))).rgb;
            float shiftedDust = shiftedDustSample.g * grainActive;
            float shiftedOverlay = clamp(
                shiftedOverlaySample.b * grainActive, 0.0, 0.96);
            float shiftedInk = max(
                shiftedBase, shiftedDust * (1.0 - shiftedBase));
            shiftedInk = mix(
                shiftedInk, 1.0 - shiftedInk, shiftedOverlay);
            scalarInk += shiftedInk;
            scalarInkMinimum = min(scalarInkMinimum, shiftedInk);
            scalarInkMaximum = max(scalarInkMaximum, shiftedInk);
            // Default and Custom use the same wavelength integration. The
            // uploaded texture is either the CIE-derived default response or
            // the artist's custom spectral ramp; neither mode paints discrete
            // wavelength rails onto the image.
            vec3 response = gradientAt(samplePosition);
            sensorInk += response * shiftedInk;
            sensorNorm += response;
        }

        float sliderResponse = pow(normalizedStrength, 0.62);
        float halftoneRetention = mix(1.0, 0.90, clamp(halftone, 0.0, 1.0));
        if (singleColorActive > 0.5) {
            // A one-color Custom ramp is a colored fringe, not three sensor
            // channels. Per-channel normalization cancels its RGB ratios and
            // turns saturated colors gray, so color one scalar displaced mask
            // directly with the exact chosen value.
            // Do not average the displaced samples here. At a deliberately
            // exaggerated spread, wavelengths on opposite sides of the core
            // otherwise cancel into a weak mask. The min/max envelope retains
            // the full calibrated footprint while the direct tint retains the
            // exact selected hue.
            float displacedInk = scalarInk / float(spectralSamples);
            float averagedFringe = abs(displacedInk - centerInk);
            float spectralEnvelope = max(
                abs(scalarInkMinimum - centerInk),
                abs(scalarInkMaximum - centerInk));
            float fringe = max(averagedFringe, spectralEnvelope);
            float restriction = clamp(
                sliderResponse * smoothstep(0.002, 0.28, fringe) *
                0.94 * halftoneRetention * aberrationIntensity *
                mix(1.0, 0.34, centerBackgroundOwner),
                0.0, 1.0);
            color = mix(color, singleColor.rgb, restriction);
            fragColor = vec4(clamp(color, 0.0, 1.0), restriction);
            return;
        }
        // A custom ramp may intentionally contain a channel with no response
        // (black/violet and green/green are useful examples). Preserve the
        // unshifted ink coverage for that channel instead of dividing by zero
        // and replacing flat scene regions with the background color.
        vec3 coverage;
        coverage.r = sensorNorm.r > 0.0001 ?
                     sensorInk.r / sensorNorm.r : centerInk;
        coverage.g = sensorNorm.g > 0.0001 ?
                     sensorInk.g / sensorNorm.g : centerInk;
        coverage.b = sensorNorm.b > 0.0001 ?
                     sensorInk.b / sensorNorm.b : centerInk;
        coverage = clamp(coverage, vec3(0.0), vec3(1.0));
        vec3 spectralColor = background.rgb * (vec3(1.0) - coverage) +
                             foreground.rgb * coverage;
        float activity = max(abs(spectralColor.r - color.r),
                         max(abs(spectralColor.g - color.g),
                             abs(spectralColor.b - color.b)));
        float restriction = clamp(
            sliderResponse * smoothstep(0.006, 0.20, activity) *
            0.94 * halftoneRetention * aberrationIntensity *
            mix(1.0, 0.34, centerBackgroundOwner), 0.0, 1.0);
        color = mix(color, spectralColor, restriction);
        fragColor = vec4(clamp(color, 0.0, 1.0), restriction);
        return;
    }

    fragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
