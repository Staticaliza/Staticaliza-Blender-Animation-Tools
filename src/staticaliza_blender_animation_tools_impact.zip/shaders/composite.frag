uniform sampler2D impactTex;
uniform sampler2D subjectTex;
uniform vec2 resolution;
uniform int mode;
uniform float angle;
uniform vec2 focus;
uniform float aberration;
uniform vec4 foreground;
uniform vec4 backgroundLineColor;
uniform vec4 background;
uniform float bleedAmount;
uniform sampler2D gradientTex;
uniform sampler2D grainTex;
uniform float grainActive;
uniform float singleColorActive;
uniform vec4 singleColor;
uniform float halftone;
uniform float halftoneSize;
uniform vec2 paperResolution;
uniform float aberrationSpread;
uniform float aberrationIntensity;
uniform float directionPolarity;
uniform vec2 cameraMotion;

in vec2 uv;
out vec4 fragColor;

const float PI = 3.141592653589793;

vec2 effectDirection(vec2 p)
{
    // Only the explicit Radial mode may consume the focus point. None keeps a
    // neutral linear axis for direction-dependent post effects; treating every
    // nonzero mode as radial leaked the pink dragger into solid-light frames.
    if (mode != 1)
        return vec2(cos(angle), sin(angle)) * directionPolarity;
    // Work in pixel space so radial dispersion remains circular at every
    // camera aspect ratio.
    vec2 radial = (p - focus) * resolution;
    vec2 direction = length(radial) > 0.00001
        ? normalize(radial) : vec2(1.0, 0.0);
    // Spatial 3D modes disperse away from the pink wind source, exactly like
    // the canonical stroke and motion-blur branches.
    return direction * directionPolarity;
}

float hash21(vec2 value)
{
    vec3 p = fract(vec3(value.xyx) * vec3(0.1031, 0.1030, 0.0973));
    p += dot(p, p.yzx + 33.33);
    return fract((p.x + p.y) * p.z);
}

float handValueNoise(vec2 pixel, float scale, vec2 offset)
{
    vec2 coordinate = pixel / max(scale, 1.0) + offset;
    vec2 cell = floor(coordinate);
    vec2 local = fract(coordinate);
    local = local * local * (3.0 - 2.0 * local);
    float a = hash21(cell);
    float b = hash21(cell + vec2(1.0, 0.0));
    float c = hash21(cell + vec2(0.0, 1.0));
    float d = hash21(cell + vec2(1.0, 1.0));
    return mix(mix(a, b, local.x), mix(c, d, local.x), local.y);
}

float resolvedInkAt(vec2 p, float dustWeight, float overlayWeight)
{
    p = clamp(p, vec2(0.0), vec2(1.0));
    vec4 impact = texture(impactTex, p);
    float backgroundOwner = clamp(-impact.g, 0.0, 1.0);
    // Background marks keep a quieter, finer screen. This preserves their
    // hierarchy beneath the subject instead of letting a global print effect
    // turn both branches into one equally loud layer.
    float halftoneAmount = clamp(halftone, 0.0, 1.0) *
        mix(1.0, 0.28, backgroundOwner);
    // Preserve analytic sub-pixel coverage for the clean line view.  A true
    // halftone print still resolves to binary dots below.
    // Stroke and mask coverage is already analytically reconstructed in the
    // impact pass. Preserve it directly here; a second image-space filter
    // would add taps, soften pigment twice, and create pale edge halos.
    float filteredCoverage = impact.r;
    float cleanInk = halftoneAmount <= 0.0001
        ? clamp(filteredCoverage, 0.0, 1.0)
        : step(0.5, impact.r);
    float resolvedInk = cleanInk;
    if (halftoneAmount <= 0.0001) {
        vec3 grainSample = texture(grainTex, p).rgb;
        float scatter = grainSample.g * dustWeight * grainActive;
        float film = clamp(grainSample.b * overlayWeight * grainActive,
                           0.0, 0.96);
        resolvedInk = max(resolvedInk, scatter * (1.0 - resolvedInk));
        return mix(resolvedInk, 1.0 - resolvedInk, film);
    }

    // Screen deposited, distorted drawing density. Captured face tone and
    // the clean rig silhouette are not printable coverage.
    vec2 densityStep=vec2(2.5)/paperResolution;
    float drawingDensity=impact.r*.40;
    drawingDensity+=texture(impactTex,clamp(p+vec2(densityStep.x,0),vec2(0),vec2(1))).r*.15;
    drawingDensity+=texture(impactTex,clamp(p-vec2(densityStep.x,0),vec2(0),vec2(1))).r*.15;
    drawingDensity+=texture(impactTex,clamp(p+vec2(0,densityStep.y),vec2(0),vec2(1))).r*.15;
    drawingDensity+=texture(impactTex,clamp(p-vec2(0,densityStep.y),vec2(0),vec2(1))).r*.15;
    float printTone=clamp(drawingDensity,0.0,.985);
    float screenAngle = 0.39269908169;
    mat2 rotation = mat2(cos(screenAngle), -sin(screenAngle),
                         sin(screenAngle),  cos(screenAngle));
    float sizeFactor = sqrt(clamp((halftoneSize - 1.0) / 99.0, 0.0, 1.0));
    float cellPixels = mix(3.25, 30.0, sizeFactor);
    vec2 screen = rotation * (p * paperResolution - paperResolution * 0.5) / cellPixels;
    vec2 cell = floor(screen);
    vec2 local = fract(screen) - 0.5;
    float threshold = 0.5 - 0.25 *
        (cos(local.x * 6.28318530718) + cos(local.y * 6.28318530718));
    // A tiny high-frequency perturbation prevents long-range moire while
    // retaining the recognizable regular print screen.
    float center = hash21(cell + vec2(37.0, 109.0));
    float neighbors = (hash21(cell + vec2(38.0, 109.0)) +
                       hash21(cell + vec2(36.0, 109.0)) +
                       hash21(cell + vec2(37.0, 110.0)) +
                       hash21(cell + vec2(37.0, 108.0))) * 0.25;
    threshold = clamp(threshold + (center - neighbors) * 0.025, 0.0, 1.0);
    float screenedInk = step(threshold, printTone) * step(0.005, printTone);
    // Never screen the empty paper/background. Halftone belongs to captured
    // anatomy planes and generated ink, not a full-frame texture overlay.
    screenedInk *= step(0.005, drawingDensity);
    // Progressively replace clean ink with screened ink using an independent
    // stable coverage mask. Every setting remains an exact two-color print;
    // intermediate slider values never introduce gray pixels.
    vec2 outputPixel = floor(p * resolution);
    float adoption = step(hash21(outputPixel + vec2(211.0, 67.0)), halftoneAmount);
    resolvedInk = mix(cleanInk, screenedInk, adoption);
    vec3 grainSample = texture(grainTex, p).rgb;
    float scatter = grainSample.g * dustWeight * grainActive;
    float film = clamp(grainSample.b * overlayWeight * grainActive,
                       0.0, 0.96);
    resolvedInk = max(resolvedInk, scatter * (1.0 - resolvedInk));
    return mix(resolvedInk, 1.0 - resolvedInk, film);
}

float inkAt(vec2 p)
{
    return resolvedInkAt(p, 1.0, 1.0);
}

float structuralInkAt(vec2 p)
{
    return texture(impactTex, clamp(p, vec2(0.0), vec2(1.0))).r;
}

float litStrokeAt(vec2 p) {
    vec4 ink=texture(impactTex,clamp(p,vec2(0),vec2(1)));
    return ink.r*step(.001,ink.g);
}

// Separation follows the warped support, emitted only by lit hatch actions.
// A bounded two-ring dilation makes an outer brush edge without face shading.
float mangaBleedAt(vec2 p, float centerInk)
{
    float amount=clamp(bleedAmount,0.0,1.0);
    if(amount<=.0001)return 0.0;
    vec2 pixel=p*resolution;
    float load=handValueNoise(pixel,27.0,vec2(71.,23.));
    float breadth=handValueNoise(pixel,49.0,vec2(7.3,19.1));
    float radius=mix(1.0,9.0,pow(amount,.72))*mix(.65,1.30,breadth);
    radius*=max(resolution.y/1080.0,.35);
    vec2 px=1.0/max(resolution,vec2(1));
    vec4 centerField=texture(impactTex,p);
    float center=clamp(max(centerField.b,centerField.r),0.0,1.0);
    vec2 wobble=(vec2(handValueNoise(pixel,7.0,vec2(3.,9.)),
        handValueNoise(pixel,11.0,vec2(17.,5.)))-.5)*px*radius*.8;
    float rim=0.0;
    // Linear/radial separation is an authored amount, independent of palette
    // contrast. Only Bleed=0 disables it; subject support stays light-directed.
    float fullStroke=(mode!=2 ? 1.0 : 0.0);
    for(int i=0;i<12;i++) {
        float angle=6.2831853*(float(i)+.13)/12.0;
        vec2 delta=vec2(cos(angle),sin(angle))*px*radius;
        vec4 nearField=texture(impactTex,clamp(p+wobble+delta*.38,vec2(0),vec2(1)));
        vec4 farField=texture(impactTex,clamp(p+wobble+delta,vec2(0),vec2(1)));
        float nearMask=max(max(nearField.b,nearField.r)*smoothstep(.02,.30,nearField.g),nearField.r*fullStroke);
        float farMask=max(max(farField.b,farField.r)*smoothstep(.02,.30,farField.g),farField.r*fullStroke);
        rim=max(rim,max(nearMask*.92,farMask*.35));
    }
    // Keep the black interior; vary brush load along the contour. Sparse
    // peripheral marks remain softer than the close separation stroke.
    return clamp(rim-center,0.0,1.0)*pow(amount,.65)*mix(.18,.95,smoothstep(.20,.80,load));
}

float subjectAt(vec2 p)
{
    return texture(subjectTex, clamp(p, vec2(0.0), vec2(1.0))).r;
}

vec3 gradientAt(float position)
{
    // The first 17 texels contain the spectrum; texels 17 and 18 carry light
    // parameters. Address only the spectral span here.
    float coordinate = (0.5 + clamp(position, 0.0, 1.0) * 16.0) / 19.0;
    return texture(gradientTex, vec2(coordinate, 0.5)).rgb;
}

vec4 lightParameters()
{
    return texelFetch(gradientTex, ivec2(17, 0), 0);
}

float lightSourceMode()
{
    return texelFetch(gradientTex, ivec2(18, 0), 0).r;
}

float glassDispersion(float wavelength)
{
    // Cauchy's first-order wavelength dependence. Normalize around 550 nm so
    // violet separates farther than red, as it does through ordinary glass.
    const float reference = 550.0;
    float raw = 1.0 / (wavelength * wavelength) -
                1.0 / (reference * reference);
    float violet = 1.0 / (400.0 * 400.0) -
                   1.0 / (reference * reference);
    float red = 1.0 / (700.0 * 700.0) -
                1.0 / (reference * reference);
    return raw >= 0.0 ? raw / violet : 0.52 * raw / abs(red);
}

void main()
{
    vec2 px = 1.0 / resolution;
    // The clean impact frame preserves only sub-pixel analytic coverage; the
    // artistic palette is still exactly Foreground/Background. Bloom,
    // aberration and grain
    // remain the only stages that introduce wider intermediate-color regions.
    float centerInk = resolvedInkAt(uv,0.0,0.0);
    vec4 light = lightParameters();
    vec4 impactCenter = texture(impactTex, uv);
    float centerBackgroundOwner = clamp(-impactCenter.g, 0.0, 1.0);
    vec2 outputPixel = uv * resolution;
    float litAmount = 0.0;
    if (light.a > 0.0001) {
        // The impact pass supplies an action-owned lighting key. Resampling
        // it at a displaced pixel would split one pencil stroke into colors.
        litAmount=clamp(impactCenter.g,0.0,1.0);

    }
    float lit=step(.001,litAmount);
    vec3 basePigment=mix(foreground.rgb,backgroundLineColor.rgb,step(.0001,centerBackgroundOwner));
    vec3 pigment=mix(basePigment,light.rgb,lit);
    // Light deposits emitted pigment; it cannot shade red toward black or
    // interpolate black marks into unwanted gray on white paper.
    // Preserve the original hatch width and pressure coverage.

    vec3 color=mix(background.rgb,pigment,centerInk);
    // Artistic separation around the warped silhouette remains visible even
    // when both authored pigment and paper are black.
    if(light.a>.0001 && bleedAmount>.0001) {
        float edgeLight=mangaBleedAt(uv,litStrokeAt(uv));
        color=mix(color,light.rgb,edgeLight*clamp(light.a,0.0,1.0));
    }
    vec3 printGrain=texture(grainTex,uv).rgb*grainActive;
    color=mix(color,foreground.rgb,clamp(printGrain.g,0.0,1.0));
    color=mix(color,vec3(1.0)-color,clamp(printGrain.b,0.0,.96));

    if (aberration > 0.0001) {
        vec2 direction = effectDirection(uv);
        if (centerBackgroundOwner > 0.0001 &&
                length(cameraMotion) > 0.00001) {
            vec2 cameraDirection = normalize(-cameraMotion);
            if (dot(cameraDirection, direction) < 0.0)
                cameraDirection *= -1.0;
            direction = normalize(mix(direction, cameraDirection,
                centerBackgroundOwner * 0.88) + vec2(1e-7));
        }
        float strength = clamp(aberration, 0.0, 100.0) *
            mix(1.0, 0.22, centerBackgroundOwner);
        float rootStrength = sqrt(strength);
        // Express the effect in camera-relative units. A reduced live target
        // therefore produces the same on-screen displacement as the applied
        // full-resolution image instead of looking artificially stronger.
        float resolutionScale = max(0.25, min(resolution.x, resolution.y) / 720.0);
        float normalizedStrength = strength / 100.0;
        // Reserve a deliberately exaggerated prism range for the top of the
        // artist control without making the useful lower half jumpy.
        float extremeStrength = pow(normalizedStrength, 4.0);
        float halftoneSharpness = mix(1.0, 0.62,
                                      clamp(halftone, 0.0, 1.0));
        float probePixels = (0.30 + 0.68 * rootStrength +
                             0.010 * strength +
                             30.0 * extremeStrength) * resolutionScale *
                            halftoneSharpness * aberrationSpread;
        vec2 probe = direction * px * probePixels;

        // The subject raster is a compact two-plane depth proxy. Preserve the
        // interior while increasing dispersion and longitudinal blur where the
        // nearer subject crosses the farther background.
        float subjectCenter = subjectAt(uv);
        float subjectForward = subjectAt(uv + probe);
        float subjectBackward = subjectAt(uv - probe);
        float depthEdge = max(abs(subjectForward - subjectCenter),
                              abs(subjectBackward - subjectCenter));
        float depthScale = mix(0.70, 1.20, clamp(depthEdge * 2.2, 0.0, 1.0));
        float pixels = probePixels * depthScale;
        vec3 sensorInk = vec3(0.0);
        vec3 sensorNorm = vec3(0.0);
        float scalarInk = 0.0;
        float scalarInkMinimum = 1.0;
        float scalarInkMaximum = 0.0;
        // Midpoint-stratified wavelength integration gives the interpolated
        // 17-texel response enough spatial samples that extreme dispersion
        // does not reveal it as a stack of separate color layers.
        const int spectralSamples = 25;
        for (int sampleIndex = 0; sampleIndex < spectralSamples; ++sampleIndex) {
            float samplePosition = (float(sampleIndex) + 0.5) /
                                   float(spectralSamples);
            float wavelength = mix(400.0, 700.0, samplePosition);
            float dispersion = glassDispersion(wavelength);
            // Texture lookup is inverse mapping: subtract the physical
            // displacement so short wavelengths appear farther along the
            // artist's positive effect direction (90 degrees = upward).
            vec2 mainPosition = uv - direction * px * pixels * dispersion;
            float shiftedBase = resolvedInkAt(mainPosition, 0.0, 0.0);
            // Scatter stays bound to linework while Film Grain remains a
            // full-frame overlay. Both use a smaller aberration spread than
            // the main generated drawing.
            vec3 shiftedDustSample = texture(
                grainTex,
                clamp(uv - direction * px * pixels * dispersion * 0.45,
                      vec2(0.0), vec2(1.0))).rgb;
            vec3 shiftedOverlaySample = texture(
                grainTex,
                clamp(uv - direction * px * pixels * dispersion * 0.18,
                      vec2(0.0), vec2(1.0))).rgb;
            float shiftedDust = shiftedDustSample.g * grainActive;
            float shiftedOverlay = clamp(
                shiftedOverlaySample.b * grainActive, 0.0, 0.96);
            float shiftedInk = max(
                shiftedBase, shiftedDust * (1.0 - shiftedBase));
            shiftedInk = mix(
                shiftedInk, 1.0 - shiftedInk, shiftedOverlay);
            scalarInk += shiftedInk;
            scalarInkMinimum = min(scalarInkMinimum, shiftedInk);
            scalarInkMaximum = max(scalarInkMaximum, shiftedInk);
            // Default and Custom use the same wavelength integration. The
            // uploaded texture is either the CIE-derived default response or
            // the artist's custom spectral ramp; neither mode paints discrete
            // wavelength rails onto the image.
            vec3 response = gradientAt(samplePosition);
            sensorInk += response * shiftedInk;
            sensorNorm += response;
        }

        float sliderResponse = pow(normalizedStrength, 0.62);
        float halftoneRetention = mix(1.0, 0.90, clamp(halftone, 0.0, 1.0));
        if (singleColorActive > 0.5) {
            // A one-color Custom ramp is a colored fringe, not three sensor
            // channels. Per-channel normalization cancels its RGB ratios and
            // turns saturated colors gray, so color one scalar displaced mask
            // directly with the exact chosen value.
            // Do not average the displaced samples here. At a deliberately
            // exaggerated spread, wavelengths on opposite sides of the core
            // otherwise cancel into a weak mask. The min/max envelope retains
            // the full calibrated footprint while the direct tint retains the
            // exact selected hue.
            float displacedInk = scalarInk / float(spectralSamples);
            float averagedFringe = abs(displacedInk - centerInk);
            float spectralEnvelope = max(
                abs(scalarInkMinimum - centerInk),
                abs(scalarInkMaximum - centerInk));
            float fringe = max(averagedFringe, spectralEnvelope);
            float restriction = clamp(
                sliderResponse * smoothstep(0.002, 0.28, fringe) *
                0.94 * halftoneRetention * aberrationIntensity *
                mix(1.0, 0.34, centerBackgroundOwner),
                0.0, 1.0);
            color = mix(color, singleColor.rgb, restriction);
            fragColor = vec4(clamp(color, 0.0, 1.0), restriction);
            return;
        }
        // A custom ramp may intentionally contain a channel with no response
        // (black/violet and green/green are useful examples). Preserve the
        // unshifted ink coverage for that channel instead of dividing by zero
        // and replacing flat scene regions with the background color.
        vec3 coverage;
        coverage.r = sensorNorm.r > 0.0001 ?
                     sensorInk.r / sensorNorm.r : centerInk;
        coverage.g = sensorNorm.g > 0.0001 ?
                     sensorInk.g / sensorNorm.g : centerInk;
        coverage.b = sensorNorm.b > 0.0001 ?
                     sensorInk.b / sensorNorm.b : centerInk;
        coverage = clamp(coverage, vec3(0.0), vec3(1.0));
        vec3 spectralColor = background.rgb * (vec3(1.0) - coverage) +
                             foreground.rgb * coverage;
        float activity = max(abs(spectralColor.r - color.r),
                         max(abs(spectralColor.g - color.g),
                             abs(spectralColor.b - color.b)));
        float restriction = clamp(
            sliderResponse * smoothstep(0.006, 0.20, activity) *
            0.94 * halftoneRetention * aberrationIntensity *
            mix(1.0, 0.34, centerBackgroundOwner), 0.0, 1.0);
        color = mix(color, spectralColor, restriction);
        fragColor = vec4(clamp(color, 0.0, 1.0), restriction);
        return;
    }

    fragColor = vec4(clamp(color, 0.0, 1.0), 1.0);
}
