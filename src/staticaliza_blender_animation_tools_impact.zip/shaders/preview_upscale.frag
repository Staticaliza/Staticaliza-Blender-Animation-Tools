uniform sampler2D colorTex;
uniform vec2 sourceResolution;
uniform vec2 outputResolution;
uniform float quality;

in vec2 uv;
out vec4 fragColor;

float hash12(vec2 p)
{
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

void main()
{
    vec2 texel = 1.0 / max(sourceResolution, vec2(1.0));
    vec3 center = texture(colorTex, uv).rgb;
    vec3 north = texture(colorTex, uv + vec2(0.0, texel.y)).rgb;
    vec3 south = texture(colorTex, uv - vec2(0.0, texel.y)).rgb;
    vec3 east = texture(colorTex, uv + vec2(texel.x, 0.0)).rgb;
    vec3 west = texture(colorTex, uv - vec2(texel.x, 0.0)).rgb;
    vec3 neighborhood = (north + south + east + west) * 0.25;
    float reconstruction = mix(0.58, 0.24, clamp(quality, 0.0, 1.0));
    vec3 sharpened = center + (center - neighborhood) * reconstruction;
    vec3 minimumColor = min(center, min(min(north, south), min(east, west)));
    vec3 maximumColor = max(center, max(max(north, south), max(east, west)));
    sharpened = clamp(sharpened, minimumColor, maximumColor);

    // Deterministic sub-pixel dither prevents broad low-resolution gradients
    // from reading as soft bands without inventing persistent stroke detail.
    float dither = (hash12(gl_FragCoord.xy + outputResolution * 0.001) - 0.5) *
                   (1.0 - clamp(quality, 0.0, 1.0)) / 255.0;
    fragColor = vec4(clamp(sharpened + vec3(dither), 0.0, 1.0), 1.0);
}
