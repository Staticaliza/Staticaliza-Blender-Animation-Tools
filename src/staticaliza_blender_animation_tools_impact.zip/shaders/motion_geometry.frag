in vec2 vVelocity;
in vec2 vAcceleration;
out vec4 fragColor;

void main()
{
    // RG is the central velocity and BA is the second-difference acceleration
    // of the same evaluated surface point.
    fragColor = vec4(vVelocity, vAcceleration);
}
