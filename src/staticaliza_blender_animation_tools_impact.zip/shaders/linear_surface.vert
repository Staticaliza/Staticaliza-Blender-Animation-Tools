in vec4 clipPosition;
in float linearDepth;
in vec2 strokeUV;
in vec4 strokeParams;
in vec4 strokeStyle;
uniform sampler2D ownershipTex;
in vec4 strokeContact;
in float sourceOwner;
in float strokeVisibility;
in float linearBandCoordinate;
out float vLinearBandCoordinate;
out float vStrokeVisibility;
out float vSourceOwner;
out float vContactOwner;
out float vContactVisible;
out vec4 vStrokeContact;
out vec4 vStrokeStyle;
out vec2 vStrokeUV;
out vec4 vStrokeParams;
out vec2 uv;
out float vLinearDepth;
void main() {
 vLinearBandCoordinate = linearBandCoordinate;
 vStrokeVisibility = strokeVisibility;
 uv = clipPosition.xy / clipPosition.w * 0.5 + 0.5;
 vLinearDepth = linearDepth;
 vStrokeUV = strokeUV;
 vStrokeParams = strokeParams;
 vStrokeStyle = strokeStyle;
 ivec2 size = textureSize(ownershipTex, 0);
 ivec2 pixel = clamp(ivec2(strokeContact.zw * vec2(size)), ivec2(0), size-1);
 vec3 surface = texelFetch(ownershipTex, pixel, 0).rgb;
 bool visible = strokeContact.x > 0.5 && surface.y > 0.5 &&
                abs(surface.z-strokeContact.x) < 0.25;
 vSourceOwner = sourceOwner;
 vContactOwner = strokeContact.x;
 vContactVisible = visible ? 1.0 : 0.0;
 // A visible tilted support plane owns its true per-lane depth. Hidden
 // contacts retain the center-depth floor and cannot project through a face.
 if (!visible) vLinearDepth = max(vLinearDepth, strokeContact.y);
 // Carry center position/depth, not an interpolated categorical owner and
 // binary visibility flag. The fragment checks the actual support sample.
 vStrokeContact = strokeContact;
 gl_Position = vec4(clipPosition.xy, 0.0, clipPosition.w);
}
