uniform sampler2D colorTex;
uniform float contrast;
uniform float grayscale;
uniform float negative;
uniform vec4 tintColor;
uniform mat3 temperatureMatrix;

in vec2 uv;
out vec4 fragColor;

void main()
{
    vec4 source = texture(colorTex, uv);
    vec3 balanced = max(temperatureMatrix * clamp(source.rgb, 0.0, 1.0), vec3(0.0));
    vec3 tinted = mix(source.rgb, balanced * tintColor.rgb, clamp(tintColor.a, 0.0, 1.0));
    float gray = dot(tinted, vec3(0.2126, 0.7152, 0.0722));
    vec3 color = mix(tinted, vec3(gray), clamp(grayscale, 0.0, 1.0));
    float factor = 1.0 + clamp(contrast, 0.0, 1.0) * 3.0;
    color = clamp((color - vec3(0.5)) * factor + vec3(0.5), 0.0, 1.0);
    if (negative > 0.5) color = vec3(1.0) - color;
    fragColor = vec4(color, source.a);
}
