uniform sampler2D colorTex;
uniform float contrast;
uniform float grayscale;
uniform float negative;

in vec2 uv;
out vec4 fragColor;

void main()
{
    vec4 source = texture(colorTex, uv);
    float gray = dot(source.rgb, vec3(0.2126, 0.7152, 0.0722));
    vec3 color = mix(source.rgb, vec3(gray), clamp(grayscale, 0.0, 1.0));
    float factor = 1.0 + clamp(contrast, 0.0, 1.0) * 3.0;
    color = clamp((color - vec3(0.5)) * factor + vec3(0.5), 0.0, 1.0);
    if (negative > 0.5) color = vec3(1.0) - color;
    fragColor = vec4(color, source.a);
}
