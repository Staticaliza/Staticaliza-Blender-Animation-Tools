in float vOwnerId;
out vec4 fragColor;

void main()
{
    // R is a stable per-object integer. G is the depth-tested visible surface
    // depth, used only to order strokes emitted by overlapping rig parts.
    fragColor = vec4(vOwnerId, gl_FragCoord.z, 0.0, 1.0);
}
