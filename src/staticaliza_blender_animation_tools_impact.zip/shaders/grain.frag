uniform sampler2D impactTex;
uniform vec2 paperResolution;
uniform float dustAmount;
uniform float filmAmount;
uniform float salt;

in vec2 uv;
out vec4 fragColor;

// Resolution-independent Boolean--Poisson grain.  Each cell owns one
// stochastic silver-halide "germ" with a marked (variable) grain radius.
// The union of those grains is evaluated directly, so this is not a tiled
// noise texture or a softened noise overlay.
float hash21(vec2 value)
{
    vec3 p = fract(vec3(value.xyx) * vec3(0.1031, 0.1030, 0.0973));
    p += dot(p, p.yzx + 33.33 + salt * 0.000001);
    return fract((p.x + p.y) * p.z);
}

vec2 hash22(vec2 value)
{
    return vec2(hash21(value + 17.0), hash21(value + 71.0));
}

float inkAt(vec2 p)
{
    // Concentration follows the canonical impact silhouette, never colors
    // introduced by aberration or bloom. The final particles still composite
    // over colorTex, so grain is visibly the topmost effect layer.
    vec4 impact = texture(impactTex,
                          clamp(p, vec2(0.0), vec2(1.0)));
    float backgroundOwner = clamp(-impact.g, 0.0, 1.0);
    return clamp(impact.r, 0.0, 1.0) *
        mix(1.0, 0.32, backgroundOwner);
}

float darkAt(vec2 p)
{
    // Dust always originates from the foreground line material. Luminance
    // must not reverse the source field when the user chooses white ink.
    return inkAt(p);
}

float valueNoise(vec2 p)
{
    vec2 cell = floor(p);
    vec2 local = fract(p);
    vec2 ease = local * local * (3.0 - 2.0 * local);
    float a = hash21(cell);
    float b = hash21(cell + vec2(1.0, 0.0));
    float c = hash21(cell + vec2(0.0, 1.0));
    float d = hash21(cell + vec2(1.0, 1.0));
    return mix(mix(a, b, ease.x), mix(c, d, ease.x), ease.y);
}

vec2 domainWarp(vec2 p)
{
    return vec2(valueNoise(p * 0.083 + 13.0),
                valueNoise(p * 0.083 + 71.0)) - 0.5;
}

// A single-pass approximation of a marked Poisson Boolean model. Each germ
// receives an asymmetric, multi-lobed boundary so medium/coarse particles
// read as irregular deposits rather than processed circles or grid stamps.
float emulsion(vec2 p, float cellSize, vec2 seed, float occupancy)
{
    vec2 grid = p / cellSize;
    vec2 base = floor(grid);
    vec2 local = fract(grid);
    float coverage = 0.0;
    for (int y = -1; y <= 1; ++y) {
        for (int x = -1; x <= 1; ++x) {
            vec2 offset = vec2(float(x), float(y));
            vec2 cell = base + offset;
            float population = step(1.0 - occupancy, hash21(cell + seed + 191.0));
            vec2 center = hash22(cell + seed);
            float radius = mix(0.13, 0.43, hash21(cell + seed + 43.0));
            vec2 delta = local - offset - center;
            float aspect = mix(0.72, 1.32, hash21(cell + seed + 109.0));
            delta.x *= aspect;
            float phase = hash21(cell + seed + 157.0) * 6.28318530718;
            float polar = atan(delta.y, delta.x);
            float boundary = 1.0 + 0.16 * sin(polar * 3.0 + phase) +
                             0.09 * sin(polar * 5.0 - phase * 1.7);
            float grain = 1.0 - smoothstep(radius * 0.58, radius,
                                            length(delta) / boundary);
            // A small attached satellite breaks the remaining single-blob
            // silhouette without turning the deposit into high-frequency salt.
            vec2 satelliteOffset = vec2(cos(phase), sin(phase)) * radius * 0.52;
            float satellite = 1.0 - smoothstep(radius * 0.24, radius * 0.47,
                                                length(delta - satelliteOffset));
            float deposit = max(grain, satellite * 0.72);
            coverage = 1.0 - (1.0 - coverage) *
                       (1.0 - population * deposit);
        }
    }
    return coverage;
}

// Fast paper-locked photographic grain. Particle centers stay inside their
// cells, while three rotated scales and irregular boundaries hide the grid.
// Unlike line Scatter, this population does not search the impact silhouette.
float filmDeposit(vec2 p, float cellSize, vec2 seed, float occupancy)
{
    vec2 grid = p / cellSize;
    vec2 cell = floor(grid);
    vec2 local = fract(grid);
    float alive = step(1.0 - occupancy, hash21(cell + seed + 191.0));
    vec2 center = mix(vec2(0.18), vec2(0.82), hash22(cell + seed));
    vec2 delta = local - center;
    vec2 axis = hash22(cell + seed + 157.0) * 2.0 - 1.0;
    axis /= max(length(axis), 0.0001);
    vec2 tangent = vec2(-axis.y, axis.x);
    float aspect = mix(0.70, 1.38, hash21(cell + seed + 109.0));
    vec2 shaped = vec2(dot(delta, axis) * aspect,
                       dot(delta, tangent) / aspect);
    float boundary = mix(0.88, 1.14, hash21(cell + seed + 277.0));
    float radius = mix(0.18, 0.48, hash21(cell + seed + 43.0));
    float particle = 1.0 - smoothstep(
        radius * 0.46, radius, length(shaped) / boundary
    );
    vec2 satelliteOffset = axis * radius * 0.52;
    float satellite = 1.0 - smoothstep(
        radius * 0.18, radius * 0.38,
        length(delta - satelliteOffset)
    );
    return alive * max(particle, satellite * 0.68);
}

float stochasticDarkField(vec2 point, vec2 p, float response)
{
    // Truncated exponential distance sampling keeps the cloud continuous and
    // avoids a visible outer shell. Range still grows strongly with amount.
    float phase = valueNoise(p * 0.021 + vec2(137.0, 419.0)) *
                  6.28318530718;
    float localReach = mix(0.62, 1.48,
                           valueNoise(p * 0.017 + vec2(53.0, 211.0)));
    float envelope = darkAt(point);
    float rangeResponse = mix(0.10, 1.0, pow(response, 2.40));
    float decayLength = mix(4.0, 42.0, pow(response, 0.85)) *
                        3.0 * rangeResponse;
    float maximumRange = decayLength * 4.60;
    float truncatedMass = 1.0 - exp(-maximumRange / decayLength);
    const int probeCount = 24;
    for (int index = 0; index < probeCount; ++index) {
        float i = float(index);
        float quantile = (i + 0.44) / float(probeCount);
        float jitter = hash21(floor(p * 0.11) +
                              vec2(i * 29.0, i * 53.0));
        float angle = phase + i * 2.39996322973 + (jitter - 0.5) * 1.10;
        float distance = (1.25 - log(max(
            0.008, 1.0 - quantile * truncatedMass)) * decayLength) *
            localReach;
        vec2 direction = vec2(cos(angle), sin(angle));
        vec2 offset = direction * distance / paperResolution;
        float falloff = exp(-distance /
                            max(1.0, decayLength * localReach));
        float cluster = mix(0.52, 1.38, valueNoise(
            (p + direction * distance) * 0.028 + 73.0));
        float contribution = darkAt(point + offset) * falloff * cluster;
        envelope = max(envelope, contribution);
    }
    return clamp(envelope, 0.0, 1.0);
}

void main()
{
    // Preserve the high-value particle morphology throughout the range. The
    // value primarily changes population and maximum travel distance.
    float normalizedDust = clamp(dustAmount / 100.0, 0.0, 1.0);
    float normalizedFilm = clamp(filmAmount / 100.0, 0.0, 1.0);
    float response = smoothstep(0.001, 0.035, normalizedDust) *
                     mix(0.20, 1.0, pow(normalizedDust, 0.55));
    response = clamp(response + normalizedDust * (1.0 - normalizedDust) *
                     0.18 * 2.06, 0.0, 1.0);
    float filmResponse = pow(normalizedFilm, 1.35);
    // From the lower-middle range onward, retain nearly the high-value
    // population while the separate range response keeps it near the line.
    // Very small values remain genuinely subtle instead of jumping at 0.01.
    float denseMinimum = mix(0.82, 1.0, pow(response, 0.60));
    float populationResponse = mix(
        response, denseMinimum,
        smoothstep(0.04, 0.12, normalizedDust));
    float extremeResponse = pow(normalizedDust, 4.0);
    if (max(response, filmResponse) <= 0.0001) {
        fragColor = vec4(0.0, 0.0, 0.0, 1.0);
        return;
    }

    // Evaluate emulsion in real output-pixel coordinates. A forced 1080-line
    // virtual grid made preview particles subpixel while final particles were
    // visible, so the same slider value changed character with resolution.
    vec2 virtualResolution = paperResolution;
    vec2 paperCoordinate = uv * virtualResolution;
    vec2 coordinate = paperCoordinate;
    float rotation = fract(salt * 0.00000061803398875) * 6.28318530718;
    mat2 grainRotation = mat2(cos(rotation), -sin(rotation),
                              sin(rotation),  cos(rotation));
    coordinate = grainRotation * (coordinate - virtualResolution * 0.5) +
                 virtualResolution * 0.5;

    // A low-frequency domain warp breaks any residual cell pattern and gives
    // the dust a lumpy, chemical-deposit silhouette rather than a halo.
    // Texture coordinates never depend on an artist slider. Strength changes
    // exposure/population only, so marks do not crawl while editing.
    vec2 filmCoordinate = coordinate +
        domainWarp(coordinate + 97.0) * 2.25;
    vec2 coordinateCenter = virtualResolution * 0.5;
    mat2 mediumRotation = mat2(0.69670670935, -0.71735609090,
                               0.71735609090,  0.69670670935);
    mat2 coarseRotation = mat2(0.31532236240,  0.94898461936,
                              -0.94898461936,  0.31532236240);
    vec2 filmFineCoordinate = filmCoordinate;
    vec2 filmSecondaryCoordinate = mediumRotation *
        (filmCoordinate - coordinateCenter) + coordinateCenter + vec2(37.0, 83.0);
    vec2 filmTertiaryCoordinate = coarseRotation *
        (filmCoordinate - coordinateCenter) + coordinateCenter + vec2(149.0, 31.0);
    float centerInk = inkAt(uv);
    float centerPaper = 1.0 - centerInk;

    // Three decorrelated micro populations avoid a repeating screen while
    // remaining below a halftone-like dot size. Strength changes population
    // monotonically and never moves an existing particle.
    float fineFilm = filmDeposit(
        filmFineCoordinate, 0.92, vec2(17.0, 83.0),
        mix(0.0, 0.68, filmResponse)
    );
    float secondaryFilm = filmDeposit(
        filmSecondaryCoordinate, 1.32, vec2(131.0, 29.0),
        mix(0.0, 0.52, pow(filmResponse, 1.08))
    );
    float tertiaryFilm = filmDeposit(
        filmTertiaryCoordinate, 2.05, vec2(59.0, 227.0),
        mix(0.0, 0.22, pow(filmResponse, 1.28))
    );
    float filmCoverage = 1.0 -
        (1.0 - fineFilm) *
        (1.0 - secondaryFilm * 0.72) *
        (1.0 - tertiaryFilm * 0.42);
    float filmExposure = mix(
        0.08, 8.00, pow(normalizedFilm, 2.15)
    );
    // Film is an optical overlay over the complete print. It must remain
    // visible over both ink and paper; only Scatter is line-source limited.
    float filmOpacity = 1.0 - exp(-filmCoverage * filmExposure);
    filmOpacity = clamp(filmOpacity, 0.0, 0.96);

    float dustOpacity = 0.0;
    if (response > 0.0001) {
    vec2 warpedCoordinate = coordinate + domainWarp(coordinate) * 7.0;
    mat2 secondaryRotation = mat2(0.89156828820,  0.45288628538,
                                 -0.45288628538,  0.89156828820);
    vec2 fineCoordinate = warpedCoordinate +
        domainWarp(paperCoordinate * 1.71 + 43.0) * 2.40;
    vec2 mediumCoordinate = mediumRotation *
        (warpedCoordinate - coordinateCenter) + coordinateCenter +
        domainWarp(paperCoordinate * 0.83 + 157.0) * 4.20;
    vec2 coarseCoordinate = coarseRotation *
        (warpedCoordinate - coordinateCenter) + coordinateCenter +
        domainWarp(paperCoordinate * 0.47 + 281.0) * 7.20;
    vec2 secondaryFineCoordinate = secondaryRotation *
        (warpedCoordinate - coordinateCenter) + coordinateCenter +
        domainWarp(paperCoordinate * 1.29 + 367.0) * 3.10;
    float darkField = stochasticDarkField(uv, paperCoordinate, response);
    float broadCloud = valueNoise(paperCoordinate * 0.023 + 31.0) * 0.42 +
                       valueNoise(paperCoordinate.yx * 0.037 + 173.0) * 0.34 +
                       valueNoise((paperCoordinate + paperCoordinate.yx) *
                                  0.014 + 293.0) * 0.24;
    float cloudModulation = mix(0.62, 1.32,
                                smoothstep(0.10, 0.92, broadCloud));
    // The sampled field already contains exponential falloff. Keep that broad
    // cloud intact so maximum Grain still has long, irregular scatter.
    float sourceSupport = pow(smoothstep(0.006, 0.72, darkField),
                              1.75);
    float broadDensity = populationResponse * centerPaper *
        sourceSupport * cloudModulation * mix(0.55, 0.80, response) *
        0.70;

    // Add a distinct contact-deposit population instead of globally raising
    // all dust. darkField falls exponentially with distance, so a power curve
    // is continuous and has no shell boundary. At low Grain the larger power
    // confines this mass to a thin band immediately outside the true line;
    // high Grain lowers the power and grows that dense band outward. The
    // multiplier deliberately saturates close to the source, producing the
    // requested heavy deposit before it smoothly evens into broad scatter.
    float nearExponent = mix(3.80, 1.12, pow(response, 0.72));
    float nearProfile = pow(clamp(darkField, 0.0, 1.0), nearExponent);
    float nearStrength = mix(1.35, 5.80, pow(response, 0.62));
    float nearDensity = populationResponse * centerPaper * nearProfile *
        cloudModulation * nearStrength;
    float dustDensity = broadDensity + nearDensity;
    dustDensity *= (1.0 + 0.35 * extremeResponse) * 0.99;
    dustDensity = clamp(dustDensity, 0.0, 0.95);

    // Two decorrelated fine populations stay stochastic at maximum. Capping
    // each below full occupancy avoids the visible one-particle-per-cell
    // lattice while their Boolean union retains a dense source deposit.
    float fineDustA = emulsion(fineCoordinate, 1.48, vec2(307.0, 43.0),
                               clamp(dustDensity * 0.72, 0.0, 0.58));
    float fineDustB = emulsion(secondaryFineCoordinate, 1.82,
                               vec2(419.0, 233.0),
                               clamp(dustDensity * 0.40, 0.0, 0.30));
    float fineDust = 1.0 - (1.0 - fineDustA) * (1.0 - fineDustB);
    float mediumDust = emulsion(mediumCoordinate, 3.45, vec2(101.0, 269.0),
                            clamp(dustDensity * 0.55, 0.0, 0.36));
    float coarseDust = emulsion(coarseCoordinate, 7.40, vec2(271.0, 157.0),
                            clamp(dustDensity * 0.18, 0.0, 0.12));
    float dust = max(fineDust,
                 max(mediumDust * 0.62, coarseDust * 0.28));
    // Continuous exponential extinction has no threshold radius. At the
    // cloud's furthest samples, proximity particles fade smoothly until the
    // underlying overlay population becomes the only visible grain.
    float dustFade = 1.0 - exp(-18.0 * dustDensity);
    dust *= dustFade;

    dustOpacity = clamp(
        dust * (0.35 + populationResponse * 0.75 + extremeResponse * 0.25),
        0.0, 0.86);
    dustOpacity = clamp(dustOpacity * 1.25, 0.0, 0.96);
    }
    // Boolean union makes the two populations overlap naturally through the
    // transition instead of exposing a seam where proximity dust ends.
    float particleCoverage = 1.0 -
        (1.0 - filmOpacity) * (1.0 - dustOpacity);
    // Keep proximity dust and the sparse full-frame overlay in separate
    // channels so optical effects can preserve their readability differently.
    fragColor = vec4(particleCoverage, dustOpacity, filmOpacity, 1.0);
}
