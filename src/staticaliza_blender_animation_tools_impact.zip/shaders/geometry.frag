in float vLight;
in vec2 vSurfaceNormal;
out vec4 fragColor;

void main()
{
    fragColor = vec4(1.0, vLight, vSurfaceNormal * 0.5 + 0.5);
}
