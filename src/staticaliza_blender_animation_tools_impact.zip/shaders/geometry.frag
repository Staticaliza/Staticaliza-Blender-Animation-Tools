in vec3 vNormal;
uniform vec2 lightFocus;
uniform float lightCastBehind;
out vec4 fragColor;
void main() {
    vec2 orbit=clamp((lightFocus-vec2(0.5))*2.0,vec2(-1.0),vec2(1.0));
    orbit/=max(1.0,length(orbit));
    float z=sqrt(max(0.0,1.0-dot(orbit,orbit)));
    z*=mix(1.0,-1.0,step(0.5,lightCastBehind));
    // Normalize AFTER interpolation. Flipping individual vertex normals in
    // the vertex shader created discontinuities on curved and concave meshes.
    vec3 normal=vNormal/max(length(vNormal),1.e-8);
    // Honor evaluated normals, including custom normals and mirrored objects.
    // A camera-Z sign test is not a surface-facing test in perspective views.
    float lambert=max(0.0,dot(normal,vec3(orbit,z)));
    float illumination=0.16+0.79*lambert;
    fragColor=vec4(1.0,illumination,normal.xy*0.5+0.5);
}
