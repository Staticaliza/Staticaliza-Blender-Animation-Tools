in vec3 position;
in float ownerId;

out float vOwnerId;

void main()
{
    vOwnerId = ownerId;
    gl_Position = vec4(position.xy * 2.0 - 1.0, position.z, 1.0);
}
