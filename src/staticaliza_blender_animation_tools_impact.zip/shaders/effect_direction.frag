uniform sampler2D ownershipTex;
uniform sampler2D impactTex;
uniform sampler2D guideTex;
uniform sampler2D rigTex;
uniform sampler2D ownerRigTex;
uniform sampler2D linearStrokeTex;
uniform int rigCount;
uniform int familyOverride;
uniform vec2 resolution;
uniform vec4 inverseProjectionW;
uniform vec4 ownerDepthDecode;
uniform vec4 linearDepthToW;
uniform int outputMode;
in vec2 uv;
out vec4 fragColor;

void main()
{
    int owner = int(round(texture(ownershipTex, uv).r));
    int rig = -1;
    if (owner > 0 && owner < textureSize(ownerRigTex, 0).x)
        rig = int(round(texelFetch(ownerRigTex, ivec2(owner, 0), 0).r)) - 1;
    int geometryRig = rig;
    vec4 guide = texture(guideTex, uv);
    vec2 authored = guide.z > .5 ? guide.xy : uv;
    vec4 current = texture(impactTex, uv);
    // Faint background coverage may fall below the nearest-seed threshold.
    // Its own authored tag still wins over a nearby, stronger subject seed.
    vec4 authoredData = current.g < -.0001 ? current : texture(impactTex, authored);
    int tag = int(round(max(0., -authoredData.a)));
    int paintedRig = tag / 8 - 1;
    if (paintedRig >= 0 && paintedRig < rigCount) rig = paintedRig;
    // Ink trails extend past their captured mesh. Continue the nearest rig's
    // authored field through those pixels instead of reverting to one rig.
    if (rig < 0 || rig >= rigCount) {
        float nearest = 1e30;
        for (int i = 0; i < rigCount; ++i) {
            vec4 bounds = texelFetch(rigTex, ivec2(i * 3 + 1, 0), 0);
            vec2 delta = (uv - clamp(uv, bounds.xy, bounds.zw)) * resolution;
            vec2 centerDelta = (uv - (bounds.xy + bounds.zw) * .5) * resolution;
            float distanceSquared = dot(delta, delta) + dot(centerDelta, centerDelta) * .001;
            if (distanceSquared < nearest) { nearest = distanceSquared; rig = i; }
        }
    }
    vec4 field = texelFetch(rigTex, ivec2(max(rig, 0) * 3, 0), 0);
    float relativeW = 1.;
    if (owner > 0 && geometryRig == rig) {
        float depth = texture(ownershipTex, uv).g * 2. - 1.;
        float inverseW = dot(inverseProjectionW, vec4(uv * 2. - 1., depth, 1.));
        if (ownerDepthDecode.w > .5) {
            inverseW = ownerDepthDecode.z > .5
                ? -(ownerDepthDecode.x + (depth + .95) / 1.9 * ownerDepthDecode.y)
                : 1.;
        }
        if (abs(inverseW) > .000001)
            relativeW = max(.001, abs(1. / inverseW) / field.w);
    }
    vec4 stroke = texture(linearStrokeTex, uv);
    if (linearDepthToW.z > .5 && stroke.r > .001 && stroke.a > .5) {
        float strokeW = stroke.b * linearDepthToW.x + linearDepthToW.y;
        if (strokeW > .000001) relativeW = strokeW / field.w;
    }
    float cameraDepth = relativeW * field.w;
    float family = familyOverride >= 0 ? -float(familyOverride) : -float(tag % 8);
    vec4 radial = texelFetch(rigTex, ivec2(max(rig, 0) * 3 + 2, 0), 0);
    if (family < -.5 && family > -1.5) {
        field.xyz = vec3(-(radial.xy * 2. - 1.) * .8, -.8) * radial.z;
        relativeW = 1.;
    }
    // XYZ stores homogeneous XY/W travel, not a normalized 2D direction.
    fragColor = outputMode == 0 ? vec4(field.xyz, relativeW)
                               : vec4(float(rig + 1), float(owner), cameraDepth, family - (radial.z < 0. ? 4. : 0.));
}
