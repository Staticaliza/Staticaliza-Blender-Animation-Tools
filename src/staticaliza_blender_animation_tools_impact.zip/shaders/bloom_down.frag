uniform sampler2D colorTex;
uniform vec2 sourceResolution;

in vec2 uv;
out vec4 fragColor;

void main()
{
    // 13-tap energy-preserving downsample from the Jimenez/Sledgehammer bloom
    // chain. Bilinear sampling gives a wide stable footprint without full-res
    // Gaussian passes or pixelated shelves.
    vec2 texel = 1.0 / sourceResolution;
    vec2 two = texel * 2.0;
    vec3 e = texture(colorTex, uv).rgb;
    vec3 result = e * 0.125;
    result += (texture(colorTex, uv + vec2(-two.x,  two.y)).rgb +
               texture(colorTex, uv + vec2( two.x,  two.y)).rgb +
               texture(colorTex, uv + vec2(-two.x, -two.y)).rgb +
               texture(colorTex, uv + vec2( two.x, -two.y)).rgb) * 0.03125;
    result += (texture(colorTex, uv + vec2(0.0,  two.y)).rgb +
               texture(colorTex, uv + vec2(-two.x, 0.0)).rgb +
               texture(colorTex, uv + vec2( two.x, 0.0)).rgb +
               texture(colorTex, uv + vec2(0.0, -two.y)).rgb) * 0.0625;
    result += (texture(colorTex, uv + vec2(-texel.x,  texel.y)).rgb +
               texture(colorTex, uv + vec2( texel.x,  texel.y)).rgb +
               texture(colorTex, uv + vec2(-texel.x, -texel.y)).rgb +
               texture(colorTex, uv + vec2( texel.x, -texel.y)).rgb) * 0.125;
    fragColor = vec4(result, 1.0);
}
