uniform sampler2D impactTex;
uniform sampler2D shapeMaskTex;
uniform sampler2D seedTex;
uniform vec2 sourceResolution;
uniform int jump;
in vec2 uv;
out vec4 fragColor;

void main() {
    vec4 best=vec4(0.0);
    float bestDistance=1.e30;
    if(jump==0) {
        // Capture thin strokes inside each quarter-resolution seed cell.
        float bestStrength=0.0;
        for(int y=0;y<4;++y)for(int x=0;x<4;++x) {
            vec2 p=uv+(vec2(x,y)-1.5)/sourceResolution;
            if(any(lessThan(p,vec2(0.0)))||any(greaterThan(p,vec2(1.0))))continue;
            vec4 shape=texture(shapeMaskTex,p);
            vec4 ink=texture(impactTex,p);
            float strength=max(ink.r*(1.0-shape.g)*mix(1.0,.32,clamp(-ink.g,0.0,1.0)),shape.r);
            if(strength>bestStrength) {bestStrength=strength;best=vec4(p,strength,1.0);}
        }
        if(bestStrength<.015)best=vec4(0.0);
    } else {
        ivec2 size=textureSize(seedTex,0);
        ivec2 cell=ivec2(uv*vec2(size));
        for(int y=-1;y<=1;++y)for(int x=-1;x<=1;++x) {
            ivec2 at=cell+ivec2(x,y)*jump;
            if(any(lessThan(at,ivec2(0)))||any(greaterThanEqual(at,size)))continue;
            vec4 seed=texelFetch(seedTex,at,0);
            vec2 delta=(uv-seed.xy)*sourceResolution;
            float distance=dot(delta,delta);
            if(seed.a>.5 && distance<bestDistance) {best=seed;bestDistance=distance;}
        }
    }
    fragColor=best;
}
