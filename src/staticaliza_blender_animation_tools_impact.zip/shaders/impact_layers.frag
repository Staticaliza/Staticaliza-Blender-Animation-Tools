uniform sampler2D subjectTex;
uniform sampler2D floorTex;

in vec2 uv;
out vec4 fragColor;

void main()
{
    vec4 radial = texture(subjectTex, uv);
    vec4 linear = texture(floorTex, uv);
    float ink = 1.0 - (1.0 - radial.r) * (1.0 - linear.r);
    float backgroundOwner = max(max(-radial.g, 0.0), max(-linear.g, 0.0));
    float lightCarrier = max(max(radial.g, 0.0), max(linear.g, 0.0));
    // Radial is evaluated first; Linear is then unioned over it. Both use the
    // same pigment, while signed ownership remains available to post effects.
    float ownership = backgroundOwner > 0.0001 ? -backgroundOwner : lightCarrier;
    fragColor = vec4(ink, ownership, linear.b, linear.a);
}
