uniform sampler2D subjectTex;
uniform sampler2D floorTex;

in vec2 uv;
out vec4 fragColor;

void main()
{
    vec4 radial = texture(subjectTex, uv);
    vec4 linear = texture(floorTex, uv);
    // A radial gap is absent pigment, never permission to erase Linear.
    // This union stays monotonic even when Twirl moves the emitter pocket.
    float ink = 1.0 - (1.0 - radial.r) * (1.0 - linear.r);
    // The front drawable owns its optical family; empty front paper does not.
    vec4 visible = (linear.r > .01 || (abs(linear.a)<.5 && linear.b>.2)) ? linear : radial;
    fragColor = vec4(ink, visible.g, linear.b, visible.a);
}
