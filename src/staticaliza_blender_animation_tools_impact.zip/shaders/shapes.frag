uniform sampler2D colorTex;
uniform sampler2D subjectTex;
uniform sampler2D shapeTex;
uniform sampler2D impactTex;
uniform sampler2D grainTex;
uniform vec2 resolution;
uniform int shapeCount;
uniform int maskOnly;
uniform float halftone;
uniform float halftoneSize;
uniform float grainActive;

in vec2 uv;
out vec4 fragColor;

float hash11(float value)
{
    return fract(sin(value * 127.1 + 311.7) * 43758.5453123);
}

float noise1(float value, float seed)
{
    float cell = floor(value);
    float fraction = fract(value);
    fraction = fraction * fraction * (3.0 - 2.0 * fraction);
    return mix(hash11(cell + seed * 37.0),
               hash11(cell + 1.0 + seed * 37.0), fraction);
}

vec2 screenDirection(float angle)
{
    // p/center are already expressed in height-normalized pixel space, so
    // reapplying frame aspect here stretches equal X/Y stars horizontally.
    vec2 delta = vec2(cos(angle), sin(angle));
    return normalize(delta + vec2(1e-7));
}

float brushArm(vec2 q, vec2 direction, float armLength,
               float baseWidth, float endScale, float seed)
{
    float rawAlong = dot(q, direction);
    float u = rawAlong / max(armLength, 0.0001);
    vec2 normal = vec2(-direction.y, direction.x);
    float across = dot(q, normal);

    // One correlated hand gesture: slow centerline drift and pressure change,
    // never per-pixel displacement or a mathematically perfect SDF spear.
    float drift = baseWidth * (
        0.075 * sin(u * 6.3 + seed * 19.3) +
        0.035 * sin(u * 15.1 + seed * 31.1));
    float handPressure = 0.78 + 0.40 *
        sin(clamp(u, 0.0, 1.0) * 3.1415927);
    // Each loaded gesture compresses independently at the collision. Their
    // overlap creates the blown-out junction without adding an SVG circle.
    float impactLoad = 1.0 + 0.52 *
        (1.0 - smoothstep(0.01, 0.29, clamp(u, 0.0, 1.0)));
    float terminal = mix(1.20, endScale, smoothstep(0.08, 1.0, u));
    float edgeRough = 0.82 + 0.30 * noise1(u * 13.0, seed) +
        0.12 * noise1(u * 37.0, seed + 11.0);
    float width = baseWidth * handPressure * impactLoad * terminal * edgeRough;
    float edgeAA = 1.35 / max(resolution.y, 1.0);
    float signedAcross = across - drift;
    // One opaque loaded swipe owns the star arm. Slow correlated edge
    // deformation gives it a brush silhouette; it is never assembled from
    // repeated parallel lanes, which created the Tesla-coil banding.
    float boundary = width * mix(0.78, 1.10,
        noise1(u * 17.0, seed + (signedAcross > 0.0 ? 23.0 : 31.0)));
    float core = 1.0 - smoothstep(
        boundary, boundary + edgeAA, abs(signedAcross));
    float body = core;
    float startGate = smoothstep(-0.035, 0.018, u);
    float endJitter = 1.0 + 0.025 * sin(seed * 91.0);
    float endGate = 1.0 - smoothstep(endJitter - 0.018, endJitter + 0.018, u);

    // Sparse edge fibres create a loaded brush silhouette. They are finite,
    // correlated with the arm, and never become a repeated internal barcode.
    // A few finite exterior bristles act as hand-drawn decoration. They share
    // the arm direction and have staggered endpoints; no perpendicular ticks
    // or repeated internal skeleton is possible.
    float fray = 0.0;
    for (int hair = 0; hair < 4; ++hair) {
        float hf = float(hair);
        float hs = hash11(seed * 83.0 + hf * 29.0 + 7.0);
        float side = hair < 2 ? -1.0 : 1.0;
        float lane = side * width * mix(0.82, 1.08, hs);
        float fibreWidth = max(edgeAA * 0.55, width * mix(0.055, 0.14, hs));
        float fibre = 1.0 - smoothstep(
            fibreWidth, fibreWidth + edgeAA,
            abs(signedAcross - lane));
        // Short edge fragments, not a second continuous outline. Long
        // parallel fibres read as banding/Tesla-coil ribs on saturated arms.
        float begin = mix(0.08, 0.68, hash11(hs * 43.0 + seed));
        float finish = min(0.99, begin + mix(
            0.10, 0.30, hash11(hs * 71.0 + seed)));
        float window = smoothstep(begin - 0.03, begin + 0.02, u) *
            (1.0 - smoothstep(finish - 0.025, finish + 0.02, u));
        fray = max(fray, fibre * window);
    }
    return clamp(max(body, fray) * startGate * endGate, 0.0, 1.0);
}

float spikyBall(vec2 q, vec2 radii, float roundness,
                float endControl, float seed)
{
    float edgeAA = 1.35 / max(resolution.y, 1.0);
    vec2 normalizedQ = q / max(radii, vec2(edgeAA * 3.0));
    float angle = atan(normalizedQ.y, normalizedQ.x);
    float angularCell = (angle + 3.1415927) / 6.2831853;
    // The p-norm evolves continuously from a diamond to an ellipse. This
    // closes the four arm concavities progressively instead of cross-fading
    // abruptly from a star into a circle.
    float exponent = mix(1.0, 2.0, roundness);
    float distanceFromCenter = pow(
        pow(abs(normalizedQ.x), exponent) +
        pow(abs(normalizedQ.y), exponent), 1.0 / exponent);
    // A loaded anisotropic impact daub with irregular radial tooth. Low
    // harmonics keep it hand-shaped; sparse high harmonics make ink spikes.
    float slowWobble = 0.88 + 0.075 * sin(angle * 5.0 + seed * 13.7) +
        0.055 * sin(angle * 9.0 - seed * 21.1);
    float tooth = noise1(angularCell * 29.0, seed + 41.0);
    float sparseSpike = pow(max(0.0,
        sin(angle * 13.0 + seed * 17.0)), 9.0);
    float boundary = slowWobble + 0.12 * tooth +
        0.18 * sparseSpike * roundness * mix(1.0, 0.16, endControl);
    float normalizedAA = edgeAA / max(min(radii.x, radii.y), edgeAA);
    float loaded = 1.0 - smoothstep(
        boundary, boundary + normalizedAA, distanceFromCenter);
    // Dry edge pickup cuts tiny correlated pieces from only the outer loaded
    // band. The center remains solid while the silhouette reads as brush,
    // not as one mathematically filled SVG primitive.
    float edgeBand = smoothstep(0.50, 0.94, distanceFromCenter);
    float angularRake = step(0.48,
        noise1(angularCell * 47.0 + distanceFromCenter * 13.0,
               seed + 89.0));
    // A second, coarser rake follows one brush-axis through the terminal
    // deposit.  Combining rather than averaging the rakes produces opaque
    // bristle islands and true paper gaps instead of an SVG-like gray fill.
    float brushCoordinate = normalizedQ.y * 17.0 +
        0.55 * sin(normalizedQ.x * 8.0 + seed * 11.0);
    float axialRake = step(0.42,
        noise1(brushCoordinate, seed + 113.0));
    float dryPickup = max(angularRake, axialRake *
        step(0.58, noise1(angularCell * 19.0, seed + 127.0)));
    return loaded * mix(1.0, dryPickup, edgeBand * 0.94);
}

float graphiteTrace(float signedAcross, float strokeT,
                    float halfWidth, float seed)
{
    float edgeAA = 1.25 / max(resolution.y, 1.0);
    float pressure = sin(clamp(strokeT, 0.0, 1.0) * 3.1415927);
    // Geometry tapers into a dry chisel end.  The deposit remains opaque, so
    // this removes round terminal balls without reintroducing alpha fog.
    pressure = mix(0.16, 1.0, pow(max(pressure, 0.0), 0.42));
    float width = max(edgeAA * 0.7, halfWidth * pressure);
    float deposit = 0.0;
    for (int hair = 0; hair < 9; ++hair) {
        float hf = float(hair);
        float hs = hash11(seed * 67.0 + hf * 23.0 + 5.0);
        float lane = mix(-0.88, 0.88, (hf + 0.5) / 9.0) * width;
        lane += (hs - 0.5) * width * 0.22;
        float wobble = width * 0.07 * sin(
            strokeT * mix(11.0, 23.0, hs) + hs * 43.0);
        float fibreWidth = max(edgeAA * 0.38,
            width * mix(0.030, 0.105, hs));
        float fibre = 1.0 - smoothstep(
            fibreWidth, fibreWidth + edgeAA * 0.68,
            abs(signedAcross - lane - wobble));
        float brokenTooth = step(0.20,
            noise1(strokeT * 39.0 + hf * 0.71, seed + hf * 3.0));
        deposit = max(deposit, fibre * mix(0.72, 1.0, brokenTooth));
    }
    float loadedCore = 1.0 - smoothstep(
        width * 0.72, width * 0.72 + edgeAA, abs(signedAcross));
    // End pressure changes geometry, never alpha. This removes the gray
    // transparency fog at doodle endpoints while retaining a brush taper.
    return max(loadedCore, deposit);
}

void roundedBezierControls(vec2 p0, vec2 p1, vec2 p2, vec2 p3,
                           out vec2 c1, out vec2 c2)
{
    float segmentLength = max(length(p2 - p1), 1.0e-7);
    vec2 incoming = normalize(p1 - p0 + vec2(1.0e-7));
    vec2 outgoing = normalize(p2 - p1 + vec2(1.0e-7));
    vec2 nextDirection = normalize(p3 - p2 + vec2(1.0e-7));
    vec2 tangentA = normalize(incoming + outgoing + vec2(1.0e-7));
    vec2 tangentB = normalize(outgoing + nextDirection + vec2(1.0e-7));
    // Convex-hull Bezier controls cannot form the inward Catmull loop/cusp.
    float handle = segmentLength * 0.115;
    c1 = p1 + tangentA * handle;
    c2 = p2 - tangentB * handle;
}

vec2 roundedBezier(vec2 p0, vec2 p1, vec2 p2, vec2 p3, float t)
{
    vec2 c1; vec2 c2;
    roundedBezierControls(p0, p1, p2, p3, c1, c2);
    float u = 1.0 - t;
    return u*u*u*p1 + 3.0*u*u*t*c1 + 3.0*u*t*t*c2 + t*t*t*p2;
}

vec2 roundedBezierDerivative(vec2 p0, vec2 p1, vec2 p2, vec2 p3, float t)
{
    vec2 c1; vec2 c2;
    roundedBezierControls(p0, p1, p2, p3, c1, c2);
    float u = 1.0 - t;
    return 3.0*u*u*(c1-p1) + 6.0*u*t*(c2-c1) +
           3.0*t*t*(p2-c2);
}

void main()
{
    vec4 base = texture(colorTex, uv);
    vec2 aspect = vec2(resolution.x / max(resolution.y, 1.0), 1.0);
    vec2 p = uv * aspect;
    vec4 result = base;
    float subject = texture(subjectTex, uv).r;
    float allShapeCoverage = 0.0;
    float allShapeEffect = 0.0;
    const int STRIDE = 6;
    const int POINT_BASE = 96;
    for (int index = 0; index < 16; ++index) {
        if (index >= shapeCount) break;
        int offset = index * STRIDE;
        vec4 header = texelFetch(shapeTex, ivec2(offset, 0), 0);
        vec4 dimensions = texelFetch(shapeTex, ivec2(offset + 1, 0), 0);
        vec4 detail = texelFetch(shapeTex, ivec2(offset + 2, 0), 0);
        vec4 color = texelFetch(shapeTex, ivec2(offset + 3, 0), 0);
        vec4 burst = texelFetch(shapeTex, ivec2(offset + 4, 0), 0);
        float starRotation = texelFetch(shapeTex, ivec2(offset + 5, 0), 0).x;
        vec2 center = header.zw * aspect;
        float shapeMask = 0.0;
        if (header.x < 0.5) {
            vec2 q = p - center;
            // 100 is a genuinely loaded rhombus-scale arm, not a slightly
            // thicker icon. The quadratic pressure curve keeps mid values
            // controllable while giving the top quarter real graphic mass.
            float thickness = mix(0.0025, 0.185,
                detail.x * detail.x);
            float endScale = detail.w <= 0.5 ?
                mix(0.025, 1.0, detail.w * 2.0) :
                mix(1.0, 1.85, (detail.w - 0.5) * 2.0);
            float reachX = dimensions.x * mix(
                1.0, 3.0, smoothstep(0.20, 1.0, dimensions.x));
            float reachY = dimensions.y * mix(
                1.0, 3.0, smoothstep(0.20, 1.0, dimensions.y));
            float primaryAngles[4] = float[4](0.0, 3.1415927, 1.5707963, -1.5707963);
            for (int arm = 0; arm < 4; ++arm) {
                float armSeed = hash11(burst.z * 53.1 + float(arm) * 17.7 + 3.0);
                float angle = primaryAngles[arm] + starRotation +
                    (armSeed - 0.5) * 0.19;
                vec2 direction = screenDirection(angle);
                // X/Y are measured against the same short-edge unit, so 100
                // has equal physical reach in both axes and can span roughly
                // three frame widths independent of aspect ratio.
                float dimension = arm < 2 ? dimensions.x : dimensions.y;
                float screenReach = dimension * mix(
                    1.0, 3.0, smoothstep(0.20, 1.0, dimension));
                vec2 reachDelta = vec2(cos(angle) * screenReach,
                                       sin(angle) * screenReach);
                float armLength = length(reachDelta) * mix(0.72, 1.27, armSeed);
                float armWidth = thickness * mix(0.68, 1.36,
                    hash11(armSeed * 79.0 + 11.0));
                shapeMask = max(shapeMask, brushArm(
                    q, direction, armLength, armWidth, endScale,
                    armSeed + burst.z));
            }

            // The upper range closes the four concave arm valleys into an
            // anisotropic diamond, then rounds it into an oval/circle at 100.
            // Independent X/Y radii preserve intentional oval stars.
            // Thickness remains the authored four-arm brush through the 90s.
            // The spiky terminal daub is a discrete 100-percent style, so no
            // gray mask crossfade or ghost duplicate can appear at 93.4483.
            float ballPhase = step(0.99995, detail.x);
            float roundness = ballPhase;
            float radiusFloor = 4.0 / max(resolution.y, 1.0);
            // X/Y remain authoritative even at maximum Thickness. The old
            // thickness floor made every loaded star large and prevented a
            // compact spiky daub; this only keeps a four-pixel raster floor.
            vec2 ballRadii = vec2(
                max(radiusFloor, reachX * 0.72),
                max(radiusFloor, reachY * 0.72));
            // Keep only a loaded inner daub; the visible terminal silhouette
            // is built by many overlapping brush gestures below.  This keeps
            // the center solid without turning the whole result into one
            // clean vector primitive.
            float ballEndControl = clamp(detail.w, 0.0, 1.0);
            float ball = spikyBall(
                q, ballRadii * mix(0.78, 0.48, roundness),
                roundness, ballEndControl, burst.z + 73.0);
            float terminalBrush = ball;
            // Short independent loaded gestures roughen the terminal daub
            // with the exact same brush-arm vocabulary as the main star.
            for (int spike = 0; spike < 20; ++spike) {
                float sf = float(spike);
                float spikeSeed = hash11(burst.z * 131.0 + sf * 43.7 + 101.0);
                float angle = starRotation + 6.2831853 * sf / 20.0 +
                    (spikeSeed - 0.5) * 0.31;
                // q and ballRadii are already in short-edge pixel units.
                // Reapplying frame aspect here made equal X/Y balls wide.
                vec2 direction = vec2(cos(angle), sin(angle));
                float ellipticalRadius = 1.0 / max(1.0e-5,
                    length(direction / ballRadii));
                float spikeLength = ellipticalRadius * mix(
                    0.82, 1.10, spikeSeed);
                // Width follows the ellipse perpendicular to this gesture.
                // Major-axis reach must not inflate diagonal spike widths and
                // therefore increase the opposite X/Y dimension.
                vec2 perpendicular = vec2(-direction.y, direction.x);
                float perpendicularRadius = 1.0 / max(1.0e-5,
                    length(perpendicular / ballRadii));
                float spikeWidth = min(ellipticalRadius,
                    perpendicularRadius * 1.18) *
                    mix(0.075, 0.16, hash11(spikeSeed * 71.0 + 13.0));
                // End owns terminal geometry at every thickness. At zero the
                // loaded daub has needle tips; at one each radial brush ends
                // as a blunt, hand-loaded stamp instead of ignoring the UI.
                float terminalEndScale = mix(0.035, 1.0, ballEndControl);
                terminalBrush = max(terminalBrush, brushArm(
                    q, direction, spikeLength, spikeWidth, terminalEndScale,
                    spikeSeed + burst.z + 17.0));
            }
            shapeMask = mix(shapeMask, terminalBrush, ballPhase);

            // The former geometric core is now one integrated diagonal burst:
            // a smaller, irregular copy of the primary brush-arm system.
            int armCount = clamp(int(burst.x + 0.5), 1, 32);
            for (int arm = 0; arm < 32; ++arm) {
                if (arm >= armCount || dimensions.z <= 0.0001) break;
                float armSeed = hash11(burst.z * 97.3 + float(arm) * 31.7 + 17.0);
                float angle = starRotation + 0.7853982 + 6.2831853 * float(arm) /
                    float(armCount) + (armSeed - 0.5) * 0.46;
                vec2 direction = screenDirection(angle);
                float screenReach = dimensions.z * mix(
                    1.0, 3.0, smoothstep(0.20, 1.0, dimensions.z)) *
                    mix(0.38, 1.34, armSeed);
                vec2 reachDelta = vec2(cos(angle) * screenReach,
                                       sin(angle) * screenReach);
                float burstWidth = mix(0.0018, 0.185,
                    burst.y * burst.y) *
                    mix(0.48, 1.38, hash11(armSeed * 61.0 + 23.0));
                shapeMask = max(shapeMask, brushArm(
                    q, direction, length(reachDelta), burstWidth,
                    mix(0.035, 1.85, burst.w),
                    armSeed + burst.z + 5.0));
            }
        } else {
            int pointStart = int(detail.y + 0.5);
            int pointCount = int(detail.z + 0.5);
            float width = mix(0.0018, 0.022, detail.x);
            for (int pointIndex = 1; pointIndex < 256; ++pointIndex) {
                if (pointIndex >= pointCount) break;
                vec4 aData = texelFetch(
                    shapeTex, ivec2(POINT_BASE + pointStart + pointIndex - 1, 0), 0);
                vec4 bData = texelFetch(
                    shapeTex, ivec2(POINT_BASE + pointStart + pointIndex, 0), 0);
                if (bData.w > 0.5) continue;
                vec4 previousData = pointIndex > 1 ? texelFetch(
                    shapeTex, ivec2(POINT_BASE + pointStart + pointIndex - 2, 0), 0)
                    : aData;
                vec4 nextData = pointIndex + 1 < pointCount ? texelFetch(
                    shapeTex, ivec2(POINT_BASE + pointStart + pointIndex + 1, 0), 0)
                    : bData;
                vec2 a = aData.xy * aspect;
                vec2 b = bData.xy * aspect;
                vec2 previous = previousData.w > 0.5 ? a : previousData.xy * aspect;
                vec2 next = nextData.w > 0.5 ? b : nextData.xy * aspect;
                vec2 ab = b - a;
                float segmentLength = max(length(ab), 1e-6);
                vec2 tangent = ab / segmentLength;
                float rawT = dot(p - a, tangent) / segmentLength;
                float t = clamp(rawT, 0.0, 1.0);
                // Refine the chord estimate against one continuous Catmull-
                // Rom centerline. Zigzags become controlled bends rather than
                // technical mitres, while the user's sampled points remain
                // interpolation anchors.
                for (int refine = 0; refine < 3; ++refine) {
                    vec2 curvePoint = roundedBezier(previous, a, b, next, t);
                    vec2 curveTangent = roundedBezierDerivative(
                        previous, a, b, next, t);
                    float denominator = max(dot(curveTangent, curveTangent), 1e-7);
                    t = clamp(t - dot(curvePoint - p, curveTangent) / denominator,
                        0.0, 1.0);
                }
                vec2 curvePoint = roundedBezier(previous, a, b, next, t);
                tangent = normalize(roundedBezierDerivative(
                    previous, a, b, next, t) + vec2(1e-7));
                vec2 normal = vec2(-tangent.y, tangent.x);
                float strokeSeed = hash11(
                    burst.z * 47.0 + float(index) * 7.0);
                float globalT = (float(pointIndex - 1) + t) /
                    max(float(pointCount - 1), 1.0);
                // One continuous hand phase crosses every sampled segment.
                // Moving the shape is therefore a rigid translation rather
                // than resampling a centipede of round per-segment capsules.
                float centerDrift = width * 0.11 *
                    sin(globalT * 17.3 + strokeSeed * 31.0);
                vec2 nearest = curvePoint +
                    normal * centerDrift;
                float pressure = mix(aData.z, bData.z, t);
                vec2 pointDelta = p - nearest;
                float signedDistance = length(pointDelta) *
                    (dot(pointDelta, normal) < 0.0 ? -1.0 : 1.0);
                float stroke = graphiteTrace(
                    signedDistance, globalT, width * pressure, strokeSeed);
                // Circular loaded joins close acute-turn pinholes without
                // creating the former centipede chain: only the shared sample
                // knots receive this dry-brush dab.
                float knotDistance = 1.0e6;
                if (pointIndex > 1 && aData.w < 0.5)
                    knotDistance = min(knotDistance, length(p - a));
                if (pointIndex + 1 < pointCount && nextData.w < 0.5)
                    knotDistance = min(knotDistance, length(p - b));
                float knotRadius = width * pressure * 0.78;
                float knot = 1.0 - smoothstep(
                    knotRadius, knotRadius + 1.25 / resolution.y,
                    knotDistance);
                stroke = max(stroke, knot);
                // The nearest-point solve already clamps to this finite
                // Bezier. A chord-space gate cut the curved corners away and
                // left triangular hooks at tight bends.
                shapeMask = max(shapeMask, stroke);
            }
        }
        // A Back shape is a true rear layer.  Both the captured subject plate
        // and generated ink own pixels above it.  The previous ink-only mask
        // let a Back star replace the subject's base fill, making Back and
        // Front visually indistinguishable on equal-black palettes.
        float inkCoverage = texture(impactTex, uv).r;
        float subjectCoverage = smoothstep(0.015, 0.32, subject);
        float rearVisibility = (1.0 - subjectCoverage) *
            (1.0 - clamp(inkCoverage, 0.0, 1.0));
        float visibility = header.y > 0.5 ? rearVisibility : 1.0;
        // Shapes are graphic deposits. Edge variation changes occupied area,
        // never transparency; this removes gray skeletons and endpoint fades.
        float opaqueDeposit = smoothstep(0.28, 0.58, shapeMask);
        if (header.x < 0.5) {
            // A fully loaded star is black graphic pigment, including when X
            // and Y are highly anisotropic. Tighten only the final coverage
            // reconstruction; the generated silhouette remains unchanged.
            float loadedPhase = smoothstep(0.94, 1.0, detail.x);
            opaqueDeposit = mix(
                opaqueDeposit, smoothstep(0.40, 0.47, shapeMask), loadedPhase);
        }
        float effectInfluence = clamp(dimensions.w, 0.0, 1.0);
        // Shapes join the same print vocabulary as the frame. Halftone is
        // evaluated on shape coverage here because shapes are intentionally
        // composited after the subject's canonical print pass.
        float localHalftone = clamp(halftone * effectInfluence, 0.0, 1.0);
        if (localHalftone > 0.0001) {
            float cellPixels = mix(3.25, 30.0,
                sqrt(clamp((halftoneSize - 1.0) / 99.0, 0.0, 1.0)));
            float screenAngle = 0.39269908169;
            mat2 rotation = mat2(cos(screenAngle), -sin(screenAngle),
                                 sin(screenAngle),  cos(screenAngle));
            vec2 local = fract(rotation *
                (uv * resolution - resolution * 0.5) / cellPixels) - 0.5;
            // Influence scales the dot aperture itself.  At zero the aperture
            // covers the cell (an exact clean-shape bypass); increasing it
            // opens visible paper around discrete ink dots without blending
            // an unaffected copy beneath the print.
            float dotRadius = mix(0.72, 0.38, localHalftone);
            float printed = opaqueDeposit * step(length(local), dotRadius);
            opaqueDeposit = printed;
        }
        // Reuse the canonical grain population. Influence zero is an exact
        // clean-shape bypass; higher values progressively break the deposit
        // with the same scatter/film carrier as the rest of the frame.
        vec3 grainSample = texture(grainTex, uv).rgb;
        float localGrain = clamp(grainActive * effectInfluence, 0.0, 1.0);
        float grainBreak = clamp(grainSample.g * 0.48 + grainSample.b * 0.72,
                                 0.0, 0.92);
        opaqueDeposit *= 1.0 - grainBreak * localGrain;
        float alpha = opaqueDeposit * color.a * visibility;
        allShapeCoverage = max(allShapeCoverage, alpha);
        allShapeEffect = max(allShapeEffect, alpha * effectInfluence);
        result.rgb = mix(result.rgb, color.rgb, alpha);
        result.a = max(result.a, alpha);
    }
    fragColor = maskOnly != 0 ?
        vec4(allShapeEffect, allShapeCoverage, 0.0, 1.0) : result;
}
