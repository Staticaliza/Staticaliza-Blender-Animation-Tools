uniform sampler2D colorTex;
uniform sampler2D subjectTex;
uniform sampler2D shapeTex;
uniform sampler2D impactTex;
uniform sampler2D grainTex;
uniform vec2 resolution;
uniform int shapeCount;
uniform int maskOnly;
uniform float halftone;
uniform float halftoneSize;
uniform vec2 paperResolution;
uniform float grainActive;
uniform vec4 frameInk;
uniform vec4 framePaper;

in vec2 uv;
out vec4 fragColor;

float hash11(float value)
{
    return fract(sin(value * 127.1 + 311.7) * 43758.5453123);
}

float noise1(float value, float seed)
{
    float cell = floor(value);
    float fraction = fract(value);
    fraction = fraction * fraction * (3.0 - 2.0 * fraction);
    return mix(hash11(cell + seed * 37.0),
               hash11(cell + 1.0 + seed * 37.0), fraction);
}

float paperTooth(vec2 p, float seed) {
    // Jittered radial deposits on a sheared lattice have no rectangular weave.
    p = mat2(0.93,0.37,-0.28,1.07)*p;
    vec2 cell=floor(p);
    float deposit=0.0;
    for(int y=-1;y<=1;++y)for(int x=-1;x<=1;++x) {
        vec2 id=cell+vec2(x,y);
        float h=hash11(dot(id,vec2(127.1,311.7))+seed);
        vec2 center=id+vec2(h,hash11(h*971.0+seed));
        float radius=mix(0.12,0.39,hash11(h*173.0));
        float distance=length(p-center);
        deposit=max(deposit,1.0-smoothstep(radius*0.35,radius,distance));
    }
    return deposit;
}

vec2 screenDirection(float angle)
{
    // p/center are already expressed in height-normalized pixel space, so
    // reapplying frame aspect here stretches equal X/Y stars horizontally.
    vec2 delta = vec2(cos(angle), sin(angle));
    return normalize(delta + vec2(1e-7));
}

float angularNoise(float x,float seed) {
    float cell=floor(x);
    return mix(hash11(cell+seed*37.),hash11(cell+1.+seed*37.),fract(x));
}

float starPenPressure(float u, float seed)
{
    // One continuous pressure gesture, with independent early/late loading.
    // Cubic interpolation stays inside the control values: no overshoot,
    // short bumps, or repeated edge teeth masquerading as pencil texture.
    float a=mix(.76,1.24,hash11(seed*37.0+13.0));
    float b=mix(.76,1.24,hash11(seed*53.0+71.0));
    float v=1.0-u;
    return v*v*v+3.0*v*v*u*a+3.0*v*u*u*b+u*u*u;
}

float brushArmCoverage(vec2 q, vec2 direction, float armLength,
               float baseWidth, float endScale, float seed, float outline,
               float load)
{
    float along=dot(q,direction);
    float tip=armLength*(1.0+.025*sin(seed*91.));
    // Grow the ink beyond the unchanged fill tip. Retaper the outer gesture
    // to this new tip instead of cutting back the fill to close its point.
    float pointed=1.0-smoothstep(.02,.15,endScale);
    tip+=pointed*min(tip*.24,outline*4.0);
    float u=clamp(along/max(tip,.00001),0.0,1.0);
    float aa=.8/max(resolution.y,1.0);
    float across=dot(q,vec2(-direction.y,direction.x));
    float side=across<0.0 ? -1.0 : 1.0;
    float edgeSeed=seed+(side<0.0?23.:71.);
    float fillU=u;
    float taper=pow(1.0-fillU,mix(2.45,1.0,load));
    float width=baseWidth*(1.50*taper+endScale*.85*fillU);
    // A restrained pressure variation leaves the original silhouette intact.
    // Both halves meet at identical root width, without transverse steps.
    float edgeGate=smoothstep(0.,.18,u)*(1.0-smoothstep(.86,1.0,u));
    float pressure=starPenPressure(u,edgeSeed);
    width*=mix(1.0,pressure,edgeGate);
    float flatEnd=smoothstep(.08,.55,endScale);
    // A pointed outline tapers with the gesture instead of carrying a thick
    // terminal cap, which read as a bead on the end of the star.
    float tipGate=mix(pow(1.0-u,.75),1.0,flatEnd);
    float strokePressure=1.0+3.0*(starPenPressure(u,edgeSeed+137.)-1.0);
    float stroke=outline*mix(.91,strokePressure,edgeGate)*tipGate;
    float boundary=width+stroke;
    // Subtle connected hand drift follows the contour rather than adding
    // little marks outside it. Keep corrections broad and below one pixel.
    boundary+=(noise1(u*5.0,edgeSeed+43.)-.5)*
        min(boundary*.08,.9/max(resolution.y,1.0))*edgeGate;
    float tipExtension=stroke*flatEnd;
    float distance=abs(across)-boundary;
    // Expand the terminal as well as both sides for blunt ends.
    float cap=tip+tipExtension;
    // Opposite arms already meet at the root. Extending their base caps by
    // the outline width creates little square tabs when the other axis is 0.
    float alongGate=step(-aa*.05,along)*(1.0-smoothstep(cap-aa,cap+aa,along));
    float deposit=(1.0-smoothstep(-aa,aa,distance))*alongGate;
    // Irregularity belongs to the continuous contour and pigment. Detached
    // subpixel fringe marks looked like dots when the drawing was enlarged.
    return deposit;
}

float brushArm(vec2 q, vec2 direction, float armLength,
               float baseWidth, float endScale, float seed, float outline, float load) {
    // Fill geometry is independent of the outline slider.
    return brushArmCoverage(q,direction,armLength,
                            baseWidth,endScale,seed,0.0,load);
}
float outlinedArm(vec2 q, vec2 direction, float armLength,
                  float baseWidth, float endScale, float seed, float outline, float load) {
    // Clamp the evaluation to the original tip while moving the query's cap
    // distance outward, so a blunt tip keeps a constant stroke thickness.
    return brushArmCoverage(q,direction,armLength,baseWidth,endScale,seed,outline,load);
}

float roundDaub(vec2 q, vec2 radii, float seed, float outline)
{
    float aa=.8/max(resolution.y,1.0);
    vec2 local=q/max(radii,vec2(aa*4.));
    float angle=atan(local.y,local.x);
    // Shared low harmonics keep fill and outline fitted to one closed contour.
    float contour=1.0+.023*sin(angle*3.+seed*13.7)
        +.015*sin(angle*5.-seed*21.1)+.007*sin(angle*11.+seed*7.);
    float radius=length(q)/max(length(local),.00001);
    float distance=(length(local)-contour)*radius-outline;
    if(length(q)<aa)return 1.0;
    float core=1.0-smoothstep(-aa,aa,distance);
    return core;
}

float graphiteTrace(float signedAcross, float strokeT,
                    float halfWidth, float seed)
{
    float edgeAA = 1.25 / max(resolution.y, 1.0);
    float pressure = sin(clamp(strokeT, 0.0, 1.0) * 3.1415927);
    // Geometry tapers into a dry chisel end.  The deposit remains opaque, so
    // this removes round terminal balls without reintroducing alpha fog.
    pressure = mix(0.16, 1.0, pow(max(pressure, 0.0), 0.42));
    float width = max(edgeAA * 0.7, halfWidth * pressure);
    float deposit = 0.0;
    for (int hair = 0; hair < 9; ++hair) {
        float hf = float(hair);
        float hs = hash11(seed * 67.0 + hf * 23.0 + 5.0);
        float lane = mix(-0.88, 0.88, (hf + 0.5) / 9.0) * width;
        lane += (hs - 0.5) * width * 0.22;
        float wobble = width * 0.07 * sin(
            strokeT * mix(11.0, 23.0, hs) + hs * 43.0);
        float fibreWidth = max(edgeAA * 0.38,
            width * mix(0.030, 0.105, hs));
        float fibre = 1.0 - smoothstep(
            fibreWidth, fibreWidth + edgeAA * 0.68,
            abs(signedAcross - lane - wobble));
        float brokenTooth = step(0.20,
            noise1(strokeT * 39.0 + hf * 0.71, seed + hf * 3.0));
        deposit = max(deposit, fibre * mix(0.72, 1.0, brokenTooth));
    }
    float loadedCore = 1.0 - smoothstep(
        width * 0.72, width * 0.72 + edgeAA, abs(signedAcross));
    // End pressure changes geometry, never alpha. This removes the gray
    // transparency fog at doodle endpoints while retaining a brush taper.
    return max(loadedCore, deposit);
}

void roundedBezierControls(vec2 p0, vec2 p1, vec2 p2, vec2 p3,
                           out vec2 c1, out vec2 c2)
{
    float segmentLength = max(length(p2 - p1), 1.0e-7);
    vec2 incoming = normalize(p1 - p0 + vec2(1.0e-7));
    vec2 outgoing = normalize(p2 - p1 + vec2(1.0e-7));
    vec2 nextDirection = normalize(p3 - p2 + vec2(1.0e-7));
    vec2 tangentA = normalize(incoming + outgoing + vec2(1.0e-7));
    vec2 tangentB = normalize(outgoing + nextDirection + vec2(1.0e-7));
    // Convex-hull Bezier controls cannot form the inward Catmull loop/cusp.
    float handle = segmentLength * 0.115;
    c1 = p1 + tangentA * handle;
    c2 = p2 - tangentB * handle;
}

vec2 roundedBezier(vec2 p0, vec2 p1, vec2 p2, vec2 p3, float t)
{
    vec2 c1; vec2 c2;
    roundedBezierControls(p0, p1, p2, p3, c1, c2);
    float u = 1.0 - t;
    return u*u*u*p1 + 3.0*u*u*t*c1 + 3.0*u*t*t*c2 + t*t*t*p2;
}

vec2 roundedBezierDerivative(vec2 p0, vec2 p1, vec2 p2, vec2 p3, float t)
{
    vec2 c1; vec2 c2;
    roundedBezierControls(p0, p1, p2, p3, c1, c2);
    float u = 1.0 - t;
    return 3.0*u*u*(c1-p1) + 6.0*u*t*(c2-c1) +
           3.0*t*t*(p2-c2);
}

void main()
{
    vec4 base = texture(colorTex, uv);
    vec2 aspect = vec2(resolution.x / max(resolution.y, 1.0), 1.0);
    vec2 p = uv * aspect;
    vec4 result = base;
    float subject = texture(subjectTex, uv).r;
    float allShapeCoverage = 0.0;
    float allShapeEffect = 0.0;
    const int STRIDE = 7;
    const int POINT_BASE = 112;
    // The texture is ordered Back then Front, bottom list row to top row.
    for (int index = 0; index < 16; ++index) {
        if (index >= shapeCount) break;
        int offset = index * STRIDE;
        vec4 header = texelFetch(shapeTex, ivec2(offset, 0), 0);
        vec4 dimensions = texelFetch(shapeTex, ivec2(offset + 1, 0), 0);
        vec4 detail = texelFetch(shapeTex, ivec2(offset + 2, 0), 0);
        vec4 color = texelFetch(shapeTex, ivec2(offset + 3, 0), 0);
        vec4 burst = texelFetch(shapeTex, ivec2(offset + 4, 0), 0);
        vec4 pose = texelFetch(shapeTex, ivec2(offset + 5, 0), 0);
        float starRotation = pose.x;
        vec4 strokeData = texelFetch(shapeTex, ivec2(offset + 6, 0), 0);
        vec2 center = header.zw * aspect;
        vec2 shapeP = p;
        float tiltLength = length(pose.yz);
        // One inverse plane projection moves the complete shape, including
        // fill, outline and circle, instead of rotating each arm separately.
        if (tiltLength > 0.00000001) {
            vec2 axis = pose.yz / tiltLength;
            float angle = min(tiltLength, 1.0) * (1.570796327 - 0.015);
            float c = cos(angle), sn = sin(angle);
            vec2 delta = p - center;
            float parallel = dot(delta, axis);
            float denominator=c-parallel*sn/4.0;
            if(denominator<=0.0001)continue;
            float along = parallel / denominator;
            shapeP = center + delta * (1.0 + along * sn / 4.0) + axis * along * (1.0-c);
        }
        float shapeMask = 0.0;
        float strokeShapeMask = 0.0;
        float strokeActive = step(0.0001, strokeData.x);
        float strokeWidth = 0.0;
        if (strokeActive > 0.5) {
            vec2 strokePixel = shapeP * resolution.y;
            float strokeMacro = noise1(
                strokePixel.x / 43.0 + strokePixel.y / 57.0,
                burst.z + 211.0);
            float strokeMeso = noise1(
                strokePixel.x / 17.0 - strokePixel.y / 23.0,
                burst.z + 307.0);
            strokeWidth = mix(1.0, 18.0, pow(
                clamp(strokeData.x, 0.0, 1.0), 0.72)) /
                max(resolution.y, 1.0) *
                mix(0.72, 1.22,
                    strokeMacro * 0.70 + strokeMeso * 0.30);
        }
        if (header.x < 0.5) {
            vec2 q = shapeP - center;
            // 100 is a genuinely loaded rhombus-scale arm, not a slightly
            // thicker icon. The quadratic pressure curve keeps mid values
            // controllable while giving the top quarter real graphic mass.
            float thickness = mix(0.0025, 0.185,
                detail.x * detail.x);
            float load=smoothstep(.50,1.0,detail.x);
            float endScale = detail.w <= 0.5 ?
                mix(0.0, 1.0, detail.w * 2.0) :
                mix(1.0, 1.85, (detail.w - 0.5) * 2.0);
            float reachX = dimensions.x * mix(
                1.0, 3.0, smoothstep(0.20, 1.0, dimensions.x));
            float reachY = dimensions.y * mix(
                1.0, 3.0, smoothstep(0.20, 1.0, dimensions.y));
            float primaryAngles[4] = float[4](0.0, 3.1415927, 1.5707963, -1.5707963);
            for (int arm = 0; arm < 4; ++arm) {
                float armSeed = hash11(burst.z * 53.1 + float(arm) * 17.7 + 3.0);
                float axisSeed=hash11(burst.z*53.1+floor(float(arm)*.5)*17.7+3.0);
                float angle = primaryAngles[arm] + starRotation +
                    (axisSeed - 0.5) * mix(.19,.03,load);
                vec2 direction = screenDirection(angle);
                // X/Y are measured against the same short-edge unit, so 100
                // has equal physical reach in both axes and can span roughly
                // three frame widths independent of aspect ratio.
                float dimension = arm < 2 ? dimensions.x : dimensions.y;
                float screenReach = dimension * mix(
                    1.0, 3.0, smoothstep(0.20, 1.0, dimension));
                vec2 reachDelta = vec2(cos(angle) * screenReach,
                                       sin(angle) * screenReach);
                reachDelta*=mix(mix(0.72,1.27,armSeed),.90,load);
                direction=normalize(reachDelta+vec2(1e-8));
                float armLength=length(reachDelta);
                if(armLength<=.00001)continue;
                // Opposite arms share their root width, even when one axis
                // is zero or arm lengths differ. No central shear seam.
                float crossReach=arm<2?reachY:reachX;
                float armWidth=mix(min(thickness,screenReach*.72*.30),crossReach*.60,load);
                // With the other axis at zero retain the two-arm drawing.
                if(crossReach<=.00001)armWidth=thickness;
                shapeMask = max(shapeMask, brushArm(
                    q, direction, armLength, armWidth, endScale,
                    armSeed + burst.z, strokeWidth,load));
                if (strokeActive > 0.5) {
                    strokeShapeMask = max(strokeShapeMask, outlinedArm(
                        q, direction, armLength, armWidth, endScale,
                        armSeed + burst.z, strokeWidth,load));
                }
            }

            // Maximum Thickness is one closed, slightly hand-shaped ellipse.
            // Equal X/Y produce a circle; no radial spikes or internal rake holes.
            if(detail.x>=.99995) {
                float radiusFloor=4.0/max(resolution.y,1.0);
                vec2 ballRadii=max(vec2(radiusFloor),vec2(reachX,reachY)*.72);
                float c=cos(starRotation),sn=sin(starRotation);
                vec2 localQ=vec2(c*q.x+sn*q.y,-sn*q.x+c*q.y);
                shapeMask=roundDaub(localQ,ballRadii,burst.z+73.,0.0);
                if(strokeActive>.5)
                    strokeShapeMask=roundDaub(localQ,ballRadii,burst.z+73.,strokeWidth);
            }

            // The former geometric core is now one integrated diagonal burst:
            // a smaller, irregular copy of the primary brush-arm system.
            int armCount = clamp(int(burst.x + 0.5), 1, 32);
            for (int arm = 0; arm < 32; ++arm) {
                if (arm >= armCount || dimensions.z <= 0.0001) break;
                float armSeed = hash11(burst.z * 97.3 + float(arm) * 31.7 + 17.0);
                float angle = starRotation + 0.7853982 + 6.2831853 * float(arm) /
                    float(armCount) + (armSeed - 0.5) * 0.46;
                vec2 direction = screenDirection(angle);
                float screenReach = dimensions.z * mix(
                    1.0, 3.0, smoothstep(0.20, 1.0, dimensions.z)) *
                    mix(0.38, 1.34, armSeed);
                vec2 reachDelta = vec2(cos(angle) * screenReach,
                                       sin(angle) * screenReach);
                direction=normalize(reachDelta+vec2(1e-8));
                float burstWidth = mix(0.0018, 0.185,
                    burst.y * burst.y) *
                    mix(0.48, 1.38, hash11(armSeed * 61.0 + 23.0));
                shapeMask = max(shapeMask, brushArm(
                    q, direction, length(reachDelta), burstWidth,
                    mix(0.035, 1.85, burst.w),
                    armSeed + burst.z + 5.0, strokeWidth,0.0));
                if (strokeActive > 0.5) {
                    strokeShapeMask = max(strokeShapeMask, outlinedArm(
                        q, direction, length(reachDelta),
                        burstWidth,
                        mix(0.035, 1.85, burst.w),
                        armSeed + burst.z + 5.0, strokeWidth,0.0));
                }
            }
        } else {
            // Rotate the complete freehand deposit around its authored shape
            // center. Inverse-transforming the sample point preserves the
            // original points, pressure, joins, and deterministic brush seed.
            float doodleCos = cos(starRotation);
            float doodleSin = sin(starRotation);
            vec2 doodleDelta = shapeP - center;
            vec2 doodleP = center + vec2(
                doodleCos * doodleDelta.x + doodleSin * doodleDelta.y,
               -doodleSin * doodleDelta.x + doodleCos * doodleDelta.y);
            int pointStart = int(detail.y + 0.5);
            int pointCount = int(detail.z + 0.5);
            float width = mix(0.0018, 0.022, detail.x);
            for (int pointIndex = 1; pointIndex < 256; ++pointIndex) {
                if (pointIndex >= pointCount) break;
                vec4 aData = texelFetch(
                    shapeTex, ivec2(POINT_BASE + pointStart + pointIndex - 1, 0), 0);
                vec4 bData = texelFetch(
                    shapeTex, ivec2(POINT_BASE + pointStart + pointIndex, 0), 0);
                if (bData.w > 0.5) continue;
                vec4 previousData = pointIndex > 1 ? texelFetch(
                    shapeTex, ivec2(POINT_BASE + pointStart + pointIndex - 2, 0), 0)
                    : aData;
                vec4 nextData = pointIndex + 1 < pointCount ? texelFetch(
                    shapeTex, ivec2(POINT_BASE + pointStart + pointIndex + 1, 0), 0)
                    : bData;
                vec2 a = aData.xy * aspect;
                vec2 b = bData.xy * aspect;
                vec2 previous = previousData.w > 0.5 ? a : previousData.xy * aspect;
                vec2 next = nextData.w > 0.5 ? b : nextData.xy * aspect;
                vec2 ab = b - a;
                float segmentLength = max(length(ab), 1e-6);
                vec2 tangent = ab / segmentLength;
                float rawT = dot(doodleP - a, tangent) / segmentLength;
                float t = clamp(rawT, 0.0, 1.0);
                // Refine the chord estimate against one continuous Catmull-
                // Rom centerline. Zigzags become controlled bends rather than
                // technical mitres, while the user's sampled points remain
                // interpolation anchors.
                for (int refine = 0; refine < 3; ++refine) {
                    vec2 curvePoint = roundedBezier(previous, a, b, next, t);
                    vec2 curveTangent = roundedBezierDerivative(
                        previous, a, b, next, t);
                    float denominator = max(dot(curveTangent, curveTangent), 1e-7);
                    t = clamp(t - dot(curvePoint - doodleP, curveTangent) / denominator,
                        0.0, 1.0);
                }
                vec2 curvePoint = roundedBezier(previous, a, b, next, t);
                tangent = normalize(roundedBezierDerivative(
                    previous, a, b, next, t) + vec2(1e-7));
                vec2 normal = vec2(-tangent.y, tangent.x);
                float strokeSeed = hash11(
                    burst.z * 47.0 + float(index) * 7.0);
                float globalT = (float(pointIndex - 1) + t) /
                    max(float(pointCount - 1), 1.0);
                // One continuous hand phase crosses every sampled segment.
                // Moving the shape is therefore a rigid translation rather
                // than resampling a centipede of round per-segment capsules.
                float centerDrift = width * 0.11 *
                    sin(globalT * 17.3 + strokeSeed * 31.0);
                vec2 nearest = curvePoint +
                    normal * centerDrift;
                float pressure = mix(aData.z, bData.z, t);
                vec2 pointDelta = doodleP - nearest;
                float signedDistance = length(pointDelta) *
                    (dot(pointDelta, normal) < 0.0 ? -1.0 : 1.0);
                float stroke = graphiteTrace(
                    signedDistance, globalT, width * pressure, strokeSeed);
                // The nearest-point solve already clamps to this finite
                // Bezier. A chord-space gate cut the curved corners away and
                // left triangular hooks at tight bends.
                shapeMask = max(shapeMask, stroke);
            }
        }
        // The complete subject occludes Back shapes, including hatch gaps.
        float inkCoverage=clamp(texture(impactTex,uv).r,0.0,1.0);
        vec3 drawnDifference=abs(texture(colorTex,uv).rgb-framePaper.rgb);
        float visibleLight=max(drawnDifference.r,max(drawnDifference.g,drawnDifference.b));
        float rearVisibility=1.0-clamp(max(max(inkCoverage,visibleLight),max(subject,texture(impactTex,uv).b)),0.0,1.0);
        float visibility = header.y > 0.5 ? rearVisibility : 1.0;
        // Shapes are graphic deposits. Edge variation changes occupied area,
        // never transparency; this removes gray skeletons and endpoint fades.
        float opaqueDeposit = header.x < 0.5 ? clamp(shapeMask,0.0,1.0) : smoothstep(0.28, 0.58, shapeMask);
        if (header.x < 0.5) {
            // A fully loaded star is black graphic pigment, including when X
            // and Y are highly anisotropic. Tighten only the final coverage
            // reconstruction; the generated silhouette remains unchanged.
            float loadedPhase = smoothstep(0.94, 1.0, detail.x);
            opaqueDeposit = mix(
                opaqueDeposit, shapeMask, loadedPhase);
        }
        float cleanDeposit = opaqueDeposit;
        float strokeDeposit = 0.0;
        if (header.x < 0.5 && strokeActive > 0.5) {
            // Match the Lighting Bleed vocabulary: a slowly varying dilation
            // around the authored pigment, populated by the same dry-brush
            // geometry rather than a mathematically exact vector contour.
            // Opaque underpaint first, then the original fill. Subtracting
            // the fill here blends its antialiased boundary twice and leaks black.
            float widenedDeposit = clamp(strokeShapeMask,0.0,1.0);
            strokeDeposit = max(widenedDeposit, cleanDeposit);
        }
        float effectInfluence = clamp(dimensions.w, 0.0, 1.0);
        // Shapes join the same print vocabulary as the frame. Halftone is
        // evaluated on shape coverage here because shapes are intentionally
        // composited after the subject's canonical print pass.
        float localHalftone = clamp(halftone * effectInfluence, 0.0, 1.0);
        if (localHalftone > 0.0001) {
            float cellPixels = mix(3.25, 30.0,
                sqrt(clamp((halftoneSize - 1.0) / 99.0, 0.0, 1.0)));
            float screenAngle = 0.39269908169;
            mat2 rotation = mat2(cos(screenAngle), -sin(screenAngle),
                                 sin(screenAngle),  cos(screenAngle));
            vec2 local = fract(rotation *
                (uv * paperResolution - paperResolution * 0.5) / cellPixels) - 0.5;
            // Influence scales the dot aperture itself.  At zero the aperture
            // covers the cell (an exact clean-shape bypass); increasing it
            // opens visible paper around discrete ink dots without blending
            // an unaffected copy beneath the print.
            float dotRadius = mix(0.72, 0.38, localHalftone);
            float printed = opaqueDeposit * step(length(local), dotRadius);
            opaqueDeposit = printed;
        }
        // Reuse the canonical grain population. Influence zero is an exact
        // clean-shape bypass; higher values progressively break the deposit
        // with the same scatter/film carrier as the rest of the frame.
        vec3 grainSample = texture(grainTex, uv).rgb;
        float localGrain = clamp(grainActive * effectInfluence, 0.0, 1.0);
        float strokeAlpha = strokeDeposit * visibility;
        float alpha = opaqueDeposit * color.a * visibility;
        float combinedAlpha = max(strokeAlpha, alpha);
        float effectFootprint=clamp(combinedAlpha,0.0,1.0);
        // Source-over ownership: an unaffected top shape also shields grain
        // emitted by an influenced shape underneath it.
        allShapeCoverage=1.0-(1.0-allShapeCoverage)*(1.0-effectFootprint);
        allShapeEffect=mix(allShapeEffect,effectInfluence,effectFootprint);
        // Solid pigment under the contour's pencil corrections. No tiled
        // scratch overlay across either the fill or the outline.
        vec3 strokePigment=strokeData.yzw;
        vec3 fillPigment=color.rgb;
        result.rgb = mix(result.rgb, strokePigment, strokeAlpha);
        result.a = max(result.a, strokeAlpha);
        result.rgb = mix(result.rgb, fillPigment, alpha);
        result.a = max(result.a, alpha);
    }
    // One final print layer above every shape fill and outline. Shape pigment
    // must not recolor the frame's grain or hide it behind a later shape.
    if(maskOnly==0 && grainActive>0.0) {
        vec3 grain=texture(grainTex,uv).rgb;
        float coverage=allShapeCoverage*step(.0001,allShapeEffect);
        result.rgb=mix(result.rgb,frameInk.rgb,clamp(grain.g*coverage,0.0,.96));
        result.rgb=mix(result.rgb,vec3(1.0)-result.rgb,clamp(grain.b*coverage,0.0,.96));
    }

    fragColor = maskOnly != 0 ?
        vec4(allShapeEffect, allShapeCoverage, 0.0, 1.0) : result;
}
