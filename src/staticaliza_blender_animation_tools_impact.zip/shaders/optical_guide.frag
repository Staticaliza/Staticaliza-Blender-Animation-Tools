uniform sampler2D impactTex;
uniform sampler2D seedTex;
uniform vec2 resolution;
uniform int jump;
in vec2 uv;
out vec4 fragColor;
void main(){
 if(jump==0){vec4 mask=texture(impactTex,uv);fragColor=(mask.r>.005||mask.b>.2)?vec4(uv,1.,0.):vec4(-1.,-1.,0.,0.);return;}
 vec4 best=texture(seedTex,uv);float distanceBest=best.z>.5?length((best.xy-uv)*resolution):1e20;
 for(int y=-1;y<=1;++y)for(int x=-1;x<=1;++x){
  vec2 p=uv+vec2(x,y)*float(jump)/resolution;
  if(any(lessThan(p,vec2(0.)))||any(greaterThan(p,vec2(1.))))continue;
  vec4 seed=texture(seedTex,p);if(seed.z<.5)continue;
  float distanceHere=length((seed.xy-uv)*resolution);
  if(distanceHere<distanceBest){best=seed;distanceBest=distanceHere;}
 }
 fragColor=best;
}
