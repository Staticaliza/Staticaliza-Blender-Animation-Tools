uniform sampler2D colorTex;
uniform sampler2D glowTex;
uniform sampler2D coreTex;
uniform float bloom;

in vec2 uv;
out vec4 fragColor;

void main()
{
    vec3 center = texture(colorTex, uv).rgb;
    bool darkenBloom = bloom < 0.0;
    float amount = clamp(abs(bloom), 0.0, 100.0);
    if (amount <= 0.0001) {
        fragColor = vec4(center, 1.0);
        return;
    }

    vec3 glow = texture(glowTex, uv).rgb;
    vec3 core = texture(coreTex, uv).rgb;
    // Preserve meaningful adjustment across the complete 0..100 control.
    // The former exponential curve was already visually saturated near 50.
    float gain = pow(amount / 100.0, 0.72);

    // The multiscale texture is already an energy-preserving convolution of
    // neutral and spectral emitters. Add that radiance into the remaining
    // per-channel display headroom: colors glow over dark pixels, retain their
    // hue, and vanish continuously into an already-light field. This avoids
    // the hard normalized-tint border produced by the former screen/mix path.
    // `glow` is the additive reconstruction of several mip levels, so it is
    // intentionally normalized here before exposure rather than treated as a
    // unit-range color texture.
    // Inverse bloom is a diffuse dark glow, not a sharp negative copy of the
    // emitter. Excluding the full-resolution core removes black/white raster
    // stamps while retaining the same multiscale spread as normal Bloom.
    vec3 emission = darkenBloom
        ? glow * 0.055
        : core * 0.160 + glow * 0.075;
    // Remove the numerical low-energy floor accumulated by the mip pyramid.
    // Without this foot, dense impact strokes make every pixel an emitter at
    // maximum Bloom and wash the complete dark field into a flat color.
    float opticalFloor = mix(0.0020, 0.00075, gain);
    emission = max(emission - vec3(opticalFloor), vec3(0.0));
    float support = smoothstep(0.00045, 0.016,
                               max(emission.r, max(emission.g, emission.b)));
    // Preserve the authored low/mid response while giving the final quarter
    // of the slider a deliberately dramatic anime-flash ceiling.
    float exposure = 0.35 + 5.25 * gain + 2.15 * gain * gain
                   + 9.0 * pow(gain, 5.0);
    vec3 scattered = emission * exposure * support;
    vec3 bloomField = vec3(1.0) - exp(-scattered);
    // Dark bloom is intentionally neutral. Channel-wise subtraction of a
    // spectral pyramid created colored black raster rails at high aberration.
    float inverseEnergy = dot(scattered, vec3(0.2126, 0.7152, 0.0722));
    float inverseField = 1.0 - exp(-inverseEnergy);
    vec3 result = darkenBloom
        ? center * (1.0 - inverseField)
        : center + bloomField * (vec3(1.0) - center);
    fragColor = vec4(clamp(result, 0.0, 1.0), 1.0);
}
