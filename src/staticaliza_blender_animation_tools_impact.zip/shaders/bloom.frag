uniform sampler2D colorTex;
uniform sampler2D glowTex;
uniform sampler2D coreTex;
uniform float bloom;

in vec2 uv;
out vec4 fragColor;

void main()
{
    vec3 center = texture(colorTex, uv).rgb;
    float amount = clamp(bloom, 0.0, 100.0);
    if (amount <= 0.0001) {
        fragColor = vec4(center, 1.0);
        return;
    }

    vec3 glow = texture(glowTex, uv).rgb;
    vec3 core = texture(coreTex, uv).rgb;
    float wideEnergy = max(glow.r, max(glow.g, glow.b));
    float coreEnergy = max(core.r, max(core.g, core.b));
    // Preserve meaningful adjustment across the complete 0..100 control.
    // The former exponential curve was already visually saturated near 50.
    float gain = pow(amount / 100.0, 0.72);

    // The multiscale texture is already an energy-preserving convolution of
    // neutral and spectral emitters. Add that radiance into the remaining
    // per-channel display headroom: colors glow over dark pixels, retain their
    // hue, and vanish continuously into an already-light field. This avoids
    // the hard normalized-tint border produced by the former screen/mix path.
    // `glow` is the additive reconstruction of several mip levels, so it is
    // intentionally normalized here before exposure rather than treated as a
    // unit-range color texture.
    vec3 emission = core * 0.160 + glow * 0.075;
    // Remove the numerical low-energy floor accumulated by the mip pyramid.
    // Without this foot, dense impact strokes make every pixel an emitter at
    // maximum Bloom and wash the complete dark field into a flat color.
    float opticalFloor = mix(0.0020, 0.00075, gain);
    emission = max(emission - vec3(opticalFloor), vec3(0.0));
    float support = smoothstep(0.00045, 0.016,
                               max(emission.r, max(emission.g, emission.b)));
    float exposure = 0.35 + 5.25 * gain + 2.15 * gain * gain;
    vec3 scattered = emission * exposure * support;
    // Bloom is radiance added over the untouched sharp image. The emitter
    // isolation above prevents full-field wash while additive composition lets
    // the glow cross into genuinely dark colors instead of stopping at them.
    vec3 result = center + scattered;
    // A display-white pixel has no additive headroom, so colored radiance
    // would otherwise be invisible over white paper. A restrained chromatic
    // veil makes that overlap readable without affecting neutral-white bloom.
    float scatterMax = max(scattered.r, max(scattered.g, scattered.b));
    float scatterMin = min(scattered.r, min(scattered.g, scattered.b));
    float centerLuma = dot(center, vec3(0.2126, 0.7152, 0.0722));
    float veil = smoothstep(0.70, 0.98, centerLuma) *
                 smoothstep(0.006, 0.16, scatterMax - scatterMin) *
                 gain * 0.18;
    vec3 glowHue = scattered / max(scatterMax, 0.0001);
    result = mix(result, mix(center, glowHue, 0.70), veil);
    fragColor = vec4(clamp(result, 0.0, 1.0), 1.0);
}
