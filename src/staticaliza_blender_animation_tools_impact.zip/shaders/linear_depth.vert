in vec4 clipPosition;
in float linearDepth;
in float surfaceOwner;
out float vSurfaceOwner;
out float vLinearDepth;
uniform vec2 depthRange;
void main() {
 float depth = (linearDepth - depthRange.x) / max(depthRange.y-depthRange.x, 0.0001);
 gl_Position = vec4(clipPosition.xy, (depth*2.0-1.0)*clipPosition.w, clipPosition.w);
 vLinearDepth = linearDepth;
 vSurfaceOwner = surfaceOwner;
}
