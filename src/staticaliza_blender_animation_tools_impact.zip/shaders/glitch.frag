uniform sampler2D colorTex;
uniform sampler2D shapeMaskTex;
uniform float glitchKey;
uniform vec2 resolution;
uniform float glitch;
uniform float glitchSize;
uniform float glitchTime;
in vec2 uv;
out vec4 fragColor;

float sourceShapeInfluence(vec2 p)
{
    vec2 sourceShape = texture(shapeMaskTex,
        clamp(p, vec2(0.0), vec2(1.0))).rg;
    float influence = sourceShape.g > 0.0001
        ? clamp(sourceShape.r / sourceShape.g, 0.0, 1.0) : 1.0;
    return influence < 0.001 ? 0.0 : influence;
}

float blockHash(vec2 p) {
    vec3 q=fract(vec3(p.xyx)*vec3(.1031,.1030,.0973));
    q+=dot(q,q.yzx+33.33);return fract((q.x+q.y)*q.z);
}
vec2 glitchCoordinate(float layer,float amount,out float timing,out float drive) {
    vec2 pixel=uv*resolution;
    float scale=max(.1,resolution.y/1080.);
    float size=clamp((glitchSize-1.)/99.,0.,1.);
    float cellSize=mix(3.,64.,pow(size,.85))*scale;
    float seed=mix(117.,31.,layer);
    // Key identity changes packet placement even for adjacent short exposures.
    float keySeed=blockHash(vec2(glitchKey,197.))*4096.;
    float bandHeight=max(24.*scale,cellSize*4.7);
    float band=floor(pixel.y/bandHeight);
    float identity=blockHash(vec2(band,seed+29.));
    // Each fault has a stable anchor and a visual hierarchy: a hairline
    // precursor, one shorter scan tear, and occasional larger packet damage.
    // They share timing and alignment, not an independent square-cell grid.
    float clock=glitchTime*mix(13.,23.,identity)+blockHash(vec2(band,seed+211.));
    float epoch=floor(clock)+keySeed, phase=fract(clock);
    float envelope=smoothstep(0.,.09,phase)*(1.-smoothstep(.72,1.,phase));
    float packetActive=step(1.-mix(.22,.90,amount),blockHash(vec2(band+epoch*13.,seed+53.)));
    float saturation=smoothstep(.45,1.,amount);
    float burst=mix(envelope*packetActive,1.,saturation*.86);
    float precursor=smoothstep(0.,.035,phase)*(1.-smoothstep(.58,.96,phase))*packetActive;
    timing=blockHash(vec2(band+epoch*17.,seed));
    float lineY=(band+mix(.18,.40,identity))*bandHeight;
    float anchorX=mix(.12,.88,blockHash(vec2(band,seed+keySeed+41.)))*resolution.x;
    float reach=mix(mix(.13,.43,blockHash(vec2(band,seed+67.))),1.05,saturation)*resolution.x;
    float edge=max(.5,scale*.5);
    float thinWidth=max(.55*scale,scale*mix(.55,1.15,identity));
    float hairline=1.-smoothstep(thinWidth,thinWidth+edge,abs(pixel.y-lineY));
    // A sparse paired echo makes thin tears feel grouped, not like ruled paper.
    float echoY=lineY+scale*mix(3.,7.,identity);
    float echo=(1.-smoothstep(.45*scale,.45*scale+edge,abs(pixel.y-echoY)))*step(.65,identity)*.55;
    hairline=max(hairline,echo);
    float longGate=1.-smoothstep(reach,reach+2.*scale,abs(pixel.x-anchorX));
    float streakY=lineY+bandHeight*.17;
    float streakWidth=max(1.5*scale,scale*mix(1.5,4.,identity));
    float streak=(1.-smoothstep(streakWidth,streakWidth+edge,abs(pixel.y-streakY)));
    float shortReach=reach*mix(.18,.48,identity);
    float shortGate=1.-smoothstep(shortReach,shortReach+scale,abs(pixel.x-anchorX-reach*.28));
    float thinDamage=hairline*longGate*precursor;
    float streakDamage=streak*shortGate*burst;
    // Blocks sit at the tail of the same tear. Width and height vary
    // independently, with wide shallow rectangles favored over squares.
    vec2 blockCenter=vec2(anchorX+reach*.52,lineY+bandHeight*.46);
    vec2 blockRadius=vec2(cellSize*mix(1.4,7.5,identity),cellSize*mix(.35,1.3,blockHash(vec2(band,seed+91.))));
    vec2 blockEdge=1.-smoothstep(blockRadius,blockRadius+vec2(edge),abs(pixel-blockCenter));
    float blockDamage=blockEdge.x*blockEdge.y*step(.73,blockHash(vec2(band,seed+101.)))*burst;
    // Overlapping, independently placed faults, not a tiled pixel grid.
    float packetDamage=0.;
    vec2 packetShift=vec2(0.);
    for(int j=0;j<32;++j){
        if(j>=int(mix(7.,32.,saturation)))break;
        float id=float(j);
        float h=blockHash(vec2(band*17.+id,seed+epoch*31.));
        float h2=blockHash(vec2(id*37.+band,seed+epoch*19.+71.));
        vec2 center=vec2(h*resolution.x,(band+h2)*bandHeight);
        float radiusY=cellSize*mix(.7,3.1,h2);
        float radiusX=radiusY*mix(.8,3.5,h)*mix(1.,1.35,saturation);
        vec2 radius=vec2(radiusX,radiusY);
        vec2 coverage=1.-smoothstep(radius,radius+vec2(edge),abs(pixel-center));
        float coverageAmount=coverage.x*coverage.y*
            step(1.-mix(.2,.95,amount),blockHash(vec2(id+epoch*7.,band+seed)))*burst;
        if(coverageAmount>packetDamage){
            packetDamage=coverageAmount;
            timing=blockHash(vec2(id*71.+band*13.,seed+epoch*43.+209.));
            packetShift=vec2((h-.5)*resolution.x*.22,(h2-.5)*cellSize*7.);
        }
    }
    blockDamage=max(blockDamage,packetDamage);
    float damage=max(thinDamage,max(streakDamage,blockDamage));
    float power=pow(amount,1.35);
    drive=power*mix(mix(.035,.32,saturation),1.,damage);
    float wave=sin(pixel.y/(cellSize*7.1)+seed-glitchTime*5.1);
    float shear=power*resolution.x*((timing-.5)*(.035*burst+.32*thinDamage+.19*streakDamage+.20*blockDamage)+wave*.0012);
    float vertical=(blockHash(vec2(band+epoch*11.,seed+83.))-.5)*power*cellSize*1.2*blockDamage;
    vec2 sourcePixel=pixel+mix(vec2(shear,vertical),
        packetShift*power,packetDamage*(1.-thinDamage*.5));
    // Preserve the source detail inside displaced blocks. Sampling one
    // quantized color per cell created the unwanted kitchen-tile mosaic.
    return clamp(sourcePixel/resolution,vec2(0),vec2(1));
}

vec3 glitchLayer(vec3 original,float layer,float strength) {
    float amount=clamp(glitch,0.0,1.0)*sourceShapeInfluence(uv);
    if(amount<=0.0)return original;
    float timing,drive;
    vec2 p=glitchCoordinate(layer,amount,timing,drive);
    // Influence changes the damage field itself, including displacement,
    // packet activation and channel separation. Never fade a second shape.
    float sourceAmount=clamp(glitch,0.0,1.0)*sourceShapeInfluence(p);
    if(sourceAmount<amount) {
        amount=sourceAmount;
        if(amount<=0.0)return original;
        p=glitchCoordinate(layer,amount,timing,drive);
    }
    // Recomputing a reduced displacement can land on a different shape.
    if(sourceShapeInfluence(p)<=0.0)return original;
    vec3 displaced=texture(colorTex,p).rgb;
    // Displace the finished spectral image as a single RGB signal.
    // No palette tint or independent channel offsets: both preserve the
    // authored aberration gradient, including monochrome when disabled.
    return displaced;
}

void main()
{
    vec3 original=texture(colorTex,uv).rgb;
    // Packet identity belongs to the damaged image signal, not mesh coverage.
    // A rig silhouette must never switch distortion maps or restore a 3D plate.
    // Choose a signal family per broad scan group, never per square tile.
    float scale=max(.1,resolution.y/1080.);
    float size=clamp((glitchSize-1.)/99.,0.,1.);
    float cellSize=mix(3.,64.,pow(size,.85))*scale;
    float scanGroup=floor(uv.y*resolution.y/max(24.*scale,cellSize*4.7));
    float layer=step(.5,blockHash(vec2(scanGroup,113.)));
    fragColor=vec4(glitchLayer(original,layer,clamp(glitch,0.,1.)),1.);
}
