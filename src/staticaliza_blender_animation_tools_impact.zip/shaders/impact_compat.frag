uniform sampler2D subjectTex;
uniform sampler2D linearStrokeTex;
uniform float linearReady;
uniform sampler2D floorTex;
uniform sampler2D brushTex;
uniform sampler2D loadedBrushTex;
uniform sampler2D motionTex;
uniform sampler2D backgroundMotionTex;
uniform sampler2D backgroundFamilyTex;
uniform sampler2D radialSeedTex;
uniform sampler2D ownershipTex;
uniform sampler2D ownerBoundsTex;
uniform sampler2D ownerSurfaceTex;
uniform vec2 resolution;
uniform int mode;
uniform int layerOnly;
uniform int hybridMode;
uniform int radialEnabled;
uniform int ownerCount;
uniform float angle;
uniform vec2 focus;
uniform vec2 backgroundFocus;
uniform float strength;
uniform float lineThickness;
uniform vec2 subjectMotion;
uniform vec2 backgroundMotion;
uniform vec2 subjectAcceleration;
uniform vec2 backgroundAcceleration;
uniform float salt;
uniform float backgroundSalt;
uniform float backgroundFrame;
uniform float velocityScale;
uniform float motionCurveInfluence;
uniform float backgroundIntensity;
uniform float backgroundLayer;
uniform float backgroundPlaneDepth;
uniform int backgroundSubjectOnly;
uniform int backgroundSpace3D;
uniform float backgroundDepthInfluence;
uniform float backgroundMotionInfluence;
uniform float bandTransition;
uniform float radialThreshold;
uniform float radialSpiral;
uniform float contrast;
uniform float lightIntensity;
uniform vec4 flowSource;
uniform float haloSpread;
uniform vec4 subjectBounds;
uniform float subjectDrawingScale;
uniform vec4 backgroundBounds;
uniform vec4 backgroundAffineX;
uniform vec4 backgroundAffineY;

in vec2 uv;
out vec4 fragColor;

/*
 * The line image is synthesized in screen space.  Geometry contributes tone,
 * depth ownership, lighting and motion, but never acts as a hard drawing clip.
 * Analytic gesture trajectories sample a cached deterministic bristle atlas.
 * This replaces the old polar cells, hatch rows, shifted silhouettes, and
 * independently truncated procedural segments.
 */

float hash21(vec2 p)
{
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

float valueNoise(vec2 p, float seed)
{
    vec2 cell = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    vec2 s = vec2(seed * 0.071, seed * 0.113);
    float a = hash21(cell + s);
    float b = hash21(cell + vec2(1.0, 0.0) + s);
    float c = hash21(cell + vec2(0.0, 1.0) + s);
    float d = hash21(cell + vec2(1.0, 1.0) + s);
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

vec2 visibleObjectState(vec2 p)
{
    return texture(ownershipTex, clamp(p, vec2(0.0), vec2(1.0))).rg;
}

float sameVisibleObject(float a, float b)
{
    return step(0.5, a) * step(0.5, b) *
           (1.0 - step(0.25, abs(a - b)));
}

// Per-mesh coverage is measured before scene occlusion.
vec2 independentOwnerState(float ownerId, vec2 p)
{
    int index = clamp(int(floor(ownerId + 0.5)) - 1, 0, max(ownerCount - 1, 0));
    vec4 bounds = texelFetch(ownerBoundsTex, ivec2(index, 0), 0);
    vec4 tile = texelFetch(ownerBoundsTex, ivec2(index, 3), 0);
    vec2 local = (p - bounds.xy) / max(bounds.zw - bounds.xy, vec2(1.0e-8));
    if (any(lessThan(local, vec2(0.0))) || any(greaterThan(local, vec2(1.0))))
        return vec2(0.0, 1.0);
    return texture(ownerSurfaceTex, mix(tile.xy, tile.zw, local)).rg;
}
vec2 independentOwnerBackState(float ownerId, vec2 p)
{
    int index = clamp(int(floor(ownerId + 0.5)) - 1, 0, max(ownerCount - 1, 0));
    vec4 bounds = texelFetch(ownerBoundsTex, ivec2(index, 0), 0);
    vec4 tile = texelFetch(ownerBoundsTex, ivec2(index, 4), 0);
    vec2 local = (p - bounds.xy) / max(bounds.zw - bounds.xy, vec2(1.0e-8));
    if (any(lessThan(local, vec2(0.0))) || any(greaterThan(local, vec2(1.0))))
        return vec2(0.0, 1.0);
    return texture(ownerSurfaceTex, mix(tile.xy, tile.zw, local)).rg;
}


vec2 independentGroupState(float ownerId, vec2 p, bool rear)
{
    int index = clamp(int(floor(ownerId + 0.5)) - 1, 0, max(ownerCount - 1, 0));
    vec4 bounds = texelFetch(ownerBoundsTex, ivec2(index, 1), 0);
    vec4 tile = texelFetch(ownerBoundsTex, ivec2(index, rear ? 6 : 5), 0);
    vec2 local = (p - bounds.xy) / max(bounds.zw - bounds.xy, vec2(1.0e-8));
    if (any(lessThan(local, vec2(0.0))) || any(greaterThan(local, vec2(1.0))))
        return vec2(0.0, 1.0);
    vec2 state = texture(ownerSurfaceTex, mix(tile.xy, tile.zw, local)).rg;
    return vec2(state.x > 0.5 ? ownerId : 0.0, state.y);
}

vec4 spreadGroupMeta(float ownerId)
{
    int ownerIndex = clamp(
        int(floor(ownerId + 0.5)) - 1, 0, max(ownerCount - 1, 0));
    return texelFetch(ownerBoundsTex, ivec2(ownerIndex, 2), 0);
}

float sameSpreadGroup(float firstOwner, float secondOwner)
{
    if (ownerCount <= 0 || firstOwner < 0.5 || secondOwner < 0.5)
        return 0.0;
    vec4 firstMeta = spreadGroupMeta(firstOwner);
    vec4 secondMeta = spreadGroupMeta(secondOwner);
    return step(0.5, firstMeta.y) * step(0.5, secondMeta.y) *
        (1.0 - step(0.25, abs(firstMeta.y - secondMeta.y)));
}

float visibleObjectEdgeBand(vec2 p, float ownerId, vec2 familyFlow,
                            float familySeed)
{
    if (ownerId < 0.5) return 0.0;
    vec2 flow = normalize(familyFlow + vec2(1.0e-7));
    vec2 normal = vec2(-flow.y, flow.x);
    float phase = hash21(vec2(
        familySeed * 91.7 + salt * 0.031,
        familySeed * 37.3 + salt * 0.047));
    float transverseReach = mix(2.5, 7.5, phase);
    float longitudinalReach = mix(3.0, 10.0, 1.0 - phase);
    vec2 transverse = normal * transverseReach / resolution;
    vec2 longitudinal = flow * longitudinalReach / resolution;
    float acrossA = sameVisibleObject(
        ownerId, visibleObjectState(p + transverse).x);
    float acrossB = sameVisibleObject(
        ownerId, visibleObjectState(p - transverse).x);
    float alongA = sameVisibleObject(
        ownerId, visibleObjectState(p + longitudinal).x);
    float alongB = sameVisibleObject(
        ownerId, visibleObjectState(p - longitudinal).x);
    float sideEdge = 1.0 - min(acrossA, acrossB);
    float endEdge = 1.0 - min(alongA, alongB);
    float dryVariation = valueNoise(
        (p - vec2(0.5)) * vec2(13.0, 11.0) + familySeed,
        salt + 4621.0 + familySeed * 43.0);
    return clamp(max(sideEdge, endEdge * mix(0.28, 0.62, dryVariation)),
                 0.0, 1.0);
}

float exteriorPaperDirection(vec2 p, float ownerId, vec2 direction,
                             float nearReach, float farReach)
{
    vec2 stepUV = normalize(direction + vec2(1.0e-7)) /
        max(resolution, vec2(1.0));
    float nearOwner = visibleObjectState(p + stepUV * nearReach).x;
    float shoulderOwner = visibleObjectState(
        p + stepUV * mix(nearReach + 2.0, farReach, 0.46)).x;
    float farOwner = visibleObjectState(p + stepUV * farReach).x;
    float paperNear = 1.0 - step(0.5, nearOwner);
    float paperShoulder = 1.0 - step(0.5, shoulderOwner);
    float foreignNear = step(0.5, nearOwner) *
        (1.0 - sameVisibleObject(ownerId, nearOwner));
    float foreignShoulder = step(0.5, shoulderOwner) *
        (1.0 - sameVisibleObject(ownerId, shoulderOwner));
    float foreignFar = step(0.5, farOwner) *
        (1.0 - sameVisibleObject(ownerId, farOwner));
    return max(paperNear, paperShoulder * 0.72) *
        (1.0 - max(foreignNear, max(foreignShoulder, foreignFar)));
}

float visibleOwnerOuterEdgeBand(vec2 p, float ownerId, vec2 familyFlow,
                                float familySeed)
{
    if (ownerId < 0.5 ||
        sameVisibleObject(ownerId, visibleObjectState(p).x) < 0.5)
        return 0.0;
    vec2 flow = normalize(familyFlow + vec2(1.0e-7));
    vec2 normal = vec2(-flow.y, flow.x);
    float phase = hash21(vec2(
        familySeed * 109.7 + salt * 0.029,
        familySeed * 47.3 + salt * 0.053));
    float nearReach = mix(2.2, 5.2, phase);
    float farReach = mix(13.0, 23.0, 1.0 - phase);
    float sideA = exteriorPaperDirection(
        p, ownerId, normal, nearReach, farReach);
    float sideB = exteriorPaperDirection(
        p, ownerId, -normal, nearReach, farReach);
    float endA = exteriorPaperDirection(
        p, ownerId, flow, nearReach, farReach);
    float endB = exteriorPaperDirection(
        p, ownerId, -flow, nearReach, farReach);
    float dry = mix(0.72, 1.0, valueNoise(
        (p - vec2(0.5)) * vec2(17.0, 13.0) + familySeed,
        salt + 6673.0 + familySeed * 41.0));
    return clamp(max(max(sideA, sideB), max(endA, endB)) * dry, 0.0, 1.0);
}

void objectLayerVisibility(vec2 p, vec2 pixelObject, vec2 seedUV,
                           vec2 familyFlow,
                           float familySeed, float ownerTravelPixels,
                           out float frontVisibility,
                           out float rearVisibility)
{
    vec2 sourceObject = visibleObjectState(seedUV);
    float sourceExists = step(0.5, sourceObject.x);
    float pixelExists = step(0.5, pixelObject.x);
    float sameObject = sameVisibleObject(sourceObject.x, pixelObject.x);
    vec2 flow = normalize(familyFlow);
    vec2 normal = vec2(-flow.y, flow.x);
    float reachPixels = mix(2.2, 7.4,
        hash21(vec2(familySeed * 73.1, salt * 0.037 + 11.0)));
    float sideSign = hash21(
        vec2(familySeed * 101.3, salt * 0.041 + 17.0)) < 0.5 ? -1.0 : 1.0;
    float alongCarry = sameVisibleObject(sourceObject.x,
        visibleObjectState(p - flow * reachPixels / resolution).x);
    float sideCarry = sameVisibleObject(sourceObject.x,
        visibleObjectState(
            p + normal * sideSign * reachPixels * 0.72 / resolution).x);
    float irregularCarry = max(alongCarry, sideCarry * 0.78) *
        mix(0.58, 0.94, valueNoise(
            (p - vec2(0.5)) * vec2(9.7, 8.3) + familySeed,
            salt + 3251.0 + familySeed * 113.0));
    float depthTolerance = mix(0.0005, 0.0022,
        valueNoise(p * vec2(37.0, 31.0) + familySeed,
                   salt + 4517.0 + familySeed * 59.0));
    float sourceIsNearer = step(
        sourceObject.y, pixelObject.y + depthTolerance);
    float ownerEdge = visibleObjectEdgeBand(
        p, sourceObject.x, familyFlow, familySeed);
    float paperVisibility = 1.0 - pixelExists;
    float entryPixels = dot((p - seedUV) * resolution, flow);
    float ownerProgress = entryPixels / max(ownerTravelPixels, 8.0);
    float ownerWindow = smoothstep(-0.10, 0.025, ownerProgress) *
        (1.0 - smoothstep(1.03, 1.18, ownerProgress));
    vec2 pixelNormal = texture(subjectTex, p).ba * 2.0 - 1.0;
    float sideFacing = smoothstep(
        0.055, 0.52, dot(pixelNormal, flow));
    float dryFrontCarry = mix(0.025, 0.080, valueNoise(
        (p - vec2(0.5)) * vec2(17.0, 13.0) + familySeed,
        salt + 5099.0 + familySeed * 71.0));
    vec2 carry3UV = p + flow * 3.5 / resolution;
    vec2 carry8UV = p + flow * 8.5 / resolution;
    vec2 carry15UV = p + flow * 15.0 / resolution;
    vec2 carry3Normal = texture(subjectTex, carry3UV).ba * 2.0 - 1.0;
    vec2 carry8Normal = texture(subjectTex, carry8UV).ba * 2.0 - 1.0;
    vec2 carry15Normal = texture(subjectTex, carry15UV).ba * 2.0 - 1.0;
    float carry3 = sameVisibleObject(sourceObject.x,
        visibleObjectState(carry3UV).x) * smoothstep(
            0.055, 0.52, dot(carry3Normal, flow));
    float carry8 = sameVisibleObject(sourceObject.x,
        visibleObjectState(carry8UV).x) * smoothstep(
            0.055, 0.52, dot(carry8Normal, flow));
    float carry15 = sameVisibleObject(sourceObject.x,
        visibleObjectState(carry15UV).x) * smoothstep(
            0.055, 0.52, dot(carry15Normal, flow));
    float faceOverrun = max(carry3 * 0.62,
        max(carry8 * 0.34, carry15 * 0.14)) *
        mix(0.58, 1.0, irregularCarry);
    float sideSurfaceClaim = clamp(max(sideFacing, faceOverrun), 0.0, 1.0);
    float sameObjectSurface = sameObject * ownerWindow *
        mix(dryFrontCarry, 1.0, sideSurfaceClaim);
    float differentObjectContact = (1.0 - sameObject) * pixelExists *
        sourceIsNearer * irregularCarry * mix(0.004, 0.020, ownerEdge);
    float foreignEntry3 = sameVisibleObject(sourceObject.x,
        visibleObjectState(p - flow * 2.5 / resolution).x);
    float foreignEntry7 = sameVisibleObject(sourceObject.x,
        visibleObjectState(p - flow * 9.0 / resolution).x);
    float foreignOverrun = (1.0 - sameObject) * pixelExists *
        max(foreignEntry3 * 0.40, foreignEntry7 * 0.14) *
        mix(0.34, 0.72, irregularCarry);
    differentObjectContact = max(differentObjectContact, foreignOverrun);
    float unoccluded = max(
        paperVisibility, max(sameObjectSurface, differentObjectContact));
    frontVisibility = mix(1.0, unoccluded, sourceExists);
    float rearPaper = 1.0 - smoothstep(
        0.025, 0.64, max(texture(subjectTex, p).r, pixelExists));
    rearVisibility = mix(rearPaper, 1.0 - pixelExists, sourceExists);
}

float sourceMask(vec2 p)
{
    return max(texture(subjectTex, p).r, texture(floorTex, p).r);
}

float sourceCoverage(vec2 p)
{
    // Derivative-aware reconstruction of the binary geometry raster. The
    // transition exists only on pixels whose quad crosses a boundary, giving
    // sub-pixel coverage without additional texture reads or a blur pass.
    float center = sourceMask(p);
    float filterWidth = clamp(fwidth(center) * 0.62, 0.02, 0.62);
    return smoothstep(0.5 - filterWidth, 0.5 + filterWidth, center);
}

float internalSeamSupport(vec2 p)
{
    vec2 px = 1.0 / max(resolution, vec2(1.0));
    float horizontal = max(
        min(sourceMask(p - vec2(px.x * 3.0, 0.0)),
            sourceMask(p + vec2(px.x * 3.0, 0.0))),
        max(min(sourceMask(p - vec2(px.x * 7.0, 0.0)),
                sourceMask(p + vec2(px.x * 7.0, 0.0))),
            min(sourceMask(p - vec2(px.x * 12.0, 0.0)),
                sourceMask(p + vec2(px.x * 12.0, 0.0)))));
    float vertical = max(
        min(sourceMask(p - vec2(0.0, px.y * 3.0)),
            sourceMask(p + vec2(0.0, px.y * 3.0))),
        max(min(sourceMask(p - vec2(0.0, px.y * 7.0)),
                sourceMask(p + vec2(0.0, px.y * 7.0))),
            min(sourceMask(p - vec2(0.0, px.y * 12.0)),
                sourceMask(p + vec2(0.0, px.y * 12.0)))));
    vec2 diagonal = px * 8.0;
    float corners = max(
        min(sourceMask(p - diagonal), sourceMask(p + diagonal)),
        min(sourceMask(p - vec2(diagonal.x, -diagonal.y)),
            sourceMask(p + vec2(diagonal.x, -diagonal.y))));
    return smoothstep(0.08, 0.64, max(max(horizontal, vertical), corners));
}

float distinctOwnerPair(vec2 p, vec2 direction, float reachPixels)
{
    vec2 stepUV = normalize(direction + vec2(1.0e-7)) *
        reachPixels / max(resolution, vec2(1.0));
    float ownerA = visibleObjectState(p - stepUV).x;
    float ownerB = visibleObjectState(p + stepUV).x;
    return step(0.5, ownerA) * step(0.5, ownerB) *
        (1.0 - sameVisibleObject(ownerA, ownerB));
}

float seamDashFamily(vec2 pixel, vec2 direction, float spacing,
                     float familySeed)
{
    vec2 tangent = normalize(direction + vec2(1.0e-7));
    vec2 normal = vec2(-tangent.y, tangent.x);
    float along = dot(pixel, tangent);
    float across = dot(pixel, normal);
    float laneIndex = floor(across / spacing);
    float laneSeed = hash21(vec2(
        laneIndex * 0.173 + familySeed,
        salt * 0.019 + laneIndex * 0.071));
    float laneCenter = (laneIndex + 0.5 + (laneSeed - 0.5) * 0.34) * spacing;
    float lineDistance = abs(across - laneCenter);
    float lineWidth = mix(0.34, 0.72, laneSeed);
    float lineAA = max(0.48, fwidth(lineDistance) * 0.86);
    float line = 1.0 - smoothstep(
        lineWidth, lineWidth + lineAA, lineDistance);

    float packetLength = mix(13.0, 27.0, laneSeed);
    float shiftedAlong = along + laneSeed * packetLength;
    float packetIndex = floor(shiftedAlong / packetLength);
    float packetU = fract(shiftedAlong / packetLength);
    float packetSeed = hash21(vec2(
        laneIndex * 11.7 + familySeed * 3.1,
        packetIndex * 7.3 + salt * 0.031));
    float attack = smoothstep(
        mix(0.01, 0.13, packetSeed), mix(0.12, 0.25, packetSeed), packetU);
    float releaseStart = mix(0.48, 0.72, packetSeed);
    float release = 1.0 - smoothstep(
        releaseStart, mix(0.80, 0.98, packetSeed), packetU);
    float presence = step(0.32, packetSeed);
    float dryContact = mix(0.48, 1.0, valueNoise(
        vec2(along / 17.0, across / 9.0),
        salt + 6619.0 + familySeed * 71.0));
    return line * attack * release * presence * dryContact;
}

float contactHatchWeight(vec2 p)
{
    vec2 center=visibleObjectState(p);
    if(center.x<0.5)return 0.0;
    // A narrow, softly varying contact shade; this changes only the loading
    // of existing pencil marks, never their geometry or texture.
    float radius=mix(24.0,40.0,valueNoise(p*resolution/64.0,salt+9287.0));
    float weight=0.0;
    for(int axis=0;axis<8;axis++) {
        float theta=float(axis)*0.78539816339;
        vec2 direction=vec2(cos(theta),sin(theta));
        for(int ring=1;ring<=4;ring++) {
            float reach=float(ring)*radius*.25;
            vec2 neighbor=visibleObjectState(p+direction*reach/resolution);
            if(neighbor.x<0.5 || sameVisibleObject(center.x,neighbor.x)>0.5)continue;
            // Refine the first ownership transition rather than printing
            // constant-width bands at each probe radius.
            float lo=reach-radius*.25,hi=reach;
            for(int step=0;step<3;step++) {
                float mid=(lo+hi)*.5;
                vec2 q=visibleObjectState(p+direction*mid/resolution);
                if(q.x>=.5 && sameVisibleObject(center.x,q.x)<.5)hi=mid;else lo=mid;
            }
            float behind=smoothstep(-0.0001,0.0001,center.y-neighbor.y);
            float falloff=1.0-smoothstep(0.0,radius,hi);
            weight=max(weight,falloff*mix(0.88,1.0,behind));
            break;
        }
    }
    return weight;
}

float cohesiveCoverage(vec2 p)
{
    // Adjacent visible rig parts can leave a narrow zero-ownership lane in
    // the per-mesh capture. Fill only bilateral gaps; a true outer silhouette
    // has ownership on one side and remains open.
    return max(sourceCoverage(p), internalSeamSupport(p));
}

float sourceTone(vec2 p)
{
    vec4 subject = texture(subjectTex, p);
    vec4 floorData = texture(floorTex, p);
    float selected = step(floorData.r, subject.r);
    float tone = mix(floorData.g * floorData.r,
                     subject.g * subject.r, selected);
    float factor = 1.0 + clamp(contrast, 0.0, 1.0) * 3.0;
    return clamp((tone - 0.5) * factor + 0.5, 0.0, 1.0);
}

float keyLightField(vec2 p)
{
    vec4 subject = texture(subjectTex, p);
    vec4 floorData = texture(floorTex, p);
    float selected = step(floorData.r, subject.r);
    return clamp(mix(floorData.g, subject.g, selected), 0.0, 1.0);
}

vec2 sourceMaskAndKey(vec2 p)
{
    vec4 subject = texture(subjectTex, p);
    vec4 floorData = texture(floorTex, p);
    float selected = step(floorData.r, subject.r);
    return vec2(max(subject.r, floorData.r),
        clamp(mix(floorData.g, subject.g, selected), 0.0, 1.0));
}

vec2 seekOwnedCandidate(vec2 candidate, float familySeed)
{
    vec2 boundsSpan = max(subjectBounds.zw - subjectBounds.xy, vec2(1.0e-5));
    vec2 unit = clamp((candidate - subjectBounds.xy) / boundsSpan,
                      vec2(0.0), vec2(1.0));
    vec2 best = candidate;
    float bestScore = sourceMaskAndKey(candidate).x;
    for (int j = 1; j <= 4; ++j) {
        float fj = float(j);
        vec2 probeUnit = vec2(
            fract(unit.x + fj * 0.236067978 + familySeed * 0.017),
            clamp(unit.y + (hash21(vec2(familySeed * 71.0, fj * 19.0)) - 0.5) *
                0.035, 0.0, 1.0));
        vec2 probe = subjectBounds.xy + boundsSpan * probeUnit;
        float score = sourceMaskAndKey(probe).x;
        if (score > bestScore) {
            best = probe;
            bestScore = score;
        }
    }
    return best;
}

vec2 seekTargetOwnerCandidate(vec2 candidate, float targetOwner,
                              vec4 ownerBounds, float familySeed,
                              out float found)
{
    found = sameVisibleObject(
        targetOwner, visibleObjectState(candidate).x);
    if (found > 0.5) return candidate;
    vec2 span = max(ownerBounds.zw - ownerBounds.xy, vec2(1.0e-5));
    vec2 best = candidate;
    for (int j = 0; j < 8; ++j) {
        float fj = float(j);
        vec2 unit = vec2(
            fract(familySeed * 0.731 + fj * 0.618033989),
            fract(familySeed * 0.417 + fj * 0.381966011));
        vec2 probe = ownerBounds.xy + span * mix(vec2(0.06), vec2(0.94), unit);
        float matches = sameVisibleObject(
            targetOwner, visibleObjectState(probe).x);
        if (matches > 0.5) {
            best = probe;
            found = 1.0;
            break;
        }
    }
    return best;
}

float toneFromMaskAndKey(vec2 state)
{
    float factor = 1.0 + clamp(contrast, 0.0, 1.0) * 3.0;
    float tone = state.y * state.x;
    return clamp((tone - 0.5) * factor + 0.5, 0.0, 1.0);
}

// Most hero gestures should be loaded from the rear/shadow drawing mass. Two
// low-discrepancy candidates are compared in captured light space; a smaller
// minority keeps the original sample so the result remains asymmetric rather
// than collapsing into one uniformly dark launch edge.
vec4 shadowBiasedSeed(vec2 candidate, float selector,
                      out float role, out vec2 localNormal)
{
    vec2 boundsSpan = max(subjectBounds.zw - subjectBounds.xy, vec2(1.0e-5));
    vec2 candidateUnit = (candidate - subjectBounds.xy) / boundsSpan;
    vec2 alternate = subjectBounds.xy + boundsSpan * vec2(
        fract(candidateUnit.x + 0.381966011),
        clamp(candidateUnit.y + (selector - 0.5) * 0.055, 0.0, 1.0));
    vec4 subjectA = texture(subjectTex, candidate);
    vec4 floorA = texture(floorTex, candidate);
    vec4 subjectB = texture(subjectTex, alternate);
    vec4 floorB = texture(floorTex, alternate);
    float selectedA = step(floorA.r, subjectA.r);
    float selectedB = step(floorB.r, subjectB.r);
    vec2 normalA = mix(floorA.ba, subjectA.ba, selectedA) * 2.0 - 1.0;
    vec2 normalB = mix(floorB.ba, subjectB.ba, selectedB) * 2.0 - 1.0;
    vec2 stateA = vec2(max(subjectA.r, floorA.r),
        clamp(mix(floorA.g, subjectA.g, selectedA), 0.0, 1.0));
    vec2 stateB = vec2(max(subjectB.r, floorB.r),
        clamp(mix(floorB.g, subjectB.g, selectedB), 0.0, 1.0));
    float darknessA = 1.0 - toneFromMaskAndKey(stateA);
    float darknessB = 1.0 - toneFromMaskAndKey(stateB);
    float centeredRear = step(0.5, flowSource.w) *
        (1.0 - smoothstep(0.04, 0.42,
            length((flowSource.xy - vec2(0.5)) * 2.0))) *
        (1.0 - step(0.0, flowSource.z));
    float edgeA = smoothstep(0.02, 0.52, length(normalA));
    float edgeB = smoothstep(0.02, 0.52, length(normalB));
    float scoreA = stateA.x * mix(1.0, mix(0.24, 1.18, edgeA), centeredRear);
    float scoreB = stateB.x * mix(1.0, mix(0.24, 1.18, edgeB), centeredRear);
    float sameOwner = sameVisibleObject(
        visibleObjectState(candidate).x,
        visibleObjectState(alternate).x);
    float chooseB = step(0.18, selector) * step(scoreA, scoreB) * sameOwner;
    float totalA = subjectA.r + floorA.r;
    float totalB = subjectB.r + floorB.r;
    float roleA = totalA > 0.001 ? subjectA.r / totalA : 0.5;
    float roleB = totalB > 0.001 ? subjectB.r / totalB : 0.5;
    role = mix(roleA, roleB, chooseB);
    localNormal = mix(normalA, normalB, chooseB);
    return mix(vec4(candidate, stateA.x, 1.0),
               vec4(alternate, stateB.x, 1.0), chooseB);
}

vec4 shiftSeedTowardOwnerSide(vec4 seedData, vec2 flow, float sideSign,
                              float familySeed)
{
    vec2 seedUV = seedData.xy;
    vec4 shifted = seedData;
    float ownerId = visibleObjectState(seedUV).x;
    if (ownerId < 0.5) return shifted;
    vec2 sideDirection = normalize(flow + vec2(1.0e-7)) * sideSign;
    float projectedBoundsReach = dot(
        abs(sideDirection),
        (subjectBounds.zw - subjectBounds.xy) * resolution);
    float firstDistance = mix(1.5, 3.5,
        hash21(vec2(familySeed * 127.1 + 19.0, salt * 0.113)));
    float stride = max(3.0, projectedBoundsReach / 13.0) *
        mix(0.92, 1.08,
            hash21(vec2(familySeed * 191.7 + 43.0, salt * 0.071)));
    vec2 outsideUV = seedUV;
    float foundOutside = 0.0;
    for (int i = 0; i < 14; ++i) {
        float distancePixels = firstDistance + stride * float(i);
        vec2 probeUV = seedUV + sideDirection * distancePixels / resolution;
        float probeOwner = visibleObjectState(probeUV).x;
        if (sameVisibleObject(ownerId, probeOwner) < 0.5) {
            outsideUV = probeUV;
            foundOutside = 1.0;
            break;
        }
        vec2 state = sourceMaskAndKey(probeUV);
        shifted = vec4(probeUV, state.x, 1.0);
    }
    for (int i = 0; i < 4; ++i) {
        if (foundOutside < 0.5) break;
        vec2 probeUV = mix(shifted.xy, outsideUV, 0.5);
        float probeOwner = visibleObjectState(probeUV).x;
        if (sameVisibleObject(ownerId, probeOwner) > 0.5) {
            vec2 state = sourceMaskAndKey(probeUV);
            shifted = vec4(probeUV, state.x, 1.0);
        }
        else outsideUV = probeUV;
    }
    return shifted;
}

vec4 shiftSeedTowardTrailing(vec4 seedData, vec2 flow, float familySeed)
{
    return shiftSeedTowardOwnerSide(seedData, flow, 1.0, familySeed);
}

vec4 shiftSeedTowardSilhouette(vec4 seedData, float familySeed)
{
    vec2 subjectCenter = 0.5 * (subjectBounds.xy + subjectBounds.zw);
    vec2 aspect = vec2(resolution.x / max(resolution.y, 1.0), 1.0);
    vec2 radial = (seedData.xy - subjectCenter) * aspect;
    float radialLength = length(radial);
    radial = radialLength > 1.0e-5 ? radial / radialLength : vec2(1.0, 0.0);
    radial /= aspect;
    vec4 shifted = seedData;
    float firstDistance = mix(7.0, 15.0,
        hash21(vec2(familySeed * 157.1 + 23.0, salt * 0.097)));
    float stride = mix(14.0, 27.0,
        hash21(vec2(familySeed * 211.7 + 59.0, salt * 0.061)));
    for (int i = 0; i < 6; ++i) {
        vec2 probeUV = seedData.xy + radial *
            (firstDistance + stride * float(i)) / resolution;
        vec2 state = sourceMaskAndKey(probeUV);
        if (state.x <= 0.12) break;
        shifted = vec4(
            probeUV, state.x, 1.0 - toneFromMaskAndKey(state));
    }
    return shifted;
}

float stylizedKeyAt(vec2 p, float transitionWidth)
{
    float key = keyLightField(clamp(p, vec2(0.0), vec2(1.0)));
    // Broad and medium pressure variation bends the cel boundary like a dry
    // painted pass. It is deterministic per frame and deliberately excludes
    // pixel-frequency noise, so the light remains a coherent authored shape.
    float paintedOffset =
        (valueNoise((p - vec2(0.5)) * vec2(4.7, 4.1), salt + 1171.0) - 0.5) * 0.070 +
        (valueNoise((p - vec2(0.5)) * vec2(12.1, 10.7), salt + 1193.0) - 0.5) * 0.024;
    key = clamp(key + paintedOffset, 0.0, 1.0);
    float width = max(transitionWidth, 0.004);
    float mid = smoothstep(0.36 - width, 0.36 + width, key);
    float high = smoothstep(0.76 - width, 0.76 + width, key);
    return mid * 0.72 + high * 0.28;
}

vec2 sourceVelocity(vec2 p)
{
    vec4 subject = texture(subjectTex, p);
    vec4 floorData = texture(floorTex, p);
    float subjectRole = step(floorData.r, subject.r);
    vec2 roleVelocity = mix(
        backgroundMotion, texture(motionTex, p).rg, subjectRole);
    return roleVelocity;
}

vec2 backgroundVelocityAt(vec2 p)
{
    vec2 centered = p - vec2(0.5);
    vec2 affine = vec2(
        backgroundAffineX.x + backgroundAffineX.y * centered.x +
            backgroundAffineX.z * centered.y,
        backgroundAffineY.x + backgroundAffineY.y * centered.x +
            backgroundAffineY.z * centered.y);
    vec2 fitted = mix(
        backgroundMotion, affine,
        min(backgroundAffineX.w, backgroundAffineY.w));
    vec2 captured = texture(
        backgroundMotionTex, clamp(p, vec2(0.0), vec2(1.0))).rg;
    float environment = texture(
        floorTex, clamp(p, vec2(0.0), vec2(1.0))).r;
    return mix(fitted, captured, smoothstep(0.06, 0.72, environment));
}

vec2 sourceAcceleration(vec2 p)
{
    float role = smoothstep(0.04, 0.72, texture(subjectTex, p).r);
    vec2 local = texture(motionTex, p).ba;
    return mix(subjectAcceleration, local, role);
}

float perspectiveScaleAt(vec2 p)
{
    return 1.0;
}

float sourceRole(vec2 p)
{
    vec4 subject = texture(subjectTex, clamp(p, vec2(0.0), vec2(1.0)));
    vec4 floorData = texture(floorTex, clamp(p, vec2(0.0), vec2(1.0)));
    float total = subject.r + floorData.r;
    return total > 0.001 ? subject.r / total : 0.5;
}

vec2 sourceSurfaceNormalXY(vec2 p)
{
    vec4 subject = texture(subjectTex, clamp(p, vec2(0.0), vec2(1.0)));
    vec4 floorData = texture(floorTex, clamp(p, vec2(0.0), vec2(1.0)));
    vec2 encoded = subject.r >= floorData.r ? subject.ba : floorData.ba;
    return encoded * 2.0 - 1.0;
}

vec2 localOwnedSpan(vec2 seedUV, vec2 flow)
{
    float ownerId = visibleObjectState(seedUV).x;
    if (ownerId < 0.5 || ownerCount <= 0) return vec2(0.0);
    int ownerIndex = clamp(
        int(floor(ownerId + 0.5)) - 1, 0, ownerCount - 1);
    vec4 bounds = texelFetch(ownerBoundsTex, ivec2(ownerIndex, 0), 0);
    vec2 seedPixel = seedUV * resolution;
    vec2 minimumPixel = bounds.xy * resolution;
    vec2 maximumPixel = bounds.zw * resolution;
    vec2 direction = normalize(flow + vec2(1.0e-7));
    float positive = 1.0e7;
    float negative = 1.0e7;
    if (abs(direction.x) > 1.0e-5) {
        float positiveX = ((direction.x > 0.0
            ? maximumPixel.x : minimumPixel.x) - seedPixel.x) / direction.x;
        float negativeX = ((direction.x > 0.0
            ? minimumPixel.x : maximumPixel.x) - seedPixel.x) / -direction.x;
        positive = min(positive, max(0.0, positiveX));
        negative = min(negative, max(0.0, negativeX));
    }
    if (abs(direction.y) > 1.0e-5) {
        float positiveY = ((direction.y > 0.0
            ? maximumPixel.y : minimumPixel.y) - seedPixel.y) / direction.y;
        float negativeY = ((direction.y > 0.0
            ? minimumPixel.y : maximumPixel.y) - seedPixel.y) / -direction.y;
        positive = min(positive, max(0.0, positiveY));
        negative = min(negative, max(0.0, negativeY));
    }
    return vec2(
        negative < 1.0e6 ? negative : 0.0,
        positive < 1.0e6 ? positive : 0.0);
}

vec2 rotateVector(vec2 v, float radians);
vec2 safeDirection(vec2 value, vec2 fallback);
vec2 blendDirection(vec2 fromDirection, vec2 toDirection, float amount);

float radialTwirlOffset(float radius)
{
    if (abs(radialSpiral) <= 0.0001) return 0.0;
    vec2 focusPixel = focus * resolution;
    float reach = max(max(
        max(length(focusPixel), length(focusPixel - vec2(resolution.x, 0.0))),
        max(length(focusPixel - vec2(0.0, resolution.y)),
            length(focusPixel - resolution))), 1.0) * 1.02;
    float t = clamp(radius / reach, 0.0, 1.0);
    float smoothT = t * t * (3.0 - 2.0 * t);
    float envelope = smoothT * (0.18 + 0.82 * t);
    return radialSpiral * 3.35 * envelope;
}

vec2 radialUntwirlPoint(vec2 p)
{
    if ((mode != 1 && hybridMode == 0) ||
        abs(radialSpiral) <= 0.0001) return p;
    vec2 delta = (p - focus) * resolution;
    float turn = -radialTwirlOffset(length(delta));
    float c = cos(turn);
    float s = sin(turn);
    vec2 untwirled = vec2(
        c * delta.x - s * delta.y,
        s * delta.x + c * delta.y);
    return focus + untwirled / max(resolution, vec2(1.0));
}

float radialTwirlTangent(float radius)
{
    if (abs(radialSpiral) <= 0.0001) return 0.0;
    float sampleStep = 2.0;
    float derivative = (
        radialTwirlOffset(radius + sampleStep) -
        radialTwirlOffset(max(0.0, radius - sampleStep))) /
        (sampleStep * 2.0);
    return atan(radius * derivative, 1.0);
}

vec2 baseFlow(vec2 p)
{
    vec2 authored = vec2(cos(angle), sin(angle));
    if (mode != 1 && hybridMode == 0) return authored;

    vec2 delta = (p - focus) * resolution;
    float radius = length(delta);
    vec2 radial = radius > 1.5 ? delta / radius : authored;
    float coreBlend = smoothstep(8.0, 58.0, radius);
    radial = normalize(mix(authored, radial, coreBlend));
    if (mode != 1) {
        vec2 radialAxis = radius > 1.5 ? delta / radius : authored;
        if (dot(radialAxis, authored) < 0.0) radialAxis = -radialAxis;
        float interaction = smoothstep(28.0, 360.0, radius) * 0.34;
        vec2 hybridFlow = blendDirection(authored, radialAxis, interaction);
        return normalize(rotateVector(
            hybridFlow, radialTwirlTangent(radius) * interaction * 0.46));
    }
    float angularDrift = (valueNoise(p * vec2(3.1, 2.7), salt + 53.0) - 0.5) *
                         mix(0.18, 0.055, smoothstep(40.0, 380.0, radius));
    return normalize(rotateVector(
        radial, angularDrift + radialTwirlTangent(radius)));
}

float backgroundTunnelAuthority()
{
    // Both 3D cross-sections have actual forward depth, including at the
    // centered pin. Only 2D uses edge-dependent family suppression.
    return step(0.5, float(backgroundSpace3D));
}

float background2DFlipAmount()
{
    return step(0.5, -float(backgroundSpace3D));
}

vec2 backgroundAuthoredFlow();

vec2 backgroundFlatPaper(vec2 p)
{
    // Projection now belongs to the common 3D family generator. Do not
    // apply a second inverse sheet transform, especially to signed 2D Spread.
    return p;
}

float background2DEdgeLoad()
{
    float pinEdge = clamp(
        length((backgroundFocus - vec2(0.5)) * 2.0), 0.0, 1.0);
    return smoothstep(0.06, 0.94, pinEdge);
}

float backgroundDepthConvergence()
{
    // Zero terminates on a constant-radius cylindrical corridor; one
    // terminates at the authored pin. This changes geometry, never weight.
    return backgroundTunnelAuthority() *
        smoothstep(0.0, 1.0, clamp(backgroundDepthInfluence, 0.0, 1.0));
}

vec2 sharedSubjectGestureFlow()
{
    vec2 authored = safeDirection(baseFlow(vec2(0.5)), vec2(1.0, 0.0));
    float sourceScreen = length((flowSource.xy - vec2(0.5)) * 2.0);
    if (ownerCount > 0 && flowSource.w > 0.5 && sourceScreen > 0.04) {
        vec2 boundsCenter = 0.5 * (subjectBounds.xy + subjectBounds.zw);
        return safeDirection(boundsCenter - flowSource.xy, authored);
    }
    return authored;
}

vec2 backgroundAuthoredFlow()
{
    // Background direction belongs to the cyan pin. The former shared
    // subject fallback resolved through baseFlow() and therefore let the
    // magenta main-stroke pin rotate most background families.
    vec2 boundsCenter = 0.5 * (backgroundBounds.xy + backgroundBounds.zw);
    vec2 target = boundsCenter;
    vec2 centerFallback = safeDirection(
        (vec2(0.5) - backgroundFocus) * resolution, vec2(-1.0, 0.0));
    return safeDirection(
        (target - backgroundFocus) * resolution, centerFallback);
}

vec2 backgroundFocusPoint()
{
    // Background composition owns its cyan pin and remains independent from
    // the magenta subject-stroke direction/focus.
    return backgroundFocus;
}

float backgroundCorridorRadiusPx()
{
    float shortEdge = max(1.0, min(resolution.x, resolution.y));
    float depth = backgroundDepthConvergence();
    depth = depth * depth * (3.0 - 2.0 * depth);
    return shortEdge * mix(0.30, 0.0, depth);
}

vec2 backgroundPerspectiveTarget(vec2 anchor)
{
    vec2 focusPx = backgroundFocusPoint() * resolution;
    vec2 anchorPx = anchor * resolution;
    vec2 axis = backgroundAuthoredFlow();
    vec2 normal = vec2(-axis.y, axis.x);
    float lane = dot(anchorPx - focusPx, normal);
    float side = abs(lane) > 0.5 ? sign(lane) : 1.0;
    float aperture = backgroundCorridorRadiusPx();
    float targetLane = side * aperture;
    vec2 targetPx = focusPx + normal * targetLane;
    return targetPx / max(resolution, vec2(1.0));
}

vec2 backgroundPerspectiveFlow(vec2 anchor, vec2 fallback)
{
    vec2 target = backgroundPerspectiveTarget(anchor);
    vec2 authored = backgroundAuthoredFlow();
    vec2 targetFlow = safeDirection((target - anchor) * resolution, authored);
    if (dot(targetFlow, authored) < 0.0) targetFlow = -targetFlow;
    float convergence = backgroundDepthConvergence();
    return safeDirection(
        mix(authored, targetFlow, mix(0.10, 0.30, convergence)), authored);
}

float backgroundPerspectiveReachPx(vec2 anchor)
{
    float targetDistance = length(
        (backgroundPerspectiveTarget(anchor) - anchor) * resolution);
    float openBoundaryFloor = backgroundCorridorRadiusPx() * 0.62;
    return max(targetDistance, openBoundaryFloor);
}

float background2DRangeGradient(vec2 samplePoint, vec2 flow)
{
    vec2 focusPx = backgroundFocus * resolution;
    vec2 samplePx = samplePoint * resolution;
    float directedTravel = max(0.0, dot(samplePx - focusPx, flow));
    float pinEdge = clamp(length((backgroundFocus - vec2(0.5)) * 2.0), 0.0, 1.0);
    float reachPx = min(resolution.x, resolution.y) *
        mix(0.34, 0.92, smoothstep(0.08, 0.92, pinEdge));
    // Extend the gradient behind an edge-authored pin instead of imposing a
    // high coverage floor at the pin. The previous terminal max switched
    // broad packets on together, making stable clusters look as if they had
    // translated into one forward slab. A negative start progressively
    // reveals the existing, independently spaced families.
    float edgeSweep = smoothstep(0.48, 0.92, pinEdge);
    float gradientStart = mix(
        min(resolution.x, resolution.y) * 0.012,
        -min(resolution.x, resolution.y) * 0.075,
        edgeSweep);
    float radialReach = smoothstep(
        gradientStart, max(reachPx, 2.0), directedTravel);
    vec2 boundsCenter = 0.5 * (backgroundBounds.xy + backgroundBounds.zw);
    vec2 subjectSide = safeDirection(
        (boundsCenter - backgroundFocus) * resolution, -flow);
    float signedSide = dot(
        (samplePoint - backgroundFocus) * resolution, subjectSide);
    float feather = max(5.0, min(resolution.x, resolution.y) * 0.028);
    float terminal = smoothstep(-feather, feather, signedSide);
    return radialReach * terminal;
}

float background2DDepthGradient(vec2 samplePoint, vec2 flow)
{
    vec2 axis = safeDirection(flow, backgroundAuthoredFlow());
    float shortEdge = max(1.0, min(resolution.x, resolution.y));
    float signedTravel = dot(
        (samplePoint - backgroundFocus) * resolution, axis) / shortEdge;
    // Flip Spread changes path curvature, never pigment ordering.
    return smoothstep(-0.62, 0.62, signedTravel);
}

float background2DDepthScale(vec2 samplePoint, vec2 flow)
{
    float authority = (1.0 - backgroundTunnelAuthority()) *
        smoothstep(0.0, 1.0,
                   abs(clamp(backgroundDepthInfluence, -1.0, 1.0)));
    float gradient = background2DDepthGradient(samplePoint, flow);
    return mix(1.0, mix(0.58, 1.46, gradient), authority);
}

float background2DFrameReach(vec2 originPixels, vec2 direction)
{
    vec2 ray = safeDirection(direction, vec2(1.0, 0.0));
    vec2 limit = vec2(1.0e20);
    if (ray.x > 1.0e-5)
        limit.x = (resolution.x - originPixels.x) / ray.x;
    else if (ray.x < -1.0e-5)
        limit.x = -originPixels.x / ray.x;
    if (ray.y > 1.0e-5)
        limit.y = (resolution.y - originPixels.y) / ray.y;
    else if (ray.y < -1.0e-5)
        limit.y = -originPixels.y / ray.y;
    return max(1.0, min(limit.x, limit.y));
}

vec2 background2DPerspectiveFlow(vec2 anchor, vec2 authored)
{
    float signedDepth = (1.0 - backgroundTunnelAuthority()) *
        clamp(backgroundDepthInfluence, -1.0, 1.0);
    float spread = abs(signedDepth);
    spread = spread * spread * (3.0 - 2.0 * spread);
    vec2 axis = safeDirection(authored, backgroundAuthoredFlow());
    vec2 normal = vec2(-axis.y, axis.x);
    float shortEdge = max(1.0, min(resolution.x, resolution.y));
    float lane = dot((anchor-backgroundFocus)*resolution, normal);
    float normalizedLane = lane / sqrt(lane*lane + shortEdge*shortEdge*0.2116);
    // One signed transverse field across the entire frame. The previous
    // per-anchor undirected pin representative changed sign at edge pins,
    // leaving isolated graphite marks rotating against their neighbours.
    float response = spread * 1.05 / (1.0 + 0.55 * spread);
    float flipScale = mix(1.0, 0.62, background2DFlipAmount());
    return safeDirection(axis + normal * normalizedLane *
        sign(signedDepth) * response * flipScale, axis);
}

float smoothSpreadResponse(float value)
{
    float t = clamp(value, 0.0, 1.0);
    return t * t * (3.0 - 2.0 * t);
}

float handDrawnFanEnvelope(float pathT)
{
    float t = clamp(pathT, 0.0, 1.20);
    return t * (0.60 + 0.40 * t);
}

float handDrawnFanSlope(float pathT)
{
    float t = clamp(pathT, 0.0, 1.20);
    return 0.60 + 0.80 * t;
}

float subjectSurfaceWrapEnvelope(float pathT, float spreadResponse)
{
    float t = clamp(pathT, 0.0, 1.20);
    float bodyT = min(t, 1.0);
    float wrap = bodyT * bodyT * (2.0 - bodyT) + max(t - 1.0, 0.0);
    return wrap * mix(1.0, 0.28, clamp(spreadResponse, 0.0, 1.0));
}

float subjectSurfaceWrapSlope(float pathT, float spreadResponse)
{
    float t = clamp(pathT, 0.0, 1.20);
    float bodyT = min(t, 1.0);
    float slope = t <= 1.0
        ? bodyT * (4.0 - 3.0 * bodyT)
        : 1.0;
    return slope * mix(1.0, 0.28,
        clamp(spreadResponse, 0.0, 1.0));
}

float curveNormalDistance(float signedDistance, float centerlineSlope)
{
    return signedDistance * inversesqrt(
        1.0 + centerlineSlope * centerlineSlope);
}

float spreadArcLengthScale(float normalizedFanSlope)
{
    float slope = abs(normalizedFanSlope);
    return inversesqrt(1.0 + 1.05333333 * slope * slope);
}

vec2 background2DLegacyBowedPaperState(vec2 samplePoint, vec2 anchorPoint)
{
    if (background2DFlipAmount() <= 0.5) return vec2(0.0);
    float signedSpread = (1.0 - backgroundTunnelAuthority()) *
        clamp(backgroundDepthInfluence, -1.0, 1.0);
    float spread = (1.0 - backgroundTunnelAuthority()) *
        smoothSpreadResponse(abs(signedSpread) * 0.5);
    if (spread <= 0.0001) return vec2(0.0);

    // Endpoint-preserving cubic sheet from the accepted Flip render. Every
    // brush family consumes this shared state, including corner/edge pins.
    vec2 authored = safeDirection(
        backgroundAuthoredFlow(), vec2(1.0, 0.0));
    vec2 authoredNormal = vec2(-authored.y, authored.x);
    vec2 anchorRelative = (anchorPoint - backgroundFocus) * resolution;
    vec2 sampleRelative = (samplePoint - backgroundFocus) * resolution;
    float lanePixels = dot(anchorRelative, authoredNormal);
    float anchorAlong = dot(anchorRelative, authored);
    float sampleAlong = dot(sampleRelative, authored);
    float focusTravel = max(abs(anchorAlong), 1.0);
    float focusDenominator = anchorAlong < 0.0
        ? focusTravel : -focusTravel;
    float pathT = (sampleAlong - anchorAlong) / focusDenominator;

    float projectionAspect = abs(lanePixels) / focusTravel;
    float aspectSquared = projectionAspect * projectionAspect;
    float aspectFourth = aspectSquared * aspectSquared;
    float chordAuthority = aspectFourth / (aspectFourth + 256.0);
    float resolvedSpread = spread /
        (1.0 + 0.08 * aspectSquared);
    float requestedConvergence = abs(lanePixels) * resolvedSpread;
    float convergenceCap = mix(
        focusTravel * 1.18, requestedConvergence, chordAuthority);
    float convergence = min(requestedConvergence, convergenceCap);
    float convergenceSign = lanePixels < 0.0 ? -1.0 : 1.0;
    float destinationLane = lanePixels - convergenceSign * convergence;
    float bow = min(abs(lanePixels) * 0.32, focusTravel * 0.50) *
        resolvedSpread;
    float positiveControl = destinationLane + convergenceSign * bow;
    // Positive keeps the accepted [P0, C, P3, P3] sheet. For Negative, moving
    // both equal-area Bernstein control deviations to the launch end creates
    // the requested opposite-end bend, but its raw controls cross. Their
    // isotonic projection is their mean: [P0, M, M, P3]. It preserves the
    // integrated lane displacement while guaranteeing ordered controls, a
    // strong forward launch, and no outward foldback or zero-tangent stem.
    float controlReach = focusTravel * 0.78;
    float controlLane = lanePixels + clamp(
        positiveControl - lanePixels, -controlReach, controlReach);
    float negativeControl = clamp(
        0.5 * (controlLane + destinationLane),
        min(lanePixels, destinationLane),
        max(lanePixels, destinationLane));

    float curveT = clamp(pathT, 0.0, 1.0);
    float curveT2 = curveT * curveT;
    float curveT3 = curveT2 * curveT;
    float curveT4 = curveT3 * curveT;
    float curveT5 = curveT4 * curveT;
    float launchControl = signedSpread < 0.0
        ? negativeControl : controlLane;
    // Five-sixths of the cubic endpoint derivative preserves its integrated
    // centerline when promoted to this zero-acceleration quintic Hermite road.
    float launchDerivative = 2.5 * (launchControl - lanePixels);
    float terminalDerivative = signedSpread < 0.0
        ? 2.5 * (destinationLane - negativeControl) : 0.0;
    float h00 = 1.0 - 10.0 * curveT3 + 15.0 * curveT4 - 6.0 * curveT5;
    float h10 = curveT - 6.0 * curveT3 + 8.0 * curveT4 - 3.0 * curveT5;
    float h01 = 10.0 * curveT3 - 15.0 * curveT4 + 6.0 * curveT5;
    float h11 = -4.0 * curveT3 + 7.0 * curveT4 - 3.0 * curveT5;
    float expectedLane = h00 * lanePixels + h10 * launchDerivative +
        h01 * destinationLane + h11 * terminalDerivative;
    float dh00 = -30.0 * curveT2 + 60.0 * curveT3 - 30.0 * curveT4;
    float dh10 = 1.0 - 18.0 * curveT2 + 32.0 * curveT3 - 15.0 * curveT4;
    float dh01 = 30.0 * curveT2 - 60.0 * curveT3 + 30.0 * curveT4;
    float dh11 = -12.0 * curveT2 + 28.0 * curveT3 - 15.0 * curveT4;
    float laneDerivative = dh00 * lanePixels + dh10 * launchDerivative +
        dh01 * destinationLane + dh11 * terminalDerivative;
    if (pathT < 0.0) {
        expectedLane = lanePixels + launchDerivative * pathT;
        laneDerivative = launchDerivative;
    } else if (pathT > 1.0) {
        expectedLane = destinationLane +
            terminalDerivative * (pathT - 1.0);
        laneDerivative = terminalDerivative;
    }
    float chordT = clamp(pathT, 0.0, 1.0);
    float chordLane = mix(lanePixels, destinationLane, chordT);
    float chordDerivative = destinationLane - lanePixels;
    if (pathT < 0.0)
        chordLane = lanePixels + chordDerivative * pathT;
    else if (pathT > 1.0) {
        if (signedSpread < 0.0)
            chordLane = destinationLane +
                chordDerivative * (pathT - 1.0);
        else
            chordDerivative = 0.0;
    }
    expectedLane = mix(expectedLane, chordLane, chordAuthority);
    laneDerivative = mix(
        laneDerivative, chordDerivative, chordAuthority);
    float laneSlope = laneDerivative / focusDenominator;
    return vec2(
        expectedLane - lanePixels, laneSlope * chordAuthority);
}

vec2 background2DEndBendState(float pathT, float curveAtFar)
{
    // A single quadratic has one curvature sign. Flattening BOTH ends of
    // the former smootherstep necessarily introduced a second, opposite bend.
    // Continue with endpoint tangents outside the frame, never a hard clamp.
    float t = clamp(pathT, 0.0, 1.0);
    float bend = mix(t * (2.0 - t), t * t, curveAtFar);
    float slope = mix(2.0 * (1.0 - t), 2.0 * t, curveAtFar);
    return vec2(bend + (pathT - t) * slope, slope);
}

vec2 background2DBowedPaperState(vec2 samplePoint, vec2 anchorPoint)
{
    if (background2DFlipAmount() <= 0.5) return vec2(0.0);
    float signedSpread = (1.0 - backgroundTunnelAuthority()) *
        clamp(backgroundDepthInfluence, -1.0, 1.0);
    float spread = (1.0 - backgroundTunnelAuthority()) *
        smoothSpreadResponse(abs(signedSpread));
    if (spread <= 0.0001) return vec2(0.0);

    vec2 focusPx = backgroundFocusPoint() * resolution;
    vec2 depthAxis = safeDirection(
        backgroundAuthoredFlow(), vec2(1.0, 0.0));
    vec2 depthNormal = vec2(-depthAxis.y, depthAxis.x);
    vec2 familyFlow = background2DPerspectiveFlow(anchorPoint, depthAxis);
    float runway = max(
        background2DFrameReach(focusPx, familyFlow),
        background2DFrameReach(focusPx, -familyFlow));
    vec2 subjectCenterPx =
        0.5 * (backgroundBounds.xy + backgroundBounds.zw) * resolution;
    vec2 pinToSubject = safeDirection(
        subjectCenterPx - focusPx, depthAxis);
    float depthRunway = max(
        background2DFrameReach(focusPx, pinToSubject), 1.0);
    float corridor = max(2.0, min(resolution.x, resolution.y) * 0.04);
    vec2 sampleRelative = samplePoint * resolution - focusPx;
    vec2 anchorRelative = anchorPoint * resolution - focusPx;
    float sampleT = dot(sampleRelative, familyFlow) / runway;
    float anchorT = dot(anchorRelative, familyFlow) / runway;

    // One family owns one side and one bend amplitude. Signed row authority
    // moves negative curvature toward the far/bottom families and positive
    // curvature toward the near/top families without sample-lane feedback.
    float authoredLane = dot(anchorRelative, depthNormal);
    float familySide = authoredLane * inversesqrt(
        authoredLane * authoredLane + corridor * corridor);
    float familyDepth = clamp(
        dot(anchorRelative, pinToSubject) / depthRunway, 0.0, 1.0);
    float farRows = smoothstep(0.18, 0.88, familyDepth);
    float nearRows = 1.0 - smoothstep(0.05, 0.55, familyDepth);
    float rowAuthority = signedSpread < 0.0
        ? mix(0.02, 1.80, farRows)
        : mix(0.08, 1.35, nearRows);
    float curveAtFar = signedSpread < 0.0 ? 1.0 : 0.0;
    vec2 sampleBend = background2DEndBendState(sampleT, curveAtFar);
    vec2 anchorBend = background2DEndBendState(anchorT, curveAtFar);
    float bowReach = runway * spread * 0.065 * rowAuthority;
    float bendSign = sign(signedSpread);
    float sampleOffset = bendSign * familySide * bowReach * sampleBend.x;
    float anchorOffset = bendSign * familySide * bowReach * anchorBend.x;
    float laneSlope = bendSign * familySide * bowReach * sampleBend.y / runway;
    return vec2(sampleOffset - anchorOffset, laneSlope);
}


float background2DParabolicDistance(vec2 samplePoint, vec2 anchorPoint,
                                    float fallbackDistance)
{
    // Compatibility wrapper retained for focused source contracts. Geometry
    // paths use the full state so physical width follows the curve tangent.
    return fallbackDistance -
        background2DBowedPaperState(samplePoint, anchorPoint).x;
}

float background2DTerminalGate(vec2 samplePoint, vec2 anchorPoint)
{
    return 1.0;
}

float background2DArcLengthScale(vec2 anchorPoint)
{
    return 1.0;
#if 0
    if (background2DFlipAmount() <= 0.5) return 1.0;
    float signedSpread = (1.0 - backgroundTunnelAuthority()) *
        clamp(backgroundDepthInfluence, -1.0, 1.0);
    float spread = (1.0 - backgroundTunnelAuthority()) *
        smoothSpreadResponse(abs(signedSpread) * 0.5);
    if (spread <= 0.0001) return 1.0;
    vec2 authored = backgroundAuthoredFlow();
    vec2 normal = vec2(-authored.y, authored.x);
    vec2 relative = (anchorPoint - backgroundFocus) * resolution;
    float lane = dot(relative, normal);
    float travel = max(abs(dot(relative, authored)), 1.0);
    float convergence = min(abs(lane) * spread, travel * 1.18);
    float laneSign = lane < 0.0 ? -1.0 : 1.0;
    float destinationLane = lane - laneSign * convergence;
    float bow = min(abs(lane) * 0.32, travel * 0.50) * spread;
    float positiveControl = destinationLane + laneSign * bow;
    float chordControl = mix(lane, destinationLane, 0.45);
    float negativeControl = 2.0 * chordControl - positiveControl;
    float controlLane = mix(negativeControl, positiveControl,
        step(0.0, signedSpread));
    float launchSlope = 3.0 * (controlLane - lane) / travel;
    float middleSlope = 1.5 * (destinationLane - controlLane) / travel;
    float normalizedSlope = max(abs(launchSlope), abs(middleSlope));
    float meanSlopeSquared = normalizedSlope * normalizedSlope * 0.58;
    return clamp(inversesqrt(1.0 + meanSlopeSquared), 0.58, 1.0);
#endif
}

vec2 rotateVector(vec2 v, float radians)
{
    float c = cos(radians);
    float s = sin(radians);
    return vec2(c * v.x - s * v.y, s * v.x + c * v.y);
}

vec2 safeDirection(vec2 value, vec2 fallback)
{
    float magnitude = length(value);
    return magnitude > 1.0e-7
        ? value / magnitude : normalize(fallback + vec2(1.0e-7));
}

float subjectCenteredSourceAmount()
{
    vec2 subjectCenter = 0.5 * (subjectBounds.xy + subjectBounds.zw);
    float distanceFromSubject = length((flowSource.xy - subjectCenter) * 2.0);
    return step(0.5, flowSource.w) *
        (1.0 - smoothstep(0.04, 0.22, distanceFromSubject));
}

vec2 blendDirection(vec2 fromDirection, vec2 toDirection, float amount)
{
    vec2 fromUnit = safeDirection(fromDirection, vec2(1.0, 0.0));
    vec2 toUnit = safeDirection(toDirection, fromUnit);
    float fromAngle = atan(fromUnit.y, fromUnit.x);
    float toAngle = atan(toUnit.y, toUnit.x);
    float delta = atan(sin(toAngle - fromAngle), cos(toAngle - fromAngle));
    float blended = fromAngle + delta * clamp(amount, 0.0, 1.0);
    return vec2(cos(blended), sin(blended));
}

vec2 alignLineAxis(vec2 candidate, vec2 reference)
{
    vec2 aligned = safeDirection(candidate, reference);
    vec2 stable = safeDirection(reference, vec2(1.0, 0.0));
    return dot(aligned, stable) < 0.0 ? -aligned : aligned;
}

float castBehindAmount()
{
    return step(0.5, flowSource.w) * (1.0 - step(0.0, flowSource.z));
}

float ownerSideFrontField(vec2 p, vec2 authoredFlow)
{
    vec2 ownerState = visibleObjectState(p);
    if (ownerState.x < 0.5) return 0.0;
    vec2 sideAspect = vec2(
        resolution.x / max(resolution.y, 1.0), 1.0);
    vec2 sideRigCenter = 0.5 * (subjectBounds.xy + subjectBounds.zw);
    vec2 sideSourceDirection = (sideRigCenter - flowSource.xy) * sideAspect;
    vec2 flow = safeDirection(
        mix(authoredFlow, sideSourceDirection, step(0.5, flowSource.w)),
        authoredFlow);
    if (flowSource.w < 0.5 && dot(flow, authoredFlow) < 0.0)
        flow = -flow;
    vec2 normal = vec2(-flow.y, flow.x);
    float towardExit = 0.0;
    float towardEntry = 0.0;
    float exitAlive = 1.0;
    float entryAlive = 1.0;
    for (int i = 0; i < 8; ++i) {
        float distancePixels = 2.5 * pow(1.62, float(i));
        float exitSame = sameVisibleObject(ownerState.x,
            visibleObjectState(p + flow * distancePixels / resolution).x);
        float entrySame = sameVisibleObject(ownerState.x,
            visibleObjectState(p - flow * distancePixels / resolution).x);
        towardExit = mix(towardExit, distancePixels, exitAlive * exitSame);
        towardEntry = mix(towardEntry, distancePixels, entryAlive * entrySame);
        exitAlive *= exitSame;
        entryAlive *= entrySame;
    }
    float ownerDepth = towardExit + towardEntry + 2.5;
    float sideT = clamp(towardExit / max(ownerDepth, 2.5), 0.0, 1.0);
    vec2 pixel = (p - vec2(0.5)) * resolution;
    float across = dot(pixel, normal);
    float ownerPhase = hash21(vec2(
        ownerState.x * 0.173 + salt * 0.013,
        ownerState.x * 0.311 + salt * 0.021));
    float spacingA = mix(18.0, 29.0, ownerPhase);
    float coordA = (across + ownerPhase * spacingA) / spacingA;
    float laneA = floor(coordA);
    float laneSeedA = hash21(vec2(
        laneA + ownerState.x * 3.17, salt * 0.071 + 19.0));
    float distanceA = abs(fract(coordA) - 0.5) * spacingA;
    float widthA = mix(0.85, 3.10, laneSeedA);
    float aaA = max(fwidth(distanceA), 0.70);
    float bandA = 1.0 - smoothstep(widthA - aaA, widthA + aaA, distanceA);
    float reachA = mix(0.16, 0.40, hash21(vec2(
        laneA * 1.91 + 7.0, ownerState.x + salt * 0.043)));
    float bodyA = 1.0 - smoothstep(reachA, reachA + 0.13, sideT);
    float spacingB = mix(9.0, 16.0, 1.0 - ownerPhase);
    float coordB = (across + (0.31 + ownerPhase) * spacingB) / spacingB;
    float laneB = floor(coordB);
    float laneSeedB = hash21(vec2(
        laneB + ownerState.x * 5.73, salt * 0.097 + 31.0));
    float distanceB = abs(fract(coordB) - 0.5) * spacingB;
    float widthB = mix(0.42, 1.45, laneSeedB);
    float aaB = max(fwidth(distanceB), 0.62);
    float bandB = 1.0 - smoothstep(widthB - aaB, widthB + aaB, distanceB);
    float reachB = mix(0.11, 0.34, hash21(vec2(
        laneB * 2.37 + 13.0, ownerState.x + salt * 0.059)));
    float bodyB = 1.0 - smoothstep(reachB, reachB + 0.10, sideT);
    vec4 subject = texture(subjectTex, p);
    vec4 floorData = texture(floorTex, p);
    float selected = step(floorData.r, subject.r);
    float localKey = clamp(mix(floorData.g, subject.g, selected), 0.0, 1.0);
    float shadow = 1.0 - smoothstep(
        0.12, 0.88, clamp(lightIntensity, 0.0, 1.0) * localKey);
    float toneLoad = mix(0.22, 1.0, smoothstep(0.18, 0.82, shadow));
    float dryPressure = mix(0.72, 1.0, valueNoise(
        vec2(sideT * 5.3, ownerState.x * 0.19 + across * 0.004),
        salt + 4721.0));
    float strokes = 1.0 - (1.0 - bandA * bodyA) *
        (1.0 - bandB * bodyB * 0.72);
    float handBreak = smoothstep(0.20, 0.76, valueNoise(
        vec2(across * 0.018, sideT * 8.7 + ownerState.x * 0.31),
        salt + 4733.0));
    strokes *= mix(0.24, 1.0, handBreak);
    float connectedOccluder = 0.0;
    for (int probe = 0; probe < 3; ++probe) {
        float distancePixels = probe == 0 ? 6.0 : (probe == 1 ? 15.0 : 29.0);
        float probeOwner = visibleObjectState(
            p + flow * distancePixels / resolution).x;
        float foreignOwner = 1.0 - sameVisibleObject(
            ownerState.x, probeOwner);
        connectedOccluder = max(
            connectedOccluder,
            foreignOwner * sameSpreadGroup(ownerState.x, probeOwner));
    }
    return clamp(strokes * toneLoad * dryPressure *
        mix(0.42, 0.92, strength) * (1.0 - connectedOccluder), 0.0, 1.0);
}

vec2 aerodynamicSurfaceFlow(vec2 p, vec2 normalXY, vec2 fallback,
                            out float confidence, out vec2 directedFlow)
{
    vec2 boundedXY = normalXY;
    float xyLength = length(boundedXY);
    if (xyLength > 0.999) boundedXY *= 0.999 / xyLength;
    vec3 surfaceNormal = vec3(
        boundedXY, sqrt(max(0.0, 1.0 - dot(boundedXY, boundedXY))));
    float pointSource = step(0.5, flowSource.w);
    vec2 aspectScale = vec2(
        resolution.x / max(resolution.y, 1.0), 1.0);
    // Parallel camera-space rays, like window light. The pin selects a
    // hemisphere direction; it is not a point attractor inside the image.
    vec2 directionXY = (flowSource.xy - vec2(0.5)) * 2.0 * aspectScale;
    vec3 sourceRay = vec3(-directionXY, flowSource.z);
    vec2 toSource = -directionXY;
    vec3 authoredWind = vec3(flowSource.xy, 0.0);
    vec3 wind = normalize(mix(authoredWind, sourceRay, pointSource) +
                          vec3(1.0e-7));
    vec3 surfaceTrail = wind - surfaceNormal * dot(wind, surfaceNormal);
    float projectedLength = length(surfaceTrail.xy);
    vec2 pinFacing = safeDirection(toSource, fallback);
    vec2 subjectCenter = 0.5 * (subjectBounds.xy + subjectBounds.zw);
    vec2 silhouetteEscape = safeDirection(
        boundedXY, safeDirection((p - subjectCenter) * aspectScale, fallback));
    vec2 surfaceFan = safeDirection(
        silhouetteEscape * sign(flowSource.z + 1.0e-6), fallback);
    float centeredSource = pointSource *
        (1.0 - smoothstep(0.04, 0.42, length(directionXY)));
    vec2 depthFormAxis = alignLineAxis(silhouetteEscape, fallback);
    confidence = pointSource > 0.5
        ? smoothstep(0.008, 0.20, max(projectedLength, length(boundedXY)))
        : smoothstep(0.025, 0.34, projectedLength);
    // A front/back source has no screen-space tangent on a front-facing face.
    // Falling back to the pin vector makes every family collapse into a star.
    // The projected surface/silhouette direction preserves perspective and
    // emits from the visible form instead.
    directedFlow = safeDirection(
        surfaceTrail.xy,
        fallback * sign(flowSource.z + 1.0e-6));
    directedFlow = blendDirection(
        directedFlow, depthFormAxis,
        centeredSource * smoothstep(0.06, 0.72, length(boundedXY)) * 0.18);
    vec2 projected = alignLineAxis(directedFlow, fallback);
    if (pointSource < 0.5) return projected;
    if (centeredSource > 0.5) {
        return blendDirection(
            safeDirection(fallback, vec2(1.0, 0.0)),
            alignLineAxis(projected, fallback),
            smoothstep(0.08, 0.72, length(boundedXY)) * 0.22);
    }
    vec2 surfacePrior = blendDirection(
        alignLineAxis(pinFacing, projected), projected, 0.90);
    return surfacePrior;
}

vec2 hatchAerodynamicFlow(vec2 p, vec2 normalXY, vec2 fallback,
                          out float confidence)
{
    vec2 boundedXY = normalXY;
    float xyLength = length(boundedXY);
    if (xyLength > 0.999) boundedXY *= 0.999 / xyLength;
    vec3 surfaceNormal = vec3(
        boundedXY, sqrt(max(0.0, 1.0 - dot(boundedXY, boundedXY))));
    vec2 aspectScale = vec2(
        resolution.x / max(resolution.y, 1.0), 1.0);
    vec2 directionXY = (flowSource.xy - vec2(0.5)) * 2.0 * aspectScale;
    vec3 sourceRay = vec3(-directionXY, flowSource.z);
    vec3 wind = normalize(sourceRay + vec3(1.0e-7));
    vec3 surfaceTrail = wind - surfaceNormal * dot(wind, surfaceNormal);
    float projectedLength = length(surfaceTrail.xy);
    confidence = smoothstep(0.035, 0.30, projectedLength);
    vec2 projected = safeDirection(surfaceTrail.xy, fallback);
    if (dot(projected, fallback) < 0.0) projected = -projected;
    float maximumTurn = 0.61086524;
    float delta = atan(
        fallback.x * projected.y - fallback.y * projected.x,
        dot(fallback, projected));
    return rotateVector(
        safeDirection(fallback, vec2(1.0, 0.0)),
        clamp(delta, -maximumTurn, maximumTurn) * confidence);
}

float hemisphereStrokeScale(vec2 p, vec2 normalXY)
{
    if (flowSource.w < 0.5) return 1.0;
    vec2 boundedXY = normalXY;
    float xyLength = length(boundedXY);
    if (xyLength > 0.999) boundedXY *= 0.999 / xyLength;
    vec3 surfaceNormal = vec3(
        boundedXY, sqrt(max(0.0, 1.0 - dot(boundedXY, boundedXY))));
    vec2 aspectScale = vec2(
        resolution.x / max(resolution.y, 1.0), 1.0);
    vec2 directionXY = (flowSource.xy - vec2(0.5)) * 2.0 * aspectScale;
    vec3 sourceRay = normalize(vec3(-directionXY, flowSource.z) +
                               vec3(1.0e-7));
    float facing = dot(surfaceNormal, sourceRay);
    return mix(1.34, 0.76, smoothstep(-0.38, 0.48, facing));
}

float sketchOutlineField(vec2 p, float center, float seamSupport)
{
    vec2 px = 1.0 / max(resolution, vec2(1.0));
    float hand = valueNoise(
        (p - vec2(0.5)) * vec2(19.0, 16.0), salt + 2371.0);
    vec2 warp = vec2(
        valueNoise((p - vec2(0.5)) * vec2(11.0, 9.0), salt + 2381.0),
        valueNoise((p - vec2(0.5)) * vec2(9.0, 12.0), salt + 2393.0));
    float outlineThickness = pow(clamp(lineThickness, 0.0, 1.0), 0.72);
    vec2 q = p + (warp - vec2(0.5)) * px *
        mix(1.8, 4.8, outlineThickness);
    float radius = mix(0.65, 2.80, hand) *
        mix(0.45, 1.0, outlineThickness);
    // Correlated angular drift keeps the construction edge directional while
    // avoiding a mechanically uniform outline around separate faces.
    float angleDrift = (valueNoise(
        (p - vec2(0.5)) * vec2(6.7, 8.3), salt + 2411.0) - 0.5) * 0.34;
    float probeAngle = hand * 6.28318531 + angleDrift;
    vec2 probeDirection = vec2(cos(probeAngle), sin(probeAngle));
    float probeA = sourceCoverage(q + probeDirection * px * radius);
    float probeB = sourceCoverage(q - probeDirection * px * radius);
    float silhouette = max(
        smoothstep(0.10, 0.72,
            max(abs(center - probeA), abs(center - probeB))),
        smoothstep(0.018, 0.16, fwidth(center)));
    float seam = 0.0;
    float paper = valueNoise(
        (p - vec2(0.5)) * resolution * 0.075, salt + 2341.0);
    float pressure = mix(0.68, 1.0, hand) * mix(0.74, 1.0, paper);
    float outlineLift = smoothstep(
        0.38, 0.68, paper * 0.62 + hand * 0.38);
    // A contour is redrawn as short, separate construction actions. The
    // transverse band owns an independent phase, so adjacent bevel/seam lines
    // do not form nested continuous lenses or share one cut plane.
    vec2 actionAxis = vec2(cos(angle), sin(angle));
    vec2 actionNormal = vec2(-actionAxis.y, actionAxis.x);
    vec2 actionPixel = (p - vec2(0.5)) * resolution;
    float transverseBand = floor(dot(actionPixel, actionNormal) / 19.0);
    float actionPhase = valueNoise(
        vec2(transverseBand * 0.37, salt * 0.19), salt + 2459.0) * 23.0;
    float actionCoordinate =
        (dot(actionPixel, actionAxis) + actionPhase) / 27.0;
    float actionIndex = floor(actionCoordinate);
    float actionT = fract(actionCoordinate);
    float actionStart = mix(0.03, 0.22, valueNoise(
        vec2(actionIndex, transverseBand), salt + 2473.0));
    float actionEnd = mix(0.68, 0.98, valueNoise(
        vec2(actionIndex, transverseBand), salt + 2503.0));
    actionEnd = max(actionEnd, actionStart + 0.38);
    float finiteActionGate = smoothstep(
        actionStart, actionStart + 0.075, actionT) *
        (1.0 - smoothstep(actionEnd - 0.10, actionEnd, actionT));
    float primary = max(
        silhouette * 0.82 * mix(0.14, 1.0, outlineLift),
        seam * 0.72) * pressure * finiteActionGate;
    // A displaced duplicate contour reads as a smooth lens, not as another
    // finite pencil action, so the construction outline has one centerline.
    return clamp(primary * outlineThickness, 0.0, 1.0);
}

vec2 surfaceFormFlow(vec2 p, vec2 anchor, out float confidence)
{
    vec2 base = safeDirection(anchor, vec2(1.0, 0.0));
    float subjectCenter = texture(
        subjectTex, clamp(p, vec2(0.0), vec2(1.0))).r;
    if (subjectCenter < 0.08) {
        vec2 normalXY = sourceSurfaceNormalXY(p);
        float normalReach = length(normalXY);
        float ownership = smoothstep(0.18, 0.88, sourceMask(p));
        confidence = ownership * smoothstep(0.08, 0.82, normalReach);
        if (confidence <= 0.0001) return base;
        vec2 formTangent = safeDirection(
            vec2(-normalXY.y, normalXY.x), base);
        if (dot(formTangent, base) < 0.0) formTangent = -formTangent;
        float delta = atan(
            base.x * formTangent.y - base.y * formTangent.x,
            dot(base, formTangent));
        float limited = clamp(delta, -0.52359878, 0.52359878);
        return rotateVector(base, limited * confidence * 0.84);
    }
    vec2 sampleStep = base * 10.0 / resolution;
    vec2 normal0 = sourceSurfaceNormalXY(p);
    vec2 normalA = sourceSurfaceNormalXY(p - sampleStep);
    vec2 normalB = sourceSurfaceNormalXY(p + sampleStep);
    vec2 tangent0 = safeDirection(vec2(-normal0.y, normal0.x), base);
    vec2 tangentA = safeDirection(vec2(-normalA.y, normalA.x), base);
    vec2 tangentB = safeDirection(vec2(-normalB.y, normalB.x), base);
    float weight0 = smoothstep(0.18, 0.88, subjectCenter) *
                    smoothstep(0.08, 0.82, length(normal0));
    float weightA = smoothstep(0.10, 0.78, texture(
                        subjectTex, clamp(p - sampleStep,
                        vec2(0.0), vec2(1.0))).r) *
                    smoothstep(0.08, 0.82, length(normalA)) * 0.72;
    float weightB = smoothstep(0.10, 0.78, texture(
                        subjectTex, clamp(p + sampleStep,
                        vec2(0.0), vec2(1.0))).r) *
                    smoothstep(0.08, 0.82, length(normalB)) * 0.72;
    vec2 doubled =
        vec2(tangent0.x * tangent0.x - tangent0.y * tangent0.y,
             2.0 * tangent0.x * tangent0.y) * weight0 +
        vec2(tangentA.x * tangentA.x - tangentA.y * tangentA.y,
             2.0 * tangentA.x * tangentA.y) * weightA +
        vec2(tangentB.x * tangentB.x - tangentB.y * tangentB.y,
             2.0 * tangentB.x * tangentB.y) * weightB;
    float support = (weight0 + weightA + weightB) / 2.44;
    confidence = smoothstep(0.08, 0.76, support);
    if (confidence <= 0.0001) return base;
    float tangentAngle = 0.5 * atan(doubled.y, doubled.x);
    vec2 formTangent = vec2(cos(tangentAngle), sin(tangentAngle));
    if (dot(formTangent, base) < 0.0) formTangent = -formTangent;
    float delta = atan(
        base.x * formTangent.y - base.y * formTangent.x,
        dot(base, formTangent));
    float limited = clamp(delta, -0.34906585, 0.34906585);
    return rotateVector(base, limited * confidence * 0.68);
}

float paperTone(vec2 p)
{
    float mask = sourceMask(p);
    return mix(1.0, sourceTone(p), smoothstep(0.02, 0.55, mask));
}

float simpleSourceEnergy(vec2 p)
{
    float mask = sourceMask(p);
    float darkness = 1.0 - sourceTone(p);
    // A weak structural deposit keeps illuminated planes available to the
    // pencil process; it is still resolved by the transported material field.
    return mask * clamp(0.14 + darkness * 0.86, 0.0, 1.0);
}

vec2 toneGuidedFlow(vec2 p, out float structureEnergy)
{
    vec2 flow = baseFlow(p);
    float formConfidence;
    flow = surfaceFormFlow(p, flow, formConfidence);
    structureEnergy = formConfidence;

    // Correlated, low-frequency steering models hand correction without any
    // row IDs, polar sectors or visible periodic diagonal carrier.
    float bendA = valueNoise(p * vec2(5.1, 4.3), salt + 19.0) - 0.5;
    float bendB = valueNoise(p * vec2(17.7, 14.1), salt + 71.0) - 0.5;
    float bend = bendA * 0.22 + bendB * 0.06;
    return normalize(rotateVector(flow, bend * 0.42));
}

vec2 hatchPacketFlow(vec2 p, vec2 anchor, out float packetGate,
                     out float formEnergy)
{
    vec2 base = safeDirection(anchor, vec2(1.0, 0.0));
    // Form is sampled once per finite gesture inside hatchFamily. Keeping the
    // global hatch frame authored here prevents continuous normal-field bends
    // and removes the artificial lift seam at individual mesh faces.
    packetGate = 1.0;
    formEnergy = 0.0;
    return base;
}

vec2 fastFlow(vec2 p, vec2 imageTangent, float tangentWeight)
{
    vec2 flow = baseFlow(p);
    if (dot(imageTangent, flow) < 0.0) imageTangent = -imageTangent;
    flow = normalize(mix(flow, imageTangent, tangentWeight));
    float bendA = valueNoise(p * vec2(5.1, 4.3), salt + 19.0) - 0.5;
    float bendB = valueNoise(p * vec2(19.7, 16.1), salt + 71.0) - 0.5;
    float bendC = valueNoise(p * vec2(34.3, 27.7), salt + 137.0) - 0.5;
    return normalize(rotateVector(flow,
        bendA * 0.66 + bendB * 0.30 + bendC * 0.16));
}

float hash11(float p)
{
    return hash21(vec2(p, p * 1.61803398875));
}

float quinticEase(float t)
{
    t = clamp(t, 0.0, 1.0);
    return t * t * t * (t * (t * 6.0 - 15.0) + 10.0);
}

float pressureEnvelope(float t, float bluntness)
{
    float attack = quinticEase(t / mix(0.045, 0.16, bluntness));
    float release = quinticEase((1.0 - t) / mix(0.22, 0.08, bluntness));
    return attack * release;
}

float angleDifference(float a, float b)
{
    return atan(sin(a - b), cos(a - b));
}

float directionalEdgeEnergy(vec2 p, vec2 flow)
{
    vec2 pixel = p * resolution;
    vec2 px = 1.6 / resolution;
    float bgx = sourceMask(p + vec2(px.x, 0.0)) -
                sourceMask(p - vec2(px.x, 0.0));
    float bgy = sourceMask(p + vec2(0.0, px.y)) -
                sourceMask(p - vec2(0.0, px.y));
    vec2 baseGradient = vec2(bgx, bgy);
    vec2 edgeNormal = normalize(baseGradient + vec2(1e-6));
    // Displace in the actual silhouette normal.  The old flow-normal offset
    // was constant on many box edges, leaving a perfect stamped outline.
    float contourDrift =
        (valueNoise(pixel * 0.0107, salt + 311.0) - 0.5) * 10.5 +
        (valueNoise(pixel * 0.0311, salt + 419.0) - 0.5) * 3.4 +
        (valueNoise(pixel * 0.0793, salt + 443.0) - 0.5) * 3.8;
    p += edgeNormal * (contourDrift / resolution);
    // A hand-drawn construction edge does not keep one nib width around an
    // entire box face. Vary the sampling footprint slowly along the contour;
    // this changes deposited thickness without adding pixel-frequency teeth.
    float nibSpan = mix(1.15, 2.65, valueNoise(
        vec2(dot(pixel, vec2(-edgeNormal.y, edgeNormal.x)) * 0.021,
             salt * 0.17), salt + 461.0));
    vec2 nibPx = nibSpan / resolution;
    float gx = sourceMask(p + vec2(nibPx.x, 0.0)) -
               sourceMask(p - vec2(nibPx.x, 0.0));
    float gy = sourceMask(p + vec2(0.0, nibPx.y)) -
               sourceMask(p - vec2(0.0, nibPx.y));
    vec2 gradient = vec2(gx, gy);
    vec2 tangent = normalize(vec2(-gradient.y, gradient.x) + vec2(1e-6));
    float alignment = abs(dot(tangent, flow));
    // The captured silhouette is guidance, not a vector outline. Correlated
    // pressure fragments it into restrained sketch passes so hatching and
    // gesture bundles describe the subject instead of a perfect mesh border.
    float arc = dot(pixel, tangent);
    float contourMacro = valueNoise(
        vec2(arc * 0.014 + salt * 0.31,
             dot(pixel, edgeNormal) * 0.006), salt + 1201.0);
    float contourMeso = valueNoise(
        vec2(arc * 0.046 + salt * 0.17,
             dot(pixel, edgeNormal) * 0.019), salt + 1277.0);
    float pressure = smoothstep(
        0.24, 0.66, contourMacro * 0.68 + contourMeso * 0.32);
    float paperContact = valueNoise(pixel * 0.23, salt + 1327.0);
    // Correlated pencil lifts fragment long ruler-like runs. The floor is
    // deliberately non-zero so the limb remains readable as one construction
    // drawing rather than dissolving into unrelated dashes.
    float pencilLift = smoothstep(0.28, 0.66, valueNoise(
        vec2(arc * 0.031 + salt * 0.23,
             dot(pixel, edgeNormal) * 0.011), salt + 1361.0));
    float contourBand = floor(dot(pixel, edgeNormal) / 18.0);
    float actionPhase = valueNoise(
        vec2(contourBand * 0.41, salt * 0.13), salt + 1373.0) * 25.0;
    float actionCoordinate = (arc + actionPhase) / 31.0;
    float actionIndex = floor(actionCoordinate);
    float actionT = fract(actionCoordinate);
    float actionStart = mix(0.02, 0.20, valueNoise(
        vec2(actionIndex, contourBand), salt + 1379.0));
    float actionEnd = mix(0.66, 0.98, valueNoise(
        vec2(actionIndex, contourBand), salt + 1399.0));
    actionEnd = max(actionEnd, actionStart + 0.40);
    float finiteActionGate = smoothstep(
        actionStart, actionStart + 0.07, actionT) *
        (1.0 - smoothstep(actionEnd - 0.10, actionEnd, actionT));
    float deposited = mix(0.10, 1.0, pressure) *
                      mix(0.68, 1.06, paperContact) *
                      mix(0.40, 1.0, pencilLift) * finiteActionGate;
    return length(gradient) * deposited * mix(0.24, 1.0,
        smoothstep(0.24, 0.82, alignment));
}

float looseToneStructure(vec2 p)
{
    vec2 pixel = p * resolution;
    vec2 px = 1.5 / resolution;
    float axp = paperTone(p + vec2(px.x, 0.0));
    float axm = paperTone(p - vec2(px.x, 0.0));
    float ayp = paperTone(p + vec2(0.0, px.y));
    float aym = paperTone(p - vec2(0.0, px.y));
    vec2 firstGradient = vec2(axp - axm, ayp - aym);
    vec2 edgeNormal = normalize(firstGradient + vec2(1e-6));
    vec2 edgeTangent = vec2(-edgeNormal.y, edgeNormal.x);
    float arc = dot(pixel, edgeTangent);
    float drift =
        (valueNoise(vec2(arc * 0.012, salt * 0.19),
                    salt + 1381.0) - 0.5) * 6.2 +
        (valueNoise(vec2(arc * 0.043, salt * 0.31),
                    salt + 1409.0) - 0.5) * 2.1;
    vec2 q = p + edgeNormal * drift / resolution;
    float txp = paperTone(q + vec2(px.x, 0.0));
    float txm = paperTone(q - vec2(px.x, 0.0));
    float typ = paperTone(q + vec2(0.0, px.y));
    float tym = paperTone(q - vec2(0.0, px.y));
    vec2 gradient = vec2(txp - txm, typ - tym);
    float neighborhood = min(
        min(sourceMask(q + vec2(px.x, 0.0)),
            sourceMask(q - vec2(px.x, 0.0))),
        min(sourceMask(q + vec2(0.0, px.y)),
            sourceMask(q - vec2(0.0, px.y))));
    float energy = smoothstep(0.012, 0.19, length(gradient)) *
                   smoothstep(0.12, 0.72, neighborhood);
    float pressure = smoothstep(0.30, 0.70, valueNoise(
        vec2(arc * 0.027 + salt * 0.11,
             dot(pixel, edgeNormal) * 0.013), salt + 1433.0));
    return energy * mix(0.18, 1.0, pressure);
}

/*
 * A stroke is created before any graphite breakup is applied.  The center is
 * deliberately coherent and dark; correlated bristle channels only scrape the
 * outer half.  This prevents both the dotted texture and the shredded-rig look
 * produced by thresholding convolved scene pixels.
 */
float brushRibbonDeposit(float across, float halfWidth, float along01,
                         float alongPixelWidth, float familySeed)
{
    // Most candidate families cannot affect a given fragment. Reject their
    // conservative footprint before atlas lookup/noise work; the bound also
    // includes the two escaping companion filaments below.
    if (along01 < -0.09 || along01 > 1.09 ||
        abs(across) > halfWidth * 1.62 + 1.4) {
        return 0.0;
    }
    // Pressure changes once across the gesture; it must not turn the brush
    // silhouette into a repeating water-wave pattern.
    float widthDrift = mix(0.92, 1.07, valueNoise(vec2(
        clamp(along01, 0.0, 1.0) * 3.7,
        familySeed * 7.3), familySeed + 1847.0));
    // Impact strokes emit from a loaded base and exhaust into a pointed fiber
    // tail. The source stays near full width; only the travel end collapses.
    float travelT = clamp(along01, 0.0, 1.0);
    float pressureShape = mix(0.82, 1.0, quinticEase(travelT / 0.14));
    float tipSeed = hash11(familySeed * 71.3 + 19.0);
    // Thick strokes retain more of their loaded end. The taper is a shallow
    // pressure release, not a rocket spike or a sudden triangular cut.
    float sizeClass = smoothstep(3.0, 28.0, halfWidth);
    float terminalWidth = mix(0.48, 0.70, sizeClass) *
                          mix(0.985, 1.015, tipSeed);
    // Keep the body loaded until the terminal brush region. An earlier taper
    // exposes a long analytic triangle as Thickness grows; the final comb and
    // atlas deposition provide the visible release instead.
    float bodyTaper = mix(1.0, terminalWidth,
        quinticEase((travelT - 0.78) / 0.22));
    float fiberTerminal = mix(0.42, 0.68,
        hash11(familySeed * 97.1 + 43.0));
    float fiberTaper = mix(1.0, fiberTerminal,
        quinticEase((travelT - 0.82) / 0.18));
    // A loaded heel remains broad, but not a ruler-cut rectangle. This small
    // geometric pickup combines with the atlas pressure attack to round and
    // feather the emitter-side end without turning it into a symmetric spike.
    float heelPickup = mix(0.56, 1.0, quinticEase(travelT / 0.12));
    float bodyHalfWidth = max(
        halfWidth * widthDrift * pressureShape * bodyTaper * heelPickup, 0.38);
    float fiberHalfWidth = max(
        halfWidth * widthDrift * mix(0.86, 1.0, pressureShape) * fiberTaper,
        0.32);
    float bodyAcross = across / bodyHalfWidth;
    float fiberAcross = across / fiberHalfWidth;
    float variant = floor(hash11(familySeed * 83.17 + 17.0) * 4.0);
    float bodyLocal = bodyAcross * 0.5 + 0.5;
    float fiberLocal = fiberAcross * 0.5 + 0.5;
    // The brush does not end on one geometric plane. Continuous correlated
    // bristle lengths avoid both a flat cap and the visible stair-steps caused
    // by assigning an entire transverse strip one endpoint.
    // The center bristles travel beyond the outer bristles, but correlated
    // breakup keeps the pressure crown from becoming a clean vector point.
    float bodyTipBase = clamp(1.0 - abs(bodyAcross), 0.0, 1.0);
    float fiberTipBase = clamp(1.0 - abs(fiberAcross), 0.0, 1.0);
    float bodyTipCrown = sqrt(bodyTipBase) *
        mix(0.86, 1.0, bodyTipBase) * 0.018;
    float fiberTipCrown = sqrt(sqrt(fiberTipBase)) *
        mix(0.82, 1.0, fiberTipBase) * 0.055;
    float bodyEndShape = bodyTipCrown +
        (valueNoise(vec2(bodyLocal * 9.7, familySeed * 13.1),
                    familySeed + 1871.0) - 0.5) * 0.13 +
        (valueNoise(vec2(bodyLocal * 27.3, familySeed * 7.9),
                    familySeed + 1907.0) - 0.5) * 0.055;
    float fiberEndShape = fiberTipCrown +
        (valueNoise(vec2(fiberLocal * 13.1, familySeed * 17.3),
                    familySeed + 1933.0) - 0.5) * 0.18 +
        (valueNoise(vec2(fiberLocal * 35.7, familySeed * 5.7),
                    familySeed + 1973.0) - 0.5) * 0.07;
    float bodyEnd = 0.985 + bodyEndShape;
    float fiberEnd = 0.995 + fiberEndShape;
    float bodyStartShape =
        (valueNoise(vec2(bodyLocal * 8.1, familySeed * 11.7),
                    familySeed + 1997.0) - 0.5) * 0.060 +
        (valueNoise(vec2(bodyLocal * 24.9, familySeed * 6.3),
                    familySeed + 2011.0) - 0.5) * 0.025;
    float fiberStartShape =
        (valueNoise(vec2(fiberLocal * 12.7, familySeed * 15.1),
                    familySeed + 2039.0) - 0.5) * 0.085 +
        (valueNoise(vec2(fiberLocal * 33.1, familySeed * 4.9),
                    familySeed + 2063.0) - 0.5) * 0.035;
    float bodyStart = -0.008 + bodyStartShape;
    float fiberStart = -0.014 + fiberStartShape;
    vec2 bodyUV = vec2(
        clamp((along01 - bodyStart) /
              max(bodyEnd - bodyStart, 0.1), 0.0, 1.0),
        (variant + clamp(bodyLocal, 0.0, 1.0)) * 0.25
    );
    vec2 fiberUV = vec2(
        // Keep atlas contact into the analytic staggered end instead of
        // multiplying two coincident release envelopes.
        clamp((along01 - fiberStart) /
              max(fiberEnd - fiberStart, 0.1) * 0.88, 0.0, 1.0),
        (variant + clamp(fiberLocal, 0.0, 1.0)) * 0.25
    );
    // Derivative-sized transition bands replace binary step clipping. They
    // cover approximately one output pixel at any angle or preview scale.
    float alongAA = clamp(alongPixelWidth * 1.18, 0.0015, 0.08);
    float bodyAlong = smoothstep(bodyStart - alongAA,
                                 bodyStart + alongAA, along01) *
        (1.0 - smoothstep(bodyEnd - alongAA,
                          bodyEnd + alongAA, along01));
    float fiberAlong = smoothstep(fiberStart - alongAA,
                                  fiberStart + alongAA, along01) *
        (1.0 - smoothstep(fiberEnd - alongAA,
                          fiberEnd + alongAA, along01));
    // Across is measured in output pixels, so its reciprocal half-width is
    // the exact normalized coverage change per pixel. Avoid evaluating two
    // more derivatives for every candidate stroke.
    float acrossFootprint = 1.05;
    float bodyAA = clamp(acrossFootprint / bodyHalfWidth, 0.006, 0.32);
    float fiberAA = clamp(acrossFootprint / fiberHalfWidth, 0.006, 0.32);
    float bodyClip = 1.0 - smoothstep(1.04 - bodyAA,
                                      1.04 + bodyAA, abs(bodyAcross));
    float fiberClip = 1.0 - smoothstep(1.04 - fiberAA,
                                       1.04 + fiberAA, abs(fiberAcross));
    float body = texture(loadedBrushTex, bodyUV).r * bodyClip * bodyAlong;
    float fibers = texture(brushTex, fiberUV).g * fiberClip * fiberAlong;
    // Resolve the travel end into the atlas' independently staggered bristle
    // endpoints. The coherent body remains loaded through most of the swipe,
    // then yields to its comb instead of presenting one shared flat cutoff.
    float terminalBreakup = quinticEase((travelT - 0.84) / 0.16);
    body *= mix(1.0, 0.06 + fibers * 0.94, terminalBreakup);
    // Fibers may break through the loaded body, but cannot become a second
    // full-strength parallel silhouette. The transverse envelope keeps the
    // outermost bristles attached to the gesture and removes the dark rail /
    // halo visible around otherwise smooth strokes.
    float fiberEnvelope = 1.0 - smoothstep(
        0.58, 0.98, abs(fiberAcross));
    float fiberDeposit = fibers * fiberEnvelope * 0.72;
    float deposit = 1.0 - (1.0 - body) * (1.0 - fiberDeposit);

    float combDrift = (travelT - 0.5) * mix(-0.42, 0.42,
        hash11(familySeed * 107.9 + 53.0));
    float combTooth = valueNoise(vec2(
        bodyAcross * 5.4 + combDrift,
        familySeed * 11.3), familySeed + 2111.0);
    float combGap = smoothstep(0.48, 0.67, combTooth) *
        smoothstep(0.09, 0.22, travelT) *
        (1.0 - smoothstep(0.78, 0.96, travelT));
    deposit *= 1.0 - sizeClass * combGap * 0.68;

    // Some loaded marks preserve a single longitudinal scrape where one
    // charcoal filament lost contact.  Its start, end and transverse drift
    // belong to the parent gesture; this creates a white bristle opening
    // without the repeated parallel rails of an exposed multi-line stamp.
    float scrapePresence = step(mix(0.76, 0.28, sizeClass),
        hash11(familySeed * 113.7 + 61.0));
    float scrapeCenter = mix(-0.66, 0.66,
        hash11(familySeed * 127.1 + 73.0));
    float scrapeStart = mix(0.26, 0.50,
        hash11(familySeed * 149.3 + 83.0));
    float scrapeEnd = mix(0.56, 0.80,
        hash11(familySeed * 163.9 + 97.0));
    float scrapeDrift = (travelT - 0.5) *
        mix(-0.12, 0.12, hash11(familySeed * 173.3 + 101.0));
    float scrapeWidth = mix(0.022, 0.058,
        hash11(familySeed * 193.1 + 109.0));
    float scrapeLane = exp(-0.5 * pow(
        (bodyAcross - scrapeCenter - scrapeDrift) / scrapeWidth, 2.0));
    float scrapeWindow = smoothstep(scrapeStart - 0.055, scrapeStart, travelT) *
        (1.0 - smoothstep(scrapeEnd, scrapeEnd + 0.055, travelT));
    float scrapeDepth = mix(0.18, 0.44,
        hash11(familySeed * 211.7 + 127.0));
    deposit *= 1.0 - scrapePresence * scrapeLane * scrapeWindow * scrapeDepth;

    // Loaded mass strokes may carry one shorter secondary dry channel. It is
    // restricted to broad parents and staggered independently, so the result
    // reads as a scraped brush belly rather than parallel bacon stripes.
    float secondaryPresence = sizeClass * step(0.56,
        hash11(familySeed * 227.3 + 131.0));
    float secondaryCenter = mix(-0.72, 0.72,
        hash11(familySeed * 239.9 + 137.0));
    float secondaryStart = mix(0.34, 0.58,
        hash11(familySeed * 251.1 + 149.0));
    float secondaryEnd = mix(0.66, 0.88,
        hash11(familySeed * 263.7 + 157.0));
    float secondaryLane = exp(-0.5 * pow(
        (bodyAcross - secondaryCenter) / mix(0.025, 0.060,
            hash11(familySeed * 277.1 + 163.0)), 2.0));
    float secondaryWindow = smoothstep(
        secondaryStart - 0.04, secondaryStart, travelT) *
        (1.0 - smoothstep(secondaryEnd, secondaryEnd + 0.04, travelT));
    deposit *= 1.0 - secondaryPresence * secondaryLane *
               secondaryWindow * 0.42;
    float loadedCore = bodyClip * bodyAlong *
        (1.0 - smoothstep(0.48, 0.82, abs(bodyAcross)));
    deposit = max(deposit, loadedCore * sizeClass * 0.16);
    return deposit;
}

// A gesture family shares one macro trajectory and pressure event. Individual
// passes receive only correlated transverse/endpoint variation. This is the
// compact GPU equivalent of an animator repeating the same fast hand action;
// independent per-line randomness would read as procedural debris instead.
float companionSwipeDeposit(float across, float halfWidth, float along01,
                            float familySeed)
{
    if (along01 < -0.08 || along01 > 1.08 ||
        abs(across) > halfWidth * 1.35 + 1.2) return 0.0;
    float t = clamp(along01, 0.0, 1.0);
    float attackEnd = mix(0.018, 0.075,
        hash11(familySeed * 41.7 + 3.0));
    float releaseStart = mix(0.72, 0.91,
        hash11(familySeed * 59.3 + 11.0));
    float attackStagger = (valueNoise(
        vec2(across / max(halfWidth, 0.35) * 2.7, familySeed * 0.23),
        familySeed + 1583.0) - 0.5) * 0.11;
    // Both ends vary continuously across the brush bundle. A shared release
    // plane makes nested companions stop as visible density shelves.
    float releaseStagger = (valueNoise(
        vec2(across / max(halfWidth, 0.35) * 4.3, familySeed * 0.29),
        familySeed + 1597.0) - 0.5) * 0.16;
    releaseStart = clamp(releaseStart + releaseStagger * 0.34, 0.66, 0.94);
    float releaseEnd = max(releaseStart + 0.045, 1.035 + releaseStagger);
    float pressure = smoothstep(-0.025 + attackStagger,
                                attackEnd + attackStagger, along01) *
        (1.0 - smoothstep(releaseStart, releaseEnd, along01));
    float terminal = mix(0.78, 0.96,
        hash11(familySeed * 73.1 + 17.0));
    float taper = mix(1.0, terminal,
        quinticEase((t - 0.84) / 0.16));
    float handPressure = valueNoise(
        vec2(t * 4.7, familySeed * 0.31), familySeed + 1613.0);
    float width = max(0.34, halfWidth * taper *
        mix(0.88, 1.10, handPressure));
    float edgeAA = max(0.82, fwidth(across) * 0.78);
    float coverage = 1.0 - smoothstep(
        width, width + edgeAA, abs(across));
    float fiber = valueNoise(
        vec2(t * 11.0, across / max(width, 0.35) * 1.7),
        familySeed + 1667.0);
    float contact = mix(0.58, 1.0, fiber) *
        mix(0.76, 1.06, handPressure);
    return coverage * pressure * contact;
}

float filamentSwipeDeposit(float across, float halfWidth, float along01,
                           float familySeed)
{
    if (along01 < -0.10 || along01 > 1.12 ||
        abs(across) > halfWidth + 1.4) return 0.0;
    float t = clamp(along01, 0.0, 1.0);
    float attackStagger = (valueNoise(
        vec2(across / max(halfWidth, 0.30) * 3.1, familySeed * 0.19),
        familySeed + 1769.0) - 0.5) * 0.14;
    float attack = smoothstep(-0.035 + attackStagger,
                              0.055 + attackStagger, along01);
    float releaseStart = mix(0.74, 0.94,
        hash11(familySeed * 47.3 + 7.0));
    float releaseStagger = (valueNoise(
        vec2(across / max(halfWidth, 0.30) * 5.1, familySeed * 0.37),
        familySeed + 1777.0) - 0.5) * 0.18;
    releaseStart = clamp(releaseStart + releaseStagger * 0.30, 0.68, 0.96);
    float releaseEnd = max(releaseStart + 0.040, 1.055 + releaseStagger);
    float release = 1.0 - smoothstep(releaseStart, releaseEnd, along01);
    float widthDrift = mix(0.78, 1.18, valueNoise(
        vec2(t * 3.7, familySeed * 0.19), familySeed + 1789.0));
    float width = max(0.24, halfWidth * widthDrift);
    float edgeAA = max(0.84, fwidth(across) * 0.78);
    float coverage = 1.0 - smoothstep(width, width + edgeAA, abs(across));
    float contact = mix(0.34, 0.72, valueNoise(
        vec2(t * 8.3, across * 0.17), familySeed + 1823.0));
    return coverage * attack * release * contact;
}

float motionFamilyDeposit(float across, float halfWidth, float along01,
                          float alongPixelWidth, float familySeed)
{
    // One family can occupy a broad mass, but fragments beyond its farthest
    // possible escaping hair need no atlas lookup or child-stroke evaluation.
    if (along01 < -0.20 || along01 > 1.20 ||
        abs(across) > halfWidth * 3.22 + 1.8) return 0.0;
    float parent = brushRibbonDeposit(
        across, halfWidth, along01, alongPixelWidth, familySeed);
    float familyPresence = smoothstep(0.9, 4.5, halfWidth);
    float a = hash11(familySeed * 103.7 + 19.0);
    float b = hash11(familySeed * 139.1 + 31.0);
    float c = hash11(familySeed * 181.3 + 47.0);
    float passA = companionSwipeDeposit(
        across - halfWidth * mix(0.82, 1.48, a),
        halfWidth * mix(0.34, 0.62, b),
        (along01 + mix(0.012, 0.055, b)) / mix(0.92, 1.04, a),
        familySeed + 17.0);
    float passB = companionSwipeDeposit(
        across + halfWidth * mix(0.68, 1.34, b),
        halfWidth * mix(0.30, 0.56, c),
        (along01 - mix(0.008, 0.047, c)) / mix(0.90, 1.02, b),
        familySeed + 37.0);
    float passC = companionSwipeDeposit(
        across - halfWidth * mix(0.10, 0.48, c),
        halfWidth * mix(0.20, 0.42, a),
        (along01 + mix(0.025, 0.082, a)) / mix(0.84, 0.98, c),
        familySeed + 59.0);
    float miniA = companionSwipeDeposit(
        across - halfWidth * mix(0.92, 1.72, b),
        halfWidth * mix(0.14, 0.27, a) + 0.16,
        (along01 + mix(0.045, 0.14, c)) / mix(0.80, 1.02, a),
        familySeed + 67.0);
    float miniB = companionSwipeDeposit(
        across + halfWidth * mix(0.86, 1.64, c),
        halfWidth * mix(0.12, 0.24, b) + 0.14,
        (along01 - mix(0.018, 0.11, a)) / mix(0.83, 1.05, c),
        familySeed + 73.0);
    passA *= familyPresence * mix(0.52, 0.82, a);
    passB *= familyPresence * mix(0.46, 0.76, b);
    passC *= familyPresence * mix(0.34, 0.66, c);
    miniA *= familyPresence * mix(0.30, 0.54, b);
    miniB *= familyPresence * mix(0.26, 0.50, c);
    // Fine escaping hairs carry the same gesture beyond the loaded body.
    // Their offsets and endpoints are correlated with the parent, while their
    // weaker contact gives the microscopic directional detail of dry media.
    float hairA = filamentSwipeDeposit(
        across - halfWidth * mix(1.42, 2.18, b),
        halfWidth * mix(0.075, 0.16, c) + 0.12,
        (along01 + mix(0.04, 0.12, a)) / mix(0.84, 1.03, b),
        familySeed + 83.0);
    float hairB = filamentSwipeDeposit(
        across + halfWidth * mix(1.28, 2.42, c),
        halfWidth * mix(0.065, 0.14, a) + 0.10,
        (along01 - mix(0.01, 0.09, b)) / mix(0.88, 1.08, c),
        familySeed + 109.0);
    float hairC = filamentSwipeDeposit(
        across - halfWidth * mix(2.05, 3.10, a),
        halfWidth * mix(0.045, 0.10, b) + 0.08,
        (along01 + mix(0.08, 0.18, c)) / mix(0.78, 1.00, a),
        familySeed + 137.0);
    hairA *= familyPresence * mix(0.24, 0.46, a);
    hairB *= familyPresence * mix(0.18, 0.40, b);
    hairC *= familyPresence * mix(0.12, 0.30, c);
    float family = 1.0 - (1.0 - parent) * (1.0 - passA) *
                   (1.0 - passB) * (1.0 - passC) *
                   (1.0 - miniA) * (1.0 - miniB) *
                   (1.0 - hairA) * (1.0 - hairB) * (1.0 - hairC);

    return family;
}

vec2 ownerContourSpan(float ownerId, vec2 centerPixel, vec2 flow,
                      vec2 normal, float across, float alongRadius,
                      out float confidence)
{
    float firstAlong = alongRadius;
    float lastAlong = -alongRadius;
    float hits = 0.0;
    for (int probe = 0; probe < 17; ++probe) {
        float t = probe == 16 ? 0.5 : (float(probe) + 0.5) / 16.0;
        float sampleAlong = mix(-alongRadius, alongRadius, t);
        vec2 sampleUV = (centerPixel + normal * across +
                         flow * sampleAlong) / resolution;
        float same = sameVisibleObject(
            ownerId, independentOwnerState(ownerId, sampleUV).x);
        firstAlong = mix(firstAlong, min(firstAlong, sampleAlong), same);
        lastAlong = mix(lastAlong, max(lastAlong, sampleAlong), same);
        hits += same;
    }
    confidence = smoothstep(0.5, 2.0, hits);
    if (hits < 0.5) return vec2(0.0);
    float cell = (2.0 * alongRadius) / 16.0;
    // Coarse cells locate a span; binary refinement supplies the actual
    // curved boundary so percentage roots do not inherit ten-pixel shelves.
    float entryOutside = max(-alongRadius, firstAlong - cell);
    float entryInside = firstAlong;
    float exitInside = lastAlong;
    float exitOutside = min(alongRadius, lastAlong + cell);
    for (int refine = 0; refine < 5; ++refine) {
        float entryMid = 0.5 * (entryOutside + entryInside);
        float exitMid = 0.5 * (exitInside + exitOutside);
        float entryOwned = sameVisibleObject(ownerId, independentOwnerState(ownerId, 
            (centerPixel + normal * across + flow * entryMid) / resolution).x);
        float exitOwned = sameVisibleObject(ownerId, independentOwnerState(ownerId, 
            (centerPixel + normal * across + flow * exitMid) / resolution).x);
        entryInside = mix(entryInside, entryMid, entryOwned);
        entryOutside = mix(entryMid, entryOutside, entryOwned);
        exitInside = mix(exitInside, exitMid, exitOwned);
        exitOutside = mix(exitMid, exitOutside, exitOwned);
    }
    return vec2(0.5 * (entryOutside + entryInside),
                0.5 * (exitInside + exitOutside));
}

vec2 groupFrontState(float ownerId, vec2 p) { return independentGroupState(ownerId, p, false); }
vec2 groupContourSpan(float ownerId, vec2 centerPixel, vec2 flow,
                      vec2 normal, float across, float alongRadius,
                      out float confidence)
{
    float firstAlong = alongRadius;
    float lastAlong = -alongRadius;
    float hits = 0.0;
    for (int probe = 0; probe < 10; ++probe) {
        float t = (float(probe) + 0.5) / 10.0;
        float sampleAlong = mix(-alongRadius, alongRadius, t);
        vec2 sampleUV = (centerPixel + normal * across +
                         flow * sampleAlong) / resolution;
        float same = sameVisibleObject(
            ownerId, groupFrontState(ownerId, sampleUV).x);
        firstAlong = mix(firstAlong, min(firstAlong, sampleAlong), same);
        lastAlong = mix(lastAlong, max(lastAlong, sampleAlong), same);
        hits += same;
    }
    confidence = smoothstep(0.5, 2.0, hits);
    if (hits < 0.5) return vec2(0.0);
    float cell = (2.0 * alongRadius) / 10.0;
    // Coarse cells locate a span; binary refinement supplies the actual
    // curved boundary so percentage roots do not inherit ten-pixel shelves.
    float entryOutside = max(-alongRadius, firstAlong - cell);
    float entryInside = firstAlong;
    float exitInside = lastAlong;
    float exitOutside = min(alongRadius, lastAlong + cell);
    for (int refine = 0; refine < 4; ++refine) {
        float entryMid = 0.5 * (entryOutside + entryInside);
        float exitMid = 0.5 * (exitInside + exitOutside);
        float entryOwned = sameVisibleObject(ownerId, groupFrontState(ownerId, 
            (centerPixel + normal * across + flow * entryMid) / resolution).x);
        float exitOwned = sameVisibleObject(ownerId, groupFrontState(ownerId, 
            (centerPixel + normal * across + flow * exitMid) / resolution).x);
        entryInside = mix(entryInside, entryMid, entryOwned);
        entryOutside = mix(entryMid, entryOutside, entryOwned);
        exitInside = mix(exitInside, exitMid, exitOwned);
        exitOutside = mix(exitMid, exitOutside, exitOwned);
    }
    return vec2(0.5 * (entryOutside + entryInside),
                0.5 * (exitInside + exitOutside));
}

vec2 contourSpanSpline(vec2 beforeSpan, vec2 startSpan,
                       vec2 endSpan, vec2 afterSpan, float t)
{
    float t2 = t * t;
    float t3 = t2 * t;
    vec2 span = 0.5 * (
        2.0 * startSpan +
        (-beforeSpan + endSpan) * t +
        (2.0 * beforeSpan - 5.0 * startSpan +
         4.0 * endSpan - afterSpan) * t2 +
        (-beforeSpan + 3.0 * startSpan -
         3.0 * endSpan + afterSpan) * t3);
    return clamp(span, min(startSpan, endSpan), max(startSpan, endSpan));
}

vec2 ownerLaneContourSpan(vec2 lowOuterSpan, float lowOuterConfidence,
                          vec2 middleSpan, float middleConfidence,
                          vec2 highOuterSpan, float highOuterConfidence,
                          float laneOrder, out float confidence)
{
    float lowOuterValid = step(0.001, lowOuterConfidence);
    float highOuterValid = step(0.001, highOuterConfidence);
    lowOuterSpan = mix(middleSpan, lowOuterSpan, lowOuterValid);
    highOuterSpan = mix(middleSpan, highOuterSpan, highOuterValid);
    lowOuterConfidence = mix(
        middleConfidence, lowOuterConfidence, lowOuterValid);
    highOuterConfidence = mix(
        middleConfidence, highOuterConfidence, highOuterValid);

    float lane = clamp(laneOrder, -0.92, 0.92);
    if (lane < 0.0) {
        float t = (lane + 0.92) / 0.92;
        confidence = mix(lowOuterConfidence, middleConfidence, t);
        return contourSpanSpline(
            lowOuterSpan, lowOuterSpan, middleSpan, highOuterSpan, t);
    }
    float t = lane / 0.92;
    confidence = mix(middleConfidence, highOuterConfidence, t);
    return contourSpanSpline(
        lowOuterSpan, middleSpan, highOuterSpan, highOuterSpan, t);
}

void ownerSpreadGroup(int ownerIndex, vec4 ownerBounds,
                      out vec4 spreadBounds, out vec4 spreadMeta)
{
    vec4 connectedBounds = texelFetch(
        ownerBoundsTex, ivec2(ownerIndex, 1), 0);
    spreadMeta = texelFetch(ownerBoundsTex, ivec2(ownerIndex, 2), 0);
    float transition = smoothstep(0.04, 0.92, spreadMeta.x) *
        step(1.5, spreadMeta.z);
    spreadBounds = mix(ownerBounds, connectedBounds, transition);
}

// Find a stable interior planar crease, not a random point on a curved head.
// Depth is screen-affine, so a planar face has a constant along-lane slope.
float ownerTrailingFaceEntry(float ownerId, vec2 origin, vec2 flow, vec2 span)
{
    float depths[9];
    for (int i = 0; i < 9; ++i) {
        float t = mix(0.08, 0.92, float(i) / 8.0);
        vec2 state = independentOwnerState(ownerId,
            (origin + flow * mix(span.x, span.y, t)) / resolution);
        if (sameVisibleObject(ownerId, state.x) < 0.5) return span.x;
        depths[i] = state.y;
    }
    float totalTurn = 0.0;
    float turns[7];
    for (int i = 1; i < 8; ++i) {
        float turn = abs(depths[i+1] - 2.0*depths[i] + depths[i-1]);
        totalTurn += turn;
        turns[i-1] = turn;
    }
    float peakTurn = 0.0;
    float creaseIndex = 4.0;
    for (int i = 0; i < 6; ++i) {
        float pair = turns[i] + turns[i+1];
        if (pair > peakTurn) {
            peakTurn = pair;
            creaseIndex = (float(i+1)*turns[i] + float(i+2)*turns[i+1]) / max(pair, 1.0e-10);
        }
    }
    // Smooth curvature distributes its turn. Only a concentrated crease splits
    // the face; otherwise retain the complete rounded contour.
    if (peakTurn < 0.00002 || peakTurn < totalTurn * 0.78) return span.x;
    float t = mix(0.08, 0.92, creaseIndex / 8.0);
    if (t < 0.20 || t > 0.80) return span.x;
    return mix(span.x, span.y, t);
}

float ownerPickupVisibility(float ownerId, vec2 origin, vec2 flow,
                            float pickup, float exitAlong)
{
    float visibleSamples = 0.0;
    for (int sampleIndex = 0; sampleIndex < 6; ++sampleIndex) {
        float t = (float(sampleIndex) + 0.5) / 6.0;
        vec2 probe = (origin + flow * mix(pickup, exitAlong, t)) / resolution;
        visibleSamples += sameVisibleObject(ownerId, visibleObjectState(probe).x);
    }
    // Suppress isolated exposed pickups on contact slivers, not the exterior
    // wake. A substantial visible stretch remains valid behind another limb.
    return smoothstep(1.0, 3.0, visibleSamples);
}

void projectedOwnerFireField(vec2 p, vec2 authoredFlow,
                             out float frontInk, out float rearInk)
{
    frontInk = 0.0;
    rearInk = 0.0;
    if (ownerCount <= 0 || strength <= 0.0001 ||
        lineThickness <= 0.0001) return;

    vec2 pixel = p * resolution;
    vec2 pixelOwner = visibleObjectState(p);
    // Let the rear half of one owner family overlap the antialiased capture
    // edge before it becomes paper-only.  The owner/front half already uses
    // the same centerline; this small shared interval removes the white slit
    // without drawing a separate silhouette or extending toward the protected
    // camera-facing side.
    float paperAdmission = 1.0 - smoothstep(
        0.78, 0.998, sourceCoverage(p));
    float shortEdge = max(1.0, min(resolution.x, resolution.y));
    float strokePixelScale = clamp(shortEdge / 540.0, 0.56, 1.80);
    vec2 aspect = vec2(resolution.x / max(resolution.y, 1.0), 1.0);
    vec2 rigCenter = 0.5 * (subjectBounds.xy + subjectBounds.zw);
    vec2 rigSourceDirection = (rigCenter - flowSource.xy) * aspect;
    vec2 rigFlow = safeDirection(
        mix(authoredFlow, rigSourceDirection, step(0.5, flowSource.w)),
        authoredFlow);
    if (flowSource.w < 0.5 && dot(rigFlow, authoredFlow) < 0.0)
        rigFlow = -rigFlow;
    for (int ownerIndex = 0; ownerIndex < 64; ++ownerIndex) {
        if (ownerIndex >= ownerCount) continue;
        vec4 bounds = texelFetch(ownerBoundsTex, ivec2(ownerIndex, 0), 0);
        vec4 spreadBounds;
        vec4 spreadMeta;
        ownerSpreadGroup(ownerIndex, bounds, spreadBounds, spreadMeta);
        vec2 centerUV = 0.5 * (bounds.xy + bounds.zw);
        vec2 centerPixel = centerUV * resolution;
        float ownerId = float(ownerIndex + 1);
        vec2 halfPixel = max(
            0.5 * (bounds.zw - bounds.xy) * resolution, vec2(2.0));
        // The authored wind remains the low-motion composition axis. A moving
        // limb, however, owns its evaluated camera-relative wake: a punch arm
        // may arc and stretch without rotating the torso and legs with it.
        vec2 ownerVelocity = sourceVelocity(centerUV) -
            backgroundVelocityAt(centerUV);
        vec2 ownerAcceleration = sourceAcceleration(centerUV) -
            backgroundAcceleration;
        float ownerSpeed = length(ownerVelocity) /
            max(velocityScale, 1.0e-6);
        float ownerMotionResponse = smoothstep(0.025, 1.05, ownerSpeed) *
            clamp(motionCurveInfluence, 0.0, 1.0);
        vec2 ownerTrailAxis = safeDirection(-ownerVelocity, rigFlow);
        if (dot(ownerTrailAxis, rigFlow) < -0.72)
            ownerTrailAxis = -ownerTrailAxis;
        vec2 ownerFlow = blendDirection(
            rigFlow, ownerTrailAxis, ownerMotionResponse * 0.78);
        // The pink pin is constrained to a camera-facing hemisphere. Project
        // that 3D source direction onto this owner's captured center surface
        // before resolving its silhouette rows. The whole owner receives one
        // restrained form correction, so the wake follows a turned head or
        // limb without each fragment inventing a different radial direction.
        float centerOwned = sameVisibleObject(
            ownerId, visibleObjectState(centerUV).x);
        float ownerFormConfidence;
        vec2 ownerDirectedFlow;
        vec2 ownerSurfaceFlow = aerodynamicSurfaceFlow(
            centerUV, sourceSurfaceNormalXY(centerUV), ownerFlow,
            ownerFormConfidence, ownerDirectedFlow);
        ownerSurfaceFlow = alignLineAxis(ownerSurfaceFlow, ownerFlow);
        ownerFlow = blendDirection(
            ownerFlow, ownerSurfaceFlow,
            centerOwned * ownerFormConfidence * 0.36);
        vec2 ownerNormal = vec2(-ownerFlow.y, ownerFlow.x);
        vec2 groupFlow = rigFlow;
        vec2 groupNormal = vec2(-groupFlow.y, groupFlow.x);
        vec2 groupCenterPixel = 0.5 *
            (spreadBounds.xy + spreadBounds.zw) * resolution;
        vec2 groupHalfPixel = max(
            0.5 * (spreadBounds.zw - spreadBounds.xy) * resolution,
            vec2(2.0));
        float groupAcrossRadius = max(
            2.0, dot(abs(groupNormal), groupHalfPixel));
        float alongRadius = max(2.0, dot(abs(ownerFlow), halfPixel));
        float acrossRadius = max(2.0, dot(abs(ownerNormal), halfPixel));
        vec2 relative = pixel - centerPixel;
        float along = dot(relative, ownerFlow);
        float across = dot(relative, ownerNormal);

        float ownerSeed = hash11(
            float(ownerIndex + 1) * 83.17 + salt * 0.071 + 6203.0);
        float heel = mix(5.0, 13.0, ownerSeed) * strokePixelScale *
            mix(0.82, 1.18, lineThickness);
        float spreadResponse = smoothSpreadResponse(
            clamp(haloSpread, 0.0, 1.0));
        float release = shortEdge * mix(0.10, 0.31, strength) *
            mix(0.76, 1.26, ownerSeed) * 1.04;
        float ownerParallelMotion = length(ownerVelocity) > 1.0e-7
            ? abs(dot(normalize(ownerVelocity), ownerFlow)) : 0.0;
        float ownerLengthResponse = clamp(
            1.0 + ownerMotionResponse * min(ownerSpeed, 1.6) *
                mix(-0.16, 1.18, ownerParallelMotion),
            0.78, 2.65);
        release *= ownerLengthResponse;
        float pathLength = max(8.0, 2.0 * alongRadius + heel + release);
        float pathT = (along + alongRadius + heel) /
            pathLength;
        // The broad rejection must contain the curved centerline, not only
        // the unspread owner rectangle. Otherwise outer top/bottom lanes hit
        // an invisible horizontal wall and collapse into a sheared cap.
        float curvedAcrossGuard = release * 2.2 * spreadResponse +
            shortEdge * 0.12 * ownerMotionResponse;
        float counterPathT =
            (-along + alongRadius + heel) / pathLength;
        float outsidePrimaryPath = step(pathT, -0.80) + step(2.0, pathT);
        float outsideCounterPath =
            step(counterPathT, -0.80) + step(2.0, counterPathT);
        if ((outsidePrimaryPath > 0.5 &&
             (castBehindAmount() < 0.5 || outsideCounterPath > 0.5)) ||
            abs(across) > acrossRadius + 54.0 + curvedAcrossGuard) continue;

        float ownerRearStroke = 0.0;
        // Preserve stroke spacing when several meshes form one long group.
        // One connected group must not stretch twenty marks into giant slabs.
        float parentCount = clamp(ceil(2.0 * acrossRadius /
            max(shortEdge * 0.014, 2.0)), 20.0, 96.0);
        for (int family = 0; family < 286; ++family) {
            if (float(family) >= parentCount * 3.0 - 2.0) break;
            float familyF = float(family);
            float familySeed = hash21(vec2(
                float(ownerIndex + 1) * 17.71 + familyF * 3.17,
                salt * 0.037 + familyF * 29.11 + 6257.0));
            float primary = 1.0 - step(parentCount - 0.5, familyF);
            float gap = step(parentCount - 0.5, familyF) *
                (1.0 - step(2.0 * parentCount - 1.5, familyF));
            float familyIndex = primary > 0.5
                ? familyF : (gap > 0.5 ? familyF - parentCount : familyF - (2.0 * parentCount - 1.0));
            float laneU = primary > 0.5
                ? (familyIndex + 0.5) / parentCount
                : (gap > 0.5
                    ? (familyIndex + 1.0) / parentCount
                    : (familyIndex + 0.5) / (parentCount - 1.0));
            // Keep fiber coverage stratified across the owner. Excessive
            // transverse jitter clustered fibers into barcode shelves and
            // left entire rows blank; this retains hand offset without losing
            // the small strokes meant to occupy those gaps.
            float laneJitter = primary > 0.5
                ? 0.24 / parentCount : (gap > 0.5 ? 0.32 / parentCount : 0.40 / parentCount);
            laneU += (familySeed - 0.5) * laneJitter;
            laneU = clamp(laneU, 0.012, 0.988);
            float laneCenter = mix(-acrossRadius, acrossRadius, laneU);
            // Reject impossible lanes before sampling their contour. This
            // bounds the full curve, pressure crest, material and AA footprint.
            float probeDirection = 1.0;
            float maxWakeClock = max(0.0,
                (along * probeDirection + alongRadius) / max(release, 1.0));
            float maxBend = release * 0.75 * spreadResponse *
                maxWakeClock * maxWakeClock +
                shortEdge * 0.104 * ownerMotionResponse *
                maxWakeClock * maxWakeClock;
            float maxBrushReach = (2.0 * acrossRadius / parentCount) * 4.4 +
                3.0 * shortEdge / 1080.0;
            float maxSlope = (1.5 * spreadResponse +
                shortEdge * 0.208 * ownerMotionResponse / max(release, 1.0)) *
                maxWakeClock;
            maxBrushReach *= sqrt(1.0 + maxSlope * maxSlope);
            if (abs(across - laneCenter) > maxBend + maxBrushReach) continue;
            float familyContourConfidence;
            // Measure the emitting mesh at each lane, including curved heads.
            vec2 familyContourSpan = ownerContourSpan(
                ownerId, centerPixel, ownerFlow, ownerNormal,
                laneCenter, alongRadius, familyContourConfidence);
            if (familyContourConfidence <= 0.001) continue;
            float familyContourEntry = familyContourSpan.x;
            float familyContourExit = familyContourSpan.y;
            float familyContourRadius = max(
                2.0, 0.5 * (familyContourExit - familyContourEntry));
            float familyContourCenter =
                0.5 * (familyContourEntry + familyContourExit);
            // Pin polarity selects depth, not alternating 2D trail directions.
            // Every lane retains the same directed contour clock.
            float counterSide = 0.0;
            float familyDirection = mix(1.0, -1.0, counterSide);
            float directedAlong = familyContourCenter +
                (along - familyContourCenter) * familyDirection;
            float familyPathLength = max(
                8.0, 2.0 * familyContourRadius + heel + release);
            float familyPathT =
                (directedAlong - familyContourCenter +
                 familyContourRadius + heel) /
                familyPathLength;
            float familyEntryT = heel / familyPathLength;
            float familyExitT =
                (heel + 2.0 * familyContourRadius) / familyPathLength;
            float familyBodySpan = max(
                familyExitT - familyEntryT, 0.04);
            float familyWakeSpan = max(1.0 - familyExitT, 0.05);
            float familyWakeBaseT =
                (familyPathT - familyExitT) / familyWakeSpan;

            // Start each owner-local action at a stable fraction of that
            // owner's projected length. Fixed-pixel heels made a head begin
            // at a different relative depth than a torso or leg.
            float familyLaunchFraction = mix(0.43, 0.57, hash11(
                familySeed * 379.7 + familyF * 41.0 + 109.0));
            vec2 laneOriginPixel = centerPixel + ownerNormal * laneCenter;
            float faceEntry = ownerTrailingFaceEntry(
                ownerId, laneOriginPixel, ownerFlow, familyContourSpan);
            float facePickup = mix(faceEntry, familyContourExit, familyLaunchFraction);
            // A connected body's travel clock must not restart at each joint.
            // Share only the longitudinal extent; contour/depth stay owner-local.
            float groupAlongRadius = max(2.0, dot(abs(ownerFlow), groupHalfPixel));
            float connectedClock = smoothstep(0.04, 0.92, spreadMeta.x) *
                step(1.5, spreadMeta.z) *
                smoothstep(1.12, 1.75, groupAlongRadius / max(alongRadius, 1.0));
            float groupPickup = dot(groupCenterPixel - centerPixel, ownerFlow) +
                (familyLaunchFraction * 2.0 - 1.0) * groupAlongRadius;
            float sharedPickup = mix(facePickup, groupPickup, connectedClock);
            // Upstream parts cannot emit their own premature wake. Downstream
            // parts continue at their actual surface, not in the empty joint.
            if (sharedPickup >= familyContourExit - 0.5) continue;
            facePickup = max(familyContourEntry, sharedPickup);
            familyLaunchFraction = (facePickup - familyContourEntry) /
                max(familyContourExit - familyContourEntry, 1.0);
            float pickupVisibility = ownerPickupVisibility(
                ownerId, laneOriginPixel, ownerFlow, facePickup, familyContourExit);

            float laneOrder = clamp(dot(
                laneOriginPixel - groupCenterPixel, groupNormal) /
                max(groupAcrossRadius, 1.0), -1.0, 1.0);
            // Spread is an authored curved envelope, independent of motion.
            // Zero Spread remains straight unless measured motion bends it.
            float spreadBend = laneOrder * release * 0.62 * spreadResponse;
            float wakeReachScale = spreadArcLengthScale(
                laneOrder * 0.62 * spreadResponse);
            float wakePathT = max(familyWakeBaseT, 0.0);
            float compensatedWakeT =
                familyWakeBaseT / max(wakeReachScale, 0.54);
            float wakePixelSpan = max(
                familyPathLength * familyWakeSpan, 1.0);
            float ownerTurn = dot(ownerAcceleration, ownerNormal) /
                max(velocityScale, 1.0e-6);
            float motionBend = clamp(ownerTurn, -2.0, 2.0) *
                shortEdge * 0.052 * ownerMotionResponse;
            float fan = (spreadBend + motionBend) * wakePathT * wakePathT;
            float handDrift = 0.0;
            float fanSlope = 2.0 * (spreadBend + motionBend) *
                wakePathT / wakePixelSpan * familyDirection;
            float localAcross = curveNormalDistance(
                across - laneCenter - fan - handDrift, fanSlope);

            // Thickness is a fraction of lane spacing. A screen-pixel floor
            // used to exceed the entire spacing when the dragger was vertical,
            // merging narrow owners into slabs while horizontal rows had gaps.
            float lanePitch = 2.0 * acrossRadius / parentCount;
            float widthFraction = primary > 0.5
                ? mix(0.55, 1.05, familySeed)
                : (gap > 0.5 ? mix(0.32, 0.68, familySeed)
                              : mix(0.22, 0.42, familySeed));
            // Width/length clusters are geometry, not a replacement brush.
            float bundleSeed = hash11(floor(familyIndex / 3.0) * 61.7 +
                                      ownerSeed * 131.0);
            widthFraction *= mix(0.72, 1.35, bundleSeed);
            float bodyWidth = max(0.65 * shortEdge / 1080.0,
                lanePitch * widthFraction *
                mix(0.24, 1.32, pow(lineThickness, 0.72)));

            float lengthRank = fract(
                familyF * 0.61803398875 + ownerSeed * 1.713);
            float wakeLengthScale = primary > 0.5
                ? mix(0.14, 1.48, pow(lengthRank, 1.85))
                : (gap > 0.5
                    ? mix(0.08, 0.56, pow(lengthRank, 1.20))
                    : mix(0.06, 0.32, pow(lengthRank, 0.86)));
            // This is one stroke clock on both sides of the contour.  Its
            // loaded start lies inside the mesh; the same parameter then
            // crosses t=rootStartT at the silhouette and reaches t=1 at the
            // established exterior wake endpoint.  Correlating root depth
            // with family reach creates sparse deep peaks among shorter
            // pickups instead of a second, uniformly short boundary band.
            // One root for the complete gesture, measured along this mesh lane.
            float rootDepth = 1.0 - familyLaunchFraction;
            float frontToExitClock = familyBodySpan /
                max(familyWakeSpan * max(wakeReachScale, 0.54), 1.0e-4);
            // Compensate the existing brush's heel distance geometrically;
            // do not crop off its grain or replace its natural start shape.
            float desiredPickupT = -frontToExitClock * rootDepth;
            float rootOriginT = (desiredPickupT - 0.12 * wakeLengthScale) / 0.88;
            float familyWakeT = (compensatedWakeT - rootOriginT) /
                max(wakeLengthScale - rootOriginT, 0.08);
            float releaseStart = primary > 0.5
                ? mix(0.24, 0.52, hash11(familySeed * 401.3 + 131.0))
                : (gap > 0.5
                    ? mix(0.16, 0.40,
                        hash11(familySeed * 409.7 + 139.0))
                    : mix(0.08, 0.24,
                        hash11(familySeed * 419.9 + 149.0)));
            float releaseT = quinticEase(
                (familyWakeT - releaseStart) / max(1.0 - releaseStart, 0.08));
            // Selected wakes carry one asymmetric pressure crest. Different
            // rise/fall spans and a small side bias create mountain-like
            // loaded peaks instead of uniformly tapered ruler bars.
            float crestSeed = hash11(
                familySeed * 443.3 + familyF * 17.0 + 157.0);
            float crestCenter = mix(0.34, 0.78,
                hash11(familySeed * 457.9 + 163.0));
            float crestRise = mix(0.14, 0.28,
                hash11(familySeed * 467.3 + 173.0));
            float crestFall = mix(0.08, 0.20,
                hash11(familySeed * 479.9 + 181.0));
            float crestOffset = familyWakeT - crestCenter;
            float crestProfile = max(0.0, 1.0 - abs(crestOffset) /
                mix(crestRise, crestFall, step(0.0, crestOffset)));
            crestProfile *= mix(0.72, 1.0, valueNoise(vec2(
                familyWakeT * 11.0, familySeed * 3.7),
                familySeed + 2819.0));
            float crestPresence = step(0.38, crestSeed);
            float crestAmount = primary > 0.5
                ? mix(0.14, 0.34, crestSeed)
                : (gap > 0.5
                    ? mix(0.10, 0.28, crestSeed)
                    : mix(0.06, 0.18, crestSeed));
            float wakeWidth = bodyWidth * mix(
                primary > 0.5 ? 0.94 : (gap > 0.5 ? 0.86 : 0.78),
                primary > 0.5 ? 0.44 : (gap > 0.5 ? 0.32 : 0.22),
                releaseT);
            wakeWidth *= 1.0 + crestPresence * crestProfile * crestAmount;
            float crestSide = mix(-1.0, 1.0,
                step(0.5, hash11(familySeed * 487.1 + 191.0)));
            float rearAcross = localAcross - crestSide * bodyWidth *
                crestPresence * crestProfile * 0.28;
            float rearShape = brushRibbonDeposit(
                rearAcross, max(wakeWidth, 0.55), familyWakeT,
                0.82 / max(release * wakeLengthScale, 1.0),
                familySeed + familyF * 101.0 + 6337.0);
            float rearPresence = 1.0;
            float rearLoad = primary > 0.5
                ? mix(0.34, 0.56, familySeed)
                : (gap > 0.5
                    ? mix(0.22, 0.40, familySeed)
                    : mix(0.14, 0.26, familySeed));
            // Carry this lane's own surface depth along its release, then
            // compare with the scene. Never borrow the nearest OTHER mesh's
            // depth at an occluded root or classify every wake as foreground.
            float depthAlong = clamp(along, familyContourEntry + 1.0, familyContourExit - 1.0);
            vec2 depthUV = (centerPixel + ownerNormal * laneCenter +
                            ownerFlow * depthAlong) / resolution;
            vec2 laneState = independentOwnerState(ownerId, depthUV);
            float sameOwner = sameVisibleObject(ownerId, pixelOwner.x);
            vec2 rearState = independentOwnerBackState(ownerId, depthUV);
            float strokeDepth = mix(laneState.y, rearState.y, castBehindAmount());
            // Full-float depth must not use the old half-float-sized bias:
            // that admitted rear ink through nearly touching neighboring meshes.
            float depthBias = max(0.00000002, abs(rearState.y - laneState.y) * 0.0005);
            float inFront = step(strokeDepth - depthBias, pixelOwner.y);
            float visible = max(paperAdmission, max(sameOwner, inFront));
            visible *= mix(pickupVisibility, 1.0, paperAdmission);
            ownerRearStroke = max(
                ownerRearStroke, rearShape * rearPresence * rearLoad * visible);


        }

        float strengthLoad = mix(0.62, 1.0, pow(strength, 0.68));
        // Front cast is a complete foreground gesture. Restricting its wake
        // to empty paper amputates head/arm trails at the next visible mesh.
        // Rear cast is occluded by other owners, but retains the emitting
        // owner's surface portion so the root and tail remain one drawing.
        float sameOwner = sameVisibleObject(ownerId, pixelOwner.x);
        float gesture = ownerRearStroke * strengthLoad;
        frontInk = max(frontInk, gesture);
        rearInk = max(rearInk, gesture);
    }
}


void projectedOwnerDepthHalo(vec2 p, out float ink)
{
    ink = 0.0;
    vec2 pixel = p * resolution;
    vec2 sceneState = visibleObjectState(p);
    float paper = 1.0 - smoothstep(0.78, 0.998, sourceCoverage(p));
    float scale = min(resolution.x, resolution.y) / 1080.0;
    // Azimuth identifies a persistent surface streamline. Adjacent candidates
    // overlap at angular cells; the sampling grid never cuts a brush in half.
    for (int owner = 0; owner < 64; ++owner) {
        if (owner >= ownerCount) break;
        if (abs(texelFetch(ownerBoundsTex, ivec2(owner, 2), 0).w - float(owner + 1)) > 0.25) continue;
        float ownerId = float(owner + 1);
        vec4 bounds = texelFetch(ownerBoundsTex, ivec2(owner, 1), 0);
        vec2 center = 0.5 * (bounds.xy + bounds.zw) * resolution;
        vec2 halfSize = max(0.5 * (bounds.zw - bounds.xy) * resolution, vec2(2.0));
        vec2 offset = pixel - center;
        float angleHere = atan(offset.y, offset.x);
        float count = 64.0;
        float cell = floor((angleHere + 3.14159265359) * count / 6.28318530718);
        for (int neighbor = -2; neighbor <= 2; ++neighbor) {
            float lane = mod(cell + float(neighbor) + count, count);
            float seed = hash21(vec2(ownerId * 17.71 + lane * 3.17,
                                     salt * 0.037 + lane * 29.11 + 6257.0));
            float theta = (lane + 0.5 + (seed - 0.5) * 0.22) *
                          6.28318530718 / count - 3.14159265359;
            vec2 ray = vec2(cos(theta), sin(theta));
            vec2 normal = vec2(-ray.y, ray.x);
            float along = dot(offset, ray);
            float across = dot(offset, normal);
            float confidence;
            vec2 span = groupContourSpan(ownerId, center, ray, normal, 0.0,
                dot(abs(ray), halfSize), confidence);
            if (confidence < 0.5 || along <= 0.0) continue;
            float rim = max(span.y, 2.0);
            float root = rim * mix(0.43, 0.57, seed);
            float release = min(resolution.x, resolution.y) *
                mix(0.035, 0.20, pow(seed, 1.4)) * mix(0.35, 1.0, haloSpread);
            float end = rim + release;
            float t = (along - root) / max(end - root, 1.0);
            if (t < -0.08 || t > 1.06) continue;
            float wake = max(0.0, (along - rim) / max(release, 1.0));
            float turn = (seed - 0.5) * 0.16 * haloSpread;
            float curve = release * turn * wake * wake;
            float slope = 2.0 * turn * wake;
            float width = max(0.65 * scale, rim * 6.28318530718 / count *
                mix(0.30, 0.72, seed) * mix(0.24, 1.32, pow(lineThickness, 0.72)));
            float deposit = brushRibbonDeposit(
                curveNormalDistance(across - curve, slope), width, t,
                0.82 / max(end - root, 1.0), seed + 6337.0);
            if (deposit < 0.001) continue;
            vec2 surfaceUV = (center + ray * clamp(along, root, rim - 1.0)) / resolution;
            vec2 front = independentGroupState(ownerId, surfaceUV, false);
            vec2 back = independentGroupState(ownerId, surfaceUV, true);
            // A streamline travels from the selected hemisphere around the
            // surface to the opposite depth, rather than staying on a 2D plane.
            float surfaceTravel = smoothstep(root, end, along);
            float depthTravel = mix(surfaceTravel, 1.0 - surfaceTravel, castBehindAmount());
            float depth = mix(front.y, back.y, depthTravel);
            float bias = max(0.00000002, abs(back.y - front.y) * 0.0005);
            float admitted = max(paper, max(sameSpreadGroup(ownerId, sceneState.x),
                                          step(depth - bias, sceneState.y)));
            ink = max(ink, deposit * admitted * mix(0.25, 0.50, seed) *
                           mix(0.62, 1.0, pow(strength, 0.68)));
        }
    }
}

float trajectorySupport(vec2 p, vec2 flow)
{
    float shortEdge = max(1.0, min(resolution.x, resolution.y));
    float reach = shortEdge * mix(0.10, 0.58, strength);
    vec2 normal = vec2(-flow.y, flow.x);
    float accumulated = sourceCoverage(p);
    float normalization = 1.0;
    // Integrate a one-sided exposure envelope. The previous four binary
    // shelves were multiplied into every family and became a diagonal
    // triangle/saw edge around 45 and -124 degrees.
    for (int i = 1; i <= 5; ++i) {
        float t = (float(i) - 0.32) / 5.0;
        float weight = exp(-2.35 * t);
        float handArc = (valueNoise(
            vec2(t * 2.7, salt * 0.071), salt + 1733.0) - 0.5) *
            mix(0.7, 4.8, strength) * (0.35 + t);
        vec2 sampleUV = p - flow * (reach * t / resolution) +
                        normal * (handArc / resolution);
        accumulated += sourceCoverage(sampleUV) * weight;
        normalization += weight;
    }
    return smoothstep(0.018, 0.31, accumulated / normalization);
}

float heroInteriorGuard(vec2 p, vec2 flow, float passVariant)
{
    // Broad impact masses may leave the silhouette, but while they pass over
    // the captured subject they respect deliberate light/negative-space
    // openings. This prevents a long ribbon from bridging two bright planes
    // as if the character were merely behind a screen-space stripe.
    vec2 normal = vec2(-flow.y, flow.x);
    float groupPhase = valueNoise(
        vec2(passVariant * 17.3, salt * 0.037 + passVariant * 9.1),
        salt + 2093.0);
    float edgeWobble =
        (valueNoise((p - vec2(0.5)) * vec2(4.1, 3.7) +
                    vec2(passVariant * 2.9),
                    salt + 2101.0 + passVariant * 53.0) - 0.5) * 9.0;
    float phasePixels = mix(4.0, 24.0, groupPhase) + edgeWobble;
    float sidePhase = mix(-7.5, 7.5,
        hash11(passVariant * 113.7 + salt * 0.071 + 17.0));
    vec2 guardP = p - flow * phasePixels / resolution +
                  normal * sidePhase / resolution;
    // Ownership and tone are sampled at the hand-group phase, not at the
    // exact projected mesh pixel. Consequently no family shares the original
    // rectangle edge, while all four strokes in a group still feel authored
    // by the same pass.
    vec2 localState = sourceMaskAndKey(guardP);
    float localMask = localState.x;
    float localDarkness = localState.x *
        (1.0 - toneFromMaskAndKey(localState));
    float darkAcceptance = smoothstep(0.025, 0.28, localDarkness);
    float interiorOwnership = smoothstep(0.32, 0.90, localMask);
    // Lay down the gesture through the value boundary, then let pressure run
    // out at a pass-specific distance. Animators do not stop every brush at
    // the cel-light mask; several loaded passes overshoot while others lift
    // early, leaving an irregular fringe around the protected light plane.
    float bleedPatch = valueNoise(
        (p - vec2(0.5)) * vec2(13.7, 11.9) +
        vec2(passVariant * 5.3, passVariant * 7.1),
        salt + 2081.0 + passVariant * 97.0);
    // Each hand group carries its own boundary phase. The previous guard
    // changed directly from 1.0 outside the captured silhouette to a weak
    // value inside it, exposing the rectangular raster as one shared wall
    // even though the bristle tips themselves differed.
    float reach = mix(10.0, 48.0, bleedPatch) *
                  mix(0.82, 1.22, groupPhase) *
                  mix(0.86, 1.10, strength);
    vec2 trailingStep = flow * reach / resolution;
    vec2 sideStep = normal * mix(-9.0, 9.0,
        valueNoise((p - vec2(0.5)) * vec2(8.3, 7.1) +
                   vec2(passVariant * 3.7),
                   salt + 2111.0 + passVariant * 71.0)) /
        resolution;
    vec2 farStateA = sourceMaskAndKey(p - trailingStep);
    vec2 farStateB = sourceMaskAndKey(
        p - trailingStep * 0.58 + sideStep);
    float nearbyDarkness = max(
        farStateA.x * (1.0 - toneFromMaskAndKey(farStateA)),
        farStateB.x * (1.0 - toneFromMaskAndKey(farStateB)));
    // A shorter probe supplies a pressure shoulder rather than a binary
    // on/off decision at the source-mask contour. The longer probe still
    // limits how far ink may enter protected light.
    vec2 shoulderStateA = sourceMaskAndKey(p - trailingStep * 0.24);
    vec2 shoulderStateB = sourceMaskAndKey(
        p - trailingStep * 0.42 - sideStep * 0.45);
    float shoulderDarkness = max(
        shoulderStateA.x * (1.0 - toneFromMaskAndKey(shoulderStateA)),
        shoulderStateB.x * (1.0 - toneFromMaskAndKey(shoulderStateB)));
    float boundaryEvidence = max(
        smoothstep(0.055, 0.48, nearbyDarkness),
        smoothstep(0.10, 0.56, shoulderDarkness) * 0.86);
    float overrunPressure = mix(0.76, 0.98,
        smoothstep(0.24, 0.78, bleedPatch));
    float bristleOverrun = boundaryEvidence * overrunPressure;
    float paintedAcceptance = max(darkAcceptance, bristleOverrun);
    return mix(1.0, paintedAcceptance, interiorOwnership);
}

float heroReadabilityGate(vec2 p, vec2 strokeFlow, float seedRole,
                          float detailClass, float familySeed)
{
    vec2 flow = safeDirection(strokeFlow, vec2(1.0, 0.0));
    vec2 flowNormal = vec2(-flow.y, flow.x);
    float reach = mix(8.0, 36.0, familySeed * familySeed);
    float sideBias = (hash11(familySeed * 193.17 + salt * 0.11) - 0.5) * 7.0;
    vec2 travel = (flow * reach + flowNormal * sideBias) / resolution;
    vec2 backUV = clamp(p - travel * 0.72, vec2(0.0), vec2(1.0));
    vec2 frontUV = clamp(p + travel * 0.58, vec2(0.0), vec2(1.0));
    vec4 subject = texture(subjectTex, clamp(p, vec2(0.0), vec2(1.0)));
    float carriedSubject = max(subject.r, max(
        texture(subjectTex, backUV).r * 0.84,
        texture(subjectTex, frontUV).r * 0.70));
    float subjectSupport = smoothstep(0.018, 0.74, carriedSubject);
    float subjectInterior = smoothstep(0.10, 0.86, subject.r);
    float backgroundFloor = mix(0.12, 0.42,
                                clamp(detailClass, 0.0, 1.0));
    float backgroundPass = mix(1.0, backgroundFloor, subjectInterior);
    vec2 localState = sourceMaskAndKey(p);
    vec2 backState = sourceMaskAndKey(backUV);
    vec2 frontState = sourceMaskAndKey(frontUV);
    float localDarkness = localState.x * (1.0 - toneFromMaskAndKey(localState));
    float carriedDarkness = max(localDarkness, max(
        backState.x * (1.0 - toneFromMaskAndKey(backState)) * 0.84,
        frontState.x * (1.0 - toneFromMaskAndKey(frontState)) * 0.70));
    float structuralDarkness = mix(
        localDarkness, carriedDarkness,
        mix(0.58, 0.82, clamp(detailClass, 0.0, 1.0)));
    float shadowMass = smoothstep(0.075, 0.62, structuralDarkness);
    float litDetail = mix(0.12, 0.34, clamp(detailClass, 0.0, 1.0));
    // Match the primary path: broad impact ink follows the captured value
    // structure instead of covering clean highlights as a solid black plate.
    float subjectPass = mix(litDetail, 1.0, shadowMass);
    subjectPass = max(subjectPass,
        litDetail * mix(0.42, 0.78, clamp(detailClass, 0.0, 1.0)));
    return mix(backgroundPass, subjectPass,
               smoothstep(0.24, 0.76, seedRole));
}

float linearRibbonField(vec2 p, vec2 flow, out float rearResult)
{
    if (strength <= 0.0001 || lineThickness <= 0.0001) return 0.0;
    vec2 pixel = (p - vec2(0.5)) * resolution;
    float result = 0.0;
    rearResult = 0.0;
    float shortEdge = max(1.0, min(resolution.x, resolution.y));
    float strokePixelScale = clamp(shortEdge / 540.0, 0.56, 1.80);
    vec2 visiblePixelObject = visibleObjectState(p);
    vec2 boundsCenter = 0.5 * (subjectBounds.xy + subjectBounds.zw);
    vec2 commonFlow = sharedSubjectGestureFlow();
    float support = trajectorySupport(p, commonFlow);
    float softSupport = mix(0.54, 1.0, support);
    float localSubjectCoverage = sourceCoverage(p);
    vec2 radialProbe = safeDirection(p - boundsCenter, commonFlow);
    float inwardCoverage = max(
        sourceCoverage(p - radialProbe * 18.0 / resolution),
        max(sourceCoverage(p - radialProbe * 42.0 / resolution),
            sourceCoverage(p - radialProbe * 78.0 / resolution) * 0.72));
    float rearSilhouetteVisibility = (1.0 - smoothstep(
        0.04, 0.72, localSubjectCoverage)) *
        smoothstep(0.04, 0.62, inwardCoverage);
    // Candidate paths are seeded from projected scene evidence. A regular grid
    // with keyed in-cell jitter gives stable coverage without random clumps;
    // cells that contain no captured subject launch no mark.
    for (int i = 0; i < 224; ++i) {
        float fi = float(i);
        // Keep one deterministic family set at every raster tier. Owner-fire
        // supplies the compact infill without Apply inventing extra families.
        float activeFamilies = 168.0;
        if (fi >= activeFamilies) continue;
        // R2 low-discrepancy positions cover the drawing without a visible
        // Cartesian seed grid or several identical launches on one lane.
        float familySeed = hash11(fi * 19.17 + salt * 0.071 + 5.0);
        float familyGroup = floor(fi * 0.25);
        float pass = mod(fi, 4.0);
        float groupTurnSeed = hash11(
            familyGroup * 59.31 + salt * 0.151 + 37.0);
        float localTurnSeed = hash11(fi * 73.17 + salt * 0.181 + 43.0);
        float packet = hash11(
            familyGroup * 31.73 + salt * 0.277 + 191.0);
        float heroClass = (1.0 - step(0.34, groupTurnSeed)) *
                          (1.0 - step(0.5, pass));
        float fineClass = step(2.5, pass) * step(0.78, groupTurnSeed);
        float supportClass = max(0.0, 1.0 - heroClass - fineClass);
        float quietFamily = step(0.995, hash11(
            familyGroup * 113.71 + salt * 0.117 + 227.0));
        if (quietFamily > 0.5 && heroClass < 0.5) continue;
        if (packet < 0.035 && fineClass > 0.5) continue;
        float familyTurn = (groupTurnSeed - 0.5) *
                           (heroClass * 0.026 + supportClass * 0.052 +
                            fineClass * 0.095) +
                           (localTurnSeed - 0.5) *
                           mix(0.008, 0.022, fineClass);
        vec2 familyFlow = rotateVector(commonFlow, familyTurn);
        vec2 familyNormal = vec2(-familyFlow.y, familyFlow.x);
        // Every brush family samples its own scene location. The group still
        // shares heading/material character, but no longer repeats all four
        // members over one large object while skipping smaller visible parts.
        float anchorIndex = familyGroup;
        float horizontalJitter = hash11(
            anchorIndex * 53.71 + salt * 0.097 + 293.0);
        float verticalJitter = hash11(
            anchorIndex * 41.17 + salt * 0.109 + 317.0);
        float safeOwnerCount = max(float(ownerCount), 1.0);
        int targetOwnerIndex = int(mod(familyGroup, safeOwnerCount));
        float targetOwner = float(targetOwnerIndex + 1);
        vec4 targetBounds = ownerCount > 0
            ? texelFetch(ownerBoundsTex, ivec2(targetOwnerIndex, 0), 0)
            : subjectBounds;
        float ownerCycle = floor(familyGroup / safeOwnerCount);
        vec2 anchorUnit = vec2(
            mix(0.16, 0.84, horizontalJitter),
            fract(0.14 + ownerCycle * 0.618033989 +
                  verticalJitter * 0.19));
        vec2 anchorUV = mix(targetBounds.xy, targetBounds.zw, anchorUnit);
        float passOffset = (pass - 1.5) * mix(
            4.0, 12.0, groupTurnSeed) * strokePixelScale;
        float passAdvance = (pass - 1.5) * mix(
            -3.0, 6.0, localTurnSeed) * strokePixelScale;
        vec2 seedUV = clamp(anchorUV +
            (familyNormal * passOffset + familyFlow * passAdvance) /
            resolution, targetBounds.xy, targetBounds.zw);
        float targetFound = 0.0;
        if (ownerCount > 0) {
            seedUV = seekTargetOwnerCandidate(
                seedUV, targetOwner, targetBounds,
                familySeed + ownerCycle * 0.173, targetFound);
            if (targetFound < 0.5) continue;
        }
        else seedUV = seekOwnedCandidate(seedUV, familySeed);
        float seedRole;
        vec2 seedNormal;
        vec4 seedData = shadowBiasedSeed(
            seedUV, hash11(fi * 47.13 + salt * 0.231 + 181.0),
            seedRole, seedNormal);
        float sourceScreenAmount = length(
            (flowSource.xy - vec2(0.5)) * 2.0);
        float centeredSourceAmount = step(0.5, flowSource.w) *
            (1.0 - smoothstep(0.04, 0.22, sourceScreenAmount));
        seedUV = seedData.xy;
        float windConfidence;
        vec2 surfaceDirected;
        vec2 surfaceFlow = aerodynamicSurfaceFlow(
            seedUV, seedNormal, familyFlow,
            windConfidence, surfaceDirected);
        if (dot(surfaceFlow, familyFlow) < 0.0) surfaceFlow = -surfaceFlow;
        float windTurn = atan(
            familyFlow.x * surfaceFlow.y - familyFlow.y * surfaceFlow.x,
            dot(familyFlow, surfaceFlow));
        vec2 surfaceGesture = rotateVector(
            familyFlow, clamp(windTurn, -0.41887902, 0.41887902) *
            windConfidence * smoothstep(0.24, 0.82, seedRole) * 0.18);
        familyFlow = surfaceGesture;
        familyNormal = vec2(-familyFlow.y, familyFlow.x);
        float guaranteedRear = step(2.5, pass);
        float seedMask = seedData.z;
        float seedDarkness = seedData.w;
        float seedWeight = seedMask;
        float seedEdgeFacing = smoothstep(0.015, 0.46, length(seedNormal));
        seedWeight *= mix(
            1.0, mix(0.48, 1.52, pow(seedEdgeFacing, 1.20)),
            centeredSourceAmount * castBehindAmount());
        if (seedWeight < 0.018) continue;
        float launchChance = 0.98;
        float launchSelector = hash11(
            fi * 83.71 + salt * 0.193 + 151.0);
        if (launchSelector > launchChance) continue;

        vec2 localSubjectMotion = sourceVelocity(seedUV) -
            backgroundVelocityAt(seedUV);
        float subjectSpeed =
            length(localSubjectMotion) / max(velocityScale, 1.0e-6);
        float keyedSubjectResponse = smoothstep(
            0.015, 1.10, subjectSpeed) *
            smoothstep(0.34, 0.84, seedRole);
        vec2 directedTrail = -safeDirection(
            localSubjectMotion, safeDirection(subjectMotion, familyFlow));
        vec2 motionGesture = alignLineAxis(directedTrail, commonFlow);
        float coherentMotionTurn = atan(
            commonFlow.x * motionGesture.y - commonFlow.y * motionGesture.x,
            dot(commonFlow, motionGesture));
        motionGesture = rotateVector(
            commonFlow, clamp(coherentMotionTurn, -0.43633231, 0.43633231));
        familyFlow = blendDirection(
            familyFlow, motionGesture, keyedSubjectResponse * 0.20);
        vec2 aerodynamicIntent = mix(
            surfaceDirected, directedTrail,
            smoothstep(0.18, 0.82, keyedSubjectResponse));
        vec2 directedIntent = mix(
            commonFlow, aerodynamicIntent,
            max(step(0.5, flowSource.w) * 0.98,
                max(windConfidence,
                    smoothstep(0.02, 0.55, keyedSubjectResponse))));
        if (dot(familyFlow, directedIntent) < 0.0) familyFlow = -familyFlow;
        vec2 sharedAxis = alignLineAxis(commonFlow, familyFlow);
        familyFlow = blendDirection(
            sharedAxis, alignLineAxis(familyFlow, sharedAxis),
            mix(0.03, 0.08, windConfidence));
        familyNormal = vec2(-familyFlow.y, familyFlow.x);

        float spreadValue = clamp(haloSpread, 0.0, 1.0);
        float spreadAperture = smoothstep(0.0, 1.0, spreadValue);
        vec2 sideRayAxis = safeDirection(
            boundsCenter - flowSource.xy, commonFlow);
        vec2 centeredRayAxis = safeDirection(
            (seedUV - boundsCenter) * vec2(
                resolution.x / max(resolution.y, 1.0), 1.0),
            commonFlow);
        vec2 centeredChannelAxis = alignLineAxis(
            blendDirection(commonFlow, motionGesture,
                keyedSubjectResponse * 0.62), commonFlow);
        vec2 centeredLaunchAxis = blendDirection(
            centeredChannelAxis,
            alignLineAxis(centeredRayAxis, centeredChannelAxis), 0.38);
        vec2 rayAxis = safeDirection(mix(
            sideRayAxis, centeredLaunchAxis, centeredSourceAmount), commonFlow);
        vec2 rayNormal = vec2(-rayAxis.y, rayAxis.x);
        vec2 boundsHalf = max(
            (subjectBounds.zw - subjectBounds.xy) * 0.5, vec2(1.0e-4));
        float fanHalfSpan = max(
            dot(abs(rayNormal), boundsHalf), 1.0e-4);
        float fanCoordinate = clamp(
            dot(seedUV - boundsCenter, rayNormal) / fanHalfSpan,
            -1.0, 1.0);
        familyFlow = rotateVector(rayAxis, familyTurn);
        vec2 awayFromPin = safeDirection(mix(
            seedUV - flowSource.xy, centeredChannelAxis,
            centeredSourceAmount), commonFlow);
        if (dot(familyFlow, awayFromPin) < 0.0) familyFlow = -familyFlow;
        float rearCounterSide = castBehindAmount() *
            step(0.5, mod(familyGroup, 2.0));
        familyFlow *= mix(1.0, -1.0, rearCounterSide);
        familyNormal = vec2(-familyFlow.y, familyFlow.x);

        vec4 frontSideSeedData = shiftSeedTowardOwnerSide(
            seedData, familyFlow, -1.0, familySeed);
        vec4 rearSideSeedData = shiftSeedTowardOwnerSide(
            seedData, familyFlow, -1.0, familySeed + 0.371);
        seedData = mix(frontSideSeedData, rearSideSeedData, guaranteedRear);
        seedUV = seedData.xy;
        seedNormal = sourceSurfaceNormalXY(seedUV);
        seedRole = sourceRole(seedUV);
        seedMask = seedData.z;
        seedDarkness = seedData.w;
        seedWeight = seedMask;
        seedEdgeFacing = smoothstep(0.015, 0.46, length(seedNormal));
        seedWeight *= mix(
            1.0, mix(0.48, 1.52, pow(seedEdgeFacing, 1.20)),
            centeredSourceAmount * castBehindAmount());

        // A bundle shares the authored direction. Small launch-angle errors
        // read as repeated hand passes; large errors read as random spikes.
        vec2 seedPixel = (seedUV - vec2(0.5)) * resolution;
        vec2 relative = pixel - seedPixel;
        float along = dot(relative, familyFlow);
        float across = dot(relative, familyNormal);
        float lengthClass = hash11(fi * 17.83 + salt * 0.163 + 9.0);
        float depthScale = perspectiveScaleAt(seedUV);
        float classLength = heroClass * 1.38 +
                            supportClass * 0.96 + fineClass * 0.54;
        float provisionalRear = step(2.5, pass);
        vec2 familyRelativeMotion = sourceVelocity(seedUV) -
            backgroundVelocityAt(seedUV);
        float familyRelativeSpeed = length(familyRelativeMotion) /
            max(velocityScale, 1.0e-6);
        float familyParallelMotion = length(familyRelativeMotion) > 1.0e-7
            ? abs(dot(normalize(familyRelativeMotion), familyFlow)) : 0.0;
        float familyTransverseMotion = length(familyRelativeMotion) > 1.0e-7
            ? abs(dot(normalize(familyRelativeMotion), familyNormal)) : 0.0;
        float motionStretch = clamp(
            1.0 + keyedSubjectResponse * min(familyRelativeSpeed, 1.60) *
                (mix(0.34, 1.10, lengthClass) * familyParallelMotion -
                 0.16 * familyTransverseMotion),
            0.76, 2.45);
        float forwardLength = shortEdge * mix(0.10, 0.62, strength) *
                              mix(0.52, 1.30, lengthClass) *
                              depthScale * classLength * motionStretch;
        float spreadExpansion = smoothSpreadResponse(spreadValue);
        forwardLength *= mix(0.72, 1.12, provisionalRear);
        float pinScreenAmount = clamp(length(
            (flowSource.xy - vec2(0.5)) * 2.0), 0.0, 1.0);
        float directionForeshorten = mix(
            0.72, 1.0, smoothstep(0.04, 0.82, pinScreenAmount));
        forwardLength *= mix(
            1.0, directionForeshorten, step(0.5, flowSource.w));
        forwardLength *= mix(
            1.0, mix(1.14, 1.24, castBehindAmount()),
            centeredSourceAmount);
        float heelLength = mix(8.0, 30.0, lineThickness) * strokePixelScale *
                           mix(0.78, 1.18, familySeed) *
                           mix(1.0, 1.52, pow(seedDarkness, 0.72)) *
                           mix(0.82, 1.18, strength);
        vec2 ownedSpan = localOwnedSpan(seedUV, familyFlow);
        float ownerForwardReach = ownedSpan.y;
        float fanVariation = mix(0.82, 1.18, groupTurnSeed);
        float fireFan = 0.27 * spreadExpansion;
        float fanReachScale = spreadArcLengthScale(
            fanCoordinate * fireFan * fanVariation);
        float fireRelease = shortEdge * mix(0.055, 0.30, strength) *
            mix(0.64, 1.18, familySeed) * 0.72;
        float frontForward = max(
            forwardLength * mix(0.56, 0.78, familySeed),
            ownerForwardReach + fireRelease);
        float rearForward = max(
            forwardLength, ownedSpan.y + fireRelease);
        forwardLength = mix(frontForward, rearForward, guaranteedRear);
        forwardLength = ownerForwardReach +
            max(forwardLength - ownerForwardReach, 0.0) * fanReachScale;
        float frontHeel = mix(4.0, 10.0, familySeed) * strokePixelScale *
            mix(0.88, 1.12, lineThickness);
        float rearHeel = mix(12.0, 26.0, familySeed) * strokePixelScale *
            mix(0.88, 1.12, lineThickness);
        heelLength = mix(frontHeel, rearHeel, guaranteedRear);
        float gestureLength = max(forwardLength + heelLength, 1.0);
        float strokeT = (along + heelLength) / gestureLength;
        // One intentional hand arc, not periodic waviness.
        float curveT = clamp(strokeT, 0.0, 1.20);
        vec2 localVelocity = sourceVelocity(seedUV) -
            backgroundVelocityAt(seedUV);
        vec2 localAcceleration = sourceAcceleration(seedUV) -
            backgroundAcceleration;
        vec2 subjectCenter = clamp(
            0.5 * (subjectBounds.xy + subjectBounds.zw),
            vec2(0.0), vec2(1.0));
        vec2 coherentVelocity = subjectMotion -
            backgroundVelocityAt(subjectCenter);
        vec2 coherentAcceleration = subjectAcceleration -
            backgroundAcceleration;
        float trajectorySpeed =
            length(localVelocity) / max(velocityScale, 1.0e-6);
        float localTrajectoryWeight = smoothstep(
            0.10, 0.48, length(localVelocity) / max(velocityScale, 1.0e-6));
        vec2 trajectoryVelocity = mix(
            coherentVelocity, localVelocity, localTrajectoryWeight);
        vec2 blendedTrajectoryAcceleration = mix(
            coherentAcceleration, localAcceleration, localTrajectoryWeight);
        vec2 trajectoryTangent = safeDirection(
            trajectoryVelocity, familyFlow);
        vec2 trajectoryNormal = vec2(
            -trajectoryTangent.y, trajectoryTangent.x);
        float lateralAcceleration = dot(
            blendedTrajectoryAcceleration, trajectoryNormal);
        float signedTurn = sign(lateralAcceleration);
        float lateralTurn = abs(lateralAcceleration) /
            max(length(trajectoryVelocity), velocityScale * 0.045);
        float accelerationResponse = smoothstep(0.0025, 0.085, lateralTurn);
        float trajectoryResponse = smoothstep(
            0.035, 0.50, trajectorySpeed) * accelerationResponse *
            smoothstep(0.18, 0.72, seedRole);
        float trajectoryAlignment = dot(trajectoryNormal, familyNormal);
        float artistMotionInfluence = clamp(
            motionCurveInfluence, 0.0, 1.0);
        float curveDecision = step(
            0.16, trajectoryResponse * artistMotionInfluence);
        float trajectoryEnvelope = curveT * curveT;
        float trajectoryArc = signedTurn * trajectoryAlignment * gestureLength *
            mix(0.26, 0.52, clamp(trajectorySpeed, 0.0, 1.0)) *
            curveDecision * artistMotionInfluence * trajectoryEnvelope;
        vec2 surfaceOutward = safeDirection(
            seedNormal, seedUV - 0.5 * (subjectBounds.xy + subjectBounds.zw));
        float surfaceBendAlignment = dot(familyNormal, surfaceOutward);
        float windingEnvelope = subjectSurfaceWrapEnvelope(
            curveT, spreadExpansion);
        float frontWinding = mix(0.52, 1.0, seedEdgeFacing);
        float rearWinding = seedEdgeFacing * 1.24;
        float hemisphereBend = mix(-1.0, 1.0, castBehindAmount());
        float surfaceWindingArc = surfaceBendAlignment * hemisphereBend *
            shortEdge * mix(0.018, 0.055, strength) *
            centeredSourceAmount * mix(
                frontWinding, rearWinding, castBehindAmount()) *
            windingEnvelope;
        float familyArc = trajectoryArc + surfaceWindingArc;
        float trajectorySlope = signedTurn * trajectoryAlignment *
            mix(0.26, 0.52, clamp(trajectorySpeed, 0.0, 1.0)) *
            curveDecision * artistMotionInfluence * (2.0 * curveT);
        float surfaceWindingSlope = surfaceBendAlignment * hemisphereBend *
            shortEdge * mix(0.018, 0.055, strength) *
            centeredSourceAmount * mix(
                frontWinding, rearWinding, castBehindAmount()) *
            subjectSurfaceWrapSlope(curveT, spreadExpansion) /
            max(gestureLength, 1.0);
        float familyArcSlope = trajectorySlope + surfaceWindingSlope;
        float sketchT = clamp(curveT, 0.0, 1.0);
        float sketchDeviation = (
            valueNoise(vec2(curveT * 5.1, familyGroup * 0.17),
                       salt + 2141.0) - 0.5) * 0.34 *
            4.0 * sketchT * (1.0 - sketchT) *
            mix(1.0, 0.22,
                trajectoryResponse * artistMotionInfluence);
        float spreadEnvelope = handDrawnFanEnvelope(curveT);
        float fanBend = fanCoordinate * gestureLength * 0.27 *
            spreadExpansion * fanVariation * spreadEnvelope;
        float familySeparation = passOffset * spreadExpansion *
            mix(0.18, 0.34, groupTurnSeed) * spreadEnvelope;
        float fanSlope = fanCoordinate * 0.27 * spreadExpansion *
            fanVariation * handDrawnFanSlope(curveT);
        float separationSlope = passOffset * spreadExpansion *
            mix(0.18, 0.34, groupTurnSeed) * handDrawnFanSlope(curveT) /
            max(gestureLength, 1.0);
        float widthClass = hash11(fi * 67.21 + salt * 0.173 + 29.0);
        float passWidth = pass < 0.5 ? 1.0 :
                          pass < 1.5 ? 0.84 :
                          pass < 2.5 ? 0.70 : 0.72;
        float groupWidth = mix(0.84, 1.18, groupTurnSeed);
        float shadowMassBoost = mix(1.02, 1.60,
            pow(seedDarkness, 0.66));
        float motionLoading = mix(1.0, 1.16, keyedSubjectResponse);
        float classWidth = heroClass * mix(1.12, 1.52, widthClass) +
                           supportClass * mix(0.72, 1.04, widthClass) +
                           fineClass * mix(0.30, 0.52, widthClass);
        float centeredLoad = centeredSourceAmount *
            (1.0 - step(0.62, groupTurnSeed)) * (1.0 - step(2.5, pass));
        classWidth *= mix(1.0, 1.36, centeredLoad);
        float halfWidth = mix(0.64, 8.2, pow(lineThickness, 1.10)) *
                          strokePixelScale *
                          classWidth * groupWidth *
                          passWidth * shadowMassBoost * motionLoading *
                          pow(depthScale, 0.62);
        float castBehind = castBehindAmount();
        float pointSource = step(0.5, flowSource.w);
        float depthPerspective = mix(
            mix(1.16, 0.70, curveT),
            mix(0.70, 1.34, curveT), castBehind);
        halfWidth *= mix(1.0, depthPerspective, pointSource);
        halfWidth *= mix(
            1.0, mix(0.82, 0.92, castBehind), centeredSourceAmount);
        halfWidth = min(halfWidth, max(
            mix(1.8, 3.4, supportClass + heroClass) * strokePixelScale,
            gestureLength * mix(0.040, 0.066, heroClass)));
        float pressureT = strokeT;
        float parentAcross = curveNormalDistance(
            across - familyArc - sketchDeviation - fanBend - familySeparation,
            familyArcSlope + fanSlope + separationSlope);
        float stroke = motionFamilyDeposit(
            parentAcross,
            halfWidth, pressureT,
            0.78 / gestureLength, familySeed);
        float fillLength = gestureLength * mix(0.34, 0.64,
            hash11(fi * 131.17 + salt * 0.157 + 409.0));
        float fillT = (along + heelLength * 0.42) / max(fillLength, 1.0);
        float fillOffset = (hash11(fi * 149.31 + salt * 0.181 + 431.0) - 0.5) *
            max(1.2 * strokePixelScale, halfWidth * 1.35);
        float fill = filamentSwipeDeposit(
            curveNormalDistance(
                across - familyArc - sketchDeviation * 0.46 -
                fanBend * 0.92 - familySeparation * 0.78 + fillOffset,
                familyArcSlope + fanSlope * 0.92 + separationSlope * 0.78),
            max(0.26, halfWidth * mix(0.055, 0.16, familySeed)),
            fillT, familySeed + 433.0);
        float fillBLength = gestureLength * mix(0.22, 0.48,
            hash11(fi * 167.11 + salt * 0.193 + 457.0));
        float fillBT = (along + heelLength * 0.24) /
            max(fillBLength, 1.0);
        float fillBOffset = -sign(fillOffset + 1.0e-4) *
            max(1.0 * strokePixelScale,
                halfWidth * mix(0.72, 1.62, familySeed));
        float fillB = filamentSwipeDeposit(
            curveNormalDistance(
                across - familyArc - sketchDeviation * 0.31 -
                fanBend * 0.86 - familySeparation * 0.62 + fillBOffset,
                familyArcSlope + fanSlope * 0.86 + separationSlope * 0.62),
            max(0.22, halfWidth * mix(0.035, 0.095, familySeed)),
            fillBT, familySeed + 461.0);
        // Compact loaded passes occupy the white shelves between long hero
        // releases. They use the same flow/depth family, but finish early and
        // keep enough width to read as ink rather than hairline hatching.
        float compactLength = gestureLength * mix(0.24, 0.46,
            hash11(fi * 181.73 + salt * 0.167 + 479.0));
        float compactT = (along + heelLength * 0.58) /
            max(compactLength, 1.0);
        float compactOffset = (hash11(
            fi * 197.11 + salt * 0.191 + 491.0) - 0.5) *
            halfWidth * 1.55;
        float compact = motionFamilyDeposit(
            curveNormalDistance(
                across - familyArc - fanBend * 0.72 + compactOffset,
                familyArcSlope + fanSlope * 0.72),
            max(0.80 * strokePixelScale,
                halfWidth * mix(0.34, 0.52, familySeed)),
            compactT, 0.78 / max(compactLength, 1.0), familySeed + 487.0);
        stroke = 1.0 - (1.0 - stroke) *
            (1.0 - fill * mix(0.28, 0.66, seedDarkness)) *
            (1.0 - fillB * mix(0.22, 0.52, seedDarkness)) *
            (1.0 - compact * mix(0.52, 0.82, seedDarkness));
        float opacitySeed = hash11(fi * 23.11 + salt * 0.223 + 41.0);
        float familyOpacity = heroClass * mix(0.68, 0.90, opacitySeed) +
                              supportClass * mix(0.38, 0.68, opacitySeed) +
                              fineClass * mix(0.20, 0.48, opacitySeed);
        familyOpacity = mix(
            familyOpacity, max(familyOpacity, 0.78), centeredLoad);
        familyOpacity *= mix(1.0, 1.16, guaranteedRear);
        float detailClass = clamp(fineClass + supportClass * 0.46, 0.0, 1.0);
        float readability = heroReadabilityGate(
            p, familyFlow, seedRole, detailClass, familySeed);
        readability = mix(1.0, readability,
            step(0.5, visiblePixelObject.x));
        // Main ink is a graphic layer. Lighting controls the hatch/tone pass,
        // never whether a loaded hero family survives.
        float centeredReadability = mix(0.46, 0.94, detailClass);
        readability = mix(
            readability, max(readability, centeredReadability),
            centeredSourceAmount);
        float coronaReadability = mix(0.54, 0.96, detailClass) *
            rearSilhouetteVisibility;
        readability = mix(
            readability, max(readability, coronaReadability),
            centeredSourceAmount * castBehindAmount());
        float intensityDeposit = mix(0.24, 1.0, pow(strength, 0.62));
        float rearOcclusion = mix(
            1.0,
            mix(0.12, 1.0, rearSilhouetteVisibility),
            centeredSourceAmount * castBehind);
        stroke *= familyOpacity * intensityDeposit *
                  mix(0.72, 1.0, seedWeight) *
                  mix(readability * softSupport * rearOcclusion,
                      1.0, provisionalRear) *
                  mix(1.0, 1.42, centeredSourceAmount * castBehind);
        // Classify depth once at the emitter. Trailing/outward families sit
        // below the subject while front/interior families stay above it.
        float trailingFace = smoothstep(
            -0.04, 0.38, -dot(seedNormal, familyFlow));
        // One member per four-pass hand bundle is always rear. A second
        // support member may tuck behind only when its source face is truly
        // leeward; hero/front passes no longer disappear behind the rig.
        float pairedRear = step(2.5, pass);
        float faceRear = pairedRear * step(
            mix(0.34, 0.72, hash11(
                fi * 211.73 + salt * 0.137 + 521.0)),
            trailingFace);
        float rearFamily = mix(
            max(pairedRear, faceRear), 1.0,
            centeredSourceAmount * castBehindAmount());
        float objectFrontVisibility;
        float objectRearVisibility;
        objectLayerVisibility(
            p, visiblePixelObject, seedUV, familyFlow, familySeed,
            ownerForwardReach,
            objectFrontVisibility, objectRearVisibility);
        rearResult = 1.0 - (1.0 - rearResult) *
            (1.0 - stroke * rearFamily * objectRearVisibility);
        float thirdFrontSupport = step(1.5, pass) * (1.0 - step(2.5, pass));
        float frontFamilyLoad = mix(1.0, 0.80, thirdFrontSupport);
        result = 1.0 - (1.0 - result) *
            (1.0 - stroke * (1.0 - rearFamily) * objectFrontVisibility *
                frontFamilyLoad);
    }
    return clamp(result, 0.0, 1.0);
}

float silhouetteTrailAccentField(vec2 p, vec2 flow, out float frontResult)
{
    if (strength <= 0.0001 || lineThickness <= 0.0001) return 0.0;
    vec2 pixel = (p - vec2(0.5)) * resolution;
    float result = 0.0;
    frontResult = 0.0;
    float shortEdge = max(1.0, min(resolution.x, resolution.y));
    vec2 subjectCenter = 0.5 * (subjectBounds.xy + subjectBounds.zw);
    vec2 boundsSpan = subjectBounds.zw - subjectBounds.xy;
    for (int i = 0; i < 56; ++i) {
        float fi = float(i);
        float group = floor(fi * 0.5);
        float member = mod(fi, 2.0);
        float accentSeed = hash11(fi * 43.17 + salt * 0.127 + 601.0);
        vec2 seedUV = subjectCenter;
        float found = 0.0;
        float horizontalScan = 1.0 - step(38.0, fi);
        float laneT = clamp(fract(
            0.5 + group * 0.618033989 + salt * 0.00731), 0.025, 0.975);
        float side = member < 0.5 ? 1.0 : -1.0;
        for (int j = 0; j < 12; ++j) {
            float scanT = (float(j) + 0.35) / 12.0;
            vec2 horizontalProbe = vec2(
                mix(subjectCenter.x, side > 0.0 ? subjectBounds.x : subjectBounds.z,
                    scanT),
                subjectBounds.y + boundsSpan.y * laneT);
            vec2 verticalProbe = vec2(
                subjectBounds.x + boundsSpan.x * laneT,
                mix(subjectCenter.y, side > 0.0 ? subjectBounds.y : subjectBounds.w,
                    scanT));
            vec2 probe = mix(verticalProbe, horizontalProbe, horizontalScan);
            if (sourceCoverage(probe) > 0.075) {
                seedUV = probe;
                found = 1.0;
            }
        }
        if (found < 0.5) continue;
        vec2 seedNormal = sourceSurfaceNormalXY(seedUV);
        vec2 accentFlow = safeDirection(
            subjectCenter - flowSource.xy, safeDirection(flow, vec2(-1.0, 0.0)));
        float windConfidence;
        vec2 directedFlow;
        vec2 projected = aerodynamicSurfaceFlow(
            seedUV, seedNormal, accentFlow, windConfidence, directedFlow);
        float topBottomFace = 1.0 - horizontalScan;
        float spreadValue = clamp(haloSpread, 0.0, 1.0);
        float centeredSourceAmount = subjectCenteredSourceAmount();
        accentFlow = safeDirection(mix(
            subjectCenter - flowSource.xy,
            (seedUV - subjectCenter) * vec2(
                resolution.x / max(resolution.y, 1.0), 1.0),
            centeredSourceAmount), flow);
        vec2 accentFanNormal = vec2(-accentFlow.y, accentFlow.x);
        float accentFanSpan = max(
            dot(abs(accentFanNormal), boundsSpan * 0.5), 1.0e-5);
        float faceCoordinate = clamp(dot(
            seedUV - subjectCenter, accentFanNormal) / accentFanSpan,
            -1.0, 1.0);
        accentFlow = rotateVector(accentFlow,
            (accentSeed - 0.5) * 0.032);
        vec2 accentAway = safeDirection(
            seedUV - flowSource.xy, vec2(1.0, 0.0));
        if (dot(accentFlow, accentAway) < 0.0) accentFlow = -accentFlow;
        vec2 accentNormal = vec2(-accentFlow.y, accentFlow.x);
        vec2 relative = pixel - (seedUV - vec2(0.5)) * resolution;
        float along = dot(relative, accentFlow);
        float across = dot(relative, accentNormal);
        float longitudinalPhase = (hash11(
            fi * 157.37 + salt * 0.173 + 751.0) - 0.5) *
            shortEdge * 0.105;
        along += longitudinalPhase;
        float lengthPixels = shortEdge * mix(0.15, 0.36,
            hash11(fi * 71.31 + salt * 0.181 + 613.0)) *
            mix(0.72, 1.0, strength);
        float heel = mix(7.0, 18.0, lineThickness) *
            mix(0.84, 1.12, accentSeed);
        float rearOwner = step(0.5, member);
        vec2 ownedSpan = localOwnedSpan(seedUV, accentFlow);
        float rearOvershoot = shortEdge * mix(0.035, 0.078, accentSeed);
        heel = mix(heel, mix(4.0, 11.0, accentSeed), rearOwner);
        lengthPixels = mix(lengthPixels,
            ownedSpan.y + ownedSpan.x +
                rearOvershoot * mix(0.84, 1.18, accentSeed),
            rearOwner);
        float gestureLength = max(lengthPixels + heel, 1.0);
        float strokeT = (along + heel) / gestureLength;
        float accentFan = faceCoordinate * gestureLength * 0.26 *
            smoothSpreadResponse(spreadValue) *
            mix(0.88, 1.12, accentSeed) *
            handDrawnFanEnvelope(strokeT);
        float accentFanSlope = faceCoordinate * 0.26 *
            smoothSpreadResponse(spreadValue) *
            mix(0.88, 1.12, accentSeed) *
            handDrawnFanSlope(strokeT);
        float memberLoad = member < 0.5 ? 1.0 : 0.68;
        float halfWidth = mix(1.5, 12.8, pow(lineThickness, 0.82)) *
            memberLoad *
            mix(0.82, 1.16, accentSeed);
        halfWidth *= mix(1.0, 0.48, topBottomFace);
        halfWidth = min(halfWidth, gestureLength * 0.145);
        float loaded = motionFamilyDeposit(
            curveNormalDistance(across - accentFan, accentFanSlope),
            halfWidth, strokeT,
            0.78 / gestureLength, accentSeed + 617.0);
        float filament = filamentSwipeDeposit(
            curveNormalDistance(
                across - accentFan * 0.92 +
                    halfWidth * mix(-0.62, 0.62, accentSeed),
                accentFanSlope * 0.92),
            max(0.34, halfWidth * 0.28),
            strokeT / mix(0.72, 0.90, accentSeed), accentSeed + 641.0);
        float accent = 1.0 - (1.0 - loaded) *
            (1.0 - filament * mix(0.42, 0.68, memberLoad));
        accent *= mix(0.88, 1.0, strength);
        accent *= mix(0.46, 0.68, strength);
        float frontOwner = (1.0 - step(0.5, member)) *
            (1.0 - centeredSourceAmount * castBehindAmount());
        frontResult = 1.0 - (1.0 - frontResult) *
            (1.0 - accent * frontOwner);
        result = 1.0 - (1.0 - result) *
            (1.0 - accent * (1.0 - frontOwner));
    }
    return clamp(result, 0.0, 1.0);
}

float frontNookFillField(vec2 p, vec2 flow)
{
    vec2 pixel = (p - vec2(0.5)) * resolution;
    vec2 boundsSpan = subjectBounds.zw - subjectBounds.xy;
    vec2 center = 0.5 * (subjectBounds.xy + subjectBounds.zw);
    float result = 0.0;
    float shortEdge = max(1.0, min(resolution.x, resolution.y));
    for (int i = 0; i < 60; ++i) {
        float fi = float(i);
        float column = mod(fi, 6.0);
        float row = floor(fi / 6.0);
        vec2 cell = (vec2(column, row) + vec2(0.5)) / vec2(6.0, 8.0);
        vec2 jitter = vec2(
            hash11(fi * 37.17 + salt * 0.113 + 811.0),
            hash11(fi * 61.73 + salt * 0.157 + 823.0)) - vec2(0.5);
        vec2 seedUV = subjectBounds.xy + boundsSpan *
            clamp(cell + jitter * vec2(0.085, 0.060), vec2(0.02), vec2(0.98));
        float owned = sourceCoverage(seedUV);
        if (owned < 0.10) continue;
        float seed = hash11(fi * 79.31 + salt * 0.181 + 839.0);
        float edgeFamily = step(0.46, seed);
        vec4 edgeSeed = shiftSeedTowardSilhouette(
            vec4(seedUV, owned, 0.72), seed);
        seedUV = mix(seedUV, edgeSeed.xy, edgeFamily);
        float normalReach = length(sourceSurfaceNormalXY(seedUV));
        float edgeEvidence = mix(
            mix(0.58, 0.92, smoothstep(0.0, 0.42, normalReach)),
            smoothstep(0.025, 0.42, normalReach), edgeFamily);
        float centeredSourceAmount = subjectCenteredSourceAmount();
        vec2 familyFlow = safeDirection(mix(
            center - flowSource.xy,
            (seedUV - center) * vec2(
                resolution.x / max(resolution.y, 1.0), 1.0),
            centeredSourceAmount), flow);
        vec2 fillFanNormal = vec2(-familyFlow.y, familyFlow.x);
        float fillFanSpan = max(
            dot(abs(fillFanNormal), boundsSpan * 0.5), 1.0e-5);
        float fanCoordinate = clamp(dot(seedUV - center, fillFanNormal) /
            fillFanSpan, -1.0, 1.0);
        float spreadValue = clamp(haloSpread, 0.0, 1.0);
        familyFlow = rotateVector(familyFlow, (seed - 0.5) * 0.018);
        vec2 normal = vec2(-familyFlow.y, familyFlow.x);
        vec2 relative = pixel - (seedUV - vec2(0.5)) * resolution;
        float along = dot(relative, familyFlow);
        float across = dot(relative, normal);
        float lengthPixels = shortEdge * mix(0.055, 0.135, seed);
        float heel = mix(7.0, 17.0, lineThickness);
        float strokeT = (along + heel) / max(lengthPixels + heel, 1.0);
        float fillFan = fanCoordinate * (lengthPixels + heel) * 0.22 *
            smoothSpreadResponse(spreadValue) * mix(0.90, 1.10, seed) *
            handDrawnFanEnvelope(strokeT);
        float fillFanSlope = fanCoordinate * 0.22 *
            smoothSpreadResponse(spreadValue) * mix(0.90, 1.10, seed) *
            handDrawnFanSlope(strokeT);
        float halfWidth = mix(2.6, 11.8, pow(lineThickness, 0.92)) *
            mix(0.78, 1.22, seed) * mix(1.08, 0.94, edgeFamily);
        float stroke = motionFamilyDeposit(
            curveNormalDistance(across - fillFan, fillFanSlope),
            halfWidth, strokeT,
            0.78 / max(lengthPixels + heel, 1.0), seed + 853.0);
        result = 1.0 - (1.0 - result) *
            (1.0 - stroke * mix(0.62, 0.92, strength) * edgeEvidence);
    }
    return clamp(result, 0.0, 1.0);
}

void rigAerodynamicEnvelopeField(vec2 p, vec2 authoredFlow,
                                 out float frontInk, out float rearInk)
{
    frontInk = 0.0;
    rearInk = 0.0;
    if (strength <= 0.0001 || lineThickness <= 0.0001) return;
    vec2 center = 0.5 * (subjectBounds.xy + subjectBounds.zw);
    vec2 halfBounds = max(
        0.5 * (subjectBounds.zw - subjectBounds.xy), vec2(1.0e-4));
    vec2 aspect = vec2(resolution.x / max(resolution.y, 1.0), 1.0);
    vec2 sourceDirection = (center - flowSource.xy) * aspect;
    vec2 carrier = safeDirection(
        mix(authoredFlow, sourceDirection, step(0.5, flowSource.w)),
        authoredFlow);
    if (dot(carrier, authoredFlow) < 0.0 && flowSource.w < 0.5)
        carrier = -carrier;
    vec2 carrierNormal = vec2(-carrier.y, carrier.x);
    float alongRadius = dot(abs(carrier), halfBounds * resolution);
    float acrossRadius = dot(abs(carrierNormal), halfBounds * resolution);
    float shortEdge = max(1.0, min(resolution.x, resolution.y));
    vec2 pixel = (p - center) * resolution;
    float subjectAtPixel = smoothstep(0.06, 0.70, cohesiveCoverage(p));
    vec2 edgeProbe = carrierNormal * mix(3.0, 8.0, lineThickness) / resolution;
    vec2 endProbe = carrier * mix(4.0, 10.0, lineThickness) / resolution;
    float edgeBand = max(
        abs(sourceCoverage(p + edgeProbe) - sourceCoverage(p - edgeProbe)),
        abs(sourceCoverage(p + endProbe) - sourceCoverage(p - endProbe)));
    edgeBand = smoothstep(0.03, 0.66, edgeBand);
    for (int i = 0; i < 48; ++i) {
        float fi = float(i);
        float family = floor(fi / 3.0);
        float member = mod(fi, 3.0);
        float familySeed = hash11(
            family * 79.31 + salt * 0.173 + 4703.0);
        float memberSeed = hash11(
            fi * 113.17 + salt * 0.137 + 4721.0);
        float lane = fract(
            family * 0.618033989 + salt * 0.00073 +
            (familySeed - 0.5) * 0.075) * 2.0 - 1.0;
        float memberOffset = (member - 1.0) *
            mix(2.0, 7.5, familySeed);
        float launchJitter = (memberSeed - 0.5) *
            min(shortEdge * 0.075, alongRadius * 0.34);
        vec2 anchor = carrierNormal *
            (lane * acrossRadius * mix(0.88, 1.08, familySeed) +
             memberOffset) + carrier * launchJitter;
        vec2 relative = pixel - anchor;
        float along = dot(relative, carrier);
        float across = dot(relative, carrierNormal);
        float trail = shortEdge * mix(0.06, 0.23, memberSeed) *
            mix(0.68, 1.22, strength);
        float heel = shortEdge * mix(0.018, 0.055, familySeed);
        float totalLength = max(8.0,
            alongRadius * 2.0 + trail + heel);
        float strokeT = (along + alongRadius + heel) / totalLength;
        float flameEnvelope = clamp(strokeT, 0.0, 1.0);
        float broadCurve = (familySeed - 0.5) *
            mix(8.0, 48.0, haloSpread) *
            flameEnvelope * flameEnvelope;
        broadCurve += dot(subjectAcceleration, carrierNormal) *
            shortEdge * 0.055 * flameEnvelope * flameEnvelope;
        broadCurve += sin(strokeT * mix(3.4, 7.8, memberSeed) +
            familySeed * 6.2831853) * mix(0.8, 4.2, haloSpread) *
            flameEnvelope;
        float handDrift = (valueNoise(
            vec2(strokeT * 5.3, family * 0.37),
            salt + 4751.0) - 0.5) * mix(0.5, 2.4, memberSeed);
        float familyClass = member < 0.5 ? 1.0 :
                            member < 1.5 ? 0.58 : 0.26;
        float flameTaper = mix(1.04, 0.78,
            smoothstep(0.72, 1.04, flameEnvelope));
        float halfWidth = mix(0.42, 21.0, pow(lineThickness, 0.94)) *
            familyClass * mix(0.72, 1.28, familySeed);
        halfWidth *= flameTaper;
        float loaded = motionFamilyDeposit(
            across - broadCurve - handDrift,
            halfWidth, strokeT, 0.78 / totalLength,
            memberSeed + 4777.0);
        float fiber = filamentSwipeDeposit(
            across - broadCurve * 0.82 +
                halfWidth * mix(-0.72, 0.72, memberSeed),
            max(0.24, halfWidth * 0.16),
            strokeT / mix(0.82, 1.08, familySeed),
            memberSeed + 4793.0);
        float dashGate = mix(0.34, 1.0, smoothstep(0.35, 0.62,
            valueNoise(vec2(strokeT * 8.0, family * 0.41),
                       salt + 4813.0)));
        float stroke = (1.0 - (1.0 - loaded) * (1.0 - fiber * 0.64)) *
            dashGate * mix(0.54, 0.96, strength);
        float frontVisibility = subjectAtPixel *
            mix(0.48, 0.96, edgeBand) *
            mix(0.72, 1.0, memberSeed);
        float rearVisibility = 1.0 - subjectAtPixel;
        frontInk = 1.0 - (1.0 - frontInk) *
            (1.0 - stroke * frontVisibility);
        rearInk = 1.0 - (1.0 - rearInk) *
            (1.0 - stroke * rearVisibility);
    }
}

float silhouetteEmitterMode()
{
    float pointSource = step(0.5, flowSource.w);
    vec2 pin = clamp(flowSource.xy, vec2(0.0), vec2(1.0));
    vec2 neighborhood = vec2(34.0) / max(resolution, vec2(1.0));
    float nearbySubject = texture(subjectTex, pin).r;
    nearbySubject = max(nearbySubject, texture(subjectTex,
        clamp(pin + vec2(neighborhood.x, 0.0), vec2(0.0), vec2(1.0))).r);
    nearbySubject = max(nearbySubject, texture(subjectTex,
        clamp(pin - vec2(neighborhood.x, 0.0), vec2(0.0), vec2(1.0))).r);
    nearbySubject = max(nearbySubject, texture(subjectTex,
        clamp(pin + vec2(0.0, neighborhood.y), vec2(0.0), vec2(1.0))).r);
    nearbySubject = max(nearbySubject, texture(subjectTex,
        clamp(pin - vec2(0.0, neighborhood.y), vec2(0.0), vec2(1.0))).r);
    vec2 centerDelta = (flowSource.xy - vec2(0.5)) *
        vec2(resolution.x / max(resolution.y, 1.0), 1.0);
    float centeredPin = 1.0 - smoothstep(0.10, 0.30, length(centerDelta));
    return pointSource * step(0.62, centeredPin);
}

float silhouetteEmitterRibbonField(vec2 p, out float edgeHatching)
{
    edgeHatching = 0.0;
    if (strength <= 0.0001 || lineThickness <= 0.0001) return 0.0;
    vec2 pixel = (p - vec2(0.5)) * resolution;
    float shortEdge = max(1.0, min(resolution.x, resolution.y));
    float searchRadius = length(resolution) * 0.58;
    float result = 0.0;
    for (int i = 0; i < 32; ++i) {
        float fi = float(i);
        float activeRays = mix(24.0, 32.0, smoothstep(
            220.0, 720.0, min(resolution.x, resolution.y)));
        if (fi >= activeRays) continue;
        float group = floor(fi * 0.25);
        float member = mod(fi, 4.0);
        float groupSeed = hash11(group * 83.17 + salt * 0.151 + 197.0);
        float familySeed = hash11(fi * 41.17 + salt * 0.173 + 223.0);
        float memberAngle = (member - 1.5) * mix(0.026, 0.068, groupSeed);
        float theta = group * 2.39996323 + salt * 0.013 +
                      (groupSeed - 0.5) * 0.18 + memberAngle;
        vec2 radialFlow = vec2(cos(theta), sin(theta));
        vec2 edgeUV = flowSource.xy;
        float found = 0.0;
        float stepPixels = searchRadius / 10.0;
        for (int j = 0; j < 10; ++j) {
            float radius = (float(j) + 0.42) * stepPixels;
            vec2 probe = flowSource.xy + radialFlow * radius / resolution;
            float owned = texture(subjectTex,
                clamp(probe, vec2(0.0), vec2(1.0))).r;
            if (owned > 0.075) {
                edgeUV = probe;
                found = 1.0;
            }
        }
        if (found < 0.5) continue;
        vec2 refineA = edgeUV + radialFlow * stepPixels * 0.50 / resolution;
        if (texture(subjectTex, clamp(refineA, vec2(0.0), vec2(1.0))).r > 0.075)
            edgeUV = refineA;
        vec2 refineB = edgeUV + radialFlow * stepPixels * 0.25 / resolution;
        if (texture(subjectTex, clamp(refineB, vec2(0.0), vec2(1.0))).r > 0.075)
            edgeUV = refineB;

        vec2 travelFlow = radialFlow;
        float passTurn = (hash11(fi * 73.31 + salt * 0.191) - 0.5) * 0.070;
        vec2 familyFlow = rotateVector(travelFlow, passTurn);
        vec2 familyNormal = vec2(-familyFlow.y, familyFlow.x);
        vec2 seedPixel = (edgeUV - vec2(0.5)) * resolution;
        vec2 relative = pixel - seedPixel;
        float along = dot(relative, familyFlow);
        float across = dot(relative, familyNormal);
        float motionResponse = smoothstep(0.015, 1.10,
            length(subjectMotion) / max(velocityScale, 1.0e-6));
        vec2 motionTarget = safeDirection(subjectMotion, familyFlow);
        float motionTurn = angleDifference(
            atan(familyFlow.y, familyFlow.x),
            atan(motionTarget.y, motionTarget.x));
        float lengthSeed = hash11(fi * 17.83 + salt * 0.163 + 9.0);
        float depthScale = hemisphereStrokeScale(
            edgeUV, sourceSurfaceNormalXY(edgeUV));
        float forwardLength = shortEdge * mix(0.10, 0.54, strength) *
            mix(0.58, 1.34, lengthSeed) *
            (1.0 + motionResponse * mix(0.24, 0.78, lengthSeed)) *
            depthScale;
        float heelLength = mix(5.0, 18.0, lineThickness) *
            mix(0.72, 1.24, familySeed);
        float gestureLength = max(forwardLength + heelLength, 1.0);
        float strokeT = (along + heelLength) / gestureLength;
        float curveT = clamp(strokeT, 0.0, 1.20);
        float curveEnvelope = curveT * curveT * (3.0 - 2.0 * curveT);
        float keyedMotionArc = sin(motionTurn) * motionResponse * shortEdge *
            mix(0.030, 0.072, familySeed) * curveEnvelope;
        float handArc = (hash11(fi * 97.13 + salt * 0.109) - 0.5) *
            mix(0.35, 2.8, strength) * curveEnvelope;
        float spreadOffset = memberAngle * gestureLength * 0.30 *
            smoothSpreadResponse(haloSpread) *
            handDrawnFanEnvelope(curveT);
        float widthSeed = hash11(fi * 67.21 + salt * 0.173 + 29.0);
        float heroClass = 1.0 - step(0.5, member);
        float fineClass = step(2.5, member);
        float supportClass = max(0.0, 1.0 - heroClass - fineClass);
        float classWidth = heroClass * mix(1.18, 1.62, widthSeed) +
                           supportClass * mix(0.54, 1.02, widthSeed) +
                           fineClass * mix(0.18, 0.38, widthSeed);
        float halfWidth = mix(0.42, 18.5, pow(lineThickness, 1.08)) *
            classWidth;
        float castBehind = castBehindAmount();
        float depthPerspective = mix(
            mix(1.18, 0.64, curveT),
            mix(0.62, 1.42, curveT), castBehind);
        halfWidth *= depthPerspective;
        float pressureT = mix(strokeT, 1.0 - strokeT, castBehind);
        float stroke = motionFamilyDeposit(
            across - handArc - keyedMotionArc - spreadOffset,
            halfWidth, pressureT,
            0.78 / gestureLength, familySeed);
        float accentLength = forwardLength * mix(0.30, 0.64,
            hash11(fi * 127.17 + salt * 0.157 + 367.0));
        float accentGesture = max(accentLength + heelLength * 0.55, 1.0);
        float accentT = (along + heelLength * 0.55) / accentGesture;
        accentT = mix(accentT, 1.0 - accentT, castBehind);
        float accentOffset = mix(-1.8, 1.8,
            hash11(fi * 149.11 + salt * 0.181 + 389.0));
        float edgeTrace = filamentSwipeDeposit(
            across - handArc * 0.42 - keyedMotionArc * 0.58 -
            spreadOffset * 0.72 + accentOffset,
            mix(0.28, 1.18, familySeed), accentT, familySeed + 401.0);
        edgeHatching = 1.0 - (1.0 - edgeHatching) *
            (1.0 - edgeTrace * mix(0.34, 0.68, familySeed));
        float familyOpacity = mix(0.58, 0.98,
            hash11(fi * 23.11 + salt * 0.223 + 41.0));
        stroke *= familyOpacity * mix(0.28, 1.0, pow(strength, 0.62));
        result = 1.0 - (1.0 - result) * (1.0 - stroke);
    }
    return clamp(result, 0.0, 1.0);
}

float frameEdgeDistance(vec2 outward)
{
    vec2 focusPixel = focus * resolution;
    vec2 safeRay = safeDirection(outward, vec2(1.0, 0.0));
    float tx = safeRay.x > 0.0
        ? (resolution.x - focusPixel.x) / max(safeRay.x, 1.0e-6)
        : -focusPixel.x / min(safeRay.x, -1.0e-6);
    float ty = safeRay.y > 0.0
        ? (resolution.y - focusPixel.y) / max(safeRay.y, 1.0e-6)
        : -focusPixel.y / min(safeRay.y, -1.0e-6);
    return max(1.0, min(tx, ty));
}

float radialCoreGate(vec2 delta)
{
    float shortEdge = max(1.0, min(resolution.x, resolution.y));
    float radius = length(delta);
    float a = atan(delta.y, delta.x);
    float primaryLobes = pow(abs(cos(a * 2.0)), 7.0);
    float irregular = valueNoise(
        vec2(cos(a), sin(a)) * 3.7 + vec2(salt * 0.013),
        salt + 2861.0);
    float threshold = clamp(radialThreshold, 0.0, 1.0);
    float thresholdResponse = threshold * threshold * (3.0 - 2.0 * threshold);
    float baseRadius = shortEdge * mix(0.006, 0.168, thresholdResponse);
    float boundary = baseRadius * mix(0.72, 1.34, primaryLobes) *
        mix(0.86, 1.14, irregular);
    float feather = max(4.0, shortEdge * mix(0.026, 0.108,
        thresholdResponse));
    float pressure = smoothstep(boundary - feather * 0.36,
                                boundary + feather * 1.72, radius);
    float graphiteFeather = mix(0.70, 1.0, valueNoise(
        vec2(a * 2.7, radius * 0.026), salt + 2879.0));
    return pow(pressure, 1.12) * mix(0.82, 1.0, graphiteFeather);
}

float radialVoidGate(vec2 delta)
{
    float shortEdge = max(1.0, min(resolution.x, resolution.y));
    float radius = length(delta);
    float a = atan(delta.y, delta.x) - radialTwirlOffset(radius);
    float threshold = clamp(radialThreshold, 0.0, 1.0);
    float response = threshold * threshold * (3.0 - 2.0 * threshold);
    float wrapped = fract((a + 3.14159265) / 6.28318531);
    float cells = 23.0;
    float cellCoord = wrapped * cells;
    float cell = floor(cellCoord);
    float local = fract(cellCoord) - 0.5;
    float cellSeed = hash11(mod(cell, cells) * 47.31 + salt * 0.071);
    float rayProfile = 1.0 - smoothstep(
        mix(0.08, 0.22, cellSeed), mix(0.25, 0.48, cellSeed), abs(local));
    float heel = shortEdge * response * mix(0.055, 0.27, cellSeed) *
        rayProfile;
    float heelFeather = max(2.0, shortEdge * mix(0.010, 0.035, response));
    float rayGate = smoothstep(heel - heelFeather,
                               heel + heelFeather, radius);
    return radialCoreGate(delta) * rayGate;
}

// Each radial family owns its interruptions and tapered width. Neighbouring
// rays share a broad irregular rhythm, with independently staggered peaks.
float radialBandPressure(float radius, float rayAngle, float familySeed, vec2 emitter)
{
    float amount=clamp(bandTransition,0.0,1.0);
    if (amount<=0.0001) return 1.0;
    float irregular=pow(amount,1.25);
    float owner=visibleObjectState(emitter).x;
    float depth=.5;
    if(owner>=.5 && ownerCount>0) {
        int index=clamp(int(owner+.5)-1,0,ownerCount-1);
        depth=clamp(texelFetch(ownerBoundsTex,ivec2(index,7),0).x*.5+.5,0.0,1.0);
    }
    float period=min(resolution.x,resolution.y)*mix(.43,.16,pow(amount,.75))*mix(1.25,.78,depth);
    vec2 circle=vec2(cos(rayAngle),sin(rayAngle));
    float coordinate=radius/max(period,1.0);
    coordinate+=(valueNoise(circle*3.7+vec2(coordinate*.23),salt+251.)-.5)*mix(.12,1.8,irregular);
    coordinate+=(familySeed-.5)*mix(.04,.24,irregular)+(depth-.5)*.38;
    float cell=floor(coordinate);
    float pressure=1.0;
    for(int j=-1;j<=1;++j) {
        float k=cell+float(j);
        float event=hash11(k*39.7+salt*.083);
        float center=k+.5+(event-.5)*irregular*.65;
        float gap=mix(.002,.24,amount)*mix(.60,1.40,event);
        float tip=mix(.055,.29,hash11(familySeed*79.1+k*17.3));
        pressure=min(pressure,clamp((abs(coordinate-center)-gap)/tip,0.0,1.0));
    }
    return mix(1.0,pressure,smoothstep(0.0,.07,amount));
}

float radialHairlineLayer(vec2 delta, float radius, float polarAngle,
                          float lineCount, float layerSeed,
                          float widthScale)
{
    float shortEdge = max(1.0, min(resolution.x, resolution.y));
    float lookupTwirl = radialTwirlOffset(radius);
    float lookupAngle = polarAngle - lookupTwirl;
    float wrappedAngle = fract(
        (lookupAngle + 3.14159265) / 6.28318531);
    float angularCell = floor(wrappedAngle * lineCount);
    float cellSeed = hash11(angularCell * 37.17 + layerSeed + salt * 0.071);
    float centerAngle = (angularCell + 0.5) / lineCount * 6.28318531 -
        3.14159265 + (cellSeed - 0.5) * 4.6 / lineCount;
    vec2 baseRay = vec2(cos(centerAngle), sin(centerAngle));
    float edgeRadius = frameEdgeDistance(baseRay);
    float pathT = clamp(radius / max(edgeRadius, 1.0), 0.0, 1.0);
    vec2 guideUV = clamp(focus + baseRay * min(radius, shortEdge * 0.26) /
        resolution, vec2(0.0), vec2(1.0));
    float role = sourceRole(guideUV);
    vec2 localMotion = mix(backgroundMotion, sourceVelocity(guideUV), role);
    float motionResponse = smoothstep(0.0005, 0.12, length(localMotion));
    vec2 target = safeDirection(mix(
        baseRay, safeDirection(localMotion, baseRay),
        motionResponse * clamp(motionCurveInfluence, 0.0, 1.0)), baseRay);
    float coherentTurn = angleDifference(centerAngle, atan(target.y, target.x));
    float curveEnvelope = pathT * pathT * (3.0 - 2.0 * pathT);
    centerAngle += coherentTurn * motionResponse * curveEnvelope *
        clamp(motionCurveInfluence, 0.0, 1.0);
    centerAngle += lookupTwirl;
    float handDrift=(valueNoise(vec2(pathT*5.1,angularCell*.31),layerSeed+17.0)-0.5)*
        shortEdge*0.0035*sin(pathT*3.14159265);
    float across = abs(angleDifference(polarAngle, centerAngle)*max(radius,1.0)-handDrift);
    float widthSeed = hash11(angularCell * 71.31 + layerSeed * 1.91);
    float width = mix(0.34, 2.25, widthSeed * widthSeed) * widthScale *
        mix(0.62, 1.38, pow(lineThickness, 0.72));
    float bandPressure=radialBandPressure(radius,centerAngle-lookupTwirl,cellSeed,guideUV);
    width*=mix(1.0,.48,pow(clamp(bandTransition,0.0,1.0),1.25))*bandPressure;
    float aa = max(0.72, fwidth(across) * 0.82);
    float line = 1.0 - smoothstep(width, width + aa, across);
    float radialT = radius / max(length(resolution), 1.0);
    float start = mix(0.0, 0.095, hash11(
        angularCell * 19.73 + layerSeed * 3.17));
    start += 0.07 * pow(cellSeed,1.7);
    float lift=mix(0.28,1.12,hash11(angularCell*53.71+layerSeed));
    float gestureT=(radialT-start)/max(lift-start,0.02);
    width*=mix(0.24,1.0,pow(max(0.0,sin(clamp(gestureT,0.0,1.0)*3.14159265)),0.55));
    line = 1.0-smoothstep(width,width+aa,across);
    float pressure = smoothstep(start, start + 0.028, radialT) *
        (1.0 - smoothstep(0.91, 1.12, radialT));
    float reversedPressure = smoothstep(start, start + 0.028, 1.0 - radialT) *
        (1.0 - smoothstep(0.91, 1.12, 1.0 - radialT));
    pressure = mix(pressure, reversedPressure, castBehindAmount());
    float handContact = valueNoise(
        vec2(radialT * mix(11.0, 29.0, cellSeed), angularCell * 0.17),
        layerSeed + salt + 2203.0);
    float core = smoothstep(shortEdge * 0.002, shortEdge * 0.025, radius);
    float sectorRhythm = 0.58 + 0.20 * sin(centerAngle * 3.0 + salt * 0.019) +
        0.13 * sin(centerAngle * 7.0 - salt * 0.011);
    float sectorContact = smoothstep(0.30, 0.76,
        sectorRhythm + (cellSeed - 0.5) * 0.32);
    float liftGate=1.0-smoothstep(lift-0.07,lift,radialT);
    // Broad quiet sectors remain correlated with the captured subject, while
    // the thin construction tier can bridge them softly.
    float contact= mix(0.10,1.0,sectorContact)*mix(0.56,1.0,role);
    return line*smoothstep(0.0,.08,bandPressure)*pressure*core*liftGate*
        mix(0.42,1.0,handContact)*contact*radialVoidGate(delta);
}

float radialHairlineField(vec2 delta, float radius, float polarAngle)
{
    float fine = radialHairlineLayer(
        delta, radius, polarAngle, 233.0, 1301.0, 0.52);
    float medium = radialHairlineLayer(
        delta, radius, polarAngle, 149.0, 1459.0, 0.86);
    float loaded = radialHairlineLayer(
        delta, radius, polarAngle, 89.0, 1601.0, 1.45);
    float field = 1.0 - (1.0 - fine * 0.62) *
        (1.0 - medium * 0.74) * (1.0 - loaded * 0.58);
    return field * 0.96 * pow(clamp(strength, 0.0, 1.0), 0.86);
}

float radialLegacyPolarField(vec2 p)
{
    if (strength <= 0.0001 || lineThickness <= 0.0001) return 0.0;
    vec2 delta = (p - focus) * resolution;
    float radius = length(delta);
    float polarAngle = atan(delta.y, delta.x);
    float shortEdge = max(1.0, min(resolution.x, resolution.y));
    float coreRadius = max(1.0, shortEdge * 0.0022);
    float result = 0.0;
    for (int i = 0; i < 96; ++i) {
        float fi = float(i);
        float activeCount = mix(72.0, 96.0, smoothstep(
            240.0, 760.0, min(resolution.x, resolution.y)));
        if (fi >= activeCount) continue;
        float group = floor(fi * 0.25);
        float pass = mod(fi, 4.0);
        float groupSeed = hash11(group * 61.37 + salt * 0.139 + 17.0);
        float passSeed = hash11(fi * 43.11 + salt * 0.097 + 13.0);
        float heroClass = 1.0 - step(0.18, groupSeed);
        float fineClass = step(0.72, groupSeed);
        float centerAngle = group * 2.39996323 + salt * 0.011 +
            (pass - 1.5) * mix(0.008, 0.024, fineClass) +
            (groupSeed - 0.5) * mix(0.035, 0.095, fineClass);
        vec2 outward = vec2(cos(centerAngle), sin(centerAngle));
        float edgeRadius = frameEdgeDistance(outward);
        float radialT = (radius - coreRadius) /
            max(edgeRadius + mix(3.0, 18.0, passSeed) - coreRadius, 1.0);
        float pathT = clamp(radialT, 0.0, 1.0);
        vec2 localMotion = sourceVelocity(clamp(
            focus + outward * min(edgeRadius * 0.42, shortEdge * 0.30) /
                    resolution,
            vec2(0.0), vec2(1.0)));
        float localSpeed = length(localMotion) / max(velocityScale, 1.0e-6);
        float motionResponse = smoothstep(0.015, 1.10, localSpeed);
        float motionTurn = angleDifference(
            centerAngle, atan(localMotion.y, localMotion.x));
        float spiralEnvelope = pathT * pathT * (3.0 - 2.0 * pathT);
        float pathAngle = centerAngle + motionTurn * motionResponse *
            spiralEnvelope * 0.28 + radialTwirlOffset(radius);
        float across = angleDifference(polarAngle, pathAngle) * max(radius, 1.0);
        float widthSeed = hash11(fi * 67.21 + salt * 0.173 + 29.0);
        float passWidth = pass < 0.5 ? 1.0 :
                          pass < 1.5 ? 0.70 :
                          pass < 2.5 ? 0.43 : 0.24;
        float classWidth = heroClass * mix(1.65, 2.35, widthSeed) +
                           (1.0 - heroClass) * mix(0.28, 1.08, widthSeed);
        float perspective = mix(0.035, 1.0,
            smoothstep(0.0, 0.18, pathT));
        float halfWidth = max(0.22,
            mix(0.42, 15.5, pow(lineThickness, 1.08)) * passWidth *
            classWidth * perspective);
        float directedT = mix(radialT, 1.0 - radialT, castBehindAmount());
        float stroke = motionFamilyDeposit(
            across, halfWidth, directedT,
            0.78 / max(edgeRadius, 1.0), passSeed);
        float opacity = mix(0.42, 0.98, widthSeed) *
            pow(clamp(strength, 0.0, 1.0), 0.86);
        result = 1.0 - (1.0 - result) * (1.0 - stroke * opacity);
    }
    float hairlines = radialHairlineField(delta, radius, polarAngle);
    return clamp(1.0 - (1.0 - result) * (1.0 - hairlines), 0.0, 1.0);
}

vec4 radialSeedRecord(int index, int channel)
{
    float fi=float(index);
    vec2 seedUV = fract(vec2(
        0.5 + fi * 0.754877666 + salt * 0.0137,
        0.5 + fi * 0.569840296 + salt * 0.0191));
    float seedRole;
    vec2 unusedNormal;
    vec4 seedData = shadowBiasedSeed(
        seedUV, hash11(fi * 43.71 + salt * 0.247 + 173.0),
        seedRole, unusedNormal);

    return channel==0 ? seedData : vec4(seedRole, unusedNormal, 0.);
}

float radialRibbonField(vec2 p)
{
    if (strength <= 0.0001 || lineThickness <= 0.0001) return 0.0;
    vec2 delta = (p - focus) * resolution;
    float radius = length(delta);
    float polarAngle = atan(delta.y, delta.x);
    float diagonal = length(resolution);
    float result = 0.0;
    float shortEdge = max(1.0, min(resolution.x, resolution.y));
    float softSupport = 1.0;
    float coreRadius = max(1.0, shortEdge * 0.0025);
    float focalGate = radialVoidGate(delta);

    // The same evidence grid launches radial paths through captured features.
    // Their focus-side and outward reaches differ, avoiding a regular sunburst.
    for (int i = 0; i < 112; ++i) {
        float fi = float(i);
        float activeFamilies = mix(58.0, 86.0, smoothstep(
            220.0, 720.0, min(resolution.x, resolution.y)));
        if (fi >= activeFamilies) continue;
        vec4 seedData=texelFetch(radialSeedTex,ivec2(i,0),0);
        float seedRole=texelFetch(radialSeedTex,ivec2(i,1),0).x;
        vec2 seedUV;
        seedUV = seedData.xy;
        float seedMask = seedData.z;
        float seedDarkness = seedData.w;
        float seedWeight = seedMask;
        if (seedWeight < 0.025) continue;
        float launchChance = 0.84;
        float launchSelector = hash11(
            fi * 79.13 + salt * 0.211 + 139.0);
        if (launchSelector > launchChance) continue;

        float familySeed = hash11(fi * 17.41 + salt * 0.079 + 3.0);
        float familyGroup = floor(fi * 0.25);
        vec2 seedDelta = (seedUV - focus) * resolution;
        float seedRadius = length(seedDelta);
        float centerAngle = atan(seedDelta.y, seedDelta.x);
        centerAngle += (hash11(fi * 43.11 + salt * 0.097 + 13.0) - 0.5) * 0.08;
        float bendSign = hash11(fi * 53.73 + salt * 0.127) * 2.0 - 1.0;
        float outwardReach = mix(70.0, diagonal * 0.42, strength) *
                             mix(0.72, 1.18, familySeed);
        float silhouetteStart = max(coreRadius, seedRadius * mix(
            0.46, 0.78,
            hash11(familyGroup * 89.17 + salt * 0.113 + 211.0)));
        float silhouetteClass = smoothstep(0.28, 0.92, familySeed);
        float startRadius = mix(coreRadius, silhouetteStart,
            mix(0.28, 0.92, silhouetteClass));
        outwardReach*=max(subjectDrawingScale,0.0001);
        float endRadius = max(startRadius+shortEdge*0.06*subjectDrawingScale,
            seedRadius+outwardReach*mix(0.48,1.22,familySeed));
        float radialT = (radius - startRadius) /
                        max(endRadius - startRadius, 1.0);
        float bendT = clamp(radialT, 0.0, 1.0);
        centerAngle += bendSign * bendT * bendT * mix(0.008, 0.040, strength);
        centerAngle += radialTwirlOffset(radius);
        float across = angleDifference(polarAngle, centerAngle) *
                       max(radius, 1.0);
        float widthClass = hash11(fi * 37.13 + salt * 0.149 + 17.0);
        float massClass = smoothstep(0.46, 0.82, widthClass);
        float pass = mod(fi, 4.0);
        float passWidth = pass < 0.5 ? 1.0 :
                          pass < 1.5 ? 0.74 :
                          pass < 2.5 ? 0.50 : 0.32;
        float groupWidth = mix(0.86, 1.16,
            hash11(familyGroup * 107.17 + salt * 0.149 + 67.0));
        float shadowMassBoost = mix(0.95, 1.34,
            pow(seedDarkness, 0.66));
        // Radial density comes primarily from many converging blades. Keep
        // its broad class restrained so maximum bloom cannot merge the whole
        // burst into a screen-sized disk and erase the protected sectors.
        float focalPerspective = mix(0.055, 1.0,
            smoothstep(0.0, 0.24, clamp(radialT, 0.0, 1.0)));
        float centerWidthRelease = mix(0.10, 1.0, pow(focalGate, 0.58));
        float halfWidth = mix(0.64, 8.6, pow(lineThickness, 1.10)) *
                          mix(0.54, 1.46, widthClass) *
                          mix(1.0, 1.25, massClass) * groupWidth * passWidth *
                          focalPerspective * shadowMassBoost * centerWidthRelease +
                          radius * mix(0.0008, 0.0032, widthClass) *
                          centerWidthRelease;
        halfWidth*=clamp(sqrt(max(subjectDrawingScale,0.0001)),0.2,4.0);
        float familyPresence = mix(0.58, 0.90, familySeed);
        float bandPressure=radialBandPressure(radius,centerAngle-radialTwirlOffset(radius),familySeed,seedUV);
        halfWidth*=mix(1.0,.48,pow(clamp(bandTransition,0.0,1.0),1.25))*bandPressure;
        float stroke = motionFamilyDeposit(
            across, halfWidth, radialT,
            0.78 / max(endRadius - startRadius, 1.0), familySeed);
        float readability = heroReadabilityGate(
            p, vec2(cos(centerAngle), sin(centerAngle)), seedRole,
            1.0 - massClass, familySeed);
        readability = 1.0;
        float gestureContact = valueNoise(
            vec2(familyGroup * 0.37, bendT * mix(5.0, 11.0, familySeed)),
            salt + 2917.0 + pass * 13.0);
        stroke *= smoothstep(0.0,.08,bandPressure)*familyPresence * mix(0.72, 1.0, seedWeight) *
                  pow(clamp(strength, 0.0, 1.0), 0.82) *
                  mix(0.52, 1.0, gestureContact) *
                  focalGate * readability * softSupport;
        result = 1.0 - (1.0 - result) * (1.0 - stroke);
    }
    float hairlines = radialHairlineField(delta, radius, polarAngle);
    return clamp((1.0 - (1.0 - result) * (1.0 - hairlines)) * focalGate,
        0.0, 1.0);
}

/*
 * Nested tonal hatching: darker tones add stable lanes instead of replacing
 * a smooth gray fill.  The first family follows the same coherent field as
 * the subject drawing; a second, oblique family appears only in deeper shade.
 * Each lane has one persistent identity derived from frame salt and lane ID,
 * so changing light intensity reveals more of the same drawing rather than
 * sliding a procedural screen over the rig.
 */
float hatchDrawingSalt()
{
    vec2 pose = floor(flowSource.xy * 24.0 + vec2(0.5));
    float hemisphere = step(0.0, -flowSource.z);
    return salt + hash11(dot(pose, vec2(37.17, 91.73)) +
                         hemisphere * 173.31) * 997.0;
}



float drawnLightCoverage=0.0;
float drawnLightKey=0.0;

float hatchLane(vec2 p, vec2 flow, float spacing, float halfWidth,
                float density, float familySeed, float candidateOffset,
                float earlyEdgeTransition)
{
    float drawingSalt = hatchDrawingSalt();
    vec2 tangent = normalize(flow + vec2(1e-6));
    vec2 normal = vec2(-tangent.y, tangent.x);
    vec2 pixel = (p - vec2(0.5)) * resolution;
    float along = dot(pixel, tangent);
    float across = dot(pixel, normal);
    // A narrow antialiased owner/paper shoulder can report zero local tone
    // even though the same pencil action is admitted immediately on both
    // sides. Returning here clips every lane at that shared coordinate and
    // exposes a ruler-straight white slit. Let every existing hatch family
    // enter the downstream same-action continuity probes at a low seed
    // density. This admits only the analytic lanes already crossing the edge;
    // it does not add a contour-normal silhouette stroke.
    // Test both axes of the authored hatch frame. A tangent-only probe cannot
    // see an edge parallel to the pencil action, so those angles returned
    // before the per-action support below and exposed a clean white divider.
    density = max(density, earlyEdgeTransition * 0.18);
    float lane = floor(across / spacing);
    float lowerBoundary = lane * spacing +
        (hash11(lane * 41.17 + familySeed * 17.31 + drawingSalt * 0.071) - 0.5) *
        spacing * 0.34;
    float upperBoundary = (lane + 1.0) * spacing +
        (hash11((lane + 1.0) * 41.17 + familySeed * 17.31 + drawingSalt * 0.071) - 0.5) *
        spacing * 0.34;
    if (across < lowerBoundary) lane -= 1.0;
    else if (across >= upperBoundary) lane += 1.0;
    lane += candidateOffset;
    lowerBoundary = lane * spacing +
        (hash11(lane * 41.17 + familySeed * 17.31 + drawingSalt * 0.071) - 0.5) *
        spacing * 0.34;
    upperBoundary = (lane + 1.0) * spacing +
        (hash11((lane + 1.0) * 41.17 + familySeed * 17.31 + drawingSalt * 0.071) - 0.5) *
        spacing * 0.34;
    float laneSpan = max(0.58, (upperBoundary - lowerBoundary) / spacing);
    // Four neighboring passes belong to one hand-action neighborhood. They
    // share slant, pressure and timing bias, then receive a smaller local
    // variation. That produces recognizable repeated intent without a ruler
    // grid or unrelated noise on every line.
    float laneGroup = floor(lane * 0.25);
    float groupSeed = hash11(
        laneGroup * 21.17 + familySeed * 91.73 + drawingSalt * 0.13);
    float localLaneSeed = hash11(
        lane * 37.17 + familySeed * 61.31 + drawingSalt * 0.17);
    float laneSeed = mix(groupSeed, localLaneSeed, 0.78);

    // Tonal-art-map nesting: raising density only admits additional stable
    // lanes. Existing lanes keep their position, width and graphite phase.
    // A line remembers its pressure through a tone transition.  Stable
    // segment/lane bias means neighboring gestures do not all terminate on
    // the same cel-light contour, while zero-density regions still remain
    // empty. This is the tonal-art-map equivalent of a hand overshooting a
    // highlight by a different amount on every pass.
    float laneCenter = 0.5 * (lowerBoundary + upperBoundary);
    laneCenter += (localLaneSeed - 0.5) * spacing * 0.16 +
                  (groupSeed - 0.5) * spacing * 0.08;

    // Each lane is a sequence of pressure gestures, not a periodic dash row.
    // Correlated longitudinal drift changes the gesture duration gradually;
    // neighboring pixels never choose unrelated segment boundaries.
    float groupLength = mix(58.0, 188.0, groupSeed * groupSeed);
    float independentLength = mix(46.0, 214.0, pow(hash11(
        lane * 59.17 + familySeed * 17.31 + drawingSalt * 0.07), 1.35));
    float segmentLength = mix(groupLength, independentLength, 0.72);
    float groupPhase = hash11(laneGroup * 47.31 + familySeed * 29.17);
    float segmentPhase = fract(groupPhase + localLaneSeed * 0.78) *
                         segmentLength;
    float longitudinalDrift = (valueNoise(
        vec2(along * 0.0067 + familySeed * 2.1, lane * 0.091),
        familySeed + 463.0) - 0.5) * segmentLength * 0.16;
    float segmentCoordinate =
        (along + segmentPhase + longitudinalDrift) / segmentLength;
    float segmentIndex = floor(segmentCoordinate);
    float segmentT = fract(segmentCoordinate);
    float segmentSeed = hash11(segmentIndex * 31.73 + lane * 13.91 +
                               familySeed * 7.17);
    // One projected-normal sample steers one finite pencil action. Holding the
    // slope fixed prevents rubber contours and lets adjoining mesh faces begin
    // separately angled traces with naturally overlapping pressure tails.
    float segmentCenterAlong =
        (segmentIndex + 0.5) * segmentLength - segmentPhase;
    vec2 segmentAnchorUV = clamp(
        vec2(0.5) + (tangent * segmentCenterAlong +
                     normal * laneCenter) / resolution,
        vec2(0.0), vec2(1.0));
    vec2 anchorNormalXY = sourceSurfaceNormalXY(segmentAnchorUV);
    float pointSource = step(0.5, flowSource.w);
    float groupSlope = (groupSeed - 0.5) * 0.14;
    float pencilSlope = groupSlope + (localLaneSeed - 0.5) * 0.09 +
        (segmentSeed - 0.5) * 0.08;
    // Five lane candidates cover this maximum excursion even on long marks.
    pencilSlope = clamp(pencilSlope, -spacing*2.0/segmentLength,
                                     spacing*2.0/segmentLength);
    float maxSlopeTurn = mix(0.34906585, 0.61086524, pointSource);
    float aerodynamicSlope = tan(clamp(
        atan(pencilSlope), -maxSlopeTurn, maxSlopeTurn));
    vec2 strokeTangent = safeDirection(
        tangent + normal * aerodynamicSlope, tangent);
    vec2 strokeNormal = vec2(-strokeTangent.y, strokeTangent.x);
    vec2 segmentAnchorPixel = (segmentAnchorUV - vec2(0.5)) * resolution;
    vec2 localRelative = pixel - segmentAnchorPixel;
    float localAlong = dot(localRelative, strokeTangent);
    float localAcross = dot(localRelative, strokeNormal);
    // Reject neighbor candidates outside the widest pressure envelope before
    // the expensive tonal continuation probes.
    if (abs(localAcross) > halfWidth * 4.0 + 2.0) return 0.0;
    float strokeT = localAlong / max(segmentLength, 1.0) + 0.5;
    // Every pencil action owns a materially different start and end. The
    // former shared 0.04/0.92 window survived the later edge-continuity path
    // and aligned otherwise irregular hatches into a slab border.
    float actionStartSeed = hash11(
        lane * 47.17 + segmentIndex * 67.31 + familySeed * 13.7);
    float actionEndSeed = hash11(
        lane * 79.13 + segmentIndex * 43.71 + familySeed * 17.9);
    float actionStart = mix(0.012, 0.17, pow(actionStartSeed, 1.45));
    float actionEnd = max(actionStart + 0.34,
        mix(0.68, 0.992, pow(actionEndSeed, 0.72)));
    actionEnd = min(actionEnd, 0.995);
    float actionAttackWidth = mix(0.024, 0.072,
        hash11(lane * 23.19 + segmentIndex * 71.13 + familySeed));
    float actionReleaseWidth = mix(0.020, 0.085,
        hash11(lane * 61.07 + segmentIndex * 29.17 + familySeed * 3.1));
    float strokeWindow = smoothstep(
        actionStart, actionStart + actionAttackWidth, strokeT) *
        (1.0 - smoothstep(
            actionEnd - actionReleaseWidth, actionEnd, strokeT));
    // Each lane probes a different position across the lit boundary. This
    // gives every gesture its own continuation distance instead of clipping a
    // whole group against the same flat tone contour.
    float laneContinuation = 0.0;
    // Fully shaded pixels already admit the complete nested set. Only tone
    // transitions need the displaced probe, avoiding redundant texture work
    // across the dense shadow masses.
    if (density < 0.985) {
        float reachSeed = hash11(
            lane * 17.71 + segmentIndex * 23.19 + familySeed * 5.3);
        float laneReach = mix(5.0, 86.0, reachSeed * reachSeed);
        float laneSide = mix(-10.0, 10.0,
            hash11(lane * 43.09 + segmentIndex * 13.51 + familySeed * 2.1));
        vec2 laneNearOffset =
            (strokeTangent * laneReach +
             strokeNormal * laneSide * 0.30) / resolution;
        vec2 nearStateA = sourceMaskAndKey(p - laneNearOffset);
        vec2 nearStateB = sourceMaskAndKey(p + laneNearOffset);
        float nearOwnerA = smoothstep(0.08, 0.72, nearStateA.x);
        float nearOwnerB = smoothstep(0.08, 0.72, nearStateB.x);
        float nearEffectiveKeyA = clamp(lightIntensity, 0.0, 1.0) *
            keyLightField(clamp(p - laneNearOffset, vec2(0.0), vec2(1.0)));
        float nearEffectiveKeyB = clamp(lightIntensity, 0.0, 1.0) *
            keyLightField(clamp(p + laneNearOffset, vec2(0.0), vec2(1.0)));
        float nearShadeA = pow(
            1.0 - smoothstep(0.08, 0.96, nearEffectiveKeyA), 0.82) *
            (1.0 - smoothstep(0.965, 0.998, nearEffectiveKeyA)) * nearOwnerA;
        float nearShadeB = pow(
            1.0 - smoothstep(0.08, 0.96, nearEffectiveKeyB), 0.82) *
            (1.0 - smoothstep(0.965, 0.998, nearEffectiveKeyB)) * nearOwnerB;
        laneContinuation = max(nearShadeA, nearShadeB) *
            mix(0.52, 0.98, segmentSeed);
    }
    float densityMemory = clamp(max(
        density * mix(0.84, 1.18, localLaneSeed) +
        (groupSeed - 0.5) * 0.12,
        laneContinuation), 0.0, 1.0);
    // Preserve this same hatch action through the first owner/paper samples.
    // Reclassifying tone independently on each side of the raster edge made
    // every admitted lane lift at one shared coordinate, so the hatching and
    // Linear roots exposed the same white separator.  The short along-stroke
    // probe changes admission only; it never deposits a contour-normal line.
    // Follow one pencil action across the complete projected edge shoulder.
    // The near probe preserves narrow limbs; the far probe catches the wider
    // antialias/overshoot moat that otherwise aligns every hatch endpoint into
    // a white ruler slit. Only hatch lanes receive this memory, so it cannot
    // paint a contour-normal silhouette bar.
    vec2 joinStepNear = strokeTangent * 4.0 / resolution;
    vec2 joinStepFar = strokeTangent * 24.0 / resolution;
    vec2 joinStateNearA = sourceMaskAndKey(p - joinStepNear);
    vec2 joinStateNearB = sourceMaskAndKey(p + joinStepNear);
    vec2 joinStateFarA = sourceMaskAndKey(p - joinStepFar);
    vec2 joinStateFarB = sourceMaskAndKey(p + joinStepFar);
    float joinOwnerNearA = smoothstep(0.08, 0.72, joinStateNearA.x);
    float joinOwnerNearB = smoothstep(0.08, 0.72, joinStateNearB.x);
    float joinOwnerFarA = smoothstep(0.08, 0.72, joinStateFarA.x);
    float joinOwnerFarB = smoothstep(0.08, 0.72, joinStateFarB.x);
    float joinShadeNearA = (1.0 - clamp(lightIntensity, 0.0, 1.0) *
        toneFromMaskAndKey(joinStateNearA)) * joinOwnerNearA;
    float joinShadeNearB = (1.0 - clamp(lightIntensity, 0.0, 1.0) *
        toneFromMaskAndKey(joinStateNearB)) * joinOwnerNearB;
    float joinShadeFarA = (1.0 - clamp(lightIntensity, 0.0, 1.0) *
        toneFromMaskAndKey(joinStateFarA)) * joinOwnerFarA;
    float joinShadeFarB = (1.0 - clamp(lightIntensity, 0.0, 1.0) *
        toneFromMaskAndKey(joinStateFarB)) * joinOwnerFarB;
    float joinTransition = smoothstep(0.08, 0.72, max(
        abs(joinOwnerNearA - joinOwnerNearB),
        abs(joinOwnerFarA - joinOwnerFarB)));
    // Give every finite pencil action its own short silhouette reach. The
    // previous shared tangent probes made all parallel actions terminate at
    // the same owner coordinate. Orthogonal probes catch every edge angle;
    // seeded reach staggers the tips without depositing a contour stroke.
    float edgeActionSeed = hash11(
        lane * 97.17 + segmentIndex * 31.19 + familySeed * 5.7);
    float edgeActionReach = mix(3.0, 13.0, edgeActionSeed);
    vec2 edgeActionStepT =
        strokeTangent * edgeActionReach / resolution;
    vec2 edgeActionStepN =
        strokeNormal * edgeActionReach / resolution;
    vec2 edgeStateTA = sourceMaskAndKey(p - edgeActionStepT);
    vec2 edgeStateTB = sourceMaskAndKey(p + edgeActionStepT);
    vec2 edgeStateNA = sourceMaskAndKey(p - edgeActionStepN);
    vec2 edgeStateNB = sourceMaskAndKey(p + edgeActionStepN);
    float edgeOwnerTA = smoothstep(0.08, 0.72, edgeStateTA.x);
    float edgeOwnerTB = smoothstep(0.08, 0.72, edgeStateTB.x);
    float edgeOwnerNA = smoothstep(0.08, 0.72, edgeStateNA.x);
    float edgeOwnerNB = smoothstep(0.08, 0.72, edgeStateNB.x);
    float edgeActionTransition = smoothstep(0.08, 0.72, max(
        abs(edgeOwnerTA - edgeOwnerTB),
        abs(edgeOwnerNA - edgeOwnerNB)));
    float edgeActionShade = max(max(
        (1.0 - clamp(lightIntensity, 0.0, 1.0) *
            toneFromMaskAndKey(edgeStateTA)) * edgeOwnerTA,
        (1.0 - clamp(lightIntensity, 0.0, 1.0) *
            toneFromMaskAndKey(edgeStateTB)) * edgeOwnerTB), max(
        (1.0 - clamp(lightIntensity, 0.0, 1.0) *
            toneFromMaskAndKey(edgeStateNA)) * edgeOwnerNA,
        (1.0 - clamp(lightIntensity, 0.0, 1.0) *
            toneFromMaskAndKey(edgeStateNB)) * edgeOwnerNB));
    // Keep the extension on the same analytic straight centerline, but load
    // its pressure gradually. Correlated stroke-local noise varies graphite
    // pickup between actions without wobbling geometry or making pixel noise.
    float widthPressure = valueNoise(
        vec2(along * 0.020 + familySeed * 2.7, lane * 0.31),
        familySeed + 733.0);
    float edgeActionLoad = clamp(
        edgeActionTransition * smoothstep(0.04, 0.90, edgeActionShade) *
        mix(0.78, 1.04, widthPressure), 0.0, 1.0);
    float edgeToneMemory = max(
        max(joinShadeNearA, joinShadeNearB),
        max(joinShadeFarA, joinShadeFarB)) * joinTransition *
        mix(0.92, 1.0, segmentSeed);
    edgeToneMemory = max(edgeToneMemory,
        edgeActionShade * edgeActionLoad *
        mix(0.46, 0.78, edgeActionSeed));
    densityMemory = max(densityMemory, edgeToneMemory);
    float admissionThreshold = mix(0.07, 0.91, densityMemory);
    float admission = 1.0 - smoothstep(
        admissionThreshold, admissionThreshold + 0.13, laneSeed);
    float edgeAdmission = edgeActionLoad *
        mix(0.28, 0.58, edgeActionSeed);
    admission = 1.0 - (1.0 - admission) * (1.0 - edgeAdmission);

    // Each hatch is a finite straight hand action. Persistent group/lane/action
    // offsets keep neighboring strokes irregular without bending any single
    // centerline into a digital U or lens.
    float actionSeed = hash11(segmentIndex * 17.91 + lane * 43.07 +
                              familySeed * 3.19);
    float groupOffset = (groupSeed - 0.5) * min(0.72, spacing * 0.11);
    float laneOffset = (localLaneSeed - 0.5) * min(0.58, spacing * 0.09);
    float actionOffset = 0.0;
    float drift = groupOffset + laneOffset;
    // Pressure shapes geometry as well as opacity. The previous uniform-width
    // cells merely faded at their ends and therefore looked like transparent
    // digital dashes with identical gaps.
    float actionSpan = max(actionEnd - actionStart, 0.34);
    float attackEnd = actionStart + actionSpan * mix(0.035, 0.16,
        hash11(segmentIndex * 61.13 + lane * 7.91 + familySeed));
    float releaseStart = actionStart + actionSpan * mix(0.52, 0.90,
        hash11(segmentIndex * 29.27 + lane * 51.31 + familySeed));
    float attack = smoothstep(actionStart, attackEnd, strokeT);
    float releaseEnd = actionEnd;
    float release = 1.0 - smoothstep(releaseStart, releaseEnd, strokeT);
    // Asymmetric action-unit pressure: individual pencil traces do not press
    // and lift with mirrored timing even when their geometric span is equal.
    float pressureSkew = mix(0.72, 1.48, hash11(
        lane * 83.11 + segmentIndex * 19.73 + familySeed * 7.9));
    float segmentPressure = pow(attack, pressureSkew) *
                            pow(release, 2.05 - pressureSkew);
    float edgeActionContinuity = max(
        joinTransition, edgeActionLoad *
        mix(0.42, 0.78, edgeActionSeed));
    float edgeActionWindow = smoothstep(
        actionStart - 0.025, actionStart + 0.012, strokeT) *
        (1.0 - smoothstep(
            actionEnd - 0.012, actionEnd + 0.035, strokeT));
    strokeWindow = max(
        strokeWindow, edgeActionContinuity * edgeActionWindow);
    segmentPressure = max(segmentPressure,
        edgeActionContinuity * edgeActionWindow *
        mix(0.64, 0.90, segmentSeed));
    float pressureWidth = pow(segmentPressure, 0.52);
    float widthVariation = mix(0.62, 1.58,
        mix(groupSeed, hash11(
            lane * 19.41 + segmentIndex * 5.17 + familySeed * 53.11), 0.55));
    float formEmphasis = step(0.78, hash11(
        laneGroup * 89.17 + segmentIndex * 7.31 + familySeed * 19.0)) *
        smoothstep(0.58, 0.92, density);
    widthVariation *= mix(1.0, 2.22, formEmphasis);
    float width = halfWidth * widthVariation * mix(0.84, 1.16,
                  clamp((laneSpan - 0.66) / 0.68, 0.0, 1.0)) *
                  mix(0.72, 1.24, widthPressure) * pressureWidth;
    float edgeAA = max(0.92, fwidth(across) * 0.82);
    float distanceToLane = abs(localAcross - drift);
    float coverage = (1.0 - smoothstep(width, width + edgeAA, distanceToLane)) *
                     strokeWindow;
    // Use the same cached physical-tool atlas as the hero strokes, sampled in
    // segment coordinates. This adds continuous graphite fibers and pressure
    // breakup inside an anti-aliased analytic footprint instead of painting a
    // translucent vector line and sprinkling screen noise over it.
    float hatchAcross = (localAcross - drift) / max(width, 0.22);
    float hatchVariant = floor(hash11(
        lane * 11.37 + segmentIndex * 29.11 + familySeed * 5.7) * 4.0);
    vec2 hatchUV = vec2(
        clamp(strokeT, 0.0, 1.0),
        (hatchVariant + clamp(hatchAcross * 0.5 + 0.5, 0.0, 1.0)) * 0.25);
    float hatchDeposit = 0.0;
    if (coverage > 0.0001) {
        vec2 hatchMaterial = texture(brushTex, hatchUV).rg;
        hatchDeposit = coverage * clamp(
            hatchMaterial.r * 0.44 + hatchMaterial.g * 0.92, 0.0, 1.0);
    }

    // A minority of gestures carry a faint adjacent graphite filament. The
    // companion shares the same pressure and endpoint, making a clustered
    // hand stroke rather than a second regular hatch grid.
    float companionChance = step(
        mix(0.72, 0.38, density),
        hash11(laneGroup * 73.31 + segmentIndex * 11.07 + familySeed));
    float companionOffset = mix(1.15, 2.65, segmentSeed) *
                            (hash11(lane * 9.7 + familySeed) < 0.5 ? -1.0 : 1.0);
    float companionDistance = abs(localAcross - drift - companionOffset);
    float companion = (1.0 - smoothstep(width * 0.34,
                                         width * 0.34 + edgeAA,
                                         companionDistance)) *
                      companionChance * mix(0.46, 0.78, density) *
                      strokeWindow * segmentPressure;
    // The companion is the same finite graphite action, not an infinite
    // analytic line that stops only when it hits the support-radius border.
    vec2 companionUV = vec2(clamp(strokeT, 0.0, 1.0),
        (hatchVariant + clamp((localAcross - drift - companionOffset) /
        max(width * 0.68, 0.22) + 0.5, 0.0, 1.0)) * 0.25);
    companion *= texture(brushTex, companionUV).g;

    // Pressure is deposited as graphite contact, not a smooth gray fill.
    // Screen-fixed paper tooth and stroke-locked grain are continuous fields:
    // they soften and break pigment without displacing the stroke silhouette
    // or producing isolated pin dots.
    float slowPressure = valueNoise(
        vec2(along * 0.012 + familySeed * 5.1, lane * 0.23),
        familySeed + 719.0);
    float paperCoarse = valueNoise(pixel * 0.13 + vec2(lane * 0.07),
                                   familySeed + 887.0);
    float paperFine = valueNoise(pixel * 0.49 + vec2(lane * 0.11),
                                 familySeed + 929.0);
    float strokeGrain = valueNoise(
        vec2(along * 0.16 + familySeed * 3.1,
             (across - laneCenter) * 0.58), familySeed + 953.0);
    float graphiteContact = paperCoarse * 0.44 +
                            paperFine * 0.26 + strokeGrain * 0.30;
    float pressure = mix(
        0.42, 1.18, max(densityMemory, edgeToneMemory)) *
                     mix(0.70, 1.14, slowPressure) *
                     mix(0.48, 1.12, graphiteContact) *
                     mix(0.82, 1.12, segmentSeed);

    // Transport subject ownership along each individual graphite gesture.
    // A binary center mask (and the old two-probe approximation) makes every
    // lane terminate on the same projected contour. Four decreasing-pressure
    // samples instead describe how far this specific hand pass can continue
    // beyond the capture. Probe chains remain straight so ownership cannot
    // manufacture a curved hatch that was absent from the action centerline.
    float forwardSeed = hash11(
        lane * 41.73 + segmentIndex * 19.13 + familySeed);
    float backwardSeed = hash11(
        lane * 29.17 + segmentIndex * 37.11 + familySeed * 1.7);
    float continuationClass = step(0.56, hash11(
        lane * 73.17 + segmentIndex * 41.13 + familySeed * 5.9));
    float extensionForward = mix(
        mix(7.0, 54.0, forwardSeed * forwardSeed),
        mix(36.0, 128.0, pow(forwardSeed, 1.35)), continuationClass);
    float extensionBackward = mix(
        mix(6.0, 48.0, backwardSeed * backwardSeed),
        mix(30.0, 112.0, pow(backwardSeed, 1.35)), continuationClass);
    float terminalSideOffset = (hash11(
        lane * 67.13 + segmentIndex * 23.41 + familySeed * 3.7) - 0.5) *
        mix(1.0, 5.0, segmentSeed);
    // Only the individual pencil trajectory transports support. The old
    // shared 5/14-pixel dilation manufactured a slab around every mesh.
    float centerSupport = sourceCoverage(p);
    float transportedSupport = 0.0;
    // Interior pixels need no ownership transport. Restrict the extra mask
    // taps to the narrow capture transition where an endpoint can exist.
    if (centerSupport < 0.985) {
        vec2 forwardSide = strokeNormal * terminalSideOffset;
        vec2 backwardSide = -forwardSide;
        vec2 f1 = (strokeTangent * extensionForward * 0.18 + forwardSide) / resolution;
        vec2 f2 = (strokeTangent * extensionForward * 0.40 + forwardSide) / resolution;
        vec2 f3 = (strokeTangent * extensionForward * 0.68 + forwardSide) / resolution;
        vec2 f4 = (strokeTangent * extensionForward + forwardSide) / resolution;
        vec2 b1 = (strokeTangent * extensionBackward * 0.18 + backwardSide) / resolution;
        vec2 b2 = (strokeTangent * extensionBackward * 0.40 + backwardSide) / resolution;
        vec2 b3 = (strokeTangent * extensionBackward * 0.68 + backwardSide) / resolution;
        vec2 b4 = (strokeTangent * extensionBackward + backwardSide) / resolution;
        float forwardEnergy = sourceMask(p - f1) * 1.00 +
            sourceMask(p - f2) * 0.64 + sourceMask(p - f3) * 0.34 +
            sourceMask(p - f4) * 0.14;
        float backwardEnergy = sourceMask(p + b1) * 1.00 +
            sourceMask(p + b2) * 0.64 + sourceMask(p + b3) * 0.34 +
            sourceMask(p + b4) * 0.14;
        transportedSupport = 1.0 - exp(
            -max(forwardEnergy, backwardEnergy) *
            mix(0.58, 1.08, segmentSeed));
    }
    float support = max(centerSupport, transportedSupport);
    float releasePressure = mix(0.76, 1.24, hash11(
        lane * 53.91 + segmentIndex * 11.27 + familySeed * 2.3));
    float supportGate = pow(
        smoothstep(0.006, 0.52, support), releasePressure);
    float deposited = 1.0 - (1.0 - hatchDeposit) * (1.0 - companion);
    // Optical-density accumulation lets overlapping dark passes approach
    // opaque pencil while light pressure remains visibly granular.
    float graphiteAlpha = 1.0 - exp(
        -1.72 * deposited * pressure * mix(0.58, 1.0, segmentPressure));
    float actionCoverage=graphiteAlpha*admission*supportGate;
    if(actionCoverage>drawnLightCoverage) {
        // Lighting belongs to this finite pencil action, including its tips.
        // Sample only fixed anchors, never the pixel currently being shaded.
        vec2 best=sourceMaskAndKey(segmentAnchorUV);
        for(int i=-1;i<=1;i+=2) {
            vec2 anchor=clamp(segmentAnchorUV+strokeTangent*
                (float(i)*segmentLength*.32)/resolution,vec2(0),vec2(1));
            vec2 candidate=sourceMaskAndKey(anchor);
            if(candidate.x>best.x)best=candidate;
        }
        float handKey=clamp(best.y+(segmentSeed-.5)*.32+(groupSeed-.5)*.18,0.0,1.0);
        // Whole-mark tonal admission, not a smooth white-to-color face wash.
        float admitted=step(mix(.32,.66,localLaneSeed),handKey);
        drawnLightKey=admitted*mix(.86,1.0,segmentSeed)*clamp(lightIntensity,0.0,1.0);
        drawnLightCoverage=actionCoverage;
    }
    return actionCoverage;
}

float hatchFamily(vec2 p, vec2 flow, float spacing, float halfWidth,
                  float density, float familySeed)
{
    // A slanted pencil crosses its seed cell. Rasterize neighboring actions
    // too: the cell selects candidates, never clips the actual stroke.
    vec2 pad = vec2(144.0) / resolution;
    if (any(lessThan(p, subjectBounds.xy - pad)) ||
        any(greaterThan(p, subjectBounds.zw + pad))) return 0.0;
    vec2 tangent = normalize(flow + vec2(1e-6));
    vec2 normal = vec2(-tangent.y, tangent.x);
    vec2 earlyNearStep = tangent * 4.0 / resolution;
    vec2 earlyFarStep = tangent * 18.0 / resolution;
    vec2 earlyNearNormalStep = normal * 4.0 / resolution;
    vec2 earlyFarNormalStep = normal * 18.0 / resolution;
    float earlyEdgeTransition = smoothstep(0.08, 0.72, max(max(
        abs(sourceCoverage(p - earlyNearStep) -
            sourceCoverage(p + earlyNearStep)),
        abs(sourceCoverage(p - earlyFarStep) -
            sourceCoverage(p + earlyFarStep))), max(
        abs(sourceCoverage(p - earlyNearNormalStep) -
            sourceCoverage(p + earlyNearNormalStep)),
        abs(sourceCoverage(p - earlyFarNormalStep) -
            sourceCoverage(p + earlyFarNormalStep)))));
    if (density <= 0.0001 && earlyEdgeTransition <= 0.0001)
        return 0.0;
    density = max(density, earlyEdgeTransition * 0.18);

    float ink = 0.0;
    for (int neighbor = -2; neighbor <= 2; ++neighbor)
        ink = max(ink, hatchLane(p, flow, spacing, halfWidth,
                               density, familySeed, float(neighbor), earlyEdgeTransition));
    return ink;
}


float subjectHatching(vec2 p, vec2 flow, float shade, float contactShade)
{
    if (lineThickness <= 0.0001) return 0.0;
    float density = clamp(shade, 0.0, 1.0);
    float hatchThickness = lineThickness;
    float thicknessResponse = pow(clamp(hatchThickness, 0.0, 1.0), 0.72);
    float spacing = mix(11.6, 6.4, thicknessResponse) * 0.80;
    float width = mix(0.52, 1.18, thicknessResponse) * 1.02;
    // Match width/spacing to preserve tone; bound tiny marks for readability.
    float hatchScale=clamp(sqrt(max(subjectDrawingScale,0.0001)),0.65,2.0);
    spacing*=hatchScale;
    width*=hatchScale;
    float drawingSalt = hatchDrawingSalt();
    float hatchPatch = valueNoise(
        (p - vec2(0.5)) * vec2(4.3, 3.7), drawingSalt + 941.0);
    float primaryDensity = pow(smoothstep(
        0.10, 0.90, clamp(
            density * mix(0.78, 1.08, hatchPatch), 0.0, 1.0)), 1.42);
    primaryDensity = max(primaryDensity,
        smoothstep(0.72, 0.96, density) * mix(0.82, 1.0, hatchPatch));
    // Cross-hatching is reserved for deep shade. Midtones remain a single
    // pencil family, which prevents the subject from becoming a uniform grid.
    float crossPatch = smoothstep(0.66, 0.84, valueNoise(
        (p - vec2(0.5)) * vec2(5.1, 4.3), drawingSalt + 977.0));
    float crossDensity = smoothstep(0.60, 0.88, density) *
                         mix(0.24, 0.94, crossPatch);
    // A shaded contact admits more of the SAME nested hatch families.
    // Preserve lane placement and brush texture; no light seam.
    primaryDensity=mix(primaryDensity,1.0,contactShade*0.65);
    crossDensity=mix(crossDensity,1.0,contactShade*0.85);
    // Density alone saturates in deep shade. Load the existing contact
    // marks more heavily so their ink mass survives viewport downsampling.
    // The original irregular contact falloff confines this to mesh contacts.
    width*=1.0+0.45*contactShade;
    vec2 primaryFlow = flow;
    float primary = hatchFamily(
        p, primaryFlow, spacing, width, primaryDensity, 211.0);
    // Choose the oblique family once per drawing. Per-pixel angle fields bend
    // a lane across packet boundaries and create nested lens-like curves.
    float crossShapeSignal = hash11(drawingSalt * 0.173 + 1063.0);
    float crossFamilyShape =
        (floor(crossShapeSignal * 5.0) + 0.5) / 5.0;
    float crossTurnSignal = hash11(drawingSalt * 0.219 + 1091.0);
    float crossAngleOffset =
        (floor(crossTurnSignal * 5.0) - 2.0) * 0.045;
    vec2 crossFlow = rotateVector(
        primaryFlow, mix(0.80, 1.19, crossFamilyShape) + crossAngleOffset);
    float crossing = hatchFamily(
        p, crossFlow, spacing * 1.14,
        width * mix(0.78, 1.02, 1.0 - crossFamilyShape),
        crossDensity, 431.0);
    return 1.0 - (1.0 - primary) * (1.0 - crossing);
}

float subjectContourField(vec2 p, vec2 flow)
{
    vec2 pixel = p * resolution;
    float structureMacro = valueNoise(
        pixel * 0.015 + vec2(salt * 0.17), salt + 1511.0);
    float structureMeso = valueNoise(
        pixel * 0.061 + vec2(salt * 0.29), salt + 1567.0);
    float structureAdmission = smoothstep(
        0.43, 0.70, structureMacro * 0.72 + structureMeso * 0.28);
    float handStructure = looseToneStructure(p);
    // The displaced construction sample is the only structural guide. There
    // is deliberately no exact mesh/tone floor capable of reconstructing a
    // perfect projected square around a front-facing limb.
    float structureGuide = handStructure;
    float structureDeposit = structureGuide * structureAdmission *
        mix(0.08, 0.38, structureMacro) *
        mix(0.48, 1.0, structureMeso);
    // Treat the captured mesh edge as a loose construction guide. A
    // correlated hand pass samples it with normal displacement and angle
    // correction; it never traces the exact projected silhouette.
    // Hatching is accumulated after this field, so its graphite naturally
    // draws across and over the broken guide rather than stopping beneath it.
    vec2 guideNormal = vec2(-flow.y, flow.x);
    float guideTurn =
        (valueNoise(pixel * 0.0087, salt + 1601.0) - 0.5) * 0.24 +
        (valueNoise(pixel * 0.0271, salt + 1627.0) - 0.5) * 0.08;
    float guideDriftA =
        (valueNoise(pixel * 0.0093, salt + 1657.0) - 0.5) * 7.0 +
        (valueNoise(pixel * 0.0361, salt + 1669.0) - 0.5) * 2.2;
    vec2 guideFlowA = rotateVector(flow, guideTurn);
    float guideA = directionalEdgeEnergy(
        p + guideNormal * guideDriftA / resolution, guideFlowA);
    float guidePressure = mix(0.010, 0.020,
        valueNoise(pixel * 0.0181, salt + 1693.0));
    // A restrained correction pass sits slightly off the first construction
    // line. It shares the same macro gesture but not its exact pressure or
    // angle, which removes the single perfect rectangle without producing a
    // noisy multi-outline effect.
    float guideDriftB = guideDriftA * 0.34 +
        (valueNoise(pixel * 0.0247, salt + 1721.0) - 0.5) * 3.4;
    float guideTurnB = guideTurn * 0.46 +
        (valueNoise(pixel * 0.0163, salt + 1747.0) - 0.5) * 0.11;
    float guideB = directionalEdgeEnergy(
        p + guideNormal * guideDriftB / resolution,
        rotateVector(flow, guideTurnB));
    float redrawPatch = smoothstep(0.42, 0.72,
        valueNoise(pixel * 0.0129, salt + 1777.0));
    float guide = guideA * guidePressure +
                  guideB * guidePressure * redrawPatch * 0.28;
    float directionalWrap = directionalEdgeEnergy(p, flow) *
        mix(0.030, 0.18, lineThickness) *
        mix(0.42, 1.0, pow(max(strength, 0.0), 0.58));
    return guide + structureDeposit + directionalWrap;
}

vec2 backgroundDepthTarget(vec2 anchor, float depthSeed);
vec2 backgroundDepthAnchor(vec2 anchor, float depthSeed);
vec2 backgroundDepthKeepLength(vec2 anchor, vec2 flow, float strokeLength);
float backgroundDepthWidth(float depthSeed);

// Compare each mark against the nearest captured surface at this pixel.
// Ownership G is shared, precision-preserving projected depth: smaller is
// nearer. Object-average depth cannot resolve a bent limb or sloping torso.
float backgroundLayerVisibility(vec2 p, float lineSeed, vec2 flow)
{
    float layer = clamp(backgroundLayer, 0.0, 1.0);
    if (layer <= 0.0) return 0.0;
    if (layer >= 1.0) return 1.0;
    vec2 surface = visibleObjectState(p);
    if (surface.x < 0.5) return 0.0;
    // Every family keeps a stable small depth bias, while broad paper-space
    // variation breaks up a mechanically straight cut across the subject.
    float bias = (hash11(lineSeed * 119.7 + backgroundSalt * 0.071) - 0.5) * 0.042;
    bias += (valueNoise(p * vec2(13.0, 11.0), backgroundSalt + 587.0) - 0.5) * 0.018;
    float plane = clamp(backgroundPlaneDepth + bias, 0.001, 0.999);
    float feather = 0.015;
    float visible = smoothstep(plane - feather, plane + feather, surface.y);
    if (visible < 0.001) return 0.0;
    // Fade an exposed ribbon before either end crosses a nearer mesh.
    // The probe is in authored output pixels, so preview resolution does not
    // alter the apparent taper or the final stroke population.
    vec2 stepUV = normalize(flow + vec2(1.0e-7)) * 7.0 / max(resolution, vec2(1.0));
    vec2 ahead = visibleObjectState(p + stepUV);
    vec2 behind = visibleObjectState(p - stepUV);
    float aheadVisible = ahead.x < 0.5 ? 1.0 :
        smoothstep(plane - feather, plane + feather, ahead.y);
    float behindVisible = behind.x < 0.5 ? 1.0 :
        smoothstep(plane - feather, plane + feather, behind.y);
    return visible * mix(0.20, 1.0, min(aheadVisible, behindVisible));
}

vec4 backgroundSingleRecord(int index,int channel)
{
    float amount=clamp(backgroundIntensity*2.0,0.0,1.0);
    float shortEdge=max(1.0,min(resolution.x,resolution.y));
    vec2 authored=backgroundAuthoredFlow();
    float tunnelAuthority=backgroundTunnelAuthority();
    vec2 backgroundFocus=backgroundFocusPoint();
    float planarEdgeLoad=background2DEdgeLoad();
    float planarReachLimit=shortEdge*mix(.16,.95,pow(planarEdgeLoad,.78));
        float fi = float(index);
        float seed = hash11(fi * 83.17 + backgroundSalt * 0.073 + 4001.0);
        float lineDepth = 1.0-hash11(fi * 271.73 + backgroundSalt * 0.019 + 4073.0);
        vec2 anchor = vec2(
            hash11(fi * 127.13 + backgroundSalt * 0.041 + 4013.0),
            hash11(fi * 179.17 + backgroundSalt * 0.037 + 4027.0));
        vec2 anchorMotion = backgroundVelocityAt(anchor);
        float lagClass = hash11(
            fi * 197.31 + backgroundSalt * 0.033 + 4039.0);
        float followRatio = mix(0.72, 0.96, lagClass);
        float familyMotionAuthority = clamp(
            backgroundMotionInfluence, 0.0, 1.0);
        float temporalAge = max(backgroundFrame - 1.0, 0.0);
        vec2 familyAdvection = anchorMotion * temporalAge *
            followRatio * familyMotionAuthority;
        vec2 screenAnchor = anchor;
        anchor = mod(anchor + familyAdvection + vec2(0.08), vec2(1.16)) -
            vec2(0.08);
        vec2 perspectiveTarget = backgroundPerspectiveTarget(anchor);
        if (tunnelAuthority > 0.5) {
            // Thin and loaded passes use the SAME shell generator. The old
            // thin pass kept random screen anchors and aperture-rail angles,
            // producing a separate distant section behind the ring packets.
            float cluster = floor(fi / 3.0);
            float member = mod(fi, 3.0) - 1.0;
            float familySeed = hash11(fi * 37.17 + backgroundSalt * 0.127 + 3203.0);
            float depthSeed = hash11(cluster * 167.31 + backgroundSalt * 0.047 + 3391.0);
            float travel = 0.02 + 0.88 * fract(depthSeed + member / 3.0);
            lineDepth = travel;
            anchor = backgroundDepthAnchor(screenAnchor, travel);
            vec2 depthMotion = backgroundVelocityAt(anchor) * followRatio *
                familyMotionAuthority * 2.0;
            anchor += depthMotion * backgroundDepthWidth(travel);
            perspectiveTarget = backgroundDepthTarget(anchor, travel);
        }
        float initialTargetDistance = length((perspectiveTarget - anchor) * resolution);
        if (tunnelAuthority > 0.5 && initialTargetDistance <= 2.0) return vec4(0.0);
        vec2 perspectiveFlow = safeDirection(
            (perspectiveTarget-anchor)*resolution, authored);
        vec2 planarFlow = background2DPerspectiveFlow(anchor, authored);
        vec2 flow = safeDirection(mix(
            planarFlow, perspectiveFlow, tunnelAuthority), authored);
        float sourceTravel = max(0.0, dot(
            (anchor - backgroundFocus) * resolution, flow));
        float travelT = tunnelAuthority * (1.0 - smoothstep(
            shortEdge * 0.04, shortEdge * 0.92, sourceTravel));
        float rangeGradient = mix(
            background2DRangeGradient(anchor, flow), 1.0, tunnelAuthority);
        rangeGradient *= mix(
            background2DDepthScale(anchor, flow), 1.0, tunnelAuthority);
        float localAmount = amount * pow(clamp(rangeGradient, 0.0, 1.0), 0.62) *
            mix(1.0, 0.40, travelT);
        // Birth probability falls much faster than brush pressure. This
        // produces a crowded graphite pickup near the source and genuinely
        // sparse construction marks at the travel end, instead of a uniform
        // field whose only change is opacity.
        // The fine construction layer obeys the same cyan reach envelope as
        // the packet families. Near center it remains sparse and local; it
        // cannot leave faint full-frame lines behind after the heavy packets
        // have correctly contracted.
        float birthProbability = mix(0.0, 0.98,
            pow(clamp(localAmount, 0.0, 1.0), 0.68)) *
            mix(0.004, 1.0, mix(planarEdgeLoad, 1.0, tunnelAuthority));
        if (seed > birthProbability) return vec4(0.0);
        vec2 normal = vec2(-flow.y, flow.x);
        float lengthSeed = hash11(fi * 211.31 + backgroundSalt * 0.029 + 4049.0);
        float strokeLength = shortEdge * mix(0.15, 0.40, lengthSeed);
        // Length belongs to the brush family, not the perspective aperture.
        float projectedCameraSpeed = abs(dot(anchorMotion, flow)) /
            max(velocityScale, 1.0e-6);
        float transverseCameraSpeed = abs(dot(anchorMotion, normal)) /
            max(velocityScale, 1.0e-6);
        strokeLength *= clamp(
            1.0 + familyMotionAuthority * (
                min(projectedCameraSpeed, 1.60) * 0.82 -
                min(transverseCameraSpeed, 1.60) * 0.24),
            0.68, 2.20);
        strokeLength = mix(
            min(strokeLength, planarReachLimit * 1.14),
            strokeLength, tunnelAuthority);
        strokeLength *= mix(
            background2DArcLengthScale(anchor), 1.0, tunnelAuthority);
        float planarFrameReach = background2DFrameReach(
            anchor * resolution, flow);
        strokeLength = mix(
            min(strokeLength,
                planarFrameReach * mix(0.94, 0.985, lengthSeed)),
            strokeLength, tunnelAuthority);
        if (tunnelAuthority > 0.5)
            anchor = backgroundDepthKeepLength(anchor, flow, strokeLength);
        float heel = strokeLength * mix(0.08, 0.30,
            hash11(fi * 239.11 + backgroundSalt * 0.023 + 4057.0));

    vec2 localCamera=backgroundVelocityAt(anchor);
    float localMotionStrength=smoothstep(.015,.82,length(localCamera)/max(velocityScale,1.e-6));
    vec2 cameraAxis=alignLineAxis(safeDirection(localCamera,flow),flow);
    float cameraTurn=atan(flow.x*cameraAxis.y-flow.y*cameraAxis.x,dot(flow,cameraAxis));
    float bend=clamp(backgroundMotionInfluence,0.,1.)*(1.-tunnelAuthority);
    float curveAngle=clamp(cameraTurn*.20,-.14,.14)*smoothstep(.035,.34,localMotionStrength);
    float cameraCurveScale=tan(curveAngle)*strokeLength*.34*bend;
    cameraCurveScale*=1.-background2DFlipAmount()*smoothSpreadResponse(abs(backgroundDepthInfluence));
    float width=mix(.16,.43,hash11(fi*271.73+backgroundSalt*.019+4073.));
    width*=mix(background2DDepthScale(anchor,flow),1.,tunnelAuthority);
    if(channel==0)return vec4(anchor,flow);
    if(channel==1)return vec4(strokeLength,heel,1.0,lineDepth);
    if(channel==2)return vec4(fi,seed,travelT,width);
    return vec4(cameraCurveScale,0.,0.,0.);
}

float backgroundSingleGraphiteLayer(vec2 p, float amount, out float frontLayer)
{
    float result = 0.0;
    frontLayer = 0.0;
    float shortEdge = max(1.0, min(resolution.x, resolution.y));
    vec2 geometryP = backgroundFlatPaper(p);
    vec2 authored = backgroundAuthoredFlow();
    float tunnelAuthority = backgroundTunnelAuthority();
    float depthConvergence = backgroundDepthConvergence();
    vec2 backgroundFocus = backgroundFocusPoint();
    float centeredBackground = tunnelAuthority *
        (1.0 - smoothstep(0.045, 0.22,
            length((backgroundFocus - vec2(0.5)) * 2.0)));
    float planarEdgeLoad = background2DEdgeLoad();
    float planarReachLimit = shortEdge * mix(
        0.16, 0.95, pow(planarEdgeLoad, 0.78));
    for (int index = 0; index < 288; ++index) {
        vec4 single0=texelFetch(backgroundFamilyTex,ivec2(index,7),0);
        vec4 single1=texelFetch(backgroundFamilyTex,ivec2(index,8),0);
        if(single1.z<.5)continue;
        vec2 anchor=single0.xy,flow=single0.zw,normal=vec2(-flow.y,flow.x);
        float strokeLength=single1.x,heel=single1.y,lineDepth=single1.w;
        vec2 delta = (geometryP - anchor) * resolution;
        float along = dot(delta, flow);
        float across = dot(delta, normal);
        float strokeT = (along + heel) / max(strokeLength + heel, 1.0);
        // Exact zero-support window: skip curve, camera and noise evaluation
        // without dropping any family or changing the visible stroke.
        if (strokeT <= -0.015 || strokeT >= 1.015) continue;
        vec2 spreadState = background2DBowedPaperState(geometryP, anchor);
        vec4 single2=texelFetch(backgroundFamilyTex,ivec2(index,9),0);
        float fi=single2.x,seed=single2.y,travelT=single2.z,width=single2.w;
        float cameraCurveScale=texelFetch(backgroundFamilyTex,ivec2(index,10),0).x;
        float curveT=clamp(strokeT,0.,1.);
        float curveEnvelope=4.*curveT*(1.-curveT);
        float cameraCurveSlope = cameraCurveScale * 4.0 *
            (1.0 - 2.0 * curveT) / max(strokeLength + heel, 1.0);
        across = curveNormalDistance(
            across - spreadState.x - cameraCurveScale * curveEnvelope,
            spreadState.y + cameraCurveSlope);
        float body = 1.0 - smoothstep(width, width + 0.82, abs(across));
        float window = smoothstep(-0.015, 0.035, strokeT) *
            (1.0 - smoothstep(0.91, 1.015, strokeT));
        float endFade = mix(1.0, 0.055,
            smoothstep(0.16, 1.0, clamp(strokeT, 0.0, 1.0)));
        if (body <= 0.0 || window <= 0.0) continue;
        float tooth = mix(0.62, 1.0, valueNoise(
            vec2(along * 0.052, across * 0.37),
            seed + backgroundSalt + 4091.0));
        // These are graphite construction lines, not miniature ink swipes.
        // Density creates the dark source value; frequency and pressure both
        // fall away down-trail.
        float stroke = body * window * endFade * tooth *
            background2DTerminalGate(geometryP, anchor) *
            mix(0.035, 0.18, amount) * mix(1.0, 0.28, travelT);
        result = 1.0 - (1.0 - result) * (1.0 - stroke);
        float selection=stroke > 0.001 ?
            backgroundLayerVisibility(p,lineDepth,flow) : 0.0;
        frontLayer=1.0-(1.0-frontLayer)*(1.0-stroke*selection);
    }
    float paperOnly = 1.0 - smoothstep(0.015, 0.28, sourceCoverage(p));
    frontLayer *= 1.0-paperOnly;
    return result * paperOnly;
}

float backgroundDepthWidth(float depthSeed)
{
    // Material perspective is depth-driven, never driven by aperture.
    return 1.0 / (1.0 + 0.33125 * mix(0.2, 6.0, depthSeed));
}

vec2 backgroundDepthAnchor(vec2 anchor, float depthSeed)
{
    // FOV-like aperture changes the transverse DEPTH layout, not the segment
    // length. Near families retain full-frame coverage; far lanes open wide
    // at zero and concentrate into a narrow cone at one. Cyan stays fixed.
    float aperture = mix(1.65, 0.38, backgroundDepthConvergence());
    float depth = clamp(depthSeed, 0.0, 1.0);
    float scale = mix(1.0, aperture, depth * depth);
    return backgroundFocus + (anchor - backgroundFocus) * scale;
}

vec2 backgroundDepthTarget(vec2 anchor, float depthSeed)
{
    // Retain the original FOV path projection. Python inversely calibrates
    // the input center so this projected focus lands on the visible cyan pin.
    float openness = 1.0 - backgroundDepthConvergence();
    return backgroundFocus + (backgroundFocus - vec2(0.5)) * (6.0 * openness);
}

vec2 backgroundDepthKeepLength(vec2 anchor, vec2 flow, float strokeLength)
{
    vec2 target = backgroundDepthTarget(anchor, 0.0);
    vec2 relative = (anchor - target) * resolution;
    float distanceToPin = length(relative);
    // Low Spread is an open tunnel, not a star of tips touching cyan.
    // Keep each finite mark's length: move its root upstream to leave the
    // aperture clear. Length-dependent staggering avoids a perfect cut ring.
    float openness = 1.0 - backgroundDepthConvergence();
    vec2 sector = relative / max(distanceToPin, 1.0);
    // Unequal broad lobes plus stable per-length staggering, not a circular
    // stencil. Perturbations vanish continuously as Spread reaches one.
    float lobes = 0.82 + 0.24 * sector.x + 0.19 * sector.y +
        0.22 * (sector.x * sector.x - sector.y * sector.y) +
        0.18 * sector.x * sector.y;
    float shortEdge = min(resolution.x, resolution.y);
    float stagger = mix(0.38, 1.30,
        hash11(strokeLength / max(shortEdge, 1.0) * 213.71 + 73.19));
    float clearance = max(2.0, shortEdge *
        (0.004 + 0.24 * openness * lobes * stagger));
    // Relocate a close root upstream without shortening its finite stroke or
    // letting it cross the focus. Short and long marks keep independent ends.
    float retreat = max(0.0, strokeLength + clearance - distanceToPin);
    return anchor - flow * retreat / max(resolution, vec2(1.0));
}

// Full-float records shared by all pixels of a background brush family.
// The mask pass computes these in a 288 x 7 staging target once per draw.
vec4 backgroundFamilyRecord(int index, int channel)
{
    float amount=clamp(backgroundIntensity*2.0,0.0,1.0);
    float shortEdge=min(resolution.x,resolution.y);
            float fi = float(index);
            float cluster = floor(fi / 3.0);
            float member = mod(fi, 3.0) - 1.0;
            float familySeed = hash11(
                fi * 37.17 + backgroundSalt * 0.127 + 3203.0);
            float clusterSeed = hash11(
                cluster * 71.31 + backgroundSalt * 0.091 + 3229.0);
            vec2 anchor = vec2(
                hash11(cluster * 97.13 + backgroundSalt * 0.071 + 3251.0),
                hash11(cluster * 131.71 + backgroundSalt * 0.053 + 3271.0));
            // Let families enter from outside the crop instead of beginning
            // at one artificial full-frame boundary.
            anchor = mix(vec2(-0.015), vec2(1.015), anchor);

            vec2 anchorCentered = anchor - vec2(0.5);
            vec2 anchorAffine = vec2(
                backgroundAffineX.x + backgroundAffineX.y * anchorCentered.x +
                    backgroundAffineX.z * anchorCentered.y,
                backgroundAffineY.x + backgroundAffineY.y * anchorCentered.x +
                    backgroundAffineY.z * anchorCentered.y);
            vec2 anchorMotion = mix(
                backgroundMotion, anchorAffine,
                min(backgroundAffineX.w, backgroundAffineY.w));
            vec2 capturedBackgroundMotion = texture(
                backgroundMotionTex, clamp(anchor, vec2(0.0), vec2(1.0))).rg;
            float environmentSurface = texture(
                floorTex, clamp(anchor, vec2(0.0), vec2(1.0))).r;
            anchorMotion = mix(
                anchorMotion, capturedBackgroundMotion,
                smoothstep(0.06, 0.72, environmentSurface));
            vec2 authored = backgroundAuthoredFlow();
            float motionStrength = smoothstep(
                0.015, 0.82,
                length(anchorMotion) / max(velocityScale, 1.0e-6));
            float lagClass = hash11(
                cluster * 211.73 + backgroundSalt * 0.061 + 3283.0);
            float followRatio = mix(0.72, 0.96, lagClass);
            float familyMotionAuthority = clamp(
                backgroundMotionInfluence, 0.0, 1.0);
            float temporalAge = max(backgroundFrame - 1.0, 0.0);
            vec2 familyAdvection = anchorMotion * temporalAge *
                followRatio * familyMotionAuthority;
            // Stable families move at a bounded fraction of camera travel and
            // wrap outside the crop. No family is re-rolled or left fixed.
            vec2 screenAnchor = anchor;
            vec2 wrappedAnchor = mod(
                anchor + familyAdvection + vec2(0.08), vec2(1.16));
            anchor = wrappedAnchor - vec2(0.08);
            float tunnelAuthority = backgroundTunnelAuthority();
            float depthConvergence = backgroundDepthConvergence();
            vec2 backgroundFocus = backgroundFocusPoint();
            // Moving the cyan pin changes visibility and direction only.
            // Never relocate stable family anchors toward a shared edge
            // corridor: that destroys transverse spacing and causes broad
            // packets to smash together as the pin approaches the crop.
            float centeredBackground = tunnelAuthority *
                (1.0 - smoothstep(0.045, 0.22,
                    length((backgroundFocus - vec2(0.5)) * 2.0)));
            float depthSeed = hash11(
                cluster * 167.31 + backgroundSalt * 0.047 + 3391.0);
            // Reuse the three hand passes as staggered depth samples of one
            // channel, not three coincident marks and an empty far corridor.
            float ringTravel = 0.02 + 0.88 * fract(depthSeed + member / 3.0);
            vec2 ringEnd = anchor;
            if (tunnelAuthority > 0.5) {
                anchor = backgroundDepthAnchor(screenAnchor, ringTravel);
                vec2 depthMotion = backgroundVelocityAt(anchor) * followRatio *
                    familyMotionAuthority * 2.0;
                anchor += depthMotion * backgroundDepthWidth(ringTravel);
                ringEnd = backgroundDepthTarget(anchor, ringTravel);
            }
            vec2 perspectiveTarget = tunnelAuthority > 0.5
                ? ringEnd : backgroundPerspectiveTarget(anchor);
            float initialTargetDistance = length((perspectiveTarget - anchor) * resolution);
            if (tunnelAuthority > 0.5 && initialTargetDistance <= 2.0) return vec4(0.0);
            vec2 perspectiveFlow = safeDirection((perspectiveTarget - anchor) * resolution, authored);
            vec2 planarFlow = background2DPerspectiveFlow(anchor, authored);
            vec2 awayFromPin = safeDirection(mix(
                planarFlow, perspectiveFlow, tunnelAuthority), authored);
            vec2 cameraFlow = alignLineAxis(
                safeDirection(anchorMotion, awayFromPin), awayFromPin);
            if (dot(cameraFlow, awayFromPin) < 0.0) cameraFlow = -cameraFlow;
            vec2 relativeSubjectMotion = subjectMotion - backgroundMotion;
            float centeredMotionResponse = smoothstep(
                0.015, 1.10,
                length(relativeSubjectMotion) / max(velocityScale, 1.0e-6)) *
                clamp(motionCurveInfluence, 0.0, 1.0);
            vec2 centeredMotionAxis = alignLineAxis(
                safeDirection(relativeSubjectMotion, authored), authored);
            vec2 centeredChannel = blendDirection(
                authored, centeredMotionAxis, centeredMotionResponse * 0.62);
            vec2 centeredPinAxis = blendDirection(
                awayFromPin, centeredChannel, 0.54);
            vec2 pinAxis = safeDirection(mix(
                awayFromPin, centeredPinAxis, centeredBackground), authored);
            float cameraResponse = motionStrength *
                clamp(backgroundMotionInfluence, 0.0, 1.0) *
                mix(0.30, 0.26, tunnelAuthority);
            vec2 guidedFlow = blendDirection(
                pinAxis, cameraFlow, cameraResponse);
            vec2 familyFlow = blendDirection(
                awayFromPin, guidedFlow, 0.82 * tunnelAuthority);
            familyFlow = blendDirection(
                familyFlow, perspectiveFlow,
                tunnelAuthority * mix(0.76, 0.91, 1.0 - cameraResponse));
            familyFlow = alignLineAxis(familyFlow, awayFromPin);
            if (dot(familyFlow, awayFromPin) < 0.0) familyFlow = -familyFlow;
            float directedTravel = max(0.0, dot(
                (anchor - backgroundFocus) * resolution, familyFlow));
            float sourceDistance = length(
                (anchor - backgroundFocus) * resolution);
            float familyTravel = mix(
                directedTravel, sourceDistance, tunnelAuthority);
            float planarGradient = background2DRangeGradient(
                anchor, familyFlow);
            planarGradient *= background2DDepthScale(anchor, familyFlow);
            float depthGradient = smoothstep(
                min(resolution.x, resolution.y) * 0.018,
                min(resolution.x, resolution.y) * 0.72,
                familyTravel);
            float familyGradient = mix(
                planarGradient, depthGradient, tunnelAuthority);
            float planarEdgeLoad = background2DEdgeLoad();
            float edgeFamilyLoad = mix(
                planarEdgeLoad, 1.0, tunnelAuthority);
            float familyAmount = amount *
                pow(clamp(familyGradient, 0.0, 1.0), 0.72);
            float familyBirth = 0.985 *
                pow(clamp(familyGradient, 0.0, 1.0), 0.56) *
                mix(0.42, 1.0, sqrt(amount));
            familyAmount *= mix(0.03, 1.0, edgeFamilyLoad);
            familyBirth *= mix(0.008, 1.0, edgeFamilyLoad);
            // A valid 3D focus owns density anywhere in the frame. Keeping
            // this boost tied to centeredBackground made the same tunnel
            // nearly disappear as soon as the artist moved its pin toward a
            // side radius, even though its shell geometry remained active.
            familyAmount = mix(familyAmount,
                max(familyAmount, amount * 0.78), tunnelAuthority);
            familyBirth = mix(familyBirth,
                max(familyBirth, 0.96 * sqrt(amount)), tunnelAuthority);
            if (clusterSeed > familyBirth) return vec4(0.0);
            vec2 familyNormal = vec2(-familyFlow.y, familyFlow.x);
            anchor += familyNormal * member * mix(3.2, 8.8, familySeed) /
                max(resolution, vec2(1.0));
            // Reproject the displaced member too; sharing its cluster's old
            // target offsets the inferred vanishing point of nearby packets.
            vec2 memberTarget = tunnelAuthority > 0.5
                ? backgroundDepthTarget(anchor, ringTravel) : perspectiveTarget;
            vec2 memberFlow = safeDirection((memberTarget - anchor) * resolution, familyFlow);
            familyFlow = blendDirection(
                familyFlow, memberFlow, tunnelAuthority);
            familyFlow = alignLineAxis(familyFlow, awayFromPin);
            if (dot(familyFlow, awayFromPin) < 0.0) familyFlow = -familyFlow;
            familyNormal = vec2(-familyFlow.y, familyFlow.x);

            float lengthSeed = hash11(
                fi * 157.11 + backgroundSalt * 0.043 + 3299.0);
            // Keep fine graphite construction marks mixed with the broader
            // dry-brush packets instead of replacing either morphology.
            float centerThinOnly = (1.0 - tunnelAuthority) *
                (1.0 - smoothstep(0.08, 0.44, planarEdgeLoad));
            float thinClass = max(step(0.38, familySeed), centerThinOnly);
            float strokeLength = shortEdge * mix(0.050, 0.18, lengthSeed) *
                mix(1.0, mix(1.85, 2.75, lengthSeed), centeredBackground);
            // Perspective redistributes anchors, never scales brush length.
            float broadClass = (1.0 - step(0.24, clusterSeed)) *
                smoothstep(0.20, 0.76, amount);
            broadClass *= mix(
                smoothstep(0.16, 0.68, planarEdgeLoad),
                1.0, tunnelAuthority);
            strokeLength *= mix(0.82, 1.16, broadClass) *
                mix(0.82, 1.08, 1.0 - abs(member));
            strokeLength = mix(strokeLength,
                shortEdge * mix(0.040, 0.125, lengthSeed), thinClass);
            float planarReachLimit = shortEdge * mix(
                0.16, 0.95, pow(planarEdgeLoad, 0.78));
            float broadReach = planarReachLimit * mix(0.82, 1.0, lengthSeed);
            strokeLength = mix(
                min(strokeLength, broadReach), strokeLength,
                tunnelAuthority);
            float projectedCameraSpeed = abs(dot(
                anchorMotion, familyFlow)) / max(velocityScale, 1.0e-6);
            float transverseCameraSpeed = abs(dot(
                anchorMotion, familyNormal)) / max(velocityScale, 1.0e-6);
            float directionalLengthScale = clamp(
                1.0 + familyMotionAuthority * (
                    min(projectedCameraSpeed, 1.60) * 0.82 -
                    min(transverseCameraSpeed, 1.60) * 0.24),
                0.68, 2.20);
            strokeLength *= directionalLengthScale;
            // No spread-dependent endpoint clamp: keep the full hand stroke.
            strokeLength *= mix(
                background2DArcLengthScale(anchor), 1.0, tunnelAuthority);
            float planarFrameReach = background2DFrameReach(
                anchor * resolution, familyFlow);
            strokeLength = mix(
                min(strokeLength,
                    planarFrameReach * mix(0.94, 0.985, lengthSeed)),
                strokeLength, tunnelAuthority);
            float heel = strokeLength * mix(0.18, 0.48,
                hash11(fi * 181.37 + backgroundSalt * 0.039 + 3313.0));
            float signedCameraTravel = dot(
                anchorMotion, familyFlow) / max(velocityScale, 1.0e-6);
            float cameraTrail = motionStrength * familyMotionAuthority *
                mix(0.45, 1.35, lagClass) * mix(0.72, 1.18, broadClass);
            heel *= 1.0 + cameraTrail *
                mix(0.72, 1.34, step(signedCameraTravel, 0.0));

            if (tunnelAuthority > 0.5)
                anchor = backgroundDepthKeepLength(anchor, familyFlow, strokeLength);

    if(channel==0)return vec4(anchor,familyFlow);
    if(channel==1)return vec4(strokeLength,heel,1.0,0.0);
    if(channel==2)return vec4(fi,cluster,member,familySeed);
    if(channel==3)return vec4(motionStrength,tunnelAuthority,backgroundFocus);
    if(channel==4)return vec4(depthSeed,ringTravel,familyGradient,planarEdgeLoad);
    if(channel==5)return vec4(familyAmount,familyNormal,lengthSeed);
    if(channel==6)return vec4(thinClass,broadClass,planarReachLimit,planarFrameReach);
            vec2 probe = clamp(
                anchor + familyFlow * strokeLength / max(resolution, vec2(1.0)),
                vec2(-0.15), vec2(1.15));
            vec2 probeCentered = probe - vec2(0.5);
            vec2 probeMotion = vec2(
                backgroundAffineX.x + backgroundAffineX.y * probeCentered.x +
                    backgroundAffineX.z * probeCentered.y,
                backgroundAffineY.x + backgroundAffineY.y * probeCentered.x +
                    backgroundAffineY.z * probeCentered.y);
            vec2 probeFlow = safeDirection(probeMotion, familyFlow);
            probeFlow = alignLineAxis(probeFlow, familyFlow);
            float capturedTurn = atan(
                familyFlow.x * probeFlow.y - familyFlow.y * probeFlow.x,
                dot(familyFlow, probeFlow));
            float motionAuthority = smoothstep(0.035, 0.42, motionStrength);
            float turn = clamp(capturedTurn, -0.30, 0.30) *
                motionAuthority *
                clamp(backgroundMotionInfluence, 0.0, 1.0);
            turn *= mix(0.72, 0.42, tunnelAuthority);
            float cameraCurveScale = tan(turn) * strokeLength * 0.25;
            cameraCurveScale *= 1.0 - background2DFlipAmount() *
                smoothSpreadResponse(abs(backgroundDepthInfluence));
            float widthSeed = hash11(fi * 211.17 + backgroundSalt * 0.031 + 3343.0);
            float halfWidth = mix(1.10, 3.40, widthSeed) *
                mix(0.78, 1.12, amount);
            halfWidth *= mix(mix(0.72, 1.30, depthSeed),
                max(0.15, 1.65 * backgroundDepthWidth(ringTravel)), tunnelAuthority);
            halfWidth = mix(halfWidth, mix(3.2, 5.8, widthSeed), broadClass);
            halfWidth = mix(halfWidth, mix(0.52, 1.08, widthSeed), thinClass);
            halfWidth *= mix(
                background2DDepthScale(anchor, familyFlow),
                1.0, tunnelAuthority);
            halfWidth *= mix(
                mix(0.72, 1.08, planarEdgeLoad),
                1.0, tunnelAuthority);
    return vec4(turn,cameraCurveScale,widthSeed,halfWidth);
}

float backgroundStrokeLayer(vec2 p, out float frontLayer)
{
    frontLayer = 0.0;
    float amount = clamp(backgroundIntensity * 2.0, 0.0, 1.0);
    if (amount <= 0.0001) return 0.0;
    float inkLoad = 1.0 + 0.85 * max(0.0, backgroundIntensity * 2.0 - 1.0);
    vec2 geometryP = backgroundFlatPaper(p);
    float shortEdge = min(resolution.x, resolution.y);
    float familyInk = 0.0;
    {
        float accumulated = 0.0;
        float frontAccumulated = 0.0;
        const int BACKGROUND_FAMILY_COUNT = 288;
        for (int index = 0; index < BACKGROUND_FAMILY_COUNT; ++index) {
            vec4 family0=texelFetch(backgroundFamilyTex,ivec2(index,0),0);
            vec4 family1=texelFetch(backgroundFamilyTex,ivec2(index,1),0);
            if(family1.z<.5)continue;
            vec2 anchor=family0.xy, familyFlow=family0.zw;
            float strokeLength=family1.x, heel=family1.y;
            vec2 familyNormal=vec2(-familyFlow.y,familyFlow.x);
            float tunnelAuthority=backgroundTunnelAuthority();
            vec2 delta = (geometryP - anchor) * resolution;
            float along = dot(delta, familyFlow);
            float rawAcross = dot(delta, familyNormal);
            // Conservative longitudinal support in both modes, including
            // graphite and heels. Transverse rejection remains 3D-only.
            // Avoid evaluating brush noise for pixels no family can reach.
            if (along < -4.0 * (strokeLength + heel) - 8.0 ||
                along > 4.0 * (strokeLength + heel) + 8.0 ||
                (tunnelAuthority > 0.5 &&
                 abs(rawAcross) > 24.0 + strokeLength * 0.35)) continue;

            vec4 family2=texelFetch(backgroundFamilyTex,ivec2(index,2),0);
            vec4 family3=texelFetch(backgroundFamilyTex,ivec2(index,3),0);
            vec4 family4=texelFetch(backgroundFamilyTex,ivec2(index,4),0);
            vec4 family5=texelFetch(backgroundFamilyTex,ivec2(index,5),0);
            vec4 family6=texelFetch(backgroundFamilyTex,ivec2(index,6),0);
            float fi=family2.x, cluster=family2.y, member=family2.z, familySeed=family2.w;
            float motionStrength=family3.x;
            vec2 backgroundFocus=family3.zw;
            float depthSeed=family4.x, ringTravel=family4.y, familyGradient=family4.z, planarEdgeLoad=family4.w;
            float familyAmount=family5.x, lengthSeed=family5.w;
            float thinClass=family6.x, broadClass=family6.y, planarReachLimit=family6.z, planarFrameReach=family6.w;

            // Sample how the affine camera field turns farther along this
            // gesture. Its signed angular change supplies one restrained arc,
            // so rolls/orbits curve coherently without per-pixel lens rings.
            vec4 family7=texelFetch(backgroundFamilyTex,ivec2(index,11),0);
            float turn=family7.x;
            float curveT = clamp((along + heel) /
                max(strokeLength + heel, 1.0), 0.0, 1.0);
            float curveEnvelope = 4.0 * curveT * (1.0 - curveT);
            float strokeT = (along + heel) /
                max(strokeLength + heel, 1.0);
            float cameraCurveScale=family7.y;
            float cameraCurveSlope = cameraCurveScale * 4.0 *
                (1.0 - 2.0 * curveT) /
                max(strokeLength + heel, 1.0);
            vec2 spreadState = background2DBowedPaperState(
                geometryP, anchor);
            float across = curveNormalDistance(
                rawAcross - spreadState.x -
                    cameraCurveScale * curveEnvelope,
                spreadState.y + cameraCurveSlope);
            float widthSeed=family7.z, halfWidth=family7.w;
            // The flipped cyan-facing end receives the same pointed release
            // as the ordinary far tip, never an inverse-width compensation.
            float brushT = mix(strokeT, 1.0 - strokeT,
                background2DFlipAmount() * (1.0 - tunnelAuthority));
            float stroke = brushRibbonDeposit(
                across, halfWidth, brushT,
                0.72 / max(strokeLength, 1.0), familySeed + 3371.0);
            stroke *= background2DTerminalGate(geometryP, anchor);
            float graphiteOffset = member * mix(1.2, 3.8, widthSeed) +
                (hash11(fi * 239.17 + backgroundSalt * 0.029 + 3361.0) - 0.5) * 2.4;
            float graphiteLength = strokeLength * mix(1.85, 3.45, widthSeed);
            graphiteLength = mix(
                min(graphiteLength, planarReachLimit * 1.14),
                graphiteLength, tunnelAuthority);
            // Graphite keeps its own finite length at every Spread value.
            graphiteLength *= mix(
                background2DArcLengthScale(anchor), 1.0, tunnelAuthority);
            graphiteLength = mix(
                min(graphiteLength,
                    planarFrameReach * mix(0.94, 0.985, lengthSeed)),
                graphiteLength, tunnelAuthority);
            float graphiteHeel = heel * mix(0.68, 0.92, widthSeed);
            // Shift a too-close graphite root back instead of shortening it
            // or drawing its tip through cyan onto the opposite side.
            float graphiteAlong = along;
            if (tunnelAuthority > 0.5) {
                vec2 graphiteAnchor = backgroundDepthKeepLength(
                    anchor, familyFlow, graphiteLength);
                graphiteAlong = dot((geometryP - graphiteAnchor) * resolution, familyFlow);
            }
            float graphiteT = (graphiteAlong + graphiteHeel) /
                max(graphiteLength + graphiteHeel, 1.0);
            float graphiteCurveT = clamp(graphiteT, 0.0, 1.0);
            float graphiteCurveEnvelope =
                4.0 * graphiteCurveT * (1.0 - graphiteCurveT);
            float graphiteCameraScale = tan(turn) * graphiteLength * 0.25;
            float graphiteCameraSlope = graphiteCameraScale * 4.0 *
                (1.0 - 2.0 * graphiteCurveT) /
                max(graphiteLength + graphiteHeel, 1.0);
            float graphiteAcross = curveNormalDistance(
                rawAcross - spreadState.x -
                    graphiteCameraScale * graphiteCurveEnvelope,
                spreadState.y + graphiteCameraSlope);
            float graphiteWidth = mix(0.32, 0.68, widthSeed) * mix(
                sqrt(max(background2DDepthScale(anchor, familyFlow), 0.0)),
                1.0, tunnelAuthority);
            float graphiteTerminalGate = 1.0 - smoothstep(
                0.935, 1.025, graphiteT);
            float graphite = filamentSwipeDeposit(
                graphiteAcross + graphiteOffset,
                graphiteWidth, graphiteT,
                familySeed + 3367.0) * thinClass *
                (1.0 - step(0.5, abs(member))) * graphiteTerminalGate *
                background2DTerminalGate(geometryP, anchor);
            float sampleTravel = max(0.0, dot(
                (geometryP - backgroundFocus) * resolution, familyFlow));
            float sampleDistance = length(
                (geometryP - backgroundFocus) * resolution);
            float samplePlanarGradient = background2DRangeGradient(
                geometryP, familyFlow);
            samplePlanarGradient *= background2DDepthScale(
                geometryP, familyFlow);
            float sampleDepthGradient = smoothstep(
                min(resolution.x, resolution.y) * 0.025,
                min(resolution.x, resolution.y) * 0.66,
                mix(sampleTravel, sampleDistance, tunnelAuthority));
            float sampleGradient = mix(
                samplePlanarGradient, sampleDepthGradient, tunnelAuthority);
            float familyPressureFloor =
                pow(clamp(familyGradient, 0.0, 1.0), 0.74) *
                mix(0.72, 0.86, tunnelAuthority);
            float spatialPressure = max(
                pow(clamp(sampleGradient, 0.0, 1.0), 0.74),
                familyPressureFloor);
            // Perspective reduces far widths, not their existence. A second
            // distance-to-pin fade erased the back of the depth corridor.
            spatialPressure = mix(spatialPressure,
                max(spatialPressure, 0.62), tunnelAuthority);
            float pressure = mix(0.10, 0.78, familyAmount) *
                mix(0.72, 1.0, widthSeed);
            pressure = mix(pressure, mix(0.14, 0.82, familyAmount), broadClass);
            pressure *= mix(1.0, 1.34, tunnelAuthority);
            pressure *= mix(0.76, 1.18, depthSeed);
            float shadeVariation = mix(0.90, 1.08, hash11(
                cluster * 359.17 + backgroundSalt * 0.013 + 3517.0));
            pressure *= mix(
                mix(0.56, 1.12, planarEdgeLoad) * shadeVariation,
                1.0, tunnelAuthority);
            pressure *= spatialPressure;
            float familyDeposit = 1.0 -
                (1.0 - stroke * pressure) *
                (1.0 - graphite * mix(0.22, 0.74, familyAmount) *
                    spatialPressure);
            familyDeposit=clamp(familyDeposit,0.0,1.0);
            accumulated = 1.0 - (1.0 - accumulated) *
                (1.0 - familyDeposit);
            float lineDepth=mix(1.0-depthSeed,ringTravel,tunnelAuthority);
            float frontSelection=familyDeposit > 0.001 ?
                backgroundLayerVisibility(p,lineDepth,familyFlow) : 0.0;
            frontAccumulated=1.0-(1.0-frontAccumulated)*(1.0-familyDeposit*frontSelection);
        }

        float blocker = sourceCoverage(p);
        float paperOnly = 1.0 - smoothstep(0.015, 0.28, blocker);
        familyInk = clamp(accumulated * paperOnly, 0.0, 1.0);
        frontLayer = clamp(frontAccumulated * (1.0 - paperOnly), 0.0, 1.0);
    }

    float singleFront;
    float singles = backgroundSingleGraphiteLayer(p, amount, singleFront);
    frontLayer=1.0-pow(clamp((1.0-frontLayer)*(1.0-singleFront),0.0,1.0),inkLoad);
    return 1.0-pow(clamp((1.0-familyInk)*(1.0-singles),0.0,1.0),inkLoad);

    vec2 centered = p - vec2(0.5);
    vec2 affineMotion = vec2(
        backgroundAffineX.x + backgroundAffineX.y * centered.x +
            backgroundAffineX.z * centered.y,
        backgroundAffineY.x + backgroundAffineY.y * centered.x +
            backgroundAffineY.z * centered.y);
    vec2 capturedMotion = texture(
        backgroundMotionTex, clamp(p, vec2(0.0), vec2(1.0))).rg;
    float environmentSurface = texture(
        floorTex, clamp(p, vec2(0.0), vec2(1.0))).r;
    float affineConfidence = min(backgroundAffineX.w, backgroundAffineY.w);
    vec2 cameraField = mix(
        mix(backgroundMotion, affineMotion, affineConfidence),
        capturedMotion, smoothstep(0.06, 0.72, environmentSurface));

    float motionStrength = smoothstep(
        0.015, 0.82, length(cameraField) / max(velocityScale, 1.0e-6));
    vec2 authored = backgroundAuthoredFlow();
    vec2 awayFromPin = safeDirection(
        vec2(0.5) - flowSource.xy, authored);
    vec2 globalCameraFlow = alignLineAxis(
        safeDirection(backgroundMotion, awayFromPin), awayFromPin);
    if (dot(globalCameraFlow, awayFromPin) < 0.0)
        globalCameraFlow = -globalCameraFlow;
    vec2 flow = authored;
    flow = alignLineAxis(flow, awayFromPin);
    if (dot(flow, awayFromPin) < 0.0) flow = -flow;
    vec2 normal = vec2(-flow.y, flow.x);
    vec2 pixel = (p - vec2(0.5)) * resolution;
    float along = dot(pixel, flow);
    float across = dot(pixel, normal);

    float laneDrift = (valueNoise(
        vec2(along * 0.0021, salt * 0.11), salt + 3203.0) - 0.5) * 1.2;
    float fineSpacing = mix(13.0, 18.0,
        hash11(salt * 0.13 + 3221.0));
    float fineLane = floor((across + laneDrift) / fineSpacing);
    float fineAcross = abs(fract((across + laneDrift) / fineSpacing) - 0.5) *
        fineSpacing;
    float fineSeed = hash11(fineLane * 17.13 + salt * 0.071 + 3251.0);
    float fineWidth = mix(0.34, 0.92, fineSeed) * mix(0.72, 1.22, amount);
    float fineAA = max(fwidth(fineAcross), 0.70);
    float fineLine = 1.0 - smoothstep(
        fineWidth - fineAA, fineWidth + fineAA, fineAcross);
    float fineCluster = smoothstep(0.30, 0.70,
        valueNoise(vec2(fineLane * 0.091, along * 0.0067), salt + 3271.0));
    float fineBreak = smoothstep(0.24, 0.60,
        valueNoise(vec2(along * 0.021, fineLane * 0.173), salt + 3299.0));
    // Keep the compatibility path's sub-pixel construction lines continuous.
    fineLine *= mix(0.82, 1.0, fineCluster) *
        mix(0.88, 1.0, fineBreak);

    float mediumSpacing = mix(32.0, 50.0, hash11(
        floor(across / 12.0) * 9.31 + salt * 0.11 + 3313.0));
    float mediumLane = floor((across - laneDrift * 0.43) / mediumSpacing);
    float mediumAcross = abs(
        fract((across - laneDrift * 0.43) / mediumSpacing) - 0.5) *
        mediumSpacing;
    float mediumSeed = hash11(mediumLane * 29.17 + salt * 0.097 + 3343.0);
    float mediumWidth = mix(0.72, 1.85, mediumSeed) *
        mix(0.55, 1.0, amount);
    float mediumAA = max(fwidth(mediumAcross), 0.76);
    float mediumLine = 1.0 - smoothstep(
        mediumWidth - mediumAA, mediumWidth + mediumAA, mediumAcross);
    float mediumSegment = smoothstep(0.46, 0.72,
        valueNoise(vec2(along * 0.0103, mediumLane * 0.137), salt + 3371.0));
    mediumLine *= mix(0.34, 1.0, mediumSegment) *
        smoothstep(0.18, 0.58, amount);

    float accentSpacing = 92.0;
    float accentLane = floor((across + laneDrift * 0.21) / accentSpacing);
    float accentAcross = abs(
        fract((across + laneDrift * 0.21) / accentSpacing) - 0.5) *
        accentSpacing;
    float accentSeed = hash11(accentLane * 41.03 + salt * 0.083 + 3407.0);
    float accentWidth = mix(1.25, 3.10, accentSeed);
    float accentAA = max(fwidth(accentAcross), 0.82);
    float accentLine = 1.0 - smoothstep(
        accentWidth - accentAA, accentWidth + accentAA, accentAcross);
    float accentSegment = smoothstep(0.59, 0.76,
        valueNoise(vec2(along * 0.0051, accentLane * 0.19), salt + 3433.0));
    accentLine *= mix(0.28, 1.0, accentSegment) * motionStrength *
        smoothstep(0.48, 0.88, amount);

    float backgroundInk = 1.0 - (1.0 - fineLine * mix(0.14, 0.34, amount)) *
        (1.0 - mediumLine * mix(0.12, 0.30, amount)) *
        (1.0 - accentLine * mix(0.14, 0.32, amount));

    vec2 blockerStep = vec2(0.0);
    float blocker = sourceCoverage(p);
    blocker = max(blocker, sourceCoverage(p + vec2(blockerStep.x, 0.0)));
    blocker = max(blocker, sourceCoverage(p - vec2(blockerStep.x, 0.0)));
    blocker = max(blocker, sourceCoverage(p + vec2(0.0, blockerStep.y)));
    blocker = max(blocker, sourceCoverage(p - vec2(0.0, blockerStep.y)));
    float paperOnly = 1.0 - smoothstep(0.015, 0.28, blocker);
    float packetA = smoothstep(0.34, 0.72,
        valueNoise(vec2(along * 0.0037 + fineLane * 0.071,
                        fineLane * 0.113), salt + 3491.0));
    float packetB = smoothstep(0.40, 0.76,
        valueNoise(vec2(along * 0.0061 - mediumLane * 0.053,
                        mediumLane * 0.149), salt + 3517.0));
    float graphitePackets = fineLine * packetA * mix(0.16, 0.31, amount);
    graphitePackets = 1.0 - (1.0 - graphitePackets) *
        (1.0 - mediumLine * packetB * mix(0.13, 0.27, amount));
    graphitePackets = 1.0 - (1.0 - graphitePackets) *
        (1.0 - accentLine * packetA * packetB * mix(0.12, 0.24, amount));
    graphitePackets *= paperOnly;
    return clamp(1.0 - (1.0 - familyInk) *
                 (1.0 - graphitePackets), 0.0, 1.0);
}

float physicalBandCoverage(float coverage, vec2 p, vec2 flow,
                           float seedOffset)
{
    float amount = clamp(bandTransition, 0.0, 1.0);
    // In combined mode the Band control belongs exclusively to Radial.
    if (amount <= 0.0001 || coverage <= 0.0001 ||
        (hybridMode != 0 && mode == 0) ||
        ((mode == 1 || linearReady > 0.5) && seedOffset == 0.0)) return coverage;
    float shortEdge = max(min(resolution.x, resolution.y), 1.0);
    vec2 pixel = (p - vec2(0.5)) * resolution;
    vec2 axis = safeDirection(flow, vec2(cos(angle), sin(angle)));
    float along = dot(pixel, axis);
    float across = dot(pixel, vec2(-axis.y, axis.x));
    vec2 delta = (p - focus) * resolution;
    float radius = length(delta);
    float theta = atan(delta.y, delta.x) - radialTwirlOffset(radius);
    float response = pow(amount, 0.75);
    float irregular = pow(amount, 1.25);
    float owner = visibleObjectState(p).x;
    if (mode == 0 && linearReady > 0.5) {
        vec4 stroke = texture(linearStrokeTex, p);
        if (stroke.r > 0.001) owner = stroke.a;
    }
    if (mode == 1 && owner < 0.5) {
        // Trace the ray toward its emitter to find its captured depth owner.
        for (int probe = 1; probe <= 4; ++probe) {
            float candidate = visibleObjectState(mix(p, focus, float(probe)/5.0)).x;
            if (candidate > 0.5) {owner=candidate;break;}
        }
    }
    float depth = 0.5;
    if (owner >= 0.5 && ownerCount > 0) {
        int index = clamp(int(owner+0.5)-1,0,ownerCount-1);
        depth = clamp(texelFetch(ownerBoundsTex,ivec2(index,7),0).x*0.5+0.5,0.0,1.0);
    }
    float period = shortEdge * mix(0.43, 0.13, response) * mix(1.25,0.78,depth);
    float laneCoordinate;
    float wave;
    if (mode == 1) {
        along = radius;
        // Integer angular frequencies close the seam, including under Twirl.
        vec2 circle = vec2(cos(theta),sin(theta));
        float exposure = along / period;
        wave = (valueNoise(circle*2.7+vec2(exposure*.73),salt+251.)-.5)*.31 +
               (valueNoise(circle*8.3+vec2(exposure*.41),salt+269.)-.5)*.12;
        float laneCount = 1024.0;
        laneCoordinate = fract(theta / 6.28318531 + 0.5) * laneCount;
    } else {
        wave = (valueNoise(vec2(across / shortEdge * 6.0, along / period*.71),
                           salt + seedOffset + 251.0) - 0.5) * 0.26;
        laneCoordinate = across / max(1.6, shortEdge * 0.0022);
    }
    float lane = floor(laneCoordinate);
    float lateral = abs(fract(laneCoordinate) - 0.5) * 2.0;
    float laneSeed = hash11(lane * 41.73 + salt * 0.071 + seedOffset);
    float coordinate = along / period + wave * mix(0.7,3.8,irregular) + (depth-.5)*.38;
    // Correlated bundle peaks plus independently staggered fine ends.
    coordinate += (valueNoise(vec2(lane*.055,along/period*.19),salt+417.)-.5)*irregular*1.3;
    coordinate += (laneSeed-.5)*mix(.04,.52,irregular);
    float cell = floor(coordinate);
    float pressure = 1.0;
    // Jittered intervals vary in both spacing and width; inspect neighbours
    // so shifted gaps remain continuous across cell boundaries.
    for (int j=-1;j<=1;++j) {
        float k=cell+float(j);
        float event=hash11(k*39.7+salt*.083+seedOffset);
        float center=k+.5+(event-.5)*irregular*.65;
        float gap=mix(.004,.20,response)*mix(.42,1.60,event);
        float tip=mix(.06,.31,hash11(lane*73.31+k*19.17+salt*.083));
        pressure=min(pressure,clamp((abs(coordinate-center)-gap)/tip,0.0,1.0));
    }
    float width=pressure*mix(1.0,.28,irregular);
    float laneAA=max(fwidth(laneCoordinate)*.45,.035);
    float gate=(1.0-smoothstep(width-laneAA,width+laneAA,lateral))*smoothstep(0.0,.06,pressure);
    return coverage*mix(1.0,gate,smoothstep(0.0,.07,amount));
}

vec2 impactField(vec2 p, out float mask, out float tone, out float lightCarrier)
{
    mask = cohesiveCoverage(p);
    vec2 authoredSubjectFlow = mode == 1
        ? vec2(cos(angle), sin(angle)) : baseFlow(p);
    vec2 relativeDrawingMotion = subjectMotion - backgroundMotion;
    float drawingMotionResponse = smoothstep(
        0.015, 1.10,
        length(relativeDrawingMotion) / max(velocityScale, 1.0e-6)) *
        clamp(motionCurveInfluence, 0.0, 1.0);
    vec2 drawingMotionAxis = alignLineAxis(
        safeDirection(relativeDrawingMotion, authoredSubjectFlow),
        authoredSubjectFlow);
    vec2 drawingChannel = blendDirection(
        authoredSubjectFlow, drawingMotionAxis, drawingMotionResponse * 0.62);
    vec2 drawingNormal = vec2(-drawingChannel.y, drawingChannel.x);
    vec2 capturedNormalXY = sourceSurfaceNormalXY(p);
    float capturedNormalZ = sqrt(max(
        0.0, 1.0 - min(dot(capturedNormalXY, capturedNormalXY), 1.0)));
    vec2 subjectPixel = (p - vec2(0.5)) * resolution;
    float faceWarpMacro = valueNoise(
        subjectPixel / 74.0, salt + 4201.0) - 0.5;
    float faceWarpMeso = valueNoise(
        subjectPixel / 27.0, salt + 4219.0) - 0.5;
    float faceWarpPixels = (faceWarpMacro * 8.5 + faceWarpMeso * 3.2) *
        (mode == 1 ? 0.0 : 1.0);
    vec2 drawingDisplacement = drawingChannel * faceWarpPixels +
        drawingNormal * faceWarpMeso * 2.2;
    vec2 drawingP = clamp(p + drawingDisplacement /
        max(resolution, vec2(1.0)), vec2(0.0), vec2(1.0));
    // Hatching and form strokes are evaluated in the displaced drawing
    // coordinate. Carry subject ownership through the same swept lookup so
    // the illuminated substrate reaches the generated face instead of
    // stopping at the undisplaced capture and exposing a white slit. The
    // midpoint closes the narrow lane between the two silhouettes without a
    // generic dilation into unrelated paper.
    float displacedCoverage = cohesiveCoverage(drawingP);
    float sweptCoverage = cohesiveCoverage(mix(p, drawingP, 0.5));
    mask = max(mask, max(displacedCoverage, sweptCoverage));
    tone = sourceTone(drawingP);
    float keyLight = keyLightField(drawingP);
    // Quantize smooth 3D Lambert shading into two restrained anime tone
    // bands. Narrow smoothsteps anti-alias each boundary without restoring a
    // Blender-like continuous gradient across rounded heads and limbs.
    float keyAA = max(fwidth(keyLight) * 1.30, 0.025);
    float stylizedKey = stylizedKeyAt(drawingP, keyAA);
    // No visible light means dense blackish pencil shade. Increasing visible
    // light removes nested hatch lanes only from light-facing tone bands;
    // shadows remain drawn rather than becoming smooth 3D gray gradients.
    float drawnShade = 1.0 - clamp(lightIntensity, 0.0, 1.0) * stylizedKey;
    // A single hero mark keeps the authored composition frame. Subject
    // construction and hatching instead use the captured normal field below;
    // moving the light therefore changes tone without steering the drawing.
    vec2 compositionFlow = baseFlow(p);
    float structureEnergy;
    vec2 contourFlow = toneGuidedFlow(p, structureEnergy);
    // The pin may be a point emitter, but hatching is made from finite pencil
    // actions, not implicit polar coordinates around that point. Start every
    // action family from one authored axis; hatchFamily then samples form and
    // aerodynamic steering once at each action anchor. This preserves the
    // centered 3D trail while preventing concentric U/lens hatches.
    vec2 hatchAnchor = vec2(cos(angle), sin(angle));
    if (mode == 1 || hybridMode != 0) {
        float owner = visibleObjectState(drawingP).x;
        vec2 anchor = (subjectBounds.xy + subjectBounds.zw) * 0.5;
        if (owner > 0.5 && ownerCount > 0) {
            int index = clamp(int(owner + 0.5)-1, 0, ownerCount-1);
            vec4 bounds = texelFetch(ownerBoundsTex, ivec2(index,0),0);
            anchor = (bounds.xy + bounds.zw) * 0.5;
        }
        vec2 towardFocus = safeDirection((focus-anchor)*resolution,hatchAnchor);
        hatchAnchor = blendDirection(hatchAnchor,towardFocus,
                                     mode == 1 ? 0.92 : 0.58);
    }
    float hatchPacketGate;
    float hatchFormEnergy;
    vec2 hatchFlow = hatchPacketFlow(
        p, hatchAnchor, hatchPacketGate, hatchFormEnergy);

    float continuousKey = clamp(keyLight +
        (valueNoise((p - vec2(0.5)) * vec2(4.7, 4.1), salt + 1171.0) - 0.5) *
        0.040, 0.0, 1.0);
    float effectiveKey = clamp(lightIntensity, 0.0, 1.0) * continuousKey;
    float hatchShade = pow(1.0 - smoothstep(0.08, 0.96, effectiveKey), 0.82);
    float cleanHighlight = smoothstep(0.965, 0.998, effectiveKey);
    hatchShade *= 1.0 - cleanHighlight;
    float heroActive = (mode != 2 && strength > 0.0001 &&
                        lineThickness > 0.0001) ? 1.0 : 0.0;
    float ribbons = 0.0;
    float rootBlend = 0.0;
    float edgeHatching = 0.0;
    if (heroActive > 0.5) {
        if (mode == 0) {
            float objectRear = 0.0;
            float objectFront = 0.0;
            // Pin position never selects a different stroke system.
            // The fallback supports old captures without world geometry only.
            if (linearReady > 0.5) {
                vec2 strokePigment = texture(linearStrokeTex, drawingP).rg;
                // Repair a narrow uncovered lane between loaded strokes on
                // the SAME visible surface. Bilateral support keeps this off
                // silhouettes, mesh separations and open paper trails; the
                // sampled pigment retains the existing brush texture.
                vec2 own=visibleObjectState(drawingP);
                if(own.x>=0.5 && strokePigment.r<0.08) {
                    vec2 across=vec2(-compositionFlow.y,compositionFlow.x);
                    across/=max(length(across),0.00001);
                    vec2 offset=across*(min(resolution.x,resolution.y)*16.0/1080.0)/resolution;
                    vec2 left=visibleObjectState(drawingP-offset);
                    vec2 right=visibleObjectState(drawingP+offset);
                    if(sameVisibleObject(own.x,left.x)>0.5 && sameVisibleObject(own.x,right.x)>0.5) {
                        float bridge=min(texture(linearStrokeTex,drawingP-offset).r,
                                         texture(linearStrokeTex,drawingP+offset).r);
                        strokePigment.r=max(strokePigment.r,bridge*smoothstep(0.12,0.20,bridge));
                    }
                }
                objectFront = strokePigment.r;
                rootBlend = smoothstep(0.035, 0.18, strokePigment.g);
                // Darken existing loaded pigment, not empty brush channels.
                // The mask's zero support and faint terminal fibers survive.
                objectFront = mix(objectFront, max(objectFront, 0.40),
                                  smoothstep(0.08, 0.18, objectFront));
                objectRear = objectFront;
            } else {
                projectedOwnerFireField(p, compositionFlow, objectFront, objectRear);
            }
            // Finite exterior owner packets replace the periodic side-lane
            // lattice, which printed barcode marks on unrelated lit parts.
            float paperGesture = max(objectFront, objectRear);
            float selectedDepth = mix(
                objectFront, objectRear, castBehindAmount());
            float ownedCoverage = cohesiveCoverage(p);
            float ownedSurface = smoothstep(
                0.18, 0.86, ownedCoverage);
            ribbons = mix(paperGesture, selectedDepth, ownedSurface);

            // Grain belongs to brushRibbonDeposit's stroke-local coordinates.
            // A second screen-aligned atlas imprinted shared bands across
            // unrelated strokes. Keep a spatially uniform contact gain only.
            ribbons *= 0.88;
        }
        else {
            ribbons = radialRibbonField(p);
            float ownedSurface = smoothstep(0.18, 0.86, cohesiveCoverage(p));
            vec2 focusRay = safeDirection(
                (p - focus) * resolution, vec2(cos(angle), sin(angle)));
            float channelPattern = smoothstep(0.54, 0.88, valueNoise(
                vec2(atan(focusRay.y, focusRay.x) * 5.3,
                     length((p - focus) * resolution) * 0.0041),
                salt + 2897.0));
            float rearChannel = mix(0.035, 0.24, channelPattern);
            float frontChannel = 1.0;
            float surfaceChannel = mix(
                frontChannel, rearChannel, castBehindAmount());
            ribbons *= mix(1.0, surfaceChannel, ownedSurface);
        }
    }
    // Continuous contour tracing reconnects adjacent bevels into lens/ring
    // distortions. Character construction now comes only from finite hatch
    // actions and the pressure-shaped hero families.
    float darkContact=smoothstep(0.72,0.94,hatchShade);
    float contactHatching=contactHatchWeight(drawingP);
    // Change local shade only; the original hatch families, spacing,
    // pressure and brush sampling remain unchanged.
    hatchShade=max(hatchShade,max(contactHatching,sourceCoverage(drawingP)*.36));
    float contour = 0.0;
    float ink = physicalBandCoverage(
        max(contour, ribbons), p, compositionFlow, 0.0);
    float surfaceHatching = subjectHatching(
        drawingP, hatchFlow, hatchShade, darkContact*contactHatching) * hatchPacketGate;
    // Darken the EXISTING pencil marks at depth contacts, including when
    // shade already admits the complete hatch set. No new lanes or texture.
    if(contactHatching>0.0)
        surfaceHatching=1.0-pow(max(0.0,1.0-surfaceHatching),1.0+1.25*contactHatching);
    if (mode == 1) {
        float pocketOwnership = 1.0 - castBehindAmount();
        surfaceHatching *= mix(1.0,
            radialCoreGate((p - focus) * resolution), pocketOwnership);
    }
    float outlineTone = mix(0.34, 1.0, hatchShade);
    float outlineInk = subjectContourField(drawingP, hatchFlow) *
        mix(0.34, 0.86, hatchShade);
    // Surface and inter-limb hatching provide the construction drawing. The
    // sampled contour guide is deliberately excluded: even at low opacity its
    // finite dashes stacked into a barcode along straight Roblox part edges.
    float hatchField = 1.0 - (1.0 - surfaceHatching) *
        (1.0 - edgeHatching * 0.72);
    if (mode == 1) {
        float protectedCenter = radialCoreGate((p - focus) * resolution);
        float pocketOwnership = 1.0 - castBehindAmount();
        hatchField *= mix(1.0, protectedCenter, pocketOwnership);
    }

    // Erode the colored-light carrier to the opaque subject interior. Light
    // must not occupy the fractional silhouette pixels later owned by pigment
    // AA, which was the source of the pale rim around dark strokes.
    // Preserve antialiased edge ownership instead of shrinking the light to
    // the high-confidence interior. The compositor still decides whether a
    // composition mode may spill beyond this generated face.
    float subjectInterior = smoothstep(0.08, 0.72, mask);
    // Preserve the captured radiometric key. Thresholding a wash multiplied
    // by hatch texture turned mesh interiors into unrelated light islands.
    lightCarrier = subjectInterior * clamp(keyLight, 0.0, 1.0) *
        clamp(lightIntensity,0.0,1.0);
    // Fade construction into the loaded root on its own visible support.
    // Empty paper and occluded roots cannot erase the subject drawing.
    hatchField *= 1.0 - rootBlend * smoothstep(0.25, 0.80, ink);
    lightCarrier *= 1.0 - rootBlend;
    return clamp(vec2(ink, hatchField), 0.0, 1.0);
}

void main()
{
    if(layerOnly==5){
        fragColor=radialSeedRecord(int(gl_FragCoord.x),int(gl_FragCoord.y));
        return;
    }
    if(layerOnly==4){
        int channel=int(gl_FragCoord.y);
        fragColor=(channel<7 || channel==11) ? backgroundFamilyRecord(int(gl_FragCoord.x),channel==11 ? 7 : channel)
                            : backgroundSingleRecord(int(gl_FragCoord.x),channel-7);
        return;
    }
    float mask, tone, lightCarrier;
    vec2 fields;
    if (layerOnly == 1) {
        mask = cohesiveCoverage(uv);
        tone = sourceTone(uv);
        lightCarrier = 0.0;
        float radialLayer = radialRibbonField(uv);
        // Keep the compatibility path identical to the primary Hybrid Band
        // contract: layer-only Radial strokes receive the authored cut too.
        radialLayer = physicalBandCoverage(
            radialLayer, uv, baseFlow(uv), 0.0);
        float ownedSurface = smoothstep(0.18, 0.86, mask);
        radialLayer *= mix(
            1.0, 1.0 - ownedSurface, castBehindAmount());
        // Carry the foreground emitter pocket into the Hybrid compositor.
        // It is negative-space ownership, not a solid white paint layer.
        mask = (1.0 - castBehindAmount()) *
            (1.0 - radialCoreGate((uv - focus) * resolution));
        lightCarrier = 0.0;
        // A negative A sentinel identifies this one radial-only intermediate
        // to impact_layers.frag. The compositor outputs Linear's normal tone,
        // so the marker cannot leak into later background composites.
        tone = -1.0;
        fields = vec2(radialLayer, 0.0);
    }
    else if (layerOnly == 0) {
        fields = impactField(uv, mask, tone, lightCarrier);
    }
    else {
        mask = cohesiveCoverage(uv);
        tone = sourceTone(uv);
        lightCarrier = 0.0;
        fields = vec2(0.0);
    }
    float field = fields.x;
    float hatchField = fields.y;
    float backgroundFrontField = 0.0;
    float backgroundField = backgroundStrokeLayer(uv, backgroundFrontField);
    vec2 backgroundFlow = backgroundAuthoredFlow();
    backgroundField = physicalBandCoverage(
        backgroundField, uv, backgroundFlow, 53.0);
    backgroundFrontField = physicalBandCoverage(
        backgroundFrontField, uv, backgroundFlow, 59.0);

    // Rig layers contribute only the background marks in front of their
    // captured surface. The shared paper layer already draws the rest.
    if (backgroundSubjectOnly != 0) backgroundField = 0.0;

    if (radialEnabled != 0) {
        // Every active Radial composition owns a clear emitter pocket in the
        // background field. Cast Behind changes subject ownership only; both
        // front and rear emitters still mask background-line pigment.
        float coreGate = radialCoreGate((uv - focus) * resolution);
        backgroundField *= coreGate;
        backgroundFrontField *= coreGate;
    }
    field = 1.0 - (1.0 - backgroundField) * (1.0 - field);
    field = 1.0 - (1.0 - backgroundFrontField) * (1.0 - field);
    // Atlas deposition already resolves pressure into coverage. A low print
    // floor preserves graphite strands instead of thresholding them away.
    float fieldAA = clamp(fwidth(field) * 1.10, 0.012, 0.28);
    float printThreshold = mix(0.075, 0.035,
                               clamp(contrast, 0.0, 1.0));
    float baseInk = smoothstep(printThreshold - fieldAA,
                               printThreshold + fieldAA, field);
    // Reconstruct the tone marks independently so their derivatives cannot
    // soften or brighten a pre-existing opaque impact stroke. This preserves
    // pigment ownership while still giving every hatch its own sub-pixel AA.
    float hatchAA = clamp(fwidth(hatchField), 0.010, 0.24);
    float hatchEdge = smoothstep(0.012, 0.012 + hatchAA, hatchField);
    float hatchInk = clamp(hatchField * 1.12, 0.0, 1.0) * hatchEdge;
    float centerInk = 1.0 - (1.0 - baseInk) * (1.0 - hatchInk);
    // This smoothstep is the sole final edge reconstruction. A second
    // pressure-based opacity veil created a visible gray fringe around the
    // already anti-aliased pigment boundary.
    // G stores the light carrier, B the rig mask, and A the captured key tone.
    // These channels are internal data; exported opacity remains unchanged.
    float backgroundOwner = smoothstep(0.012, 0.18, backgroundField) *
        (1.0 - smoothstep(0.015, 0.28, mask));
    backgroundOwner = max(backgroundOwner, smoothstep(0.012, 0.18, backgroundFrontField));
    lightCarrier=0.0; // Linear/radial hero pigment is not subject lighting.
    if(drawnLightCoverage>.005 && hatchInk>baseInk) {
        lightCarrier=drawnLightKey;
        backgroundOwner=0.0;
    }
    // Match the primary shader's optical family contract on OpenGL.
    tone = 0.0;
    // Isolated BG marks keep their pigment/optical owner over a mesh too.
    // Depth clipping already decided their visibility upstream.
    if (layerOnly == 2 || layerOnly == 3) backgroundOwner = 1.0;
    if (backgroundOwner > .0001) tone = backgroundSpace3D > 0 ? -3.0 : -2.0;
    else if (mode == 1 && field > hatchField) tone = -1.0;
    fragColor = vec4(centerInk,
        backgroundOwner > 0.0001 ? -backgroundOwner : lightCarrier,
        mask, tone);
}
