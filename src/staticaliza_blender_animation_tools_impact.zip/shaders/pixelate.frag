uniform sampler2D colorTex;
uniform sampler2D impactTex;
uniform sampler2D shapeMaskTex;
uniform vec2 resolution;
uniform float pixelate;
uniform float pixelSize;

in vec2 uv;
out vec4 fragColor;

void main()
{
    // Pixelation is a deterministic sampling grid in output-pixel space. The
    // cell grows continuously from one pixel, so zero is an exact bypass and
    // the effect composes cleanly before aberration and bloom.
    float backgroundOwner = clamp(-texture(impactTex, uv).g, 0.0, 1.0);
    vec2 shapeData = texture(shapeMaskTex, uv).rg;
    float shapeCoverage = shapeData.g;
    float shapeInfluence = shapeCoverage > 0.0001
        ? clamp(shapeData.r / shapeCoverage, 0.0, 1.0) : 1.0;
    float globalPixelate = clamp(pixelate, 0.0, 1.0);
    // Shape influence scales the pixel size itself.  Do not cross-fade the
    // blocked result over the clean source: that leaves the original shape
    // visibly underneath and reads as two layers rather than weaker pixels.
    // Probe the full-grid cell as well as the current pixel. This makes the
    // shape boundary participate in the block grid: a star can expand/erase
    // by whole cells instead of retaining its original sharp silhouette.
    float fullCellPixels = mix(1.0, max(1.0, pixelSize), globalPixelate);
    vec2 fullCell = vec2(fullCellPixels) / resolution;
    vec2 fullSampleUV = (floor(uv / fullCell) + vec2(0.5)) * fullCell;
    vec2 sampledShapeData = texture(shapeMaskTex,
        clamp(fullSampleUV, vec2(0.0), vec2(1.0))).rg;
    float sampledCoverage = sampledShapeData.g;
    float sampledInfluence = sampledCoverage > 0.0001
        ? clamp(sampledShapeData.r / sampledCoverage, 0.0, 1.0) : 1.0;
    // Pixelation is a shared output raster, not an artist-strength overlay.
    // Shapes therefore use the exact same grid and amount as the frame; their
    // Effect Influence controls other effects but never creates smaller cells.
    float localPixelate = globalPixelate;
    float cellPixels = mix(1.0, max(1.0, pixelSize), localPixelate);
    vec2 cell = vec2(cellPixels) / resolution;
    vec2 sampleUV = (floor(uv / cell) + vec2(0.5)) * cell;
    vec4 blocked = texture(colorTex, clamp(sampleUV, vec2(0.0), vec2(1.0)));
    // Pixelate is a coverage transform, not a foreground-only overlay. At a
    // nonzero setting every layer enters the same output grid exactly once;
    // otherwise fine background graphite and shape fibres survive as sharp
    // duplicates behind the blocked image.
    fragColor = blocked;
}
