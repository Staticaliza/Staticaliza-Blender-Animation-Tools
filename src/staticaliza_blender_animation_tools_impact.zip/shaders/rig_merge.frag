uniform sampler2D backColor;
uniform sampler2D frontColor;
uniform sampler2D backMask;
uniform sampler2D frontMask;
uniform sampler2D backShape;
uniform sampler2D frontShape;
uniform vec4 paper;
uniform vec4 frontPigment;
uniform int outputMode;
uniform int frontRig;
in vec2 uv;
out vec4 fragColor;
void main(){
 if(outputMode==3){fragColor=texture(frontMask,uv);return;}
 vec4 bc=texture(backColor,uv),fc=texture(frontColor,uv);
 if(outputMode==5){
  // The background layer already resolves mesh depth. Preserve its authored
  // RGB where it is visible instead of selecting different channels from
  // the subject and background, which invents a third overlap color.
  vec3 departure=abs(fc.rgb-paper.rgb);
  vec3 pigmentDeparture=abs(frontPigment.rgb-paper.rgb);
  float contrast=max(pigmentDeparture.r,max(pigmentDeparture.g,pigmentDeparture.b));
  float coverage=contrast>.00001
      ? clamp(max(departure.r,max(departure.g,departure.b))/contrast,0.,1.)
      : clamp(texture(frontMask,uv).r,0.,1.);
  vec3 color=clamp(fc.rgb+(bc.rgb-paper.rgb)*(1.-coverage),0.,1.);
  fragColor=vec4(mix(color,bc.rgb,texture(backShape,uv).g),1.);
  return;
 }
 if(outputMode==4){
  // Union independently transported pigments without an ownership cutout.
  // Choose the stronger departure from the same paper in each channel.
  vec3 da=bc.rgb-paper.rgb, db=fc.rgb-paper.rgb;
  vec3 delta=mix(da,db,step(abs(da),abs(db)));
  float protectedShape=texture(backShape,uv).g;
  fragColor=vec4(mix(clamp(paper.rgb+delta,0.,1.),bc.rgb,protectedShape),1.);
  return;
 }
 vec4 bm=texture(backMask,uv),fm=texture(frontMask,uv);
 vec4 bs=texture(backShape,uv),fs=texture(frontShape,uv);
 float visible=clamp(max(abs(fc.r-paper.r),max(abs(fc.g-paper.g),abs(fc.b-paper.b))),0.,1.);
 float coverage=clamp(max(max(fm.b,fm.r),max(fs.g,visible)),0.,1.);
 if(outputMode==0)fragColor=vec4(clamp(bc.rgb*(1.-coverage)+fc.rgb-paper.rgb*(1.-coverage),0.,1.),1.);
 else if(outputMode==1){
  fragColor=mix(bm,fm,coverage);
  fragColor.r=1.-(1.-bm.r)*(1.-fm.r);
  fragColor.b=max(bm.b,fm.b);
  if (coverage > .01) fragColor.a = fm.a - float(frontRig * 8);
  else fragColor.a = bm.a;
 }else{
  fragColor=vec4(mix(bs.r,fs.r,coverage),mix(bs.g,fs.g,coverage),0.,1.);
 }
}
