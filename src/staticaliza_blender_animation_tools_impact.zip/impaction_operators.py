from pathlib import Path

import bpy
from bpy.props import IntProperty, StringProperty
from bpy.types import Menu, Operator

from .impaction_action import (
    impact_grid_frame, impact_grid_interval, insert_marker,
    rebuild_marker_exposure, remove_marker,
)
from .impaction_discovery import camera_bone_binding, viewed_camera
from .impaction_renderer import (
    cache_matches_record, camera_view_rect, cached_image, delete_record_cache,
    display_image, has_cached_capture, recapture_records, render_record,
    cached_subject_center, promote_record_preview,
)
from .impaction_gradient import (
    MAX_ABERRATION_COLORS, aberration_colors, add_aberration_color,
    apply_aberration_ramp, remove_aberration_color,
    remove_aberration_ramp, serialize_aberration_ramp,
)
from .impaction_runtime import (
    cancel_live_render, cancel_pending_live_render, frame_record,
    commit_exclusive_property_edit, held_frame_record,
    remember_gradient_signatures, request_redraw, selected_property_records,
    selected_records,
    schedule_live_render, set_exclusive_property_edit, suspend_live_render,
    interactive_radial_record, interactive_direction_record,
    interactive_light_record, interactive_frame_record, displayed_frame_record,
)
from .impaction_properties import reroll_shape_variation, shape_selection_indices

_clipboard = None
_shape_clipboard = None
_SHAPE_CLIPBOARD_KEY = "staticaliza_blender_animation_tools_impact.shape_clipboard"
_INPUT_SHIELD_AREAS = set()
_INPUT_SHIELD_TOKEN_KEY = "staticaliza_blender_animation_tools_impact.input_shield_token"
_INPUT_SHIELD_TOKEN = object()
_OPERATOR_KEYMAPS = []
bpy.app.driver_namespace[_INPUT_SHIELD_TOKEN_KEY] = _INPUT_SHIELD_TOKEN


def _stored_shape_clipboard():
    return bpy.app.driver_namespace.get(_SHAPE_CLIPBOARD_KEY, _shape_clipboard)


def _store_shape_clipboard(values):
    global _shape_clipboard
    _shape_clipboard = values
    bpy.app.driver_namespace[_SHAPE_CLIPBOARD_KEY] = values


def _shape_clipboard_values(values=None):
    """Normalize the old single-shape clipboard and the new ordered batch."""
    values = _stored_shape_clipboard() if values is None else values
    if isinstance(values, dict):
        return [values]
    if isinstance(values, (list, tuple)):
        return [value for value in values if isinstance(value, dict)]
    return []


def _set_shape_selection(record, indices, active_index=None, anchor=None):
    """Set transient row flags without triggering legacy exclusive selection."""
    selected = sorted({
        int(index) for index in indices
        if 0 <= int(index) < len(record.shapes)
    })
    if active_index not in selected:
        active_index = selected[-1] if selected else -1
    if anchor is None:
        anchor = active_index
    if not 0 <= int(anchor) < len(record.shapes):
        anchor = active_index

    record["_syncing_shape_selection"] = True
    try:
        selected_set = set(selected)
        for index, shape in enumerate(record.shapes):
            shape.is_selected = index in selected_set
        record.active_shape_index = int(active_index)
        record.shape_selection_anchor = int(anchor)
    finally:
        del record["_syncing_shape_selection"]
    return selected


def _select_shape_index(record, index, shift=False, ctrl=False):
    """Apply Blender-style plain, Ctrl-toggle, and Shift-range selection."""
    index = int(index)
    if not 0 <= index < len(record.shapes):
        return []

    selected = set(shape_selection_indices(record))
    if shift:
        anchor = int(getattr(record, "shape_selection_anchor", -1))
        if not 0 <= anchor < len(record.shapes):
            active = int(getattr(record, "active_shape_index", -1))
            anchor = active if 0 <= active < len(record.shapes) else index
        row_range = set(range(min(anchor, index), max(anchor, index) + 1))
        selected = selected | row_range if ctrl else row_range
        active = index
    elif ctrl:
        previous_anchor = int(getattr(record, "shape_selection_anchor", -1))
        if index in selected:
            selected.remove(index)
            previous_active = int(getattr(record, "active_shape_index", -1))
            if previous_active in selected:
                active = previous_active
            elif selected:
                active = min(selected, key=lambda item: (abs(item - index), item))
            else:
                active = -1
            anchor = (
                previous_anchor
                if previous_anchor in selected else active
            )
        else:
            selected.add(index)
            active = anchor = index
    else:
        selected = {index}
        active = anchor = index

    return _set_shape_selection(
        record, selected, active_index=active, anchor=anchor,
    )


def _active_camera(context, require_view=True):
    camera = viewed_camera(context) if require_view else context.scene.camera
    return camera if camera and camera_bone_binding(camera)[0] is not None else None


def _editing_record(context):
    camera = _active_camera(context)
    if camera is None:
        return None, None
    selected = selected_records(camera)
    record = selected[0] if selected else None
    return camera, record


def _settle_live_preview(context, camera, record):
    """Apply the newest live pixels once, rendering only if input outran them."""
    cancel_pending_live_render(camera, record)
    promoted = promote_record_preview(camera, record, context.scene)
    if promoted is not None:
        return promoted
    if cache_matches_record(record, context.scene):
        return cached_image(record)
    return render_record(
        context, camera, record, preview=True, apply_preview=True,
    )


def _operation_records(context, camera):
    """Prefer explicitly selected keys, falling back to the held exposure."""
    records = selected_records(camera)
    if records:
        return records
    held = held_frame_record(context.scene, camera, context.scene.frame_current)
    return [held] if held is not None else []


def _visible_impact_image(context):
    """Return the image currently covering this camera view, if any."""
    camera = viewed_camera(context)
    record = displayed_frame_record(context, camera)
    state = getattr(getattr(context, "scene", None), "impaction", None)
    if (camera is None or record is None or state is None or
            state.preview_opacity <= 0.0):
        return None, None, None
    return camera, record, display_image(camera, record)


def _current_impact_image(context):
    """Resolve the current Impact image from any editor in this window."""
    visible = _visible_impact_image(context)
    if visible[2] is not None:
        return visible
    scene = getattr(context, "scene", None)
    state = getattr(scene, "impaction", None) if scene is not None else None
    camera = getattr(scene, "camera", None) if scene is not None else None
    if (camera is None or camera_bone_binding(camera)[0] is None or
            state is None or state.preview_opacity <= 0.0):
        return None, None, None
    record = held_frame_record(scene, camera, scene.frame_current)
    image = display_image(camera, record) if record is not None else None
    return (camera, record, image) if image is not None else (None, None, None)


def _copy_image_with_editor_context(context, image):
    """Use Blender's native clipboard operator from any Blender window."""
    windows = tuple(getattr(context.window_manager, "windows", ()))
    for window in windows:
        screen = window.screen
        for area in screen.areas:
            if area.type != "IMAGE_EDITOR":
                continue
            region = next((item for item in area.regions if item.type == "WINDOW"), None)
            if region is None:
                continue
            area.spaces.active.image = image
            with context.temp_override(
                    window=window, screen=screen, area=area, region=region):
                return bpy.ops.image.clipboard_copy()

    # A file can have no Image Editor at all. Temporarily provide the exact
    # context Blender's native clipboard operator polls for, then restore the
    # user's current editor synchronously.
    area = getattr(context, "area", None)
    if area is None:
        return {"CANCELLED"}
    original_type = area.type
    try:
        area.type = "IMAGE_EDITOR"
        area.spaces.active.image = image
        region = next((item for item in area.regions if item.type == "WINDOW"), None)
        if region is None:
            return {"CANCELLED"}
        with context.temp_override(area=area, region=region):
            return bpy.ops.image.clipboard_copy()
    finally:
        area.type = original_type


def ensure_viewport_input_shield(context):
    """Retired: precise gizmo hit tests do not need a full-view modal guard."""
    return


class IMPACTION_OT_viewport_input_shield(Operator):
    """Consume viewport selection clicks on the rendered camera image only."""

    bl_idname = "impaction.viewport_input_shield"
    bl_label = "Protect Impact Frame Viewport"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        return (getattr(getattr(context, "area", None), "type", None) == "VIEW_3D"
                and getattr(getattr(context, "region", None), "type", None) == "WINDOW")

    @staticmethod
    def _over_pin(record, rect, event, shapes_only=False):
        x0, y0, x1, y1 = rect
        width = x1 - x0
        height = y1 - y0
        points = [] if shapes_only else [
            (record.direction_focus, 14.0), (record.light_focus, 14.0),
        ]
        selected = set(shape_selection_indices(record))
        points.extend(
            (shape.position, 17.0 if index in selected else 14.0)
            for index, shape in enumerate(record.shapes[:16])
        )
        for point, hit_radius in points:
            px = x0 + float(point[0]) * width
            py = y0 + float(point[1]) * height
            if (abs(event.mouse_region_x - px) +
                    abs(event.mouse_region_y - py) <= hit_radius):
                return True
        return False

    def invoke(self, context, event):
        camera = viewed_camera(context)
        record = displayed_frame_record(context, camera)
        if record is None:
            return {"PASS_THROUGH"}
        rect = camera_view_rect(context, camera)
        if rect is None:
            return {"PASS_THROUGH"}
        x0, y0, x1, y1 = rect
        inside = (x0 <= event.mouse_region_x <= x1 and
                  y0 <= event.mouse_region_y <= y1)
        if not self._over_pin(record, rect, event, shapes_only=True):
            _set_shape_selection(record, [])
            request_redraw()
        if not inside or self._over_pin(record, rect, event):
            return {"PASS_THROUGH"}
        return {"FINISHED"}

    def _finish(self):
        _INPUT_SHIELD_AREAS.discard(getattr(self, "_area_pointer", 0))
        return {"FINISHED"}

    @staticmethod
    def _pin_interaction_active():
        try:
            from .impaction_gizmo import pin_highlighted
            return (pin_highlighted("FOCUS") or
                    pin_highlighted("DIRECTION") or
                    pin_highlighted("LIGHT") or
                    any(pin_highlighted(f"SHAPE:{index}")
                        for index in range(16)))
        except (ImportError, ReferenceError, RuntimeError):
            return False

    def modal(self, context, event):
        return self._finish()

    def cancel(self, _context):
        _INPUT_SHIELD_AREAS.discard(getattr(self, "_area_pointer", 0))


class IMPACTION_MT_image_context(Menu):
    bl_idname = "IMPACTION_MT_image_context"
    bl_label = "Impact Frame"

    def draw(self, _context):
        layout = self.layout
        layout.operator("impaction.copy_image", text="Copy Image", icon="COPYDOWN")
        layout.operator("impaction.export_image", text="Export Image", icon="EXPORT")


class IMPACTION_OT_image_context_menu(Operator):
    """Open the Impact image menu, passing through everywhere else."""

    bl_idname = "impaction.image_context_menu"
    bl_label = "Impact Frame Image Menu"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        return getattr(getattr(context, "area", None), "type", None) == "VIEW_3D"

    def invoke(self, context, event):
        camera, _record, image = _visible_impact_image(context)
        if camera is None or image is None:
            return {"PASS_THROUGH"}
        rect = camera_view_rect(context, camera)
        if rect is None:
            return {"PASS_THROUGH"}
        x0, y0, x1, y1 = rect
        if not (x0 <= event.mouse_region_x <= x1 and
                y0 <= event.mouse_region_y <= y1):
            return {"PASS_THROUGH"}
        bpy.ops.wm.call_menu(name="IMPACTION_MT_image_context")
        return {"FINISHED"}


def register_operator_keymaps():
    """Bind the camera-image menu in every 3D View and Blender window."""
    unregister_operator_keymaps()
    keyconfig = getattr(bpy.context.window_manager.keyconfigs, "addon", None)
    if keyconfig is None:
        return
    # Mode-specific context menus may run before the generic 3D View map.
    # Register at the head of each common editing map so the opaque impact
    # image owns RMB consistently in Object, Edit, and Pose workflows.
    for name in (
        "3D View", "Object Mode", "Mesh", "Armature", "Pose",
        "Curve", "Grease Pencil",
    ):
        keymap = keyconfig.keymaps.new(name=name, space_type="VIEW_3D")
        try:
            item = keymap.keymap_items.new(
                "impaction.image_context_menu", "RIGHTMOUSE", "PRESS", head=True)
        except TypeError:
            item = keymap.keymap_items.new(
                "impaction.image_context_menu", "RIGHTMOUSE", "PRESS")
        _OPERATOR_KEYMAPS.append((keymap, item))

    # A regular keymap operator protects only the camera image and completes
    # immediately. Unlike the retired modal guard, it cannot intercept clicks
    # in the timeline, headers, panels, or other editors.
    keymap = keyconfig.keymaps.new(name="3D View", space_type="VIEW_3D")
    try:
        item = keymap.keymap_items.new(
            "impaction.viewport_input_shield", "LEFTMOUSE", "PRESS", head=True)
    except TypeError:
        item = keymap.keymap_items.new(
            "impaction.viewport_input_shield", "LEFTMOUSE", "PRESS")
    _OPERATOR_KEYMAPS.append((keymap, item))


def unregister_operator_keymaps():
    while _OPERATOR_KEYMAPS:
        keymap, item = _OPERATOR_KEYMAPS.pop()
        try:
            keymap.keymap_items.remove(item)
        except (ReferenceError, RuntimeError, ValueError):
            pass


class IMPACTION_OT_copy_image(Operator):
    bl_idname = "impaction.copy_image"
    bl_label = "Copy Image"
    bl_description = "Copy the displayed Impact Frame image to the system clipboard"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        return _current_impact_image(context)[2] is not None

    def execute(self, context):
        _camera, _record, image = _current_impact_image(context)
        if image is None:
            return {"CANCELLED"}
        try:
            result = _copy_image_with_editor_context(context, image)
        except (AttributeError, RuntimeError) as error:
            self.report({"ERROR"}, f"Copy failed: {error}")
            return {"CANCELLED"}
        if "FINISHED" not in result:
            self.report({"ERROR"}, "Blender could not copy the displayed image.")
            return {"CANCELLED"}
        self.report({"INFO"}, "Impact Frame image copied.")
        return {"FINISHED"}


class IMPACTION_OT_export_image(Operator):
    bl_idname = "impaction.export_image"
    bl_label = "Export Image"
    bl_description = "Export the displayed Impact Frame image as a PNG"
    bl_options = {"REGISTER"}

    filepath: StringProperty(name="File Path", subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.png", options={"HIDDEN"})
    camera_name: StringProperty(options={"HIDDEN"})
    record_salt: IntProperty(options={"HIDDEN"})

    @classmethod
    def poll(cls, context):
        return _current_impact_image(context)[2] is not None

    def invoke(self, context, _event):
        camera, record, image = _current_impact_image(context)
        if image is None:
            return {"CANCELLED"}
        self.camera_name = camera.name_full
        self.record_salt = int(record.salt)
        self.filepath = bpy.path.abspath(f"//impact_frame_{record.frame}.png")
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        camera = bpy.data.objects.get(self.camera_name)
        record = next((item for item in getattr(camera, "impaction_frames", ())
                       if int(item.salt) == self.record_salt), None)
        image = display_image(camera, record) if record is not None else None
        if image is None:
            self.report({"ERROR"}, "The displayed Impact Frame is no longer available.")
            return {"CANCELLED"}
        filepath = Path(bpy.path.abspath(self.filepath))
        if filepath.suffix.lower() != ".png":
            filepath = filepath.with_suffix(".png")
        try:
            filepath.parent.mkdir(parents=True, exist_ok=True)
            image.file_format = "PNG"
            image.save_render(str(filepath), scene=context.scene)
        except Exception as error:
            self.report({"ERROR"}, f"Export failed: {error}")
            return {"CANCELLED"}
        self.report({"INFO"}, f"Exported {filepath.name}.")
        return {"FINISHED"}


def _record_values(record):
    return {
        "mode": record.mode,
        "linear_enabled": record.linear_enabled,
        "radial_enabled": record.radial_enabled,
        "direction_focus": tuple(record.direction_focus),
        "direction_cast_behind": record.direction_cast_behind,
        "halo_spread": record.halo_spread,
        "motion_curve_influence": record.motion_curve_influence,
        "angle": record.angle, "focus": tuple(record.focus),
        "strength": record.strength, "line_thickness": record.line_thickness,
        "radial_threshold": record.radial_threshold,
        "radial_spiral": record.radial_spiral,
        "foreground": tuple(record.foreground),
        "background": tuple(record.background),
        "background_intensity": record.background_intensity,
        "background_motion": record.background_motion,
        "invert": record.invert,
        "band_transition": record.band_transition,
        "motion_blur": record.motion_blur,
        "light_focus": tuple(record.light_focus), "light_radius": record.light_radius,
        "bleed": record.bleed,
        "light_cast_behind": record.light_cast_behind,
        "light_color_source": record.light_color_source,
        "light_color": tuple(record.light_color),
        "contrast": record.contrast, "grayscale": record.grayscale,
        "bloom": record.bloom, "chromatic_aberration": record.chromatic_aberration,
        "aberration_blur_smoothing": record.aberration_blur_smoothing,
        "aberration_preset": record.aberration_preset,
        "aberration_color_a": tuple(record.aberration_color_a),
        "aberration_color_b": tuple(record.aberration_color_b),
        "grain": record.grain,
        "grain_overlay_intensity": record.grain_overlay_intensity,
        "halftone": record.halftone, "halftone_size": record.halftone_size,
        "pixelate": record.pixelate, "pixelate_size": record.pixelate_size,
        # Snapshotting must be read-only. Creating a missing ramp here mutates
        # the source collection item while Blender is adding the new one and
        # can crash in IDP_AddToGroup (Blender 5.2).
        "aberration_gradient": serialize_aberration_ramp(record, create=False),
        "shapes": [_shape_values(shape) for shape in record.shapes],
    }


def _shape_values(shape):
    return {
        "name": shape.name, "shape_type": shape.shape_type,
        "variation": int(getattr(shape, "variation", 1)),
        "position": tuple(shape.position),
        "width": shape.width, "height": shape.height,
        "rotation": shape.rotation,
        "radius": shape.radius, "diagonal": shape.diagonal,
        "end_width": shape.end_width,
        "burst_amount": shape.burst_amount,
        "burst_thickness": shape.burst_thickness,
        "burst_end": shape.burst_end,
        "stroke": shape.stroke,
        "stroke_color": tuple(shape.stroke_color),
        "line_thickness": shape.line_thickness,
        "effect_influence": shape.effect_influence,
        "foreground": tuple(shape.foreground),
        "background": tuple(shape.background), "layer": shape.layer,
        "points": [(tuple(point.position), point.pressure,
                    bool(point.break_before))
                   for point in shape.points],
    }


def _apply_shape_values(shape, values):
    shape["_preserve_variation"] = True
    try:
        for name, value in values.items():
            if name == "points":
                shape.points.clear()
                for item in value:
                    position, pressure = item[:2]
                    point = shape.points.add()
                    point.position = position
                    point.pressure = pressure
                    point.break_before = bool(item[2]) if len(item) > 2 else False
            else:
                setattr(shape, name, value)
    finally:
        del shape["_preserve_variation"]


def _copy_selected_shape_values(record):
    """Snapshot selected shapes in their stable collection order."""
    return [
        _shape_values(record.shapes[index])
        for index in shape_selection_indices(record)
    ]


def _paste_shape_values(record, values):
    """Paste an old single shape or ordered batch and select every new row."""
    marker_key = "_impaction_paste_order"
    marker_prefix = f"{record.as_pointer()}:{id(values)}:"
    pasted = []
    try:
        for order, shape_values in enumerate(_shape_clipboard_values(values)):
            shape = record.shapes.add()
            # RNA collection element pointers can change when a later add()
            # reallocates storage. A short-lived ID-property marker survives
            # both reallocation and numeric-slot moves.
            shape[marker_key] = f"{marker_prefix}{order}"
            _apply_shape_values(shape, shape_values)
            reroll_shape_variation(shape)
            IMPACTION_OT_add_shape._name_and_order(record, shape)
        ordered = []
        for index, shape in enumerate(record.shapes):
            marker = str(shape.get(marker_key, ""))
            if marker.startswith(marker_prefix):
                ordered.append((int(marker[len(marker_prefix):]), index))
        pasted = [index for _order, index in sorted(ordered)]
    finally:
        for shape in record.shapes:
            marker = str(shape.get(marker_key, ""))
            if marker.startswith(marker_prefix):
                del shape[marker_key]
    if pasted:
        _set_shape_selection(
            record, pasted, active_index=pasted[-1], anchor=pasted[0],
        )
    return pasted


def _replace_shapes(record, values):
    record.shapes.clear()
    for shape_values in values:
        shape = record.shapes.add()
        _apply_shape_values(shape, shape_values)
    _set_shape_selection(record, [])


def _apply_values(record, values):
    for name, value in values.items():
        if name == "flip":
            # Hot-reload clipboards from the former checkbox contract may
            # still contain this key. Colors are already materialized, so
            # replaying legacy toggle state would reverse them a second time.
            continue
        if name == "aberration_gradient":
            apply_aberration_ramp(record, value)
        elif name == "shapes":
            _replace_shapes(record, value)
        else:
            setattr(record, name, value)


def _swap_palette(record):
    """Swap the materialized color endpoints without storing toggle state."""
    foreground = tuple(record.foreground)
    background = tuple(record.background)
    record.foreground = background
    record.background = foreground
    record["flip"] = False
    record["flip_semantics_version"] = 2


class IMPACTION_OT_flip_colors(Operator):
    bl_idname = "impaction.flip_colors"
    bl_label = "Flip Colors"
    bl_description = "Swap the Foreground and Background colors once"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        camera = _active_camera(context)
        return camera is not None and bool(_operation_records(context, camera))

    def execute(self, context):
        camera = _active_camera(context)
        records = _operation_records(context, camera)
        suspend_live_render(True)
        try:
            for record in records:
                _swap_palette(record)
        finally:
            suspend_live_render(False)
        for record in records:
            schedule_live_render(camera, record, input_change=True)
        request_redraw()
        return {"FINISHED"}


class IMPACTION_OT_select_shape(Operator):
    bl_idname = "impaction.select_shape"
    bl_label = "Select Shape"
    bl_description = "Select; Shift selects a range and Ctrl toggles this shape"
    bl_options = {"INTERNAL"}

    shape_index: IntProperty(default=-1, options={"HIDDEN"})

    def _apply(self, context, shift=False, ctrl=False):
        _camera, record = _editing_record(context)
        if record is None or not 0 <= self.shape_index < len(record.shapes):
            return {"CANCELLED"}
        context.scene.impaction.shape_draw_active = False
        _select_shape_index(
            record, self.shape_index, shift=shift, ctrl=ctrl,
        )
        request_redraw()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self._apply(
            context, shift=bool(event.shift), ctrl=bool(event.ctrl),
        )

    def execute(self, context):
        return self._apply(context)


class IMPACTION_OT_add_shape(Operator):
    bl_idname = "impaction.add_shape"
    bl_label = "Add Shape"
    bl_description = "Add a frame-local Star shape"
    bl_options = {"REGISTER", "UNDO"}

    shape_type: StringProperty(default="STAR", options={"HIDDEN"})

    @staticmethod
    def _available_slot(record, exclude=None):
        used = {
            str(candidate.name) for candidate in record.shapes
            if exclude is None or candidate.as_pointer() != exclude.as_pointer()
        }
        number = 1
        while f"Shape {number}" in used:
            number += 1
        return number

    @classmethod
    def _name_and_order(cls, record, shape):
        number = cls._available_slot(record, shape)
        shape.name = f"Shape {number}"
        current = len(record.shapes) - 1
        target = min(current, number - 1)
        if target != current:
            record.shapes.move(current, target)
        return target

    def execute(self, context):
        camera, record = _editing_record(context)
        if record is None:
            return {"CANCELLED"}
        context.scene.impaction.shape_draw_active = False
        shape = record.shapes.add()
        reroll_shape_variation(shape)
        shape.shape_type = self.shape_type if self.shape_type in {"STAR", "DOODLE"} else "STAR"
        target = self._name_and_order(record, shape)
        shape.position = (0.5, 0.5)
        shape.foreground = tuple(record.foreground)
        shape.background = tuple(record.background)
        _set_shape_selection(record, [target], active_index=target)
        schedule_live_render(camera, record, input_change=True)
        request_redraw()
        return {"FINISHED"}


class IMPACTION_OT_remove_shape(Operator):
    bl_idname = "impaction.remove_shape"
    bl_label = "Remove Shape"
    bl_description = "Remove the selected frame-local shape"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        camera, record = _editing_record(context)
        index = int(getattr(record, "active_shape_index", -1)) if record else -1
        if record is None or not 0 <= index < len(record.shapes):
            return {"CANCELLED"}
        context.scene.impaction.shape_draw_active = False
        record.shapes.remove(index)
        _set_shape_selection(record, [])
        schedule_live_render(camera, record, input_change=True)
        request_redraw()
        return {"FINISHED"}


class IMPACTION_OT_copy_shape(Operator):
    bl_idname = "impaction.copy_shape"
    bl_label = "Copy Shape"
    bl_description = "Copy the selected shapes and all of their editable data"

    @classmethod
    def poll(cls, context):
        _camera, record = _editing_record(context)
        return record is not None and bool(shape_selection_indices(record))

    def execute(self, context):
        _camera, record = _editing_record(context)
        values = _copy_selected_shape_values(record) if record is not None else []
        if not values:
            return {"CANCELLED"}
        _store_shape_clipboard(values)
        count = len(values)
        self.report({"INFO"}, f"{count} shape{'s' if count != 1 else ''} copied.")
        return {"FINISHED"}


class IMPACTION_OT_paste_shape(Operator):
    bl_idname = "impaction.paste_shape"
    bl_label = "Paste Shape"
    bl_description = "Paste the copied shapes into this impact frame"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, _context):
        return bool(_shape_clipboard_values())

    def execute(self, context):
        camera, record = _editing_record(context)
        values = _stored_shape_clipboard()
        if record is None or not _shape_clipboard_values(values):
            return {"CANCELLED"}
        suspend_live_render(True)
        try:
            pasted = _paste_shape_values(record, values)
        finally:
            suspend_live_render(False)
        if not pasted:
            return {"CANCELLED"}
        schedule_live_render(camera, record, input_change=True)
        request_redraw()
        count = len(pasted)
        self.report({"INFO"}, f"{count} shape{'s' if count != 1 else ''} pasted.")
        return {"FINISHED"}


class IMPACTION_OT_drag_shape(Operator):
    bl_idname = "impaction.drag_shape"
    bl_label = "Move Shape"
    bl_description = "Select and move this frame shape"
    bl_options = {"REGISTER", "UNDO"}

    shape_index: IntProperty(default=-1, options={"HIDDEN"})

    def invoke(self, context, event):
        from .impaction_gizmo import set_pin_active
        self.camera = _active_camera(context)
        self.record = interactive_frame_record(context, self.camera)
        if (self.record is None or not 0 <= self.shape_index <
                len(self.record.shapes)):
            return {"CANCELLED"}
        selected = _select_shape_index(
            self.record, self.shape_index,
            shift=bool(event.shift), ctrl=bool(event.ctrl),
        )
        if self.shape_index not in selected:
            request_redraw()
            return {"FINISHED"}
        self.drag_indices = tuple(selected)
        self.snapshots = []
        for index in self.drag_indices:
            shape = self.record.shapes[index]
            self.snapshots.append({
                "shape": shape,
                "position": tuple(shape.position),
                "variation": int(shape.variation),
                "points": [tuple(point.position) for point in shape.points],
            })
        self.mouse_origin = (float(event.mouse_region_x), float(event.mouse_region_y))
        self.original_cache_valid = bool(self.record.cache_valid)
        self._role = f"SHAPE:{self.shape_index}"
        set_exclusive_property_edit(self.record)
        set_pin_active(self._role, True)
        context.window_manager.modal_handler_add(self)
        request_redraw()
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        from .impaction_gizmo import set_pin_active
        if event.type in {"ESC", "RIGHTMOUSE"}:
            suspend_live_render(True)
            try:
                for snapshot in self.snapshots:
                    shape = snapshot["shape"]
                    shape["_preserve_variation"] = True
                    try:
                        shape.position = snapshot["position"]
                        shape["variation"] = snapshot["variation"]
                        for point, original in zip(shape.points, snapshot["points"]):
                            point.position = original
                    finally:
                        del shape["_preserve_variation"]
            finally:
                suspend_live_render(False)
            self.record.cache_valid = self.original_cache_valid
            cancel_live_render(self.camera, self.record)
            set_exclusive_property_edit(None)
            set_pin_active(self._role, False)
            request_redraw()
            return {"CANCELLED"}
        if event.type == "MOUSEMOVE":
            x0, y0, x1, y1 = camera_view_rect(context, self.camera)
            delta_x = (float(event.mouse_region_x) - self.mouse_origin[0]) / max(1.0, x1 - x0)
            delta_y = (float(event.mouse_region_y) - self.mouse_origin[1]) / max(1.0, y1 - y0)
            delta_x = max(
                -min(snapshot["position"][0] for snapshot in self.snapshots),
                min(delta_x, 1.0 - max(snapshot["position"][0] for snapshot in self.snapshots)),
            )
            delta_y = max(
                -min(snapshot["position"][1] for snapshot in self.snapshots),
                min(delta_y, 1.0 - max(snapshot["position"][1] for snapshot in self.snapshots)),
            )
            suspend_live_render(True)
            try:
                for snapshot in self.snapshots:
                    shape = snapshot["shape"]
                    shape["_preserve_variation"] = True
                    try:
                        original_position = snapshot["position"]
                        shape.position = (
                            original_position[0] + delta_x,
                            original_position[1] + delta_y,
                        )
                        shape["variation"] = snapshot["variation"]
                        if shape.shape_type == "DOODLE":
                            for point, original in zip(shape.points, snapshot["points"]):
                                point.position = (
                                    min(1.0, max(0.0, original[0] + delta_x)),
                                    min(1.0, max(0.0, original[1] + delta_y)),
                                )
                    finally:
                        del shape["_preserve_variation"]
            finally:
                suspend_live_render(False)
            schedule_live_render(self.camera, self.record, input_change=True)
            request_redraw()
        if event.type == "LEFTMOUSE" and event.value == "RELEASE":
            _settle_live_preview(context, self.camera, self.record)
            set_exclusive_property_edit(None)
            set_pin_active(self._role, False)
            return {"FINISHED"}
        return {"RUNNING_MODAL"}


class IMPACTION_OT_draw_doodle(Operator):
    bl_idname = "impaction.draw_doodle"
    bl_label = "Draw Doodle"
    bl_description = "Draw a dry-brush doodle directly in the camera frame"
    bl_options = {"REGISTER", "UNDO"}

    mode: StringProperty(default="DRAW", options={"HIDDEN"})

    def invoke(self, context, _event):
        state = context.scene.impaction
        if state.shape_draw_active:
            state.shape_draw_active = False
            request_redraw()
            return {"FINISHED"}
        self.camera, self.record = _editing_record(context)
        index = int(getattr(self.record, "active_shape_index", -1)) if self.record else -1
        if (self.record is None or not 0 <= index < len(self.record.shapes)
                or self.record.shapes[index].shape_type != "DOODLE"):
            return {"CANCELLED"}
        self.shape = self.record.shapes[index]
        self._initial = self._snapshot()
        self._drawing = False
        self._new_stroke = True
        self._undo = []
        self._redo = []
        state.shape_draw_active = True
        state.shape_draw_mode = self.mode
        try:
            context.window.cursor_modal_set("CROSSHAIR")
        except (AttributeError, RuntimeError, TypeError):
            pass
        set_exclusive_property_edit(self.record)
        context.window_manager.modal_handler_add(self)
        self.report({"INFO"}, "LMB draw/erase, Enter finish, Esc cancel")
        return {"RUNNING_MODAL"}

    def _point(self, context, event):
        x0, y0, x1, y1 = camera_view_rect(context, self.camera)
        return ((event.mouse_region_x - x0) / max(1.0, x1 - x0),
                (event.mouse_region_y - y0) / max(1.0, y1 - y0))

    def _recenter(self):
        if not self.shape.points:
            return
        self.shape.position = (
            0.5 * (min(float(point.position[0]) for point in self.shape.points) +
                   max(float(point.position[0]) for point in self.shape.points)),
            0.5 * (min(float(point.position[1]) for point in self.shape.points) +
                   max(float(point.position[1]) for point in self.shape.points)),
        )

    def _snapshot(self):
        return (int(self.shape.variation), [
            (tuple(point.position), float(point.pressure),
             bool(point.break_before)) for point in self.shape.points
        ])

    def _restore(self, snapshot):
        variation, points = snapshot
        self.shape.points.clear()
        for position, pressure, break_before in points:
            point = self.shape.points.add()
            point.position = position
            point.pressure = pressure
            point.break_before = break_before
        self.shape["variation"] = variation
        schedule_live_render(self.camera, self.record, input_change=True)
        request_redraw()

    def _finish(self, context, cancelled=False):
        if cancelled and hasattr(self, "_initial"):
            self._restore(self._initial)
        context.scene.impaction.shape_draw_active = False
        try:
            context.window.cursor_modal_restore()
        except (AttributeError, RuntimeError):
            pass
        set_exclusive_property_edit(None)
        request_redraw()
        return {"CANCELLED" if cancelled else "FINISHED"}

    def modal(self, context, event):
        if not context.scene.impaction.shape_draw_active:
            return self._finish(context)
        # Modal events can be delivered after the pointer crosses into an
        # editor/window without a VIEW_3D SpaceView3D.  Stop cleanly instead
        # of dereferencing context.space_data.region_3d.
        space = getattr(context, "space_data", None)
        area = getattr(context, "area", None)
        if (space is None or area is None or
                getattr(area, "type", "") != "VIEW_3D" or
                not hasattr(space, "region_3d")):
            self._recenter()
            return self._finish(context)
        if event.type in {"ESC", "RIGHTMOUSE"}:
            return self._finish(context, cancelled=True)
        if event.type in {"RET", "NUMPAD_ENTER", "SPACE"}:
            self._recenter()
            cancel_live_render(self.camera, self.record)
            render_record(context, self.camera, self.record,
                          preview=True, apply_preview=True)
            return self._finish(context)
        if event.ctrl and event.shift and event.type == "Z" and event.value == "PRESS":
            if self._redo:
                self._undo.append(self._snapshot())
                self._restore(self._redo.pop())
            return {"RUNNING_MODAL"}
        if event.ctrl and event.type == "Z" and event.value == "PRESS":
            if self._undo:
                self._redo.append(self._snapshot())
                self._restore(self._undo.pop())
            return {"RUNNING_MODAL"}
        x0, y0, x1, y1 = camera_view_rect(context, self.camera)
        inside = (x0 <= event.mouse_region_x <= x1 and
                  y0 <= event.mouse_region_y <= y1)
        if not inside and not self._drawing:
            return {"PASS_THROUGH"}
        if event.type == "LEFTMOUSE":
            if event.value == "PRESS":
                self._undo.append(self._snapshot())
                self._redo.clear()
            self._drawing = event.value == "PRESS"
            self._new_stroke = self._drawing
        if event.type == "MOUSEMOVE" and self._drawing:
            point = self._point(context, event)
            if not (0.0 <= point[0] <= 1.0 and 0.0 <= point[1] <= 1.0):
                return {"RUNNING_MODAL"}
            if self.mode == "ERASE":
                radius = 0.018 + 0.035 * float(self.shape.line_thickness)
                removed = False
                for index in range(len(self.shape.points) - 1, -1, -1):
                    old = self.shape.points[index].position
                    if (old[0] - point[0]) ** 2 + (old[1] - point[1]) ** 2 < radius ** 2:
                        self.shape.points.remove(index)
                        if index < len(self.shape.points):
                            self.shape.points[index].break_before = True
                        removed = True
                if removed:
                    reroll_shape_variation(self.shape)
                    schedule_live_render(
                        self.camera, self.record, input_change=True,
                    )
            else:
                if self.shape.points:
                    old = self.shape.points[-1].position
                    if ((old[0] - point[0]) ** 2 + (old[1] - point[1]) ** 2 <
                            0.0025 ** 2):
                        return {"RUNNING_MODAL"}
                item = self.shape.points.add()
                item.position = point
                item.pressure = float(getattr(event, "pressure", 1.0) or 1.0)
                item.break_before = self._new_stroke
                self._new_stroke = False
                reroll_shape_variation(self.shape)
                schedule_live_render(
                    self.camera, self.record, input_change=True,
                )
            request_redraw()
        return {"RUNNING_MODAL"}

    def cancel(self, context):
        self._finish(context, cancelled=True)


def _next_frame_plan(context, camera):
    """Return (target frame, optional selected property source)."""
    interval = impact_grid_interval(context.scene, camera)
    selected = selected_records(camera)
    property_source = max(selected, key=lambda item: int(item.frame)) if selected else None
    if property_source is None:
        tail = max(camera.impaction_frames, key=lambda item: int(item.frame))
    else:
        tail = property_source
        records_by_frame = {int(item.frame): item for item in camera.impaction_frames}
        while int(tail.frame) + interval in records_by_frame:
            tail = records_by_frame[int(tail.frame) + interval]
    return int(tail.frame) + interval, property_source


def _render_without_moving_cursor(context, camera, record, *, recapture=False):
    scene = context.scene
    original_frame = scene.frame_current
    original_subframe = scene.frame_subframe
    moved_frame = (
        (recapture or not has_cached_capture(camera, record))
        and (original_frame != record.frame or bool(original_subframe))
    )
    try:
        if moved_frame:
            scene.frame_set(record.frame)
        return render_record(context, camera, record, recapture=recapture)
    finally:
        if moved_frame:
            scene.frame_set(original_frame, subframe=original_subframe)


class IMPACTION_OT_create_frame(Operator):
    bl_idname = "impaction.create_frame"
    bl_label = "Create Frame"
    bl_description = "Create and render an Impact Frame key at the current frame"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _active_camera(context) is not None

    def execute(self, context):
        camera = _active_camera(context)
        target_frame = impact_grid_frame(context.scene, camera, context.scene.frame_current)
        record = frame_record(camera, target_frame)
        created = record is None
        if created:
            record = camera.impaction_frames.add()
            record.initialize(target_frame)
            armature, _bone = camera_bone_binding(camera)
            insert_marker(armature, camera, record.frame, record.salt)
        context.scene.frame_set(target_frame)
        try:
            render_record(
                context, camera, record, recapture=created,
                preview=True, apply_preview=True,
            )
        except Exception as error:
            self.report({"ERROR"}, f"Impact render failed: {error}")
            return {"CANCELLED"}
        context.scene.impaction.preview_opacity = 100.0
        request_redraw()
        return {"FINISHED"}


class IMPACTION_OT_update_frame(Operator):
    bl_idname = "impaction.update_frame"
    bl_label = "Update Frames"
    bl_description = "Recapture the pose, camera, and motion for the selected Impact Frames"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        camera = _active_camera(context)
        return camera is not None and bool(_operation_records(context, camera))

    def execute(self, context):
        camera = _active_camera(context)
        records = _operation_records(context, camera)
        suspend_live_render(True)
        try:
            # Scene evaluation during a multi-frame recapture must never become
            # the authority for style RNA. Snapshot the exact edited values,
            # then restore them before rendering the fresh subject capture.
            style_snapshots = {
                int(record.salt): _record_values(record) for record in records
            }
            for record in records:
                cancel_live_render(camera, record)
            recapture_records(context, camera, records)
            for record in records:
                set_exclusive_property_edit(record)
                try:
                    _apply_values(record, style_snapshots[int(record.salt)])
                finally:
                    set_exclusive_property_edit(None)
                render_record(
                    context, camera, record,
                    preview=True, apply_preview=True,
                )
        except Exception as error:
            self.report({"ERROR"}, f"Impact update failed: {error}")
            return {"CANCELLED"}
        finally:
            suspend_live_render(False)
        context.scene.impaction.preview_opacity = 100.0
        request_redraw()
        return {"FINISHED"}


class IMPACTION_OT_create_next_frame(Operator):
    bl_idname = "impaction.create_next_frame"
    bl_label = "Create Next Frame"
    bl_description = "Create the next Impact-grid frame; copy a selected key or use defaults"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        camera = _active_camera(context)
        return camera is not None and bool(camera.impaction_frames)

    def execute(self, context):
        camera = _active_camera(context)
        target_frame, property_source = _next_frame_plan(context, camera)
        existing = frame_record(camera, target_frame)
        if existing is not None:
            context.scene.frame_set(target_frame)
            request_redraw()
            return {"FINISHED"}

        record = camera.impaction_frames.add()
        record.initialize(target_frame)
        if property_source is not None:
            suspend_live_render(True)
            try:
                _apply_values(record, _record_values(property_source))
            finally:
                suspend_live_render(False)
        armature, _bone = camera_bone_binding(camera)
        insert_marker(armature, camera, record.frame, record.salt)
        context.scene.frame_set(target_frame)
        try:
            render_record(
                context, camera, record, recapture=True,
                preview=True, apply_preview=True,
            )
        except Exception as error:
            self.report({"ERROR"}, f"Next Impact frame failed: {error}")
            return {"CANCELLED"}
        # Rendering and marker insertion can trigger handlers which restore a
        # prior scene time. Next is navigation as well as creation, so its
        # generated key must be the final observable timeline state.
        context.scene.frame_set(target_frame)
        context.scene.impaction.preview_opacity = 100.0
        request_redraw()
        return {"FINISHED"}


class IMPACTION_OT_delete_frame(Operator):
    bl_idname = "impaction.delete_frame"
    bl_label = "Remove Frames"
    bl_description = "Remove the selected Impact Frame keys, settings, and cached images"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        camera = _active_camera(context)
        return camera is not None and bool(_operation_records(context, camera))

    def execute(self, context):
        camera = _active_camera(context)
        records = _operation_records(context, camera)
        armature, _bone = camera_bone_binding(camera)
        for record in records:
            remove_marker(armature, camera, record.frame, record.salt)
            cancel_live_render(camera, record)
            delete_record_cache(camera, record)
            remove_aberration_ramp(record)
        pointers = {record.as_pointer() for record in records}
        indices = [
            index for index, item in enumerate(camera.impaction_frames)
            if item.as_pointer() in pointers
        ]
        for index in reversed(indices):
            camera.impaction_frames.remove(index)
        rebuild_marker_exposure(armature, camera)
        if not camera.impaction_frames:
            camera.impaction_grid_initialized = False
        request_redraw()
        return {"FINISHED"}


class IMPACTION_OT_copy_frame(Operator):
    bl_idname = "impaction.copy_frame"
    bl_label = "Copy"
    bl_description = "Copy only the selected Impact Frame's artistic properties, not its image"

    @classmethod
    def poll(cls, context):
        camera = _active_camera(context)
        return camera is not None and len(selected_records(camera)) == 1

    def execute(self, context):
        global _clipboard
        _camera, record = _editing_record(context)
        _clipboard = _record_values(record)
        self.report({"INFO"}, "Impact Frame settings copied.")
        return {"FINISHED"}


class IMPACTION_OT_paste_frame(Operator):
    bl_idname = "impaction.paste_frame"
    bl_label = "Paste"
    bl_description = "Paste artistic properties onto selected Impact Frames without copying imagery"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        camera = _active_camera(context)
        return _clipboard is not None and camera is not None and bool(selected_records(camera))

    def execute(self, context):
        camera = _active_camera(context)
        records = selected_records(camera)
        if not records:
            self.report({"WARNING"}, "Select at least one Impact Frame key first.")
            return {"CANCELLED"}
        suspend_live_render(True)
        try:
            for record in records:
                _apply_values(record, _clipboard)
        finally:
            suspend_live_render(False)
        try:
            for record in records:
                cancel_live_render(camera, record)
                _render_without_moving_cursor(context, camera, record, recapture=False)
        except Exception as error:
            self.report({"ERROR"}, f"Property paste failed: {error}")
            return {"CANCELLED"}
        request_redraw()
        self.report({"INFO"}, f"Pasted properties to {len(records)} Impact Frame(s).")
        return {"FINISHED"}


class IMPACTION_OT_drag_focus(Operator):
    bl_idname = "impaction.drag_focus"
    bl_label = "Drag Radial Focus"
    bl_description = "Drag the radial origin inside the camera frame"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return interactive_radial_record(context) is not None

    def invoke(self, context, event):
        from .impaction_gizmo import set_pin_active
        self.camera = _active_camera(context)
        self.record = interactive_radial_record(context, self.camera)
        if self.record is None:
            return {"CANCELLED"}
        self.original_focus = tuple(self.record.focus)
        self.original_cache_valid = bool(self.record.cache_valid)
        self._closed = False
        set_exclusive_property_edit(self.record)
        set_pin_active("FOCUS", True)
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        from .impaction_gizmo import set_pin_active
        current = interactive_radial_record(context, self.camera)
        if current is None or current.as_pointer() != self.record.as_pointer():
            self.record.focus = self.original_focus
            cancel_live_render(self.camera, self.record)
            set_exclusive_property_edit(None)
            set_pin_active("FOCUS", False)
            self._closed = True
            return {"CANCELLED"}
        if event.type == "MIDDLEMOUSE":
            self.record.focus = self.original_focus
            cancel_live_render(self.camera, self.record)
            set_exclusive_property_edit(None)
            set_pin_active("FOCUS", False)
            self._closed = True
            return {"CANCELLED", "PASS_THROUGH"}
        if event.type in {"ESC", "RIGHTMOUSE"}:
            self.record.focus = self.original_focus
            self.record.cache_valid = self.original_cache_valid
            cancel_live_render(self.camera, self.record)
            set_exclusive_property_edit(None)
            set_pin_active("FOCUS", False)
            self._closed = True
            return {"CANCELLED"}
        if event.type == "MOUSEMOVE":
            x0, y0, x1, y1 = camera_view_rect(context, self.camera)
            x = min(1.0, max(0.0, (event.mouse_region_x - x0) / max(1.0, x1 - x0)))
            y = min(1.0, max(0.0, (event.mouse_region_y - y0) / max(1.0, y1 - y0)))
            self.record.focus = (x, y)
            request_redraw()
        if event.type == "LEFTMOUSE" and event.value == "RELEASE":
            try:
                cancel_live_render(self.camera, self.record)
                render_record(
                    context, self.camera, self.record,
                    preview=True, apply_preview=True,
                )
                commit_exclusive_property_edit(
                    self.record, context, "focus",
                )
            except Exception as error:
                set_exclusive_property_edit(None)
                set_pin_active("FOCUS", False)
                self._closed = True
                self.report({"ERROR"}, str(error))
                return {"CANCELLED"}
            set_pin_active("FOCUS", False)
            self._closed = True
            return {"FINISHED"}
        return {"RUNNING_MODAL"}

    def cancel(self, _context):
        from .impaction_gizmo import set_pin_active
        if getattr(self, "_closed", False):
            return
        if getattr(self, "record", None) is not None:
            self.record.focus = self.original_focus
            self.record.cache_valid = self.original_cache_valid
            cancel_live_render(self.camera, self.record)
        set_exclusive_property_edit(None)
        set_pin_active("FOCUS", False)
        self._closed = True


class IMPACTION_OT_drag_light(Operator):
    bl_idname = "impaction.drag_light"
    bl_label = "Drag Impact Light"
    bl_description = "Orbit the camera-facing Impact light around the subject"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return interactive_light_record(context) is not None

    def invoke(self, context, _event):
        from .impaction_gizmo import set_pin_active
        self.camera = _active_camera(context)
        self.record = interactive_light_record(context, self.camera)
        if self.record is None:
            return {"CANCELLED"}
        self.original_focus = tuple(self.record.light_focus)
        self.original_cache_valid = bool(self.record.cache_valid)
        self._closed = False
        set_exclusive_property_edit(self.record)
        set_pin_active("LIGHT", True)
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        from .impaction_gizmo import set_pin_active
        current = interactive_light_record(context, self.camera)
        if current is None or current.as_pointer() != self.record.as_pointer():
            self.record.light_focus = self.original_focus
            cancel_live_render(self.camera, self.record)
            set_exclusive_property_edit(None)
            set_pin_active("LIGHT", False)
            self._closed = True
            return {"CANCELLED"}
        if event.type == "MIDDLEMOUSE":
            self.record.light_focus = self.original_focus
            cancel_live_render(self.camera, self.record)
            set_exclusive_property_edit(None)
            set_pin_active("LIGHT", False)
            self._closed = True
            return {"CANCELLED", "PASS_THROUGH"}
        if event.type in {"ESC", "RIGHTMOUSE"}:
            self.record.light_focus = self.original_focus
            self.record.cache_valid = self.original_cache_valid
            cancel_live_render(self.camera, self.record)
            set_exclusive_property_edit(None)
            set_pin_active("LIGHT", False)
            self._closed = True
            return {"CANCELLED"}
        if event.type == "MOUSEMOVE":
            x0, y0, x1, y1 = camera_view_rect(context, self.camera)
            x = min(1.0, max(0.0, (event.mouse_region_x - x0) / max(1.0, x1 - x0)))
            y = min(1.0, max(0.0, (event.mouse_region_y - y0) / max(1.0, y1 - y0)))
            orbit_x, orbit_y = (x - 0.5) * 2.0, (y - 0.5) * 2.0
            orbit_length = (orbit_x * orbit_x + orbit_y * orbit_y) ** 0.5
            if orbit_length > 1.0:
                orbit_x, orbit_y = orbit_x / orbit_length, orbit_y / orbit_length
                x, y = orbit_x * 0.5 + 0.5, orbit_y * 0.5 + 0.5
            self.record.light_focus = (x, y)
            request_redraw()
        if event.type == "LEFTMOUSE" and event.value == "RELEASE":
            try:
                _settle_live_preview(context, self.camera, self.record)
                commit_exclusive_property_edit(
                    self.record, context, "light_focus",
                )
            except Exception as error:
                set_exclusive_property_edit(None)
                set_pin_active("LIGHT", False)
                self._closed = True
                self.report({"ERROR"}, str(error))
                return {"CANCELLED"}
            set_pin_active("LIGHT", False)
            self._closed = True
            return {"FINISHED"}
        return {"RUNNING_MODAL"}

    def cancel(self, _context):
        from .impaction_gizmo import set_pin_active
        if getattr(self, "_closed", False):
            return
        if getattr(self, "record", None) is not None:
            self.record.light_focus = self.original_focus
            self.record.cache_valid = self.original_cache_valid
            cancel_live_render(self.camera, self.record)
        set_exclusive_property_edit(None)
        set_pin_active("LIGHT", False)
        self._closed = True


class IMPACTION_OT_drag_direction(Operator):
    bl_idname = "impaction.drag_direction"
    bl_label = "Drag 3D Impact Direction"
    bl_description = "Orbit the camera-space aerodynamic stroke direction"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return interactive_direction_record(context) is not None

    def invoke(self, context, _event):
        from .impaction_gizmo import set_pin_active
        self.camera = _active_camera(context)
        self.record = interactive_direction_record(context, self.camera)
        if self.record is None:
            return {"CANCELLED"}
        self.original_focus = tuple(self.record.direction_focus)
        self.original_cache_valid = bool(self.record.cache_valid)
        self._closed = False
        set_exclusive_property_edit(self.record)
        set_pin_active("DIRECTION", True)
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        from .impaction_gizmo import set_pin_active
        current = interactive_direction_record(context, self.camera)
        if current is None or current.as_pointer() != self.record.as_pointer():
            self.record.direction_focus = self.original_focus
            cancel_live_render(self.camera, self.record)
            set_exclusive_property_edit(None)
            set_pin_active("DIRECTION", False)
            self._closed = True
            return {"CANCELLED"}
        if event.type == "MIDDLEMOUSE":
            self.record.direction_focus = self.original_focus
            cancel_live_render(self.camera, self.record)
            set_exclusive_property_edit(None)
            set_pin_active("DIRECTION", False)
            self._closed = True
            return {"CANCELLED", "PASS_THROUGH"}
        if event.type in {"ESC", "RIGHTMOUSE"}:
            self.record.direction_focus = self.original_focus
            self.record.cache_valid = self.original_cache_valid
            cancel_live_render(self.camera, self.record)
            set_exclusive_property_edit(None)
            set_pin_active("DIRECTION", False)
            self._closed = True
            return {"CANCELLED"}
        if event.type == "MOUSEMOVE":
            x0, y0, x1, y1 = camera_view_rect(context, self.camera)
            x = min(1.0, max(0.0, (event.mouse_region_x - x0) / max(1.0, x1 - x0)))
            y = min(1.0, max(0.0, (event.mouse_region_y - y0) / max(1.0, y1 - y0)))
            # The frontal sunray pose is important enough to deserve a real
            # target. Magnetize to the cached projected subject center within
            # a comfortable screen-space radius; Shift retains precise free
            # placement. This reads existing capture data and never recaptures
            # geometry during a drag.
            snap = cached_subject_center(self.camera, self.record) or (0.5, 0.5)
            snap_dx = (x - snap[0]) * max(1.0, x1 - x0)
            snap_dy = (y - snap[1]) * max(1.0, y1 - y0)
            if not event.shift and snap_dx * snap_dx + snap_dy * snap_dy <= 34.0 ** 2:
                x, y = snap
            # Radial interprets the shared pin as a literal full-frame focus.
            # Directional modes retain their camera-hemisphere unit-disc map.
            if not bool(self.record.radial_enabled):
                orbit_x, orbit_y = (x - 0.5) * 2.0, (y - 0.5) * 2.0
                orbit_length = (orbit_x * orbit_x + orbit_y * orbit_y) ** 0.5
                if orbit_length > 1.0:
                    orbit_x, orbit_y = orbit_x / orbit_length, orbit_y / orbit_length
                    x, y = orbit_x * 0.5 + 0.5, orbit_y * 0.5 + 0.5
            self.record.direction_focus = (x, y)
            request_redraw()
        if event.type == "LEFTMOUSE" and event.value == "RELEASE":
            try:
                _settle_live_preview(context, self.camera, self.record)
                commit_exclusive_property_edit(
                    self.record, context, "direction_focus",
                )
            except Exception as error:
                set_exclusive_property_edit(None)
                set_pin_active("DIRECTION", False)
                self._closed = True
                self.report({"ERROR"}, str(error))
                return {"CANCELLED"}
            set_pin_active("DIRECTION", False)
            self._closed = True
            return {"FINISHED"}
        return {"RUNNING_MODAL"}

    def cancel(self, _context):
        from .impaction_gizmo import set_pin_active
        if getattr(self, "_closed", False):
            return
        if getattr(self, "record", None) is not None:
            self.record.direction_focus = self.original_focus
            self.record.cache_valid = self.original_cache_valid
            cancel_live_render(self.camera, self.record)
        set_exclusive_property_edit(None)
        set_pin_active("DIRECTION", False)
        self._closed = True


class IMPACTION_OT_export_frames(Operator):
    bl_idname = "impaction.export_frames"
    bl_label = "Export Frames"
    bl_description = "Export this camera's Impact Frames as frame-numbered PNG files"
    directory: StringProperty(name="Folder", subtype="DIR_PATH")
    camera_name: StringProperty(options={"HIDDEN"})

    @classmethod
    def poll(cls, context):
        camera = _active_camera(context)
        return camera is not None and bool(camera.impaction_frames)

    def invoke(self, context, _event):
        camera = _active_camera(context)
        self.camera_name = camera.name_full
        if not self.directory:
            self.directory = bpy.path.abspath("//impact_frames")
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        scene = context.scene
        camera = bpy.data.objects.get(self.camera_name)
        if camera is None or camera_bone_binding(camera)[0] is None:
            self.report({"ERROR"}, "The camera used to start export is unavailable.")
            return {"CANCELLED"}
        directory = Path(bpy.path.abspath(self.directory))
        directory.mkdir(parents=True, exist_ok=True)
        original_frame = scene.frame_current
        try:
            for record in sorted(camera.impaction_frames, key=lambda item: item.frame):
                image = (
                    cached_image(record)
                    if cache_matches_record(record, scene) else None
                )
                if image is None:
                    image = _render_without_moving_cursor(context, camera, record)
                image.file_format = "PNG"
                image.save_render(str(directory / f"{record.frame}.png"), scene=scene)
        except Exception as error:
            self.report({"ERROR"}, f"Export failed: {error}")
            return {"CANCELLED"}
        finally:
            scene.frame_set(original_frame)
        self.report({"INFO"}, f"Exported {len(camera.impaction_frames)} Impact Frames.")
        return {"FINISHED"}


class _AberrationColorOperator:
    camera_name: StringProperty(options={"HIDDEN"})
    record_salt: IntProperty(options={"HIDDEN"})

    def _record(self):
        camera = bpy.data.objects.get(self.camera_name)
        if camera is None or not hasattr(camera, "impaction_frames"):
            return None, None
        record = next(
            (item for item in camera.impaction_frames if item.salt == self.record_salt),
            None,
        )
        return camera, record

    def _finish(self, camera, records):
        records = tuple(records)
        remember_gradient_signatures(camera, records)
        for record in records:
            schedule_live_render(camera, record, input_change=True)
        request_redraw()
        return {"FINISHED"}


class IMPACTION_OT_add_aberration_color(_AberrationColorOperator, Operator):
    bl_idname = "impaction.add_aberration_color"
    bl_label = "Add Aberration Color"
    bl_description = "Add another smoothly blended custom aberration color"
    bl_options = {"REGISTER", "UNDO", "INTERNAL"}

    def execute(self, _context):
        camera, record = self._record()
        if record is None:
            return {"CANCELLED"}
        if len(aberration_colors(record)) >= MAX_ABERRATION_COLORS:
            self.report({"WARNING"}, f"Custom aberration supports up to {MAX_ABERRATION_COLORS} colors.")
            return {"CANCELLED"}
        changed = tuple(
            target for target in selected_property_records(camera, record)
            if add_aberration_color(target)
        )
        return self._finish(camera, changed) if changed else {"CANCELLED"}


class IMPACTION_OT_remove_aberration_color(_AberrationColorOperator, Operator):
    bl_idname = "impaction.remove_aberration_color"
    bl_label = "Remove Aberration Color"
    bl_description = "Remove this custom aberration color"
    bl_options = {"REGISTER", "UNDO", "INTERNAL"}

    color_index: IntProperty(options={"HIDDEN"})

    def execute(self, _context):
        camera, record = self._record()
        if record is None:
            return {"CANCELLED"}
        colors = list(aberration_colors(record))
        if len(colors) <= 1 or not 0 <= self.color_index < len(colors):
            return {"CANCELLED"}
        changed = tuple(
            target for target in selected_property_records(camera, record)
            if remove_aberration_color(target, self.color_index)
        )
        return self._finish(camera, changed) if changed else {"CANCELLED"}


OPERATOR_CLASSES = (
    IMPACTION_MT_image_context,
    IMPACTION_OT_image_context_menu,
    IMPACTION_OT_viewport_input_shield,
    IMPACTION_OT_copy_image, IMPACTION_OT_export_image,
    IMPACTION_OT_create_frame, IMPACTION_OT_create_next_frame,
    IMPACTION_OT_update_frame, IMPACTION_OT_delete_frame,
    IMPACTION_OT_flip_colors,
    IMPACTION_OT_copy_frame, IMPACTION_OT_paste_frame,
    IMPACTION_OT_select_shape,
    IMPACTION_OT_add_shape, IMPACTION_OT_remove_shape,
    IMPACTION_OT_copy_shape, IMPACTION_OT_paste_shape,
    IMPACTION_OT_drag_shape, IMPACTION_OT_draw_doodle,
    IMPACTION_OT_drag_focus, IMPACTION_OT_drag_direction,
    IMPACTION_OT_drag_light,
    IMPACTION_OT_export_frames,
    IMPACTION_OT_add_aberration_color, IMPACTION_OT_remove_aberration_color,
)
