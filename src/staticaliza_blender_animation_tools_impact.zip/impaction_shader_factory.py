"""Compile the Impact GPU shader interfaces from packaged GLSL."""

from pathlib import Path

import gpu

_SHADER_DIR = Path(__file__).with_name("shaders")


def _source(name):
    return (_SHADER_DIR / name).read_text(encoding="utf-8")


def _shader_body(name):
    lines = _source(name).splitlines()
    return "\n".join(
        line for line in lines
        # CreateInfo supplies only file-scope interfaces. Preserve indented
        # `out` parameters in multiline GLSL function signatures; stripping
        # those made the full impact shader syntactically invalid while the
        # compatibility shader happened not to expose the parser defect.
        if not line.startswith(("in ", "out ", "uniform "))
    )


def _create_shader(name, vertex, fragment):
    info = gpu.types.GPUShaderCreateInfo()
    interface = gpu.types.GPUStageInterfaceInfo(f"impaction_{name}_interface")
    if name == "geometry":
        info.vertex_in(0, "VEC3", "position")
        info.vertex_in(1, "VEC3", "normal")
        interface.smooth("VEC3", "vNormal")
        for kind, uniform in (
            ("VEC2", "lightFocus"), ("FLOAT", "lightCastBehind"),
        ):
            info.push_constant(kind, uniform)
    elif name == "ownership_geometry":
        info.vertex_in(0, "VEC3", "position")
        info.vertex_in(1, "FLOAT", "ownerId")
        interface.smooth("FLOAT", "vOwnerId")
    elif name in {"linear_surface", "linear_preview"}:
        info.depth_write("ANY")
        info.vertex_in(0, "VEC4", "clipPosition")
        info.vertex_in(1, "VEC2", "strokeUV")
        info.vertex_in(2, "VEC4", "strokeParams")
        info.vertex_in(3, "FLOAT", "linearDepth")
        info.vertex_in(4, "VEC4", "strokeStyle")
        info.vertex_in(5, "VEC4", "strokeContact")
        info.vertex_in(6, "FLOAT", "sourceOwner")
        info.vertex_in(7, "FLOAT", "strokeVisibility")
        info.vertex_in(8, "FLOAT", "linearBandCoordinate")
        if name == "linear_preview":
            info.vertex_in(9, "VEC4", "previewWorld")
            info.vertex_in(10, "VEC4", "previewPivot")
            info.push_constant("MAT4", "previewMatrix")
            info.push_constant("VEC3", "previewAxis")
            info.push_constant("FLOAT", "previewAngle")
            info.push_constant("VEC3", "previewDepthAxis")

        interface.smooth("FLOAT", "vLinearBandCoordinate")
        interface.smooth("FLOAT", "vStrokeVisibility")
        interface.flat("FLOAT", "vSourceOwner")
        interface.flat("FLOAT", "vContactOwner")
        interface.smooth("FLOAT", "vContactVisible")
        interface.smooth("VEC4", "vStrokeContact")
        interface.smooth("VEC2", "vStrokeUV")
        interface.smooth("VEC4", "vStrokeParams")
        interface.smooth("VEC2", "uv")
        interface.smooth("FLOAT", "vLinearDepth")
        interface.flat("VEC4", "vStrokeStyle")
        info.push_constant("FLOAT", "strokeStrength")
        info.push_constant("FLOAT", "strokeBandAmount")
        info.sampler(0, "FLOAT_2D", "brushTex")
        info.sampler(1, "FLOAT_2D", "loadedBrushTex")
        info.sampler(2, "FLOAT_2D", "ownershipTex")
    elif name == "linear_depth":
        info.vertex_in(0, "VEC4", "clipPosition")
        info.vertex_in(1, "FLOAT", "linearDepth")
        info.vertex_in(2, "FLOAT", "surfaceOwner")
        interface.flat("FLOAT", "vSurfaceOwner")
        interface.smooth("FLOAT", "vLinearDepth")
        info.push_constant("VEC2", "depthRange")
    elif name == "motion_geometry":
        info.vertex_in(0, "VEC3", "position")
        info.vertex_in(1, "VEC2", "velocity")
        info.vertex_in(2, "VEC2", "acceleration")
        interface.smooth("VEC2", "vVelocity")
        interface.smooth("VEC2", "vAcceleration")
    elif name == "impact":
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        info.sampler(0, "FLOAT_2D", "subjectTex")
        info.sampler(1, "FLOAT_2D", "floorTex")
        info.sampler(2, "FLOAT_2D", "brushTex")
        info.sampler(3, "FLOAT_2D", "motionTex")
        info.sampler(4, "FLOAT_2D", "backgroundMotionTex")
        info.sampler(10, "FLOAT_2D", "backgroundFamilyTex")
        info.sampler(11, "FLOAT_2D", "radialSeedTex")
        info.sampler(5, "FLOAT_2D", "ownershipTex")
        info.sampler(6, "FLOAT_2D", "ownerBoundsTex")
        info.sampler(7, "FLOAT_2D", "loadedBrushTex")
        info.sampler(8, "FLOAT_2D", "ownerSurfaceTex")
        info.sampler(9, "FLOAT_2D", "linearStrokeTex")
        for kind, uniform in (
            ("VEC2", "resolution"), ("INT", "mode"), ("INT", "layerOnly"),
            ("INT", "hybridMode"), ("INT", "radialEnabled"),
            ("INT", "ownerCount"),
            ("FLOAT", "angle"),
            ("VEC2", "focus"), ("FLOAT", "strength"), ("FLOAT", "salt"),
            ("FLOAT", "backgroundSalt"), ("FLOAT", "backgroundFrame"),
            ("FLOAT", "lineThickness"),
            ("VEC2", "subjectMotion"), ("VEC2", "backgroundMotion"),
            ("VEC2", "subjectAcceleration"),
            ("VEC2", "backgroundAcceleration"),
            ("FLOAT", "velocityScale"), ("FLOAT", "motionCurveInfluence"),
            ("FLOAT", "backgroundIntensity"),
            ("FLOAT", "backgroundLayer"),
            ("INT", "backgroundSubjectOnly"),
            ("INT", "backgroundSpace3D"),
            ("VEC2", "backgroundFocus"),
            ("VEC4", "backgroundBounds"),
            ("FLOAT", "backgroundDepthInfluence"),
            ("FLOAT", "backgroundMotionInfluence"),
            ("FLOAT", "bandTransition"), ("FLOAT", "radialThreshold"),
            ("FLOAT", "radialSpiral"),
            ("FLOAT", "contrast"), ("FLOAT", "lightIntensity"),
            ("VEC4", "flowSource"), ("FLOAT", "haloSpread"),
            ("FLOAT", "linearReady"),
            ("VEC4", "subjectBounds"), ("FLOAT", "subjectDrawingScale"), ("FLOAT", "backgroundPlaneDepth"),
            ("VEC4", "backgroundAffineX"),
            ("VEC4", "backgroundAffineY"),
        ):
            info.push_constant(kind, uniform)
    elif name == "impact_layers":
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        info.sampler(0, "FLOAT_2D", "subjectTex")
        info.sampler(1, "FLOAT_2D", "floorTex")
    elif name == "grain_distance":
        info.vertex_in(0,"VEC2","position")
        info.vertex_in(1,"VEC2","texCoord")
        interface.smooth("VEC2","uv")
        info.sampler(0,"FLOAT_2D","impactTex")
        info.sampler(1,"FLOAT_2D","shapeMaskTex")
        info.sampler(2,"FLOAT_2D","seedTex")
        info.push_constant("VEC2","sourceResolution")
        info.push_constant("INT","jump")
    elif name == "grain":
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        info.sampler(0, "FLOAT_2D", "impactTex")
        info.sampler(1, "FLOAT_2D", "shapeMaskTex")
        for kind, uniform in (
            ("VEC2", "paperResolution"),
            ("FLOAT", "dustAmount"),
            ("FLOAT", "filmAmount"), ("FLOAT", "salt"),
        ):
            info.push_constant(kind, uniform)
    elif name == "grain_apply":
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        for index, uniform in enumerate(("colorTex", "grainTex", "shapeMaskTex")):
            info.sampler(index, "FLOAT_2D", uniform)
        info.push_constant("VEC4", "foreground")
    elif name == "optical_guide":
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        info.sampler(0, "FLOAT_2D", "impactTex")
        info.sampler(1, "FLOAT_2D", "seedTex")
        info.push_constant("VEC2", "resolution")
        info.push_constant("INT", "jump")
    elif name == "effect_direction":
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        for index, uniform in enumerate(("ownershipTex", "rigTex", "ownerRigTex", "impactTex", "guideTex", "linearStrokeTex")):
            info.sampler(index, "FLOAT_2D", uniform)
        info.push_constant("INT", "rigCount")
        info.push_constant("INT", "familyOverride")
        info.push_constant("VEC2", "resolution")
        info.push_constant("VEC4", "inverseProjectionW")
        info.push_constant("VEC4", "ownerDepthDecode")
        info.push_constant("VEC4", "linearDepthToW")
        info.push_constant("INT", "outputMode")
    elif name == "glitch":
        info.vertex_in(0,"VEC2","position")
        info.vertex_in(1,"VEC2","texCoord")
        interface.smooth("VEC2","uv")
        for index,name_ in enumerate(("colorTex","shapeMaskTex")):
            info.sampler(index,"FLOAT_2D",name_)
        for kind,name_ in (("VEC2","resolution"),("FLOAT","glitch"),
            ("FLOAT","glitchSize"),("FLOAT","glitchTime"),("FLOAT","glitchKey")):
            info.push_constant(kind,name_)
    elif name == "motion_blur":
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        info.sampler(0, "FLOAT_2D", "colorTex")
        info.sampler(1, "FLOAT_2D", "impactTex")
        info.sampler(2, "FLOAT_2D", "shapeMaskTex")
        info.sampler(3, "FLOAT_2D", "directionTex")
        info.sampler(4, "FLOAT_2D", "fieldOwnerTex")
        info.sampler(5, "FLOAT_2D", "underShapeTex")
        info.sampler(6, "FLOAT_2D", "shapeInfluencesTex")
        info.push_constant("VEC2", "backgroundFocus")
        info.push_constant("VEC2", "backgroundFlow")
        info.push_constant("VEC4", "backgroundShape")
        for kind, uniform in (
            ("VEC2", "resolution"), ("INT", "mode"),
            ("VEC2", "focus"),
            ("FLOAT", "amount"), 
            ("INT", "sampleCount"),
            ("VEC4", "background"),
        ):
            info.push_constant(kind, uniform)
    elif name == "aberration_blend":
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        info.sampler(0, "FLOAT_2D", "colorTex")
        info.sampler(1, "FLOAT_2D", "grainTex")
        info.sampler(2, "FLOAT_2D", "impactTex")
        info.sampler(3, "FLOAT_2D", "shapeMaskTex")
        info.sampler(4, "FLOAT_2D", "gradientTex")
        info.sampler(5, "FLOAT_2D", "spectralTex")
        info.sampler(7, "FLOAT_2D", "directionTex")
        info.sampler(8, "FLOAT_2D", "fieldOwnerTex")
        info.sampler(9, "FLOAT_2D", "underShapeTex")
        info.sampler(10, "FLOAT_2D", "shapeInfluencesTex")
        info.push_constant("VEC2", "backgroundFocus")
        info.push_constant("VEC2", "backgroundFlow")
        info.push_constant("VEC4", "backgroundShape")
        for kind, uniform in (
            ("VEC2", "resolution"), ("FLOAT", "angle"),
            ("FLOAT", "aberration"), ("FLOAT", "halftone"),
            ("FLOAT", "aberrationIntensity"),
            ("FLOAT", "aberrationTaper"),
            ("FLOAT", "grainActive"), 
            ("VEC4", "foreground"),
            ("VEC4", "background"), ("FLOAT", "singleColorActive"),
            ("VEC4", "singleColor"), ("FLOAT", "blurSmoothing"),
            ("INT", "sampleCount"),
        ):
            info.push_constant(kind, uniform)
    elif name == "rig_merge":
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        for index, sampler in enumerate(("backColor", "frontColor", "backMask", "frontMask", "backShape", "frontShape")):
            info.sampler(index, "FLOAT_2D", sampler)
        info.push_constant("VEC4", "paper")
        info.push_constant("INT", "outputMode")
        info.push_constant("INT", "frontRig")
        info.push_constant("VEC4", "frontPigment")
    elif name == "bloom_extract":
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        info.sampler(0, "FLOAT_2D", "colorTex")
        info.sampler(1, "FLOAT_2D", "impactTex")
        info.sampler(2, "FLOAT_2D", "grainTex")
        info.sampler(3, "FLOAT_2D", "shapeMaskTex")
        for kind, uniform in (
            ("VEC2", "resolution"),
            ("VEC4", "foreground"), ("VEC4", "background"),
            ("FLOAT", "aberrationActive"),
            ("FLOAT", "grainActive"), ("FLOAT", "grainBloomMix"),
        ):
            info.push_constant(kind, uniform)
    elif name == "bloom_down":
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        info.sampler(0, "FLOAT_2D", "colorTex")
        for kind, uniform in (
            ("VEC2", "sourceResolution"),
        ):
            info.push_constant(kind, uniform)
    elif name == "bloom_up":
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        info.sampler(0, "FLOAT_2D", "lowTex")
        info.sampler(1, "FLOAT_2D", "highTex")
        for kind, uniform in (
            ("VEC2", "lowResolution"), ("FLOAT", "lowWeight"),
            ("FLOAT", "highWeight"),
        ):
            info.push_constant(kind, uniform)
    elif name == "bloom":
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        info.sampler(0, "FLOAT_2D", "colorTex")
        info.sampler(1, "FLOAT_2D", "glowTex")
        info.sampler(2, "FLOAT_2D", "coreTex")
        for kind, uniform in (("FLOAT", "bloom"),):
            info.push_constant(kind, uniform)
    elif name == "preview_upscale":
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        info.sampler(0, "FLOAT_2D", "colorTex")
        info.push_constant("VEC2", "sourceResolution")
        info.push_constant("VEC2", "outputResolution")
        info.push_constant("FLOAT", "quality")
    elif name == "mask_resolve":
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        info.sampler(0, "FLOAT_2D", "impactTex")
        info.push_constant("VEC2", "resolution")
    elif name == "shapes":
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        info.sampler(0, "FLOAT_2D", "colorTex")
        info.sampler(1, "FLOAT_2D", "subjectTex")
        info.sampler(2, "FLOAT_2D", "shapeTex")
        info.sampler(3, "FLOAT_2D", "impactTex")
        info.sampler(4, "FLOAT_2D", "grainTex")
        info.push_constant("VEC2", "resolution")
        info.push_constant("INT", "shapeCount")
        info.push_constant("INT", "maskOnly")
        info.push_constant("FLOAT", "halftone")
        info.push_constant("FLOAT", "halftoneSize")
        info.push_constant("VEC2", "paperResolution")
        info.push_constant("FLOAT", "grainActive")
        info.push_constant("VEC4", "frameInk")
        info.push_constant("VEC4", "framePaper")
    elif name == "grade":
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        info.sampler(0, "FLOAT_2D", "colorTex")
        for kind, uniform in (
            ("FLOAT", "contrast"), ("FLOAT", "grayscale"),
            ("FLOAT", "negative"),
        ):
            info.push_constant(kind, uniform)
    elif name == "pixelate":
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        info.sampler(0, "FLOAT_2D", "colorTex")
        info.sampler(1, "FLOAT_2D", "impactTex")
        info.sampler(2, "FLOAT_2D", "shapeMaskTex")
        for kind, uniform in (
            ("VEC2", "resolution"), ("FLOAT", "pixelate"),
            ("FLOAT", "pixelSize"),
        ):
            info.push_constant(kind, uniform)
    else:
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        info.sampler(0, "FLOAT_2D", "impactTex")
        info.sampler(1, "FLOAT_2D", "subjectTex")
        info.sampler(2, "FLOAT_2D", "gradientTex")
        info.sampler(3, "FLOAT_2D", "grainTex")
        for kind, uniform in (
            ("VEC2", "resolution"), ("INT", "mode"), ("FLOAT", "angle"),
            ("VEC2", "focus"), ("FLOAT", "aberration"),
            ("VEC4", "foreground"), ("VEC4", "background"),
            ("VEC4", "backgroundLineColor"),
            ("FLOAT", "bleedAmount"),
            ("FLOAT", "halftone"),
            ("FLOAT", "halftoneSize"),
            ("VEC2", "paperResolution"),
            ("FLOAT", "aberrationSpread"),
            ("FLOAT", "aberrationIntensity"),
            ("FLOAT", "grainActive"),
            ("FLOAT", "singleColorActive"),
            ("VEC4", "singleColor"), ("FLOAT", "directionPolarity"),
            ("VEC2", "cameraMotion"),
        ):
            info.push_constant(kind, uniform)
    info.vertex_out(interface)
    info.fragment_out(0, "VEC4", "fragColor")
    info.vertex_source(_shader_body(vertex))
    info.fragment_source(_shader_body(fragment))
    return gpu.shader.create_from_info(info)
