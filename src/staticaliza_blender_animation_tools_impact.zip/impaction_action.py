"""Small Blender 4.2/5.x action compatibility layer for Impact markers."""

import secrets
import math
import bpy

from .impaction_constants import MARKER_GROUP, MARKER_HOST, MARKER_PROPERTY


_COLLAPSE_TIMER_KEY = "staticaliza_blender_animation_tools_impact.collapse_marker_host_timer"
_COLLAPSE_RETRY_INTERVAL = 0.1
_COLLAPSE_MAX_ATTEMPTS = 20
_collapse_attempts = 0
_channel_expansion_history = None
_channel_expansion_restore = None


def capture_marker_channel_expansion():
    """Channel folding is editor intent, independent of animation Undo."""
    global _channel_expansion_history
    host = impact_marker_host(False)
    action = getattr(getattr(host, 'animation_data', None), 'action', None)
    if host is None or action is None:
        _channel_expansion_history = None
        return
    groups = (g for bag in action_channelbags(action, host) for g in bag.groups)
    _channel_expansion_history = {
        'done': bool(host.get('impaction_initial_expand_done', False)),
        'slots': {slot.handle: bool(slot.show_expanded) for slot in getattr(action, 'slots', ())},
        'groups': {g.name: (bool(g.show_expanded), bool(g.show_expanded_graph)) for g in groups},
    }


def _apply_marker_channel_expansion(host, state):
    action = getattr(getattr(host, 'animation_data', None), 'action', None)
    if action is None:
        return
    for slot in getattr(action, 'slots', ()):
        if slot.handle in state['slots']:
            slot.show_expanded = state['slots'][slot.handle]
    for bag in action_channelbags(action, host):
        for group in bag.groups:
            if group.name in state['groups']:
                group.show_expanded, group.show_expanded_graph = state['groups'][group.name]


def restore_marker_channel_expansion():
    global _channel_expansion_restore
    state = _channel_expansion_history
    host = impact_marker_host(False)
    action = getattr(getattr(host, 'animation_data', None), 'action', None)
    if not state or host is None or action is None:
        return
    reveal = state['done'] and any(state['slots'].values()) and (
        not host.get('impaction_initial_expand_done', False)
        or any(not slot.show_expanded and state['slots'].get(slot.handle, False)
               for slot in getattr(action, 'slots', ())))
    _apply_marker_channel_expansion(host, state)
    if reveal:
        _channel_expansion_restore = state
        host['impaction_initial_expand_done'] = False
        schedule_marker_host_collapse()
    elif state['done']:
        host['impaction_initial_expand_done'] = True


def collapse_marker_collection_once():
    """Scope native Outliner collapse to this collection, preserving other rows."""
    collection = bpy.data.collections.get("IMPACT FRAME")
    if collection is None or not collection.get("_impact_initial_collapse_pending", False):
        return
    completed = False
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type != "OUTLINER" or area.spaces.active.display_mode != "VIEW_LAYER":
                continue
            space = area.spaces.active
            region = next((r for r in area.regions if r.type == "WINDOW"), None)
            if region is None:
                continue
            names = ("filter_text", "use_filter_complete", "use_filter_children", "use_filter_object")
            saved = {name: getattr(space, name) for name in names if hasattr(space, name)}
            try:
                space.filter_text = collection.name
                space.use_filter_complete = True
                space.use_filter_children = False
                if "use_filter_object" in saved:space.use_filter_object = False
                with bpy.context.temp_override(window=window, area=area, region=region):
                    # Rebuild the filtered native tree before the operator runs.
                    # Unmatched rows are absent, so their expansion is untouched.
                    bpy.ops.wm.redraw_timer(type="DRAW", iterations=1)
                    bpy.ops.outliner.show_one_level(open=False)
                    bpy.ops.outliner.show_one_level(open=False)
                completed = True
            except (AttributeError, ReferenceError, RuntimeError):
                continue
            finally:
                for name, value in saved.items():
                    setattr(space, name, value)
                area.tag_redraw()
    if completed:
        del collection["_impact_initial_collapse_pending"]


def configure_marker_host(host, scene=None):
    """Suppress helper drawing without hiding its animation owner/channels."""
    if host is None or not host.get("impaction_marker_host",False):return
    scene=scene or bpy.context.scene
    collection=bpy.data.collections.get("IMPACT FRAME")
    if collection is None:
        collection=bpy.data.collections.new("IMPACT FRAME")
        collection["_impact_initial_collapse_pending"] = True
    # Keep this same animation owner reachable in every scene that used it.
    scenes=[item for item in bpy.data.scenes if host.name in item.objects]
    if scene not in scenes:scenes.append(scene)
    for item in scenes:
        if collection.name not in item.collection.children:
            item.collection.children.link(collection)
    if host.name not in collection.objects:collection.objects.link(host)
    for previous in tuple(host.users_collection):
        if previous!=collection:previous.objects.unlink(host)
    # Image-empty display flags suppress its geometry in both projection
    # modes while Object visibility (and Dope Sheet filtering) stays native.
    host.empty_display_type="IMAGE"
    host.show_empty_image_perspective=False
    host.show_empty_image_orthographic=False
    host.hide_render=True


def impact_marker_host(create=False):
    """Scene-level animation owner shown as its own blue Dope Sheet row."""
    host = bpy.data.objects.get(MARKER_HOST)
    if host is None or not host.get("impaction_marker_host",False):
        host=next((obj for obj in bpy.data.objects if obj.get("impaction_marker_host",False)),None)
    if host is None and create:
        host = bpy.data.objects.new(MARKER_HOST, None)
        host.hide_render = True
        host["impaction_marker_host"] = True
    if host is not None and create:configure_marker_host(host)
    return host


def collapse_new_marker_host_once():
    """Reveal the generated Dope Sheet hierarchy once; preserve later folding."""
    global _collapse_attempts, _channel_expansion_restore
    if bpy.app.driver_namespace.get(_COLLAPSE_TIMER_KEY) is not collapse_new_marker_host_once:
        # A reload/unregister replaced or cancelled this exact callback.
        return None
    _collapse_attempts += 1
    collapse_marker_collection_once()
    host = impact_marker_host(False)
    if host is None or bool(host.get("impaction_initial_expand_done", False)):
        bpy.app.driver_namespace.pop(_COLLAPSE_TIMER_KEY, None)
        return None
    window_manager = getattr(bpy.context, "window_manager", None)
    for window in getattr(window_manager, "windows", ()) if window_manager else ():
        screen = getattr(window, "screen", None)
        for area in getattr(screen, "areas", ()) if screen else ():
            if area.type != "DOPESHEET_EDITOR":
                continue
            region = next((item for item in area.regions if item.type == "WINDOW"), None)
            if region is None:
                continue
            space = area.spaces.active
            if getattr(space,"mode","") != "DOPESHEET":
                continue
            dopesheet = getattr(space, "dopesheet", None)
            old_filter = getattr(dopesheet, "filter_text", "") if dopesheet else ""
            old_only_selected = getattr(dopesheet,"show_only_selected",False)
            saved_filters={name:getattr(dopesheet,name) for name in
                           ('show_extras','show_hidden','show_only_errors','filter_collection')
                           if dopesheet is not None and hasattr(dopesheet,name)}
            # Pose-mode objects remain in Blender's animation channel filter
            # even after select_set(False). Scope by collection membership,
            # not selection, so rig/action/group expansion is untouched.
            if dopesheet is None or not hasattr(dopesheet, "filter_collection"):
                continue
            scope = bpy.data.collections.new("_ImpactChannelExpandScope")
            scope.objects.link(host)
            try:
                dopesheet.filter_text = ""
                dopesheet.show_only_selected = False
                for name, value in (("show_extras", True), ("show_hidden", True),
                                    ("show_only_errors", False)):
                    if name in saved_filters:
                        setattr(dopesheet, name, value)
                dopesheet.filter_collection = scope
                with bpy.context.temp_override(
                    window=window, screen=screen, area=area, region=region,
                ):
                    result = bpy.ops.anim.channels_expand("EXEC_DEFAULT", False, all=True)
                    action = host.animation_data.action if host.animation_data else None
                    if action is not None:
                        for slot in getattr(action, "slots", ()):
                            slot.show_expanded = True
                        groups = tuple(action.groups) if hasattr(action, "groups") else tuple(
                            group for bag in action_channelbags(action, host) for group in bag.groups)
                        for group in groups:
                            group.show_expanded = False
                if "FINISHED" in result:
                    host["impaction_initial_expand_done"] = True
                    if _channel_expansion_restore is not None:
                        _apply_marker_channel_expansion(host, _channel_expansion_restore)
                        _channel_expansion_restore = None
            except (RuntimeError, TypeError):
                pass
            finally:
                dopesheet.filter_text = old_filter
                dopesheet.show_only_selected = old_only_selected
                for name, value in saved_filters.items():
                    setattr(dopesheet, name, value)
                bpy.data.collections.remove(scope)
                area.tag_redraw()
            if bool(host.get("impaction_initial_expand_done", False)):
                bpy.app.driver_namespace.pop(_COLLAPSE_TIMER_KEY, None)
                return None
    # The Dope Sheet may not exist until the workspace finishes switching.
    # Keep retries finite so a workspace without a Dope Sheet cannot leave a
    # permanent timer behind for the rest of the Blender session.
    if _collapse_attempts >= _COLLAPSE_MAX_ATTEMPTS:
        bpy.app.driver_namespace.pop(_COLLAPSE_TIMER_KEY, None)
        return None
    return _COLLAPSE_RETRY_INTERVAL


def cancel_marker_host_collapse_timer():
    """Remove this module's pending UI timer, including a stale reload copy."""
    global _collapse_attempts
    callback = bpy.app.driver_namespace.pop(_COLLAPSE_TIMER_KEY, None)
    if callback is not None:
        try:
            if bpy.app.timers.is_registered(callback):
                bpy.app.timers.unregister(callback)
        except (ReferenceError, RuntimeError, ValueError):
            pass
    _collapse_attempts = 0


def _marker_host_ui_available():
    return not bpy.app.background


def schedule_marker_host_collapse():
    """Queue first-use channel expansion and deduplicate repeated inserts."""
    global _collapse_attempts
    if not _marker_host_ui_available():
        return False
    callback = bpy.app.driver_namespace.get(_COLLAPSE_TIMER_KEY)
    if callback is collapse_new_marker_host_once:
        try:
            if bpy.app.timers.is_registered(callback):
                return False
        except (ReferenceError, RuntimeError, ValueError):
            pass
    elif callback is not None:
        # A prior module instance can survive a development reload. Use the
        # same driver-namespace ownership convention as the runtime timers.
        cancel_marker_host_collapse_timer()
    _collapse_attempts = 0
    bpy.app.driver_namespace[_COLLAPSE_TIMER_KEY] = collapse_new_marker_host_once
    try:
        bpy.app.timers.register(collapse_new_marker_host_once, first_interval=0.2)
    except (ReferenceError, RuntimeError, ValueError):
        bpy.app.driver_namespace.pop(_COLLAPSE_TIMER_KEY, None)
        return False
    return True


def _marker_owner(armature, create=False):
    return impact_marker_host(create=create) or armature


def action_channelbags(action, animated_id=None):
    if action is None or hasattr(action, "fcurves"):
        return ()
    target_handle = 0
    animation_data = getattr(animated_id, "animation_data", None)
    if animation_data and animation_data.action is action:
        target_handle = int(getattr(animation_data, "action_slot_handle", 0) or 0)
    result = []
    for layer in getattr(action, "layers", ()):
        for strip in getattr(layer, "strips", ()):
            if getattr(strip, "type", "") != "KEYFRAME":
                continue
            for bag in getattr(strip, "channelbags", ()):
                if target_handle and int(getattr(bag, "slot_handle", 0)) != target_handle:
                    continue
                result.append(bag)
    return tuple(result)


def action_fcurves(action, animated_id=None):
    if action is None:
        return ()
    legacy = getattr(action, "fcurves", None)
    if legacy is not None:
        return tuple(legacy)
    return tuple(curve for bag in action_channelbags(action, animated_id) for curve in bag.fcurves)


def ensure_channelbag(action, animated_id):
    if hasattr(action, "fcurves"):
        return None
    animation_data = animated_id.animation_data_create()
    slot = getattr(animation_data, "action_slot", None) if animation_data.action is action else None
    if slot is None:
        suitable = tuple(getattr(animation_data, "action_suitable_slots", ()))
        slot = suitable[0] if suitable else action.slots.new(animated_id.id_type, animated_id.name)
    if animation_data.action is action and animation_data.action_slot is not slot:
        animation_data.action_slot = slot
    for layer in action.layers:
        for strip in layer.strips:
            if getattr(strip, "type", "") == "KEYFRAME":
                bag = strip.channelbag(slot)
                if bag is not None:
                    return bag
    layer = action.layers[0] if action.layers else action.layers.new("Layer")
    strip = next((item for item in layer.strips if getattr(item, "type", "") == "KEYFRAME"), None)
    if strip is None:
        strip = layer.strips.new(type="KEYFRAME")
    return strip.channelbag(slot, ensure=True)


def ensure_action(armature):
    animation_data = armature.animation_data_create()
    if animation_data.action is None:
        animation_data.action = bpy.data.actions.new(f"{armature.name} Action")
    return animation_data.action


def _group_owners(action, animated_id):
    legacy = getattr(action, "groups", None)
    if legacy is not None:
        return (legacy,)
    return tuple(bag.groups for bag in action_channelbags(action, animated_id))


def order_impact_group_last(action, animated_id):
    """Keep Impact Frames in Blender's natural appended group position.

    Blender creates a new Action group at the end, which already gives new
    Impact channels the requested post-effect ordering. The old implementation
    rebuilt every Action group to force ordering. That invalidated native UI
    references held by an open Outliner and could trigger an access violation
    during its next redraw (Blender 5.2's ``but_equals_old`` path).

    Never replace or remove Action groups merely for cosmetic ordering. Older
    files retain their existing order safely; newly created Impact groups are
    appended last by Blender itself.
    """
    del action, animated_id


def _marker_property(camera, create=False, run_index=0):
    uid = int(camera.get("impaction_camera_uid", 0) or 0)
    if not uid and create:
        uid = secrets.randbelow(2_000_000_000) + 1
        camera["impaction_camera_uid"] = uid
    if not uid:
        return ""
    base = f"{MARKER_PROPERTY}_{uid}"
    return base if not run_index else f"{base}_run_{run_index}"


def marker_fcurves(armature, camera):
    base = _marker_property(camera, create=False)
    if not base:
        return ()
    prefix = f'["{base}'
    for owner in (impact_marker_host(False), armature):
        if owner is None:
            continue
        action = getattr(getattr(owner, "animation_data", None), "action", None)
        curves = tuple(
            curve for curve in action_fcurves(action, owner)
            if curve.data_path.startswith(prefix) and curve.data_path.endswith('"]')
        )
        if curves:
            return curves
    return ()


def marker_fcurve(armature, camera, create=False):
    owner = _marker_owner(armature, create=create)
    action = ensure_action(owner) if create else getattr(getattr(owner, "animation_data", None), "action", None)
    if action is None:
        return None
    property_name = _marker_property(camera, create=create)
    if not property_name:
        return None
    data_path = f'["{property_name}"]'
    found = next((curve for curve in action_fcurves(action, owner) if curve.data_path == data_path), None)
    if found or not create:
        return found
    legacy = getattr(action, "fcurves", None)
    if legacy is not None:
        curve = legacy.new(data_path=data_path, index=0, action_group=MARKER_GROUP)
    else:
        bag = ensure_channelbag(action, owner)
        curve = bag.fcurves.new(data_path=data_path, index=0)
        group = bag.groups.get(MARKER_GROUP) or bag.groups.new(MARKER_GROUP)
        curve.group = group
    order_impact_group_last(action, owner)
    return curve


def _new_run_curve(armature, camera, run_index):
    owner = _marker_owner(armature, create=True)
    action = ensure_action(owner)
    property_name = _marker_property(camera, create=True, run_index=run_index)
    owner[property_name] = 0.0
    data_path = f'["{property_name}"]'
    legacy = getattr(action, "fcurves", None)
    if legacy is not None:
        return legacy.new(data_path=data_path, index=0, action_group=MARKER_GROUP)
    bag = ensure_channelbag(action, owner)
    curve = bag.fcurves.new(data_path=data_path, index=0)
    group = bag.groups.get(MARKER_GROUP) or bag.groups.new(MARKER_GROUP)
    curve.group = group
    return curve


def _remove_curve(action, armature, curve):
    legacy = getattr(action, "fcurves", None)
    if legacy is not None:
        legacy.remove(curve)
        return
    for bag in action_channelbags(action, armature):
        if any(candidate.as_pointer() == curve.as_pointer() for candidate in bag.fcurves):
            bag.fcurves.remove(curve)
            return


def salt_value(salt):
    return float(int(salt)) / 2_000_000_001.0


def impact_grid_interval(scene, camera):
    """Fixed whole-frame spacing nearest to the requested Impact cadence.

    Blender playback visits whole frames. A fractional spacing such as 2.5
    would otherwise alternate between 2 and 3 frames. Use one stable spacing;
    exact half-frame ties round upward so the effect is not oversampled.
    """
    scene_fps = float(scene.render.fps) / max(0.0001, float(scene.render.fps_base))
    requested = max(1.0, float(camera.impaction_fps))
    return max(1, int(math.floor((scene_fps / requested) + 0.5)))


def impact_grid_frame(scene, camera, requested_frame, initialize=True):
    """Nearest integer timeline frame on this camera's Impact-only FPS grid."""
    if not camera.impaction_grid_initialized:
        existing = [int(record.frame) for record in camera.impaction_frames]
        anchor = min(existing) if existing else int(
            math.floor(float(requested_frame) + 0.5)
        )
        if initialize:
            camera.impaction_grid_anchor = anchor
            camera.impaction_grid_initialized = True
    else:
        anchor = int(camera.impaction_grid_anchor)
    interval = impact_grid_interval(scene, camera)
    slot = math.floor(((float(requested_frame) - anchor) / interval) + 0.5)
    return anchor + int(slot) * interval


def rebuild_marker_exposure(armature, camera):
    """Build one FCurve per contiguous exposure so gaps have no joining line."""
    old_curves = marker_fcurves(armature, camera)
    selected_salts = tuple(
        float(point.co.y)
        for curve in old_curves for point in curve.keyframe_points
        if getattr(point, "type", "") != "GENERATED"
        and (point.select_control_point or point.select_left_handle or point.select_right_handle)
    )
    for curve in old_curves:
        for owner in (impact_marker_host(False), armature):
            if owner is None:
                continue
            action = getattr(getattr(owner, "animation_data", None), "action", None)
            if action and any(candidate.as_pointer() == curve.as_pointer()
                              for candidate in action_fcurves(action, owner)):
                _remove_curve(action, owner, curve)
                break
    records = tuple(sorted(camera.impaction_frames, key=lambda item: int(item.frame)))
    if not records:
        return
    interval = impact_grid_interval(bpy.context.scene, camera)
    runs = []
    for record in records:
        if not runs or int(record.frame) != int(runs[-1][-1].frame) + interval:
            runs.append([])
        runs[-1].append(record)
    for run_index, run in enumerate(runs):
        # Actual editable markers and generated exposure tails must live on
        # separate FCurves. Otherwise moving a selected group forward can put
        # an actual key on the old unselected tail's frame; Blender merges the
        # coincident points before Python can reconcile them and silently
        # destroys one Impact record.
        curve = _new_run_curve(armature, camera, run_index * 2)
        for record_index,record in enumerate(run):
            value = salt_value(record.salt)
            point = curve.keyframe_points.insert(float(record.frame), value)
            point.interpolation = "CONSTANT"
            point.handle_left_type = "VECTOR"
            point.handle_right_type = "VECTOR"
            try:
                point.type = "KEYFRAME" if record_index==0 else "MOVING_HOLD"
            except (AttributeError, TypeError, ValueError):
                pass
            # FCurve coordinates are float32 while salts originate as Python
            # doubles. Exact/rounded equality intermittently lost selection
            # after a multi-key TIME_TRANSLATE; match with the same tolerance
            # used by record reconciliation instead.
            selected = any(abs(value - selected_value) <= 1.0e-5 for selected_value in selected_salts)
            point.select_control_point = selected
            point.select_left_handle = selected
            point.select_right_handle = selected
        curve.extrapolation = "CONSTANT"
        curve.update()

        last = run[-1]
        tail_curve = _new_run_curve(armature, camera, run_index * 2 + 1)
        tail_frames = (float(last.frame), float(int(last.frame) + interval))
        for tail_index, frame in enumerate(tail_frames):
            boundary = tail_curve.keyframe_points.insert(frame, salt_value(last.salt))
            boundary.interpolation = "CONSTANT"
            # Both generated exposure boundaries use Vector handles so the end
            # marker keeps the requested square/vector timeline appearance.
            boundary.handle_left_type = "VECTOR"
            boundary.handle_right_type = "VECTOR"
            try:
                boundary.type = "GENERATED"
            except (AttributeError, TypeError, ValueError):
                pass
            boundary.select_control_point = False
            boundary.select_left_handle = False
            boundary.select_right_handle = False
        tail_curve.extrapolation = "CONSTANT"
        tail_curve.update()
    owner = _marker_owner(armature, create=True)
    order_impact_group_last(owner.animation_data.action, owner)


def insert_marker(armature, camera, frame, salt):
    previous_curves=marker_fcurves(armature,camera)
    first_key=not any(getattr(point,'type','')!='GENERATED'
                      for curve in previous_curves for point in curve.keyframe_points)
    if first_key:
        host=impact_marker_host(create=True)
        host['impaction_initial_expand_done']=False
        cancel_marker_host_collapse_timer()
    property_name = _marker_property(camera, create=True)
    owner = _marker_owner(armature, create=True)
    owner[property_name] = salt_value(salt)
    curve = marker_fcurve(armature, camera, create=True)
    for candidate in curve.keyframe_points:
        candidate.select_control_point = False
        candidate.select_left_handle = False
        candidate.select_right_handle = False
    existing = next(
        (item for item in curve.keyframe_points if abs(item.co.x - float(frame)) < 0.001),
        None,
    )
    point = existing or curve.keyframe_points.insert(float(frame), salt_value(salt))
    if existing is not None:
        existing.co.y = salt_value(salt)
    if point is None:
        point = min(curve.keyframe_points, key=lambda item: abs(item.co.x - float(frame)))
    point.interpolation = "CONSTANT"
    try:
        point.type = "KEYFRAME"
    except (AttributeError, TypeError, ValueError):
        pass
    point.select_control_point = True
    curve.update()
    order_impact_group_last(owner.animation_data.action, owner)
    rebuild_marker_exposure(armature, camera)
    host = impact_marker_host(False)
    if host is not None and not bool(host.get("impaction_initial_expand_done", False)):
        schedule_marker_host_collapse()
    return marker_fcurve(armature, camera, create=False)


def remove_marker(armature, camera, frame, salt=None):
    curves = marker_fcurves(armature, camera)
    if not curves:
        return False
    value = salt_value(salt) if salt else None
    targets = [(curve, point) for curve in curves for point in curve.keyframe_points
               if getattr(point, "type", "") != "GENERATED"
               and abs(point.co.x - frame) < 0.001
               and (value is None or abs(point.co.y - value) < 1.0e-6)]
    for curve, point in targets:
        curve.keyframe_points.remove(point, fast=True)
    if targets:
        for curve in curves:
            curve.update()
    return bool(targets)
