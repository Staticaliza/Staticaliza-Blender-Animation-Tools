"""Precise camera-space focus and key-light pins."""

import time

import bpy
from bpy.props import StringProperty

from .impaction_discovery import camera_bone_binding, viewed_camera
from .impaction_renderer import camera_view_rect
from .impaction_runtime import displayed_frame_record, interactive_frame_record

_PIN_HIGHLIGHT_UNTIL = {"FOCUS": 0.0, "DIRECTION": 0.0, "LIGHT": 0.0}
_PIN_ACTIVE = {"FOCUS": False, "DIRECTION": False, "LIGHT": False}
_CURSOR_WINDOW = None


def _mark_pin_hover(role, hovered):
    _PIN_HIGHLIGHT_UNTIL.setdefault(role, 0.0)
    if hovered:
        # Selection and display passes may disagree for a frame on some GPUs.
        # A short release hysteresis prevents both opacity and cursor flicker.
        _PIN_HIGHLIGHT_UNTIL[role] = time.monotonic() + 0.14


def set_pin_active(role, active):
    _PIN_ACTIVE[role] = bool(active)


def _sync_move_cursor(context, enabled):
    global _CURSOR_WINDOW
    window = getattr(context, "window", None)
    if enabled and window is not None and _CURSOR_WINDOW is None:
        try:
            window.cursor_modal_set("SCROLL_XY")
            _CURSOR_WINDOW = window
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            _CURSOR_WINDOW = None
    elif not enabled and _CURSOR_WINDOW is not None:
        try:
            _CURSOR_WINDOW.cursor_modal_restore()
        except (AttributeError, ReferenceError, RuntimeError):
            pass
        _CURSOR_WINDOW = None


def pin_highlighted(role):
    return bool(_PIN_ACTIVE.get(role, False) or
                time.monotonic() < _PIN_HIGHLIGHT_UNTIL.get(role, 0.0))


class IMPACTION_GT_camera_pin(bpy.types.Gizmo):
    """Small diamond with an explicit hit test; never captures the whole viewport."""

    bl_idname = "IMPACTION_GT_camera_pin"
    role: StringProperty(default="FOCUS")

    def setup(self):
        self._shape = self.new_custom_shape("TRIS", (
            (0.0, 1.0), (1.0, 0.0), (0.0, 0.0),
            (1.0, 0.0), (0.0, -1.0), (0.0, 0.0),
            (0.0, -1.0), (-1.0, 0.0), (0.0, 0.0),
            (-1.0, 0.0), (0.0, 1.0), (0.0, 0.0),
        ))

    def draw(self, _context):
        _mark_pin_hover(self.role, bool(self.is_highlight))
        # The opaque Impact image is drawn in POST_PIXEL. Drawing the visible
        # gizmo here as well caused two asynchronously highlighted diamonds to
        # alternate on hover. The post-image overlay owns visible pixels;
        # this gizmo supplies only the precise interaction/select surface.

    def draw_select(self, _context, select_id):
        self.draw_custom_shape(self._shape, matrix=self.matrix_basis, select_id=select_id)

    def test_select(self, _context, location):
        dx = abs(float(location[0]) - float(self.matrix_basis[0][3]))
        dy = abs(float(location[1]) - float(self.matrix_basis[1][3]))
        return 0 if dx + dy <= 14.0 else -1


class IMPACTION_GGT_camera_pins(bpy.types.GizmoGroup):
    bl_idname = "IMPACTION_GGT_camera_pins"
    bl_label = "Impact Frame Camera Controls"
    bl_space_type = "VIEW_3D"
    bl_region_type = "WINDOW"
    bl_options = {"PERSISTENT", "SELECT"}

    @classmethod
    def poll(cls, context):
        camera = viewed_camera(context)
        eligible = bool(
            camera and camera_bone_binding(camera)[0] is not None
            and displayed_frame_record(context, camera) is not None
        )
        if not eligible:
            _sync_move_cursor(context, False)
        return eligible

    def setup(self, context):
        focus = self.gizmos.new(IMPACTION_GT_camera_pin.bl_idname)
        focus.role = "FOCUS"
        focus.color = (0.05, 0.20, 1.0)
        focus.color_highlight = (0.20, 0.48, 1.0)
        focus.alpha = 0.48
        focus.alpha_highlight = 0.96
        focus.scale_basis = 9.0
        focus.use_draw_modal = True
        focus.target_set_operator("impaction.drag_focus")
        self.focus = focus

        direction = self.gizmos.new(IMPACTION_GT_camera_pin.bl_idname)
        direction.role = "DIRECTION"
        direction.color = (1.0, 0.0, 1.0)
        direction.color_highlight = (1.0, 0.0, 1.0)
        direction.alpha = 0.52
        direction.alpha_highlight = 0.98
        direction.scale_basis = 9.0
        direction.use_draw_modal = True
        direction.target_set_operator("impaction.drag_direction")
        self.direction = direction

        light = self.gizmos.new(IMPACTION_GT_camera_pin.bl_idname)
        light.role = "LIGHT"
        light.color = (1.0, 1.0, 0.0)
        light.color_highlight = (1.0, 1.0, 0.0)
        light.alpha = 0.48
        light.alpha_highlight = 0.98
        light.scale_basis = 9.0
        light.use_draw_modal = True
        light.target_set_operator("impaction.drag_light")
        self.light = light

        self.shape_pins = []
        for index in range(16):
            pin = self.gizmos.new(IMPACTION_GT_camera_pin.bl_idname)
            pin.role = f"SHAPE:{index}"
            pin.color = (0.10, 0.88, 0.12)
            pin.color_highlight = (0.35, 1.0, 0.25)
            pin.alpha = 0.58
            pin.alpha_highlight = 1.0
            pin.scale_basis = 8.0
            pin.use_draw_modal = True
            props = pin.target_set_operator("impaction.drag_shape")
            props.shape_index = index
            self.shape_pins.append(pin)

    @staticmethod
    def _place(pin, point, rect, visible):
        if not visible:
            pin.hide = True
            pin.hide_select = True
            pin.matrix_basis[0][3] = -10000.0
            pin.matrix_basis[1][3] = -10000.0
            return
        x0, y0, x1, y1 = rect
        # Reloaded Gizmo instances can retain scale/rotation basis data from a
        # previous area. Rebuild a pure region-pixel translation every draw.
        pin.matrix_basis.identity()
        pin.matrix_basis[0][3] = x0 + float(point[0]) * (x1 - x0)
        pin.matrix_basis[1][3] = y0 + float(point[1]) * (y1 - y0)
        pin.matrix_basis[2][3] = 0.0
        pin.hide = False
        pin.hide_select = False

    def draw_prepare(self, context):
        camera = viewed_camera(context)
        record = interactive_frame_record(context, camera)
        if record is None:
            self._place(self.focus, (0.0, 0.0), (0, 0, 1, 1), False)
            self._place(self.direction, (0.0, 0.0), (0, 0, 1, 1), False)
            self._place(self.light, (0.0, 0.0), (0, 0, 1, 1), False)
            _sync_move_cursor(context, False)
            return
        rect = camera_view_rect(context, camera)
        # One magenta position is authoritative in every line mode.  The old
        # blue radial-focus property remains serialized only so older files can
        # still be read without losing data.
        self._place(self.focus, (0.0, 0.0), rect, False)
        direction_visible = True
        self._place(
            self.direction, record.direction_focus, rect, direction_visible,
        )
        self._place(self.light, record.light_focus, rect, True)
        for index, pin in enumerate(self.shape_pins):
            visible = index < len(record.shapes)
            point = record.shapes[index].position if visible else (0.0, 0.0)
            self._place(pin, point, rect, visible)
            if visible:
                _mark_pin_hover(pin.role, bool(pin.is_highlight))
        _mark_pin_hover("FOCUS", False)
        _mark_pin_hover("LIGHT", bool(self.light.is_highlight))
        _mark_pin_hover("DIRECTION", direction_visible and
                        bool(self.direction.is_highlight))
        _sync_move_cursor(context,
                          pin_highlighted("FOCUS") or
                          pin_highlighted("DIRECTION") or
                          pin_highlighted("LIGHT") or
                          any(pin_highlighted(pin.role)
                              for pin in self.shape_pins))


GIZMO_CLASSES = (IMPACTION_GT_camera_pin, IMPACTION_GGT_camera_pins)
