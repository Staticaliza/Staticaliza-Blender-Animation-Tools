"""Persistent Blender Color Ramps used by Impact Frame aberration."""

import math
import bpy

_RAMP_PREFIX = "Impaction Aberration "
_NODE_NAME = "Aberration Gradient"
_COLOR_COUNT_KEY = "impaction_color_count"
MAX_ABERRATION_COLORS = 8
_SAMPLE_COUNT = 17


def _asymmetric_gaussian(wavelength, mean, left_scale, right_scale):
    value = (wavelength - mean) * (
        left_scale if wavelength < mean else right_scale
    )
    return math.exp(-0.5 * value * value)


def _sensor_response(wavelength):
    """Positive linear-RGB response derived from the CIE 1931 observer."""
    # Multi-lobe fit from Wyman, Sloan and Shirley (JCGT 2013). Computing this
    # once in Python keeps the per-pixel shader to texture samples and mask
    # integration rather than evaluating 119 exponential functions per pixel.
    x_value = (
        0.362 * _asymmetric_gaussian(wavelength, 442.0, 0.0624, 0.0374)
        + 1.056 * _asymmetric_gaussian(wavelength, 599.8, 0.0264, 0.0323)
        - 0.065 * _asymmetric_gaussian(wavelength, 501.1, 0.0490, 0.0382)
    )
    y_value = (
        0.821 * _asymmetric_gaussian(wavelength, 568.8, 0.0213, 0.0247)
        + 0.286 * _asymmetric_gaussian(wavelength, 530.9, 0.0613, 0.0322)
    )
    z_value = (
        1.217 * _asymmetric_gaussian(wavelength, 437.0, 0.0845, 0.0278)
        + 0.681 * _asymmetric_gaussian(wavelength, 459.0, 0.0385, 0.0725)
    )
    linear_rgb = (
        3.2406 * x_value - 1.5372 * y_value - 0.4986 * z_value,
        -0.9689 * x_value + 1.8758 * y_value + 0.0415 * z_value,
        0.0557 * x_value - 0.2040 * y_value + 1.0570 * z_value,
    )
    positive = [max(0.0, value) for value in linear_rgb]
    # The 400--437 nm spectral locus falls outside linear sRGB and otherwise
    # clips to display-blue. Fold a bounded red component into that short-wave
    # tail so an ordinary RGB monitor represents it as violet rather than
    # falsely extending the blue band. This is a display-gamut mapping, not an
    # extra spatial dispersion sample.
    violet_weight = max(0.0, min(1.0, (437.0 - wavelength) / 37.0))
    positive[0] = max(positive[0], positive[2] * violet_weight * 0.56)
    peak = max(positive)
    return tuple(value / peak if peak > 1.0e-8 else 0.0 for value in positive)


# Seventeen CIE-derived sensor samples are integrated by the shader into three
# broad response channels. They are never emitted as seventeen visible bands.
_PRISM_COLORS = tuple(
    (*_sensor_response(400.0 + index * 300.0 / (_SAMPLE_COUNT - 1)), 1.0)
    for index in range(_SAMPLE_COUNT)
)

# Exact normalized RGB endpoints requested by the art direction. These named
# presets use the same continuous spectral texture as Custom, not two hard
# channel offsets, so their fringes remain smooth at large spread values.
_NAMED_PRESETS = {
    "CYAN_MAGENTA": ((0.0, 1.0, 1.0, 1.0), (1.0, 0.0, 1.0, 1.0)),
    "RED_CYAN": ((1.0, 0.0, 0.0, 1.0), (0.0, 1.0, 1.0, 1.0)),
    "GREEN_MAGENTA": ((0.0, 1.0, 0.0, 1.0), (1.0, 0.0, 1.0, 1.0)),
    "AMBER_BLUE": ((1.0, 183.0 / 255.0, 0.0, 1.0), (0.0, 0.0, 1.0, 1.0)),
    "RGB": (
        (0.0, 0.0, 1.0, 1.0),
        (0.0, 1.0, 0.0, 1.0),
        (1.0, 0.0, 0.0, 1.0),
    ),
    "CMY": (
        (1.0, 1.0, 0.0, 1.0),
        (1.0, 0.0, 1.0, 1.0),
        (0.0, 1.0, 1.0, 1.0),
    ),
}


def _preset_samples(colors):
    samples = []
    segment_count = max(1, len(colors) - 1)
    for index in range(_SAMPLE_COUNT):
        position = index / max(1, _SAMPLE_COUNT - 1) * segment_count
        segment = min(segment_count - 1, int(position))
        blend = min(1.0, position - segment)
        first, second = colors[segment], colors[segment + 1]
        samples.append(tuple(
            first[channel] + (second[channel] - first[channel]) * blend
            for channel in range(4)
        ))
    return samples


def _record_key(record):
    return max(1, int(getattr(record, "salt", 0)))


def ensure_aberration_ramp(record):
    name = str(getattr(record, "aberration_ramp", ""))
    tree = bpy.data.node_groups.get(name) if name else None
    node = tree.nodes.get(_NODE_NAME) if tree is not None else None
    if node is not None and node.bl_idname == "ShaderNodeValToRGB":
        return node

    tree = bpy.data.node_groups.new(
        f"{_RAMP_PREFIX}{_record_key(record)}", "ShaderNodeTree",
    )
    tree.use_fake_user = True
    node = tree.nodes.new("ShaderNodeValToRGB")
    node.name = _NODE_NAME
    node.label = "Custom Aberration Colors"
    ramp = node.color_ramp
    ramp.color_mode = "RGB"
    ramp.interpolation = "LINEAR"
    ramp.elements[0].position = 0.0
    ramp.elements[1].position = 1.0
    first = tuple(float(value) for value in record.aberration_color_a)
    legacy_custom = getattr(record, "aberration_preset", "PRISM") == "CUSTOM"
    if legacy_custom:
        second = tuple(float(value) for value in record.aberration_color_b)
        ramp.elements[0].color = first
        ramp.elements[1].color = second
        node[_COLOR_COUNT_KEY] = 2
    else:
        # A new Custom setup starts as one logical color. Blender ramps require
        # two physical endpoints, so both endpoints carry that exact color.
        ramp.elements[0].color = first
        ramp.elements[1].color = first
        node[_COLOR_COUNT_KEY] = 1
    record.aberration_ramp = tree.name
    return node


def aberration_color_elements(record):
    node = ensure_aberration_ramp(record)
    elements = tuple(sorted(node.color_ramp.elements, key=lambda item: item.position))
    count = max(1, min(MAX_ABERRATION_COLORS, int(node.get(_COLOR_COUNT_KEY, len(elements)))))
    return elements[:1] if count == 1 else elements[:count]


def aberration_colors(record):
    return tuple(tuple(float(value) for value in element.color) for element in aberration_color_elements(record))


def set_aberration_color(record, index, color):
    """Set one logical stop color without replacing neighboring stops."""
    elements = aberration_color_elements(record)
    if not 0 <= int(index) < len(elements):
        return False
    color = tuple(float(value) for value in color)
    element = elements[int(index)]
    if tuple(float(value) for value in element.color) == color:
        return False
    element.color = color
    if len(elements) == 1:
        # Blender requires two physical endpoints for a one-color logical ramp.
        ramp = ensure_aberration_ramp(record).color_ramp
        ramp.elements[1].color = color
    record["aberration_custom_initialized"] = True
    return True


def add_aberration_color(record):
    """Append one stop by duplicating this record's own final color."""
    colors = list(aberration_colors(record))
    if not colors or len(colors) >= MAX_ABERRATION_COLORS:
        return False
    colors.append(colors[-1])
    set_aberration_colors(record, colors)
    return True


def remove_aberration_color(record, index):
    """Remove one logical stop while preserving every remaining color."""
    colors = list(aberration_colors(record))
    if len(colors) <= 1 or not 0 <= int(index) < len(colors):
        return False
    colors.pop(int(index))
    set_aberration_colors(record, colors)
    return True


def set_aberration_colors(record, colors):
    colors = tuple(tuple(float(value) for value in color) for color in colors)
    if not colors:
        return
    colors = colors[:MAX_ABERRATION_COLORS]
    node = ensure_aberration_ramp(record)
    ramp = node.color_ramp
    while len(ramp.elements) > 2:
        ramp.elements.remove(ramp.elements[-1])
    ramp.color_mode = "RGB"
    ramp.interpolation = "LINEAR"
    physical = colors if len(colors) > 1 else (colors[0], colors[0])
    ramp.elements[0].position = 0.0
    ramp.elements[0].color = physical[0]
    ramp.elements[1].position = 1.0
    ramp.elements[1].color = physical[-1]
    for index, color in enumerate(physical[1:-1], start=1):
        element = ramp.elements.new(index / (len(physical) - 1))
        element.color = color
    node[_COLOR_COUNT_KEY] = len(colors)
    record["aberration_custom_initialized"] = True


def serialize_aberration_ramp(record, *, create=True):
    """Return ramp data without mutating Blender IDs when ``create`` is false.

    Collection-item copying happens while Blender is still editing the owning
    IDProperty group.  Creating a node group and assigning its name back to the
    source record from that read path can re-enter ``IDP_AddToGroup`` and crash
    Blender 5.2.  The Next-frame operator only needs a value snapshot, so a
    missing legacy ramp is serialized directly from its RNA colors instead.
    """
    name = str(getattr(record, "aberration_ramp", ""))
    tree = bpy.data.node_groups.get(name) if name else None
    node = tree.nodes.get(_NODE_NAME) if tree is not None else None
    if node is None or node.bl_idname != "ShaderNodeValToRGB":
        if create:
            node = ensure_aberration_ramp(record)
        else:
            first = tuple(float(value) for value in record.aberration_color_a)
            legacy_custom = getattr(record, "aberration_preset", "PRISM") == "CUSTOM"
            colors = (first, tuple(float(value) for value in record.aberration_color_b)) \
                if legacy_custom else (first,)
            return {
                "color_mode": "RGB", "interpolation": "LINEAR",
                "hue_interpolation": "NEAR", "color_count": len(colors),
                "elements": tuple(
                    (index / max(1, len(colors) - 1), color)
                    for index, color in enumerate(colors)
                ),
            }
    ramp = node.color_ramp
    elements = tuple(sorted(ramp.elements, key=lambda item: item.position))
    count = max(1, min(
        MAX_ABERRATION_COLORS,
        int(node.get(_COLOR_COUNT_KEY, len(elements))),
    ))
    colors = tuple(
        tuple(float(value) for value in element.color)
        for element in (elements[:1] if count == 1 else elements[:count])
    )
    return {
        "color_mode": ramp.color_mode,
        "interpolation": ramp.interpolation,
        "hue_interpolation": ramp.hue_interpolation,
        "color_count": len(colors),
        "elements": tuple(
            (index / max(1, len(colors) - 1), color)
            for index, color in enumerate(colors)
        ),
    }


def apply_aberration_ramp(record, values):
    elements = tuple(sorted(values.get("elements", ()), key=lambda item: item[0]))
    if not elements:
        return
    count = max(1, min(MAX_ABERRATION_COLORS, int(values.get("color_count", len(elements)))))
    colors = tuple(tuple(color) for _position, color in elements[:count])
    set_aberration_colors(record, colors)
    ramp = ensure_aberration_ramp(record).color_ramp
    ramp.color_mode = values.get("color_mode", "RGB")
    ramp.interpolation = values.get("interpolation", "LINEAR")
    ramp.hue_interpolation = values.get("hue_interpolation", "NEAR")


def copy_aberration_ramp(source, target):
    apply_aberration_ramp(target, serialize_aberration_ramp(source))


def aberration_glitch_colors(record):
    """Exact authored colors for solid glitch packets, without ramp averaging."""
    preset = getattr(record, "aberration_preset", "PRISM")
    if preset == "PRISM":
        return _PRISM_COLORS
    if preset in _NAMED_PRESETS:
        return _NAMED_PRESETS[preset]
    return aberration_colors(record)


def aberration_gradient_samples(record):
    preset = getattr(record, "aberration_preset", "PRISM")
    if preset == "PRISM":
        colors = list(_PRISM_COLORS)
        return colors, (1.0, 1.0, 1.0)
    if preset in _NAMED_PRESETS:
        return _preset_samples(_NAMED_PRESETS[preset]), (1.0, 1.0, 1.0)
    node = ensure_aberration_ramp(record)
    ramp = node.color_ramp
    logical = aberration_colors(record)
    if len(logical) == 1:
        colors = [logical[0]] * _SAMPLE_COUNT
    else:
        colors = [
            tuple(float(value) for value in ramp.evaluate(
                index / max(1, _SAMPLE_COUNT - 1)
            ))
            for index in range(_SAMPLE_COUNT)
        ]
    # Kept as a compatibility return value for callers/tests. The shader no
    # longer performs per-channel normalization because that distorts ramps
    # containing black or repeated colors.
    return colors, (1.0, 1.0, 1.0)


def aberration_ramp_signature(record):
    values = serialize_aberration_ramp(record)
    return (
        values["color_mode"], values["interpolation"], values["hue_interpolation"],
        values["color_count"],
        tuple(
            (round(position, 5), tuple(round(float(channel), 5) for channel in color))
            for position, color in values["elements"]
        ),
    )


def remove_aberration_ramp(record):
    tree = bpy.data.node_groups.get(str(getattr(record, "aberration_ramp", "")))
    if tree is not None:
        bpy.data.node_groups.remove(tree)
    record.aberration_ramp = ""
