"""Compare authored capture inputs without seeking frames or recapturing meshes."""
import hashlib,json
from array import array
import bpy
from .impaction_action import action_fcurves
from .impaction_discovery import resolve_sources

_cache={}
_mesh_cache={}

def invalidate(scene=None, depsgraph=None):
    _cache.clear()
    if depsgraph is None:
        _mesh_cache.clear()
    else:
        for update in depsgraph.updates:
            owner=getattr(update.id,'original',update.id)
            if isinstance(owner,bpy.types.Mesh):_mesh_cache.pop(owner.as_pointer(),None)

def _value(value):
    if isinstance(value,(str,int,float,bool)) or value is None:return value
    if isinstance(value,bpy.types.ID):return (value.bl_rna.identifier,value.name_full)
    if hasattr(value,'to_dict'):return _value(value.to_dict())
    if isinstance(value,dict):return tuple((key,_value(item)) for key,item in sorted(value.items()))
    try:return tuple(_value(item) for item in value)
    except TypeError:return None

def _settings(owner,animated=()):
    if owner is None:return ()
    result=[]
    for prop in owner.bl_rna.properties:
        if prop.is_readonly or prop.type=='COLLECTION' or prop.identifier in {'name','name_full'}:continue
        if prop.identifier.startswith('show_'):continue
        try:
            path=owner.path_from_id(prop.identifier) if hasattr(owner,'path_from_id') else ''
            if (path,0) in animated and not getattr(prop,'is_array',False):continue
            value=getattr(owner,prop.identifier)
            if getattr(prop,'is_array',False) and any((path,i) in animated for i in range(len(value))):
                value=tuple((i,_value(item)) for i,item in enumerate(value) if (path,i) not in animated)
            result.append((prop.identifier,_value(value)))
        except (AttributeError,ReferenceError,RuntimeError,TypeError,ValueError):continue
    return result

def _animation(owner):
    data=getattr(owner,'animation_data',None)
    if data is None:return (),set()
    curves=action_fcurves(data.action,owner)
    animated={(fc.data_path,int(fc.array_index)) for fc in curves}
    payload=[]
    deviations=[]
    for fc in curves:
        if 'impaction_marker' in fc.data_path:continue
        payload.append((fc.data_path,fc.array_index,fc.mute,fc.extrapolation,
            [(tuple(k.co),k.interpolation,k.easing,tuple(k.handle_left),tuple(k.handle_right),
              k.amplitude,k.back,k.period) for k in fc.keyframe_points],
            [_settings(modifier) for modifier in fc.modifiers]))
        # A manual pose edit on an animated component is still a new input.
        # Record its deviation from the curve, not its time-varying value.
        if not fc.mute and not data.nla_tracks:
            try:
                value=owner.path_resolve(fc.data_path)
                value=float(value[fc.array_index] if hasattr(value,'__len__') else value)
                delta=value-float(fc.evaluate(bpy.context.scene.frame_current_final))
                if abs(delta)>5.e-6:deviations.append((fc.data_path,fc.array_index,round(delta,5)))
            except (AttributeError,ValueError,TypeError,IndexError):pass
    drivers=[]
    for fc in data.drivers:
        animated.add((fc.data_path,int(fc.array_index)))
        drivers.append((fc.data_path,fc.array_index,fc.mute,fc.driver.type,fc.driver.expression,
            [(v.name,v.type,[_settings(target) for target in v.targets]) for v in fc.driver.variables]))
    # NLA's timing and weights are inputs even with an unchanged active Action.
    tracks=[(track.mute,track.is_solo,[_settings(strip) for strip in track.strips]) for track in data.nla_tracks]
    nla_actions=[]
    for track in data.nla_tracks:
        for strip in track.strips:
            if strip.action is not None and strip.action!=data.action:
                animated.update((fc.data_path,int(fc.array_index)) for fc in action_fcurves(strip.action))
                nla_actions.append([(fc.data_path,fc.array_index,[(tuple(k.co),k.interpolation,tuple(k.handle_left),tuple(k.handle_right)) for k in fc.keyframe_points])
                                    for fc in action_fcurves(strip.action)])
    return (payload,drivers,tracks,nla_actions,deviations),animated

def _transforms(owner,animated,prefix=''):
    values=[]
    for name in ('location','rotation_euler','rotation_quaternion','rotation_axis_angle','scale',
                 'delta_location','delta_rotation_euler','delta_rotation_quaternion','delta_scale'):
        value=getattr(owner,name,None)
        if value is not None:values.append((name,[(i,float(v)) for i,v in enumerate(value) if (prefix+name,i) not in animated]))
    return (getattr(owner,'rotation_mode',''),values)

def _mesh(mesh):
    key=mesh.as_pointer()
    if key not in _mesh_cache:
        digest=hashlib.blake2b(digest_size=16)
        for collection,attribute,width,kind in ((mesh.vertices,'co',3,'f'),(mesh.edges,'vertices',2,'i'),(mesh.loops,'vertex_index',1,'i'),(mesh.polygons,'loop_total',1,'i')):
            data=array(kind,[0])*(len(collection)*width)
            if data:collection.foreach_get(attribute,data)
            digest.update(data.tobytes())
        keys=mesh.shape_keys
        if keys is not None:
            for block in keys.key_blocks:
                data=array('f',[0])*(len(block.data)*3)
                if data:block.data.foreach_get('co',data)
                digest.update(data.tobytes())
        # Armature weights affect the captured pose without moving base verts.
        for vertex in mesh.vertices:
            digest.update(repr(tuple((group.group,group.weight) for group in vertex.groups)).encode())
        _mesh_cache[key]=digest.hexdigest()
    keys=mesh.shape_keys
    return (_mesh_cache[key],_animation(keys)[0] if keys else (),
            [(block.name,block.value,block.mute) for block in keys.key_blocks] if keys else ())

def signature(context,camera):
    scene=context.scene;key=(scene.as_pointer(),camera.as_pointer())
    if key in _cache:return _cache[key]
    subjects,_=resolve_sources(context)
    objects=set(subjects+[camera]);pending=list(objects)
    while pending:
        owner=pending.pop()
        targets=[owner.parent]
        constraints=list(owner.constraints)
        if owner.type=='ARMATURE':constraints.extend(c for bone in owner.pose.bones for c in bone.constraints)
        targets.extend(getattr(c,'target',None) for c in constraints)
        targets.extend(getattr(modifier,'object',None) for modifier in owner.modifiers)
        for target in targets:
            if isinstance(target,bpy.types.Object) and target not in objects:objects.add(target);pending.append(target)
    payload=[]
    for owner in sorted(objects,key=lambda obj:obj.name_full):
        animation,animated=_animation(owner)
        bones=[]
        if owner.type=='ARMATURE':
            for bone in owner.pose.bones:
                # Simulation publishes channel values. Its authored markers,
                # stored starts and relationship constraints own those inputs.
                simulated=('Ragdoll Enabled' in bone)
                custom=[(name,_value(bone[name])) for name in sorted(bone.keys())
                        if not any(word in name.lower() for word in ('color','label','preview','cache'))
                        and (bone.path_from_id('['+json.dumps(name)+']'),0) not in animated]
                bones.append((bone.name,tuple(tuple(row) for row in bone.bone.matrix_local),
                    bone.parent.name if bone.parent else '',
                    () if simulated else _transforms(bone,animated,bone.path_from_id()+'.'),
                    [_settings(c,animated) for c in bone.constraints],custom))
        camera_animation,camera_animated=_animation(owner.data) if owner.type=='CAMERA' else ((),set())
        geometry=_mesh(owner.data) if owner.type=='MESH' else (_settings(owner.data,camera_animated),camera_animation) if owner.type=='CAMERA' else ()
        payload.append((owner.name_full,owner.type,owner.parent.name_full if owner.parent else '',
            owner.parent_type,owner.parent_bone,tuple(tuple(row) for row in owner.matrix_parent_inverse),
            _transforms(owner,animated),animation,bones,geometry,
            [_settings(c,animated) for c in owner.constraints],[_settings(m,animated) for m in owner.modifiers]))
    render=scene.render
    result=hashlib.blake2b(repr((payload,render.resolution_x,render.resolution_y,
        render.pixel_aspect_x,render.pixel_aspect_y,render.fps,render.fps_base)).encode(),digest_size=20).hexdigest()
    _cache[key]=result;return result

def remember(context,camera,records):
    invalidate(context.scene)
    value=signature(context,camera)
    for record in records:
        record['_capture_inputs_v1']=value;record['_capture_inputs_frame']=int(record.frame)

def needs_update(context,camera,record):
    if not record.capture_subject or not record.capture_floor:return True
    if int(record.get('_capture_inputs_frame',-1))!=int(record.frame):return True
    saved=str(record.get('_capture_inputs_v1',''))
    return not saved or saved!=signature(context,camera)
