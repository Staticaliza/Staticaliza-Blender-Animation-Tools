import secrets
import math

import bpy
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    FloatVectorProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import PropertyGroup


def _changed(property_name):
    def update(self, context):
        try:
            from .impaction_runtime import property_changed
            property_changed(self, context, property_name)
        except (ImportError, RuntimeError):
            pass
    return update


def _legacy_mode_changed(record, context):
    """Map the former exclusive enum onto independent line toggles."""
    if not bool(record.get("_syncing_line_modes", False)):
        record["_syncing_line_modes"] = True
        try:
            mode = str(record.mode)
            record.linear_enabled = mode == "LINEAR"
            record.radial_enabled = mode == "RADIAL"
        finally:
            del record["_syncing_line_modes"]
    _changed("mode")(record, context)


def _background_layer_changed(property_name, incompatible_name):
    """Keep the 2D/3D background layers mutually exclusive."""
    def update(record, context):
        if bool(getattr(record, property_name, False)):
            # Writing the backing ID property avoids a second recursive RNA
            # callback while still normalizing files or scripts that set both.
            record[incompatible_name] = False
        _changed(property_name)(record, context)
    return update


def _background_mode_get(record):
    if bool(record.background_3d_enabled):
        return 2
    if bool(record.background_2d_enabled):
        return 1
    return 0


def _background_mode_set(record, value):
    value = int(value)
    if value == _background_mode_get(record):
        return
    # One atomic discrete edit. Two nested Bool callbacks previously queued
    # drag previews and could wait forever for a release the enum never owned.
    record["background_2d_enabled"] = value == 1
    record["background_3d_enabled"] = value == 2
    _changed("background_mode")(record, bpy.context)


def shape_selection_indices(record):
    """Return only explicit transient shape selections."""
    return [
        index for index, shape in enumerate(record.shapes)
        if bool(getattr(shape, "is_selected", False))
    ]


_shape_selection_syncing = set()


def clear_shape_selection(record):
    """Clear every transient shape-selection field without selecting a fallback."""
    if record is None:
        return
    pointer = record.as_pointer()
    _shape_selection_syncing.add(pointer)
    try:
        for shape in record.shapes:
            shape.is_selected = False
        record.active_shape_index = -1
        record.shape_selection_anchor = -1
    finally:
        _shape_selection_syncing.discard(pointer)


def shape_selection_type(record):
    """Return the one selected shape type, or None for empty/mixed selections."""
    shape_types = {
        record.shapes[index].shape_type
        for index in shape_selection_indices(record)
    }
    return next(iter(shape_types)) if len(shape_types) == 1 else None


def _shape_owner(shape, context):
    pointer = shape.as_pointer()
    camera = getattr(shape, "id_data", None)
    candidates = (
        (camera,) if getattr(camera, "type", None) == "CAMERA"
        else tuple(
            owner for owner in getattr(getattr(context, "scene", None), "objects", ())
            if getattr(owner, "type", None) == "CAMERA"
        )
    )
    for owner in candidates:
        for record in getattr(owner, "impaction_frames", ()):
            if any(item.as_pointer() == pointer for item in record.shapes):
                return owner, record
    return None, None


def _shape_property_value(shape, property_name):
    value = getattr(shape, property_name)
    if property_name in {"position", "foreground", "background", "stroke_color", "perspective"}:
        return tuple(value)
    return value


def _assign_shape_property(shape, property_name, value):
    """Let each changed selected shape redraw once; no-op setters stay quiet."""
    setattr(shape, property_name, value)


def _sync_selected_shape_property(record, source, property_name):
    """Copy one edited property across a homogeneous shape selection."""
    indices = shape_selection_indices(record)
    selected = [record.shapes[index] for index in indices]
    source_pointer = source.as_pointer()
    if not any(shape.as_pointer() == source_pointer for shape in selected):
        return ()
    if len(selected) < 2:
        return tuple(selected)

    if property_name == "shape_type":
        # The callback sees the source's new type. The remaining selected rows
        # still carry the common old type until this propagation completes.
        other_types = {
            shape.shape_type for shape in selected
            if shape.as_pointer() != source_pointer
        }
        if len(other_types) > 1:
            return (source,)
    elif len({shape.shape_type for shape in selected}) != 1:
        return (source,)

    value = _shape_property_value(source, property_name)
    record["_syncing_shape_properties"] = True
    try:
        for shape in selected:
            if shape.as_pointer() != source_pointer:
                _assign_shape_property(shape, property_name, value)
    finally:
        del record["_syncing_shape_properties"]
    return tuple(selected)


def _sync_selected_frame_shape_property(
        owner, record, source_shapes, property_name):
    """Copy one nested property to same-named shapes on selected frames."""
    if not source_shapes:
        return
    from .impaction_runtime import selected_property_records
    from .impaction_renderer import invalidate_record_signature
    from .impaction_runtime import schedule_live_render

    source_pointer = record.as_pointer()
    for target_record in selected_property_records(owner, record):
        if target_record.as_pointer() == source_pointer:
            continue
        by_name = {str(shape.name): shape for shape in target_record.shapes}
        changed = False
        target_record["_syncing_shape_properties"] = True
        try:
            for source_shape in source_shapes:
                target_shape = by_name.get(str(source_shape.name))
                if target_shape is None:
                    continue
                if (property_name != "shape_type" and
                        target_shape.shape_type != source_shape.shape_type):
                    continue
                value = _shape_property_value(source_shape, property_name)
                if _shape_property_value(target_shape, property_name) == value:
                    continue
                _assign_shape_property(target_shape, property_name, value)
                changed = True
        finally:
            del target_record["_syncing_shape_properties"]
        if changed:
            invalidate_record_signature(target_record)
            schedule_live_render(owner, target_record, input_change=True, shape_only=True)


_shape_assignment_changes = {}


def _shape_changed(property_name):
    """Sync one nested edit without replacing unrelated shape/frame data."""
    def update(shape, context):
        if not _shape_assignment_changes.pop((shape.as_pointer(), property_name), True):
            return
        try:
            from .impaction_runtime import (
                live_render_suspended, request_redraw, schedule_live_render,
            )
            from .impaction_renderer import invalidate_record_signature
            if (property_name not in {"layer", "stroke_color", "foreground", "background"}
                    and not bool(shape.get("_preserve_variation", False))):
                reroll_shape_variation(shape)
            owner, record = _shape_owner(shape, context)
            if record is None:
                return
            if bool(record.get("_syncing_shape_properties", False)):
                return
            if live_render_suspended():
                invalidate_record_signature(record)
                schedule_live_render(owner, record, input_change=True, shape_only=True)
                request_redraw()
                return
            source_shapes = _sync_selected_shape_property(
                record, shape, property_name,
            )
            _sync_selected_frame_shape_property(
                owner, record, source_shapes, property_name,
            )
            invalidate_record_signature(record)
            schedule_live_render(owner, record, input_change=True, shape_only=True)
            request_redraw()
        except (AttributeError, ImportError, ReferenceError, RuntimeError, TypeError):
            pass
    return update


def _shape_type_changed(shape, context):
    """Changing Star/Doodle ends a modal brush without blocking other edits."""
    try:
        state = getattr(getattr(context, "scene", None), "impaction", None)
        if state is not None:
            state.shape_draw_active = False
            state.shape_perspective_target = ""
    except (AttributeError, ReferenceError, RuntimeError):
        pass
    _shape_changed("shape_type")(shape, context)


def _shape_selection_changed(record, context):
    """Selection changes terminate the previous shape's modal brush mode."""
    try:
        if (
            record.as_pointer() not in _shape_selection_syncing
            and not bool(record.get("_syncing_shape_selection", False))
        ):
            active = int(record.active_shape_index)
            for index, shape in enumerate(record.shapes):
                shape.is_selected = index == active
            record.shape_selection_anchor = active
        state = getattr(getattr(context, "scene", None), "impaction", None)
        if state is not None:
            state.shape_draw_active = False
            state.shape_perspective_target = ""
        from .impaction_runtime import request_redraw
        request_redraw()
    except (AttributeError, ImportError, RuntimeError):
        pass


def _preview_changed(_self, context):
    try:
        from .impaction_runtime import preview_mode_changed
        preview_mode_changed(context)
    except (ImportError, RuntimeError):
        pass


def _preview_quality_changed(_self, context):
    try:
        from .impaction_runtime import preview_quality_changed
        preview_quality_changed(context)
    except (ImportError, RuntimeError):
        pass


def _aberration_preset_changed(record, context):
    if (record.aberration_preset == "CUSTOM" and
            not record.aberration_custom_initialized):
        try:
            from .impaction_gradient import set_aberration_colors
            set_aberration_colors(record, (
                (1.0, 0.0, 0.0, 1.0),
                (0.0, 1.0, 1.0, 1.0),
            ))
            record.aberration_custom_initialized = True
        except (ImportError, RuntimeError):
            pass
    _changed("aberration_preset")(record, context)


def _fps_changed(camera, _context):
    try:
        from .impaction_runtime import fps_property_changed
        fps_property_changed(camera)
    except (ImportError, RuntimeError):
        pass


def _canonical_angle(value):
    """Store one visible turn while accepting arbitrary typed/dragged input."""
    value = float(value)
    if not math.isfinite(value):
        return math.pi * 0.5
    wrapped = (value + math.pi) % math.tau - math.pi
    # Keep the interval visually stable at its single shared boundary.
    return -math.pi if abs(wrapped - math.pi) < 1.0e-10 else wrapped


def _angle_get(record):
    return _canonical_angle(record.get("angle", math.pi * 0.5))


def _angle_set(record, value):
    # A custom setter makes the number field read back the canonical value on
    # every modal drag update, rather than showing 270 until mouse release.
    record["angle"] = _canonical_angle(value)


def _focus_resolution():
    scene = getattr(bpy.context, "scene", None)
    if scene is None:
        return 1, 1
    return (
        max(1, int(scene.render.resolution_x)),
        max(1, int(scene.render.resolution_y)),
    )


_property_alias_context = {}


def property_alias_context(record):
    return _property_alias_context.get(record.as_pointer(), ("", -1))


def _set_aliased_property(
        record, alias_name, property_name, component, value):
    """Identify a component edit while the backing-vector callback runs."""
    current = tuple(float(item) for item in getattr(record, property_name))
    candidate = tuple(float(item) for item in value)
    # Blender 5.2 may dispatch the same numeric field assignment twice.  Do
    # not re-enter the RNA update/render path for an identical backing vector;
    # repeated writes during a queued GPU preview were able to reach a stale
    # UI pointer and crash in blender.exe before Python produced a traceback.
    if len(current) == len(candidate) and all(
            abs(left - right) <= 1.0e-7
            for left, right in zip(current, candidate)):
        return
    # Bookkeeping belongs to Python, not native IDProperties mutated while
    # Blender is inside a numeric RNA setter.
    pointer = record.as_pointer()
    previous = _property_alias_context.get(pointer)
    _property_alias_context[pointer] = (alias_name, int(component))
    try:
        setattr(record, property_name, value)
    finally:
        if previous is None:
            _property_alias_context.pop(pointer, None)
        else:
            _property_alias_context[pointer] = previous


def _focus_x_get(record):
    width, _height = _focus_resolution()
    return int(round(float(record.focus[0]) * max(1, width - 1)))


def _focus_x_set(record, value):
    width, _height = _focus_resolution()
    pixel = min(max(0, int(value)), max(0, width - 1))
    _set_aliased_property(
        record, "focus_x", "focus", 0,
        (pixel / max(1, width - 1), float(record.focus[1])),
    )


def _focus_y_get(record):
    _width, height = _focus_resolution()
    return int(round(float(record.focus[1]) * max(1, height - 1)))


def _focus_y_set(record, value):
    _width, height = _focus_resolution()
    pixel = min(max(0, int(value)), max(0, height - 1))
    _set_aliased_property(
        record, "focus_y", "focus", 1,
        (float(record.focus[0]), pixel / max(1, height - 1)),
    )


def _light_x_get(record):
    return int(round((float(record.light_focus[0]) - 0.5) * 180.0))


def _light_x_set(record, value):
    angle = min(90, max(-90, int(value)))
    x = angle / 90.0
    y = (float(record.light_focus[1]) - 0.5) * 2.0
    length = math.hypot(x, y)
    if length > 1.0:
        x, y = x / length, y / length
    _set_aliased_property(
        record, "light_x", "light_focus", 0,
        (x * 0.5 + 0.5, y * 0.5 + 0.5),
    )


def _light_y_get(record):
    return int(round((float(record.light_focus[1]) - 0.5) * 180.0))


def _light_y_set(record, value):
    angle = min(90, max(-90, int(value)))
    x = (float(record.light_focus[0]) - 0.5) * 2.0
    y = angle / 90.0
    length = math.hypot(x, y)
    if length > 1.0:
        x, y = x / length, y / length
    _set_aliased_property(
        record, "light_y", "light_focus", 1,
        (x * 0.5 + 0.5, y * 0.5 + 0.5),
    )


def _direction_x_get(record):
    return int(round((float(record.direction_focus[0]) - 0.5) * 180.0))


def _direction_x_set(record, value):
    angle = min(90, max(-90, int(value)))
    x = angle / 90.0
    y = (float(record.direction_focus[1]) - 0.5) * 2.0
    length = math.hypot(x, y)
    if length > 1.0:
        x, y = x / length, y / length
    _set_aliased_property(
        record, "direction_x", "direction_focus", 0,
        (x * 0.5 + 0.5, y * 0.5 + 0.5),
    )


def _direction_y_get(record):
    return int(round((float(record.direction_focus[1]) - 0.5) * 180.0))


def _direction_y_set(record, value):
    angle = min(90, max(-90, int(value)))
    x = (float(record.direction_focus[0]) - 0.5) * 2.0
    y = angle / 90.0
    length = math.hypot(x, y)
    if length > 1.0:
        x, y = x / length, y / length
    _set_aliased_property(
        record, "direction_y", "direction_focus", 1,
        (x * 0.5 + 0.5, y * 0.5 + 0.5),
    )


def _background_x_get(record):
    return int(round((float(record.background_focus[0]) - 0.5) * 180.0))


def _background_x_set(record, value):
    x = min(90, max(-90, int(value))) / 180.0 + 0.5
    _set_aliased_property(
        record, "background_x", "background_focus", 0,
        (x, float(record.background_focus[1])),
    )


def _background_y_get(record):
    return int(round((float(record.background_focus[1]) - 0.5) * 180.0))


def _background_y_set(record, value):
    y = min(90, max(-90, int(value))) / 180.0 + 0.5
    _set_aliased_property(
        record, "background_y", "background_focus", 1,
        (float(record.background_focus[0]), y),
    )


class ImpactionShapePoint(PropertyGroup):
    # Doodle geometry may extend beyond the camera frame and is clipped by
    # the render target. Hard RNA limits used to collapse every out-of-frame
    # sample onto the same border, producing a dense "smashed" edge.
    position: FloatVectorProperty(size=2, soft_min=0.0, soft_max=1.0)
    pressure: FloatProperty(default=1.0, min=0.0, max=1.0)
    break_before: BoolProperty(default=False)


def reroll_shape_variation(shape):
    """Generate a new persistent imperfection identity for one shape."""
    previous = int(getattr(shape, "variation", 1))
    rerolled = secrets.randbelow(2_000_000_000) + 1
    shape["variation"] = rerolled if rerolled != previous else (
        previous % 2_000_000_000 + 1
    )


def _shape_percent_get(name):
    def get(shape):
        return float(getattr(shape, name)) * 100.0
    return get


def _shape_value_get(name, default):
    def get(shape):
        return shape.get(name, default)
    return get


def _shape_value_set(name, default):
    def set(shape, value):
        previous = shape.get(name, default)
        if isinstance(default, tuple):
            value = tuple(value)
            changed = any(abs(float(a)-float(b)) > 1.e-7
                          for a, b in zip(previous, value))
        else:
            changed = abs(float(previous)-float(value)) > 1.e-7
        _shape_assignment_changes[(shape.as_pointer(), name)] = changed
        if changed:
            shape[name] = value
    return set


def _shape_percent_set(name):
    def set(shape, value):
        candidate = max(0.0, min(1.0, float(value) / 100.0))
        changed = abs(float(getattr(shape, name)) - candidate) > 1.0e-7
        _shape_assignment_changes[(shape.as_pointer(), name)] = changed
        if changed:
            # Store once; the alias update runs after this native setter returns.
            shape[name] = candidate
    return set


def _shape_rotation_get(shape):
    return _canonical_angle(shape.get("rotation", 0.0))


def _shape_rotation_set(shape, value):
    # Match the legacy Composition Angle control exactly: Blender exposes
    # degrees in the UI while RNA stores radians, and every modal update wraps
    # continuously across +/-180 instead of hitting a hard slider stop.
    candidate = _canonical_angle(value)
    # RNA converts the input to float32 before this setter. Equivalent turns
    # can differ slightly after wrapping, even though the angle is unchanged.
    changed = abs(_shape_rotation_get(shape)-candidate) > 1.e-6
    _shape_assignment_changes[(shape.as_pointer(), "rotation")] = changed
    if changed:
        shape["rotation"] = candidate


def _shape_layer_get(shape):
    return int(shape.get("layer", 0))


def _shape_layer_set(shape, value):
    changed = _shape_layer_get(shape) != int(value)
    _shape_assignment_changes[(shape.as_pointer(), "layer")] = changed
    if changed:
        shape["layer"] = int(value)


class ImpactionShapeSettings(PropertyGroup):
    name: StringProperty(default="Shape")
    variation: IntProperty(default=1, options={"HIDDEN"})
    is_selected: BoolProperty(
        default=False, options={"HIDDEN", "SKIP_SAVE"},
        description='Transient multi-selection state for the Shapes list.',
    )
    shape_type: EnumProperty(
        name="Shape",
        items=(("STAR", "Star", "Four-axis anime impact star"),
               ("DOODLE", "Doodle", "Freehand dry-brush doodle")),
        default="STAR", update=_shape_type_changed,
    )
    position: FloatVectorProperty(
        name="Position", size=2, default=(0.5, 0.5), min=0.0, max=1.0,
        update=_shape_changed("position"),
        get=_shape_value_get('position', (0.5, 0.5)), set=_shape_value_set('position', (0.5, 0.5)),
    )
    perspective: FloatVectorProperty(
        name="Perspective", size=2, default=(0.0, 0.0), min=-1.0, max=1.0,
        description="Tilt of the original drawing plane; zero restores the authored shape",
        update=_shape_changed("perspective"),
        get=_shape_value_get('perspective', (0.0, 0.0)), set=_shape_value_set('perspective', (0.0, 0.0)),
    )
    width: FloatProperty(
        name="X", subtype="FACTOR", default=0.25, min=0.0, max=1.0, precision=2,
        update=_shape_changed("width"),
        get=_shape_value_get('width', 0.25), set=_shape_value_set('width', 0.25),
    )
    height: FloatProperty(
        name="Y", subtype="FACTOR", default=0.25, min=0.0, max=1.0, precision=2,
        update=_shape_changed("height"),
        get=_shape_value_get('height', 0.25), set=_shape_value_set('height', 0.25),
    )
    width_percent: FloatProperty(
        name="X", min=0.0, max=100.0, precision=2,
        get=_shape_percent_get("width"), set=_shape_percent_set("width"), update=_shape_changed("width"),
    )
    height_percent: FloatProperty(
        name="Y", min=0.0, max=100.0, precision=2,
        get=_shape_percent_get("height"), set=_shape_percent_set("height"), update=_shape_changed("height"),
    )
    rotation: FloatProperty(
        name="Rotation",
        description='Two-dimensional shape rotation; values wrap into -180 to 180 degrees.',
        subtype="ANGLE", default=0.0,
        soft_min=-math.pi, soft_max=math.pi,
        precision=2, step=1,
        get=_shape_rotation_get, set=_shape_rotation_set,
        update=_shape_changed("rotation"),
    )
    radius: FloatProperty(
        name="Burst", subtype="FACTOR", default=0.0, min=0.0, max=1.0, precision=2,
        update=_shape_changed("radius"),
        get=_shape_value_get('radius', 0.0), set=_shape_value_set('radius', 0.0),
    )
    burst_percent: FloatProperty(
        name="Burst", min=0.0, max=100.0, precision=2,
        get=_shape_percent_get("radius"), set=_shape_percent_set("radius"), update=_shape_changed("radius"),
    )
    stroke: FloatProperty(
        name="Stroke", subtype="FACTOR", default=0.0,
        min=0.0, max=1.0, precision=2,
        description='Opaque irregular outline deposited around the Star and Burst.',
        update=_shape_changed("stroke"),
        get=_shape_value_get('stroke', 0.0), set=_shape_value_set('stroke', 0.0),
    )
    stroke_percent: FloatProperty(
        name="Stroke", min=0.0, max=100.0, precision=2,
        get=_shape_percent_get("stroke"), set=_shape_percent_set("stroke"), update=_shape_changed("stroke"),
    )
    stroke_color: FloatVectorProperty(
        name="Stroke Color", subtype="COLOR", size=3,
        default=(1.0, 1.0, 1.0), min=0.0, max=1.0,
        update=_shape_changed("stroke_color"),
        get=_shape_value_get('stroke_color', (1.0, 1.0, 1.0)), set=_shape_value_set('stroke_color', (1.0, 1.0, 1.0)),
    )
    diagonal: FloatProperty(
        name="Burst Growth", subtype="FACTOR", default=0.28, min=0.0, max=1.0, precision=2,
        update=_shape_changed("diagonal"),
        get=_shape_value_get('diagonal', 0.28), set=_shape_value_set('diagonal', 0.28),
    )
    end_width: FloatProperty(
        name="End", subtype="FACTOR", default=0.0, min=0.0, max=1.0, precision=2,
        description='Pointed at 0, rectangular near 0.5, flared at 1.',
        update=_shape_changed("end_width"),
        get=_shape_value_get('end_width', 0.0), set=_shape_value_set('end_width', 0.0),
    )
    burst_amount: IntProperty(
        name="Arms", default=4, min=1, max=32,
        update=_shape_changed("burst_amount"),
        get=_shape_value_get('burst_amount', 4), set=_shape_value_set('burst_amount', 4),
    )
    burst_thickness: FloatProperty(
        name="Burst Thickness", subtype="FACTOR", default=0.25,
        min=0.0, max=1.0, precision=2,
        update=_shape_changed("burst_thickness"),
        get=_shape_value_get('burst_thickness', 0.25), set=_shape_value_set('burst_thickness', 0.25),
    )
    burst_thickness_percent: FloatProperty(
        name="Burst Thickness", min=0.0, max=100.0, precision=2,
        get=_shape_percent_get("burst_thickness"),
        set=_shape_percent_set("burst_thickness"), update=_shape_changed("burst_thickness"),
    )
    burst_end: FloatProperty(
        name="Burst End", subtype="FACTOR", default=0.0,
        min=0.0, max=1.0, precision=2,
        update=_shape_changed("burst_end"),
        get=_shape_value_get('burst_end', 0.0), set=_shape_value_set('burst_end', 0.0),
    )
    line_thickness: FloatProperty(
        name="Thickness", subtype="FACTOR", default=0.0, min=0.0, max=1.0, precision=2,
        update=_shape_changed("line_thickness"),
        get=_shape_value_get('line_thickness', 0.0), set=_shape_value_set('line_thickness', 0.0),
    )
    thickness_percent: FloatProperty(
        name="Thickness", min=0.0, max=100.0, precision=2,
        get=_shape_percent_get("line_thickness"),
        set=_shape_percent_set("line_thickness"), update=_shape_changed("line_thickness"),
    )
    foreground: FloatVectorProperty(description='Choose the color of the impact ink.', 
        name="Color", subtype="COLOR", size=4,
        default=(0.0, 0.0, 0.0, 1.0), min=0.0, max=1.0,
        update=_shape_changed("foreground"),
        get=_shape_value_get('foreground', (0.0, 0.0, 0.0, 1.0)), set=_shape_value_set('foreground', (0.0, 0.0, 0.0, 1.0)),
    )
    effect_influence: FloatProperty(
        name="Effect Influence",
        description='How strongly frame effects affect this shape; zero is an exact bypass.',
        subtype="FACTOR", default=0.0, min=0.0, max=1.0,
        step=1, precision=2, update=_shape_changed("effect_influence"),
        get=_shape_value_get('effect_influence', 0.0), set=_shape_value_set('effect_influence', 0.0),
    )
    background: FloatVectorProperty(description='Choose the paper color behind the impact ink.', 
        name="Fill", subtype="COLOR", size=4,
        default=(1.0, 1.0, 1.0, 1.0), min=0.0, max=1.0,
        update=_shape_changed("background"),
        get=_shape_value_get('background', (1.0, 1.0, 1.0, 1.0)), set=_shape_value_set('background', (1.0, 1.0, 1.0, 1.0)),
    )
    layer: EnumProperty(
        name="Layer", items=(("FRONT", "Front", "Draw above the subject"),
                              ("BACK", "Back", "Draw behind the subject")),
        default="FRONT", get=_shape_layer_get, set=_shape_layer_set,
        update=_shape_changed("layer"),
    )
    points: CollectionProperty(type=ImpactionShapePoint)


def _stepped_float(**kwargs):
    """Commit the advertised hundredth steps before native UI reads back RNA."""
    if kwargs.get("precision") == 2 and kwargs.get("step") == 1 and "get" not in kwargs:
        name = kwargs.pop("storage_name")
        default = float(kwargs.get("default", 0.0))
        minimum, maximum = kwargs.get("min", -1.e30), kwargs.get("max", 1.e30)
        def get(record):
            return round(float(record.get(name, default)), 2) + 0.0
        def set(record, value):
            record[name] = round(max(minimum, min(maximum, float(value))), 2) + 0.0
        kwargs.update(get=get, set=set)
    else:
        kwargs.pop("storage_name", None)
    return FloatProperty(**kwargs)


def _glitch_get(record):
    # Existing files store 0..100; keep their intensity through the UI change.
    return round(max(0.0,min(1.0,float(record.get('aberration_glitch',0.0))*.01)),2)


def _glitch_set(record,value):
    record['aberration_glitch']=round(max(0.0,min(1.0,float(value))),2)*100.0


class ImpactionFrameSettings(PropertyGroup):
    frame: IntProperty(name="Frame")
    salt: IntProperty(name="Variation", default=1, options={"HIDDEN"})
    direction_seed_offset: IntProperty(default=0, options={"HIDDEN"})
    mode: EnumProperty(
        name="Direction",
        items=(
            ("NONE", "None", "Hide the primary impact strokes while retaining automatic hatching", 2),
            ("LINEAR", "Linear", "Bundled impact strokes follow a screen-space action angle", 0),
            ("RADIAL", "Radial", "Impact strokes concentrate around a softened focal pocket", 1),
        ),
        default="LINEAR",
        update=_legacy_mode_changed,
    )
    linear_enabled: BoolProperty(
        name="Linear",
        description='Enable camera-space bundled linear impact strokes.',
        default=True, update=_changed("linear_enabled"),
    )
    radial_enabled: BoolProperty(
        name="Radial",
        description='Enable radial impact strokes behind any Linear layer.',
        default=False, update=_changed("radial_enabled"),
    )
    direction_focus: FloatVectorProperty(description='Set the subject stroke direction with the pink pin.', 
        name="3D Direction", size=2, subtype="XYZ", default=(0.75, 0.5),
        min=0.0, max=1.0, update=_changed("direction_focus"),
    )
    direction_x: IntProperty(
        name="X", description='Horizontal orbit of the 3D aerodynamic direction.',
        min=-90, max=90, step=1, get=_direction_x_get, set=_direction_x_set,
    )
    direction_y: IntProperty(
        name="Y", description='Vertical orbit of the 3D aerodynamic direction.',
        min=-90, max=90, step=1, get=_direction_y_get, set=_direction_y_set,
    )
    direction_cast_behind: BoolProperty(
        name="Cast Behind",
        description=(
            'Move the source to the opposite rear hemisphere face; trails travel away from that face.'
        ),
        default=False, update=_changed("direction_cast_behind"),
    )
    halo_spread: _stepped_float(storage_name="halo_spread", 
        name="Spread",
        description=(
            'Open the main-stroke cone from a narrow aerodynamic bundle (0) to a wide up/down fan around the same 3D direction (1).'
        ),
        subtype="FACTOR", default=0.50, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("halo_spread"),
    )
    motion_curve_influence: _stepped_float(storage_name="motion_curve_influence", 
        name="Motion",
        description=(
            '0: normal static strokes controlled by the pink pin. 1: animation-driven direction and curvature, independent of the pink pin. Intermediate values favor the animation curve while allowing pink-pin steering. Lower values transition toward static strokes.'
        ),
        subtype="FACTOR", default=0.5, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("motion_curve_influence"),
    )
    angle: _stepped_float(storage_name="angle", 
        name="Angle",
        description='Cyclic direction; values outside +/-180 degrees wrap to the equivalent angle.',
        subtype="ANGLE", default=1.57079632679,
        step=1, precision=2, get=_angle_get, set=_angle_set,
        update=_changed("angle"),
    )
    focus: FloatVectorProperty(description='Set the center of the radial strokes.', 
        name="Focus", size=2, subtype="XYZ", default=(0.5, 0.5),
        min=0.0, max=1.0, update=_changed("focus"),
    )
    focus_x: IntProperty(
        name="X", description='Radial focus X coordinate in camera-output pixels.',
        min=0, max=65535, step=1, get=_focus_x_get, set=_focus_x_set,
    )
    focus_y: IntProperty(
        name="Y", description='Radial focus Y coordinate in camera-output pixels.',
        min=0, max=65535, step=1, get=_focus_y_get, set=_focus_y_set,
    )
    strength: _stepped_float(storage_name="strength", description='Control the length and intensity of subject impact strokes.', 
        name="Intensity", subtype="FACTOR", default=0.50, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("strength"),
    )
    line_thickness: _stepped_float(storage_name="line_thickness", 
        name="Thickness",
        description='Median foreground-stroke width; stroke families keep their natural width variation.',
        subtype="FACTOR", default=0.50, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("line_thickness"),
    )
    radial_threshold: _stepped_float(storage_name="radial_threshold", 
        name="Threshold",
        description=(
            'Size of the protected white impact burst at the Radial focus; higher values stop ink farther from the focus.'
        ),
        subtype="FACTOR", default=0.50, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("radial_threshold"),
    )
    radial_spiral: _stepped_float(storage_name="radial_spiral", 
        name="Twirl",
        description=(
            'Signed hypnosis-like radial twirl; zero keeps rays straight and negative and positive values reverse the curl without changing ink intensity.'
        ),
        default=0.0, min=-1.0, max=1.0,
        step=1, precision=2, update=_changed("radial_spiral"),
    )
    band_transition: _stepped_float(storage_name="band_transition", 
        name="Band",
        description=(
            'Strength of irregular white rests within generated impact lines; low values make fewer, longer rests and high values make them denser.'
        ),
        subtype="FACTOR", default=0.0, min=0.0, max=1.0,
        step=1, precision=2,
        update=_changed("band_transition"),
    )
    motion_blur: _stepped_float(storage_name="motion_blur", 
        name="Motion Blur",
        description='Directional frame blur following the resolved 3D/2D Linear direction or Radial focus field.',
        subtype="FACTOR", default=0.0, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("motion_blur"),
    )
    foreground: FloatVectorProperty(description='Choose the color of the impact ink.', 
        name="Foreground", subtype="COLOR", size=4,
        default=(0.0, 0.0, 0.0, 1.0), min=0.0, max=1.0, update=_changed("foreground"),
    )
    background: FloatVectorProperty(description='Choose the paper color behind the impact ink.', 
        name="Background", subtype="COLOR", size=4,
        default=(1.0, 1.0, 1.0, 1.0), min=0.0, max=1.0, update=_changed("background"),
    )
    background_line_color: FloatVectorProperty(
        name="Background Lines", description="Independent pigment for background lines across every rig",
        subtype="COLOR", size=4, default=(0.0, 0.0, 0.0, 1.0),
        min=0.0, max=1.0, update=_changed("background_line_color"),
    )
    flip: BoolProperty(
        name="Legacy Flip State",
        description='Compatibility storage for frames authored before Flip became an action.',
        default=False, options={"HIDDEN"},
    )
    background_intensity: _stepped_float(storage_name="background_intensity", 
        name="Background Intensity",
        description=(
            'Background stroke loading: 0 disables lines, 0.5 gives full standard coverage, and 1 adds stronger ink.'
        ),
        subtype="FACTOR", default=0.5, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("background_intensity"),
    )
    background_layer: _stepped_float(storage_name="background_layer", 
        name="Background Layer",
        description='Place background lines on a camera-depth layer: 0 behind the furthest captured subject face, 1 in front of the closest; intermediate values move between those mesh depths.',
        subtype="FACTOR", default=0.0, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("background_layer"),
    )
    background_space: EnumProperty(
        name="Background Space",
        description=(
            'Choose screen-space background lines or a shared drawing projected into depth.'
        ),
        items=(
            ("2D", "2D", "Keep background lines on one authored screen-space axis", 0),
            ("3D", "3D", "Distribute speed lines through depth, or constrain them to a shaped corridor", 1),
        ),
        default="2D",
        update=_changed("background_space"), options={"HIDDEN"},
    )
    background_2d_enabled: BoolProperty(
        name="2D",
        description='Draw screen-space background lines in the Linear layer.',
        default=True,
        update=_background_layer_changed(
            "background_2d_enabled", "background_3d_enabled",
        ),
    )
    background_3d_enabled: BoolProperty(
        name="3D",
        description='Draw depth-convergent background lines behind the subject.',
        default=False,
        update=_background_layer_changed(
            "background_3d_enabled", "background_2d_enabled",
        ),
    )
    background_mode: EnumProperty(
        name="Background Mode",
        description='Disable background lines or choose one compatible line space.',
        items=(
            ("NONE", "None", "Disable background lines", 0),
            ("2D", "2D", "Use screen-space background lines", 1),
            ("3D", "3D", "Use depth-convergent background lines", 2),
        ),
        get=_background_mode_get, set=_background_mode_set,
    )
    background_modes_version: IntProperty(
        default=0, options={"HIDDEN"},
    )
    background_focus: FloatVectorProperty(description='Set the background stroke direction with the cyan pin.', 
        name="Background Direction", size=2, subtype="XYZ",
        default=(0.625, 0.5), min=0.0, max=1.0,
        update=_changed("background_focus"),
    )
    background_x: IntProperty(
        name="X", description='Horizontal background focus position.',
        min=-90, max=90, step=1,
        get=_background_x_get, set=_background_x_set,
    )
    background_y: IntProperty(
        name="Y", description='Vertical background focus position.',
        min=-90, max=90, step=1,
        get=_background_y_get, set=_background_y_set,
    )
    background_depth: _stepped_float(storage_name="background_depth", 
        name="Background Spread",
        description=(
            'Background perspective aperture: 0 is wide, 1 concentrates a narrow cone around cyan; does not scale stroke lengths.'
        ),
        subtype="FACTOR", default=0.5, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("background_depth"),
    )
    background_motion: _stepped_float(storage_name="background_motion", 
        name="Background Motion",
        description=(
            'Influence of captured camera movement and hand-drawn curvature on background lines.'
        ),
        subtype="FACTOR", default=0.5, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("background_motion"),
    )
    background_depth_2d: _stepped_float(storage_name="background_depth_2d", 
        name="Background Spread",
        description=(
            'Signed plane spread of 2D background lines; negative values pop the drawing toward the opposite side.'
        ),
        default=0.0, min=-1.0, max=1.0,
        step=1, precision=2, update=_changed("background_depth_2d"),
    )
    background_flip_depth_2d: BoolProperty(
        name="Flip Spread",
        description=(
            'Reverse the coherent inward/outward perspective bow of 2D background lines without mirroring their authored direction.'
        ),
        default=False, update=_changed("background_flip_depth_2d"),
    )
    background_shaped: BoolProperty(
        name="Shaped",
        description='Legacy saved value; 3D backgrounds now use the unified depth volume.',
        default=False, options={"HIDDEN"},
    )
    invert: BoolProperty(
        name="Invert",
        description='Negative the complete rendered frame.',
        default=False, update=_changed("invert"),
    )
    color_semantics_version: IntProperty(default=0, options={"HIDDEN"})
    band_semantics_version: IntProperty(default=0, options={"HIDDEN"})
    flip_semantics_version: IntProperty(default=0, options={"HIDDEN"})
    light_focus: FloatVectorProperty(
        name="Light", size=2, subtype="XYZ", default=(0.875, 0.5),
        min=0.0, max=1.0, update=_changed("light_focus"),
    )
    light_x: IntProperty(
        name="X", description='Horizontal orbit of the camera-facing key light.',
        min=-90, max=90, step=1, get=_light_x_get, set=_light_x_set,
    )
    light_y: IntProperty(
        name="Y", description='Vertical orbit of the camera-facing key light.',
        min=-90, max=90, step=1, get=_light_y_get, set=_light_y_set,
    )
    light_radius: _stepped_float(storage_name="light_radius", 
        name="Strength", description='Brightness of the camera-space key light.',
        subtype="FACTOR", default=1.0, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("light_radius"),
    )
    bleed: _stepped_float(storage_name="bleed", 
        name="Bleed",
        description=(
            'Light-colored manga separation surrounding generated lines so their motion remains readable over dark backgrounds; 0 is an exact bypass.'
        ),
        subtype="FACTOR", default=0.5, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("bleed"),
    )
    light_cast_behind: BoolProperty(
        name="Cast Behind",
        description='Orbit the key light over the rear camera-space hemisphere.',
        default=False, update=_changed("light_cast_behind"),
    )
    light_color_source: EnumProperty(
        name="Color",
        description='Choose a frame endpoint or an independent light color.',
        items=(
            ("FOREGROUND", "Foreground", "Use the current Foreground color"),
            ("BACKGROUND", "Background", "Use the current Background color"),
            ("CUSTOM", "Custom", "Use an independent light color"),
        ),
        default="CUSTOM", update=_changed("light_color_source"),
    )
    light_color: FloatVectorProperty(description='Choose the custom key light color.', 
        name="Light Color", subtype="COLOR", size=4,
        default=(1.0, 1.0, 1.0, 1.0), min=0.0, max=1.0,
        update=_changed("light_color"),
    )
    shapes: CollectionProperty(type=ImpactionShapeSettings)
    active_shape_index: IntProperty(
        default=-1, min=-1, options={"HIDDEN"},
        update=_shape_selection_changed,
    )
    shape_selection_anchor: IntProperty(
        default=-1, min=-1, options={"HIDDEN", "SKIP_SAVE"},
    )
    contrast: _stepped_float(storage_name="contrast", description='Increase the contrast of the completed frame.', 
        name="Contrast", subtype="FACTOR", default=0.0, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("contrast"),
    )
    grayscale: _stepped_float(storage_name="grayscale", description='Remove color from the completed frame.', 
        name="Grayscale", subtype="FACTOR", default=0.0, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("grayscale"),
    )
    bloom: _stepped_float(storage_name="bloom", description='Add a glow around bright areas of the frame.', 
        name="Bloom", subtype="FACTOR", default=0.0, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("bloom"),
    )
    bloom_invert: BoolProperty(
        name="Invert Bloom",
        description='Reverse bloom so emitted highlights darken before color inversion.',
        default=False,
        update=_changed("bloom_invert"),
    )
    chromatic_aberration: _stepped_float(storage_name="chromatic_aberration", description='Separate colors along high-contrast edges.', 
        name="Chromatic Aberration", subtype="FACTOR", default=0.0, min=0.0, max=1.0,
        step=1, precision=2,
        update=_changed("chromatic_aberration"),
    )
    aberration_glitch: _stepped_float(storage_name="aberration_glitch", name="Glitch", description="Signal distortion across subject and background", subtype="FACTOR", min=0.0, max=1.0, precision=2, step=1, get=_glitch_get, set=_glitch_set, update=_changed("aberration_glitch"))
    glitch_size: IntProperty(name="Size", description="Size of glitch blocks and scan distortions", default=5, min=1, max=100, update=_changed("glitch_size"))
    aberration_preset: EnumProperty(
        name="Color",
        description='Choose an optical spectrum, a named color pair, or a custom gradient.',
        items=(
            ("PRISM", "Full Color",
             "CIE-derived full visible-spectrum glass dispersion"),
            ("CYAN_MAGENTA", "Digital Glitch",
             "Cyan #00FFFF to Magenta #FF00FF"),
            ("RED_CYAN", "3D Anaglyph",
             "Red #FF0000 to Cyan #00FFFF"),
            ("GREEN_MAGENTA", "Acid Glitch",
             "Green #00FF00 to Magenta #FF00FF"),
            ("AMBER_BLUE", "Cinematic Fringe",
             "Amber #FFB700 to Blue #0000FF"),
            ("RGB", "RGB", "Blue #0000FF, Green #00FF00, Red #FF0000"),
            ("CMY", "CMY", "Yellow #FFFF00, Magenta #FF00FF, Cyan #00FFFF"),
            ("CUSTOM", "Custom", "Use an editable custom aberration gradient"),
        ),
        default="PRISM", update=_aberration_preset_changed,
    )
    aberration_blur_smoothing: BoolProperty(
        name="Blur Smoothing",
        description='Blend neighboring spectral samples for softer color fringes.',
        default=True, update=_changed("aberration_blur_smoothing"),
    )
    aberration_color_a: FloatVectorProperty(description='Choose the first color of the custom fringe.', 
        name="Color A", subtype="COLOR", size=4,
        default=(1.0, 0.0, 0.0, 1.0), min=0.0, max=1.0,
        update=_changed("aberration_color_a"),
    )
    aberration_color_b: FloatVectorProperty(description='Choose the second color of the custom fringe.', 
        name="Color B", subtype="COLOR", size=4,
        default=(0.0, 1.0, 1.0, 1.0), min=0.0, max=1.0,
        update=_changed("aberration_color_b"),
    )
    grain: _stepped_float(storage_name="grain", 
        name="Line Grain",
        description='Foreground-colored proximity scatter emitted from the drawn linework.',
        subtype="FACTOR", default=0.0, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("grain"),
    )
    grain_overlay_intensity: _stepped_float(storage_name="grain_overlay_intensity", 
        name="Film Grain",
        description='Strength of the sparse frame-wide film emulsion.',
        subtype="FACTOR", default=0.0, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("grain_overlay_intensity"),
    )
    halftone: _stepped_float(storage_name="halftone", 
        name="Halftone",
        description='Intensity of the depth- and light-aware clustered-dot print screen.',
        subtype="FACTOR", default=0.0, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("halftone"),
    )
    halftone_size: IntProperty(
        name="Halftone Size", description='Halftone cluster size.',
        default=5, min=1, max=100, soft_min=1, soft_max=100,
        step=1, update=_changed("halftone_size"),
    )
    pixelate: _stepped_float(storage_name="pixelate", 
        name="Pixelate",
        description='Block-sample the composed frame before optical effects.',
        subtype="FACTOR", default=0.0, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("pixelate"),
    )
    pixelate_size: IntProperty(
        name="Size", description='Pixel block size.',
        default=10, min=1, max=100, soft_min=1, soft_max=100,
        step=1, update=_changed("pixelate_size"),
    )
    aberration_ramp: StringProperty(default="", options={"HIDDEN"})
    aberration_custom_initialized: BoolProperty(default=False, options={"HIDDEN"})
    cache_valid: BoolProperty(default=False, options={"HIDDEN"})
    cache_image: StringProperty(default="", options={"HIDDEN"})
    cache_signature: StringProperty(default="", options={"HIDDEN"})
    capture_subject: StringProperty(default="", options={"HIDDEN"})
    capture_floor: StringProperty(default="", options={"HIDDEN"})
    # Presentation-only state: organized sections without renderer features.
    ui_composition_open: BoolProperty(default=True, options={"SKIP_SAVE"})
    ui_properties_open: BoolProperty(default=True, options={"SKIP_SAVE"})
    ui_line_open: BoolProperty(default=True, options={"SKIP_SAVE"})
    ui_light_open: BoolProperty(default=True, options={"SKIP_SAVE"})
    ui_effects_open: BoolProperty(default=True, options={"SKIP_SAVE"})

    def initialize(self, frame):
        self.frame = int(frame)
        self.salt = secrets.randbelow(2_000_000_000) + 1
        # Explicit initialization prevents stale RNA/default state from older
        # enabled extension builds from creating a hidden-stroke first frame.
        self.mode = "LINEAR"
        self.linear_enabled = True
        self.radial_enabled = False
        self.direction_focus = (0.75, 0.5)
        self.direction_cast_behind = False
        self.light_cast_behind = False
        self.bleed = 0.5
        self.halo_spread = 0.50
        self.motion_curve_influence = 0.5
        self.radial_threshold = 0.50
        self.radial_spiral = 0.0
        self.motion_blur = 0.0
        self.aberration_blur_smoothing = True
        # Existing saved frames inherit the RNA zero default and remain
        # unchanged; new frames leave the backdrop disabled until requested.
        # Its strength/motion values are ready when the user enables it.
        self.background_intensity = 0.5
        self.background_layer = 0.0
        self.background_line_color = tuple(self.foreground)
        self.background_space = "2D"
        self.background_2d_enabled = False
        self.background_3d_enabled = False
        self.background_modes_version = 1
        self.background_focus = (0.625, 0.5)
        self.background_depth = 0.0
        self.background_motion = 0.5
        self.background_depth_2d = 0.0
        self.background_flip_depth_2d = False
        self.background_shaped = False
        self.light_focus = (0.875, 0.5)
        self.color_semantics_version = 2
        self.band_semantics_version = 1
        self.flip = False
        self.flip_semantics_version = 2
        self.cache_valid = False
        self.cache_signature = ""
        from .impaction_gradient import ensure_aberration_ramp
        ensure_aberration_ramp(self)


class ImpactionSceneState(PropertyGroup):
    shape_perspective_target: StringProperty(default="", options={"HIDDEN", "SKIP_SAVE"})
    shape_draw_active: BoolProperty(default=False, options={"HIDDEN"})
    shape_draw_mode: StringProperty(default="DRAW", options={"HIDDEN"})
    preview_opacity: FloatProperty(
        name="Opacity",
        description='Impact Frame opacity in the camera-view live preview.',
        subtype="PERCENTAGE", default=100.0, min=0.0, max=100.0,
        step=1, precision=0,
        update=_preview_changed,
    )
    preview_quality: FloatProperty(
        name="Preview Quality",
        description=(
            'Maximum temporary live-interaction quality; zero selects automatic quality, while settled and updated frames always render at full quality.'
        ),
        subtype="PERCENTAGE", default=0.0, min=0.0, max=100.0,
        step=5, precision=0, options={"SKIP_SAVE"},
        update=_preview_quality_changed,
    )


PROPERTY_CLASSES = (
    ImpactionShapePoint, ImpactionShapeSettings,
    ImpactionFrameSettings, ImpactionSceneState,
)


def register_properties():
    for cls in PROPERTY_CLASSES:
        bpy.utils.register_class(cls)
    from .impaction_multirig import enum_items, enum_get, enum_set
    bpy.types.Object.impaction_rig = EnumProperty(name="", items=enum_items, get=enum_get, set=enum_set)
    bpy.types.Object.impaction_frames = CollectionProperty(type=ImpactionFrameSettings)
    bpy.types.Object.impaction_fps = IntProperty(
        name="FPS",
        description="Spacing cadence for this camera's Impact Frame keys",
        default=24, min=1, max=120, update=_fps_changed,
    )
    bpy.types.Object.impaction_grid_anchor = IntProperty(default=0, options={"HIDDEN"})
    bpy.types.Object.impaction_grid_initialized = BoolProperty(default=False, options={"HIDDEN"})
    bpy.types.Scene.impaction = PointerProperty(type=ImpactionSceneState)


def unregister_properties():
    if hasattr(bpy.types.Object, "impaction_rig"):
        del bpy.types.Object.impaction_rig
    _shape_assignment_changes.clear()
    if hasattr(bpy.types.Scene, "impaction"):
        del bpy.types.Scene.impaction
    if hasattr(bpy.types.Object, "impaction_frames"):
        del bpy.types.Object.impaction_frames
    if hasattr(bpy.types.Object, "impaction_fps"):
        del bpy.types.Object.impaction_fps
    if hasattr(bpy.types.Object, "impaction_grid_anchor"):
        del bpy.types.Object.impaction_grid_anchor
    if hasattr(bpy.types.Object, "impaction_grid_initialized"):
        del bpy.types.Object.impaction_grid_initialized
    for cls in reversed(PROPERTY_CLASSES):
        bpy.utils.unregister_class(cls)
