import secrets
import math

import bpy
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    FloatProperty,
    FloatVectorProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from bpy.types import PropertyGroup


def _changed(property_name):
    def update(self, context):
        try:
            from .impaction_runtime import property_changed
            property_changed(self, context, property_name)
        except (ImportError, RuntimeError):
            pass
    return update


def _legacy_mode_changed(record, context):
    """Map the former exclusive enum onto independent line toggles."""
    if not bool(record.get("_syncing_line_modes", False)):
        record["_syncing_line_modes"] = True
        try:
            mode = str(record.mode)
            record.linear_enabled = mode == "LINEAR"
            record.radial_enabled = mode == "RADIAL"
        finally:
            del record["_syncing_line_modes"]
    _changed("mode")(record, context)


def shape_selection_indices(record):
    """Return only explicit transient shape selections."""
    return [
        index for index, shape in enumerate(record.shapes)
        if bool(getattr(shape, "is_selected", False))
    ]


def clear_shape_selection(record):
    """Clear every transient shape-selection field without selecting a fallback."""
    if record is None:
        return
    record["_syncing_shape_selection"] = True
    try:
        for shape in record.shapes:
            shape.is_selected = False
        record.active_shape_index = -1
        record.shape_selection_anchor = -1
    finally:
        del record["_syncing_shape_selection"]


def shape_selection_type(record):
    """Return the one selected shape type, or None for empty/mixed selections."""
    shape_types = {
        record.shapes[index].shape_type
        for index in shape_selection_indices(record)
    }
    return next(iter(shape_types)) if len(shape_types) == 1 else None


def _shape_owner(shape, context):
    pointer = shape.as_pointer()
    camera = getattr(shape, "id_data", None)
    candidates = (
        (camera,) if getattr(camera, "type", None) == "CAMERA"
        else tuple(
            owner for owner in getattr(getattr(context, "scene", None), "objects", ())
            if getattr(owner, "type", None) == "CAMERA"
        )
    )
    for owner in candidates:
        for record in getattr(owner, "impaction_frames", ()):
            if any(item.as_pointer() == pointer for item in record.shapes):
                return owner, record
    return None, None


def _shape_property_value(shape, property_name):
    value = getattr(shape, property_name)
    if property_name in {"position", "foreground", "background", "stroke_color"}:
        return tuple(value)
    return value


def _assign_shape_property(shape, property_name, value):
    """Assign a synchronized value without rerolling unrelated variation."""
    preserved = bool(shape.get("_preserve_variation", False))
    shape["_preserve_variation"] = True
    try:
        setattr(shape, property_name, value)
    finally:
        if preserved:
            shape["_preserve_variation"] = True
        else:
            del shape["_preserve_variation"]


def _sync_selected_shape_property(record, source, property_name):
    """Copy one edited property across a homogeneous shape selection."""
    indices = shape_selection_indices(record)
    selected = [record.shapes[index] for index in indices]
    source_pointer = source.as_pointer()
    if not any(shape.as_pointer() == source_pointer for shape in selected):
        return ()
    if len(selected) < 2:
        return tuple(selected)

    if property_name == "shape_type":
        # The callback sees the source's new type. The remaining selected rows
        # still carry the common old type until this propagation completes.
        other_types = {
            shape.shape_type for shape in selected
            if shape.as_pointer() != source_pointer
        }
        if len(other_types) > 1:
            return (source,)
    elif len({shape.shape_type for shape in selected}) != 1:
        return (source,)

    value = _shape_property_value(source, property_name)
    record["_syncing_shape_properties"] = True
    try:
        for shape in selected:
            if shape.as_pointer() != source_pointer:
                _assign_shape_property(shape, property_name, value)
    finally:
        del record["_syncing_shape_properties"]
    return tuple(selected)


def _sync_selected_frame_shape_property(
        owner, record, source_shapes, property_name):
    """Copy one nested property to same-named shapes on selected frames."""
    if not source_shapes:
        return
    from .impaction_runtime import selected_property_records
    from .impaction_renderer import invalidate_record_signature
    from .impaction_runtime import schedule_live_render

    source_pointer = record.as_pointer()
    for target_record in selected_property_records(owner, record):
        if target_record.as_pointer() == source_pointer:
            continue
        by_name = {str(shape.name): shape for shape in target_record.shapes}
        changed = False
        target_record["_syncing_shape_properties"] = True
        try:
            for source_shape in source_shapes:
                target_shape = by_name.get(str(source_shape.name))
                if target_shape is None:
                    continue
                if (property_name != "shape_type" and
                        target_shape.shape_type != source_shape.shape_type):
                    continue
                value = _shape_property_value(source_shape, property_name)
                if _shape_property_value(target_shape, property_name) == value:
                    continue
                _assign_shape_property(target_shape, property_name, value)
                changed = True
        finally:
            del target_record["_syncing_shape_properties"]
        if changed:
            invalidate_record_signature(target_record)
            schedule_live_render(owner, target_record, input_change=True)


def _shape_changed(property_name):
    """Sync one nested edit without replacing unrelated shape/frame data."""
    def update(shape, context):
        try:
            from .impaction_runtime import (
                live_render_suspended, request_redraw, schedule_live_render,
            )
            from .impaction_renderer import invalidate_record_signature
            if not bool(shape.get("_preserve_variation", False)):
                reroll_shape_variation(shape)
            owner, record = _shape_owner(shape, context)
            if record is None:
                return
            if bool(record.get("_syncing_shape_properties", False)):
                return
            if live_render_suspended():
                invalidate_record_signature(record)
                schedule_live_render(owner, record, input_change=True)
                request_redraw()
                return
            source_shapes = _sync_selected_shape_property(
                record, shape, property_name,
            )
            _sync_selected_frame_shape_property(
                owner, record, source_shapes, property_name,
            )
            invalidate_record_signature(record)
            schedule_live_render(owner, record, input_change=True)
            request_redraw()
        except (AttributeError, ImportError, ReferenceError, RuntimeError, TypeError):
            pass
    return update


def _shape_type_changed(shape, context):
    """Changing Star/Doodle ends a modal brush without blocking other edits."""
    try:
        state = getattr(getattr(context, "scene", None), "impaction", None)
        if state is not None:
            state.shape_draw_active = False
    except (AttributeError, ReferenceError, RuntimeError):
        pass
    _shape_changed("shape_type")(shape, context)


def _shape_selection_changed(record, context):
    """Selection changes terminate the previous shape's modal brush mode."""
    try:
        if not bool(record.get("_syncing_shape_selection", False)):
            active = int(record.active_shape_index)
            for index, shape in enumerate(record.shapes):
                shape.is_selected = index == active
            record.shape_selection_anchor = active
        state = getattr(getattr(context, "scene", None), "impaction", None)
        if state is not None:
            state.shape_draw_active = False
        from .impaction_runtime import request_redraw
        request_redraw()
    except (AttributeError, ImportError, RuntimeError):
        pass


def _preview_changed(_self, context):
    try:
        from .impaction_runtime import preview_mode_changed
        preview_mode_changed(context)
    except (ImportError, RuntimeError):
        pass


def _aberration_preset_changed(record, context):
    if (record.aberration_preset == "CUSTOM" and
            not record.aberration_custom_initialized):
        try:
            from .impaction_gradient import set_aberration_colors
            set_aberration_colors(record, (
                (1.0, 0.0, 0.0, 1.0),
                (0.0, 1.0, 1.0, 1.0),
            ))
            record.aberration_custom_initialized = True
        except (ImportError, RuntimeError):
            pass
    _changed("aberration_preset")(record, context)


def _fps_changed(camera, _context):
    try:
        from .impaction_runtime import fps_property_changed
        fps_property_changed(camera)
    except (ImportError, RuntimeError):
        pass


def _canonical_angle(value):
    """Store one visible turn while accepting arbitrary typed/dragged input."""
    value = float(value)
    if not math.isfinite(value):
        return math.pi * 0.5
    wrapped = (value + math.pi) % math.tau - math.pi
    # Keep the interval visually stable at its single shared boundary.
    return -math.pi if abs(wrapped - math.pi) < 1.0e-10 else wrapped


def _angle_get(record):
    return _canonical_angle(record.get("angle", math.pi * 0.5))


def _angle_set(record, value):
    # A custom setter makes the number field read back the canonical value on
    # every modal drag update, rather than showing 270 until mouse release.
    record["angle"] = _canonical_angle(value)


def _focus_resolution():
    scene = getattr(bpy.context, "scene", None)
    if scene is None:
        return 1, 1
    return (
        max(1, int(scene.render.resolution_x)),
        max(1, int(scene.render.resolution_y)),
    )


def _set_aliased_property(
        record, alias_name, property_name, component, value):
    """Identify a component edit while the backing-vector callback runs."""
    record["_property_alias"] = alias_name
    record["_property_alias_component"] = int(component)
    try:
        setattr(record, property_name, value)
    finally:
        del record["_property_alias"]
        del record["_property_alias_component"]


def _focus_x_get(record):
    width, _height = _focus_resolution()
    return int(round(float(record.focus[0]) * max(1, width - 1)))


def _focus_x_set(record, value):
    width, _height = _focus_resolution()
    pixel = min(max(0, int(value)), max(0, width - 1))
    _set_aliased_property(
        record, "focus_x", "focus", 0,
        (pixel / max(1, width - 1), float(record.focus[1])),
    )


def _focus_y_get(record):
    _width, height = _focus_resolution()
    return int(round(float(record.focus[1]) * max(1, height - 1)))


def _focus_y_set(record, value):
    _width, height = _focus_resolution()
    pixel = min(max(0, int(value)), max(0, height - 1))
    _set_aliased_property(
        record, "focus_y", "focus", 1,
        (float(record.focus[0]), pixel / max(1, height - 1)),
    )


def _light_x_get(record):
    return int(round((float(record.light_focus[0]) - 0.5) * 180.0))


def _light_x_set(record, value):
    angle = min(90, max(-90, int(value)))
    x = angle / 90.0
    y = (float(record.light_focus[1]) - 0.5) * 2.0
    length = math.hypot(x, y)
    if length > 1.0:
        x, y = x / length, y / length
    _set_aliased_property(
        record, "light_x", "light_focus", 0,
        (x * 0.5 + 0.5, y * 0.5 + 0.5),
    )


def _light_y_get(record):
    return int(round((float(record.light_focus[1]) - 0.5) * 180.0))


def _light_y_set(record, value):
    angle = min(90, max(-90, int(value)))
    x = (float(record.light_focus[0]) - 0.5) * 2.0
    y = angle / 90.0
    length = math.hypot(x, y)
    if length > 1.0:
        x, y = x / length, y / length
    _set_aliased_property(
        record, "light_y", "light_focus", 1,
        (x * 0.5 + 0.5, y * 0.5 + 0.5),
    )


def _direction_x_get(record):
    return int(round((float(record.direction_focus[0]) - 0.5) * 180.0))


def _direction_x_set(record, value):
    angle = min(90, max(-90, int(value)))
    x = angle / 90.0
    y = (float(record.direction_focus[1]) - 0.5) * 2.0
    length = math.hypot(x, y)
    if length > 1.0:
        x, y = x / length, y / length
    _set_aliased_property(
        record, "direction_x", "direction_focus", 0,
        (x * 0.5 + 0.5, y * 0.5 + 0.5),
    )


def _direction_y_get(record):
    return int(round((float(record.direction_focus[1]) - 0.5) * 180.0))


def _direction_y_set(record, value):
    angle = min(90, max(-90, int(value)))
    x = (float(record.direction_focus[0]) - 0.5) * 2.0
    y = angle / 90.0
    length = math.hypot(x, y)
    if length > 1.0:
        x, y = x / length, y / length
    _set_aliased_property(
        record, "direction_y", "direction_focus", 1,
        (x * 0.5 + 0.5, y * 0.5 + 0.5),
    )


class ImpactionShapePoint(PropertyGroup):
    position: FloatVectorProperty(size=2, min=0.0, max=1.0)
    pressure: FloatProperty(default=1.0, min=0.0, max=1.0)
    break_before: BoolProperty(default=False)


def reroll_shape_variation(shape):
    """Generate a new persistent imperfection identity for one shape."""
    previous = int(getattr(shape, "variation", 1))
    rerolled = secrets.randbelow(2_000_000_000) + 1
    shape["variation"] = rerolled if rerolled != previous else (
        previous % 2_000_000_000 + 1
    )


def _shape_percent_get(name):
    def get(shape):
        return float(getattr(shape, name)) * 100.0
    return get


def _shape_percent_set(name):
    def set(shape, value):
        setattr(shape, name, max(0.0, min(1.0, float(value) / 100.0)))
    return set


def _shape_rotation_get(shape):
    return _canonical_angle(shape.get("rotation", 0.0))


def _shape_rotation_set(shape, value):
    # Match the legacy Composition Angle control exactly: Blender exposes
    # degrees in the UI while RNA stores radians, and every modal update wraps
    # continuously across +/-180 instead of hitting a hard slider stop.
    shape["rotation"] = _canonical_angle(value)


class ImpactionShapeSettings(PropertyGroup):
    name: StringProperty(default="Shape")
    variation: IntProperty(default=1, options={"HIDDEN"})
    is_selected: BoolProperty(
        default=False, options={"HIDDEN", "SKIP_SAVE"},
        description="Transient multi-selection state for the Shapes list",
    )
    shape_type: EnumProperty(
        name="Shape",
        items=(("STAR", "Star", "Four-axis anime impact star"),
               ("DOODLE", "Doodle", "Freehand dry-brush doodle")),
        default="STAR", update=_shape_type_changed,
    )
    position: FloatVectorProperty(
        name="Position", size=2, default=(0.5, 0.5), min=0.0, max=1.0,
        update=_shape_changed("position"),
    )
    width: FloatProperty(
        name="X", subtype="FACTOR", default=0.25, min=0.0, max=1.0, precision=2,
        update=_shape_changed("width"),
    )
    height: FloatProperty(
        name="Y", subtype="FACTOR", default=0.25, min=0.0, max=1.0, precision=2,
        update=_shape_changed("height"),
    )
    width_percent: FloatProperty(
        name="X", min=0.0, max=100.0, precision=2,
        get=_shape_percent_get("width"), set=_shape_percent_set("width"),
    )
    height_percent: FloatProperty(
        name="Y", min=0.0, max=100.0, precision=2,
        get=_shape_percent_get("height"), set=_shape_percent_set("height"),
    )
    rotation: FloatProperty(
        name="Rotation",
        description="Two-dimensional star rotation; values wrap into -180 to 180 degrees",
        subtype="ANGLE", default=0.0,
        precision=2, step=1,
        get=_shape_rotation_get, set=_shape_rotation_set,
        update=_shape_changed("rotation"),
    )
    radius: FloatProperty(
        name="Burst", subtype="FACTOR", default=0.0, min=0.0, max=1.0, precision=2,
        update=_shape_changed("radius"),
    )
    burst_percent: FloatProperty(
        name="Burst", min=0.0, max=100.0, precision=2,
        get=_shape_percent_get("radius"), set=_shape_percent_set("radius"),
    )
    stroke: FloatProperty(
        name="Stroke", subtype="FACTOR", default=0.0,
        min=0.0, max=1.0, precision=2,
        description="Opaque irregular outline deposited around the Star and Burst",
        update=_shape_changed("stroke"),
    )
    stroke_percent: FloatProperty(
        name="Stroke", min=0.0, max=100.0, precision=2,
        get=_shape_percent_get("stroke"), set=_shape_percent_set("stroke"),
    )
    stroke_color: FloatVectorProperty(
        name="Stroke Color", subtype="COLOR", size=3,
        default=(1.0, 1.0, 1.0), min=0.0, max=1.0,
        update=_shape_changed("stroke_color"),
    )
    diagonal: FloatProperty(
        name="Burst Growth", subtype="FACTOR", default=0.28, min=0.0, max=1.0, precision=2,
        update=_shape_changed("diagonal"),
    )
    end_width: FloatProperty(
        name="End", subtype="FACTOR", default=0.0, min=0.0, max=1.0, precision=2,
        description="Pointed at 0, rectangular near 0.5, flared at 1",
        update=_shape_changed("end_width"),
    )
    burst_amount: IntProperty(
        name="Arms", default=4, min=1, max=32,
        update=_shape_changed("burst_amount"),
    )
    burst_thickness: FloatProperty(
        name="Burst Thickness", subtype="FACTOR", default=0.25,
        min=0.0, max=1.0, precision=2,
        update=_shape_changed("burst_thickness"),
    )
    burst_thickness_percent: FloatProperty(
        name="Burst Thickness", min=0.0, max=100.0, precision=2,
        get=_shape_percent_get("burst_thickness"),
        set=_shape_percent_set("burst_thickness"),
    )
    burst_end: FloatProperty(
        name="Burst End", subtype="FACTOR", default=0.0,
        min=0.0, max=1.0, precision=2,
        update=_shape_changed("burst_end"),
    )
    line_thickness: FloatProperty(
        name="Thickness", subtype="FACTOR", default=0.0, min=0.0, max=1.0, precision=2,
        update=_shape_changed("line_thickness"),
    )
    thickness_percent: FloatProperty(
        name="Thickness", min=0.0, max=100.0, precision=2,
        get=_shape_percent_get("line_thickness"),
        set=_shape_percent_set("line_thickness"),
    )
    foreground: FloatVectorProperty(
        name="Color", subtype="COLOR", size=4,
        default=(0.0, 0.0, 0.0, 1.0), min=0.0, max=1.0,
        update=_shape_changed("foreground"),
    )
    effect_influence: FloatProperty(
        name="Effect Influence",
        description="How strongly frame effects affect this shape; zero is an exact bypass",
        subtype="FACTOR", default=0.5, min=0.0, max=1.0,
        step=1, precision=2, update=_shape_changed("effect_influence"),
    )
    background: FloatVectorProperty(
        name="Fill", subtype="COLOR", size=4,
        default=(1.0, 1.0, 1.0, 1.0), min=0.0, max=1.0,
        update=_shape_changed("background"),
    )
    layer: EnumProperty(
        name="Layer", items=(("FRONT", "Front", "Draw above the subject"),
                              ("BACK", "Back", "Draw behind the subject")),
        default="FRONT", update=_shape_changed("layer"),
    )
    points: CollectionProperty(type=ImpactionShapePoint)


class ImpactionFrameSettings(PropertyGroup):
    frame: IntProperty(name="Frame")
    salt: IntProperty(name="Variation", default=1, options={"HIDDEN"})
    mode: EnumProperty(
        name="Direction",
        items=(
            ("NONE", "None", "Hide the primary impact strokes while retaining automatic hatching", 2),
            ("LINEAR", "Linear", "Bundled impact strokes follow a screen-space action angle", 0),
            ("RADIAL", "Radial", "Impact strokes concentrate around a softened focal pocket", 1),
        ),
        default="LINEAR",
        update=_legacy_mode_changed,
    )
    linear_enabled: BoolProperty(
        name="Linear",
        description="Enable camera-space bundled linear impact strokes",
        default=True, update=_changed("linear_enabled"),
    )
    radial_enabled: BoolProperty(
        name="Radial",
        description="Enable radial impact strokes behind any Linear layer",
        default=False, update=_changed("radial_enabled"),
    )
    direction_focus: FloatVectorProperty(
        name="3D Direction", size=2, subtype="XYZ", default=(0.5, 0.75),
        min=0.0, max=1.0, update=_changed("direction_focus"),
    )
    direction_x: IntProperty(
        name="X", description="Horizontal orbit of the 3D aerodynamic direction",
        min=-90, max=90, step=1, get=_direction_x_get, set=_direction_x_set,
    )
    direction_y: IntProperty(
        name="Y", description="Vertical orbit of the 3D aerodynamic direction",
        min=-90, max=90, step=1, get=_direction_y_get, set=_direction_y_set,
    )
    direction_cast_behind: BoolProperty(
        name="Cast Behind",
        description="Place the 3D wind source on the rear camera hemisphere",
        default=False, update=_changed("direction_cast_behind"),
    )
    halo_spread: FloatProperty(
        name="Spread",
        description=(
            "Open the main-stroke cone from a narrow aerodynamic bundle (0) "
            "to a wide up/down fan around the same 3D direction (1)"
        ),
        subtype="FACTOR", default=0.50, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("halo_spread"),
    )
    motion_curve_influence: FloatProperty(
        name="Motion Curve",
        description=(
            "Influence of surrounding animation keyframes on main-stroke "
            "direction and curvature; 0 preserves the static line design"
        ),
        subtype="FACTOR", default=1.0, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("motion_curve_influence"),
    )
    angle: FloatProperty(
        name="Angle",
        description="Cyclic direction; values outside +/-180 degrees wrap to the equivalent angle",
        subtype="ANGLE", default=1.57079632679,
        step=1, precision=2, get=_angle_get, set=_angle_set,
        update=_changed("angle"),
    )
    focus: FloatVectorProperty(
        name="Focus", size=2, subtype="XYZ", default=(0.5, 0.5),
        min=0.0, max=1.0, update=_changed("focus"),
    )
    focus_x: IntProperty(
        name="X", description="Radial focus X coordinate in camera-output pixels",
        min=0, max=65535, step=1, get=_focus_x_get, set=_focus_x_set,
    )
    focus_y: IntProperty(
        name="Y", description="Radial focus Y coordinate in camera-output pixels",
        min=0, max=65535, step=1, get=_focus_y_get, set=_focus_y_set,
    )
    strength: FloatProperty(
        name="Strength", subtype="FACTOR", default=0.50, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("strength"),
    )
    line_thickness: FloatProperty(
        name="Thickness",
        description="Median foreground-stroke width; stroke families keep their natural width variation",
        subtype="FACTOR", default=0.50, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("line_thickness"),
    )
    radial_threshold: FloatProperty(
        name="Threshold",
        description=(
            "Size of the protected white impact burst at the Radial focus; "
            "higher values stop ink farther from the focus"
        ),
        subtype="FACTOR", default=0.50, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("radial_threshold"),
    )
    radial_spiral: FloatProperty(
        name="Twirl",
        description=(
            "Signed hypnosis-like radial twirl; zero keeps rays straight and "
            "negative and positive values reverse the curl without changing ink intensity"
        ),
        default=0.0, min=-1.0, max=1.0,
        step=1, precision=2, update=_changed("radial_spiral"),
    )
    band_transition: FloatProperty(
        name="Band",
        description=(
            "Strength of irregular white rests within generated impact lines; "
            "low values make fewer, longer rests and high values make them denser"
        ),
        subtype="FACTOR", default=0.0, min=0.0, max=1.0,
        step=1, precision=2,
        update=_changed("band_transition"),
    )
    motion_blur: FloatProperty(
        name="Motion Blur",
        description="Directional frame blur following the resolved 3D/2D Linear direction or Radial focus field",
        subtype="FACTOR", default=0.0, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("motion_blur"),
    )
    foreground: FloatVectorProperty(
        name="Foreground", subtype="COLOR", size=4,
        default=(0.0, 0.0, 0.0, 1.0), min=0.0, max=1.0, update=_changed("foreground"),
    )
    background: FloatVectorProperty(
        name="Background", subtype="COLOR", size=4,
        default=(1.0, 1.0, 1.0, 1.0), min=0.0, max=1.0, update=_changed("background"),
    )
    flip: BoolProperty(
        name="Legacy Flip State",
        description="Compatibility storage for frames authored before Flip became an action",
        default=False, options={"HIDDEN"},
    )
    background_intensity: FloatProperty(
        name="Background Intensity",
        description=(
            "Coverage of the thin camera-flow strokes behind the subject; "
            "0 is an exact background-line bypass"
        ),
        subtype="FACTOR", default=0.5, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("background_intensity"),
    )
    background_motion: FloatProperty(
        name="Background Motion",
        description=(
            "Influence of captured camera pan, rotation, and dolly motion on "
            "the background stroke field"
        ),
        subtype="FACTOR", default=0.5, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("background_motion"),
    )
    invert: BoolProperty(
        name="Invert",
        description="Negative the complete rendered frame",
        default=False, update=_changed("invert"),
    )
    color_semantics_version: IntProperty(default=0, options={"HIDDEN"})
    band_semantics_version: IntProperty(default=0, options={"HIDDEN"})
    flip_semantics_version: IntProperty(default=0, options={"HIDDEN"})
    light_focus: FloatVectorProperty(
        name="Light", size=2, subtype="XYZ", default=(0.5, 0.5),
        min=0.0, max=1.0, update=_changed("light_focus"),
    )
    light_x: IntProperty(
        name="X", description="Horizontal orbit of the camera-facing key light",
        min=-90, max=90, step=1, get=_light_x_get, set=_light_x_set,
    )
    light_y: IntProperty(
        name="Y", description="Vertical orbit of the camera-facing key light",
        min=-90, max=90, step=1, get=_light_y_get, set=_light_y_set,
    )
    light_radius: FloatProperty(
        name="Strength", description="Brightness of the camera-space key light",
        subtype="FACTOR", default=1.0, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("light_radius"),
    )
    bleed: FloatProperty(
        name="Bleed",
        description=(
            "Light-colored manga separation surrounding generated lines so "
            "their motion remains readable over dark backgrounds; 0 is an exact bypass"
        ),
        subtype="FACTOR", default=0.5, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("bleed"),
    )
    light_cast_behind: BoolProperty(
        name="Cast Behind",
        description="Orbit the key light over the rear camera-space hemisphere",
        default=False, update=_changed("light_cast_behind"),
    )
    light_color_source: EnumProperty(
        name="Color",
        description="Choose a frame endpoint or an independent light color",
        items=(
            ("FOREGROUND", "Foreground", "Use the current Foreground color"),
            ("BACKGROUND", "Background", "Use the current Background color"),
            ("CUSTOM", "Custom", "Use an independent light color"),
        ),
        default="CUSTOM", update=_changed("light_color_source"),
    )
    light_color: FloatVectorProperty(
        name="Light Color", subtype="COLOR", size=4,
        default=(1.0, 1.0, 1.0, 1.0), min=0.0, max=1.0,
        update=_changed("light_color"),
    )
    shapes: CollectionProperty(type=ImpactionShapeSettings)
    active_shape_index: IntProperty(
        default=-1, min=-1, options={"HIDDEN"},
        update=_shape_selection_changed,
    )
    shape_selection_anchor: IntProperty(
        default=-1, min=-1, options={"HIDDEN", "SKIP_SAVE"},
    )
    contrast: FloatProperty(
        name="Contrast", subtype="FACTOR", default=0.0, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("contrast"),
    )
    grayscale: FloatProperty(
        name="Grayscale", subtype="FACTOR", default=0.0, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("grayscale"),
    )
    bloom: FloatProperty(
        name="Bloom", subtype="FACTOR", default=0.0, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("bloom"),
    )
    chromatic_aberration: FloatProperty(
        name="Chromatic Aberration", subtype="FACTOR", default=0.0, min=0.0, max=1.0,
        step=1, precision=2,
        update=_changed("chromatic_aberration"),
    )
    aberration_preset: EnumProperty(
        name="Color",
        description="Choose an optical spectrum, a named color pair, or a custom gradient",
        items=(
            ("PRISM", "Full Color",
             "CIE-derived full visible-spectrum glass dispersion"),
            ("CYAN_MAGENTA", "Digital Glitch",
             "Cyan #00FFFF to Magenta #FF00FF"),
            ("RED_CYAN", "3D Anaglyph",
             "Red #FF0000 to Cyan #00FFFF"),
            ("GREEN_MAGENTA", "Acid Glitch",
             "Green #00FF00 to Magenta #FF00FF"),
            ("AMBER_BLUE", "Cinematic Fringe",
             "Amber #FFB700 to Blue #0000FF"),
            ("RGB", "RGB", "Blue #0000FF, Green #00FF00, Red #FF0000"),
            ("CMY", "CMY", "Yellow #FFFF00, Magenta #FF00FF, Cyan #00FFFF"),
            ("CUSTOM", "Custom", "Use an editable custom aberration gradient"),
        ),
        default="PRISM", update=_aberration_preset_changed,
    )
    aberration_blur_smoothing: BoolProperty(
        name="Blur Smoothing",
        description="Blend neighboring spectral samples for softer color fringes",
        default=True, update=_changed("aberration_blur_smoothing"),
    )
    aberration_color_a: FloatVectorProperty(
        name="Color A", subtype="COLOR", size=4,
        default=(1.0, 0.0, 0.0, 1.0), min=0.0, max=1.0,
        update=_changed("aberration_color_a"),
    )
    aberration_color_b: FloatVectorProperty(
        name="Color B", subtype="COLOR", size=4,
        default=(0.0, 1.0, 1.0, 1.0), min=0.0, max=1.0,
        update=_changed("aberration_color_b"),
    )
    grain: FloatProperty(
        name="Scatter",
        description="Foreground-colored proximity scatter emitted from the drawn linework",
        subtype="FACTOR", default=0.0, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("grain"),
    )
    grain_overlay_intensity: FloatProperty(
        name="Film Grain",
        description="Strength of the sparse frame-wide film emulsion",
        subtype="FACTOR", default=0.0, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("grain_overlay_intensity"),
    )
    halftone: FloatProperty(
        name="Halftone",
        description="Intensity of the depth- and light-aware clustered-dot print screen",
        subtype="FACTOR", default=0.0, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("halftone"),
    )
    halftone_size: IntProperty(
        name="Halftone Size", description="Halftone cluster size",
        default=3, min=1, max=100, soft_min=1, soft_max=100,
        step=1, update=_changed("halftone_size"),
    )
    pixelate: FloatProperty(
        name="Pixelate",
        description="Block-sample the composed frame before optical effects",
        subtype="FACTOR", default=0.0, min=0.0, max=1.0,
        step=1, precision=2, update=_changed("pixelate"),
    )
    pixelate_size: IntProperty(
        name="Size", description="Pixel block size",
        default=10, min=1, max=100, soft_min=1, soft_max=100,
        step=1, update=_changed("pixelate_size"),
    )
    aberration_ramp: StringProperty(default="", options={"HIDDEN"})
    aberration_custom_initialized: BoolProperty(default=False, options={"HIDDEN"})
    cache_valid: BoolProperty(default=False, options={"HIDDEN"})
    cache_image: StringProperty(default="", options={"HIDDEN"})
    cache_signature: StringProperty(default="", options={"HIDDEN"})
    capture_subject: StringProperty(default="", options={"HIDDEN"})
    capture_floor: StringProperty(default="", options={"HIDDEN"})
    # Presentation-only state: organized sections without renderer features.
    ui_composition_open: BoolProperty(default=True, options={"SKIP_SAVE"})
    ui_properties_open: BoolProperty(default=True, options={"SKIP_SAVE"})
    ui_line_open: BoolProperty(default=True, options={"SKIP_SAVE"})
    ui_light_open: BoolProperty(default=True, options={"SKIP_SAVE"})
    ui_effects_open: BoolProperty(default=True, options={"SKIP_SAVE"})

    def initialize(self, frame):
        self.frame = int(frame)
        self.salt = secrets.randbelow(2_000_000_000) + 1
        # Explicit initialization prevents stale RNA/default state from older
        # enabled extension builds from creating a hidden-stroke first frame.
        self.mode = "LINEAR"
        self.linear_enabled = True
        self.radial_enabled = False
        self.direction_focus = (0.5, 0.75)
        self.direction_cast_behind = False
        self.light_cast_behind = False
        self.bleed = 0.5
        self.halo_spread = 0.50
        self.motion_curve_influence = 1.0
        self.radial_threshold = 0.50
        self.radial_spiral = 0.0
        self.motion_blur = 0.0
        self.aberration_blur_smoothing = True
        # Existing saved frames inherit the RNA zero default and remain
        # unchanged; newly authored frames use the requested full backdrop
        # coverage with a balanced camera-motion contribution.
        self.background_intensity = 0.5
        self.background_motion = 0.5
        self.color_semantics_version = 2
        self.band_semantics_version = 1
        self.flip = False
        self.flip_semantics_version = 2
        self.cache_valid = False
        self.cache_signature = ""
        from .impaction_gradient import ensure_aberration_ramp
        ensure_aberration_ramp(self)


class ImpactionSceneState(PropertyGroup):
    shape_draw_active: BoolProperty(default=False, options={"HIDDEN"})
    shape_draw_mode: StringProperty(default="DRAW", options={"HIDDEN"})
    preview_opacity: FloatProperty(
        name="Opacity",
        description="Impact Frame opacity in the camera-view live preview",
        subtype="PERCENTAGE", default=100.0, min=0.0, max=100.0,
        step=1, precision=0,
        update=_preview_changed,
    )


PROPERTY_CLASSES = (
    ImpactionShapePoint, ImpactionShapeSettings,
    ImpactionFrameSettings, ImpactionSceneState,
)


def register_properties():
    for cls in PROPERTY_CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Object.impaction_frames = CollectionProperty(type=ImpactionFrameSettings)
    bpy.types.Object.impaction_fps = IntProperty(
        name="FPS",
        description="Spacing cadence for this camera's Impact Frame keys",
        default=24, min=1, max=120, update=_fps_changed,
    )
    bpy.types.Object.impaction_grid_anchor = IntProperty(default=0, options={"HIDDEN"})
    bpy.types.Object.impaction_grid_initialized = BoolProperty(default=False, options={"HIDDEN"})
    bpy.types.Scene.impaction = PointerProperty(type=ImpactionSceneState)


def unregister_properties():
    if hasattr(bpy.types.Scene, "impaction"):
        del bpy.types.Scene.impaction
    if hasattr(bpy.types.Object, "impaction_frames"):
        del bpy.types.Object.impaction_frames
    if hasattr(bpy.types.Object, "impaction_fps"):
        del bpy.types.Object.impaction_fps
    if hasattr(bpy.types.Object, "impaction_grid_anchor"):
        del bpy.types.Object.impaction_grid_anchor
    if hasattr(bpy.types.Object, "impaction_grid_initialized"):
        del bpy.types.Object.impaction_grid_initialized
    for cls in reversed(PROPERTY_CLASSES):
        bpy.utils.unregister_class(cls)
