"""GPU mask/velocity rasterization and procedural impact-frame rendering."""

from collections import OrderedDict
from array import array
import json
import hashlib
import math
import time
from types import SimpleNamespace

import bpy
import gpu
import numpy as np
from gpu_extras.batch import batch_for_shader
from bpy_extras import view3d_utils

from .impaction_capture import (
    CaptureGeometry, ImpactCapture, capture_current_impact, capture_impact,
    capture_impacts,
)
from .impaction_shader_factory import _create_shader
from .impaction_constants import CACHE_PREFIX
from .impaction_gradient import (
    aberration_colors, aberration_gradient_samples, aberration_glitch_colors, aberration_ramp_signature,
)

_shaders = {}
_capture_cache = OrderedDict()
_capture_cache_bytes = 0
_raster_cache = OrderedDict()
_mask_cache = OrderedDict()
_radial_mask_cache = OrderedDict()
_background_family_scratch = None
_radial_seed_scratch = None
_owner_geometry_cache = OrderedDict()
_linear_depth_cache = OrderedDict()
_linear_stroke_cache = OrderedDict()
_linear_batch_cache = OrderedDict()
_interactive_mask_keys = {}
_rig_layer_cache = OrderedDict()
_grade_source_cache = OrderedDict()
_tail_source_cache = OrderedDict()
_motion_result_cache = OrderedDict()
_effect_field_cache = OrderedDict()
_surface_pool = OrderedDict()
_surface_pool_bytes = 0
_SURFACE_POOL_BUDGET = 96 * 1024 * 1024
_cache_diagnostics = {
    "mask_evictions": 0,
    "raster_evictions": 0,
    "interactive_replacements": 0,
    "interactive_resize_discards": 0,
    "surface_free_seconds": 0.0,
    "max_surface_free_seconds": 0.0,
    "orphan_preview_images_removed": 0,
    "orphan_preview_bytes_released": 0,
}
_preview_images = {}
_preview_signatures = {}
_preview_surfaces = OrderedDict()
_retired_preview_images = set()
_preview_generation = 0
_display_batches = OrderedDict()
_display_upload_seen = OrderedDict()
_signature_revisions = OrderedDict()
_signature_cache = OrderedDict()
_gradient_textures = OrderedDict()
_readback_buffers = OrderedDict()
_display_shader = None
_brush_texture = None
_loaded_brush_texture = None
_fullscreen_batch = None
_empty_rgba_texture = None
_RASTER_PIXEL_BUDGET = 80_000_000
_PREVIEW_SURFACE_BUDGET = 8
_MASK_PIXEL_BUDGET = 28_000_000
_CAPTURE_BYTE_BUDGET = 128 * 1024 * 1024
_DISPLAY_BATCH_BUDGET = 24
_DISPLAY_UPLOAD_BUDGET = 64
_SIGNATURE_CACHE_BUDGET = 4096
_GRADIENT_TEXTURE_BUDGET = 24
_READBACK_BUFFER_BUDGET = 2
_READBACK_BYTE_BUDGET = 64 * 1024 * 1024
# Increment only when a renderer/shader change makes persisted pixels unsafe
# to reuse. Old frames keep their capture geometry and regenerate on first
# visible draw instead of showing a stale or black image after an update.
_RENDER_CACHE_VERSION = 366
_CAPTURE_SCHEMA_VERSION = 5  # Past-only translation and rigid surface rotation.


def _gpu_backend_name():
    try:
        backend = getattr(gpu.platform, "backend_type_get", None)
        return str(backend()) if backend is not None else "UNKNOWN"
    except Exception:
        return "UNKNOWN"


def _shader(name, vertex, fragment):
    shader = _shaders.get(name)
    if shader is not None:
        return shader
    backend = _gpu_backend_name()
    # Blender's OpenGL GLSL translation rejects the primary shader's richer
    # out-parameter interface before it can optimize it. Select the audited
    # compatibility path up front instead of printing a screenful of compiler
    # errors and then arriving at the same shader through exception fallback.
    if name == "impact" and backend == "OPENGL":
        shader = _create_shader(name, vertex, "impact_compat.frag")
        _shaders[name] = shader
        return shader
    try:
        shader = _create_shader(name, vertex, fragment)
    except Exception as primary_error:
        if name != "impact":
            raise
        print(
            "Impaction: primary impact shader compilation failed "
            f"on {backend}; retrying compatibility shader. "
            f"Primary error: {primary_error}"
        )
        try:
            shader = _create_shader(name, vertex, "impact_compat.frag")
            print(f"Impaction: compatibility impact shader active on {backend}.")
        except Exception as fallback_error:
            raise RuntimeError(
                "Impact shader compilation failed for both primary and "
                f"compatibility paths on {backend}. Primary: {primary_error}; "
                f"Fallback: {fallback_error}"
            ) from fallback_error
    _shaders[name] = shader
    return shader


def _fullscreen_quad(shader):
    """Return the immutable fullscreen geometry shared by every post pass."""
    global _fullscreen_batch
    if _fullscreen_batch is None:
        _fullscreen_batch = batch_for_shader(
            shader, "TRI_FAN",
            {
                "position": (
                    (-1.0, -1.0), (1.0, -1.0),
                    (1.0, 1.0), (-1.0, 1.0),
                ),
                "texCoord": (
                    (0.0, 0.0), (1.0, 0.0),
                    (1.0, 1.0), (0.0, 1.0),
                ),
            },
        )
    return _fullscreen_batch


def _enable_linear_filter(texture):
    """Enable linear sampling when Blender exposes the texture setter.

    Blender 4.2-5.0 already initialize non-integer GPU textures with linear
    sampling, but their Python GPUTexture type does not expose filter_mode().
    Blender 5.1+ exposes the setter, so retain the explicit request there.
    """
    set_filter_mode = getattr(texture, "filter_mode", None)
    if callable(set_filter_mode):
        set_filter_mode(True)
    return texture


def _enable_nearest_filter(texture):
    """Keep categorical render targets from interpolating adjacent IDs."""
    set_filter_mode = getattr(texture, "filter_mode", None)
    if callable(set_filter_mode):
        set_filter_mode(False)
    return texture


def _empty_texture():
    """Return one context-local transparent/zero sampling texture."""
    global _empty_rgba_texture
    if _empty_rgba_texture is None:
        buffer = gpu.types.Buffer("FLOAT", 4, (0.0, 0.0, 0.0, 0.0))
        _empty_rgba_texture = gpu.types.GPUTexture(
            (1, 1), format="RGBA32F", data=buffer,
        )
        _enable_linear_filter(_empty_rgba_texture)
    return _empty_rgba_texture


def _gradient_texture(parameters):
    """Reuse exact immutable gradient/light parameter textures by value."""
    key = tuple(tuple(float(channel) for channel in texel) for texel in parameters)
    texture = _gradient_textures.pop(key, None)
    if texture is not None:
        _gradient_textures[key] = texture
        return texture
    buffer = gpu.types.Buffer(
        "FLOAT", len(key) * 4,
        [channel for texel in key for channel in texel],
    )
    texture = gpu.types.GPUTexture(
        (len(key), 1), format="RGBA32F", data=buffer,
    )
    _enable_linear_filter(texture)
    _gradient_textures[key] = texture
    while len(_gradient_textures) > _GRADIENT_TEXTURE_BUDGET:
        _old_key, old_texture = _gradient_textures.popitem(last=False)
        try:
            old_texture.free()
        except (AttributeError, ReferenceError, RuntimeError):
            pass
    return texture



class _OwnerGeometryPacket:
    def __init__(self, geometry, bounds_texture, count, surface):
        self.geometry = geometry  # Keeps identity keys safe against ID reuse.
        self.bounds_texture = bounds_texture
        self.count = count
        self.surface = surface

    def free(self):
        if self.surface is not None:
            self.surface.free()
            self.surface = None
        if self.bounds_texture is not None:
            self.bounds_texture.free()
            self.bounds_texture = None
        self.geometry = None


def _cached_owner_geometry(camera, record, capture, width, height):
    key = (*_capture_key(camera, record), width, height, id(capture.subject))
    packet = _cache_get(_owner_geometry_cache, key)
    if packet is None:
        texture, count, owned, surface = _owner_bounds_texture(
            capture.subject, width, height)
        if not owned:
            return texture, count, False, surface
        packet = _OwnerGeometryPacket(capture.subject, texture, count, surface)
        _cache_put(_owner_geometry_cache, key, packet,
                   surface.width * surface.height, 8_000_000)
        while len(_owner_geometry_cache) > 2:
            _drop_cache_key(_owner_geometry_cache, next(iter(_owner_geometry_cache)))
    return packet.bounds_texture, packet.count, False, packet.surface


def _owner_depth_atlas(geometry, bounds, width, height):
    """Rasterize each mesh separately at output-pixel density in cropped tiles.

    Nearer limbs must not trim another owner's contour before stroke construction.
    G uses the same window depth as ownershipTex; empty tiles have ID zero.
    """
    sizes = [(max(2, int(math.ceil((b[2] - b[0]) * width))),
              max(2, int(math.ceil((b[3] - b[1]) * height)))) for b in bounds]
    # Bound allocation in unusually large crowds. Ordinary rig crops retain
    # one sample per output pixel, including the full-HD validation fixture.
    area = sum((x + 4) * (y + 4) for x, y in sizes)
    scale = min(1.0, math.sqrt(4_000_000 / max(area, 1)))
    sizes = [(max(2, int(x * scale)), max(2, int(y * scale))) for x, y in sizes]
    shelf_width = max(max(x + 4 for x, _y in sizes),
                      min(4096, max(512, int(math.sqrt(area * scale * scale) * 1.4))))
    offsets, cursor_x, cursor_y, shelf_height = [], 0, 0, 0
    for x, y in sizes:
        if cursor_x + x + 4 > shelf_width:
            cursor_x, cursor_y = 0, cursor_y + shelf_height
            shelf_height = 0
        offsets.append((cursor_x + 2, cursor_y + 2))
        cursor_x += x + 4
        shelf_height = max(shelf_height, y + 4)
    atlas_height = 2 * max(4, cursor_y + shelf_height)
    tiles = [[x / shelf_width, y / atlas_height,
              (x + size[0]) / shelf_width, (y + size[1]) / atlas_height]
             for (x, y), size in zip(offsets, sizes)]
    positions = []
    for p, owner in zip(geometry.positions, geometry.owner_ids):
        index = int(round(owner)) - 1
        b, tile = bounds[index], tiles[index]
        u = (float(p[0]) - b[0]) / max(b[2] - b[0], 1e-8)
        v = (float(p[1]) - b[1]) / max(b[3] - b[1], 1e-8)
        positions.append((tile[0] + u * (tile[2] - tile[0]),
                          tile[1] + v * (tile[3] - tile[1]), float(p[2])))
    atlas_geometry = SimpleNamespace(
        positions=positions, triangles=geometry.triangles,
        owner_ids=geometry.owner_ids)
    back_geometry = SimpleNamespace(
        positions=[(x, y + 0.5, z) for x, y, z in positions],
        triangles=geometry.triangles, owner_ids=geometry.owner_ids)
    surface = _draw_ownership_geometry(
        atlas_geometry, shelf_width, atlas_height, back_geometry=back_geometry)
    back_tiles = [[x0, y0 + 0.5, x1, y1 + 0.5] for x0, y0, x1, y1 in tiles]
    return surface, tiles, back_tiles

def _owner_bounds_texture(geometry, width, height):
    """Encode owner bounds and soft proximity-connected spread groups.

    Row 0 stores each visible owner's projected bounds. Row 1 stores the
    union bounds of its evaluated-world proximity component. Row 2 stores the
    owner's transition weight, stable component ID, and member count.
    Keeping this in the existing texture avoids another shader resource.
    """
    if geometry is None or not geometry.owner_ids:
        return _empty_texture(), 0, False, None
    geometry = _linearized_depth_geometry(geometry)
    owner_count = max(0, int(round(max(geometry.owner_ids))))
    if owner_count <= 0:
        return _empty_texture(), 0, False, None
    bounds = [[1.0, 1.0, 0.0, 0.0] for _index in range(owner_count)]
    group_ids = [0.0] * owner_count
    cohesion = [0.0] * owner_count
    vertex_groups = geometry.spread_group_ids or geometry.owner_ids
    vertex_weights = geometry.spread_group_weights or [0.0] * len(
        geometry.owner_ids,
    )
    for position, owner_value, group_value, group_weight in zip(
            geometry.positions, geometry.owner_ids,
            vertex_groups, vertex_weights):
        owner_index = int(round(owner_value)) - 1
        if owner_index < 0 or owner_index >= owner_count:
            continue
        if group_ids[owner_index] <= 0.0:
            group_ids[owner_index] = float(group_value)
        cohesion[owner_index] = max(
            cohesion[owner_index], float(group_weight),
        )
        x = float(position[0])
        y = float(position[1])
        item = bounds[owner_index]
        item[0] = min(item[0], x)
        item[1] = min(item[1], y)
        item[2] = max(item[2], x)
        item[3] = max(item[3], y)
    for item in bounds:
        if item[2] <= item[0] or item[3] <= item[1]:
            item[:] = (0.0, 0.0, 0.0, 0.0)

    components = {}
    for owner_index, group_id in enumerate(group_ids):
        stable_group = int(round(group_id)) if group_id > 0.0 else owner_index + 1
        group_ids[owner_index] = float(stable_group)
        components.setdefault(stable_group, []).append(owner_index)
    ordered_components = sorted(components.values(), key=lambda members: min(members))
    group_bounds = [list(item) for item in bounds]
    group_counts = [1.0] * owner_count
    for members in ordered_components:
        valid = [bounds[index] for index in members
                 if bounds[index][2] > bounds[index][0]
                 and bounds[index][3] > bounds[index][1]]
        if valid:
            union_bounds = [
                min(item[0] for item in valid),
                min(item[1] for item in valid),
                max(item[2] for item in valid),
                max(item[3] for item in valid),
            ]
        else:
            union_bounds = [0.0, 0.0, 0.0, 0.0]
        for owner_index in members:
            group_bounds[owner_index] = list(union_bounds)
            group_counts[owner_index] = float(len(members))

    # Rasterize each connected component as a union in separate atlas tiles.
    # Object tiles remain available for independent depth diagnostics.
    member_to_group = {}
    representative = [0.0] * owner_count
    union_bounds = []
    for group_index, members in enumerate(ordered_components):
        union_bounds.append(group_bounds[members[0]])
        for member in members:
            member_to_group[member] = group_index
            representative[member] = float(min(members) + 1)
    count = len(geometry.positions)
    combined = SimpleNamespace(
        positions=list(geometry.positions) + list(geometry.positions),
        owner_ids=list(geometry.owner_ids) + [
            float(owner_count + member_to_group[int(round(owner)) - 1] + 1)
            for owner in geometry.owner_ids],
        triangles=list(geometry.triangles) + [
            tuple(index + count for index in triangle)
            for triangle in geometry.triangles])
    owner_surface, all_front, all_back = _owner_depth_atlas(
        combined, bounds + union_bounds, width, height)
    tile_bounds, back_tiles = all_front[:owner_count], all_back[:owner_count]
    group_front = [all_front[owner_count + member_to_group[i]] for i in range(owner_count)]
    group_back = [all_back[owner_count + member_to_group[i]] for i in range(owner_count)]
    # Rig slices retain global owner IDs, leaving holes in this table. A
    # grouped sum avoids rescanning every vertex per owner and empty means.
    owner_indices = np.rint(np.asarray(geometry.owner_ids)).astype(np.int64) - 1
    valid_owners = (owner_indices >= 0) & (owner_indices < owner_count)
    owner_indices = owner_indices[valid_owners]
    depth_values = np.asarray(geometry.positions, dtype=np.float64)[:, 2][valid_owners]
    depth_sum = np.bincount(owner_indices, weights=depth_values, minlength=owner_count)
    depth_count = np.bincount(owner_indices, minlength=owner_count)
    owner_depth = np.divide(depth_sum, depth_count, out=np.zeros(owner_count), where=depth_count > 0)
    metadata_rows = [
        bounds,
        group_bounds,
        [
            [cohesion[index], group_ids[index],
             group_counts[index], representative[index]]
            for index in range(owner_count)
        ],
        tile_bounds,
        back_tiles,
        group_front,
        group_back,
        # Owner-relative captured depth accompanies released strokes on paper.
        [[float(value), 0., 0., 0.] for value in owner_depth],
    ]
    buffer = gpu.types.Buffer(
        "FLOAT", owner_count * 8 * 4,
        [channel for row in metadata_rows for item in row for channel in item],
    )
    texture = gpu.types.GPUTexture(
        (owner_count, 8), format="RGBA32F", data=buffer,
    )
    _enable_nearest_filter(texture)
    return texture, owner_count, True, owner_surface


def _background_family_target():
    global _background_family_scratch
    if _background_family_scratch is None:
        # Float32 keeps authored anchors and widths; half floats visibly shift
        # distant fine lines. One staging surface is reused in command order.
        _background_family_scratch = gpu.types.GPUOffScreen(288,12,format="RGBA32F")
    return _background_family_scratch


def _radial_seed_target():
    global _radial_seed_scratch
    if _radial_seed_scratch is None:
        _radial_seed_scratch = gpu.types.GPUOffScreen(112, 2, format="RGBA32F")
    return _radial_seed_scratch


class _BorrowedSurface:
    """Read-only cached surface lease; its cache retains allocation ownership."""
    def __init__(self, surface): self._surface = surface
    @property
    def texture_color(self): return self._surface.texture_color
    @property
    def width(self): return self._surface.width
    @property
    def height(self): return self._surface.height
    def bind(self): return self._surface.bind()
    def free(self): pass


class _PooledSurface:
    """One checked-out scratch framebuffer; release never aliases its owner."""
    def __init__(self, surface, key):
        self._surface, self._key = surface, key
    @property
    def texture_color(self): return self._surface.texture_color
    @property
    def width(self): return self._surface.width
    @property
    def height(self): return self._surface.height
    def bind(self): return self._surface.bind()
    def free(self):
        global _surface_pool_bytes
        surface, self._surface = self._surface, None
        if surface is None: return
        weight = self._key[0] * self._key[1] * (12 if self._key[2] else 8)
        if weight > _SURFACE_POOL_BUDGET:
            surface.free(); return
        _surface_pool[id(surface)] = (self._key, surface, weight)
        _surface_pool_bytes += weight
        while _surface_pool_bytes > _SURFACE_POOL_BUDGET:
            _, (_, victim, count) = _surface_pool.popitem(last=False)
            _surface_pool_bytes -= count
            victim.free()


def _clear_surface_pool():
    global _surface_pool_bytes
    for _key, surface, _weight in _surface_pool.values(): surface.free()
    _surface_pool.clear()
    _surface_pool_bytes = 0


def _offscreen(width, height, high_precision=False):
    global _surface_pool_bytes
    key = (int(width), int(height), bool(high_precision))
    found = next((token for token, item in reversed(_surface_pool.items()) if item[0] == key), None)
    if found is not None:
        _, target, weight = _surface_pool.pop(found)
        _surface_pool_bytes -= weight
    else:
        target = gpu.types.GPUOffScreen(width,height,format="RGBA16F" if high_precision else "RGBA8")
    # Previous data passes can have changed sampler filtering while checked out.
    _enable_linear_filter(target.texture_color)
    return _PooledSurface(target,key)


def _shape_texture(record):
    """Encode frame-local shapes in one compact GPU texture."""
    max_shapes, max_points, stride = 16, 256, 7
    point_base = max_shapes * stride
    texels = np.zeros((point_base + max_points, 4), dtype=np.float32)
    point_cursor = 0
    count = min(max_shapes, len(record.shapes))
    ordered_shapes = sorted(enumerate(record.shapes[:count]),
                            key=lambda item: (item[1].layer == "FRONT", -item[0]))
    for index, (_source_index, shape) in enumerate(ordered_shapes):
        offset = index * stride
        point_count = min(max_points - point_cursor, len(shape.points))
        texels[offset] = (
            0.0 if shape.shape_type == "STAR" else 1.0,
            0.0 if shape.layer == "FRONT" else 1.0,
            float(shape.position[0]), float(shape.position[1]),
        )
        texels[offset + 1] = (
            float(shape.width), float(shape.height), float(shape.radius),
            float(getattr(shape, "effect_influence", 0.5)),
        )
        texels[offset + 2] = (
            float(shape.line_thickness), float(point_cursor),
            float(point_count), float(shape.end_width),
        )
        texels[offset + 3] = tuple(shape.foreground)
        texels[offset + 4] = (
            float(shape.burst_amount), float(shape.burst_thickness),
            float(int(getattr(shape, "variation", 1)) % 104729) / 104729.0,
            float(getattr(shape, "burst_end", 0.0)),
        )
        texels[offset + 5] = (float(shape.rotation), *tuple(getattr(shape, "perspective", (0.0, 0.0))), 0.0)
        texels[offset + 6] = (
            float(getattr(shape, "stroke", 0.0)),
            float(shape.stroke_color[0]), float(shape.stroke_color[1]),
            float(shape.stroke_color[2]),
        )
        for point_index in range(point_count):
            point = shape.points[point_index]
            texels[point_base + point_cursor + point_index] = (
                float(point.position[0]), float(point.position[1]),
                float(point.pressure), 1.0 if point.break_before else 0.0,
            )
        point_cursor += point_count
    buffer = gpu.types.Buffer("FLOAT", texels.size, texels.ravel().tolist())
    texture = gpu.types.GPUTexture(
        (len(texels), 1), format="RGBA32F", data=buffer,
    )
    return texture, count


def _smoothstep(edge0, edge1, value):
    value = max(0.0, min(1.0, (value - edge0) / max(edge1 - edge0, 1.0e-8)))
    return value * value * (3.0 - 2.0 * value)


def _brush_pressure(position, attack, release):
    return (_smoothstep(0.0, attack, position) *
            _smoothstep(0.0, release, 1.0 - position))


def _brush_atlas():
    """Return one cached procedural atlas of original charcoal brush swipes."""
    global _brush_texture
    if _brush_texture is not None:
        return _brush_texture
    width, cell_height, variants = 1024, 256, 4
    height = cell_height * variants
    pixels = np.zeros((height, width, 2), dtype=np.float32)
    # core radius, lane count, attack, release, edge veil.  The core value is
    # only a sampling-density bias; no opaque rectangle is laid underneath.
    styles = (
        (0.46, 76, 0.07, 0.23, 0.010),
        (0.52, 68, 0.10, 0.18, 0.012),
        (0.42, 84, 0.045, 0.29, 0.008),
        (0.48, 72, 0.13, 0.16, 0.010),
    )
    for variant, (core_radius, lane_count, attack, release, veil) in enumerate(styles):
        lane_data = []
        for lane in range(lane_count):
            seed = math.sin((variant + 1.7) * (lane + 3.1) * 19.19) * 43758.5453
            seed -= math.floor(seed)
            seed_b = math.sin((variant + 4.3) * (lane + 7.7) * 11.73) * 24634.6345
            seed_b -= math.floor(seed_b)
            # Randomized bristle placement avoids the evenly spaced grooves
            # that read as a computer hatch.  Most fibers bunch near the core;
            # a few live at the ragged outside edge.
            signed = seed * 2.0 - 1.0
            center = math.copysign(abs(signed) ** 1.28, signed) * 0.96
            center += (seed_b - 0.5) * 0.035
            lane_width = 0.008 + 0.030 * ((seed * 1.731) % 1.0)
            if lane % 7 == 0:
                lane_width *= 4.8
            edge_bias = min(1.0, abs(center))
            endpoint_spread = 0.13 + 0.24 * edge_bias
            start_point = 0.010 + endpoint_spread * seed
            end_point = 0.990 - endpoint_spread * (1.0 - seed_b)
            gap_center = 0.18 + 0.64 * ((seed * 2.917) % 1.0)
            gap_width = 0.045 + 0.11 * ((seed * 4.137) % 1.0)
            gap_depth = (0.08 + 0.28 * ((seed * 7.311) % 1.0) +
                         0.40 * edge_bias)
            lane_data.append((
                center, lane_width, start_point, end_point, seed,
                gap_center, gap_width, gap_depth,
            ))
        along = (np.arange(width, dtype=np.float32) + 0.5) / width
        across = ((np.arange(cell_height, dtype=np.float32) + 0.5) /
                  cell_height * 2.0 - 1.0)
        along_grid = along[None, :]
        across_grid = across[:, None]
        edge_width = (
            0.96
            + 0.008 * np.sin(along_grid * 6.3 + variant * 1.9)
            + 0.004 * np.sin(along_grid * 17.1 + variant * 4.3)
        )
        normalized = across_grid / np.maximum(edge_width, 0.5)
        distance = np.abs(normalized)

        def smoothstep_array(edge0, edge1, values):
            denominator = np.maximum(np.asarray(edge1) - np.asarray(edge0), 1.0e-8)
            values = np.clip((values - edge0) / denominator,
                             0.0, 1.0)
            return values * values * (3.0 - 2.0 * values)

        def pressure_array(position, attack_value, release_value):
            return (smoothstep_array(0.0, attack_value, position) *
                    smoothstep_array(0.0, release_value, 1.0 - position))

        silhouette = 1.0 - smoothstep_array(0.84, 1.02, distance)
        pressure = pressure_array(along_grid, attack, release)
        # Real loaded charcoal deposits a connected pressure body. Fibers
        # separate mainly at its perimeter; leaving every lane exposed through
        # the center creates the parallel white "bacon" channels. Taper the
        # core geometrically so its ends remain pointed instead of clipped.
        tip_profile = np.sqrt(np.clip(pressure, 0.0, 1.0))
        core_span = core_radius * (0.06 + 0.94 * tip_profile)
        core_shape = 1.0 - smoothstep_array(
            core_span, core_span + 0.10, distance,
        )
        core_coverage = core_shape * pressure * 0.96
        fiber_coverage = np.zeros_like(core_coverage)
        for (center, lane_width, start_point, end_point, seed,
             gap_center, gap_width, gap_depth) in lane_data:
            lane_drift = (
                np.sin(along_grid * (5.0 + seed * 4.0) + seed * 11.0) * 0.010
                + np.sin(along_grid * (13.0 + seed * 7.0) + seed * 3.0) * 0.004
            )
            lane_width_at_x = lane_width * (
                0.82 + 0.24 * np.sin(along_grid * (17.0 + seed * 11.0) + seed * 5.0)
            )
            lane_body = 1.0 - smoothstep_array(
                lane_width_at_x * 0.60,
                lane_width_at_x,
                np.abs(normalized - center - lane_drift),
            )
            attack_width = attack * (0.62 + seed * 0.55)
            release_width = release * (0.58 + (1.0 - seed) * 0.54)
            lane_pressure = smoothstep_array(
                start_point, start_point + attack_width, along_grid,
            )
            lane_pressure *= 1.0 - smoothstep_array(
                end_point - release_width, end_point, along_grid,
            )
            scrape = np.exp(-0.5 * ((along_grid - gap_center) /
                                    max(gap_width, 1.0e-4)) ** 2)
            lane_pressure *= 1.0 - gap_depth * scrape
            lane_pressure *= 0.78 + 0.22 * np.sin(
                along_grid * (12.0 + seed * 9.0) + seed * 17.0,
            ) ** 2
            fiber_coverage = np.maximum(
                fiber_coverage, lane_body * lane_pressure,
            )
        fiber_coverage = np.maximum(
            fiber_coverage, silhouette * pressure * veil,
        )
        row_slice = slice(variant * cell_height, (variant + 1) * cell_height)
        pixels[row_slice, :, 0] = np.clip(core_coverage, 0.0, 1.0)
        pixels[row_slice, :, 1] = np.clip(fiber_coverage, 0.0, 1.0)
    flat_pixels = np.ascontiguousarray(pixels.ravel())
    buffer = gpu.types.Buffer("FLOAT", flat_pixels.size, flat_pixels)
    _brush_texture = gpu.types.GPUTexture(
        (width, height), format="RG32F", data=buffer,
    )
    # The atlas stores material deposition, not final pixels. Linear sampling
    # reconstructs that continuous footprint before the shader applies its
    # analytic one-pixel coverage transition, avoiding texel stairs without a
    # 4x full-frame fragment cost.
    _enable_linear_filter(_brush_texture)
    return _brush_texture


def _loaded_brush_atlas():
    """Return a compact Linear-only atlas with dragged charcoal scrapes."""
    global _loaded_brush_texture
    if _loaded_brush_texture is not None:
        return _loaded_brush_texture
    width, cell_height, variants = 512, 128, 4
    height = cell_height * variants
    pixels = np.zeros((height, width), dtype=np.float32)
    styles = (
        (0.46, 0.07, 0.23),
        (0.52, 0.10, 0.18),
        (0.42, 0.045, 0.29),
        (0.48, 0.13, 0.16),
    )
    along = (np.arange(width, dtype=np.float32) + 0.5) / width
    across = ((np.arange(cell_height, dtype=np.float32) + 0.5) /
              cell_height * 2.0 - 1.0)
    along_grid = along[None, :]
    across_grid = across[:, None]

    def smoothstep_array(edge0, edge1, values):
        denominator = np.maximum(
            np.asarray(edge1) - np.asarray(edge0), 1.0e-8,
        )
        values = np.clip((values - edge0) / denominator, 0.0, 1.0)
        return values * values * (3.0 - 2.0 * values)

    for variant, (core_radius, attack, release) in enumerate(styles):
        edge_width = (
            0.96
            + 0.008 * np.sin(along_grid * 6.3 + variant * 1.9)
            + 0.004 * np.sin(along_grid * 17.1 + variant * 4.3)
        )
        normalized = across_grid / np.maximum(edge_width, 0.5)
        distance = np.abs(normalized)
        pressure = smoothstep_array(0.0, attack, along_grid)
        pressure *= smoothstep_array(0.0, release, 1.0 - along_grid)
        tip_profile = np.sqrt(np.clip(pressure, 0.0, 1.0))
        core_span = core_radius * (0.06 + 0.94 * tip_profile)
        loaded = (1.0 - smoothstep_array(
            core_span, core_span + 0.10, distance,
        )) * pressure * 0.96
        loaded *= 0.52 + 0.48 * (
            0.5 + 0.5 * np.sin(
                along_grid * (31.0 + variant * 3.7)
                + np.sin(normalized * (7.0 + variant) + variant * 1.9),
            )
        )
        for scrape_index in range(4):
            scrape_seed = (variant + 1) * 17.0 + scrape_index * 11.0
            scrape_center = -0.36 + scrape_index * 0.24
            scrape_center += 0.035 * np.sin(
                along_grid * (4.7 + scrape_index * 1.3) + scrape_seed,
            )
            scrape_width = 0.052 + 0.022 * (
                0.5 + 0.5 * math.sin(scrape_seed * 1.73)
            )
            scrape_lane = np.exp(
                -0.5 * ((normalized - scrape_center) / scrape_width) ** 2,
            )
            scrape_start = 0.08 + 0.065 * scrape_index
            scrape_end = 0.84 - 0.055 * ((scrape_index + variant) % 2)
            scrape_window = smoothstep_array(
                scrape_start - 0.06, scrape_start, along_grid,
            )
            scrape_window *= 1.0 - smoothstep_array(
                scrape_end, scrape_end + 0.07, along_grid,
            )
            scrape_pressure = 0.76 + 0.18 * (
                0.5 + 0.5 * np.sin(
                    along_grid * (13.0 + scrape_index * 2.1)
                    + scrape_seed,
                )
            )
            loaded *= 1.0 - scrape_lane * scrape_window * scrape_pressure
        row_slice = slice(variant * cell_height, (variant + 1) * cell_height)
        pixels[row_slice, :] = np.clip(loaded, 0.0, 1.0)
    flat_pixels = np.ascontiguousarray(pixels.ravel())
    buffer = gpu.types.Buffer("FLOAT", flat_pixels.size, flat_pixels)
    _loaded_brush_texture = gpu.types.GPUTexture(
        (width, height), format="R32F", data=buffer,
    )
    _enable_linear_filter(_loaded_brush_texture)
    return _loaded_brush_texture


def _draw_geometry(geometry, width, height, record, target=None):
    if not geometry.positions or not geometry.triangles:
        width = height = 1
    target = target or _offscreen(width, height, high_precision=True)
    with target.bind():
        framebuffer = gpu.state.active_framebuffer_get()
        framebuffer.clear(color=(0.0, 0.0, 0.0, 0.0), depth=1.0)
        if geometry.positions and geometry.triangles:
            shader = _shader("geometry", "geometry.vert", "geometry.frag")
            cached_batch = getattr(geometry, "_lighting_batch", None)
            corner_normals=getattr(geometry,"corner_normals",())
            if cached_batch is not None and cached_batch[0] is shader:
                batch = cached_batch[1]
            elif len(corner_normals)==len(geometry.triangles)*3:
                indices=np.asarray(geometry.triangles,dtype=np.int32).ravel()
                positions=np.asarray(geometry.positions,dtype=np.float32)[indices]
                batch=batch_for_shader(shader,"TRIS",{
                    "position":positions,"normal":corner_normals})
            else:
                # Existing saved captures remain usable; an explicit Update
                # captures split normals without silently changing the pose.
                batch=batch_for_shader(shader,"TRIS",{
                    "position":geometry.positions,"normal":geometry.normals},
                    indices=geometry.triangles)
            geometry._lighting_batch = (shader, batch)
            shader.uniform_float("lightFocus", tuple(record.light_focus))
            shader.uniform_float(
                "lightCastBehind", 1.0 if record.light_cast_behind else 0.0,
            )
            gpu.state.blend_set("NONE")
            gpu.state.depth_test_set("LESS_EQUAL")
            gpu.state.depth_mask_set(True)
            batch.draw(shader)
            gpu.state.depth_mask_set(False)
            gpu.state.depth_test_set("NONE")
    return target


def _draw_motion_geometry(geometry, width, height):
    """Rasterize interpolated local screen velocity for articulated trails."""
    if not geometry.positions or not geometry.triangles:
        width = height = 1
    target = _offscreen(width, height, high_precision=True)
    with target.bind():
        framebuffer = gpu.state.active_framebuffer_get()
        framebuffer.clear(color=(0.0, 0.0, 0.0, 0.0), depth=1.0)
        if geometry.positions and geometry.triangles:
            shader = _shader(
                "motion_geometry", "motion_geometry.vert", "motion_geometry.frag",
            )
            batch = batch_for_shader(
                shader, "TRIS",
                {
                    "position": geometry.positions,
                    "velocity": geometry.velocities,
                    "acceleration": geometry.accelerations,
                },
                indices=geometry.triangles,
            )
            gpu.state.blend_set("NONE")
            gpu.state.depth_test_set("LESS_EQUAL")
            gpu.state.depth_mask_set(True)
            batch.draw(shader)
            gpu.state.depth_mask_set(False)
            gpu.state.depth_test_set("NONE")
    return target


def _linearized_depth_geometry(geometry):
    """Keep owner depth precision independent of the camera's clip range.

    Screen XY is unchanged. All owners share one affine depth range, so their
    ordering and interpolated front/rear tests remain comparable. Perspective
    uses reciprocal view distance, which is affine in projected screen space;
    orthographic cameras use linear distance. Do not
    normalize per owner: that would itself permit contact bleed-through.
    """
    cached = getattr(geometry, "_linearized_owner_geometry", None)
    if cached is not None:
        return cached
    world = getattr(geometry, "world_positions", ())
    projection = getattr(geometry, "view_projection", ())
    if not world or not projection or len(world) != len(geometry.positions):
        return geometry
    vertices = np.asarray(world, dtype=np.float64)
    matrix = np.asarray(projection, dtype=np.float64)
    if np.linalg.norm(matrix[3, :3]) > 1e-10:
        distance = vertices @ matrix[3, :3] + matrix[3, 3]
        # Preserve ordinary clipping for geometry crossing the camera plane;
        # that case requires homogeneous clipping before building owner tiles.
        if np.any(distance <= 1e-7):
            return geometry
        depth = -1.0 / distance
    else:
        axis = matrix[2, :3].copy()
        axis /= max(float(np.linalg.norm(axis)), 1e-12)
        depth = vertices @ axis
    low, high = float(depth.min()), float(depth.max())
    normalized = (depth-low)/max(high-low, 1e-15)*1.9-.95
    result = SimpleNamespace(**vars(geometry))
    result.positions = [(p[0], p[1], float(z)) for p, z in zip(geometry.positions, normalized)]
    result.world_positions = []
    # Ownership stores a normalized reciprocal-distance range, not camera Z.
    result.owner_depth_decode = (low, max(high-low, 1e-15),
                                float(np.linalg.norm(matrix[3, :3]) > 1e-10), 1.0)
    geometry._linearized_owner_geometry = result
    return result


def _draw_ownership_geometry(geometry, width, height, *, back_geometry=None):
    """Rasterize the nearest visible mesh owner and its projected depth."""
    geometry = _linearized_depth_geometry(geometry)
    if not geometry.positions and (back_geometry is None or not back_geometry.positions):
        width = height = 1
    initialize = getattr(gpu, "init", None)
    if initialize is not None:
        initialize()
    # Half-float pigment buffers collapse nearby camera depths to the same
    # value. Ownership needs full float precision for independent mesh tests.
    target = gpu.types.GPUOffScreen(width, height, format="RGBA32F")
    try:
        with target.bind():
            framebuffer = gpu.state.active_framebuffer_get()
            framebuffer.clear(color=(0.0, 1.0, 0.0, 0.0), depth=1.0)
            if geometry.positions and geometry.triangles:
                shader = _shader(
                    "ownership_geometry", "ownership_geometry.vert",
                    "ownership_geometry.frag",
                )
                batch = batch_for_shader(
                    shader, "TRIS",
                    {"position": geometry.positions, "ownerId": geometry.owner_ids},
                    indices=geometry.triangles,
                )
                gpu.state.blend_set("NONE")
                gpu.state.depth_test_set("LESS_EQUAL")
                gpu.state.depth_mask_set(True)
                batch.draw(shader)
                if back_geometry is not None:
                    # Separate tiles preserve nearest and farthest surfaces. Only
                    # depth is cleared: the front tile's color remains intact.
                    framebuffer.clear(depth=0.0)
                    rear_batch = batch_for_shader(
                        shader, "TRIS",
                        {"position": back_geometry.positions,
                         "ownerId": back_geometry.owner_ids},
                        indices=back_geometry.triangles)
                    gpu.state.depth_test_set("GREATER_EQUAL")
                    rear_batch.draw(shader)
                gpu.state.depth_mask_set(False)
                gpu.state.depth_test_set("NONE")
    except Exception:
        target.free()
        raise
    finally:
        gpu.state.depth_mask_set(False)
        gpu.state.depth_test_set("NONE")
    # Owner IDs are categorical values; filtering them would invent phantom
    # IDs between adjacent limbs and destabilize depth ownership at edges.
    _enable_nearest_filter(target.texture_color)
    return target


def _free_surface(surface):
    started = time.perf_counter()
    try:
        surface.free()
    except (AttributeError, ReferenceError, RuntimeError):
        pass
    elapsed = time.perf_counter() - started
    _cache_diagnostics["surface_free_seconds"] += elapsed
    _cache_diagnostics["max_surface_free_seconds"] = max(
        _cache_diagnostics["max_surface_free_seconds"], elapsed,
    )


def _drop_cache_key(cache, key, *, reason="eviction"):
    item = cache.pop(key, None)
    if item is None:
        return False
    value, _weight = item
    surfaces = value if isinstance(value, tuple) else (value,)
    for surface in surfaces:
        _free_surface(surface)
    if reason == "interactive":
        _cache_diagnostics["interactive_replacements"] += 1
    elif cache is _mask_cache:
        _cache_diagnostics["mask_evictions"] += 1
    elif cache is _raster_cache:
        _cache_diagnostics["raster_evictions"] += 1
    return True


def _cache_put(cache, key, value, pixel_weight, budget, protected_keys=()):
    # Retain the latest version per drawing family, not a slider's entire
    # history. Otherwise old versions evict the other rig's unchanged data.
    if cache is _motion_result_cache:
        family = lambda item: item[:-1]
    elif cache is _grade_source_cache or cache is _tail_source_cache:
        family = lambda item: item[:2]
    elif cache is _radial_mask_cache:
        family = lambda item: item[:-1]
    elif cache is _mask_cache:
        family = lambda item: item[:8] + item[9:]
    elif cache is _effect_field_cache:
        family = lambda item: item[:5] + (item[6],)
    elif cache is _rig_layer_cache:
        family = lambda item: item[:7] + item[8:]
    elif cache is _raster_cache:
        # A light gesture replaces its lit raster; retain unlit depth/motion.
        family = lambda item: item[:-1] if item[-2] == "geometry" else item
    else:
        family = None
    if family is not None:
        identity = family(key)
        for old in tuple(cache):
            if old != key and family(old) == identity:
                _drop_cache_key(cache,old,reason="superseded")
    _drop_cache_key(cache, key, reason="replacement")
    cache[key] = (value, int(pixel_weight))
    total = sum(item[1] for item in cache.values())
    protected = set(protected_keys)
    protected.add(key)
    while total > budget and len(cache) > 1:
        victim = next((candidate for candidate in cache if candidate not in protected), None)
        if victim is None:
            # One in-flight render can legitimately exceed the steady-state
            # budget at very large resolutions. Keep its surfaces alive until
            # the next raster request can evict the complete old frame.
            break
        weight = cache[victim][1]
        _drop_cache_key(cache, victim)
        total -= weight


def _cache_get(cache, key):
    item = cache.pop(key, None)
    if item is None:
        return None
    cache[key] = item
    return item[0]


def _purge_surface_cache(camera_name, salt):
    owner_key = (camera_name, int(salt))
    for key in tuple(_interactive_mask_keys):
        if key[:2] == owner_key: _interactive_mask_keys.pop(key, None)
    for cache in (_motion_result_cache, _tail_source_cache, _grade_source_cache, _rig_layer_cache, _effect_field_cache, _radial_mask_cache, _raster_cache, _mask_cache, _owner_geometry_cache, _linear_depth_cache, _linear_stroke_cache, _linear_batch_cache):
        for key in tuple(cache):
            if key[0] == camera_name and key[1] == int(salt):
                _drop_cache_key(cache, key)


def surface_cache_stats():
    """Return bounded renderer-cache telemetry for isolated profiling."""
    capture_stats = capture_cache_stats()
    return {
        "raster_entries": len(_raster_cache),
        "raster_pixels": sum(item[1] for item in _raster_cache.values()),
        "mask_entries": len(_mask_cache),
        "radial_mask_entries": len(_radial_mask_cache),
        "scratch_pool_bytes": _surface_pool_bytes,
        "effect_field_entries": len(_effect_field_cache),
        "rig_layer_entries": len(_rig_layer_cache),
        "owner_geometry_entries": len(_owner_geometry_cache),
        "linear_depth_entries": len(_linear_depth_cache),
        "linear_stroke_entries": len(_linear_stroke_cache),
        "linear_batch_entries": len(_linear_batch_cache),
        "linear_batch_bytes": sum(item[1] for item in _linear_batch_cache.values()),
        "owner_geometry_pixels": sum(item[1] for item in _owner_geometry_cache.values()),
        "mask_pixels": sum(item[1] for item in _mask_cache.values()),
        "interactive_mask_owners": len(_interactive_mask_keys),
        "preview_surface_entries": len(_preview_surfaces),
        "preview_surface_pixels": sum(
            int(item[2]) * int(item[3])
            for item in _preview_surfaces.values()
        ),
        "preview_image_entries": len(_preview_images),
        "retired_preview_images": len(_retired_preview_images),
        "capture_entries": int(capture_stats["entries"]),
        "capture_estimated_bytes": int(capture_stats["estimated_bytes"]),
        "capture_budget_bytes": int(capture_stats["budget_bytes"]),
        **{
            key: round(float(value), 6)
            if isinstance(value, float) else int(value)
            for key, value in _cache_diagnostics.items()
        },
    }


def _rasterized_capture(camera, record, capture, width, height, raster_quality=1.0):
    light_signature = (
        round(float(record.light_focus[0]), 6), round(float(record.light_focus[1]), 6),
        bool(record.light_cast_behind),
    )
    # At 1080p-class output, a 2x source raster gives the contour shader four
    # geometry samples per output pixel. At 4K the native pixel density is
    # already equivalent and avoids an unnecessary 8K allocation.
    # Scale the actual lighting/depth raster too, not only its final composite.
    # Authored paper dimensions still govern brush and post-effect sizes.
    paper_width, paper_height = _render_size(bpy.context)
    raster_scale = 2 if max(paper_width, paper_height) <= 2048 else 1
    source_quality = max(.20, min(1., float(raster_quality)))
    raster_width = max(1, round(paper_width * raster_scale * source_quality))
    raster_height = max(1, round(paper_height * raster_scale * source_quality))
    base_key = (*_capture_key(camera, record), getattr(capture, "_rig_cache", "all"), raster_width, raster_height)
    geometry_key = (*base_key, "geometry", light_signature)
    geometry_surfaces = _cache_get(_raster_cache, geometry_key)
    if geometry_surfaces is None:
        old_key = next((key for key in _raster_cache if key[:-1] == geometry_key[:-1]), None)
        reusable = _raster_cache.pop(old_key)[0] if old_key is not None else (None, None)
        subject = _draw_geometry(
            capture.subject, raster_width, raster_height, record, target=reusable[0],
        )
        floor = (
            _draw_geometry(capture.floor, raster_width, raster_height, record, target=reusable[1])
            if capture.floor.positions and capture.floor.triangles else None
        )
        geometry_surfaces = (subject, floor)
        _cache_put(
            _raster_cache, geometry_key, geometry_surfaces,
            subject.width * subject.height + (floor.width * floor.height if floor is not None else 0),
            _RASTER_PIXEL_BUDGET,
        )
    ownership_key = (*base_key, "ownership")
    ownership = _cache_get(_raster_cache, ownership_key)
    if ownership is None:
        ownership = _draw_ownership_geometry(capture.subject, raster_width, raster_height)
        _cache_put(_raster_cache, ownership_key, ownership,
                   ownership.width * ownership.height, _RASTER_PIXEL_BUDGET,
                   protected_keys=(geometry_key,))
    motion_key = (*base_key, "motion")
    motion = _cache_get(_raster_cache, motion_key)
    if motion is None:
        motion = _draw_motion_geometry(
            capture.subject, raster_width, raster_height,
        )
        _cache_put(
            _raster_cache, motion_key, motion,
            motion.width * motion.height, _RASTER_PIXEL_BUDGET,
            protected_keys=(geometry_key, ownership_key),
        )
    background_motion_key = (*base_key, "background_motion")
    background_motion_surface = _cache_get(
        _raster_cache, background_motion_key,
    )
    if background_motion_surface is None and (
        capture.floor.positions and capture.floor.triangles
    ):
        background_motion_surface = _draw_motion_geometry(
            capture.floor, raster_width, raster_height,
        )
        _cache_put(
            _raster_cache, background_motion_key, background_motion_surface,
            raster_width * raster_height, _RASTER_PIXEL_BUDGET,
            protected_keys=(geometry_key, ownership_key, motion_key),
        )
    return (*geometry_surfaces, ownership, motion, background_motion_surface)


def _impact_mode(record):
    return {"LINEAR": 0, "RADIAL": 1}.get(str(record.mode), 2)


def _enabled_line_modes(record):
    modes = []
    if bool(getattr(record, "radial_enabled", False)):
        modes.append(1)
    if bool(getattr(record, "linear_enabled", True)):
        modes.append(0)
    return tuple(modes) or (2,)


def _effect_mode(record):
    if bool(getattr(record, "linear_enabled", True)):
        return 0
    if bool(getattr(record, "radial_enabled", False)):
        return 1
    return 2


def _effect_focus(record):
    return tuple(record.direction_focus)


def _effect_polarity(record):
    """Keep optical direction stable when only depth ownership changes."""
    # Cast Behind is a compositor choice. Reversing one-sided post effects
    # here made the apparent stroke envelope change with the checkbox even
    # after the hero geometry itself was unchanged.
    return 1.0


def _direction_vector(record):
    """Resolve one camera-space direction for strokes and optical effects."""
    focus = getattr(record, "direction_focus", (0.75, 0.5))
    x = (float(focus[0]) - 0.5) * 2.0
    y = (float(focus[1]) - 0.5) * 2.0
    radius = math.hypot(x, y)
    if radius > 1.0:
        x, y = x / radius, y / radius
        radius = 1.0
    # Cast Behind is an occlusion choice, not a second stroke generator.
    # Keep the same hemisphere geometry and let the shader choose the depth
    # layer; otherwise toggling it changes silhouette width and stroke mass.
    z = math.sqrt(max(0.0, 1.0 - radius * radius))
    return x, y, z


def _flow_source(record, capture=None):
    """Encode the shared spatial 3D wind-source hemisphere."""
    focus = getattr(record, "direction_focus", (0.75, 0.5))
    # Direction is evaluated on deliberate drawing poses.  A 1/24-frame step
    # is fine enough to aim accurately but coarse enough that a one-pixel pin
    # drag cannot make the drawing twitch between unrelated up/down headings.
    # Hatch identity is derived from this same pose in the fragment shader,
    # so a step redraws the marks instead of rubber-rotating an old lattice.
    x = round(float(focus[0]) * 24.0) / 24.0
    y = round(float(focus[1]) * 24.0) / 24.0
    if capture is not None and bool(getattr(record, "radial_enabled", False)):
        left, bottom, right, top = _subject_bounds(capture)
        subject_center = (0.5 * (left + right), 0.5 * (bottom + top))
        # A snapped pin is a true frontal/rearward hemisphere pole even when
        # composition places the subject away from the frame center.
        if math.hypot(
            float(focus[0]) - subject_center[0],
            float(focus[1]) - subject_center[1],
        ) <= 0.012:
            x, y = subject_center
    sphere_x = (x - 0.5) * 2.0
    sphere_y = (y - 0.5) * 2.0
    raw_radius = math.hypot(sphere_x, sphere_y)
    if raw_radius > 1.0:
        sphere_x /= raw_radius
        sphere_y /= raw_radius
        x = sphere_x * 0.5 + 0.5
        y = sphere_y * 0.5 + 0.5
    radius = min(1.0, raw_radius)
    z = math.sqrt(max(0.0, 1.0 - radius * radius))
    # Match the CPU hemisphere reflection without mirroring the pin bearing.
    # flowSource is the subject/main-stroke 3D wind-source contract.  The
    # background 2D/3D choice has its own shader uniform and must never alter
    # this value, otherwise changing only the background mode also changes
    # subject stroke ownership, winding, hatching, and taper polarity.
    if bool(getattr(record, "direction_cast_behind", False)):
        return x, y, -z, 1.0
    return x, y, z, 1.0


def _background_plane_depth(capture, layer):
    """Map a world-depth plane into the ownership raster's shared depth range."""
    geometry=getattr(capture.subject,'_linear_collision_context',capture.subject)
    decode=getattr(_linearized_depth_geometry(geometry),'owner_depth_decode',None)
    layer=max(0.,min(1.,float(layer)))
    if layer<=0.:return 1.0
    if layer>=1.:return 0.0
    if not decode:return 1.-layer
    low,span,perspective,_=decode
    if perspective:
        near=-1./min(low,-1.e-15)
        far=-1./min(low+span,-1.e-15)
        coordinate=-1./max(far+(near-far)*layer,1.e-15)
    else:
        coordinate=low+span*(1.-layer)
    return .025+.95*(coordinate-low)/max(span,1.e-15)


def _subject_drawing_scale(capture, width, height):
    """Uncropped projected world extent; independent of transient raster size."""
    geometry=capture.subject
    cached=getattr(geometry,"_drawing_projected_extent",None)
    if cached is None:
        points=np.asarray(geometry.world_positions,dtype=float)
        matrix=np.asarray(geometry.view_projection,dtype=float)
        cached=1.
        if len(points) and matrix.shape==(4,4):
            lo=points.min(axis=0);hi=points.max(axis=0)
            depth=abs(float(matrix[3]@np.append((lo+hi)*.5,1.)))
            if depth>1.e-7:
                cached=float(np.linalg.norm(hi-lo)*.5*np.linalg.norm(matrix[1,:3])/depth)
        geometry._drawing_projected_extent=cached
    return max(.0001,float(cached)*height/max(1,min(width,height)))


def _subject_bounds(capture):
    """Tight projected subject bounds used only to distribute gesture seeds."""
    cached = getattr(capture, "_impaction_subject_bounds", None)
    if cached is not None:
        return cached
    positions = getattr(getattr(capture, "subject", None), "positions", ())
    visible = [
        value for value in positions
        if len(value) >= 2 and -0.25 <= float(value[0]) <= 1.25
        and -0.25 <= float(value[1]) <= 1.25
    ]
    if not visible:
        result = (0.0, 0.0, 1.0, 1.0)
        capture._impaction_subject_bounds = result
        return result
    pad = 0.025
    left = max(0.0, min(float(value[0]) for value in visible) - pad)
    bottom = max(0.0, min(float(value[1]) for value in visible) - pad)
    right = min(1.0, max(float(value[0]) for value in visible) + pad)
    top = min(1.0, max(float(value[1]) for value in visible) + pad)
    if right - left < 0.02 or top - bottom < 0.02:
        result = (0.0, 0.0, 1.0, 1.0)
    else:
        result = (left, bottom, right, top)
    capture._impaction_subject_bounds = result
    return result


def cached_subject_center(camera, record):
    """Return the captured subject's projected center without recapturing."""
    if camera is None or record is None:
        return None
    capture = _capture_cache_get(_capture_key(camera, record))
    if capture is None:
        capture = _load_persistent_capture(record)
    if capture is None:
        return None
    left, bottom, right, top = _subject_bounds(capture)
    return (0.5 * (left + right), 0.5 * (bottom + top))


def direction_control_rect(context, camera, record):
    """Resolution-aspect hemisphere shared by display, hit test and dragging."""
    return camera_view_rect(context, camera)


def background_render_focus(record, background_space):
    """Invert the 3D FOV center projection; never move the authored cyan pin."""
    point = tuple(getattr(record, "background_focus", (0.625, 0.5)))
    if background_space != "3D":
        return point
    spread = max(0.0, min(1.0, float(getattr(record, "background_depth", 0.0))))
    convergence = spread * spread * (3.0 - 2.0 * spread)
    scale = 1.0 + 6.0 * (1.0 - convergence)
    return tuple(0.5 + (float(value) - 0.5) / scale for value in point)


def direction_pin_position(record, point=None):
    """Keep the authored control fixed when switching casting hemispheres."""
    point = record.direction_focus if point is None else point
    return tuple(point)


def _resolved_direction_angle(record):
    flow = _flow_source(record)
    x = (float(flow[0]) - 0.5) * 2.0
    y = (float(flow[1]) - 0.5) * 2.0
    if math.hypot(x, y) <= 1.0e-6:
        # A centered pin is a depth-facing 3D wind view, not an undefined 2D
        # angle. Preserve the authored camera-basis direction requested for
        # the torso-back view so the projection cannot fall through to an old
        # unrelated manual angle stored on the record.
        return math.atan2(3.0, -5.0)
    return math.atan2(y, x)


def _frame_palette(record):
    """Return the stored endpoints; Flip now swaps the color-box values."""
    return tuple(record.foreground), tuple(record.background)


def _effective_light(record, foreground=None, background=None):
    """Return the selected light color and its visible drawing energy.

    Exact black is an absent light. Authored RGB value is preserved separately
    from the intensity control, including dark and near-black colors.
    """
    if foreground is None or background is None:
        foreground, background = _frame_palette(record)
    # Lighting now has one direct artist color. The legacy source enum remains
    # serialized only so older files can migrate without broken RNA paths.
    source = "CUSTOM"
    color = tuple(record.light_color)
    peak = max(float(color[0]), float(color[1]), float(color[2]))
    # RGB is authored pigment, not a normalized hue. Normalizing dark red
    # to (1,0,0) lost its value once whole hatch actions selected the light.
    # Intensity is an alternate RGB dimmer. Keep the drawing/key field at
    # its authored strength so lowering it cannot add darker/thicker hatches.
    dimmer = max(0.0, min(1.0, float(record.light_radius)))
    emitted = tuple(float(component) * dimmer for component in color[:3]) + (float(color[3]),)
    energy = 1.0 if peak * dimmer > 0.0 else 0.0
    return emitted, energy, source


def _valid_image(image):
    try:
        return bool(
            image is not None
            and len(image.size) >= 2
            and min(int(value) for value in image.size[:2]) >= 2
            and image.has_data
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return False


def _rounded_tuple(values, digits=6):
    return tuple(round(float(value), digits) for value in values)


_exposure_frame_override = None


def _held_motion_age(record, scene=None):
    if scene is None or float(getattr(record,'motion_curve_influence',0.))<=1.e-6:return 0
    return max(0,int(scene.frame_current if _exposure_frame_override is None else _exposure_frame_override)-int(record.frame))


def _glitch_time(record, scene=None):
    """One timeline clock across keyed images; independent of rig/record RNG.

    Held Impact drawings hold their effect phase too. Exporting out of order
    uses the same keyed phase without needing earlier renders or wall time.
    """
    if float(getattr(record, "aberration_glitch", 0.0)) <= .0001:
        return 0.0
    render = getattr(scene, "render", None)
    fps = float(getattr(render, "fps", 24)) / max(float(getattr(render, "fps_base", 1.0)), 1.e-6)
    return float(record.frame) / max(fps, 1.e-6)


def record_render_signature(record, scene=None):
    """Hash every input that changes cached output pixels.

    The signature is saved with the record, but the packed Image pixels are not
    part of Blender's RNA undo stack. Runtime undo handling therefore clears
    signatures and lazily rebuilds frames as they become visible.
    """
    from .impaction_multirig import canonical_visual_record
    record = canonical_visual_record(record)
    render = getattr(scene, "render", None)
    resolution = (
        int(getattr(render, "resolution_x", 0)),
        int(getattr(render, "resolution_y", 0)),
        round(float(getattr(render, "pixel_aspect_x", 1.0)), 6),
        round(float(getattr(render, "pixel_aspect_y", 1.0)), 6),
    )
    shape_payload = tuple(
        (str(shape.shape_type), str(shape.layer),
         int(getattr(shape, "variation", 1)),
         _rounded_tuple(shape.position, 7), round(float(shape.width), 6),
         round(float(shape.height), 6), round(float(shape.radius), 6),
         round(float(shape.rotation), 7),
         _rounded_tuple(getattr(shape, "perspective", (0.0, 0.0)), 7),
         round(float(shape.diagonal), 6),
         round(float(shape.end_width), 6), int(shape.burst_amount),
         round(float(shape.burst_thickness), 6),
         round(float(getattr(shape, "burst_end", 0.0)), 6),
         round(float(getattr(shape, "stroke", 0.0)), 6),
         _rounded_tuple(getattr(
             shape, "stroke_color", (1.0, 1.0, 1.0),
         )),
         round(float(shape.line_thickness), 6),
         round(float(getattr(shape, "effect_influence", 0.5)), 6),
         _rounded_tuple(shape.foreground),
         tuple((_rounded_tuple(point.position, 7),
                round(float(point.pressure), 5), bool(point.break_before))
               for point in shape.points))
        for shape in getattr(record, "shapes", ())
    )
    from .impaction_multirig import signature as rig_signature
    payload = (
        rig_signature(record, scene or bpy.context.scene),
        _RENDER_CACHE_VERSION,
        int(record.frame), int(record.salt), _held_motion_age(record,scene),
        round(_glitch_time(record, scene), 7),
        str(record.capture_subject), str(record.capture_floor),
        _trail_dependency_token(record),
        bool(getattr(record, "linear_enabled", True)),
        bool(getattr(record, "radial_enabled", False)), str(record.mode),
        _rounded_tuple(getattr(record, "direction_focus", (0.75, 0.5)), 7),
        bool(getattr(record, "direction_cast_behind", False)),
        int(getattr(record, "direction_seed_offset", 0)),
        round(float(getattr(record, "halo_spread", 0.5)), 6),
        round(float(getattr(record, "motion_curve_influence", 1.0)), 6),
        round(float(getattr(record, "background_intensity", 0.5)), 6),
        round(float(getattr(record, "background_layer", 0.5)), 6),
        bool(getattr(record, "_background_subject_only", False)),
        int(getattr(record, "_background_salt", record.salt)),
        str(getattr(record, "background_space", "2D")),
        bool(getattr(record, "background_2d_enabled", True)),
        bool(getattr(record, "background_3d_enabled", False)),
        _rounded_tuple(getattr(record, "background_focus", (0.625, 0.5)), 7),
        round(float(getattr(record, "background_depth", 0.0)), 6),
        round(float(getattr(record, "background_motion", 0.5)), 6),
        round(float(getattr(record, "background_depth_2d", 0.0)), 6),
        bool(getattr(record, "background_flip_depth_2d", False)),
        round(float(record.angle), 7), _rounded_tuple(record.focus, 7),
        round(float(record.strength), 6),
        round(float(record.line_thickness), 6),
        round(float(getattr(record, "radial_threshold", 0.5)), 6),
        round(float(getattr(record, "radial_spiral", 0.0)), 6),
        round(float(record.band_transition), 6),
        round(float(getattr(record, "motion_blur", 0.0)), 6),
        _rounded_tuple(record.foreground), _rounded_tuple(record.background),
        _rounded_tuple(getattr(record, "background_line_color", record.foreground)),
        bool(record.invert),
        _rounded_tuple(record.light_focus, 7),
        round(float(record.light_radius), 6),
        round(float(getattr(record, "bleed", 0.5)), 6),
        bool(getattr(record, "light_cast_behind", False)),
        str(record.light_color_source), _rounded_tuple(record.light_color),
        round(float(record.contrast), 6), round(float(record.grayscale), 6),
        round(float(record.bloom), 6), bool(getattr(record, "bloom_invert", False)),
        round(float(record.chromatic_aberration), 6),
        round(float(getattr(record,"aberration_glitch",0.0)),6),
        int(getattr(record,"glitch_size",10)),
        str(record.aberration_preset),
        bool(getattr(record, "aberration_blur_smoothing", True)),
        _rounded_tuple(record.aberration_color_a),
        _rounded_tuple(record.aberration_color_b),
        str(getattr(record, "aberration_ramp", "")),
        aberration_ramp_signature(record),
        round(float(record.grain), 6),
        round(float(record.grain_overlay_intensity), 6),
        shape_payload,
        round(float(record.halftone), 6), int(record.halftone_size),
        round(float(record.pixelate), 6), int(record.pixelate_size),
        resolution,
    )
    return hashlib.blake2b(
        repr(payload).encode("utf-8"), digest_size=16,
    ).hexdigest()


def _signature_scene_key(scene):
    render = getattr(scene, "render", None)
    return (
        int(getattr(render, "resolution_x", 0)),
        int(getattr(render, "resolution_y", 0)),
        round(float(getattr(render, "pixel_aspect_x", 1.0)), 6),
        round(float(getattr(render, "pixel_aspect_y", 1.0)), 6),
    )


def invalidate_record_signature(record):
    """Mark one record's expensive visual signature dirty without hiding it."""
    try:
        pointer = record.as_pointer()
    except (AttributeError, ReferenceError, RuntimeError):
        return
    revision = int(_signature_revisions.pop(pointer, 0)) + 1
    _signature_revisions[pointer] = revision
    _signature_cache.pop(pointer, None)
    while len(_signature_revisions) > _SIGNATURE_CACHE_BUDGET:
        stale_pointer, _revision = _signature_revisions.popitem(last=False)
        _signature_cache.pop(stale_pointer, None)


_trail_capture_revisions={}

def _trail_dependency_token(record):
    supplied=getattr(record,'_trail_dependency',None)
    if supplied is not None:return supplied
    camera=getattr(record,'id_data',None)
    if camera is None or not hasattr(camera,'impaction_frames'):return ()
    return tuple((int(r.frame),int(r.salt),str(r.capture_subject),
        _trail_capture_revisions.get((camera.name_full,int(r.salt)),0),
        tuple(r.direction_focus),bool(r.direction_cast_behind),float(r.halo_spread),
        float(r.motion_curve_influence),float(r.strength),float(r.line_thickness))
        for r in sorted(camera.impaction_frames,key=lambda r:r.frame) if r.frame<record.frame)


def _current_render_signature(record, scene=None):
    """Memoize the full signature between Blender property notifications."""
    try:
        pointer = record.as_pointer()
    except (AttributeError, ReferenceError, RuntimeError):
        return record_render_signature(record, scene)
    revision = int(_signature_revisions.get(pointer, 0))
    scene_key = _signature_scene_key(scene)
    identity = (
        int(getattr(record, "salt", 0)),
        int(getattr(record, "frame", 0)),
        _held_motion_age(record,scene),
        round(_glitch_time(record, scene), 7),
        _trail_dependency_token(record),
    )
    cached = _signature_cache.pop(pointer, None)
    if cached is not None and cached[:3] == (revision, scene_key, identity):
        _signature_cache[pointer] = cached
        return cached[3]
    signature = record_render_signature(record, scene)
    _signature_cache[pointer] = (revision, scene_key, identity, signature)
    while len(_signature_cache) > _SIGNATURE_CACHE_BUDGET:
        _signature_cache.popitem(last=False)
    return signature


def cache_matches_record(record, scene=None):
    return bool(
        cached_image(record) is not None
        and str(getattr(record, "cache_signature", ""))
        == _current_render_signature(record, scene)
    )


def preview_matches_record(camera, record, scene=None):
    key = (camera.name_full, int(record.salt)) if camera and record else None
    signature = _current_render_signature(record, scene) if key else None
    surface_entry = _preview_surfaces.get(key) if key else None
    if (surface_entry is not None
            and surface_entry[1] == signature):
        return True
    image_name = _preview_images.get(key) if key else None
    image = bpy.data.images.get(image_name) if image_name else None
    return bool(
        key is not None and _valid_image(image)
        and _preview_signatures.get(key) == signature
    )


def display_matches_record(camera, record, scene=None):
    """Check the visible transient first, hashing complex shape data once."""
    if camera is None or record is None:
        return False
    signature = _current_render_signature(record, scene)
    key = (camera.name_full, int(record.salt))
    if key in _undo_display_pending and (*key, signature) in _undo_display_history:
        return True
    surface_entry = _preview_surfaces.get(key)
    if surface_entry is not None and surface_entry[1] == signature:
        return True
    preview_name = _preview_images.get(key)
    preview = bpy.data.images.get(preview_name) if preview_name else None
    if _valid_image(preview) and _preview_signatures.get(key) == signature:
        return True
    return bool(
        cached_image(record) is not None
        and str(getattr(record, "cache_signature", "")) == signature
    )


def fresh_display_match_kind(camera, record, scene=None):
    """Return which displayed result already represents the current RNA state.

    Property update callbacks run before the normal signature revision is
    invalidated.  Computing the signature directly lets callers distinguish a
    real edit from Blender re-confirming an unchanged slider or enum value.
    """
    if camera is None or record is None:
        return None
    signature = record_render_signature(record, scene)
    key = (camera.name_full, int(record.salt))
    surface_entry = _preview_surfaces.get(key)
    if surface_entry is not None and surface_entry[1] == signature:
        return "surface"
    preview_name = _preview_images.get(key)
    preview = bpy.data.images.get(preview_name) if preview_name else None
    if _valid_image(preview) and _preview_signatures.get(key) == signature:
        return "preview"
    if (cached_image(record) is not None
            and str(getattr(record, "cache_signature", "")) == signature):
        return "cache"
    return None


def _internalize_image(image, *, pack=False):
    """Keep generated pixels owned by the .blend rather than an external path."""
    if not _valid_image(image):
        return False
    try:
        image.filepath_raw = ""
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        pass
    image.use_fake_user = True
    if pack:
        try:
            packed = getattr(image, "packed_file", None) is not None
            dirty = bool(getattr(image, "is_dirty", True))
            if not packed or dirty:
                image.pack()
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            return False
    return True


def promote_record_preview(camera, record, scene=None, *, pack=True):
    """Apply the exact displayed transient, optionally deferring disk packing."""
    if camera is None or record is None:
        return None
    key = (camera.name_full, int(record.salt))
    signature = _current_render_signature(record, scene)
    surface_entry = _preview_surfaces.get(key)
    if surface_entry is not None and surface_entry[1] == signature:
        surface, _entry_signature, width, height, name = surface_entry
        image = bpy.data.images.get(name)
        if image is not None and not image.is_float:
            bpy.data.images.remove(image)
            image = None
        if image is None:
            image = bpy.data.images.new(
                name, width=width, height=height,
                alpha=True, float_buffer=True,
            )
        try:
            image.colorspace_settings.name = "Non-Color"
        except TypeError:
            pass
        _write_offscreen_to_image(surface, image, width, height)
        _mark_display_upload(image.name_full)
    else:
        name = _preview_images.get(key)
        image = bpy.data.images.get(name) if name else None
        if not _valid_image(image) or _preview_signatures.get(key) != signature:
            return None
    old_name = str(record.cache_image)
    if not _internalize_image(image, pack=pack):
        return None
    record.cache_image = image.name
    record.cache_valid = True
    record.cache_signature = signature
    record["_render_cache_version"] = _RENDER_CACHE_VERSION
    if old_name and old_name != image.name:
        stale = bpy.data.images.get(old_name)
        if stale is not None:
            stale.use_fake_user = False
        schedule_preview_cleanup()
    _full_quality_previews.pop(key, None)
    surface_entry = _preview_surfaces.pop(key, None)
    if surface_entry is not None:
        _free_surface(surface_entry[0])
    _preview_images.pop(key, None)
    _preview_signatures.pop(key, None)
    _remember_completed_display(camera, record, image, scene)
    return image


def pack_record_images():
    """Pack active caches and remove abandoned dirty preview datablocks."""
    try:
        objects = tuple(bpy.data.objects)
    except (AttributeError, ReferenceError, RuntimeError):
        return 0
    objects_by_name = {obj.name_full: obj for obj in objects}
    scene = getattr(bpy.context, "scene", None)
    for (camera_name, salt), _surface_entry in tuple(_preview_surfaces.items()):
        camera = objects_by_name.get(camera_name)
        record = next(
            (item for item in getattr(camera, "impaction_frames", ())
             if int(item.salt) == int(salt)),
            None,
        ) if camera is not None else None
        if record is not None:
            promote_record_preview(camera, record, scene)
    try:
        images = tuple(bpy.data.images)
    except (AttributeError, ReferenceError, RuntimeError):
        return 0
    referenced = {
        str(record.cache_image)
        for owner in objects
        for record in getattr(owner, "impaction_frames", ())
        if record.cache_image
    }
    referenced.update(_preview_images.values())
    packed = 0
    for image in images:
        if not image.name.startswith(CACHE_PREFIX):
            continue
        real_users = max(0, int(image.users) - int(bool(image.use_fake_user)))
        if image.name not in referenced and real_users == 0:
            # Preview generations from an older extension session are not
            # project assets. Removing them prevents one abandoned dirty image
            # from continuing to trigger Blender's save-images dialog.
            image.use_fake_user = False
            bpy.data.images.remove(image)
            continue
        if _internalize_image(image, pack=True):
            packed += 1
    return packed


def invalidate_display_uploads():
    """Forget managed GPU upload timestamps after undo/context restoration."""
    _display_upload_seen.clear()


def _mask_signature(record, capture):
    _light_color, light_energy, _light_source = _effective_light(record)
    signature = (
        tuple(getattr(capture, "_background_bounds", ())),
        int(getattr(capture,"motion_age",0)),
        bool(getattr(record, "linear_enabled", True)),
        bool(getattr(record, "radial_enabled", False)), record.mode,
        _rounded_tuple(getattr(record, "direction_focus", (0.75, 0.5)), 6),
        bool(getattr(record, "direction_cast_behind", False)),
        int(getattr(record, "direction_seed_offset", 0)),
        round(float(getattr(record, "halo_spread", 0.5)), 6),
        round(float(getattr(record, "motion_curve_influence", 1.0)), 6),
        round(float(getattr(record, "background_intensity", 0.5)), 6),
        round(float(getattr(record, "background_layer", 0.5)), 6),
        bool(getattr(record, "_background_subject_only", False)),
        int(getattr(record, "_background_salt", record.salt)),
        str(getattr(record, "background_space", "2D")),
        bool(getattr(record, "background_2d_enabled", True)),
        bool(getattr(record, "background_3d_enabled", False)),
        _rounded_tuple(getattr(record, "background_focus", (0.625, 0.5)), 6),
        round(float(getattr(record, "background_depth", 0.0)), 6),
        round(float(getattr(record, "background_motion", 0.5)), 6),
        round(float(getattr(record, "background_depth_2d", 0.0)), 6),
        bool(getattr(record, "background_flip_depth_2d", False)),
        round(float(record.angle), 6),
        round(float(record.focus[0]), 6), round(float(record.focus[1]), 6),
        round(float(record.strength), 6), round(float(record.line_thickness), 6),
        round(float(getattr(record, "radial_threshold", 0.5)), 6),
        round(float(getattr(record, "radial_spiral", 0.0)), 6),
        round(float(record.band_transition), 6),
        round(float(record.light_focus[0]), 6), round(float(record.light_focus[1]), 6),
        bool(getattr(record, "light_cast_behind", False)),
        round(float(light_energy), 6),
        int(record.salt), round(float(capture.velocity_scale), 7),
        round(float(capture.subject_motion[0]), 7),
        round(float(capture.subject_motion[1]), 7),
        round(float(capture.background_motion[0]), 7),
        round(float(capture.background_motion[1]), 7),
        round(float(capture.subject_acceleration[0]), 7),
        round(float(capture.subject_acceleration[1]), 7),
    )

    if int(getattr(record, "_optical_family", -1)) in (0, 1):
        # Background controls cannot affect a subject/linear or radial-only
        # pass. Cyan-pin movement must not invalidate their expensive masks.
        signature = tuple(None if index in (10, 11, 14, 17, 18, 19, 20, 21)
                          else value for index, value in enumerate(signature))
    return (*signature, bool(getattr(record, "_draft_linear", False)))


def _frame_seed(record):
    """Return a deterministic frame coordinate, not unrelated frame noise.

    Grain/scatter still hash this value in their own material shaders. The
    impact shader receives a small scaled coordinate, so neighboring frames
    retain the same hand and gesture families while their local pressure and
    endpoints drift over time instead of being completely re-rolled.
    """
    return float((int(record.frame) & 0x00FFFFFF) + 1)


def _impact_style_salt(record):
    """Deterministically redraw main-stroke topology when controls change.

    Direction and spread retain their existing redraw identity. Strength and
    thickness only scale the current drawing: reseeding them introduces a
    discontinuity in the intensity ramp and unnecessarily redraws hatching.
    """
    frame_seed = int(_frame_seed(record))
    # At the sphere's equator front and back are the same direction. The
    # depth toggle must never reroll the brush/material realization.
    direction_x = int(getattr(record, "direction_x", 0))
    direction_y = int(getattr(record, "direction_y", 0))
    spread_step = int(round(float(getattr(record, "halo_spread", 0.5)) * 100.0))
    spatial_hash = (
        direction_x * 73856093 ^ direction_y * 19349663 ^
        spread_step * 83492791
    ) & 0x0000FFFF
    spatial_hash = (spatial_hash + int(getattr(record, "direction_seed_offset", 0))) & 0xFFFF
    return ((frame_seed + spatial_hash) % 100000) * 0.001


def _background_identity_salt(camera, record):
    """Stable family identity; camera motion advects lines without rerolling."""
    identity = f"{camera.name_full}:{int(getattr(record, '_background_salt', record.salt))}".encode("utf-8")
    value = int.from_bytes(
        hashlib.blake2b(identity, digest_size=4).digest(), "little",
    )
    return (value & 0x00FFFFFF) * (1000.0 / float(0x00FFFFFF))


def _background_affine_field(capture):
    """Fit v(p)=c+A(p-.5) to captured environment screen motion.

    The constant term carries a pan.  The 2x2 derivative retains camera roll,
    orbit and dolly expansion across otherwise empty paper, where sampling the
    environment motion texture directly has no geometry coverage.
    """
    cached = getattr(capture, "_impaction_background_affine", None)
    if cached is not None:
        return cached
    geometry = (
        capture.floor if len(capture.floor.positions) >= 3 else capture.subject
    )
    samples = [
        (position, velocity)
        for position, velocity in zip(geometry.positions, geometry.velocities)
        if (-0.25 <= float(position[0]) <= 1.25
            and -0.25 <= float(position[1]) <= 1.25)
    ]
    fallback = tuple(float(value) for value in capture.background_motion)
    if len(samples) < 3:
        result = ((fallback[0], 0.0, 0.0, 0.0),
                  (fallback[1], 0.0, 0.0, 0.0))
        capture._impaction_background_affine = result
        return result
    design = np.asarray([
        (1.0, float(position[0]) - 0.5, float(position[1]) - 0.5)
        for position, _velocity in samples
    ], dtype=np.float64)
    values = np.asarray([
        (float(velocity[0]), float(velocity[1]))
        for _position, velocity in samples
    ], dtype=np.float64)
    coefficients, _residuals, rank, _singular = np.linalg.lstsq(
        design, values, rcond=None,
    )
    if rank < 3 or not np.isfinite(coefficients).all():
        result = ((fallback[0], 0.0, 0.0, 0.0),
                  (fallback[1], 0.0, 0.0, 0.0))
        capture._impaction_background_affine = result
        return result
    prediction = design @ coefficients
    # When subject geometry is the fallback proxy, discard the articulated
    # minority (for example a punching arm) and refit the coherent camera
    # field. Camera motion affects the low-residual majority; action does not.
    if geometry is capture.subject and len(samples) >= 8:
        errors = np.linalg.norm(values - prediction, axis=1)
        cutoff = float(np.quantile(errors, 0.70))
        retained = errors <= max(cutoff, 1.0e-8)
        if int(np.count_nonzero(retained)) >= 3:
            refined, _residuals, refined_rank, _singular = np.linalg.lstsq(
                design[retained], values[retained], rcond=None,
            )
            if refined_rank >= 3 and np.isfinite(refined).all():
                coefficients = refined
                prediction = design @ coefficients
    residual = float(np.sqrt(np.mean(np.square(values - prediction))))
    scale = max(float(capture.velocity_scale), 1.0e-6)
    confidence = max(0.0, min(1.0, 1.0 - residual / (scale * 1.5)))
    result = (
        (float(coefficients[0, 0]), float(coefficients[1, 0]),
         float(coefficients[2, 0]), confidence),
        (float(coefficients[0, 1]), float(coefficients[1, 1]),
         float(coefficients[2, 1]), confidence),
    )
    capture._impaction_background_affine = result
    return result


def _resolve_full_quality_mask(target, width, height, batch):
    """Resolve generated pigment once before entering the full mask cache."""
    resolved = _offscreen(width, height, high_precision=True)
    resolve_shader = _shader(
        "mask_resolve", "fullscreen.vert", "mask_resolve.frag",
    )
    with resolved.bind():
        framebuffer = gpu.state.active_framebuffer_get()
        framebuffer.clear(color=(0.0, 0.0, 0.0, 1.0), depth=1.0)
        resolve_shader.uniform_sampler("impactTex", target.texture_color)
        resolve_shader.uniform_float(
            "resolution", (float(width), float(height)),
        )
        gpu.state.blend_set("NONE")
        batch.draw(resolve_shader)
    _free_surface(target)
    return resolved


def _linear_path_key(record, capture, interactive=False):
    key = (
        int(getattr(capture,"motion_age",0)),
        tuple(record.direction_focus), bool(record.direction_cast_behind),
        float(record.halo_spread), _impact_style_salt(record),
        float(getattr(record, "motion_curve_influence", 1.0)),
        tuple(capture.background_motion), tuple(capture.background_acceleration),
        float(capture.velocity_scale), float(record.strength), float(record.line_thickness),
        False,  # Coverage/visibility decisions must match Apply at every raster tier.
    )

    # Light/BG/effect edits can reuse existing full geometry even while their
    # GPU optics use a temporary tier. Never build a preview subset needlessly.
    full_key = key[:-1] + (False,)
    if interactive and full_key in getattr(capture.subject, "_linear_surface_paths", {}):
        return full_key
    return key


def _preview_record_snapshot(record, *, frame_record=True):
    """Detached visual values; never hold a mutable RNA value across chunks."""
    if isinstance(record, SimpleNamespace):
        # Snapshot values are immutable tuples/scalars. Only nested shape
        # snapshots need independent attribute dictionaries; deepcopy also
        # duplicated bound custom-property dictionaries at every optics leaf.
        values = vars(record).copy()
        if "shapes" in values:
            values["shapes"] = tuple(_preview_record_snapshot(shape, frame_record=False)
                                    for shape in values["shapes"])
        return SimpleNamespace(**values)
    values = {}
    for prop in record.bl_rna.properties:
        name = prop.identifier
        if name == "rna_type":
            continue
        value = getattr(record, name)
        if prop.type == "COLLECTION":
            value = tuple(_preview_record_snapshot(item, frame_record=False) for item in value)
        elif getattr(prop, "is_array", False):
            value = tuple(value)
        values[name] = value
    custom = dict(record.items())
    values["get"] = custom.get
    if frame_record:
        values["_trail_dependency"] = _trail_dependency_token(record)
    return SimpleNamespace(**values)


def _optical_family_record(record, family):
    local = _preview_record_snapshot(record)
    local._optical_family = family
    local._optical_hybrid = bool(record.linear_enabled and record.radial_enabled)
    local._optical_radial_enabled = bool(record.radial_enabled)
    local.linear_enabled = bool(record.linear_enabled) if family == 0 else False
    local.radial_enabled = family == 1
    local.background_2d_enabled = family == 2
    local.background_3d_enabled = family == 3
    if family != 0:
        local.shapes = ()
        local._draft_linear = False
    return local


def _linear_geometry(geometry, interactive=False):
    """One canonical physical path/visibility solution at every raster tier."""
    return geometry


def direction_preview_record(context, camera, record):
    """Return a transient current-pose snapshot only when every rig is ready."""
    from . import impaction_multirig as multi
    from .impaction_preview_geometry import source_ribbons, prepare_transport
    capture = _record_capture(context, camera, record)
    snapshot = _preview_record_snapshot(record)
    plans = multi.plans(context, camera, snapshot, capture) or [(0., snapshot, capture)]
    width, height = _render_size(context)
    changed = []
    for _depth, local, sliced in plans:
        if not local.linear_enabled:
            continue
        key = _linear_path_key(local, sliced)
        source = source_ribbons(sliced.subject, key, width, height)
        if source is None:
            return None
        if source[0][0] != key:
            if len(source[1][1]) and prepare_transport(sliced.subject, key, width, height) is None:
                return None
            changed.append(int(local.salt))
    if not changed:
        return None
    snapshot._draft_linear = True
    snapshot._draft_linear_salts = tuple(changed)
    return snapshot


def begin_linear_preview(context, camera, record, recapture=False, interactive=False, *, _capture_override=None, _rig_layer=False):
    """Prepare an immutable in-flight drawing; later input is a next request."""
    from .impaction_envelope import iter_group_paths
    from . import impaction_multirig as multi
    if not _rig_layer and hasattr(record, 'as_pointer') and (len(multi.rigs(context.scene))>1 or record.get('_rig_profiles','')):
        multi.ensure(record,camera,context.scene)
    capture = _capture_override if _capture_override is not None else _record_capture(context, camera, record, recapture=recapture)
    snapshot = _preview_record_snapshot(record)
    if not _rig_layer and record.get('_rig_profiles',''):
        jobs=[begin_linear_preview(context,camera,local,interactive=interactive,
                _capture_override=sliced,_rig_layer=True)
              for _depth,local,sliced in multi.plans(context,camera,record,capture)
              if local.linear_enabled]
        return dict(record=snapshot,signature=record_render_signature(snapshot,context.scene),
                    jobs=jobs,done=False,max_slice=0.0,interactive=interactive)
    key = _linear_path_key(snapshot, capture, interactive)
    geometry = _linear_geometry(capture.subject, interactive)
    cache = getattr(geometry, "_linear_surface_paths", None)
    if cache is None:
        cache = geometry._linear_surface_paths = OrderedDict()
    paper_width, paper_height = _render_size(context)
    iterator = iter_group_paths(
        geometry, snapshot.direction_focus, snapshot.direction_cast_behind,
        paper_width/max(paper_height, 1), snapshot.halo_spread,
        _impact_style_salt(snapshot), motion_influence=snapshot.motion_curve_influence,
        background_motion=capture.background_motion,
        background_acceleration=capture.background_acceleration,
        velocity_scale=capture.velocity_scale, strength=snapshot.strength,
        thickness=snapshot.line_thickness, preview=float(key[-1]),
    )
    return dict(record=snapshot, signature=record_render_signature(snapshot, context.scene),
                geometry=geometry, key=key, iterator=iterator, strokes=list(cache.get(key, ())),
                interactive=interactive,
                path_done=key in cache, done=False, max_slice=0.0,
                paper_size=(paper_width,paper_height), thickness=float(record.line_thickness))


def advance_linear_preview(job, budget=0.008):
    """Bound path and ribbon preparation, including per-lane visibility."""
    import time
    from .impaction_streamlines import iter_conforming_ribbons
    if job["done"]:return True
    start=time.perf_counter()
    if 'jobs' in job:
        while job['jobs']:
            remaining=max(.001,budget-(time.perf_counter()-start))
            if not advance_linear_preview(job['jobs'][0],remaining):break
            job['jobs'].pop(0)
            if time.perf_counter()-start>=budget:break
        job['done']=not job['jobs']
        elapsed=time.perf_counter()-start
        job['work_seconds']=job.get('work_seconds',0.)+elapsed
        job['max_slice']=max(job['max_slice'],elapsed)
        return job['done']
    while True:
        if not job["path_done"]:
            try:
                stroke=next(job["iterator"])
                if stroke is not None:job["strokes"].append(stroke)
            except StopIteration:
                cache=job["geometry"]._linear_surface_paths
                cache[job["key"]]=job["strokes"]
                while len(cache)>2:cache.popitem(last=False)
                job["path_done"]=True
        else:
            geometry=job["geometry"]
            cache=getattr(geometry,"_linear_ribbon_cache",None)
            if cache is None:cache=geometry._linear_ribbon_cache=OrderedDict()
            width,height=job["paper_size"]
            key=(job["key"],int(width),int(height))
            if key in cache:
                job["done"]=True
                break
            iterator=job.get("ribbon_iterator")
            if iterator is None:
                iterator=job["ribbon_iterator"]=iter_conforming_ribbons(
                    job["strokes"],geometry.view_projection,width,height,
                    job["thickness"],sampling_quality=float(job["key"][-1]) or 1.)
            try:next(iterator)
            except StopIteration as result:
                cache[key]=result.value
                while len(cache)>2:cache.popitem(last=False)
                job["done"]=True
                break
        if time.perf_counter()-start>=budget:break
    elapsed=time.perf_counter()-start
    job["work_seconds"]=job.get("work_seconds",0.)+elapsed
    job["max_slice"]=max(job["max_slice"],elapsed)
    return job["done"]


def _linear_stroke_surface(camera, record, capture, width, height, paper_width, paper_height, interactive=False):
    """Draw existing brush coverage along world paths, with independent depth."""
    from .impaction_streamlines import build_group_paths, conforming_ribbons
    geometry = _linear_geometry(capture.subject, interactive)
    if not geometry.positions or len(geometry.world_positions) != len(geometry.positions) or not geometry.view_projection:
        return None
    base_key = (*_capture_key(camera, record), getattr(capture, "_rig_cache", "all"), int(width), int(height))
    influence = float(getattr(record, "motion_curve_influence", 1.0))
    path_key = _linear_path_key(record, capture, interactive)
    band_amount=0.0 if bool(record.radial_enabled) else float(record.band_transition)
    draft = bool(getattr(record, "_draft_linear", False))
    key = (*base_key, path_key, float(record.line_thickness), int(paper_width), int(paper_height),band_amount,draft)
    cached = _cache_get(_linear_stroke_cache, key)
    if cached is not None:
        return cached
    depth_geometry = getattr(geometry, '_linear_collision_context', geometry)
    if not hasattr(depth_geometry,"_shared_depth_token"):
        depth_geometry._shared_depth_token = time.monotonic_ns()
    depth_key = (camera.name_full, int(record.frame), depth_geometry._shared_depth_token, int(width), int(height))
    scene_depth = _cache_get(_linear_depth_cache, depth_key)
    if scene_depth is None:
        matrix = np.asarray(depth_geometry.view_projection, dtype=np.float64)
        world = np.asarray(depth_geometry.world_positions, dtype=np.float64)
        clips = np.column_stack((world, np.ones(len(world)))) @ matrix.T
        axis = matrix[2, :3] / np.linalg.norm(matrix[2, :3])
        depths = world @ axis
        surface_owners=np.zeros(len(world),dtype=np.float32)
        labelled=min(len(world),len(depth_geometry.owner_ids))
        surface_owners[:labelled]=np.asarray(depth_geometry.owner_ids[:labelled],dtype=np.float32)+1.
        shader = _shader("linear_depth", "linear_depth.vert", "linear_depth.frag")
        depth_batch = batch_for_shader(shader, "TRIS", {
            "clipPosition": np.ascontiguousarray(clips,dtype=np.float32),
            "linearDepth": np.ascontiguousarray(depths,dtype=np.float32),
            "surfaceOwner": surface_owners,
        }, indices=depth_geometry.triangles)
        scene_depth = gpu.types.GPUOffScreen(width, height, format="RGBA32F")
        try:
            with scene_depth.bind():
                gpu.state.active_framebuffer_get().clear(color=(0, 0, 0, 0), depth=1)
                gpu.state.depth_test_set("LESS_EQUAL")
                gpu.state.depth_mask_set(True)
                gpu.state.blend_set("NONE")
                shader.uniform_float("depthRange", (float(depths.min())-.01, float(depths.max())+.01))
                depth_batch.draw(shader)
        except Exception:
            _free_surface(scene_depth)
            raise
        finally:
            gpu.state.depth_test_set("NONE")
        _cache_put(_linear_depth_cache, depth_key, scene_depth, width*height, 8_000_000)
    ribbon_data = None
    if draft:
        from .impaction_preview_geometry import transport_state
        draft_state = transport_state(geometry, path_key, paper_width, paper_height)
        if draft_state is None:
            raise RuntimeError("Interactive ribbon source expired; exact geometry is required")
        ribbon_data = draft_state[0]["gpu_data"]
        ribbon_key = (draft_state[0]["token"], "gpu-direction-preview")
    else:
        path_cache = getattr(geometry, "_linear_surface_paths", None)
        if path_cache is None:
            path_cache = geometry._linear_surface_paths = OrderedDict()
        strokes = path_cache.get(path_key)
        if strokes is None:
            strokes = build_group_paths(
                geometry, record.direction_focus, record.direction_cast_behind,
                paper_width / max(paper_height, 1), record.halo_spread,
                _impact_style_salt(record), motion_influence=influence,
                background_motion=capture.background_motion,
                background_acceleration=capture.background_acceleration,
                velocity_scale=capture.velocity_scale, strength=float(record.strength), thickness=float(record.line_thickness),
                preview=float(path_key[-1]),
            )
            path_cache[path_key] = strokes
            while len(path_cache) > 2:
                path_cache.popitem(last=False)
        # Brush coordinates use authored output pixels at every tier.
        # Sampling precision belongs to path_key; release builds full detail.
        ribbon_cache=getattr(geometry,"_linear_ribbon_cache",None)
        if ribbon_cache is None:
            ribbon_cache=geometry._linear_ribbon_cache=OrderedDict()
        ribbon_key=(path_key,int(paper_width),int(paper_height))
        ribbon_data=ribbon_cache.get(ribbon_key)
        if ribbon_data is None:
            ribbon_data=conforming_ribbons(
                strokes, geometry.view_projection, paper_width, paper_height,
                float(record.line_thickness), sampling_quality=float(path_key[-1]) or 1.,
            )
            ribbon_cache[ribbon_key]=ribbon_data
            while len(ribbon_cache)>2:ribbon_cache.popitem(last=False)
    arrays, triangles=ribbon_data
    surface = _offscreen(width, height, high_precision=True)
    try:
        with surface.bind():
            gpu.state.active_framebuffer_get().clear(color=(0, 0, 0, 0), depth=1)
            gpu.state.depth_test_set("LESS_EQUAL")
            gpu.state.depth_mask_set(True)
            gpu.state.blend_set("NONE")
            if len(triangles):
                shader = _shader("linear_preview" if draft else "linear_surface",
                                 "linear_preview.vert" if draft else "linear_surface.vert", "linear_surface.frag")
                if draft:
                    from mathutils import Matrix
                    shader.uniform_float("previewMatrix", Matrix(geometry.view_projection))
                    shader.uniform_float("previewAxis", tuple(draft_state[1]))
                    shader.uniform_float("previewAngle", draft_state[2])
                    shader.uniform_float("previewDepthAxis", tuple(draft_state[0]["axis"]))
                # Material sliders and raster quality do not change mesh data.
                # Reuse its device buffers across those edits and full apply.
                batch_key=(*_capture_key(camera,record),id(geometry),ribbon_key)
                stroke_batch=_cache_get(_linear_batch_cache,batch_key)
                if stroke_batch is None:
                    stroke_batch=batch_for_shader(shader,"TRIS",arrays,indices=triangles)
                    weight=sum(np.asarray(v).nbytes for v in arrays.values())+np.asarray(triangles).nbytes
                    _cache_put(_linear_batch_cache,batch_key,stroke_batch,weight,64*1024*1024)
                    while len(_linear_batch_cache)>4:
                        _drop_cache_key(_linear_batch_cache,next(iter(_linear_batch_cache)))
                shader.uniform_sampler("ownershipTex", scene_depth.texture_color)
                shader.uniform_sampler("brushTex", _brush_atlas())
                shader.uniform_sampler("loadedBrushTex", _loaded_brush_atlas())
                shader.uniform_float("strokeStrength", float(record.strength))
                shader.uniform_float("strokeBandAmount",band_amount)
                stroke_batch.draw(shader)
    except Exception:
        _free_surface(surface)
        raise
    finally:
        gpu.state.depth_test_set("NONE")
        gpu.state.depth_mask_set(True)
        gpu.state.blend_set("NONE")
    # One latest pin result per record; effects reuse it without geometry work.
    for old_key in tuple(_linear_stroke_cache):
        if old_key[:2] == key[:2]:
            _drop_cache_key(_linear_stroke_cache, old_key)
    _cache_put(_linear_stroke_cache, key, surface, width*height, 8_000_000)
    return surface


def _impact_mask(
    camera, record, capture, subject, floor, ownership, motion,
    background_motion_surface,
    width, height, batch,
    paper_width, paper_height, preview_quality=1.0, interactive_geometry=False,
):
    key = (
        *_capture_key(camera, record), int(width), int(height),
        int(paper_width), int(paper_height), round(float(preview_quality), 4),
        _mask_signature(record, capture),
        float(interactive_geometry), int(getattr(record, "_optical_family", -1)),
        bool(getattr(record,"_optical_hybrid",False)), bool(getattr(record,"_optical_radial_enabled",False)),
    )
    owner_key = (camera.name_full, int(record.salt), int(getattr(record, "_optical_family", -1)),
                 getattr(capture, "_rig_cache", "all"))
    reusable_target = None
    if float(preview_quality) < 0.999:
        previous_key = _interactive_mask_keys.get(owner_key)
        if previous_key is not None and previous_key != key:
            previous_item = _mask_cache.pop(previous_key, None)
            if previous_item is not None:
                # A line-affecting drag changes the mask signature every event,
                # but not its dimensions. Re-render into the same GPU target so
                # a long gesture neither grows the cache nor repeatedly blocks
                # on GPU allocation/free. The target is retired once, when the
                # full-quality release render replaces the interactive image.
                previous_target = previous_item[0]
                if (int(previous_target.width) == int(width)
                        and int(previous_target.height) == int(height)):
                    reusable_target = previous_target
                    _cache_diagnostics["interactive_replacements"] += 1
                else:
                    # Adaptive quality can change dimensions mid-gesture. A
                    # differently sized mask is not reusable: binding it while
                    # uploading the new resolution produced scaled/soft line
                    # fields and mislabeled the old allocation under a new key.
                    _free_surface(previous_target)
                    _cache_diagnostics["interactive_resize_discards"] += 1
        _interactive_mask_keys[owner_key] = key
    else:
        previous_key = _interactive_mask_keys.pop(owner_key, None)
        if previous_key is not None and previous_key != key:
            _drop_cache_key(_mask_cache, previous_key, reason="interactive")
    cached = _cache_get(_mask_cache, key)
    if cached is not None:
        return cached
    shader = _shader("impact", "fullscreen.vert", "impact.frag")
    modes = _enabled_line_modes(record)
    linear_surface = _linear_stroke_surface(
        camera, record, capture, width, height, paper_width, paper_height, interactive_geometry,
    ) if 0 in modes and float(record.strength) > .0001 and float(record.line_thickness) > .0001 else None
    hybrid_mode = bool(getattr(record,"_optical_hybrid",len(modes) > 1))
    flow_source = _flow_source(record, capture)
    subject_bounds = _subject_bounds(capture)
    affine_x, affine_y = _background_affine_field(capture)
    resolved_angle = _resolved_direction_angle(record)
    effect_focus = _effect_focus(record)
    style_salt = _impact_style_salt(record)
    background_salt = _background_identity_salt(camera, record)
    _light_color, light_energy, _light_source = _effective_light(record)
    owner_bounds_texture, owner_count, owns_owner_bounds_texture, owner_surface = (
        _cached_owner_geometry(camera, record, capture, width, height)
    )

    try:
        def draw_mode(
            mode, *, layer_only=0, background_space=None,
            target_override=None,
        ):
            radial_key = None
            if mode == 1 and layer_only == 1 and target_override is None:
                # Hybrid and its isolated Radial optics leaf draw the same raw
                # radial ink. Reuse BEFORE coverage resolve, preserving pigment.
                # Linear-ready cannot affect this pass (mode 1 band bypass).
                signature = list(_mask_signature(record, capture))
                for index in (2, 3, 15, 16): signature[index] = None
                if not hasattr(capture.subject, "_radial_mask_token"):
                    capture.subject._radial_mask_token = time.monotonic_ns()
                radial_key = (*_capture_key(camera, record), width, height,
                    paper_width, paper_height, capture.subject._radial_mask_token,
                    (tuple(signature), hybrid_mode,
                     bool(getattr(record, "_optical_radial_enabled", 1 in modes)),
                     tuple(flow_source), tuple(effect_focus), resolved_angle,
                     style_salt, background_salt, tuple(subject_bounds),
                     tuple(affine_x), tuple(affine_y)))
                cached_radial = _cache_get(_radial_mask_cache, radial_key)
                if cached_radial is not None:
                    return _BorrowedSurface(cached_radial)
            if layer_only in (2, 3) and target_override is None:
                # The parent and isolated optics leaf draw identical raw BG
                # coverage. Reuse it before either coverage-resolve operation.
                signature = list(_mask_signature(record, capture))
                for index in (2, 3, 15, 16): signature[index] = None
                if not hasattr(capture.subject, "_radial_mask_token"):
                    capture.subject._radial_mask_token = time.monotonic_ns()
                radial_key = (*_capture_key(camera, record), width, height,
                    paper_width, paper_height, capture.subject._radial_mask_token,
                    ("background", layer_only, tuple(signature), hybrid_mode,
                     bool(getattr(record, "_optical_radial_enabled", 1 in modes)),
                     tuple(flow_source), tuple(effect_focus), resolved_angle,
                     style_salt, background_salt, tuple(subject_bounds),
                     tuple(affine_x), tuple(affine_y)))
                cached_background = _cache_get(_radial_mask_cache, radial_key)
                if cached_background is not None:
                    return _BorrowedSurface(cached_background)
            target = target_override or _offscreen(
                width, height, high_precision=True,
            )
            # Creating an offscreen while another framebuffer is bound can
            # disturb that first draw's GPU state. Allocate staging before bind.
            families = (_background_family_target()
                        if background_space is not None and float(record.background_intensity) > .00005
                        else None)
            radial_seeds = _radial_seed_target() if mode == 1 else None
            with target.bind():
                framebuffer = gpu.state.active_framebuffer_get()
                framebuffer.clear(color=(0.0, 0.0, 0.0, 1.0), depth=1.0)
                shader.uniform_sampler(
                    "subjectTex", subject.texture_color if subject is not None
                    else _empty_texture(),
                )
                shader.uniform_sampler(
                    "floorTex", floor.texture_color if floor is not None
                    else _empty_texture(),
                )
                shader.uniform_sampler("brushTex", _brush_atlas())
                shader.uniform_sampler("loadedBrushTex", _loaded_brush_atlas())
                shader.uniform_sampler("linearStrokeTex", linear_surface.texture_color
                                       if linear_surface is not None else _empty_texture())
                shader.uniform_float("linearReady", 1.0 if linear_surface is not None else 0.0)
                shader.uniform_sampler(
                    "motionTex", motion.texture_color if motion is not None
                    else _empty_texture(),
                )
                shader.uniform_sampler(
                    "backgroundMotionTex",
                    background_motion_surface.texture_color
                    if background_motion_surface is not None
                    else _empty_texture(),
                )
                shader.uniform_sampler(
                    "ownershipTex", ownership.texture_color
                    if ownership is not None else _empty_texture(),
                )
                shader.uniform_sampler("ownerBoundsTex", owner_bounds_texture)
                shader.uniform_sampler("ownerSurfaceTex", owner_surface.texture_color
                                       if owner_surface is not None else _empty_texture())
                shader.uniform_int("ownerCount", owner_count)
                shader.uniform_float(
                    "resolution", (float(paper_width), float(paper_height)),
                )
                shader.uniform_int("mode", mode)
                shader.uniform_int("layerOnly", int(layer_only))
                shader.uniform_int(
                    "hybridMode",
                    # Background-only passes also need radial ownership so the
                    # emitter can erase background strokes in Hybrid without a
                    # solid-color plate.
                    1 if hybrid_mode else 0,
                )
                shader.uniform_int("radialEnabled", 1 if getattr(record,"_optical_radial_enabled",1 in modes) else 0)
                shader.uniform_float("angle", resolved_angle)
                shader.uniform_float("flowSource", flow_source)
                shader.uniform_float(
                    "haloSpread", float(getattr(record, "halo_spread", 0.5)),
                )
                shader.uniform_float("subjectBounds", subject_bounds)
                shader.uniform_float("backgroundPlaneDepth", _background_plane_depth(capture,record.background_layer))
                shader.uniform_float("subjectDrawingScale", _subject_drawing_scale(capture, paper_width, paper_height))
                shader.uniform_float("backgroundBounds", getattr(capture, "_background_bounds", subject_bounds))
                shader.uniform_float("focus", effect_focus)
                # Two complete high-density modes otherwise collide into a black
                # wall. Hybrid may reduce family count, but Linear remains the
                # foreground owner and keeps the artist's authored stroke width.
                linear_hybrid = hybrid_mode and mode == 0
                radial_hybrid = hybrid_mode and mode == 1
                # Linear owns the authored subject gesture in Hybrid. Scaling it
                # to 28% shortened its trails whenever Radial was also enabled.
                strength_scale = 1.0
                thickness_scale = 1.0
                background_scale = 0.46 if linear_hybrid else (0.58 if radial_hybrid else 1.0)
                if background_space is not None:
                    background_scale = 1.0
                authored_strength = max(0.0, min(1.0, float(record.strength)))
                # Preserve ordinary values while making the authored maximum a
                # genuinely extreme impact instead of another mild increment.
                impact_strength = authored_strength * (
                    1.0 + 0.85 * authored_strength ** 5
                )
                shader.uniform_float("strength", impact_strength * strength_scale)
                shader.uniform_float(
                    "lineThickness",
                    record.line_thickness * thickness_scale,
                )
                # Motion Blur is a post effect and is intentionally absent from
                # the canonical impact-mask shader contract.
                shader.uniform_float("subjectMotion", tuple(capture.subject_motion))
                shader.uniform_float(
                    "backgroundMotion", tuple(capture.background_motion),
                )
                shader.uniform_float("backgroundAffineX", affine_x)
                shader.uniform_float("backgroundAffineY", affine_y)
                shader.uniform_float(
                    "subjectAcceleration", tuple(capture.subject_acceleration),
                )
                shader.uniform_float(
                    "backgroundAcceleration",
                    tuple(capture.background_acceleration),
                )
                shader.uniform_float("salt", style_salt)
                shader.uniform_float("backgroundSalt", background_salt)
                shader.uniform_float("backgroundFrame", _frame_seed(record))
                shader.uniform_float("velocityScale", capture.velocity_scale)
                shader.uniform_float(
                    "motionCurveInfluence",
                    float(getattr(record, "motion_curve_influence", 1.0)),
                )
                shader.uniform_float(
                    "backgroundIntensity",
                    (
                        float(getattr(record, "background_intensity", 0.5)) *
                        background_scale
                        if background_space in {"2D", "3D"}
                        else 0.0
                    ),
                )
                shader.uniform_float("backgroundLayer", float(getattr(record, "background_layer", 0.5)))
                shader.uniform_int("backgroundSubjectOnly", int(getattr(record, "_background_subject_only", False)))
                background_space_3d = background_space == "3D"
                shader.uniform_int(
                    "backgroundSpace3D",
                    2 if background_space_3d else (
                        -1 if bool(getattr(
                            record, "background_flip_depth_2d", False,
                        )) else 0
                    ),
                )
                shader.uniform_float(
                    "backgroundFocus",
                    background_render_focus(record, background_space),
                )
                shader.uniform_float(
                    "backgroundDepthInfluence",
                    float(getattr(
                        record,
                        "background_depth" if background_space_3d
                        else "background_depth_2d",
                        0.0,
                    )),
                )
                shader.uniform_float(
                    "backgroundMotionInfluence",
                    float(getattr(record, "background_motion", 0.5)),
                )
                shader.uniform_float("bandTransition", record.band_transition)
                shader.uniform_float(
                    "radialThreshold",
                    float(getattr(record, "radial_threshold", 0.5)),
                )
                shader.uniform_float(
                    "radialSpiral",
                    float(getattr(record, "radial_spiral", 0.0)),
                )
                shader.uniform_float("contrast", 0.0)
                shader.uniform_float("lightIntensity", light_energy)
                shader.uniform_sampler("backgroundFamilyTex", _empty_texture())
                shader.uniform_sampler("radialSeedTex", _empty_texture())
                gpu.state.blend_set("NONE")
                if radial_seeds is not None:
                    with radial_seeds.bind():
                        shader.uniform_int("layerOnly", 5)
                        batch.draw(shader)
                    shader.uniform_int("layerOnly", int(layer_only))
                    shader.uniform_sampler("radialSeedTex", radial_seeds.texture_color)
                if families is not None:
                    with families.bind():
                        shader.uniform_int("layerOnly", 4)
                        batch.draw(shader)
                    shader.uniform_int("layerOnly", int(layer_only))
                    shader.uniform_sampler("backgroundFamilyTex", families.texture_color)
                batch.draw(shader)
            if radial_key is not None:
                _cache_put(_radial_mask_cache, radial_key, target,
                           width * height, 8_500_000)
                return _BorrowedSurface(target)
            return target

        def composite_layers(rear_target, front_target, target_override=None):
            composite_target = target_override or _offscreen(
                width, height, high_precision=True,
            )
            layer_shader = _shader(
                "impact_layers", "fullscreen.vert", "impact_layers.frag",
            )
            with composite_target.bind():
                framebuffer = gpu.state.active_framebuffer_get()
                framebuffer.clear(color=(0.0, 0.0, 0.0, 1.0), depth=1.0)
                layer_shader.uniform_sampler(
                    "subjectTex", rear_target.texture_color,
                )
                layer_shader.uniform_sampler(
                    "floorTex", front_target.texture_color,
                )
                gpu.state.blend_set("NONE")
                batch.draw(layer_shader)
            return composite_target

        background_2d = bool(getattr(record, "background_2d_enabled", True))
        background_3d = bool(getattr(record, "background_3d_enabled", False))
        background_passes = int(background_3d) + int(background_2d)

        optical_family = int(getattr(record, "_optical_family", -1))
        if optical_family in (1, 2, 3):
            target = draw_mode(1 if optical_family == 1 else 0,
                layer_only=optical_family,
                background_space="3D" if optical_family == 3 else "2D" if optical_family == 2 else None)
            background_2d = background_3d = False
        elif len(modes) == 1:
            target = draw_mode(
                modes[0],
                target_override=(reusable_target if not background_passes else None),
            )
        else:
            radial_target = draw_mode(1, layer_only=1)
            linear_target = draw_mode(0)
            target = composite_layers(
                radial_target, linear_target,
                reusable_target if not background_passes else None,
            )
            radial_target.free()
            linear_target.free()

        remaining_backgrounds = background_passes
        if background_3d:
            remaining_backgrounds -= 1
            rear_background = draw_mode(
                0, layer_only=3, background_space="3D",
            )
            combined = composite_layers(
                rear_background, target,
                reusable_target if remaining_backgrounds == 0 else None,
            )
            rear_background.free()
            target.free()
            target = combined
        if background_2d:
            remaining_backgrounds -= 1
            front_background = draw_mode(
                0, layer_only=2, background_space="2D",
            )
            combined = composite_layers(
                target, front_background,
                reusable_target if remaining_backgrounds == 0 else None,
            )
            target.free()
            front_background.free()
            target = combined
        # Coverage resolve is part of the drawing, not a final-only effect.
        # Raster dimensions may change during input, but the pigment rule may not.
        target = _resolve_full_quality_mask(target, width, height, batch)
        _cache_put(_mask_cache, key, target, width * height, _MASK_PIXEL_BUDGET)
        return target
    finally:
        if owns_owner_bounds_texture and owner_surface is not None:
            _free_surface(owner_surface)
        if owns_owner_bounds_texture:
            _free_surface(owner_bounds_texture)


def _render_size(context, max_dimension=None):
    scene = context.scene
    # Impact frames are camera-output assets, so completed caches and exported
    # PNGs always use the literal Output Properties X/Y dimensions. The render
    # percentage is a temporary render-performance scale and must not silently
    # reduce a keyed post-effect asset.
    width = max(16, int(scene.render.resolution_x))
    height = max(16, int(scene.render.resolution_y))
    if max_dimension:
        preview_scale = float(max_dimension) / max(width, height)
        width = max(16, int(width * preview_scale))
        height = max(16, int(height * preview_scale))
    return width, height


def _preview_dimension(
    context, camera, *, interactive=False, interactive_scale=None,
):
    # Preview geometry must not change when a sidebar, tooltip, or property
    # editor resizes the viewport. Use one deterministic reconstruction size
    # derived solely from output settings; live and applied preview therefore
    # evaluate exactly the same procedural stroke field.
    scene = context.scene
    output_long_edge = max(
        16, int(scene.render.resolution_x), int(scene.render.resolution_y),
    )
    # Applied previews are project pixels and must match the configured output
    # dimensions.  The old 1536 cap was then enlarged by the viewport, making
    # thin strokes visibly stair-step and exposing dotted reconstruction
    # artifacts.  Only an active interactive gesture may lower this value.
    dimension = output_long_edge
    if interactive:
        state = getattr(context.scene, "impaction", None)
        quality = 1.0
        if interactive_scale is not None:
            quality = min(quality, float(interactive_scale))
        dimension = max(96, int(round(dimension * max(0.20, quality))))
    return dimension


def interactive_preview_is_full_quality(scene):
    state = getattr(scene, "impaction", None)
    configured = float(getattr(state, "preview_quality", 0.0)) if state else 0.0
    return bool(
        state is None
        or configured <= 0.0
        or configured >= 99.999
    )


def synchronize_preview(camera, record):
    """Sparse one-pixel fence for adaptive timing, never a full image readback."""
    entry = _preview_surfaces.get((camera.name_full, int(record.salt)))
    if entry is not None:
        with entry[0].bind():
            gpu.state.active_framebuffer_get().read_color(0, 0, 1, 1, 4, 0, 'FLOAT')


def _image_name(camera, record):
    return f"{CACHE_PREFIX}{camera.name_full} - {record.frame} - {record.salt}"


def _write_offscreen_to_image(offscreen, image, width, height):
    key = (int(width), int(height))
    pixels = _readback_buffers.pop(key, None)
    if pixels is None:
        pixels = gpu.types.Buffer("FLOAT", width * height * 4)
    with offscreen.bind():
        framebuffer = gpu.state.active_framebuffer_get()
        framebuffer.read_color(
            0, 0, width, height, 4, 0, "FLOAT", data=pixels,
        )
    pixels.dimensions = width * height * 4
    if tuple(image.size) != (width, height):
        image.scale(width, height)
    image.pixels.foreach_set(pixels)
    image.update()
    # Retain the common interactive buffers, but never pin a 4K/8K float
    # readback (128 MiB/512 MiB) after its one required Image upload.
    weight = int(width) * int(height) * 4 * 4
    if weight <= _READBACK_BYTE_BUDGET:
        _readback_buffers[key] = pixels
        total = sum(
            int(size[0]) * int(size[1]) * 4 * 4
            for size in _readback_buffers
        )
        while (_readback_buffers and (
                len(_readback_buffers) > _READBACK_BUFFER_BUDGET
                or total > _READBACK_BYTE_BUDGET)):
            old_size, _old_buffer = _readback_buffers.popitem(last=False)
            total -= int(old_size[0]) * int(old_size[1]) * 4 * 4


def _mark_display_upload(image_key, timestamp=None):
    """Bound upload bookkeeping even when an image has not been drawn yet."""
    image_key = str(image_key)
    _display_upload_seen.pop(image_key, None)
    _display_upload_seen[image_key] = (
        time.monotonic() if timestamp is None else float(timestamp)
    )
    while len(_display_upload_seen) > _DISPLAY_UPLOAD_BUDGET:
        _display_upload_seen.popitem(last=False)


def _grain_distance_field(impact, shapes, width, height):
    """Quarter-resolution JFA: bounded GPU work, no image readback."""
    w,h=max(1,(width+3)//4),max(1,(height+3)//4)
    surfaces=[]
    try:
        surfaces=[_offscreen(w,h,high_precision=True)]
        surfaces.append(_offscreen(w,h,high_precision=True))
        shader=_shader("grain_distance","fullscreen.vert","grain_distance.frag")
        shader.uniform_sampler("impactTex",impact)
        shader.uniform_sampler("shapeMaskTex",shapes)
        shader.uniform_float("sourceResolution",(float(width),float(height)))
        steps=[0]
        step=1 << max(0,(max(w,h)-1).bit_length()-1)
        while step:
            steps.append(step);step//=2
        steps.append(1)  # JFA+1 refinement limits seed-cell errors.
        previous=shapes
        for index,step in enumerate(steps):
            current=surfaces[index%2]
            with current.bind():
                gpu.state.blend_set("NONE");gpu.state.depth_test_set("NONE")
                shader.uniform_sampler("seedTex",previous)
                shader.uniform_int("jump",step)
                _fullscreen_quad(shader).draw(shader)
            previous=current.texture_color
        unused=surfaces[1-(len(steps)-1)%2]
        unused.free()
        return current
    except Exception:
        for surface in surfaces:_free_surface(surface)
        raise


def _configure_grain_shader(
    shader, record, width, height, paper_width=None, paper_height=None,
):
    shader.uniform_float(
        "paperResolution",
        (float(paper_width or width), float(paper_height or height)),
    )
    shader.uniform_float(
        "dustAmount", max(0.0, min(1.0, record.grain)) * 100.0,
    )
    shader.uniform_float(
        "filmAmount",
        max(0.0, min(1.0, record.grain_overlay_intensity)) * 100.0,
    )
    shader.uniform_float("salt", _frame_seed(record))


def _optical_guide_surface(impact, width, height):
    """Extend each visible drawing group through its neighboring paper gaps."""
    buffers = [gpu.types.GPUOffScreen(width,height,format="RGBA32F") for _ in range(2)]
    shader = _shader("optical_guide", "fullscreen.vert", "optical_guide.frag")
    for buffer in buffers: _enable_nearest_filter(buffer.texture_color)
    jumps=[0];step=1 << max(0,(max(width,height)-1).bit_length()-1)
    while step: jumps.append(step);step//=2
    jumps.append(1)
    try:
        previous=impact
        for index, step in enumerate(jumps):
            current=buffers[index%2]
            with current.bind():
                shader.uniform_sampler("impactTex",impact)
                shader.uniform_sampler("seedTex",previous)
                shader.uniform_float("resolution",(width,height))
                shader.uniform_int("jump",step)
                gpu.state.blend_set("NONE")
                _fullscreen_quad(shader).draw(shader)
            previous=current.texture_color
        buffers[1-(len(jumps)-1)%2].free()
        return current
    except Exception:
        for buffer in buffers: buffer.free()
        raise


class _EffectFields:
    def __init__(self, direction, owners):
        self.direction, self.owners = direction, owners
        self.texture_color = direction.texture_color
        self.ownership_texture = owners.texture_color

    def bind(self):
        return self.direction.bind()

    def free(self):
        self.direction.free()
        self.owners.free()


def _effect_direction_surface(record, capture, rig_plans, ownership, width, height, camera=None, impact=None, interactive_geometry=False):
    """Project the same world-space dome wind used by Linear stroke paths."""
    from .impaction_linear import dome_direction
    plans = rig_plans or [(0.0, record, capture)]
    field_key = (camera.name_full if camera else "", int(record.salt), id(capture.subject),
        width,height,float(interactive_geometry),_mask_signature(record,capture),int(getattr(record,"_optical_family",-1)),
        tuple((tuple(local.direction_focus),bool(local.direction_cast_behind),id(sliced.subject))
              for _depth,local,sliced in plans))
    cached = _cache_get(_effect_field_cache,field_key)
    if cached is not None: return cached
    matrix = np.asarray(capture.subject.view_projection, dtype=np.float64)
    if matrix.shape != (4,4):
        camera = camera or bpy.context.scene.camera
        matrix = np.asarray(camera.calc_matrix_camera(bpy.context.evaluated_depsgraph_get(),
            x=width,y=height) @ camera.matrix_world.inverted(),dtype=np.float64)
    inverse = np.linalg.inv(matrix)
    inverse_w = inverse[3]
    depth_decode = getattr(_linearized_depth_geometry(capture.subject),
                           "owner_depth_decode", (0., 0., 0., 0.))
    parameters = []
    owner_indices = {0: 0}
    for index, (_depth, local, sliced) in enumerate(plans):
        points = np.asarray(sliced.subject.world_positions, dtype=np.float64)
        if not len(points) or len(points) != len(sliced.subject.positions):
            # Old captures and shape-only frames still have a valid camera.
            # Reconstruct a support plane rather than failing or using NaNs.
            screen = np.asarray(sliced.subject.positions or ((.25,.25,0.),(.75,.75,0.)),dtype=np.float64)
            clip = np.column_stack((screen[:,:2]*2.-1.,screen[:,2],np.ones(len(screen))))
            world = clip @ inverse.T
            points = world[:,:3] / np.where(abs(world[:,3:4])>1e-8,world[:,3:4],1e-8)
        bounds = _subject_bounds(sliced)
        center = ((bounds[0]+bounds[2])*.5, (bounds[1]+bounds[3])*.5)
        wind = np.asarray(dome_direction(_effect_focus(local), center, width/height,
            bool(local.direction_cast_behind), matrix))
        reach = max(.001, float(np.linalg.norm(np.ptp(points,axis=0))) * .75)
        clip_points = np.column_stack((points, np.ones(len(points)))) @ matrix.T
        reference_w = max(.001, float(np.median(np.abs(clip_points[:,3]))))
        delta = matrix @ np.append(wind * reach, 0.)
        # One world-space shutter interval for the entire rig. Keep every
        # visible mesh point in front of the camera for either spectral sign;
        # do not independently compress screen X/Y or normalize pixel speed.
        positive_w = clip_points[:, 3][clip_points[:, 3] > 1.e-6]
        if len(positive_w) and abs(delta[3]) > 1.e-8:
            delta *= min(1., .65 * float(positive_w.min()) / abs(delta[3]))
        parameters.extend(((delta[0]/reference_w, delta[1]/reference_w,
                            delta[3]/reference_w, reference_w), bounds,
                           (*tuple(local.direction_focus), -1.0 if local.direction_cast_behind else 1.0, 0.0)))
        for owner in set(sliced.subject.owner_ids):
            owner_indices[int(owner)] = index + 1
    owner_table = tuple((float(owner_indices.get(i, 0)), 0.0, 0.0, 0.0)
                        for i in range(max(owner_indices) + 1))
    # Released ribbons already carry world-depth in their pigment texture.
    # Reuse it: assigning them the rig's median plane flattens their optics.
    linear_surface = None
    if len(plans) == 1 and record.linear_enabled and int(getattr(record, '_optical_family', -1)) <= 0:
        paper_width, paper_height = _render_size(bpy.context)
        linear_surface = _linear_stroke_surface(camera, record, capture, width, height,
                                                paper_width, paper_height, interactive_geometry)
    depth_axis = matrix[2, :3] / max(float(np.linalg.norm(matrix[2, :3])), 1.e-12)
    depth_to_w = (float(matrix[3, :3] @ depth_axis), float(matrix[3, 3]),
                  float(linear_surface is not None), 0.)
    shader = _shader("effect_direction", "fullscreen.vert", "effect_direction.frag")
    target = _offscreen(width, height, high_precision=True)
    owner_target = _offscreen(width, height, high_precision=True)
    _enable_nearest_filter(owner_target.texture_color)
    guide = (_optical_guide_surface(impact,width,height)
        if impact is not None and int(getattr(record,"_optical_family",-1)) < 0 else None)
    try:
        for mode, output in enumerate((target,owner_target)):
            with output.bind():
                shader.uniform_sampler("ownershipTex", ownership.texture_color)
                shader.uniform_sampler("impactTex", impact if impact is not None else _empty_texture())
                shader.uniform_sampler("guideTex", guide.texture_color if guide is not None else _empty_texture())
                shader.uniform_sampler("linearStrokeTex", linear_surface.texture_color if linear_surface is not None else _empty_texture())
                shader.uniform_sampler("rigTex", _gradient_texture(parameters))
                shader.uniform_sampler("ownerRigTex", _gradient_texture(owner_table))
                shader.uniform_int("rigCount", len(plans))
                shader.uniform_int("familyOverride", int(getattr(record,"_optical_family",-1)))
                shader.uniform_int("outputMode", mode)
                shader.uniform_float("resolution", (float(width), float(height)))
                shader.uniform_float("inverseProjectionW", tuple(inverse_w))
                shader.uniform_float("ownerDepthDecode", depth_decode)
                shader.uniform_float("linearDepthToW", depth_to_w)
                gpu.state.blend_set("NONE")
                _fullscreen_quad(shader).draw(shader)
        if guide is not None: guide.free()
        fields = _EffectFields(target,owner_target)
        _cache_put(_effect_field_cache,field_key,fields,width*height*2,32_000_000)
        return fields
    except Exception:
        target.free()
        owner_target.free()
        if guide is not None: guide.free()
        raise


def _capture_key(camera, record):
    return camera.name_full, int(record.salt), int(record.frame)


def _capture_byte_weight(capture):
    """Conservative CPython-object estimate for duplicated capture payloads."""
    total = 0
    for geometry in (capture.subject, capture.floor):
        vertices = len(geometry.positions)
        # Numeric Python lists/tuples are much larger
        # than their packed numeric payload. Include tuple/list references and
        # allocator overhead so the 128 MiB policy means roughly 128 MiB.
        # World coordinates and the shared-range owner positions are retained
        # with this capture; include both in the existing memory budget.
        total += vertices * 2032  # Includes four evaluated motion-offset arrays.
        total += len(geometry.triangles) * 160
        total += int(getattr(getattr(geometry,"corner_normals",None),"nbytes",0))
    return max(1, total)


def _capture_cache_get(key):
    item = _capture_cache.pop(key, None)
    if item is None:
        return None
    _capture_cache[key] = item
    return item[0]


def _capture_cache_remove(key):
    global _capture_cache_bytes
    item = _capture_cache.pop(key, None)
    if item is not None:
        _capture_cache_bytes = max(0, _capture_cache_bytes - int(item[1]))
    return item


def _capture_cache_put(key, capture):
    global _capture_cache_bytes
    _capture_cache_remove(key)
    weight = _capture_byte_weight(capture)
    _capture_cache[key] = (capture, weight)
    _capture_cache_bytes += weight
    while _capture_cache_bytes > _CAPTURE_BYTE_BUDGET and len(_capture_cache) > 1:
        _old_key, (_old_capture, weight) = _capture_cache.popitem(last=False)
        _capture_cache_bytes -= int(weight)
    return capture


def capture_cache_stats():
    """Expose bounded session ownership for diagnostics and soak tests."""
    return {
        "entries": len(_capture_cache),
        "estimated_bytes": int(_capture_cache_bytes),
        "budget_bytes": _CAPTURE_BYTE_BUDGET,
    }


def _capture_mesh_name(camera, record, role):
    return f".Impaction Capture - {camera.name_full} - {record.frame} - {record.salt} - {role}"


def _remove_capture_mesh(name):
    mesh = bpy.data.meshes.get(name) if name else None
    if mesh is not None:
        mesh.use_fake_user = False
        if mesh.users == 0:
            bpy.data.meshes.remove(mesh)


def _write_capture_mesh(
        name, geometry, velocity_scale, role_motion, role_acceleration,
        temporal):
    _remove_capture_mesh(name)
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(geometry.positions, (), geometry.triangles)
    normals = mesh.attributes.new("impaction_normal", type="FLOAT_VECTOR", domain="POINT")
    velocities = mesh.attributes.new("impaction_velocity", type="FLOAT_VECTOR", domain="POINT")
    accelerations = mesh.attributes.new(
        "impaction_acceleration", type="FLOAT_VECTOR", domain="POINT",
    )
    owners = mesh.attributes.new(
        "impaction_owner_id", type="FLOAT", domain="POINT",
    )
    spread_groups = mesh.attributes.new(
        "impaction_spread_group_id", type="FLOAT", domain="POINT",
    )
    spread_weights = mesh.attributes.new(
        "impaction_spread_group_weight", type="FLOAT", domain="POINT",
    )
    world_positions = mesh.attributes.new(
        "impaction_world_position", type="FLOAT_VECTOR", domain="POINT",
    )
    if geometry.world_positions:
        world_positions.data.foreach_set(
            "vector", array("f", (c for p in geometry.world_positions for c in p)),
        )
    for field_name in ("world_velocities", "world_accelerations", "world_before",
                       "world_before_mid", "world_after_mid", "world_after"):
        attribute = mesh.attributes.new("impaction_"+field_name,type="FLOAT_VECTOR",domain="POINT")
        values = getattr(geometry, field_name, ())
        if values:
            attribute.data.foreach_set("vector",array("f",(c for p in values for c in p)))
    if geometry.view_projection:
        mesh["impaction_view_projection"] = [c for row in geometry.view_projection for c in row]
    mesh["impaction_motion_history"] = json.dumps(getattr(geometry,"motion_history",{}))
    if geometry.positions:
        normals.data.foreach_set(
            "vector", array("f", (component for value in geometry.normals for component in value)),
        )
        velocities.data.foreach_set(
            "vector", array(
                "f", (
                    component
                    for value in geometry.velocities
                    for component in (value[0], value[1], 0.0)
                )
            ),
        )
        accelerations.data.foreach_set(
            "vector", array(
                "f", (
                    component
                    for value in geometry.accelerations
                    for component in (value[0], value[1], 0.0)
                )
            ),
        )
        owners.data.foreach_set("value", array("f", geometry.owner_ids))
        spread_groups.data.foreach_set(
            "value", array("f", geometry.spread_group_ids),
        )
        spread_weights.data.foreach_set(
            "value", array("f", geometry.spread_group_weights),
        )
    corner_normals=getattr(geometry,"corner_normals",())
    if len(corner_normals)==len(mesh.loops) and len(corner_normals):
        attr=mesh.attributes.new("impaction_corner_normal",type="FLOAT_VECTOR",domain="CORNER")
        attr.data.foreach_set("vector",np.asarray(corner_normals,dtype=np.float32).ravel())
    mesh["impaction_velocity_scale"] = float(velocity_scale)
    mesh["impaction_motion_x"] = float(role_motion[0])
    mesh["impaction_motion_y"] = float(role_motion[1])
    mesh["impaction_acceleration_x"] = float(role_acceleration[0])
    mesh["impaction_acceleration_y"] = float(role_acceleration[1])
    mesh["impaction_temporal_capture"] = bool(temporal)
    mesh["impaction_capture_schema"] = _CAPTURE_SCHEMA_VERSION
    mesh.update()
    mesh.use_fake_user = True
    return mesh


def _read_capture_mesh(name):
    mesh = bpy.data.meshes.get(name) if name else None
    if mesh is None or mesh.get("impaction_capture_schema",0)!=_CAPTURE_SCHEMA_VERSION:
        return None, None, (0.0, 0.0), (0.0, 0.0), False
    normal_attribute = mesh.attributes.get("impaction_normal")
    world_attribute = mesh.attributes.get("impaction_world_position")
    projection_values = mesh.get("impaction_view_projection")
    velocity_attribute = mesh.attributes.get("impaction_velocity")
    acceleration_attribute = mesh.attributes.get("impaction_acceleration")
    world_velocity_attribute = mesh.attributes.get("impaction_world_velocities")
    world_acceleration_attribute = mesh.attributes.get("impaction_world_accelerations")
    owner_attribute = mesh.attributes.get("impaction_owner_id")
    spread_group_attribute = mesh.attributes.get("impaction_spread_group_id")
    spread_weight_attribute = mesh.attributes.get(
        "impaction_spread_group_weight",
    )
    # Captures written before local acceleration existed can still claim to be
    # temporal. Treat them as stale instead of silently rendering a zero arc;
    # _record_capture will rebuild frame-1/current/frame+1 on first use.
    if (normal_attribute is None or velocity_attribute is None
            or world_velocity_attribute is None or world_acceleration_attribute is None
            or (mesh.get('impaction_temporal_capture',False) and any(
                mesh.attributes.get('impaction_'+name) is None for name in
                ('world_before','world_before_mid','world_after_mid','world_after')))
            or (len(mesh.vertices) and (world_attribute is None or projection_values is None))
            or acceleration_attribute is None or owner_attribute is None
            or spread_group_attribute is None
            or spread_weight_attribute is None):
        return None, None, (0.0, 0.0), (0.0, 0.0), False
    count = len(mesh.vertices)
    coordinates = array("f", [0.0]) * (count * 3)
    world_coordinates = array("f", [0.0]) * (count * 3)
    normals = array("f", [0.0]) * (count * 3)
    velocities = array("f", [0.0]) * (count * 3)
    accelerations = array("f", [0.0]) * (count * 3)
    owner_ids = array("f", [0.0]) * count
    spread_group_ids = array("f", [0.0]) * count
    spread_group_weights = array("f", [0.0]) * count
    if count:
        mesh.vertices.foreach_get("co", coordinates)
        world_attribute.data.foreach_get("vector", world_coordinates)
        normal_attribute.data.foreach_get("vector", normals)
        velocity_attribute.data.foreach_get("vector", velocities)
        if acceleration_attribute is not None:
            acceleration_attribute.data.foreach_get("vector", accelerations)
        owner_attribute.data.foreach_get("value", owner_ids)
        spread_group_attribute.data.foreach_get("value", spread_group_ids)
        spread_weight_attribute.data.foreach_get(
            "value", spread_group_weights,
        )
    geometry = CaptureGeometry(
        [tuple(coordinates[index:index + 3]) for index in range(0, len(coordinates), 3)],
        [tuple(normals[index:index + 3]) for index in range(0, len(normals), 3)],
        [tuple(velocities[index:index + 2]) for index in range(0, len(velocities), 3)],
        [tuple(accelerations[index:index + 2]) for index in range(0, len(accelerations), 3)],
        list(owner_ids),
        [tuple(polygon.vertices) for polygon in mesh.polygons],
        list(spread_group_ids),
        list(spread_group_weights),
        [tuple(world_coordinates[i:i+3]) for i in range(0, len(world_coordinates), 3)],
        tuple(tuple(projection_values[i:i+4]) for i in range(0, 16, 4)) if projection_values else (),
    )
    for field_name, attribute in (("world_velocities",world_velocity_attribute),
                                  ("world_accelerations",world_acceleration_attribute)):
        values=array("f",[0.])* (count*3)
        if count: attribute.data.foreach_get("vector",values)
        setattr(geometry,field_name,[tuple(values[i:i+3]) for i in range(0,len(values),3)])
    for field_name in ('world_before','world_before_mid','world_after_mid','world_after'):
        attribute=mesh.attributes.get('impaction_'+field_name)
        if attribute is not None:
            values=array('f',[0.])*(count*3)
            if count:attribute.data.foreach_get('vector',values)
            setattr(geometry,field_name,[tuple(values[i:i+3]) for i in range(0,len(values),3)])
    corners=mesh.attributes.get("impaction_corner_normal")
    if corners is not None and len(corners.data)==len(geometry.triangles)*3:
        values=np.empty((len(corners.data),3),dtype=np.float32)
        corners.data.foreach_get("vector",values.ravel())
        geometry.corner_normals=values
    geometry.motion_history=json.loads(mesh.get("impaction_motion_history","{}"))
    return (
        geometry,
        float(mesh.get("impaction_velocity_scale", 1.0)),
        (
            float(mesh.get("impaction_motion_x", 0.0)),
            float(mesh.get("impaction_motion_y", 0.0)),
        ),
        (
            float(mesh.get("impaction_acceleration_x", 0.0)),
            float(mesh.get("impaction_acceleration_y", 0.0)),
        ),
        bool(mesh.get("impaction_temporal_capture", False)),
    )


def _persistent_capture_available(record):
    return bool(
        record
        and record.capture_subject and bpy.data.meshes.get(record.capture_subject)
        and record.capture_floor and bpy.data.meshes.get(record.capture_floor)
    )


def _load_persistent_capture(record):
    if not _persistent_capture_available(record):
        return None
    subject_data = _read_capture_mesh(record.capture_subject)
    floor_data = _read_capture_mesh(record.capture_floor)
    subject, subject_scale, subject_motion, subject_acceleration, subject_temporal = subject_data
    floor, floor_scale, background_motion, background_acceleration, floor_temporal = floor_data
    if subject is None or floor is None:
        return None
    return ImpactCapture(
        subject, floor, max(subject_scale, floor_scale),
        subject_motion=subject_motion,
        background_motion=background_motion,
        subject_acceleration=subject_acceleration,
        background_acceleration=background_acceleration,
        temporal=bool(subject_temporal and floor_temporal),
    )


def _store_persistent_capture(camera, record, capture):
    # Capture identities are undo data; never replace meshes under the same name.
    import time
    revision = str(time.time_ns())
    subject_name = _capture_mesh_name(camera, record, "Subject") + " - " + revision
    floor_name = _capture_mesh_name(camera, record, "Floor") + " - " + revision
    old_names = (str(record.capture_subject), str(record.capture_floor))
    subject = _write_capture_mesh(
        subject_name, capture.subject, capture.velocity_scale,
        capture.subject_motion, capture.subject_acceleration, capture.temporal,
    )
    floor = _write_capture_mesh(
        floor_name, capture.floor, capture.velocity_scale,
        capture.background_motion, capture.background_acceleration, capture.temporal,
    )
    record.capture_subject = subject.name
    record.capture_floor = floor.name
    for old_name in old_names:
        if old_name not in {subject.name, floor.name}:
            old = bpy.data.meshes.get(old_name)
            if old is not None:old.use_fake_user=False
    from .impaction_multirig import capture_owners
    record["_rig_capture_owners"] = json.dumps(capture_owners(bpy.context))
    capture._persistent_names=(subject.name,floor.name)
    invalidate_record_signature(record)


def _delete_persistent_capture(record):
    names = (str(record.capture_subject), str(record.capture_floor))
    record.capture_subject = ""
    record.capture_floor = ""
    for name in names:
        _remove_capture_mesh(name)


def invalidate_capture(camera, record):
    if camera is None or record is None:
        return
    dependency_key=(camera.name_full,int(record.salt))
    _trail_capture_revisions[dependency_key]=_trail_capture_revisions.get(dependency_key,0)+1
    # Distinct capture identities keep older completed pixels valid for Undo.
    camera_name = camera.name_full
    salt = int(record.salt)
    for key in tuple(_capture_cache):
        if key[0] == camera_name and key[1] == salt:
            _capture_cache_remove(key)
    _purge_surface_cache(camera_name, salt)


def has_cached_capture(camera, record):
    return bool(
        camera is not None and record is not None
        and (_capture_key(camera, record) in _capture_cache or _persistent_capture_available(record))
    )


def retime_capture(camera, record, old_frame):
    """Move cached source geometry with a retimed key without regenerating it."""
    if camera is None or record is None:
        return
    old_key = (camera.name_full, int(record.salt), int(old_frame))
    item = _capture_cache_remove(old_key)
    capture = item[0] if item is not None else None
    if capture is not None:
        _capture_cache_put(_capture_key(camera, record), capture)
    _purge_surface_cache(camera.name_full, int(record.salt))


def duplicate_record_cache(camera, source, target):
    """Clone a completed frame without reevaluating geometry or rerendering it."""
    source_capture = (
        _capture_cache_get(_capture_key(camera, source))
        or _load_persistent_capture(source)
    )
    if source_capture is not None:
        from copy import copy
        # New keys may share immutable mesh arrays, never mutable path/frame
        # metadata or rig caches. Linking one key otherwise changes another.
        target_capture=copy(source_capture)
        target_capture.subject=copy(source_capture.subject)
        for name in tuple(vars(target_capture.subject)):
            if name.startswith(('_linear_','_trail_')) or name=='_rig_slices':
                delattr(target_capture.subject,name)
        if hasattr(target_capture,'_held_motion_variants'):
            delattr(target_capture,'_held_motion_variants')
        _capture_cache_put(_capture_key(camera, target), target_capture)
        _store_persistent_capture(camera, target, target_capture)
    source_image = cached_image(source)
    if source_image is None:
        target.cache_valid = False
        target.cache_image = ""
        target.cache_signature = ""
        return
    name = _image_name(camera, target)
    stale = bpy.data.images.get(name)
    if stale is not None and stale.users == 0:
        bpy.data.images.remove(stale)
    clone = source_image.copy()
    clone.name = name
    try:
        clone.pack()
    except RuntimeError:
        pass
    clone.use_fake_user = True
    target.cache_image = clone.name
    target.cache_valid = True
    target.cache_signature = record_render_signature(
        target, getattr(bpy.context, "scene", None),
    )
    target["_render_cache_version"] = _RENDER_CACHE_VERSION


def delete_record_cache(camera, record):
    """Remove both the CPU capture and packed image owned by a deleted key."""
    invalidate_capture(camera, record)
    _delete_persistent_capture(record)
    clear_record_preview(camera, record)
    image = bpy.data.images.get(record.cache_image) if record.cache_image else None
    record.cache_valid = False
    record.cache_image = ""
    record.cache_signature = ""
    if image is not None:
        image.use_fake_user = False
        if image.users == 0:
            bpy.data.images.remove(image)


def detach_record_cache(camera, record):
    """Detach ownership while retaining native pixels/meshes for Blender Undo."""
    capture = None
    for key in tuple(_capture_cache):
        if key[0] == camera.name_full and key[1] == int(record.salt):
            item = _capture_cache_remove(key)
            capture = (item[0] if item is not None else None) or capture
    _purge_surface_cache(camera.name_full, int(record.salt))
    clear_record_preview(camera, record)
    # The persistent capture meshes below are authoritative. Keeping the same
    # high-poly geometry a second time as Python tuples in every undo snapshot
    # made delete/redo sessions grow without bound.
    state = (
        None, str(record.cache_image), bool(record.cache_valid),
        str(getattr(record, "cache_signature", "")),
        str(record.capture_subject), str(record.capture_floor),
    )
    record.cache_image = ""
    record.cache_valid = False
    record.cache_signature = ""
    record.capture_subject = ""
    record.capture_floor = ""
    return state


def restore_record_cache(camera, record, state):
    """Reattach a deletion snapshot without rerendering its imagery."""
    if not state:
        return
    capture, image_name, was_valid, *remaining = state
    if len(remaining) >= 3:
        signature, *capture_names = remaining
    else:
        signature, capture_names = "", remaining
    if capture is not None:
        _capture_cache_put(_capture_key(camera, record), capture)
    image = bpy.data.images.get(image_name) if image_name else None
    record.cache_image = image.name if image is not None else ""
    record.cache_valid = bool(was_valid and _valid_image(image))
    record.cache_signature = str(signature) if record.cache_valid else ""
    if len(capture_names) >= 2:
        record.capture_subject = (
            capture_names[0] if bpy.data.meshes.get(capture_names[0]) is not None else ""
        )
        record.capture_floor = (
            capture_names[1] if bpy.data.meshes.get(capture_names[1]) is not None else ""
        )


def _needs_temporal_capture(record):
    return (float(getattr(record,"motion_curve_influence",1.))>1.e-6 or
            (float(getattr(record,"background_intensity",.5))>1.e-6 and
             float(getattr(record,"background_motion",.5))>1.e-6))


def _link_trail_snapshots(context, camera, record, capture):
    """Connect frozen impact records, independent of playback/render order."""
    geometry=capture.subject
    geometry._trail_frame=float(record.frame)
    geometry._trail_predecessor=None
    if record.motion_curve_influence<=1.e-6:return
    earlier=[r for r in camera.impaction_frames if r.frame<record.frame]
    if not earlier:return
    previous=max(earlier,key=lambda r:r.frame)
    elapsed=float(record.frame-previous.frame)
    if elapsed>=8. or previous.motion_curve_influence<=1.e-6:return
    source=_capture_cache_get(_capture_key(camera,previous))
    if source is None:source=_load_persistent_capture(previous)
    if source is None:return
    _capture_cache_put(_capture_key(camera,previous),source)
    _link_trail_snapshots(context,camera,previous,source)
    width,height=_render_size(context)
    arguments=(tuple(previous.direction_focus),bool(previous.direction_cast_behind),
        width/max(height,1),float(previous.halo_spread),_impact_style_salt(previous),
        float(previous.motion_curve_influence),tuple(source.background_motion),
        tuple(source.background_acceleration),float(source.velocity_scale),
        float(previous.strength),float(previous.line_thickness))
    geometry._trail_predecessor=(source.subject,arguments)


def _record_capture(context, camera, record, recapture=False):
    key = _capture_key(camera, record)
    if recapture:
        invalidate_capture(camera, record)
    capture = _capture_cache_get(key)
    if capture is None and not recapture:
        capture = _load_persistent_capture(record)
    # A style edit never replaces an authored subject, even when an older
    # snapshot has no motion channels. Update captures all channels explicitly.
    if capture is None and not recapture and (record.capture_subject or record.cache_image):
        raise RuntimeError("Saved subject capture is unavailable. Press Update to recapture it.")
    if capture is None:
        scene = context.scene
        original_frame = scene.frame_current
        original_subframe = scene.frame_subframe
        moved_frame = (
            int(original_frame) != int(record.frame)
            or abs(float(original_subframe)) > 1.0e-8
        )
        try:
            if moved_frame:
                scene.frame_set(int(record.frame), subframe=0.0)
            capture = capture_impact(context, camera)
        finally:
            if moved_frame:
                scene.frame_set(original_frame, subframe=original_subframe)
        _store_persistent_capture(camera, record, capture)
    _capture_cache_put(key, capture)
    _link_trail_snapshots(context,camera,record,capture)
    age=_held_motion_age(record,context.scene)
    if age and getattr(capture.subject,'motion_history',None):
        variants=getattr(capture,'_held_motion_variants',None)
        if variants is None:variants=capture._held_motion_variants={}
        if age not in variants:
            from copy import copy
            held=copy(capture);held.subject=copy(capture.subject)
            for name in tuple(vars(held.subject)):
                if name.startswith('_linear_') or name in {'_rig_slices','_drawing_projected_extent'}:delattr(held.subject,name)
            held.subject.motion_history={owner:[[float(row[0])-age,*row[1:]] for row in rows]
                for owner,rows in capture.subject.motion_history.items()}
            held.subject._trail_frame=float(record.frame)+age
            held.motion_age=age
            if len(variants)>=4:variants.pop(next(iter(variants)))
            variants[age]=held
        return variants[age]
    return capture


def recapture_records(context, camera, records):
    """Capture keyed geometry and adjacent samples in one ordered pass."""
    records = tuple(records)
    if not records:
        return
    previous_views = {}
    for record in records:
        previous = _capture_cache_get(_capture_key(camera, record)) or _load_persistent_capture(record)
        if previous is not None:
            previous_views[int(record.salt)] = previous.subject.view_projection
        invalidate_capture(camera, record)
    view_changes = {}
    scene = context.scene
    original_frame = scene.frame_current
    original_subframe = scene.frame_subframe
    try:
        ordered = sorted(records, key=lambda item: int(item.frame))
        captures = capture_impacts(
            context, camera, (int(record.frame) for record in ordered),
            temporal_frames={int(record.frame) for record in ordered},
        )
        for record in ordered:
            capture = captures[int(record.frame)]
            view_changes[int(record.salt)] = (previous_views.get(int(record.salt)), capture.subject.view_projection)
            _capture_cache_put(_capture_key(camera, record), capture)
            _store_persistent_capture(camera, record, capture)
    finally:
        scene.frame_set(original_frame, subframe=original_subframe)
    return view_changes


class _TailPrefix:
    def __init__(self, source, mask, shape, grain, foreground, background):
        self.source,self.mask,self.shape,self.grain=source,mask,shape,grain
        self.foreground,self.background=foreground,background
    def free(self):
        for surface in (self.source,self.mask,self.shape,self.grain):
            if surface is not None:_free_surface(surface)


def _finish_frame_effects(context, record, master_record, processed_surface, mask,
                          shape_effect_texture, grain_mask, foreground, background,
                          width, height, paper_width, paper_height, final, grade_source_key):
    from . import impaction_multirig as multirig
    batch=_fullscreen_quad(_shader("grade", "fullscreen.vert", "grade.frag"))
    bloom_amount=max(0.,min(1.,record.bloom));needs_bloom=bloom_amount>.0001
    needs_aberration=record.chromatic_aberration>.0001
    needs_grain=max(record.grain,record.grain_overlay_intensity)>.0001
    pixelate_amount=max(0.,min(1.,record.pixelate))
    needs_pixelate=pixelate_amount>.0001 and record.pixelate_size>1
    bloom_level_limit=6
    bloom_emission=_offscreen(width,height,high_precision=True) if needs_bloom else None
    pixelate_surface=_offscreen(width,height,high_precision=True) if needs_pixelate else None
    glitch_surface=invert_before_bloom_surface=grade_surface=None
    bloom_levels=[];bloom_upsamples=[];output_surface=None
    try:
        glitch_amount = float(getattr(master_record,"aberration_glitch",0.0))
        if glitch_amount > .0001:
            # Mesh/depth layers have already been composed. Glitch distorts the
            # final drawing once; the compositor cannot stamp the old mesh
            # silhouette back over displaced pixels afterward.
            glitch_shader = _shader("glitch", "fullscreen.vert", "glitch.frag")
            glitch_surface = _offscreen(width,height,high_precision=True)
            with glitch_surface.bind():
                glitch_shader.uniform_sampler("colorTex",processed_surface.texture_color)
                glitch_shader.uniform_sampler("shapeMaskTex",shape_effect_texture)
                glitch_shader.uniform_float("resolution",(float(width),float(height)))
                glitch_shader.uniform_float("glitch",glitch_amount)
                glitch_shader.uniform_float("glitchTime",_glitch_time(master_record, context.scene))
                glitch_shader.uniform_float("glitchKey",float(master_record.frame))
                glitch_shader.uniform_float("glitchSize",float(getattr(master_record,"glitch_size",10)))
                gpu.state.blend_set("NONE")
                batch.draw(glitch_shader)
            processed_surface=glitch_surface
        invert_before_bloom = bool(
            needs_bloom and record.invert and record.bloom_invert
        )
        if invert_before_bloom:
            # Invert Bloom is authored against the visible negative. Invert
            # the completed spatial image before extraction, then run normal
            # additive bloom so its white and spectral energy glow instead of
            # producing a second subtractive/rasterized negative.
            invert_before_bloom_surface = _offscreen(
                width, height, high_precision=True,
            )
            pre_bloom_grade = _shader(
                "grade", "fullscreen.vert", "grade.frag",
            )
            with invert_before_bloom_surface.bind():
                framebuffer = gpu.state.active_framebuffer_get()
                framebuffer.clear(color=background, depth=1.0)
                pre_bloom_grade.uniform_sampler(
                    "colorTex", processed_surface.texture_color,
                )
                pre_bloom_grade.uniform_float("contrast", 0.0)
                pre_bloom_grade.uniform_float("grayscale", 0.0)
                pre_bloom_grade.uniform_float("negative", 1.0)
                gpu.state.blend_set("NONE")
                batch.draw(pre_bloom_grade)
            processed_surface = invert_before_bloom_surface

        if needs_bloom:
            extract_shader = _shader("bloom_extract", "fullscreen.vert", "bloom_extract.frag")
            with bloom_emission.bind():
                framebuffer = gpu.state.active_framebuffer_get()
                framebuffer.clear(color=(0.0, 0.0, 0.0, 1.0), depth=1.0)
                extract_shader.uniform_sampler(
                    "colorTex", processed_surface.texture_color,
                )
                extract_shader.uniform_sampler("impactTex", mask.texture_color)
                extract_shader.uniform_sampler("shapeMaskTex", shape_effect_texture)
                extract_shader.uniform_sampler(
                    "grainTex",
                    grain_mask.texture_color if grain_mask is not None
                    else mask.texture_color,
                )
                extract_shader.uniform_float("resolution", (float(width), float(height)))
                extract_shader.uniform_float("foreground", foreground)
                extract_shader.uniform_float("background", background)
                extract_shader.uniform_float(
                    "aberrationActive", float(needs_aberration),
                )
                extract_shader.uniform_float(
                    "grainActive", 1.0 if grain_mask is not None else 0.0,
                )
                extract_shader.uniform_float("grainBloomMix", 1.0)
                gpu.state.blend_set("NONE")
                batch.draw(extract_shader)

            down_shader = _shader("bloom_down", "fullscreen.vert", "bloom_down.frag")
            source_surface = bloom_emission
            source_width, source_height = width, height
            mip_count = max(
                2,
                min(
                    bloom_level_limit,
                    max(3, int(math.log2(max(16, min(paper_width, paper_height)))) - 4),
                ),
            )
            for _level in range(mip_count):
                level_width = max(16, source_width // 2)
                level_height = max(16, source_height // 2)
                level_surface = _offscreen(level_width, level_height, high_precision=True)
                with level_surface.bind():
                    framebuffer = gpu.state.active_framebuffer_get()
                    framebuffer.clear(color=(0.0, 0.0, 0.0, 1.0), depth=1.0)
                    down_shader.uniform_sampler("colorTex", source_surface.texture_color)
                    down_shader.uniform_float(
                        "sourceResolution", (float(source_width), float(source_height)),
                    )
                    gpu.state.blend_set("NONE")
                    batch.draw(down_shader)
                bloom_levels.append((level_surface, level_width, level_height))
                source_surface = level_surface
                source_width, source_height = level_width, level_height

            up_shader = _shader("bloom_up", "fullscreen.vert", "bloom_up.frag")
            current_surface, current_width, current_height = bloom_levels[-1]
            # Linear radius allocation keeps deeper mips available for the
            # upper half of the slider instead of exhausting them near 50.
            spread = bloom_amount
            activations = [1.0]
            for level_index in range(1, len(bloom_levels)):
                low_edge = max(0.0, (level_index - 1.0) / len(bloom_levels))
                high_edge = min(1.0, (level_index + 0.65) / len(bloom_levels))
                value = max(0.0, min(1.0, (spread - low_edge) /
                                     max(0.001, high_edge - low_edge)))
                activations.append(value * value * (3.0 - 2.0 * value))
            first_upsample = True
            for high_index in range(len(bloom_levels) - 2, -1, -1):
                high_surface, high_width, high_height = bloom_levels[high_index]
                upsampled = _offscreen(high_width, high_height, high_precision=True)
                with upsampled.bind():
                    framebuffer = gpu.state.active_framebuffer_get()
                    framebuffer.clear(color=(0.0, 0.0, 0.0, 1.0), depth=1.0)
                    up_shader.uniform_sampler("lowTex", current_surface.texture_color)
                    up_shader.uniform_sampler("highTex", high_surface.texture_color)
                    up_shader.uniform_float(
                        "lowResolution", (float(current_width), float(current_height)),
                    )
                    up_shader.uniform_float(
                        "lowWeight",
                        activations[high_index + 1] if first_upsample else 1.0,
                    )
                    up_shader.uniform_float("highWeight", activations[high_index])
                    gpu.state.blend_set("NONE")
                    batch.draw(up_shader)
                bloom_upsamples.append(upsampled)
                current_surface = upsampled
                current_width, current_height = high_width, high_height
                first_upsample = False

            bloom_shader = _shader("bloom", "fullscreen.vert", "bloom.frag")
            bloom_target = final
            with bloom_target.bind():
                framebuffer = gpu.state.active_framebuffer_get()
                framebuffer.clear(color=background, depth=1.0)
                bloom_shader.uniform_sampler("colorTex", processed_surface.texture_color)
                bloom_shader.uniform_sampler("glowTex", current_surface.texture_color)
                bloom_shader.uniform_sampler("coreTex", bloom_levels[0][0].texture_color)
                bloom_shader.uniform_float(
                    "bloom",
                    bloom_amount * 100.0 * (
                        -1.0
                        if record.bloom_invert and not invert_before_bloom
                        else 1.0
                    ),
                )
                gpu.state.blend_set("NONE")
                batch.draw(bloom_shader)
            processed_surface = bloom_target

        # Pixelation is the final spatial transform. Aberration, bloom, and
        # motion abstraction may not displace sub-pixel source lines back into
        # an already-formed cell grid.
        if needs_pixelate:
            pixelate_shader = _shader(
                "pixelate", "fullscreen.vert", "pixelate.frag",
            )
            pixelate_target = pixelate_surface or final
            with pixelate_target.bind():
                framebuffer = gpu.state.active_framebuffer_get()
                framebuffer.clear(color=background, depth=1.0)
                pixelate_shader.uniform_sampler(
                    "colorTex", processed_surface.texture_color,
                )
                pixelate_shader.uniform_sampler("impactTex", mask.texture_color)
                pixelate_shader.uniform_sampler("shapeMaskTex", shape_effect_texture)
                pixelate_shader.uniform_float(
                    "resolution", (float(paper_width), float(paper_height)),
                )
                pixelate_shader.uniform_float("pixelate", pixelate_amount)
                pixelate_shader.uniform_float(
                    "pixelSize", float(record.pixelate_size),
                )
                gpu.state.blend_set("NONE")
                batch.draw(pixelate_shader)
            processed_surface = pixelate_target

        if grade_source_key is not None:
            import sys
            grade_source = multirig.copy_texture(sys.modules[__name__], processed_surface.texture_color, width, height)
            _cache_put(_grade_source_cache, grade_source_key, grade_source, width * height, 8_500_000)
        output_surface = processed_surface
        if (record.contrast > 0.0001 or record.grayscale > 0.0001
                or (record.invert and not invert_before_bloom)):
            grade_surface = _offscreen(width, height, high_precision=True)
            grade_shader = _shader("grade", "fullscreen.vert", "grade.frag")
            with grade_surface.bind():
                framebuffer = gpu.state.active_framebuffer_get()
                framebuffer.clear(color=background, depth=1.0)
                grade_shader.uniform_sampler("colorTex", processed_surface.texture_color)
                grade_shader.uniform_float("contrast", float(record.contrast))
                grade_shader.uniform_float("grayscale", float(record.grayscale))
                grade_shader.uniform_float(
                    "negative",
                    1.0 if record.invert and not invert_before_bloom else 0.0,
                )
                gpu.state.blend_set("NONE")
                batch.draw(grade_shader)
            output_surface = grade_surface

        return output_surface
    finally:
        owned=[glitch_surface,invert_before_bloom_surface,grade_surface,bloom_emission,pixelate_surface]
        owned.extend(v[0] for v in bloom_levels);owned.extend(bloom_upsamples)
        for surface in owned:
            if surface is not None and surface is not output_surface:_free_surface(surface)


# Exact full-resolution surfaces can be promoted, but transported/reduced
# previews can never become final pixels. Values follow the bounded surface cache.
_full_quality_previews = OrderedDict()


def _remember_preview_quality(camera, record, surface, full_quality):
    key = (camera.name_full, int(record.salt))
    _full_quality_previews.pop(key, None)
    if full_quality:
        _full_quality_previews[key] = surface
    while len(_full_quality_previews) > _PREVIEW_SURFACE_BUDGET:
        _full_quality_previews.popitem(last=False)


def render_record(
    context, camera, record, *, preview=False, recapture=False,
    apply_preview=False, retain_gpu_preview=False, interactive_quality=False,
    interactive_scale=None, pack_result=True, _rig_layer=False, _capture_override=None,
):
    if camera is None or camera.type != "CAMERA":
        raise RuntimeError("The viewed camera is unavailable.")
    from . import impaction_multirig as multirig
    if not _rig_layer and hasattr(record, 'as_pointer'):
        if len(multirig.rigs(context.scene)) > 1 or record.get('_rig_profiles', ''):
            multirig.ensure(record, camera, context.scene)
    master_record = record
    rig_resources = []
    layer_payloads = []
    paper_width, paper_height = _render_size(context)
    width, height = _render_size(
        context, max_dimension=(
            _preview_dimension(
                context, camera, interactive=interactive_quality,
                interactive_scale=interactive_scale,
            ) if preview else None
        ),
    )
    if not _rig_layer and not recapture and (not preview or apply_preview):
        key = (camera.name_full, int(record.salt))
        entry = _preview_surfaces.get(key)
        if (entry is not None and _full_quality_previews.get(key) is entry[0]
                and entry[2:4] == (paper_width, paper_height)
                and entry[1] == _current_render_signature(record, context.scene)):
            image = promote_record_preview(camera, record, context.scene, pack=pack_result)
            _full_quality_previews.pop(key, None)
            if image is not None:
                return image
    exact_preview = (not getattr(record, '_draft_linear', False)
        and (not interactive_quality or interactive_scale is None or interactive_scale >= 1.0)
        and (width, height) == (paper_width, paper_height))
    if preview and apply_preview:
        # A settled render must never promote the reduced GPU surface left by
        # the interactive pass.  The visual signature is intentionally the
        # same at both qualities, so signature-only promotion otherwise wins
        # over the full-resolution image produced below.
        preview_key = (camera.name_full, int(record.salt))
        reduced_surface = _preview_surfaces.pop(preview_key, None)
        if reduced_surface is not None:
            _free_surface(reduced_surface[0])
    preview_quality = 1.0
    if interactive_quality and interactive_scale is not None:
        preview_quality = min(preview_quality, float(interactive_scale))
    stroke_quality = 0.24 + 0.76 * preview_quality
    # Keep full integration at the best tier; smaller targets need fewer taps.
    # Sample density follows linear raster scale, never the number of strokes.
    motion_samples = max(9, int(math.ceil(64 * preview_quality * preview_quality)) + 1)
    aberration_samples = max(13, int(math.ceil(96 * preview_quality * preview_quality)) + 1)
    bloom_level_limit = 6
    grade_source_key = None
    if preview and retain_gpu_preview and not apply_preview and not _rig_layer and not recapture and not getattr(record, "_draft_linear", False):
        ungraded = _preview_record_snapshot(record)
        ungraded.contrast = ungraded.grayscale = 0.0
        grade_source_key = (camera.name_full, int(record.salt),
            record_render_signature(ungraded, context.scene), width, height,
            preview_quality, motion_samples, aberration_samples)
        cached_grade = _cache_get(_grade_source_cache, grade_source_key)
        if cached_grade is not None:
            output = _offscreen(width, height, high_precision=True)
            shader = _shader("grade", "fullscreen.vert", "grade.frag")
            with output.bind():
                shader.uniform_sampler("colorTex", cached_grade.texture_color)
                shader.uniform_float("contrast", float(record.contrast))
                shader.uniform_float("grayscale", float(record.grayscale))
                shader.uniform_float("negative", float(record.invert and not (record.bloom > .0001 and record.bloom_invert)))
                gpu.state.blend_set("NONE")
                _fullscreen_quad(shader).draw(shader)
            key = (camera.name_full, int(record.salt))
            previous = _preview_surfaces.pop(key, None)
            if previous is not None: _free_surface(previous[0])
            signature = _current_render_signature(record, context.scene)
            _preview_surfaces[key] = (output, signature, width, height, _image_name(camera, record) + " - Grade Preview")
            _preview_signatures[key] = signature
            _remember_preview_quality(camera, record, output, exact_preview)
            return output
    tail_source_key=None
    if grade_source_key is not None:
        prefix_record=_preview_record_snapshot(record)
        for field in ("aberration_glitch","bloom","pixelate","grayscale","contrast"):
            setattr(prefix_record,field,0.0)
        prefix_record.glitch_size=5;prefix_record.pixelate_size=1
        prefix_record.invert=False;prefix_record.bloom_invert=False
        tail_source_key=(camera.name_full,int(record.salt),record_render_signature(prefix_record,context.scene),width,height,preview_quality,motion_samples,aberration_samples)
        prefix=_cache_get(_tail_source_cache,tail_source_key)
        if prefix is not None:
            target=_offscreen(width,height,high_precision=True)
            try:
                output=_finish_frame_effects(context,record,record,prefix.source,prefix.mask,
                    prefix.shape.texture_color,prefix.grain,prefix.foreground,prefix.background,
                    width,height,paper_width,paper_height,target,grade_source_key)
            except Exception:
                _free_surface(target);raise
            if output is prefix.source:
                import sys
                output=multirig.copy_texture(sys.modules[__name__],output.texture_color,width,height)
            if output is not target:_free_surface(target)
            key=(camera.name_full,int(record.salt));previous=_preview_surfaces.pop(key,None)
            if previous is not None:_free_surface(previous[0])
            signature=_current_render_signature(record,context.scene)
            _preview_surfaces[key]=(output,signature,width,height,_image_name(camera,record)+" - Effects Preview")
            _preview_signatures[key]=signature
            _remember_preview_quality(camera, record, output, exact_preview)
            return output
    capture = _capture_override if _capture_override is not None else _record_capture(context, camera, record, recapture=recapture)
    layer_cache_key = None
    if _rig_layer:
        token=getattr(capture.subject,'_drawing_token',None)
        if token is None:
            token=capture.subject._drawing_token=time.monotonic_ns()
        layer_record = _preview_record_snapshot(record)
        layer_record.aberration_glitch = 0.0
        layer_record.glitch_size = 5
        # These stages execute only after rig/family composition.
        for field in ("contrast", "grayscale", "bloom"):
            setattr(layer_record, field, 0.0)
        layer_record.invert = False
        layer_record.bloom_invert = False
        if int(getattr(record, "_optical_family", -1)) in (0, 1):
            # The isolated optical field follows pink, independent of cyan.
            for name, value in (("background_focus",(.5,.5)),
                ("background_x",0),("background_y",0),("background_intensity",0.),
                ("background_layer",0.),("background_depth",0.),
                ("background_depth_2d",0.),("background_motion",0.),
                ("background_flip_depth_2d",False),("background_space","2D")):
                setattr(layer_record,name,value)
        layer_cache_key=(camera.name_full,int(record.salt),width,height,paper_width,paper_height,
                         token,record_render_signature(layer_record,context.scene),preview_quality,motion_samples,aberration_samples,bool(getattr(record,"_draft_linear",False)),
                         int(getattr(record,"_optical_family",-1)), bool(getattr(record,"_optical_hybrid",False)),
                         bool(getattr(record,"_optical_radial_enabled",False)))
        cached_layer=_cache_get(_rig_layer_cache,layer_cache_key)
        if cached_layer is not None:return cached_layer
    full_capture = capture
    rig_plans = [] if _rig_layer else multirig.plans(context, camera, record, capture)
    rig_composition = not _rig_layer and bool(record.get("_rig_profiles", ""))
    if rig_composition:
        from copy import copy
        reference = json.loads(record.get('_rig_profiles', '{}')).get(record.get('_rig_reference', ''), {})
        if record.get('_rig_reference', '') == record.get('_rig_edit', ''):
            reference = {}
        record = multirig.apply_snapshot(record, reference)
        record.shapes = ()
        capture = copy(capture)
        if not hasattr(full_capture,"_background_subject"):
            full_capture._background_subject = CaptureGeometry([], [], [], [], [], [])
        capture.subject = full_capture._background_subject
        capture._rig_cache = "background"
        capture._background_bounds = _subject_bounds(full_capture)
    subject, floor, ownership, motion, background_motion_surface = (
        _rasterized_capture(
            camera, record, capture, width, height,
            raster_quality=preview_quality if interactive_quality else 1.0,
        )
    )
    # Effects need linear half-float intermediates. Repeated 8-bit bloom mip
    # quantization produces visible contour shelves and apparent low resolution.
    direct_key = (
        (camera.name_full, int(record.salt))
        if preview and retain_gpu_preview and not apply_preview else None
    )
    previous_direct = _preview_surfaces.pop(direct_key, None) if direct_key else None
    if (previous_direct is not None
            and int(previous_direct[2]) == int(width)
            and int(previous_direct[3]) == int(height)):
        final = previous_direct[0]
    else:
        if previous_direct is not None:
            _free_surface(previous_direct[0])
        final = _offscreen(width, height, high_precision=True)
    motion_blur_amount = max(0.0, min(1.0, record.motion_blur))
    aberration_amount = max(0.0, min(1.0, record.chromatic_aberration))
    bloom_amount = max(0.0, min(1.0, record.bloom))
    grain_amount = max(
        max(0.0, min(1.0, record.grain)),
        max(0.0, min(1.0, record.grain_overlay_intensity)),
    )
    halftone_amount = max(0.0, min(1.0, record.halftone))
    pixelate_amount = max(0.0, min(1.0, record.pixelate))
    needs_motion_blur = motion_blur_amount > 0.0001
    needs_aberration = aberration_amount > 0.0001
    optical_families = ([0] if len(capture.subject.positions) or record.shapes else [])
    if record.radial_enabled and not rig_composition: optical_families.append(1)
    if record.background_2d_enabled: optical_families.append(2)
    if record.background_3d_enabled: optical_families.append(3)
    split_optics = ((len(optical_families) > 1 or (rig_composition and optical_families)) and
        int(getattr(record, "_optical_family", -1)) < 0 and
        (needs_motion_blur or needs_aberration or
         record.background_2d_enabled or record.background_3d_enabled))
    needs_bloom = not _rig_layer and bloom_amount > 0.0001
    needs_grain = grain_amount > 0.0001
    needs_pixelate = pixelate_amount > 0.0001 and record.pixelate_size > 1
    needs_post = (
        needs_grain or needs_pixelate or needs_motion_blur
        or needs_aberration or needs_bloom
    )
    composite_buffer = (
        _offscreen(width, height, high_precision=True)
        if needs_post else None
    )
    chromatic = (
        _offscreen(width, height, high_precision=True)
        if needs_aberration and needs_bloom else None
    )
    motion_surface = (
        _offscreen(width, height, high_precision=True)
        if needs_motion_blur and (needs_aberration or needs_bloom) else None
    )
    grain_mask = (
        _offscreen(width, height, high_precision=True) if needs_grain else None
    )
    grain_surface = (
        _offscreen(width, height, high_precision=True)
        if needs_grain and (
            needs_pixelate or needs_motion_blur or needs_aberration or needs_bloom
        ) else None
    )
    pixelate_surface = None
    bloom_emission = None
    invert_before_bloom_surface = None
    grade_surface = None
    shape_surface = None
    clean_motion_surface = None
    glitch_surface = None
    optical_group_surfaces = []
    optical_group_mask = None
    preview_family_payloads = {}
    preview_family_surfaces = []
    preview_mask_surface = None
    shape_mask_surface = None
    grain_distance_surface = None
    direction_surface = None
    shape_texture = None
    shape_shader = None
    shape_count = 0
    bloom_levels = []
    bloom_upsamples = []
    retained_surface = None
    try:
        shader = _shader("composite", "fullscreen.vert", "composite.frag")
        batch = _fullscreen_quad(shader)
        if split_optics and interactive_quality and preview_quality < .999:
            # The full parent mask repeats every expensive procedural family
            # immediately before its optics leaf draws it again. During input,
            # assemble parent ownership from the already resolved leaf masks.
            # Final/export retains the exact original resolve-after-union rule.
            import sys
            for family in optical_families:
                local = _optical_family_record(record, family)
                payload = render_record(context, camera, local, preview=preview,
                    interactive_quality=True, interactive_scale=interactive_scale,
                    pack_result=False, _rig_layer=True, _capture_override=capture)
                owned = tuple(multirig.copy_texture(sys.modules[__name__], item.texture_color,
                    width, height) for item in payload[:2])
                preview_family_surfaces.extend(owned)
                preview_family_payloads[family] = owned
            layers_shader = _shader("impact_layers", "fullscreen.vert", "impact_layers.frag")
            for family in (3, 1, 0, 2):
                if family not in preview_family_payloads: continue
                front = preview_family_payloads[family][1]
                if preview_mask_surface is None:
                    preview_mask_surface = multirig.copy_texture(sys.modules[__name__],
                        front.texture_color, width, height)
                else:
                    merged_mask = _offscreen(width,height,high_precision=True)
                    with merged_mask.bind():
                        layers_shader.uniform_sampler("subjectTex",preview_mask_surface.texture_color)
                        layers_shader.uniform_sampler("floorTex",front.texture_color)
                        gpu.state.blend_set("NONE")
                        batch.draw(layers_shader)
                    preview_mask_surface.free()
                    preview_mask_surface = merged_mask
            mask = preview_mask_surface
        else:
            mask = _impact_mask(
                camera, record, capture, subject, floor, ownership, motion,
                background_motion_surface,
                width, height, batch,
                paper_width, paper_height, stroke_quality, interactive_geometry=(preview_quality if interactive_quality else False),
            )
        # Flip exchanges the two base endpoints first. Invert remains an
        # independent full-frame photographic negative applied after every
        # effect and grade, so enabling both intentionally performs both.
        raw_foreground, raw_background = _frame_palette(record)
        # Grade after the complete optical pipeline so contrast and grayscale
        # also affect bloom, spectral dispersion, halftone and grain.
        foreground = raw_foreground
        background = raw_background
        gradient, _gradient_norm = aberration_gradient_samples(record)
        logical_aberration_colors = (
            aberration_colors(record)
            if record.aberration_preset == "CUSTOM" else ()
        )
        single_aberration_color = (
            logical_aberration_colors[0]
            if len(logical_aberration_colors) == 1
            else (0.0, 0.0, 0.0, 1.0)
        )
        effective_light_color, light_energy, light_source = _effective_light(
            record, raw_foreground, raw_background,
        )
        # Texel 17 carries light RGB plus intensity. Texel 18 carries the
        # artist-selected source mode, because inferring the mode from equal
        # RGB values makes Custom black/gray collide with palette endpoints.
        light_source_code = {
            "FOREGROUND": 0.0,
            "BACKGROUND": 1.0,
            "CUSTOM": 2.0,
        }.get(light_source, 0.0)
        composite_parameters = tuple(gradient) + ((
            float(effective_light_color[0]), float(effective_light_color[1]),
            float(effective_light_color[2]), float(light_energy),
        ), (light_source_code, 0.0, 0.0, 0.0))
        gradient_texture = _gradient_texture(composite_parameters)
        def draw_composite(target, grain_texture, grain_active):
            with target.bind():
                framebuffer = gpu.state.active_framebuffer_get()
                framebuffer.clear(color=background, depth=1.0)
                shader.uniform_sampler("impactTex", mask.texture_color)
                shader.uniform_sampler("subjectTex", subject.texture_color)
                shader.uniform_sampler("gradientTex", gradient_texture)
                shader.uniform_sampler("grainTex", grain_texture)
                shader.uniform_float("resolution", (float(width), float(height)))
                shader.uniform_int("mode", _effect_mode(record))
                shader.uniform_float(
                    "angle", _resolved_direction_angle(record),
                )
                shader.uniform_float("focus", _effect_focus(record))
                # Spectral displacement is applied once, after shapes have
                # joined the composite. Keeping the old pre-shape pass active
                # left crisp, unprocessed shape/background lines underneath.
                shader.uniform_float("aberration", 0.0)
                shader.uniform_float("foreground", foreground)
                shader.uniform_float("background", background)
                shader.uniform_float("backgroundLineColor", tuple(getattr(record, "background_line_color", foreground)))
                shader.uniform_float(
                    "bleedAmount", float(getattr(record, "bleed", 0.5)),
                )
                shader.uniform_float("halftone", halftone_amount)
                shader.uniform_float("halftoneSize", float(record.halftone_size))
                shader.uniform_float("paperResolution", (float(paper_width), float(paper_height)))
                shader.uniform_float("aberrationSpread", 1.5)
                shader.uniform_float("aberrationIntensity", 2.0)
                shader.uniform_float("grainActive", grain_active)
                shader.uniform_float(
                    "singleColorActive",
                    1.0 if len(logical_aberration_colors) == 1 else 0.0,
                )
                shader.uniform_float("singleColor", single_aberration_color)
                shader.uniform_float(
                    "directionPolarity", _effect_polarity(record),
                )
                shader.uniform_float(
                    "cameraMotion", tuple(capture.background_motion),
                )
                gpu.state.blend_set("NONE")
                batch.draw(shader)

        composite_target = composite_buffer or final
        draw_composite(composite_target, mask.texture_color, 0.0)
        processed_surface = composite_target

        # Build clean shape coverage before Line Grain. The grain population
        # must know that a shape is ink; generating it only from impactTex made
        # shape-only pixels incapable of emitting the same line scatter.
        if record.shapes:
            shape_texture, shape_count = _shape_texture(record)
            shape_shader = _shader("shapes", "fullscreen.vert", "shapes.frag")
            shape_mask_surface = _offscreen(width, height, high_precision=True)
            with shape_mask_surface.bind():
                framebuffer = gpu.state.active_framebuffer_get()
                framebuffer.clear(color=(0.0, 0.0, 0.0, 1.0), depth=1.0)
                shape_shader.uniform_sampler("colorTex", processed_surface.texture_color)
                shape_shader.uniform_sampler("subjectTex", subject.texture_color)
                shape_shader.uniform_sampler("shapeTex", shape_texture)
                shape_shader.uniform_sampler("impactTex", mask.texture_color)
                shape_shader.uniform_sampler("grainTex", mask.texture_color)
                shape_shader.uniform_float("resolution", (float(paper_width), float(paper_height)))
                shape_shader.uniform_int("shapeCount", shape_count)
                shape_shader.uniform_float("frameInk", foreground)
                shape_shader.uniform_float("framePaper", background)
                shape_shader.uniform_int("maskOnly", 1)
                shape_shader.uniform_float("halftone", halftone_amount)
                shape_shader.uniform_float("halftoneSize", float(record.halftone_size))
                shape_shader.uniform_float("paperResolution", (float(paper_width), float(paper_height)))
                shape_shader.uniform_float("grainActive", 0.0)
                gpu.state.blend_set("NONE")
                batch.draw(shape_shader)

        if grain_mask is not None and not rig_composition:
            shape_source=(shape_mask_surface.texture_color if shape_mask_surface is not None else _empty_texture())
            grain_shader = _shader("grain", "fullscreen.vert", "grain.frag")
            with grain_mask.bind():
                framebuffer = gpu.state.active_framebuffer_get()
                framebuffer.clear(color=(0.0, 0.0, 0.0, 1.0), depth=1.0)
                grain_shader.uniform_sampler("impactTex", mask.texture_color)
                grain_shader.uniform_sampler(
                    "shapeMaskTex",
                    shape_mask_surface.texture_color
                    if shape_mask_surface is not None else _empty_texture(),
                )
                _configure_grain_shader(
                    grain_shader, record, width, height,
                    paper_width, paper_height,
                )
                gpu.state.blend_set("NONE")
                batch.draw(grain_shader)
            grain_target = grain_surface or final
            draw_composite(grain_target, grain_mask.texture_color, 1.0)
            processed_surface = grain_target

        under_shape_surface = processed_surface
        shape_influences = tuple((v,0.,0.,0.) for v in sorted(set(float(getattr(shape,"effect_influence",.5)) for shape in record.shapes))) or ((-1.,0.,0.,0.),)
        shape_influence_texture = _gradient_texture(shape_influences)
        # Shapes must enter the image before spatial post effects. The old
        # post-bloom placement made Pixelate, Motion Blur, Aberration and Bloom
        # mathematically incapable of affecting a star or doodle.
        if shape_shader is not None:
            shape_surface = _offscreen(width, height, high_precision=True)
            with shape_surface.bind():
                framebuffer = gpu.state.active_framebuffer_get()
                framebuffer.clear(color=background, depth=1.0)
                shape_shader.uniform_sampler("colorTex", processed_surface.texture_color)
                shape_shader.uniform_sampler("subjectTex", subject.texture_color)
                shape_shader.uniform_sampler("shapeTex", shape_texture)
                shape_shader.uniform_sampler("impactTex", mask.texture_color)
                shape_shader.uniform_sampler(
                    "grainTex", grain_mask.texture_color
                    if grain_mask is not None else mask.texture_color,
                )
                shape_shader.uniform_float("resolution", (float(paper_width), float(paper_height)))
                shape_shader.uniform_int("shapeCount", shape_count)
                shape_shader.uniform_float("frameInk", foreground)
                shape_shader.uniform_float("framePaper", background)
                shape_shader.uniform_int("maskOnly", 0)
                shape_shader.uniform_float("halftone", halftone_amount)
                shape_shader.uniform_float("halftoneSize", float(record.halftone_size))
                shape_shader.uniform_float("paperResolution", (float(paper_width), float(paper_height)))
                shape_shader.uniform_float("grainActive", 1.0 if grain_mask is not None else 0.0)
                gpu.state.blend_set("NONE")
                batch.draw(shape_shader)
            processed_surface = shape_surface
        if shape_mask_surface is not None:
            shape_effect_texture = shape_mask_surface.texture_color
        else:
            shape_effect_texture = _empty_texture()
        if (needs_motion_blur or needs_aberration) and not split_optics:
            bounds = getattr(full_capture, "_background_bounds", _subject_bounds(full_capture))
            flow = (np.array(((bounds[0]+bounds[2])*.5, (bounds[1]+bounds[3])*.5)) - np.array(record.background_focus)) * (width,height)
            if np.linalg.norm(flow) < 1e-6: flow = np.array((-1.,0.))
            background_flow = tuple(flow / np.linalg.norm(flow) * min(width,height) * .45 / (width,height))
            direction_surface = _effect_direction_surface(
                record, full_capture, rig_plans, ownership, width, height, camera=camera, impact=mask.texture_color,
                interactive_geometry=(preview_quality if interactive_quality else False))
        if needs_motion_blur and not split_optics:
            motion_record=_preview_record_snapshot(record)
            motion_record.chromatic_aberration=0.;motion_record.aberration_blur_smoothing=True
            for field in ("aberration_glitch","bloom","contrast","grayscale","pixelate"):
                setattr(motion_record,field,0.)
            motion_record.glitch_size=5;motion_record.pixelate_size=1
            motion_record.invert=False;motion_record.bloom_invert=False
            motion_key=(camera.name_full,int(record.salt),width,height,id(full_capture.subject),
                int(getattr(record,"_optical_family",-1)),record_render_signature(motion_record,context.scene),motion_samples,bool(getattr(record,"_draft_linear",False)))
            cached_motion=_cache_get(_motion_result_cache,motion_key)
            if cached_motion is not None:
                import sys
                processed_surface=multirig.copy_texture(sys.modules[__name__],cached_motion[0].texture_color,width,height)
                optical_group_surfaces.append(processed_surface)
                under_shape_surface=cached_motion[1] or cached_motion[0]
            else:
                motion_shader = _shader(
                    "motion_blur", "fullscreen.vert", "motion_blur.frag",
                )
                motion_target = motion_surface or final
                with motion_target.bind():
                    framebuffer = gpu.state.active_framebuffer_get()
                    framebuffer.clear(color=background, depth=1.0)
                    motion_shader.uniform_sampler(
                        "colorTex", processed_surface.texture_color,
                    )
                    motion_shader.uniform_sampler("impactTex", mask.texture_color)
                    motion_shader.uniform_sampler("shapeMaskTex", shape_effect_texture)
                    motion_shader.uniform_sampler("directionTex", direction_surface.texture_color)
                    motion_shader.uniform_sampler("fieldOwnerTex", direction_surface.ownership_texture)
                    motion_shader.uniform_sampler("underShapeTex", under_shape_surface.texture_color)
                    motion_shader.uniform_sampler("shapeInfluencesTex", shape_influence_texture)
                    motion_shader.uniform_float("backgroundFocus", tuple(record.background_focus))
                    motion_shader.uniform_float("backgroundFlow", background_flow)
                    motion_shader.uniform_float("backgroundShape", (float(record.background_depth_2d), float(record.background_flip_depth_2d), float(record.background_2d_enabled), float(record.background_3d_enabled)))
                    motion_shader.uniform_float(
                        "resolution", (float(width), float(height)),
                    )
                    motion_shader.uniform_float("amount", motion_blur_amount)
                    motion_shader.uniform_int("sampleCount", motion_samples)
                    motion_shader.uniform_float("background", background)
                    gpu.state.blend_set("NONE")
                    batch.draw(motion_shader)
                processed_surface = motion_target
                if record.shapes:
                    clean_motion_surface = _offscreen(width,height,high_precision=True)
                    with clean_motion_surface.bind():
                        motion_shader.uniform_sampler("colorTex",under_shape_surface.texture_color)
                        motion_shader.uniform_sampler("shapeMaskTex",_empty_texture())
                        motion_shader.uniform_sampler("underShapeTex",under_shape_surface.texture_color)
                        batch.draw(motion_shader)
                    under_shape_surface = clean_motion_surface
                elif not record.shapes:
                    under_shape_surface = motion_target
                import sys
                saved_motion=multirig.copy_texture(sys.modules[__name__],processed_surface.texture_color,width,height)
                saved_under=(multirig.copy_texture(sys.modules[__name__],under_shape_surface.texture_color,width,height)
                             if record.shapes else None)
                _cache_put(_motion_result_cache,motion_key,(saved_motion,saved_under),width*height*(2 if saved_under is not None else 1),12_500_000)
        if needs_aberration and not split_optics:
            aberration_shader = _shader(
                "aberration_blend", "fullscreen.vert", "aberration_blend.frag",
            )
            aberration_target = chromatic or final
            with aberration_target.bind():
                framebuffer = gpu.state.active_framebuffer_get()
                framebuffer.clear(color=background, depth=1.0)
                aberration_shader.uniform_sampler("colorTex", processed_surface.texture_color)
                aberration_shader.uniform_sampler(
                    # Abbreviation belongs to the completed optical image.
                    # Sampling the sharp pre-blur frame here produced detached
                    # spectral rails around a motion-blurred base image.
                    "spectralTex", processed_surface.texture_color,
                )
                aberration_shader.uniform_sampler(
                    "grainTex",
                    grain_mask.texture_color if grain_mask is not None
                    else mask.texture_color,
                )
                aberration_shader.uniform_sampler("impactTex", mask.texture_color)
                aberration_shader.uniform_sampler("shapeMaskTex", shape_effect_texture)
                aberration_shader.uniform_sampler("directionTex", direction_surface.texture_color)
                aberration_shader.uniform_sampler("fieldOwnerTex", direction_surface.ownership_texture)
                aberration_shader.uniform_sampler("underShapeTex", under_shape_surface.texture_color)
                aberration_shader.uniform_sampler("shapeInfluencesTex", shape_influence_texture)
                aberration_shader.uniform_float("backgroundFocus", tuple(record.background_focus))
                aberration_shader.uniform_float("backgroundFlow", background_flow)
                aberration_shader.uniform_float("backgroundShape", (float(record.background_depth_2d), float(record.background_flip_depth_2d), float(record.background_2d_enabled), float(record.background_3d_enabled)))
                aberration_shader.uniform_sampler("gradientTex", gradient_texture)
                aberration_shader.uniform_float("resolution", (float(width), float(height)))
                aberration_shader.uniform_float("aberration", aberration_amount * 100.0)
                aberration_shader.uniform_int("sampleCount", aberration_samples)
                aberration_shader.uniform_float("halftone", halftone_amount)
                aberration_shader.uniform_float("aberrationIntensity", 2.0)
                aberration_shader.uniform_float(
                    "aberrationTaper", motion_blur_amount,
                )
                aberration_shader.uniform_float("foreground", foreground)
                aberration_shader.uniform_float("background", background)
                aberration_shader.uniform_float(
                    "singleColorActive",
                    1.0 if len(logical_aberration_colors) == 1 else 0.0,
                )
                aberration_shader.uniform_float("singleColor", single_aberration_color)
                aberration_shader.uniform_float(
                    "blurSmoothing",
                    1.0 if getattr(record, "aberration_blur_smoothing", True) else 0.0,
                )
                aberration_shader.uniform_float(
                    "grainActive", 1.0 if grain_mask is not None else 0.0,
                )
                gpu.state.blend_set("NONE")
                batch.draw(aberration_shader)
            processed_surface = aberration_target

        if split_optics:
            # Each family transports its own ink through empty paper. Choosing
            # one nearest family after merging clips trails at a Voronoi seam.
            import sys
            optical_group_mask = multirig.copy_texture(sys.modules[__name__], mask.texture_color, width, height)
            mask = optical_group_mask
            combined = None
            for family in sorted(optical_families, key=lambda item: (0, 1, 3, 2).index(item)):
                payload = preview_family_payloads.get(family)
                if payload is None:
                    local = _optical_family_record(record, family)
                    payload = render_record(context, camera, local, preview=preview,
                        interactive_quality=interactive_quality, interactive_scale=interactive_scale,
                        pack_result=False, _rig_layer=True, _capture_override=capture)
                # Own a color copy before the next family can evict its cache.
                if combined is None:
                    combined = multirig.copy_texture(sys.modules[__name__], payload[0].texture_color, width, height)
                else:
                    merged = _offscreen(width,height,high_precision=True)
                    merge_shader = _shader("rig_merge", "fullscreen.vert", "rig_merge.frag")
                    with merged.bind():
                        for name, texture in (("backColor",combined.texture_color),
                            ("frontColor",payload[0].texture_color),
                            ("backMask",mask.texture_color),("frontMask",payload[1].texture_color),
                            ("backShape",shape_effect_texture),("frontShape",_empty_texture())):
                            merge_shader.uniform_sampler(name,texture)
                        merge_shader.uniform_float("paper",background)
                        # Background pigment is source-over, not per-channel
                        # darkest-color union with subject/radial pigment.
                        merge_shader.uniform_float("frontPigment", tuple(record.background_line_color))
                        merge_shader.uniform_int("outputMode",5 if family in (2,3) else 4)
                        merge_shader.uniform_int("frontRig",0)
                        gpu.state.blend_set("NONE")
                        batch.draw(merge_shader)
                    combined.free()
                    combined = merged
                optical_group_surfaces[:] = [combined]
            processed_surface = combined

        if _rig_layer:
            import sys
            owned_mask = multirig.copy_texture(sys.modules[__name__], mask.texture_color, width, height)
            retained_surface = processed_surface
            payload=(processed_surface, owned_mask, shape_mask_surface)
            _cache_put(_rig_layer_cache,layer_cache_key,payload,
                       sum(item.width*item.height for item in payload if item is not None),48_000_000)
            return payload
        if rig_composition:
            import sys
            owned_mask = multirig.copy_texture(sys.modules[__name__], mask.texture_color, width, height)
            rig_resources = [owned_mask]
            mask = owned_mask
            for rig_index, (_depth, local_record, local_capture) in enumerate(rig_plans):
                payload = render_record(context, camera, local_record, preview=preview,
                    interactive_quality=interactive_quality, interactive_scale=interactive_scale,
                    pack_result=False, _rig_layer=True, _capture_override=local_capture)
                layer_payloads = [payload]
                processed_surface, merged_mask, shape_effect_texture, new_resources = multirig.composite_layers(
                    sys.modules[__name__], processed_surface, mask.texture_color, shape_effect_texture,
                    layer_payloads, width, height, background, front_rig=rig_index+1)
                for old_surface in rig_resources:old_surface.free()
                rig_resources = new_resources
                mask = merged_mask
                # Payload surfaces belong to the bounded rig layer cache.
                layer_payloads = []
            if grain_mask is not None:
                # Generate and apply one population after all rig coverage is
                # assembled. Per-rig grain turned paper noise into opaque
                # layer coverage and repeatedly inverted overlapping rigs.
                grain_shader = _shader("grain", "fullscreen.vert", "grain.frag")
                with grain_mask.bind():
                    grain_shader.uniform_sampler("impactTex", mask.texture_color)
                    grain_shader.uniform_sampler("shapeMaskTex", shape_effect_texture)
                    _configure_grain_shader(grain_shader, record, width, height, paper_width, paper_height)
                    gpu.state.blend_set("NONE")
                    batch.draw(grain_shader)
                grain_target = grain_surface or final
                grain_apply = _shader("grain_apply", "fullscreen.vert", "grain_apply.frag")
                with grain_target.bind():
                    grain_apply.uniform_sampler("colorTex", processed_surface.texture_color)
                    grain_apply.uniform_sampler("grainTex", grain_mask.texture_color)
                    grain_apply.uniform_sampler("shapeMaskTex", shape_effect_texture)
                    grain_apply.uniform_float("foreground", foreground)
                    gpu.state.blend_set("NONE")
                    batch.draw(grain_apply)
                processed_surface = grain_target
        if tail_source_key is not None:
            import sys
            def own(texture):
                return multirig.copy_texture(sys.modules[__name__],texture,width,height)
            prefix=_TailPrefix(own(processed_surface.texture_color),own(mask.texture_color),
                own(shape_effect_texture),own(grain_mask.texture_color) if grain_mask is not None else None,
                foreground,background)
            _cache_put(_tail_source_cache,tail_source_key,prefix,width*height*(4 if grain_mask is not None else 3),12_500_000)
        output_surface=_finish_frame_effects(context,record,master_record,processed_surface,mask,
            shape_effect_texture,grain_mask,foreground,background,width,height,paper_width,paper_height,final,grade_source_key)
        if output_surface is not final:grade_surface=output_surface

        # Keep the interactive surface at its true reduced dimensions. The
        # viewport already filters that texture while scaling it to the camera
        # rectangle. Enlarging it back to output size here allocated and drew
        # a full-resolution offscreen on every mouse move, which erased the
        # performance benefit and caused visible input stalls.

        record = master_record
        global _preview_generation
        if preview:
            _preview_generation += 1
            name = f"{_image_name(camera, record)} - Preview {_preview_generation}"
        else:
            name = _image_name(camera, record)
        if preview and retain_gpu_preview and not apply_preview:
            # The output surface is already the exact image the artist must
            # see. Keep it on the GPU during interaction instead of forcing a
            # GPU readback, allocating a float Image, and uploading the same
            # pixels back to the viewport for every mouse event. Settle reads
            # and packs this identical surface once via promote_record_preview.
            key = (camera.name_full, int(record.salt))
            previous_surface = _preview_surfaces.pop(key, None)
            if previous_surface is not None:
                _free_surface(previous_surface[0])
            previous_name = _preview_images.pop(key, None)
            previous_image = bpy.data.images.get(previous_name) if previous_name else None
            if (previous_image is not None
                    and previous_image.name != str(record.cache_image)
                    and not previous_image.use_fake_user
                    and previous_image.users == 0):
                bpy.data.images.remove(previous_image)
            signature = _current_render_signature(record, context.scene)
            _preview_surfaces[key] = (
                output_surface, signature, int(width), int(height), name,
            )
            _preview_surfaces.move_to_end(key)
            while len(_preview_surfaces) > _PREVIEW_SURFACE_BUDGET:
                _old_key, old_surface = _preview_surfaces.popitem(last=False)
                _free_surface(old_surface[0])
                _preview_signatures.pop(_old_key, None)
            _preview_signatures[key] = signature
            retained_surface = output_surface
            _remember_preview_quality(camera, record, output_surface, exact_preview)
            return output_surface
        old_name = record.cache_image
        image = bpy.data.images.get(name)
        if image is not None and not image.is_float:
            bpy.data.images.remove(image)
            image = None
        if image is None:
            image = bpy.data.images.new(
                name, width=width, height=height, alpha=True, float_buffer=True,
            )
        try:
            image.colorspace_settings.name = "Non-Color"
        except TypeError:
            pass
        _write_offscreen_to_image(output_surface, image, width, height)
        _mark_display_upload(image.name_full)
        if preview:
            # GPU-only drag previews return above without creating an Image.
            # Any image-backed transient must be clean before control returns
            # to Blender's save dialog, even when it is not applied yet.
            if not apply_preview and not _internalize_image(image, pack=True):
                raise RuntimeError("Impact preview could not be embedded")
            if not apply_preview:
                image.use_fake_user = False  # Session alias, not an applied asset.
            # Publish only after the replacement has complete pixels. Retain
            # the previously displayed image through one further swap so an
            # image-backed GPU texture is never invalidated mid draw.
            _purge_retired_previews()
            key = (camera.name_full, int(record.salt))
            previous = _preview_images.get(key)
            _preview_images[key] = image.name
            _preview_signatures[key] = _current_render_signature(
                record, context.scene,
            )
            if previous and previous != image.name:
                _retired_preview_images.add(previous)
            if apply_preview:
                # The visible live result is the applied result. Do not issue
                # a second full-resolution render after the slider settles.
                # Applied slider pixels are project data, not an external
                # image-editor document. Packing here clears Image.is_dirty
                # immediately, preventing Blender's multi-image save prompt
                # while keeping the cache inside the .blend.
                if promote_record_preview(
                    camera, record, context.scene, pack=pack_result,
                ) is None:
                    raise RuntimeError("live preview could not be packed and promoted")
        else:
            if not _internalize_image(image, pack=pack_result):
                raise RuntimeError("Impact frame could not be embedded")
            record.cache_image = name
            record.cache_valid = True
            record.cache_signature = _current_render_signature(record, context.scene)
            record["_render_cache_version"] = _RENDER_CACHE_VERSION
            clear_record_preview(camera, record)
            if old_name and old_name != name:
                stale = bpy.data.images.get(old_name)
                if stale and stale.users == 0:
                    stale.use_fake_user = False
                    bpy.data.images.remove(stale)
        if grade_surface is not None:
            grade_surface.free()
            grade_surface = None
        if not preview:
            _remember_completed_display(camera, record, image, context.scene)
        return image
    finally:
        if shape_texture is not None:
            try:
                shape_texture.free()
            except (AttributeError, ReferenceError, RuntimeError):
                pass
        for group_surface in optical_group_surfaces:
            if group_surface is not retained_surface: group_surface.free()
        if optical_group_mask is not None: optical_group_mask.free()
        if preview_mask_surface is not None: preview_mask_surface.free()
        for surface in preview_family_surfaces: surface.free()
        if glitch_surface is not None and glitch_surface is not retained_surface:
            glitch_surface.free()
        if clean_motion_surface is not None:
            clean_motion_surface.free()
        if shape_surface is not None and shape_surface is not retained_surface:
            shape_surface.free()
        if (shape_mask_surface is not None and not _rig_layer
                and shape_mask_surface is not retained_surface):
            shape_mask_surface.free()
        layer_payloads.clear()  # Cache owns returned rig surfaces.
        for rig_surface in rig_resources:
            if rig_surface is not retained_surface: rig_surface.free()
        for surface in reversed(bloom_upsamples):
            if surface is not retained_surface:
                surface.free()
        for surface, _level_width, _level_height in reversed(bloom_levels):
            if surface is not retained_surface:
                surface.free()
        if bloom_emission is not None and bloom_emission is not retained_surface:
            bloom_emission.free()
        if (invert_before_bloom_surface is not None
                and invert_before_bloom_surface is not retained_surface):
            invert_before_bloom_surface.free()
        if chromatic is not None and chromatic is not retained_surface:
            chromatic.free()
        if motion_surface is not None and motion_surface is not retained_surface:
            motion_surface.free()
        if grain_surface is not None and grain_surface is not retained_surface:
            grain_surface.free()
        if pixelate_surface is not None and pixelate_surface is not retained_surface:
            pixelate_surface.free()
        if grain_distance_surface is not None:
            grain_distance_surface.free()
        if grain_mask is not None and grain_mask is not retained_surface:
            grain_mask.free()
        if composite_buffer is not None and composite_buffer is not retained_surface:
            composite_buffer.free()
        if grade_surface is not None and grade_surface is not retained_surface:
            grade_surface.free()
        if final is not retained_surface:
            final.free()



def cached_image(record):
    if not record or not record.cache_valid:
        return None
    image = bpy.data.images.get(record.cache_image)
    if not _valid_image(image):
        record.cache_valid = False
        record.cache_signature = ""
        return None
    return image


def display_image(camera, record, prefer_preview=True):
    key = (camera.name_full, int(record.salt)) if camera and record else None
    preview_name = _preview_images.get(key) if key and prefer_preview else None
    preview_image = bpy.data.images.get(preview_name) if preview_name else None
    if _valid_image(preview_image):
        return preview_image
    if preview_name:
        _preview_images.pop(key, None)
        _preview_signatures.pop(key, None)
        if preview_image is not None and preview_image.name != record.cache_image:
            _retired_preview_images.add(preview_image.name)
    return cached_image(record)


def display_surface(camera, record, prefer_preview=True):
    """Return the exact on-GPU interactive result, when one is active."""
    if not prefer_preview or camera is None or record is None:
        return None
    return _preview_surfaces.get((camera.name_full, int(record.salt)))


def clear_record_preview(camera, record):
    if camera is None or record is None:
        return
    key = (camera.name_full, int(record.salt))
    _full_quality_previews.pop(key, None)
    surface_entry = _preview_surfaces.pop(key, None)
    if surface_entry is not None:
        _free_surface(surface_entry[0])
    name = _preview_images.pop(key, None)
    _preview_signatures.pop(key, None)
    image = bpy.data.images.get(name) if name else None
    if (image is not None and image.name != str(record.cache_image)
            and not image.use_fake_user and image.users == 0):
        bpy.data.images.remove(image)
    _purge_retired_previews()


def clear_transient_previews():
    """Drop session-only presentation aliases without deleting applied caches."""
    names = set(_preview_images.values()) | set(_retired_preview_images)
    for surface_entry in tuple(_preview_surfaces.values()):
        _free_surface(surface_entry[0])
    _preview_surfaces.clear()
    _full_quality_previews.clear()
    _preview_images.clear()
    _preview_signatures.clear()
    _retired_preview_images.clear()
    referenced = {
        str(record.cache_image)
        for owner in getattr(bpy.data, "objects", ())
        for record in getattr(owner, "impaction_frames", ())
        if record.cache_image
    }
    for name in names:
        image = bpy.data.images.get(name)
        if (image is not None and name not in referenced
                and not image.use_fake_user and image.users == 0):
            bpy.data.images.remove(image)


def _purge_retired_previews():
    referenced = {
        str(record.cache_image)
        for owner in getattr(bpy.data, "objects", ())
        for record in getattr(owner, "impaction_frames", ())
        if record.cache_image
    }
    for name in tuple(_retired_preview_images):
        image = bpy.data.images.get(name)
        if (image is not None and name not in referenced
                and not image.use_fake_user and image.users == 0):
            bpy.data.images.remove(image)
        _retired_preview_images.discard(name)


def schedule_preview_cleanup():
    """Release superseded derived images after presentation has swapped."""
    if not bpy.app.timers.is_registered(collect_abandoned_previews):
        bpy.app.timers.register(collect_abandoned_previews,first_interval=0.25)


def collect_abandoned_previews():
    """Bound cleanup to idle slices; keep only names, never retained RNA."""
    from . import impaction_runtime as runtime
    if runtime._rendering_live or runtime._live_suspended or runtime._preview_pointer_held:
        return 0.25
    referenced={str(r.cache_image) for obj in bpy.data.objects
                for r in getattr(obj,'impaction_frames',()) if r.cache_image}
    referenced.update(_preview_images.values())
    referenced.update(entry[3] for entry in _undo_display_history.values()
                      if isinstance(entry[3],str))
    # Editors can hold a displayed image without a conventional ID user.
    for screen in bpy.data.screens:
        for area in screen.areas:
            for space in area.spaces:
                if space.type=='IMAGE_EDITOR' and space.image is not None:
                    referenced.add(space.image.name)
    candidates=[im.name for im in bpy.data.images if im.name.startswith(CACHE_PREFIX)
                and ' - Preview ' in im.name and im.name not in referenced
                and not im.use_fake_user and im.users==0]
    started=time.perf_counter()
    for index,name in enumerate(candidates):
        image=bpy.data.images.get(name)
        if image is not None:
            size=int(image.size[0])*int(image.size[1])*(16 if image.is_float else 4)
            bpy.data.images.remove(image)
            _retired_preview_images.discard(name)
            _display_upload_seen.pop(name,None)
            _cache_diagnostics['orphan_preview_images_removed']+=1
            _cache_diagnostics['orphan_preview_bytes_released']+=size
        if index>=3 or time.perf_counter()-started>=0.004:
            return 0.05 if index+1<len(candidates) else None
    return None


def _viewport_safe_bounds(context):
    """Return WINDOW-local bounds not covered by overlapping area regions."""
    region = getattr(context, "region", None)
    area = getattr(context, "area", None)
    if region is None:
        return (0.0, 0.0, 1.0, 1.0)
    margin = 4.0
    left, bottom = margin, margin
    right = max(left + 1.0, float(region.width) - margin)
    top = max(bottom + 1.0, float(region.height) - margin)
    if area is None:
        return left, bottom, right, top
    window_x = float(getattr(region, "x", 0.0))
    window_y = float(getattr(region, "y", 0.0))
    for obstacle in getattr(area, "regions", ()):
        if obstacle is region or int(getattr(obstacle, "width", 0)) <= 0 or int(getattr(obstacle, "height", 0)) <= 0:
            continue
        kind = str(getattr(obstacle, "type", ""))
        if kind not in {"HEADER", "TOOL_HEADER", "UI", "TOOLS", "HUD", "NAVIGATION_BAR"}:
            continue
        ox0 = float(getattr(obstacle, "x", 0.0)) - window_x
        oy0 = float(getattr(obstacle, "y", 0.0)) - window_y
        ox1 = ox0 + float(obstacle.width)
        oy1 = oy0 + float(obstacle.height)
        if ox1 <= 0.0 or oy1 <= 0.0 or ox0 >= region.width or oy0 >= region.height:
            continue
        if kind in {"HEADER", "TOOL_HEADER"}:
            if oy0 >= float(region.height) * 0.5:
                top = min(top, oy0 - margin)
            else:
                bottom = max(bottom, oy1 + margin)
        elif ox0 >= float(region.width) * 0.5:
            right = min(right, ox0 - margin)
        else:
            left = max(left, ox1 + margin)
    return left, bottom, max(left + 1.0, right), max(bottom + 1.0, top)


def camera_view_rect(context, camera):
    region = context.region
    region_3d = context.space_data.region_3d
    # Extension reloads can momentarily invoke a surviving POST_PIXEL handler
    # with a transitioning or non-camera region. Never turn a failed camera
    # projection into a full-viewport rectangle: an invalid/black managed
    # texture would otherwise cover the entire 3D view.
    if (region is None or region_3d is None or
            region_3d.view_perspective != "CAMERA"):
        return None
    points = []
    for corner in camera.data.view_frame(scene=context.scene):
        point = view3d_utils.location_3d_to_region_2d(
            region, region_3d, camera.matrix_world @ corner
        )
        if point is not None:
            points.append(point)
    if len(points) != 4:
        return None
    xs = [point.x for point in points]
    ys = [point.y for point in points]
    rect = min(xs), min(ys), max(xs), max(ys)
    if (not all(math.isfinite(value) for value in rect) or
            rect[2] - rect[0] < 2.0 or rect[3] - rect[1] < 2.0):
        return None
    # This projected rectangle is also Blender's reference-camera rectangle.
    # Independently shrinking or recentering only the Impact overlay makes the
    # subject visibly drift against the live camera plate. Presentation clips
    # this exact rectangle to safe UI bounds and supplies an opaque black matte
    # around it instead.
    return rect


def _viewport_shader():
    global _display_shader
    if _display_shader is None:
        try:
            _display_shader = (gpu.shader.from_builtin("IMAGE_COLOR"), True)
        except ValueError:
            _display_shader = (gpu.shader.from_builtin("IMAGE"), False)
    return _display_shader


def _viewport_texture(image):
    # Blender owns and invalidates image-backed GPU textures. Request its
    # managed handle without freeing a cache merely because the image was not
    # drawn recently. A sequence of applied Impact frames naturally revisits
    # each image after a gap; time-based gl_free()/update() turned that cheap
    # visibility change into a full-frame GPU upload on every recurrence.
    # Explicit image writes and clear_session_caches() already invalidate the
    # managed texture at the lifecycle boundaries where pixels can change.
    now = time.monotonic()
    image_key = image.name_full
    _mark_display_upload(image_key, now)
    try:
        # Prevent Blender's idle image collector from retiring the cache while
        # the user works outside camera view for an extended period.
        image.gl_touch()
    except (AttributeError, ReferenceError, RuntimeError):
        pass
    texture = gpu.texture.from_image(image)
    _enable_linear_filter(texture)
    return texture


_VIEWPORT_OVERREACH = 1.5
_VIEWPORT_EDGE_MARGIN = 2.0


def _workspace_is_presentation(context):
    """Return whether this draw belongs to an exact-fit output workspace."""
    area = getattr(context, "area", None)
    window = getattr(context, "window", None)
    workspace = getattr(window, "workspace", None)
    if area is not None:
        try:
            if window is None or area not in window.screen.areas:
                window = None
        except (AttributeError, ReferenceError, TypeError):
            window = None
        if window is None:
            manager = getattr(context, "window_manager", None)
            for candidate in getattr(manager, "windows", ()):
                try:
                    if area in candidate.screen.areas:
                        workspace = candidate.workspace
                        break
                except (AttributeError, ReferenceError, TypeError):
                    continue
    if workspace is None:
        workspace = getattr(context, "workspace", None)
    try:
        workspace_name = str(workspace.name).strip().casefold()
        if workspace_name.rsplit(".", 1)[-1].isdigit():
            workspace_name = workspace_name.rsplit(".", 1)[0]
    except (AttributeError, ReferenceError, TypeError, ValueError):
        return False
    return workspace_name in {"preview", "audio"}


def _presentation_image_rect(context, width, height):
    """Aspect-fit a cached frame inside the unobstructed presentation canvas."""
    left, bottom, right, top = _viewport_safe_bounds(context)
    available_width = max(1.0, right - left)
    available_height = max(1.0, top - bottom)
    image_aspect = max(1.0, float(width)) / max(1.0, float(height))
    canvas_aspect = available_width / available_height
    if canvas_aspect > image_aspect:
        draw_height = available_height
        draw_width = draw_height * image_aspect
    else:
        draw_width = available_width
        draw_height = draw_width / image_aspect
    center_x = (left + right) * 0.5
    center_y = (bottom + top) * 0.5
    return (
        center_x - draw_width * 0.5, center_y - draw_height * 0.5,
        center_x + draw_width * 0.5, center_y + draw_height * 0.5,
    )


def _viewport_navigation_rects(context):
    """Keep native navigation gizmos visible beneath our POST_PIXEL overlay.

    Layout follows Blender's view3d_gizmo_navigate.cc. These are display-only
    exclusions: neither the camera projection nor the exported image changes.
    """
    space = getattr(context, "space_data", None)
    if not (getattr(space, "show_gizmo", False) and
            getattr(space, "show_gizmo_navigate", False)):
        return ()
    preferences = context.preferences
    view = preferences.view
    scale = float(preferences.system.ui_scale)
    axis = getattr(view, "mini_axis_type", "GIZMO")
    # Safe bounds include a four-pixel margin; Blender's visible rectangle
    # anchors its widgets directly to the overlapping region edges.
    _, _, right, top = _viewport_safe_bounds(context)
    right += 4.0
    top += 4.0
    size = float(getattr(view, "gizmo_size_navigate_v3d", 80))
    offset = scale * (10.0 + (size * 0.5 if axis == "GIZMO" else 0.0))
    rects = []
    if axis == "GIZMO":
        cx, cy = right - offset, top - offset
        radius = scale * (size * 0.5 + 4.0)
        rects.append((cx - radius, cy - radius, cx + radius, cy + radius))
    if getattr(view, "show_gizmo", True):
        step = 30.0 * scale
        if axis == "GIZMO":
            axis_offset = offset * 2.2
        elif axis == "MINIMAL":
            axis_offset = scale * (40.0 + float(view.mini_axis_size) * 1.6)
        else:
            axis_offset = step * 0.75
        cx, cy = round(right - step * 0.75), round(top - axis_offset)
        radius = 17.0 * scale
        rects.append((cx - radius, cy - 3.0 * step - radius,
                      cx + radius, cy + radius))
    return tuple(rects)


def _viewport_uncovered_rects(rect, exclusions):
    """Subtract UI rectangles without rescaling any of the image pieces."""
    pieces = [rect] if rect[2] > rect[0] and rect[3] > rect[1] else []
    for ex0, ey0, ex1, ey1 in exclusions:
        remaining = []
        for x0, y0, x1, y1 in pieces:
            ix0, iy0 = max(x0, ex0), max(y0, ey0)
            ix1, iy1 = min(x1, ex1), min(y1, ey1)
            if ix0 >= ix1 or iy0 >= iy1:
                remaining.append((x0, y0, x1, y1))
                continue
            remaining.extend(piece for piece in (
                (x0, y0, x1, iy0), (x0, iy1, x1, y1),
                (x0, iy0, ix0, iy1), (ix1, iy0, x1, iy1),
            ) if piece[2] > piece[0] and piece[3] > piece[1])
        pieces = remaining
    return pieces


def _viewport_batch(shader, context, rect, width, height):
    region = getattr(context, "region", None)
    region_key = region.as_pointer() if region is not None and hasattr(region, "as_pointer") else id(region)
    x0, y0, x1, y1 = rect
    width = max(1.0, float(width))
    height = max(1.0, float(height))
    presentation = _workspace_is_presentation(context)
    safe_bounds = (_viewport_safe_bounds(context) if presentation else
                   (0.0, 0.0, float(region.width), float(region.height)))
    navigation = _viewport_navigation_rects(context)
    key = (
        region_key, round(x0, 3), round(y0, 3), round(x1, 3), round(y1, 3),
        presentation, safe_bounds, navigation,
        int(width), int(height),
        int(getattr(region, "width", 0)), int(getattr(region, "height", 0)),
        shader.as_pointer() if hasattr(shader, "as_pointer") else id(shader),
    )
    batch = _display_batches.pop(key, None)
    if batch is not None:
        _display_batches[key] = batch
        return batch
    # Preview and Audio are exact-fit presentation outputs and must never show
    # extension pixels. Ordinary workspaces retain the camera-outline cover,
    # but extend the complete final image (linework and post effects together)
    # instead of repeating one edge texel or painting a mismatched solid band.
    overscan = 0.0 if presentation else _VIEWPORT_OVERREACH
    desired_x0, desired_y0 = x0 - overscan, y0 - overscan
    desired_x1, desired_y1 = x1 + overscan, y1 + overscan
    safe_x0, safe_y0, safe_x1, safe_y1 = safe_bounds
    clipped_x0 = max(safe_x0, desired_x0)
    clipped_y0 = max(safe_y0, desired_y0)
    clipped_x1 = min(safe_x1, desired_x1)
    clipped_y1 = min(safe_y1, desired_y1)
    span_x = max(1.0e-6, desired_x1 - desired_x0)
    span_y = max(1.0e-6, desired_y1 - desired_y0)
    positions = []
    for left, bottom, right, top in _viewport_uncovered_rects(
            (clipped_x0, clipped_y0, clipped_x1, clipped_y1), navigation):
        positions.extend(((left, bottom), (right, bottom), (right, top),
                          (left, bottom), (right, top), (left, top)))
    texcoords = [((x - desired_x0) / span_x, (y - desired_y0) / span_y)
                 for x, y in positions]
    batch = batch_for_shader(
        shader, "TRIS", {"pos": positions, "texCoord": texcoords},
    )
    _display_batches[key] = batch
    while len(_display_batches) > _DISPLAY_BATCH_BUDGET:
        _display_batches.popitem(last=False)
    return batch


def _viewport_visible_rect(context, rect):
    """Return the exact UI-safe portion of the projected camera rectangle."""
    x0, y0, x1, y1 = rect
    safe_x0, safe_y0, safe_x1, safe_y1 = _viewport_safe_bounds(context)
    if not _workspace_is_presentation(context):
        safe_x0, safe_y0 = 0.0, 0.0
        safe_x1, safe_y1 = float(context.region.width), float(context.region.height)
    return (
        max(safe_x0, x0),
        max(safe_y0, y0),
        min(safe_x1, x1),
        min(safe_y1, y1),
    )


def _composition_thirds_segments(rect):
    x0, y0, x1, y1 = rect
    x_third = (x1 - x0) / 3.0
    y_third = (y1 - y0) / 3.0
    return (
        (x0 + x_third, y0), (x0 + x_third, y1),
        (x0 + x_third * 2.0, y0), (x0 + x_third * 2.0, y1),
        (x0, y0 + y_third), (x1, y0 + y_third),
        (x0, y0 + y_third * 2.0), (x1, y0 + y_third * 2.0),
    )


def _draw_camera_composition_guides(camera, rect):
    # POST_PIXEL impact images sit above Blender's native camera guides, so
    # restore the enabled thirds guide after the opaque replacement image.
    if not getattr(camera.data, "show_composition_thirds", False):
        return
    shader = gpu.shader.from_builtin("UNIFORM_COLOR")
    batch = batch_for_shader(
        shader, "LINES", {"pos": _composition_thirds_segments(rect)},
    )
    gpu.state.blend_set("ALPHA")
    shader.uniform_float("color", (0.72, 0.72, 0.72, 0.52))
    batch.draw(shader)
    gpu.state.blend_set("NONE")


def _draw_viewport_matte(context, rect):
    """Black out presentation letterbox without covering ordinary viewport UI."""
    region = getattr(context, "region", None)
    if region is None:
        return
    presentation=_workspace_is_presentation(context)
    camera=getattr(getattr(context,"space_data",None),"camera",None) or context.scene.camera
    if not presentation and (camera is None or not camera.data.show_passepartout):
        return
    # Draw the matte in pixel space in every enabled camera view. Blender's
    # native passepartout does not cover UI-safe clipping strips at deep zoom.
    x0, y0 = 0.0, 0.0
    x1, y1 = float(region.width), float(region.height)
    rx0, ry0, rx1, ry1 = _viewport_visible_rect(context, rect)
    rx0, rx1 = max(x0, rx0), min(x1, rx1)
    ry0, ry1 = max(y0, ry0), min(y1, ry1)
    shader = gpu.shader.from_builtin("UNIFORM_COLOR")
    gpu.state.blend_set("NONE")
    shader.uniform_float("color", (0.0, 0.0, 0.0, 1.0))
    navigation = _viewport_navigation_rects(context)
    for matte_rect in (
        (x0, y0, x1, ry0), (x0, ry1, x1, y1),
        (x0, ry0, rx0, ry1), (rx1, ry0, x1, ry1),
    ):
        for left, bottom, right, top in _viewport_uncovered_rects(matte_rect, navigation):
            batch_for_shader(
                shader, "TRI_FAN",
                {"pos": ((left, bottom), (right, bottom),
                         (right, top), (left, top))},
            ).draw(shader)


# Immutable, bounded snapshots of completed displays survive native RNA undo.
# Blender can restore Image properties without restoring its generated pixels.
_undo_display_history = OrderedDict()
_undo_display_pending = set()
_UNDO_DISPLAY_BYTES = 128 * 1024 * 1024


def invalidate_undo_display():
    _signature_cache.clear()
    _signature_revisions.clear()
    _undo_display_pending.update(
        (camera.name_full, int(record.salt))
        for camera in bpy.data.objects if camera.type == "CAMERA"
        for record in getattr(camera, "impaction_frames", ())
    )


def _drop_undo_snapshot(entry):
    if len(entry) > 4 and entry[4] is not None:
        _free_surface(entry[4])
    name = entry[3]
    image = bpy.data.images.get(name) if isinstance(name, str) else None
    if image is not None:
        referenced = any(record.cache_image == name
            for camera in bpy.data.objects if camera.type == "CAMERA"
            for record in getattr(camera, "impaction_frames", ()))
        if not referenced:
            image.use_fake_user = False
            if image.users == 0:
                bpy.data.images.remove(image)


def prepare_undo_display():
    """Rehydrate immutable pixels after native undo, outside handlers/draw."""
    for camera in bpy.data.objects:
        if camera.type != "CAMERA":
            continue
        for record in getattr(camera, "impaction_frames", ()):
            key = (camera.name_full, int(record.salt))
            if key not in _undo_display_pending:
                continue
            signature = _current_render_signature(record, bpy.context.scene)
            entry = _undo_display_history.get((*key, signature))
            if entry is None:
                continue
            pixels, width, height, _name = entry[:4]
            name = ".Impaction Undo Display - " + hashlib.sha256(repr((*key, signature)).encode()).hexdigest()[:24]
            image = bpy.data.images.get(name)
            if image is None:
                image = bpy.data.images.new(name, width=width, height=height,
                    alpha=True, float_buffer=True)
            image.colorspace_settings.name = "Non-Color"
            image.pixels.foreach_set(pixels)
            image.update()
            _internalize_image(image, pack=True)
            entry[3] = image.name
            record.cache_image = image.name
            record.cache_valid = True
            record.cache_signature = signature
            record["_render_cache_version"] = _RENDER_CACHE_VERSION
            _undo_display_pending.discard(key)
            from .impaction_runtime import cancel_pending_live_render
            cancel_pending_live_render(camera, record)
            # Rehydrate at most one datablock per UI tick. The immutable
            # texture already supplies the restored picture in the meantime.
            return 0.01
    return None


def _undo_snapshot_texture(entry):
    """Upload immutable pixels directly, without waiting for RNA restoration."""
    if len(entry) == 4:
        entry.append(None)
    if entry[4] is None:
        pixels, width, height = entry[:3]
        entry[4] = gpu.types.GPUTexture((width, height), format="RGBA16F",
            data=gpu.types.Buffer("FLOAT", pixels.size, pixels))
        _enable_linear_filter(entry[4])
    return entry[4]


def _remember_completed_display(camera, record, image, scene):
    if image.name != record.cache_image or not cache_matches_record(record, scene):
        return
    key = (camera.name_full, int(record.salt), _current_render_signature(record, scene))
    if key in _undo_display_history:
        _undo_display_history.move_to_end(key)
        return
    width, height = map(int, image.size)
    size = width * height * 16
    if size > _UNDO_DISPLAY_BYTES:
        return
    while _undo_display_history and sum(item[0].nbytes for item in _undo_display_history.values()) + size > _UNDO_DISPLAY_BYTES:
        _old_key, old = _undo_display_history.popitem(last=False)
        _drop_undo_snapshot(old)
    pixels = np.empty(width * height * 4, dtype=np.float32)
    image.pixels.foreach_get(pixels)
    _undo_display_history[key] = [pixels, width, height, None, None]


def draw_cached_image(context, camera, record, opacity=1.0, prefer_preview=True):
    history = None
    display_key = (camera.name_full, int(record.salt))
    if display_key in _undo_display_pending:
        history_key = (*display_key, _current_render_signature(record, context.scene))
        history = _undo_display_history.get(history_key)
        if history is not None:
            _undo_display_history.move_to_end(history_key)
        else:
            # An evicted undo state needs a rebuild. Keep the most recent
            # completed frame visible until its replacement is ready.
            history = next((entry for key, entry in reversed(_undo_display_history.items())
                            if key[:2] == display_key), None)
    surface_entry = display_surface(
        camera, record, prefer_preview=prefer_preview,
    )
    if history is not None:
        _pixels, width, height = history[:3]
        texture = _undo_snapshot_texture(history)
    elif surface_entry is not None:
        surface, _signature, width, height, _name = surface_entry
        texture = surface.texture_color
    else:
        image = display_image(camera, record, prefer_preview=prefer_preview)
        if image is None:
            return False
        width, height = int(image.size[0]), int(image.size[1])
        texture = _viewport_texture(image)
        # Playback is a texture presentation path. Copying full float images
        # into undo history here can thrash that history during a long sequence.
        # Editing/Apply and idle display capture undo snapshots instead.
        if prefer_preview:
            _remember_completed_display(camera, record, image, context.scene)
    rect = camera_view_rect(context, camera)
    if rect is None and _workspace_is_presentation(context):
        rect = _presentation_image_rect(context, width, height)
    if rect is None:
        # No valid camera projection means there is intentionally nothing to
        # draw. Treat it as handled so the runtime does not schedule a costly
        # frame regeneration merely because another extension is reloading.
        return True
    shader, tinted = _viewport_shader()
    _draw_viewport_matte(context, rect)
    batch = _viewport_batch(shader, context, rect, width, height)
    gpu.state.blend_set("ALPHA")
    shader.uniform_sampler("image", texture)
    if tinted:
        shader.uniform_float("color", (1.0, 1.0, 1.0, float(opacity)))
    batch.draw(shader)
    gpu.state.blend_set("NONE")
    _draw_camera_composition_guides(camera, rect)
    return True


def _draw_perspective_link(a,b):
    delta=(b[0]-a[0],b[1]-a[1])
    length=math.hypot(*delta)
    if length<22.0:return
    direction=(delta[0]/length,delta[1]/length)
    normal=(-direction[1],direction[0])
    diamond_axis=max(abs(direction[0])+abs(direction[1]),1e-6)
    start=6.0/diamond_axis
    end=length-13.0/diamond_axis
    if end<=start:return
    vertices=[];colors=[];indices=[]
    # Feather both sides and both ends; never overpaint either diamond.
    for i,(t,alpha) in enumerate(((0.,0.),(.12,.68),(.40,.52),(.75,.27),(1.,0.))):
        distance=start+(end-start)*t
        for side,weight in ((-1.4,0.),(0.,1.),(1.4,0.)):
            vertices.append((a[0]+direction[0]*distance+normal[0]*side,
                             a[1]+direction[1]*distance+normal[1]*side))
            colors.append((.12,.92,.14,alpha*weight))
        if i:
            for side in range(2):
                j=(i-1)*3+side;k=i*3+side
                indices.extend(((j,j+1,k),(j+1,k+1,k)))
    shader=gpu.shader.from_builtin("SMOOTH_COLOR")
    batch_for_shader(shader,"TRIS",{"pos":vertices,"color":colors},indices=indices).draw(shader)


def draw_camera_pin_overlays(context,camera,record):
    """Flat region-pixel UI, independent of the scene's view/depth matrix."""
    from mathutils import Matrix
    width=max(1,context.region.width);height=max(1,context.region.height)
    projection=Matrix(((2.0/width,0,0,-1),(0,2.0/height,0,-1),(0,0,-1,0),(0,0,0,1)))
    depth=gpu.state.depth_test_get()
    with gpu.matrix.push_pop(),gpu.matrix.push_pop_projection():
        gpu.matrix.load_identity();gpu.matrix.load_projection_matrix(projection)
        gpu.state.depth_test_set("NONE")
        try:_draw_camera_pin_pixels(context,camera,record)
        finally:gpu.state.depth_test_set(depth)


def _draw_camera_pin_pixels(context, camera, record):
    """Draw camera pins above the opaque replacement; gizmos supply input."""
    if record is None:
        return
    from .impaction_gizmo import pin_highlighted
    from .impaction_perspective import active, handle
    rect = camera_view_rect(context, camera)
    if rect is None:
        return
    x0, y0, x1, y1 = rect
    shader = gpu.shader.from_builtin("UNIFORM_COLOR")
    gpu.state.blend_set("ALPHA")
    pins = []
    selected_shapes = {
        index for index, shape in enumerate(record.shapes)
        if bool(getattr(shape, "is_selected", False))
    }
    if not selected_shapes:
        pins.append(("DIRECTION", direction_pin_position(record), (1.0, 0.0, 1.0), False))
        if (bool(getattr(record, "background_2d_enabled", True)) or
                bool(getattr(record, "background_3d_enabled", False))):
            pins.append((
                "BACKGROUND",
                getattr(record, "background_focus", (0.625, 0.5)),
                (0.0, 1.0, 1.0), False,
            ))
        pins.append(("LIGHT", record.light_focus, (1.0, 1.0, 0.0), False))
    for index, shape in enumerate(record.shapes):
        if index >= 16:
            break
        pins.append((
            f"SHAPE:{index}", shape.position, (0.12, 0.92, 0.14),
            index in selected_shapes,
        ))
    for index, shape in enumerate(record.shapes[:16]):
        if active(context,camera,record,index):
            point=handle(shape,rect)
            pins.append((f"PERSPECTIVE:{index}",point,(0.12,0.92,0.14),True))
            a=(x0+point[0]*(x1-x0),y0+point[1]*(y1-y0))
            b=(x0+shape.position[0]*(x1-x0),y0+shape.position[1]*(y1-y0))
            _draw_perspective_link(a,b)
    for role, point, color, selected in pins:
        pin_rect = direction_control_rect(context, camera, record) if role == "DIRECTION" else rect
        px0, py0, px1, py1 = pin_rect
        x = px0 + float(point[0]) * (px1 - px0)
        y = py0 + float(point[1]) * (py1 - py0)
        size = 6.0 if role.startswith("PERSPECTIVE:") else (13.0 if selected else 10.0)
        vertices = (
            (x, y + size), (x + size, y), (x, y - size),
            (x, y + size), (x, y - size), (x - size, y),
        )
        batch = batch_for_shader(shader, "TRIS", {"pos": vertices})
        highlighted = pin_highlighted(role)
        alpha = 1.0 if selected else (0.96 if highlighted else 0.62)
        if role.startswith("SHAPE:") and active(context,camera,record,int(role.split(":")[1])):
            alpha=0.22
        shader.uniform_float("color", (*color, alpha))
        batch.draw(shader)
    gpu.state.blend_set("NONE")


def clear_shader_cache():
    global _display_shader, _brush_texture, _loaded_brush_texture
    for name in tuple(_preview_images.values()):
        image = bpy.data.images.get(name)
        if image is not None and image.users == 0:
            bpy.data.images.remove(image)
    _purge_retired_previews()
    clear_session_caches()
    _display_shader = None
    if _brush_texture is not None:
        try:
            _brush_texture.free()
        except (AttributeError, ReferenceError, RuntimeError):
            pass
        _brush_texture = None
    if _loaded_brush_texture is not None:
        try:
            _loaded_brush_texture.free()
        except (AttributeError, ReferenceError, RuntimeError):
            pass
        _loaded_brush_texture = None
    _shaders.clear()


def warm_interactive_resources():
    """Compile one missing stage per idle tick, including cold optical passes."""
    if bpy.app.background:
        return True
    _brush_atlas()
    _loaded_brush_atlas()
    stages = (
        ("geometry", "geometry.vert"), ("impact", "fullscreen.vert"),
        ("linear_depth", "linear_depth.vert"), ("linear_surface", "linear_surface.vert"),
        ("composite", "fullscreen.vert"), ("effect_direction", "fullscreen.vert"),
        ("motion_blur", "fullscreen.vert"), ("aberration_blend", "fullscreen.vert"),
        ("impact_layers", "fullscreen.vert"), ("rig_merge", "fullscreen.vert"),
        ("glitch", "fullscreen.vert"),
    )
    for name, vertex in stages:
        if name not in _shaders:
            _shader(name, vertex, name + ".frag")
            return False
    return True


def invalidate_history_geometry():
    global _capture_cache_bytes
    _capture_cache.clear();_capture_cache_bytes=0
    _signature_cache.clear();_signature_revisions.clear()
    _trail_capture_revisions.clear()
    for cache in (_motion_result_cache, _tail_source_cache, _grade_source_cache,_rig_layer_cache,_effect_field_cache,_radial_mask_cache,_raster_cache,_mask_cache,_owner_geometry_cache,
                  _linear_depth_cache,_linear_stroke_cache,_linear_batch_cache):
        for value,_weight in cache.values():
            for surface in (value if isinstance(value,tuple) else (value,)):
                _free_surface(surface)
        cache.clear()
    _interactive_mask_keys.clear()


def clear_session_caches():
    """Discard file-local CPU/GPU state while retaining saved datablocks."""
    global _radial_seed_scratch
    if _radial_seed_scratch is not None:
        _radial_seed_scratch.free()
        _radial_seed_scratch = None
    global _fullscreen_batch, _empty_rgba_texture, _capture_cache_bytes, _background_family_scratch
    if _background_family_scratch is not None:
        _background_family_scratch.free()
        _background_family_scratch = None
    for cache in (_motion_result_cache, _tail_source_cache, _grade_source_cache, _rig_layer_cache, _effect_field_cache, _radial_mask_cache, _raster_cache, _mask_cache, _owner_geometry_cache, _linear_depth_cache, _linear_stroke_cache, _linear_batch_cache):
        for value, _weight in cache.values():
            surfaces = value if isinstance(value, tuple) else (value,)
            for surface in surfaces:
                _free_surface(surface)
        cache.clear()
    _interactive_mask_keys.clear()
    for name in set(_preview_images.values()) | _retired_preview_images:
        image = bpy.data.images.get(name)
        if image is not None and image.users == 0:
            bpy.data.images.remove(image)
    for surface_entry in tuple(_preview_surfaces.values()):
        _free_surface(surface_entry[0])
    _preview_surfaces.clear()
    _full_quality_previews.clear()
    _preview_images.clear()
    _preview_signatures.clear()
    _retired_preview_images.clear()
    if bpy.app.timers.is_registered(prepare_undo_display):
        bpy.app.timers.unregister(prepare_undo_display)
    for entry in _undo_display_history.values():
        _drop_undo_snapshot(entry)
    _undo_display_history.clear()
    _undo_display_pending.clear()
    _display_batches.clear()
    _display_upload_seen.clear()
    _capture_cache.clear()
    _capture_cache_bytes = 0
    _signature_revisions.clear()
    _signature_cache.clear()
    _fullscreen_batch = None
    for texture in tuple(_gradient_textures.values()):
        try:
            texture.free()
        except (AttributeError, ReferenceError, RuntimeError):
            pass
    _gradient_textures.clear()
    _readback_buffers.clear()
    if _empty_rgba_texture is not None:
        try:
            _empty_rgba_texture.free()
        except (AttributeError, ReferenceError, RuntimeError):
            pass
        _empty_rgba_texture = None
    # Saved cache pixels live in Blender image datablocks, but their managed
    # GPU handles may outlive an extension reload or a long viewport absence.
    # Free only those handles so the next draw re-uploads the preserved pixels
    # instead of presenting a stale all-black texture.
    try:
        images = tuple(bpy.data.images)
    except (AttributeError, RuntimeError):
        # Extension registration can call load handlers while Blender exposes
        # _RestrictData. The real load_post call refreshes images once normal
        # datablock access is restored.
        images = ()
    for image in images:
        if not image.name.startswith(CACHE_PREFIX):
            continue
        try:
            image.gl_free()
            image.update()
        except (AttributeError, ReferenceError, RuntimeError):
            pass

    _clear_surface_pool()
