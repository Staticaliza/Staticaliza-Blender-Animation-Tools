"""GPU mask/velocity rasterization and procedural impact-frame rendering."""

from pathlib import Path
from collections import OrderedDict
from array import array
import hashlib
import math
import time

import bpy
import gpu
import numpy as np
from gpu_extras.batch import batch_for_shader
from bpy_extras import view3d_utils

from .impaction_capture import (
    CaptureGeometry, ImpactCapture, capture_current_impact, capture_impact,
    capture_impacts,
)
from .impaction_constants import CACHE_PREFIX
from .impaction_gradient import (
    aberration_colors, aberration_gradient_samples, aberration_ramp_signature,
)

_SHADER_DIR = Path(__file__).with_name("shaders")
_shaders = {}
_capture_cache = OrderedDict()
_capture_cache_bytes = 0
_raster_cache = OrderedDict()
_mask_cache = OrderedDict()
_preview_images = {}
_preview_signatures = {}
_preview_surfaces = {}
_retired_preview_images = set()
_preview_generation = 0
_display_batches = OrderedDict()
_display_upload_seen = OrderedDict()
_signature_revisions = OrderedDict()
_signature_cache = OrderedDict()
_gradient_textures = OrderedDict()
_readback_buffers = OrderedDict()
_display_shader = None
_brush_texture = None
_fullscreen_batch = None
_empty_rgba_texture = None
_RASTER_PIXEL_BUDGET = 20_000_000
_MASK_PIXEL_BUDGET = 10_000_000
_CAPTURE_BYTE_BUDGET = 128 * 1024 * 1024
_DISPLAY_BATCH_BUDGET = 24
_DISPLAY_UPLOAD_BUDGET = 64
_SIGNATURE_CACHE_BUDGET = 4096
_GRADIENT_TEXTURE_BUDGET = 24
_READBACK_BUFFER_BUDGET = 2
_READBACK_BYTE_BUDGET = 64 * 1024 * 1024
# Increment only when a renderer/shader change makes persisted pixels unsafe
# to reuse. Old frames keep their capture geometry and regenerate on first
# visible draw instead of showing a stale or black image after an update.
_RENDER_CACHE_VERSION = 92


def _source(name):
    return (_SHADER_DIR / name).read_text(encoding="utf-8")


def _shader_body(name):
    lines = _source(name).splitlines()
    return "\n".join(
        line for line in lines
        # CreateInfo supplies only file-scope interfaces. Preserve indented
        # `out` parameters in multiline GLSL function signatures; stripping
        # those made the full impact shader syntactically invalid while the
        # compatibility shader happened not to expose the parser defect.
        if not line.startswith(("in ", "out ", "uniform "))
    )


def _create_shader(name, vertex, fragment):
    info = gpu.types.GPUShaderCreateInfo()
    interface = gpu.types.GPUStageInterfaceInfo(f"impaction_{name}_interface")
    if name == "geometry":
        info.vertex_in(0, "VEC3", "position")
        info.vertex_in(1, "VEC3", "normal")
        interface.smooth("FLOAT", "vLight")
        interface.smooth("VEC2", "vSurfaceNormal")
        for kind, uniform in (
            ("VEC2", "lightFocus"), ("FLOAT", "lightCastBehind"),
        ):
            info.push_constant(kind, uniform)
    elif name == "motion_geometry":
        info.vertex_in(0, "VEC3", "position")
        info.vertex_in(1, "VEC2", "velocity")
        info.vertex_in(2, "VEC2", "acceleration")
        interface.smooth("VEC2", "vVelocity")
        interface.smooth("VEC2", "vAcceleration")
    elif name == "impact":
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        info.sampler(0, "FLOAT_2D", "subjectTex")
        info.sampler(1, "FLOAT_2D", "floorTex")
        info.sampler(2, "FLOAT_2D", "brushTex")
        info.sampler(3, "FLOAT_2D", "motionTex")
        info.sampler(4, "FLOAT_2D", "backgroundMotionTex")
        for kind, uniform in (
            ("VEC2", "resolution"), ("INT", "mode"), ("INT", "layerOnly"),
            ("INT", "hybridMode"),
            ("FLOAT", "angle"),
            ("VEC2", "focus"), ("FLOAT", "strength"), ("FLOAT", "salt"),
            ("FLOAT", "lineThickness"),
            ("VEC2", "subjectMotion"), ("VEC2", "backgroundMotion"),
            ("VEC2", "subjectAcceleration"),
            ("FLOAT", "velocityScale"), ("FLOAT", "motionCurveInfluence"),
            ("FLOAT", "backgroundIntensity"),
            ("FLOAT", "backgroundMotionInfluence"),
            ("FLOAT", "bandTransition"), ("FLOAT", "radialThreshold"),
            ("FLOAT", "radialSpiral"),
            ("FLOAT", "contrast"), ("FLOAT", "lightIntensity"),
            ("VEC4", "flowSource"), ("FLOAT", "haloSpread"),
            ("VEC4", "subjectBounds"),
            ("VEC4", "backgroundAffineX"),
            ("VEC4", "backgroundAffineY"),
        ):
            info.push_constant(kind, uniform)
    elif name == "impact_layers":
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        info.sampler(0, "FLOAT_2D", "subjectTex")
        info.sampler(1, "FLOAT_2D", "floorTex")
    elif name == "grain":
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        info.sampler(0, "FLOAT_2D", "impactTex")
        for kind, uniform in (
            ("VEC2", "paperResolution"),
            ("FLOAT", "dustAmount"),
            ("FLOAT", "filmAmount"), ("FLOAT", "salt"),
        ):
            info.push_constant(kind, uniform)
    elif name == "motion_blur":
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        info.sampler(0, "FLOAT_2D", "colorTex")
        info.sampler(1, "FLOAT_2D", "impactTex")
        info.sampler(2, "FLOAT_2D", "shapeMaskTex")
        for kind, uniform in (
            ("VEC2", "resolution"), ("INT", "mode"),
            ("FLOAT", "angle"), ("VEC2", "focus"),
            ("FLOAT", "amount"), ("FLOAT", "directionPolarity"),
            ("VEC2", "cameraMotion"),
        ):
            info.push_constant(kind, uniform)
    elif name == "aberration_blend":
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        info.sampler(0, "FLOAT_2D", "colorTex")
        info.sampler(1, "FLOAT_2D", "grainTex")
        info.sampler(2, "FLOAT_2D", "impactTex")
        info.sampler(3, "FLOAT_2D", "shapeMaskTex")
        info.sampler(4, "FLOAT_2D", "gradientTex")
        for kind, uniform in (
            ("VEC2", "resolution"), ("INT", "mode"), ("FLOAT", "angle"),
            ("VEC2", "focus"), ("FLOAT", "aberration"), ("FLOAT", "halftone"),
            ("FLOAT", "aberrationBlur"), ("FLOAT", "aberrationIntensity"),
            ("FLOAT", "aberrationTaper"),
            ("FLOAT", "grainActive"), ("FLOAT", "directionPolarity"),
            ("VEC2", "cameraMotion"), ("VEC4", "foreground"),
            ("VEC4", "background"), ("FLOAT", "singleColorActive"),
            ("VEC4", "singleColor"), ("FLOAT", "blurSmoothing"),
        ):
            info.push_constant(kind, uniform)
    elif name == "bloom_extract":
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        info.sampler(0, "FLOAT_2D", "colorTex")
        info.sampler(1, "FLOAT_2D", "impactTex")
        info.sampler(2, "FLOAT_2D", "grainTex")
        info.sampler(3, "FLOAT_2D", "shapeMaskTex")
        for kind, uniform in (
            ("VEC2", "resolution"),
            ("VEC4", "foreground"), ("VEC4", "background"),
            ("FLOAT", "aberrationActive"),
            ("FLOAT", "grainActive"), ("FLOAT", "grainBloomMix"),
        ):
            info.push_constant(kind, uniform)
    elif name == "bloom_down":
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        info.sampler(0, "FLOAT_2D", "colorTex")
        for kind, uniform in (
            ("VEC2", "sourceResolution"),
        ):
            info.push_constant(kind, uniform)
    elif name == "bloom_up":
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        info.sampler(0, "FLOAT_2D", "lowTex")
        info.sampler(1, "FLOAT_2D", "highTex")
        for kind, uniform in (
            ("VEC2", "lowResolution"), ("FLOAT", "lowWeight"),
            ("FLOAT", "highWeight"),
        ):
            info.push_constant(kind, uniform)
    elif name == "bloom":
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        info.sampler(0, "FLOAT_2D", "colorTex")
        info.sampler(1, "FLOAT_2D", "glowTex")
        info.sampler(2, "FLOAT_2D", "coreTex")
        for kind, uniform in (("FLOAT", "bloom"),):
            info.push_constant(kind, uniform)
    elif name == "shapes":
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        info.sampler(0, "FLOAT_2D", "colorTex")
        info.sampler(1, "FLOAT_2D", "subjectTex")
        info.sampler(2, "FLOAT_2D", "shapeTex")
        info.sampler(3, "FLOAT_2D", "impactTex")
        info.sampler(4, "FLOAT_2D", "grainTex")
        info.push_constant("VEC2", "resolution")
        info.push_constant("INT", "shapeCount")
        info.push_constant("INT", "maskOnly")
        info.push_constant("FLOAT", "halftone")
        info.push_constant("FLOAT", "halftoneSize")
        info.push_constant("FLOAT", "grainActive")
    elif name == "grade":
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        info.sampler(0, "FLOAT_2D", "colorTex")
        for kind, uniform in (
            ("FLOAT", "contrast"), ("FLOAT", "grayscale"),
            ("FLOAT", "negative"),
        ):
            info.push_constant(kind, uniform)
    elif name == "pixelate":
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        info.sampler(0, "FLOAT_2D", "colorTex")
        info.sampler(1, "FLOAT_2D", "impactTex")
        info.sampler(2, "FLOAT_2D", "shapeMaskTex")
        for kind, uniform in (
            ("VEC2", "resolution"), ("FLOAT", "pixelate"),
            ("FLOAT", "pixelSize"),
        ):
            info.push_constant(kind, uniform)
    else:
        info.vertex_in(0, "VEC2", "position")
        info.vertex_in(1, "VEC2", "texCoord")
        interface.smooth("VEC2", "uv")
        info.sampler(0, "FLOAT_2D", "impactTex")
        info.sampler(1, "FLOAT_2D", "subjectTex")
        info.sampler(2, "FLOAT_2D", "gradientTex")
        info.sampler(3, "FLOAT_2D", "grainTex")
        for kind, uniform in (
            ("VEC2", "resolution"), ("INT", "mode"), ("FLOAT", "angle"),
            ("VEC2", "focus"), ("FLOAT", "aberration"),
            ("VEC4", "foreground"), ("VEC4", "background"),
            ("FLOAT", "bleedAmount"),
            ("FLOAT", "halftone"),
            ("FLOAT", "halftoneSize"),
            ("FLOAT", "aberrationSpread"),
            ("FLOAT", "aberrationIntensity"),
            ("FLOAT", "grainActive"),
            ("FLOAT", "singleColorActive"),
            ("VEC4", "singleColor"), ("FLOAT", "directionPolarity"),
            ("VEC2", "cameraMotion"),
        ):
            info.push_constant(kind, uniform)
    info.vertex_out(interface)
    info.fragment_out(0, "VEC4", "fragColor")
    info.vertex_source(_shader_body(vertex))
    info.fragment_source(_shader_body(fragment))
    return gpu.shader.create_from_info(info)


def _gpu_backend_name():
    try:
        backend = getattr(gpu.platform, "backend_type_get", None)
        return str(backend()) if backend is not None else "UNKNOWN"
    except Exception:
        return "UNKNOWN"


def _shader(name, vertex, fragment):
    shader = _shaders.get(name)
    if shader is not None:
        return shader
    backend = _gpu_backend_name()
    # Blender's OpenGL GLSL translation rejects the primary shader's richer
    # out-parameter interface before it can optimize it. Select the audited
    # compatibility path up front instead of printing a screenful of compiler
    # errors and then arriving at the same shader through exception fallback.
    if name == "impact" and backend == "OPENGL":
        shader = _create_shader(name, vertex, "impact_compat.frag")
        _shaders[name] = shader
        return shader
    try:
        shader = _create_shader(name, vertex, fragment)
    except Exception as primary_error:
        if name != "impact":
            raise
        print(
            "Impaction: primary impact shader compilation failed "
            f"on {backend}; retrying compatibility shader. "
            f"Primary error: {primary_error}"
        )
        try:
            shader = _create_shader(name, vertex, "impact_compat.frag")
            print(f"Impaction: compatibility impact shader active on {backend}.")
        except Exception as fallback_error:
            raise RuntimeError(
                "Impact shader compilation failed for both primary and "
                f"compatibility paths on {backend}. Primary: {primary_error}; "
                f"Fallback: {fallback_error}"
            ) from fallback_error
    _shaders[name] = shader
    return shader


def _fullscreen_quad(shader):
    """Return the immutable fullscreen geometry shared by every post pass."""
    global _fullscreen_batch
    if _fullscreen_batch is None:
        _fullscreen_batch = batch_for_shader(
            shader, "TRI_FAN",
            {
                "position": (
                    (-1.0, -1.0), (1.0, -1.0),
                    (1.0, 1.0), (-1.0, 1.0),
                ),
                "texCoord": (
                    (0.0, 0.0), (1.0, 0.0),
                    (1.0, 1.0), (0.0, 1.0),
                ),
            },
        )
    return _fullscreen_batch


def _enable_linear_filter(texture):
    """Enable linear sampling when Blender exposes the texture setter.

    Blender 4.2-5.0 already initialize non-integer GPU textures with linear
    sampling, but their Python GPUTexture type does not expose filter_mode().
    Blender 5.1+ exposes the setter, so retain the explicit request there.
    """
    set_filter_mode = getattr(texture, "filter_mode", None)
    if callable(set_filter_mode):
        set_filter_mode(True)
    return texture


def _empty_texture():
    """Return one context-local transparent/zero sampling texture."""
    global _empty_rgba_texture
    if _empty_rgba_texture is None:
        buffer = gpu.types.Buffer("FLOAT", 4, (0.0, 0.0, 0.0, 0.0))
        _empty_rgba_texture = gpu.types.GPUTexture(
            (1, 1), format="RGBA32F", data=buffer,
        )
        _enable_linear_filter(_empty_rgba_texture)
    return _empty_rgba_texture


def _gradient_texture(parameters):
    """Reuse exact immutable gradient/light parameter textures by value."""
    key = tuple(tuple(float(channel) for channel in texel) for texel in parameters)
    texture = _gradient_textures.pop(key, None)
    if texture is not None:
        _gradient_textures[key] = texture
        return texture
    buffer = gpu.types.Buffer(
        "FLOAT", len(key) * 4,
        [channel for texel in key for channel in texel],
    )
    texture = gpu.types.GPUTexture(
        (len(key), 1), format="RGBA32F", data=buffer,
    )
    _gradient_textures[key] = texture
    while len(_gradient_textures) > _GRADIENT_TEXTURE_BUDGET:
        _old_key, old_texture = _gradient_textures.popitem(last=False)
        try:
            old_texture.free()
        except (AttributeError, ReferenceError, RuntimeError):
            pass
    return texture


def _offscreen(width, height, high_precision=False):
    initialize = getattr(gpu, "init", None)
    if initialize is not None:
        initialize()
    if high_precision:
        try:
            target = gpu.types.GPUOffScreen(width, height, format="RGBA16F")
            _enable_linear_filter(target.texture_color)
            return target
        except TypeError:
            pass
    target = gpu.types.GPUOffScreen(width, height)
    _enable_linear_filter(target.texture_color)
    return target


def _shape_texture(record):
    """Encode frame-local shapes in one compact GPU texture."""
    max_shapes, max_points, stride = 16, 256, 7
    point_base = max_shapes * stride
    texels = np.zeros((point_base + max_points, 4), dtype=np.float32)
    point_cursor = 0
    count = min(max_shapes, len(record.shapes))
    for index, shape in enumerate(record.shapes):
        if index >= count:
            break
        offset = index * stride
        point_count = min(max_points - point_cursor, len(shape.points))
        texels[offset] = (
            0.0 if shape.shape_type == "STAR" else 1.0,
            0.0 if shape.layer == "FRONT" else 1.0,
            float(shape.position[0]), float(shape.position[1]),
        )
        texels[offset + 1] = (
            float(shape.width), float(shape.height), float(shape.radius),
            float(getattr(shape, "effect_influence", 0.5)),
        )
        texels[offset + 2] = (
            float(shape.line_thickness), float(point_cursor),
            float(point_count), float(shape.end_width),
        )
        texels[offset + 3] = tuple(shape.foreground)
        texels[offset + 4] = (
            float(shape.burst_amount), float(shape.burst_thickness),
            float(int(getattr(shape, "variation", 1)) % 104729) / 104729.0,
            float(getattr(shape, "burst_end", 0.0)),
        )
        texels[offset + 5] = (float(shape.rotation), 0.0, 0.0, 0.0)
        texels[offset + 6] = (
            float(getattr(shape, "stroke", 0.0)),
            float(shape.stroke_color[0]), float(shape.stroke_color[1]),
            float(shape.stroke_color[2]),
        )
        for point_index in range(point_count):
            point = shape.points[point_index]
            texels[point_base + point_cursor + point_index] = (
                float(point.position[0]), float(point.position[1]),
                float(point.pressure), 1.0 if point.break_before else 0.0,
            )
        point_cursor += point_count
    buffer = gpu.types.Buffer("FLOAT", texels.size, texels.ravel().tolist())
    texture = gpu.types.GPUTexture(
        (len(texels), 1), format="RGBA32F", data=buffer,
    )
    return texture, count


def _smoothstep(edge0, edge1, value):
    value = max(0.0, min(1.0, (value - edge0) / max(edge1 - edge0, 1.0e-8)))
    return value * value * (3.0 - 2.0 * value)


def _brush_pressure(position, attack, release):
    return (_smoothstep(0.0, attack, position) *
            _smoothstep(0.0, release, 1.0 - position))


def _brush_atlas():
    """Return one cached procedural atlas of original charcoal brush swipes."""
    global _brush_texture
    if _brush_texture is not None:
        return _brush_texture
    width, cell_height, variants = 1024, 256, 4
    height = cell_height * variants
    pixels = np.zeros((height, width, 2), dtype=np.float32)
    # core radius, lane count, attack, release, edge veil.  The core value is
    # only a sampling-density bias; no opaque rectangle is laid underneath.
    styles = (
        (0.46, 76, 0.07, 0.23, 0.010),
        (0.52, 68, 0.10, 0.18, 0.012),
        (0.42, 84, 0.045, 0.29, 0.008),
        (0.48, 72, 0.13, 0.16, 0.010),
    )
    for variant, (core_radius, lane_count, attack, release, veil) in enumerate(styles):
        lane_data = []
        for lane in range(lane_count):
            seed = math.sin((variant + 1.7) * (lane + 3.1) * 19.19) * 43758.5453
            seed -= math.floor(seed)
            seed_b = math.sin((variant + 4.3) * (lane + 7.7) * 11.73) * 24634.6345
            seed_b -= math.floor(seed_b)
            # Randomized bristle placement avoids the evenly spaced grooves
            # that read as a computer hatch.  Most fibers bunch near the core;
            # a few live at the ragged outside edge.
            signed = seed * 2.0 - 1.0
            center = math.copysign(abs(signed) ** 1.28, signed) * 0.96
            center += (seed_b - 0.5) * 0.035
            lane_width = 0.008 + 0.030 * ((seed * 1.731) % 1.0)
            if lane % 7 == 0:
                lane_width *= 4.8
            edge_bias = min(1.0, abs(center))
            endpoint_spread = 0.13 + 0.24 * edge_bias
            start_point = 0.010 + endpoint_spread * seed
            end_point = 0.990 - endpoint_spread * (1.0 - seed_b)
            gap_center = 0.18 + 0.64 * ((seed * 2.917) % 1.0)
            gap_width = 0.045 + 0.11 * ((seed * 4.137) % 1.0)
            gap_depth = (0.08 + 0.28 * ((seed * 7.311) % 1.0) +
                         0.40 * edge_bias)
            lane_data.append((
                center, lane_width, start_point, end_point, seed,
                gap_center, gap_width, gap_depth,
            ))
        along = (np.arange(width, dtype=np.float32) + 0.5) / width
        across = ((np.arange(cell_height, dtype=np.float32) + 0.5) /
                  cell_height * 2.0 - 1.0)
        along_grid = along[None, :]
        across_grid = across[:, None]
        edge_width = (
            0.96
            + 0.008 * np.sin(along_grid * 6.3 + variant * 1.9)
            + 0.004 * np.sin(along_grid * 17.1 + variant * 4.3)
        )
        normalized = across_grid / np.maximum(edge_width, 0.5)
        distance = np.abs(normalized)

        def smoothstep_array(edge0, edge1, values):
            denominator = np.maximum(np.asarray(edge1) - np.asarray(edge0), 1.0e-8)
            values = np.clip((values - edge0) / denominator,
                             0.0, 1.0)
            return values * values * (3.0 - 2.0 * values)

        def pressure_array(position, attack_value, release_value):
            return (smoothstep_array(0.0, attack_value, position) *
                    smoothstep_array(0.0, release_value, 1.0 - position))

        silhouette = 1.0 - smoothstep_array(0.84, 1.02, distance)
        pressure = pressure_array(along_grid, attack, release)
        # Real loaded charcoal deposits a connected pressure body. Fibers
        # separate mainly at its perimeter; leaving every lane exposed through
        # the center creates the parallel white "bacon" channels. Taper the
        # core geometrically so its ends remain pointed instead of clipped.
        tip_profile = np.sqrt(np.clip(pressure, 0.0, 1.0))
        core_span = core_radius * (0.06 + 0.94 * tip_profile)
        core_shape = 1.0 - smoothstep_array(
            core_span, core_span + 0.10, distance,
        )
        core_coverage = core_shape * pressure * 0.96
        fiber_coverage = np.zeros_like(core_coverage)
        for (center, lane_width, start_point, end_point, seed,
             gap_center, gap_width, gap_depth) in lane_data:
            lane_drift = (
                np.sin(along_grid * (5.0 + seed * 4.0) + seed * 11.0) * 0.010
                + np.sin(along_grid * (13.0 + seed * 7.0) + seed * 3.0) * 0.004
            )
            lane_width_at_x = lane_width * (
                0.82 + 0.24 * np.sin(along_grid * (17.0 + seed * 11.0) + seed * 5.0)
            )
            lane_body = 1.0 - smoothstep_array(
                lane_width_at_x * 0.60,
                lane_width_at_x,
                np.abs(normalized - center - lane_drift),
            )
            attack_width = attack * (0.62 + seed * 0.55)
            release_width = release * (0.58 + (1.0 - seed) * 0.54)
            lane_pressure = smoothstep_array(
                start_point, start_point + attack_width, along_grid,
            )
            lane_pressure *= 1.0 - smoothstep_array(
                end_point - release_width, end_point, along_grid,
            )
            scrape = np.exp(-0.5 * ((along_grid - gap_center) /
                                    max(gap_width, 1.0e-4)) ** 2)
            lane_pressure *= 1.0 - gap_depth * scrape
            lane_pressure *= 0.78 + 0.22 * np.sin(
                along_grid * (12.0 + seed * 9.0) + seed * 17.0,
            ) ** 2
            fiber_coverage = np.maximum(
                fiber_coverage, lane_body * lane_pressure,
            )
        fiber_coverage = np.maximum(
            fiber_coverage, silhouette * pressure * veil,
        )
        row_slice = slice(variant * cell_height, (variant + 1) * cell_height)
        pixels[row_slice, :, 0] = np.clip(core_coverage, 0.0, 1.0)
        pixels[row_slice, :, 1] = np.clip(fiber_coverage, 0.0, 1.0)
    flat_pixels = np.ascontiguousarray(pixels.ravel())
    buffer = gpu.types.Buffer("FLOAT", flat_pixels.size, flat_pixels)
    _brush_texture = gpu.types.GPUTexture(
        (width, height), format="RG32F", data=buffer,
    )
    # The atlas stores material deposition, not final pixels. Linear sampling
    # reconstructs that continuous footprint before the shader applies its
    # analytic one-pixel coverage transition, avoiding texel stairs without a
    # 4x full-frame fragment cost.
    _enable_linear_filter(_brush_texture)
    return _brush_texture


def _draw_geometry(geometry, width, height, record):
    target = _offscreen(width, height, high_precision=True)
    with target.bind():
        framebuffer = gpu.state.active_framebuffer_get()
        framebuffer.clear(color=(0.0, 0.0, 0.0, 0.0), depth=1.0)
        if geometry.positions and geometry.triangles:
            shader = _shader("geometry", "geometry.vert", "geometry.frag")
            batch = batch_for_shader(
                shader, "TRIS",
                {"position": geometry.positions,
                 "normal": geometry.normals},
                indices=geometry.triangles,
            )
            shader.uniform_float("lightFocus", tuple(record.light_focus))
            shader.uniform_float(
                "lightCastBehind", 1.0 if record.light_cast_behind else 0.0,
            )
            gpu.state.blend_set("NONE")
            gpu.state.depth_test_set("LESS_EQUAL")
            gpu.state.depth_mask_set(True)
            batch.draw(shader)
            gpu.state.depth_mask_set(False)
            gpu.state.depth_test_set("NONE")
    return target


def _draw_motion_geometry(geometry, width, height):
    """Rasterize interpolated local screen velocity for articulated trails."""
    target = _offscreen(width, height, high_precision=True)
    with target.bind():
        framebuffer = gpu.state.active_framebuffer_get()
        framebuffer.clear(color=(0.0, 0.0, 0.0, 0.0), depth=1.0)
        if geometry.positions and geometry.triangles:
            shader = _shader(
                "motion_geometry", "motion_geometry.vert", "motion_geometry.frag",
            )
            batch = batch_for_shader(
                shader, "TRIS",
                {
                    "position": geometry.positions,
                    "velocity": geometry.velocities,
                    "acceleration": geometry.accelerations,
                },
                indices=geometry.triangles,
            )
            gpu.state.blend_set("NONE")
            gpu.state.depth_test_set("LESS_EQUAL")
            gpu.state.depth_mask_set(True)
            batch.draw(shader)
            gpu.state.depth_mask_set(False)
            gpu.state.depth_test_set("NONE")
    return target


def _free_surface(surface):
    try:
        surface.free()
    except (AttributeError, ReferenceError, RuntimeError):
        pass


def _cache_put(cache, key, value, pixel_weight, budget, protected_keys=()):
    old = cache.pop(key, None)
    if old is not None:
        surfaces = old[0] if isinstance(old[0], tuple) else (old[0],)
        for surface in surfaces:
            _free_surface(surface)
    cache[key] = (value, int(pixel_weight))
    total = sum(item[1] for item in cache.values())
    protected = set(protected_keys)
    protected.add(key)
    while total > budget and len(cache) > 1:
        victim = next((candidate for candidate in cache if candidate not in protected), None)
        if victim is None:
            # One in-flight render can legitimately exceed the steady-state
            # budget at very large resolutions. Keep its surfaces alive until
            # the next raster request can evict the complete old frame.
            break
        old_value, weight = cache.pop(victim)
        surfaces = old_value if isinstance(old_value, tuple) else (old_value,)
        for surface in surfaces:
            _free_surface(surface)
        total -= weight


def _cache_get(cache, key):
    item = cache.pop(key, None)
    if item is None:
        return None
    cache[key] = item
    return item[0]


def _purge_surface_cache(camera_name, salt):
    for cache in (_raster_cache, _mask_cache):
        for key in tuple(cache):
            if key[0] == camera_name and key[1] == int(salt):
                value, _weight = cache.pop(key)
                surfaces = value if isinstance(value, tuple) else (value,)
                for surface in surfaces:
                    _free_surface(surface)


def _rasterized_capture(camera, record, capture, width, height):
    light_signature = (
        round(float(record.light_focus[0]), 6), round(float(record.light_focus[1]), 6),
        bool(record.light_cast_behind),
    )
    # At 1080p-class output, a 2x source raster gives the contour shader four
    # geometry samples per output pixel. At 4K the native pixel density is
    # already equivalent and avoids an unnecessary 8K allocation.
    raster_scale = 2 if max(width, height) <= 2048 else 1
    raster_width = width * raster_scale
    raster_height = height * raster_scale
    base_key = (*_capture_key(camera, record), int(width), int(height))
    geometry_key = (*base_key, "geometry", light_signature)
    geometry_surfaces = _cache_get(_raster_cache, geometry_key)
    if geometry_surfaces is None:
        subject = _draw_geometry(
            capture.subject, raster_width, raster_height, record,
        )
        floor = (
            _draw_geometry(capture.floor, raster_width, raster_height, record)
            if capture.floor.positions and capture.floor.triangles else None
        )
        geometry_surfaces = (subject, floor)
        _cache_put(
            _raster_cache, geometry_key, geometry_surfaces,
            raster_width * raster_height * (2 if floor is not None else 1),
            _RASTER_PIXEL_BUDGET,
        )
    motion_key = (*base_key, "motion")
    motion = _cache_get(_raster_cache, motion_key)
    if motion is None:
        motion = _draw_motion_geometry(
            capture.subject, raster_width, raster_height,
        )
        _cache_put(
            _raster_cache, motion_key, motion,
            raster_width * raster_height, _RASTER_PIXEL_BUDGET,
            protected_keys=(geometry_key,),
        )
    return (*geometry_surfaces, motion)


def _impact_mode(record):
    return {"LINEAR": 0, "RADIAL": 1}.get(str(record.mode), 2)


def _enabled_line_modes(record):
    modes = []
    if bool(getattr(record, "radial_enabled", False)):
        modes.append(1)
    if bool(getattr(record, "linear_enabled", True)):
        modes.append(0)
    return tuple(modes) or (2,)


def _effect_mode(record):
    if bool(getattr(record, "linear_enabled", True)):
        return 0
    if bool(getattr(record, "radial_enabled", False)):
        return 1
    return 2


def _effect_focus(record):
    return tuple(record.direction_focus)


def _effect_polarity(record):
    """Match one-sided optical effects to the directed 3D stroke taper."""
    return -1.0 if bool(
        getattr(record, "direction_cast_behind", False)
    ) else 1.0


def _direction_vector(record):
    """Resolve one camera-space direction for strokes and optical effects."""
    focus = getattr(record, "direction_focus", (0.5, 0.75))
    x = (float(focus[0]) - 0.5) * 2.0
    y = (float(focus[1]) - 0.5) * 2.0
    radius = math.hypot(x, y)
    if radius > 1.0:
        x, y = x / radius, y / radius
        radius = 1.0
    z = math.sqrt(max(0.0, 1.0 - radius * radius))
    if bool(getattr(record, "direction_cast_behind", False)):
        z = -z
    return x, y, z


def _flow_source(record, capture=None):
    """Encode the shared spatial 3D wind-source hemisphere."""
    focus = getattr(record, "direction_focus", (0.5, 0.75))
    # Direction is evaluated on deliberate drawing poses.  A 1/24-frame step
    # is fine enough to aim accurately but coarse enough that a one-pixel pin
    # drag cannot make the drawing twitch between unrelated up/down headings.
    # Hatch identity is derived from this same pose in the fragment shader,
    # so a step redraws the marks instead of rubber-rotating an old lattice.
    x = round(float(focus[0]) * 24.0) / 24.0
    y = round(float(focus[1]) * 24.0) / 24.0
    if capture is not None:
        left, bottom, right, top = _subject_bounds(capture)
        subject_center = (0.5 * (left + right), 0.5 * (bottom + top))
        # A snapped pin is a true frontal/rearward hemisphere pole even when
        # composition places the subject away from the frame center.
        if math.hypot(
            float(focus[0]) - subject_center[0],
            float(focus[1]) - subject_center[1],
        ) <= 0.012:
            x, y = subject_center
    sphere_x = (x - 0.5) * 2.0
    sphere_y = (y - 0.5) * 2.0
    raw_radius = math.hypot(sphere_x, sphere_y)
    if raw_radius > 1.0:
        sphere_x /= raw_radius
        sphere_y /= raw_radius
        x = sphere_x * 0.5 + 0.5
        y = sphere_y * 0.5 + 0.5
    radius = min(1.0, raw_radius)
    z = math.sqrt(max(0.0, 1.0 - radius * radius))
    if bool(getattr(record, "direction_cast_behind", False)):
        z = -z
    return x, y, z, 1.0


def _subject_bounds(capture):
    """Tight projected subject bounds used only to distribute gesture seeds."""
    cached = getattr(capture, "_impaction_subject_bounds", None)
    if cached is not None:
        return cached
    positions = getattr(getattr(capture, "subject", None), "positions", ())
    visible = [
        value for value in positions
        if len(value) >= 2 and -0.25 <= float(value[0]) <= 1.25
        and -0.25 <= float(value[1]) <= 1.25
    ]
    if not visible:
        result = (0.0, 0.0, 1.0, 1.0)
        capture._impaction_subject_bounds = result
        return result
    pad = 0.025
    left = max(0.0, min(float(value[0]) for value in visible) - pad)
    bottom = max(0.0, min(float(value[1]) for value in visible) - pad)
    right = min(1.0, max(float(value[0]) for value in visible) + pad)
    top = min(1.0, max(float(value[1]) for value in visible) + pad)
    if right - left < 0.02 or top - bottom < 0.02:
        result = (0.0, 0.0, 1.0, 1.0)
    else:
        result = (left, bottom, right, top)
    capture._impaction_subject_bounds = result
    return result


def cached_subject_center(camera, record):
    """Return the captured subject's projected center without recapturing."""
    if camera is None or record is None:
        return None
    capture = _capture_cache_get(_capture_key(camera, record))
    if capture is None:
        capture = _load_persistent_capture(record)
    if capture is None:
        return None
    left, bottom, right, top = _subject_bounds(capture)
    return (0.5 * (left + right), 0.5 * (bottom + top))


def _resolved_direction_angle(record):
    flow = _flow_source(record)
    x = (float(flow[0]) - 0.5) * 2.0
    y = (float(flow[1]) - 0.5) * 2.0
    if math.hypot(x, y) <= 1.0e-6:
        # A centered pin is a depth-facing 3D wind view, not an undefined 2D
        # angle. Preserve the authored camera-basis direction requested for
        # the torso-back view so the projection cannot fall through to an old
        # unrelated manual angle stored on the record.
        return math.atan2(3.0, -5.0)
    return math.atan2(y, x)


def _frame_palette(record):
    """Return the stored endpoints; Flip now swaps the color-box values."""
    return tuple(record.foreground), tuple(record.background)


def _effective_light(record, foreground=None, background=None):
    """Return the selected light color and its visible drawing energy.

    Exact black is an absent light. Near-black colors ramp in gently so gray
    remains useful without creating a discontinuous white/gray rim.
    """
    if foreground is None or background is None:
        foreground, background = _frame_palette(record)
    # Lighting now has one direct artist color. The legacy source enum remains
    # serialized only so older files can migrate without broken RNA paths.
    source = "CUSTOM"
    color = tuple(record.light_color)
    peak = max(float(color[0]), float(color[1]), float(color[2]))
    # Illumination is an emitted-light control, not the paper value. A dark
    # Background endpoint must not switch the key light off. Preserve a dark
    # color's hue by normalising it to emissive value; exact black has no hue,
    # so it falls back to a neutral white key. Strength owns light energy.
    if peak <= 1.0e-5:
        emitted = (1.0, 1.0, 1.0, float(color[3]))
    else:
        emitted = (
            float(color[0]) / peak,
            float(color[1]) / peak,
            float(color[2]) / peak,
            float(color[3]),
        )
    energy = max(0.0, min(1.0, float(record.light_radius)))
    return emitted, energy, source


def _valid_image(image):
    try:
        return bool(
            image is not None
            and len(image.size) >= 2
            and min(int(value) for value in image.size[:2]) >= 2
            and image.has_data
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return False


def _rounded_tuple(values, digits=6):
    return tuple(round(float(value), digits) for value in values)


def record_render_signature(record, scene=None):
    """Hash every input that changes cached output pixels.

    The signature is saved with the record, but the packed Image pixels are not
    part of Blender's RNA undo stack. Runtime undo handling therefore clears
    signatures and lazily rebuilds frames as they become visible.
    """
    render = getattr(scene, "render", None)
    resolution = (
        int(getattr(render, "resolution_x", 0)),
        int(getattr(render, "resolution_y", 0)),
        round(float(getattr(render, "pixel_aspect_x", 1.0)), 6),
        round(float(getattr(render, "pixel_aspect_y", 1.0)), 6),
    )
    shape_payload = tuple(
        (str(shape.shape_type), str(shape.layer),
         int(getattr(shape, "variation", 1)),
         _rounded_tuple(shape.position, 7), round(float(shape.width), 6),
         round(float(shape.height), 6), round(float(shape.radius), 6),
         round(float(shape.rotation), 7),
         round(float(shape.diagonal), 6),
         round(float(shape.end_width), 6), int(shape.burst_amount),
         round(float(shape.burst_thickness), 6),
         round(float(getattr(shape, "burst_end", 0.0)), 6),
         round(float(getattr(shape, "stroke", 0.0)), 6),
         _rounded_tuple(getattr(
             shape, "stroke_color", (1.0, 1.0, 1.0),
         )),
         round(float(shape.line_thickness), 6),
         round(float(getattr(shape, "effect_influence", 0.5)), 6),
         _rounded_tuple(shape.foreground),
         tuple((_rounded_tuple(point.position, 7),
                round(float(point.pressure), 5), bool(point.break_before))
               for point in shape.points))
        for shape in getattr(record, "shapes", ())
    )
    payload = (
        _RENDER_CACHE_VERSION,
        int(record.frame), int(record.salt),
        bool(getattr(record, "linear_enabled", True)),
        bool(getattr(record, "radial_enabled", False)), str(record.mode),
        _rounded_tuple(getattr(record, "direction_focus", (0.5, 0.75)), 7),
        bool(getattr(record, "direction_cast_behind", False)),
        round(float(getattr(record, "halo_spread", 0.5)), 6),
        round(float(getattr(record, "motion_curve_influence", 1.0)), 6),
        round(float(getattr(record, "background_intensity", 0.5)), 6),
        round(float(getattr(record, "background_motion", 0.5)), 6),
        round(float(record.angle), 7), _rounded_tuple(record.focus, 7),
        round(float(record.strength), 6),
        round(float(record.line_thickness), 6),
        round(float(getattr(record, "radial_threshold", 0.5)), 6),
        round(float(getattr(record, "radial_spiral", 0.0)), 6),
        round(float(record.band_transition), 6),
        round(float(getattr(record, "motion_blur", 0.0)), 6),
        _rounded_tuple(record.foreground), _rounded_tuple(record.background),
        bool(record.invert),
        _rounded_tuple(record.light_focus, 7),
        round(float(record.light_radius), 6),
        round(float(getattr(record, "bleed", 0.5)), 6),
        bool(getattr(record, "light_cast_behind", False)),
        str(record.light_color_source), _rounded_tuple(record.light_color),
        round(float(record.contrast), 6), round(float(record.grayscale), 6),
        round(float(record.bloom), 6),
        round(float(record.chromatic_aberration), 6),
        str(record.aberration_preset),
        bool(getattr(record, "aberration_blur_smoothing", True)),
        _rounded_tuple(record.aberration_color_a),
        _rounded_tuple(record.aberration_color_b),
        str(getattr(record, "aberration_ramp", "")),
        aberration_ramp_signature(record),
        round(float(record.grain), 6),
        round(float(record.grain_overlay_intensity), 6),
        shape_payload,
        round(float(record.halftone), 6), int(record.halftone_size),
        round(float(record.pixelate), 6), int(record.pixelate_size),
        resolution,
    )
    return hashlib.blake2b(
        repr(payload).encode("utf-8"), digest_size=16,
    ).hexdigest()


def _signature_scene_key(scene):
    render = getattr(scene, "render", None)
    return (
        int(getattr(render, "resolution_x", 0)),
        int(getattr(render, "resolution_y", 0)),
        round(float(getattr(render, "pixel_aspect_x", 1.0)), 6),
        round(float(getattr(render, "pixel_aspect_y", 1.0)), 6),
    )


def invalidate_record_signature(record):
    """Mark one record's expensive visual signature dirty without hiding it."""
    try:
        pointer = record.as_pointer()
    except (AttributeError, ReferenceError, RuntimeError):
        return
    revision = int(_signature_revisions.pop(pointer, 0)) + 1
    _signature_revisions[pointer] = revision
    _signature_cache.pop(pointer, None)
    while len(_signature_revisions) > _SIGNATURE_CACHE_BUDGET:
        stale_pointer, _revision = _signature_revisions.popitem(last=False)
        _signature_cache.pop(stale_pointer, None)


def _current_render_signature(record, scene=None):
    """Memoize the full signature between Blender property notifications."""
    try:
        pointer = record.as_pointer()
    except (AttributeError, ReferenceError, RuntimeError):
        return record_render_signature(record, scene)
    revision = int(_signature_revisions.get(pointer, 0))
    scene_key = _signature_scene_key(scene)
    identity = (
        int(getattr(record, "salt", 0)),
        int(getattr(record, "frame", 0)),
    )
    cached = _signature_cache.pop(pointer, None)
    if cached is not None and cached[:3] == (revision, scene_key, identity):
        _signature_cache[pointer] = cached
        return cached[3]
    signature = record_render_signature(record, scene)
    _signature_cache[pointer] = (revision, scene_key, identity, signature)
    while len(_signature_cache) > _SIGNATURE_CACHE_BUDGET:
        _signature_cache.popitem(last=False)
    return signature


def cache_matches_record(record, scene=None):
    return bool(
        cached_image(record) is not None
        and str(getattr(record, "cache_signature", ""))
        == _current_render_signature(record, scene)
    )


def preview_matches_record(camera, record, scene=None):
    key = (camera.name_full, int(record.salt)) if camera and record else None
    signature = _current_render_signature(record, scene) if key else None
    surface_entry = _preview_surfaces.get(key) if key else None
    if (surface_entry is not None
            and surface_entry[1] == signature):
        return True
    image_name = _preview_images.get(key) if key else None
    image = bpy.data.images.get(image_name) if image_name else None
    return bool(
        key is not None and _valid_image(image)
        and _preview_signatures.get(key) == signature
    )


def display_matches_record(camera, record, scene=None):
    """Check the visible transient first, hashing complex shape data once."""
    if camera is None or record is None:
        return False
    signature = _current_render_signature(record, scene)
    key = (camera.name_full, int(record.salt))
    surface_entry = _preview_surfaces.get(key)
    if surface_entry is not None and surface_entry[1] == signature:
        return True
    preview_name = _preview_images.get(key)
    preview = bpy.data.images.get(preview_name) if preview_name else None
    if _valid_image(preview) and _preview_signatures.get(key) == signature:
        return True
    return bool(
        cached_image(record) is not None
        and str(getattr(record, "cache_signature", "")) == signature
    )


def _internalize_image(image, *, pack=False):
    """Keep generated pixels owned by the .blend rather than an external path."""
    if not _valid_image(image):
        return False
    try:
        image.filepath_raw = ""
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        pass
    image.use_fake_user = True
    if pack:
        try:
            packed = getattr(image, "packed_file", None) is not None
            dirty = bool(getattr(image, "is_dirty", True))
            if not packed or dirty:
                image.pack()
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            return False
    return True


def promote_record_preview(camera, record, scene=None):
    """Pack and apply the exact currently displayed transient once."""
    if camera is None or record is None:
        return None
    key = (camera.name_full, int(record.salt))
    signature = _current_render_signature(record, scene)
    surface_entry = _preview_surfaces.get(key)
    if surface_entry is not None and surface_entry[1] == signature:
        surface, _entry_signature, width, height, name = surface_entry
        image = bpy.data.images.get(name)
        if image is not None and not image.is_float:
            bpy.data.images.remove(image)
            image = None
        if image is None:
            image = bpy.data.images.new(
                name, width=width, height=height,
                alpha=True, float_buffer=True,
            )
        try:
            image.colorspace_settings.name = "Non-Color"
        except TypeError:
            pass
        _write_offscreen_to_image(surface, image, width, height)
        _mark_display_upload(image.name_full)
    else:
        name = _preview_images.get(key)
        image = bpy.data.images.get(name) if name else None
        if not _valid_image(image) or _preview_signatures.get(key) != signature:
            return None
    old_name = str(record.cache_image)
    if not _internalize_image(image, pack=True):
        return None
    record.cache_image = image.name
    record.cache_valid = True
    record.cache_signature = signature
    record["_render_cache_version"] = _RENDER_CACHE_VERSION
    if old_name and old_name != image.name:
        stale = bpy.data.images.get(old_name)
        if stale is not None:
            stale.use_fake_user = False
    surface_entry = _preview_surfaces.pop(key, None)
    if surface_entry is not None:
        _free_surface(surface_entry[0])
    _preview_images.pop(key, None)
    _preview_signatures.pop(key, None)
    return image


def pack_record_images():
    """Pack active caches and remove abandoned dirty preview datablocks."""
    try:
        objects = tuple(bpy.data.objects)
    except (AttributeError, ReferenceError, RuntimeError):
        return 0
    objects_by_name = {obj.name_full: obj for obj in objects}
    scene = getattr(bpy.context, "scene", None)
    for (camera_name, salt), _surface_entry in tuple(_preview_surfaces.items()):
        camera = objects_by_name.get(camera_name)
        record = next(
            (item for item in getattr(camera, "impaction_frames", ())
             if int(item.salt) == int(salt)),
            None,
        ) if camera is not None else None
        if record is not None:
            promote_record_preview(camera, record, scene)
    try:
        images = tuple(bpy.data.images)
    except (AttributeError, ReferenceError, RuntimeError):
        return 0
    referenced = {
        str(record.cache_image)
        for owner in objects
        for record in getattr(owner, "impaction_frames", ())
        if record.cache_image
    }
    referenced.update(_preview_images.values())
    packed = 0
    for image in images:
        if not image.name.startswith(CACHE_PREFIX):
            continue
        real_users = max(0, int(image.users) - int(bool(image.use_fake_user)))
        if image.name not in referenced and real_users == 0:
            # Preview generations from an older extension session are not
            # project assets. Removing them prevents one abandoned dirty image
            # from continuing to trigger Blender's save-images dialog.
            image.use_fake_user = False
            bpy.data.images.remove(image)
            continue
        if _internalize_image(image, pack=True):
            packed += 1
    return packed


def invalidate_display_uploads():
    """Forget managed GPU upload timestamps after undo/context restoration."""
    _display_upload_seen.clear()


def _mask_signature(record, capture):
    _light_color, light_energy, _light_source = _effective_light(record)
    return (
        bool(getattr(record, "linear_enabled", True)),
        bool(getattr(record, "radial_enabled", False)), record.mode,
        _rounded_tuple(getattr(record, "direction_focus", (0.5, 0.75)), 6),
        bool(getattr(record, "direction_cast_behind", False)),
        round(float(getattr(record, "halo_spread", 0.5)), 6),
        round(float(getattr(record, "motion_curve_influence", 1.0)), 6),
        round(float(getattr(record, "background_intensity", 0.5)), 6),
        round(float(getattr(record, "background_motion", 0.5)), 6),
        round(float(record.angle), 6),
        round(float(record.focus[0]), 6), round(float(record.focus[1]), 6),
        round(float(record.strength), 6), round(float(record.line_thickness), 6),
        round(float(getattr(record, "radial_threshold", 0.5)), 6),
        round(float(getattr(record, "radial_spiral", 0.0)), 6),
        round(float(record.band_transition), 6),
        round(float(record.contrast), 6),
        round(float(record.light_focus[0]), 6), round(float(record.light_focus[1]), 6),
        bool(getattr(record, "light_cast_behind", False)),
        round(float(light_energy), 6),
        int(record.salt), round(float(capture.velocity_scale), 7),
        round(float(capture.subject_motion[0]), 7),
        round(float(capture.subject_motion[1]), 7),
        round(float(capture.background_motion[0]), 7),
        round(float(capture.background_motion[1]), 7),
        round(float(capture.subject_acceleration[0]), 7),
        round(float(capture.subject_acceleration[1]), 7),
    )


def _frame_seed(record):
    """Return a deterministic frame coordinate, not unrelated frame noise.

    Grain/scatter still hash this value in their own material shaders. The
    impact shader receives a small scaled coordinate, so neighboring frames
    retain the same hand and gesture families while their local pressure and
    endpoints drift over time instead of being completely re-rolled.
    """
    return float((int(record.frame) & 0x00FFFFFF) + 1)


def _impact_style_salt(record):
    """Deterministically redraw main-stroke topology when controls change.

    Direction uses its integer artist controls, while continuous sliders are
    quantized finely enough that each visible UI step selects a new hand-drawn
    family arrangement instead of rotating the previous frame smoothly.
    """
    frame_seed = int(_frame_seed(record))
    hemisphere = 1 if bool(getattr(record, "direction_cast_behind", False)) else 0
    direction_x = int(getattr(record, "direction_x", 0))
    direction_y = int(getattr(record, "direction_y", 0))
    spread_step = int(round(float(getattr(record, "halo_spread", 0.5)) * 100.0))
    strength_step = int(round(float(getattr(record, "strength", 0.5)) * 100.0))
    thickness_step = int(round(
        float(getattr(record, "line_thickness", 0.5)) * 100.0,
    ))
    spatial_hash = (
        direction_x * 73856093 ^ direction_y * 19349663 ^
        spread_step * 83492791 ^ strength_step * 2654435761 ^
        thickness_step * 97531 ^ hemisphere * 49979687
    ) & 0x0000FFFF
    return ((frame_seed + spatial_hash) % 100000) * 0.001


def _background_affine_field(capture):
    """Fit v(p)=c+A(p-.5) to captured environment screen motion.

    The constant term carries a pan.  The 2x2 derivative retains camera roll,
    orbit and dolly expansion across otherwise empty paper, where sampling the
    environment motion texture directly has no geometry coverage.
    """
    cached = getattr(capture, "_impaction_background_affine", None)
    if cached is not None:
        return cached
    geometry = (
        capture.floor if len(capture.floor.positions) >= 3 else capture.subject
    )
    samples = [
        (position, velocity)
        for position, velocity in zip(geometry.positions, geometry.velocities)
        if (-0.25 <= float(position[0]) <= 1.25
            and -0.25 <= float(position[1]) <= 1.25)
    ]
    fallback = tuple(float(value) for value in capture.background_motion)
    if len(samples) < 3:
        result = ((fallback[0], 0.0, 0.0, 0.0),
                  (fallback[1], 0.0, 0.0, 0.0))
        capture._impaction_background_affine = result
        return result
    design = np.asarray([
        (1.0, float(position[0]) - 0.5, float(position[1]) - 0.5)
        for position, _velocity in samples
    ], dtype=np.float64)
    values = np.asarray([
        (float(velocity[0]), float(velocity[1]))
        for _position, velocity in samples
    ], dtype=np.float64)
    coefficients, _residuals, rank, _singular = np.linalg.lstsq(
        design, values, rcond=None,
    )
    if rank < 3 or not np.isfinite(coefficients).all():
        result = ((fallback[0], 0.0, 0.0, 0.0),
                  (fallback[1], 0.0, 0.0, 0.0))
        capture._impaction_background_affine = result
        return result
    prediction = design @ coefficients
    # When subject geometry is the fallback proxy, discard the articulated
    # minority (for example a punching arm) and refit the coherent camera
    # field. Camera motion affects the low-residual majority; action does not.
    if geometry is capture.subject and len(samples) >= 8:
        errors = np.linalg.norm(values - prediction, axis=1)
        cutoff = float(np.quantile(errors, 0.70))
        retained = errors <= max(cutoff, 1.0e-8)
        if int(np.count_nonzero(retained)) >= 3:
            refined, _residuals, refined_rank, _singular = np.linalg.lstsq(
                design[retained], values[retained], rcond=None,
            )
            if refined_rank >= 3 and np.isfinite(refined).all():
                coefficients = refined
                prediction = design @ coefficients
    residual = float(np.sqrt(np.mean(np.square(values - prediction))))
    scale = max(float(capture.velocity_scale), 1.0e-6)
    confidence = max(0.0, min(1.0, 1.0 - residual / (scale * 1.5)))
    result = (
        (float(coefficients[0, 0]), float(coefficients[1, 0]),
         float(coefficients[2, 0]), confidence),
        (float(coefficients[0, 1]), float(coefficients[1, 1]),
         float(coefficients[2, 1]), confidence),
    )
    capture._impaction_background_affine = result
    return result


def _impact_mask(
    camera, record, capture, subject, floor, motion,
    width, height, batch,
    paper_width, paper_height,
):
    key = (
        *_capture_key(camera, record), int(width), int(height),
        int(paper_width), int(paper_height), _mask_signature(record, capture),
    )
    cached = _cache_get(_mask_cache, key)
    if cached is not None:
        return cached
    shader = _shader("impact", "fullscreen.vert", "impact.frag")
    modes = _enabled_line_modes(record)
    hybrid_mode = len(modes) > 1
    flow_source = _flow_source(record, capture)
    subject_bounds = _subject_bounds(capture)
    affine_x, affine_y = _background_affine_field(capture)
    resolved_angle = _resolved_direction_angle(record)
    effect_focus = _effect_focus(record)
    style_salt = _impact_style_salt(record)
    _light_color, light_energy, _light_source = _effective_light(record)

    def draw_mode(mode, *, layer_only=False):
        target = _offscreen(width, height, high_precision=True)
        with target.bind():
            framebuffer = gpu.state.active_framebuffer_get()
            framebuffer.clear(color=(0.0, 0.0, 0.0, 1.0), depth=1.0)
            shader.uniform_sampler(
                "subjectTex", subject.texture_color if subject is not None
                else _empty_texture(),
            )
            shader.uniform_sampler(
                "floorTex", floor.texture_color if floor is not None
                else _empty_texture(),
            )
            shader.uniform_sampler("brushTex", _brush_atlas())
            shader.uniform_sampler(
                "motionTex", motion.texture_color if motion is not None
                else _empty_texture(),
            )
            shader.uniform_sampler(
                "backgroundMotionTex", _empty_texture(),
            )
            shader.uniform_float(
                "resolution", (float(paper_width), float(paper_height)),
            )
            shader.uniform_int("mode", mode)
            shader.uniform_int("layerOnly", 1 if layer_only else 0)
            shader.uniform_int("hybridMode", 1 if hybrid_mode else 0)
            shader.uniform_float("angle", resolved_angle)
            shader.uniform_float("flowSource", flow_source)
            shader.uniform_float(
                "haloSpread", float(getattr(record, "halo_spread", 0.5)),
            )
            shader.uniform_float("subjectBounds", subject_bounds)
            shader.uniform_float("focus", effect_focus)
            # Two complete high-density modes otherwise collide into a black
            # wall. Hybrid may reduce family count, but Linear remains the
            # foreground owner and keeps the artist's authored stroke width.
            linear_hybrid = hybrid_mode and mode == 0
            radial_hybrid = hybrid_mode and mode == 1
            strength_scale = 0.28 if linear_hybrid else (0.46 if radial_hybrid else 1.0)
            thickness_scale = 1.0 if linear_hybrid else (0.72 if radial_hybrid else 1.0)
            background_scale = 0.46 if linear_hybrid else (0.58 if radial_hybrid else 1.0)
            shader.uniform_float(
                "strength", record.strength * strength_scale,
            )
            shader.uniform_float(
                "lineThickness",
                record.line_thickness * thickness_scale,
            )
            # Motion Blur is a post effect and is intentionally absent from
            # the canonical impact-mask shader contract.
            shader.uniform_float("subjectMotion", tuple(capture.subject_motion))
            shader.uniform_float(
                "backgroundMotion", tuple(capture.background_motion),
            )
            shader.uniform_float("backgroundAffineX", affine_x)
            shader.uniform_float("backgroundAffineY", affine_y)
            shader.uniform_float(
                "subjectAcceleration", tuple(capture.subject_acceleration),
            )
            shader.uniform_float("salt", style_salt)
            shader.uniform_float("velocityScale", capture.velocity_scale)
            shader.uniform_float(
                "motionCurveInfluence",
                float(getattr(record, "motion_curve_influence", 1.0)),
            )
            shader.uniform_float(
                "backgroundIntensity",
                float(getattr(record, "background_intensity", 0.5)) *
                background_scale,
            )
            shader.uniform_float(
                "backgroundMotionInfluence",
                float(getattr(record, "background_motion", 0.5)),
            )
            shader.uniform_float("bandTransition", record.band_transition)
            shader.uniform_float(
                "radialThreshold",
                float(getattr(record, "radial_threshold", 0.5)),
            )
            shader.uniform_float(
                "radialSpiral",
                float(getattr(record, "radial_spiral", 0.0)),
            )
            shader.uniform_float("contrast", record.contrast)
            shader.uniform_float("lightIntensity", light_energy)
            gpu.state.blend_set("NONE")
            batch.draw(shader)
        return target

    if len(modes) == 1:
        target = draw_mode(modes[0])
    else:
        radial_target = draw_mode(1, layer_only=True)
        linear_target = draw_mode(0)
        target = _offscreen(width, height, high_precision=True)
        layer_shader = _shader(
            "impact_layers", "fullscreen.vert", "impact_layers.frag",
        )
        with target.bind():
            framebuffer = gpu.state.active_framebuffer_get()
            framebuffer.clear(color=(0.0, 0.0, 0.0, 1.0), depth=1.0)
            layer_shader.uniform_sampler(
                "subjectTex", radial_target.texture_color,
            )
            layer_shader.uniform_sampler(
                "floorTex", linear_target.texture_color,
            )
            gpu.state.blend_set("NONE")
            batch.draw(layer_shader)
        radial_target.free()
        linear_target.free()
    _cache_put(_mask_cache, key, target, width * height, _MASK_PIXEL_BUDGET)
    return target


def _render_size(context, max_dimension=None):
    scene = context.scene
    # Impact frames are camera-output assets, so completed caches and exported
    # PNGs always use the literal Output Properties X/Y dimensions. The render
    # percentage is a temporary render-performance scale and must not silently
    # reduce a keyed post-effect asset.
    width = max(16, int(scene.render.resolution_x))
    height = max(16, int(scene.render.resolution_y))
    if max_dimension:
        preview_scale = float(max_dimension) / max(width, height)
        width = max(16, int(width * preview_scale))
        height = max(16, int(height * preview_scale))
    return width, height


def _preview_dimension(context, camera):
    # Preview geometry must not change when a sidebar, tooltip, or property
    # editor resizes the viewport. Use one deterministic reconstruction size
    # derived solely from output settings; live and applied preview therefore
    # evaluate exactly the same procedural stroke field.
    scene = context.scene
    output_long_edge = max(
        16, int(scene.render.resolution_x), int(scene.render.resolution_y),
    )
    return max(800, min(1536, output_long_edge))


def _image_name(camera, record):
    return f"{CACHE_PREFIX}{camera.name_full} - {record.frame} - {record.salt}"


def _write_offscreen_to_image(offscreen, image, width, height):
    key = (int(width), int(height))
    pixels = _readback_buffers.pop(key, None)
    if pixels is None:
        pixels = gpu.types.Buffer("FLOAT", width * height * 4)
    with offscreen.bind():
        framebuffer = gpu.state.active_framebuffer_get()
        framebuffer.read_color(
            0, 0, width, height, 4, 0, "FLOAT", data=pixels,
        )
    pixels.dimensions = width * height * 4
    if tuple(image.size) != (width, height):
        image.scale(width, height)
    image.pixels.foreach_set(pixels)
    image.update()
    # Retain the common interactive buffers, but never pin a 4K/8K float
    # readback (128 MiB/512 MiB) after its one required Image upload.
    weight = int(width) * int(height) * 4 * 4
    if weight <= _READBACK_BYTE_BUDGET:
        _readback_buffers[key] = pixels
        total = sum(
            int(size[0]) * int(size[1]) * 4 * 4
            for size in _readback_buffers
        )
        while (_readback_buffers and (
                len(_readback_buffers) > _READBACK_BUFFER_BUDGET
                or total > _READBACK_BYTE_BUDGET)):
            old_size, _old_buffer = _readback_buffers.popitem(last=False)
            total -= int(old_size[0]) * int(old_size[1]) * 4 * 4


def _mark_display_upload(image_key, timestamp=None):
    """Bound upload bookkeeping even when an image has not been drawn yet."""
    image_key = str(image_key)
    _display_upload_seen.pop(image_key, None)
    _display_upload_seen[image_key] = (
        time.monotonic() if timestamp is None else float(timestamp)
    )
    while len(_display_upload_seen) > _DISPLAY_UPLOAD_BUDGET:
        _display_upload_seen.popitem(last=False)


def _configure_grain_shader(
    shader, record, width, height, paper_width=None, paper_height=None,
):
    shader.uniform_float(
        "paperResolution",
        (float(paper_width or width), float(paper_height or height)),
    )
    shader.uniform_float(
        "dustAmount", max(0.0, min(1.0, record.grain)) * 100.0,
    )
    shader.uniform_float(
        "filmAmount",
        max(0.0, min(1.0, record.grain_overlay_intensity)) * 100.0,
    )
    shader.uniform_float("salt", _frame_seed(record))


def _capture_key(camera, record):
    return camera.name_full, int(record.salt), int(record.frame)


def _capture_byte_weight(capture):
    """Conservative CPython-object estimate for duplicated capture payloads."""
    total = 0
    for geometry in (capture.subject, capture.floor):
        vertices = len(geometry.positions)
        # Four lists of tuples containing Python float objects are much larger
        # than their packed numeric payload. Include tuple/list references and
        # allocator overhead so the 128 MiB policy means roughly 128 MiB.
        total += vertices * 640
        total += len(geometry.triangles) * 160
    return max(1, total)


def _capture_cache_get(key):
    item = _capture_cache.pop(key, None)
    if item is None:
        return None
    _capture_cache[key] = item
    return item[0]


def _capture_cache_remove(key):
    global _capture_cache_bytes
    item = _capture_cache.pop(key, None)
    if item is not None:
        _capture_cache_bytes = max(0, _capture_cache_bytes - int(item[1]))
    return item


def _capture_cache_put(key, capture):
    global _capture_cache_bytes
    _capture_cache_remove(key)
    weight = _capture_byte_weight(capture)
    _capture_cache[key] = (capture, weight)
    _capture_cache_bytes += weight
    while _capture_cache_bytes > _CAPTURE_BYTE_BUDGET and len(_capture_cache) > 1:
        _old_key, (_old_capture, weight) = _capture_cache.popitem(last=False)
        _capture_cache_bytes -= int(weight)
    return capture


def capture_cache_stats():
    """Expose bounded session ownership for diagnostics and soak tests."""
    return {
        "entries": len(_capture_cache),
        "estimated_bytes": int(_capture_cache_bytes),
        "budget_bytes": _CAPTURE_BYTE_BUDGET,
    }


def _capture_mesh_name(camera, record, role):
    return f".Impaction Capture - {camera.name_full} - {record.frame} - {record.salt} - {role}"


def _remove_capture_mesh(name):
    mesh = bpy.data.meshes.get(name) if name else None
    if mesh is not None:
        mesh.use_fake_user = False
        if mesh.users == 0:
            bpy.data.meshes.remove(mesh)


def _write_capture_mesh(
        name, geometry, velocity_scale, role_motion, role_acceleration,
        temporal):
    _remove_capture_mesh(name)
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(geometry.positions, (), geometry.triangles)
    normals = mesh.attributes.new("impaction_normal", type="FLOAT_VECTOR", domain="POINT")
    velocities = mesh.attributes.new("impaction_velocity", type="FLOAT_VECTOR", domain="POINT")
    accelerations = mesh.attributes.new(
        "impaction_acceleration", type="FLOAT_VECTOR", domain="POINT",
    )
    if geometry.positions:
        normals.data.foreach_set(
            "vector", array("f", (component for value in geometry.normals for component in value)),
        )
        velocities.data.foreach_set(
            "vector", array(
                "f", (
                    component
                    for value in geometry.velocities
                    for component in (value[0], value[1], 0.0)
                )
            ),
        )
        accelerations.data.foreach_set(
            "vector", array(
                "f", (
                    component
                    for value in geometry.accelerations
                    for component in (value[0], value[1], 0.0)
                )
            ),
        )
    mesh["impaction_velocity_scale"] = float(velocity_scale)
    mesh["impaction_motion_x"] = float(role_motion[0])
    mesh["impaction_motion_y"] = float(role_motion[1])
    mesh["impaction_acceleration_x"] = float(role_acceleration[0])
    mesh["impaction_acceleration_y"] = float(role_acceleration[1])
    mesh["impaction_temporal_capture"] = bool(temporal)
    mesh.update()
    mesh.use_fake_user = True
    return mesh


def _read_capture_mesh(name):
    mesh = bpy.data.meshes.get(name) if name else None
    if mesh is None:
        return None, None, (0.0, 0.0), (0.0, 0.0), False
    normal_attribute = mesh.attributes.get("impaction_normal")
    velocity_attribute = mesh.attributes.get("impaction_velocity")
    acceleration_attribute = mesh.attributes.get("impaction_acceleration")
    # Captures written before local acceleration existed can still claim to be
    # temporal. Treat them as stale instead of silently rendering a zero arc;
    # _record_capture will rebuild frame-1/current/frame+1 on first use.
    if (normal_attribute is None or velocity_attribute is None
            or acceleration_attribute is None):
        return None, None, (0.0, 0.0), (0.0, 0.0), False
    count = len(mesh.vertices)
    coordinates = array("f", [0.0]) * (count * 3)
    normals = array("f", [0.0]) * (count * 3)
    velocities = array("f", [0.0]) * (count * 3)
    accelerations = array("f", [0.0]) * (count * 3)
    if count:
        mesh.vertices.foreach_get("co", coordinates)
        normal_attribute.data.foreach_get("vector", normals)
        velocity_attribute.data.foreach_get("vector", velocities)
        if acceleration_attribute is not None:
            acceleration_attribute.data.foreach_get("vector", accelerations)
    geometry = CaptureGeometry(
        [tuple(coordinates[index:index + 3]) for index in range(0, len(coordinates), 3)],
        [tuple(normals[index:index + 3]) for index in range(0, len(normals), 3)],
        [tuple(velocities[index:index + 2]) for index in range(0, len(velocities), 3)],
        [tuple(accelerations[index:index + 2]) for index in range(0, len(accelerations), 3)],
        [tuple(polygon.vertices) for polygon in mesh.polygons],
    )
    return (
        geometry,
        float(mesh.get("impaction_velocity_scale", 1.0)),
        (
            float(mesh.get("impaction_motion_x", 0.0)),
            float(mesh.get("impaction_motion_y", 0.0)),
        ),
        (
            float(mesh.get("impaction_acceleration_x", 0.0)),
            float(mesh.get("impaction_acceleration_y", 0.0)),
        ),
        bool(mesh.get("impaction_temporal_capture", False)),
    )


def _persistent_capture_available(record):
    return bool(
        record
        and record.capture_subject and bpy.data.meshes.get(record.capture_subject)
        and record.capture_floor and bpy.data.meshes.get(record.capture_floor)
    )


def _load_persistent_capture(record):
    if not _persistent_capture_available(record):
        return None
    subject_data = _read_capture_mesh(record.capture_subject)
    floor_data = _read_capture_mesh(record.capture_floor)
    subject, subject_scale, subject_motion, subject_acceleration, subject_temporal = subject_data
    floor, floor_scale, background_motion, background_acceleration, floor_temporal = floor_data
    if subject is None or floor is None:
        return None
    return ImpactCapture(
        subject, floor, max(subject_scale, floor_scale),
        subject_motion=subject_motion,
        background_motion=background_motion,
        subject_acceleration=subject_acceleration,
        background_acceleration=background_acceleration,
        temporal=bool(subject_temporal and floor_temporal),
    )


def _store_persistent_capture(camera, record, capture):
    subject_name = _capture_mesh_name(camera, record, "Subject")
    floor_name = _capture_mesh_name(camera, record, "Floor")
    old_names = (str(record.capture_subject), str(record.capture_floor))
    subject = _write_capture_mesh(
        subject_name, capture.subject, capture.velocity_scale,
        capture.subject_motion, capture.subject_acceleration, capture.temporal,
    )
    floor = _write_capture_mesh(
        floor_name, capture.floor, capture.velocity_scale,
        capture.background_motion, capture.background_acceleration, capture.temporal,
    )
    record.capture_subject = subject.name
    record.capture_floor = floor.name
    for old_name in old_names:
        if old_name not in {subject.name, floor.name}:
            _remove_capture_mesh(old_name)


def _delete_persistent_capture(record):
    names = (str(record.capture_subject), str(record.capture_floor))
    record.capture_subject = ""
    record.capture_floor = ""
    for name in names:
        _remove_capture_mesh(name)


def invalidate_capture(camera, record):
    if camera is None or record is None:
        return
    camera_name = camera.name_full
    salt = int(record.salt)
    for key in tuple(_capture_cache):
        if key[0] == camera_name and key[1] == salt:
            _capture_cache_remove(key)
    _purge_surface_cache(camera_name, salt)


def has_cached_capture(camera, record):
    return bool(
        camera is not None and record is not None
        and (_capture_key(camera, record) in _capture_cache or _persistent_capture_available(record))
    )


def retime_capture(camera, record, old_frame):
    """Move cached source geometry with a retimed key without regenerating it."""
    if camera is None or record is None:
        return
    old_key = (camera.name_full, int(record.salt), int(old_frame))
    item = _capture_cache_remove(old_key)
    capture = item[0] if item is not None else None
    if capture is not None:
        _capture_cache_put(_capture_key(camera, record), capture)
    _purge_surface_cache(camera.name_full, int(record.salt))


def duplicate_record_cache(camera, source, target):
    """Clone a completed frame without reevaluating geometry or rerendering it."""
    source_capture = (
        _capture_cache_get(_capture_key(camera, source))
        or _load_persistent_capture(source)
    )
    if source_capture is not None:
        _capture_cache_put(_capture_key(camera, target), source_capture)
        _store_persistent_capture(camera, target, source_capture)
    source_image = cached_image(source)
    if source_image is None:
        target.cache_valid = False
        target.cache_image = ""
        target.cache_signature = ""
        return
    name = _image_name(camera, target)
    stale = bpy.data.images.get(name)
    if stale is not None and stale.users == 0:
        bpy.data.images.remove(stale)
    clone = source_image.copy()
    clone.name = name
    try:
        clone.pack()
    except RuntimeError:
        pass
    clone.use_fake_user = True
    target.cache_image = clone.name
    target.cache_valid = True
    target.cache_signature = record_render_signature(
        target, getattr(bpy.context, "scene", None),
    )
    target["_render_cache_version"] = _RENDER_CACHE_VERSION


def delete_record_cache(camera, record):
    """Remove both the CPU capture and packed image owned by a deleted key."""
    invalidate_capture(camera, record)
    _delete_persistent_capture(record)
    clear_record_preview(camera, record)
    image = bpy.data.images.get(record.cache_image) if record.cache_image else None
    record.cache_valid = False
    record.cache_image = ""
    record.cache_signature = ""
    if image is not None:
        image.use_fake_user = False
        if image.users == 0:
            bpy.data.images.remove(image)


def detach_record_cache(camera, record):
    """Detach ownership while retaining native pixels/meshes for Blender Undo."""
    capture = None
    for key in tuple(_capture_cache):
        if key[0] == camera.name_full and key[1] == int(record.salt):
            item = _capture_cache_remove(key)
            capture = (item[0] if item is not None else None) or capture
    _purge_surface_cache(camera.name_full, int(record.salt))
    clear_record_preview(camera, record)
    # The persistent capture meshes below are authoritative. Keeping the same
    # high-poly geometry a second time as Python tuples in every undo snapshot
    # made delete/redo sessions grow without bound.
    state = (
        None, str(record.cache_image), bool(record.cache_valid),
        str(getattr(record, "cache_signature", "")),
        str(record.capture_subject), str(record.capture_floor),
    )
    record.cache_image = ""
    record.cache_valid = False
    record.cache_signature = ""
    record.capture_subject = ""
    record.capture_floor = ""
    return state


def restore_record_cache(camera, record, state):
    """Reattach a deletion snapshot without rerendering its imagery."""
    if not state:
        return
    capture, image_name, was_valid, *remaining = state
    if len(remaining) >= 3:
        signature, *capture_names = remaining
    else:
        signature, capture_names = "", remaining
    if capture is not None:
        _capture_cache_put(_capture_key(camera, record), capture)
    image = bpy.data.images.get(image_name) if image_name else None
    record.cache_image = image.name if image is not None else ""
    record.cache_valid = bool(was_valid and _valid_image(image))
    record.cache_signature = str(signature) if record.cache_valid else ""
    if len(capture_names) >= 2:
        record.capture_subject = (
            capture_names[0] if bpy.data.meshes.get(capture_names[0]) is not None else ""
        )
        record.capture_floor = (
            capture_names[1] if bpy.data.meshes.get(capture_names[1]) is not None else ""
        )


def _record_capture(context, camera, record, recapture=False):
    key = _capture_key(camera, record)
    if recapture:
        invalidate_capture(camera, record)
    capture = _capture_cache_get(key)
    if capture is None and not recapture:
        capture = _load_persistent_capture(record)
    motion_curve_influence = float(getattr(
        record, "motion_curve_influence", 1.0,
    ))
    background_temporal = (
        float(getattr(record, "background_intensity", 0.5)) > 0.000001
        and float(getattr(record, "background_motion", 0.5)) > 0.000001
    )
    needs_temporal = (
        motion_curve_influence > 0.000001 or background_temporal
    )
    if (capture is not None and needs_temporal and
            not bool(getattr(capture, "temporal", False))):
        capture = None
    if capture is None:
        scene = context.scene
        original_frame = scene.frame_current
        original_subframe = scene.frame_subframe
        moved_frame = (
            int(original_frame) != int(record.frame)
            or abs(float(original_subframe)) > 1.0e-8
        )
        try:
            if moved_frame:
                scene.frame_set(int(record.frame), subframe=0.0)
            capture = (
                capture_impact(context, camera)
                if needs_temporal else capture_current_impact(context, camera)
            )
        finally:
            if moved_frame:
                scene.frame_set(original_frame, subframe=original_subframe)
        _store_persistent_capture(camera, record, capture)
    _capture_cache_put(key, capture)
    return capture


def recapture_records(context, camera, records):
    """Capture keyed geometry and adjacent samples in one ordered pass."""
    records = tuple(records)
    if not records:
        return
    for record in records:
        invalidate_capture(camera, record)
    scene = context.scene
    original_frame = scene.frame_current
    original_subframe = scene.frame_subframe
    try:
        ordered = sorted(records, key=lambda item: int(item.frame))
        captures = capture_impacts(
            context, camera, (int(record.frame) for record in ordered),
        )
        for record in ordered:
            capture = captures[int(record.frame)]
            _capture_cache_put(_capture_key(camera, record), capture)
            _store_persistent_capture(camera, record, capture)
    finally:
        scene.frame_set(original_frame, subframe=original_subframe)


def render_record(
    context, camera, record, *, preview=False, recapture=False,
    apply_preview=False, retain_gpu_preview=False,
):
    if camera is None or camera.type != "CAMERA":
        raise RuntimeError("The viewed camera is unavailable.")
    paper_width, paper_height = _render_size(context)
    width, height = _render_size(
        context, max_dimension=_preview_dimension(context, camera) if preview else None,
    )
    capture = _record_capture(context, camera, record, recapture=recapture)
    subject, floor, motion = _rasterized_capture(
        camera, record, capture, width, height,
    )
    # Effects need linear half-float intermediates. Repeated 8-bit bloom mip
    # quantization produces visible contour shelves and apparent low resolution.
    direct_key = (
        (camera.name_full, int(record.salt))
        if preview and retain_gpu_preview and not apply_preview else None
    )
    previous_direct = _preview_surfaces.pop(direct_key, None) if direct_key else None
    if (previous_direct is not None
            and int(previous_direct[2]) == int(width)
            and int(previous_direct[3]) == int(height)):
        final = previous_direct[0]
    else:
        if previous_direct is not None:
            _free_surface(previous_direct[0])
        final = _offscreen(width, height, high_precision=True)
    motion_blur_amount = max(0.0, min(1.0, record.motion_blur))
    aberration_amount = max(0.0, min(1.0, record.chromatic_aberration))
    bloom_amount = max(0.0, min(1.0, record.bloom))
    grain_amount = max(
        max(0.0, min(1.0, record.grain)),
        max(0.0, min(1.0, record.grain_overlay_intensity)),
    )
    halftone_amount = max(0.0, min(1.0, record.halftone))
    pixelate_amount = max(0.0, min(1.0, record.pixelate))
    needs_motion_blur = motion_blur_amount > 0.0001
    needs_aberration = aberration_amount > 0.0001
    needs_bloom = bloom_amount > 0.0001
    needs_grain = grain_amount > 0.0001
    needs_pixelate = pixelate_amount > 0.0001 and record.pixelate_size > 1
    needs_post = (
        needs_grain or needs_pixelate or needs_motion_blur
        or needs_aberration or needs_bloom
    )
    composite_buffer = (
        _offscreen(width, height, high_precision=True)
        if needs_post else None
    )
    chromatic = (
        _offscreen(width, height, high_precision=True)
        if needs_aberration and needs_bloom else None
    )
    motion_surface = (
        _offscreen(width, height, high_precision=True)
        if needs_motion_blur and (needs_aberration or needs_bloom) else None
    )
    grain_mask = (
        _offscreen(width, height, high_precision=True) if needs_grain else None
    )
    grain_surface = (
        _offscreen(width, height, high_precision=True)
        if needs_grain and (
            needs_pixelate or needs_motion_blur or needs_aberration or needs_bloom
        ) else None
    )
    pixelate_surface = (
        _offscreen(width, height, high_precision=True)
        if needs_pixelate and (
            needs_motion_blur or needs_aberration or needs_bloom
        ) else None
    )
    bloom_emission = (
        _offscreen(width, height, high_precision=True) if needs_bloom else None
    )
    grade_surface = None
    shape_surface = None
    shape_mask_surface = None
    shape_texture = None
    bloom_levels = []
    bloom_upsamples = []
    retained_surface = None
    try:
        shader = _shader("composite", "fullscreen.vert", "composite.frag")
        batch = _fullscreen_quad(shader)
        mask = _impact_mask(
            camera, record, capture, subject, floor, motion,
            width, height, batch,
            paper_width, paper_height,
        )
        # Flip exchanges the two base endpoints first. Invert remains an
        # independent full-frame photographic negative applied after every
        # effect and grade, so enabling both intentionally performs both.
        raw_foreground, raw_background = _frame_palette(record)
        # Grade after the complete optical pipeline so contrast and grayscale
        # also affect bloom, spectral dispersion, halftone and grain.
        foreground = raw_foreground
        background = raw_background
        gradient, _gradient_norm = aberration_gradient_samples(record)
        logical_aberration_colors = (
            aberration_colors(record)
            if record.aberration_preset == "CUSTOM" else ()
        )
        single_aberration_color = (
            logical_aberration_colors[0]
            if len(logical_aberration_colors) == 1
            else (0.0, 0.0, 0.0, 1.0)
        )
        effective_light_color, light_energy, light_source = _effective_light(
            record, raw_foreground, raw_background,
        )
        # Texel 17 carries light RGB plus intensity. Texel 18 carries the
        # artist-selected source mode, because inferring the mode from equal
        # RGB values makes Custom black/gray collide with palette endpoints.
        light_source_code = {
            "FOREGROUND": 0.0,
            "BACKGROUND": 1.0,
            "CUSTOM": 2.0,
        }.get(light_source, 0.0)
        composite_parameters = tuple(gradient) + ((
            float(effective_light_color[0]), float(effective_light_color[1]),
            float(effective_light_color[2]), float(light_energy),
        ), (light_source_code, 0.0, 0.0, 0.0))
        gradient_texture = _gradient_texture(composite_parameters)
        def draw_composite(target, grain_texture, grain_active):
            with target.bind():
                framebuffer = gpu.state.active_framebuffer_get()
                framebuffer.clear(color=background, depth=1.0)
                shader.uniform_sampler("impactTex", mask.texture_color)
                shader.uniform_sampler("subjectTex", subject.texture_color)
                shader.uniform_sampler("gradientTex", gradient_texture)
                shader.uniform_sampler("grainTex", grain_texture)
                shader.uniform_float("resolution", (float(width), float(height)))
                shader.uniform_int("mode", _effect_mode(record))
                shader.uniform_float(
                    "angle", _resolved_direction_angle(record),
                )
                shader.uniform_float("focus", _effect_focus(record))
                # Spectral displacement is applied once, after shapes have
                # joined the composite. Keeping the old pre-shape pass active
                # left crisp, unprocessed shape/background lines underneath.
                shader.uniform_float("aberration", 0.0)
                shader.uniform_float("foreground", foreground)
                shader.uniform_float("background", background)
                shader.uniform_float(
                    "bleedAmount", float(getattr(record, "bleed", 0.5)),
                )
                shader.uniform_float("halftone", halftone_amount)
                shader.uniform_float("halftoneSize", float(record.halftone_size))
                shader.uniform_float("aberrationSpread", 1.5)
                shader.uniform_float("aberrationIntensity", 2.0)
                shader.uniform_float("grainActive", grain_active)
                shader.uniform_float(
                    "singleColorActive",
                    1.0 if len(logical_aberration_colors) == 1 else 0.0,
                )
                shader.uniform_float("singleColor", single_aberration_color)
                shader.uniform_float(
                    "directionPolarity", _effect_polarity(record),
                )
                shader.uniform_float(
                    "cameraMotion", tuple(capture.background_motion),
                )
                gpu.state.blend_set("NONE")
                batch.draw(shader)

        composite_target = composite_buffer or final
        draw_composite(composite_target, mask.texture_color, 0.0)
        processed_surface = composite_target

        if grain_mask is not None:
            grain_shader = _shader("grain", "fullscreen.vert", "grain.frag")
            with grain_mask.bind():
                framebuffer = gpu.state.active_framebuffer_get()
                framebuffer.clear(color=(0.0, 0.0, 0.0, 1.0), depth=1.0)
                grain_shader.uniform_sampler("impactTex", mask.texture_color)
                _configure_grain_shader(
                    grain_shader, record, width, height,
                    paper_width, paper_height,
                )
                gpu.state.blend_set("NONE")
                batch.draw(grain_shader)
            grain_target = grain_surface or final
            draw_composite(grain_target, grain_mask.texture_color, 1.0)
            processed_surface = grain_target

        # Shapes must enter the image before spatial post effects. The old
        # post-bloom placement made Pixelate, Motion Blur, Aberration and Bloom
        # mathematically incapable of affecting a star or doodle.
        if record.shapes:
            shape_texture, shape_count = _shape_texture(record)
            shape_shader = _shader("shapes", "fullscreen.vert", "shapes.frag")
            shape_mask_surface = _offscreen(width, height, high_precision=True)
            with shape_mask_surface.bind():
                framebuffer = gpu.state.active_framebuffer_get()
                framebuffer.clear(color=(0.0, 0.0, 0.0, 1.0), depth=1.0)
                shape_shader.uniform_sampler("colorTex", processed_surface.texture_color)
                shape_shader.uniform_sampler("subjectTex", subject.texture_color)
                shape_shader.uniform_sampler("shapeTex", shape_texture)
                shape_shader.uniform_sampler("impactTex", mask.texture_color)
                shape_shader.uniform_sampler(
                    "grainTex", grain_mask.texture_color
                    if grain_mask is not None else mask.texture_color,
                )
                shape_shader.uniform_float("resolution", (float(width), float(height)))
                shape_shader.uniform_int("shapeCount", shape_count)
                shape_shader.uniform_int("maskOnly", 1)
                shape_shader.uniform_float("halftone", halftone_amount)
                shape_shader.uniform_float("halftoneSize", float(record.halftone_size))
                shape_shader.uniform_float("grainActive", 1.0 if grain_mask is not None else 0.0)
                gpu.state.blend_set("NONE")
                batch.draw(shape_shader)
            shape_surface = _offscreen(width, height, high_precision=True)
            with shape_surface.bind():
                framebuffer = gpu.state.active_framebuffer_get()
                framebuffer.clear(color=background, depth=1.0)
                shape_shader.uniform_sampler("colorTex", processed_surface.texture_color)
                shape_shader.uniform_sampler("subjectTex", subject.texture_color)
                shape_shader.uniform_sampler("shapeTex", shape_texture)
                shape_shader.uniform_sampler("impactTex", mask.texture_color)
                shape_shader.uniform_sampler(
                    "grainTex", grain_mask.texture_color
                    if grain_mask is not None else mask.texture_color,
                )
                shape_shader.uniform_float("resolution", (float(width), float(height)))
                shape_shader.uniform_int("shapeCount", shape_count)
                shape_shader.uniform_int("maskOnly", 0)
                shape_shader.uniform_float("halftone", halftone_amount)
                shape_shader.uniform_float("halftoneSize", float(record.halftone_size))
                shape_shader.uniform_float("grainActive", 1.0 if grain_mask is not None else 0.0)
                gpu.state.blend_set("NONE")
                batch.draw(shape_shader)
            processed_surface = shape_surface
        if shape_mask_surface is not None:
            shape_effect_texture = shape_mask_surface.texture_color
        else:
            shape_effect_texture = _empty_texture()
        if needs_motion_blur:
            motion_shader = _shader(
                "motion_blur", "fullscreen.vert", "motion_blur.frag",
            )
            motion_target = motion_surface or final
            with motion_target.bind():
                framebuffer = gpu.state.active_framebuffer_get()
                framebuffer.clear(color=background, depth=1.0)
                motion_shader.uniform_sampler(
                    "colorTex", processed_surface.texture_color,
                )
                motion_shader.uniform_sampler("impactTex", mask.texture_color)
                motion_shader.uniform_sampler("shapeMaskTex", shape_effect_texture)
                motion_shader.uniform_float(
                    "resolution", (float(width), float(height)),
                )
                motion_shader.uniform_int("mode", _effect_mode(record))
                motion_shader.uniform_float(
                    "angle", _resolved_direction_angle(record),
                )
                motion_shader.uniform_float("focus", _effect_focus(record))
                motion_shader.uniform_float("amount", motion_blur_amount)
                motion_shader.uniform_float(
                    "directionPolarity", _effect_polarity(record),
                )
                motion_shader.uniform_float(
                    "cameraMotion", tuple(capture.background_motion),
                )
                gpu.state.blend_set("NONE")
                batch.draw(motion_shader)
            processed_surface = motion_target
        if needs_aberration:
            aberration_shader = _shader(
                "aberration_blend", "fullscreen.vert", "aberration_blend.frag",
            )
            aberration_target = chromatic or final
            with aberration_target.bind():
                framebuffer = gpu.state.active_framebuffer_get()
                framebuffer.clear(color=background, depth=1.0)
                aberration_shader.uniform_sampler("colorTex", processed_surface.texture_color)
                aberration_shader.uniform_sampler(
                    "grainTex",
                    grain_mask.texture_color if grain_mask is not None
                    else mask.texture_color,
                )
                aberration_shader.uniform_sampler("impactTex", mask.texture_color)
                aberration_shader.uniform_sampler("shapeMaskTex", shape_effect_texture)
                aberration_shader.uniform_sampler("gradientTex", gradient_texture)
                aberration_shader.uniform_float("resolution", (float(width), float(height)))
                aberration_shader.uniform_int("mode", _effect_mode(record))
                aberration_shader.uniform_float(
                    "angle", _resolved_direction_angle(record),
                )
                aberration_shader.uniform_float("focus", _effect_focus(record))
                aberration_shader.uniform_float("aberration", aberration_amount * 100.0)
                aberration_shader.uniform_float("halftone", halftone_amount)
                aberration_shader.uniform_float("aberrationBlur", 1.0)
                aberration_shader.uniform_float("aberrationIntensity", 2.0)
                aberration_shader.uniform_float("foreground", foreground)
                aberration_shader.uniform_float("background", background)
                aberration_shader.uniform_float(
                    "singleColorActive",
                    1.0 if len(logical_aberration_colors) == 1 else 0.0,
                )
                aberration_shader.uniform_float("singleColor", single_aberration_color)
                aberration_shader.uniform_float(
                    "blurSmoothing",
                    1.0 if getattr(record, "aberration_blur_smoothing", True) else 0.0,
                )
                aberration_shader.uniform_float(
                    "grainActive", 1.0 if grain_mask is not None else 0.0,
                )
                aberration_shader.uniform_float(
                    "directionPolarity", _effect_polarity(record),
                )
                aberration_shader.uniform_float(
                    "cameraMotion", tuple(capture.background_motion),
                )
                gpu.state.blend_set("NONE")
                batch.draw(aberration_shader)
            processed_surface = aberration_target

        if needs_bloom:
            extract_shader = _shader("bloom_extract", "fullscreen.vert", "bloom_extract.frag")
            with bloom_emission.bind():
                framebuffer = gpu.state.active_framebuffer_get()
                framebuffer.clear(color=(0.0, 0.0, 0.0, 1.0), depth=1.0)
                extract_shader.uniform_sampler("colorTex", processed_surface.texture_color)
                extract_shader.uniform_sampler("impactTex", mask.texture_color)
                extract_shader.uniform_sampler("shapeMaskTex", shape_effect_texture)
                extract_shader.uniform_sampler(
                    "grainTex",
                    grain_mask.texture_color if grain_mask is not None
                    else mask.texture_color,
                )
                extract_shader.uniform_float("resolution", (float(width), float(height)))
                extract_shader.uniform_float("foreground", foreground)
                extract_shader.uniform_float("background", background)
                extract_shader.uniform_float("aberrationActive", float(needs_aberration))
                extract_shader.uniform_float(
                    "grainActive", 1.0 if grain_mask is not None else 0.0,
                )
                extract_shader.uniform_float("grainBloomMix", 1.0)
                gpu.state.blend_set("NONE")
                batch.draw(extract_shader)

            down_shader = _shader("bloom_down", "fullscreen.vert", "bloom_down.frag")
            source_surface = bloom_emission
            source_width, source_height = width, height
            mip_count = max(3, min(6, int(math.log2(max(16, min(width, height)))) - 4))
            for _level in range(mip_count):
                level_width = max(16, source_width // 2)
                level_height = max(16, source_height // 2)
                level_surface = _offscreen(level_width, level_height, high_precision=True)
                with level_surface.bind():
                    framebuffer = gpu.state.active_framebuffer_get()
                    framebuffer.clear(color=(0.0, 0.0, 0.0, 1.0), depth=1.0)
                    down_shader.uniform_sampler("colorTex", source_surface.texture_color)
                    down_shader.uniform_float(
                        "sourceResolution", (float(source_width), float(source_height)),
                    )
                    gpu.state.blend_set("NONE")
                    batch.draw(down_shader)
                bloom_levels.append((level_surface, level_width, level_height))
                source_surface = level_surface
                source_width, source_height = level_width, level_height

            up_shader = _shader("bloom_up", "fullscreen.vert", "bloom_up.frag")
            current_surface, current_width, current_height = bloom_levels[-1]
            # Linear radius allocation keeps deeper mips available for the
            # upper half of the slider instead of exhausting them near 50.
            spread = bloom_amount
            activations = [1.0]
            for level_index in range(1, len(bloom_levels)):
                low_edge = max(0.0, (level_index - 1.0) / len(bloom_levels))
                high_edge = min(1.0, (level_index + 0.65) / len(bloom_levels))
                value = max(0.0, min(1.0, (spread - low_edge) /
                                     max(0.001, high_edge - low_edge)))
                activations.append(value * value * (3.0 - 2.0 * value))
            first_upsample = True
            for high_index in range(len(bloom_levels) - 2, -1, -1):
                high_surface, high_width, high_height = bloom_levels[high_index]
                upsampled = _offscreen(high_width, high_height, high_precision=True)
                with upsampled.bind():
                    framebuffer = gpu.state.active_framebuffer_get()
                    framebuffer.clear(color=(0.0, 0.0, 0.0, 1.0), depth=1.0)
                    up_shader.uniform_sampler("lowTex", current_surface.texture_color)
                    up_shader.uniform_sampler("highTex", high_surface.texture_color)
                    up_shader.uniform_float(
                        "lowResolution", (float(current_width), float(current_height)),
                    )
                    up_shader.uniform_float(
                        "lowWeight",
                        activations[high_index + 1] if first_upsample else 1.0,
                    )
                    up_shader.uniform_float("highWeight", activations[high_index])
                    gpu.state.blend_set("NONE")
                    batch.draw(up_shader)
                bloom_upsamples.append(upsampled)
                current_surface = upsampled
                current_width, current_height = high_width, high_height
                first_upsample = False

            bloom_shader = _shader("bloom", "fullscreen.vert", "bloom.frag")
            bloom_target = final
            with bloom_target.bind():
                framebuffer = gpu.state.active_framebuffer_get()
                framebuffer.clear(color=background, depth=1.0)
                bloom_shader.uniform_sampler("colorTex", processed_surface.texture_color)
                bloom_shader.uniform_sampler("glowTex", current_surface.texture_color)
                bloom_shader.uniform_sampler("coreTex", bloom_levels[0][0].texture_color)
                bloom_shader.uniform_float("bloom", bloom_amount * 100.0)
                gpu.state.blend_set("NONE")
                batch.draw(bloom_shader)
            processed_surface = bloom_target

        # Pixelation is the final spatial transform. Aberration, bloom, and
        # motion abstraction may not displace sub-pixel source lines back into
        # an already-formed cell grid.
        if needs_pixelate:
            pixelate_shader = _shader(
                "pixelate", "fullscreen.vert", "pixelate.frag",
            )
            pixelate_target = pixelate_surface or final
            with pixelate_target.bind():
                framebuffer = gpu.state.active_framebuffer_get()
                framebuffer.clear(color=background, depth=1.0)
                pixelate_shader.uniform_sampler(
                    "colorTex", processed_surface.texture_color,
                )
                pixelate_shader.uniform_sampler("impactTex", mask.texture_color)
                pixelate_shader.uniform_sampler("shapeMaskTex", shape_effect_texture)
                pixelate_shader.uniform_float(
                    "resolution", (float(width), float(height)),
                )
                pixelate_shader.uniform_float("pixelate", pixelate_amount)
                pixelate_shader.uniform_float(
                    "pixelSize", float(record.pixelate_size),
                )
                gpu.state.blend_set("NONE")
                batch.draw(pixelate_shader)
            processed_surface = pixelate_target

        output_surface = processed_surface
        if (record.contrast > 0.0001 or record.grayscale > 0.0001
                or record.invert):
            grade_surface = _offscreen(width, height, high_precision=True)
            grade_shader = _shader("grade", "fullscreen.vert", "grade.frag")
            with grade_surface.bind():
                framebuffer = gpu.state.active_framebuffer_get()
                framebuffer.clear(color=background, depth=1.0)
                grade_shader.uniform_sampler("colorTex", processed_surface.texture_color)
                grade_shader.uniform_float("contrast", float(record.contrast))
                grade_shader.uniform_float("grayscale", float(record.grayscale))
                grade_shader.uniform_float("negative", 1.0 if record.invert else 0.0)
                gpu.state.blend_set("NONE")
                batch.draw(grade_shader)
            output_surface = grade_surface

        global _preview_generation
        if preview:
            _preview_generation += 1
            name = f"{_image_name(camera, record)} - Preview {_preview_generation}"
        else:
            name = _image_name(camera, record)
        if preview and retain_gpu_preview and not apply_preview:
            # The output surface is already the exact image the artist must
            # see. Keep it on the GPU during interaction instead of forcing a
            # GPU readback, allocating a float Image, and uploading the same
            # pixels back to the viewport for every mouse event. Settle reads
            # and packs this identical surface once via promote_record_preview.
            key = (camera.name_full, int(record.salt))
            previous_surface = _preview_surfaces.pop(key, None)
            if previous_surface is not None:
                _free_surface(previous_surface[0])
            previous_name = _preview_images.pop(key, None)
            previous_image = bpy.data.images.get(previous_name) if previous_name else None
            if (previous_image is not None
                    and previous_image.name != str(record.cache_image)
                    and not previous_image.use_fake_user
                    and previous_image.users == 0):
                bpy.data.images.remove(previous_image)
            signature = _current_render_signature(record, context.scene)
            _preview_surfaces[key] = (
                output_surface, signature, int(width), int(height), name,
            )
            _preview_signatures[key] = signature
            retained_surface = output_surface
            return output_surface
        old_name = record.cache_image
        image = bpy.data.images.get(name)
        if image is not None and not image.is_float:
            bpy.data.images.remove(image)
            image = None
        if image is None:
            image = bpy.data.images.new(
                name, width=width, height=height, alpha=True, float_buffer=True,
            )
        try:
            image.colorspace_settings.name = "Non-Color"
        except TypeError:
            pass
        _write_offscreen_to_image(output_surface, image, width, height)
        _mark_display_upload(image.name_full)
        if preview:
            # Publish only after the replacement has complete pixels. Retain
            # the previously displayed image through one further swap so an
            # image-backed GPU texture is never invalidated mid draw.
            _purge_retired_previews()
            key = (camera.name_full, int(record.salt))
            previous = _preview_images.get(key)
            _preview_images[key] = image.name
            _preview_signatures[key] = _current_render_signature(
                record, context.scene,
            )
            if previous and previous != image.name:
                _retired_preview_images.add(previous)
            if apply_preview:
                # The visible live result is the applied result. Do not issue
                # a second full-resolution render after the slider settles.
                # Applied slider pixels are project data, not an external
                # image-editor document. Packing here clears Image.is_dirty
                # immediately, preventing Blender's multi-image save prompt
                # while keeping the cache inside the .blend.
                if promote_record_preview(camera, record, context.scene) is None:
                    raise RuntimeError("live preview could not be packed and promoted")
        else:
            _internalize_image(image, pack=True)
            record.cache_image = name
            record.cache_valid = True
            record.cache_signature = _current_render_signature(record, context.scene)
            record["_render_cache_version"] = _RENDER_CACHE_VERSION
            clear_record_preview(camera, record)
            if old_name and old_name != name:
                stale = bpy.data.images.get(old_name)
                if stale and stale.users == 0:
                    stale.use_fake_user = False
                    bpy.data.images.remove(stale)
        if grade_surface is not None:
            grade_surface.free()
            grade_surface = None
        return image
    finally:
        if shape_texture is not None:
            try:
                shape_texture.free()
            except (AttributeError, ReferenceError, RuntimeError):
                pass
        if shape_surface is not None and shape_surface is not retained_surface:
            shape_surface.free()
        if (shape_mask_surface is not None
                and shape_mask_surface is not retained_surface):
            shape_mask_surface.free()
        for surface in reversed(bloom_upsamples):
            if surface is not retained_surface:
                surface.free()
        for surface, _level_width, _level_height in reversed(bloom_levels):
            if surface is not retained_surface:
                surface.free()
        if bloom_emission is not None and bloom_emission is not retained_surface:
            bloom_emission.free()
        if chromatic is not None and chromatic is not retained_surface:
            chromatic.free()
        if motion_surface is not None and motion_surface is not retained_surface:
            motion_surface.free()
        if grain_surface is not None and grain_surface is not retained_surface:
            grain_surface.free()
        if pixelate_surface is not None and pixelate_surface is not retained_surface:
            pixelate_surface.free()
        if grain_mask is not None and grain_mask is not retained_surface:
            grain_mask.free()
        if composite_buffer is not None and composite_buffer is not retained_surface:
            composite_buffer.free()
        if grade_surface is not None and grade_surface is not retained_surface:
            grade_surface.free()
        if final is not retained_surface:
            final.free()



def cached_image(record):
    if not record or not record.cache_valid:
        return None
    image = bpy.data.images.get(record.cache_image)
    if not _valid_image(image):
        record.cache_valid = False
        record.cache_signature = ""
        return None
    return image


def display_image(camera, record, prefer_preview=True):
    key = (camera.name_full, int(record.salt)) if camera and record else None
    preview_name = _preview_images.get(key) if key and prefer_preview else None
    preview_image = bpy.data.images.get(preview_name) if preview_name else None
    if _valid_image(preview_image):
        return preview_image
    if preview_name:
        _preview_images.pop(key, None)
        _preview_signatures.pop(key, None)
        if preview_image is not None and preview_image.name != record.cache_image:
            _retired_preview_images.add(preview_image.name)
    return cached_image(record)


def display_surface(camera, record, prefer_preview=True):
    """Return the exact on-GPU interactive result, when one is active."""
    if not prefer_preview or camera is None or record is None:
        return None
    return _preview_surfaces.get((camera.name_full, int(record.salt)))


def clear_record_preview(camera, record):
    if camera is None or record is None:
        return
    key = (camera.name_full, int(record.salt))
    surface_entry = _preview_surfaces.pop(key, None)
    if surface_entry is not None:
        _free_surface(surface_entry[0])
    name = _preview_images.pop(key, None)
    _preview_signatures.pop(key, None)
    image = bpy.data.images.get(name) if name else None
    if (image is not None and image.name != str(record.cache_image)
            and not image.use_fake_user and image.users == 0):
        bpy.data.images.remove(image)
    _purge_retired_previews()


def clear_transient_previews():
    """Drop session-only presentation aliases without deleting applied caches."""
    names = set(_preview_images.values()) | set(_retired_preview_images)
    for surface_entry in tuple(_preview_surfaces.values()):
        _free_surface(surface_entry[0])
    _preview_surfaces.clear()
    _preview_images.clear()
    _preview_signatures.clear()
    _retired_preview_images.clear()
    referenced = {
        str(record.cache_image)
        for owner in getattr(bpy.data, "objects", ())
        for record in getattr(owner, "impaction_frames", ())
        if record.cache_image
    }
    for name in names:
        image = bpy.data.images.get(name)
        if (image is not None and name not in referenced
                and not image.use_fake_user and image.users == 0):
            bpy.data.images.remove(image)


def _purge_retired_previews():
    referenced = {
        str(record.cache_image)
        for owner in getattr(bpy.data, "objects", ())
        for record in getattr(owner, "impaction_frames", ())
        if record.cache_image
    }
    for name in tuple(_retired_preview_images):
        image = bpy.data.images.get(name)
        if (image is not None and name not in referenced
                and not image.use_fake_user and image.users == 0):
            bpy.data.images.remove(image)
        _retired_preview_images.discard(name)


def camera_view_rect(context, camera):
    region = context.region
    region_3d = context.space_data.region_3d
    # Extension reloads can momentarily invoke a surviving POST_PIXEL handler
    # with a transitioning or non-camera region. Never turn a failed camera
    # projection into a full-viewport rectangle: an invalid/black managed
    # texture would otherwise cover the entire 3D view.
    if (region is None or region_3d is None or
            region_3d.view_perspective != "CAMERA"):
        return None
    points = []
    for corner in camera.data.view_frame(scene=context.scene):
        point = view3d_utils.location_3d_to_region_2d(
            region, region_3d, camera.matrix_world @ corner
        )
        if point is not None:
            points.append(point)
    if len(points) != 4:
        return None
    xs = [point.x for point in points]
    ys = [point.y for point in points]
    rect = min(xs), min(ys), max(xs), max(ys)
    if (not all(math.isfinite(value) for value in rect) or
            rect[2] - rect[0] < 2.0 or rect[3] - rect[1] < 2.0):
        return None
    return rect


def _viewport_shader():
    global _display_shader
    if _display_shader is None:
        try:
            _display_shader = (gpu.shader.from_builtin("IMAGE_COLOR"), True)
        except ValueError:
            _display_shader = (gpu.shader.from_builtin("IMAGE"), False)
    return _display_shader


def _viewport_texture(image):
    # Blender owns and invalidates image-backed GPU textures. Request its
    # managed handle without freeing a cache merely because the image was not
    # drawn recently. A sequence of applied Impact frames naturally revisits
    # each image after a gap; time-based gl_free()/update() turned that cheap
    # visibility change into a full-frame GPU upload on every recurrence.
    # Explicit image writes and clear_session_caches() already invalidate the
    # managed texture at the lifecycle boundaries where pixels can change.
    now = time.monotonic()
    image_key = image.name_full
    _mark_display_upload(image_key, now)
    try:
        # Prevent Blender's idle image collector from retiring the cache while
        # the user works outside camera view for an extended period.
        image.gl_touch()
    except (AttributeError, ReferenceError, RuntimeError):
        pass
    texture = gpu.texture.from_image(image)
    _enable_linear_filter(texture)
    return texture


def _viewport_batch(shader, context, rect, width, height):
    region = getattr(context, "region", None)
    region_key = region.as_pointer() if region is not None and hasattr(region, "as_pointer") else id(region)
    x0, y0, x1, y1 = rect
    width = max(1.0, float(width))
    height = max(1.0, float(height))
    key = (
        region_key, round(x0, 3), round(y0, 3), round(x1, 3), round(y1, 3),
        int(width), int(height), shader.as_pointer() if hasattr(shader, "as_pointer") else id(shader),
    )
    batch = _display_batches.pop(key, None)
    if batch is not None:
        _display_batches[key] = batch
        return batch
    # Cover Blender's anti-aliased camera outline completely, but crop two
    # source texels on every side so Film Grain's noisy edge rows are never
    # stretched into a dotted seam around the overscan.
    overscan = 4.0
    u0, v0 = 2.0 / width, 2.0 / height
    u1, v1 = 1.0 - u0, 1.0 - v0
    batch = batch_for_shader(
        shader, "TRI_FAN",
        {"pos": ((x0 - overscan, y0 - overscan),
                 (x1 + overscan, y0 - overscan),
                 (x1 + overscan, y1 + overscan),
                 (x0 - overscan, y1 + overscan)),
         "texCoord": ((u0, v0), (u1, v0), (u1, v1), (u0, v1))},
    )
    _display_batches[key] = batch
    while len(_display_batches) > _DISPLAY_BATCH_BUDGET:
        _display_batches.popitem(last=False)
    return batch


def _composition_thirds_segments(rect):
    x0, y0, x1, y1 = rect
    x_third = (x1 - x0) / 3.0
    y_third = (y1 - y0) / 3.0
    return (
        (x0 + x_third, y0), (x0 + x_third, y1),
        (x0 + x_third * 2.0, y0), (x0 + x_third * 2.0, y1),
        (x0, y0 + y_third), (x1, y0 + y_third),
        (x0, y0 + y_third * 2.0), (x1, y0 + y_third * 2.0),
    )


def _draw_camera_composition_guides(camera, rect):
    # POST_PIXEL impact images sit above Blender's native camera guides, so
    # restore the enabled thirds guide after the opaque replacement image.
    if not getattr(camera.data, "show_composition_thirds", False):
        return
    shader = gpu.shader.from_builtin("UNIFORM_COLOR")
    batch = batch_for_shader(
        shader, "LINES", {"pos": _composition_thirds_segments(rect)},
    )
    gpu.state.blend_set("ALPHA")
    shader.uniform_float("color", (0.72, 0.72, 0.72, 0.52))
    batch.draw(shader)
    gpu.state.blend_set("NONE")


def draw_cached_image(context, camera, record, opacity=1.0, prefer_preview=True):
    surface_entry = display_surface(
        camera, record, prefer_preview=prefer_preview,
    )
    if surface_entry is not None:
        surface, _signature, width, height, _name = surface_entry
        texture = surface.texture_color
    else:
        image = display_image(camera, record, prefer_preview=prefer_preview)
        if image is None:
            return False
        width, height = int(image.size[0]), int(image.size[1])
        texture = _viewport_texture(image)
    rect = camera_view_rect(context, camera)
    if rect is None:
        # No valid camera projection means there is intentionally nothing to
        # draw. Treat it as handled so the runtime does not schedule a costly
        # frame regeneration merely because another extension is reloading.
        return True
    shader, tinted = _viewport_shader()
    batch = _viewport_batch(shader, context, rect, width, height)
    gpu.state.blend_set("ALPHA")
    shader.uniform_sampler("image", texture)
    if tinted:
        shader.uniform_float("color", (1.0, 1.0, 1.0, float(opacity)))
    batch.draw(shader)
    gpu.state.blend_set("NONE")
    _draw_camera_composition_guides(camera, rect)
    return True


def draw_camera_pin_overlays(context, camera, record):
    """Draw camera pins above the opaque replacement; gizmos supply input."""
    if record is None:
        return
    from .impaction_gizmo import pin_highlighted
    rect = camera_view_rect(context, camera)
    if rect is None:
        return
    x0, y0, x1, y1 = rect
    shader = gpu.shader.from_builtin("UNIFORM_COLOR")
    gpu.state.blend_set("ALPHA")
    pins = []
    selected_shapes = {
        index for index, shape in enumerate(record.shapes)
        if bool(getattr(shape, "is_selected", False))
    }
    if not selected_shapes:
        pins.append(("DIRECTION", record.direction_focus, (1.0, 0.0, 1.0), False))
        pins.append(("LIGHT", record.light_focus, (1.0, 1.0, 0.0), False))
    for index, shape in enumerate(record.shapes):
        if index >= 16:
            break
        pins.append((
            f"SHAPE:{index}", shape.position, (0.12, 0.92, 0.14),
            index in selected_shapes,
        ))
    for role, point, color, selected in pins:
        x = x0 + float(point[0]) * (x1 - x0)
        y = y0 + float(point[1]) * (y1 - y0)
        size = 13.0 if selected else 10.0
        vertices = (
            (x, y + size), (x + size, y), (x, y - size),
            (x, y + size), (x, y - size), (x - size, y),
        )
        batch = batch_for_shader(shader, "TRIS", {"pos": vertices})
        highlighted = pin_highlighted(role)
        alpha = 1.0 if selected else (0.96 if highlighted else 0.62)
        shader.uniform_float("color", (*color, alpha))
        batch.draw(shader)
    gpu.state.blend_set("NONE")


def clear_shader_cache():
    global _display_shader, _brush_texture
    for name in tuple(_preview_images.values()):
        image = bpy.data.images.get(name)
        if image is not None and image.users == 0:
            bpy.data.images.remove(image)
    _purge_retired_previews()
    clear_session_caches()
    _display_shader = None
    if _brush_texture is not None:
        try:
            _brush_texture.free()
        except (AttributeError, ReferenceError, RuntimeError):
            pass
        _brush_texture = None
    _shaders.clear()


def warm_interactive_resources():
    """Prepare default GPU resources without capturing or changing a frame.

    Shader compilation and the physical-tool atlas are one-time costs. Doing
    this from Blender's idle timer prevents the first Create Frame click from
    paying them synchronously, while deliberately avoiding scene evaluation.
    """
    if bpy.app.background:
        return False
    scratch = _offscreen(8, 8, high_precision=True)
    try:
        _brush_atlas()
        _shader("geometry", "geometry.vert", "geometry.frag")
        _shader("impact", "fullscreen.vert", "impact.frag")
        _shader("composite", "fullscreen.vert", "composite.frag")
    finally:
        _free_surface(scratch)
    return True


def clear_session_caches():
    """Discard file-local CPU/GPU state while retaining saved datablocks."""
    global _fullscreen_batch, _empty_rgba_texture, _capture_cache_bytes
    for cache in (_raster_cache, _mask_cache):
        for value, _weight in cache.values():
            surfaces = value if isinstance(value, tuple) else (value,)
            for surface in surfaces:
                _free_surface(surface)
        cache.clear()
    for name in set(_preview_images.values()) | _retired_preview_images:
        image = bpy.data.images.get(name)
        if image is not None and image.users == 0:
            bpy.data.images.remove(image)
    for surface_entry in tuple(_preview_surfaces.values()):
        _free_surface(surface_entry[0])
    _preview_surfaces.clear()
    _preview_images.clear()
    _preview_signatures.clear()
    _retired_preview_images.clear()
    _display_batches.clear()
    _display_upload_seen.clear()
    _capture_cache.clear()
    _capture_cache_bytes = 0
    _signature_revisions.clear()
    _signature_cache.clear()
    _fullscreen_batch = None
    for texture in tuple(_gradient_textures.values()):
        try:
            texture.free()
        except (AttributeError, ReferenceError, RuntimeError):
            pass
    _gradient_textures.clear()
    _readback_buffers.clear()
    if _empty_rgba_texture is not None:
        try:
            _empty_rgba_texture.free()
        except (AttributeError, ReferenceError, RuntimeError):
            pass
        _empty_rgba_texture = None
    # Saved cache pixels live in Blender image datablocks, but their managed
    # GPU handles may outlive an extension reload or a long viewport absence.
    # Free only those handles so the next draw re-uploads the preserved pixels
    # instead of presenting a stale all-black texture.
    try:
        images = tuple(bpy.data.images)
    except (AttributeError, RuntimeError):
        # Extension registration can call load handlers while Blender exposes
        # _RestrictData. The real load_post call refreshes images once normal
        # datablock access is restored.
        images = ()
    for image in images:
        if not image.name.startswith(CACHE_PREFIX):
            continue
        try:
            image.gl_free()
            image.update()
        except (AttributeError, ReferenceError, RuntimeError):
            pass
