"""Evaluated mesh snapshots and adjacent-frame screen-space velocity capture."""

from dataclasses import dataclass
import math

import bpy
from mathutils import Vector

from .impaction_discovery import resolve_sources
from .impaction_action import action_fcurves


@dataclass
class MeshSample:
    points: list
    normals: list
    triangles: list
    center: Vector


@dataclass
class CaptureGeometry:
    positions: list
    normals: list
    velocities: list
    accelerations: list
    triangles: list


@dataclass
class ImpactCapture:
    subject: CaptureGeometry
    floor: CaptureGeometry
    velocity_scale: float
    subject_motion: tuple = (0.0, 0.0)
    background_motion: tuple = (0.0, 0.0)
    subject_acceleration: tuple = (0.0, 0.0)
    background_acceleration: tuple = (0.0, 0.0)
    temporal: bool = True


def _camera_projection(scene, depsgraph, camera):
    evaluated = camera.evaluated_get(depsgraph)
    width = max(1, int(scene.render.resolution_x))
    height = max(1, int(scene.render.resolution_y))
    projection = evaluated.calc_matrix_camera(
        depsgraph, x=width, y=height,
        scale_x=scene.render.pixel_aspect_x,
        scale_y=scene.render.pixel_aspect_y,
    )
    return projection @ evaluated.matrix_world.inverted(), evaluated


def _project(matrix, point):
    clip = matrix @ point.to_4d()
    if abs(clip.w) < 1.0e-8:
        return Vector((-10.0, -10.0, 1.0))
    return Vector((clip.x / clip.w * 0.5 + 0.5,
                   clip.y / clip.w * 0.5 + 0.5,
                   clip.z / clip.w))


def _mesh_sample(depsgraph, obj, view_projection, camera_normal_matrix):
    evaluated = obj.evaluated_get(depsgraph)
    mesh = evaluated.to_mesh(preserve_all_data_layers=False, depsgraph=depsgraph)
    try:
        mesh.calc_loop_triangles()
        world = evaluated.matrix_world
        normal_matrix = world.to_3x3().inverted_safe().transposed()
        points = []
        normals = []
        center = Vector((0.0, 0.0))
        for vertex in mesh.vertices:
            world_point = world @ vertex.co
            projected = _project(view_projection, world_point)
            points.append(projected)
            center += Vector((projected.x, projected.y))
            normal = (normal_matrix @ vertex.normal).normalized()
            camera_normal = (camera_normal_matrix @ normal).normalized()
            normals.append(tuple(camera_normal))
        if points:
            center /= len(points)
        triangles = [tuple(triangle.vertices) for triangle in mesh.loop_triangles]
        return MeshSample(points, normals, triangles, center)
    finally:
        evaluated.to_mesh_clear()


def _snapshot(scene, camera, objects):
    mesh_objects = [
        obj for obj in objects if obj and obj.type == "MESH"
    ]
    if not mesh_objects:
        return {}
    depsgraph = bpy.context.evaluated_depsgraph_get()
    view_projection, evaluated_camera = _camera_projection(
        scene, depsgraph, camera,
    )
    camera_normal_matrix = (
        evaluated_camera.matrix_world.to_3x3().inverted_safe()
    )
    return {
        obj.name_full: _mesh_sample(
            depsgraph, obj, view_projection, camera_normal_matrix,
        )
        for obj in mesh_objects
    }


def _select_snapshot(snapshot, names):
    return {
        name: sample for name, sample in snapshot.items()
        if name in names
    }


def _percentile(values, fraction):
    if not values:
        return 1.0
    ordered = sorted(values)
    return max(1.0e-5, ordered[min(len(ordered) - 1, int((len(ordered) - 1) * fraction))])


def _coherent_motion(velocities):
    """Robust screen-space motion shared by most geometry vertices."""
    if not velocities:
        return Vector((0.0, 0.0))
    magnitudes = [Vector(value).length for value in velocities]
    ceiling = _percentile(magnitudes, 0.80)
    selected = [
        Vector(value) for value, magnitude in zip(velocities, magnitudes)
        if magnitude <= ceiling * 1.15
    ] or [Vector(value) for value in velocities]
    result = Vector((0.0, 0.0))
    for value in selected:
        result += value
    return result / max(1, len(selected))


def _dominant_subject_motion(velocities, background):
    """Estimate the dominant action while retaining coherent camera motion.

    Fast limbs can occupy fewer vertices than the torso, so an ordinary mean
    suppresses the action. A trimmed high-motion set and a 2D principal axis
    retain the dominant gesture without allowing one malformed vertex to win.
    """
    if not velocities:
        return background.copy()
    relative = [Vector(value) - background for value in velocities]
    speeds = [value.length for value in relative]
    floor = _percentile(speeds, 0.62)
    candidates = [
        (value, speed)
        for value, speed in zip(relative, speeds)
        if speed >= floor * 0.92 and speed > 1.0e-8
    ]
    if not candidates:
        return background.copy()
    # Estimate the cap inside the non-zero action set. Computing a 94th
    # percentile over every torso vertex collapses to zero when a fast hand has
    # only a few vertices; the candidate-local cap retains that sparse action
    # while still clipping isolated malformed projections.
    ceiling = _percentile([speed for _value, speed in candidates], 0.88)
    selected = [
        (value, min(speed, ceiling)) for value, speed in candidates
    ]
    weighted = Vector((0.0, 0.0))
    total = 0.0
    for value, weight in selected:
        direction_sample = value.normalized()
        weighted += direction_sample * weight
        total += weight
    mean = weighted / max(total, 1.0e-8)
    mean_length = mean.length
    target_length = _percentile([speed for _value, speed in selected], 0.72)
    if mean_length > 0.12:
        direction = mean / mean_length
    else:
        xx = xy = yy = 0.0
        fastest = max(selected, key=lambda item: item[1])[0]
        for value, weight in selected:
            direction_sample = value.normalized()
            xx += direction_sample.x * direction_sample.x * weight
            xy += direction_sample.x * direction_sample.y * weight
            yy += direction_sample.y * direction_sample.y * weight
        trace = xx + yy
        discriminant = math.sqrt(max(0.0, (xx - yy) ** 2 + 4.0 * xy * xy))
        eigenvalue = 0.5 * (trace + discriminant)
        axis = Vector((xy, eigenvalue - xx))
        if axis.length < 1.0e-8:
            axis = Vector((eigenvalue - yy, xy))
        direction = axis.normalized() if axis.length > 1.0e-8 else fastest.normalized()
        if direction.dot(fastest) < 0.0:
            direction = -direction
    return background + direction * target_length


def _assemble(current, previous, following, previous_dt=1.0, following_dt=1.0):
    positions, normals, velocities, accelerations, triangles = [], [], [], [], []
    magnitudes = []
    for name, sample in current.items():
        before = previous.get(name)
        after = following.get(name)
        topology_matches = (
            before is not None and after is not None
            and len(before.points) == len(sample.points) == len(after.points)
            and len(before.triangles) == len(sample.triangles) == len(after.triangles)
        )
        if topology_matches:
            # Projected positions retain Z for depth testing, but motion is a
            # camera-plane quantity consumed as vec2 by the shader. Keeping Z
            # here mixed 3D topology velocities with 2D center fallbacks and
            # broke coherent motion aggregation in the 0.3.0 beta.
            previous_dt = max(float(previous_dt), 1.0e-5)
            following_dt = max(float(following_dt), 1.0e-5)
            total_dt = previous_dt + following_dt
            local_velocity = [Vector((
                (after.points[i].x - before.points[i].x) / total_dt,
                (after.points[i].y - before.points[i].y) / total_dt,
            )) for i in range(len(sample.points))]
            local_acceleration = [Vector((
                2.0 * ((after.points[i].x - sample.points[i].x) / following_dt -
                       (sample.points[i].x - before.points[i].x) / previous_dt) /
                total_dt,
                2.0 * ((after.points[i].y - sample.points[i].y) / following_dt -
                       (sample.points[i].y - before.points[i].y) / previous_dt) /
                total_dt,
            )) for i in range(len(sample.points))]
        else:
            center_before = before.center if before else sample.center
            center_after = after.center if after else sample.center
            previous_dt = max(float(previous_dt), 1.0e-5)
            following_dt = max(float(following_dt), 1.0e-5)
            total_dt = previous_dt + following_dt
            fallback = (center_after - center_before) / total_dt
            local_velocity = [fallback.copy() for _point in sample.points]
            fallback_acceleration = 2.0 * (
                (center_after - sample.center) / following_dt -
                (sample.center - center_before) / previous_dt
            ) / total_dt
            local_acceleration = [
                fallback_acceleration.copy() for _point in sample.points
            ]
        base = len(positions)
        positions.extend(tuple(point) for point in sample.points)
        normals.extend(sample.normals)
        velocities.extend(tuple(velocity) for velocity in local_velocity)
        accelerations.extend(tuple(value) for value in local_acceleration)
        magnitudes.extend(velocity.length for velocity in local_velocity)
        triangles.extend(tuple(base + index for index in triangle) for triangle in sample.triangles)
    return CaptureGeometry(
        positions, normals, velocities, accelerations, triangles,
    ), magnitudes


def capture_impact(context, camera):
    """Capture frame-1/current/frame+1 while preserving the user's frame."""
    frame = int(context.scene.frame_current)
    return capture_impacts(context, camera, (frame,))[frame]


def capture_current_impact(context, camera):
    """Capture current geometry once, with an exact-zero velocity field.

    Frames with zero Motion Blur do not consume temporal motion geometry.
    Avoiding two redundant dependency-graph evaluations keeps creation cheap;
    the renderer upgrades this snapshot lazily when t-1/t+1 motion is needed.
    """
    scene = context.scene
    subjects, floors = resolve_sources(context)
    all_objects = list({
        obj.as_pointer(): obj for obj in subjects + floors
    }.values())
    current = _snapshot(scene, camera, all_objects)

    subject_names = {obj.name_full for obj in subjects}
    floor_names = {obj.name_full for obj in floors}
    subject_snapshot = _select_snapshot(current, subject_names)
    floor_snapshot = _select_snapshot(current, floor_names)

    subject, _subject_speeds = _assemble(
        subject_snapshot, subject_snapshot, subject_snapshot,
    )
    floor, _floor_speeds = _assemble(
        floor_snapshot, floor_snapshot, floor_snapshot,
    )
    return ImpactCapture(
        subject, floor, 1.0,
        subject_motion=(0.0, 0.0), background_motion=(0.0, 0.0),
        subject_acceleration=(0.0, 0.0), background_acceleration=(0.0, 0.0),
        temporal=False,
    )


def _animation_key_frames(scene):
    """Return authored animation keys, excluding Impaction exposure markers."""
    frames = set()
    owners = tuple(scene.objects) + (scene,)
    for owner in owners:
        animation_data = getattr(owner, "animation_data", None)
        action = getattr(animation_data, "action", None)
        for curve in action_fcurves(action, owner):
            if "impaction_marker" in str(getattr(curve, "data_path", "")):
                continue
            for point in curve.keyframe_points:
                frames.add(int(round(float(point.co.x))))
    return tuple(sorted(frames))


def _motion_bracket(frame, key_frames):
    """Use nearest authored before/after keys, with adjacent-frame fallback."""
    before = max((value for value in key_frames if value < frame),
                 default=frame - 1)
    after = min((value for value in key_frames if value > frame),
                default=frame + 1)
    return before, after


def capture_impacts(context, camera, frames):
    """Capture several keys with one ordered dependency-graph sampling pass."""
    scene = context.scene
    original_frame = scene.frame_current
    original_subframe = scene.frame_subframe
    target_frames = tuple(dict.fromkeys(int(frame) for frame in frames))
    if not target_frames:
        return {}
    subjects, floors = resolve_sources(context)
    all_objects = list({obj.as_pointer(): obj for obj in subjects + floors}.values())
    subject_names = {obj.name_full for obj in subjects}
    floor_names = {obj.name_full for obj in floors}
    samples = {}
    try:
        key_frames = _animation_key_frames(scene)
        brackets = {
            frame: _motion_bracket(frame, key_frames)
            for frame in target_frames
        }
        sample_frames = sorted({
            sample
            for frame in target_frames
            for sample in (brackets[frame][0], frame, brackets[frame][1])
        })
        for frame in sample_frames:
            scene.frame_set(frame, subframe=0.0)
            samples[frame] = _snapshot(scene, camera, all_objects)
    finally:
        scene.frame_set(original_frame, subframe=original_subframe)

    subject_samples = {
        frame: _select_snapshot(snapshot, subject_names)
        for frame, snapshot in samples.items()
    }
    floor_samples = {
        frame: _select_snapshot(snapshot, floor_names)
        for frame, snapshot in samples.items()
    }
    # The partition dictionaries now own every required MeshSample reference;
    # release the all-object snapshots before assembled captures begin adding
    # their own position/velocity arrays.
    samples.clear()
    sample_uses = {frame: 0 for frame in sample_frames}
    for frame in target_frames:
        before, after = brackets[frame]
        for sample_frame in (before, frame, after):
            sample_uses[sample_frame] += 1

    captures = {}
    for frame in target_frames:
        previous_frame, following_frame = brackets[frame]
        previous_dt = max(1, frame - previous_frame)
        following_dt = max(1, following_frame - frame)
        subject, subject_speeds = _assemble(
            subject_samples[frame], subject_samples[previous_frame],
            subject_samples[following_frame], previous_dt, following_dt,
        )
        floor, floor_speeds = _assemble(
            floor_samples[frame], floor_samples[previous_frame],
            floor_samples[following_frame], previous_dt, following_dt,
        )
        # Static/environment geometry is the cleanest camera-motion proxy.
        # Scenes without a tagged floor still receive camera compensation from
        # the coherent, low-motion majority of the subject instead of falling
        # back to a motionless background field.
        background_candidates = (
            floor.velocities if floor.velocities else subject.velocities
        )
        background_motion = _coherent_motion(background_candidates)
        background_acceleration = _coherent_motion(
            floor.accelerations if floor.accelerations else subject.accelerations
        )
        subject_motion = _dominant_subject_motion(
            subject.velocities, background_motion,
        )
        subject_acceleration = _dominant_subject_motion(
            subject.accelerations, background_acceleration,
        )
        captures[frame] = ImpactCapture(
            subject, floor, _percentile(subject_speeds + floor_speeds, 0.90),
            subject_motion=tuple(subject_motion),
            background_motion=tuple(background_motion),
            subject_acceleration=tuple(subject_acceleration),
            background_acceleration=tuple(background_acceleration),
            temporal=True,
        )
        for sample_frame in (previous_frame, frame, following_frame):
            sample_uses[sample_frame] -= 1
            if sample_uses[sample_frame] == 0:
                subject_samples.pop(sample_frame, None)
                floor_samples.pop(sample_frame, None)
    return captures
