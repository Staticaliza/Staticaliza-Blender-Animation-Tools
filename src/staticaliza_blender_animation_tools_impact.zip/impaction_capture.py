"""Evaluated mesh snapshots and adjacent-frame screen-space velocity capture."""

from dataclasses import dataclass, field
import math
import numpy as np

import bpy
from mathutils import Vector

from .impaction_discovery import resolve_sources
from .impaction_action import action_fcurves
from .impaction_spatial import nearby_pairs


@dataclass
class MeshSample:
    points: list
    normals: list
    triangles: list
    center: Vector
    rig_key: str
    world_min: Vector
    world_max: Vector
    world_points: list = field(default_factory=list)
    view_projection: tuple = ()
    corner_normals: list = field(default_factory=list)


@dataclass
class CaptureGeometry:
    positions: list
    normals: list
    velocities: list
    accelerations: list
    owner_ids: list
    triangles: list
    spread_group_ids: list = field(default_factory=list)
    spread_group_weights: list = field(default_factory=list)
    world_positions: list = field(default_factory=list)
    view_projection: tuple = ()
    world_velocities: list = field(default_factory=list)
    world_accelerations: list = field(default_factory=list)
    world_before: list = field(default_factory=list)
    world_before_mid: list = field(default_factory=list)
    world_after_mid: list = field(default_factory=list)
    world_after: list = field(default_factory=list)
    motion_history: dict = field(default_factory=dict)
    corner_normals: list = field(default_factory=list)


@dataclass
class ImpactCapture:
    subject: CaptureGeometry
    floor: CaptureGeometry
    velocity_scale: float
    subject_motion: tuple = (0.0, 0.0)
    background_motion: tuple = (0.0, 0.0)
    subject_acceleration: tuple = (0.0, 0.0)
    background_acceleration: tuple = (0.0, 0.0)
    temporal: bool = True


def _camera_projection(scene, depsgraph, camera):
    evaluated = camera.evaluated_get(depsgraph)
    width = max(1, int(scene.render.resolution_x))
    height = max(1, int(scene.render.resolution_y))
    projection = evaluated.calc_matrix_camera(
        depsgraph, x=width, y=height,
        scale_x=scene.render.pixel_aspect_x,
        scale_y=scene.render.pixel_aspect_y,
    )
    return projection @ evaluated.matrix_world.inverted(), evaluated


def _project(matrix, point):
    clip = matrix @ point.to_4d()
    if abs(clip.w) < 1.0e-8:
        return Vector((-10.0, -10.0, 1.0))
    return Vector((clip.x / clip.w * 0.5 + 0.5,
                   clip.y / clip.w * 0.5 + 0.5,
                   clip.z / clip.w))


def _mesh_rig_key(obj):
    """Return a stable armature affiliation for proximity grouping."""
    candidates = []
    if obj.parent is not None and obj.parent.type == "ARMATURE":
        candidates.append(obj.parent)
    candidates.extend(
        getattr(modifier, "object", None)
        for modifier in obj.modifiers
        if modifier.type == "ARMATURE"
    )
    candidates.extend(
        getattr(constraint, "target", None)
        for constraint in obj.constraints
        if getattr(getattr(constraint, "target", None), "type", None)
        == "ARMATURE"
    )
    armatures = sorted(
        {candidate.name_full: candidate for candidate in candidates
         if candidate is not None}.values(),
        key=lambda candidate: candidate.name_full,
    )
    return armatures[0].name_full if armatures else obj.name_full


def _mesh_sample(depsgraph, obj, view_projection, camera_normal_matrix, sample_cache=None):
    evaluated = obj.evaluated_get(depsgraph)
    mesh = evaluated.to_mesh(preserve_all_data_layers=False, depsgraph=depsgraph)
    try:
        mesh.calc_loop_triangles()
        world = evaluated.matrix_world
        cache_key = obj.as_pointer()
        if sample_cache is not None:
            # Temporal sampling often evaluates an unchanged rigid part five
            # times. Compare the evaluated inputs in bulk before repeating
            # projection/normal work. This is scoped to one capture, and also
            # checks deformation, topology, camera motion and custom normals.
            signature = (tuple(map(tuple, world)), tuple(map(tuple, view_projection)),
                         tuple(map(tuple, camera_normal_matrix)), _mesh_rig_key(obj))
            arrays = []
            for data, attribute, width, dtype in (
                (mesh.vertices, 'co', 3, np.float32),
                (mesh.vertices, 'normal', 3, np.float32),
                (mesh.loop_triangles, 'vertices', 3, np.int32),
                (mesh.loop_triangles, 'loops', 3, np.int32),
                (mesh.corner_normals, 'vector', 3, np.float32),
            ):
                values = np.empty((len(data), width), dtype=dtype)
                data.foreach_get(attribute, values.ravel())
                arrays.append(values)
            previous = sample_cache.get(cache_key)
            if (previous is not None and previous[0] == signature
                    and all(np.array_equal(a, b) for a, b in zip(previous[1], arrays))):
                return previous[2]
        normal_matrix = world.to_3x3().inverted_safe().transposed()
        points = []
        world_points = []
        normals = []
        center = Vector((0.0, 0.0))
        world_min = Vector((float("inf"),) * 3)
        world_max = Vector((float("-inf"),) * 3)
        for vertex in mesh.vertices:
            world_point = world @ vertex.co
            world_points.append(tuple(world_point))
            world_min.x = min(world_min.x, world_point.x)
            world_min.y = min(world_min.y, world_point.y)
            world_min.z = min(world_min.z, world_point.z)
            world_max.x = max(world_max.x, world_point.x)
            world_max.y = max(world_max.y, world_point.y)
            world_max.z = max(world_max.z, world_point.z)
            projected = _project(view_projection, world_point)
            points.append(projected)
            center += Vector((projected.x, projected.y))
            normal = (normal_matrix @ vertex.normal).normalized()
            camera_normal = (camera_normal_matrix @ normal).normalized()
            normals.append(tuple(camera_normal))
        if points:
            center /= len(points)
        else:
            world_min = world.translation.copy()
            world_max = world.translation.copy()
        triangles = [tuple(triangle.vertices) for triangle in mesh.loop_triangles]
        sample = MeshSample(
            points, normals, triangles, center, _mesh_rig_key(obj),
            world_min, world_max,
            world_points, tuple(tuple(row) for row in view_projection),
        )
        # Lighting needs evaluated split/custom normals, not averaged vertex
        # normals across hard edges. Keep topology unchanged for motion.
        corner = np.empty((len(mesh.loops),3),dtype=np.float32)
        mesh.corner_normals.foreach_get("vector",corner.ravel())
        matrix=np.asarray(camera_normal_matrix @ normal_matrix,dtype=np.float32)
        corner=corner @ matrix.T
        corner/=np.maximum(np.linalg.norm(corner,axis=1,keepdims=True),1.e-12)
        loops=np.empty((len(mesh.loop_triangles),3),dtype=np.int32)
        mesh.loop_triangles.foreach_get("loops",loops.ravel())
        sample.corner_normals=np.ascontiguousarray(corner[loops.ravel()])
        if sample_cache is not None:
            sample_cache[cache_key] = (signature, arrays, sample)
        return sample
    finally:
        evaluated.to_mesh_clear()


def _snapshot(scene, camera, objects, sample_cache=None):
    mesh_objects = [
        obj for obj in objects if obj and obj.type == "MESH"
    ]
    if not mesh_objects:
        return {}
    depsgraph = bpy.context.evaluated_depsgraph_get()
    view_projection, evaluated_camera = _camera_projection(
        scene, depsgraph, camera,
    )
    camera_normal_matrix = (
        evaluated_camera.matrix_world.to_3x3().inverted_safe()
    )
    return {
        obj.name_full: _mesh_sample(
            depsgraph, obj, view_projection, camera_normal_matrix, sample_cache,
        )
        for obj in mesh_objects
    }


def _select_snapshot(snapshot, names):
    return {
        name: sample for name, sample in snapshot.items()
        if name in names
    }


def _percentile(values, fraction):
    if not values:
        return 1.0
    ordered = sorted(values)
    return max(1.0e-5, ordered[min(len(ordered) - 1, int((len(ordered) - 1) * fraction))])


def _coherent_motion(velocities):
    """Robust screen-space motion shared by most geometry vertices."""
    if not velocities:
        return Vector((0.0, 0.0))
    magnitudes = [Vector(value).length for value in velocities]
    ceiling = _percentile(magnitudes, 0.80)
    selected = [
        Vector(value) for value, magnitude in zip(velocities, magnitudes)
        if magnitude <= ceiling * 1.15
    ] or [Vector(value) for value in velocities]
    result = Vector((0.0, 0.0))
    for value in selected:
        result += value
    return result / max(1, len(selected))


def _dominant_subject_motion(velocities, background):
    """Estimate the dominant action while retaining coherent camera motion.

    Fast limbs can occupy fewer vertices than the torso, so an ordinary mean
    suppresses the action. A trimmed high-motion set and a 2D principal axis
    retain the dominant gesture without allowing one malformed vertex to win.
    """
    if not velocities:
        return background.copy()
    relative = [Vector(value) - background for value in velocities]
    speeds = [value.length for value in relative]
    floor = _percentile(speeds, 0.62)
    candidates = [
        (value, speed)
        for value, speed in zip(relative, speeds)
        if speed >= floor * 0.92 and speed > 1.0e-8
    ]
    if not candidates:
        return background.copy()
    # Estimate the cap inside the non-zero action set. Computing a 94th
    # percentile over every torso vertex collapses to zero when a fast hand has
    # only a few vertices; the candidate-local cap retains that sparse action
    # while still clipping isolated malformed projections.
    ceiling = _percentile([speed for _value, speed in candidates], 0.88)
    selected = [
        (value, min(speed, ceiling)) for value, speed in candidates
    ]
    weighted = Vector((0.0, 0.0))
    total = 0.0
    for value, weight in selected:
        direction_sample = value.normalized()
        weighted += direction_sample * weight
        total += weight
    mean = weighted / max(total, 1.0e-8)
    mean_length = mean.length
    target_length = _percentile([speed for _value, speed in selected], 0.72)
    if mean_length > 0.12:
        direction = mean / mean_length
    else:
        xx = xy = yy = 0.0
        fastest = max(selected, key=lambda item: item[1])[0]
        for value, weight in selected:
            direction_sample = value.normalized()
            xx += direction_sample.x * direction_sample.x * weight
            xy += direction_sample.x * direction_sample.y * weight
            yy += direction_sample.y * direction_sample.y * weight
        trace = xx + yy
        discriminant = math.sqrt(max(0.0, (xx - yy) ** 2 + 4.0 * xy * xy))
        eigenvalue = 0.5 * (trace + discriminant)
        axis = Vector((xy, eigenvalue - xx))
        if axis.length < 1.0e-8:
            axis = Vector((eigenvalue - yy, xy))
        direction = axis.normalized() if axis.length > 1.0e-8 else fastest.normalized()
        if direction.dot(fastest) < 0.0:
            direction = -direction
    return background + direction * target_length


def _world_spread_groups(current):
    """Return stable buffered proximity groups in evaluated 3D space."""
    names = sorted(current)
    parents = list(range(len(names)))
    adjacency = []

    def find(index):
        while parents[index] != index:
            parents[index] = parents[parents[index]]
            index = parents[index]
        return index

    def union(first, second):
        first_root = find(first)
        second_root = find(second)
        if first_root != second_root:
            parents[second_root] = first_root

    def smoothstep(edge0, edge1, value):
        if edge1 <= edge0:
            return float(value >= edge1)
        t = max(0.0, min(1.0, (value - edge0) / (edge1 - edge0)))
        return t * t * (3.0 - 2.0 * t)

    samples = [current[name] for name in names]
    spans = [max((sample.world_max-sample.world_min).length, 1.e-4) for sample in samples]
    radii = [max(max(.015, span*.035)+.025, span*.62) for span in spans]
    for first, second in nearby_pairs([s.world_min for s in samples],
                                      [s.world_max for s in samples], radii):
        sample_a, sample_b = samples[first], samples[second]
        if sample_a.rig_key != sample_b.rig_key:
            continue
        gap = Vector((
            max(sample_a.world_min.x - sample_b.world_max.x,
                sample_b.world_min.x - sample_a.world_max.x, 0.0),
            max(sample_a.world_min.y - sample_b.world_max.y,
                sample_b.world_min.y - sample_a.world_max.y, 0.0),
            max(sample_a.world_min.z - sample_b.world_max.z,
                sample_b.world_min.z - sample_a.world_max.z, 0.0),
        )).length
        smaller_span = min(spans[first], spans[second])
        inner = max(0.015, smaller_span * 0.035)
        outer = max(inner + 0.025, smaller_span * 0.62)
        weight = 1.0 - smoothstep(inner, outer, gap)
        if weight > 0.0:
            adjacency.append((first, second, weight))
        if weight > 0.001:
            union(first, second)

    components = {}
    for index in range(len(names)):
        components.setdefault(find(index), []).append(index)
    ordered = sorted(components.values(), key=lambda members: min(members))
    group_ids = [0.0] * len(names)
    cohesion = [0.0] * len(names)
    for group_index, members in enumerate(ordered):
        for owner_index in members:
            group_ids[owner_index] = float(group_index + 1)
    for first, second, weight in adjacency:
        if group_ids[first] == group_ids[second]:
            cohesion[first] = max(cohesion[first], weight)
            cohesion[second] = max(cohesion[second], weight)
    return {
        name: (group_ids[index], cohesion[index])
        for index, name in enumerate(names)
    }


def _assemble(current, previous, following, previous_dt=1.0, following_dt=1.0):
    positions, normals, velocities, accelerations = [], [], [], []
    corner_normals = []
    world_positions = []
    world_velocities, world_accelerations = [], []
    view_projection = ()
    owner_ids, triangles = [], []
    spread_group_ids, spread_group_weights = [], []
    magnitudes = []
    spread_groups = _world_spread_groups(current)
    previous_steps,following_steps=previous_dt,following_dt
    # A small integer survives RGBA16F rasterization exactly and remains stable
    # across camera/output-size changes. Sorting by the persistent Blender name
    # prevents selection, collection iteration, or dependency-graph order from
    # changing which visible limb owns a stroke family.
    for owner_index, name in enumerate(sorted(current)):
        previous_dt=previous_steps.get(name,1.) if isinstance(previous_steps,dict) else previous_steps
        following_dt=following_steps.get(name,1.) if isinstance(following_steps,dict) else following_steps
        sample = current[name]
        world_positions.extend(sample.world_points)
        view_projection = sample.view_projection
        before = previous.get(name)
        after = following.get(name)
        topology_matches = (
            before is not None and after is not None
            and len(before.points) == len(sample.points) == len(after.points)
            and len(before.triangles) == len(sample.triangles) == len(after.triangles)
        )
        stationary = (before is sample and after is sample) or (
            topology_matches
            and before.view_projection == sample.view_projection == after.view_projection
            and before.world_points == sample.world_points == after.world_points
        )
        if stationary:
            local_velocity = [Vector((0., 0.))] * len(sample.points)
            local_acceleration = local_velocity
        elif topology_matches:
            # Projected positions retain Z for depth testing, but motion is a
            # camera-plane quantity consumed as vec2 by the shader. Keeping Z
            # here mixed 3D topology velocities with 2D center fallbacks and
            # broke coherent motion aggregation in the 0.3.0 beta.
            previous_dt = max(float(previous_dt), 1.0e-5)
            following_dt = max(float(following_dt), 1.0e-5)
            total_dt = previous_dt + following_dt
            local_velocity = [Vector((
                ((sample.points[i].x-before.points[i].x)*following_dt/previous_dt +
                 (after.points[i].x-sample.points[i].x)*previous_dt/following_dt) / total_dt,
                ((sample.points[i].y-before.points[i].y)*following_dt/previous_dt +
                 (after.points[i].y-sample.points[i].y)*previous_dt/following_dt) / total_dt,
            )) for i in range(len(sample.points))]
            local_acceleration = [Vector((
                2.0 * ((after.points[i].x - sample.points[i].x) / following_dt -
                       (sample.points[i].x - before.points[i].x) / previous_dt) /
                total_dt,
                2.0 * ((after.points[i].y - sample.points[i].y) / following_dt -
                       (sample.points[i].y - before.points[i].y) / previous_dt) /
                total_dt,
            )) for i in range(len(sample.points))]
        else:
            center_before = before.center if before else sample.center
            center_after = after.center if after else sample.center
            previous_dt = max(float(previous_dt), 1.0e-5)
            following_dt = max(float(following_dt), 1.0e-5)
            total_dt = previous_dt + following_dt
            fallback = ((sample.center-center_before)*(following_dt/previous_dt)+
                (center_after-sample.center)*(previous_dt/following_dt))/total_dt
            local_velocity = [fallback.copy() for _point in sample.points]
            fallback_acceleration = 2.0 * (
                (center_after - sample.center) / following_dt -
                (sample.center - center_before) / previous_dt
            ) / total_dt
            local_acceleration = [
                fallback_acceleration.copy() for _point in sample.points
            ]
        base = len(positions)
        # Keep true local motion for 3D trails; projected XY cannot distinguish
        # a forward punch from a stationary limb seen end-on. Units are world
        # distance per frame and per frame squared (same time base as XY).
        dt0, dt1 = max(float(previous_dt),1.e-5), max(float(following_dt),1.e-5)
        if stationary:
            world_velocities.extend([(0., 0., 0.)] * len(sample.world_points))
            world_accelerations.extend([(0., 0., 0.)] * len(sample.world_points))
        for i, point in (() if stationary else enumerate(sample.world_points)):
            before_world = Vector(before.world_points[i]) if topology_matches else Vector(point)
            after_world = Vector(after.world_points[i]) if topology_matches else Vector(point)
            point = Vector(point)
            world_velocities.append(tuple(((point-before_world)*(dt1/dt0)+
                (after_world-point)*(dt0/dt1))/(dt0+dt1)))
            world_accelerations.append(tuple(2.*((after_world-point)/dt1-(point-before_world)/dt0)/(dt0+dt1)))
        positions.extend(tuple(point) for point in sample.points)
        normals.extend(sample.normals)
        corners=getattr(sample,"corner_normals",())
        if len(corners)==len(sample.triangles)*3:
            corner_normals.append(corners)
        else:
            indices=np.asarray(sample.triangles,dtype=np.int32).ravel()
            corner_normals.append(np.asarray(sample.normals,dtype=np.float32).reshape(-1,3)[indices])
        velocities.extend(tuple(velocity) for velocity in local_velocity)
        accelerations.extend(tuple(value) for value in local_acceleration)
        owner_ids.extend([float(owner_index + 1)] * len(sample.points))
        group_id, group_weight = spread_groups[name]
        spread_group_ids.extend([group_id] * len(sample.points))
        spread_group_weights.extend([group_weight] * len(sample.points))
        magnitudes.extend(velocity.length for velocity in local_velocity)
        triangles.extend(tuple(base + index for index in triangle) for triangle in sample.triangles)
    geometry = CaptureGeometry(
        positions, normals, velocities, accelerations, owner_ids, triangles,
        spread_group_ids, spread_group_weights,
        world_positions, view_projection, world_velocities, world_accelerations,
    )
    geometry.corner_normals=(np.concatenate(corner_normals).astype(np.float32,copy=False)
                             if corner_normals else np.empty((0,3),dtype=np.float32))
    return geometry, magnitudes


def capture_impact(context, camera):
    """Capture frame-1/current/frame+1 while preserving the user's frame."""
    frame = int(context.scene.frame_current)
    return capture_impacts(context, camera, (frame,))[frame]


def capture_current_impact(context, camera):
    """Capture current geometry once, with an exact-zero velocity field.

    Frames with zero Motion Blur do not consume temporal motion geometry.
    Avoiding two redundant dependency-graph evaluations keeps creation cheap;
    the renderer upgrades this snapshot lazily when t-1/t+1 motion is needed.
    """
    scene = context.scene
    subjects, floors = resolve_sources(context)
    all_objects = list({
        obj.as_pointer(): obj for obj in subjects + floors
    }.values())
    current = _snapshot(scene, camera, all_objects)

    subject_names = {obj.name_full for obj in subjects}
    floor_names = {obj.name_full for obj in floors}
    subject_snapshot = _select_snapshot(current, subject_names)
    floor_snapshot = _select_snapshot(current, floor_names)

    subject, _subject_speeds = _assemble(
        subject_snapshot, subject_snapshot, subject_snapshot,
    )
    floor, _floor_speeds = _assemble(
        floor_snapshot, floor_snapshot, floor_snapshot,
    )
    return ImpactCapture(
        subject, floor, 1.0,
        subject_motion=(0.0, 0.0), background_motion=(0.0, 0.0),
        subject_acceleration=(0.0, 0.0), background_acceleration=(0.0, 0.0),
        temporal=False,
    )


def _animation_key_frames(scene):
    """Return authored animation keys, excluding Impaction exposure markers."""
    frames = set()
    owners = tuple(scene.objects) + (scene,)
    for owner in owners:
        animation_data = getattr(owner, "animation_data", None)
        action = getattr(animation_data, "action", None)
        for curve in action_fcurves(action, owner):
            if "impaction_marker" in str(getattr(curve, "data_path", "")):
                continue
            for point in curve.keyframe_points:
                frames.add(int(round(float(point.co.x))))
    return tuple(sorted(frames))


def _motion_bracket(frame, key_frames):
    """Bracket the current pose with authored keys; bound very distant keys."""
    before=max((key for key in key_frames if key<frame),default=frame-1)
    after=min((key for key in key_frames if key>frame),default=frame+1)
    return max(frame-24,before),min(frame+24,after)


def _mesh_key_frames(obj):
    """Keys of the mesh's driving bones (and ancestors), not unrelated bones."""
    sources=[(obj,None)]
    if obj.parent:
        sources.append((obj.parent,{obj.parent_bone} if obj.parent_bone else None))
    for modifier in obj.modifiers:
        if modifier.type=='ARMATURE' and modifier.object:
            sources.append((modifier.object,{g.name for g in obj.vertex_groups}))
    for constraint in obj.constraints:
        target=getattr(constraint,'target',None)
        if target:
            bone=getattr(constraint,'subtarget','')
            sources.append((target,{bone} if bone else None))
    frames=set()
    for owner,bones in sources:
        if bones and owner.type=='ARMATURE':
            names=set(bones)
            for name in bones:
                bone=owner.data.bones.get(name)
                if bone:names.update(p.name for p in bone.parent_recursive)
            prefixes=tuple('pose.bones["'+bpy.utils.escape_identifier(name)+'"]' for name in names)
        else:prefixes=None
        action=getattr(getattr(owner,'animation_data',None),'action',None)
        for curve in action_fcurves(action,owner):
            path=curve.data_path
            if 'impaction_marker' in path:continue
            if prefixes and path.startswith('pose.bones[') and not path.startswith(prefixes):continue
            frames.update(float(p.co.x) for p in curve.keyframe_points)
    return tuple(sorted(frames))


def _attach_motion_samples(geometry,current,before,before_mid,after_mid,after):
    for field_name,snapshot in zip(('world_before','world_before_mid','world_after_mid','world_after'),
                                   (before,before_mid,after_mid,after)):
        values=[]
        for name in sorted(current):
            sample=current[name]
            other=snapshot.get(name)
            valid=other is not None and len(other.world_points)==len(sample.world_points) and other.triangles==sample.triangles
            source=np.asarray(other.world_points if valid else sample.world_points,dtype=float)
            base=np.asarray(sample.world_points,dtype=float)
            values.extend(map(tuple,source-base))
        setattr(geometry,field_name,values)


def _keyed_history(scene,camera,objects,current,keys,frame,cache):
    """Walk evaluated keyed intervals until a limb's spatial budget is filled."""
    result={}
    saved=(scene.frame_current,scene.frame_subframe)
    try:
        by_name={obj.name_full:obj for obj in objects}
        for owner,name in enumerate(sorted(current),1):
            sample=current[name]
            if not sample.world_points:continue
            origin=sum((Vector(p) for p in sample.world_points),Vector())/len(sample.world_points)
            limit=max((sample.world_max-sample.world_min).length*2.,1.e-5)
            base=np.asarray(sample.world_points,dtype=float)
            centered=base-base.mean(axis=0)
            def walk(times,reverse):
                path=[[0.]*13];last_points=base;travel=0.;start=float(frame)
                for end in times:
                    for fraction in (.25,.5,.75,1.):
                        t=start+(end-start)*fraction
                        snapshot=cache.setdefault(t,{})
                        if name not in snapshot:
                            scene.frame_set(math.floor(t),subframe=t-math.floor(t))
                            snapshot.update(_snapshot(scene,camera,objects))
                        pose=snapshot.get(name)
                        if pose is None or not pose.world_points:return path,travel
                        center=sum((Vector(p) for p in pose.world_points),Vector())/len(pose.world_points)
                        posed=np.asarray(pose.world_points,dtype=float)
                        valid=posed.shape==base.shape and pose.triangles==sample.triangles
                        rotation=np.eye(3)
                        if valid:
                            u,_,vt=np.linalg.svd(centered.T@(posed-posed.mean(axis=0)))
                            parity=np.eye(3);parity[2,2]=np.linalg.det(u@vt)
                            rotation=u@parity@vt
                            travel+=float(np.sqrt(np.mean(np.sum((posed-last_points)**2,axis=1))))
                            last_points=posed
                        else:
                            travel+=(center-Vector(last_points.mean(axis=0))).length
                            last_points=np.asarray(pose.world_points,dtype=float)
                        delta=(center-origin)*(-1. if reverse else 1.)
                        if reverse:rotation=rotation.T
                        path.append([-abs(t-frame),*delta,*(rotation-np.eye(3)).reshape(-1).tolist()])
                        if travel>=limit:return path,travel
                    start=end
                return path,travel
            all_past=sorted((t for t in keys[name] if t<frame),reverse=True)
            cutoff=float(frame)-8.
            past=[t for t in all_past if t>=cutoff]
            if all_past and all_past[-1]<cutoff:past.append(cutoff)
            path,travel=walk(past,False)
            if travel>1.e-5:result[str(owner)]=path
    finally:scene.frame_set(saved[0],subframe=saved[1])
    return result


def capture_impacts(context, camera, frames, temporal_frames=None):
    """Capture several keys with one ordered dependency-graph sampling pass."""
    scene = context.scene
    original_frame = scene.frame_current
    original_subframe = scene.frame_subframe
    target_frames = tuple(dict.fromkeys(int(frame) for frame in frames))
    temporal_frames = set(target_frames) if temporal_frames is None else set(temporal_frames)
    if not target_frames:
        return {}
    subjects, floors = resolve_sources(context)
    all_objects = list({obj.as_pointer(): obj for obj in subjects + floors}.values())
    subject_names = {obj.name_full for obj in subjects}
    floor_names = {obj.name_full for obj in floors}
    samples = {}
    keys={obj.name_full:_mesh_key_frames(obj) for obj in all_objects}
    schedules={}
    for frame in target_frames:
        schedules[frame]={}
        for obj in all_objects:
            before,after=(_motion_bracket(frame,keys[obj.name_full])
                          if frame in temporal_frames else (frame,frame))
            schedules[frame][obj.name_full]=(before,(before+frame)*.5,frame,(after+frame)*.5,after)
    sample_frames=sorted({t for schedule in schedules.values() for times in schedule.values() for t in times})
    sample_cache = {}
    try:
        for frame in sample_frames:
            scene.frame_set(math.floor(frame),subframe=frame-math.floor(frame))
            needed=[obj for obj in all_objects if any(frame in schedule[obj.name_full] for schedule in schedules.values())]
            samples[frame]=_snapshot(scene,camera,needed,sample_cache)
    finally:
        scene.frame_set(original_frame,subframe=original_subframe)
        sample_cache.clear()
    uses={t:sum(any(t in times for times in schedule.values()) for schedule in schedules.values()) for t in sample_frames}
    captures={}
    history_cache={t:dict(snapshot) for t,snapshot in samples.items()}
    for frame in target_frames:
        schedule=schedules[frame]
        poses=[{name:samples[times[i]][name] for name,times in schedule.items()} for i in range(5)]
        previous_dt={name:max(1.e-5,frame-times[0]) for name,times in schedule.items()}
        following_dt={name:max(1.e-5,times[-1]-frame) for name,times in schedule.items()}
        subject_poses=[_select_snapshot(p,subject_names) for p in poses]
        floor_poses=[_select_snapshot(p,floor_names) for p in poses]
        subject,subject_speeds=_assemble(subject_poses[2],subject_poses[0],subject_poses[4],previous_dt,following_dt)
        floor,floor_speeds=_assemble(floor_poses[2],floor_poses[0],floor_poses[4],previous_dt,following_dt)
        if frame in temporal_frames:
            _attach_motion_samples(subject,subject_poses[2],subject_poses[0],subject_poses[1],subject_poses[3],subject_poses[4])
            _attach_motion_samples(floor,floor_poses[2],floor_poses[0],floor_poses[1],floor_poses[3],floor_poses[4])
            subject.motion_history=_keyed_history(scene,camera,subjects,subject_poses[2],keys,frame,history_cache)
        # Static/environment geometry is the cleanest camera-motion proxy.
        # Scenes without a tagged floor still receive camera compensation from
        # the coherent, low-motion majority of the subject instead of falling
        # back to a motionless background field.
        background_candidates = (
            floor.velocities if floor.velocities else subject.velocities
        )
        background_motion = _coherent_motion(background_candidates)
        background_acceleration = _coherent_motion(
            floor.accelerations if floor.accelerations else subject.accelerations
        )
        subject_motion = _dominant_subject_motion(
            subject.velocities, background_motion,
        )
        subject_acceleration = _dominant_subject_motion(
            subject.accelerations, background_acceleration,
        )
        captures[frame] = ImpactCapture(
            subject, floor, _percentile(subject_speeds + floor_speeds, 0.90),
            subject_motion=tuple(subject_motion),
            background_motion=tuple(background_motion),
            subject_acceleration=tuple(subject_acceleration),
            background_acceleration=tuple(background_acceleration),
            temporal=frame in temporal_frames,
        )
        for t in {t for times in schedule.values() for t in times}:
            uses[t]-=1
            if uses[t]==0:samples.pop(t,None)
    return captures
