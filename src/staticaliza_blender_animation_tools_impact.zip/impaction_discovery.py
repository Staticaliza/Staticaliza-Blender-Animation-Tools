"""Camera binding and subject discovery compatible with Staticaliza scenes."""

import re

import bpy

from .impaction_constants import (
    FLOOR,
    STATICALIZA_CAMERA_BONE,
    STATICALIZA_CAMERA_OWNER,
    STATICALIZA_CAMERA_OWNER_NAME,
    STATICALIZA_CAMERA_OWNER_SESSION_UID,
    SUBJECT,
)


def _armature_session_uid(armature):
    if armature is None:
        return 0
    try:
        uid = int(armature.session_uid)
    except (AttributeError, ReferenceError, TypeError, ValueError):
        uid = 0
    if uid:
        return uid
    try:
        return int(armature.as_pointer())
    except (AttributeError, ReferenceError, TypeError, ValueError):
        return 0


def _armature_from_session_uid(session_uid):
    try:
        session_uid = int(session_uid or 0)
    except (TypeError, ValueError):
        return None
    if not session_uid:
        return None
    return next(
        (
            obj for obj in bpy.data.objects
            if obj.type == "ARMATURE" and _armature_session_uid(obj) == session_uid
        ),
        None,
    )


def camera_bone_binding(camera):
    if camera is None or camera.type != "CAMERA":
        return None, ""
    if (camera.parent is not None and camera.parent.type == "ARMATURE"
            and camera.parent_type == "BONE" and camera.parent_bone):
        return camera.parent, camera.parent_bone
    bone_name = str(camera.get(STATICALIZA_CAMERA_BONE, ""))
    if bone_name:
        armature = _armature_from_session_uid(
            camera.get(STATICALIZA_CAMERA_OWNER_SESSION_UID, 0)
        )
        if armature is None:
            armature = bpy.data.objects.get(str(camera.get(STATICALIZA_CAMERA_OWNER, "")))
        if armature is None:
            armature = bpy.data.objects.get(str(camera.get(STATICALIZA_CAMERA_OWNER_NAME, "")))
        if (armature is not None and armature.type == "ARMATURE"
                and armature.pose.bones.get(bone_name) is not None):
            return armature, bone_name
    for constraint in camera.constraints:
        target = getattr(constraint, "target", None)
        subtarget = getattr(constraint, "subtarget", "")
        if constraint.type == "CHILD_OF" and target and target.type == "ARMATURE" and subtarget:
            return target, subtarget
    return None, ""


def viewed_camera(context):
    space = getattr(context, "space_data", None)
    region_3d = getattr(space, "region_3d", None)
    if not region_3d or region_3d.view_perspective != "CAMERA":
        return None
    camera = getattr(space, "camera", None) or context.scene.camera
    return camera if camera and camera.type == "CAMERA" else None


def _is_visible(obj, view_layer):
    try:
        return bool(
            obj.name in view_layer.objects
            and not obj.hide_render
            and not obj.hide_viewport
            and not obj.hide_get(view_layer=view_layer)
            and obj.visible_get(view_layer=view_layer)
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        return False


def _strip_blender_numeric_suffix(name):
    """Match Animator Utils' identity handling for duplicated rig data."""
    return re.sub(r"\.\d{3}$", "", str(name or ""))


def _child_collection_by_base_name(collection, base_name):
    for child in collection.children:
        if _strip_blender_numeric_suffix(child.name) == base_name:
            return child
    return None


def recognized_rigs(scene):
    """Return Animator Utils-compatible ``(collection, armature, parts)`` rigs.

    A valid imported rig is deliberately strict: ``RIG: Name`` must contain a
    ``Parts`` child plus the matching ``__Name_Armature`` and ``__NameMeta``.
    This prevents arbitrary armatures, helpers, and loose scene meshes from
    leaking into an impact-frame capture.
    """
    scene_objects = set(scene.objects)
    seen = set()
    rigs = []
    for collection in bpy.data.collections:
        if not collection.name.startswith("RIG: "):
            continue
        rig_name = _strip_blender_numeric_suffix(collection.name[5:].strip())
        parts = _child_collection_by_base_name(collection, "Parts")
        if not rig_name or parts is None:
            continue
        armature_name = f"__{rig_name}_Armature"
        meta_name = f"__{rig_name}Meta"
        armature = None
        has_meta = False
        for obj in collection.all_objects:
            base_name = _strip_blender_numeric_suffix(obj.name)
            if obj.type == "ARMATURE" and base_name == armature_name:
                armature = obj
            elif obj.type == "EMPTY" and base_name == meta_name:
                has_meta = True
        if armature is None or not has_meta or armature not in scene_objects:
            continue
        pointer = armature.as_pointer()
        if pointer in seen:
            continue
        seen.add(pointer)
        rigs.append((collection, armature, parts))
    return rigs


def armature_targets(context, armature):
    """Minimal independent copy of Staticaliza's target affiliation rules."""
    result = []
    if armature is None:
        return result
    for obj in context.view_layer.objects:
        if obj.type != "MESH" or not _is_visible(obj, context.view_layer):
            continue
        include = obj.parent == armature
        if not include:
            include = any(
                modifier.type == "ARMATURE" and getattr(modifier, "object", None) == armature
                for modifier in obj.modifiers
            )
        if not include:
            include = any(
                getattr(constraint, "target", None) == armature
                for constraint in obj.constraints
            )
        if include:
            result.append(obj)
    return result


def _collection_meshes(collection, view_layer):
    if collection is None:
        return []
    return [obj for obj in collection.all_objects
            if obj.type == "MESH" and _is_visible(obj, view_layer)]


def resolve_sources(context):
    """Capture only visible mesh parts belonging to recognized Animator rigs."""
    subjects = {}
    for _collection, _armature, parts in recognized_rigs(context.scene):
        for obj in parts.all_objects:
            if obj.type == "MESH" and _is_visible(obj, context.view_layer):
                subjects[obj.as_pointer()] = obj

    # Background/floor scene geometry is intentionally excluded. The impact
    # renderer creates its own two-color background and never samples materials.
    return list(subjects.values()), []
