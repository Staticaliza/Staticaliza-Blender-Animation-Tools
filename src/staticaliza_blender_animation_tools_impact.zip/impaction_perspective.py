"""Shape-local tilted-plane projection and pixel-space pin snapping."""
import math

HANDLE_RADIUS = 120.0
# Half-size admission/release radii with the Animator latched snap behavior.
SNAP_RADIUS = 8.0
SNAP_RELEASE_RADIUS = 10.0

def key(camera, record, index):
    return f"{camera.name_full}:{int(record.salt)}:{index}"

def active(context, camera, record, index):
    return (camera is not None and index >= 0 and index < len(record.shapes)
            and bool(record.shapes[index].is_selected)
            and context.scene.impaction.shape_perspective_target == key(camera, record, index))

def handle(shape, rect):
    x0,y0,x1,y1=rect
    tilt=getattr(shape, 'perspective', (0.0,0.0))
    return (float(shape.position[0])+tilt[0]*HANDLE_RADIUS/max(x1-x0,1.0),
            float(shape.position[1])+tilt[1]*HANDLE_RADIUS/max(y1-y0,1.0))

def constrain(x, y, latched=False):
    distance=math.hypot(x,y)
    snapped=distance <= (SNAP_RELEASE_RADIUS if latched else SNAP_RADIUS)
    if snapped: return (0.0,0.0), True
    divisor=max(HANDLE_RADIUS,distance)
    return (x/divisor,y/divisor), False

def inverse(delta, tilt):
    length=math.hypot(*tilt)
    if length < 1e-8: return tuple(delta)
    nx,ny=tilt[0]/length,tilt[1]/length
    angle=min(length,1.0)*(math.pi/2-0.015)
    cosine,sine=math.cos(angle),math.sin(angle)
    parallel=delta[0]*nx+delta[1]*ny
    # Perspective projection of a rotated plane at distance 4 short edges:
    # screen_parallel = cos(theta)*local_parallel/(1+sin(theta)*local_parallel/4).
    denominator=max(0.0001,cosine-parallel*sine/4.0)
    along=parallel/denominator
    scale=1.0+along*sine/4.0
    return (delta[0]*scale+nx*along*(1-cosine),
            delta[1]*scale+ny*along*(1-cosine))
