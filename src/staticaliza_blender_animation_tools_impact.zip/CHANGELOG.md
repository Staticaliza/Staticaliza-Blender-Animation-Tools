# Roblox Animator Impact

# Release 1.0.0

- Integrated the verified Impact Frames renderer as the third Staticaliza
  animation extension and N-panel category.
- Preserved the existing `impaction.*` operators, RNA, marker group, and packed
  cache names so saved `.blend` files remain compatible.
- Replaced the legacy Flip state with a one-shot palette action; Update, Next,
  Copy, and Paste now preserve palette properties exactly.
- Added radial-layer banding in hybrid mode, aspect-correct regular stars,
  multi-shape selection/copy/paste, and isolated multi-frame property editing.
- Adopted the optimized transient-preview/promote lifecycle from 0.3.87 while
  leaving rendered appearance and final preview/apply pixels unchanged.
- Stopped recurring cached frames from time-expiring their managed GPU image
  textures during playback, eliminating redundant full-frame re-uploads.
- Kept the exact completed live surface on the GPU during slider and dragger
  motion, then read back and packed that same surface once on settle.
- Removed the standalone development self-updater; the shared Setup extension
  now owns download and upgrade behavior.

# Impaction Impact Frames 0.3.87

- Made live dragging latest-state-wins: the visible frame renders transiently,
  then the exact displayed image is promoted and packed on settle without a
  second render. Hidden selected frames coalesce and apply once after input
  becomes quiet.
- Reused fullscreen batches, gradient textures, zero textures, and GPU readback
  buffers; removed unused floor/background-motion raster work while preserving
  the shader contract and bit-identical output.
- Cached immutable subject bounds, centers, affine fields, and render
  signatures, and reduced multi-subject capture projection/normal setup from
  once per mesh or vertex to once per sampled frame.
- Added bounded LRU/ownership policies for capture, raster, mask, gradient,
  readback, signature, deleted-record, and preview resources, with explicit
  cleanup on reload and unregister.
- Removed redundant image packing and bounded the one-shot Dope Sheet collapse
  scheduler so repeated extension reloads cannot accumulate timers.
- Added live-preview identity, multi-frame coalescing, capture equivalence,
  timer lifecycle, resource-bound, and packaged-render regression contracts.

# Impaction Impact Frames 0.3.86

- Restored object-selection protection over the displayed Impact camera image with a non-modal 3D View keymap operator. It passes pin clicks through and cannot capture timeline, panel, header, or other-editor input.

- Removed the persistent camera-view input shield that could consume left-click and selection events after an Impact Frame was created. Pin dragging remains constrained by each pin's precise diamond hit test.
- Fixed the one-time `Impact Frames` Dope Sheet collapse by temporarily isolating the generated host channel, collapsing it, restoring the user's channel filter, and retrying until a Dope Sheet context is available.

- Collapse the dedicated Impact Frames Dope Sheet host once, immediately
  after its first marker is created. Later user expansion remains untouched.

# Impaction Impact Frames 0.3.83

- Moved Impact marker animation to a dedicated scene-level `Impact Frames`
  host so the Dope Sheet shows its own blue top-level action row instead of a
  green group nested beneath one rig.
- Unified marker display across multi-rig captures and retained per-camera
  marker identity, retiming, selection, exposure tails, and deletion behavior.
- Existing rig-nested marker curves migrate when their exposure is rebuilt;
  the non-rendering marker host is created after scene rigs for bottom sorting.

# Impaction Impact Frames 0.3.82

- Added an independent persistent imperfection seed to every Star and Doodle.
- Reroll shape imperfection on every editable shape-property change, position
  drag, and doodle point addition/removal while leaving frame-line RNG stable.
- Preserve shape variation through frame copies and restore it when a modal
  shape drag or doodle edit is cancelled/undone.

# Impaction Impact Frames 0.3.81

- Made Flip swap the stored Foreground and Background color-box values, with
  one-time migration that preserves the appearance of older flipped frames.
- Increased maximum Motion Blur shutter reach and exposure contribution.
- Increased maximum Chromatic Aberration separation and full-strength onset
  while retaining a progressive response at lower settings.

# Impaction Impact Frames 0.3.80

- Simplified Band to an unsigned 0–1 control and migrated legacy negative
  values to the equivalent positive strength.
- Remapped low Band values to fewer, longer white rests while higher values
  pack shorter rests more densely; exact zero and subject hatching bypass it.
- Added a cached subject-center magnetic target for the pink direction pin;
  hold Shift while dragging to bypass the snap for precise free placement.
- Made the shader's centered sunray classification follow the captured subject
  center, including off-center compositions, instead of the frame midpoint.

# Impaction Impact Frames 0.3.79

- Preserved the complete authored/lighted RGB center through Chromatic
  Aberration and applied only the wavelength-displaced palette delta, fixing
  colored subjects and impact light collapsing to gray.
- Replaced the prematurely saturated aberration onset with a normalized,
  progressive response so low settings produce restrained edge fringes while
  high settings retain the intended strong dispersion.

# Impaction Impact Frames 0.3.78

- Replaced centered Linear's single screen-axis lock with restrained
  face-launched tangents and mid-span surface bows that rejoin one keyed
  terminal channel instead of becoming radial spikes or identical swipes.
- Restored a projected 3D fan to centered background families while retaining
  coherent keyframed motion steering and exact zero-motion behavior.
- Split Radial's protected star from its threshold-controlled sunray heels, so
  Threshold moves individual ray starting points without lens-erasing subject
  hatching or projecting long white light streaks across the mesh.
- Rebuilt Radial and Hybrid Band as periodic, broken angular sectors with
  per-sector offsets, edge wear, and graded opacity; Twirl no longer exposes
  the polar seam as a left-side separator.

# Impaction Impact Frames 0.3.77

- Restored None-mode lighting to its neutral painted plate while giving Linear
  and Radial light deposits a finer manga dry-brush breakup.
- Warped captured tone, light, hatching, and construction-line lookups along
  the action field so rendered mesh faces read as imperfect drawn regions;
  None remains unwarped.
- Replaced centered Linear's final radial overwrite with one face-launched,
  motion-aware channel and removed the competing centered explosion accents.
- Aligned centered background families to that same motion channel, increased
  their Cast Behind admission and reach, and retained exact motion-off bypass.
- Rebuilt zero-Twirl Band boundaries from asymmetric lobes, sector breaks, and
  correlated displacement that grows progressively more chaotic with strength.

# Impaction Impact Frames 0.3.76

- Replaced per-line Band dashes with coherent, imperfect negative-space regions
  that cut across complete radial bundles and share one field in Hybrid.
- Made Band strength progress from sparse broad interruptions to denser broken
  rings while preserving the exact zero bypass and subject-hatch invariance.
- Rebuilt subject lighting as roughened, simplified drawing regions with
  directionally correlated deposits and real paper gaps instead of pristine
  per-polygon light plates.
- Removed Hybrid's weak orthogonal radial sectors, extended centered background
  gestures across the crop, and strengthened face-anchored 3D winding so the
  main channel wraps the subject instead of reading as a flat explosion.
- Made centered subject hatch packets follow the projected wind and displaced
  Band boundaries with correlated angular waves to avoid perfect circles.

# Impaction Impact Frames 0.3.75

- Removed Band from subject hatching, construction contours, and their final
  print threshold; hatch-only output is now pixel-identical across Band values.
- Replaced shared periodic Band rings with stable narrow-lane identities,
  independently randomized run lengths, duty cycles, offsets, and edge wear.
- Restored full authored Linear stroke width in Hybrid while retaining the
  lower family count used to prevent two complete line systems becoming a wall.
- Reduced Bleed reach and replaced its symmetric outline probes with slowly
  varying asymmetric brush load and imperfect local coverage.
- Rebuilt colored subject lighting from the captured light carrier and broken
  macro/meso paint load instead of filling every captured mesh plane opaquely.

# Impaction Impact Frames 0.3.74

- Added the Lighting-panel Bleed control with exact zero bypass, using a
  light-colored, line-native separation rim to retain motion readability over
  dark backgrounds without washing the full frame.
- Extended Radial Threshold into narrow negative-space sunrays, kept strong
  corner Twirl curved through the complete camera crop, and changed Band to
  dense, family-offset material erosion in isotropic radial coordinates.
- Smoothed Hybrid sector admission and applied Band to both constituent line
  fields without a hard white wedge.
- Removed the Star's translucent 90-percent transition: regular spikes remain
  opaque until the terminal value, where the spiky ball switches immediately
  and equal X/Y sizes produce a pixel-circular result.

# Impaction Impact Frames 0.3.73

- Coupled hybrid Linear/Radial composition through a shared direction field
  and low-frequency radial sectors, preventing two full-density masks from
  colliding into an unrelated black wall while preserving either mode alone.
- Closed the strong-Twirl angular family seam with periodic cell indexing.
- Rebalanced Band into alternating retained black deposit and physically
  eroded translucent gaps, and matched its blue-fill slider to Twirl.
- Restored centered and edge-pin background admission with distance-aware
  family reach so rear-cast strokes can cross and fill the camera crop.
- Decoupled maximum-thickness Star spike width from the major-axis radius,
  keeping X/Y stretch independent and equal values aspect-correct.

# Impaction Impact Frames 0.3.72

- Replaced the exclusive None/Linear/Radial selector with independent Linear
  and Radial toggles. Neither retains automatic subject drawing; both renders
  Radial first and gives Linear foreground priority.
- Migrated legacy exclusive modes into the new toggles without altering saved
  frame behavior or removing the serialized compatibility field.
- Rebuilt every gizmo basis from region pixels on each draw, preventing stale
  transforms after Quick Update or extension reload from offsetting draggers.
- Made rear-cast Radial use the complete protected-center erosion, preserving
  the same broad white transition around the magenta focus as front cast.
- Locked centered broad Linear/background packets to the same projected 3D
  hemisphere tangent as thin construction strokes, including front/rear
  camera-axis sun-ray behavior.
- Added a combined-mask layer pass and skipped duplicate subject hatching in
  the rear Radial layer to bound the cost of enabling both modes.

# Impaction Impact Frames 0.3.71

- Strengthened Radial Twirl endpoints while retaining one isotropic curve
  field for loaded ribbons, hairlines, hatching, and background gestures.
- Rebuilt Band's high range as dense irregular material erosion, producing
  visibly thinner and lighter deposited marks without a white overlay.
- Expanded Threshold's nonlinear range and physically tapered radial widths
  into its center pocket; Cast Behind now preserves the same white-star fade.
- Unified Radial with the magenta direction/focus pin used by the other line
  modes, with full-frame positioning in Radial and hemisphere clamping in
  directional modes.
- Corrected maximum-thickness anisotropic stars to keep local-axis spike mass
  and opaque pigment instead of a soft stretched center bar.
- Made Copy Image and Export Image resolve the current Impact frame from any
  editor and installed the RMB camera-image guard in every visible workspace.
- Coalesced slider-release work with an already-current live cache and reduced
  Band shader noise sampling without changing promoted preview pixels.

# Impaction Impact Frames 0.3.70

- Rebuilt Radial Twirl around one aspect-correct radius contract shared by
  loaded ribbons and graphite hairlines, removing the rectangular frame-edge
  normalization that made high curls form square corners.
- Inverse-warped grouped background brush and graphite gestures through the
  same Twirl field, so the broad trail behind the subject now follows the
  thin radial families instead of remaining comparatively straight.
- Reworked Band as deterministic coverage erosion and pigment-opacity
  modulation. Values near -1 and +1 now produce much thinner, lighter marks
  with multiscale offsets rather than a regular sinusoidal white-mask effect.
- Removed `motionBlur` from the canonical impact-mask shader interface;
  Motion Blur remains an independent post pass, eliminating the optimized-out
  uniform upload risk without changing the exact zero-blur mask.

# Impaction Impact Frames 0.3.68

- Made Star thickness a deliberate morphology control: high values merge the
  four primary brush arms into a diamond, while 100 becomes an irregular
  circular spiky impact daub; unequal X/Y values preserve the same transition
  as an anisotropic oval rather than snapping back to a circle.
- Removed the elbow in long background graphite lines by evaluating their arc
  over their own full length rather than reusing a shorter, clamped brush arc.
- Applied the background population gradient to every fragment of grouped
  thick and graphite families, so pressure is strongest opposite the pink pin
  and visibly falls toward it even when one long stroke crosses both regions.
- Strengthened the same gradient at family admission while retaining a quiet
  nonzero terminal floor.

# Impaction Impact Frames 0.3.67

- Added a Radial-only Spiral control (-1.00 to 1.00, default 0.00) below
  Threshold; its sign reverses the coherent curl shared by loaded rays and
  graphite hairlines.
- Extended radial paths beyond the camera diagonal so the viewport crop—not
  an interior radius—forms their outer endpoint, and removed the dilated
  subject-support multiplier that exposed a character-shaped ring.
- Replaced the hard central cutout with a wider irregular graphite pressure
  transition so black rays fade into the protected white impact star.
- Corrected both background families to be most frequent opposite the pink
  pin and progressively quieter toward it, while retaining a nonzero terminal
  floor; independent thin lines now use midshade graphite pressure.

- Reduced the independent background speed-line family from ink pressure to
  graphite pressure, with narrower hatching-derived marks.
- Strengthened its directional population gradient: marks are now materially
  denser and darker at the source, then both less frequent and lighter toward
  the travel end instead of fading by opacity alone.

- Rebuilt Radial composition around subject-seeded brush families: loaded and graphite strokes now share coherent motion-conditioned curvature into the focus.
- Added a Radial-only Threshold control (default 0.5) that protects an irregular four-lobed white impact pocket from all foreground, hatch, and background stroke layers.
- Exposed Motion Curve and Spread in Radial mode.
- Added a separately seeded graphite speed-line layer for quiet background
  paper, with source-heavy population and a lighter, sparser down-trail fade.
- Made Background Motion map from exactly straight at zero to progressively
  stronger coherent gesture curvature at one.
- Split radial front/rear ownership so Cast Behind preserves the subject while
  selected channels still travel through the body into the focus.

## 0.3.66

- Added a readable scale of long, single, hatching-derived graphite strokes behind the subject while retaining broad brush families.

# Impaction Impact Frames 0.3.65

- Standardized continuous Shape controls to four-decimal input precision while preserving integer-only Arms values.
- Removed subject-edge blocker expansion so colored light no longer exposes a white divider between the silhouette and black stroke layers.

# Impaction Impact Frames 0.3.64

- Changed per-shape effect influence from clean/effected cross-fades to local
  effect-parameter scaling, preventing the original star or doodle from
  remaining visible beneath pixelation, aberration, motion, or halftone.
- Added wrapped two-dimensional Star Rotation from -180 to 180 degrees and
  applied it consistently to primary arms and the integrated burst.
- Made Next leave Blender's animation cursor on the generated impact key after
  capture and rendering handlers finish.
- Made shape halftone replace interior coverage with visible discrete dots,
  made crisp aberration use five separated spectral color plates, and deferred
  undo/redo GPU rebuilds to the safe main-loop timer for reliable RNA undo.
- Made Pixelate use one identical frame grid for shapes regardless of Shape
  Effect Influence, hid Background Motion at zero intensity, and restore the
  marker/record layout associated with an undone or redone FPS value.

# Impaction Impact Frames 0.3.63

- Replaced the Lighting color-source choice with one direct white-default
  color field while migrating legacy Foreground/Background selections.
- Added serialized per-shape Effect Influence (default 0.5, exact bypass at
  zero) and applied it to halftone, grain, aberration, motion, pixelation, and
  bloom participation.
- Corrected Aberration Blur Smoothing so both modes share identical spectral
  wavelengths and displacement; smoothing now changes only spatial softness.

# Impaction Impact Frames 0.3.62

- Fixed Back shape ownership: rear stars and doodles are now occluded by the
  complete captured subject silhouette as well as generated ink; Front shapes
  remain above the subject, hatching, and hero strokes.
- Replaced smooth Lambert-like subject color grading with a flat full-color
  light plate. Light direction still controls drawing structure, but enabled
  light no longer produces soft 3D-render shading across anime planes.

# Impaction Impact Frames 0.3.61

- Removed round Doodle endpoint caps while retaining opaque dry-brush ends.
- Shape type/list/add/remove changes now terminate active Draw/Erase sessions.
- Renamed the Type selector to Shape and updated Star authoring defaults.
- Back shapes now reveal black subject ink correctly over black paper.

# Impaction Impact Frames 0.3.60

- Rebuilt centered subject/background flow as an explicit cast-aware 3D
  hemisphere projection, including the lower frame instead of collapsing back
  to one screen-space axis.
- Reused finite hatch-like graphite actions throughout the background at the
  default 0.5 intensity/motion, with shared broad/fine direction and no rare
  edge-dash-only result.
- Reworked Star arms into opaque loaded brush silhouettes with short exterior
  edge fibres, removed transverse banding, increased maximum arm/burst mass,
  and moved X/Y controls above Thickness.
- Changed Shape bloom to a boundary-seeded multiscale convolution so saturated
  Shapes diffuse without creating a flat colored duplicate.
- Decoupled light energy from dark Background pigment and normalized colored
  light hue, while retaining thick graphic strokes independently of lighting.
- Restored rounded, finite Doodle endpoints and true point-to-curve distance at
  bends, eliminating concave tangent-line extensions.
- Restored the cube icon for the Shapes subpanel while preserving Star and
  pencil icons in the list.

# Impaction Impact Frames 0.3.59

- Made thick and curved subject strokes graphic-light independent: changing
  the light now redraws tonal hatching without deleting or relocating loaded
  main-stroke families.
- Restored functional aberration color presets and added default-on Blur
  Smoothing beneath the renamed Color selector.
- Added a perspective-aware virtual hemisphere to centered subject and
  background flow so camera/pink-pin rotation produces a 3D corona rather
  than a flat screen-space bend.
- Replaced Doodle's concave corner construction with bounded rounded Bezier
  joins that preserve the authored zigzag without inner hooks.
- Kept Composition and Lighting Cast Behind defaults off for new frames.
- Added short, finite graphite speed marks to centered and directional
  backgrounds, sharing the same cast-aware 3D flow as the broad strokes.
- Made aberration Blur Smoothing switch between continuous filtered color
  separation and visibly discrete unfiltered color rails.
- Expanded Star reach to three frame-short-edge units at maximum, strengthened
  primary and Burst thickness, and made Burst thickness/end controls fully
  independent.
- Closed Doodle's tight-turn gaps with round dry-brush knot deposits and kept
  bloom chroma sourced from each Shape instead of bleaching it to white.
- Disabled Shape Copy when no Shape is selected and made reused Shape numbers
  fill their missing ordered slot without duplicate names.

# Impaction Impact Frames 0.3.58

- Decoupled loaded hero/main-stroke admission, density, and width from the
  lighting field; lighting continues to grade hatching without erasing the
  graphic action silhouette.
- Reprojected centered background families as a cast-aware radial 3D field and
  increased finite graphite-trace visibility while keeping broad and thin
  marks on one shared pink-pin/camera direction.
- Set Motion Blur's actual RNA/initialization default to zero and consolidated
  aberration/pixelation after subject, background, and Shapes are composited,
  eliminating crisp unprocessed lines beneath those effects.
- Rebuilt Star and Doodle deposits from discrete loaded graphite fibres with
  correlated paper tooth and continuous doodle phase, replacing smooth tubes,
  twisted gradients, dotted capsules, and barcode edges.
- Rebuilt Star shapes from independently perturbed dry-brush arms and an
  integrated diagonal Burst, with corrected screen-space X/Y reach and 0-100
  artist controls.
- Made Doodle translation rigid, restored cancellation/undo state, and fixed
  Draw/Erase labels, icons, centering, naming, and cross-frame clipboard use.
- Moved Shapes before spatial post effects and added a shape ownership mask so
  Pixelate, Motion Blur, Aberration, and Bloom affect them consistently at a
  reduced strength.
- Restored finite, direction-aligned graphite construction strokes behind the
  subject without full-frame lens fields, broken contours, or opposing flow.
- Locked preview reconstruction to deterministic output-derived dimensions,
  preserved exact preview/apply pixels, and blocked bone/object selection
  through every visible Impact overlay opacity.

# Impaction Impact Frames 0.3.57

- Reworked Star shapes into a single-color, dry-brush explosion silhouette
  with independent horizontal/vertical reach, arm-end profile, core size, and
  optional irregular burst rays. Doodles are now single-color strokes.
- Fixed shape dragging's missing interactive-frame lookup and added draw-mode
  crosshair, Stop toggle, pass-through UI access, and local undo/redo history.
- Promoted the exact live drag preview on release so the applied main-stroke
  pattern no longer changes after the pink, yellow, or radial pin is released.
- Replaced the background's screen-wide lens lanes with finite aligned brush
  families, retaining longer graphite construction marks without cut seams or
  accidental four-point intersections.
- Moved the impact-image right-click binding ahead of Blender mode menus and
  routed it through the viewport shield for Copy Image and Export Image.
- The development updater now atomically installs and activates the new module
  after a delayed UI-safe reload, without requiring a Blender restart.

- Restored sparse finite graphite/graphene background accents without the old
  continuous lens-contour field.
- Added frame-local Star and Doodle shapes, green camera pins, Front/Back
  layering, direct doodle draw/erase, selected-shape controls, and shape/frame
  Copy/Paste serialization.
- Added a reduced-effects shape composite so graphic accents stay readable.
- Restored the Install Latest Extension label and import icon.

# Impaction Impact Frames 0.3.55

- Restored the **Install Latest Extension** label and import icon after the
  accidental 0.3.53 build-only regression.
- The updater now atomically installs package files after the button operator
  returns, while leaving live Blender RNA registered until restart.
- Added a direct add-on keymap for right-clicking a visible Impact image in any
  camera-view 3D editor. The menu exposes **Copy Image** and **Export Image**
  and passes right-click through everywhere else.

# Impaction Impact Frames 0.3.54

- Fixed an unreachable background-ink stage that made enabled background
  defaults appear nearly identical to a background bypass.
- Set Background Intensity and Background Motion defaults to `0.5`; validation
  now renders those exact values from the saved `.PunchTester.blend` with all
  post-processing disabled.
- Unified thin and loaded background families with the main away-from-pin
  polarity, removed per-pixel lens curvature, softened binary dropout cuts,
  and retained finite brush/graphite packets behind the captured subject.
- Changed the in-Blender development action to build a package only. It no
  longer disables and re-registers live Operator RNA, avoiding the Blender 5.2
  tooltip crash in `WM_operator_properties_sanitize`; restart before install.

# Impaction Impact Frames 0.3.53

- Added a camera-image-only right-click menu with native Blender-styled
  **Copy Image** and **Export Image** actions. It intercepts right-click only
  over a visible Impact overlay and preserves normal menus everywhere else,
  including other Blender windows and editors.
- Rebalanced main ink into clearer parent/support/fine families: fewer
  equal-weight macro deposits, coherent quiet-paper corridors, reduced local
  angular chatter, and earlier whole-stroke centered winding.
- Reduced background packet admission while retaining both loaded brush and
  graphite construction families, improving macro/meso/micro hierarchy without
  flattening the hand-drawn Impact Frame identity.

# Impaction Impact Frames 0.3.52

- Prevented the Blender 5.2 Next-frame crash by making aberration-gradient
  snapshots read-only; a missing legacy ramp no longer mutates IDProperties
  while a new frame collection item is being copied.
- Changed new-frame background defaults to Intensity 1.0 and Motion 0.5.
- Corrected camera/background polarity, retained a restrained thin-line class,
  shortened isolated hairs, and loosely biased background packets to the pin.
- Removed the remaining analytic rocket taper; dry-brush releases now keep a
  loaded body and vary through staggered bristle endpoints.
- Centered Cast Behind now assigns all centered impact families below the
  subject and suppresses visible front deposits; front cast keeps its
  through-subject aerodynamic channel. Spread remains active in both paths.

# Impaction Impact Frames 0.3.51

- Made motion curvature a complete family-level trajectory: weak guidance is
  straight, while confident guidance curves the loaded body and every bristle
  continuously through its staggered release.
- Replaced background rain-like hairlines with clustered three-pass brush
  packets, wider dry-brush blades, irregular lengths, and larger paper gaps.
- Strengthened the subject-shaped outer shell using the existing main-stroke
  texture, with denser side/top/bottom silhouette emitters and varied blades.

# Impaction Impact Frames 0.3.50

- Preserved background-stroke ownership through the post-processing pipeline.
- Reduced background halftone, pixelation, grain, motion blur, aberration, and
  bloom while retaining full-strength subject effects.
- Camera motion now steers background blur and aberration independently from
  the subject/action direction.

# Impaction Impact Frames 0.3.49

- Added Background Intensity and Background Motion directly below Flip.
- Added a separate, deterministic behind-subject background stroke layer with
  fine dry-brush families and sparse loaded camera-motion accents.
- Camera pan, roll/orbit, and dolly now drive a fitted screen-space affine
  field; environment motion remains spatial where captured geometry exists.
- Background Intensity 0 is an exact bypass, preserving existing frame pixels.

# Impaction Impact Frames 0.3.48

- Strengthened Motion Curve using each emitting body region's captured velocity
  and acceleration, preventing the torso average from cancelling a punching
  limb's authored turn.
- Replaced short-edge/smoothstep bending with a stroke-length-scaled quadratic
  centerline so long loaded strokes retain one visible arc through their tip.
- Preserved the exact Motion Curve 0 bypass and matching shader behavior on the
  modern and compatibility render paths.

# Impaction Impact Frames 0.3.47

- Reworked a screen-centered 3D pin into a seed-relative perspective halo,
  retaining one renderer while making every surface family radiate coherently.
- Removed the centered-source half-length collapse and increased loaded halo
  overlap to eliminate giant white wedges between primary stroke groups.
- Preserved distinct front and Cast Behind depth composition: front families
  cross the visible form, while rear families occlude under it and re-emerge.
- Added Motion Curve influence (0-1, default 1) with an exact zero-motion
  capture path that bypasses animation-derived steering and curvature.
- Replaced adjacent-frame-only sampling with nearest surrounding authored
  animation-key sampling, normalized for unequal key intervals, while keeping
  rasterized per-vertex motion for limb-local ownership.
- Changed motion curvature to one smooth family-level trajectory and suppresses
  small procedural deviations when a confident keyed arc is present.

# Impaction Impact Frames 0.3.46

- Rebased Spread so 0.5 preserves the former 0.0 near-parallel appearance.
- Replaced screen-Y rotation with a ray-perpendicular signed fan: 0 converges,
  0.5 stays neutral, and 1 opens strongly without forming an inward arrow.
- Applied the same mapping to primary, silhouette-accent, and front nook-fill
  strokes so the whole main-stroke system follows one control standard.

# Impaction Impact Frames 0.3.45

- Split short front-fill strokes between silhouette-loaded and interior-loaded
  seeds so heads, arms, torsos, and legs retain dense visible-face ink.
- Use curved-surface normals only for pressure/loading, preserving the shared
  sunray direction while distributing brush mass across rounded faces.
- Occlude rear rays with a dilated subject-only blocker, preventing rear-layer
  ink from leaking over fractional curved head and limb edges.

# Impaction Impact Frames 0.3.44

- Replace the shared subject-envelope cutoff with independent pressure-shaped
  brush endpoints and soft opacity support, removing flat vertical borders.
- Make loaded and support brush families the dominant trail morphology while
  retaining only a small keyed population of fine needle accents.
- Increase secondary pass widths and width floors so long leeward trails keep
  normal brush thickness and varied dry-brush overshoot.

# Impaction Impact Frames 0.3.43

- Treat the pink direction pin as a sun/source: every main, companion, and
  silhouette family travels away from its source-relative projected position.
- Make rear rays use a compact source-side heel and a long leeward release, so
  they disappear beneath a limb and reappear only beyond its away-facing edge.
- Preserve the same ray polarity for front and rear depth layers and for
  mirrored left/right pin positions.

# Impaction Impact Frames 0.3.42

- Regenerate deterministic main-stroke topology whenever direction, Spread,
  intensity, thickness, or Cast Behind changes instead of rotating old marks.
- Give every limb packet three front-visible passes plus one rear-under-subject
  pass, preventing rear classification from erasing the right arm or leg.
- Remap Spread around a neutral 0.5: zero converges, 0.5 stays parallel, and
  one diverges more widely, including silhouette support families.
- Increased main candidates from 80 to 96, retained nearly every packet, and
  added compact loaded companions to fill small gaps.

# Impaction Impact Frames 0.3.41

- Routed trailing camera-perspective duplicates exclusively through the rear
  layer, which is occluded wherever the captured subject is visible.
- Added shorter, thick loaded companion strokes to fill white shelves between
  hero strokes while preserving the same away-from-pin direction and depth.

# Impaction Impact Frames 0.3.40

- Added a final geometric polarity lock after surface, motion, and Spread
  steering so all main and silhouette families travel away from the pink pin.
- Added regression coverage for the away-from-pin direction invariant.

# Impaction Impact Frames 0.3.39

- Removed per-side silhouette polarity reversal so every main stroke follows
  the pink-pin direction rather than firing outward from opposite faces.
- Restored loaded brush mass across hero and support families.
- Made each launch packet contribute a fixed front/rear pair, preventing
  face-normal classification from deleting entire limbs or torso regions.

# Impaction Impact Frames 0.3.38

- Replaced late per-stroke Spread bending with a coherent pin-relative fan
  angle shared by loaded, companion, filament, and silhouette families.
- Replaced random front/rear membership with face-derived depth ownership;
  rear families are composited only outside the visible subject mask.
- Increased low-discrepancy side-face coverage and split silhouette support
  across front and rear layers while retaining flatter top/bottom strokes.
- Corrected the visual harness so it renders the supplied tester state without
  hidden direction, Cast Behind, Spread, or recapture overrides.

# Impaction Impact Frames 0.3.37

- Made front/rear main-stroke membership independent of the Cast Behind toggle;
  both states retain a mixed depth population while the toggle changes bias.
- Kept front families clipped to the visible subject surface, preventing
  detached foreground bars from protruding into empty paper.
- Reduced the special rear silhouette support from 48 heavy bundles to 24
  narrower, lower-opacity gestures so it no longer overwhelms front strokes.
- Replaced synchronized 12-lane placement with low-discrepancy silhouette
  sampling, independent longitudinal phases, and unequal lengths to remove
  barcode-like white gutters.
- Validated both toggle states at the user's reproduced `X 74`, `Y -12`,
  `Spread 0.5` settings on `ImpactFrameTest.blend`.

# Impaction Impact Frames 0.3.36

- Replaced the incorrect global cast-behind cut with per-family depth
  ownership assigned at each stroke emitter.
- Rear-classified trailing families now render below the subject mask while
  interior and front-facing families remain above the torso and limbs.
- Kept silhouette accents in the rear layer without forcing every main stroke
  behind the character.
- Added an explicit centered cast-behind fixture override and verified mixed
  front/rear stroke visibility on `ImpactFrameTest.blend`.

# Impaction Impact Frames 0.3.35

- Promoted the backside silhouette pass from a subtle accent into the major
  perimeter trail requested by the reference markup.
- Increased coverage to 48 correlated gestures across 12 horizontal and 12
  vertical bands, loading both members of each bundle instead of leaving one
  member as a faint filament.
- Made the strokes shorter, substantially wider, and more opaque so the crown,
  torso-left edge, arm, and both legs read as a nearly continuous black rear
  boundary rather than isolated marks.
- Verified visibly different ordinary and centered X=-5, Y=3 renders using
  `ImpactFrameTest.blend`; the centered render retains the same 3D trail system.

# Impaction Impact Frames 0.3.34

- Replaced faint backside filaments with medium two-pass dry-brush bundles:
  one loaded support stroke plus one shorter broken companion.
- Increased backside travel length, heel loading, width, and opacity so head,
  torso-left, arm perimeter, and leg-back sectors carry visible black weight.
- Removed the per-pixel silhouette mask that chopped stronger trails into
  square fragments; backside ownership is now decided once per verified
  silhouette anchor and outward polarity.
- Preserved tapered/bristled endpoints by letting the complete pressure-shaped
  gesture extend onto paper instead of clipping it to the blocky subject mask.
- Verified the stronger bundles in both ordinary off-center mode and centered
  X=-5, Y=3 depth-facing projection on `ImpactFrameTest.blend`.

# Impaction Impact Frames 0.3.33

- Removed the failed ordinary-mode rear-silhouette layer that produced random
  black rectangles, detached head caps, and bleached front-leg masses.
- Restored one coherent through-body wind system with one loaded parent, two
  narrower support passes, and a fine accent per gesture bundle.
- Bounded hero width by trajectory length and extended heel taper so short
  strokes cannot become square limb- or head-shaped slabs.
- Added a separate narrow perimeter-trail pass with deterministic left/right
  and top/bottom sector sampling for head, arm, torso, and leg silhouettes.
- Forced perimeter accents to choose the outward polarity and limited them to
  exterior pixels whose backward probe reaches the subject, preventing clean
  parallel rails across the torso.
- Replaced centered-pin silhouette-tangent topology with the same aerodynamic
  surface projection used elsewhere. Center now preserves the X=-5, Y=3
  camera-basis direction and applies 3D perspective through restrained normal
  correction, foreshortening, width, and taper polarity.
- Added explicit off-center and centered-pin source-fixture renders using
  `ImpactFrameTest.blend` for the active Blender 5.2 OpenGL shader path.

# Impaction Impact Frames 0.3.32

- Ported the complete coverage and temporal-coherence system to Blender 5.2's
  active OpenGL compatibility shader instead of changing only the unused
  primary GPU path.
- Replaced probabilistic rear launches with one stratified silhouette member
  per low-discrepancy family bundle, covering torso-left, head, arm top, torso
  top, and lower-body boundaries without side-specific random holes.
- Restricted rear deposits to exterior paper pixels that can probe inward to
  captured subject ownership, preserving the white subject window instead of
  painting behind-form trails across its visible face.
- Reduced overly long/deep charcoal scrape channels and retained a weak loaded
  brush core, removing ruler-like white cuts through broad leg strokes while
  keeping dry-brush edge breakup.
- Corrected the ImpactFrameTest harness to force the workspace extension source
  and verify the actual OpenGL shader selected on the target Blender build.

# Impaction Impact Frames 0.3.31

- Stabilized main-stroke semantic IDs while dragging the pink direction pin,
  eliminating whole-composition re-rolls and wild up/down heading jumps from
  tiny edits.
- Quantized the shared 3D direction into deliberate animation drawing poses;
  hatching now redraws with a pose-specific pencil lattice instead of smoothly
  rubber-rotating the previous one.
- Increased low-discrepancy main-family coverage and converted formerly empty
  packets into short, low-pressure correction strokes that fill subject gaps
  without an additional shader pass.
- Added restrained silhouette/rear-launch families so loaded strokes can emerge
  from behind the captured form as well as deposit across its visible face.
- Reduced random group and local angle error while preserving broad parent,
  support, filament, and pointed endpoint variety.

# Impaction Impact Frames 0.3.30

- Replaced Spread's whole-stroke rotation with a genuine curved fan: every
  family keeps its shared aerodynamic launch tangent and separates laterally
  toward the far endpoint.
- Ordered fan curvature from each actual launch position, bending upper
  families upward and lower families downward.
- Scaled fan displacement by each stroke's own gesture length, preventing
  short marks from curling into vertical hooks at viewport resolutions.
- Applied the same centerline bend to companion bristles so broad brush
  families remain coherent rather than splitting into unrelated angles.

# Impaction Impact Frames 0.3.29

- Exaggerated the Spread 1 endpoint to a much wider vertical cone while using
  a cubic response so the default 0.5 remains controlled.
- Restored long hero, support, and accent trajectories after the previous
  hierarchy pass shortened them too aggressively.
- Regularized main-stroke headings around one shared projected 3D axis;
  captured surface direction now supplies only a restrained form correction
  instead of rotating every stroke to an unrelated angle.
- Added reduced-resolution `ImpactFrameTest.blend` validation matching the
  viewport scale where short/random-angle failures were visible.

# Impaction Impact Frames 0.3.28

- Corrected Spread semantics: 0 is now a narrow aerodynamic bundle and 1 is
  a wide, spatially ordered up/down cone around the same central 3D axis.
- Removed the former pin-convergence and perpendicular-rotation branches that
  caused Spread 0 to form a star and Spread 1 to rotate into random spikes.
- Began the main-stroke hierarchy rework with fewer candidate bundles, more
  intentional negative space, broader hero swipes, and shorter/lighter
  supporting and accent families.
- Added a repeatable 0/0.5/1 visual sweep for the supplied
  `ImpactFrameTest.blend` fixture.

# Impaction Impact Frames 0.3.27

- Removed the legacy 2D/3D direction selector and its serialized property;
  Linear and None now always use the shared camera-space 3D wind field.
- Exposed Cast Behind consistently for None, Linear, and Radial modes.
- Made Radial Cast Behind reverse both brush heel/release ownership and the
  polarity of directional post effects.

# Impaction Impact Frames 0.3.26

- Corrected None-mode motion blur, chromatic displacement, and directional
  composite effects to use the pink 3D wind pin rather than the unrelated
  radial-focus control.
- Made None-mode directional post effects honor Cast Behind, keeping their
  one-sided trail polarity consistent with the aerodynamic hatch field.

# Impaction Impact Frames 0.3.25

- Restored a persistent hand-drawn external silhouette with lighter pressure
  in lit regions, while excluding artificial internal U/lens seam contours.
- Made light intensity and custom-color value drive a graded nested hatch ramp
  instead of erasing the subject as a binary white cutout.
- Restored irregular hatch and loaded-stroke overshoot beyond the captured
  subject edge; finite straight hatch actions now lift before they can join
  into lens-like curves.
- Increased loaded main-stroke coverage and centered-family density, reduced
  non-motion curvature, and preserved distinct front/rear 3D ownership.
- Spread defaults to 0.5 and now reserves convergence for 0 and perpendicular
  fanning for 1 without replacing the shared aerodynamic stroke system.

# Impaction Impact Frames 0.3.24

- Removed the unrequested Torso snap operator and both Torso UI buttons.
- Replaced the inert late Spread offset with shared 3D trajectory steering:
  `0` converges on the pin, `0.5` retains aerodynamic surface flow, and `1`
  rotates toward a perpendicular/tangential family.
- Centered front and Cast Behind now relocate the same linear families to the
  silhouette; front owns the visible face while rear receives a readable
  outward corona gate instead of being suppressed as background detail.
- Removed long-range shadow bleed and the lit-pixel hatch sentinel. Hatching
  now follows local cel-light value, rejects highlights exactly, and loads
  primary/cross families progressively in genuine shadow.
- Added exact PunchTester sweeps at 3D direction X=-5, Y=3 for both
  hemispheres and Spread values 0, 0.5, and 1.

# Impaction Impact Frames 0.3.23

- Replaced centered 3D screen-axis rotation with surface-normal and projected
  silhouette winding inside the shared linear family system. Front wind now
  crosses the visible form; Cast Behind relocates the same seeds toward the
  silhouette and applies camera-correct rear occlusion.
- Removed continuous contour/seam tracers that generated nested lens shapes;
  hatch actions now have straight centerlines, straight ownership probes, and
  real pressure-lift gaps between independently angled actions.
- Staggered companion/filament release points across brush width to eliminate
  synchronized density shelves, while retaining the 0.5 Spread default.
- Added source-backed PunchTester validation with an auditable centered `.blend`
  copy and explicit front/rear image digests.

# Impaction Impact Frames 0.3.22

- Removed centered-pin dispatch to the separate silhouette-ray renderer;
  centered and off-center 3D pins now use the same aerodynamic stroke system.
- Preserved the directed 3D surface-trail sign separately from its undirected
  line axis, so front/rear hemisphere changes reverse heel and release
  ownership without inventing unrelated rotations.
- Replaced the centered 80% length collapse with surface-projected depth
  foreshortening, retaining force while using pressure and width to communicate
  travel into or out of the screen.
- Expanded the shared renderer to eighty bounded candidates while reducing the
  count and width of broad parents; medium and fine families now supply stroke
  density without fusing into opaque character-blocking slabs.
- Reworked broad-stroke pressure, width drift, terminal comb breakup, and
  stroke-local bristle channels for less rectangular line material.
- Added centered front/rear, Spread, subject-readability, and deterministic
  PunchTester regression coverage.

# Impaction Impact Frames 0.3.21

- Reworked linear and centered emitters into stable hero, support, and fine
  stroke families whose orientation follows captured velocity and only bends
  when measured acceleration supports the turn.
- Made Spread an endpoint convergence/divergence control: zero tightens each
  family, the 0.5 default stays parallel, and one fans the family outward.
- Separated undirected line orientation from Cast Behind trail polarity and
  propagated that polarity through pressure, depth taper, motion blur, and
  chromatic aberration.
- Reduced character blocking with tone-aware hero deposition, broken contour
  gaps, and deeper-shadow cross-hatching; added selected medium hatch gestures
  while limiting unsupported rotations.
- Reduced centered-emitter loop and ray-march work while retaining deterministic
  stroke identities and warm cached previews.

# Impaction Impact Frames 0.3.20

- Added restrained, broken secondary construction traces near hatching
  outlines to communicate adjacent depth planes without forming a solid band.
- Added correlated angular drift to outline deposition for subtler hand-drawn
  imperfections while retaining the Thickness-driven footprint.

# Impaction Impact Frames 0.3.19

- Reduced the deposited hatching/construction-outline footprint and connected
  its radius, displacement, and opacity to the Thickness control. At zero
  Thickness the outline is now completely absent.

# Impaction Impact Frames 0.3.18

- Stabilized front/rear 3D wind projection by separating undirected stroke
  orientation from directed trail polarity, preventing rear-pin angle flips.
- Restored subject-blocked silhouette emission for centered 3D pins, with
  front/back pressure-length ownership instead of an imploding starburst.
- Quantized pin and angle drawing states so hatching redraws as discrete
  pencil actions while live preview and applied output retain identical IDs.
- Replaced per-family motion-arc handedness with one projected action arc, so
  keyed trails remain behind the moving subject and share a coherent turn.
- Added an irregular construction-outline pass over silhouettes and narrow
  bevel/part seams, masking artificial white channels with deposited sketch ink.

# Impaction Impact Frames 0.3.17

- Replaced wind-normal curvature with a single velocity/acceleration trajectory shared by each loaded brush bundle, so keyed punch arcs remain visible and keep their handedness after moving the 3D wind pin.
- Kept broad stroke bodies loaded through the exterior overshoot, increased medium/hero coverage, and removed the motion-time width reduction that made fast strokes turn into hairlines outside the subject.
- Unified 3D motion blur and chromatic-aberration polarity with the pink wind source, and automatically rebuilds legacy temporal captures that lack acceleration data.
- Kept semantic stroke IDs stable while dragging the 3D pin or applying a live preview, so Update no longer births a different set of marks; removed Blender's progress API from Update to prevent the `0.00` cursor.
- Replaced the per-pixel hatch wind warp with finite, face-anchored pencil actions. Front/back emitter directions now retain a stable drafting tangent instead of collapsing the head into nested black-hole rings, while adjacent face samples bridge narrow bevel seams.

# Impaction Impact Frames 0.3.16

- Replace independent random ribbon bows with one evaluated local trajectory:
  rasterized velocity controls direction/stretch and rasterized acceleration
  controls the signed quadratic arc for each moving mesh region.
- Raise the loaded subject family count from 40–56 to 60–76 while retaining
  the existing hierarchy of broad swipes, support strokes and filaments.
- Preserve broad brush width through 92% of travel so ink remains loaded after
  leaving the silhouette and releases only in the final bristle region.
- Add direction-aware rough contour loading and wider bilateral/diagonal seam
  bridging for beveled limb corners without filling true outer silhouettes.

# Impaction Impact Frames 0.3.15

- Make hatch packets follow the same projected 3D wind source as the primary
  ink families without reintroducing per-pixel rubber-contour distortion.
- Bridge narrow bilateral bevel/material seams with graphite ownership while
  preserving true outer silhouettes.
- Gate broad stroke curvature to evaluated subject motion and add central
  second-difference acceleration from frame -1/current/frame +1 captures.
- Extend and vary windward brush heels so intensity does not expose a shared
  hard cutoff at the subject boundary.

# Impaction Impact Frames 0.3.14

- Rebuilt the pink 3D direction control as a camera-space directional
  hemisphere source, eliminating pin-centered point-attractor collapse and
  projecting parallel window-like rays over captured face normals.
- Added the direction pin, X/Y, Cast Behind, Thickness, and Band controls to
  None mode; None now reselects deterministic hatch families as direction
  changes and honors zero-to-full hatch thickness.
- Replaced binary/max hatch ownership extension with pressure-integrated,
  curved per-gesture transport and soft endpoint windows, allowing staggered
  seam overshoot without moving one shared digital cutoff farther outward.
- Moved 3D hero launch heels toward the directed subject boundary, added a
  second unique miniature fill trace, perspective-foreshortened front/back
  casts, and staggered companion-brush starts.
- Added a constant-cost three-scale radial hairline field around the existing
  broad family renderer so Radial fills the complete frame with fine, medium,
  and loaded converging marks.
- Made extension unregister tolerate a Blender-invalidated native draw handle,
  preventing the null-handler crash during reload and background shutdown.

# Impaction Impact Frames 0.3.13

- Renamed the visible 3D `Halo Spread` control to `Spread` while preserving
  its serialized property identifier for existing files and copied settings.
- Added per-fragment camera depth to the cached motion surface. The 3D source
  now constructs a perspective source ray, projects it onto each captured face,
  and applies near/far foreshortening to hero length and width.
- Added a bounded perspective arc to 3D hero families so long marks converge
  or open with depth instead of remaining rigid screen-space bars.
- Expanded per-gesture hatch ownership transport with a deterministic long-tail
  class. Selected pencil actions now cross wider face/object gaps with tapered,
  pressure-varying overshoot instead of sharing the captured border cutoff.

# Impaction Impact Frames 0.3.12

- Removed the experimental connected-scribble stroke family completely.
- Added a 0–1 Halo Spread control whose 0.5 default projects the 3D source over
  captured surface normals. Front and Cast Behind now use the same aerodynamic
  solver; rear casting changes only the selected hemisphere.
- Mapped deterministic hero bundles into the projected subject bounds and
  added unique short fill filaments, restoring dense broad/medium/fine coverage
  without a pin-centered starburst or unrelated full-frame crossings.
- Rasterized evaluated per-vertex t-1/t+1 velocity as a cached GPU field.
  Animated limbs now bend and lengthen nearby trails from local deformation,
  independently of the optional Motion Blur post effect.
- Rebuilt Radial as dense frame-edge-to-focus families with a shared compact
  focal pocket, irregular grouped spacing, and the same exact-magenta dragger.
- Changed hatch actions to finite locally oriented pencil deposits. Each face
  samples one restrained slope, lifts, and redraws; no continuous lane is bent
  through a corner or light-source singularity.
- Kept background accent wind trails out of this release for the planned
  dedicated background pass.

# Impaction Impact Frames 0.3.11

- Reinterpreted the pink 3D control as a spatial wind source. Each main or
  hatch gesture samples one source-to-face direction, projects it over the
  captured surface normal, and holds that direction for the complete stroke.
- Added a dedicated 3D `Cast Behind` option. Centering the source now produces
  a converging/diverging halo field instead of falling back to the 2D Angle.
- Made the direction pin exact RGB magenta, compacted the Direction UI row,
  and hardened absent legacy Composition values to the Linear default.
- Reduced compatibility-path family count and clustered passes around shared
  hand-action anchors, removing the unrelated diagonal crossings that made
  broad strokes look chaotic.
- Direction/source edits now choose new deterministic stroke arrangements on
  tighter spatial/angular buckets rather than visibly rotating one drawing.
- Replaced long contour worms with separate, longer pencil actions, explicit
  pen lifts, restrained line wobble, and surface-aligned face slopes.
- Added a minority compact scribble family built from overlapping rounded,
  asymmetrically timed reversal commands. It shades short regions without a
  geometric zigzag carrier and retains dry-brush pressure variation.
- Staggered main/hatch pressure tails and retained transported ownership so
  light, silhouette, and face transitions no longer share a flat cutoff.
- Routed Motion Blur and Chromatic Aberration through the 3D point-source
  field while preserving the original 2D Angle and Radial modes.

# Impaction Impact Frames 0.3.10

## 3D Aerodynamic Direction and Longer Tonal Gestures

- Made new Impact Frames explicitly start in Linear composition with a 3D
  camera-space direction source and a pink hemispherical viewport dragger.
- Added a 2D direction option that restores the wrapped manual Angle control;
  existing saved frames migrate to 2D so their prior drawing is preserved.
- Projected one shared 3D direction over captured face normals at persistent
  hero-family and hatch-segment anchors, retaining subject-motion influence
  without continuously warping strokes around surface changes.
- Routed the resolved direction through canonical strokes, Motion Blur, and
  Chromatic Aberration, with deterministic three-degree redraw buckets rather
  than rigidly rotating the existing family layout.
- Added Lighting > Cast Behind to orbit the key over the rear hemisphere.
- Lengthened hatch action units, reduced surface steering, softened tonal
  transitions, restored visible Intensity deposition, and removed the final
  subject-support multiplier that clipped thick swipes at the silhouette.

# Impaction Impact Frames 0.3.9

## Transported Stroke Pressure and Face-Anchored Hatching

- Removed the subject-mask stencil that cut broad black strokes exactly on the
  character silhouette; family-specific pressure now travels past the edge
  before lifting at an unequal, brush-like distance.
- Removed per-pixel hatch normal steering and its mesh-face lift gate, which
  created rubber contours and visible seams between faces.
- Added one projected-normal sample per finite hatch gesture. Each trace keeps
  that straight, angle-limited surface slope through its pressure overshoot,
  while the next face begins a separately oriented trace.
- Extended forward/backward hatch ownership transport and softened its release
  so tone and mesh boundaries receive staggered imperfect graphite endings.

# Impaction Impact Frames 0.3.8

## Readable Subject Masses, Packet Hatching, and True Radial Focus

- Split hero-ribbon ownership into background framing and subject shadow
  masses, preventing broad action strokes from painting indiscriminately over
  illuminated character planes while retaining fine construction detail.
- Added family-level width hierarchy so every loaded gesture carries broad,
  medium, support, and hairline passes within the Thickness-controlled range.
- Replaced continuously bent hatch orientation with quantized form packets and
  narrow pressure lifts, making corner changes terminate and redraw rather
  than curling as one computer-generated contour.
- Added monotone irregular lane boundaries and stronger nested crosshatching
  in dark tone packets for unequal spacing and shading-like accumulation.
- Unified every radial family at one shared emitter with near-zero focal width,
  so the complete burst converges at the authored focus.

# Impaction Impact Frames 0.3.7

## Coherent Part-to-Part Shading and Pencil Phrasing

- Regularized subject surface tangents across neighboring mesh parts with an
  undirected, tangent-aligned field so one hatch gesture no longer visibly
  stops and restarts at a character seam.
- Removed the warped hatch coordinate and large analytic action bend that
  produced evenly empty bands and repeated smooth procedural curves.
- Restored family-correlated gesture length and phase while retaining small
  band-limited pencil wobble, staggered pressure release, and boundary
  transport for imperfect trace endings without disconnected line worms.
- Rebalanced graphite optical density to preserve dense shading bundles and
  negative space under maximum Bloom, with a faster measured first render.

# Impaction Impact Frames 0.3.6

## Humanized Pencil Traces and Broken Tone Seams

- Replaced ruled hatch lanes with a low-frequency warped coordinate and
  independently displaced pencil traces, producing clustered unequal gaps.
- Replaced group-dominant curve and length repetition with segmented action
  units carrying independent length, slope, bend, and asymmetric pressure.
- Added a subject-only continuation sentinel and nonlinear lane-specific shadow
  memory, allowing strokes to cross illumination borders
  by unequal distances instead of ending on a shared contour.
- Kept added sampling confined to tone transitions and empty-background early
  exits so the richer pencil geometry remains suitable for live preview.

# Impaction Impact Frames 0.3.5

## Per-Stroke Boundary Release and Opaque Viewport Input

- Replaced the shared hatch-mask cutoff with four pressure-weighted ownership
  samples per direction, using lane-specific reach and curved terminal drift.
- Added an overlay-scoped input guard so object selection, Box Select, Circle
  Select, and active selection tools cannot pass through the rendered camera
  frame while navigation and Impact light/focus pins remain usable.

# Impaction Impact Frames 0.3.4

## Surface-Wrapped Hatching, Continuous Blur, and Safe Reload

- Reused the geometry raster's former velocity channels for view-facing
  surface normals, letting subject hatching bend gently around rotated forms.
- Removed light-gradient steering from subject construction, so dragging the
  light changes cel tone without pulling linework into a focal vortex.
- Replaced seven separated blur copies with a normalized 33-sample one-sided
  shutter integral and increased the maximum directional reach.
- Made development updates single-flight and two-phase, retiring live timers,
  draw handlers, and GPU resources before overwriting extension modules.
- Preserved negative space at maximum Bloom after the denser form drawing, and
  fixed the GLSL loader so multiline `out` parameters reach the full shader.

# Impaction Impact Frames 0.3.3

## Directional Motion and Organic Hatch Terminals

- Moved Motion Blur into Effects immediately before Chromatic Aberration.
- Replaced the weak in-stroke motion deposits with a fixed seven-tap post
  exposure following the Linear angle or the Radial focus field.
- Replaced shared binary hatch clipping with lane-specific evidence falloff,
  short randomized overshoot, terminal curvature, and pressure-shaped tips.
- Kept Motion Blur out of canonical-mask capture so effect-only edits reuse
  the expensive ink and hatch render.

# Impaction Impact Frames 0.3.2

## Live Angle and Image-Ownership Follow-up

- Canonicalized angle values in the RNA setter so modal dragging displays the
  wrapped equivalent immediately instead of waiting for mouse release.
- Added deterministic 7.5-degree drafting buckets: angle changes periodically
  redraw equivalent stroke families rather than rigidly rotating one sketch.
- Reconciled every Impaction-owned image during registration/load, packing
  active frame caches and removing abandoned dirty previews from older builds.

# Impaction Impact Frames 0.3.1

## Impact Rendering and Workflow Fixes

- Started from the 0.3.0-beta compatibility/hotfix baseline.
- Removed the compatibility shader's diagonal swept-mask shelves that caused
  triangle/saw-tooth stroke edges near 45 and -124 degrees.
- Made hero intensity and thickness zero exact bypasses while keeping neutral
  subject hatching available in None mode.
- Packed every applied cache immediately into the `.blend`, eliminating dirty
  generated-image prompts and external cache-file dependencies.
- Forced packed cache re-upload after undo to prevent a restored frame from
  appearing as a black overlay until Update.
- Added cyclic angle normalization and the always-open Properties box with
  concise Copy/Paste actions.

# Impaction Impact Frames 0.3.0

## Shader Interface Hotfix

- Fixed `GPUShader.uniform_float: uniform subjectMotion not found` on compatibility-shader backends.
- The compatibility shader now actually consumes `subjectMotion` and `backgroundMotion`, preventing backend dead-uniform elimination.
- Added a narrowly scoped safe bind for optional motion push constants so backend optimization cannot abort frame creation.
- Extension version intentionally remains 0.3.0.

- Added automatic impact-shader compatibility fallback for Blender/GPU-driver compiler differences.
- Reduced primary impact-shader instruction pressure and candidate count without changing the UI.
- Removed dynamic vector indexing from the primary linear family path for cross-backend reliability.
- Kept None, Linear, Radial, packed blend caches, undo recovery, hatching, lighting, and Motion Blur behavior.
- Compatibility shader retains the known-working 0.2.3 drawing core with 0.3 mode semantics and motion gating.
# 0.3.69

- Radial Cast Behind now preserves subject ink and hatching over the rear burst, while regular radial keeps its foreground channel.
- Radial rays feather into the protected white center and use clustered graphite/brush pressure instead of a uniform polar cage.
- Spiral is now presented and evaluated as Twirl: it bends paths without changing radial pigment intensity.
- Radial intensity now reaches a true zero-line state and scales pigment continuously above zero.
- Star End now controls the terminal spikes of the max-thickness spiky/oval form.
- Shape sliders display two decimal places.
