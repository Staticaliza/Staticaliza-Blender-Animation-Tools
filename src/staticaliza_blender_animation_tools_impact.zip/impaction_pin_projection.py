"""Keep camera-relative pin controls aligned with their captured world bearing."""
from copy import deepcopy
import numpy as np


def _basis(projection):
    matrix = np.asarray(projection, dtype=float)
    if matrix.shape != (4, 4):
        return None
    right = matrix[0, :3]
    right = right / max(np.linalg.norm(right), 1e-12)
    up = matrix[1, :3] - right * np.dot(matrix[1, :3], right)
    up = up / max(np.linalg.norm(up), 1e-12)
    return np.stack((right, up, np.cross(right, up)))


def reproject_pin(point, behind, old_basis, new_basis):
    xy = (np.asarray(point, dtype=float) - .5) * 2.
    radius = float(np.linalg.norm(xy))
    xy = xy / max(1., radius)
    z = np.sqrt(max(0., 1. - np.dot(xy, xy))) * (-1. if behind else 1.)
    orbit = new_basis @ (old_basis.T @ np.array((*xy, z)))
    # Keep the authored Cast Behind switch. If the world bearing crosses its
    # allowed hemisphere, the rim is the closest representable direction.
    if orbit[2] * (-1. if behind else 1.) < 0:
        length = float(np.linalg.norm(orbit[:2]))
        orbit[:2] = orbit[:2] / length if length > 1e-12 else (1., 0.)
    return tuple(.5 + orbit[:2] * max(1., radius) * .5)


def _direction_hash(values):
    x, y = (int(round((float(v) - .5) * 180.)) for v in values['direction_focus'])
    spread = int(round(float(values.get('halo_spread', .5)) * 100.))
    return (x * 73856093 ^ y * 19349663 ^ spread * 83492791) & 0xFFFF


def reproject_style(values, old_projection, new_projection):
    result = deepcopy(values)
    old_basis, new_basis = _basis(old_projection), _basis(new_projection)
    if old_basis is None or new_basis is None or np.allclose(old_basis, new_basis, atol=1e-8, rtol=0):
        return result
    old_seed = (_direction_hash(result) + int(result.get('direction_seed_offset', 0))) & 0xFFFF if 'direction_focus' in result else None
    for prefix in ('direction', 'light', 'background'):
        name = prefix + '_focus'
        if name not in result:
            continue
        result[name] = reproject_pin(result[name], bool(result.get(prefix + '_cast_behind', False)), old_basis, new_basis)
    if old_seed is not None:
        # Reprojection changes coordinates, not the authored random drawing.
        result['direction_seed_offset'] = (old_seed - _direction_hash(result)) & 0xFFFF
    return result
