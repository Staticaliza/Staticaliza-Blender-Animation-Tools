"""Rig-local drawing styles, shared frame controls, and depth-ordered layers.

The camera frame remains the editing projection. Rig UUID profiles are retained
when objects disappear so Blender undo can restore the exact drawing state.
"""
import json
import uuid
import zlib
from copy import deepcopy
from types import SimpleNamespace
import bpy
import numpy as np
from .impaction_discovery import recognized_rigs, camera_bone_binding, resolve_sources

_ENUM_ITEMS = []
_ENUM_HISTORY = globals().get("_ENUM_HISTORY", {})
_switching = False
SHARED = {'glitch_size', 'background', 'invert', 'contrast', 'grayscale', 'bloom', 'bloom_invert',
          'motion_blur', 'chromatic_aberration', 'grain', 'grain_overlay_intensity',
          'halftone', 'halftone_size', 'pixelate', 'pixelate_size', 'aberration_gradient'}

def is_shared(name):
    return name in SHARED or name.startswith(('background_', 'aberration_'))

def rig_id(rig, create=False):
    value = rig.get('_impaction_uuid', '')
    if not value and create:
        value = uuid.uuid4().hex
        rig['_impaction_uuid'] = value
    return value or ('legacy:' + rig.name_full)

def rigs(scene):
    return [(collection.name[5:].strip(), armature, parts)
            for collection, armature, parts in recognized_rigs(scene)]

def enum_items(camera, context):
    global _ENUM_ITEMS
    scene = context.scene if context else bpy.context.scene
    bound = camera_bone_binding(camera)[0]
    entries = sorted(rigs(scene), key=lambda entry: (entry[1] != bound, entry[0]))
    _ENUM_ITEMS = [(rig_id(rig), name, 'Edit this rig\'s linework, lighting and shapes',
                    zlib.crc32(rig_id(rig).encode()) & 0x7fffffff)
                   for name, rig, _parts in entries]
    items = _ENUM_ITEMS or [('NONE', 'N/A', '', 0)]
    token = tuple(items)
    return _ENUM_HISTORY.setdefault(token, items)

def enum_get(camera):
    entries = enum_items(camera, bpy.context)
    current = camera.get('_impact_selected_rig', '')
    return next((item[3] for item in entries if item[0] == current), entries[0][3])

def local_values(record):
    from .impaction_operators import _record_values
    return {key: value for key, value in _record_values(record).items() if not is_shared(key)}

def ensure(record, camera, scene):
    """Initialize only on an authorized edit/render, never from panel drawing."""
    if not hasattr(record, 'as_pointer'):
        return
    entries = rigs(scene)
    # A multi-rig camera belongs to the scene, even if originally imported
    # inside one rig collection. Utils preserves objects with external links.
    if len(entries) > 1 and scene.collection.objects.get(camera.name) is None:
        scene.collection.objects.link(camera)
    seen = set()
    for _name, rig, _parts in sorted(entries, key=lambda entry: int(entry[1].session_uid)):
        key = rig_id(rig, True)
        if key in seen:
            rig['_impaction_uuid'] = uuid.uuid4().hex
        seen.add(rig_id(rig))
    profiles = json.loads(record.get('_rig_profiles', '{}'))
    bound = camera_bone_binding(camera)[0]
    active = record.get('_rig_edit', '')
    valid = {rig_id(rig) for _name, rig, _parts in entries}
    if not active:
        active = rig_id(bound) if bound else next(iter(valid), '')
        record['_rig_edit'] = active
    values = local_values(record)
    if not record.get('_rig_capture_owners', ''):
        record['_rig_capture_owners'] = json.dumps(capture_owners(bpy.context))
    if not record.get('_rig_reference', ''):
        record['_rig_reference'] = active
    if active in valid:
        profiles[active] = values
    for _name, rig, _parts in entries:
        key = rig_id(rig)
        if key not in profiles:
            profiles[key] = deepcopy(values)
            profiles[key]['shapes'] = []
    encoded = json.dumps(profiles, sort_keys=True)
    if record.get('_rig_profiles', '') != encoded:
        record['_rig_profiles'] = encoded
        from .impaction_renderer import invalidate_record_signature
        invalidate_record_signature(record)
    if not camera.get('_impact_selected_rig', '') and active in valid:
        camera['_impact_selected_rig'] = active

def sync_edit_record(record, camera, scene):
    """Align a frame's editable RNA with the camera's selected rig."""
    selected=camera.get('_impact_selected_rig','')
    if not selected or not record.get('_rig_profiles',''):
        return False
    if record.get('_rig_edit','')==selected:
        return False
    profiles=json.loads(record.get('_rig_profiles','{}'))
    if selected not in profiles:
        return False
    from . import impaction_runtime as runtime
    from .impaction_operators import _apply_values
    previous=runtime._propagating
    runtime._propagating=True
    try:
        # Save the outgoing projection before loading this frame's target rig.
        active=record.get('_rig_edit','')
        if active in profiles: profiles[active]=local_values(record)
        _apply_values(record,profiles[selected])
        record['_rig_edit']=selected
        record['_rig_profiles']=json.dumps(profiles,sort_keys=True)
        from .impaction_renderer import invalidate_record_signature
        invalidate_record_signature(record)
    finally:
        runtime._propagating=previous
    return True


def enum_set(camera, number):
    global _switching
    if _switching:
        return
    items = enum_items(camera, bpy.context)
    selected = next((item[0] for item in items if item[3] == number), None)
    if not selected or selected == 'NONE':
        return
    if selected == camera.get('_impact_selected_rig', ''):
        return
    from . import impaction_runtime as runtime
    from .impaction_operators import _apply_values
    # Resolve legacy enum IDs before ensure assigns persistent UUIDs.
    chosen = next((rig for _name, rig, _parts in rigs(bpy.context.scene)
                   if rig_id(rig) == selected), None)
    if chosen is None:
        return
    _switching = True
    previous = runtime._propagating
    runtime._propagating = True
    try:
        for record in camera.impaction_frames:
            ensure(record, camera, bpy.context.scene)
            selected = rig_id(chosen, True)
            values = json.loads(record.get('_rig_profiles', '{}')).get(selected)
            if values is not None:
                _apply_values(record, {name: value for name, value in values.items()
                                       if not is_shared(name)})
                record['_rig_edit'] = selected
                from .impaction_renderer import invalidate_record_signature
                invalidate_record_signature(record)
        camera['_impact_selected_rig'] = rig_id(chosen, True)
    finally:
        runtime._propagating = previous
        _switching = False
    runtime.invalidate_selection_cache(camera) if hasattr(runtime, 'invalidate_selection_cache') else None
    current = runtime.held_frame_record(bpy.context.scene, camera, bpy.context.scene.frame_current)
    if current is not None:
        from .impaction_renderer import display_matches_record
        if not display_matches_record(camera, current, bpy.context.scene):
            runtime.schedule_live_render(camera, current, input_change=False)
    runtime.request_redraw(camera)

def signature(record, scene):
    if bool(getattr(record, "_background_subject_only", False)):
        # A local layer depends on its own capture/style, not other rig IDs.
        return ()
    return (record.get('_rig_profiles', ''), record.get('_rig_edit', ''),
            record.get('_rig_capture_owners', ''))


def canonical_visual_record(record):
    """Hash the complete composition, independent of the editing projection."""
    encoded = record.get('_rig_profiles', '')
    if not encoded or bool(getattr(record, '_background_subject_only', False)):
        return record
    profiles = json.loads(encoded)
    active = record.get('_rig_edit', '')
    if active in profiles:
        profiles[active] = local_values(record)
    reference = record.get('_rig_reference', '') or min(profiles, default='')
    result = apply_snapshot(record, profiles.get(reference, {}))
    original_get = record.get
    canonical = {'_rig_profiles': json.dumps(profiles, sort_keys=True),
                 '_rig_edit': reference}
    result.get = lambda key, default=None: canonical.get(key, original_get(key, default))
    return result

def apply_snapshot(snapshot, values):
    from .impaction_renderer import _preview_record_snapshot
    result = _preview_record_snapshot(snapshot)
    for name, value in values.items():
        # Older saved profiles may contain formerly local effect settings.
        # The frame remains the authority even when switching those profiles.
        if is_shared(name):
            continue
        if name == 'shapes':
            shapes = []
            for data in value:
                data = deepcopy(data)
                data['points'] = tuple(SimpleNamespace(position=point[0], pressure=point[1], break_before=point[2] if len(point)>2 else False) for point in data.get('points', ()))
                shapes.append(SimpleNamespace(**data))
            result.shapes = tuple(shapes)
        else:
            setattr(result, name, deepcopy(value))
    for prefix, vector in (("direction", result.direction_focus), ("light", result.light_focus), ("background", result.background_focus)):
        setattr(result, prefix+"_x", int(round((float(vector[0])-.5)*180.)))
        setattr(result, prefix+"_y", int(round((float(vector[1])-.5)*180.)))
    return result

def split_geometry(geometry, owners):
    """Select vertices and triangles without recapturing evaluated meshes."""
    from .impaction_capture import CaptureGeometry
    from dataclasses import fields
    ids = np.asarray(geometry.owner_ids)
    keep = np.isin(ids, list(owners))
    index = np.flatnonzero(keep)
    remap = np.full(len(ids), -1, np.int32); remap[index] = np.arange(len(index))
    triangles = np.asarray(geometry.triangles, dtype=np.int32).reshape(-1, 3)
    face_keep = np.all(keep[triangles], axis=1)
    values = {}
    for field in fields(CaptureGeometry):
        name = field.name; value = getattr(geometry, name)
        if name == 'triangles':
            values[name] = remap[triangles[face_keep]].tolist()
        elif name == 'corner_normals' and len(value):
            values[name] = np.asarray(value).reshape(-1, 3, 3)[face_keep].reshape(-1, 3).tolist()
        elif isinstance(value, (list, tuple, np.ndarray)) and len(value) == len(ids) and name != 'view_projection':
            values[name] = np.asarray(value)[index].tolist()
        elif name == 'motion_history':
            values[name] = {key: item for key, item in value.items() if int(key) in owners}
        else:
            values[name] = value
    result = CaptureGeometry(**values)
    if hasattr(geometry, "owner_depth_decode"):
        result.owner_depth_decode = geometry.owner_depth_decode
    return result

def plans(context, camera, record, capture):
    from copy import copy
    entries = rigs(context.scene)
    if len(entries) < 2 and not record.get('_rig_profiles', ''):
        return []
    saved_owners = json.loads(record.get('_rig_capture_owners', '{}'))
    owner_map = {}
    if not saved_owners:
        subjects, _ = resolve_sources(context)
        from .impaction_capture import _mesh_rig_key
        for i, obj in enumerate(sorted(subjects, key=lambda obj: obj.name_full)):
            owner_map.setdefault(_mesh_rig_key(obj), []).append(i + 1)
    profiles = json.loads(record.get('_rig_profiles', '{}'))
    active = record.get('_rig_edit', '')
    result = []
    captured_entries = [(key, owners) for key, owners in saved_owners.items()] if saved_owners else [(rig_id(rig), owner_map.get(rig.name_full, ())) for _name, rig, _parts in entries]
    for key, owners in captured_entries:
        if not owners:
            continue
        values = profiles.get(key, {})
        local = apply_snapshot(record, values) if key != active else apply_snapshot(record, {})
        if key != active and not values:
            local.shapes = ()
        local.salt = (int(record.salt) * 131 + (zlib.crc32(key.encode()) & 0x7fffffff)) % 1000000000 + 1
        if getattr(record, '_draft_linear', False):
            local._draft_linear = int(local.salt) in getattr(record, '_draft_linear_salts', ())
        # Shared grading runs after layer assembly. Directional optics run
        # inside each rig layer so their sampling cannot borrow another rig.
        local.get = {}.get
        for field in ('bloom','contrast','grayscale','pixelate','grain','grain_overlay_intensity'):
            setattr(local,field,0.0)
        local.invert=False
        # Paper draws the shared background once. Each rig adds only marks
        # passing in front of its surface, using the same family identity.
        local._background_subject_only = True
        local._background_salt = int(record.salt)
        sliced = copy(capture)
        # Captures are immutable. Retain each slice and its expensive path,
        # BVH and ribbon caches for every subsequent style edit.
        slices = getattr(capture.subject, '_rig_slices', None)
        if slices is None:
            slices = capture.subject._rig_slices = {}
        slice_key = (key, tuple(owners))
        if slice_key not in slices:
            slices[slice_key] = split_geometry(capture.subject, owners)
        sliced.subject = slices[slice_key]
        sliced.subject._linear_collision_context = capture.subject
        sliced.subject._linear_drawing_context = sliced.subject
        from . import impaction_renderer as renderer
        if not hasattr(sliced.subject, '_linearized_owner_geometry'):
            # Normalize depth across all rigs before slicing, never per rig.
            shared_depth = renderer._linearized_depth_geometry(capture.subject)
            sliced.subject._linearized_owner_geometry = split_geometry(shared_depth, owners)
        sliced._impaction_background_affine = renderer._background_affine_field(capture)
        sliced._background_bounds = renderer._subject_bounds(capture)
        sliced._rig_cache = key
        if not len(sliced.subject.positions):
            continue
        depth = float(np.median(np.asarray(sliced.subject.positions)[:, 2]))
        result.append((depth, local, sliced))
    return sorted(result, key=lambda item: item[0], reverse=True)

def composite_layers(renderer, base, mask, shape, layers, width, height, paper, front_rig=0):
    """Composite each rig's Back-shapes/subject/Front-shapes as one depth layer."""
    import gpu
    shader = renderer._shader('rig_merge', 'fullscreen.vert', 'rig_merge.frag')
    resources = []
    current_color, current_mask, current_shape = base, mask, shape
    for color_surface, mask_texture, shape_surface in layers:
        outputs = [renderer._offscreen(width, height, high_precision=True) for _ in range(3)]
        try:
            for output_mode, target in enumerate(outputs):
                with target.bind():
                    for name, texture in [('backColor', current_color.texture_color),
                                          ('frontColor', color_surface.texture_color),
                                          ('backMask', current_mask), ('frontMask', mask_texture.texture_color),
                                          ('backShape', current_shape),
                                          ('frontShape', shape_surface.texture_color if shape_surface else renderer._empty_texture())]:
                        shader.uniform_sampler(name, texture)
                    shader.uniform_float('paper', paper)
                    shader.uniform_int('outputMode', output_mode)
                    shader.uniform_int('frontRig', front_rig)
                    gpu.state.blend_set('NONE')
                    renderer._fullscreen_quad(shader).draw(shader)
        except Exception:
            for target in outputs:target.free()
            raise
        # Only the preceding merge is sampled by this draw. Recycle completed
        # intermediate triplets now instead of retaining every family/rig
        # until the entire frame finishes (large allocation stalls at 1080p).
        for previous in resources:
            previous.free()
        resources = outputs
        current_color = outputs[0]
        current_mask = outputs[1].texture_color
        current_shape = outputs[2].texture_color
    return current_color, (resources[-2] if resources else None), current_shape, resources

def capture_owners(context):
    from .impaction_capture import _mesh_rig_key
    subjects, _ = resolve_sources(context)
    by_name = {rig.name_full: rig_id(rig, True) for _name, rig, _parts in rigs(context.scene)}
    mapping = {}
    for index, obj in enumerate(sorted(subjects, key=lambda obj: obj.name_full)):
        name = _mesh_rig_key(obj)
        mapping.setdefault(by_name.get(name, name), []).append(index + 1)
    return mapping

_scene_membership = {}

def scene_changed(scene):
    """Membership edits invalidate display, without destroying authored captures."""
    entries = rigs(scene)
    token = tuple(sorted((rig_id(rig), rig.name_full) for _name, rig, _parts in entries))
    previous = _scene_membership.get(scene.name_full)
    _scene_membership[scene.name_full] = token
    if previous is None or previous == token:
        return
    from . import impaction_runtime as runtime
    from .impaction_renderer import invalidate_record_signature
    for camera in scene.objects:
        if camera.type != 'CAMERA' or not camera.impaction_frames:
            continue
        if not any(record.get('_rig_profiles', '') for record in camera.impaction_frames):
            continue
        for record in camera.impaction_frames:
            invalidate_record_signature(record)
        current = runtime.held_frame_record(scene, camera, scene.frame_current)
        if current:
            runtime.schedule_live_render(camera, current, input_change=True, recapture=False)
        valid = {rig_id(rig) for _name, rig, _parts in entries}
        if entries and camera.get('_impact_selected_rig', '') not in valid:
            camera_name, scene_name = camera.name_full, scene.name_full
            def select_survivor(camera_name=camera_name, scene_name=scene_name):
                cam = bpy.data.objects.get(camera_name)
                if cam is not None and bpy.context.scene.name_full == scene_name:
                    choices = enum_items(cam, bpy.context)
                    if choices and choices[0][0] != 'NONE':enum_set(cam, choices[0][3])
                return None
            bpy.app.timers.register(select_survivor, first_interval=.05)
        runtime.request_redraw(camera)

def clone_profiles(source, target):
    for name in ('_rig_profiles', '_rig_edit', '_rig_reference', '_rig_capture_owners'):
        if source.get(name, ''):
            target[name] = source[name]

def copy_texture(renderer, texture, width, height):
    import gpu
    target = renderer._offscreen(width, height, high_precision=True)
    shader = renderer._shader('rig_merge', 'fullscreen.vert', 'rig_merge.frag')
    with target.bind():
        for name in ('backColor','frontColor','backMask','frontMask','backShape','frontShape'):
            shader.uniform_sampler(name, texture)
        shader.uniform_float('paper',(0,0,0,1));shader.uniform_int('outputMode',3)
        shader.uniform_int('frontRig',0)
        gpu.state.blend_set('NONE');renderer._fullscreen_quad(shader).draw(shader)
    return target
