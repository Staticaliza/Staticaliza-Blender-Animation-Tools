"""In-editor, frame-at-a-time export with a locked Impact panel."""
from pathlib import Path
import os
import bpy

_jobs = []


def export_status():
    return _jobs[0].status() if _jobs else None


class ExportJob:
    def __init__(self, context, camera, directory):
        from . import impaction_runtime as runtime
        if _jobs:
            raise RuntimeError("An Impact export is already running")
        self.scene = context.scene
        self.camera_name = camera.name_full
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.records = tuple((int(r.frame), int(r.salt)) for r in sorted(camera.impaction_frames, key=lambda r:r.frame))
        self.total = len(self.records)
        self.done = 0
        self.error = None
        self.closed = False
        self.was_suspended = runtime.live_render_suspended()
        runtime.cancel_all_live_renders()
        runtime.suspend_live_render(True)
        _jobs.append(self)
        runtime.request_redraw()

    def status(self):
        return dict(state="error" if self.error else "complete" if self.done == self.total else "running",
                    done=self.done, total=self.total, error=self.error)

    def step(self, context):
        """Called by the editor timer; GPU and bpy remain on the main thread."""
        from . import impaction_renderer as renderer
        if self.closed or self.error or self.done >= self.total:
            return self.status()
        frame, salt = self.records[self.done]
        original_frame, original_subframe = self.scene.frame_current, self.scene.frame_subframe
        original_format = self.scene.render.image_settings.file_format
        original_exposure = renderer._exposure_frame_override
        temporary = self.directory / f".{frame}.{os.getpid()}.png"
        try:
            if context.scene != self.scene:
                raise RuntimeError("The export scene changed; export stopped")
            camera = bpy.data.objects.get(self.camera_name)
            record = next((r for r in camera.impaction_frames if int(r.salt)==salt), None) if camera else None
            if record is None:
                raise RuntimeError(f"Impact frame {frame} was removed")
            renderer._exposure_frame_override = frame
            if not renderer.has_cached_capture(camera, record):
                self.scene.frame_set(frame)
            image = renderer.cached_image(record) if renderer.cache_matches_record(record, self.scene) else None
            if image is None:
                # Final quality is unconditional; no preview tier or intermediate packing.
                image = renderer.render_record(context, camera, record, preview=False, pack_result=False)
            self.scene.render.image_settings.file_format = 'PNG'
            image.save_render(str(temporary), scene=self.scene)
            os.replace(temporary, self.directory / f"{frame}.png")
            self.done += 1
        except Exception as error:
            self.error = str(error)
        finally:
            temporary.unlink(missing_ok=True)
            self.scene.render.image_settings.file_format = original_format
            renderer._exposure_frame_override = original_exposure
            if self.scene.frame_current != original_frame or self.scene.frame_subframe != original_subframe:
                self.scene.frame_set(original_frame, subframe=original_subframe)
        return self.status()

    def close(self):
        if self.closed:
            return
        self.closed = True
        if self in _jobs:
            _jobs.remove(self)
        from . import impaction_runtime as runtime
        runtime.suspend_live_render(self.was_suspended)
        runtime.request_redraw()


def cancel_all_exports():
    for job in tuple(_jobs):
        job.close()
