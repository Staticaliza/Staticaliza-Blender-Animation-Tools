import time

import bpy
from bpy.types import Panel, UIList

from .impaction_discovery import camera_bone_binding, viewed_camera
from .impaction_constants import ADDON_BUILD_DISPLAY, ADDON_VERSION_TEXT
from .impaction_gradient import (
    MAX_ABERRATION_COLORS, aberration_color_elements, ensure_aberration_ramp,
)
from .impaction_properties import shape_selection_indices, shape_selection_type
from .impaction_runtime import held_frame_record, selected_records


_EXTENSION_UPDATE_GUARD_KEY = "__staticaliza_utils_extension_update_guard"


def _extension_update_active():
    """Read the cross-extension update guard without depending on Utils."""
    try:
        namespace = bpy.app.driver_namespace
        value = namespace.get(_EXTENSION_UPDATE_GUARD_KEY)
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            if time.perf_counter() >= float(value):
                namespace.pop(_EXTENSION_UPDATE_GUARD_KEY, None)
                return False
        return bool(value)
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        return False


def _prop(layout, record, _records, property_name, text):
    layout.prop(record, property_name, text=text)


def _selection_hint(layout, text):
    hint = layout.row(align=True)
    hint.active = False
    hint.label(text=text)


def _section(layout, _record, _property_name, label, icon):
    box = layout.box()
    box.label(text=label, icon=icon)
    return box


def _draw_aberration_colors(box, record):
    spectrum = box.split(factor=0.42, align=True)
    spectrum.label(text="Color")
    spectrum.prop(record, "aberration_preset", text="")
    box.prop(record, "aberration_blur_smoothing", text="Blur Smoothing")
    if record.aberration_preset != "CUSTOM":
        return
    ensure_aberration_ramp(record)
    elements = aberration_color_elements(record)
    for index, element in enumerate(elements):
        custom_color = box.row(align=True)
        custom_color.prop(element, "color", text="")
        remove = custom_color.row(align=True)
        remove.enabled = len(elements) > 1
        operator = remove.operator(
            "impaction.remove_aberration_color", text="", icon="TRASH",
        )
        operator.camera_name = record.id_data.name
        operator.record_salt = record.salt
        operator.color_index = index
    add = box.row(align=True)
    add.enabled = len(elements) < MAX_ABERRATION_COLORS
    operator = add.operator(
        "impaction.add_aberration_color", text="Add Color", icon="ADD",
    )
    operator.camera_name = record.id_data.name
    operator.record_salt = record.salt


class IMPACTION_UL_shapes(UIList):
    """Compact frame-local shape list; details live below the selection."""

    def draw_item(self, _context, layout, data, item, _icon, _active_data,
                  _active_propname, index):
        icon = "SOLO_ON" if item.shape_type == "STAR" else "GREASEPENCIL"
        selected = index in shape_selection_indices(data)
        operator = layout.operator(
            "impaction.select_shape", text=item.name, icon=icon,
            depress=selected,
        )
        operator.shape_index = index


def _draw_shapes(box, record):
    row = box.row()
    row.template_list(
        "IMPACTION_UL_shapes", "", record, "shapes", record,
        "active_shape_index", rows=2,
    )
    tools = row.column(align=True)
    add = tools.operator("impaction.add_shape", text="", icon="ADD")
    add.shape_type = "STAR"
    tools.operator("impaction.remove_shape", text="", icon="REMOVE")
    index = int(record.active_shape_index)
    if shape_selection_indices(record) and 0 <= index < len(record.shapes):
        up = tools.row(align=True)
        up.enabled = index > 0
        up.operator("impaction.move_shape", text="", icon="TRIA_UP").direction = -1
        down = tools.row(align=True)
        down.enabled = index + 1 < len(record.shapes)
        down.operator("impaction.move_shape", text="", icon="TRIA_DOWN").direction = 1

    clipboard = box.row(align=True)
    copy = clipboard.row(align=True)
    selected_indices = shape_selection_indices(record)
    copy.enabled = bool(selected_indices)
    copy.operator("impaction.copy_shape", text="Copy", icon="COPYDOWN")
    clipboard.operator("impaction.paste_shape", text="Paste", icon="PASTEDOWN")

    index = int(record.active_shape_index)
    if not selected_indices or not 0 <= index < len(record.shapes):
        return
    if shape_selection_type(record) is None:
        _selection_hint(
            box, "Mixed Star/Doodle selection; edit one shape type at a time.",
        )
        return
    if len(selected_indices) > 1:
        _selection_hint(
            box, f"Editing {len(selected_indices)} selected shapes.",
        )
    shape = record.shapes[index]
    box.prop(shape, "shape_type", text="Shape")
    layer = box.row(align=True)
    layer.prop_enum(shape, "layer", "FRONT", text="Front")
    layer.prop_enum(shape, "layer", "BACK", text="Back")
    from .impaction_perspective import active
    editing_perspective = active(bpy.context, viewed_camera(bpy.context), record, index)
    box.operator("impaction.edit_perspective",
                 text="Apply Perspective" if editing_perspective else "Edit Perspective",
                 icon="CHECKMARK" if editing_perspective else "ORIENTATION_VIEW")
    color = box.column(align=True)
    color.label(text="Color")
    color.prop(shape, "foreground", text="")
    box.prop(shape, "effect_influence", text="Effect Influence", slider=True)
    if shape.shape_type == "STAR":
        dimensions = box.row(align=True)
        dimensions.prop(shape, "width_percent", text="X")
        dimensions.prop(shape, "height_percent", text="Y")
        # Wrapped angles are deliberately numeric, not bounded progress bars.
        # Dragging can continue through +/-180 and immediately wraps around.
        box.prop(shape, "rotation", text="Rotation")
        box.prop(shape, "thickness_percent", text="Thickness", slider=True)
        box.prop(shape, "end_width", text="End", slider=True)
        box.prop(shape, "burst_percent", text="Burst", slider=True)
        box.prop(shape, "stroke_percent", text="Stroke", slider=True)
        if shape.stroke > 0.0001:
            box.prop(shape, "stroke_color", text="Stroke Color")
        if shape.radius > 0.0001:
            box.prop(shape, "burst_amount", text="Burst Arms")
            box.prop(shape, "burst_thickness_percent",
                     text="Burst Thickness", slider=True)
            box.prop(shape, "burst_end", text="Burst End", slider=True)
    else:
        # Doodles use the same serialized, multi-frame-synchronized rotation
        # contract as Stars, with the authored shape center as their pivot.
        box.prop(shape, "rotation", text="Rotation", slider=True)
        box.prop(shape, "thickness_percent", text="Thickness", slider=True)
        paint = box.row(align=True)
        drawing = bool(getattr(
            bpy.context.scene.impaction, "shape_draw_active", False,
        ))
        active_mode = bpy.context.scene.impaction.shape_draw_mode
        if drawing:
            stop = paint.operator(
                "impaction.draw_doodle",
                text="Stop Erasing" if active_mode == "ERASE" else "Stop Drawing",
                icon="CANCEL",
            )
            stop.mode = active_mode
        else:
            draw = paint.operator(
                "impaction.draw_doodle", text="Draw", icon="GREASEPENCIL",
            )
            draw.mode = "DRAW"
            erase = paint.operator(
                "impaction.draw_doodle", text="Erase", icon="BRUSH_DATA",
            )
            erase.mode = "ERASE"


class VIEW3D_PT_impaction(Panel):
    bl_label = f"Roblox Animator Impact (v{ADDON_VERSION_TEXT}){ADDON_BUILD_DISPLAY}"
    bl_idname = "VIEW3D_PT_impaction"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Roblox Animator Impact"

    def draw(self, context):
        layout = self.layout
        if _extension_update_active():
            update_box = layout.box()
            update_box.label(text="Extension Update", icon="FILE_REFRESH")
            update_box.label(text="Updating extensions...")
            return

        from .impaction_export import export_status
        exporting = export_status()
        if exporting is not None:
            box = layout.box()
            box.label(text="Exporting Impact Frames", icon="RENDER_STILL")
            box.label(text=f"{exporting['done']} / {exporting['total']} frames")
            box.label(text="Please wait. Esc to cancel.")
            return

        scene = context.scene
        camera = viewed_camera(context)
        attached = bool(camera and (camera_bone_binding(camera)[0] or any(r.get("_rig_profiles", "") for r in camera.impaction_frames)))

        current = held_frame_record(scene, camera, scene.frame_current) if attached else None
        selected = selected_records(camera) if attached else []
        record = selected[0] if selected else (current if camera and not camera_bone_binding(camera)[0] else None)

        if camera is None:
            _selection_hint(layout, "Enter Camera View.")
        elif not attached:
            _selection_hint(layout, "Attach the viewed camera to an armature bone.")

        if attached:
            frame_box = layout.box()
            frame_box.label(text="Frame", icon="IMAGE_DATA")
            if selected or current:
                actions = frame_box.row(align=True)
                actions.operator("impaction.create_next_frame", text="Next", icon="NEXT_KEYFRAME")
                actions.operator("impaction.update_frame", text="Update", icon="FILE_REFRESH")
                actions.operator("impaction.delete_frame", text="", icon="TRASH")
            else:
                frame_box.operator("impaction.create_frame", text="Create Frame", icon="KEY_HLT")
            frame_box.prop(
                scene.impaction, "preview_opacity",
                text="Opacity", slider=True,
            )
            frame_box.prop(camera, "impaction_fps", text="FPS")
            frame_box.prop(camera, "impaction_rig", text="")
            frame_box.operator("impaction.export_frames", text="Export Frames", icon="EXPORT")

        if record:
            properties = _section(
                layout, record, "ui_properties_open", "Properties", "PROPERTIES",
            )
            clipboard = properties.row(align=True)
            clipboard.operator(
                "impaction.copy_frame", text="Copy", icon="COPYDOWN",
            )
            clipboard.operator(
                "impaction.paste_frame", text="Paste", icon="PASTEDOWN",
            )

            box = _section(
                layout, record, "ui_composition_open", "Composition", "GREASEPENCIL",
            )
            if box:
                colors = box.grid_flow(
                    row_major=True, columns=2, even_columns=True,
                    even_rows=True, align=False,
                )
                foreground = colors.column(align=True)
                foreground.label(text="Foreground")
                foreground.prop(record, "foreground", text="")
                background = colors.column(align=True)
                background.label(text="Background")
                background.prop(record, "background", text="")
                lines = box.column(align=True)
                lines.label(text="Background Lines")
                lines.prop(record, "background_line_color", text="")
                flip_row = box.row()
                flip_row.operator(
                    "impaction.flip_colors", text="Flip",
                    icon="ARROW_LEFTRIGHT",
                )
                background_modes = box.row(align=True)
                background_modes.prop_enum(
                    record, "background_mode", "NONE", text="None",
                )
                background_modes.prop_enum(
                    record, "background_mode", "2D", text="2D",
                )
                background_modes.prop_enum(
                    record, "background_mode", "3D", text="3D",
                )
                background_enabled = bool(
                    record.background_2d_enabled or
                    record.background_3d_enabled
                )
                if background_enabled:
                    background_direction = box.row(align=True)
                    background_direction.prop(record, "background_x", text="X")
                    background_direction.prop(record, "background_y", text="Y")
                    box.prop(
                        record, "background_intensity",
                        text="Background Intensity", slider=True,
                    )
                    box.prop(
                        record, "background_layer",
                        text="Background Layer", slider=True,
                    )
                    if record.background_2d_enabled:
                        box.prop(
                            record, "background_depth_2d",
                            text="Background Spread", slider=True,
                        )
                        box.prop(
                            record, "background_flip_depth_2d",
                            text="Flip Spread",
                        )
                    if record.background_3d_enabled:
                        box.prop(
                            record, "background_depth",
                            text=(
                                "3D Background Spread"
                                if record.background_2d_enabled
                                else "Background Spread"
                            ), slider=True,
                        )
                    box.prop(
                        record, "background_motion",
                        text="Background Motion", slider=True,
                    )
                modes = box.row(align=True)
                modes.prop(record, "linear_enabled", text="Linear", toggle=True)
                modes.prop(record, "radial_enabled", text="Radial", toggle=True)
                if record.radial_enabled:
                    focus = box.row(align=True)
                    focus.prop(record, "focus_x", text="X")
                    focus.prop(record, "focus_y", text="Y")
                else:
                    direction = box.row(align=True)
                    direction.prop(record, "direction_x", text="X")
                    direction.prop(record, "direction_y", text="Y")
                box.prop(
                    record, "direction_cast_behind", text="Cast Behind",
                )
                if record.linear_enabled or record.radial_enabled:
                    box.prop(record, "strength", text="Intensity", slider=True)
                box.prop(record, "line_thickness", text="Thickness", slider=True)
                if record.linear_enabled or record.radial_enabled:
                    box.prop(record, "halo_spread", text="Spread", slider=True)
                    box.prop(
                        record, "motion_curve_influence",
                        text="Motion", slider=True,
                    )
                if record.radial_enabled:
                    box.prop(
                        record, "radial_threshold",
                        text="Threshold", slider=True,
                    )
                    box.prop(
                        record, "radial_spiral",
                        text="Twirl", slider=True,
                    )
                if record.linear_enabled or record.radial_enabled:
                    box.prop(record, "band_transition", text="Band", slider=True)

            box = _section(layout, record, "ui_light_open", "Lighting", "LIGHT_SUN")
            if box:
                direction = box.row(align=True)
                direction.prop(record, "light_x", text="X")
                direction.prop(record, "light_y", text="Y")
                box.prop(record, "light_radius", text="Intensity", slider=True)
                box.prop(record, "bleed", text="Bleed", slider=True)
                box.prop(record, "light_cast_behind", text="Cast Behind")
                light_color = box.column(align=True)
                light_color.label(text="Color")
                light_color.prop(record, "light_color", text="")

            shapes = _section(
                layout, record, "ui_shapes_open", "Shapes", "CUBE",
            )
            _draw_shapes(shapes, record)

            box = _section(layout, record, "ui_effects_open", "Effects", "SHADERFX")
            if box:
                box.prop(record, "invert", text="Invert")
                box.prop(record, "contrast", text="Contrast", slider=True)
                box.prop(record, "grayscale", text="Grayscale", slider=True)
                box.prop(record, "bloom", text="Bloom", slider=True)
                if record.bloom > 0.0:
                    box.prop(record, "bloom_invert", text="Invert Bloom")
                box.prop(record, "motion_blur", text="Motion Blur", slider=True)
                box.prop(
                    record, "chromatic_aberration",
                    text="Chromatic Aberration", slider=True,
                )
                if record.chromatic_aberration > 0.0:
                    _draw_aberration_colors(box, record)
                box.prop(record, "aberration_glitch", text="Glitch", slider=True)
                if record.aberration_glitch > 0.0:
                    box.prop(record, "glitch_size", text="Size", slider=True)
                box.prop(
                    record, "grain_overlay_intensity",
                    text="Film Grain", slider=True,
                )
                box.prop(record, "grain", text="Line Grain", slider=True)
                box.prop(record, "halftone", text="Halftone", slider=True)
                if record.halftone > 0.0:
                    box.prop(record, "halftone_size", text="Halftone Size")
                box.prop(record, "pixelate", text="Pixelate", slider=True)
                if record.pixelate > 0.0:
                    box.prop(record, "pixelate_size", text="Size")
        elif attached and camera.impaction_frames:
            _selection_hint(layout, "Select an impact frame keyframe.")

        if attached and camera.impaction_frames:
            pass  # Export belongs directly beneath the rig selector.


class VIEW3D_PT_impact_animator_anchor(Panel):
    bl_label = "Roblox Animator"
    bl_idname = "VIEW3D_PT_impact_animator_anchor"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Roblox Animator"

    @classmethod
    def poll(cls, _context):
        return False

    def draw(self, _context):
        pass


class VIEW3D_PT_impact_utils_anchor(Panel):
    bl_label = "Roblox Animator Utils"
    bl_idname = "VIEW3D_PT_impact_utils_anchor"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Roblox Animator Utils"

    @classmethod
    def poll(cls, _context):
        return False

    def draw(self, _context):
        pass


UI_CLASSES = (
    IMPACTION_UL_shapes,
    VIEW3D_PT_impact_animator_anchor,
    VIEW3D_PT_impact_utils_anchor,
    VIEW3D_PT_impaction,
)
