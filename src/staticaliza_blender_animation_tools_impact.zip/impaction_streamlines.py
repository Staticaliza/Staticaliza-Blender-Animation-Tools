"""Depth-bearing group streamlines with continuous projected brush footprints."""
import math
import numpy as np
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from .impaction_linear import (
    _mesh_packets, _section, _unit, dome_direction, SurfaceStroke)

def build_group_paths(*args, **kwargs):
    """One ordered 3D casting field at every pin position."""
    from .impaction_envelope import build_group_paths as exterior_paths
    return exterior_paths(*args, **kwargs)


def build_group_paths_face_following(geometry, focus, behind, aspect, spread, salt,
                      motion_influence=0.0, background_motion=(0.,0.),
                      background_acceleration=(0.,0.), velocity_scale=1.0, strength=.72):
    """One world-space placement stage for every pin, including the poles.

    This stage changes placement, not the brush/compositor.
    Section planes belong to proximity components; triangles retain local form.
    """
    packets = _mesh_packets(geometry)
    if not packets:
        return []
    screen = np.asarray(geometry.positions)
    center = (screen[:,:2].min(axis=0)+screen[:,:2].max(axis=0))*.5
    matrix = np.asarray(geometry.view_projection, dtype=np.float64)
    wind = dome_direction(focus, center, aspect, behind, matrix)
    right = Vector(matrix[0,:3]).normalized()
    up = Vector(matrix[1,:3]).normalized()
    # Invariant for a pin update: never rescan an owner's vertices per stroke.
    motion_by_owner = {}
    if motion_influence > 1.e-6 and geometry.velocities and geometry.accelerations:
        owner_ids = np.asarray(geometry.owner_ids)
        velocities = np.asarray(geometry.velocities)
        accelerations = np.asarray(geometry.accelerations)
        for owner, _, _, _, _ in packets:
            mask = owner_ids == owner
            velocity = velocities[mask].mean(axis=0)-np.asarray(background_motion)
            acceleration = accelerations[mask].mean(axis=0)-np.asarray(background_acceleration)
            speed = np.linalg.norm(velocity)/max(velocity_scale,1.e-6)
            response = min(1.,max(0.,(speed-.025)/1.025))
            response = response*response*(3.-2.*response)*min(1.,motion_influence)
            motion_by_owner[owner] = np.clip(acceleration/max(velocity_scale,1.e-6),-2.,2.)*.052*response
    groups = {}
    for packet in packets:
        groups.setdefault(packet[1], []).append(packet)
    strokes = []
    for group, members in sorted(groups.items()):
        vertices, faces, face_owners = [], [], []
        for owner, _, points, triangles, _ in members:
            faces.extend((triangles+len(vertices)).tolist())
            vertices.extend(points.tolist())
            face_owners.extend([owner]*len(triangles))
        vertices = np.asarray(vertices, dtype=np.float64)
        faces = np.asarray(faces, dtype=np.int32)
        bvh = BVHTree.FromPolygons(vertices.tolist(),faces.tolist(),all_triangles=True)
        along = vertices @ np.asarray(wind)
        lo, hi = float(along.min()), float(along.max())
        span = hi-lo
        diagonal = float(np.linalg.norm(vertices.max(axis=0)-vertices.min(axis=0)))
        group_center = Vector((vertices.min(axis=0)+vertices.max(axis=0))*.5)
        if span <= 1e-7:
            continue
        segments = _section(vertices,faces,wind,(lo+hi)*.5)
        perimeter = sum(s[2] for s in segments)
        if not segments:
            continue
        # Density depends on geometric perimeter, never triangle count.
        parents = min(288,max(32,int(perimeter/max(diagonal*.013,1e-7))))
        count = parents*3
        cursor, consumed = 0, 0.
        for i in range(count):
            target = (i+.5)*perimeter/count
            while cursor+1 < len(segments) and consumed+segments[cursor][2] < target:
                consumed += segments[cursor][2]
                cursor += 1
            a,b,length = segments[cursor]
            base = a.lerp(b,(target-consumed)/length)
            fraction = .5+.055*math.sin(i*2.3999632297+group*.71)
            root, normal, face, _ = bvh.find_nearest(base+wind*((fraction-.5)*span))
            if root is None:
                continue
            actual = (root.dot(wind)-lo)/span
            if not .43 <= actual <= .57:
                continue
            owner = face_owners[face]
            # No draw through a contacting part: offset by geometry-scaled
            # epsilon only; the camera depth pass has no same-owner exemption.
            epsilon = diagonal*1e-5
            point = root.copy()
            path = [point+normal*epsilon]
            step = max(span/40.,diagonal/180.)
            tangent = _unit(wind-normal*wind.dot(normal),wind)
            for _ in range(64):
                if normal.dot(wind) > .50 or point.dot(wind) >= hi-span*.008:
                    break
                field = _unit(wind-normal*wind.dot(normal),tangent)
                middle, middle_n, _, _ = bvh.find_nearest(point+field*(step*.5))
                if middle is None:
                    break
                field = _unit(wind-middle_n*wind.dot(middle_n),field)
                candidate, next_n, _, _ = bvh.find_nearest(point+field*step)
                if candidate is None or (candidate-point).length < step*.08:
                    break
                # Enforce monotonic downstream travel: nearest-surface jumps
                # must never fold a path into a loop at a joint.
                if (candidate-point).dot(wind) < -step*.03:
                    break
                point, normal, tangent = candidate,next_n,field
                path.append(point+normal*epsilon)
            # Outward is perpendicular to travel in actual 3D, not an image
            # radial angle. Front/rear poles use the identical construction.
            cross_offset = root-group_center
            outward = _unit(cross_offset-wind*cross_offset.dot(wind),tangent)
            seed = float((int(salt)%65521)+group*173+i*1.61803398875)
            phase = .5+.5*math.sin(i*1.713+group)
            tier = i%3
            reach = ((.10+.21*max(0.,strength))/(.10+.21*.72))*diagonal*(.035+.48*phase**1.85)*(1. if tier==0 else (.56 if tier==1 else .32))
            start = path[-1]
            contact_count = len(path)
            motion_bend = Vector((0.,0.,0.))
            if owner in motion_by_owner:
                bend = motion_by_owner[owner]*diagonal
                motion_bend = right*float(bend[0])+up*float(bend[1])
            for j in range(1,25):
                t = j/24.
                relax = (1.0-math.exp(-4.0*t))/4.0
                path.append(start+wind*(reach*t)+(tangent-wind)*(reach*relax)+outward*(reach*max(0.,spread)*.22*t*t)+motion_bend*(t*t))
            # Relative width retains loaded parents and shorter companions.
            width = (1.0+.80*(.5+.5*math.sin(i*.83+group))) * (1. if tier==0 else (.78 if tier==1 else .60))
            stroke = SurfaceStroke(owner,group,seed,actual,path,width)
            stroke.diagonal = diagonal
            stroke.contact_count = contact_count
            stroke.family = i
            stroke.family_seed = phase
            stroke.primary = tier == 0
            stroke.gap = tier == 1
            stroke.normals = [bvh.find_nearest(p)[1] for p in path[:contact_count]]
            stroke.surface = bvh
            stroke.epsilon = epsilon
            strokes.append(stroke)
    return strokes


def conforming_ribbons_reference(strokes, projection, width, height, thickness):
    """Stable screen footprint; surface edges intersect the local tangent plane.

    No independent nearest-mesh snapping for the two ribbon edges: that folded
    whole triangles at creases and made the white diagonal cuts.
    """
    matrix = np.asarray(projection,dtype=np.float64)
    inverse = np.linalg.inv(matrix)
    depth_axis = matrix[2,:3]/np.linalg.norm(matrix[2,:3])
    positions,coordinates,parameters,depths,styles,triangles=[],[],[],[],[],[]
    surface_permits=[]
    scale=np.array((width,height))
    for stroke in strokes:
        world=np.asarray([tuple(p) for p in stroke.points])
        clips=np.column_stack((world,np.ones(len(world))))@matrix.T
        if np.any(clips[:,3]<=1e-7):
            continue
        pixel=(clips[:,:2]/clips[:,3:4]*.5+.5)*scale
        arc=np.r_[0.,np.cumsum(np.linalg.norm(np.diff(pixel,axis=0),axis=1))]
        keep=np.r_[True,np.diff(arc)>.001]
        indices=np.flatnonzero(keep)
        if len(indices)<2 or arc[-1]<2.:
            continue
        world,clips,pixel,arc=world[keep],clips[keep],pixel[keep],arc[keep]
        # Carry the atlas' irregular terminals beyond t=1 instead of slicing
        # every stroke on the last triangle. Do the same for its soft heel.
        end_extra=(world[-1]-world[-2])*.10*arc[-1]/max(arc[-1]-arc[-2],.001)
        start_extra=(world[0]-world[1])*.04*arc[-1]/max(arc[1]-arc[0],.001)
        world=np.vstack((world[0]+start_extra,world,world[-1]+end_extra))
        clips=np.column_stack((world,np.ones(len(world))))@matrix.T
        pixel=(clips[:,:2]/clips[:,3:4]*.5+.5)*scale
        arc=np.r_[-.04*arc[-1],arc,1.10*arc[-1]]
        indices=np.r_[indices[0],indices,indices[-1]+1]
        clock_length=arc[-1]/1.10
        # Extend geometry outside the analytic brush support at BOTH ends.
        tangent=np.diff(pixel,axis=0)
        tangent/=np.maximum(np.linalg.norm(tangent,axis=1)[:,None],1e-7)
        normals=np.column_stack((-tangent[:,1],tangent[:,0]))
        joins=np.vstack((normals[0],normals[:-1]+normals[1:],normals[-1]))
        joins/=np.maximum(np.linalg.norm(joins,axis=1)[:,None],1e-7)
        denom=np.r_[1.,np.einsum('ij,ij->i',joins[1:-1],normals[1:]),1.]
        joins/=np.maximum(denom[:,None],.4)
        half_width=min(width,height)*(.0027+.0068*thickness)*stroke.width
        base=len(positions)
        edge = pixel[:,None,:]+joins[:,None,:]*np.array((-1.,1.))[None,:,None]*half_width*2.2
        ndc = edge/scale*2.-1.
        n=len(pixel)
        clip_edges=np.empty((n,2,4),dtype=np.float64)
        clip_edges[:,:,:2]=ndc*clips[:,None,3:4]
        clip_edges[:,:,2:]=clips[:,None,2:]
        # Two ray/plane intersections per cross-section, batched in NumPy.
        homogeneous=np.concatenate((ndc,np.full((n,2,1),-1.),np.ones((n,2,1))),axis=2)
        near=homogeneous@inverse.T
        homogeneous[:,:,2]=1.
        far=homogeneous@inverse.T
        near=near[:,:,:3]/near[:,:,3:4]
        far=far[:,:,:3]/far[:,:,3:4]
        ray=far-near
        ns=np.zeros((n,3),dtype=np.float64)
        contact=indices<stroke.contact_count
        ns[contact]=np.asarray(stroke.normals)[indices[contact]]
        den=np.einsum('ijk,ik->ij',ray,ns)
        numer=np.einsum('ijk,ik->ij',world[:,None,:]-near,ns)
        ratio=np.divide(numer,den,out=np.zeros_like(den),where=abs(den)>1.e-7)
        candidate=near+ray*ratio[:,:,None]
        valid=contact[:,None]&(abs(den)>1.e-7)&(np.linalg.norm(candidate-world[:,None,:],axis=2)<stroke.diagonal*.04)
        edge_world=np.where(valid[:,:,None],candidate,world[:,None,:])
        positions.extend(clip_edges.reshape((-1,4)).tolist())
        depths.extend((edge_world@depth_axis-stroke.epsilon).reshape(-1).tolist())
        coords=np.empty((n,2,2))
        coords[:,:,0]=arc[:,None]/clock_length
        coords[:,:,1]=np.array((-2.2,2.2))[None,:]
        coordinates.extend(coords.reshape((-1,2)).tolist())
        parameters.extend([(half_width,stroke.seed,float(stroke.owner),1./clock_length)]*(n*2))
        styles.extend([(stroke.family_seed,float(stroke.family),float(stroke.primary),float(stroke.gap))]*(n*2))
        surface_permits.extend([(0.,0.,0.,0.)]*(n*2))
        for j in range(len(pixel)-1):
            a=base+j*2
            triangles.extend(((a,a+1,a+2),(a+1,a+3,a+2)))
    return dict(clipPosition=positions,strokeUV=coordinates,strokeParams=parameters,
                linearDepth=depths,strokeStyle=styles,strokeContact=surface_permits),triangles


def _round_ribbon_corners(world, footprint, normals, owners, arc, sizes,
                          matrix, scale, brush_width):
    """Interpolate the original 3D trajectory; never replace a turn by a cap."""
    starts=np.cumsum(sizes)-sizes
    packed=np.column_stack((world,footprint,normals,owners,arc))
    sections=[];counts=[]
    for start,size in zip(starts,sizes):
        rows=packed[start:start+size];p=rows[:,:3]
        delta=np.diff(p,axis=0);length=np.linalg.norm(delta,axis=1)
        direction=delta/np.maximum(length[:,None],1.e-12)
        # Neighbor spacing carries the trajectory's acceleration. Weighted
        # tangents are evaluated in world coordinates before camera projection.
        dt=np.sqrt(np.maximum(length,1.e-12))
        tangent=np.zeros_like(p);tangent[0]=direction[0];tangent[-1]=direction[-1]
        tangent[1:-1]=(direction[:-1]*dt[1:,None]+direction[1:]*dt[:-1,None])
        tangent/=np.maximum(np.linalg.norm(tangent,axis=1)[:,None],1.e-12)
        free=np.linalg.norm(rows[:,5:8],axis=1)<.01
        clips=np.c_[p,np.ones(size)]@matrix.T
        pixel=(clips[:,:2]/clips[:,3:4]*.5+.5)*scale+rows[:,3:5]
        screen_delta=np.diff(pixel,axis=0)
        screen_delta/=np.maximum(np.linalg.norm(screen_delta,axis=1)[:,None],1.e-12)
        turn=np.zeros(size,dtype=bool)
        turn[1:-1]=np.sum(screen_delta[:-1]*screen_delta[1:],axis=1)<.75
        eligible=(turn[:-1]|turn[1:])&free[:-1]&free[1:]&(rows[:-1,8]==rows[1:,8])
        if not eligible.any():
            sections.append(rows);counts.append(len(rows));continue
        pieces=[]
        for i in range(size-1):
            pieces.append(rows[i:i+1])
            lo=max(0,i-1);hi=min(size,i+3)
            if (not (turn[i] or turn[i+1]) or not free[lo:hi].all()
                    or not np.all(rows[lo:hi,8]==rows[i,8]) or length[i]<1.e-9):continue
            t=np.array([.25,.5,.75])[:,None]
            values=rows[i]*(1.-t)+rows[i+1]*t
            # Cubic Hermite: exact original knots, continuous tangent direction,
            # handles bounded by the existing segment's world length.
            m0=tangent[i]*length[i];m1=tangent[i+1]*length[i]
            minimum_w=min(clips[i,3],clips[i+1,3])*.5
            change0=float(np.dot(matrix[3,:3],m0))/3.
            change1=-float(np.dot(matrix[3,:3],m1))/3.
            if change0<0.:m0*=min(1.,(clips[i,3]-minimum_w)/(-change0))
            if change1<0.:m1*=min(1.,(clips[i+1,3]-minimum_w)/(-change1))
            values[:,:3]=(2*t**3-3*t**2+1)*p[i]+(t**3-2*t**2+t)*m0+(-2*t**3+3*t**2)*p[i+1]+(t**3-t**2)*m1
            pieces.append(values)
        pieces.append(rows[-1:]);section=np.concatenate(pieces)
        sections.append(section);counts.append(len(section))
    result=np.concatenate(sections)
    return result[:,:3],result[:,3:5],result[:,5:8],result[:,8],result[:,9],np.array(counts),np.ones(len(result))


def iter_conforming_ribbons(strokes, projection, width, height, thickness, sampling_quality=1.):
    """Batch projection, arclength, joins and ray/plane tests over every ribbon."""
    if not strokes:
        return {}, []
    matrix=np.asarray(projection,dtype=np.float64)
    inverse=np.linalg.inv(matrix)
    axis=matrix[2,:3]/np.linalg.norm(matrix[2,:3])
    scale=np.array((width,height))
    sizes=np.array([len(s.points) for s in strokes])
    starts=np.cumsum(sizes)-sizes
    ends=starts+sizes-1
    ids=np.repeat(np.arange(len(strokes)),sizes)
    world=np.asarray([tuple(p) for s in strokes for p in s.points])
    clips=np.column_stack((world,np.ones(len(world))))@matrix.T
    yield None
    safe=np.minimum.reduceat(clips[:,3],starts)>1.e-7
    if not safe.all():
        return (yield from iter_conforming_ribbons([s for s,ok in zip(strokes,safe) if ok],
                                  projection,width,height,thickness,sampling_quality))
    pixel=(clips[:,:2]/clips[:,3:4]*.5+.5)*scale
    # Project a subject-relative world brush at each stroke's root. A median
    # depth / current depth ratio cancels camera dolly and fixes width on screen.
    root_depth=np.maximum(abs(clips[starts,3]),1.e-7)
    world_scale=np.array([getattr(s,'brush_world_scale',s.diagonal) for s in strokes])
    subject_pixels=world_scale*(.5*height*np.linalg.norm(matrix[1,:3]))/root_depth
    # A fixed subject-relative world brush projects at its actual depth.
    brush_pixels=subject_pixels
    nominal_width=brush_pixels*(.0027+.0068*thickness)*np.array([s.width for s in strokes])
    # Reject sub-brush chips before longitudinal footprint regularization.
    # Use 3D free length, so a substantial end-on stroke remains a finite
    # brush deposit rather than disappearing merely because of its angle.
    free_length=np.array([sum((b-a).length for a,b in zip(
        s.points[(0 if getattr(s,'support_only',False) else s.contact_count-1):-1],
        s.points[(1 if getattr(s,'support_only',False) else s.contact_count):])) for s in strokes])
    release_indices=starts+np.minimum(sizes,np.array([s.contact_count for s in strokes]))-1
    world_per_pixel=2.*abs(clips[release_indices,3])/max(np.linalg.norm(matrix[1,:3])*height,1.e-8)
    min_length=np.maximum(subject_pixels*(12./1080.)*world_per_pixel,
        nominal_width*world_per_pixel*1.5)
    readable=free_length>=min_length
    # A short motion remnant can have substantial depth travel while its
    # visible trail is only a few pixels long. Enlarging that footprint made
    # detached triangle-shaped pellets. Keep the static brush as coverage;
    # admit a motion trail only when its projected run is readable.
    moving=np.array([getattr(s,'motion_path',False) for s in strokes])
    motion_authority=np.array([getattr(s,"motion_authority",1.) for s in strokes])
    # One segmented prefix sum replaces two Python loops over every path.
    previous=np.maximum(np.arange(len(world))-1,starts[ids])
    projected_steps=np.linalg.norm(pixel-pixel[previous],axis=1)
    projected_prefix=np.cumsum(projected_steps)
    projected_free=projected_prefix[ends]-projected_prefix[release_indices]
    cropped=np.array([getattr(s,"cropped_tip",False) for s in strokes])
    minimum_projected=np.where(cropped,
        np.maximum(subject_pixels*(36./1080.),nominal_width*4.0),
        np.maximum(subject_pixels*(36./1080.),nominal_width*2.25))
    readable &= ~(moving|cropped) | (projected_free>=minimum_projected*np.where(cropped,1.,motion_authority))
    # Surface-only remnants have no free tail to explain a foreshortened
    # footprint. Require a visible brush run; do not enlarge a tiny cap chip.
    supported=np.array([getattr(s,'support_only',False) for s in strokes])
    projected_run=projected_prefix[ends]-projected_prefix[starts]
    readable &= ~supported | (projected_run>=subject_pixels*(32./1080.))
    yield None
    if not readable.all():
        return (yield from iter_conforming_ribbons([s for s,ok in zip(strokes,readable) if ok],
                                  projection,width,height,thickness,sampling_quality))
    # Deposit the same finite brush along every path, including end-on paths.
    # Only its projected longitudinal footprint is regularized; world points,
    # contact ownership and depth stay on the original trajectory.
    # Arc and foreshortened footprint are separable by stroke. Calculate all
    # points in contiguous arrays, preserving every original contact/tip.
    delta=pixel[ends]-pixel[release_indices]
    chord=np.linalg.norm(delta,axis=1)
    directions=delta/np.maximum(chord[:,None],1.e-12)
    directions[chord<1.e-12]=(1.,0.)
    world_steps=np.linalg.norm(world-world[previous],axis=1)
    world_prefix=np.cumsum(world_steps)
    free_distance=np.maximum(0.,world_prefix-world_prefix[release_indices[ids]])
    phase=free_distance/np.maximum(free_distance[ends[ids]],1.e-12)
    # Do not extend depth-foreshortened paths in screen space. Coverage is
    # rasterized around the real projected centerline, including axial paths.
    footprint=np.zeros((len(world),2),dtype=float)
    yield None
    pixel+=footprint
    previous=np.maximum(np.arange(len(world))-1,starts[ids])
    segment_length=np.linalg.norm(pixel-pixel[previous],axis=1)
    cumulative=np.cumsum(segment_length)
    arc=cumulative-cumulative[starts[ids]]
    total=arc[ends]
    release_indices=starts+np.minimum(sizes,np.array([s.contact_count for s in strokes]))-1
    free_chord=np.linalg.norm(pixel[ends]-pixel[release_indices],axis=1)
    # A foreshortened companion has less space to deposit pigment. Fit only
    # collapsed free bodies; broad primary families keep their original load.
    contact_chord=np.linalg.norm(pixel[release_indices]-pixel[starts],axis=1)
    secondary=np.array([not s.primary for s in strokes])
    available=np.where(secondary,free_chord,np.maximum(free_chord,contact_chord*.8))
    aspect=np.where(secondary,2.8,1.8)
    # Foreshortening may compress a mark, but never turn its entire body into
    # a hairline. Neighbouring ribbons can overlap; there is no packing gap.
    facing=np.array([getattr(s,'casting_facing',1.) for s in strokes])
    width_floor=np.full(len(strokes),.85)
    width_floor=np.maximum(width_floor,np.array([.8 if getattr(s,'motion_path',False) else 0. for s in strokes]))
    free_width_fit=np.minimum(1.,np.maximum(available/np.maximum(nominal_width*aspect,1.e-6),width_floor))
    chord=np.linalg.norm(pixel[ends]-pixel[starts],axis=1)
    # End-on travel is a finite deposit too; do not discard it using an
    # aspect-ratio gate after preserving its continuous brush footprint.
    safe=(total>1.e-6)&(chord>1.e-6)
    if not safe.all():
        return (yield from iter_conforming_ribbons([s for s,ok in zip(strokes,safe) if ok],
                                  projection,width,height,thickness,sampling_quality))
    normal_world=np.zeros_like(world)
    contact_owners=np.zeros(len(world))
    launch_ends=starts+np.minimum(sizes,np.array([getattr(s,'launch_count',s.contact_count) for s in strokes]))-1
    launch_fraction=arc[launch_ends]/np.maximum(total,1.e-8)
    for start,s in zip(starts,strokes):
        normal_world[start:start+s.contact_count]=np.asarray(s.normals)
        contact_owners[start:start+s.contact_count]=np.asarray(
            getattr(s,'contact_owners',[s.owner]*s.contact_count))+1.
    yield None
    kept=np.ones(len(world),dtype=bool)
    kept[segment_length<=.001]=False
    kept[starts]=True
    index=np.flatnonzero(kept)
    original_index=index.copy()
    ids=ids[index]
    sizes=np.bincount(ids,minlength=len(strokes))
    starts=np.cumsum(sizes)-sizes
    ends=starts+sizes-1
    footprint=footprint[index]
    world,arc,normal_world=world[index],arc[index],normal_world[index]
    contact_owners=contact_owners[index]
    # Padding belongs to geometry, not to the brush; the shader still owns tips.
    # Padding is brush coverage, not additional surface travel. Scaling the
    # heel by the entire off-screen tail could extrapolate a tiny initial
    # bevel segment hundreds of pixels backward into another visible limb.
    head_padding=np.minimum(.08*total,np.maximum(subject_pixels*(4./1080.),nominal_width*.45))
    head_padding*=np.array([0. if hasattr(s,'surface_owners') else 1. for s in strokes])
    supported_flags=np.array([getattr(s,'support_only',False) for s in strokes])
    head_padding=np.where(supported_flags,np.minimum(total*.25,np.maximum(subject_pixels*(4./1080.),nominal_width*.45)),head_padding)
    first_extra=(world[starts]-world[starts+1])*(head_padding/np.maximum(arc[starts+1],.001))[:,None]
    first_budget=np.array([s.diagonal*.025 for s in strokes])
    first_extra*=np.minimum(1.,first_budget/np.maximum(np.linalg.norm(first_extra,axis=1),1.e-8))[:,None]
    # Never divide world displacement by a projected segment length.
    # A depth-aligned last segment can have zero projected length, turning
    # harmless brush padding into a world-space spear across the camera.
    tip_delta=world[ends]-world[ends-1]
    tip_length=np.linalg.norm(tip_delta,axis=1)
    world_chord=np.linalg.norm(world[ends]-world[starts],axis=1)
    tip_budget=np.minimum(tip_length,world_chord*.10)
    last_extra=tip_delta*(tip_budget/np.maximum(tip_length,1.e-8))[:,None]
    # Keep padded endpoints on the same valid side of the near plane.
    end_w=np.c_[world[ends],np.ones(len(ends))]@matrix[3]
    delta_w=last_extra@matrix[3,:3]
    camera_limit=np.minimum(1.,np.maximum(end_w*.5,0.)/np.maximum(-delta_w,1.e-8))
    last_extra*=camera_limit[:,None]
    last_extra*=np.array([0. if getattr(s,"support_only",False) or getattr(s,"cropped_tip",False) else 1. for s in strokes])[:,None]
    # Repeat endpoints in one segmented gather instead of constructing a
    # separate Python/NumPy array for every brush ribbon.
    expanded_ids=np.repeat(np.arange(len(strokes)),sizes+2)
    expanded=np.clip(np.arange(len(world)+2*len(strokes))-2*expanded_ids-1,
                     starts[expanded_ids],ends[expanded_ids])
    footprint=footprint[expanded]
    world=world[expanded].copy()
    normal_world=normal_world[expanded].copy()
    contact_owners=contact_owners[expanded].copy()
    arc=arc[expanded].copy()
    sizes=sizes+2
    starts=np.cumsum(sizes)-sizes
    ends=starts+sizes-1
    ids=np.repeat(np.arange(len(strokes)),sizes)
    world[starts]+=first_extra
    world[ends]+=last_extra
    normal_world[ends]=0.
    arc[starts]=-head_padding
    arc[ends]=1.10*total
    world,footprint,normal_world,contact_owners,arc,sizes,return_pressure=_round_ribbon_corners(
        world,footprint,normal_world,contact_owners,arc,sizes,
        matrix,scale,nominal_width)
    starts=np.cumsum(sizes)-sizes
    ends=starts+sizes-1
    ids=np.repeat(np.arange(len(strokes)),sizes)
    clips=np.column_stack((world,np.ones(len(world))))@matrix.T
    pixel=(clips[:,:2]/clips[:,3:4]*.5+.5)*scale+footprint
    idx=np.arange(len(world))
    previous=np.maximum(idx-1,starts[ids])
    following=np.minimum(idx+1,ends[ids])
    incoming=pixel-pixel[previous]
    outgoing=pixel[following]-pixel
    incoming[starts]=outgoing[starts]
    outgoing[ends]=incoming[ends]
    incoming/=np.maximum(np.linalg.norm(incoming,axis=1)[:,None],1.e-7)
    outgoing/=np.maximum(np.linalg.norm(outgoing,axis=1)[:,None],1.e-7)
    normal_in=np.column_stack((-incoming[:,1],incoming[:,0]))
    normal_out=np.column_stack((-outgoing[:,1],outgoing[:,0]))
    joins=normal_in+normal_out
    joins/=np.maximum(np.linalg.norm(joins,axis=1)[:,None],1.e-7)
    # A contact bend is not a pointed miter. Bound its outer excursion;
    # otherwise a broad brush magnifies a short bevel into a triangular fin.
    joins/=np.maximum(np.einsum('ij,ij->i',joins,normal_out)[:,None],.85)
    # A loaded brush does not rotate its cross-section at each tiny bevel
    # triangle. Estimate its director over a brush-sized arc neighbourhood,
    # retaining the same center samples and finite surface intersections.
    for j,(start,end) in enumerate(zip(starts,ends)):
        section=slice(start,end+1)
        local_arc=arc[section]
        radius=max(nominal_width[j]*1.25,1.e-6)
        low=np.maximum(local_arc-radius,local_arc[0])
        high=np.minimum(local_arc+radius,local_arc[-1])
        delta=np.column_stack([np.interp(high,local_arc,pixel[section,k])-
                               np.interp(low,local_arc,pixel[section,k]) for k in (0,1)])
        norm=np.linalg.norm(delta,axis=1)
        valid=norm>1.e-6
        smooth=np.column_stack((-delta[:,1],delta[:,0]))/np.maximum(norm[:,None],1.e-6)
        joins[section]=np.where(valid[:,None],smooth,joins[section])
        if j%32==31:yield None
    half_width=(nominal_width*free_width_fit)[ids]
    # Project world brush width at EVERY station: nearer sections grow and
    # farther sections shrink, independently of the material pressure/taper.
    perspective_width=root_depth[ids]/np.maximum(abs(clips[:,3]),1.e-7)
    half_width*=perspective_width*return_pressure
    # A projected offset ribbon folds when its width exceeds the local bend
    # radius. Limit only that excess on free trails, after perspective scaling.
    # This follows the actual 3D trajectory instead of imposing a circular cap.
    va=pixel-pixel[previous];vb=pixel[following]-pixel
    la=np.linalg.norm(va,axis=1);lb=np.linalg.norm(vb,axis=1)
    chord=np.linalg.norm(pixel[following]-pixel[previous],axis=1)
    cross=np.abs(va[:,0]*vb[:,1]-va[:,1]*vb[:,0])
    radius=la*lb*chord/np.maximum(2.*cross,1.e-12)
    valid=(cross>1.e-5)&(la>.001)&(lb>.001)&(np.linalg.norm(normal_world,axis=1)<.01)
    turn_pressure=np.clip(radius/np.maximum(half_width*1.3,1.e-8),.4,1.)
    turn_pressure=np.where(valid,turn_pressure,1.)
    turn_pressure=(turn_pressure[previous]+2.*turn_pressure+turn_pressure[following])*.25
    half_width*=np.where(np.linalg.norm(normal_world,axis=1)<.01,turn_pressure,1.)
    root_end=np.maximum(launch_fraction[ids]+.08,.12)
    root_t=np.clip((arc/total[ids]-launch_fraction[ids])/np.maximum(root_end-launch_fraction[ids],.08),0.,1.)
    root_gain=np.array([getattr(s,'root_scale',1.) for s in strokes])[ids]
    half_width*=1.+(root_gain-1.)*(1.-root_t*root_t*(3.-2.*root_t))
    yield None
    # Keep the center and inner brush lanes on their own plane intersections.
    # A two-edge strip interpolated across rejected outer plane intersections
    # loses even the valid center depth, cutting broad marks into white bars.
    # Visibility is solved per lane and can reject a whole brush section.
    # Keep Apply's lanes even when the output raster is reduced.
    lane=np.linspace(-1.,1.,9)
    columns=len(lane)
    edge=pixel[:,None,:]+joins[:,None,:]*lane[None,:,None]*half_width[:,None,None]*2.2
    ndc=edge/scale*2.-1.
    n=len(world)
    clip_edges=np.empty((n,columns,4))
    clip_edges[:,:,:2]=ndc*clips[:,None,3:4]
    clip_edges[:,:,2:]=clips[:,None,2:]
    # Source ownership is resolved per fragment; preserve actual center depth.
    center_depth=world@axis-np.array([s.epsilon for s in strokes])[ids]
    depth=np.broadcast_to(center_depth[:,None],(n,columns))
    # Negative contact metadata marks an already bounded, surface-only pickup.
    # It keeps normal center-depth handling and needs no second fringe clip.
    pickup_tag=-np.array([getattr(s,'support_only',False) for s in strokes],dtype=float)[ids]
    contact_data=np.column_stack((pickup_tag,center_depth,pixel/scale))
    lane_contacts=np.repeat(contact_data[:,None,:],columns,axis=1)
    uv=np.empty((n,columns,2))
    pickup_width=nominal_width*(1.10+.80*np.array([s.family_seed for s in strokes]))
    contour=np.array([getattr(s,'contour_inlet',False) for s in strokes])
    supported=np.array([getattr(s,'support_only',False) for s in strokes])
    contact_span=launch_fraction*total
    stagger=np.minimum(contact_span*(.35+.25*np.array([s.family_seed for s in strokes])),
        nominal_width*(3.0+2.0*np.array([s.family_seed for s in strokes])))
    heel_start=np.where(supported,-head_padding*.85,np.where(contour,contact_span-stagger,
        np.maximum(0.,contact_span-pickup_width)))
    # Moving brushes retain their supported surface sweep. The short static
    # pickup window otherwise hides the wrap and cuts every heel at the cap.
    moving=np.array([getattr(s,"motion_path",False) for s in strokes])
    family_phase=np.array([s.family_seed for s in strokes])
    # Keep broad parents loaded earlier and let short companions pick up
    # later. A shared contact fraction cut all moving heels into one slab.
    pickup_phase=np.where(np.array([s.primary for s in strokes]),
        .10+.30*family_phase,.35+.50*family_phase)
    wrap_start=contact_span*pickup_phase
    wrap_weight=np.where(moving,motion_authority,0.)
    heel_start+=wrap_weight*(wrap_start-heel_start)
    drawing_total=total-heel_start
    uv[:,:,0]=(arc[:,None]-heel_start[ids,None])/drawing_total[ids,None]
    uv[:,:,1]=(lane*2.2)[None,:]
    # z carries the surface-to-free-trail transition, not an unused owner ID.
    params=np.column_stack((half_width,np.array([s.seed+17.*getattr(s,"brush_phase",0.) for s in strokes])[ids],
                            (launch_fraction[ids]*total[ids]-heel_start[ids])/drawing_total[ids],1./drawing_total[ids]))
    lane_params=np.repeat(params[:,None,:],columns,axis=1)
    yield None
    # Clip coverage, never the longitudinal brush coordinates: retiming
    # individual lanes shears the charcoal texture into needles and holes.
    # A hidden pickup may emerge, but an exposed lane cannot reappear after
    # entering another mesh. Keep supported pigment if its free tail is blocked.
    visibility=np.ones((n,columns),dtype=float)
    # Surface pickup uses the same depth test as the rest of the ribbon.
    # A normal-facing mask erased valid front contact for centered pins.
    homogeneous=np.concatenate((ndc,np.full((n,columns,1),-1.),np.ones((n,columns,1))),axis=2)
    near=homogeneous@inverse.T
    homogeneous[:,:,2]=1.
    far=homogeneous@inverse.T
    near=near[:,:,:3]/near[:,:,3:4]
    far=far[:,:,:3]/far[:,:,3:4]
    rays=far-near
    rays/=np.maximum(np.linalg.norm(rays,axis=2)[:,:,None],1.e-8)
    yield None
    for j,(start,end) in enumerate(zip(starts,ends)):
        stroke=strokes[j]
        surface=getattr(stroke,'surface',None)
        owners=getattr(stroke,'surface_owners',None)
        if surface is None or owners is None:continue
        first=start+int(np.searchsorted(arc[start:end+1],heel_start[j]))
        bounds=getattr(stroke, 'surface_screen_bounds', None)
        possible_hits=None
        if bounds is not None:
            lo,hi=np.asarray(bounds)*scale
            possible_hits=np.all((edge[start:end+1]>=lo)&(edge[start:end+1]<=hi),axis=2)
        for column in range(columns):
            exposed=False
            for station in range(first,end+1):
                if possible_hits is None or possible_hits[station-start,column]:
                    hit,_,face,_=surface.ray_cast(Vector(near[station,column]),Vector(rays[station,column]))
                else:
                    hit=None
                blocked=(hit is not None and int(owners[face])!=stroke.owner and
                         (hit.x*axis[0]+hit.y*axis[1]+hit.z*axis[2])<center_depth[station]-0.00005)
                if not blocked:
                    if (not exposed and station>first and arc[station]>contact_span[j]
                            and not getattr(stroke,"motion_path",False)):
                        visibility[start:end+1,column]=0.
                        break
                    exposed=True
                    continue
                if not exposed:
                    visibility[start:station+1,column]=0.
                    continue
                stop=arc[max(first,station-1)]
                fade=max(subject_pixels[j]*(2./1080.),nominal_width[j]*.5)
                visibility[first:end+1,column]*=np.clip(
                    (stop-arc[first:end+1])/fade,0.,1.)
                break
        yield None
    # w: gap bit, motion bit (2), and Cast Behind static rim deposit (4).
    # Measured motion uses actual depth
    # when crossing a different mesh in front of the subject.
    styles=np.array([(s.family_seed,s.family,s.primary,float(s.gap)+2.*bool(getattr(s,'motion_path',False))+4.*bool(getattr(s,'cast_behind',False) and not getattr(s,'motion_path',False))) for s in strokes],dtype=float)[ids]
    # Band travels in physical arclength, before projection. Depth-oriented
    # and curving paths therefore foreshorten their intervals with the path.
    previous_world=np.maximum(np.arange(len(world))-1,starts[ids])
    world_segments=np.linalg.norm(world-world[previous_world],axis=1)
    world_cumulative=np.cumsum(world_segments)
    world_arc=world_cumulative-world_cumulative[starts[ids]]
    band_coordinate=world_arc/np.maximum(np.array([s.diagonal for s in strokes])[ids],1.e-8)
    edge_idx=(idx[idx!=ends[ids],None]*columns+np.arange(columns-1)[None,:]).reshape(-1)
    triangles=np.stack((np.column_stack((edge_idx,edge_idx+1,edge_idx+columns)),
                        np.column_stack((edge_idx+1,edge_idx+columns+1,edge_idx+columns))),axis=1).reshape((-1,3)).astype(np.int32)
    arrays=dict(clipPosition=clip_edges.reshape((-1,4)),strokeUV=uv.reshape((-1,2)),
                strokeParams=lane_params.reshape((-1,4)),linearDepth=depth.reshape(-1),
                strokeStyle=np.repeat(styles,columns,axis=0),
                sourceOwner=np.repeat(np.array([s.owner+1. for s in strokes])[ids],columns),
                strokeContact=lane_contacts.reshape((-1,4)),
                linearBandCoordinate=np.repeat(band_coordinate,columns),
                 strokeVisibility=visibility.reshape(-1))
    # GPUVertBuf.attr_fill consumes raw typed buffers, not Python float values.
    # FLOAT attributes must never receive NumPy float64 memory.
    return {name:np.ascontiguousarray(value,dtype=np.float32) for name,value in arrays.items()},triangles


def conforming_ribbons(*args, **kwargs):
    """Synchronous export adapter for the same cooperative ribbon constructor."""
    iterator=iter_conforming_ribbons(*args,**kwargs)
    while True:
        try:next(iterator)
        except StopIteration as result:return result.value
