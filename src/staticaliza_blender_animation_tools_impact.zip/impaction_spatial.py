"""Exact broad-phase queries over immutable capture bounds."""

import numpy as np


class BoundsIndex:
    """Balanced AABB tree; candidates still receive their original exact test."""

    def __init__(self, lower, upper):
        self.lower = np.asarray(lower, dtype=float)
        self.upper = np.asarray(upper, dtype=float)
        self.root = self._build(np.arange(len(self.lower))) if len(self.lower) else None

    def _build(self, indices):
        lo = self.lower[indices].min(axis=0)
        hi = self.upper[indices].max(axis=0)
        if len(indices) <= 8:
            return lo, hi, indices, None, None
        centers = (self.lower[indices] + self.upper[indices]) * .5
        axis = int(np.argmax(np.ptp(centers, axis=0)))
        order = indices[np.argsort(centers[:, axis], kind='stable')]
        middle = len(order) // 2
        return lo, hi, None, self._build(order[:middle]), self._build(order[middle:])

    def query(self, lower, upper):
        if self.root is None:
            return np.empty(0, dtype=int)
        lower, upper = np.asarray(lower), np.asarray(upper)
        pending = [self.root]
        found = []
        while pending:
            lo, hi, indices, left, right = pending.pop()
            if np.any(lo > upper) or np.any(hi < lower):
                continue
            if indices is None:
                pending.extend((left, right))
            else:
                keep = np.all(self.lower[indices] <= upper, axis=1)
                keep &= np.all(self.upper[indices] >= lower, axis=1)
                found.extend(indices[keep])
        return np.asarray(sorted(found), dtype=int)


def nearby_pairs(lower, upper, radii):
    """Yield pairs whose distance can be within either member's radius.

    Callers use a monotonic radius of the smaller member. Querying each box
    expanded by its own radius therefore cannot discard an accepted pair.
    """
    lower, upper = np.asarray(lower), np.asarray(upper)
    if not len(lower):
        return
    # The per-island tree does thousands of tiny NumPy reductions for an OBJ
    # made of disconnected two-triangle surfaces. A sorted primary axis lets
    # NumPy reject those boxes in batches, without changing the exact AABB
    # predicate or the narrow-phase test performed by the caller.
    if len(lower) > 8192:
        index = BoundsIndex(lower, upper)
        for first, radius in enumerate(radii):
            for second in index.query(lower[first] - radius, upper[first] + radius):
                if second < first:
                    yield first, int(second)
        return
    axis = int(np.argmax(np.ptp((lower + upper) * .5, axis=0)))
    order = np.argsort(lower[:, axis], kind="stable")
    sorted_lower = lower[order, axis]
    for first, radius in enumerate(radii):
        stop = int(np.searchsorted(sorted_lower, upper[first, axis] + radius, side="right"))
        candidates = order[:stop]
        candidates = candidates[candidates < first]
        if not len(candidates):
            continue
        candidates = candidates[np.all(upper[candidates] >= lower[first] - radius, axis=1)]
        candidates = candidates[np.all(lower[candidates] <= upper[first] + radius, axis=1)]
        for second in np.sort(candidates):
            yield first, int(second)


def owner_indices(owners):
    """Partition once instead of scanning all vertices for every mesh owner."""
    owners = np.asarray(owners)
    order = np.argsort(owners, kind='stable')
    if not len(order):
        return {}
    cuts = np.flatnonzero(np.diff(owners[order])) + 1
    return {int(owners[part[0]]): part for part in np.split(order, cuts)}
