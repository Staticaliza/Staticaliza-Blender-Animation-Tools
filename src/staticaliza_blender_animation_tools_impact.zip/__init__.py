"""Roblox Animator Impact Blender extension."""

bl_info = {
    "name": "Roblox Animator Impact",
    "author": "Staticaliza",
    "version": (1, 0, 0),
    "blender": (4, 2, 0),
    "location": "3D View > Sidebar > Roblox Animator Impact",
    "description": "Keyed camera-space anime impact frames",
    "category": "Animation",
}

import bpy

from .impaction_action import cancel_marker_host_collapse_timer
from .impaction_operators import (
    OPERATOR_CLASSES, register_operator_keymaps, unregister_operator_keymaps,
)
from .impaction_gizmo import GIZMO_CLASSES
from .impaction_properties import (
    PROPERTY_CLASSES, register_properties, unregister_properties,
)
from .impaction_renderer import clear_shader_cache
from .impaction_runtime import register_runtime, unregister_runtime
from .impaction_ui import UI_CLASSES


def _registered_class(cls):
    existing = getattr(bpy.types, cls.__name__, None)
    if existing is not None:
        return existing
    for root in (
        bpy.types.PropertyGroup, bpy.types.Operator, bpy.types.Gizmo,
        bpy.types.GizmoGroup, bpy.types.Menu, bpy.types.Panel,
    ):
        try:
            existing = root.bl_rna_get_subclass_py(cls.__name__, None)
        except (AttributeError, RuntimeError, TypeError):
            existing = None
        if existing is not None:
            return existing
    if getattr(cls, "is_registered", False) or "bl_rna" in cls.__dict__:
        return cls
    return None


def _remove_stale_registration():
    """Recover when Blender installs over an enabled extension instance."""
    cancel_marker_host_collapse_timer()
    classes = PROPERTY_CLASSES + OPERATOR_CLASSES + GIZMO_CLASSES + UI_CLASSES

    # v0.1.25 and earlier registered a custom pin Gizmo. It is intentionally
    # absent from the new class tuple, so remove a live copy explicitly during
    # an in-place development update.
    stale_pin = getattr(bpy.types, "IMPACTION_GT_focus_pin", None)
    if stale_pin is None:
        try:
            stale_pin = bpy.types.Gizmo.bl_rna_get_subclass_py("IMPACTION_GT_focus_pin", None)
        except (AttributeError, RuntimeError, TypeError):
            stale_pin = None
    if stale_pin is not None:
        try:
            bpy.utils.unregister_class(stale_pin)
        except (RuntimeError, TypeError, ValueError):
            pass

    # RNA pointer/collection properties must release old PropertyGroup types
    # before those classes can be unregistered.
    for owner, name in (
        (bpy.types.Scene, "impaction"),
        (bpy.types.Object, "impaction_frames"),
        (bpy.types.Object, "impaction_fps"),
        (bpy.types.Object, "impaction_grid_anchor"),
        (bpy.types.Object, "impaction_grid_initialized"),
    ):
        if hasattr(owner, name):
            try:
                delattr(owner, name)
            except (AttributeError, RuntimeError):
                pass

    # Remove persistent callbacks left by an older module object.
    handler_names = {
        "frame_change_post", "depsgraph_update_post", "undo_post", "redo_post", "save_pre", "load_post",
    }
    for handlers in (
        bpy.app.handlers.frame_change_post, bpy.app.handlers.depsgraph_update_post,
        bpy.app.handlers.undo_post, bpy.app.handlers.redo_post,
        bpy.app.handlers.save_pre, bpy.app.handlers.load_post,
    ):
        for callback in tuple(handlers):
            if (getattr(callback, "__name__", "") in handler_names
                    and getattr(callback, "__module__", "").endswith(".impaction_runtime")):
                try:
                    handlers.remove(callback)
                except ValueError:
                    pass

    for cls in reversed(classes):
        existing = _registered_class(cls)
        if existing is not None:
            try:
                bpy.utils.unregister_class(existing)
            except (RuntimeError, TypeError, ValueError):
                pass


def _assert_no_foreign_impact_registration():
    """Do not tear down a separately installed legacy Impact extension.

    Setup disables the legacy package before enabling this one.  This guard is
    for manual installs and makes the conflict explicit instead of allowing
    the hot-reload cleanup below to unregister classes owned by another add-on.
    """
    package_root = str(__package__ or __name__)
    classes = PROPERTY_CLASSES + OPERATOR_CLASSES + GIZMO_CLASSES + UI_CLASSES
    for cls in classes:
        existing = _registered_class(cls)
        if existing is None:
            continue
        owner = str(getattr(existing, "__module__", ""))
        if owner == package_root or owner.startswith(f"{package_root}."):
            continue
        raise RuntimeError(
            "Roblox Animator Impact cannot run beside the legacy "
            "Impaction Impact Frames extension. Disable the legacy extension "
            "first; its saved Impact Frames data will remain available."
        )


def register():
    _assert_no_foreign_impact_registration()
    _remove_stale_registration()
    register_properties()
    for cls in OPERATOR_CLASSES:
        bpy.utils.register_class(cls)
    register_operator_keymaps()
    for cls in GIZMO_CLASSES:
        bpy.utils.register_class(cls)
    for cls in UI_CLASSES:
        bpy.utils.register_class(cls)
    register_runtime()


def unregister():
    cancel_marker_host_collapse_timer()
    unregister_runtime()
    unregister_operator_keymaps()
    for cls in reversed(UI_CLASSES):
        existing = _registered_class(cls)
        if existing is not None:
            bpy.utils.unregister_class(existing)
    for cls in reversed(GIZMO_CLASSES):
        existing = _registered_class(cls)
        if existing is not None:
            bpy.utils.unregister_class(existing)
    for cls in reversed(OPERATOR_CLASSES):
        existing = _registered_class(cls)
        if existing is not None:
            bpy.utils.unregister_class(existing)
    unregister_properties()
    clear_shader_cache()
