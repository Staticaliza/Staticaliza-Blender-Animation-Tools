# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# <pep8 compliant>

# Credits to Staticaliza for most features.
# Credits to Roman Volodin, roman.volodin@gmail.com for their "Dynamic Parent" 2.0.2 (Blender 4 compatable) extension.

ADDON_VERSION = (1, 3, 47)

bl_info = {
    "name": "Roblox Animator Utils",
    "blender": (4, 3, 0),
    "version": ADDON_VERSION,
    "category": "Animation"
}

import bpy
import gpu
import addon_utils
import hashlib
import importlib
import json
import math
import os
import tempfile
import time
import tomllib
import urllib.error
import urllib.request
import zipfile
from mathutils import Color, Vector, Matrix
from gpu_extras.batch import batch_for_shader
from bpy.app.handlers import persistent

_state = {
    "enabled": False,
    "handle_view": None,
    "handle_pixel": None,
    "shader_3d": None,
    "shader_3d_mode": "UNIFORM",
    "shader_2d": None,
    "mesh_batches": [],
    "raycast_fixed": {},
    "yellow_fixed": {},
    "yellow_modes": {},
    "yellow_hidden": False,
    "unparent_rel_cache": {},
    "unparent_handler_mute": False,
    "last_error": "",
    "smart_material_processed_rigs": set(),
    "material_import_baseline": None,
    "extension_update_running": False,
    "extension_update_lock_waits": 0,
    "roblox_constraints_normalized": set(),
    "roblox_serializer_patch": None,
    "roblox_export_execute_patch": None,
    "roblox_import_execute_patch": None,
    "unparent_export_armature": None,
    "smart_material_scan_pending": False,
    "roblox_compatibility_scan_pending": False,
    "armature_overlay_saved": {},
    "part_pivot_syncing": False,
    "part_pivot_armature": 0,
    "part_pivot_bone": "",
    "part_pivot_object": "",
    "part_pivot_object_local": None,
    "part_pivot_saved": None,
    "part_pivot_last_signature": None,
    "part_pivot_cursor_visibility": {},
    "camera_fov_syncing": False,
    "camera_view_spaces": {},
    "pose_tool_active_session": False,
    "pose_last_tool": "",
}

ARMATURE_OVERLAY_STATE_KEY = "_staticaliza_advanced_overlay_state"
CLOTHING_LAYER_OFFSET_MODIFIER = "Staticaliza Clothing Offset"
IMPORTED_MATERIAL_DISPLAY_COLOR = tuple(
    Color((231.0 / 255.0,) * 3).from_srgb_to_scene_linear()
) + (1.0,)

_keymaps = []

UNP_PROP = "staticaliza_unparent_marker"
UNP_STATE_KEY = "staticaliza_unparent_state"
REL_K_PARENT = "staticaliza_rel_saved_parent"
REL_K_CONNECT = "staticaliza_rel_saved_connect"
UNP_VIS_CONSTRAINT = "STATICALIZA_UNPARENT_VIS"
DP_AUTO_UNPARENT_START_KEY = "staticaliza_auto_unparent_start"
DP_AUTO_UNPARENT_PROPERTY_PREFIX = "staticaliza_dp_unp_"

REL_K_HEAD = "staticaliza_rel_saved_head"
REL_K_TAIL = "staticaliza_rel_saved_tail"
REL_K_ROLL = "staticaliza_rel_saved_roll"

DP_BL_INFO = {
    "name": "Dynamic Parent",
    "author": "Roman Volodin, roman.volodin@gmail.com",
    "version": (2, 0, 2),
    "blender": (4, 0, 0),
    "location": "View3D > Tool Panel",
    "description": "Allows to create and disable an animated ChildOf constraint",
    "category": "Animation",
}

def get_rotation_mode(obj):
    if obj.rotation_mode in ("QUATERNION", "AXIS_ANGLE"):
        return obj.rotation_mode.lower()
    return "euler"

def get_selected_objects(context):
    if context.mode not in ("OBJECT", "POSE"):
        return

    if context.mode == "OBJECT":
        active = context.active_object
        selected = [obj for obj in context.selected_objects if obj != active]

    if context.mode == "POSE":
        active = context.active_pose_bone
        selected = [bone for bone in context.selected_pose_bones if bone != active]

    selected.append(active)
    return selected

def get_last_dynamic_parent_constraint(obj):
    if not obj.constraints:
        return
    for constraint in reversed(obj.constraints):
        if constraint.name.startswith("DP_") and constraint.influence > 0.5:
            return constraint


def _dp_auto_unparent_property_name(constraint):
    name = str(getattr(constraint, "name", ""))
    digest = hashlib.sha1(name.encode("utf-8")).hexdigest()[:16]
    return f"{DP_AUTO_UNPARENT_PROPERTY_PREFIX}{digest}"


def _dp_auto_unparent_property_names(constraint):
    if constraint is None:
        return ()
    return (
        _dp_auto_unparent_property_name(constraint),
        f"{DP_AUTO_UNPARENT_START_KEY}::{constraint.name}",
    )


def _dp_auto_unparent_start(owner, constraint):
    if not isinstance(owner, bpy.types.PoseBone) or constraint is None:
        return None
    for property_name in _dp_auto_unparent_property_names(constraint):
        try:
            value = owner.get(property_name, None)
            if value is not None:
                return int(value)
        except (AttributeError, KeyError, TypeError, ValueError):
            continue
    return None


def _dp_auto_unparent_start_frames(owner):
    if not isinstance(owner, bpy.types.PoseBone):
        return set()

    prefixes = (
        DP_AUTO_UNPARENT_PROPERTY_PREFIX,
        f"{DP_AUTO_UNPARENT_START_KEY}::",
    )
    frames = set()
    try:
        property_names = tuple(owner.keys())
    except (AttributeError, TypeError):
        return frames

    for property_name in property_names:
        if not str(property_name).startswith(prefixes):
            continue
        try:
            frames.add(int(owner[property_name]))
        except (KeyError, TypeError, ValueError):
            continue
    return frames


def _set_keyframe_handles_auto(target, frame):
    id_data = getattr(target, "id_data", None) or target
    animation_data = getattr(id_data, "animation_data", None)
    action = getattr(animation_data, "action", None)
    if action is None:
        return 0

    changed = 0
    target_frame = float(frame)
    for fcurve in action.fcurves:
        curve_changed = False
        for key in fcurve.keyframe_points:
            if abs(float(key.co.x) - target_frame) > 1.0e-5:
                continue
            if key.handle_left_type != "AUTO":
                key.handle_left_type = "AUTO"
                changed += 1
                curve_changed = True
            if key.handle_right_type != "AUTO":
                key.handle_right_type = "AUTO"
                changed += 1
                curve_changed = True
        if curve_changed:
            fcurve.update()
    return changed


def insert_keyframe(obj, frame):
    rotation_mode = get_rotation_mode(obj)
    data_paths = (
        "location",
        f"rotation_{rotation_mode}",
        "scale",
    )
    for data_path in data_paths:
        obj.keyframe_insert(data_path = data_path, frame = frame)
    _set_keyframe_handles_auto(obj, frame)


def _insert_evaluated_transform_key(obj, frame):
    scene = bpy.context.scene
    saved_frame = int(scene.frame_current)
    try:
        if saved_frame != int(frame):
            scene.frame_set(int(frame))
            bpy.context.view_layer.update()
        insert_keyframe(obj, int(frame))
    finally:
        if int(scene.frame_current) != saved_frame:
            scene.frame_set(saved_frame)
            bpy.context.view_layer.update()

def insert_keyframe_constraint(constraint, frame):
    constraint.keyframe_insert(data_path = "influence", frame = frame)
    _set_keyframe_handles_auto(constraint, frame)

def dp_keyframe_insert_obj(obj):
    obj.keyframe_insert(data_path = "location")
    if obj.rotation_mode == "QUATERNION":
        obj.keyframe_insert(data_path = "rotation_quaternion")
    elif obj.rotation_mode == "AXIS_ANGLE":
        obj.keyframe_insert(data_path = "rotation_axis_angle")
    else:
        obj.keyframe_insert(data_path = "rotation_euler")
    obj.keyframe_insert(data_path = "scale")
    _set_keyframe_handles_auto(obj, bpy.context.scene.frame_current)

def dp_keyframe_insert_pbone(arm, pbone):
    arm.keyframe_insert(data_path = 'pose.bones["' + pbone.name + '"].location')
    if pbone.rotation_mode == "QUATERNION":
        arm.keyframe_insert(
            data_path = 'pose.bones["' + pbone.name + '"].rotation_quaternion'
        )
    elif pbone.rotation_mode == "AXIS_ANGLE":
        arm.keyframe_insert(
            data_path = 'pose.bones["' + pbone.name + '"].rotation_axis_angle'
        )
    else:
        arm.keyframe_insert(data_path = 'pose.bones["' + pbone.name + '"].rotation_euler')
    arm.keyframe_insert(data_path = 'pose.bones["' + pbone.name + '"].scale')
    _set_keyframe_handles_auto(arm, bpy.context.scene.frame_current)

def dp_create_dynamic_parent_obj(op):
    obj = bpy.context.active_object
    scn = bpy.context.scene
    list_selected_obj = bpy.context.selected_objects

    if len(list_selected_obj) == 2:
        i = list_selected_obj.index(obj)
        list_selected_obj.pop(i)
        parent_obj = list_selected_obj[0]

        dp_keyframe_insert_obj(obj)
        bpy.ops.object.constraint_add_with_targets(type = "CHILD_OF")
        last_constraint = obj.constraints[-1]

        if parent_obj.type == "ARMATURE":
            last_constraint.subtarget = parent_obj.data.bones.active.name
            last_constraint.name = "DP_" + last_constraint.target.name + "." + last_constraint.subtarget
        else:
            last_constraint.name = "DP_" + last_constraint.target.name

        C = bpy.context.copy()
        C["constraint"] = last_constraint
        bpy.ops.constraint.childof_set_inverse(
            constraint = last_constraint.name,
            owner = "OBJECT"
        )

        current_frame = scn.frame_current
        scn.frame_current = current_frame - 1
        obj.constraints[last_constraint.name].influence = 0
        obj.keyframe_insert(
            data_path = 'constraints["' + last_constraint.name + '"].influence'
        )

        scn.frame_current = current_frame
        obj.constraints[last_constraint.name].influence = 1
        obj.keyframe_insert(
            data_path = 'constraints["' + last_constraint.name + '"].influence'
        )
        _set_keyframe_handles_auto(obj, current_frame - 1)
        _set_keyframe_handles_auto(obj, current_frame)

        for ob in list_selected_obj:
            ob.select_set(False)

        obj.select_set(True)
    else:
        op.report({"ERROR"}, "Two objects must be selected")

def dp_create_dynamic_parent_pbone(op):
    arm = bpy.context.active_object
    pbone = bpy.context.active_pose_bone
    scn = bpy.context.scene
    list_selected_obj = bpy.context.selected_objects

    if len(list_selected_obj) == 2 or len(list_selected_obj) == 1:
        if len(list_selected_obj) == 2:
            i = list_selected_obj.index(arm)
            list_selected_obj.pop(i)
            parent_obj = list_selected_obj[0]
            if parent_obj.type == "ARMATURE":
                parent_obj_pbone = parent_obj.data.bones.active
                if not parent_obj_pbone.select:
                    op.report({"ERROR"}, "At least two bones must be selected")
                    return
        else:
            parent_obj = arm
            selected_bones = bpy.context.selected_pose_bones
            selected_bones.remove(pbone)
            if not selected_bones:
                op.report({"ERROR"}, "At least two bones must be selected")
                return
            parent_obj_pbone = selected_bones[0]

        dp_keyframe_insert_pbone(arm, pbone)
        bpy.ops.pose.constraint_add_with_targets(type = "CHILD_OF")
        last_constraint = pbone.constraints[-1]

        if parent_obj.type == "ARMATURE":
            last_constraint.subtarget = parent_obj_pbone.name
            last_constraint.name = "DP_" + last_constraint.target.name + "." + last_constraint.subtarget
        else:
            last_constraint.name = "DP_" + last_constraint.target.name

        C = bpy.context.copy()
        C["constraint"] = last_constraint
        bpy.ops.constraint.childof_set_inverse(
            constraint = last_constraint.name,
            owner = "BONE"
        )

        current_frame = scn.frame_current
        scn.frame_current = current_frame - 1
        pbone.constraints[last_constraint.name].influence = 0
        arm.keyframe_insert(
            data_path = 'pose.bones["'
            + pbone.name
            + '"].constraints["'
            + last_constraint.name
            + '"].influence'
        )

        scn.frame_current = current_frame
        pbone.constraints[last_constraint.name].influence = 1
        arm.keyframe_insert(
            data_path = 'pose.bones["'
            + pbone.name
            + '"].constraints["'
            + last_constraint.name
            + '"].influence'
        )
        _set_keyframe_handles_auto(arm, current_frame - 1)
        _set_keyframe_handles_auto(arm, current_frame)
    else:
        op.report({"ERROR"}, "Two objects must be selected")

def disable_constraint(obj, const, frame):
    if isinstance(obj, bpy.types.PoseBone):
        matrix_final = obj.matrix.copy()
    else:
        matrix_final = obj.matrix_world.copy()

    _insert_evaluated_transform_key(obj, frame - 1)
    const.influence = 1
    insert_keyframe_constraint(const, frame = frame - 1)

    const.influence = 0
    if isinstance(obj, bpy.types.PoseBone):
        obj.matrix = matrix_final
    else:
        obj.matrix_world = matrix_final

    insert_keyframe(obj, frame = frame)
    insert_keyframe_constraint(const, frame = frame)
    return

def _dp_curve_distance_from_frame(fcurve, frame):
    points = sorted(
        (
            int(round(float(key.co.x))),
            float(key.co.y),
        )
        for key in fcurve.keyframe_points
    )
    if not points:
        return float("inf")

    active_frames = [point_frame for point_frame, value in points if value > 0.5]
    if not active_frames:
        return min(abs(int(frame) - point_frame) for point_frame, _ in points)

    start_frame = min(active_frames)
    end_candidates = [
        point_frame
        for point_frame, value in points
        if point_frame > start_frame and value <= 0.5
    ]
    end_frame = min(end_candidates) if end_candidates else max(active_frames)
    if start_frame <= int(frame) <= end_frame:
        return 0
    return min(abs(int(frame) - start_frame), abs(int(frame) - end_frame))


def dp_clear(obj, pbone):
    if not obj:
        return False

    target = pbone if pbone else obj
    constraints = [
        constraint
        for constraint in target.constraints
        if constraint.name.startswith("DP_")
    ]
    if not constraints:
        return False

    action = obj.animation_data.action if obj.animation_data else None
    frame = int(bpy.context.scene.frame_current)
    candidates = []

    for constraint in constraints:
        fcurve = None
        if action:
            try:
                data_path = constraint.path_from_id("influence")
            except Exception:
                data_path = ""
            fcurve = _fcurve_find(action, data_path) if data_path else None
        distance = _dp_curve_distance_from_frame(fcurve, frame) if fcurve else float("inf")
        candidates.append((distance, constraint.name, constraint, fcurve))

    _, _, constraint, fcurve = min(candidates, key = lambda item: (item[0], item[1]))
    auto_unparent_start = _dp_auto_unparent_start(pbone, constraint)
    auto_unparent_properties = (
        _dp_auto_unparent_property_names(constraint)
        if auto_unparent_start is not None
        else ()
    )
    generated_frames = set()
    if fcurve:
        generated_frames.update(
            int(round(float(key.co.x))) for key in fcurve.keyframe_points
        )
        action.fcurves.remove(fcurve)

    if action and generated_frames:
        if pbone:
            transform_paths = {
                _pose_dp(pbone.name, "location"),
                _pose_dp(pbone.name, "scale"),
                _pose_dp(pbone.name, "rotation_euler"),
                _pose_dp(pbone.name, "rotation_quaternion"),
                _pose_dp(pbone.name, "rotation_axis_angle"),
            }
        else:
            transform_paths = {
                "location",
                "scale",
                "rotation_euler",
                "rotation_quaternion",
                "rotation_axis_angle",
            }

        for transform_curve in list(action.fcurves):
            if transform_curve.data_path not in transform_paths:
                continue
            keyframe_points = transform_curve.keyframe_points
            for index in range(len(keyframe_points) - 1, -1, -1):
                key = keyframe_points[index]
                if int(round(float(key.co.x))) in generated_frames:
                    keyframe_points.remove(key)
            if not transform_curve.keyframe_points:
                action.fcurves.remove(transform_curve)
            else:
                transform_curve.update()

    target.constraints.remove(constraint)
    if pbone and auto_unparent_start is not None:
        for property_name in auto_unparent_properties:
            if property_name in pbone:
                del pbone[property_name]
        _unparent_remove_start_key(
            bpy.context,
            obj,
            pbone,
            auto_unparent_start,
        )
    return True

def _tag_redraw_all_view3d():
    wm = bpy.context.window_manager
    for window in wm.windows:
        for area in window.screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()

def _ensure_shader_3d():
    if _state["shader_3d"] is not None:
        return _state["shader_3d"]

    _state["last_error"] = ""
    try:
        _state["shader_3d"] = gpu.shader.from_builtin("UNIFORM_COLOR")
        _state["shader_3d_mode"] = "UNIFORM"
    except Exception:
        _state["shader_3d"] = gpu.shader.from_builtin("FLAT_COLOR")
        _state["shader_3d_mode"] = "VERTEX"

    return _state["shader_3d"]

def _ensure_shader_2d():
    if _state["shader_2d"] is not None:
        return _state["shader_2d"]

    vert = """
    in vec2 pos;
    uniform vec2 u_viewport;
    void main()
    {
        vec2 ndc = (pos / u_viewport) * 2.0 - 1.0;
        gl_Position = vec4(ndc.xy, 0.0, 1.0);
    }
    """
    frag = """
    uniform vec4 color;
    out vec4 FragColor;
    void main()
    {
        FragColor = color;
    }
    """
    _state["shader_2d"] = gpu.types.GPUShader(vert, frag)
    return _state["shader_2d"]

def _as_p4(v):
    try:
        if isinstance(v, Vector):
            if len(v) == 4:
                return Vector((float(v.x), float(v.y), float(v.z), float(v.w)))
            if len(v) == 3:
                return Vector((float(v.x), float(v.y), float(v.z), 1.0))
    except Exception:
        pass

    if isinstance(v, (list, tuple)) and len(v) >= 3:
        try:
            return Vector((float(v[0]), float(v[1]), float(v[2]), 1.0))
        except Exception:
            pass

    return Vector((0.0, 0.0, 0.0, 1.0))

def _world_to_bone_local_p4(eval_arm, pb, world_point):
    arm_mw = eval_arm.matrix_world
    try:
        arm_inv = arm_mw.inverted()
    except Exception:
        arm_inv = Matrix.Identity(4)

    try:
        pb_inv = pb.matrix.inverted()
    except Exception:
        pb_inv = Matrix.Identity(4)

    return pb_inv @ (arm_inv @ _as_p4(world_point))

def _bone_local_to_world(eval_arm, pb, local_p4):
    arm_mw = eval_arm.matrix_world
    try:
        out = arm_mw @ (pb.matrix @ _as_p4(local_p4))
    except Exception:
        out = arm_mw @ _as_p4((0.0, 0.0, 0.0))
    return Vector((float(out.x), float(out.y), float(out.z)))

def _is_object_visible(obj, context):
    wm = getattr(context, "window_manager", None)
    scn = getattr(context, "scene", None)
    if wm and not wm.onion_skin_skip_hidden:
        return True
    if not scn:
        return True
    if obj.hide_viewport:
        return False
    if obj.hide_get():
        return False
    try:
        if hasattr(obj, "visible_get"):
            return obj.visible_get(view_layer=context.view_layer)
    except TypeError:
        try:
            return obj.visible_get()
        except Exception:
            return True
    return True

def _active_armature(context):
    ob = context.active_object
    if ob and ob.type == "ARMATURE":
        return ob
    for ob in context.selected_objects:
        if ob.type == "ARMATURE":
            return ob
    ob = context.active_object
    if ob and hasattr(ob, "find_armature"):
        arm = ob.find_armature()
        if arm and arm.type == "ARMATURE":
            return arm
    return None

def _targets(context):
    arm = _active_armature(context)
    items = []

    if arm and _is_object_visible(arm, context):
        items.append(arm)

    if not arm:
        return items, None

    for obj in context.view_layer.objects:
        if obj == arm:
            continue
        if not _is_object_visible(obj, context):
            continue

        include = False

        if obj.parent == arm:
            include = True
        if obj.parent_type == "BONE" and obj.parent == arm:
            include = True

        if not include:
            for m in obj.modifiers:
                if m.type == "ARMATURE" and getattr(m, "object", None) == arm:
                    include = True
                    break

        if not include:
            for c in obj.constraints:
                t = getattr(c, "target", None)
                st = getattr(c, "subtarget", "")
                if t == arm and st:
                    include = True
                    break
                if c.type == "CHILD_OF" and t == arm:
                    include = True
                    break
                if c.type == "COPY_TRANSFORMS" and t == arm:
                    include = True
                    break
                if c.type == "COPY_LOCATION" and t == arm:
                    include = True
                    break
                if c.type == "COPY_ROTATION" and t == arm:
                    include = True
                    break
                if c.type == "COPY_SCALE" and t == arm:
                    include = True
                    break

        if include:
            items.append(obj)

    return list(dict.fromkeys(items)), arm

def _is_unmovable(pb):
    locked_loc = all(pb.lock_location)
    locked_scale = all(pb.lock_scale)
    locked_rot = all(pb.lock_rotation)
    if hasattr(pb, "lock_rotation_w"):
        locked_rot = locked_rot and bool(pb.lock_rotation_w)
    return locked_loc and locked_rot and locked_scale

def _runtime_needed(context):
    wm = getattr(context, "window_manager", None)
    if not wm:
        return bool(_state["yellow_modes"])
    return bool(wm.onion_skin_enabled) or bool(_state["yellow_modes"])

def _enable_runtime():
    if _state["enabled"]:
        return
    _state["enabled"] = True
    _state["handle_view"] = bpy.types.SpaceView3D.draw_handler_add(_draw_view, (), "WINDOW", "POST_VIEW")
    _state["handle_pixel"] = bpy.types.SpaceView3D.draw_handler_add(_draw_pixel, (), "WINDOW", "POST_PIXEL")
    _tag_redraw_all_view3d()

def _disable_runtime():
    if not _state["enabled"]:
        return

    _state["enabled"] = False

    if _state["handle_view"] is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_state["handle_view"], "WINDOW")
        _state["handle_view"] = None

    if _state["handle_pixel"] is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_state["handle_pixel"], "WINDOW")
        _state["handle_pixel"] = None

    _state["mesh_batches"] = []
    _state["raycast_fixed"] = {}
    _tag_redraw_all_view3d()

def _circle_tris_2d(center_xy, radius, segments = 18):
    if radius <= 0.0:
        return []

    cx, cy = center_xy
    verts = []

    for i in range(segments):
        a0 = (i / segments) * (math.pi * 2.0)
        a1 = ((i + 1) / segments) * (math.pi * 2.0)

        v0 = (cx, cy)
        v1 = (cx + math.cos(a0) * radius, cy + math.sin(a0) * radius)
        v2 = (cx + math.cos(a1) * radius, cy + math.sin(a1) * radius)

        verts.extend((v0, v1, v2))

    return verts

def _circle_scale_from_dist(dist_px):
    min_scale = 1.25
    max_scale = 3.0
    min_px = 14.0
    max_px = 120.0

    if dist_px <= min_px:
        return min_scale
    if dist_px >= max_px:
        return max_scale

    t = (dist_px - min_px) / (max_px - min_px)
    t = t * t * (3.0 - (2.0 * t))
    return min_scale + (t * (max_scale - min_scale))

def _bounds_init(p):
    return [p.x, p.y, p.z, p.x, p.y, p.z]

def _bounds_add(b, p):
    if p.x < b[0]:
        b[0] = p.x
    if p.y < b[1]:
        b[1] = p.y
    if p.z < b[2]:
        b[2] = p.z
    if p.x > b[3]:
        b[3] = p.x
    if p.y > b[4]:
        b[4] = p.y
    if p.z > b[5]:
        b[5] = p.z

def _bounds_center(b):
    return Vector(((b[0] + b[3]) * 0.5, (b[1] + b[4]) * 0.5, (b[2] + b[5]) * 0.5))

def _collect_world_shape_from_largest_components(context, depsgraph, arm, eval_arm, only_names, objs = None):
    if objs is None:
        objs, _ = _targets(context)

    min_w = 0.05
    per_bone = {bn: [] for bn in only_names}

    for obj in objs:
        if obj.type != "MESH":
            continue
        if not _is_object_visible(obj, context):
            continue

        eval_obj = obj.evaluated_get(depsgraph)
        mw = eval_obj.matrix_world

        mesh = eval_obj.to_mesh(preserve_all_data_layers = False, depsgraph = depsgraph)
        if not mesh:
            continue

        for bn in only_names:
            vg = None
            try:
                vg = obj.vertex_groups.get(bn)
            except Exception:
                vg = None
            if not vg:
                continue

            vg_i = int(vg.index)

            b_world = None
            for v in mesh.vertices:
                w = 0.0
                for g in v.groups:
                    if int(g.group) == vg_i:
                        w = float(g.weight)
                        break
                if w < float(min_w):
                    continue

                p_world = mw @ v.co
                if b_world is None:
                    b_world = _bounds_init(p_world)
                else:
                    _bounds_add(b_world, p_world)

            if b_world is None:
                continue

            dx = float(b_world[3] - b_world[0])
            dy = float(b_world[4] - b_world[1])
            dz = float(b_world[5] - b_world[2])
            vol = max(0.0, dx) * max(0.0, dy) * max(0.0, dz)

            per_bone[bn].append((vol, b_world))

        eval_obj.to_mesh_clear()

    out = {}
    keep_ratio = 0.25
    keep_max = 6

    for bn, items in per_bone.items():
        if not items:
            continue

        items.sort(key = lambda x: float(x[0]), reverse = True)
        max_vol = float(items[0][0])
        cutoff = max_vol * keep_ratio

        keep = []
        for vol, b in items:
            if len(keep) >= keep_max:
                break
            if len(keep) == 0 or float(vol) >= cutoff:
                keep.append(b)

        merged = None
        for b in keep:
            if merged is None:
                merged = list(b)
            else:
                merged[0] = min(merged[0], b[0])
                merged[1] = min(merged[1], b[1])
                merged[2] = min(merged[2], b[2])
                merged[3] = max(merged[3], b[3])
                merged[4] = max(merged[4], b[4])
                merged[5] = max(merged[5], b[5])

        if merged is not None:
            out[bn] = merged

    return out

def _rig_local_bottom_center(matrix_world, points):
    try:
        matrix_inverse = matrix_world.inverted()
    except Exception:
        matrix_inverse = Matrix.Identity(4)

    rig_bounds = None
    for point in points:
        local = matrix_inverse @ Vector((point.x, point.y, point.z, 1.0))
        local_point = Vector((float(local.x), float(local.y), float(local.z)))
        if rig_bounds is None:
            rig_bounds = _bounds_init(local_point)
        else:
            _bounds_add(rig_bounds, local_point)

    if rig_bounds is None:
        return None

    center_x = (float(rig_bounds[0]) + float(rig_bounds[3])) * 0.5
    center_y = (float(rig_bounds[1]) + float(rig_bounds[4])) * 0.5
    bottom_z = float(rig_bounds[2])
    world = matrix_world @ Vector((center_x, center_y, bottom_z, 1.0))
    return Vector((float(world.x), float(world.y), float(world.z)))


def _rig_local_lower_bone_endpoint(eval_arm, pose_bone):
    endpoint = pose_bone.head if pose_bone.head.z <= pose_bone.tail.z else pose_bone.tail
    return eval_arm.matrix_world @ endpoint


def _pose_bone_numeric_family_levels(eval_arm, pose_bone):
    canonical_name = _strip_blender_numeric_suffix(pose_bone.name)
    levels = []

    canonical_bone = eval_arm.pose.bones.get(canonical_name)
    if canonical_bone is not None:
        levels.append({canonical_bone.name})

    prefix = f"{canonical_name}."
    variants = []
    for bone in eval_arm.pose.bones:
        if not bone.name.startswith(prefix):
            continue
        suffix = bone.name[len(prefix):]
        if suffix.isdigit():
            variants.append((int(suffix), bone.name))

    if variants:
        variants.sort(key = lambda item: (item[0], item[1]))
        levels.append({name for _number, name in variants})

    if not levels:
        levels.append({pose_bone.name})

    return levels


def _node_tree_has_linked_base_color(node_tree, visited = None):
    if node_tree is None:
        return False
    if visited is None:
        visited = set()

    pointer = node_tree.as_pointer()
    if pointer in visited:
        return False
    visited.add(pointer)

    for node in node_tree.nodes:
        if node.type == "BSDF_PRINCIPLED":
            base_color = node.inputs.get("Base Color")
            if base_color and base_color.is_linked:
                return True
        if (
            node.type == "GROUP"
            and getattr(node, "node_tree", None)
            and _node_tree_has_linked_base_color(node.node_tree, visited)
        ):
            return True
    return False


def _object_has_linked_base_color(obj):
    materials = getattr(getattr(obj, "data", None), "materials", ())
    return any(
        _node_tree_has_linked_base_color(getattr(material, "node_tree", None))
        for material in materials
        if material is not None
    )


def _rigid_object_smart_anchor(arm, eval_arm, eval_obj, controller_bone_name):
    points = []
    for corner in eval_obj.bound_box:
        points.append(eval_obj.matrix_world @ Vector(corner))
    if not points:
        return None, points, 0.0

    pose_bone = eval_arm.pose.bones.get(controller_bone_name)
    rest_bone = arm.data.bones.get(controller_bone_name)
    if pose_bone is None or rest_bone is None:
        world_anchor = _rig_local_bottom_center(eval_arm.matrix_world, points)
        if world_anchor is None:
            return None, points, 0.0
        local_anchor = eval_obj.matrix_world.inverted() @ _as_p4(world_anchor)
        return local_anchor, points, 0.0

    current_bone_world = eval_arm.matrix_world @ pose_bone.matrix
    rest_bone_world = arm.matrix_world @ rest_bone.matrix_local
    try:
        pose_delta = current_bone_world @ rest_bone_world.inverted()
        pose_delta_inverse = pose_delta.inverted()
        rig_inverse = eval_arm.matrix_world.inverted()
        object_inverse = eval_obj.matrix_world.inverted()
    except Exception:
        return None, points, 0.0

    rest_rig_bounds = None
    for point in points:
        rest_world = pose_delta_inverse @ _as_p4(point)
        rest_rig = rig_inverse @ rest_world
        rest_point = Vector((float(rest_rig.x), float(rest_rig.y), float(rest_rig.z)))
        if rest_rig_bounds is None:
            rest_rig_bounds = _bounds_init(rest_point)
        else:
            _bounds_add(rest_rig_bounds, rest_point)

    if rest_rig_bounds is None:
        return None, points, 0.0

    rest_anchor_rig = Vector((
        (float(rest_rig_bounds[0]) + float(rest_rig_bounds[3])) * 0.5,
        (float(rest_rig_bounds[1]) + float(rest_rig_bounds[4])) * 0.5,
        float(rest_rig_bounds[2]),
        1.0,
    ))
    rest_anchor_world = eval_arm.matrix_world @ rest_anchor_rig
    current_anchor_world = pose_delta @ rest_anchor_world
    local_anchor = object_inverse @ current_anchor_world

    dx = float(rest_rig_bounds[3] - rest_rig_bounds[0])
    dy = float(rest_rig_bounds[4] - rest_rig_bounds[1])
    dz = float(rest_rig_bounds[5] - rest_rig_bounds[2])
    volume = max(0.0, dx) * max(0.0, dy) * max(0.0, dz)
    return local_anchor, points, volume


def _yellow_mode3_anchor(context, depsgraph, arm, eval_arm, objs, bone_name):
    pb = eval_arm.pose.bones.get(bone_name)
    if not pb:
        return None, "", None

    fallback = _rig_local_lower_bone_endpoint(eval_arm, pb)
    canonical_name = _strip_blender_numeric_suffix(pb.name)

    keep_ratio = 0.25
    keep_max = 6
    candidates = []

    # Prefer the canonical non-numbered bone. Only fall back through connected
    # Blender numeric variants, never unrelated child branches such as limbs.
    for level_names in _pose_bone_numeric_family_levels(eval_arm, pb):
        level_candidates = []

        for obj in objs or ():
            if obj.type != "MESH":
                continue
            if not _is_object_visible(obj, context):
                continue

            controller_bone_name = ""
            rigid_match = (
                obj.parent == arm
                and obj.parent_type == "BONE"
                and getattr(obj, "parent_bone", "") in level_names
            )
            if rigid_match:
                controller_bone_name = getattr(obj, "parent_bone", "")
            for constraint in obj.constraints:
                if (
                    getattr(constraint, "target", None) == arm
                    and getattr(constraint, "subtarget", "") in level_names
                ):
                    rigid_match = True
                    controller_bone_name = getattr(constraint, "subtarget", "")
                    break

            vertex_group_indices = set()
            if not rigid_match:
                try:
                    for descendant_name in level_names:
                        vertex_group = obj.vertex_groups.get(descendant_name)
                        if vertex_group:
                            vertex_group_indices.add(int(vertex_group.index))
                except Exception:
                    vertex_group_indices.clear()

            points = []
            object_local_anchor = None
            volume = 0.0

            if rigid_match:
                eval_obj = obj.evaluated_get(depsgraph)
                object_local_anchor, points, volume = _rigid_object_smart_anchor(
                    arm,
                    eval_arm,
                    eval_obj,
                    controller_bone_name,
                )
            elif vertex_group_indices:
                eval_obj = obj.evaluated_get(depsgraph)
                mesh = eval_obj.to_mesh(preserve_all_data_layers = False, depsgraph = depsgraph)
                if not mesh:
                    continue

                mw = eval_obj.matrix_world

                for min_w in (0.35, 0.2, 0.05):
                    points = []
                    for vertex in mesh.vertices:
                        weight = 0.0
                        for group in vertex.groups:
                            if int(group.group) in vertex_group_indices:
                                weight = max(weight, float(group.weight))
                        if weight >= float(min_w):
                            points.append(mw @ vertex.co)

                    if len(points) >= 12:
                        break

                eval_obj.to_mesh_clear()
            else:
                continue

            if not points:
                continue

            if object_local_anchor is None:
                bounds = _bounds_init(points[0])
                for point in points[1:]:
                    _bounds_add(bounds, point)

                dx = float(bounds[3] - bounds[0])
                dy = float(bounds[4] - bounds[1])
                dz = float(bounds[5] - bounds[2])
                volume = max(0.0, dx) * max(0.0, dy) * max(0.0, dz)
            level_candidates.append(
                (
                    volume,
                    points,
                    obj,
                    _object_has_linked_base_color(obj),
                    object_local_anchor,
                    _strip_blender_numeric_suffix(obj.name) == canonical_name,
                    obj.name == canonical_name,
                )
            )

        if level_candidates:
            exact_name = [
                candidate for candidate in level_candidates if candidate[6]
            ]
            matching_name = [
                candidate for candidate in level_candidates if candidate[5]
            ]
            preferred_candidates = exact_name or matching_name or level_candidates
            without_linked_base_color = [
                candidate for candidate in preferred_candidates if not candidate[3]
            ]
            candidates = without_linked_base_color or preferred_candidates
            break

    if not candidates:
        return fallback.copy(), "", None

    candidates.sort(key = lambda x: float(x[0]), reverse = True)
    max_vol = float(candidates[0][0])
    cutoff = max_vol * keep_ratio

    primary = candidates[0]
    if primary[4] is not None:
        eval_obj = primary[2].evaluated_get(depsgraph)
        local_anchor = primary[4].copy()
        world_anchor = eval_obj.matrix_world @ local_anchor
        return (
            Vector((float(world_anchor.x), float(world_anchor.y), float(world_anchor.z))),
            primary[2].name,
            local_anchor,
        )

    cloud = []
    kept = 0
    for (
        vol,
        points,
        _obj,
        _has_linked_base_color,
        _local_anchor,
        _matching_name,
        _exact_name,
    ) in candidates:
        if kept >= keep_max:
            break
        if kept == 0 or float(vol) >= cutoff:
            cloud.extend(points)
            kept += 1

    if not cloud:
        return fallback.copy(), "", None

    if len(cloud) > 8000:
        step = int(len(cloud) / 8000) + 1
        cloud = cloud[::step]

    bottom = _rig_local_bottom_center(eval_arm.matrix_world, cloud)
    return (bottom if bottom is not None else fallback.copy()), "", None


def _yellow_mode3_point(context, depsgraph, arm, eval_arm, objs, bone_name):
    return _yellow_mode3_anchor(
        context,
        depsgraph,
        arm,
        eval_arm,
        objs,
        bone_name,
    )[0]

def _yellow_capture(context, depsgraph, arm, eval_arm, objs, bone_name, mode, bounds_world_map):
    pb = eval_arm.pose.bones.get(bone_name)
    if not pb:
        return None

    arm_mw = eval_arm.matrix_world
    head = arm_mw @ pb.head
    tail = arm_mw @ pb.tail

    smart_object_name = ""
    smart_object_local = None

    if mode == 1:
        end = tail
    elif mode == 2:
        b_world = bounds_world_map.get(bone_name, None) if bounds_world_map else None
        if b_world:
            end = _bounds_center(b_world)
        else:
            end = (head + tail) * 0.5
    elif mode == 4:
        end = head
    else:
        end, smart_object_name, smart_object_local = _yellow_mode3_anchor(
            context,
            depsgraph,
            arm,
            eval_arm,
            objs,
            bone_name,
        )
        if end is None:
            end = tail

    draw_dots = True
    if _is_unmovable(pb):
        draw_dots = False

    if mode == 4:
        local_p4 = Vector((0.0, 0.0, 0.0, 1.0))
    else:
        try:
            local_p4 = _world_to_bone_local_p4(eval_arm, pb, end)
        except Exception:
            local_p4 = Vector((0.0, 0.0, 0.0, 1.0))

    packed = (end.copy(), local_p4.copy(), draw_dots, int(mode))
    if mode == 3 and smart_object_name and smart_object_local is not None:
        packed += (smart_object_name, smart_object_local.copy())
    return packed

def _yellow_refresh_runtime(context):
    if not getattr(context, "window_manager", None):
        return
    if _runtime_needed(context):
        _enable_runtime()
    else:
        _disable_runtime()
    _tag_redraw_all_view3d()

def _build_snapshot_data(context):
    scn = context.scene
    wm = context.window_manager
    depsgraph = context.evaluated_depsgraph_get()
    objs, arm = _targets(context)

    include_meshes = wm.onion_skin_include_meshes
    include_bones = wm.onion_skin_include_bones
    raycast = wm.onion_skin_raycast

    shader3d = _ensure_shader_3d()
    vertex_color = (_state["shader_3d_mode"] == "VERTEX")

    mesh_alpha = wm.onion_skin_opacity
    mesh_color = (1.0, 0.0, 0.0, mesh_alpha)

    mesh_batches = []
    raycast_fixed = {}

    if include_meshes:
        for obj in objs:
            if obj.type != "MESH":
                continue
            if not _is_object_visible(obj, context):
                continue

            eval_obj = obj.evaluated_get(depsgraph)
            mesh = eval_obj.to_mesh(preserve_all_data_layers = False, depsgraph = depsgraph)
            if not mesh:
                continue

            mw = eval_obj.matrix_world

            try:
                mesh.calc_loop_triangles()
            except Exception:
                eval_obj.to_mesh_clear()
                continue

            tri_pos = []
            verts = mesh.vertices
            for tri in mesh.loop_triangles:
                v0, v1, v2 = tri.vertices
                tri_pos.append(mw @ verts[v0].co)
                tri_pos.append(mw @ verts[v1].co)
                tri_pos.append(mw @ verts[v2].co)

            if tri_pos:
                if vertex_color:
                    cols = [mesh_color] * len(tri_pos)
                    mesh_batches.append(batch_for_shader(shader3d, "TRIS", {"pos": tri_pos, "color": cols}))
                else:
                    mesh_batches.append(batch_for_shader(shader3d, "TRIS", {"pos": tri_pos}))

            eval_obj.to_mesh_clear()

    if not arm or not include_bones or not raycast:
        return mesh_batches, raycast_fixed

    arm_eval = arm.evaluated_get(depsgraph)
    arm_mw = arm_eval.matrix_world

    for pb in arm_eval.pose.bones:
        head = arm_mw @ pb.head
        tail = arm_mw @ pb.tail
        end = tail

        draw_dots = True
        if pb.parent is None:
            draw_dots = False
        elif _is_unmovable(pb):
            draw_dots = False

        try:
            local_p4 = _world_to_bone_local_p4(arm_eval, pb, end)
        except Exception:
            local_p4 = Vector((0.0, 0.0, 0.0, 1.0))

        raycast_fixed[pb.name] = (end.copy(), local_p4.copy(), draw_dots, 1)

    return mesh_batches, raycast_fixed

def _capture_or_clear(context, enable_ghost):
    _state["last_error"] = ""

    if enable_ghost:
        _enable_runtime()
        try:
            bpy.context.view_layer.update()
            mesh_batches, raycast_fixed = _build_snapshot_data(context)
            _state["mesh_batches"] = mesh_batches
            _state["raycast_fixed"] = raycast_fixed
        except Exception as e:
            _state["last_error"] = str(e)
            _state["mesh_batches"] = []
            _state["raycast_fixed"] = {}
    else:
        _state["mesh_batches"] = []
        _state["raycast_fixed"] = {}

    if not _runtime_needed(context):
        _disable_runtime()

    _tag_redraw_all_view3d()

def _on_enabled_toggle(self, context):
    _capture_or_clear(context, self.onion_skin_enabled)

def _on_setting_change(self, context):
    if not self.onion_skin_enabled:
        return
    _capture_or_clear(context, True)


def _capture_gpu_draw_state():
    return (
        gpu.state.depth_test_get(),
        gpu.state.depth_mask_get(),
        gpu.state.blend_get(),
        gpu.state.line_width_get(),
    )


def _restore_gpu_draw_state(state):
    depth_test, depth_mask, blend, line_width = state
    gpu.state.depth_test_set(depth_test)
    gpu.state.depth_mask_set(depth_mask)
    gpu.state.blend_set(blend)
    gpu.state.line_width_set(line_width)


def _draw_view():
    context = bpy.context
    wm = getattr(context, "window_manager", None)
    if not wm or not wm.onion_skin_enabled:
        return
    if not _state["mesh_batches"]:
        return

    shader = _ensure_shader_3d()
    color = (1.0, 0.0, 0.0, wm.onion_skin_opacity)

    previous_state = _capture_gpu_draw_state()
    try:
        gpu.state.depth_test_set("LESS_EQUAL")
        gpu.state.depth_mask_set(False)
        gpu.state.blend_set("ALPHA")

        if _state["shader_3d_mode"] == "UNIFORM":
            shader.bind()
            shader.uniform_float("color", color)

        for batch in _state["mesh_batches"]:
            batch.draw(shader)
    finally:
        _restore_gpu_draw_state(previous_state)


def _yellow_current_world_point(depsgraph, eval_arm, pose_bone, packed):
    mode = int(packed[3]) if len(packed) >= 4 else 1
    if mode == 3 and len(packed) >= 6 and packed[4]:
        smart_object = bpy.data.objects.get(packed[4])
        if smart_object is not None:
            eval_object = smart_object.evaluated_get(depsgraph)
            current = eval_object.matrix_world @ _as_p4(packed[5])
            return Vector((float(current.x), float(current.y), float(current.z)))

    if mode == 4:
        return eval_arm.matrix_world @ pose_bone.matrix.to_translation()

    try:
        return _bone_local_to_world(eval_arm, pose_bone, packed[1])
    except Exception:
        return eval_arm.matrix_world @ pose_bone.tail


def _draw_raycast_layer(context, fixed_map, color_rgba):
    if not fixed_map:
        return

    region = getattr(context, "region", None)
    rv3d = getattr(context, "region_data", None)
    if not region or not rv3d:
        return

    from bpy_extras import view3d_utils

    arm = _active_armature(context)
    if not arm:
        return

    depsgraph = context.evaluated_depsgraph_get()
    eval_arm = arm.evaluated_get(depsgraph)

    shader2d = _ensure_shader_2d()
    shader2d.bind()
    shader2d.uniform_float("u_viewport", (float(region.width), float(region.height)))

    line_pos = []
    tri_pos = []
    line_pos_snap = []
    tri_pos_snap = []

    circle_base = 5.0
    green = (0.0, 1.0, 0.0, float(color_rgba[3]))

    for name, packed in fixed_map.items():
        if not packed or len(packed) < 2:
            continue

        fixed3d = packed[0]
        draw_dots = bool(packed[2]) if len(packed) >= 3 else True

        pb = eval_arm.pose.bones.get(name)
        if not pb:
            continue

        current3d = _yellow_current_world_point(depsgraph, eval_arm, pb, packed)

        fixed2d = view3d_utils.location_3d_to_region_2d(region, rv3d, fixed3d)
        curr2d = view3d_utils.location_3d_to_region_2d(region, rv3d, current3d)
        if not fixed2d or not curr2d:
            continue

        a = (fixed2d.x, fixed2d.y)
        b = (curr2d.x, curr2d.y)

        dx = a[0] - b[0]
        dy = a[1] - b[1]
        dist_px = math.sqrt((dx * dx) + (dy * dy))

        dist_world = (fixed3d - current3d).length
        snap_world = 0.05
        snapped = dist_world <= snap_world

        if snapped:
            line_pos_snap.extend((a, b))
        else:
            line_pos.extend((a, b))

        if draw_dots:
            if snapped:
                tri_pos_snap.extend(_circle_tris_2d(a, circle_base))
                tri_pos_snap.extend(_circle_tris_2d(b, circle_base))
            else:
                r = circle_base * _circle_scale_from_dist(dist_px)
                tri_pos.extend(_circle_tris_2d(a, circle_base))
                tri_pos.extend(_circle_tris_2d(b, r))

    if line_pos:
        shader2d.uniform_float("color", color_rgba)
        batch_for_shader(shader2d, "LINES", {"pos": line_pos}).draw(shader2d)

    if tri_pos:
        shader2d.uniform_float("color", color_rgba)
        batch_for_shader(shader2d, "TRIS", {"pos": tri_pos}).draw(shader2d)

    if line_pos_snap:
        shader2d.uniform_float("color", green)
        batch_for_shader(shader2d, "LINES", {"pos": line_pos_snap}).draw(shader2d)

    if tri_pos_snap:
        shader2d.uniform_float("color", green)
        batch_for_shader(shader2d, "TRIS", {"pos": tri_pos_snap}).draw(shader2d)

def _draw_pixel():
    context = bpy.context
    wm = getattr(context, "window_manager", None)
    if not wm:
        return
    if (not wm.onion_skin_enabled) and (not _state["yellow_modes"]):
        return

    previous_state = _capture_gpu_draw_state()
    try:
        gpu.state.depth_test_set("NONE")
        gpu.state.depth_mask_set(False)
        gpu.state.blend_set("NONE")
        gpu.state.line_width_set(4.0)

        if wm.onion_skin_enabled and wm.onion_skin_include_bones and wm.onion_skin_raycast:
            _draw_raycast_layer(context, _state["raycast_fixed"], (1.0, 0.0, 0.0, 1.0))

        if _state["yellow_modes"] and (not _state["yellow_hidden"]):
            _draw_raycast_layer(context, _state["yellow_fixed"], (1.0, 1.0, 0.0, 1.0))
    finally:
        _restore_gpu_draw_state(previous_state)

class ONION_SKIN_OT_ghost_toggle(bpy.types.Operator):
    bl_idname = "onion_skin.ghost_toggle"
    bl_label = "Toggle Ghost"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def execute(self, context):
        wm = context.window_manager
        enabling = not wm.onion_skin_enabled
        wm.onion_skin_enabled = enabling

        if enabling:
            wm.onion_skin_include_meshes = True
            wm.onion_skin_include_bones = False

        return {"FINISHED"}

def _selected_pose_bones_or_active(context):
    try:
        selected = list(context.selected_pose_bones) if context.selected_pose_bones else []
    except Exception:
        selected = []
    if selected:
        return [b for b in selected if b]
    if context.active_pose_bone:
        return [context.active_pose_bone]
    return []

def _selected_pose_bones_only(context):
    try:
        return [b for b in (list(context.selected_pose_bones) if context.selected_pose_bones else []) if b]
    except Exception:
        return []

class STATICALIZA_OT_yellow_resync_all(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_resync_all"
    bl_label = "Update Pins"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def execute(self, context):
        if not _state["yellow_modes"]:
            return {"CANCELLED"}

        arm = _active_armature(context)
        if not arm:
            return {"CANCELLED"}

        depsgraph = context.evaluated_depsgraph_get()
        eval_arm = arm.evaluated_get(depsgraph)
        objs, _ = _targets(context)

        pins = dict(_state["yellow_modes"])
        fixed = {}

        need_bounds = {n for n, m in pins.items() if int(m) in (2, 3)}
        bounds_world = {}
        if need_bounds:
            bounds_world = _collect_world_shape_from_largest_components(context, depsgraph, arm, eval_arm, need_bounds, objs = objs)

        for n, m in pins.items():
            cap = _yellow_capture(context, depsgraph, arm, eval_arm, objs, n, int(m), bounds_world)
            if cap:
                fixed[n] = cap

        _state["yellow_fixed"] = fixed
        _state["yellow_hidden"] = False
        _yellow_refresh_runtime(context)
        return {"FINISHED"}

class STATICALIZA_OT_yellow_clear_all(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_clear_all"
    bl_label = "Clear"
    bl_description = "Remove every Onion Pin"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE" and bool(_state.get("yellow_modes"))

    def execute(self, context):
        removed = len(_state.get("yellow_modes", {}))
        _state["yellow_modes"] = {}
        _state["yellow_fixed"] = {}
        _state["yellow_hidden"] = False
        _yellow_refresh_runtime(context)
        self.report({"INFO"}, f"Cleared {removed} Onion Pin(s).")
        return {"FINISHED"}

class STATICALIZA_OT_yellow_hide_all(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_hide_all"
    bl_label = "Hide Pins"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def execute(self, context):
        _state["yellow_hidden"] = True
        _yellow_refresh_runtime(context)
        return {"FINISHED"}

class STATICALIZA_OT_yellow_show(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_show"
    bl_label = "Show Pins"
    bl_options = {"REGISTER"}

    resync: bpy.props.BoolProperty(default = False)

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def execute(self, context):
        _state["yellow_hidden"] = False

        if self.resync and _state["yellow_modes"]:
            arm = _active_armature(context)
            if arm:
                depsgraph = context.evaluated_depsgraph_get()
                eval_arm = arm.evaluated_get(depsgraph)
                objs, _ = _targets(context)

                pins = dict(_state["yellow_modes"])
                fixed = dict(_state["yellow_fixed"])

                need_bounds = {n for n, m in pins.items() if int(m) in (2, 3)}
                bounds_world = {}
                if need_bounds:
                    bounds_world = _collect_world_shape_from_largest_components(context, depsgraph, arm, eval_arm, need_bounds, objs = objs)

                for n, m in pins.items():
                    cap = _yellow_capture(context, depsgraph, arm, eval_arm, objs, n, int(m), bounds_world)
                    if cap:
                        fixed[n] = cap

                _state["yellow_fixed"] = fixed

        _yellow_refresh_runtime(context)
        return {"FINISHED"}

class STATICALIZA_OT_yellow_apply(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_apply"
    bl_label = "Apply Yellow Pin"
    bl_options = {"REGISTER"}

    action: bpy.props.EnumProperty(
        items = (
            ("MODE_1", "Bone End", ""),
            ("MODE_2", "Bone Center", ""),
            ("MODE_3", "Smart Bottom", ""),
            ("PIVOT", "Pivot", ""),
            ("REMOVE", "Remove", "")
        )
    )

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def execute(self, context):
        arm = _active_armature(context)
        if not arm:
            return {"CANCELLED"}

        bones = _selected_pose_bones_or_active(context)
        if not bones:
            return {"CANCELLED"}

        pins = dict(_state.get("yellow_modes", {}))
        fixed = dict(_state.get("yellow_fixed", {}))

        sel_names = [b.name for b in bones if b]
        sel_set = set(sel_names)

        if self.action == "PIVOT":
            depsgraph = context.evaluated_depsgraph_get()
            eval_arm = arm.evaluated_get(depsgraph)
            
            frame = int(context.scene.frame_current)

            for n in sel_set:
                if n not in fixed:
                    continue
                
                packed = fixed[n]
                fixed3d = packed[0]

                pb_eval = eval_arm.pose.bones.get(n)
                if not pb_eval:
                    continue

                curr = _yellow_current_world_point(
                    depsgraph,
                    eval_arm,
                    pb_eval,
                    packed,
                )
                
                if curr is None:
                    continue

                diff = fixed3d - curr
                
                arm_mw = eval_arm.matrix_world
                try:
                    diff_arm = arm_mw.inverted().to_3x3() @ diff
                except Exception:
                    diff_arm = Vector((0.0, 0.0, 0.0))
                
                pb = arm.pose.bones.get(n)
                if pb:
                    m = pb.matrix.copy()
                    m.translation += diff_arm
                    pb.matrix = m
                    
                    context.view_layer.update()
                    _insert_bone_keys(pb, frame)

            return {"FINISHED"}

        if self.action == "REMOVE":
            for n in sel_set:
                pins.pop(n, None)
                fixed.pop(n, None)

            _state["yellow_modes"] = pins
            _state["yellow_fixed"] = fixed
            _yellow_refresh_runtime(context)
            return {"FINISHED"}

        mode = 1
        if self.action == "MODE_2":
            mode = 2
        elif self.action == "MODE_3":
            mode = 3

        depsgraph = context.evaluated_depsgraph_get()
        eval_arm = arm.evaluated_get(depsgraph)
        objs, _ = _targets(context)

        need_bounds = sel_set if mode in (2, 3) else set()
        bounds_world = {}
        if need_bounds:
            bounds_world = _collect_world_shape_from_largest_components(context, depsgraph, arm, eval_arm, need_bounds, objs = objs)

        for n in sel_set:
            pins[n] = int(mode)
            cap = _yellow_capture(context, depsgraph, arm, eval_arm, objs, n, int(mode), bounds_world)
            if cap:
                fixed[n] = cap

        fixed = {k: v for k, v in fixed.items() if k in pins}

        _state["yellow_modes"] = pins
        _state["yellow_fixed"] = fixed

        _yellow_refresh_runtime(context)
        return {"FINISHED"}
    
class STATICALIZA_MT_yellow_pin_menu(bpy.types.Menu):
    bl_label = "Onion Pin"

    def draw(self, context):
        bones = _selected_pose_bones_only(context)
        sel_names = [b.name for b in bones if b]
        sel_set = set(sel_names)
        pinned = set(_state.get("yellow_modes", {}).keys())

        any_pinned = bool(sel_set.intersection(pinned))

        layout = self.layout
        mode = getattr(context.window_manager, "yellow_pin_mode", "MODE_3")
        selected_pins = len(sel_set.intersection(pinned))
        update_text = "Update Selected Pin" if selected_pins == 1 else "Update Selected Pins"
        layout.operator("staticaliza.yellow_apply", text = update_text).action = mode

        if any_pinned:
            layout.separator()
            txt_piv = "Pivot Selected Pin" if len(sel_set) == 1 else "Pivot Selected Pins"
            layout.operator("staticaliza.yellow_apply", text = txt_piv).action = "PIVOT"

            layout.separator()
            txt_rem = "Remove Selected Pin" if len(sel_set) == 1 else "Remove Selected Pins"
            layout.operator("staticaliza.yellow_apply", text = txt_rem).action = "REMOVE"

class STATICALIZA_MT_yellow_hidden_menu(bpy.types.Menu):
    bl_label = "Onion Pin"

    def draw(self, context):
        layout = self.layout
        op = layout.operator("staticaliza.yellow_show", text = "Show Pins")
        op.resync = False
        op2 = layout.operator("staticaliza.yellow_show", text = "Show and Update Pins")
        op2.resync = True

class STATICALIZA_MT_empty_cancel(bpy.types.Menu):
    bl_label = "Cancel"

    def draw(self, context):
        pass

class STATICALIZA_MT_yellow_no_selection_menu(bpy.types.Menu):
    bl_label = "Onion Pin"

    def draw(self, context):
        layout = self.layout
        layout.operator("staticaliza.yellow_hide_all", text = "Hide Pins")
        layout.operator("staticaliza.yellow_resync_all", text = "Update Pins")

class STATICALIZA_OT_yellow_menu(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_menu"
    bl_label = "Onion Pin"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def invoke(self, context, event):
        bones = _selected_pose_bones_only(context)

        if not bones:
            if not _state["yellow_modes"]:
                return {"CANCELLED"}

            if _state["yellow_hidden"]:
                bpy.ops.wm.call_menu(name = "STATICALIZA_MT_yellow_hidden_menu")
                return {"FINISHED"}

            bpy.ops.wm.call_menu(name = "STATICALIZA_MT_yellow_no_selection_menu")
            return {"FINISHED"}

        pinned = set(_state.get("yellow_modes", {}).keys())
        selected_names = {bone.name for bone in bones if bone}
        if selected_names.intersection(pinned):
            bpy.ops.wm.call_menu(name = "STATICALIZA_MT_yellow_pin_menu")
            return {"FINISHED"}

        mode = getattr(context.window_manager, "yellow_pin_mode", "MODE_3")
        return bpy.ops.staticaliza.yellow_apply("EXEC_DEFAULT", action = mode)

def _ensure_object_action(obj):
    if not obj.animation_data:
        obj.animation_data_create()
    if not obj.animation_data.action:
        obj.animation_data.action = bpy.data.actions.new(name = f"{obj.name}Action")
    return obj.animation_data.action

def _fcurve_find(action, data_path):
    if not action:
        return None
    for fc in action.fcurves:
        if fc.data_path == data_path:
            return fc
    return None

def _fcurves_find_all(action, data_path):
    if not action:
        return []
    return [fc for fc in action.fcurves if fc.data_path == data_path]

def _fcurve_key_at(fc, frame):
    if not fc:
        return None
    for kp in fc.keyframe_points:
        if abs(float(kp.co.x) - float(frame)) <= 0.0001:
            return kp
    return None

def _fcurve_remove_key_all(action, data_path, frame):
    if not action:
        return

    frame = int(frame)

    for fc in list(_fcurves_find_all(action, data_path)):
        removed = False

        for kp in list(fc.keyframe_points):
            try:
                fr = int(round(float(kp.co.x)))
            except Exception:
                continue

            if int(fr) != int(frame):
                continue

            try:
                fc.keyframe_points.remove(kp)
                removed = True
            except Exception:
                pass

        if removed:
            if not fc.keyframe_points:
                try:
                    action.fcurves.remove(fc)
                except Exception:
                    pass
            else:
                try:
                    fc.update()
                except Exception:
                    pass

def _fcurve_set_constant(action, data_path, frame):
    if not action:
        return

    frame = float(int(frame))

    for fc in _fcurves_find_all(action, data_path):
        kp = _fcurve_key_at(fc, frame)
        if not kp:
            continue

        try:
            kp.interpolation = "CONSTANT"
        except Exception:
            pass

        try:
            kp.handle_left_type = "AUTO"
            kp.handle_right_type = "AUTO"
        except Exception:
            pass

        try:
            kp.type = "KEYFRAME"
        except Exception:
            pass

        try:
            fc.update()
        except Exception:
            pass

def _unparent_next_transform_keyframe(action, bone_name, after_frame):
    if not action:
        return None

    after_frame = int(after_frame)
    prefix = f'pose.bones["{bone_name}"].'
    best = None

    for prop in (
        "location",
        "scale",
        "rotation_euler",
        "rotation_quaternion",
        "rotation_axis_angle"
    ):
        for fc in _fcurves_find_all(action, prefix + prop):
            for kp in fc.keyframe_points:
                try:
                    fr = int(round(float(kp.co.x)))
                except Exception:
                    continue

                if fr <= after_frame:
                    continue

                if best is None or fr < best:
                    best = fr

    return int(best) if best is not None else None

def _unparent_next_start_after(action, bone_name, start_frame):
    if not action:
        return None

    s = int(start_frame)
    pts = _unparent_points(action, bone_name)
    if not pts:
        return None

    state = False
    inside = False

    for fr, v in pts:
        fr = int(fr)
        new_state = float(v) >= 0.5

        if fr <= s:
            state = new_state
            continue

        if inside:
            if new_state and not state:
                return int(fr)
        else:
            if state:
                inside = True

        state = new_state

    return None

def _unparent_allow_settle(action, bone_name, frame):
    nxt = _unparent_next_start_after(action, bone_name, int(frame))
    if nxt is None:
        return True
    return int(frame + 1) < int(nxt)

def _unparent_insert_hold_keys(context, arm, action, bone_name, frame, world_m, snap_pose, allow_next = True):
    scn = context.scene

    try:
        arm_inv = arm.matrix_world.inverted()
    except Exception:
        arm_inv = Matrix.Identity(4)

    f0 = int(frame)
    f1 = int(f0 + 1)

    do_f1 = bool(allow_next)
    if do_f1 and action:
        do_f1 = _unparent_allow_settle(action, bone_name, int(f0))
    if int(f1) > int(scn.frame_end):
        do_f1 = False

    scn.frame_set(int(f0))
    context.view_layer.update()

    pb0 = arm.pose.bones.get(bone_name)
    if pb0 and world_m is not None:
        try:
            pb0.matrix = arm_inv @ world_m
        except Exception:
            pass
        context.view_layer.update()
        _insert_bone_keys(pb0, int(f0))
        _set_pose_keys_vector_handles_new_only(action, bone_name, int(f0), snap_pose)

    if do_f1:
        scn.frame_set(int(f1))
        context.view_layer.update()

        pb1 = arm.pose.bones.get(bone_name)
        if pb1 and world_m is not None:
            try:
                pb1.matrix = arm_inv @ world_m
            except Exception:
                pass
            context.view_layer.update()
            _insert_bone_keys(pb1, int(f1))
            _set_pose_keys_vector_handles_new_only(action, bone_name, int(f1), snap_pose)

    lock_frames = {int(f0)}
    if do_f1:
        lock_frames.add(int(f1))

    for lf in sorted(lock_frames):
        _lock_pose_key_handles(action, bone_name, int(lf))

def _unparent_bake_to_end_target(context, action, bone_name, current_frame):
    scn = context.scene
    f_end = int(scn.frame_end)

    nxt_t = _unparent_next_transform_keyframe(action, bone_name, int(current_frame))
    nxt_s = _unparent_find_next_start_frame_from_points(action, bone_name, int(current_frame))

    targets = [f_end]
    if nxt_t is not None:
        targets.append(int(nxt_t))
    
    if nxt_s is not None:
        targets.append(int(nxt_s) - 1)

    return min(targets)

def _unparent_dp(bone_name):
    return f'pose.bones["{bone_name}"]["{UNP_PROP}"]'

def _pose_dp(bone_name, prop):
    return f'pose.bones["{bone_name}"].{prop}'

def _pb_prop_get(pb, key, default_value = 0.0):
    try:
        return float(pb.get(key, default_value))
    except Exception:
        return float(default_value)

def _pb_prop_set(pb, key, value):
    try:
        pb[key] = float(value)
    except Exception:
        pass

def _pb_prop_key(pb, key, frame):
    try:
        pb.keyframe_insert(data_path = f'["{key}"]', frame = int(frame), options = {"INSERTKEY_NEEDED"})
    except Exception:
        try:
            pb.keyframe_insert(data_path = f'["{key}"]', frame = int(frame))
        except Exception:
            pass
    _set_keyframe_handles_auto(pb, frame)

def _unparent_eval(action, bone_name, frame, pb_default = 0.0):
    if not action:
        return float(pb_default)

    dp = _unparent_dp(bone_name)
    fcs = _fcurves_find_all(action, dp)
    if not fcs:
        return float(pb_default)

    f = int(frame)
    v_best = None

    for fc in fcs:
        last_x = None
        last_v = None

        for kp in fc.keyframe_points:
            try:
                x = int(round(float(kp.co.x)))
                y = float(kp.co.y)
            except Exception:
                continue

            if x > f:
                continue

            if last_x is None or x > int(last_x):
                last_x = int(x)
                last_v = float(y)

        v = 0.0 if last_v is None else float(last_v)

        if v_best is None or float(v) > float(v_best):
            v_best = float(v)

    return float(v_best) if v_best is not None else float(pb_default)

def _unparent_remove_pose_keys_at(action, bone_name, frame):
    if not action:
        return

    for dp in (
        _pose_dp(bone_name, "location"),
        _pose_dp(bone_name, "scale"),
        _pose_dp(bone_name, "rotation_euler"),
        _pose_dp(bone_name, "rotation_quaternion"),
        _pose_dp(bone_name, "rotation_axis_angle")
    ):
        _fcurve_remove_key_all(action, dp, int(frame))

def _arm_pose_mtx_eval(context, arm, bone_name):
    depsgraph = context.evaluated_depsgraph_get()
    eval_arm = arm.evaluated_get(depsgraph)
    pb_eval = eval_arm.pose.bones.get(bone_name)
    if not pb_eval:
        return None
    try:
        return pb_eval.matrix.copy()
    except Exception:
        return None
    
def _insert_bone_keys(pb, frame):
    frame = int(frame)
    opts = {"INSERTKEY_VISUAL"}

    pb.keyframe_insert(data_path = "location", frame = frame, options = opts)

    if pb.rotation_mode == "QUATERNION":
        pb.keyframe_insert(data_path = "rotation_quaternion", frame = frame, options = opts)
    elif pb.rotation_mode == "AXIS_ANGLE":
        pb.keyframe_insert(data_path = "rotation_axis_angle", frame = frame, options = opts)
    else:
        pb.keyframe_insert(data_path = "rotation_euler", frame = frame, options = opts)

    pb.keyframe_insert(data_path = "scale", frame = frame, options = opts)
    _set_keyframe_handles_auto(pb, frame)

def _rel_saved_parent(pb):
    b = pb.bone
    if REL_K_PARENT not in b:
        b[REL_K_PARENT] = pb.parent.name if pb.parent else ""
        try:
            b[REL_K_CONNECT] = 1 if bool(b.use_connect) else 0
        except Exception:
            b[REL_K_CONNECT] = 0
    return str(b.get(REL_K_PARENT, ""))

def _unparent_ensure_visual_constraint(arm, pb):
    c = pb.constraints.get(UNP_VIS_CONSTRAINT)
    if c and c.type != "LIMIT_LOCATION":
        try:
            pb.constraints.remove(c)
        except Exception:
            pass
        c = None

    if not c:
        c = pb.constraints.new("LIMIT_LOCATION")
        c.name = UNP_VIS_CONSTRAINT

    try:
        c.owner_space = "WORLD"
    except Exception:
        pass

    try:
        c.use_min_x = False
        c.use_min_y = False
        c.use_min_z = False
        c.use_max_x = False
        c.use_max_y = False
        c.use_max_z = False
    except Exception:
        pass

    try:
        c.mute = False
    except Exception:
        pass

    try:
        c.influence = 1.0
    except Exception:
        pass

    return c

def _unparent_remove_visual_constraint(pb):
    c = pb.constraints.get(UNP_VIS_CONSTRAINT)
    if not c:
        return
    try:
        pb.constraints.remove(c)
    except Exception:
        pass

def _safe_mode_set(mode):
    try:
        bpy.ops.object.mode_set(mode = mode)
        return True
    except Exception:
        return False

def _unparent_apply_relation(context, arm, bone_name, detach):
    if not arm or arm.type != "ARMATURE":
        return False

    saved_active = context.view_layer.objects.active
    saved_mode = bpy.context.mode

    try:
        try:
            context.view_layer.objects.active = arm
        except Exception:
            pass

        if not _safe_mode_set("EDIT"):
            return False

        eb = arm.data.edit_bones.get(bone_name)
        if not eb:
            return False

        b = arm.data.bones.get(bone_name)
        if not b:
            return False

        if detach:
            eb.parent = None
            try:
                eb.use_connect = False
            except Exception:
                pass
            return True

        parent_name = str(b.get(REL_K_PARENT, ""))
        try:
            connect_val = bool(int(b.get(REL_K_CONNECT, 0)))
        except Exception:
            connect_val = False

        if parent_name:
            eb.parent = arm.data.edit_bones.get(parent_name)
        else:
            eb.parent = None

        try:
            eb.use_connect = bool(connect_val)
        except Exception:
            pass

        return True

    except Exception:
        return False

    finally:
        try:
            if saved_mode.startswith("POSE"):
                _safe_mode_set("POSE")
            else:
                _safe_mode_set("OBJECT")
        except Exception:
            pass

        try:
            if saved_active:
                context.view_layer.objects.active = saved_active
        except Exception:
            pass

def _unparent_rel_get_cached(arm_name, bone_name):
    return bool(_state["unparent_rel_cache"].get(f"{arm_name}::{bone_name}", False))

def _unparent_rel_set_cached(arm_name, bone_name, detached):
    _state["unparent_rel_cache"][f"{arm_name}::{bone_name}"] = bool(detached)

def _unparent_relation_is_detached(pb):
    if pb is None:
        return False
    saved_parent_name = str(pb.bone.get(REL_K_PARENT, ""))
    return bool(saved_parent_name and pb.parent is None)

def _unparent_switch_preserve_pose(context, arm, pb, detach):
    action = arm.animation_data.action if arm.animation_data else None
    object_keys_before = _snapshot_object_keys_all(action)
    previous_autokey = _autokey_push(context)
    try:
        bone_name = pb.name
        pose_m = _arm_pose_mtx_eval(context, arm, bone_name)
        if pose_m is None:
            return False

        _rel_saved_parent(pb)
        _unparent_ensure_visual_constraint(arm, pb)

        if not _unparent_apply_relation(context, arm, bone_name, detach):
            return False

        context.view_layer.update()

        current_pb = arm.pose.bones.get(bone_name)
        if current_pb is None:
            return False
        try:
            current_pb.matrix = pose_m
        except Exception:
            return False

        context.view_layer.update()
        return _unparent_relation_is_detached(current_pb) == bool(detach)
    finally:
        current_action = arm.animation_data.action if arm.animation_data else None
        _cleanup_new_object_keys_all(current_action, object_keys_before)
        _autokey_pop(context, previous_autokey)

def _capture_pose_matrices(context, arm, bone_name, frames):
    scn = context.scene
    saved_frame = int(scn.frame_current)
    mats = {}

    try:
        for f in sorted({int(x) for x in frames}):
            scn.frame_set(int(f))
            context.view_layer.update()

            depsgraph = context.evaluated_depsgraph_get()
            eval_arm = arm.evaluated_get(depsgraph)
            pb_eval = eval_arm.pose.bones.get(bone_name)
            if not pb_eval:
                continue

            mats[int(f)] = (eval_arm.matrix_world @ pb_eval.matrix).copy()

    finally:
        scn.frame_set(saved_frame)
        context.view_layer.update()

    return mats

def _unparent_start_frame(pb):
    try:
        v = pb.bone.get(UNP_STATE_KEY, None)
    except Exception:
        v = None
    if v is None:
        return None
    try:
        return int(v)
    except Exception:
        return None

def _unparent_clear_start_frame(pb):
    try:
        if UNP_STATE_KEY in pb.bone:
            del pb.bone[UNP_STATE_KEY]
    except Exception:
        pass

def _unparent_is_active_at(context, arm, pb, frame):
    action = arm.animation_data.action if arm.animation_data else None
    if not action:
        return False
    v = _unparent_eval(action, pb.name, int(frame), pb_default = 0.0)
    return float(v) >= 0.5

def _unparent_points(action, bone_name):
    if not action:
        return []

    dp = _unparent_dp(bone_name)
    merged = {}

    for fc in _fcurves_find_all(action, dp):
        for kp in fc.keyframe_points:
            try:
                fr = int(round(float(kp.co.x)))
                v = float(kp.co.y)
            except Exception:
                continue

            if fr not in merged or v > float(merged[fr]):
                merged[fr] = float(v)

    out = [(int(fr), float(v)) for fr, v in merged.items()]
    out.sort(key = lambda x: int(x[0]))
    return out

def _unparent_find_active_start_frame(action, bone_name, frame):
    if not action:
        return None

    f = int(frame)
    pts = _unparent_points(action, bone_name)
    if not pts:
        return None

    state = False
    last_start = None

    for fr, v in pts:
        if fr > f:
            break

        new_state = float(v) >= 0.5
        if new_state and not state:
            last_start = int(fr)

        state = new_state

    return int(last_start) if state and last_start is not None else None

def _unparent_find_end_frame(action, bone_name, start_frame):
    if not action:
        return None

    s = int(start_frame)
    pts = _unparent_points(action, bone_name)
    if not pts:
        return None

    for fr, v in pts:
        if int(fr) <= s:
            continue
        if float(v) < 0.5:
            return int(fr)

    return None

def _unparent_find_start_frame_fallback(action, bone_name):
    if not action:
        return None

    pts = _unparent_points(action, bone_name)
    if not pts:
        return None

    for fr, v in pts:
        if float(v) >= 0.5:
            return int(fr)

    return None

def _unparent_find_next_start_frame_from_points(action, bone_name, frame):
    if not action:
        return None

    f = int(frame)
    pts = _unparent_points(action, bone_name)
    if not pts:
        return None

    state = False

    for fr, v in pts:
        if int(fr) <= f:
            state = float(v) >= 0.5
            continue

        new_state = float(v) >= 0.5
        if new_state and not state:
            return int(fr)

        state = new_state

    return None

def _unparent_remove_window_keys_only(action, bone_name, start_f, end_f):
    if not action:
        return

    s = int(start_f)
    e = int(end_f)

    if e < s:
        s, e = e, s

    dp = _unparent_dp(bone_name)

    for fc in list(_fcurves_find_all(action, dp)):
        idxs = []

        try:
            kps = fc.keyframe_points
        except Exception:
            continue

        for i in range(len(kps)):
            try:
                fr = int(round(float(kps[i].co.x)))
            except Exception:
                continue

            if fr < s or fr > e:
                continue

            idxs.append(i)

        if not idxs:
            continue

        for i in reversed(idxs):
            try:
                fc.keyframe_points.remove(fc.keyframe_points[i])
            except RuntimeError:
                pass
            except Exception:
                pass

        try:
            if not fc.keyframe_points:
                try:
                    action.fcurves.remove(fc)
                except Exception:
                    pass
            else:
                try:
                    fc.update()
                except Exception:
                    pass
        except Exception:
            pass

def _unparent_clear_cached_start_if_matches(pb, start_frame):
    if not pb:
        return
    sf = _unparent_start_frame(pb)
    if sf is None:
        return
    if int(sf) == int(start_frame):
        _unparent_clear_start_frame(pb)

def _autokey_push(context):
    ts = getattr(getattr(context, "scene", None), "tool_settings", None)
    if not ts:
        return None

    prev_auto = getattr(ts, "use_keyframe_insert_auto", None)
    prev_ks = getattr(ts, "use_keyframe_insert_keyingset", None)

    if prev_auto is not None:
        ts.use_keyframe_insert_auto = False

    if prev_ks is not None:
        ts.use_keyframe_insert_keyingset = False

    return (prev_auto, prev_ks)

def _autokey_pop(context, prev):
    ts = getattr(getattr(context, "scene", None), "tool_settings", None)
    if not ts or prev is None:
        return

    prev_auto, prev_ks = prev

    if prev_auto is not None:
        ts.use_keyframe_insert_auto = bool(prev_auto)

    if prev_ks is not None:
        ts.use_keyframe_insert_keyingset = bool(prev_ks)

def _obj_transform_dps():
    return (
        "location",
        "scale",
        "rotation_euler",
        "rotation_quaternion",
        "rotation_axis_angle",
        "delta_location",
        "delta_scale",
        "delta_rotation_euler",
        "delta_rotation_quaternion"
    )

def _snapshot_object_keys_all(action):
    out = {}
    if not action:
        return out
    for prop in _obj_transform_dps():
        keys = set()
        for fc in _fcurves_find_all(action, prop):
            idx = int(getattr(fc, "array_index", 0))
            for kp in fc.keyframe_points:
                keys.add((prop, idx, int(round(float(kp.co.x)))))
        out[prop] = keys
    return out

def _cleanup_new_object_keys_all(action, snap):
    if not action:
        return
    for prop in _obj_transform_dps():
        before = snap.get(prop, set()) if snap else set()
        for fc in list(_fcurves_find_all(action, prop)):
            idx = int(getattr(fc, "array_index", 0))
            removed_any = False
            for kp in list(fc.keyframe_points):
                x = int(round(float(kp.co.x)))
                key_id = (prop, idx, x)
                if key_id in before:
                    continue
                fc.keyframe_points.remove(kp)
                removed_any = True
            if removed_any:
                if not fc.keyframe_points:
                    try:
                        action.fcurves.remove(fc)
                    except Exception:
                        pass
                else:
                    try:
                        fc.update()
                    except Exception:
                        pass
    for group in list(getattr(action, "groups", ())):
        if group.name != "Object Transforms":
            continue
        if len(group.channels) == 0:
            try:
                action.groups.remove(group)
            except Exception:
                pass

def _snapshot_bone_pose_keys(action, bone_name):
    out = set()
    if not action:
        return out

    for dp in (
        _pose_dp(bone_name, "location"),
        _pose_dp(bone_name, "scale"),
        _pose_dp(bone_name, "rotation_euler"),
        _pose_dp(bone_name, "rotation_quaternion"),
        _pose_dp(bone_name, "rotation_axis_angle")
    ):
        for fc in _fcurves_find_all(action, dp):
            idx = int(getattr(fc, "array_index", 0))
            for kp in fc.keyframe_points:
                out.add((dp, idx, int(round(float(kp.co.x)))))

    return out

def _set_pose_keys_vector_handles_new_only(action, bone_name, frame, snap):
    if not action:
        return

    frame = int(frame)

    for dp in (
        _pose_dp(bone_name, "location"),
        _pose_dp(bone_name, "scale"),
        _pose_dp(bone_name, "rotation_euler"),
        _pose_dp(bone_name, "rotation_quaternion"),
        _pose_dp(bone_name, "rotation_axis_angle")
    ):
        for fc in _fcurves_find_all(action, dp):
            idx = int(getattr(fc, "array_index", 0))

            if snap and (dp, idx, frame) in snap:
                continue

            kp = _fcurve_key_at(fc, frame)
            if not kp:
                continue

            try:
                kp.interpolation = "BEZIER"
            except Exception:
                pass

            try:
                kp.handle_left_type = "AUTO"
                kp.handle_right_type = "AUTO"
            except Exception:
                pass

            try:
                fc.update()
            except Exception:
                pass

def _unparent_has_marker_keys(action, bone_name):
    if not action:
        return False
    dp = _unparent_dp(bone_name)
    for fc in _fcurves_find_all(action, dp):
        try:
            if fc.keyframe_points and len(fc.keyframe_points) > 0:
                return True
        except Exception:
            pass
    return False

def _unparent_segment_at_frame(action, bone_name, frame):
    if not action:
        return (None, None, None, False)

    f = int(frame)
    start_f = _unparent_find_active_start_frame(action, bone_name, f)
    if start_f is None:
        return (None, None, None, False)

    start_f = int(start_f)
    end_f = _unparent_find_end_frame(action, bone_name, start_f)
    end_f = int(end_f) if end_f is not None else None

    next_start = _unparent_find_next_start_frame_from_points(action, bone_name, start_f)
    next_start = int(next_start) if next_start is not None else None

    conjoined = False
    if end_f is not None and next_start is not None:
        conjoined = int(end_f) == int(next_start) - 1

    return (start_f, end_f, next_start, bool(conjoined))


def _unparent_nearest_segment(action, bone_name, frame, excluded_starts = None):
    points = _unparent_points(action, bone_name)
    if not points:
        return (None, None)

    excluded_starts = set(excluded_starts or ())
    segments = []
    active = False
    start_frame = None
    for point_frame, value in points:
        next_active = float(value) >= 0.5
        if next_active and not active:
            start_frame = int(point_frame)
        elif active and not next_active and start_frame is not None:
            if int(start_frame) not in excluded_starts:
                segments.append((int(start_frame), int(point_frame)))
            start_frame = None
        active = next_active

    if (
        active
        and start_frame is not None
        and int(start_frame) not in excluded_starts
    ):
        segments.append((int(start_frame), None))
    if not segments:
        return (None, None)

    current_frame = int(frame)

    def distance(segment):
        segment_start, segment_end = segment
        effective_end = segment_end if segment_end is not None else segment_start
        if segment_end is not None and segment_start <= current_frame <= segment_end:
            return 0
        return min(
            abs(current_frame - segment_start),
            abs(current_frame - effective_end),
        )

    return min(segments, key = lambda segment: (distance(segment), segment[0]))

def _unparent_cleanup_orphans(context, arm, action):
    for pb in arm.pose.bones:
        has_vis = bool(pb.constraints.get(UNP_VIS_CONSTRAINT))
        has_prop = (UNP_PROP in pb)

        if (not has_vis) and (not has_prop) and (not _unparent_relation_is_detached(pb)):
            continue

        fc = _fcurve_find(action, _unparent_dp(pb.name))
        if fc:
            continue

        saved_parent_name = str(pb.bone.get(REL_K_PARENT, ""))
        if saved_parent_name and (pb.parent is None):
            _unparent_switch_preserve_pose(context, arm, pb, False)

        _unparent_remove_visual_constraint(pb)

        if UNP_PROP in pb:
            try:
                del pb[UNP_PROP]
            except Exception:
                pass

        _unparent_rel_set_cached(arm.name, pb.name, False)
        _unparent_clear_start_frame(pb)

def _unparent_has_end_between(action, bone_name, a_frame, b_frame):
    if not action:
        return False

    dp = _unparent_dp(bone_name)
    fcs = _fcurves_find_all(action, dp)
    if not fcs:
        return False

    a = int(a_frame)
    b = int(b_frame)

    for fc in fcs:
        for kp in fc.keyframe_points:
            try:
                fr = int(round(float(kp.co.x)))
                v = float(kp.co.y)
            except Exception:
                continue
            if fr <= a or fr >= b:
                continue
            if float(v) < 0.5:
                return True

    return False

def _fcurve_prev_next_keyframes(fc, frame):
    prev_kp = None
    next_kp = None
    f = float(frame)

    for kp in fc.keyframe_points:
        x = float(kp.co.x)
        if x < f and (prev_kp is None or x > float(prev_kp.co.x)):
            prev_kp = kp
        if x > f and (next_kp is None or x < float(next_kp.co.x)):
            next_kp = kp

    return prev_kp, next_kp

def _lock_pose_key_handles(action, bone_name, frame):
    if not action:
        return

    frame = int(frame)

    for dp in (
        _pose_dp(bone_name, "location"),
        _pose_dp(bone_name, "scale"),
        _pose_dp(bone_name, "rotation_euler"),
        _pose_dp(bone_name, "rotation_quaternion"),
        _pose_dp(bone_name, "rotation_axis_angle")
    ):
        for fc in _fcurves_find_all(action, dp):
            kp = _fcurve_key_at(fc, frame)
            prev_kp, next_kp = _fcurve_prev_next_keyframes(fc, frame)

            for k in (prev_kp, kp, next_kp):
                if not k:
                    continue

                try:
                    k.interpolation = "BEZIER"
                except Exception:
                    pass

                try:
                    k.handle_left_type = "AUTO"
                    k.handle_right_type = "AUTO"
                except Exception:
                    pass

            try:
                fc.update()
            except Exception:
                pass

def _unparent_bake_window(context, arm, pb, start_frame, end_frame):
    scn = context.scene
    action = _ensure_object_action(arm)

    start_f = int(start_frame)
    end_f = int(end_frame)
    if end_f < start_f:
        start_f, end_f = end_f, start_f

    nxt_s = _unparent_find_next_start_frame_from_points(action, pb.name, start_f)
    
    is_abutting = False
    if nxt_s is not None:
        if int(end_f) >= int(nxt_s):
            end_f = int(nxt_s) - 1
            is_abutting = True
        elif int(end_f) == int(nxt_s) - 1:
            is_abutting = True

    obj_action = arm.animation_data.action if arm.animation_data else None
    obj_snap_all = _snapshot_object_keys_all(obj_action)

    if start_f < int(scn.frame_start) or start_f > int(scn.frame_end):
        return False

    end_f = max(int(scn.frame_start), min(int(end_f), int(scn.frame_end)))
    if end_f <= start_f:
        return False

    end_is_off = False
    if not is_abutting:
        try:
            end_is_off = _unparent_eval(action, pb.name, int(end_f), pb_default = 0.0) < 0.5
        except Exception:
            end_is_off = False

    baseline_f = int(start_f)
    bake_first = int(start_f + 1)
    bake_last = int(end_f - 1) if end_is_off else int(end_f)

    if bake_last < bake_first:
        bake_first = int(baseline_f)
        bake_last = int(baseline_f)

    snap_pose_before = _snapshot_bone_pose_keys(action, pb.name)
    had_end_plus_1 = any(int(fr) == int(end_f + 1) for _dp, _idx, fr in snap_pose_before)

    saved_frame = int(scn.frame_current)

    write_frames = {int(baseline_f)}
    if bake_last >= bake_first:
        write_frames.update(set(range(int(bake_first), int(bake_last) + 1)))
    if end_is_off:
        write_frames.add(int(end_f))

    capture_frames_list = sorted(list(write_frames))
    mats = {}

    _state["unparent_handler_mute"] = False
    
    try:
        pre_warm_f = int(capture_frames_list[0] - 1)
        if pre_warm_f >= int(scn.frame_start):
            scn.frame_set(pre_warm_f)
            context.view_layer.update()

        for f in capture_frames_list:
            scn.frame_set(int(f))
            context.view_layer.update()
            
            depsgraph = context.evaluated_depsgraph_get()
            eval_arm = arm.evaluated_get(depsgraph)
            pb_eval = eval_arm.pose.bones.get(pb.name)
            
            if pb_eval:
                try:
                    arm_mw = eval_arm.matrix_world.copy()
                    world_m = (arm_mw @ pb_eval.matrix).copy()
                    mats[int(f)] = (arm_mw, world_m)
                except Exception:
                    pass

    finally:
        try:
            scn.frame_set(int(saved_frame))
        except Exception:
            pass
        context.view_layer.update()

    if not mats:
        return False

    if end_is_off:
        last_on = int(end_f - 1)
        if int(last_on) in mats and int(end_f) in mats:
            mats[int(end_f)] = mats[int(last_on)]

    _state["unparent_handler_mute"] = True
    
    try:
        _fcurve_remove_key_all(action, _unparent_dp(pb.name), int(start_f))
        
        _unparent_remove_window_keys_only(action, pb.name, int(start_f) + 1, int(end_f))

        for fr in sorted(write_frames):
            _unparent_remove_pose_keys_at(action, pb.name, int(fr))

        context.view_layer.update()

        if not _unparent_switch_preserve_pose(context, arm, pb, False):
            return False

        _unparent_rel_set_cached(arm.name, pb.name, False)
        _unparent_remove_visual_constraint(pb)
        _unparent_clear_start_frame(pb)

        if action and (not _unparent_has_marker_keys(action, pb.name)):
            if UNP_PROP in pb:
                try:
                    del pb[UNP_PROP]
                except Exception:
                    pass

        context.view_layer.update()

        snap_pose = _snapshot_bone_pose_keys(action, pb.name)

        for fr in sorted(write_frames):
            if int(fr) not in mats:
                continue

            arm_mw, world_m = mats[int(fr)]

            scn.frame_set(int(fr))
            context.view_layer.update()

            pb2 = arm.pose.bones.get(pb.name)
            if not pb2:
                continue

            try:
                inv = arm_mw.inverted()
            except Exception:
                inv = Matrix.Identity(4)

            try:
                pb2.matrix = inv @ world_m
            except Exception:
                continue

            context.view_layer.update()
            
            _insert_bone_keys(pb2, int(fr))

            if int(fr) == int(baseline_f):
                _lock_pose_key_handles(action, pb.name, int(fr))
            elif end_is_off and int(fr) == int(end_f):
                _lock_pose_key_handles(action, pb.name, int(fr))
            else:
                _set_pose_keys_vector_handles_new_only(action, pb.name, int(fr), snap_pose)

        if (not had_end_plus_1) and int(end_f + 1) <= int(scn.frame_end):
            if not is_abutting:
                if not _unparent_is_active_at(context, arm, pb, int(end_f + 1)):
                    _unparent_remove_pose_keys_at(action, pb.name, int(end_f + 1))

        a0 = max(int(start_f), int(baseline_f - 2))
        a1 = min(int(end_f), int(baseline_f + 2))
        for lf in range(int(a0), int(a1) + 1):
            _lock_pose_key_handles(action, pb.name, int(lf))

        if bake_last >= bake_first:
            b0 = max(int(start_f), int(bake_last - 2))
            b1 = min(int(end_f), int(bake_last + 2))
            for lf in range(int(b0), int(b1) + 1):
                _lock_pose_key_handles(action, pb.name, int(lf))

        context.view_layer.update()
        _cleanup_new_object_keys_all(obj_action, obj_snap_all)

    finally:
        _state["unparent_handler_mute"] = False
        try:
            scn.frame_set(int(saved_frame))
        except Exception:
            pass
        context.view_layer.update()

    f_now = int(scn.frame_current)
    want_detached = _unparent_is_active_at(context, arm, pb, int(f_now))
    have_detached = _unparent_relation_is_detached(pb)

    _state["unparent_handler_mute"] = True
    try:
        if bool(want_detached) != bool(have_detached):
            if _unparent_switch_preserve_pose(context, arm, pb, bool(want_detached)):
                _unparent_rel_set_cached(arm.name, pb.name, bool(want_detached))

        if want_detached:
            _unparent_ensure_visual_constraint(arm, pb)
        else:
            _unparent_remove_visual_constraint(pb)

    finally:
        _state["unparent_handler_mute"] = False
        context.view_layer.update()
        _cleanup_new_object_keys_all(obj_action, obj_snap_all)

    return True

def _unparent_toggle(context, arm, pb, frame):
    scn = context.scene
    action = _ensure_object_action(arm)

    f = int(frame)
    f_prev = max(0, int(f - 1))

    saved_parent_name = str(pb.bone.get(REL_K_PARENT, ""))
    if pb.parent is None and not saved_parent_name:
        return False

    _unparent_ensure_visual_constraint(arm, pb)

    v_now = _unparent_eval(action, pb.name, int(f), pb_default = _pb_prop_get(pb, UNP_PROP, 0.0))
    in_window = float(v_now) >= 0.5

    dp = _unparent_dp(pb.name)
    fc_prop = _ddm_ensure_fcurve(action, dp)

    if not in_window:
        snap_before = _snapshot_bone_pose_keys(action, pb.name)

        m_prev = _eval_pose_matrix_at_frame(context, arm, pb.name, int(f_prev))
        m_now = _eval_pose_matrix_at_frame(context, arm, pb.name, int(f))

        if m_prev is not None:
            _insert_stability_keys(context, arm, pb.name, int(f_prev), m_prev)

        _pb_prop_set(pb, UNP_PROP, 1.0)
        _ddm_insert_key(fc_prop, int(f), 1.0)

        try:
            fc_prop.update()
        except Exception:
            pass

        _unparent_inject_end_before_start(context, arm, pb, int(f))

        if _unparent_switch_preserve_pose(context, arm, pb, True):
            _unparent_rel_set_cached(arm.name, pb.name, True)

            if m_now is not None:
                _insert_stability_keys(context, arm, pb.name, int(f), m_now)

            for dp2 in (
                _pose_dp(pb.name, "location"),
                _pose_dp(pb.name, "scale"),
                _pose_dp(pb.name, "rotation_euler"),
                _pose_dp(pb.name, "rotation_quaternion"),
                _pose_dp(pb.name, "rotation_axis_angle")
            ):
                for fc in _fcurves_find_all(action, dp2):
                    idx = int(getattr(fc, "array_index", 0))

                    for src, dst in ((int(f), int(f + 1)), (int(f_prev), int(f))):
                        if (dp2, idx, int(src)) in snap_before:
                            continue
                        
                        kp_src = _fcurve_key_at(fc, int(src))
                        if not kp_src:
                            continue

                        kp_dst = _fcurve_key_at(fc, int(dst))
                        if kp_dst and (dp2, idx, int(dst)) not in snap_before:
                            try:
                                fc.keyframe_points.remove(kp_dst)
                            except Exception:
                                pass

                        try:
                            kp_src.co.x = float(dst)
                        except Exception:
                            pass

                    try:
                        fc.update()
                    except Exception:
                        pass

            return True

        return False

    snap_before = _snapshot_bone_pose_keys(action, pb.name)
    packs = _capture_pose_world_matrices_with_arm_mw(context, arm, pb.name, {int(f_prev), int(f)})
    world_prev = None
    arm_mw_f = None

    try:
        if int(f_prev) in packs:
            world_prev = packs[int(f_prev)][1]
        if int(f) in packs:
            arm_mw_f = packs[int(f)][0]
    except Exception:
        pass

    m_end_fix = None
    if world_prev is not None and arm_mw_f is not None:
        try:
            inv_f = arm_mw_f.inverted()
            m_end_fix = (inv_f @ world_prev).copy()
        except Exception:
            pass

    m_prev = _eval_pose_matrix_at_frame(context, arm, pb.name, int(f_prev))
    if m_prev is not None:
        _insert_stability_keys(context, arm, pb.name, int(f_prev), m_prev)

    _pb_prop_set(pb, UNP_PROP, 0.0)
    _ddm_insert_key(fc_prop, int(f_prev), 1.0)
    _ddm_insert_key(fc_prop, int(f), 0.0)

    try:
        fc_prop.update()
    except Exception:
        pass

    if _unparent_switch_preserve_pose(context, arm, pb, False):
        _unparent_rel_set_cached(arm.name, pb.name, False)
        if m_end_fix is None:
            m_end_fix = _eval_pose_matrix_at_frame(context, arm, pb.name, int(f))

        if m_end_fix is not None:
            _insert_stability_keys(context, arm, pb.name, int(f), m_end_fix)

        for dp2 in (
            _pose_dp(pb.name, "location"),
            _pose_dp(pb.name, "scale"),
            _pose_dp(pb.name, "rotation_euler"),
            _pose_dp(pb.name, "rotation_quaternion"),
            _pose_dp(pb.name, "rotation_axis_angle")
        ):
            for fc in _fcurves_find_all(action, dp2):
                idx = int(getattr(fc, "array_index", 0))
                for src, dst in ((int(f), int(f + 1)), (int(f_prev), int(f))):
                    if (dp2, idx, int(src)) in snap_before:
                        continue
                    kp_src = _fcurve_key_at(fc, int(src))
                    if not kp_src:
                        continue
                    kp_dst = _fcurve_key_at(fc, int(dst))
                    if kp_dst and (dp2, idx, int(dst)) not in snap_before:
                        try:
                            fc.keyframe_points.remove(kp_dst)
                        except Exception:
                            pass
                    try:
                        kp_src.co.x = float(dst)
                    except Exception:
                        pass
                try:
                    fc.update()
                except Exception:
                    pass
        return True
    return False

def _ddm_ensure_fcurve(action, data_path):
    fc = _fcurve_find(action, data_path)
    if not fc:
        fc = action.fcurves.new(data_path)
    return fc

def _ddm_insert_key(fc, frame, value):
    for kp in fc.keyframe_points:
        if abs(kp.co.x - frame) < 0.001:
            try:
                fc.keyframe_points.remove(kp)
            except:
                pass
            break
    kp = fc.keyframe_points.insert(frame, value)
    kp.interpolation = "CONSTANT"
    return kp

def _unparent_inject_end_before_start(context, arm, pb, new_start_frame):
    action = arm.animation_data.action if arm.animation_data else None
    if not action:
        return
    dp = _unparent_dp(pb.name)
    fc = _ddm_ensure_fcurve(action, dp)

    s_next = None
    sorted_pts = sorted(fc.keyframe_points, key = lambda k: k.co.x)

    for kp in sorted_pts:
        if kp.co.x > float(new_start_frame) + 0.1 and float(kp.co.y) > 0.5:
            s_next = int(round(float(kp.co.x)))
            break

    if s_next is None:
        return

    if int(s_next) <= int(new_start_frame) + 1:
        return

    mats = _capture_pose_matrices(context, arm, pb.name, {int(new_start_frame)})
    m_hold = mats.get(int(new_start_frame))
    if m_hold is None:
        return

    end_frame = int(s_next) - 1

    _unparent_remove_window_keys_only(action, pb.name, int(new_start_frame) + 1, end_frame)

    for fr in range(int(new_start_frame) + 1, end_frame + 1):
        _unparent_remove_pose_keys_at(action, pb.name, int(fr))

    snap_pose = _snapshot_bone_pose_keys(action, pb.name)
    _unparent_insert_hold_keys(context, arm, action, pb.name, end_frame, m_hold, snap_pose, allow_next = False)

    _lock_pose_key_handles(action, pb.name, end_frame)

    try:
        fc.update()
    except Exception:
        pass

def _unparent_remove_start_key(context, arm, pb, start_frame):
    action = arm.animation_data.action if arm.animation_data else None
    start_frame = int(start_frame)

    if action:
        end_key = _unparent_find_end_frame(action, pb.name, int(start_frame))
        next_start = _unparent_find_next_start_frame_from_points(action, pb.name, int(start_frame))

        conjoined = False
        if end_key is not None and next_start is not None:
            conjoined = int(end_key) == int(next_start) - 1

        dp = _unparent_dp(pb.name)

        if conjoined and end_key is not None:
            end_key = int(end_key)

            _unparent_remove_window_keys_only(action, pb.name, int(start_frame - 1), int(end_key))

            for fr in (int(start_frame - 1), int(start_frame), int(start_frame + 1)):
                _unparent_remove_pose_keys_at(action, pb.name, int(fr))

            for fr in (int(end_key - 1), int(end_key), int(end_key + 1)):
                _unparent_remove_pose_keys_at(action, pb.name, int(fr))

        else:
            for fr in (int(start_frame - 1), int(start_frame)):
                _fcurve_remove_key_all(action, dp, int(fr))

            if end_key is not None:
                end_key = int(end_key)
                for fr in (int(end_key - 1), int(end_key)):
                    _fcurve_remove_key_all(action, dp, int(fr))

            for fr in (int(start_frame - 1), int(start_frame), int(start_frame + 1)):
                _unparent_remove_pose_keys_at(action, pb.name, int(fr))

            if end_key is not None:
                for fr in (int(end_key - 1), int(end_key), int(end_key + 1)):
                    _unparent_remove_pose_keys_at(action, pb.name, int(fr))

    context.view_layer.update()

    f_now = int(context.scene.frame_current)
    want_detached = _unparent_is_active_at(context, arm, pb, int(f_now)) if action else False
    have_detached = _unparent_relation_is_detached(pb)

    _state["unparent_handler_mute"] = True
    try:
        if want_detached:
            _unparent_ensure_visual_constraint(arm, pb)
        else:
            _unparent_remove_visual_constraint(pb)

        if bool(want_detached) != bool(have_detached):
            _rel_saved_parent(pb)
            world_m = _arm_pose_mtx_eval(context, arm, pb.name)

            if _unparent_apply_relation(context, arm, pb.name, bool(want_detached)):
                context.view_layer.update()

                if world_m is not None:
                    try:
                        arm_inv = arm.matrix_world.inverted()
                    except Exception:
                        arm_inv = Matrix.Identity(4)

                    pb2 = arm.pose.bones.get(pb.name)
                    if pb2:
                        try:
                            pb2.matrix = arm_inv @ world_m
                        except Exception:
                            pass
                        context.view_layer.update()

                _unparent_rel_set_cached(arm.name, pb.name, bool(want_detached))

    finally:
        _state["unparent_handler_mute"] = False
        context.view_layer.update()

    if action and (not _unparent_has_marker_keys(action, pb.name)):
        if UNP_PROP in pb:
            try:
                del pb[UNP_PROP]
            except Exception:
                pass
        _unparent_clear_start_frame(pb)
    else:
        _unparent_clear_cached_start_if_matches(pb, int(start_frame))

    return True

def _unparent_remove_end_key(context, arm, pb, end_frame):
    action = arm.animation_data.action if arm.animation_data else None
    if not action:
        return False

    scn = context.scene
    f_now = int(scn.frame_current)
    end_frame = int(end_frame)

    prev_start = _unparent_find_active_start_frame(action, pb.name, int(end_frame - 1))
    next_start = None
    if prev_start is not None:
        next_start = _unparent_find_next_start_frame_from_points(action, pb.name, int(prev_start))

    _fcurve_remove_key_all(action, _unparent_dp(pb.name), int(end_frame))
    _fcurve_remove_key_all(action, _unparent_dp(pb.name), int(end_frame - 1))

    for fr in (int(end_frame - 1), int(end_frame), int(end_frame + 1)):
        _unparent_remove_pose_keys_at(action, pb.name, int(fr))

    context.view_layer.update()

    if prev_start is not None and next_start is not None:
        if not _unparent_has_end_between(action, pb.name, int(prev_start), int(next_start)):
            _fcurve_remove_key_all(action, _unparent_dp(pb.name), int(prev_start))
            _fcurve_remove_key_all(action, _unparent_dp(pb.name), int(prev_start - 1))

            for fr in (int(prev_start - 1), int(prev_start), int(prev_start + 1)):
                _unparent_remove_pose_keys_at(action, pb.name, int(fr))

            off_f = int(next_start - 1)
            if off_f >= int(scn.frame_start) and off_f <= int(scn.frame_end):
                pb_now = arm.pose.bones.get(pb.name)
                if pb_now:
                    _pb_prop_set(pb_now, UNP_PROP, 0.0)
                    _pb_prop_key(pb_now, UNP_PROP, int(off_f))
                    _fcurve_set_constant(action, _unparent_dp(pb.name), int(off_f))

    context.view_layer.update()

    want_detached = _unparent_is_active_at(context, arm, pb, int(f_now))
    have_detached = _unparent_relation_is_detached(pb)

    _state["unparent_handler_mute"] = True
    try:
        if want_detached:
            _unparent_ensure_visual_constraint(arm, pb)
        else:
            _unparent_remove_visual_constraint(pb)

        if bool(want_detached) != bool(have_detached):
            _rel_saved_parent(pb)

            world_m = _arm_pose_mtx_eval(context, arm, pb.name)

            if _unparent_apply_relation(context, arm, pb.name, bool(want_detached)):
                context.view_layer.update()

                if world_m is not None:
                    try:
                        arm_inv = arm.matrix_world.inverted()
                    except Exception:
                        arm_inv = Matrix.Identity(4)

                    pb2 = arm.pose.bones.get(pb.name)
                    if pb2:
                        try:
                            pb2.matrix = arm_inv @ world_m
                        except Exception:
                            pass
                        context.view_layer.update()

                _unparent_rel_set_cached(arm.name, pb.name, bool(want_detached))

    finally:
        _state["unparent_handler_mute"] = False
        context.view_layer.update()

    return True

def _capture_pose_world_matrices_with_arm_mw(context, arm, bone_name, frames):
    scn = context.scene
    saved_frame = int(scn.frame_current)
    mats = {}

    try:
        for f in sorted({int(x) for x in frames}):
            scn.frame_set(int(f))
            context.view_layer.update()

            depsgraph = context.evaluated_depsgraph_get()
            eval_arm = arm.evaluated_get(depsgraph)
            pb_eval = eval_arm.pose.bones.get(bone_name)
            if not pb_eval:
                continue

            try:
                arm_mw = eval_arm.matrix_world.copy()
                world_m = (arm_mw @ pb_eval.matrix).copy()
                mats[int(f)] = (arm_mw, world_m)
            except Exception:
                pass

    finally:
        scn.frame_set(saved_frame)
        context.view_layer.update()

    return mats

def _unparent_rel_scan_arm(arm):
    out = set()
    if not arm or arm.type != "ARMATURE":
        return out

    action = arm.animation_data.action if arm.animation_data else None
    if not action:
        return out

    needle = f'["{UNP_PROP}"]'

    for fc in action.fcurves:
        dp = str(getattr(fc, "data_path", ""))
        if not dp or needle not in dp:
            continue
        if not dp.startswith('pose.bones["'):
            continue

        try:
            name = dp.split('pose.bones["', 1)[1].split('"]', 1)[0]
        except Exception:
            name = ""

        if name:
            out.add(name)

    return out

def _eval_pose_matrix_at_frame(context, arm, bone_name, frame):
    scn = context.scene
    saved = int(scn.frame_current)

    try:
        scn.frame_set(int(frame))
        context.view_layer.update()

        depsgraph = context.evaluated_depsgraph_get()
        eval_arm = arm.evaluated_get(depsgraph)
        pb_eval = eval_arm.pose.bones.get(bone_name)
        if not pb_eval:
            return None

        try:
            return pb_eval.matrix.copy()
        except Exception:
            return None

    finally:
        scn.frame_set(saved)
        context.view_layer.update()

def _insert_stability_keys(context, arm, bone_name, frame, matrix_value):
    if matrix_value is None:
        return

    scn = context.scene
    saved_frame = int(scn.frame_current)
    saved_mtx = _arm_pose_mtx_eval(context, arm, bone_name)

    try:
        scn.frame_set(int(frame))
        context.view_layer.update()

        pb = arm.pose.bones.get(bone_name)
        if not pb:
            return

        try:
            pb.matrix = matrix_value
        except Exception:
            return

        context.view_layer.update()
        _insert_bone_keys(pb, int(frame))

    finally:
        scn.frame_set(saved_frame)
        context.view_layer.update()

        if saved_mtx is not None:
            pb2 = arm.pose.bones.get(bone_name)
            if pb2:
                try:
                    pb2.matrix = saved_mtx
                except Exception:
                    pass

        context.view_layer.update()

def _unparent_toggle(context, arm, pb, frame):
    scn = context.scene
    action = _ensure_object_action(arm)

    f = int(frame)
    f_prev = max(0, int(f - 1))

    saved_parent_name = str(pb.bone.get(REL_K_PARENT, ""))
    if pb.parent is None and not saved_parent_name:
        return False

    _unparent_ensure_visual_constraint(arm, pb)

    v_now = _unparent_eval(action, pb.name, int(f), pb_default = _pb_prop_get(pb, UNP_PROP, 0.0))
    in_window = float(v_now) >= 0.5

    dp = _unparent_dp(pb.name)
    fc_prop = _ddm_ensure_fcurve(action, dp)

    if not in_window:
        snap_before = _snapshot_bone_pose_keys(action, pb.name)

        m_prev = _eval_pose_matrix_at_frame(context, arm, pb.name, int(f_prev))
        m_now = _eval_pose_matrix_at_frame(context, arm, pb.name, int(f))

        if m_prev is not None:
            _insert_stability_keys(context, arm, pb.name, int(f_prev), m_prev)

        _pb_prop_set(pb, UNP_PROP, 1.0)

        _ddm_insert_key(fc_prop, int(f), 1.0)

        try:
            fc_prop.update()
        except Exception:
            pass

        _unparent_inject_end_before_start(context, arm, pb, int(f))

        if _unparent_switch_preserve_pose(context, arm, pb, True):
            _unparent_rel_set_cached(arm.name, pb.name, True)

            if m_now is not None:
                _insert_stability_keys(context, arm, pb.name, int(f), m_now)

            for dp2 in (
                _pose_dp(pb.name, "location"),
                _pose_dp(pb.name, "scale"),
                _pose_dp(pb.name, "rotation_euler"),
                _pose_dp(pb.name, "rotation_quaternion"),
                _pose_dp(pb.name, "rotation_axis_angle")
            ):
                for fc in _fcurves_find_all(action, dp2):
                    idx = int(getattr(fc, "array_index", 0))

                    for src, dst in ((int(f), int(f + 1)), (int(f_prev), int(f))):
                        if (dp2, idx, int(src)) in snap_before:
                            continue
                        if (dp2, idx, int(dst)) in snap_before:
                            continue

                        kp_src = _fcurve_key_at(fc, int(src))
                        if not kp_src:
                            continue

                        kp_dst = _fcurve_key_at(fc, int(dst))
                        if kp_dst and (dp2, idx, int(dst)) not in snap_before:
                            try:
                                fc.keyframe_points.remove(kp_dst)
                            except Exception:
                                pass

                        try:
                            kp_src.co.x = float(dst)
                        except Exception:
                            pass

                    try:
                        fc.update()
                    except Exception:
                        pass

            return True

        return False

    m_now = _eval_pose_matrix_at_frame(context, arm, pb.name, int(f))
    m_end_fix = m_now.copy() if m_now is not None else None
    _insert_evaluated_transform_key(pb, int(f_prev))

    _pb_prop_set(pb, UNP_PROP, 0.0)

    _ddm_insert_key(fc_prop, int(f_prev), 1.0)
    _ddm_insert_key(fc_prop, int(f), 0.0)

    try:
        fc_prop.update()
    except Exception:
        pass

    if _unparent_switch_preserve_pose(context, arm, pb, False):
        _unparent_rel_set_cached(arm.name, pb.name, False)

        if m_end_fix is None:
            m_end_fix = m_now

        if m_end_fix is not None:
            _insert_stability_keys(context, arm, pb.name, int(f), m_end_fix)

        return True

    return False

def _unparent_cleanup_orphans(context, arm, action):
    for pb in arm.pose.bones:
        has_vis = bool(pb.constraints.get(UNP_VIS_CONSTRAINT))
        has_prop = (UNP_PROP in pb)

        if (not has_vis) and (not has_prop) and (not _unparent_relation_is_detached(pb)):
            continue

        if action and _unparent_has_marker_keys(action, pb.name):
            continue

        saved_parent_name = str(pb.bone.get(REL_K_PARENT, ""))
        if saved_parent_name and (pb.parent is None):
            _unparent_switch_preserve_pose(context, arm, pb, False)

        _unparent_remove_visual_constraint(pb)

        if UNP_PROP in pb:
            try:
                del pb[UNP_PROP]
            except Exception:
                pass

        _unparent_rel_set_cached(arm.name, pb.name, False)
        _unparent_clear_start_frame(pb)

class STATICALIZA_OT_unparent_action(bpy.types.Operator):
    bl_idname = "staticaliza.unparent_action"
    bl_label = "Unparent Action"
    bl_options = {"REGISTER", "UNDO"}
    action: bpy.props.EnumProperty(
    items = (
            ("START", "Start", ""),
            ("END", "End", ""),
            ("BAKE", "Bake", ""),
            ("BAKE_TO_NEAREST", "Bake To Nearest", ""),
            ("BAKE_TO_ENDING", "Bake To End", ""),
            ("CLEAR", "Clear", ""),
            ("REMOVE_START", "Remove Start", ""),
            ("REMOVE_END", "Remove End", "")
        )
    )

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE" and bool(_selected_pose_bones_only(context))

    def execute(self, context):
        prev_autokey = _autokey_push(context)
        previous_handler_mute = bool(_state.get("unparent_handler_mute", False))
        _state["unparent_handler_mute"] = True
        try:
            arm = _active_armature(context)
            if not arm:
                return {"CANCELLED"}

            bones = _selected_pose_bones_only(context)
            if not bones:
                return {"CANCELLED"}

            scn = context.scene
            f = int(scn.frame_current)
            action = arm.animation_data.action if arm.animation_data else None

            any_done = False

            if self.action in {"START", "END"}:
                for pb in bones:
                    if not pb:
                        continue

                    auto_starts = _dp_auto_unparent_start_frames(pb)
                    active_now = False
                    active_start = None
                    if action:
                        active_now = _unparent_eval(action, pb.name, int(f), pb_default = 0.0) >= 0.5
                        active_start = _unparent_find_active_start_frame(
                            action,
                            pb.name,
                            int(f),
                        )
                    active_is_auto = bool(
                        active_now
                        and active_start is not None
                        and int(active_start) in auto_starts
                    )

                    if self.action == "START" and (not active_now):
                        if _unparent_toggle(context, arm, pb, int(f)):
                            any_done = True

                    if self.action == "END" and active_now and not active_is_auto:
                        if _unparent_toggle(context, arm, pb, int(f)):
                            any_done = True

                context.view_layer.update()
                _tag_redraw_all_view3d()
                return {"FINISHED"} if any_done else {"CANCELLED"}

            for pb in bones:
                if not pb:
                    continue

                auto_starts = _dp_auto_unparent_start_frames(pb)
                active_start = (
                    _unparent_find_active_start_frame(
                        action,
                        pb.name,
                        int(f),
                    )
                    if action
                    else None
                )
                if active_start is not None and int(active_start) in auto_starts:
                    continue

                if self.action == "CLEAR":
                    if not action:
                        continue
                    start_frame, _end_frame = _unparent_nearest_segment(
                        action,
                        pb.name,
                        int(f),
                        excluded_starts = auto_starts,
                    )
                    if start_frame is not None and _unparent_remove_start_key(
                        context,
                        arm,
                        pb,
                        int(start_frame),
                    ):
                        any_done = True
                    continue

                active_now = _unparent_is_active_at(context, arm, pb, int(f))

                seg_start = None
                seg_end = None
                seg_next = None
                seg_conjoined = False

                if action:
                    seg_start, seg_end, seg_next, seg_conjoined = _unparent_segment_at_frame(action, pb.name, int(f))
                    if (
                        seg_start is not None
                        and int(seg_start) in auto_starts
                    ):
                        continue

                start_f = seg_start
                if start_f is None:
                    start_f = _unparent_start_frame(pb)
                if start_f is None and action:
                    start_f = _unparent_find_start_frame_fallback(action, pb.name)

                if self.action == "REMOVE_START":
                    if action and seg_start is not None:
                        if _unparent_remove_start_key(context, arm, pb, int(seg_start)):
                            any_done = True
                    elif start_f is not None:
                        if _unparent_remove_start_key(context, arm, pb, int(start_f)):
                            any_done = True

                elif self.action == "REMOVE_END":
                    if action and seg_start is not None:
                        end_key = _unparent_find_end_frame(action, pb.name, int(seg_start))
                        if end_key is not None:
                            if _unparent_remove_end_key(context, arm, pb, int(end_key)):
                                any_done = True

                elif self.action == "BAKE":
                    if action and seg_start is not None:
                        end_key = _unparent_find_end_frame(action, pb.name, int(seg_start))
                        if end_key is not None and int(end_key) != int(seg_start):
                            if _unparent_bake_window(context, arm, pb, int(seg_start), int(end_key)):
                                any_done = True

                elif self.action == "BAKE_TO_NEAREST":
                    if action and seg_start is not None:
                        end_key = _unparent_find_end_frame(action, pb.name, int(seg_start))

                        if end_key is not None:
                            end_f = int(end_key)
                        else:
                            end_f = int(_unparent_bake_to_end_target(context, action, pb.name, int(f)))

                        if int(end_f) != int(seg_start):
                            if _unparent_bake_window(context, arm, pb, int(seg_start), int(end_f)):
                                any_done = True

                elif self.action == "BAKE_TO_ENDING":
                    if action and seg_start is not None:
                        end_key = _unparent_find_end_frame(action, pb.name, int(seg_start))
                        
                        if end_key is not None:
                            end_f = int(end_key)
                        else:
                            end_f = int(scn.frame_end)

                        if int(end_f) != int(seg_start):
                            if _unparent_bake_window(context, arm, pb, int(seg_start), int(end_f)):
                                any_done = True

            context.view_layer.update()
            _tag_redraw_all_view3d()
            return {"FINISHED"} if any_done else {"CANCELLED"}

        finally:
            _state["unparent_handler_mute"] = previous_handler_mute
            _autokey_pop(context, prev_autokey)
            
class STATICALIZA_MT_unparent_menu_inactive(bpy.types.Menu):
    bl_label = "Dynamic Unparent"

    def draw(self, context):
        layout = self.layout
        layout.operator("staticaliza.unparent_action", text = "Create Start").action = "START"
        arm = _active_armature(context)
        pb = context.active_pose_bone
        action = arm.animation_data.action if (arm and arm.animation_data) else None
        manual_start, _manual_end = (
            _unparent_nearest_segment(
                action,
                pb.name,
                int(context.scene.frame_current),
                excluded_starts = _dp_auto_unparent_start_frames(pb),
            )
            if pb and action
            else (None, None)
        )
        if manual_start is not None:
            layout.operator("staticaliza.unparent_action", text = "Clear").action = "CLEAR"

class STATICALIZA_MT_unparent_menu_active(bpy.types.Menu):
    bl_label = "Dynamic Unparent Active"
    def draw(self, context):
        arm = _active_armature(context)
        pb = context.active_pose_bone
        action = arm.animation_data.action if (arm and arm.animation_data) else None
        f = int(context.scene.frame_current)
        hide_advanced = not getattr(
            context.window_manager,
            "roblox_compat_advanced_mode",
            False,
        )

        layout = self.layout

        if not arm or not pb or not action:
            layout.operator("staticaliza.unparent_action", text = "Create Start").action = "START"
            return

        start_f, end_f, next_start, conjoined = _unparent_segment_at_frame(action, pb.name, int(f))

        if (
            start_f is not None
            and int(start_f) in _dp_auto_unparent_start_frames(pb)
        ):
            layout.label(text = "Managed by Dynamic Parent")
            return

        if start_f is None:
            layout.operator("staticaliza.unparent_action", text = "Create Start").action = "START"
            return

        if end_f is None:
            layout.operator("staticaliza.unparent_action", text = "Create End").action = "END"
            layout.operator("staticaliza.unparent_action", text = "Clear").action = "CLEAR"
            if hide_advanced:
                return
            layout.operator("staticaliza.unparent_action", text = "Remove Start").action = "REMOVE_START"
            layout.separator()

            target_near = _unparent_bake_to_end_target(context, action, pb.name, int(f))
            if int(target_near) != int(start_f):
                layout.operator("staticaliza.unparent_action", text = "Bake To Nearest").action = "BAKE_TO_NEAREST"

            target_end = int(context.scene.frame_end)
            if int(target_end) != int(start_f):
                layout.operator("staticaliza.unparent_action", text = "Bake To End").action = "BAKE_TO_ENDING"
            return

        if conjoined:
            layout.operator("staticaliza.unparent_action", text = "Clear").action = "CLEAR"
            if hide_advanced:
                return
            layout.operator("staticaliza.unparent_action", text = "Remove Start").action = "REMOVE_START"
            layout.separator()
            layout.operator("staticaliza.unparent_action", text = "Bake").action = "BAKE"
            return

        layout.operator("staticaliza.unparent_action", text = "Clear").action = "CLEAR"
        if hide_advanced:
            return
        layout.operator("staticaliza.unparent_action", text = "Remove End").action = "REMOVE_END"
        layout.operator("staticaliza.unparent_action", text = "Remove Start").action = "REMOVE_START"
        layout.separator()
        layout.operator("staticaliza.unparent_action", text = "Bake").action = "BAKE"
        
class STATICALIZA_OT_unparent_menu(bpy.types.Operator):
    bl_idname = "staticaliza.unparent_menu"
    bl_label = "Dynamic Unparent"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE" and bool(_selected_pose_bones_only(context))

    def invoke(self, context, event):
        arm = _active_armature(context)
        if not arm:
            return {"CANCELLED"}

        bones = _selected_pose_bones_only(context)
        if not bones:
            return {"CANCELLED"}

        pb = context.active_pose_bone
        if pb not in bones:
            pb = bones[0]

        action = arm.animation_data.action if arm.animation_data else None
        f = int(context.scene.frame_current)

        active_now = False
        active_start = None
        if action:
            active_now = _unparent_eval(action, pb.name, f, pb_default = 0.0) >= 0.5
            active_start = _unparent_find_active_start_frame(
                action,
                pb.name,
                f,
            )

        if (
            active_now
            and active_start is not None
            and int(active_start) in _dp_auto_unparent_start_frames(pb)
        ):
            return {"CANCELLED"}

        if not active_now:
            bpy.ops.wm.call_menu(name = "STATICALIZA_MT_unparent_menu_inactive")
            return {"FINISHED"}

        bpy.ops.wm.call_menu(name = "STATICALIZA_MT_unparent_menu_active")
        return {"FINISHED"}


def _unparent_apply_action_pose_channels(action, pose_bone, frame):
    if action is None or pose_bone is None:
        return False

    applied = False
    for property_name in (
        "location",
        "scale",
        "rotation_euler",
        "rotation_quaternion",
        "rotation_axis_angle",
    ):
        curves = _fcurves_find_all(
            action,
            _pose_dp(pose_bone.name, property_name),
        )
        if not curves:
            continue

        current_value = getattr(pose_bone, property_name, None)
        if current_value is None:
            continue
        values = list(current_value)
        for curve in curves:
            index = int(getattr(curve, "array_index", 0))
            if 0 <= index < len(values):
                values[index] = float(curve.evaluate(float(frame)))
                applied = True
        try:
            setattr(pose_bone, property_name, values)
        except (AttributeError, TypeError, ValueError):
            continue
    return applied


@persistent
def _unparent_frame_change_post(scene, depsgraph):
    if _state.get("unparent_handler_mute", False):
        return

    context = bpy.context
    if not context or not context.scene:
        return

    export_armature = _state.get("unparent_export_armature")
    if export_armature and getattr(export_armature, "type", None) == "ARMATURE":
        arm = export_armature
    else:
        arm = _active_armature(context)
        if not arm:
            return

    action = arm.animation_data.action if arm.animation_data else None
    if not action:
        for pb in arm.pose.bones:
            _unparent_remove_visual_constraint(pb)
        return

    _unparent_cleanup_orphans(context, arm, action)

    bone_names = _unparent_rel_scan_arm(arm)
    if not bone_names:
        return

    f = int(context.scene.frame_current)

    for name in bone_names:
        pb = arm.pose.bones.get(name)
        if not pb:
            continue

        want_detached = _unparent_eval(action, name, int(f), pb_default = _pb_prop_get(pb, UNP_PROP, 0.0)) >= 0.5
        have_detached = _unparent_relation_is_detached(pb)

        if want_detached:
            _unparent_ensure_visual_constraint(arm, pb)
        else:
            _unparent_remove_visual_constraint(pb)

        if bool(want_detached) == bool(have_detached):
            continue

        if _unparent_switch_preserve_pose(context, arm, pb, bool(want_detached)):
            _unparent_rel_set_cached(arm.name, name, bool(want_detached))
            _unparent_apply_action_pose_channels(action, pb, f)
            context.view_layer.update()

    _tag_redraw_all_view3d()

@persistent
def _load_post(*_):
    _state["yellow_fixed"] = {}
    _state["yellow_modes"] = {}
    _state["yellow_hidden"] = False
    _state["unparent_rel_cache"] = {}
    _state["unparent_handler_mute"] = False
    _state["unparent_export_armature"] = None
    _state["smart_material_scan_pending"] = False
    _state["roblox_compatibility_scan_pending"] = False
    _state["armature_overlay_saved"] = {}
    _state["part_pivot_syncing"] = False
    _state["part_pivot_armature"] = 0
    _state["part_pivot_bone"] = ""
    _state["part_pivot_object"] = ""
    _state["part_pivot_object_local"] = None
    _state["part_pivot_saved"] = None
    _state["part_pivot_last_signature"] = None
    _state["part_pivot_cursor_visibility"] = {}
    _state["camera_view_spaces"] = {}
    _state["pose_tool_active_session"] = False
    _state["last_error"] = ""
    _set_default_keyframe_handle_type()
    window_manager = getattr(bpy.context, "window_manager", None)
    if window_manager is not None and hasattr(
        window_manager,
        "staticaliza_pivot_mode",
    ):
        window_manager.staticaliza_pivot_mode = "BONE"
    _yellow_refresh_runtime(bpy.context)
    _state["smart_material_processed_rigs"] = set()
    _capture_material_import_baseline()
    _state["roblox_constraints_normalized"] = set()
    _smart_material_import_scan(bpy.context.scene)
    _apply_roblox_compatibility(bpy.context.scene)
    _sync_view3d_relationship_lines(bpy.context)
    _sync_all_attached_camera_object_visibility()
    _unregister_addon_keymaps()
    if not _register_addon_keymaps():
        bpy.app.timers.register(
            _register_addon_keymaps_timer,
            first_interval = 0.05,
        )

def _clear_material_input_links(node_tree, socket_names, visited = None):
    if node_tree is None:
        return 0
    if getattr(node_tree, "library", None) is not None:
        return 0

    if visited is None:
        visited = set()

    tree_id = node_tree.as_pointer()
    if tree_id in visited:
        return 0
    visited.add(tree_id)

    removed = 0

    for node in node_tree.nodes:
        for socket_name in socket_names:
            socket = node.inputs.get(socket_name)
            if not socket or not socket.is_linked:
                continue

            for link in tuple(socket.links):
                node_tree.links.remove(link)
                removed += 1

        if node.type == "GROUP" and getattr(node, "node_tree", None):
            removed += _clear_material_input_links(node.node_tree, socket_names, visited)

    return removed

def dp_clear_material_links():
    removed = 0
    visited = set()

    for material in bpy.data.materials:
        if getattr(material, "library", None) is not None:
            continue
        if _is_bundled_template_baseplate_material(material):
            continue
        node_tree = getattr(material, "node_tree", None)
        if node_tree is None:
            continue
        removed += _clear_material_input_links(node_tree, {"Base Color", "Alpha"}, visited)

    return removed


def _is_bundled_template_baseplate_material(material):
    if material is None or material.name != "Baseplate":
        return False
    node_tree = getattr(material, "node_tree", None)
    if node_tree is None or not any(
        node.type == "TEX_IMAGE"
        and getattr(getattr(node, "image", None), "name", "") == "Baseplate.png"
        for node in node_tree.nodes
    ):
        return False

    baseplate = bpy.data.objects.get("Baseplate")
    if baseplate is None or baseplate.type != "MESH":
        return False
    return any(slot.material == material for slot in baseplate.material_slots)

def _strip_blender_numeric_suffix(name):
    base, separator, suffix = str(name).rpartition(".")
    if separator and suffix.isdigit():
        return base
    return name


def _object_world_bounds_center(obj):
    if not getattr(obj, "bound_box", None):
        return obj.matrix_world.to_translation()
    center = Vector((0.0, 0.0, 0.0))
    for corner in obj.bound_box:
        center += Vector(corner)
    return obj.matrix_world @ (center / 8.0)


def _is_matching_clothing_layer(base_obj, candidate):
    base_dimensions = tuple(abs(float(axis)) for axis in base_obj.dimensions)
    candidate_dimensions = tuple(abs(float(axis)) for axis in candidate.dimensions)
    if min(base_dimensions) <= 1.0e-6 or min(candidate_dimensions) <= 1.0e-6:
        return False

    for base_axis, candidate_axis in zip(base_dimensions, candidate_dimensions):
        if abs(base_axis - candidate_axis) / max(base_axis, candidate_axis) > 0.08:
            return False

    largest_dimension = max(max(base_dimensions), max(candidate_dimensions))
    center_distance = (
        _object_world_bounds_center(base_obj)
        - _object_world_bounds_center(candidate)
    ).length
    return center_distance <= largest_dimension * 0.03


def _set_imported_clothing_layer_offsets(parts_collection, enabled):
    mesh_objects = [
        obj for obj in parts_collection.all_objects if obj.type == "MESH"
    ]
    if not enabled:
        removed = 0
        for obj in mesh_objects:
            modifier = obj.modifiers.get(CLOTHING_LAYER_OFFSET_MODIFIER)
            if modifier is not None:
                obj.modifiers.remove(modifier)
                removed += 1
        return -removed

    families = {}
    for obj in mesh_objects:
        families.setdefault(_strip_blender_numeric_suffix(obj.name), []).append(obj)

    adjusted = 0
    for canonical_name, family in families.items():
        if len(family) < 2:
            continue

        linked_candidates = [
            obj for obj in family if _object_has_linked_base_color(obj)
        ]
        unlinked_candidates = [
            obj for obj in family if not _object_has_linked_base_color(obj)
        ]
        has_material_signal = bool(linked_candidates and unlinked_candidates)
        body_candidates = unlinked_candidates if has_material_signal else family
        body_candidates.sort(
            key = lambda obj: (
                float(obj.dimensions.x * obj.dimensions.y * obj.dimensions.z),
                obj.name != canonical_name,
                obj.name,
            )
        )
        body_obj = body_candidates[0]
        body_volume = abs(float(
            body_obj.dimensions.x
            * body_obj.dimensions.y
            * body_obj.dimensions.z
        ))

        for obj in family:
            if (
                obj == body_obj
                or (
                    has_material_signal
                    and not _object_has_linked_base_color(obj)
                )
                or not _is_matching_clothing_layer(body_obj, obj)
            ):
                continue
            if not has_material_signal:
                candidate_volume = abs(float(
                    obj.dimensions.x * obj.dimensions.y * obj.dimensions.z
                ))
                if candidate_volume <= body_volume * 1.0001:
                    continue

            modifier = obj.modifiers.get(CLOTHING_LAYER_OFFSET_MODIFIER)
            if modifier is None:
                modifier = obj.modifiers.new(
                    name = CLOTHING_LAYER_OFFSET_MODIFIER,
                    type = "DISPLACE",
                )
                adjusted += 1
            positive_dimensions = [
                abs(float(axis)) for axis in body_obj.dimensions if abs(float(axis)) > 1.0e-6
            ]
            reference_dimension = min(positive_dimensions, default = 1.0)
            modifier.direction = "NORMAL"
            modifier.mid_level = 0.0
            modifier.strength = max(0.001, min(0.02, reference_dimension * 0.005))

    return adjusted

def _get_smart_material_rig(collection):
    if not collection.name.startswith("RIG: "):
        return None

    rig_name = _strip_blender_numeric_suffix(collection.name[5:].strip())
    parts_collection = collection.children.get("Parts")
    if not rig_name or parts_collection is None:
        return None

    armature_name = f"__{rig_name}_Armature"
    meta_name = f"__{rig_name}Meta"
    armature = None
    meta = None

    for obj in collection.all_objects:
        obj_name = _strip_blender_numeric_suffix(obj.name)
        if obj.type == "ARMATURE" and obj_name == armature_name:
            armature = obj
        elif obj.type == "EMPTY" and obj_name == meta_name:
            meta = obj

    if armature is None or meta is None:
        return None

    return rig_name, parts_collection

def _smart_disconnect_base_color_links(node_tree, visited = None):
    if node_tree is None or getattr(node_tree, "library", None) is not None:
        return 0

    if visited is None:
        visited = set()

    tree_id = node_tree.as_pointer()
    if tree_id in visited:
        return 0
    visited.add(tree_id)

    removed = 0
    for node in node_tree.nodes:
        if node.type == "BSDF_PRINCIPLED":
            base_color = node.inputs.get("Base Color")
            normal = node.inputs.get("Normal")
            if base_color and base_color.is_linked and normal and normal.is_linked:
                for link in tuple(base_color.links):
                    node_tree.links.remove(link)
                    removed += 1

        if node.type == "GROUP" and getattr(node, "node_tree", None):
            removed += _smart_disconnect_base_color_links(node.node_tree, visited)

    return removed


def _capture_material_import_baseline():
    try:
        materials = bpy.data.materials
    except AttributeError:
        return False
    _state["material_import_baseline"] = {
        int(material.as_pointer()) for material in materials
    }
    return True


def _initialize_material_import_tracking():
    return None if _capture_material_import_baseline() else 0.1


def _standardize_imported_material_display(material):
    material.diffuse_color = IMPORTED_MATERIAL_DISPLAY_COLOR
    material.metallic = 0.0
    material.roughness = 0.5

def _smart_material_import_scan(scene):
    context = bpy.context
    wm = getattr(context, "window_manager", None)
    if wm is None:
        return

    smart_enabled = getattr(wm, "smart_material_import_enabled", True)
    display_enabled = getattr(
        wm,
        "standardize_imported_material_display_enabled",
        True,
    )
    clothing_offset_enabled = getattr(
        wm,
        "prevent_clothing_layer_clipping_enabled",
        True,
    )

    processed = _state.setdefault("smart_material_processed_rigs", set())
    material_baseline = _state.get("material_import_baseline")
    if material_baseline is None:
        if not _capture_material_import_baseline():
            return
        material_baseline = _state["material_import_baseline"]
    current_rigs = set()

    for collection in bpy.data.collections:
        rig = _get_smart_material_rig(collection)
        if rig is None:
            continue

        rig_name, parts_collection = rig
        rig_id = collection.as_pointer()
        current_rigs.add(rig_id)
        if rig_id in processed:
            continue

        removed = 0
        standardized = 0
        adjusted_layers = 0
        material_ids = set()
        visited_trees = set()

        for obj in parts_collection.all_objects:
            if obj.type != "MESH":
                continue
            for slot in obj.material_slots:
                material = slot.material
                if material is None or getattr(material, "library", None) is not None:
                    continue
                material_id = material.as_pointer()
                if material_id in material_ids:
                    continue
                material_ids.add(material_id)
                if smart_enabled:
                    removed += _smart_disconnect_base_color_links(
                        material.node_tree,
                        visited_trees,
                    )
                if display_enabled and material_id not in material_baseline:
                    _standardize_imported_material_display(material)
                    standardized += 1

        adjusted_layers = _set_imported_clothing_layer_offsets(
            parts_collection,
            clothing_offset_enabled,
        )

        processed.add(rig_id)
        if removed:
            print(f"[Smart Material Import] Removed {removed} Base Color link(s) from '{rig_name}'.")
        if standardized:
            print(
                f"[Smart Material Import] Standardized {standardized} viewport "
                f"material(s) on '{rig_name}'."
            )
        if adjusted_layers > 0:
            print(
                f"[Smart Material Import] Offset {adjusted_layers} clothing "
                f"layer(s) on '{rig_name}' to prevent clipping."
            )
        elif adjusted_layers < 0:
            print(
                f"[Smart Material Import] Removed {-adjusted_layers} clothing "
                f"layer offset(s) from '{rig_name}'."
            )

    processed.intersection_update(current_rigs)

def _on_smart_material_import_toggle(self, context):
    _state["smart_material_processed_rigs"] = set()
    _smart_material_import_scan(context.scene)

@persistent
def _smart_material_import_depsgraph_update(scene, depsgraph):
    for update in depsgraph.updates:
        datablock = getattr(update, "id", None)
        if not isinstance(datablock, bpy.types.Object):
            continue
        if datablock.type == "ARMATURE" or (
            datablock.type == "EMPTY"
            and datablock.name.startswith("__")
            and "Meta" in datablock.name
        ):
            _schedule_smart_material_import_scan()
            return


def _run_smart_material_import_scan():
    _state["smart_material_scan_pending"] = False
    context = bpy.context
    if context and context.scene:
        _smart_material_import_scan(context.scene)
    return None


def _schedule_smart_material_import_scan(delay = 0.15):
    if _state.get("smart_material_scan_pending", False):
        return
    _state["smart_material_scan_pending"] = True
    try:
        bpy.app.timers.register(
            _run_smart_material_import_scan,
            first_interval = delay,
        )
    except Exception:
        _state["smart_material_scan_pending"] = False


RBX_RELEASE_API_URL = "https://api.github.com/repos/Cautioned/Blender-Animations-Plugin/releases/latest"
RBX_ADDON_ID = "roblox_animations_importer_exporter"
UTILS_ADDON_ID = "staticaliza_blender_animation_tools"
UTILS_PACKAGE_URL = (
    "https://raw.githubusercontent.com/Staticaliza/"
    "Staticaliza-Blender-Animation-Tools/main/src/"
    "staticaliza_blender_animation_tools.zip"
)


def _roblox_addon_module_name(refresh = False):
    try:
        modules = addon_utils.modules(refresh = refresh)
    except Exception:
        return None

    for module in modules:
        module_name = getattr(module, "__name__", "")
        if module_name == RBX_ADDON_ID or module_name.endswith(f".{RBX_ADDON_ID}"):
            return module_name
    return None


def _roblox_addon_is_enabled():
    return hasattr(bpy.types, "OBJECT_PT_RbxAnimations")


def _download_json(url):
    separator = "&" if "?" in url else "?"
    request = urllib.request.Request(
        f"{url}{separator}_staticaliza_cache_bust={time.time_ns()}",
        headers = {
            "Accept": "application/vnd.github+json",
            "Cache-Control": "no-cache, no-store, max-age=0",
            "Pragma": "no-cache",
            "User-Agent": "Staticaliza-Blender-Animation-Tools",
        },
    )
    with urllib.request.urlopen(request, timeout = 20) as response:
        return json.loads(response.read().decode("utf-8"))


def _get_roblox_release_asset():
    release = _download_json(RBX_RELEASE_API_URL)
    assets = [
        asset for asset in release.get("assets", [])
        if str(asset.get("name", "")).lower().endswith(".zip")
    ]
    if not assets:
        raise RuntimeError("The latest release has no ZIP package.")

    use_legacy = bpy.app.version < (4, 1, 0)
    preferred = [
        asset for asset in assets
        if ("legacy" in str(asset.get("name", "")).lower()) == use_legacy
    ]
    asset = preferred[0] if preferred else assets[0]
    asset_url = asset.get("browser_download_url")
    if not asset_url:
        raise RuntimeError("The release package has no download URL.")

    return release.get("tag_name", "latest"), asset.get("name", "package.zip"), asset_url


def _download_release_asset(asset_name, asset_url):
    safe_name = os.path.basename(asset_name) or "roblox_animations.zip"
    destination = os.path.join(tempfile.gettempdir(), f"staticaliza_{safe_name}")
    separator = "&" if "?" in asset_url else "?"
    request = urllib.request.Request(
        f"{asset_url}{separator}_staticaliza_cache_bust={time.time_ns()}",
        headers = {
            "Cache-Control": "no-cache, no-store, max-age=0",
            "Pragma": "no-cache",
            "User-Agent": "Staticaliza-Blender-Animation-Tools",
        },
    )

    try:
        with urllib.request.urlopen(request, timeout = 60) as response, open(destination, "wb") as output:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                output.write(chunk)

        return _prepare_roblox_addon_zip(destination)
    except Exception:
        if os.path.exists(destination):
            try:
                os.remove(destination)
            except OSError:
                pass
        raise


def _download_utils_package():
    handle, destination = tempfile.mkstemp(prefix = "staticaliza_utils_", suffix = ".zip")
    os.close(handle)
    separator = "&" if "?" in UTILS_PACKAGE_URL else "?"
    request = urllib.request.Request(
        f"{UTILS_PACKAGE_URL}{separator}_staticaliza_cache_bust={time.time_ns()}",
        headers = {
            "Cache-Control": "no-cache, no-store, max-age=0",
            "Pragma": "no-cache",
            "User-Agent": "Staticaliza-Blender-Animation-Tools",
        },
    )

    try:
        with urllib.request.urlopen(request, timeout = 60) as response, open(destination, "wb") as output:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                output.write(chunk)

        with zipfile.ZipFile(destination) as package:
            if package.testzip() is not None:
                raise RuntimeError("The downloaded Utils ZIP failed its integrity check.")
            manifest_names = [
                name for name in package.namelist()
                if name.replace("\\", "/").endswith("blender_manifest.toml")
            ]
            if not manifest_names:
                raise RuntimeError("The downloaded Utils ZIP has no Blender manifest.")
            manifest_name = min(manifest_names, key = lambda name: name.count("/"))
            manifest = tomllib.loads(package.read(manifest_name).decode("utf-8"))
            if manifest.get("id") != UTILS_ADDON_ID:
                raise RuntimeError("The downloaded ZIP is not Roblox Animator Utils.")
            version = str(manifest.get("version", "unknown"))
        return destination, version
    except Exception:
        try:
            os.remove(destination)
        except OSError:
            pass
        raise


def _extension_repository_is_locked():
    try:
        from bl_pkg import cookie_from_session
        from bl_pkg.bl_extension_utils import repo_lock_directory_query
    except ImportError:
        return False

    extensions = getattr(bpy.context.preferences, "extensions", None)
    repositories = getattr(extensions, "repos", ())
    repository = next(
        (repo for repo in repositories if repo.module == "user_default"),
        None,
    )
    if repository is None:
        return False

    return repo_lock_directory_query(
        repository.directory,
        cookie_from_session(),
    ) is not None


def _replace_manifest_display_name(data, display_name):
    text = data.decode("utf-8")
    lines = text.splitlines(keepends = True)

    for index, line in enumerate(lines):
        if not line.lstrip().startswith("name ="):
            continue
        indent = line[:len(line) - len(line.lstrip())]
        newline = "\r\n" if line.endswith("\r\n") else "\n" if line.endswith("\n") else ""
        lines[index] = f'{indent}name = "{display_name}"{newline}'
        return "".join(lines).encode("utf-8")

    raise RuntimeError("Downloaded Blender manifest has no name field.")


def _replace_bl_info_display_name(data, display_name):
    text = data.decode("utf-8")
    lines = text.splitlines(keepends = True)
    in_bl_info = False

    for index, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith("bl_info") and "{" in stripped:
            in_bl_info = True
            continue
        if not in_bl_info:
            continue
        if stripped == "}":
            break
        if not (stripped.startswith('"name"') or stripped.startswith("'name'")):
            continue

        indent = line[:len(line) - len(line.lstrip())]
        newline = "\r\n" if line.endswith("\r\n") else "\n" if line.endswith("\n") else ""
        lines[index] = f'{indent}"name": "{display_name}",{newline}'
        return "".join(lines).encode("utf-8")

    raise RuntimeError("Downloaded add-on metadata has no name field.")


def _replace_roblox_panel_display_name(data):
    text = data.decode("utf-8")
    text = text.replace(
        'bl_label = "Rbx Animations"',
        'bl_label = "Roblox Animator" + (f" (v{ADDON_VERSION_TEXT})" if ADDON_VERSION_TEXT.lower() != "unknown" else "")',
    )
    text = text.replace(
        "bl_label = 'Rbx Animations'",
        'bl_label = "Roblox Animator" + (f" (v{ADDON_VERSION_TEXT})" if ADDON_VERSION_TEXT.lower() != "unknown" else "")',
    )
    text = text.replace('"Rbx Animations"', '"Roblox Animator"')
    text = text.replace("'Rbx Animations'", "'Roblox Animator'")
    text = text.replace('text="Bake (Clipboard)"', 'text="Export"')
    text = text.replace("text='Bake (Clipboard)'", "text='Export'")
    version_block = (
        "        version_row = layout.row()\n"
        "        version_row.alignment = \"RIGHT\"\n"
        "        version_row.label(text=f\"v{ADDON_VERSION_TEXT}\")\n\n"
    )
    text = text.replace(version_block, "")
    text = text.replace(version_block.replace("\n", "\r\n"), "")
    return text.encode("utf-8")


def _replace_roblox_export_metadata(data):
    text = data.decode("utf-8")
    text = text.replace(
        'class OBJECT_OT_Bake(bpy.types.Operator):\n'
        '    bl_label = "Bake"\n'
        '    bl_idname = "object.rbxanims_bake"\n'
        '    bl_description = "Bake animation for export to clipboard"',
        'class OBJECT_OT_Bake(bpy.types.Operator):\n'
        '    bl_label = "Export"\n'
        '    bl_idname = "object.rbxanims_bake"\n'
        '    bl_description = "Export animation to clipboard"',
    )
    text = text.replace(
        'bl_description = "Bake animation for export to clipboard"',
        'bl_description = "Export animation to clipboard"',
    )
    return text.encode("utf-8")


def _prepare_roblox_addon_zip(filepath):
    repacked_path = f"{filepath}.install.zip"

    try:
        with zipfile.ZipFile(filepath) as package:
            infos = [info for info in package.infolist() if info.filename]
            normalized_names = []

            for info in infos:
                normalized = info.filename.replace("\\", "/").lstrip("/")
                parts = [part for part in normalized.split("/") if part]
                if not parts or ".." in parts:
                    raise RuntimeError("Downloaded ZIP contains an unsafe path.")
                normalized_names.append(normalized)

            if not any(name.endswith("__init__.py") for name in normalized_names):
                raise RuntimeError("Downloaded ZIP is not a Blender add-on package.")

            manifest_names = [
                name for name in normalized_names if name.endswith("blender_manifest.toml")
            ]
            if not manifest_names:
                raise RuntimeError("Downloaded ZIP has no Blender manifest.")
            manifest_name = min(manifest_names, key = lambda name: name.count("/"))
            manifest_parent = manifest_name.rsplit("/", 1)[0] if "/" in manifest_name else ""
            package_init_name = f"{manifest_parent}/__init__.py" if manifest_parent else "__init__.py"
            if package_init_name not in normalized_names:
                raise RuntimeError("Downloaded ZIP has no package __init__.py beside its manifest.")
            wrap_top_level = "__init__.py" in normalized_names

            with zipfile.ZipFile(repacked_path, "w", compression = zipfile.ZIP_DEFLATED) as output:
                for info, normalized in zip(infos, normalized_names):
                    target = f"{RBX_ADDON_ID}/{normalized}" if wrap_top_level else normalized
                    if info.is_dir():
                        output.writestr(f"{target.rstrip('/')}/", b"")
                        continue

                    data = package.read(info)
                    if normalized == manifest_name:
                        data = _replace_manifest_display_name(data, "Roblox Animator")
                    elif normalized == package_init_name:
                        data = _replace_bl_info_display_name(data, "Roblox Animator")
                    elif normalized.endswith("ui/panels.py"):
                        data = _replace_roblox_panel_display_name(data)
                    elif normalized.endswith("operators/animation_ops.py"):
                        data = _replace_roblox_export_metadata(data)
                    output.writestr(target, data)
    except Exception:
        if os.path.exists(repacked_path):
            try:
                os.remove(repacked_path)
            except OSError:
                pass
        raise

    os.remove(filepath)
    return repacked_path


def _install_roblox_addon(filepath):
    existing_module = _roblox_addon_module_name(refresh = True)
    if existing_module:
        disable = getattr(bpy.ops.preferences, "addon_disable", None)
        if disable is None:
            disable = getattr(bpy.ops.wm, "addon_disable", None)
        if disable is not None:
            try:
                disable(module = existing_module)
            except RuntimeError:
                pass

    install = getattr(bpy.ops.preferences, "addon_install", None)
    if install is None:
        install = getattr(bpy.ops.wm, "addon_install", None)
    if install is None:
        raise RuntimeError("This Blender build does not expose an add-on installer API.")

    try:
        install(overwrite = True, target = "DEFAULT", filepath = filepath)
    except TypeError:
        install(overwrite = True, filepath = filepath)

    module_name = _roblox_addon_module_name(refresh = True)
    if module_name is None:
        raise RuntimeError("Blender installed the package but could not locate its add-on module.")

    enable = getattr(bpy.ops.preferences, "addon_enable", None)
    if enable is None:
        enable = getattr(bpy.ops.wm, "addon_enable", None)
    if enable is None:
        raise RuntimeError("This Blender build does not expose an add-on enable API.")

    enable(module = module_name)
    bpy.app.timers.register(_configure_roblox_sidebar_tabs, first_interval = 0.1)


def _utils_addon_module_name(refresh = False):
    for module in addon_utils.modules(refresh = refresh):
        module_name = getattr(module, "__name__", "")
        if module_name == UTILS_ADDON_ID or module_name.endswith(f".{UTILS_ADDON_ID}"):
            return module_name
    return None


def _install_utils_addon(filepath):
    extension_ops = getattr(bpy.ops, "extensions", None)
    install = getattr(extension_ops, "package_install_files", None)
    if install is None:
        raise RuntimeError("This Blender build does not expose the extension installer API.")

    original_module_name = _utils_addon_module_name(refresh = True)
    was_enabled = bool(original_module_name and addon_utils.check(original_module_name)[1])
    if was_enabled:
        addon_utils.disable(original_module_name, default_set = True)

    try:
        try:
            result = install(
                "EXEC_DEFAULT",
                filepath = filepath,
                repo = "user_default",
                enable_on_install = True,
            )
        except TypeError:
            result = install("EXEC_DEFAULT", filepath = filepath, repo = "user_default")
        if "FINISHED" not in result:
            raise RuntimeError("Blender did not finish installing Roblox Animator Utils.")

        installed_module_name = _utils_addon_module_name(refresh = True)
        if installed_module_name is None:
            raise RuntimeError("Blender installed Utils but could not locate its module.")
        if not addon_utils.check(installed_module_name)[1]:
            try:
                addon_utils.enable(installed_module_name, default_set = True, persistent = True)
            except TypeError:
                addon_utils.enable(installed_module_name, default_set = True)
    except Exception:
        if (
            was_enabled
            and original_module_name
            and not addon_utils.check(original_module_name)[1]
        ):
            try:
                addon_utils.enable(original_module_name, default_set = True, persistent = True)
            except TypeError:
                addon_utils.enable(original_module_name, default_set = True)
        raise


def _iter_roblox_rig_armatures():
    seen = set()

    for collection in bpy.data.collections:
        if not collection.name.startswith("RIG: "):
            continue

        rig_name = _strip_blender_numeric_suffix(collection.name[5:].strip())
        if not rig_name or collection.children.get("Parts") is None:
            continue

        armature_name = f"__{rig_name}_Armature"
        meta_name = f"__{rig_name}Meta"
        armature = None
        has_meta = False

        for obj in collection.all_objects:
            obj_name = _strip_blender_numeric_suffix(obj.name)
            if obj.type == "ARMATURE" and obj_name == armature_name:
                armature = obj
            elif obj.type == "EMPTY" and obj_name == meta_name:
                has_meta = True

        if armature is not None and has_meta and armature.as_pointer() not in seen:
            seen.add(armature.as_pointer())
            yield armature


def _set_roblox_bone_visibility(armature, collection_name, predicate, hidden):
    bones = [bone for bone in armature.data.bones if predicate(bone)]
    if not bones:
        return 0

    # A bone can belong to multiple collections, so collection visibility alone
    # does not guarantee that Blender hides it in the viewport.
    for bone in bones:
        bone.hide = hidden

    try:
        bone_collections = armature.data.collections
        use_collections = True
    except Exception:
        bone_collections = None
        use_collections = False

    if use_collections:
        bone_collection = bone_collections.get(collection_name)
        if bone_collection is None:
            bone_collection = bone_collections.new(collection_name)
        for bone in bones:
            try:
                bone_collection.assign(bone)
            except RuntimeError:
                pass
        bone_collection.is_visible = not hidden
    return len(bones)


def _find_generated_roblox_armature(context, meta, previous_armatures):
    active = context.view_layer.objects.active
    if (
        active is not None
        and active.type == "ARMATURE"
        and active.as_pointer() not in previous_armatures
    ):
        return active

    settings = getattr(context.scene, "rbx_anim_settings", None)
    configured_name = getattr(settings, "rbx_anim_armature", "") if settings else ""
    configured = context.scene.objects.get(configured_name) if configured_name else None
    if (
        configured is not None
        and configured.type == "ARMATURE"
        and configured.as_pointer() not in previous_armatures
    ):
        return configured

    try:
        source_collections = tuple(meta.users_collection) if meta is not None else ()
    except ReferenceError:
        source_collections = ()

    for collection in source_collections:
        for obj in collection.all_objects:
            if obj.type == "ARMATURE" and obj.as_pointer() not in previous_armatures:
                return obj

    for obj in context.scene.objects:
        if obj.type == "ARMATURE" and obj.as_pointer() not in previous_armatures:
            return obj

    return None


def _find_roblox_parts_collection(armature):
    visited = set()
    pending = list(armature.users_collection)

    while pending:
        collection = pending.pop(0)
        pointer = collection.as_pointer()
        if pointer in visited:
            continue
        visited.add(pointer)
        if collection.name == "Parts" or collection.name.endswith("_Parts"):
            return collection
        pending.extend(collection.children)

    return None


def _normalize_roblox_part_constraints(armature):
    parts_collection = _find_roblox_parts_collection(armature)
    if parts_collection is None:
        return 0

    normalized = 0
    channel_names = (
        "use_location_x",
        "use_location_y",
        "use_location_z",
        "use_rotation_x",
        "use_rotation_y",
        "use_rotation_z",
        "use_scale_x",
        "use_scale_y",
        "use_scale_z",
    )

    for obj in parts_collection.all_objects:
        if obj.type != "MESH":
            continue

        constraints = [
            constraint for constraint in obj.constraints
            if constraint.type == "CHILD_OF" and constraint.target == armature
        ]
        if not constraints:
            continue

        valid_constraints = [
            constraint for constraint in constraints
            if constraint.subtarget and armature.data.bones.get(constraint.subtarget) is not None
        ]
        keep = valid_constraints[0] if valid_constraints else constraints[0]
        for constraint in constraints:
            if constraint is not keep:
                obj.constraints.remove(constraint)

        keep.influence = 1.0
        for channel_name in channel_names:
            if hasattr(keep, channel_name):
                setattr(keep, channel_name, True)

        bone = armature.data.bones.get(keep.subtarget)
        if bone is not None:
            bone_matrix = getattr(bone, "matrix_local", None)
            if bone_matrix is None:
                bone_matrix = bone.matrix
            if hasattr(bone_matrix, "to_4x4"):
                bone_matrix = bone_matrix.to_4x4()
            keep.inverse_matrix = (armature.matrix_world @ bone_matrix).inverted()
        normalized += 1

    return normalized


def _sync_armature_debug_overlays(advanced_mode):
    runtime_saved = _state.setdefault("armature_overlay_saved", {})

    for armature_data in bpy.data.armatures:
        pointer = int(armature_data.as_pointer())
        persisted = armature_data.get(ARMATURE_OVERLAY_STATE_KEY)

        if not advanced_mode:
            if persisted is None and pointer not in runtime_saved:
                original = (
                    bool(armature_data.show_axes),
                    bool(armature_data.show_names),
                )
                runtime_saved[pointer] = (armature_data, original)
                try:
                    armature_data[ARMATURE_OVERLAY_STATE_KEY] = list(original)
                except (AttributeError, RuntimeError, TypeError):
                    pass
            try:
                armature_data.show_axes = False
                armature_data.show_names = False
            except (AttributeError, RuntimeError, TypeError):
                pass
            continue

        original = None
        if persisted is not None and len(persisted) >= 2:
            original = (bool(persisted[0]), bool(persisted[1]))
        elif pointer in runtime_saved:
            original = runtime_saved[pointer][1]

        if original is not None:
            try:
                armature_data.show_axes = original[0]
                armature_data.show_names = original[1]
            except (AttributeError, RuntimeError, TypeError):
                pass
        try:
            if ARMATURE_OVERLAY_STATE_KEY in armature_data:
                del armature_data[ARMATURE_OVERLAY_STATE_KEY]
        except (AttributeError, RuntimeError, TypeError):
            pass
        runtime_saved.pop(pointer, None)


def _apply_roblox_compatibility(scene):
    wm = getattr(bpy.context, "window_manager", None)
    if wm is None:
        return

    advanced_mode = getattr(wm, "roblox_compat_advanced_mode", False)
    _sync_armature_debug_overlays(advanced_mode)

    if not _roblox_addon_is_enabled():
        return

    hide_welds = not advanced_mode
    hide_face_bones = not advanced_mode

    for armature in _iter_roblox_rig_armatures():
        pointer = armature.as_pointer()
        if pointer not in _state["roblox_constraints_normalized"]:
            _normalize_roblox_part_constraints(armature)
            _state["roblox_constraints_normalized"].add(pointer)
        _set_roblox_bone_visibility(
            armature,
            "_StaticalizaWeldBones",
            lambda bone: bone.get("rbx_joint_type") in {"Weld", "WeldConstraint"},
            hide_welds,
        )
        _set_roblox_bone_visibility(
            armature,
            "_StaticalizaFaceBones",
            lambda bone: bool(bone.get("rbx_face_deform_bone")),
            hide_face_bones,
        )


def _on_roblox_compatibility_setting_change(self, context):
    _apply_roblox_compatibility(context.scene)
    _tag_redraw_all_view3d()


def _on_hide_advanced_panels_change(self, context):
    window_manager = getattr(context, "window_manager", None)
    if window_manager is None:
        return
    for window in window_manager.windows:
        screen = window.screen
        if screen is None:
            continue
        for area in screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


def _sync_view3d_relationship_lines(context):
    window_manager = getattr(context, "window_manager", None)
    if window_manager is None:
        return

    show_lines = bool(
        getattr(window_manager, "roblox_compat_advanced_mode", False)
    )
    for window in window_manager.windows:
        screen = getattr(window, "screen", None)
        if screen is None:
            continue
        for area in screen.areas:
            if area.type != "VIEW_3D":
                continue
            for space in area.spaces:
                if space.type == "VIEW_3D":
                    space.overlay.show_relationship_lines = show_lines
            area.tag_redraw()


def _on_advanced_mode_change(self, context):
    _apply_roblox_compatibility(context.scene)
    _sync_view3d_relationship_lines(context)
    _on_hide_advanced_panels_change(self, context)


@persistent
def _roblox_compatibility_depsgraph_update(scene, depsgraph):
    normalized = _state.get("roblox_constraints_normalized", set())
    for update in depsgraph.updates:
        datablock = getattr(update, "id", None)
        if not isinstance(datablock, bpy.types.Object):
            continue
        if datablock.type == "ARMATURE" and datablock.as_pointer() not in normalized:
            _schedule_roblox_compatibility_scan()
            return


def _run_roblox_compatibility_scan():
    _state["roblox_compatibility_scan_pending"] = False
    context = bpy.context
    if context and context.scene:
        _apply_roblox_compatibility(context.scene)
    return None


def _schedule_roblox_compatibility_scan(delay = 0.15):
    if _state.get("roblox_compatibility_scan_pending", False):
        return
    _state["roblox_compatibility_scan_pending"] = True
    try:
        bpy.app.timers.register(
            _run_roblox_compatibility_scan,
            first_interval = delay,
        )
    except Exception:
        _state["roblox_compatibility_scan_pending"] = False


def _show_extension_update_result(message, icon):
    window_manager = getattr(bpy.context, "window_manager", None)
    if window_manager is None:
        print(f"[Roblox Animator Utils] {message}")
        return

    def draw(self, context):
        self.layout.label(text = message)

    window_manager.popup_menu(draw, title = "Extension Update", icon = icon)


def _perform_combined_extension_update():
    roblox_filepath = None
    utils_filepath = None

    if _extension_repository_is_locked():
        _state["extension_update_lock_waits"] += 1
        if _state["extension_update_lock_waits"] <= 20:
            return 0.5

        _show_extension_update_result(
            "Update paused because the User Default repository is still locked. "
            "Wait for the current install to finish or use Force Unlock Repository.",
            "ERROR",
        )
        _state["extension_update_running"] = False
        _state["extension_update_lock_waits"] = 0
        return None

    _state["extension_update_lock_waits"] = 0

    try:
        tag, asset_name, asset_url = _get_roblox_release_asset()
        roblox_filepath = _download_release_asset(asset_name, asset_url)
        utils_filepath, utils_version = _download_utils_package()

        # Keep Roblox Animator above Utils in the N-panel category order.
        _install_roblox_addon(roblox_filepath)
        _install_utils_addon(utils_filepath)
        _show_extension_update_result(
            f"Installed Roblox Animator {tag} and Roblox Animator Utils v{utils_version}.",
            "CHECKMARK",
        )
    except Exception as exc:
        _show_extension_update_result(f"Update failed: {exc}", "ERROR")
    finally:
        for filepath in (roblox_filepath, utils_filepath):
            if filepath and os.path.exists(filepath):
                try:
                    os.remove(filepath)
                except OSError:
                    pass
        _state["extension_update_running"] = False
        _state["extension_update_lock_waits"] = 0

    return None


class STATICALIZA_OT_install_roblox_animations(bpy.types.Operator):
    bl_idname = "staticaliza.install_roblox_animations"
    bl_label = "Install Latest Extension"
    bl_description = "Install or update Roblox Animator first, then Roblox Animator Utils"
    bl_options = {"REGISTER"}

    def execute(self, context):
        if not getattr(bpy.app, "online_access", True):
            self.report({"ERROR"}, "Blender online access is disabled in Preferences.")
            return {"CANCELLED"}

        if _state["extension_update_running"]:
            self.report({"WARNING"}, "An extension update is already running.")
            return {"CANCELLED"}

        _state["extension_update_running"] = True
        _state["extension_update_lock_waits"] = 0
        try:
            bpy.app.timers.register(_perform_combined_extension_update, first_interval = 0.1)
        except Exception as exc:
            _state["extension_update_running"] = False
            self.report({"ERROR"}, f"Could not start extension update: {exc}")
            return {"CANCELLED"}

        self.report({"INFO"}, "Downloading the latest Roblox Animator and Utils releases.")
        return {"FINISHED"}


class STATICALIZA_OT_open_roblox_plugins(bpy.types.Operator):
    bl_idname = "staticaliza.open_roblox_plugins"
    bl_label = "Install Roblox Plugins"
    bl_description = "Open both recommended Roblox animation plugins in the Creator Store"

    def execute(self, context):
        for url in (
            "https://create.roblox.com/store/asset/118148792788940",
            "https://create.roblox.com/store/asset/16708835782",
        ):
            bpy.ops.wm.url_open(url = url)
        return {"FINISHED"}


def _part_pivot_selected_bone(context):
    selected = _selected_pose_bones_only(context)
    active_bone = context.active_pose_bone
    if active_bone not in selected:
        active_bone = selected[0] if selected else None
    return active_bone


def _part_pivot_connected_object(context, armature, eval_armature, objects, pose_bone):
    canonical_name = _strip_blender_numeric_suffix(pose_bone.name)
    candidates = {}

    for level_index, level_names in enumerate(
        _pose_bone_numeric_family_levels(eval_armature, pose_bone)
    ):
        for obj in objects:
            if obj.type != "MESH" or not _is_object_visible(obj, context):
                continue

            exact_name = obj.name == canonical_name
            matching_name = _strip_blender_numeric_suffix(obj.name) == canonical_name
            directly_connected = (
                obj.parent == armature
                and obj.parent_type == "BONE"
                and getattr(obj, "parent_bone", "") in level_names
            )
            if not directly_connected:
                directly_connected = any(
                    getattr(constraint, "target", None) == armature
                    and getattr(constraint, "subtarget", "") in level_names
                    for constraint in obj.constraints
                )
            if not directly_connected:
                try:
                    directly_connected = any(
                        obj.vertex_groups.get(name) is not None
                        for name in level_names
                    )
                except (AttributeError, RuntimeError):
                    directly_connected = False

            # Objects in this list already belong to the active rig. An exact
            # object name is therefore a stronger match than a generic armature
            # modifier that does not expose a per-bone vertex group.
            if not (exact_name or matching_name or directly_connected):
                continue

            score = (
                0 if exact_name else 1 if matching_name else 2,
                level_index,
                0 if directly_connected else 1,
                1 if _object_has_linked_base_color(obj) else 0,
                obj.name.casefold(),
            )
            previous = candidates.get(obj.name)
            if previous is None or score < previous[0]:
                candidates[obj.name] = (score, obj)

    if not candidates:
        return None
    return min(candidates.values(), key = lambda item: item[0])[1]


def _part_pivot_target(context):
    armature = _active_armature(context)
    if armature is None or context.mode != "POSE":
        return None

    active_bone = _part_pivot_selected_bone(context)
    if active_bone is None:
        return None

    depsgraph = context.evaluated_depsgraph_get()
    eval_armature = armature.evaluated_get(depsgraph)
    objects, _target_armature = _targets(context)
    eval_pose_bone = eval_armature.pose.bones.get(active_bone.name)
    if eval_pose_bone is None:
        return None
    part = _part_pivot_connected_object(
        context,
        armature,
        eval_armature,
        objects,
        eval_pose_bone,
    )
    if part is None:
        return None

    eval_part = part.evaluated_get(depsgraph)
    local_bounds = None
    for corner in eval_part.bound_box:
        point = Vector(corner)
        if local_bounds is None:
            local_bounds = _bounds_init(point)
        else:
            _bounds_add(local_bounds, point)
    if local_bounds is None:
        return None

    local_center = Vector((
        (float(local_bounds[0]) + float(local_bounds[3])) * 0.5,
        (float(local_bounds[1]) + float(local_bounds[4])) * 0.5,
        (float(local_bounds[2]) + float(local_bounds[5])) * 0.5,
        1.0,
    ))
    return int(armature.as_pointer()), active_bone.name, part.name, local_center


def _view3d_spaces(context):
    window_manager = getattr(context, "window_manager", None)
    for window in getattr(window_manager, "windows", ()) if window_manager else ():
        screen = getattr(window, "screen", None)
        for area in getattr(screen, "areas", ()) if screen else ():
            if area.type != "VIEW_3D":
                continue
            for space in area.spaces:
                if space.type == "VIEW_3D":
                    yield space


def _hide_part_pivot_cursor(context):
    visibility = _state.setdefault("part_pivot_cursor_visibility", {})
    for space in _view3d_spaces(context):
        pointer = int(space.as_pointer())
        if pointer not in visibility:
            visibility[pointer] = bool(space.overlay.show_cursor)
        if space.overlay.show_cursor:
            space.overlay.show_cursor = False


def _restore_part_pivot_cursor(context):
    visibility = _state.get("part_pivot_cursor_visibility", {})
    for space in _view3d_spaces(context):
        pointer = int(space.as_pointer())
        if pointer in visibility:
            space.overlay.show_cursor = bool(visibility[pointer])
    _state["part_pivot_cursor_visibility"] = {}


def _sync_part_pivot(context, rematch = False):
    window_manager = getattr(context, "window_manager", None)
    if window_manager is None:
        return False
    if getattr(window_manager, "staticaliza_pivot_mode", "BONE") != "PART":
        return False
    if _state.get("part_pivot_syncing", False):
        return True

    _state["part_pivot_syncing"] = True
    try:
        armature = _active_armature(context)
        active_bone = _part_pivot_selected_bone(context) if context.mode == "POSE" else None
        armature_pointer = int(armature.as_pointer()) if armature else 0
        bone_name = active_bone.name if active_bone else ""
        if (
            rematch
            or armature_pointer != _state.get("part_pivot_armature", 0)
            or bone_name != _state.get("part_pivot_bone", "")
            or not _state.get("part_pivot_object", "")
        ):
            _state["part_pivot_armature"] = armature_pointer
            _state["part_pivot_bone"] = bone_name
            _state["part_pivot_object"] = ""
            _state["part_pivot_object_local"] = None
            _state["part_pivot_last_signature"] = None
            target = _part_pivot_target(context)
            if target is None:
                return False
            armature_pointer, bone_name, object_name, local_center = target
            _state["part_pivot_armature"] = armature_pointer
            _state["part_pivot_bone"] = bone_name
            _state["part_pivot_object"] = object_name
            _state["part_pivot_object_local"] = local_center.copy()
            _state["part_pivot_last_signature"] = None

        part = bpy.data.objects.get(_state.get("part_pivot_object", ""))
        local_center = _state.get("part_pivot_object_local")
        if part is None or local_center is None:
            return False

        depsgraph = context.evaluated_depsgraph_get()
        eval_part = part.evaluated_get(depsgraph)
        matrix_signature = tuple(float(value) for row in eval_part.matrix_world for value in row)
        signature = (armature_pointer, bone_name, part.name, matrix_signature)
        _hide_part_pivot_cursor(context)
        world_center = eval_part.matrix_world @ _as_p4(local_center)
        world_location = Vector(world_center[:3])
        world_rotation = eval_part.matrix_world.to_quaternion().normalized()
        cursor = context.scene.cursor
        same_location = (cursor.location - world_location).length_squared <= 1.0e-16
        same_rotation = (
            cursor.rotation_mode == "QUATERNION"
            and abs(float(cursor.rotation_quaternion.dot(world_rotation)))
            >= 1.0 - 1.0e-10
        )
        if context.scene.tool_settings.transform_pivot_point != "CURSOR":
            context.scene.tool_settings.transform_pivot_point = "CURSOR"
        if (
            signature == _state.get("part_pivot_last_signature")
            and same_location
            and same_rotation
        ):
            return True

        cursor.location = world_location
        context.scene.cursor.rotation_mode = "QUATERNION"
        cursor.rotation_quaternion = world_rotation
        _state["part_pivot_last_signature"] = signature
        return True
    finally:
        _state["part_pivot_syncing"] = False


def _disable_part_pivot(context):
    _restore_part_pivot_cursor(context)
    saved = _state.get("part_pivot_saved")
    if saved is not None:
        cursor = context.scene.cursor
        context.scene.tool_settings.transform_pivot_point = saved["pivot_point"]
        cursor.location = saved["cursor_location"]
        cursor.rotation_mode = "QUATERNION"
        cursor.rotation_quaternion = saved["cursor_rotation"]
        cursor.rotation_mode = saved["cursor_rotation_mode"]

    slot = context.scene.transform_orientation_slots[0]
    if slot.type == "CURSOR":
        slot.type = "LOCAL"

    window_manager = getattr(context, "window_manager", None)
    if window_manager is not None:
        window_manager.staticaliza_pivot_mode = "BONE"
    _state["part_pivot_bone"] = ""
    _state["part_pivot_armature"] = 0
    _state["part_pivot_object"] = ""
    _state["part_pivot_object_local"] = None
    _state["part_pivot_saved"] = None
    _state["part_pivot_last_signature"] = None
    _tag_redraw_all_view3d()


@persistent
def _part_pivot_depsgraph_update(_scene, _depsgraph):
    context = bpy.context
    window_manager = getattr(context, "window_manager", None)
    if (
        window_manager is not None
        and getattr(window_manager, "staticaliza_pivot_mode", "BONE") == "PART"
    ):
        _sync_part_pivot(context)


@persistent
def _part_pivot_frame_change_post(_scene, _depsgraph):
    _part_pivot_depsgraph_update(_scene, _depsgraph)


def _part_pivot_selection_timer():
    context = bpy.context
    window_manager = getattr(context, "window_manager", None)
    if (
        window_manager is None
        or getattr(window_manager, "staticaliza_pivot_mode", "BONE") != "PART"
    ):
        return 0.2

    armature = _active_armature(context)
    active_bone = _part_pivot_selected_bone(context) if context.mode == "POSE" else None
    armature_pointer = int(armature.as_pointer()) if armature else 0
    bone_name = active_bone.name if active_bone else ""
    changed = (
        armature_pointer != _state.get("part_pivot_armature", 0)
        or bone_name != _state.get("part_pivot_bone", "")
    )
    if changed:
        if active_bone is None:
            _state["part_pivot_armature"] = armature_pointer
            _state["part_pivot_bone"] = ""
            _state["part_pivot_object"] = ""
            _state["part_pivot_object_local"] = None
            _state["part_pivot_last_signature"] = None
        else:
            _sync_part_pivot(context, rematch = True)
        _tag_redraw_all_view3d()
    return 0.03


class STATICALIZA_OT_set_transform_orientation(bpy.types.Operator):
    bl_idname = "staticaliza.set_transform_orientation"
    bl_label = "Set Transform Orientation"
    bl_description = "Set or toggle the 3D View transform orientation between Global and Local"
    bl_options = {"REGISTER"}

    orientation: bpy.props.EnumProperty(
        items = (
            ("TOGGLE", "Toggle", "Toggle between Global and Local"),
            ("GLOBAL", "Global", "Use Global transform orientation"),
            ("LOCAL", "Local", "Use Local transform orientation"),
        ),
        default = "TOGGLE",
        options = {"SKIP_SAVE"},
    )

    def execute(self, context):
        slot = context.scene.transform_orientation_slots[0]
        target = self.orientation
        part_mode = (
            getattr(context.window_manager, "staticaliza_pivot_mode", "BONE")
            == "PART"
        )
        if target == "TOGGLE":
            local_types = {"CURSOR"} if part_mode else {"LOCAL"}
            target = "GLOBAL" if slot.type in local_types else "LOCAL"

        if target == "LOCAL" and part_mode:
            if not _sync_part_pivot(context):
                self.report({"ERROR"}, "Select a bone connected to a rig object.")
                return {"CANCELLED"}
            slot.type = "CURSOR"
        else:
            slot.type = target
        self.report({"INFO"}, f"Transform orientation: {target.title()}")
        return {"FINISHED"}


class STATICALIZA_OT_set_pivot_mode(bpy.types.Operator):
    bl_idname = "staticaliza.set_pivot_mode"
    bl_label = "Set Pivot Mode"
    bl_description = "Toggle between the normal bone pivot and the connected object pivot"
    bl_options = {"REGISTER"}

    pivot_mode: bpy.props.EnumProperty(
        items = (
            ("TOGGLE", "Toggle", "Toggle between Bone and Object pivot modes"),
            ("BONE", "Bone", "Use Blender's normal bone pivot"),
            ("PART", "Object", "Use the center and axes of the first connected rig object"),
        ),
        default = "TOGGLE",
        options = {"SKIP_SAVE"},
    )

    def execute(self, context):
        window_manager = context.window_manager
        current = getattr(window_manager, "staticaliza_pivot_mode", "BONE")
        target = self.pivot_mode
        if target == "TOGGLE":
            target = "PART" if current == "BONE" else "BONE"

        if target == "BONE":
            _disable_part_pivot(context)
            self.report({"INFO"}, "Pivot mode: Bone")
            return {"FINISHED"}

        if context.mode != "POSE" or not _selected_pose_bones_only(context):
            self.report({"ERROR"}, "Select a pose bone connected to a rig object.")
            return {"CANCELLED"}

        if current != "PART":
            cursor = context.scene.cursor
            original_rotation_mode = cursor.rotation_mode
            cursor.rotation_mode = "QUATERNION"
            original_rotation = cursor.rotation_quaternion.copy()
            cursor.rotation_mode = original_rotation_mode
            _state["part_pivot_saved"] = {
                "pivot_point": context.scene.tool_settings.transform_pivot_point,
                "cursor_location": cursor.location.copy(),
                "cursor_rotation": original_rotation,
                "cursor_rotation_mode": original_rotation_mode,
            }
        window_manager.staticaliza_pivot_mode = "PART"
        if not _sync_part_pivot(context, rematch = True):
            _disable_part_pivot(context)
            self.report({"ERROR"}, "No connected rig object was found for this bone.")
            return {"CANCELLED"}

        slot = context.scene.transform_orientation_slots[0]
        if slot.type == "LOCAL":
            slot.type = "CURSOR"
        self.report({"INFO"}, "Pivot mode: Object")
        _tag_redraw_all_view3d()
        return {"FINISHED"}


CAMERA_ORIENTATION_ITEMS = (
    ("X_POS", "+X", "Point the camera along the bone's positive X axis"),
    ("X_NEG", "-X", "Point the camera along the bone's negative X axis"),
    ("Y_POS", "+Y", "Point the camera along the bone's positive Y axis"),
    ("Y_NEG", "-Y", "Point the camera along the bone's negative Y axis"),
    ("Z_POS", "+Z", "Point the camera along the bone's positive Z axis"),
    ("Z_NEG", "-Z", "Point the camera along the bone's negative Z axis"),
)


CAMERA_FOV_PRESET_ITEMS = (
    ("CINEMATIC", "Cinematic (35°)", "Use a 35-degree horizontal field of view"),
    ("CLASSIC", "Classic (70°)", "Use a 70-degree horizontal field of view"),
    ("CUSTOM", "Custom", "Use the manually selected field of view"),
)


def _camera_bone_binding(camera):
    if camera is None or camera.type != "CAMERA":
        return None, ""
    if (
        camera.parent is not None
        and camera.parent.type == "ARMATURE"
        and camera.parent_type == "BONE"
        and camera.parent_bone
    ):
        return camera.parent, camera.parent_bone
    for constraint in camera.constraints:
        target = getattr(constraint, "target", None)
        subtarget = getattr(constraint, "subtarget", "")
        if constraint.type == "CHILD_OF" and target and target.type == "ARMATURE" and subtarget:
            return target, subtarget
    return None, ""


def _on_camera_fov_preset(window_manager, _context):
    if _state.get("camera_fov_syncing", False):
        return
    preset_angles = {
        "CINEMATIC": math.radians(35.0),
        "CLASSIC": math.radians(70.0),
    }
    angle = preset_angles.get(window_manager.staticaliza_camera_fov_preset)
    if angle is None:
        return
    _state["camera_fov_syncing"] = True
    try:
        window_manager.staticaliza_camera_fov = angle
    finally:
        _state["camera_fov_syncing"] = False


def _on_camera_fov_change(window_manager, _context):
    if _state.get("camera_fov_syncing", False):
        return
    angle = float(window_manager.staticaliza_camera_fov)
    if abs(angle - math.radians(35.0)) <= math.radians(0.01):
        preset = "CINEMATIC"
    elif abs(angle - math.radians(70.0)) <= math.radians(0.01):
        preset = "CLASSIC"
    else:
        preset = "CUSTOM"
    if window_manager.staticaliza_camera_fov_preset == preset:
        return
    _state["camera_fov_syncing"] = True
    try:
        window_manager.staticaliza_camera_fov_preset = preset
    finally:
        _state["camera_fov_syncing"] = False


def _camera_preset_from_angle(angle):
    if abs(float(angle) - math.radians(35.0)) <= math.radians(0.01):
        return "CINEMATIC"
    if abs(float(angle) - math.radians(70.0)) <= math.radians(0.01):
        return "CLASSIC"
    return "CUSTOM"


def _on_attached_camera_preset(camera, _context):
    if _state.get("camera_fov_syncing", False) or camera.type != "CAMERA":
        return
    angle = {
        "CINEMATIC": math.radians(35.0),
        "CLASSIC": math.radians(70.0),
    }.get(camera.staticaliza_camera_fov_preset)
    if angle is not None:
        camera.data.angle = angle


def _sync_attached_camera_preset(camera):
    if camera is None or camera.type != "CAMERA":
        return
    preset = _camera_preset_from_angle(camera.data.angle)
    if camera.staticaliza_camera_fov_preset == preset:
        return
    _state["camera_fov_syncing"] = True
    try:
        camera.staticaliza_camera_fov_preset = preset
    finally:
        _state["camera_fov_syncing"] = False


def _camera_for_bone(scene, armature, bone_name):
    matches = []
    for camera in scene.objects:
        if camera.type != "CAMERA":
            continue
        target, subtarget = _camera_bone_binding(camera)
        if target == armature and subtarget == bone_name:
            matches.append(camera)
    if scene.camera in matches:
        return scene.camera
    return matches[0] if matches else None


def _selected_camera_bone(context):
    if context.mode != "POSE":
        return None, None, None
    armature = _active_armature(context)
    if armature is None:
        return None, None, None
    selected = _selected_pose_bones_only(context)
    active = context.active_pose_bone
    ordered = []
    if active in selected:
        ordered.append(active)
    ordered.extend(pose_bone for pose_bone in selected if pose_bone not in ordered)
    for pose_bone in ordered:
        camera = _camera_for_bone(context.scene, armature, pose_bone.name)
        if camera is not None:
            return armature, pose_bone, camera
    return None, None, None


def _standalone_camera(context):
    candidates = []
    active = context.active_object
    if active is not None and active.type == "CAMERA":
        candidates.append(active)
    if context.scene.camera is not None:
        candidates.append(context.scene.camera)
    candidates.extend(obj for obj in context.scene.objects if obj.type == "CAMERA")
    seen = set()
    for camera in candidates:
        pointer = int(camera.as_pointer())
        if pointer in seen:
            continue
        seen.add(pointer)
        target, bone_name = _camera_bone_binding(camera)
        if target is None or not bone_name:
            return camera
    return None


def _view_camera_matrix(context):
    region_data = getattr(context, "region_data", None)
    if region_data is None:
        return None
    try:
        matrix = region_data.view_matrix.inverted()
        location, rotation, _scale = matrix.decompose()
        result = rotation.to_matrix().to_4x4()
        result.translation = location
        return result
    except Exception:
        return None


def _camera_world_at_bone_tip(armature, pose_bone, orientation = "Z_NEG"):
    bone_world = armature.matrix_world @ pose_bone.matrix
    axes = bone_world.to_3x3().normalized()
    local_direction = {
        "X_POS": Vector((1.0, 0.0, 0.0)),
        "X_NEG": Vector((-1.0, 0.0, 0.0)),
        "Y_POS": Vector((0.0, 1.0, 0.0)),
        "Y_NEG": Vector((0.0, -1.0, 0.0)),
        "Z_POS": Vector((0.0, 0.0, 1.0)),
        "Z_NEG": Vector((0.0, 0.0, -1.0)),
    }.get(orientation, Vector((0.0, 0.0, -1.0)))
    forward = (axes @ local_direction).normalized()
    up_reference = axes.col[2].normalized()
    if abs(float(forward.dot(up_reference))) >= 0.999:
        up_reference = axes.col[1].normalized()
    x_axis = forward.cross(up_reference).normalized()
    up_axis = (-forward).cross(x_axis).normalized()
    matrix = Matrix((
        (x_axis.x, up_axis.x, -forward.x, 0.0),
        (x_axis.y, up_axis.y, -forward.y, 0.0),
        (x_axis.z, up_axis.z, -forward.z, 0.0),
        (0.0, 0.0, 0.0, 1.0),
    ))
    matrix.translation = bone_world @ Vector((0.0, pose_bone.length, 0.0))
    return matrix


def _on_attached_camera_orientation(camera, context):
    if camera.type != "CAMERA":
        return
    armature, bone_name = _camera_bone_binding(camera)
    if armature is None or not bone_name:
        return
    pose_bone = armature.pose.bones.get(bone_name)
    if pose_bone is None:
        return
    camera.matrix_world = _camera_world_at_bone_tip(
        armature,
        pose_bone,
        camera.staticaliza_camera_orientation,
    )
    try:
        context.view_layer.update()
    except Exception:
        pass


def _insert_camera_bone_keys(armature, pose_bone, frame):
    frame = int(frame)
    group = pose_bone.name
    options = {"INSERTKEY_VISUAL"}
    base = f'pose.bones["{pose_bone.name}"]'
    armature.keyframe_insert(
        data_path = f"{base}.location",
        frame = frame,
        group = group,
        options = options,
    )
    if pose_bone.rotation_mode == "QUATERNION":
        rotation_path = "rotation_quaternion"
    elif pose_bone.rotation_mode == "AXIS_ANGLE":
        rotation_path = "rotation_axis_angle"
    else:
        rotation_path = "rotation_euler"
    armature.keyframe_insert(
        data_path = f"{base}.{rotation_path}",
        frame = frame,
        group = group,
        options = options,
    )
    armature.keyframe_insert(
        data_path = f"{base}.scale",
        frame = frame,
        group = group,
        options = options,
    )
    _set_keyframe_handles_auto(armature, frame)


def _keyframe_camera_bone(context, armature, pose_bone, camera, camera_world):
    action = armature.animation_data.action if armature.animation_data else None
    object_keys_before = _snapshot_object_keys_all(action)
    previous_autokey = _autokey_push(context)
    try:
        depsgraph = context.evaluated_depsgraph_get()
        evaluated_armature = armature.evaluated_get(depsgraph)
        evaluated_bone = evaluated_armature.pose.bones.get(pose_bone.name)
        if evaluated_bone is None:
            return False
        evaluated_camera = camera.evaluated_get(depsgraph)
        bone_world = evaluated_armature.matrix_world @ evaluated_bone.matrix
        relative_camera = bone_world.inverted() @ evaluated_camera.matrix_world
        desired_bone_world = camera_world @ relative_camera.inverted()
        pose_bone.matrix = armature.matrix_world.inverted() @ desired_bone_world
        context.view_layer.update()
        _insert_camera_bone_keys(
            armature,
            pose_bone,
            int(context.scene.frame_current),
        )
        context.view_layer.update()
        return True
    except Exception:
        return False
    finally:
        current_action = armature.animation_data.action if armature.animation_data else None
        _cleanup_new_object_keys_all(current_action, object_keys_before)
        _autokey_pop(context, previous_autokey)


def _keyframe_standalone_camera(camera, frame, camera_world):
    camera.matrix_world = camera_world
    camera.keyframe_insert(data_path = "location", frame = int(frame))
    if camera.rotation_mode == "QUATERNION":
        camera.keyframe_insert(data_path = "rotation_quaternion", frame = int(frame))
    elif camera.rotation_mode == "AXIS_ANGLE":
        camera.keyframe_insert(data_path = "rotation_axis_angle", frame = int(frame))
    else:
        camera.keyframe_insert(data_path = "rotation_euler", frame = int(frame))
    _set_keyframe_handles_auto(camera, frame)


def _objects_affiliated_with_camera_bone(scene, camera):
    armature, bone_name = _camera_bone_binding(camera)
    if armature is None or not bone_name:
        return []
    objects = []
    for obj in scene.objects:
        if obj == camera or obj.type != "MESH":
            continue
        matches = (
            obj.parent == armature
            and obj.parent_type == "BONE"
            and obj.parent_bone == bone_name
        )
        if not matches:
            for constraint in obj.constraints:
                if (
                    getattr(constraint, "target", None) == armature
                    and getattr(constraint, "subtarget", "") == bone_name
                ):
                    matches = True
                    break
        if matches:
            objects.append(obj)
    return objects


def _set_attached_camera_object_visibility(scene, camera, hidden):
    for obj in _objects_affiliated_with_camera_bone(scene, camera):
        obj.hide_viewport = bool(hidden)
        obj.hide_render = bool(hidden)


def _sync_all_attached_camera_object_visibility():
    for scene in bpy.data.scenes:
        for camera in (obj for obj in scene.objects if obj.type == "CAMERA"):
            armature, bone_name = _camera_bone_binding(camera)
            if armature is None or not bone_name:
                continue
            hidden = getattr(
                camera,
                "staticaliza_camera_hide_attached_object",
                True,
            )
            _set_attached_camera_object_visibility(scene, camera, hidden)
    return None


def _on_camera_attached_object_hide_change(camera, context):
    scenes = list(camera.users_scene)
    if context and context.scene and context.scene not in scenes:
        scenes.append(context.scene)
    for scene in scenes:
        _set_attached_camera_object_visibility(
            scene,
            camera,
            camera.staticaliza_camera_hide_attached_object,
        )


def _level_free_view_rotation(region_data):
    rotation = region_data.view_rotation.copy()
    direction = (rotation @ Vector((0.0, 0.0, -1.0))).normalized()
    world_up = Vector((0.0, 0.0, 1.0))
    if abs(direction.dot(world_up)) >= 1.0 - 1.0e-10:
        return False
    region_data.view_rotation = direction.to_track_quat("-Z", "Y")
    return True


def _set_default_keyframe_handle_type():
    preferences = getattr(bpy.context, "preferences", None)
    edit_preferences = getattr(preferences, "edit", None)
    if edit_preferences is None or not hasattr(
        edit_preferences,
        "keyframe_new_handle_type",
    ):
        return False
    try:
        edit_preferences.keyframe_new_handle_type = "AUTO"
    except (AttributeError, TypeError, ValueError):
        return False
    return edit_preferences.keyframe_new_handle_type == "AUTO"


def _camera_view_state(previous = None):
    if isinstance(previous, dict):
        return previous
    return {
        "attached": bool(previous),
        "pending_level": False,
        "last_rotation": None,
        "stable_ticks": 0,
    }


def _camera_view_exit_timer():
    context = bpy.context
    window_manager = getattr(context, "window_manager", None)
    states = _state.setdefault("camera_view_spaces", {})
    live_spaces = set()
    if window_manager is not None:
        for window in window_manager.windows:
            scene = window.scene
            for area in window.screen.areas:
                if area.type != "VIEW_3D":
                    continue
                for space in area.spaces:
                    if space.type != "VIEW_3D":
                        continue
                    region_data = getattr(space, "region_3d", None)
                    if region_data is None:
                        continue
                    pointer = int(space.as_pointer())
                    live_spaces.add(pointer)
                    state = _camera_view_state(states.get(pointer))
                    in_camera_view = region_data.view_perspective == "CAMERA"
                    if in_camera_view:
                        camera = getattr(space, "camera", None) or scene.camera
                        armature, bone_name = _camera_bone_binding(camera)
                        state["attached"] = bool(armature is not None and bone_name)
                        state["pending_level"] = False
                        state["last_rotation"] = None
                        state["stable_ticks"] = 0
                    else:
                        current_rotation = region_data.view_rotation.copy()
                        if state["attached"]:
                            state["attached"] = False
                            state["pending_level"] = True
                            state["last_rotation"] = current_rotation
                            state["stable_ticks"] = 0
                        elif state["pending_level"]:
                            last_rotation = state["last_rotation"]
                            changed = (
                                last_rotation is None
                                or abs(current_rotation.dot(last_rotation)) < 1.0 - 1.0e-12
                            )
                            if changed:
                                state["last_rotation"] = current_rotation
                                state["stable_ticks"] = 0
                            else:
                                state["stable_ticks"] += 1
                                if state["stable_ticks"] >= 2:
                                    if _level_free_view_rotation(region_data):
                                        area.tag_redraw()
                                    state["pending_level"] = False
                                    state["last_rotation"] = None
                                    state["stable_ticks"] = 0
                    states[pointer] = state

    for pointer in tuple(states):
        if pointer not in live_spaces:
            states.pop(pointer, None)
    return 0.05


class STATICALIZA_OT_add_bone_camera(bpy.types.Operator):
    bl_idname = "staticaliza.add_bone_camera"
    bl_label = "Create Camera"
    bl_description = "Create or remove the camera rigidly attached to the selected pose bone"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE" and bool(_selected_pose_bones_only(context))

    def execute(self, context):
        armature = _active_armature(context)
        selected = _selected_pose_bones_only(context)
        pose_bone = context.active_pose_bone
        if pose_bone not in selected:
            pose_bone = selected[0] if selected else None
        if armature is None or pose_bone is None:
            return {"CANCELLED"}

        existing_camera = _camera_for_bone(context.scene, armature, pose_bone.name)
        if existing_camera is not None:
            _set_attached_camera_object_visibility(
                context.scene,
                existing_camera,
                False,
            )
            camera_data = existing_camera.data
            if context.scene.camera == existing_camera:
                context.scene.camera = None
            bpy.data.objects.remove(existing_camera, do_unlink = True)
            if camera_data.users == 0:
                bpy.data.cameras.remove(camera_data)
            self.report({"INFO"}, f"Removed camera from {pose_bone.name}.")
            return {"FINISHED"}

        camera_data = bpy.data.cameras.new(f"Camera - {pose_bone.name}")
        camera_data.type = "PERSP"
        camera_data.sensor_fit = "HORIZONTAL"
        camera_data.angle = context.window_manager.staticaliza_camera_fov

        camera = bpy.data.objects.new(camera_data.name, camera_data)
        context.collection.objects.link(camera)
        camera.staticaliza_camera_fov_preset = (
            context.window_manager.staticaliza_camera_fov_preset
        )
        camera.staticaliza_camera_orientation = (
            context.window_manager.staticaliza_camera_orientation
        )
        camera_world = _camera_world_at_bone_tip(
            armature,
            pose_bone,
            camera.staticaliza_camera_orientation,
        )
        camera.parent = armature
        camera.parent_type = "BONE"
        camera.parent_bone = pose_bone.name
        camera.matrix_parent_inverse = Matrix.Identity(4)
        camera.matrix_world = camera_world
        camera.staticaliza_camera_hide_attached_object = True
        _set_attached_camera_object_visibility(context.scene, camera, True)
        context.scene.render.resolution_x = 1920
        context.scene.render.resolution_y = 1080
        context.scene.render.resolution_percentage = 100
        context.scene.camera = camera
        context.view_layer.update()
        self.report({"INFO"}, f"Added camera to {pose_bone.name}.")
        return {"FINISHED"}


class STATICALIZA_OT_keyframe_camera_view(bpy.types.Operator):
    bl_idname = "staticaliza.keyframe_camera_view"
    bl_label = "Keyframe Camera to View"
    bl_description = "Move the selected bone camera to the current view and insert a keyframe"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        camera_world = _view_camera_matrix(context)
        if camera_world is None:
            return {"FINISHED"}

        armature, pose_bone, camera = _selected_camera_bone(context)
        if camera is not None:
            if _keyframe_camera_bone(context, armature, pose_bone, camera, camera_world):
                context.scene.camera = camera
                self.report({"INFO"}, f"Keyframed camera bone {pose_bone.name}.")
            return {"FINISHED"}

        camera = _standalone_camera(context)
        if camera is None:
            return {"FINISHED"}
        _keyframe_standalone_camera(camera, context.scene.frame_current, camera_world)
        context.scene.camera = camera
        context.view_layer.update()
        self.report({"INFO"}, f"Keyframed camera {camera.name}.")
        return {"FINISHED"}


class STATICALIZA_OT_load_template(bpy.types.Operator):
    bl_idname = "staticaliza.load_template"
    bl_label = "Load Template"
    bl_description = "Replace the current Blender file with the bundled animation template"

    def draw(self, context):
        layout = self.layout
        layout.label(text = "This replaces the entire current Blender file.", icon = "ERROR")
        layout.label(text = "All unsaved changes will be permanently lost.")
        layout.separator()
        layout.label(text = "Continue and load the animation template?")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width = 440)

    def execute(self, context):
        templates_directory = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "templates",
        )
        template_path = os.path.join(templates_directory, "template.blend")
        baseplate_path = os.path.join(templates_directory, "Baseplate.png")
        if not os.path.isfile(template_path):
            self.report({"ERROR"}, "The bundled animation template is missing.")
            return {"CANCELLED"}
        if not os.path.isfile(baseplate_path):
            self.report({"ERROR"}, "The bundled Baseplate.png is missing.")
            return {"CANCELLED"}

        bpy.ops.wm.read_homefile(filepath = template_path, load_ui = True)
        _set_default_keyframe_handle_type()
        image = bpy.data.images.get("Baseplate.png")
        if image is None:
            image = bpy.data.images.load(baseplate_path, check_existing = True)
        else:
            image.filepath = baseplate_path
            image.reload()
        return {"FINISHED"}


def _dynamic_unparent_ui_state(context):
    if context.mode != "POSE":
        return (False, False, False, False)

    arm = _active_armature(context)
    bones = _selected_pose_bones_only(context)
    if not arm or not bones:
        return (False, False, False, False)

    action = arm.animation_data.action if arm.animation_data else None
    frame = int(context.scene.frame_current)
    can_start = False
    can_end = False
    can_clear = False
    can_bake = False

    for pose_bone in bones:
        if not pose_bone:
            continue
        auto_starts = _dp_auto_unparent_start_frames(pose_bone)
        active_start = (
            _unparent_find_active_start_frame(
                action,
                pose_bone.name,
                frame,
            )
            if action
            else None
        )
        active = bool(
            action
            and _unparent_eval(
                action,
                pose_bone.name,
                frame,
                pb_default = 0.0,
            ) >= 0.5
        )
        active_is_manual = bool(
            active
            and active_start is not None
            and int(active_start) not in auto_starts
        )
        active_is_auto = bool(
            active
            and active_start is not None
            and int(active_start) in auto_starts
        )
        if active_is_auto:
            continue
        has_parent = bool(
            pose_bone.parent
            or str(pose_bone.bone.get(REL_K_PARENT, ""))
        )
        manual_start, _manual_end = _unparent_nearest_segment(
            action,
            pose_bone.name,
            frame,
            excluded_starts = auto_starts,
        )
        has_markers = manual_start is not None
        can_start = can_start or (has_parent and not active)
        can_end = can_end or active_is_manual
        can_clear = can_clear or has_markers
        can_bake = can_bake or has_markers

    return (can_start, can_end, can_clear, can_bake)


def _dynamic_parent_target(context):
    if context.mode == "POSE":
        return context.active_pose_bone
    if context.mode == "OBJECT":
        return context.active_object
    return None


def _dynamic_parent_has_data(target):
    if target is None:
        return False
    return any(constraint.name.startswith("DP_") for constraint in target.constraints)


def _dynamic_parent_can_create(context):
    target = _dynamic_parent_target(context)
    if target is None or get_last_dynamic_parent_constraint(target) is not None:
        return False
    if context.mode == "OBJECT":
        return len(context.selected_objects) == 2
    if context.mode == "POSE":
        selected_pose_bones = context.selected_pose_bones or ()
        selected_objects = context.selected_objects or ()
        return len(selected_pose_bones) >= 2 or len(selected_objects) == 2
    return False


def _dynamic_parent_can_end(context):
    target = _dynamic_parent_target(context)
    return bool(target and get_last_dynamic_parent_constraint(target))

class VIEW3D_PT_staticaliza_roblox_animator_anchor(bpy.types.Panel):
    bl_label = "Roblox Animator"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Roblox Animator"
    bl_options = {"HIDE_HEADER"}

    @classmethod
    def poll(cls, context):
        return False

    def draw(self, context):
        pass


class VIEW3D_PT_staticaliza_main(bpy.types.Panel):
    bl_label = "Roblox Animator Utils (v" + ".".join(str(part) for part in ADDON_VERSION) + ")"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Roblox Animator Utils"

    def draw(self, context):
        wm = context.window_manager
        layout = self.layout
        advanced_mode = getattr(wm, "roblox_compat_advanced_mode", False)
        hide_advanced = not advanced_mode

        template = layout.box()
        template.label(text = "Scene Setup")
        template.operator("staticaliza.load_template", text = "Load Template")

        onion_tools = layout.box()
        onion_tools.label(text = "Onion Tools")

        onion = onion_tools.column(align = True)
        onion.label(text = "Onion Skin (F)")

        row = onion.row(align = True)
        row.prop(wm, "onion_skin_enabled", toggle = True, text = "Toggle")

        if advanced_mode:
            col = onion.column()
            col.prop(wm, "onion_skin_opacity", text = "Opacity")

            row2 = col.row(align = True)
            row2.prop(wm, "onion_skin_include_meshes", text = "Meshes")
            row2.prop(wm, "onion_skin_include_bones", text = "Bones")

            col.prop(wm, "onion_skin_raycast", text = "Raycast")
            col.prop(wm, "onion_skin_skip_hidden", text = "Skip Hidden")

        if _state["last_error"]:
            err = onion.box()
            err.label(text = "Last Error:")
            err.label(text = _state["last_error"])

        onion_tools.separator()
        yellow = onion_tools.column(align = True)
        yellow.label(text = "Onion Pin (Shift + F)")
        yellow.prop(wm, "yellow_pin_mode", text = "Position")
        rowy = yellow.row(align = True)
        rowy.operator("staticaliza.yellow_menu", text = "Create Pin")
        yellow.operator("staticaliza.yellow_clear_all", text = "Clear")
        if advanced_mode:
            yellow.label(text = f"Pinned: {len(_state.get('yellow_modes', {}))} | Hidden: {bool(_state.get('yellow_hidden', False))}")

        dynamic_tools = layout.box()
        dynamic_tools.label(text = "Dynamic Tools (Alt + F)")

        dp = dynamic_tools.column(align = True)
        dp.label(text = "Dynamic Parent")

        rowdp = dp.row(align = True)
        parent_start = rowdp.column(align = True)
        parent_start.enabled = _dynamic_parent_can_create(context)
        parent_start.operator("dynamic_parent.create", text = "Create Start")
        parent_end = rowdp.column(align = True)
        parent_end.enabled = _dynamic_parent_can_end(context)
        parent_end.operator("dynamic_parent.disable", text = "Create End")

        if hide_advanced:
            parent_clear = dp.column(align = True)
            parent_clear.enabled = _dynamic_parent_has_data(
                _dynamic_parent_target(context)
            )
            parent_clear.operator("dynamic_parent.clear", text = "Clear")
        else:
            rowdp2 = dp.row(align = True)
            parent_clear = rowdp2.column(align = True)
            parent_clear.enabled = _dynamic_parent_has_data(
                _dynamic_parent_target(context)
            )
            parent_clear.operator("dynamic_parent.clear", text = "Clear")
            parent_bake = rowdp2.column(align = True)
            parent_bake.enabled = _dynamic_parent_has_data(
                _dynamic_parent_target(context)
            )
            parent_bake.operator("dynamic_parent.bake", text = "Bake")

        dynamic_tools.separator()
        unparent = dynamic_tools.column(align = True)
        unparent.label(text = "Dynamic Unparent")
        can_unparent_start, can_unparent_end, can_unparent_clear, can_unparent_bake = (
            _dynamic_unparent_ui_state(context)
        )
        unparent_actions = unparent.row(align = True)
        unparent_start = unparent_actions.column(align = True)
        unparent_start.enabled = can_unparent_start
        start_operator = unparent_start.operator(
            "staticaliza.unparent_action",
            text = "Create Start",
        )
        start_operator.action = "START"
        unparent_end = unparent_actions.column(align = True)
        unparent_end.enabled = can_unparent_end
        end_operator = unparent_end.operator(
            "staticaliza.unparent_action",
            text = "Create End",
        )
        end_operator.action = "END"

        if hide_advanced:
            unparent_clear = unparent.column(align = True)
            unparent_clear.enabled = can_unparent_clear
            clear_operator = unparent_clear.operator(
                "staticaliza.unparent_action",
                text = "Clear",
            )
            clear_operator.action = "CLEAR"
        else:
            unparent_tools = unparent.row(align = True)
            unparent_clear = unparent_tools.column(align = True)
            unparent_clear.enabled = can_unparent_clear
            clear_operator = unparent_clear.operator(
                "staticaliza.unparent_action",
                text = "Clear",
            )
            clear_operator.action = "CLEAR"
            unparent_bake = unparent_tools.column(align = True)
            unparent_bake.enabled = can_unparent_bake
            bake_operator = unparent_bake.operator(
                "staticaliza.unparent_action",
                text = "Bake",
            )
            bake_operator.action = "BAKE_TO_ENDING"

        transform_tools = layout.box()
        transform_tools.label(text = "Transform Tools")
        transform_tools.label(text = "Orientation (Y)")
        orientation = context.scene.transform_orientation_slots[0].type
        pivot_mode = getattr(wm, "staticaliza_pivot_mode", "BONE")
        orientation_row = transform_tools.row(align = True)
        global_op = orientation_row.operator(
            "staticaliza.set_transform_orientation",
            text = "Global",
            depress = orientation == "GLOBAL",
        )
        global_op.orientation = "GLOBAL"
        local_op = orientation_row.operator(
            "staticaliza.set_transform_orientation",
            text = "Local",
            depress = orientation == ("CURSOR" if pivot_mode == "PART" else "LOCAL"),
        )
        local_op.orientation = "LOCAL"

        transform_tools.label(text = "Pivot (Shift + Y)")
        pivot_row = transform_tools.row(align = True)
        bone_pivot = pivot_row.operator(
            "staticaliza.set_pivot_mode",
            text = "Bone",
            depress = pivot_mode == "BONE",
        )
        bone_pivot.pivot_mode = "BONE"
        part_pivot_column = pivot_row.column(align = True)
        part_pivot_column.enabled = (
            pivot_mode == "PART"
            or (context.mode == "POSE" and bool(_selected_pose_bones_only(context)))
        )
        part_pivot = part_pivot_column.operator(
            "staticaliza.set_pivot_mode",
            text = "Object",
            depress = pivot_mode == "PART",
        )
        part_pivot.pivot_mode = "PART"

        camera_tools = layout.box()
        camera_tools.label(text = "Camera (Ctrl + Alt + NumPad 0)")
        _camera_armature, _camera_bone, attached_camera = _selected_camera_bone(context)
        if attached_camera is not None:
            _sync_attached_camera_preset(attached_camera)
            camera_tools.prop(
                attached_camera,
                "staticaliza_camera_fov_preset",
                text = "Preset",
            )
            if attached_camera.staticaliza_camera_fov_preset == "CUSTOM":
                camera_tools.prop(attached_camera.data, "angle", text = "FOV")
            camera_tools.prop(
                attached_camera,
                "staticaliza_camera_orientation",
                text = "Orientation",
            )
            camera_tools.prop(
                attached_camera,
                "staticaliza_camera_hide_attached_object",
                text = "Hide Attached Object",
            )
        else:
            camera_tools.prop(wm, "staticaliza_camera_fov_preset", text = "Preset")
            if wm.staticaliza_camera_fov_preset == "CUSTOM":
                camera_tools.prop(wm, "staticaliza_camera_fov", text = "FOV")
            camera_tools.prop(
                wm,
                "staticaliza_camera_orientation",
                text = "Orientation",
            )
        add_camera = camera_tools.column(align = True)
        add_camera.enabled = context.mode == "POSE" and bool(
            _selected_pose_bones_only(context)
        )
        add_camera.operator(
            "staticaliza.add_bone_camera",
            text = "Remove Camera" if attached_camera is not None else "Create Camera",
            icon = "TRASH" if attached_camera is not None else "CAMERA_DATA",
        )

        materials = layout.box()
        materials.label(text = "Materials")
        if advanced_mode:
            materials.prop(wm, "smart_material_import_enabled", text = "Smart Material Import")
            materials.prop(
                wm,
                "standardize_imported_material_display_enabled",
                text = "Standardize Viewport Display",
            )
            materials.prop(
                wm,
                "prevent_clothing_layer_clipping_enabled",
                text = "Prevent Clothing Clipping",
            )
        materials.operator("dynamic_parent.clear_material_links", text = "Clear")

        roblox = layout.box()
        roblox.label(text = "Roblox Animator")
        roblox.operator("staticaliza.install_roblox_animations", text = "Install Latest Extension")
        roblox.operator("staticaliza.open_roblox_plugins", text = "Install Roblox Plugins")
        roblox.prop(wm, "roblox_compat_advanced_mode", text = "Advanced Mode")


_ADVANCED_ROBLOX_PANEL_HEADERS = frozenset({"Roblox Account", "UGC Emote Validation"})
_FACE_ROBLOX_PANEL_HEADERS = frozenset({"Face Controls"})
_ADVANCED_ROBLOX_OPERATORS = frozenset({
    "object.rbxanims_genrig",
    "object.rbxanims_autoconstraint",
    "object.rbxanims_manualconstraint",
    "object.rbxanims_toggle_weld_bones",
    "object.rbxanims_toggle_com",
    "object.rbxanims_toggle_com_grid",
    "object.rbxanims_edit_com_weights",
    "object.rbxanims_mapkeyframes",
    "object.rbxanims_applytransform",
    "object.rbxanims_bake_file",
    "object.rbxanims_importfbxanimation",
})
_ADVANCED_ROBLOX_PROPERTIES = frozenset({
    "rbx_auto_deform_scale",
    "rbx_deform_rig_scale",
    "rbx_full_range_bake",
})
_ADVANCED_ROBLOX_LABELS = frozenset({"Center of Mass:"})


def _roblox_operator_ui_kwargs(operator_id, kwargs):
    updated = dict(kwargs)
    if operator_id == "object.rbxanims_bake":
        updated["text"] = "Export"
    elif operator_id == "object.rbxanims_importmodel":
        updated["text"] = "Import Rig"
    return updated


class _NullOperatorProperties:
    def __setattr__(self, name, value):
        pass


class _NullUILayout:
    def __setattr__(self, name, value):
        pass

    def row(self, *args, **kwargs):
        return self

    def column(self, *args, **kwargs):
        return self

    def column_flow(self, *args, **kwargs):
        return self

    def grid_flow(self, *args, **kwargs):
        return self

    def split(self, *args, **kwargs):
        return self

    def box(self, *args, **kwargs):
        return self

    def operator(self, *args, **kwargs):
        return _NullOperatorProperties()

    def __getattr__(self, name):
        return lambda *args, **kwargs: None


_NULL_UI_LAYOUT = _NullUILayout()
_UI_CONTAINER_METHODS = frozenset({"row", "column", "column_flow", "grid_flow", "split"})


class _UILayoutProxy:
    __slots__ = ("_layout", "_hidden_headers", "_hide_advanced")

    def __init__(self, layout, hidden_headers, hide_advanced = False):
        object.__setattr__(self, "_layout", layout)
        object.__setattr__(self, "_hidden_headers", hidden_headers)
        object.__setattr__(self, "_hide_advanced", hide_advanced)

    def box(self, *args, **kwargs):
        return _LazyBoxProxy(
            self._layout,
            self._hidden_headers,
            self._hide_advanced,
            args,
            kwargs,
        )

    def label(self, *args, **kwargs):
        text = kwargs.get("text", args[0] if args else "")
        if self._hide_advanced and text in _ADVANCED_ROBLOX_LABELS:
            return None
        return self._layout.label(*args, **kwargs)

    def operator(self, *args, **kwargs):
        operator_id = args[0] if args else kwargs.get("operator", "")
        if self._hide_advanced and operator_id in _ADVANCED_ROBLOX_OPERATORS:
            return _NullOperatorProperties()
        kwargs = _roblox_operator_ui_kwargs(operator_id, kwargs)
        return self._layout.operator(*args, **kwargs)

    def prop(self, *args, **kwargs):
        property_name = args[1] if len(args) > 1 else kwargs.get("property", "")
        if self._hide_advanced and property_name in _ADVANCED_ROBLOX_PROPERTIES:
            return None
        return self._layout.prop(*args, **kwargs)

    def __getattr__(self, name):
        attribute = getattr(self._layout, name)
        if not callable(attribute) or name not in _UI_CONTAINER_METHODS:
            return attribute

        def call_container(*args, **kwargs):
            return _UILayoutProxy(
                attribute(*args, **kwargs),
                self._hidden_headers,
                self._hide_advanced,
            )

        return call_container

    def __setattr__(self, name, value):
        setattr(self._layout, name, value)


class _LazyBoxProxy:
    __slots__ = (
        "_parent_layout",
        "_hidden_headers",
        "_hide_advanced",
        "_box_args",
        "_box_kwargs",
        "_layout_proxy",
        "_suppressed",
    )

    def __init__(self, parent_layout, hidden_headers, hide_advanced, box_args, box_kwargs):
        object.__setattr__(self, "_parent_layout", parent_layout)
        object.__setattr__(self, "_hidden_headers", hidden_headers)
        object.__setattr__(self, "_hide_advanced", hide_advanced)
        object.__setattr__(self, "_box_args", box_args)
        object.__setattr__(self, "_box_kwargs", box_kwargs)
        object.__setattr__(self, "_layout_proxy", None)
        object.__setattr__(self, "_suppressed", False)

    def _materialize(self):
        if self._layout_proxy is None:
            layout = self._parent_layout.box(*self._box_args, **self._box_kwargs)
            object.__setattr__(
                self,
                "_layout_proxy",
                _UILayoutProxy(layout, self._hidden_headers, self._hide_advanced),
            )
        return self._layout_proxy

    def label(self, *args, **kwargs):
        if self._suppressed:
            return None
        text = kwargs.get("text", args[0] if args else "")
        if text in self._hidden_headers:
            object.__setattr__(self, "_suppressed", True)
            return None
        if self._hide_advanced and text in _ADVANCED_ROBLOX_LABELS:
            return None
        return self._materialize().label(*args, **kwargs)

    def __getattr__(self, name):
        if self._suppressed:
            return getattr(_NULL_UI_LAYOUT, name)
        if name in _UI_CONTAINER_METHODS:
            def call_container(*args, **kwargs):
                return _DeferredLayoutProxy(self, name, args, kwargs)

            return call_container
        return getattr(self._materialize(), name)

    def __setattr__(self, name, value):
        if not self._suppressed:
            setattr(self._materialize(), name, value)


class _DeferredLayoutProxy:
    __slots__ = ("_root", "_parent", "_method", "_args", "_kwargs", "_layout")

    def __init__(self, root, method, args, kwargs, parent = None):
        object.__setattr__(self, "_root", root)
        object.__setattr__(self, "_parent", parent)
        object.__setattr__(self, "_method", method)
        object.__setattr__(self, "_args", args)
        object.__setattr__(self, "_kwargs", kwargs)
        object.__setattr__(self, "_layout", None)

    def _materialize(self):
        if self._layout is None:
            parent_layout = self._parent._materialize() if self._parent else self._root._materialize()
            layout = getattr(parent_layout, self._method)(*self._args, **self._kwargs)
            object.__setattr__(self, "_layout", layout)
        return self._layout

    def _hide_if_needed(self, args, kwargs):
        text = kwargs.get("text", args[0] if args else "")
        if text not in self._root._hidden_headers:
            return False
        object.__setattr__(self._root, "_suppressed", True)
        return True

    def label(self, *args, **kwargs):
        if self._root._suppressed:
            return None
        if self._hide_if_needed(args, kwargs):
            return None
        text = kwargs.get("text", args[0] if args else "")
        if self._root._hide_advanced and text in _ADVANCED_ROBLOX_LABELS:
            return None
        return self._materialize().label(*args, **kwargs)

    def prop(self, *args, **kwargs):
        if self._root._suppressed:
            return None
        if self._hide_if_needed((), kwargs):
            return None
        property_name = args[1] if len(args) > 1 else kwargs.get("property", "")
        if (
            self._root._hide_advanced
            and property_name in _ADVANCED_ROBLOX_PROPERTIES
        ):
            return None
        return self._materialize().prop(*args, **kwargs)

    def operator(self, *args, **kwargs):
        if self._root._suppressed:
            return _NullOperatorProperties()
        if self._hide_if_needed(args, kwargs):
            return _NullOperatorProperties()
        operator_id = args[0] if args else kwargs.get("operator", "")
        if self._root._hide_advanced and operator_id in _ADVANCED_ROBLOX_OPERATORS:
            return _NullOperatorProperties()
        kwargs = _roblox_operator_ui_kwargs(operator_id, kwargs)
        return self._materialize().operator(*args, **kwargs)

    def __getattr__(self, name):
        if self._root._suppressed:
            return getattr(_NULL_UI_LAYOUT, name)
        if name in _UI_CONTAINER_METHODS:
            def call_container(*args, **kwargs):
                return _DeferredLayoutProxy(
                    self._root,
                    name,
                    args,
                    kwargs,
                    parent = self,
                )

            return call_container
        return getattr(self._materialize(), name)

    def __setattr__(self, name, value):
        if not self._root._suppressed:
            setattr(self._materialize(), name, value)


class _PanelDrawProxy:
    __slots__ = ("_panel", "layout")

    def __init__(self, panel, layout):
        object.__setattr__(self, "_panel", panel)
        object.__setattr__(self, "layout", layout)

    def __getattr__(self, name):
        return getattr(self._panel, name)


def _restore_roblox_advanced_panel_filter():
    patch = _state.pop("roblox_advanced_panel_patch", None)
    if patch is None:
        return

    panel_class, original_draw, patched_draw = patch
    if getattr(panel_class, "draw", None) is patched_draw:
        panel_class.draw = original_draw


def _patch_roblox_advanced_panels():
    panel_class = getattr(bpy.types, "OBJECT_PT_RbxAnimations", None)
    if panel_class is None:
        return False

    existing = _state.get("roblox_advanced_panel_patch")
    if existing is not None:
        if existing[0] is panel_class and panel_class.draw is existing[2]:
            return True
        _restore_roblox_advanced_panel_filter()

    original_draw = panel_class.draw

    def draw_with_advanced_panel_filter(self, context):
        advanced_mode = getattr(
            context.window_manager,
            "roblox_compat_advanced_mode",
            False,
        )
        hide_advanced = not advanced_mode
        hide_face_controls = not advanced_mode
        hidden_headers = set()
        if hide_advanced:
            hidden_headers.update(_ADVANCED_ROBLOX_PANEL_HEADERS)
        if hide_face_controls:
            hidden_headers.update(_FACE_ROBLOX_PANEL_HEADERS)
        if not hidden_headers:
            return original_draw(self, context)

        layout = _UILayoutProxy(
            self.layout,
            frozenset(hidden_headers),
            hide_advanced = hide_advanced,
        )
        return original_draw(_PanelDrawProxy(self, layout), context)

    draw_with_advanced_panel_filter.__name__ = original_draw.__name__
    draw_with_advanced_panel_filter.__doc__ = original_draw.__doc__
    draw_with_advanced_panel_filter.__module__ = original_draw.__module__
    draw_with_advanced_panel_filter.__qualname__ = original_draw.__qualname__

    panel_class.draw = draw_with_advanced_panel_filter
    _state["roblox_advanced_panel_patch"] = (
        panel_class,
        original_draw,
        draw_with_advanced_panel_filter,
    )
    return True


def _restore_roblox_nodes_only_default():
    invoke_patch = _state.pop("roblox_genrig_invoke_patch", None)
    if invoke_patch is not None:
        operator_class, original_invoke, patched_invoke = invoke_patch
        if getattr(operator_class, "invoke", None) is patched_invoke:
            operator_class.invoke = original_invoke

    execute_patch = _state.pop("roblox_genrig_execute_patch", None)
    if execute_patch is not None:
        operator_class, original_execute, patched_execute = execute_patch
        if getattr(operator_class, "execute", None) is patched_execute:
            operator_class.execute = original_execute


def _restore_roblox_import_patch():
    patch = _state.pop("roblox_import_execute_patch", None)
    if patch is None:
        return

    operator_class, original_execute, patched_execute = patch
    if getattr(operator_class, "execute", None) is patched_execute:
        operator_class.execute = original_execute


def _patch_roblox_import_auto_generation():
    module_name = _roblox_addon_module_name()
    if module_name is None:
        return False

    try:
        import_ops = importlib.import_module(f"{module_name}.operators.import_ops")
        rig_ops = importlib.import_module(f"{module_name}.operators.rig_ops")
        operator_class = import_ops.OBJECT_OT_ImportModel
    except (AttributeError, ImportError):
        return False

    existing = _state.get("roblox_import_execute_patch")
    if existing is not None:
        if existing[0] is operator_class and operator_class.execute is existing[2]:
            return True
        _restore_roblox_import_patch()

    original_execute = operator_class.execute

    def execute_with_local_y_auto_generation(self, context):
        hide_advanced = not getattr(
            context.window_manager,
            "roblox_compat_advanced_mode",
            False,
        )
        previous_armatures = {
            obj.as_pointer() for obj in context.scene.objects if obj.type == "ARMATURE"
        }
        previous_meta = {
            obj.as_pointer()
            for obj in context.scene.objects
            if obj.type == "EMPTY" and "RigMeta" in obj
        }

        original_create_rig = import_ops.create_rig
        if hide_advanced:
            def create_local_y_rig(_rigging_type, rig_meta_name):
                return original_create_rig("LOCAL_YAXIS_EXTEND", rig_meta_name)

            import_ops.create_rig = create_local_y_rig

        try:
            result = original_execute(self, context)
        finally:
            if hide_advanced:
                import_ops.create_rig = original_create_rig

        if "FINISHED" not in result or not hide_advanced:
            return result

        new_armatures = [
            obj
            for obj in context.scene.objects
            if obj.type == "ARMATURE" and obj.as_pointer() not in previous_armatures
        ]
        new_meta_names = [
            obj.name
            for obj in context.scene.objects
            if obj.type == "EMPTY"
            and "RigMeta" in obj
            and obj.as_pointer() not in previous_meta
        ]

        if new_armatures or not new_meta_names:
            _schedule_roblox_compatibility_scan(delay = 0.05)
            _schedule_smart_material_import_scan(delay = 0.05)
            return result

        scene_name = context.scene.name

        def generate_imported_rig():
            scene = bpy.data.scenes.get(scene_name)
            if scene is None:
                return None

            for meta_name in new_meta_names:
                meta = scene.objects.get(meta_name)
                if meta is None or "RigMeta" not in meta:
                    continue
                try:
                    rig_ops.create_rig("LOCAL_YAXIS_EXTEND", meta_name)
                except Exception as exc:
                    print(
                        f"[Roblox Animator Utils] Automatic Local Y-axis rig generation failed: {exc}"
                    )

            _schedule_roblox_compatibility_scan(delay = 0.05)
            _schedule_smart_material_import_scan(delay = 0.05)
            return None

        bpy.app.timers.register(generate_imported_rig, first_interval = 0.1)
        return result

    execute_with_local_y_auto_generation.__name__ = original_execute.__name__
    execute_with_local_y_auto_generation.__doc__ = original_execute.__doc__
    execute_with_local_y_auto_generation.__module__ = original_execute.__module__
    execute_with_local_y_auto_generation.__qualname__ = original_execute.__qualname__

    operator_class.execute = execute_with_local_y_auto_generation
    _state["roblox_import_execute_patch"] = (
        operator_class,
        original_execute,
        execute_with_local_y_auto_generation,
    )
    return True


def _restore_roblox_serializer_patch():
    patch = _state.pop("roblox_serializer_patch", None)
    if patch is None:
        return

    serialization_module, original_function, patched_function = patch
    if serialization_module.get_all_constrained_bones is patched_function:
        serialization_module.get_all_constrained_bones = original_function


def _restore_dynamic_unparent_export_metadata(saved_metadata):
    for bone, had_worldspace, worldspace_value, had_parent, parent_value in saved_metadata:
        try:
            if had_worldspace:
                bone["worldspace_bone"] = worldspace_value
            elif "worldspace_bone" in bone:
                del bone["worldspace_bone"]

            if had_parent:
                bone["worldspace_original_parent"] = parent_value
            elif "worldspace_original_parent" in bone:
                del bone["worldspace_original_parent"]
        except Exception:
            pass


def _apply_dynamic_unparent_export_metadata(armature):
    saved_metadata = []
    if not armature or armature.type != "ARMATURE":
        return saved_metadata

    for bone_name in _unparent_rel_scan_arm(armature):
        bone = armature.data.bones.get(bone_name)
        if bone is None:
            continue
        parent_name = str(bone.get(REL_K_PARENT, ""))
        if not parent_name:
            continue

        had_worldspace = "worldspace_bone" in bone
        worldspace_value = bone.get("worldspace_bone")
        had_parent = "worldspace_original_parent" in bone
        parent_value = bone.get("worldspace_original_parent")
        saved_metadata.append(
            (bone, had_worldspace, worldspace_value, had_parent, parent_value)
        )
        bone["worldspace_bone"] = True
        bone["worldspace_original_parent"] = parent_name

    return saved_metadata


def _restore_roblox_export_patch():
    patches = _state.pop("roblox_export_execute_patch", None)
    if not patches:
        return

    for operator_class, original_execute, patched_execute in patches:
        if getattr(operator_class, "execute", None) is patched_execute:
            operator_class.execute = original_execute


def _patch_roblox_export():
    module_name = _roblox_addon_module_name()
    if module_name is None:
        return False

    try:
        animation_ops = importlib.import_module(f"{module_name}.operators.animation_ops")
    except ImportError:
        return False

    operator_classes = [
        getattr(animation_ops, "OBJECT_OT_Bake", None),
        getattr(animation_ops, "OBJECT_OT_Bake_File", None),
    ]
    operator_classes = [operator_class for operator_class in operator_classes if operator_class]
    if not operator_classes:
        return False

    existing = _state.get("roblox_export_execute_patch")
    if existing and all(
        getattr(operator_class, "execute", None) is patched_execute
        for operator_class, _original_execute, patched_execute in existing
    ):
        return True
    _restore_roblox_export_patch()

    patches = []
    for operator_class in operator_classes:
        original_execute = operator_class.execute

        def make_export_execute(execute_function):
            def execute_with_dynamic_unparent(self, context):
                settings = getattr(context.scene, "rbx_anim_settings", None)
                armature_name = getattr(settings, "rbx_anim_armature", "") if settings else ""
                armature = context.scene.objects.get(armature_name) if armature_name else None
                if armature is None and armature_name:
                    armature = bpy.data.objects.get(armature_name)

                saved_frame = int(context.scene.frame_current)
                previous_export_armature = _state.get("unparent_export_armature")
                saved_metadata = _apply_dynamic_unparent_export_metadata(armature)
                _state["unparent_export_armature"] = armature

                try:
                    if armature is not None:
                        _unparent_frame_change_post(context.scene, None)
                    return execute_function(self, context)
                finally:
                    try:
                        context.scene.frame_set(saved_frame)
                        if armature is not None:
                            _unparent_frame_change_post(context.scene, None)
                    except Exception:
                        pass
                    _state["unparent_export_armature"] = previous_export_armature
                    _restore_dynamic_unparent_export_metadata(saved_metadata)
                    try:
                        context.view_layer.update()
                    except Exception:
                        pass

            execute_with_dynamic_unparent.__name__ = execute_function.__name__
            execute_with_dynamic_unparent.__doc__ = execute_function.__doc__
            execute_with_dynamic_unparent.__module__ = execute_function.__module__
            execute_with_dynamic_unparent.__qualname__ = execute_function.__qualname__
            return execute_with_dynamic_unparent

        patched_execute = make_export_execute(original_execute)
        operator_class.execute = patched_execute
        patches.append((operator_class, original_execute, patched_execute))

    _state["roblox_export_execute_patch"] = patches
    return True


def _patch_roblox_serializer():
    module_name = _roblox_addon_module_name()
    if module_name is None:
        return False

    try:
        serialization_module = importlib.import_module(
            f"{module_name}.animation.serialization"
        )
    except ImportError:
        return False

    existing = _state.get("roblox_serializer_patch")
    if existing is not None:
        if (
            existing[0] is serialization_module
            and serialization_module.get_all_constrained_bones is existing[2]
        ):
            return True
        _restore_roblox_serializer_patch()

    original_function = serialization_module.get_all_constrained_bones

    def get_all_constrained_bones_with_dynamic_unparent(armature_obj):
        constrained = set(original_function(armature_obj))
        constrained.update(_unparent_rel_scan_arm(armature_obj))
        return constrained

    get_all_constrained_bones_with_dynamic_unparent.__name__ = original_function.__name__
    get_all_constrained_bones_with_dynamic_unparent.__doc__ = original_function.__doc__
    get_all_constrained_bones_with_dynamic_unparent.__module__ = original_function.__module__
    get_all_constrained_bones_with_dynamic_unparent.__qualname__ = original_function.__qualname__

    serialization_module.get_all_constrained_bones = get_all_constrained_bones_with_dynamic_unparent
    _state["roblox_serializer_patch"] = (
        serialization_module,
        original_function,
        get_all_constrained_bones_with_dynamic_unparent,
    )
    return True


def _patch_roblox_nodes_only_default():
    module_name = _roblox_addon_module_name()
    if module_name is None:
        return False

    try:
        rig_ops = importlib.import_module(f"{module_name}.operators.rig_ops")
        operator_class = rig_ops.OBJECT_OT_GenRig
    except (AttributeError, ImportError):
        return False

    invoke_patch = _state.get("roblox_genrig_invoke_patch")
    execute_patch = _state.get("roblox_genrig_execute_patch")
    if invoke_patch is not None or execute_patch is not None:
        invoke_current = (
            invoke_patch is None
            or (invoke_patch[0] is operator_class and operator_class.invoke is invoke_patch[2])
        )
        execute_current = (
            execute_patch is not None
            and execute_patch[0] is operator_class
            and operator_class.execute is execute_patch[2]
        )
        if invoke_current and execute_current:
            return True
        _restore_roblox_nodes_only_default()

    original_execute = operator_class.execute

    def execute_with_staticaliza_compatibility(self, context):
        source = context.scene.objects.get(self.pr_rig_meta_name)
        previous_armatures = {
            obj.as_pointer() for obj in context.scene.objects if obj.type == "ARMATURE"
        }
        result = original_execute(self, context)
        if "FINISHED" not in result:
            return result

        armature = _find_generated_roblox_armature(context, source, previous_armatures)
        if armature is None:
            self.report({"WARNING"}, "Generated armature could not be located for compatibility cleanup.")
            return result

        armature_pointer = armature.as_pointer()

        def apply_after_native_constraints():
            _state["roblox_constraints_normalized"].discard(armature_pointer)
            _schedule_roblox_compatibility_scan(delay = 0.05)
            _schedule_smart_material_import_scan(delay = 0.05)
            return None

        bpy.app.timers.register(apply_after_native_constraints, first_interval = 0.1)
        return result

    execute_with_staticaliza_compatibility.__name__ = original_execute.__name__
    execute_with_staticaliza_compatibility.__doc__ = original_execute.__doc__
    execute_with_staticaliza_compatibility.__module__ = original_execute.__module__
    execute_with_staticaliza_compatibility.__qualname__ = original_execute.__qualname__

    operator_class.execute = execute_with_staticaliza_compatibility
    _state["roblox_genrig_execute_patch"] = (
        operator_class,
        original_execute,
        execute_with_staticaliza_compatibility,
    )
    return True


def _normalize_version_text(version):
    if isinstance(version, (tuple, list)):
        text = ".".join(str(part) for part in version)
    elif version is None:
        return ""
    else:
        text = str(version).strip()
    return "" if not text or text.lower() == "unknown" else text.lstrip("vV")


def _roblox_version_text(module_name):
    try:
        roblox_module = importlib.import_module(module_name)
    except ImportError:
        return ""

    bl_info_data = getattr(roblox_module, "bl_info", None)
    if isinstance(bl_info_data, dict):
        version_text = _normalize_version_text(bl_info_data.get("version"))
        if version_text:
            return version_text

    try:
        panels_module = importlib.import_module(f"{module_name}.ui.panels")
        version_text = _normalize_version_text(
            getattr(panels_module, "ADDON_VERSION_TEXT", None)
        )
        if version_text:
            return version_text
    except ImportError:
        pass

    module_file = getattr(roblox_module, "__file__", "")
    search_dir = os.path.dirname(os.path.abspath(module_file)) if module_file else ""
    for _ in range(5):
        if not search_dir:
            break
        manifest_path = os.path.join(search_dir, "blender_manifest.toml")
        try:
            with open(manifest_path, "rb") as manifest_file:
                version_text = _normalize_version_text(
                    tomllib.load(manifest_file).get("version")
                )
            if version_text:
                return version_text
        except (OSError, tomllib.TOMLDecodeError):
            pass
        parent_dir = os.path.dirname(search_dir)
        if parent_dir == search_dir:
            break
        search_dir = parent_dir

    return ""


def _configure_roblox_sidebar_tabs():
    if not _roblox_addon_is_enabled():
        return None

    _patch_roblox_nodes_only_default()
    _patch_roblox_import_auto_generation()
    _patch_roblox_advanced_panels()
    _patch_roblox_serializer()
    _patch_roblox_export()

    module_name = _roblox_addon_module_name()
    version_text = ""
    if module_name:
        try:
            roblox_module = importlib.import_module(module_name)
            if isinstance(getattr(roblox_module, "bl_info", None), dict):
                roblox_module.bl_info["name"] = "Roblox Animator"
        except ImportError:
            pass

        version_text = _roblox_version_text(module_name)

        try:
            animation_ops = importlib.import_module(f"{module_name}.operators.animation_ops")
            animation_ops.OBJECT_OT_Bake.bl_label = "Export"
            animation_ops.OBJECT_OT_Bake.bl_description = "Export animation to clipboard"
        except (AttributeError, ImportError):
            pass

    roblox_panel = getattr(bpy.types, "OBJECT_PT_RbxAnimations", None)
    if roblox_panel is not None:
        panel_label = "Roblox Animator"
        if version_text:
            panel_label += f" (v{version_text})"
        if roblox_panel.bl_label != panel_label:
            roblox_panel.bl_label = panel_label
        if roblox_panel.bl_category != "Roblox Animator":
            roblox_panel.bl_category = "Roblox Animator"

    tool_panel = getattr(bpy.types, "OBJECT_PT_RbxAnimations_Tool", None)
    if tool_panel is not None:
        tool_panel.bl_label = "Roblox Animator"
        if version_text:
            tool_panel.bl_label += f" (v{version_text})"

    return None


classes = (
    ONION_SKIN_OT_ghost_toggle,
    STATICALIZA_OT_yellow_resync_all,
    STATICALIZA_OT_yellow_clear_all,
    STATICALIZA_OT_yellow_hide_all,
    STATICALIZA_OT_yellow_show,
    STATICALIZA_OT_yellow_apply,
    STATICALIZA_MT_yellow_pin_menu,
    STATICALIZA_MT_yellow_hidden_menu,
    STATICALIZA_MT_yellow_no_selection_menu,
    STATICALIZA_OT_yellow_menu,
    STATICALIZA_OT_unparent_action,
    STATICALIZA_MT_unparent_menu_inactive,
    STATICALIZA_MT_unparent_menu_active,
    STATICALIZA_OT_unparent_menu,
    STATICALIZA_OT_install_roblox_animations,
    STATICALIZA_OT_open_roblox_plugins,
    STATICALIZA_OT_set_transform_orientation,
    STATICALIZA_OT_set_pivot_mode,
    STATICALIZA_OT_add_bone_camera,
    STATICALIZA_OT_keyframe_camera_view,
    STATICALIZA_OT_load_template,
    VIEW3D_PT_staticaliza_roblox_animator_anchor,
    VIEW3D_PT_staticaliza_main
)

class DYNAMIC_PARENT_OT_menu(bpy.types.Operator):
    bl_idname = "dynamic_parent.menu"
    bl_label = "Dynamic Tools"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.mode in ("OBJECT", "POSE")

    def execute(self, context):
        bpy.ops.wm.call_menu(name = "DYNAMIC_PARENT_MT_hotkey_menu")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)

class DYNAMIC_PARENT_MT_hotkey_menu(bpy.types.Menu):
    bl_label = "Dynamic Tools"
    bl_idname = "DYNAMIC_PARENT_MT_hotkey_menu"

    def draw(self, context):
        layout = self.layout
        advanced_mode = getattr(
            context.window_manager,
            "roblox_compat_advanced_mode",
            False,
        )

        layout.label(text = "Dynamic Parent")
        layout.operator("dynamic_parent.create", text = "Create Start", icon = "KEY_HLT")
        layout.operator("dynamic_parent.disable", text = "Create End", icon = "KEY_DEHLT")
        layout.operator("dynamic_parent.clear", text = "Clear", icon = "X")
        if advanced_mode:
            layout.operator("dynamic_parent.bake", text = "Bake", icon = "REC")

        layout.separator()
        layout.label(text = "Dynamic Unparent")
        can_start, can_end, can_clear, can_bake = _dynamic_unparent_ui_state(context)

        start_row = layout.row()
        start_row.enabled = can_start
        start_operator = start_row.operator(
            "staticaliza.unparent_action",
            text = "Create Start",
            icon = "KEY_HLT",
        )
        start_operator.action = "START"

        end_row = layout.row()
        end_row.enabled = can_end
        end_operator = end_row.operator(
            "staticaliza.unparent_action",
            text = "Create End",
            icon = "KEY_DEHLT",
        )
        end_operator.action = "END"

        clear_row = layout.row()
        clear_row.enabled = can_clear
        clear_operator = clear_row.operator(
            "staticaliza.unparent_action",
            text = "Clear",
            icon = "X",
        )
        clear_operator.action = "CLEAR"

        if advanced_mode:
            bake_row = layout.row()
            bake_row.enabled = can_bake
            bake_operator = bake_row.operator(
                "staticaliza.unparent_action",
                text = "Bake",
                icon = "REC",
            )
            bake_operator.action = "BAKE_TO_ENDING"

def _dynamic_parent_pose_operation_begin(context, armature):
    action = armature.animation_data.action if armature.animation_data else None
    state = {
        "frame": int(context.scene.frame_current),
        "handler_mute": bool(_state.get("unparent_handler_mute", False)),
        "autokey": _autokey_push(context),
        "object_keys": _snapshot_object_keys_all(action),
    }
    if not state["handler_mute"]:
        _unparent_frame_change_post(context.scene, None)
    _state["unparent_handler_mute"] = True
    return state


def _dynamic_parent_pose_operation_end(context, armature, state):
    try:
        if int(context.scene.frame_current) != int(state["frame"]):
            context.scene.frame_set(int(state["frame"]))
        context.view_layer.update()
    finally:
        _state["unparent_handler_mute"] = bool(state["handler_mute"])
        if not state["handler_mute"]:
            _unparent_frame_change_post(context.scene, None)
        action = armature.animation_data.action if armature.animation_data else None
        _cleanup_new_object_keys_all(action, state["object_keys"])
        _autokey_pop(context, state["autokey"])


def _dynamic_parent_begin_auto_unparent(context, armature, pose_bone, frame):
    if pose_bone is None:
        return False
    saved_parent = str(pose_bone.bone.get(REL_K_PARENT, ""))
    if pose_bone.parent is None and not saved_parent:
        return False

    action = armature.animation_data.action if armature.animation_data else None
    already_detached = _unparent_relation_is_detached(pose_bone)
    already_active = bool(
        action
        and _unparent_eval(
            action,
            pose_bone.name,
            int(frame),
            pb_default = _pb_prop_get(pose_bone, UNP_PROP, 0.0),
        ) >= 0.5
    )
    if already_detached or already_active:
        return False

    started = _unparent_toggle(context, armature, pose_bone, int(frame))
    _state["unparent_handler_mute"] = True
    return bool(started)


def _dynamic_parent_end_auto_unparent(
    context,
    armature,
    pose_bone,
    constraint,
    frame,
):
    if (
        pose_bone is None
        or constraint is None
        or _dp_auto_unparent_start(pose_bone, constraint) is None
    ):
        return False

    action = armature.animation_data.action if armature.animation_data else None
    active = bool(
        action
        and _unparent_eval(
            action,
            pose_bone.name,
            int(frame),
            pb_default = _pb_prop_get(pose_bone, UNP_PROP, 0.0),
        ) >= 0.5
    )
    if not active and not _unparent_relation_is_detached(pose_bone):
        return False

    ended = _unparent_toggle(context, armature, pose_bone, int(frame))
    _state["unparent_handler_mute"] = True
    return bool(ended)


class DYNAMIC_PARENT_OT_create(bpy.types.Operator):
    bl_idname = "dynamic_parent.create"
    bl_label = "Create Constraint"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _dynamic_parent_can_create(context)

    def execute(self, context):
        obj = context.active_object
        frame = context.scene.frame_current
        operation_state = None

        if obj.type == "ARMATURE":
            if obj.mode != "POSE":
                self.report({"ERROR"}, "Armature objects must be in Pose mode.")
                return {"CANCELLED"}
            operation_state = _dynamic_parent_pose_operation_begin(context, obj)

        try:
            if obj.type == "ARMATURE":
                pose_bone = bpy.context.active_pose_bone
                const = get_last_dynamic_parent_constraint(pose_bone)
                if const:
                    disable_constraint(pose_bone, const, frame)
                auto_unparent_started = _dynamic_parent_begin_auto_unparent(
                    context,
                    obj,
                    pose_bone,
                    frame,
                )
                dp_create_dynamic_parent_pbone(self)
                created_constraint = get_last_dynamic_parent_constraint(pose_bone)
                if auto_unparent_started and created_constraint is not None:
                    pose_bone[
                        _dp_auto_unparent_property_name(created_constraint)
                    ] = int(frame)
            else:
                const = get_last_dynamic_parent_constraint(obj)
                if const:
                    disable_constraint(obj, const, frame)
                dp_create_dynamic_parent_obj(self)
        finally:
            if operation_state is not None:
                _dynamic_parent_pose_operation_end(context, obj, operation_state)

        return {"FINISHED"}

class DYNAMIC_PARENT_OT_disable(bpy.types.Operator):
    bl_idname = "dynamic_parent.disable"
    bl_label = "Disable Constraint"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _dynamic_parent_can_end(context)

    def execute(self, context):
        frame = context.scene.frame_current
        armature = context.active_object if context.mode == "POSE" else None
        operation_state = (
            _dynamic_parent_pose_operation_begin(context, armature)
            if armature is not None and armature.type == "ARMATURE"
            else None
        )
        objects = get_selected_objects(context)
        counter = 0

        try:
            if not objects:
                self.report({"ERROR"}, "Nothing selected.")
                return {"CANCELLED"}

            for obj in objects:
                const = get_last_dynamic_parent_constraint(obj)
                if const is None:
                    continue
                disable_constraint(obj, const, frame)
                if armature is not None and isinstance(obj, bpy.types.PoseBone):
                    current_bone = armature.pose.bones.get(obj.name)
                    _dynamic_parent_end_auto_unparent(
                        context,
                        armature,
                        current_bone,
                        const,
                        frame,
                    )
                counter += 1
        finally:
            if operation_state is not None:
                _dynamic_parent_pose_operation_end(context, armature, operation_state)

        self.report({"INFO"}, f"{counter} constraints were disabled.")
        return {"FINISHED"}

class DYNAMIC_PARENT_OT_clear(bpy.types.Operator):
    bl_idname = "dynamic_parent.clear"
    bl_label = "Clear Dynamic Parent"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _dynamic_parent_has_data(_dynamic_parent_target(context))

    def execute(self, context):
        pbone = None
        obj = bpy.context.active_object
        if obj.type == "ARMATURE":
            pbone = bpy.context.active_pose_bone

        dp_clear(obj, pbone)

        return {"FINISHED"}

class DYNAMIC_PARENT_OT_bake(bpy.types.Operator):
    bl_idname = "dynamic_parent.bake"
    bl_label = "Bake Dynamic Parent"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _dynamic_parent_has_data(_dynamic_parent_target(context))

    def execute(self, context):
        obj = bpy.context.active_object
        scn = bpy.context.scene

        if obj.type == "ARMATURE":
            obj = bpy.context.active_pose_bone
            bpy.ops.nla.bake(
                frame_start = scn.frame_start,
                frame_end = scn.frame_end,
                step = 1,
                only_selected = True,
                visual_keying = True,
                clear_constraints = False,
                clear_parents = False,
                bake_types = {"POSE"},
            )
            for const in obj.constraints[:]:
                if const.name.startswith("DP_"):
                    obj.constraints.remove(const)
        else:
            bpy.ops.nla.bake(
                frame_start = scn.frame_start,
                frame_end = scn.frame_end,
                step = 1,
                only_selected = True,
                visual_keying = True,
                clear_constraints = False,
                clear_parents = False,
                bake_types = {"OBJECT"},
            )
            for const in obj.constraints[:]:
                if const.name.startswith("DP_"):
                    obj.constraints.remove(const)

        return {"FINISHED"}

class DYNAMIC_PARENT_OT_clear_material_links(bpy.types.Operator):
    bl_idname = "dynamic_parent.clear_material_links"
    bl_label = "Clear Material Links"
    bl_description = "Disconnect Base Color and Alpha links for all materials in the current file"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        removed = dp_clear_material_links()

        if removed:
            self.report({"INFO"}, f"Removed {removed} Base Color/Alpha link(s).")
        else:
            self.report({"INFO"}, "No Base Color or Alpha links were connected.")

        return {"FINISHED"}

class DYNAMIC_PARENT_MT_clear_menu(bpy.types.Menu):
    bl_label = "Clear Dynamic Parent?"
    bl_idname = "DYNAMIC_PARENT_MT_clear_menu"

    def draw(self, context):
        layout = self.layout
        layout.operator("dynamic_parent.clear", text = "Clear", icon = "X")
        layout.operator("dynamic_parent.bake", text = "Bake and clear", icon = "REC")

class DYNAMIC_PARENT_PT_ui(bpy.types.Panel):
    bl_label = "Dynamic Parent {}.{}.{}".format(*DP_BL_INFO["version"])
    bl_idname = "DYNAMIC_PARENT_PT_ui"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Dynamic Parent"

    def draw(self, context):
        layout = self.layout
        col = layout.column(align = True)
        col.operator("dynamic_parent.create", text = "Create", icon = "KEY_HLT")
        col.operator("dynamic_parent.disable", text = "Disable", icon = "KEY_DEHLT")
        col.menu("DYNAMIC_PARENT_MT_clear_menu", text = "Clear")

        layout.separator()
        layout.label(text = "Materials")
        layout.operator("dynamic_parent.clear_material_links", text = "Clear")

def _dp_register():
    for c in (
        DYNAMIC_PARENT_OT_menu,
        DYNAMIC_PARENT_MT_hotkey_menu,
        DYNAMIC_PARENT_OT_create,
        DYNAMIC_PARENT_OT_disable,
        DYNAMIC_PARENT_OT_clear,
        DYNAMIC_PARENT_OT_bake,
        DYNAMIC_PARENT_OT_clear_material_links,
        DYNAMIC_PARENT_MT_clear_menu,
    ):
        try:
            bpy.utils.register_class(c)
        except Exception:
            pass

def _dp_unregister():
    for c in reversed((
        DYNAMIC_PARENT_OT_menu,
        DYNAMIC_PARENT_MT_hotkey_menu,
        DYNAMIC_PARENT_OT_create,
        DYNAMIC_PARENT_OT_disable,
        DYNAMIC_PARENT_OT_clear,
        DYNAMIC_PARENT_OT_bake,
        DYNAMIC_PARENT_OT_clear_material_links,
        DYNAMIC_PARENT_MT_clear_menu,
    )):
        try:
            bpy.utils.unregister_class(c)
        except Exception:
            pass


def _unregister_addon_keymaps():
    for km, kmi in _keymaps:
        try:
            km.keymap_items.remove(kmi)
        except (ReferenceError, RuntimeError):
            pass
    _keymaps.clear()


def _register_addon_keymaps():
    if _keymaps:
        return True
    try:
        wm = bpy.context.window_manager
    except AttributeError:
        return False
    kc = wm.keyconfigs.addon if wm and wm.keyconfigs else None
    if kc is None:
        return False

    km = kc.keymaps.new(name = "Pose", space_type = "EMPTY", region_type = "WINDOW")
    _keymaps.append((km, km.keymap_items.new(
        "staticaliza.keyframe_camera_view",
        type = "NUMPAD_0",
        value = "PRESS",
        ctrl = True,
        alt = True,
        head = True,
    )))
    _keymaps.append((km, km.keymap_items.new("onion_skin.ghost_toggle", type = "F", value = "PRESS")))
    _keymaps.append((km, km.keymap_items.new("staticaliza.yellow_menu", type = "F", value = "PRESS", shift = True)))
    _keymaps.append((km, km.keymap_items.new("dynamic_parent.menu", type = "F", value = "PRESS", alt = True)))
    _keymaps.append((km, km.keymap_items.new("staticaliza.set_transform_orientation", type = "Y", value = "PRESS")))
    _keymaps.append((km, km.keymap_items.new("staticaliza.set_pivot_mode", type = "Y", value = "PRESS", shift = True)))

    km = kc.keymaps.new(name = "Object Mode", space_type = "EMPTY", region_type = "WINDOW")
    _keymaps.append((km, km.keymap_items.new("dynamic_parent.menu", type = "F", value = "PRESS", alt = True)))
    _keymaps.append((km, km.keymap_items.new("staticaliza.set_transform_orientation", type = "Y", value = "PRESS")))

    km = kc.keymaps.new(name = "3D View", space_type = "VIEW_3D", region_type = "WINDOW")
    _keymaps.append((km, km.keymap_items.new(
        "staticaliza.keyframe_camera_view",
        type = "NUMPAD_0",
        value = "PRESS",
        ctrl = True,
        alt = True,
        head = True,
    )))
    _keymaps.append((km, km.keymap_items.new("onion_skin.ghost_toggle", type = "F", value = "PRESS")))
    _keymaps.append((km, km.keymap_items.new("staticaliza.yellow_menu", type = "F", value = "PRESS", shift = True)))
    _keymaps.append((km, km.keymap_items.new("dynamic_parent.menu", type = "F", value = "PRESS", alt = True)))

    km = kc.keymaps.new(name = "Dopesheet Generic", space_type = "DOPESHEET_EDITOR", region_type = "WINDOW")
    _keymaps.append((km, km.keymap_items.new("onion_skin.ghost_toggle", type = "F", value = "PRESS")))
    _keymaps.append((km, km.keymap_items.new("staticaliza.yellow_menu", type = "F", value = "PRESS", shift = True)))
    _keymaps.append((km, km.keymap_items.new("dynamic_parent.menu", type = "F", value = "PRESS", alt = True)))

    km = kc.keymaps.new(name = "Graph Editor", space_type = "GRAPH_EDITOR", region_type = "WINDOW")
    _keymaps.append((km, km.keymap_items.new("onion_skin.ghost_toggle", type = "F", value = "PRESS")))
    _keymaps.append((km, km.keymap_items.new("staticaliza.yellow_menu", type = "F", value = "PRESS", shift = True)))
    _keymaps.append((km, km.keymap_items.new("dynamic_parent.menu", type = "F", value = "PRESS", alt = True)))
    return True


def _register_addon_keymaps_timer():
    return None if _register_addon_keymaps() else 0.1


_POSE_TRANSFORM_TOOLS = {
    "builtin.move",
    "builtin.rotate",
    "builtin.scale",
    "builtin.transform",
}


def _pose_workspace_tool(context):
    workspace = getattr(context, "workspace", None)
    if workspace is None:
        return None
    try:
        return workspace.tools.from_space_view3d_mode("POSE", create = False)
    except (AttributeError, RuntimeError):
        return None


def _set_pose_workspace_tool(context, tool_id):
    window_manager = getattr(context, "window_manager", None)
    if window_manager is None:
        return False
    for window in window_manager.windows:
        screen = window.screen
        for area in screen.areas if screen else ():
            if area.type != "VIEW_3D":
                continue
            region = next(
                (candidate for candidate in area.regions if candidate.type == "WINDOW"),
                None,
            )
            if region is None:
                continue
            try:
                with context.temp_override(window = window, area = area, region = region):
                    result = bpy.ops.wm.tool_set_by_id(name = tool_id)
                return "FINISHED" in result
            except (AttributeError, RuntimeError):
                continue
    return False


def _pose_tool_selection_timer():
    context = bpy.context
    if context.mode != "POSE":
        _state["pose_tool_active_session"] = False
        return 0.1

    tool = _pose_workspace_tool(context)
    tool_id = getattr(tool, "idname", "") if tool else ""
    if tool_id in _POSE_TRANSFORM_TOOLS:
        _state["pose_last_tool"] = tool_id

    if _state.get("pose_tool_active_session", False):
        return 0.1
    if not _selected_pose_bones_only(context):
        return 0.1

    target = tool_id
    if not target or target.startswith("builtin.select"):
        target = _state.get("pose_last_tool", "") or "builtin.rotate"
    if target != tool_id and not _set_pose_workspace_tool(context, target):
        return 0.1
    if target in _POSE_TRANSFORM_TOOLS:
        _state["pose_last_tool"] = target
    _state["pose_tool_active_session"] = True
    return 0.1

def register():
    _set_default_keyframe_handle_type()
    for name in (
        "onion_skin_enabled",
        "onion_skin_opacity",
        "onion_skin_include_meshes",
        "onion_skin_include_bones",
        "onion_skin_raycast",
        "onion_skin_skip_hidden"
    ):
        if hasattr(bpy.types.Scene, name):
            delattr(bpy.types.Scene, name)

    if hasattr(bpy.types.WindowManager, "smart_material_import_enabled"):
        delattr(bpy.types.WindowManager, "smart_material_import_enabled")
    if hasattr(
        bpy.types.WindowManager,
        "standardize_imported_material_display_enabled",
    ):
        delattr(
            bpy.types.WindowManager,
            "standardize_imported_material_display_enabled",
        )
    if hasattr(
        bpy.types.WindowManager,
        "prevent_clothing_layer_clipping_enabled",
    ):
        delattr(
            bpy.types.WindowManager,
            "prevent_clothing_layer_clipping_enabled",
        )
    if hasattr(bpy.types.WindowManager, "yellow_pin_mode"):
        delattr(bpy.types.WindowManager, "yellow_pin_mode")
    for name in (
        "roblox_compat_hide_weld_bones",
        "roblox_compat_hide_face_bones",
        "roblox_compat_hide_advanced_panels",
        "roblox_compat_advanced_mode",
        "staticaliza_pivot_mode",
        "staticaliza_camera_fov_mode",
        "staticaliza_camera_custom_fov",
        "staticaliza_camera_fov_preset",
        "staticaliza_camera_fov",
        "staticaliza_camera_orientation",
    ):
        if hasattr(bpy.types.WindowManager, name):
            delattr(bpy.types.WindowManager, name)
    for name in (
        "staticaliza_camera_fov_preset",
        "staticaliza_camera_orientation",
        "staticaliza_camera_hide_attached_preview",
        "staticaliza_camera_hide_attached_object",
    ):
        if hasattr(bpy.types.Object, name):
            delattr(bpy.types.Object, name)

    bpy.types.WindowManager.onion_skin_enabled = bpy.props.BoolProperty(
        name = "Ghost",
        default = False,
        options = {"SKIP_SAVE"},
        update = _on_enabled_toggle
    )
    bpy.types.WindowManager.onion_skin_opacity = bpy.props.FloatProperty(
        name = "Opacity",
        default = 0.10,
        min = 0.001,
        max = 1.0,
        update = _on_setting_change
    )
    bpy.types.WindowManager.onion_skin_include_meshes = bpy.props.BoolProperty(
        name = "Meshes",
        default = True,
        update = _on_setting_change
    )
    bpy.types.WindowManager.onion_skin_include_bones = bpy.props.BoolProperty(
        name = "Bones",
        default = False,
        update = _on_setting_change
    )
    bpy.types.WindowManager.onion_skin_raycast = bpy.props.BoolProperty(
        name = "Raycast",
        default = True,
        update = _on_setting_change
    )
    bpy.types.WindowManager.onion_skin_skip_hidden = bpy.props.BoolProperty(
        name = "Skip Hidden",
        default = True,
        update = _on_setting_change
    )
    bpy.types.WindowManager.smart_material_import_enabled = bpy.props.BoolProperty(
        name = "Smart Material Import",
        description = "Automatically remove Base Color links from imported rig parts that also use a Normal link",
        default = True,
        update = _on_smart_material_import_toggle
    )
    bpy.types.WindowManager.standardize_imported_material_display_enabled = bpy.props.BoolProperty(
        name = "Standardize Viewport Display",
        description = "Set newly imported rig materials to #E7E7E7, metallic 0, and roughness 0.5 in Viewport Display",
        default = True,
        update = _on_smart_material_import_toggle,
    )
    bpy.types.WindowManager.prevent_clothing_layer_clipping_enabled = bpy.props.BoolProperty(
        name = "Prevent Clothing Clipping",
        description = "Offset imported clothing overlay meshes slightly so the underlying body does not clip through",
        default = True,
        update = _on_smart_material_import_toggle,
    )
    bpy.types.WindowManager.yellow_pin_mode = bpy.props.EnumProperty(
        name = "Pin Position",
        description = "Choose where new and updated pins are placed",
        items = (
            ("MODE_3", "Smart", "Use the bottom center of the bone's visible geometry"),
            ("MODE_1", "Bone End", "Use the bone tail"),
            ("MODE_2", "Bone Center", "Use the center of the weighted geometry"),
        ),
        default = "MODE_3",
    )
    bpy.types.WindowManager.roblox_compat_advanced_mode = bpy.props.BoolProperty(
        name = "Advanced Mode",
        description = "Show advanced panels, weld and face bones, bone axes, bone names, and detailed Utils controls",
        default = False,
        update = _on_advanced_mode_change
    )
    bpy.types.WindowManager.staticaliza_pivot_mode = bpy.props.EnumProperty(
        name = "Pivot Mode",
        description = "Use Blender's bone pivot or the first connected object's center and axes",
        items = (
            ("BONE", "Bone", "Use Blender's normal bone pivot"),
            ("PART", "Object", "Use the center and axes of the first connected rig object"),
        ),
        default = "BONE",
        options = {"SKIP_SAVE"},
    )
    bpy.types.WindowManager.staticaliza_camera_fov_preset = bpy.props.EnumProperty(
        name = "Camera Preset",
        description = "Choose a field-of-view preset for newly attached cameras",
        items = CAMERA_FOV_PRESET_ITEMS,
        default = "CINEMATIC",
        update = _on_camera_fov_preset,
    )
    bpy.types.WindowManager.staticaliza_camera_fov = bpy.props.FloatProperty(
        name = "FOV",
        description = "Horizontal field of view used for newly attached cameras",
        subtype = "ANGLE",
        default = math.radians(35.0),
        min = math.radians(1.0),
        max = math.radians(179.0),
        update = _on_camera_fov_change,
    )
    bpy.types.WindowManager.staticaliza_camera_orientation = bpy.props.EnumProperty(
        name = "Camera Orientation",
        description = "Choose the local bone axis the camera points along",
        items = CAMERA_ORIENTATION_ITEMS,
        default = "Z_NEG",
    )
    bpy.types.Object.staticaliza_camera_fov_preset = bpy.props.EnumProperty(
        name = "Camera Preset",
        description = "Choose the field-of-view preset for this camera",
        items = CAMERA_FOV_PRESET_ITEMS,
        default = "CINEMATIC",
        update = _on_attached_camera_preset,
    )
    bpy.types.Object.staticaliza_camera_orientation = bpy.props.EnumProperty(
        name = "Camera Orientation",
        description = "Choose the local bone axis this camera points along",
        items = CAMERA_ORIENTATION_ITEMS,
        default = "Z_NEG",
        update = _on_attached_camera_orientation,
    )
    bpy.types.Object.staticaliza_camera_hide_attached_object = bpy.props.BoolProperty(
        name = "Hide Attached Object",
        description = "Hide mesh objects driven by this camera bone in the viewport and final render",
        default = True,
        update = _on_camera_attached_object_hide_change,
    )

    for c in classes:
        bpy.utils.register_class(c)

    _dp_register()

    _state["yellow_fixed"] = {}
    _state["yellow_modes"] = {}
    _state["yellow_hidden"] = False
    _state["unparent_rel_cache"] = {}
    _state["unparent_handler_mute"] = False
    _state["last_error"] = ""
    _state["smart_material_processed_rigs"] = set()
    _state["material_import_baseline"] = None
    if not _capture_material_import_baseline():
        bpy.app.timers.register(
            _initialize_material_import_tracking,
            first_interval = 0.05,
        )
    _state["extension_update_lock_waits"] = 0
    _state["roblox_constraints_normalized"] = set()
    _state["unparent_export_armature"] = None
    _state["smart_material_scan_pending"] = False
    _state["roblox_compatibility_scan_pending"] = False
    _state["armature_overlay_saved"] = {}
    _state["part_pivot_syncing"] = False
    _state["part_pivot_armature"] = 0
    _state["part_pivot_bone"] = ""
    _state["part_pivot_object"] = ""
    _state["part_pivot_object_local"] = None
    _state["part_pivot_saved"] = None
    _state["part_pivot_last_signature"] = None
    _state["part_pivot_cursor_visibility"] = {}
    _state["camera_view_spaces"] = {}
    _state["pose_tool_active_session"] = False
    _state["pose_last_tool"] = ""

    if not _register_addon_keymaps():
        bpy.app.timers.register(
            _register_addon_keymaps_timer,
            first_interval = 0.05,
        )

    for h in list(bpy.app.handlers.frame_change_post):
        if getattr(h, "__name__", "") in {
            "_unparent_frame_change_post",
            "_part_pivot_frame_change_post",
        }:
            bpy.app.handlers.frame_change_post.remove(h)
    bpy.app.handlers.frame_change_post.append(_unparent_frame_change_post)
    bpy.app.handlers.frame_change_post.append(_part_pivot_frame_change_post)

    for h in list(bpy.app.handlers.load_post):
        if getattr(h, "__name__", "") == "_load_post":
            bpy.app.handlers.load_post.remove(h)
    bpy.app.handlers.load_post.append(_load_post)

    for h in list(bpy.app.handlers.depsgraph_update_post):
        if getattr(h, "__name__", "") == "_smart_material_import_depsgraph_update":
            bpy.app.handlers.depsgraph_update_post.remove(h)
    bpy.app.handlers.depsgraph_update_post.append(_smart_material_import_depsgraph_update)

    for h in list(bpy.app.handlers.depsgraph_update_post):
        if getattr(h, "__name__", "") in {
            "_roblox_compatibility_depsgraph_update",
            "_part_pivot_depsgraph_update",
        }:
            bpy.app.handlers.depsgraph_update_post.remove(h)
    bpy.app.handlers.depsgraph_update_post.append(_roblox_compatibility_depsgraph_update)
    bpy.app.handlers.depsgraph_update_post.append(_part_pivot_depsgraph_update)

    bpy.app.timers.register(lambda: (_yellow_refresh_runtime(bpy.context), None)[1], first_interval = 0.1)
    bpy.app.timers.register(lambda: (_sync_view3d_relationship_lines(bpy.context), None)[1], first_interval = 0.1)
    bpy.app.timers.register(
        _camera_view_exit_timer,
        first_interval = 0.05,
        persistent = True,
    )
    bpy.app.timers.register(_sync_all_attached_camera_object_visibility, first_interval = 0.2)
    bpy.app.timers.register(
        _pose_tool_selection_timer,
        first_interval = 0.1,
        persistent = True,
    )
    bpy.app.timers.register(
        _part_pivot_selection_timer,
        first_interval = 0.05,
        persistent = True,
    )
    bpy.app.timers.register(lambda: (_smart_material_import_scan(bpy.context.scene), None)[1], first_interval = 0.2)
    bpy.app.timers.register(lambda: (_apply_roblox_compatibility(bpy.context.scene), None)[1], first_interval = 0.3)
    bpy.app.timers.register(_configure_roblox_sidebar_tabs, first_interval = 0.5)

def unregister():
    _unregister_addon_keymaps()
    _restore_roblox_nodes_only_default()
    _restore_roblox_import_patch()
    _restore_roblox_advanced_panel_filter()
    _restore_roblox_serializer_patch()
    _restore_roblox_export_patch()
    _sync_armature_debug_overlays(True)

    for timer_function in (
        _run_smart_material_import_scan,
        _run_roblox_compatibility_scan,
        _camera_view_exit_timer,
        _part_pivot_selection_timer,
        _initialize_material_import_tracking,
        _register_addon_keymaps_timer,
        _pose_tool_selection_timer,
    ):
        try:
            if bpy.app.timers.is_registered(timer_function):
                bpy.app.timers.unregister(timer_function)
        except Exception:
            pass

    try:
        if bpy.context and bpy.context.window_manager:
            if getattr(
                bpy.context.window_manager,
                "staticaliza_pivot_mode",
                "BONE",
            ) == "PART":
                _disable_part_pivot(bpy.context)
            bpy.context.window_manager.onion_skin_enabled = False
    except Exception:
        pass

    try:
        for h in list(bpy.app.handlers.frame_change_post):
            if getattr(h, "__name__", "") in {
                "_unparent_frame_change_post",
                "_part_pivot_frame_change_post",
            }:
                bpy.app.handlers.frame_change_post.remove(h)

        for h in list(bpy.app.handlers.load_post):
            if getattr(h, "__name__", "") == "_load_post":
                bpy.app.handlers.load_post.remove(h)

        for h in list(bpy.app.handlers.depsgraph_update_post):
            if getattr(h, "__name__", "") == "_smart_material_import_depsgraph_update":
                bpy.app.handlers.depsgraph_update_post.remove(h)
            if getattr(h, "__name__", "") == "_roblox_compatibility_depsgraph_update":
                bpy.app.handlers.depsgraph_update_post.remove(h)
            if getattr(h, "__name__", "") == "_part_pivot_depsgraph_update":
                bpy.app.handlers.depsgraph_update_post.remove(h)
    except Exception:
        pass

    _disable_runtime()

    _dp_unregister()

    for c in reversed(classes):
        bpy.utils.unregister_class(c)

    for name in (
        "onion_skin_enabled",
        "onion_skin_opacity",
        "onion_skin_include_meshes",
        "onion_skin_include_bones",
        "onion_skin_raycast",
        "onion_skin_skip_hidden",
        "smart_material_import_enabled",
        "standardize_imported_material_display_enabled",
        "prevent_clothing_layer_clipping_enabled",
        "yellow_pin_mode",
        "roblox_compat_advanced_mode",
        "staticaliza_pivot_mode",
        "staticaliza_camera_fov_preset",
        "staticaliza_camera_fov",
        "staticaliza_camera_orientation",
    ):
        if hasattr(bpy.types.WindowManager, name):
            delattr(bpy.types.WindowManager, name)
    for name in (
        "staticaliza_camera_fov_preset",
        "staticaliza_camera_orientation",
        "staticaliza_camera_hide_attached_preview",
        "staticaliza_camera_hide_attached_object",
    ):
        if hasattr(bpy.types.Object, name):
            delattr(bpy.types.Object, name)
