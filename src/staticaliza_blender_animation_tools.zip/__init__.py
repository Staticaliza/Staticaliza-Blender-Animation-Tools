# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# <pep8 compliant>

# Credits to Staticaliza for most features.
# Credits to Roman Volodin, roman.volodin@gmail.com for their "Dynamic Parent" 2.0.2 (Blender 4 compatable) extension.

ADDON_VERSION = (1, 3, 21)

bl_info = {
    "name": "Roblox Animator Utils",
    "blender": (4, 3, 0),
    "version": ADDON_VERSION,
    "category": "Animation"
}

import bpy
import gpu
import addon_utils
import importlib
import json
import math
import os
import tempfile
import time
import tomllib
import urllib.error
import urllib.request
import zipfile
from mathutils import Vector, Matrix
from gpu_extras.batch import batch_for_shader
from bpy.app.handlers import persistent

_state = {
    "enabled": False,
    "handle_view": None,
    "handle_pixel": None,
    "shader_3d": None,
    "shader_3d_mode": "UNIFORM",
    "shader_2d": None,
    "mesh_batches": [],
    "raycast_fixed": {},
    "yellow_fixed": {},
    "yellow_modes": {},
    "yellow_hidden": False,
    "unparent_rel_cache": {},
    "unparent_handler_mute": False,
    "last_error": "",
    "smart_material_processed_rigs": set(),
    "extension_update_running": False,
    "extension_update_lock_waits": 0,
    "roblox_constraints_normalized": set(),
    "roblox_serializer_patch": None,
    "roblox_export_execute_patch": None,
    "roblox_import_execute_patch": None,
    "unparent_export_armature": None,
    "smart_material_scan_pending": False,
    "roblox_compatibility_scan_pending": False,
}

_keymaps = []

UNP_PROP = "staticaliza_unparent_marker"
UNP_STATE_KEY = "staticaliza_unparent_state"
REL_K_PARENT = "staticaliza_rel_saved_parent"
REL_K_CONNECT = "staticaliza_rel_saved_connect"
UNP_VIS_CONSTRAINT = "STATICALIZA_UNPARENT_VIS"

REL_K_HEAD = "staticaliza_rel_saved_head"
REL_K_TAIL = "staticaliza_rel_saved_tail"
REL_K_ROLL = "staticaliza_rel_saved_roll"

DP_BL_INFO = {
    "name": "Dynamic Parent",
    "author": "Roman Volodin, roman.volodin@gmail.com",
    "version": (2, 0, 2),
    "blender": (4, 0, 0),
    "location": "View3D > Tool Panel",
    "description": "Allows to create and disable an animated ChildOf constraint",
    "category": "Animation",
}

def get_rotation_mode(obj):
    if obj.rotation_mode in ("QUATERNION", "AXIS_ANGLE"):
        return obj.rotation_mode.lower()
    return "euler"

def get_selected_objects(context):
    if context.mode not in ("OBJECT", "POSE"):
        return

    if context.mode == "OBJECT":
        active = context.active_object
        selected = [obj for obj in context.selected_objects if obj != active]

    if context.mode == "POSE":
        active = context.active_pose_bone
        selected = [bone for bone in context.selected_pose_bones if bone != active]

    selected.append(active)
    return selected

def get_last_dynamic_parent_constraint(obj):
    if not obj.constraints:
        return
    for constraint in reversed(obj.constraints):
        if constraint.name.startswith("DP_") and constraint.influence > 0.5:
            return constraint

def insert_keyframe(obj, frame):
    rotation_mode = get_rotation_mode(obj)
    data_paths = (
        "location",
        f"rotation_{rotation_mode}",
        "scale",
    )
    for data_path in data_paths:
        obj.keyframe_insert(data_path = data_path, frame = frame)

def insert_keyframe_constraint(constraint, frame):
    constraint.keyframe_insert(data_path = "influence", frame = frame)

def dp_keyframe_insert_obj(obj):
    obj.keyframe_insert(data_path = "location")
    if obj.rotation_mode == "QUATERNION":
        obj.keyframe_insert(data_path = "rotation_quaternion")
    elif obj.rotation_mode == "AXIS_ANGLE":
        obj.keyframe_insert(data_path = "rotation_axis_angle")
    else:
        obj.keyframe_insert(data_path = "rotation_euler")
    obj.keyframe_insert(data_path = "scale")

def dp_keyframe_insert_pbone(arm, pbone):
    arm.keyframe_insert(data_path = 'pose.bones["' + pbone.name + '"].location')
    if pbone.rotation_mode == "QUATERNION":
        arm.keyframe_insert(
            data_path = 'pose.bones["' + pbone.name + '"].rotation_quaternion'
        )
    elif pbone.rotation_mode == "AXIS_ANGLE":
        arm.keyframe_insert(
            data_path = 'pose.bones["' + pbone.name + '"].rotation_axis_angle'
        )
    else:
        arm.keyframe_insert(data_path = 'pose.bones["' + pbone.name + '"].rotation_euler')
    arm.keyframe_insert(data_path = 'pose.bones["' + pbone.name + '"].scale')

def dp_create_dynamic_parent_obj(op):
    obj = bpy.context.active_object
    scn = bpy.context.scene
    list_selected_obj = bpy.context.selected_objects

    if len(list_selected_obj) == 2:
        i = list_selected_obj.index(obj)
        list_selected_obj.pop(i)
        parent_obj = list_selected_obj[0]

        dp_keyframe_insert_obj(obj)
        bpy.ops.object.constraint_add_with_targets(type = "CHILD_OF")
        last_constraint = obj.constraints[-1]

        if parent_obj.type == "ARMATURE":
            last_constraint.subtarget = parent_obj.data.bones.active.name
            last_constraint.name = "DP_" + last_constraint.target.name + "." + last_constraint.subtarget
        else:
            last_constraint.name = "DP_" + last_constraint.target.name

        C = bpy.context.copy()
        C["constraint"] = last_constraint
        bpy.ops.constraint.childof_set_inverse(
            constraint = last_constraint.name,
            owner = "OBJECT"
        )

        current_frame = scn.frame_current
        scn.frame_current = current_frame - 1
        obj.constraints[last_constraint.name].influence = 0
        obj.keyframe_insert(
            data_path = 'constraints["' + last_constraint.name + '"].influence'
        )

        scn.frame_current = current_frame
        obj.constraints[last_constraint.name].influence = 1
        obj.keyframe_insert(
            data_path = 'constraints["' + last_constraint.name + '"].influence'
        )

        for ob in list_selected_obj:
            ob.select_set(False)

        obj.select_set(True)
    else:
        op.report({"ERROR"}, "Two objects must be selected")

def dp_create_dynamic_parent_pbone(op):
    arm = bpy.context.active_object
    pbone = bpy.context.active_pose_bone
    scn = bpy.context.scene
    list_selected_obj = bpy.context.selected_objects

    if len(list_selected_obj) == 2 or len(list_selected_obj) == 1:
        if len(list_selected_obj) == 2:
            i = list_selected_obj.index(arm)
            list_selected_obj.pop(i)
            parent_obj = list_selected_obj[0]
            if parent_obj.type == "ARMATURE":
                parent_obj_pbone = parent_obj.data.bones.active
                if not parent_obj_pbone.select:
                    op.report({"ERROR"}, "At least two bones must be selected")
                    return
        else:
            parent_obj = arm
            selected_bones = bpy.context.selected_pose_bones
            selected_bones.remove(pbone)
            if not selected_bones:
                op.report({"ERROR"}, "At least two bones must be selected")
                return
            parent_obj_pbone = selected_bones[0]

        dp_keyframe_insert_pbone(arm, pbone)
        bpy.ops.pose.constraint_add_with_targets(type = "CHILD_OF")
        last_constraint = pbone.constraints[-1]

        if parent_obj.type == "ARMATURE":
            last_constraint.subtarget = parent_obj_pbone.name
            last_constraint.name = "DP_" + last_constraint.target.name + "." + last_constraint.subtarget
        else:
            last_constraint.name = "DP_" + last_constraint.target.name

        C = bpy.context.copy()
        C["constraint"] = last_constraint
        bpy.ops.constraint.childof_set_inverse(
            constraint = last_constraint.name,
            owner = "BONE"
        )

        current_frame = scn.frame_current
        scn.frame_current = current_frame - 1
        pbone.constraints[last_constraint.name].influence = 0
        arm.keyframe_insert(
            data_path = 'pose.bones["'
            + pbone.name
            + '"].constraints["'
            + last_constraint.name
            + '"].influence'
        )

        scn.frame_current = current_frame
        pbone.constraints[last_constraint.name].influence = 1
        arm.keyframe_insert(
            data_path = 'pose.bones["'
            + pbone.name
            + '"].constraints["'
            + last_constraint.name
            + '"].influence'
        )
    else:
        op.report({"ERROR"}, "Two objects must be selected")

def disable_constraint(obj, const, frame):
    if isinstance(obj, bpy.types.PoseBone):
        matrix_final = obj.matrix
    else:
        matrix_final = obj.matrix_world

    insert_keyframe(obj, frame = frame - 1)
    insert_keyframe_constraint(const, frame = frame - 1)

    const.influence = 0
    if isinstance(obj, bpy.types.PoseBone):
        obj.matrix = matrix_final
    else:
        obj.matrix_world = matrix_final

    insert_keyframe(obj, frame = frame)
    insert_keyframe_constraint(const, frame = frame)
    return

def _dp_curve_distance_from_frame(fcurve, frame):
    points = sorted(
        (
            int(round(float(key.co.x))),
            float(key.co.y),
        )
        for key in fcurve.keyframe_points
    )
    if not points:
        return float("inf")

    active_frames = [point_frame for point_frame, value in points if value > 0.5]
    if not active_frames:
        return min(abs(int(frame) - point_frame) for point_frame, _ in points)

    start_frame = min(active_frames)
    end_candidates = [
        point_frame
        for point_frame, value in points
        if point_frame > start_frame and value <= 0.5
    ]
    end_frame = min(end_candidates) if end_candidates else max(active_frames)
    if start_frame <= int(frame) <= end_frame:
        return 0
    return min(abs(int(frame) - start_frame), abs(int(frame) - end_frame))


def dp_clear(obj, pbone):
    if not obj:
        return False

    target = pbone if pbone else obj
    constraints = [
        constraint
        for constraint in target.constraints
        if constraint.name.startswith("DP_")
    ]
    if not constraints:
        return False

    action = obj.animation_data.action if obj.animation_data else None
    frame = int(bpy.context.scene.frame_current)
    candidates = []

    for constraint in constraints:
        fcurve = None
        if action:
            try:
                data_path = constraint.path_from_id("influence")
            except Exception:
                data_path = ""
            fcurve = _fcurve_find(action, data_path) if data_path else None
        distance = _dp_curve_distance_from_frame(fcurve, frame) if fcurve else float("inf")
        candidates.append((distance, constraint.name, constraint, fcurve))

    _, _, constraint, fcurve = min(candidates, key = lambda item: (item[0], item[1]))
    generated_frames = set()
    if fcurve:
        generated_frames.update(
            int(round(float(key.co.x))) for key in fcurve.keyframe_points
        )
        action.fcurves.remove(fcurve)

    if action and generated_frames:
        if pbone:
            transform_paths = {
                _pose_dp(pbone.name, "location"),
                _pose_dp(pbone.name, "scale"),
                _pose_dp(pbone.name, "rotation_euler"),
                _pose_dp(pbone.name, "rotation_quaternion"),
                _pose_dp(pbone.name, "rotation_axis_angle"),
            }
        else:
            transform_paths = {
                "location",
                "scale",
                "rotation_euler",
                "rotation_quaternion",
                "rotation_axis_angle",
            }

        for transform_curve in list(action.fcurves):
            if transform_curve.data_path not in transform_paths:
                continue
            for key in list(transform_curve.keyframe_points):
                if int(round(float(key.co.x))) in generated_frames:
                    transform_curve.keyframe_points.remove(key)
            if not transform_curve.keyframe_points:
                action.fcurves.remove(transform_curve)
            else:
                transform_curve.update()

    target.constraints.remove(constraint)
    return True

def _tag_redraw_all_view3d():
    wm = bpy.context.window_manager
    for window in wm.windows:
        for area in window.screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()

def _ensure_shader_3d():
    if _state["shader_3d"] is not None:
        return _state["shader_3d"]

    _state["last_error"] = ""
    try:
        _state["shader_3d"] = gpu.shader.from_builtin("UNIFORM_COLOR")
        _state["shader_3d_mode"] = "UNIFORM"
    except Exception:
        _state["shader_3d"] = gpu.shader.from_builtin("FLAT_COLOR")
        _state["shader_3d_mode"] = "VERTEX"

    return _state["shader_3d"]

def _ensure_shader_2d():
    if _state["shader_2d"] is not None:
        return _state["shader_2d"]

    vert = """
    in vec2 pos;
    uniform vec2 u_viewport;
    void main()
    {
        vec2 ndc = (pos / u_viewport) * 2.0 - 1.0;
        gl_Position = vec4(ndc.xy, 0.0, 1.0);
    }
    """
    frag = """
    uniform vec4 color;
    out vec4 FragColor;
    void main()
    {
        FragColor = color;
    }
    """
    _state["shader_2d"] = gpu.types.GPUShader(vert, frag)
    return _state["shader_2d"]

def _as_p4(v):
    try:
        if isinstance(v, Vector):
            if len(v) == 4:
                return Vector((float(v.x), float(v.y), float(v.z), float(v.w)))
            if len(v) == 3:
                return Vector((float(v.x), float(v.y), float(v.z), 1.0))
    except Exception:
        pass

    if isinstance(v, (list, tuple)) and len(v) >= 3:
        try:
            return Vector((float(v[0]), float(v[1]), float(v[2]), 1.0))
        except Exception:
            pass

    return Vector((0.0, 0.0, 0.0, 1.0))

def _world_to_bone_local_p4(eval_arm, pb, world_point):
    arm_mw = eval_arm.matrix_world
    try:
        arm_inv = arm_mw.inverted()
    except Exception:
        arm_inv = Matrix.Identity(4)

    try:
        pb_inv = pb.matrix.inverted()
    except Exception:
        pb_inv = Matrix.Identity(4)

    return pb_inv @ (arm_inv @ _as_p4(world_point))

def _bone_local_to_world(eval_arm, pb, local_p4):
    arm_mw = eval_arm.matrix_world
    try:
        out = arm_mw @ (pb.matrix @ _as_p4(local_p4))
    except Exception:
        out = arm_mw @ _as_p4((0.0, 0.0, 0.0))
    return Vector((float(out.x), float(out.y), float(out.z)))

def _is_object_visible(obj, context):
    wm = getattr(context, "window_manager", None)
    scn = getattr(context, "scene", None)
    if wm and not wm.onion_skin_skip_hidden:
        return True
    if not scn:
        return True
    if obj.hide_viewport:
        return False
    if obj.hide_get():
        return False
    try:
        if hasattr(obj, "visible_get"):
            return obj.visible_get(view_layer=context.view_layer)
    except TypeError:
        try:
            return obj.visible_get()
        except Exception:
            return True
    return True

def _active_armature(context):
    ob = context.active_object
    if ob and ob.type == "ARMATURE":
        return ob
    for ob in context.selected_objects:
        if ob.type == "ARMATURE":
            return ob
    ob = context.active_object
    if ob and hasattr(ob, "find_armature"):
        arm = ob.find_armature()
        if arm and arm.type == "ARMATURE":
            return arm
    return None

def _targets(context):
    arm = _active_armature(context)
    items = []

    if arm and _is_object_visible(arm, context):
        items.append(arm)

    if not arm:
        return items, None

    for obj in context.view_layer.objects:
        if obj == arm:
            continue
        if not _is_object_visible(obj, context):
            continue

        include = False

        if obj.parent == arm:
            include = True
        if obj.parent_type == "BONE" and obj.parent == arm:
            include = True

        if not include:
            for m in obj.modifiers:
                if m.type == "ARMATURE" and getattr(m, "object", None) == arm:
                    include = True
                    break

        if not include:
            for c in obj.constraints:
                t = getattr(c, "target", None)
                st = getattr(c, "subtarget", "")
                if t == arm and st:
                    include = True
                    break
                if c.type == "CHILD_OF" and t == arm:
                    include = True
                    break
                if c.type == "COPY_TRANSFORMS" and t == arm:
                    include = True
                    break
                if c.type == "COPY_LOCATION" and t == arm:
                    include = True
                    break
                if c.type == "COPY_ROTATION" and t == arm:
                    include = True
                    break
                if c.type == "COPY_SCALE" and t == arm:
                    include = True
                    break

        if include:
            items.append(obj)

    return list(dict.fromkeys(items)), arm

def _is_unmovable(pb):
    locked_loc = all(pb.lock_location)
    locked_scale = all(pb.lock_scale)
    locked_rot = all(pb.lock_rotation)
    if hasattr(pb, "lock_rotation_w"):
        locked_rot = locked_rot and bool(pb.lock_rotation_w)
    return locked_loc and locked_rot and locked_scale

def _runtime_needed(context):
    wm = getattr(context, "window_manager", None)
    if not wm:
        return bool(_state["yellow_modes"])
    return bool(wm.onion_skin_enabled) or bool(_state["yellow_modes"])

def _enable_runtime():
    if _state["enabled"]:
        return
    _state["enabled"] = True
    _state["handle_view"] = bpy.types.SpaceView3D.draw_handler_add(_draw_view, (), "WINDOW", "POST_VIEW")
    _state["handle_pixel"] = bpy.types.SpaceView3D.draw_handler_add(_draw_pixel, (), "WINDOW", "POST_PIXEL")
    _tag_redraw_all_view3d()

def _disable_runtime():
    if not _state["enabled"]:
        return

    _state["enabled"] = False

    if _state["handle_view"] is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_state["handle_view"], "WINDOW")
        _state["handle_view"] = None

    if _state["handle_pixel"] is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_state["handle_pixel"], "WINDOW")
        _state["handle_pixel"] = None

    _state["mesh_batches"] = []
    _state["raycast_fixed"] = {}
    _tag_redraw_all_view3d()

def _circle_tris_2d(center_xy, radius, segments = 18):
    if radius <= 0.0:
        return []

    cx, cy = center_xy
    verts = []

    for i in range(segments):
        a0 = (i / segments) * (math.pi * 2.0)
        a1 = ((i + 1) / segments) * (math.pi * 2.0)

        v0 = (cx, cy)
        v1 = (cx + math.cos(a0) * radius, cy + math.sin(a0) * radius)
        v2 = (cx + math.cos(a1) * radius, cy + math.sin(a1) * radius)

        verts.extend((v0, v1, v2))

    return verts

def _circle_scale_from_dist(dist_px):
    min_scale = 1.25
    max_scale = 3.0
    min_px = 14.0
    max_px = 120.0

    if dist_px <= min_px:
        return min_scale
    if dist_px >= max_px:
        return max_scale

    t = (dist_px - min_px) / (max_px - min_px)
    t = t * t * (3.0 - (2.0 * t))
    return min_scale + (t * (max_scale - min_scale))

def _bounds_init(p):
    return [p.x, p.y, p.z, p.x, p.y, p.z]

def _bounds_add(b, p):
    if p.x < b[0]:
        b[0] = p.x
    if p.y < b[1]:
        b[1] = p.y
    if p.z < b[2]:
        b[2] = p.z
    if p.x > b[3]:
        b[3] = p.x
    if p.y > b[4]:
        b[4] = p.y
    if p.z > b[5]:
        b[5] = p.z

def _bounds_center(b):
    return Vector(((b[0] + b[3]) * 0.5, (b[1] + b[4]) * 0.5, (b[2] + b[5]) * 0.5))

def _collect_world_shape_from_largest_components(context, depsgraph, arm, eval_arm, only_names, objs = None):
    if objs is None:
        objs, _ = _targets(context)

    min_w = 0.05
    per_bone = {bn: [] for bn in only_names}

    for obj in objs:
        if obj.type != "MESH":
            continue
        if not _is_object_visible(obj, context):
            continue

        eval_obj = obj.evaluated_get(depsgraph)
        mw = eval_obj.matrix_world

        mesh = eval_obj.to_mesh(preserve_all_data_layers = False, depsgraph = depsgraph)
        if not mesh:
            continue

        for bn in only_names:
            vg = None
            try:
                vg = obj.vertex_groups.get(bn)
            except Exception:
                vg = None
            if not vg:
                continue

            vg_i = int(vg.index)

            b_world = None
            for v in mesh.vertices:
                w = 0.0
                for g in v.groups:
                    if int(g.group) == vg_i:
                        w = float(g.weight)
                        break
                if w < float(min_w):
                    continue

                p_world = mw @ v.co
                if b_world is None:
                    b_world = _bounds_init(p_world)
                else:
                    _bounds_add(b_world, p_world)

            if b_world is None:
                continue

            dx = float(b_world[3] - b_world[0])
            dy = float(b_world[4] - b_world[1])
            dz = float(b_world[5] - b_world[2])
            vol = max(0.0, dx) * max(0.0, dy) * max(0.0, dz)

            per_bone[bn].append((vol, b_world))

        eval_obj.to_mesh_clear()

    out = {}
    keep_ratio = 0.25
    keep_max = 6

    for bn, items in per_bone.items():
        if not items:
            continue

        items.sort(key = lambda x: float(x[0]), reverse = True)
        max_vol = float(items[0][0])
        cutoff = max_vol * keep_ratio

        keep = []
        for vol, b in items:
            if len(keep) >= keep_max:
                break
            if len(keep) == 0 or float(vol) >= cutoff:
                keep.append(b)

        merged = None
        for b in keep:
            if merged is None:
                merged = list(b)
            else:
                merged[0] = min(merged[0], b[0])
                merged[1] = min(merged[1], b[1])
                merged[2] = min(merged[2], b[2])
                merged[3] = max(merged[3], b[3])
                merged[4] = max(merged[4], b[4])
                merged[5] = max(merged[5], b[5])

        if merged is not None:
            out[bn] = merged

    return out

def _rig_local_bottom_center(matrix_world, points):
    try:
        matrix_inverse = matrix_world.inverted()
    except Exception:
        matrix_inverse = Matrix.Identity(4)

    rig_bounds = None
    for point in points:
        local = matrix_inverse @ Vector((point.x, point.y, point.z, 1.0))
        local_point = Vector((float(local.x), float(local.y), float(local.z)))
        if rig_bounds is None:
            rig_bounds = _bounds_init(local_point)
        else:
            _bounds_add(rig_bounds, local_point)

    if rig_bounds is None:
        return None

    center_x = (float(rig_bounds[0]) + float(rig_bounds[3])) * 0.5
    center_y = (float(rig_bounds[1]) + float(rig_bounds[4])) * 0.5
    bottom_z = float(rig_bounds[2])
    world = matrix_world @ Vector((center_x, center_y, bottom_z, 1.0))
    return Vector((float(world.x), float(world.y), float(world.z)))


def _rig_local_lower_bone_endpoint(eval_arm, pose_bone):
    endpoint = pose_bone.head if pose_bone.head.z <= pose_bone.tail.z else pose_bone.tail
    return eval_arm.matrix_world @ endpoint


def _pose_bone_numeric_family_levels(eval_arm, pose_bone):
    canonical_name = _strip_blender_numeric_suffix(pose_bone.name)
    levels = []

    canonical_bone = eval_arm.pose.bones.get(canonical_name)
    if canonical_bone is not None:
        levels.append({canonical_bone.name})

    prefix = f"{canonical_name}."
    variants = []
    for bone in eval_arm.pose.bones:
        if not bone.name.startswith(prefix):
            continue
        suffix = bone.name[len(prefix):]
        if suffix.isdigit():
            variants.append((int(suffix), bone.name))

    if variants:
        variants.sort(key = lambda item: (item[0], item[1]))
        levels.append({name for _number, name in variants})

    if not levels:
        levels.append({pose_bone.name})

    return levels


def _node_tree_has_linked_base_color(node_tree, visited = None):
    if node_tree is None:
        return False
    if visited is None:
        visited = set()

    pointer = node_tree.as_pointer()
    if pointer in visited:
        return False
    visited.add(pointer)

    for node in node_tree.nodes:
        if node.type == "BSDF_PRINCIPLED":
            base_color = node.inputs.get("Base Color")
            if base_color and base_color.is_linked:
                return True
        if (
            node.type == "GROUP"
            and getattr(node, "node_tree", None)
            and _node_tree_has_linked_base_color(node.node_tree, visited)
        ):
            return True
    return False


def _object_has_linked_base_color(obj):
    materials = getattr(getattr(obj, "data", None), "materials", ())
    return any(
        _node_tree_has_linked_base_color(getattr(material, "node_tree", None))
        for material in materials
        if material is not None
    )


def _yellow_mode3_point(context, depsgraph, arm, eval_arm, objs, bone_name):
    pb = eval_arm.pose.bones.get(bone_name)
    if not pb:
        return None

    fallback = _rig_local_lower_bone_endpoint(eval_arm, pb)

    keep_ratio = 0.25
    keep_max = 6
    candidates = []

    # Prefer the canonical non-numbered bone. Only fall back through connected
    # Blender numeric variants, never unrelated child branches such as limbs.
    for level_names in _pose_bone_numeric_family_levels(eval_arm, pb):
        level_candidates = []

        for obj in objs or ():
            if obj.type != "MESH":
                continue
            if not _is_object_visible(obj, context):
                continue

            rigid_match = (
                obj.parent == arm
                and obj.parent_type == "BONE"
                and getattr(obj, "parent_bone", "") in level_names
            )
            if not rigid_match:
                for constraint in obj.constraints:
                    if (
                        getattr(constraint, "target", None) == arm
                        and getattr(constraint, "subtarget", "") in level_names
                    ):
                        rigid_match = True
                        break

            vertex_group_indices = set()
            if not rigid_match:
                try:
                    for descendant_name in level_names:
                        vertex_group = obj.vertex_groups.get(descendant_name)
                        if vertex_group:
                            vertex_group_indices.add(int(vertex_group.index))
                except Exception:
                    vertex_group_indices.clear()

            points = []

            if rigid_match:
                eval_obj = obj.evaluated_get(depsgraph)
                mw = eval_obj.matrix_world
                for corner in eval_obj.bound_box:
                    points.append(mw @ Vector(corner))
            elif vertex_group_indices:
                eval_obj = obj.evaluated_get(depsgraph)
                mesh = eval_obj.to_mesh(preserve_all_data_layers = False, depsgraph = depsgraph)
                if not mesh:
                    continue

                mw = eval_obj.matrix_world

                for min_w in (0.35, 0.2, 0.05):
                    points = []
                    for vertex in mesh.vertices:
                        weight = 0.0
                        for group in vertex.groups:
                            if int(group.group) in vertex_group_indices:
                                weight = max(weight, float(group.weight))
                        if weight >= float(min_w):
                            points.append(mw @ vertex.co)

                    if len(points) >= 12:
                        break

                eval_obj.to_mesh_clear()
            else:
                continue

            if not points:
                continue

            bounds = _bounds_init(points[0])
            for point in points[1:]:
                _bounds_add(bounds, point)

            dx = float(bounds[3] - bounds[0])
            dy = float(bounds[4] - bounds[1])
            dz = float(bounds[5] - bounds[2])
            volume = max(0.0, dx) * max(0.0, dy) * max(0.0, dz)
            level_candidates.append(
                (volume, points, obj, _object_has_linked_base_color(obj))
            )

        if level_candidates:
            without_linked_base_color = [
                candidate for candidate in level_candidates if not candidate[3]
            ]
            candidates = without_linked_base_color or level_candidates
            break

    if not candidates:
        return fallback.copy()

    candidates.sort(key = lambda x: float(x[0]), reverse = True)
    max_vol = float(candidates[0][0])
    cutoff = max_vol * keep_ratio

    cloud = []
    kept = 0
    for vol, points, _obj, _has_linked_base_color in candidates:
        if kept >= keep_max:
            break
        if kept == 0 or float(vol) >= cutoff:
            cloud.extend(points)
            kept += 1

    if not cloud:
        return fallback.copy()

    if len(cloud) > 8000:
        step = int(len(cloud) / 8000) + 1
        cloud = cloud[::step]

    bottom = _rig_local_bottom_center(eval_arm.matrix_world, cloud)
    return bottom if bottom is not None else fallback.copy()

def _yellow_capture(context, depsgraph, arm, eval_arm, objs, bone_name, mode, bounds_world_map):
    pb = eval_arm.pose.bones.get(bone_name)
    if not pb:
        return None

    arm_mw = eval_arm.matrix_world
    head = arm_mw @ pb.head
    tail = arm_mw @ pb.tail

    if mode == 1:
        end = tail
    elif mode == 2:
        b_world = bounds_world_map.get(bone_name, None) if bounds_world_map else None
        if b_world:
            end = _bounds_center(b_world)
        else:
            end = (head + tail) * 0.5
    elif mode == 4:
        end = head
    else:
        end = _yellow_mode3_point(context, depsgraph, arm, eval_arm, objs, bone_name)
        if end is None:
            end = tail

    draw_dots = True
    if _is_unmovable(pb):
        draw_dots = False

    if mode == 3 or mode == 4:
        local_p4 = Vector((0.0, 0.0, 0.0, 1.0))
    else:
        try:
            local_p4 = _world_to_bone_local_p4(eval_arm, pb, end)
        except Exception:
            local_p4 = Vector((0.0, 0.0, 0.0, 1.0))

    return (end.copy(), local_p4.copy(), draw_dots, int(mode))

def _yellow_refresh_runtime(context):
    if not getattr(context, "window_manager", None):
        return
    if _runtime_needed(context):
        _enable_runtime()
    else:
        _disable_runtime()
    _tag_redraw_all_view3d()

def _build_snapshot_data(context):
    scn = context.scene
    wm = context.window_manager
    depsgraph = context.evaluated_depsgraph_get()
    objs, arm = _targets(context)

    include_meshes = wm.onion_skin_include_meshes
    include_bones = wm.onion_skin_include_bones
    raycast = wm.onion_skin_raycast

    shader3d = _ensure_shader_3d()
    vertex_color = (_state["shader_3d_mode"] == "VERTEX")

    mesh_alpha = wm.onion_skin_opacity
    mesh_color = (1.0, 0.0, 0.0, mesh_alpha)

    mesh_batches = []
    raycast_fixed = {}

    if include_meshes:
        for obj in objs:
            if obj.type != "MESH":
                continue
            if not _is_object_visible(obj, context):
                continue

            eval_obj = obj.evaluated_get(depsgraph)
            mesh = eval_obj.to_mesh(preserve_all_data_layers = False, depsgraph = depsgraph)
            if not mesh:
                continue

            mw = eval_obj.matrix_world

            try:
                mesh.calc_loop_triangles()
            except Exception:
                eval_obj.to_mesh_clear()
                continue

            tri_pos = []
            verts = mesh.vertices
            for tri in mesh.loop_triangles:
                v0, v1, v2 = tri.vertices
                tri_pos.append(mw @ verts[v0].co)
                tri_pos.append(mw @ verts[v1].co)
                tri_pos.append(mw @ verts[v2].co)

            if tri_pos:
                if vertex_color:
                    cols = [mesh_color] * len(tri_pos)
                    mesh_batches.append(batch_for_shader(shader3d, "TRIS", {"pos": tri_pos, "color": cols}))
                else:
                    mesh_batches.append(batch_for_shader(shader3d, "TRIS", {"pos": tri_pos}))

            eval_obj.to_mesh_clear()

    if not arm or not include_bones or not raycast:
        return mesh_batches, raycast_fixed

    arm_eval = arm.evaluated_get(depsgraph)
    arm_mw = arm_eval.matrix_world

    for pb in arm_eval.pose.bones:
        head = arm_mw @ pb.head
        tail = arm_mw @ pb.tail
        end = tail

        draw_dots = True
        if pb.parent is None:
            draw_dots = False
        elif _is_unmovable(pb):
            draw_dots = False

        try:
            local_p4 = _world_to_bone_local_p4(arm_eval, pb, end)
        except Exception:
            local_p4 = Vector((0.0, 0.0, 0.0, 1.0))

        raycast_fixed[pb.name] = (end.copy(), local_p4.copy(), draw_dots, 1)

    return mesh_batches, raycast_fixed

def _capture_or_clear(context, enable_ghost):
    _state["last_error"] = ""

    if enable_ghost:
        _enable_runtime()
        try:
            bpy.context.view_layer.update()
            mesh_batches, raycast_fixed = _build_snapshot_data(context)
            _state["mesh_batches"] = mesh_batches
            _state["raycast_fixed"] = raycast_fixed
        except Exception as e:
            _state["last_error"] = str(e)
            _state["mesh_batches"] = []
            _state["raycast_fixed"] = {}
    else:
        _state["mesh_batches"] = []
        _state["raycast_fixed"] = {}

    if not _runtime_needed(context):
        _disable_runtime()

    _tag_redraw_all_view3d()

def _on_enabled_toggle(self, context):
    _capture_or_clear(context, self.onion_skin_enabled)

def _on_setting_change(self, context):
    if not self.onion_skin_enabled:
        return
    _capture_or_clear(context, True)

def _draw_view():
    context = bpy.context
    wm = getattr(context, "window_manager", None)
    if not wm or not wm.onion_skin_enabled:
        return
    if not _state["mesh_batches"]:
        return

    shader = _ensure_shader_3d()
    color = (1.0, 0.0, 0.0, wm.onion_skin_opacity)

    gpu.state.depth_test_set("LESS_EQUAL")
    gpu.state.depth_mask_set(False)
    gpu.state.blend_set("ALPHA")

    if _state["shader_3d_mode"] == "UNIFORM":
        shader.bind()
        shader.uniform_float("color", color)

    for b in _state["mesh_batches"]:
        b.draw(shader)

    gpu.state.blend_set("NONE")
    gpu.state.depth_mask_set(True)
    gpu.state.depth_test_set("LESS_EQUAL")

def _draw_raycast_layer(context, fixed_map, color_rgba):
    if not fixed_map:
        return

    region = getattr(context, "region", None)
    rv3d = getattr(context, "region_data", None)
    if not region or not rv3d:
        return

    from bpy_extras import view3d_utils

    arm = _active_armature(context)
    if not arm:
        return

    depsgraph = context.evaluated_depsgraph_get()
    eval_arm = arm.evaluated_get(depsgraph)
    mw = eval_arm.matrix_world

    shader2d = _ensure_shader_2d()
    shader2d.bind()
    shader2d.uniform_float("u_viewport", (float(region.width), float(region.height)))

    line_pos = []
    tri_pos = []
    line_pos_snap = []
    tri_pos_snap = []

    circle_base = 5.0
    green = (0.0, 1.0, 0.0, float(color_rgba[3]))

    objs_cache = None

    for name, packed in fixed_map.items():
        if not packed or len(packed) < 2:
            continue

        fixed3d = packed[0]
        local_p4 = packed[1]
        draw_dots = bool(packed[2]) if len(packed) >= 3 else True
        mode = int(packed[3]) if len(packed) >= 4 else 1

        pb = eval_arm.pose.bones.get(name)
        if not pb:
            continue

        if mode == 3:
            if objs_cache is None:
                objs_cache, _ = _targets(context)
            current3d = _yellow_mode3_point(context, depsgraph, arm, eval_arm, objs_cache, name)
            if current3d is None:
                current3d = mw @ pb.tail
        elif mode == 4:
            current3d = mw @ pb.matrix.to_translation()
        else:
            try:
                current3d = _bone_local_to_world(eval_arm, pb, local_p4)
            except Exception:
                current3d = mw @ pb.tail

        fixed2d = view3d_utils.location_3d_to_region_2d(region, rv3d, fixed3d)
        curr2d = view3d_utils.location_3d_to_region_2d(region, rv3d, current3d)
        if not fixed2d or not curr2d:
            continue

        a = (fixed2d.x, fixed2d.y)
        b = (curr2d.x, curr2d.y)

        dx = a[0] - b[0]
        dy = a[1] - b[1]
        dist_px = math.sqrt((dx * dx) + (dy * dy))

        dist_world = (fixed3d - current3d).length
        snap_world = 0.05
        snapped = dist_world <= snap_world

        if snapped:
            line_pos_snap.extend((a, b))
        else:
            line_pos.extend((a, b))

        if draw_dots:
            if snapped:
                tri_pos_snap.extend(_circle_tris_2d(a, circle_base))
                tri_pos_snap.extend(_circle_tris_2d(b, circle_base))
            else:
                r = circle_base * _circle_scale_from_dist(dist_px)
                tri_pos.extend(_circle_tris_2d(a, circle_base))
                tri_pos.extend(_circle_tris_2d(b, r))

    if line_pos:
        shader2d.uniform_float("color", color_rgba)
        batch_for_shader(shader2d, "LINES", {"pos": line_pos}).draw(shader2d)

    if tri_pos:
        shader2d.uniform_float("color", color_rgba)
        batch_for_shader(shader2d, "TRIS", {"pos": tri_pos}).draw(shader2d)

    if line_pos_snap:
        shader2d.uniform_float("color", green)
        batch_for_shader(shader2d, "LINES", {"pos": line_pos_snap}).draw(shader2d)

    if tri_pos_snap:
        shader2d.uniform_float("color", green)
        batch_for_shader(shader2d, "TRIS", {"pos": tri_pos_snap}).draw(shader2d)

def _draw_pixel():
    context = bpy.context
    wm = getattr(context, "window_manager", None)
    if not wm:
        return
    if (not wm.onion_skin_enabled) and (not _state["yellow_modes"]):
        return

    gpu.state.depth_test_set("NONE")
    gpu.state.blend_set("NONE")

    try:
        gpu.state.line_width_set(4.0)
    except Exception:
        pass

    if wm.onion_skin_enabled and wm.onion_skin_include_bones and wm.onion_skin_raycast:
        _draw_raycast_layer(context, _state["raycast_fixed"], (1.0, 0.0, 0.0, 1.0))

    if _state["yellow_modes"] and (not _state["yellow_hidden"]):
        _draw_raycast_layer(context, _state["yellow_fixed"], (1.0, 1.0, 0.0, 1.0))

    try:
        gpu.state.line_width_set(1.0)
    except Exception:
        pass

class ONION_SKIN_OT_ghost_toggle(bpy.types.Operator):
    bl_idname = "onion_skin.ghost_toggle"
    bl_label = "Toggle Ghost"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def execute(self, context):
        wm = context.window_manager
        enabling = not wm.onion_skin_enabled
        wm.onion_skin_enabled = enabling

        if enabling:
            wm.onion_skin_include_meshes = True
            wm.onion_skin_include_bones = False

        return {"FINISHED"}

def _selected_pose_bones_or_active(context):
    try:
        selected = list(context.selected_pose_bones) if context.selected_pose_bones else []
    except Exception:
        selected = []
    if selected:
        return [b for b in selected if b]
    if context.active_pose_bone:
        return [context.active_pose_bone]
    return []

def _selected_pose_bones_only(context):
    try:
        return [b for b in (list(context.selected_pose_bones) if context.selected_pose_bones else []) if b]
    except Exception:
        return []

class STATICALIZA_OT_yellow_resync_all(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_resync_all"
    bl_label = "Update Pins"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def execute(self, context):
        if not _state["yellow_modes"]:
            return {"CANCELLED"}

        arm = _active_armature(context)
        if not arm:
            return {"CANCELLED"}

        depsgraph = context.evaluated_depsgraph_get()
        eval_arm = arm.evaluated_get(depsgraph)
        objs, _ = _targets(context)

        pins = dict(_state["yellow_modes"])
        fixed = {}

        need_bounds = {n for n, m in pins.items() if int(m) in (2, 3)}
        bounds_world = {}
        if need_bounds:
            bounds_world = _collect_world_shape_from_largest_components(context, depsgraph, arm, eval_arm, need_bounds, objs = objs)

        for n, m in pins.items():
            cap = _yellow_capture(context, depsgraph, arm, eval_arm, objs, n, int(m), bounds_world)
            if cap:
                fixed[n] = cap

        _state["yellow_fixed"] = fixed
        _state["yellow_hidden"] = False
        _yellow_refresh_runtime(context)
        return {"FINISHED"}

class STATICALIZA_OT_yellow_clear_all(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_clear_all"
    bl_label = "Clear"
    bl_description = "Remove every Onion Pin"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE" and bool(_state.get("yellow_modes"))

    def execute(self, context):
        removed = len(_state.get("yellow_modes", {}))
        _state["yellow_modes"] = {}
        _state["yellow_fixed"] = {}
        _state["yellow_hidden"] = False
        _yellow_refresh_runtime(context)
        self.report({"INFO"}, f"Cleared {removed} Onion Pin(s).")
        return {"FINISHED"}

class STATICALIZA_OT_yellow_hide_all(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_hide_all"
    bl_label = "Hide Pins"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def execute(self, context):
        _state["yellow_hidden"] = True
        _yellow_refresh_runtime(context)
        return {"FINISHED"}

class STATICALIZA_OT_yellow_show(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_show"
    bl_label = "Show Pins"
    bl_options = {"REGISTER"}

    resync: bpy.props.BoolProperty(default = False)

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def execute(self, context):
        _state["yellow_hidden"] = False

        if self.resync and _state["yellow_modes"]:
            arm = _active_armature(context)
            if arm:
                depsgraph = context.evaluated_depsgraph_get()
                eval_arm = arm.evaluated_get(depsgraph)
                objs, _ = _targets(context)

                pins = dict(_state["yellow_modes"])
                fixed = dict(_state["yellow_fixed"])

                need_bounds = {n for n, m in pins.items() if int(m) in (2, 3)}
                bounds_world = {}
                if need_bounds:
                    bounds_world = _collect_world_shape_from_largest_components(context, depsgraph, arm, eval_arm, need_bounds, objs = objs)

                for n, m in pins.items():
                    cap = _yellow_capture(context, depsgraph, arm, eval_arm, objs, n, int(m), bounds_world)
                    if cap:
                        fixed[n] = cap

                _state["yellow_fixed"] = fixed

        _yellow_refresh_runtime(context)
        return {"FINISHED"}

class STATICALIZA_OT_yellow_apply(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_apply"
    bl_label = "Apply Yellow Pin"
    bl_options = {"REGISTER"}

    action: bpy.props.EnumProperty(
        items = (
            ("MODE_1", "Bone End", ""),
            ("MODE_2", "Bone Center", ""),
            ("MODE_3", "Smart Bottom", ""),
            ("PIVOT", "Pivot", ""),
            ("REMOVE", "Remove", "")
        )
    )

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def execute(self, context):
        arm = _active_armature(context)
        if not arm:
            return {"CANCELLED"}

        bones = _selected_pose_bones_or_active(context)
        if not bones:
            return {"CANCELLED"}

        pins = dict(_state.get("yellow_modes", {}))
        fixed = dict(_state.get("yellow_fixed", {}))

        sel_names = [b.name for b in bones if b]
        sel_set = set(sel_names)

        if self.action == "PIVOT":
            depsgraph = context.evaluated_depsgraph_get()
            eval_arm = arm.evaluated_get(depsgraph)
            
            objs_cache = None
            if any(int(fixed.get(n, [0,0,0,1])[3]) == 3 for n in sel_set if n in fixed):
                objs_cache, _ = _targets(context)

            frame = int(context.scene.frame_current)

            for n in sel_set:
                if n not in fixed:
                    continue
                
                packed = fixed[n]
                fixed3d = packed[0]
                local_p4 = packed[1]
                mode = int(packed[3]) if len(packed) >= 4 else 1

                pb_eval = eval_arm.pose.bones.get(n)
                if not pb_eval:
                    continue
                
                curr = None
                if mode == 3:
                    curr = _yellow_mode3_point(context, depsgraph, arm, eval_arm, objs_cache, n)
                
                if curr is None:
                    try:
                        curr = _bone_local_to_world(eval_arm, pb_eval, local_p4)
                    except Exception:
                        curr = None
                
                if curr is None:
                    continue

                diff = fixed3d - curr
                
                arm_mw = eval_arm.matrix_world
                try:
                    diff_arm = arm_mw.inverted().to_3x3() @ diff
                except Exception:
                    diff_arm = Vector((0.0, 0.0, 0.0))
                
                pb = arm.pose.bones.get(n)
                if pb:
                    m = pb.matrix.copy()
                    m.translation += diff_arm
                    pb.matrix = m
                    
                    context.view_layer.update()
                    _insert_bone_keys(pb, frame)

            return {"FINISHED"}

        if self.action == "REMOVE":
            for n in sel_set:
                pins.pop(n, None)
                fixed.pop(n, None)

            _state["yellow_modes"] = pins
            _state["yellow_fixed"] = fixed
            _yellow_refresh_runtime(context)
            return {"FINISHED"}

        mode = 1
        if self.action == "MODE_2":
            mode = 2
        elif self.action == "MODE_3":
            mode = 3

        depsgraph = context.evaluated_depsgraph_get()
        eval_arm = arm.evaluated_get(depsgraph)
        objs, _ = _targets(context)

        need_bounds = sel_set if mode in (2, 3) else set()
        bounds_world = {}
        if need_bounds:
            bounds_world = _collect_world_shape_from_largest_components(context, depsgraph, arm, eval_arm, need_bounds, objs = objs)

        for n in sel_set:
            pins[n] = int(mode)
            cap = _yellow_capture(context, depsgraph, arm, eval_arm, objs, n, int(mode), bounds_world)
            if cap:
                fixed[n] = cap

        fixed = {k: v for k, v in fixed.items() if k in pins}

        _state["yellow_modes"] = pins
        _state["yellow_fixed"] = fixed

        _yellow_refresh_runtime(context)
        return {"FINISHED"}
    
class STATICALIZA_MT_yellow_pin_menu(bpy.types.Menu):
    bl_label = "Onion Pin"

    def draw(self, context):
        bones = _selected_pose_bones_only(context)
        sel_names = [b.name for b in bones if b]
        sel_set = set(sel_names)
        pinned = set(_state.get("yellow_modes", {}).keys())

        any_pinned = bool(sel_set.intersection(pinned))

        layout = self.layout
        mode = getattr(context.window_manager, "yellow_pin_mode", "MODE_3")
        selected_pins = len(sel_set.intersection(pinned))
        update_text = "Update Selected Pin" if selected_pins == 1 else "Update Selected Pins"
        layout.operator("staticaliza.yellow_apply", text = update_text).action = mode

        if any_pinned:
            layout.separator()
            txt_piv = "Pivot Selected Pin" if len(sel_set) == 1 else "Pivot Selected Pins"
            layout.operator("staticaliza.yellow_apply", text = txt_piv).action = "PIVOT"

            layout.separator()
            txt_rem = "Remove Selected Pin" if len(sel_set) == 1 else "Remove Selected Pins"
            layout.operator("staticaliza.yellow_apply", text = txt_rem).action = "REMOVE"

class STATICALIZA_MT_yellow_hidden_menu(bpy.types.Menu):
    bl_label = "Onion Pin"

    def draw(self, context):
        layout = self.layout
        op = layout.operator("staticaliza.yellow_show", text = "Show Pins")
        op.resync = False
        op2 = layout.operator("staticaliza.yellow_show", text = "Show and Update Pins")
        op2.resync = True

class STATICALIZA_MT_empty_cancel(bpy.types.Menu):
    bl_label = "Cancel"

    def draw(self, context):
        pass

class STATICALIZA_MT_yellow_no_selection_menu(bpy.types.Menu):
    bl_label = "Onion Pin"

    def draw(self, context):
        layout = self.layout
        layout.operator("staticaliza.yellow_hide_all", text = "Hide Pins")
        layout.operator("staticaliza.yellow_resync_all", text = "Update Pins")

class STATICALIZA_OT_yellow_menu(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_menu"
    bl_label = "Onion Pin"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def invoke(self, context, event):
        bones = _selected_pose_bones_only(context)

        if not bones:
            if not _state["yellow_modes"]:
                return {"CANCELLED"}

            if _state["yellow_hidden"]:
                bpy.ops.wm.call_menu(name = "STATICALIZA_MT_yellow_hidden_menu")
                return {"FINISHED"}

            bpy.ops.wm.call_menu(name = "STATICALIZA_MT_yellow_no_selection_menu")
            return {"FINISHED"}

        pinned = set(_state.get("yellow_modes", {}).keys())
        selected_names = {bone.name for bone in bones if bone}
        if selected_names.intersection(pinned):
            bpy.ops.wm.call_menu(name = "STATICALIZA_MT_yellow_pin_menu")
            return {"FINISHED"}

        mode = getattr(context.window_manager, "yellow_pin_mode", "MODE_3")
        return bpy.ops.staticaliza.yellow_apply("EXEC_DEFAULT", action = mode)

def _ensure_object_action(obj):
    if not obj.animation_data:
        obj.animation_data_create()
    if not obj.animation_data.action:
        obj.animation_data.action = bpy.data.actions.new(name = f"{obj.name}Action")
    return obj.animation_data.action

def _fcurve_find(action, data_path):
    if not action:
        return None
    for fc in action.fcurves:
        if fc.data_path == data_path:
            return fc
    return None

def _fcurves_find_all(action, data_path):
    if not action:
        return []
    return [fc for fc in action.fcurves if fc.data_path == data_path]

def _fcurve_key_at(fc, frame):
    if not fc:
        return None
    for kp in fc.keyframe_points:
        if abs(float(kp.co.x) - float(frame)) <= 0.0001:
            return kp
    return None

def _fcurve_remove_key_all(action, data_path, frame):
    if not action:
        return

    frame = int(frame)

    for fc in list(_fcurves_find_all(action, data_path)):
        removed = False

        for kp in list(fc.keyframe_points):
            try:
                fr = int(round(float(kp.co.x)))
            except Exception:
                continue

            if int(fr) != int(frame):
                continue

            try:
                fc.keyframe_points.remove(kp)
                removed = True
            except Exception:
                pass

        if removed:
            if not fc.keyframe_points:
                try:
                    action.fcurves.remove(fc)
                except Exception:
                    pass
            else:
                try:
                    fc.update()
                except Exception:
                    pass

def _fcurve_set_constant(action, data_path, frame):
    if not action:
        return

    frame = float(int(frame))

    for fc in _fcurves_find_all(action, data_path):
        kp = _fcurve_key_at(fc, frame)
        if not kp:
            continue

        try:
            kp.interpolation = "CONSTANT"
        except Exception:
            pass

        try:
            kp.handle_left_type = "AUTO_CLAMPED"
            kp.handle_right_type = "AUTO_CLAMPED"
        except Exception:
            pass

        try:
            kp.type = "KEYFRAME"
        except Exception:
            pass

        try:
            fc.update()
        except Exception:
            pass

def _unparent_next_transform_keyframe(action, bone_name, after_frame):
    if not action:
        return None

    after_frame = int(after_frame)
    prefix = f'pose.bones["{bone_name}"].'
    best = None

    for prop in (
        "location",
        "scale",
        "rotation_euler",
        "rotation_quaternion",
        "rotation_axis_angle"
    ):
        for fc in _fcurves_find_all(action, prefix + prop):
            for kp in fc.keyframe_points:
                try:
                    fr = int(round(float(kp.co.x)))
                except Exception:
                    continue

                if fr <= after_frame:
                    continue

                if best is None or fr < best:
                    best = fr

    return int(best) if best is not None else None

def _unparent_next_start_after(action, bone_name, start_frame):
    if not action:
        return None

    s = int(start_frame)
    pts = _unparent_points(action, bone_name)
    if not pts:
        return None

    state = False
    inside = False

    for fr, v in pts:
        fr = int(fr)
        new_state = float(v) >= 0.5

        if fr <= s:
            state = new_state
            continue

        if inside:
            if new_state and not state:
                return int(fr)
        else:
            if state:
                inside = True

        state = new_state

    return None

def _unparent_allow_settle(action, bone_name, frame):
    nxt = _unparent_next_start_after(action, bone_name, int(frame))
    if nxt is None:
        return True
    return int(frame + 1) < int(nxt)

def _unparent_insert_hold_keys(context, arm, action, bone_name, frame, world_m, snap_pose, allow_next = True):
    scn = context.scene

    try:
        arm_inv = arm.matrix_world.inverted()
    except Exception:
        arm_inv = Matrix.Identity(4)

    f0 = int(frame)
    f1 = int(f0 + 1)

    do_f1 = bool(allow_next)
    if do_f1 and action:
        do_f1 = _unparent_allow_settle(action, bone_name, int(f0))
    if int(f1) > int(scn.frame_end):
        do_f1 = False

    scn.frame_set(int(f0))
    context.view_layer.update()

    pb0 = arm.pose.bones.get(bone_name)
    if pb0 and world_m is not None:
        try:
            pb0.matrix = arm_inv @ world_m
        except Exception:
            pass
        context.view_layer.update()
        _insert_bone_keys(pb0, int(f0))
        _set_pose_keys_vector_handles_new_only(action, bone_name, int(f0), snap_pose)

    if do_f1:
        scn.frame_set(int(f1))
        context.view_layer.update()

        pb1 = arm.pose.bones.get(bone_name)
        if pb1 and world_m is not None:
            try:
                pb1.matrix = arm_inv @ world_m
            except Exception:
                pass
            context.view_layer.update()
            _insert_bone_keys(pb1, int(f1))
            _set_pose_keys_vector_handles_new_only(action, bone_name, int(f1), snap_pose)

    lock_frames = {int(f0)}
    if do_f1:
        lock_frames.add(int(f1))

    for lf in sorted(lock_frames):
        _lock_pose_key_handles(action, bone_name, int(lf))

def _unparent_bake_to_end_target(context, action, bone_name, current_frame):
    scn = context.scene
    f_end = int(scn.frame_end)

    nxt_t = _unparent_next_transform_keyframe(action, bone_name, int(current_frame))
    nxt_s = _unparent_find_next_start_frame_from_points(action, bone_name, int(current_frame))

    targets = [f_end]
    if nxt_t is not None:
        targets.append(int(nxt_t))
    
    if nxt_s is not None:
        targets.append(int(nxt_s) - 1)

    return min(targets)

def _unparent_dp(bone_name):
    return f'pose.bones["{bone_name}"]["{UNP_PROP}"]'

def _pose_dp(bone_name, prop):
    return f'pose.bones["{bone_name}"].{prop}'

def _pb_prop_get(pb, key, default_value = 0.0):
    try:
        return float(pb.get(key, default_value))
    except Exception:
        return float(default_value)

def _pb_prop_set(pb, key, value):
    try:
        pb[key] = float(value)
    except Exception:
        pass

def _pb_prop_key(pb, key, frame):
    try:
        pb.keyframe_insert(data_path = f'["{key}"]', frame = int(frame), options = {"INSERTKEY_NEEDED"})
    except Exception:
        try:
            pb.keyframe_insert(data_path = f'["{key}"]', frame = int(frame))
        except Exception:
            pass

def _unparent_eval(action, bone_name, frame, pb_default = 0.0):
    if not action:
        return float(pb_default)

    dp = _unparent_dp(bone_name)
    fcs = _fcurves_find_all(action, dp)
    if not fcs:
        return float(pb_default)

    f = int(frame)
    v_best = None

    for fc in fcs:
        last_x = None
        last_v = None

        for kp in fc.keyframe_points:
            try:
                x = int(round(float(kp.co.x)))
                y = float(kp.co.y)
            except Exception:
                continue

            if x > f:
                continue

            if last_x is None or x > int(last_x):
                last_x = int(x)
                last_v = float(y)

        v = 0.0 if last_v is None else float(last_v)

        if v_best is None or float(v) > float(v_best):
            v_best = float(v)

    return float(v_best) if v_best is not None else float(pb_default)

def _unparent_remove_pose_keys_at(action, bone_name, frame):
    if not action:
        return

    for dp in (
        _pose_dp(bone_name, "location"),
        _pose_dp(bone_name, "scale"),
        _pose_dp(bone_name, "rotation_euler"),
        _pose_dp(bone_name, "rotation_quaternion"),
        _pose_dp(bone_name, "rotation_axis_angle")
    ):
        _fcurve_remove_key_all(action, dp, int(frame))

def _arm_pose_mtx_eval(context, arm, bone_name):
    depsgraph = context.evaluated_depsgraph_get()
    eval_arm = arm.evaluated_get(depsgraph)
    pb_eval = eval_arm.pose.bones.get(bone_name)
    if not pb_eval:
        return None
    try:
        return pb_eval.matrix.copy()
    except Exception:
        return None
    
def _insert_bone_keys(pb, frame):
    frame = int(frame)
    opts = {"INSERTKEY_VISUAL"}

    pb.keyframe_insert(data_path = "location", frame = frame, options = opts)

    if pb.rotation_mode == "QUATERNION":
        pb.keyframe_insert(data_path = "rotation_quaternion", frame = frame, options = opts)
    elif pb.rotation_mode == "AXIS_ANGLE":
        pb.keyframe_insert(data_path = "rotation_axis_angle", frame = frame, options = opts)
    else:
        pb.keyframe_insert(data_path = "rotation_euler", frame = frame, options = opts)

    pb.keyframe_insert(data_path = "scale", frame = frame, options = opts)

def _rel_saved_parent(pb):
    b = pb.bone
    if REL_K_PARENT not in b:
        b[REL_K_PARENT] = pb.parent.name if pb.parent else ""
        try:
            b[REL_K_CONNECT] = 1 if bool(b.use_connect) else 0
        except Exception:
            b[REL_K_CONNECT] = 0
    return str(b.get(REL_K_PARENT, ""))

def _unparent_ensure_visual_constraint(arm, pb):
    c = pb.constraints.get(UNP_VIS_CONSTRAINT)
    if c and c.type != "LIMIT_LOCATION":
        try:
            pb.constraints.remove(c)
        except Exception:
            pass
        c = None

    if not c:
        c = pb.constraints.new("LIMIT_LOCATION")
        c.name = UNP_VIS_CONSTRAINT

    try:
        c.owner_space = "WORLD"
    except Exception:
        pass

    try:
        c.use_min_x = False
        c.use_min_y = False
        c.use_min_z = False
        c.use_max_x = False
        c.use_max_y = False
        c.use_max_z = False
    except Exception:
        pass

    try:
        c.mute = False
    except Exception:
        pass

    try:
        c.influence = 1.0
    except Exception:
        pass

    return c

def _unparent_remove_visual_constraint(pb):
    c = pb.constraints.get(UNP_VIS_CONSTRAINT)
    if not c:
        return
    try:
        pb.constraints.remove(c)
    except Exception:
        pass

def _safe_mode_set(mode):
    try:
        bpy.ops.object.mode_set(mode = mode)
        return True
    except Exception:
        return False

def _unparent_apply_relation(context, arm, bone_name, detach):
    if not arm or arm.type != "ARMATURE":
        return False

    saved_active = context.view_layer.objects.active
    saved_mode = bpy.context.mode

    try:
        try:
            context.view_layer.objects.active = arm
        except Exception:
            pass

        if not _safe_mode_set("EDIT"):
            return False

        eb = arm.data.edit_bones.get(bone_name)
        if not eb:
            return False

        b = arm.data.bones.get(bone_name)
        if not b:
            return False

        if detach:
            eb.parent = None
            try:
                eb.use_connect = False
            except Exception:
                pass
            return True

        parent_name = str(b.get(REL_K_PARENT, ""))
        try:
            connect_val = bool(int(b.get(REL_K_CONNECT, 0)))
        except Exception:
            connect_val = False

        if parent_name:
            eb.parent = arm.data.edit_bones.get(parent_name)
        else:
            eb.parent = None

        try:
            eb.use_connect = bool(connect_val)
        except Exception:
            pass

        return True

    except Exception:
        return False

    finally:
        try:
            if saved_mode.startswith("POSE"):
                _safe_mode_set("POSE")
            else:
                _safe_mode_set("OBJECT")
        except Exception:
            pass

        try:
            if saved_active:
                context.view_layer.objects.active = saved_active
        except Exception:
            pass

def _unparent_rel_get_cached(arm_name, bone_name):
    return bool(_state["unparent_rel_cache"].get(f"{arm_name}::{bone_name}", False))

def _unparent_rel_set_cached(arm_name, bone_name, detached):
    _state["unparent_rel_cache"][f"{arm_name}::{bone_name}"] = bool(detached)

def _unparent_switch_preserve_pose(context, arm, pb, detach):
    pose_m = _arm_pose_mtx_eval(context, arm, pb.name)
    if pose_m is None:
        return False

    _rel_saved_parent(pb)
    _unparent_ensure_visual_constraint(arm, pb)

    if not _unparent_apply_relation(context, arm, pb.name, detach):
        return False

    context.view_layer.update()

    try:
        pb.matrix = pose_m
    except Exception:
        pass

    context.view_layer.update()
    return True

def _capture_pose_matrices(context, arm, bone_name, frames):
    scn = context.scene
    saved_frame = int(scn.frame_current)
    mats = {}

    try:
        for f in sorted({int(x) for x in frames}):
            scn.frame_set(int(f))
            context.view_layer.update()

            depsgraph = context.evaluated_depsgraph_get()
            eval_arm = arm.evaluated_get(depsgraph)
            pb_eval = eval_arm.pose.bones.get(bone_name)
            if not pb_eval:
                continue

            mats[int(f)] = (eval_arm.matrix_world @ pb_eval.matrix).copy()

    finally:
        scn.frame_set(saved_frame)
        context.view_layer.update()

    return mats

def _unparent_start_frame(pb):
    try:
        v = pb.bone.get(UNP_STATE_KEY, None)
    except Exception:
        v = None
    if v is None:
        return None
    try:
        return int(v)
    except Exception:
        return None

def _unparent_clear_start_frame(pb):
    try:
        if UNP_STATE_KEY in pb.bone:
            del pb.bone[UNP_STATE_KEY]
    except Exception:
        pass

def _unparent_is_active_at(context, arm, pb, frame):
    action = arm.animation_data.action if arm.animation_data else None
    if not action:
        return False
    v = _unparent_eval(action, pb.name, int(frame), pb_default = 0.0)
    return float(v) >= 0.5

def _unparent_points(action, bone_name):
    if not action:
        return []

    dp = _unparent_dp(bone_name)
    merged = {}

    for fc in _fcurves_find_all(action, dp):
        for kp in fc.keyframe_points:
            try:
                fr = int(round(float(kp.co.x)))
                v = float(kp.co.y)
            except Exception:
                continue

            if fr not in merged or v > float(merged[fr]):
                merged[fr] = float(v)

    out = [(int(fr), float(v)) for fr, v in merged.items()]
    out.sort(key = lambda x: int(x[0]))
    return out

def _unparent_find_active_start_frame(action, bone_name, frame):
    if not action:
        return None

    f = int(frame)
    pts = _unparent_points(action, bone_name)
    if not pts:
        return None

    state = False
    last_start = None

    for fr, v in pts:
        if fr > f:
            break

        new_state = float(v) >= 0.5
        if new_state and not state:
            last_start = int(fr)

        state = new_state

    return int(last_start) if state and last_start is not None else None

def _unparent_find_end_frame(action, bone_name, start_frame):
    if not action:
        return None

    s = int(start_frame)
    pts = _unparent_points(action, bone_name)
    if not pts:
        return None

    for fr, v in pts:
        if int(fr) <= s:
            continue
        if float(v) < 0.5:
            return int(fr)

    return None

def _unparent_find_start_frame_fallback(action, bone_name):
    if not action:
        return None

    pts = _unparent_points(action, bone_name)
    if not pts:
        return None

    for fr, v in pts:
        if float(v) >= 0.5:
            return int(fr)

    return None

def _unparent_find_next_start_frame_from_points(action, bone_name, frame):
    if not action:
        return None

    f = int(frame)
    pts = _unparent_points(action, bone_name)
    if not pts:
        return None

    state = False

    for fr, v in pts:
        if int(fr) <= f:
            state = float(v) >= 0.5
            continue

        new_state = float(v) >= 0.5
        if new_state and not state:
            return int(fr)

        state = new_state

    return None

def _unparent_remove_window_keys_only(action, bone_name, start_f, end_f):
    if not action:
        return

    s = int(start_f)
    e = int(end_f)

    if e < s:
        s, e = e, s

    dp = _unparent_dp(bone_name)

    for fc in list(_fcurves_find_all(action, dp)):
        idxs = []

        try:
            kps = fc.keyframe_points
        except Exception:
            continue

        for i in range(len(kps)):
            try:
                fr = int(round(float(kps[i].co.x)))
            except Exception:
                continue

            if fr < s or fr > e:
                continue

            idxs.append(i)

        if not idxs:
            continue

        for i in reversed(idxs):
            try:
                fc.keyframe_points.remove(fc.keyframe_points[i])
            except RuntimeError:
                pass
            except Exception:
                pass

        try:
            if not fc.keyframe_points:
                try:
                    action.fcurves.remove(fc)
                except Exception:
                    pass
            else:
                try:
                    fc.update()
                except Exception:
                    pass
        except Exception:
            pass

def _unparent_clear_cached_start_if_matches(pb, start_frame):
    if not pb:
        return
    sf = _unparent_start_frame(pb)
    if sf is None:
        return
    if int(sf) == int(start_frame):
        _unparent_clear_start_frame(pb)

def _autokey_push(context):
    ts = getattr(getattr(context, "scene", None), "tool_settings", None)
    if not ts:
        return None

    prev_auto = getattr(ts, "use_keyframe_insert_auto", None)
    prev_ks = getattr(ts, "use_keyframe_insert_keyingset", None)

    if prev_auto is not None:
        ts.use_keyframe_insert_auto = False

    if prev_ks is not None:
        ts.use_keyframe_insert_keyingset = False

    return (prev_auto, prev_ks)

def _autokey_pop(context, prev):
    ts = getattr(getattr(context, "scene", None), "tool_settings", None)
    if not ts or prev is None:
        return

    prev_auto, prev_ks = prev

    if prev_auto is not None:
        ts.use_keyframe_insert_auto = bool(prev_auto)

    if prev_ks is not None:
        ts.use_keyframe_insert_keyingset = bool(prev_ks)

def _obj_transform_dps():
    return (
        "location",
        "scale",
        "rotation_euler",
        "rotation_quaternion",
        "rotation_axis_angle",
        "delta_location",
        "delta_scale",
        "delta_rotation_euler",
        "delta_rotation_quaternion"
    )

def _snapshot_object_keys_all(action):
    out = {}
    if not action:
        return out
    for prop in _obj_transform_dps():
        keys = set()
        for fc in _fcurves_find_all(action, prop):
            idx = int(getattr(fc, "array_index", 0))
            for kp in fc.keyframe_points:
                keys.add((prop, idx, int(round(float(kp.co.x)))))
        out[prop] = keys
    return out

def _cleanup_new_object_keys_all(action, snap):
    if not action:
        return
    for prop in _obj_transform_dps():
        before = snap.get(prop, set()) if snap else set()
        for fc in list(_fcurves_find_all(action, prop)):
            idx = int(getattr(fc, "array_index", 0))
            removed_any = False
            for kp in list(fc.keyframe_points):
                x = int(round(float(kp.co.x)))
                key_id = (prop, idx, x)
                if key_id in before:
                    continue
                fc.keyframe_points.remove(kp)
                removed_any = True
            if removed_any:
                if not fc.keyframe_points:
                    try:
                        action.fcurves.remove(fc)
                    except Exception:
                        pass
                else:
                    try:
                        fc.update()
                    except Exception:
                        pass

def _snapshot_bone_pose_keys(action, bone_name):
    out = set()
    if not action:
        return out

    for dp in (
        _pose_dp(bone_name, "location"),
        _pose_dp(bone_name, "scale"),
        _pose_dp(bone_name, "rotation_euler"),
        _pose_dp(bone_name, "rotation_quaternion"),
        _pose_dp(bone_name, "rotation_axis_angle")
    ):
        for fc in _fcurves_find_all(action, dp):
            idx = int(getattr(fc, "array_index", 0))
            for kp in fc.keyframe_points:
                out.add((dp, idx, int(round(float(kp.co.x)))))

    return out

def _set_pose_keys_vector_handles_new_only(action, bone_name, frame, snap):
    if not action:
        return

    frame = int(frame)

    for dp in (
        _pose_dp(bone_name, "location"),
        _pose_dp(bone_name, "scale"),
        _pose_dp(bone_name, "rotation_euler"),
        _pose_dp(bone_name, "rotation_quaternion"),
        _pose_dp(bone_name, "rotation_axis_angle")
    ):
        for fc in _fcurves_find_all(action, dp):
            idx = int(getattr(fc, "array_index", 0))

            if snap and (dp, idx, frame) in snap:
                continue

            kp = _fcurve_key_at(fc, frame)
            if not kp:
                continue

            try:
                kp.interpolation = "BEZIER"
            except Exception:
                pass

            try:
                kp.handle_left_type = "AUTO_CLAMPED"
                kp.handle_right_type = "AUTO_CLAMPED"
            except Exception:
                pass

            try:
                fc.update()
            except Exception:
                pass

def _unparent_has_marker_keys(action, bone_name):
    if not action:
        return False
    dp = _unparent_dp(bone_name)
    for fc in _fcurves_find_all(action, dp):
        try:
            if fc.keyframe_points and len(fc.keyframe_points) > 0:
                return True
        except Exception:
            pass
    return False

def _unparent_segment_at_frame(action, bone_name, frame):
    if not action:
        return (None, None, None, False)

    f = int(frame)
    start_f = _unparent_find_active_start_frame(action, bone_name, f)
    if start_f is None:
        return (None, None, None, False)

    start_f = int(start_f)
    end_f = _unparent_find_end_frame(action, bone_name, start_f)
    end_f = int(end_f) if end_f is not None else None

    next_start = _unparent_find_next_start_frame_from_points(action, bone_name, start_f)
    next_start = int(next_start) if next_start is not None else None

    conjoined = False
    if end_f is not None and next_start is not None:
        conjoined = int(end_f) == int(next_start) - 1

    return (start_f, end_f, next_start, bool(conjoined))


def _unparent_nearest_segment(action, bone_name, frame):
    points = _unparent_points(action, bone_name)
    if not points:
        return (None, None)

    segments = []
    active = False
    start_frame = None
    for point_frame, value in points:
        next_active = float(value) >= 0.5
        if next_active and not active:
            start_frame = int(point_frame)
        elif active and not next_active and start_frame is not None:
            segments.append((int(start_frame), int(point_frame)))
            start_frame = None
        active = next_active

    if active and start_frame is not None:
        segments.append((int(start_frame), None))
    if not segments:
        return (None, None)

    current_frame = int(frame)

    def distance(segment):
        segment_start, segment_end = segment
        effective_end = segment_end if segment_end is not None else segment_start
        if segment_end is not None and segment_start <= current_frame <= segment_end:
            return 0
        return min(
            abs(current_frame - segment_start),
            abs(current_frame - effective_end),
        )

    return min(segments, key = lambda segment: (distance(segment), segment[0]))

def _unparent_cleanup_orphans(context, arm, action):
    for pb in arm.pose.bones:
        has_vis = bool(pb.constraints.get(UNP_VIS_CONSTRAINT))
        has_prop = (UNP_PROP in pb)

        if (not has_vis) and (not has_prop) and (not _unparent_rel_get_cached(arm.name, pb.name)):
            continue

        fc = _fcurve_find(action, _unparent_dp(pb.name))
        if fc:
            continue

        saved_parent_name = str(pb.bone.get(REL_K_PARENT, ""))
        if saved_parent_name and (pb.parent is None):
            _unparent_switch_preserve_pose(context, arm, pb, False)

        _unparent_remove_visual_constraint(pb)

        if UNP_PROP in pb:
            try:
                del pb[UNP_PROP]
            except Exception:
                pass

        _unparent_rel_set_cached(arm.name, pb.name, False)
        _unparent_clear_start_frame(pb)

def _unparent_has_end_between(action, bone_name, a_frame, b_frame):
    if not action:
        return False

    dp = _unparent_dp(bone_name)
    fcs = _fcurves_find_all(action, dp)
    if not fcs:
        return False

    a = int(a_frame)
    b = int(b_frame)

    for fc in fcs:
        for kp in fc.keyframe_points:
            try:
                fr = int(round(float(kp.co.x)))
                v = float(kp.co.y)
            except Exception:
                continue
            if fr <= a or fr >= b:
                continue
            if float(v) < 0.5:
                return True

    return False

def _fcurve_prev_next_keyframes(fc, frame):
    prev_kp = None
    next_kp = None
    f = float(frame)

    for kp in fc.keyframe_points:
        x = float(kp.co.x)
        if x < f and (prev_kp is None or x > float(prev_kp.co.x)):
            prev_kp = kp
        if x > f and (next_kp is None or x < float(next_kp.co.x)):
            next_kp = kp

    return prev_kp, next_kp

def _lock_pose_key_handles(action, bone_name, frame):
    if not action:
        return

    frame = int(frame)

    for dp in (
        _pose_dp(bone_name, "location"),
        _pose_dp(bone_name, "scale"),
        _pose_dp(bone_name, "rotation_euler"),
        _pose_dp(bone_name, "rotation_quaternion"),
        _pose_dp(bone_name, "rotation_axis_angle")
    ):
        for fc in _fcurves_find_all(action, dp):
            kp = _fcurve_key_at(fc, frame)
            prev_kp, next_kp = _fcurve_prev_next_keyframes(fc, frame)

            for k in (prev_kp, kp, next_kp):
                if not k:
                    continue

                try:
                    k.interpolation = "BEZIER"
                except Exception:
                    pass

                try:
                    k.handle_left_type = "AUTO_CLAMPED"
                    k.handle_right_type = "AUTO_CLAMPED"
                except Exception:
                    pass

            try:
                fc.update()
            except Exception:
                pass

def _unparent_bake_window(context, arm, pb, start_frame, end_frame):
    scn = context.scene
    action = _ensure_object_action(arm)

    start_f = int(start_frame)
    end_f = int(end_frame)
    if end_f < start_f:
        start_f, end_f = end_f, start_f

    nxt_s = _unparent_find_next_start_frame_from_points(action, pb.name, start_f)
    
    is_abutting = False
    if nxt_s is not None:
        if int(end_f) >= int(nxt_s):
            end_f = int(nxt_s) - 1
            is_abutting = True
        elif int(end_f) == int(nxt_s) - 1:
            is_abutting = True

    obj_action = arm.animation_data.action if arm.animation_data else None
    obj_snap_all = _snapshot_object_keys_all(obj_action)

    if start_f < int(scn.frame_start) or start_f > int(scn.frame_end):
        return False

    end_f = max(int(scn.frame_start), min(int(end_f), int(scn.frame_end)))
    if end_f <= start_f:
        return False

    end_is_off = False
    if not is_abutting:
        try:
            end_is_off = _unparent_eval(action, pb.name, int(end_f), pb_default = 0.0) < 0.5
        except Exception:
            end_is_off = False

    baseline_f = int(start_f)
    bake_first = int(start_f + 1)
    bake_last = int(end_f - 1) if end_is_off else int(end_f)

    if bake_last < bake_first:
        bake_first = int(baseline_f)
        bake_last = int(baseline_f)

    snap_pose_before = _snapshot_bone_pose_keys(action, pb.name)
    had_end_plus_1 = any(int(fr) == int(end_f + 1) for _dp, _idx, fr in snap_pose_before)

    saved_frame = int(scn.frame_current)

    write_frames = {int(baseline_f)}
    if bake_last >= bake_first:
        write_frames.update(set(range(int(bake_first), int(bake_last) + 1)))
    if end_is_off:
        write_frames.add(int(end_f))

    capture_frames_list = sorted(list(write_frames))
    mats = {}

    _state["unparent_handler_mute"] = False
    
    try:
        pre_warm_f = int(capture_frames_list[0] - 1)
        if pre_warm_f >= int(scn.frame_start):
            scn.frame_set(pre_warm_f)
            context.view_layer.update()

        for f in capture_frames_list:
            scn.frame_set(int(f))
            context.view_layer.update()
            
            depsgraph = context.evaluated_depsgraph_get()
            eval_arm = arm.evaluated_get(depsgraph)
            pb_eval = eval_arm.pose.bones.get(pb.name)
            
            if pb_eval:
                try:
                    arm_mw = eval_arm.matrix_world.copy()
                    world_m = (arm_mw @ pb_eval.matrix).copy()
                    mats[int(f)] = (arm_mw, world_m)
                except Exception:
                    pass

    finally:
        try:
            scn.frame_set(int(saved_frame))
        except Exception:
            pass
        context.view_layer.update()

    if not mats:
        return False

    if end_is_off:
        last_on = int(end_f - 1)
        if int(last_on) in mats and int(end_f) in mats:
            mats[int(end_f)] = mats[int(last_on)]

    _state["unparent_handler_mute"] = True
    
    try:
        _fcurve_remove_key_all(action, _unparent_dp(pb.name), int(start_f))
        
        _unparent_remove_window_keys_only(action, pb.name, int(start_f) + 1, int(end_f))

        for fr in sorted(write_frames):
            _unparent_remove_pose_keys_at(action, pb.name, int(fr))

        context.view_layer.update()

        if not _unparent_switch_preserve_pose(context, arm, pb, False):
            return False

        _unparent_rel_set_cached(arm.name, pb.name, False)
        _unparent_remove_visual_constraint(pb)
        _unparent_clear_start_frame(pb)

        if action and (not _unparent_has_marker_keys(action, pb.name)):
            if UNP_PROP in pb:
                try:
                    del pb[UNP_PROP]
                except Exception:
                    pass

        context.view_layer.update()

        snap_pose = _snapshot_bone_pose_keys(action, pb.name)

        for fr in sorted(write_frames):
            if int(fr) not in mats:
                continue

            arm_mw, world_m = mats[int(fr)]

            scn.frame_set(int(fr))
            context.view_layer.update()

            pb2 = arm.pose.bones.get(pb.name)
            if not pb2:
                continue

            try:
                inv = arm_mw.inverted()
            except Exception:
                inv = Matrix.Identity(4)

            try:
                pb2.matrix = inv @ world_m
            except Exception:
                continue

            context.view_layer.update()
            
            _insert_bone_keys(pb2, int(fr))

            if int(fr) == int(baseline_f):
                _lock_pose_key_handles(action, pb.name, int(fr))
            elif end_is_off and int(fr) == int(end_f):
                _lock_pose_key_handles(action, pb.name, int(fr))
            else:
                _set_pose_keys_vector_handles_new_only(action, pb.name, int(fr), snap_pose)

        if (not had_end_plus_1) and int(end_f + 1) <= int(scn.frame_end):
            if not is_abutting:
                if not _unparent_is_active_at(context, arm, pb, int(end_f + 1)):
                    _unparent_remove_pose_keys_at(action, pb.name, int(end_f + 1))

        a0 = max(int(start_f), int(baseline_f - 2))
        a1 = min(int(end_f), int(baseline_f + 2))
        for lf in range(int(a0), int(a1) + 1):
            _lock_pose_key_handles(action, pb.name, int(lf))

        if bake_last >= bake_first:
            b0 = max(int(start_f), int(bake_last - 2))
            b1 = min(int(end_f), int(bake_last + 2))
            for lf in range(int(b0), int(b1) + 1):
                _lock_pose_key_handles(action, pb.name, int(lf))

        context.view_layer.update()
        _cleanup_new_object_keys_all(obj_action, obj_snap_all)

    finally:
        _state["unparent_handler_mute"] = False
        try:
            scn.frame_set(int(saved_frame))
        except Exception:
            pass
        context.view_layer.update()

    f_now = int(scn.frame_current)
    want_detached = _unparent_is_active_at(context, arm, pb, int(f_now))
    have_detached = _unparent_rel_get_cached(arm.name, pb.name)

    _state["unparent_handler_mute"] = True
    try:
        if bool(want_detached) != bool(have_detached):
            if _unparent_switch_preserve_pose(context, arm, pb, bool(want_detached)):
                _unparent_rel_set_cached(arm.name, pb.name, bool(want_detached))

        if want_detached:
            _unparent_ensure_visual_constraint(arm, pb)
        else:
            _unparent_remove_visual_constraint(pb)

    finally:
        _state["unparent_handler_mute"] = False
        context.view_layer.update()
        _cleanup_new_object_keys_all(obj_action, obj_snap_all)

    return True

def _unparent_toggle(context, arm, pb, frame):
    scn = context.scene
    action = _ensure_object_action(arm)

    f = int(frame)
    f_prev = max(0, int(f - 1))

    saved_parent_name = str(pb.bone.get(REL_K_PARENT, ""))
    if pb.parent is None and not saved_parent_name:
        return False

    _unparent_ensure_visual_constraint(arm, pb)

    v_now = _unparent_eval(action, pb.name, int(f), pb_default = _pb_prop_get(pb, UNP_PROP, 0.0))
    in_window = float(v_now) >= 0.5

    dp = _unparent_dp(pb.name)
    fc_prop = _ddm_ensure_fcurve(action, dp)

    if not in_window:
        snap_before = _snapshot_bone_pose_keys(action, pb.name)

        m_prev = _eval_pose_matrix_at_frame(context, arm, pb.name, int(f_prev))
        m_now = _eval_pose_matrix_at_frame(context, arm, pb.name, int(f))

        if m_prev is not None:
            _insert_stability_keys(context, arm, pb.name, int(f_prev), m_prev)

        _pb_prop_set(pb, UNP_PROP, 1.0)
        _ddm_insert_key(fc_prop, int(f), 1.0)

        try:
            fc_prop.update()
        except Exception:
            pass

        _unparent_inject_end_before_start(context, arm, pb, int(f))

        if _unparent_switch_preserve_pose(context, arm, pb, True):
            _unparent_rel_set_cached(arm.name, pb.name, True)

            if m_now is not None:
                _insert_stability_keys(context, arm, pb.name, int(f), m_now)

            for dp2 in (
                _pose_dp(pb.name, "location"),
                _pose_dp(pb.name, "scale"),
                _pose_dp(pb.name, "rotation_euler"),
                _pose_dp(pb.name, "rotation_quaternion"),
                _pose_dp(pb.name, "rotation_axis_angle")
            ):
                for fc in _fcurves_find_all(action, dp2):
                    idx = int(getattr(fc, "array_index", 0))

                    for src, dst in ((int(f), int(f + 1)), (int(f_prev), int(f))):
                        if (dp2, idx, int(src)) in snap_before:
                            continue
                        
                        kp_src = _fcurve_key_at(fc, int(src))
                        if not kp_src:
                            continue

                        kp_dst = _fcurve_key_at(fc, int(dst))
                        if kp_dst and (dp2, idx, int(dst)) not in snap_before:
                            try:
                                fc.keyframe_points.remove(kp_dst)
                            except Exception:
                                pass

                        try:
                            kp_src.co.x = float(dst)
                        except Exception:
                            pass

                    try:
                        fc.update()
                    except Exception:
                        pass

            return True

        return False

    snap_before = _snapshot_bone_pose_keys(action, pb.name)
    packs = _capture_pose_world_matrices_with_arm_mw(context, arm, pb.name, {int(f_prev), int(f)})
    world_prev = None
    arm_mw_f = None

    try:
        if int(f_prev) in packs:
            world_prev = packs[int(f_prev)][1]
        if int(f) in packs:
            arm_mw_f = packs[int(f)][0]
    except Exception:
        pass

    m_end_fix = None
    if world_prev is not None and arm_mw_f is not None:
        try:
            inv_f = arm_mw_f.inverted()
            m_end_fix = (inv_f @ world_prev).copy()
        except Exception:
            pass

    m_prev = _eval_pose_matrix_at_frame(context, arm, pb.name, int(f_prev))
    if m_prev is not None:
        _insert_stability_keys(context, arm, pb.name, int(f_prev), m_prev)

    _pb_prop_set(pb, UNP_PROP, 0.0)
    _ddm_insert_key(fc_prop, int(f_prev), 1.0)
    _ddm_insert_key(fc_prop, int(f), 0.0)

    try:
        fc_prop.update()
    except Exception:
        pass

    if _unparent_switch_preserve_pose(context, arm, pb, False):
        _unparent_rel_set_cached(arm.name, pb.name, False)
        if m_end_fix is None:
            m_end_fix = _eval_pose_matrix_at_frame(context, arm, pb.name, int(f))

        if m_end_fix is not None:
            _insert_stability_keys(context, arm, pb.name, int(f), m_end_fix)

        for dp2 in (
            _pose_dp(pb.name, "location"),
            _pose_dp(pb.name, "scale"),
            _pose_dp(pb.name, "rotation_euler"),
            _pose_dp(pb.name, "rotation_quaternion"),
            _pose_dp(pb.name, "rotation_axis_angle")
        ):
            for fc in _fcurves_find_all(action, dp2):
                idx = int(getattr(fc, "array_index", 0))
                for src, dst in ((int(f), int(f + 1)), (int(f_prev), int(f))):
                    if (dp2, idx, int(src)) in snap_before:
                        continue
                    kp_src = _fcurve_key_at(fc, int(src))
                    if not kp_src:
                        continue
                    kp_dst = _fcurve_key_at(fc, int(dst))
                    if kp_dst and (dp2, idx, int(dst)) not in snap_before:
                        try:
                            fc.keyframe_points.remove(kp_dst)
                        except Exception:
                            pass
                    try:
                        kp_src.co.x = float(dst)
                    except Exception:
                        pass
                try:
                    fc.update()
                except Exception:
                    pass
        return True
    return False

def _ddm_ensure_fcurve(action, data_path):
    fc = _fcurve_find(action, data_path)
    if not fc:
        fc = action.fcurves.new(data_path)
    return fc

def _ddm_insert_key(fc, frame, value):
    for kp in fc.keyframe_points:
        if abs(kp.co.x - frame) < 0.001:
            try:
                fc.keyframe_points.remove(kp)
            except:
                pass
            break
    kp = fc.keyframe_points.insert(frame, value)
    kp.interpolation = "CONSTANT"
    return kp

def _unparent_inject_end_before_start(context, arm, pb, new_start_frame):
    action = arm.animation_data.action if arm.animation_data else None
    if not action:
        return
    dp = _unparent_dp(pb.name)
    fc = _ddm_ensure_fcurve(action, dp)

    s_next = None
    sorted_pts = sorted(fc.keyframe_points, key = lambda k: k.co.x)

    for kp in sorted_pts:
        if kp.co.x > float(new_start_frame) + 0.1 and float(kp.co.y) > 0.5:
            s_next = int(round(float(kp.co.x)))
            break

    if s_next is None:
        return

    if int(s_next) <= int(new_start_frame) + 1:
        return

    mats = _capture_pose_matrices(context, arm, pb.name, {int(new_start_frame)})
    m_hold = mats.get(int(new_start_frame))
    if m_hold is None:
        return

    end_frame = int(s_next) - 1

    _unparent_remove_window_keys_only(action, pb.name, int(new_start_frame) + 1, end_frame)

    for fr in range(int(new_start_frame) + 1, end_frame + 1):
        _unparent_remove_pose_keys_at(action, pb.name, int(fr))

    snap_pose = _snapshot_bone_pose_keys(action, pb.name)
    _unparent_insert_hold_keys(context, arm, action, pb.name, end_frame, m_hold, snap_pose, allow_next = False)

    _lock_pose_key_handles(action, pb.name, end_frame)

    try:
        fc.update()
    except Exception:
        pass

def _unparent_remove_start_key(context, arm, pb, start_frame):
    action = arm.animation_data.action if arm.animation_data else None
    start_frame = int(start_frame)

    if action:
        end_key = _unparent_find_end_frame(action, pb.name, int(start_frame))
        next_start = _unparent_find_next_start_frame_from_points(action, pb.name, int(start_frame))

        conjoined = False
        if end_key is not None and next_start is not None:
            conjoined = int(end_key) == int(next_start) - 1

        dp = _unparent_dp(pb.name)

        if conjoined and end_key is not None:
            end_key = int(end_key)

            _unparent_remove_window_keys_only(action, pb.name, int(start_frame - 1), int(end_key))

            for fr in (int(start_frame - 1), int(start_frame), int(start_frame + 1)):
                _unparent_remove_pose_keys_at(action, pb.name, int(fr))

            for fr in (int(end_key - 1), int(end_key), int(end_key + 1)):
                _unparent_remove_pose_keys_at(action, pb.name, int(fr))

        else:
            for fr in (int(start_frame - 1), int(start_frame)):
                _fcurve_remove_key_all(action, dp, int(fr))

            if end_key is not None:
                end_key = int(end_key)
                for fr in (int(end_key - 1), int(end_key)):
                    _fcurve_remove_key_all(action, dp, int(fr))

            for fr in (int(start_frame - 1), int(start_frame), int(start_frame + 1)):
                _unparent_remove_pose_keys_at(action, pb.name, int(fr))

            if end_key is not None:
                for fr in (int(end_key - 1), int(end_key), int(end_key + 1)):
                    _unparent_remove_pose_keys_at(action, pb.name, int(fr))

    context.view_layer.update()

    f_now = int(context.scene.frame_current)
    want_detached = _unparent_is_active_at(context, arm, pb, int(f_now)) if action else False
    have_detached = _unparent_rel_get_cached(arm.name, pb.name)

    _state["unparent_handler_mute"] = True
    try:
        if want_detached:
            _unparent_ensure_visual_constraint(arm, pb)
        else:
            _unparent_remove_visual_constraint(pb)

        if bool(want_detached) != bool(have_detached):
            _rel_saved_parent(pb)
            world_m = _arm_pose_mtx_eval(context, arm, pb.name)

            if _unparent_apply_relation(context, arm, pb.name, bool(want_detached)):
                context.view_layer.update()

                if world_m is not None:
                    try:
                        arm_inv = arm.matrix_world.inverted()
                    except Exception:
                        arm_inv = Matrix.Identity(4)

                    pb2 = arm.pose.bones.get(pb.name)
                    if pb2:
                        try:
                            pb2.matrix = arm_inv @ world_m
                        except Exception:
                            pass
                        context.view_layer.update()

                _unparent_rel_set_cached(arm.name, pb.name, bool(want_detached))

    finally:
        _state["unparent_handler_mute"] = False
        context.view_layer.update()

    if action and (not _unparent_has_marker_keys(action, pb.name)):
        if UNP_PROP in pb:
            try:
                del pb[UNP_PROP]
            except Exception:
                pass
        _unparent_clear_start_frame(pb)
    else:
        _unparent_clear_cached_start_if_matches(pb, int(start_frame))

    return True

def _unparent_remove_end_key(context, arm, pb, end_frame):
    action = arm.animation_data.action if arm.animation_data else None
    if not action:
        return False

    scn = context.scene
    f_now = int(scn.frame_current)
    end_frame = int(end_frame)

    prev_start = _unparent_find_active_start_frame(action, pb.name, int(end_frame - 1))
    next_start = None
    if prev_start is not None:
        next_start = _unparent_find_next_start_frame_from_points(action, pb.name, int(prev_start))

    _fcurve_remove_key_all(action, _unparent_dp(pb.name), int(end_frame))
    _fcurve_remove_key_all(action, _unparent_dp(pb.name), int(end_frame - 1))

    for fr in (int(end_frame - 1), int(end_frame), int(end_frame + 1)):
        _unparent_remove_pose_keys_at(action, pb.name, int(fr))

    context.view_layer.update()

    if prev_start is not None and next_start is not None:
        if not _unparent_has_end_between(action, pb.name, int(prev_start), int(next_start)):
            _fcurve_remove_key_all(action, _unparent_dp(pb.name), int(prev_start))
            _fcurve_remove_key_all(action, _unparent_dp(pb.name), int(prev_start - 1))

            for fr in (int(prev_start - 1), int(prev_start), int(prev_start + 1)):
                _unparent_remove_pose_keys_at(action, pb.name, int(fr))

            off_f = int(next_start - 1)
            if off_f >= int(scn.frame_start) and off_f <= int(scn.frame_end):
                pb_now = arm.pose.bones.get(pb.name)
                if pb_now:
                    _pb_prop_set(pb_now, UNP_PROP, 0.0)
                    _pb_prop_key(pb_now, UNP_PROP, int(off_f))
                    _fcurve_set_constant(action, _unparent_dp(pb.name), int(off_f))

    context.view_layer.update()

    want_detached = _unparent_is_active_at(context, arm, pb, int(f_now))
    have_detached = _unparent_rel_get_cached(arm.name, pb.name)

    _state["unparent_handler_mute"] = True
    try:
        if want_detached:
            _unparent_ensure_visual_constraint(arm, pb)
        else:
            _unparent_remove_visual_constraint(pb)

        if bool(want_detached) != bool(have_detached):
            _rel_saved_parent(pb)

            world_m = _arm_pose_mtx_eval(context, arm, pb.name)

            if _unparent_apply_relation(context, arm, pb.name, bool(want_detached)):
                context.view_layer.update()

                if world_m is not None:
                    try:
                        arm_inv = arm.matrix_world.inverted()
                    except Exception:
                        arm_inv = Matrix.Identity(4)

                    pb2 = arm.pose.bones.get(pb.name)
                    if pb2:
                        try:
                            pb2.matrix = arm_inv @ world_m
                        except Exception:
                            pass
                        context.view_layer.update()

                _unparent_rel_set_cached(arm.name, pb.name, bool(want_detached))

    finally:
        _state["unparent_handler_mute"] = False
        context.view_layer.update()

    return True

def _capture_pose_world_matrices_with_arm_mw(context, arm, bone_name, frames):
    scn = context.scene
    saved_frame = int(scn.frame_current)
    mats = {}

    try:
        for f in sorted({int(x) for x in frames}):
            scn.frame_set(int(f))
            context.view_layer.update()

            depsgraph = context.evaluated_depsgraph_get()
            eval_arm = arm.evaluated_get(depsgraph)
            pb_eval = eval_arm.pose.bones.get(bone_name)
            if not pb_eval:
                continue

            try:
                arm_mw = eval_arm.matrix_world.copy()
                world_m = (arm_mw @ pb_eval.matrix).copy()
                mats[int(f)] = (arm_mw, world_m)
            except Exception:
                pass

    finally:
        scn.frame_set(saved_frame)
        context.view_layer.update()

    return mats

def _unparent_rel_scan_arm(arm):
    out = set()
    if not arm or arm.type != "ARMATURE":
        return out

    action = arm.animation_data.action if arm.animation_data else None
    if not action:
        return out

    needle = f'["{UNP_PROP}"]'

    for fc in action.fcurves:
        dp = str(getattr(fc, "data_path", ""))
        if not dp or needle not in dp:
            continue
        if not dp.startswith('pose.bones["'):
            continue

        try:
            name = dp.split('pose.bones["', 1)[1].split('"]', 1)[0]
        except Exception:
            name = ""

        if name:
            out.add(name)

    return out

def _eval_pose_matrix_at_frame(context, arm, bone_name, frame):
    scn = context.scene
    saved = int(scn.frame_current)

    try:
        scn.frame_set(int(frame))
        context.view_layer.update()

        depsgraph = context.evaluated_depsgraph_get()
        eval_arm = arm.evaluated_get(depsgraph)
        pb_eval = eval_arm.pose.bones.get(bone_name)
        if not pb_eval:
            return None

        try:
            return pb_eval.matrix.copy()
        except Exception:
            return None

    finally:
        scn.frame_set(saved)
        context.view_layer.update()

def _insert_stability_keys(context, arm, bone_name, frame, matrix_value):
    if matrix_value is None:
        return

    scn = context.scene
    saved_frame = int(scn.frame_current)
    saved_mtx = _arm_pose_mtx_eval(context, arm, bone_name)

    try:
        scn.frame_set(int(frame))
        context.view_layer.update()

        pb = arm.pose.bones.get(bone_name)
        if not pb:
            return

        try:
            pb.matrix = matrix_value
        except Exception:
            return

        context.view_layer.update()
        _insert_bone_keys(pb, int(frame))

    finally:
        scn.frame_set(saved_frame)
        context.view_layer.update()

        if saved_mtx is not None:
            pb2 = arm.pose.bones.get(bone_name)
            if pb2:
                try:
                    pb2.matrix = saved_mtx
                except Exception:
                    pass

        context.view_layer.update()

def _unparent_toggle(context, arm, pb, frame):
    scn = context.scene
    action = _ensure_object_action(arm)

    f = int(frame)
    f_prev = max(0, int(f - 1))

    saved_parent_name = str(pb.bone.get(REL_K_PARENT, ""))
    if pb.parent is None and not saved_parent_name:
        return False

    _unparent_ensure_visual_constraint(arm, pb)

    v_now = _unparent_eval(action, pb.name, int(f), pb_default = _pb_prop_get(pb, UNP_PROP, 0.0))
    in_window = float(v_now) >= 0.5

    dp = _unparent_dp(pb.name)
    fc_prop = _ddm_ensure_fcurve(action, dp)

    if not in_window:
        snap_before = _snapshot_bone_pose_keys(action, pb.name)

        m_prev = _eval_pose_matrix_at_frame(context, arm, pb.name, int(f_prev))
        m_now = _eval_pose_matrix_at_frame(context, arm, pb.name, int(f))

        if m_prev is not None:
            _insert_stability_keys(context, arm, pb.name, int(f_prev), m_prev)

        _pb_prop_set(pb, UNP_PROP, 1.0)

        _ddm_insert_key(fc_prop, int(f), 1.0)

        try:
            fc_prop.update()
        except Exception:
            pass

        _unparent_inject_end_before_start(context, arm, pb, int(f))

        if _unparent_switch_preserve_pose(context, arm, pb, True):
            _unparent_rel_set_cached(arm.name, pb.name, True)

            if m_now is not None:
                _insert_stability_keys(context, arm, pb.name, int(f), m_now)

            for dp2 in (
                _pose_dp(pb.name, "location"),
                _pose_dp(pb.name, "scale"),
                _pose_dp(pb.name, "rotation_euler"),
                _pose_dp(pb.name, "rotation_quaternion"),
                _pose_dp(pb.name, "rotation_axis_angle")
            ):
                for fc in _fcurves_find_all(action, dp2):
                    idx = int(getattr(fc, "array_index", 0))

                    for src, dst in ((int(f), int(f + 1)), (int(f_prev), int(f))):
                        if (dp2, idx, int(src)) in snap_before:
                            continue
                        if (dp2, idx, int(dst)) in snap_before:
                            continue

                        kp_src = _fcurve_key_at(fc, int(src))
                        if not kp_src:
                            continue

                        kp_dst = _fcurve_key_at(fc, int(dst))
                        if kp_dst and (dp2, idx, int(dst)) not in snap_before:
                            try:
                                fc.keyframe_points.remove(kp_dst)
                            except Exception:
                                pass

                        try:
                            kp_src.co.x = float(dst)
                        except Exception:
                            pass

                    try:
                        fc.update()
                    except Exception:
                        pass

            return True

        return False

    snap_before = _snapshot_bone_pose_keys(action, pb.name)

    packs = _capture_pose_world_matrices_with_arm_mw(context, arm, pb.name, {int(f_prev), int(f)})
    world_prev = None
    arm_mw_f = None

    try:
        if int(f_prev) in packs:
            world_prev = packs[int(f_prev)][1]
        if int(f) in packs:
            arm_mw_f = packs[int(f)][0]
    except Exception:
        world_prev = None
        arm_mw_f = None

    m_end_fix = None
    if world_prev is not None:
        if arm_mw_f is None:
            try:
                arm_mw_f = arm.matrix_world.copy()
            except Exception:
                arm_mw_f = None

        if arm_mw_f is not None:
            try:
                inv_f = arm_mw_f.inverted()
            except Exception:
                inv_f = Matrix.Identity(4)

            try:
                m_end_fix = (inv_f @ world_prev).copy()
            except Exception:
                m_end_fix = None

    m_prev = _eval_pose_matrix_at_frame(context, arm, pb.name, int(f_prev))
    m_now = _eval_pose_matrix_at_frame(context, arm, pb.name, int(f))

    if m_prev is not None:
        _insert_stability_keys(context, arm, pb.name, int(f_prev), m_prev)

    _pb_prop_set(pb, UNP_PROP, 0.0)

    _ddm_insert_key(fc_prop, int(f_prev), 1.0)
    _ddm_insert_key(fc_prop, int(f), 0.0)

    try:
        fc_prop.update()
    except Exception:
        pass

    if _unparent_switch_preserve_pose(context, arm, pb, False):
        _unparent_rel_set_cached(arm.name, pb.name, False)

        if m_end_fix is None:
            m_end_fix = m_now

        if m_end_fix is not None:
            _insert_stability_keys(context, arm, pb.name, int(f), m_end_fix)

        for dp2 in (
            _pose_dp(pb.name, "location"),
            _pose_dp(pb.name, "scale"),
            _pose_dp(pb.name, "rotation_euler"),
            _pose_dp(pb.name, "rotation_quaternion"),
            _pose_dp(pb.name, "rotation_axis_angle")
        ):
            for fc in _fcurves_find_all(action, dp2):
                idx = int(getattr(fc, "array_index", 0))

                for src, dst in ((int(f), int(f + 1)), (int(f_prev), int(f))):
                    if (dp2, idx, int(src)) in snap_before:
                        continue
                    if (dp2, idx, int(dst)) in snap_before:
                        continue

                    kp_src = _fcurve_key_at(fc, int(src))
                    if not kp_src:
                        continue

                    kp_dst = _fcurve_key_at(fc, int(dst))
                    if kp_dst and (dp2, idx, int(dst)) not in snap_before:
                        try:
                            fc.keyframe_points.remove(kp_dst)
                        except Exception:
                            pass

                    try:
                        kp_src.co.x = float(dst)
                    except Exception:
                        pass

                try:
                    fc.update()
                except Exception:
                    pass

        return True

    return False

def _unparent_cleanup_orphans(context, arm, action):
    for pb in arm.pose.bones:
        has_vis = bool(pb.constraints.get(UNP_VIS_CONSTRAINT))
        has_prop = (UNP_PROP in pb)

        if (not has_vis) and (not has_prop) and (not _unparent_rel_get_cached(arm.name, pb.name)):
            continue

        if action and _unparent_has_marker_keys(action, pb.name):
            continue

        saved_parent_name = str(pb.bone.get(REL_K_PARENT, ""))
        if saved_parent_name and (pb.parent is None):
            _unparent_switch_preserve_pose(context, arm, pb, False)

        _unparent_remove_visual_constraint(pb)

        if UNP_PROP in pb:
            try:
                del pb[UNP_PROP]
            except Exception:
                pass

        _unparent_rel_set_cached(arm.name, pb.name, False)
        _unparent_clear_start_frame(pb)

class STATICALIZA_OT_unparent_action(bpy.types.Operator):
    bl_idname = "staticaliza.unparent_action"
    bl_label = "Unparent Action"
    bl_options = {"REGISTER", "UNDO"}
    action: bpy.props.EnumProperty(
    items = (
            ("START", "Start", ""),
            ("END", "End", ""),
            ("BAKE", "Bake", ""),
            ("BAKE_TO_NEAREST", "Bake To Nearest", ""),
            ("BAKE_TO_ENDING", "Bake To End", ""),
            ("CLEAR", "Clear", ""),
            ("REMOVE_START", "Remove Start", ""),
            ("REMOVE_END", "Remove End", "")
        )
    )

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE" and bool(_selected_pose_bones_only(context))

    def execute(self, context):
        prev_autokey = _autokey_push(context)
        try:
            arm = _active_armature(context)
            if not arm:
                return {"CANCELLED"}

            bones = _selected_pose_bones_only(context)
            if not bones:
                return {"CANCELLED"}

            scn = context.scene
            f = int(scn.frame_current)
            action = arm.animation_data.action if arm.animation_data else None

            any_done = False

            if self.action in {"START", "END"}:
                for pb in bones:
                    if not pb:
                        continue

                    active_now = False
                    if action:
                        active_now = _unparent_eval(action, pb.name, int(f), pb_default = 0.0) >= 0.5

                    if self.action == "START" and (not active_now):
                        if _unparent_toggle(context, arm, pb, int(f)):
                            any_done = True

                    if self.action == "END" and active_now:
                        if _unparent_toggle(context, arm, pb, int(f)):
                            any_done = True

                context.view_layer.update()
                _tag_redraw_all_view3d()
                return {"FINISHED"} if any_done else {"CANCELLED"}

            for pb in bones:
                if not pb:
                    continue

                if self.action == "CLEAR":
                    if not action:
                        continue
                    start_frame, _end_frame = _unparent_nearest_segment(
                        action,
                        pb.name,
                        int(f),
                    )
                    if start_frame is not None and _unparent_remove_start_key(
                        context,
                        arm,
                        pb,
                        int(start_frame),
                    ):
                        any_done = True
                    continue

                active_now = _unparent_is_active_at(context, arm, pb, int(f))

                seg_start = None
                seg_end = None
                seg_next = None
                seg_conjoined = False

                if action:
                    seg_start, seg_end, seg_next, seg_conjoined = _unparent_segment_at_frame(action, pb.name, int(f))

                start_f = seg_start
                if start_f is None:
                    start_f = _unparent_start_frame(pb)
                if start_f is None and action:
                    start_f = _unparent_find_start_frame_fallback(action, pb.name)

                if self.action == "REMOVE_START":
                    if action and seg_start is not None:
                        if _unparent_remove_start_key(context, arm, pb, int(seg_start)):
                            any_done = True
                    elif start_f is not None:
                        if _unparent_remove_start_key(context, arm, pb, int(start_f)):
                            any_done = True

                elif self.action == "REMOVE_END":
                    if action and seg_start is not None:
                        end_key = _unparent_find_end_frame(action, pb.name, int(seg_start))
                        if end_key is not None:
                            if _unparent_remove_end_key(context, arm, pb, int(end_key)):
                                any_done = True

                elif self.action == "BAKE":
                    if action and seg_start is not None:
                        end_key = _unparent_find_end_frame(action, pb.name, int(seg_start))
                        if end_key is not None and int(end_key) != int(seg_start):
                            if _unparent_bake_window(context, arm, pb, int(seg_start), int(end_key)):
                                any_done = True

                elif self.action == "BAKE_TO_NEAREST":
                    if action and seg_start is not None:
                        end_key = _unparent_find_end_frame(action, pb.name, int(seg_start))

                        if end_key is not None:
                            end_f = int(end_key)
                        else:
                            end_f = int(_unparent_bake_to_end_target(context, action, pb.name, int(f)))

                        if int(end_f) != int(seg_start):
                            if _unparent_bake_window(context, arm, pb, int(seg_start), int(end_f)):
                                any_done = True

                elif self.action == "BAKE_TO_ENDING":
                    if action and seg_start is not None:
                        end_key = _unparent_find_end_frame(action, pb.name, int(seg_start))
                        
                        if end_key is not None:
                            end_f = int(end_key)
                        else:
                            end_f = int(scn.frame_end)

                        if int(end_f) != int(seg_start):
                            if _unparent_bake_window(context, arm, pb, int(seg_start), int(end_f)):
                                any_done = True

            context.view_layer.update()
            _tag_redraw_all_view3d()
            return {"FINISHED"} if any_done else {"CANCELLED"}

        finally:
            _autokey_pop(context, prev_autokey)
            
class STATICALIZA_MT_unparent_menu_inactive(bpy.types.Menu):
    bl_label = "Dynamic Unparent"

    def draw(self, context):
        layout = self.layout
        layout.operator("staticaliza.unparent_action", text = "Create Start").action = "START"
        arm = _active_armature(context)
        pb = context.active_pose_bone
        action = arm.animation_data.action if (arm and arm.animation_data) else None
        if pb and action and _unparent_has_marker_keys(action, pb.name):
            layout.operator("staticaliza.unparent_action", text = "Clear").action = "CLEAR"

class STATICALIZA_MT_unparent_menu_active(bpy.types.Menu):
    bl_label = "Dynamic Unparent Active"
    def draw(self, context):
        arm = _active_armature(context)
        pb = context.active_pose_bone
        action = arm.animation_data.action if (arm and arm.animation_data) else None
        f = int(context.scene.frame_current)
        hide_advanced = not getattr(
            context.window_manager,
            "roblox_compat_advanced_mode",
            False,
        )

        layout = self.layout

        if not arm or not pb or not action:
            layout.operator("staticaliza.unparent_action", text = "Create Start").action = "START"
            return

        start_f, end_f, next_start, conjoined = _unparent_segment_at_frame(action, pb.name, int(f))

        if start_f is None:
            layout.operator("staticaliza.unparent_action", text = "Create Start").action = "START"
            return

        if end_f is None:
            layout.operator("staticaliza.unparent_action", text = "Create End").action = "END"
            layout.operator("staticaliza.unparent_action", text = "Clear").action = "CLEAR"
            if hide_advanced:
                return
            layout.operator("staticaliza.unparent_action", text = "Remove Start").action = "REMOVE_START"
            layout.separator()

            target_near = _unparent_bake_to_end_target(context, action, pb.name, int(f))
            if int(target_near) != int(start_f):
                layout.operator("staticaliza.unparent_action", text = "Bake To Nearest").action = "BAKE_TO_NEAREST"

            target_end = int(context.scene.frame_end)
            if int(target_end) != int(start_f):
                layout.operator("staticaliza.unparent_action", text = "Bake To End").action = "BAKE_TO_ENDING"
            return

        if conjoined:
            layout.operator("staticaliza.unparent_action", text = "Clear").action = "CLEAR"
            if hide_advanced:
                return
            layout.operator("staticaliza.unparent_action", text = "Remove Start").action = "REMOVE_START"
            layout.separator()
            layout.operator("staticaliza.unparent_action", text = "Bake").action = "BAKE"
            return

        layout.operator("staticaliza.unparent_action", text = "Clear").action = "CLEAR"
        if hide_advanced:
            return
        layout.operator("staticaliza.unparent_action", text = "Remove End").action = "REMOVE_END"
        layout.operator("staticaliza.unparent_action", text = "Remove Start").action = "REMOVE_START"
        layout.separator()
        layout.operator("staticaliza.unparent_action", text = "Bake").action = "BAKE"
        
class STATICALIZA_OT_unparent_menu(bpy.types.Operator):
    bl_idname = "staticaliza.unparent_menu"
    bl_label = "Dynamic Unparent"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE" and bool(_selected_pose_bones_only(context))

    def invoke(self, context, event):
        arm = _active_armature(context)
        if not arm:
            return {"CANCELLED"}

        bones = _selected_pose_bones_only(context)
        if not bones:
            return {"CANCELLED"}

        pb = context.active_pose_bone
        if pb not in bones:
            pb = bones[0]

        action = arm.animation_data.action if arm.animation_data else None
        f = int(context.scene.frame_current)

        active_now = False
        if action:
            active_now = _unparent_eval(action, pb.name, f, pb_default = 0.0) >= 0.5

        if not active_now:
            bpy.ops.wm.call_menu(name = "STATICALIZA_MT_unparent_menu_inactive")
            return {"FINISHED"}

        bpy.ops.wm.call_menu(name = "STATICALIZA_MT_unparent_menu_active")
        return {"FINISHED"}
    
@persistent
def _unparent_frame_change_post(scene, depsgraph):
    if _state.get("unparent_handler_mute", False):
        return

    context = bpy.context
    if not context or not context.scene:
        return

    export_armature = _state.get("unparent_export_armature")
    if export_armature and getattr(export_armature, "type", None) == "ARMATURE":
        arm = export_armature
    else:
        arm = _active_armature(context)
        if not arm or context.mode != "POSE":
            return

    action = arm.animation_data.action if arm.animation_data else None
    if not action:
        for pb in arm.pose.bones:
            _unparent_remove_visual_constraint(pb)
        return

    _unparent_cleanup_orphans(context, arm, action)

    bone_names = _unparent_rel_scan_arm(arm)
    if not bone_names:
        return

    f = int(context.scene.frame_current)

    for name in bone_names:
        pb = arm.pose.bones.get(name)
        if not pb:
            continue

        want_detached = _unparent_eval(action, name, int(f), pb_default = _pb_prop_get(pb, UNP_PROP, 0.0)) >= 0.5
        have_detached = _unparent_rel_get_cached(arm.name, name)

        if want_detached:
            _unparent_ensure_visual_constraint(arm, pb)
        else:
            _unparent_remove_visual_constraint(pb)

        if bool(want_detached) == bool(have_detached):
            continue

        if _unparent_switch_preserve_pose(context, arm, pb, bool(want_detached)):
            _unparent_rel_set_cached(arm.name, name, bool(want_detached))

    _tag_redraw_all_view3d()

@persistent
def _load_post(*_):
    _state["yellow_fixed"] = {}
    _state["yellow_modes"] = {}
    _state["yellow_hidden"] = False
    _state["unparent_rel_cache"] = {}
    _state["unparent_handler_mute"] = False
    _state["unparent_export_armature"] = None
    _state["smart_material_scan_pending"] = False
    _state["roblox_compatibility_scan_pending"] = False
    _state["last_error"] = ""
    _yellow_refresh_runtime(bpy.context)
    _state["smart_material_processed_rigs"] = set()
    _state["roblox_constraints_normalized"] = set()
    _smart_material_import_scan(bpy.context.scene)

def _clear_material_input_links(node_tree, socket_names, visited = None):
    if node_tree is None:
        return 0
    if getattr(node_tree, "library", None) is not None:
        return 0

    if visited is None:
        visited = set()

    tree_id = node_tree.as_pointer()
    if tree_id in visited:
        return 0
    visited.add(tree_id)

    removed = 0

    for node in node_tree.nodes:
        for socket_name in socket_names:
            socket = node.inputs.get(socket_name)
            if not socket or not socket.is_linked:
                continue

            for link in tuple(socket.links):
                node_tree.links.remove(link)
                removed += 1

        if node.type == "GROUP" and getattr(node, "node_tree", None):
            removed += _clear_material_input_links(node.node_tree, socket_names, visited)

    return removed

def dp_clear_material_links():
    removed = 0
    visited = set()

    for material in bpy.data.materials:
        if getattr(material, "library", None) is not None:
            continue
        node_tree = getattr(material, "node_tree", None)
        if node_tree is None:
            continue
        removed += _clear_material_input_links(node_tree, {"Base Color", "Alpha"}, visited)

    return removed

def _strip_blender_numeric_suffix(name):
    base, separator, suffix = str(name).rpartition(".")
    if separator and suffix.isdigit():
        return base
    return name

def _get_smart_material_rig(collection):
    if not collection.name.startswith("RIG: "):
        return None

    rig_name = _strip_blender_numeric_suffix(collection.name[5:].strip())
    parts_collection = collection.children.get("Parts")
    if not rig_name or parts_collection is None:
        return None

    armature_name = f"__{rig_name}_Armature"
    meta_name = f"__{rig_name}Meta"
    armature = None
    meta = None

    for obj in collection.all_objects:
        obj_name = _strip_blender_numeric_suffix(obj.name)
        if obj.type == "ARMATURE" and obj_name == armature_name:
            armature = obj
        elif obj.type == "EMPTY" and obj_name == meta_name:
            meta = obj

    if armature is None or meta is None:
        return None

    return rig_name, parts_collection

def _smart_disconnect_base_color_links(node_tree, visited = None):
    if node_tree is None or getattr(node_tree, "library", None) is not None:
        return 0

    if visited is None:
        visited = set()

    tree_id = node_tree.as_pointer()
    if tree_id in visited:
        return 0
    visited.add(tree_id)

    removed = 0
    for node in node_tree.nodes:
        if node.type == "BSDF_PRINCIPLED":
            base_color = node.inputs.get("Base Color")
            normal = node.inputs.get("Normal")
            if base_color and base_color.is_linked and normal and normal.is_linked:
                for link in tuple(base_color.links):
                    node_tree.links.remove(link)
                    removed += 1

        if node.type == "GROUP" and getattr(node, "node_tree", None):
            removed += _smart_disconnect_base_color_links(node.node_tree, visited)

    return removed

def _smart_material_import_scan(scene):
    context = bpy.context
    wm = getattr(context, "window_manager", None)
    if wm is None or not getattr(wm, "smart_material_import_enabled", True):
        return

    processed = _state.setdefault("smart_material_processed_rigs", set())
    current_rigs = set()

    for collection in bpy.data.collections:
        rig = _get_smart_material_rig(collection)
        if rig is None:
            continue

        rig_name, parts_collection = rig
        rig_id = collection.as_pointer()
        current_rigs.add(rig_id)
        if rig_id in processed:
            continue

        removed = 0
        material_ids = set()
        visited_trees = set()

        for obj in parts_collection.all_objects:
            if obj.type != "MESH":
                continue
            for slot in obj.material_slots:
                material = slot.material
                if material is None or getattr(material, "library", None) is not None:
                    continue
                material_id = material.as_pointer()
                if material_id in material_ids:
                    continue
                material_ids.add(material_id)
                removed += _smart_disconnect_base_color_links(material.node_tree, visited_trees)

        processed.add(rig_id)
        if removed:
            print(f"[Smart Material Import] Removed {removed} Base Color link(s) from '{rig_name}'.")

    processed.intersection_update(current_rigs)

def _on_smart_material_import_toggle(self, context):
    _state["smart_material_processed_rigs"] = set()
    if self.smart_material_import_enabled:
        _smart_material_import_scan(context.scene)

@persistent
def _smart_material_import_depsgraph_update(scene, depsgraph):
    for update in depsgraph.updates:
        datablock = getattr(update, "id", None)
        if not isinstance(datablock, bpy.types.Object):
            continue
        if datablock.type == "ARMATURE" or (
            datablock.type == "EMPTY"
            and datablock.name.startswith("__")
            and "Meta" in datablock.name
        ):
            _schedule_smart_material_import_scan()
            return


def _run_smart_material_import_scan():
    _state["smart_material_scan_pending"] = False
    context = bpy.context
    if context and context.scene:
        _smart_material_import_scan(context.scene)
    return None


def _schedule_smart_material_import_scan(delay = 0.15):
    if _state.get("smart_material_scan_pending", False):
        return
    _state["smart_material_scan_pending"] = True
    try:
        bpy.app.timers.register(
            _run_smart_material_import_scan,
            first_interval = delay,
        )
    except Exception:
        _state["smart_material_scan_pending"] = False


RBX_RELEASE_API_URL = "https://api.github.com/repos/Cautioned/Blender-Animations-Plugin/releases/latest"
RBX_ADDON_ID = "roblox_animations_importer_exporter"
UTILS_ADDON_ID = "staticaliza_blender_animation_tools"
UTILS_PACKAGE_URL = (
    "https://raw.githubusercontent.com/Staticaliza/"
    "Staticaliza-Blender-Animation-Tools/main/src/"
    "staticaliza_blender_animation_tools.zip"
)


def _roblox_addon_module_name(refresh = False):
    try:
        modules = addon_utils.modules(refresh = refresh)
    except Exception:
        return None

    for module in modules:
        module_name = getattr(module, "__name__", "")
        if module_name == RBX_ADDON_ID or module_name.endswith(f".{RBX_ADDON_ID}"):
            return module_name
    return None


def _roblox_addon_is_enabled():
    return hasattr(bpy.types, "OBJECT_PT_RbxAnimations")


def _download_json(url):
    separator = "&" if "?" in url else "?"
    request = urllib.request.Request(
        f"{url}{separator}_staticaliza_cache_bust={time.time_ns()}",
        headers = {
            "Accept": "application/vnd.github+json",
            "Cache-Control": "no-cache, no-store, max-age=0",
            "Pragma": "no-cache",
            "User-Agent": "Staticaliza-Blender-Animation-Tools",
        },
    )
    with urllib.request.urlopen(request, timeout = 20) as response:
        return json.loads(response.read().decode("utf-8"))


def _get_roblox_release_asset():
    release = _download_json(RBX_RELEASE_API_URL)
    assets = [
        asset for asset in release.get("assets", [])
        if str(asset.get("name", "")).lower().endswith(".zip")
    ]
    if not assets:
        raise RuntimeError("The latest release has no ZIP package.")

    use_legacy = bpy.app.version < (4, 1, 0)
    preferred = [
        asset for asset in assets
        if ("legacy" in str(asset.get("name", "")).lower()) == use_legacy
    ]
    asset = preferred[0] if preferred else assets[0]
    asset_url = asset.get("browser_download_url")
    if not asset_url:
        raise RuntimeError("The release package has no download URL.")

    return release.get("tag_name", "latest"), asset.get("name", "package.zip"), asset_url


def _download_release_asset(asset_name, asset_url):
    safe_name = os.path.basename(asset_name) or "roblox_animations.zip"
    destination = os.path.join(tempfile.gettempdir(), f"staticaliza_{safe_name}")
    separator = "&" if "?" in asset_url else "?"
    request = urllib.request.Request(
        f"{asset_url}{separator}_staticaliza_cache_bust={time.time_ns()}",
        headers = {
            "Cache-Control": "no-cache, no-store, max-age=0",
            "Pragma": "no-cache",
            "User-Agent": "Staticaliza-Blender-Animation-Tools",
        },
    )

    try:
        with urllib.request.urlopen(request, timeout = 60) as response, open(destination, "wb") as output:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                output.write(chunk)

        return _prepare_roblox_addon_zip(destination)
    except Exception:
        if os.path.exists(destination):
            try:
                os.remove(destination)
            except OSError:
                pass
        raise


def _download_utils_package():
    handle, destination = tempfile.mkstemp(prefix = "staticaliza_utils_", suffix = ".zip")
    os.close(handle)
    separator = "&" if "?" in UTILS_PACKAGE_URL else "?"
    request = urllib.request.Request(
        f"{UTILS_PACKAGE_URL}{separator}_staticaliza_cache_bust={time.time_ns()}",
        headers = {
            "Cache-Control": "no-cache, no-store, max-age=0",
            "Pragma": "no-cache",
            "User-Agent": "Staticaliza-Blender-Animation-Tools",
        },
    )

    try:
        with urllib.request.urlopen(request, timeout = 60) as response, open(destination, "wb") as output:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                output.write(chunk)

        with zipfile.ZipFile(destination) as package:
            if package.testzip() is not None:
                raise RuntimeError("The downloaded Utils ZIP failed its integrity check.")
            manifest_names = [
                name for name in package.namelist()
                if name.replace("\\", "/").endswith("blender_manifest.toml")
            ]
            if not manifest_names:
                raise RuntimeError("The downloaded Utils ZIP has no Blender manifest.")
            manifest_name = min(manifest_names, key = lambda name: name.count("/"))
            manifest = tomllib.loads(package.read(manifest_name).decode("utf-8"))
            if manifest.get("id") != UTILS_ADDON_ID:
                raise RuntimeError("The downloaded ZIP is not Roblox Animator Utils.")
            version = str(manifest.get("version", "unknown"))
        return destination, version
    except Exception:
        try:
            os.remove(destination)
        except OSError:
            pass
        raise


def _extension_repository_is_locked():
    try:
        from bl_pkg import cookie_from_session
        from bl_pkg.bl_extension_utils import repo_lock_directory_query
    except ImportError:
        return False

    extensions = getattr(bpy.context.preferences, "extensions", None)
    repositories = getattr(extensions, "repos", ())
    repository = next(
        (repo for repo in repositories if repo.module == "user_default"),
        None,
    )
    if repository is None:
        return False

    return repo_lock_directory_query(
        repository.directory,
        cookie_from_session(),
    ) is not None


def _replace_manifest_display_name(data, display_name):
    text = data.decode("utf-8")
    lines = text.splitlines(keepends = True)

    for index, line in enumerate(lines):
        if not line.lstrip().startswith("name ="):
            continue
        indent = line[:len(line) - len(line.lstrip())]
        newline = "\r\n" if line.endswith("\r\n") else "\n" if line.endswith("\n") else ""
        lines[index] = f'{indent}name = "{display_name}"{newline}'
        return "".join(lines).encode("utf-8")

    raise RuntimeError("Downloaded Blender manifest has no name field.")


def _replace_bl_info_display_name(data, display_name):
    text = data.decode("utf-8")
    lines = text.splitlines(keepends = True)
    in_bl_info = False

    for index, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith("bl_info") and "{" in stripped:
            in_bl_info = True
            continue
        if not in_bl_info:
            continue
        if stripped == "}":
            break
        if not (stripped.startswith('"name"') or stripped.startswith("'name'")):
            continue

        indent = line[:len(line) - len(line.lstrip())]
        newline = "\r\n" if line.endswith("\r\n") else "\n" if line.endswith("\n") else ""
        lines[index] = f'{indent}"name": "{display_name}",{newline}'
        return "".join(lines).encode("utf-8")

    raise RuntimeError("Downloaded add-on metadata has no name field.")


def _replace_roblox_panel_display_name(data):
    text = data.decode("utf-8")
    text = text.replace(
        'bl_label = "Rbx Animations"',
        'bl_label = "Roblox Animator" + (f" (v{ADDON_VERSION_TEXT})" if ADDON_VERSION_TEXT.lower() != "unknown" else "")',
    )
    text = text.replace(
        "bl_label = 'Rbx Animations'",
        'bl_label = "Roblox Animator" + (f" (v{ADDON_VERSION_TEXT})" if ADDON_VERSION_TEXT.lower() != "unknown" else "")',
    )
    text = text.replace('"Rbx Animations"', '"Roblox Animator"')
    text = text.replace("'Rbx Animations'", "'Roblox Animator'")
    text = text.replace('text="Bake (Clipboard)"', 'text="Export"')
    text = text.replace("text='Bake (Clipboard)'", "text='Export'")
    version_block = (
        "        version_row = layout.row()\n"
        "        version_row.alignment = \"RIGHT\"\n"
        "        version_row.label(text=f\"v{ADDON_VERSION_TEXT}\")\n\n"
    )
    text = text.replace(version_block, "")
    text = text.replace(version_block.replace("\n", "\r\n"), "")
    return text.encode("utf-8")


def _replace_roblox_export_metadata(data):
    text = data.decode("utf-8")
    text = text.replace(
        'class OBJECT_OT_Bake(bpy.types.Operator):\n'
        '    bl_label = "Bake"\n'
        '    bl_idname = "object.rbxanims_bake"\n'
        '    bl_description = "Bake animation for export to clipboard"',
        'class OBJECT_OT_Bake(bpy.types.Operator):\n'
        '    bl_label = "Export"\n'
        '    bl_idname = "object.rbxanims_bake"\n'
        '    bl_description = "Export animation to clipboard"',
    )
    text = text.replace(
        'bl_description = "Bake animation for export to clipboard"',
        'bl_description = "Export animation to clipboard"',
    )
    return text.encode("utf-8")


def _prepare_roblox_addon_zip(filepath):
    repacked_path = f"{filepath}.install.zip"

    try:
        with zipfile.ZipFile(filepath) as package:
            infos = [info for info in package.infolist() if info.filename]
            normalized_names = []

            for info in infos:
                normalized = info.filename.replace("\\", "/").lstrip("/")
                parts = [part for part in normalized.split("/") if part]
                if not parts or ".." in parts:
                    raise RuntimeError("Downloaded ZIP contains an unsafe path.")
                normalized_names.append(normalized)

            if not any(name.endswith("__init__.py") for name in normalized_names):
                raise RuntimeError("Downloaded ZIP is not a Blender add-on package.")

            manifest_names = [
                name for name in normalized_names if name.endswith("blender_manifest.toml")
            ]
            if not manifest_names:
                raise RuntimeError("Downloaded ZIP has no Blender manifest.")
            manifest_name = min(manifest_names, key = lambda name: name.count("/"))
            manifest_parent = manifest_name.rsplit("/", 1)[0] if "/" in manifest_name else ""
            package_init_name = f"{manifest_parent}/__init__.py" if manifest_parent else "__init__.py"
            if package_init_name not in normalized_names:
                raise RuntimeError("Downloaded ZIP has no package __init__.py beside its manifest.")
            wrap_top_level = "__init__.py" in normalized_names

            with zipfile.ZipFile(repacked_path, "w", compression = zipfile.ZIP_DEFLATED) as output:
                for info, normalized in zip(infos, normalized_names):
                    target = f"{RBX_ADDON_ID}/{normalized}" if wrap_top_level else normalized
                    if info.is_dir():
                        output.writestr(f"{target.rstrip('/')}/", b"")
                        continue

                    data = package.read(info)
                    if normalized == manifest_name:
                        data = _replace_manifest_display_name(data, "Roblox Animator")
                    elif normalized == package_init_name:
                        data = _replace_bl_info_display_name(data, "Roblox Animator")
                    elif normalized.endswith("ui/panels.py"):
                        data = _replace_roblox_panel_display_name(data)
                    elif normalized.endswith("operators/animation_ops.py"):
                        data = _replace_roblox_export_metadata(data)
                    output.writestr(target, data)
    except Exception:
        if os.path.exists(repacked_path):
            try:
                os.remove(repacked_path)
            except OSError:
                pass
        raise

    os.remove(filepath)
    return repacked_path


def _install_roblox_addon(filepath):
    existing_module = _roblox_addon_module_name(refresh = True)
    if existing_module:
        disable = getattr(bpy.ops.preferences, "addon_disable", None)
        if disable is None:
            disable = getattr(bpy.ops.wm, "addon_disable", None)
        if disable is not None:
            try:
                disable(module = existing_module)
            except RuntimeError:
                pass

    install = getattr(bpy.ops.preferences, "addon_install", None)
    if install is None:
        install = getattr(bpy.ops.wm, "addon_install", None)
    if install is None:
        raise RuntimeError("This Blender build does not expose an add-on installer API.")

    try:
        install(overwrite = True, target = "DEFAULT", filepath = filepath)
    except TypeError:
        install(overwrite = True, filepath = filepath)

    module_name = _roblox_addon_module_name(refresh = True)
    if module_name is None:
        raise RuntimeError("Blender installed the package but could not locate its add-on module.")

    enable = getattr(bpy.ops.preferences, "addon_enable", None)
    if enable is None:
        enable = getattr(bpy.ops.wm, "addon_enable", None)
    if enable is None:
        raise RuntimeError("This Blender build does not expose an add-on enable API.")

    enable(module = module_name)
    bpy.app.timers.register(_configure_roblox_sidebar_tabs, first_interval = 0.1)


def _utils_addon_module_name(refresh = False):
    for module in addon_utils.modules(refresh = refresh):
        module_name = getattr(module, "__name__", "")
        if module_name == UTILS_ADDON_ID or module_name.endswith(f".{UTILS_ADDON_ID}"):
            return module_name
    return None


def _install_utils_addon(filepath):
    extension_ops = getattr(bpy.ops, "extensions", None)
    install = getattr(extension_ops, "package_install_files", None)
    if install is None:
        raise RuntimeError("This Blender build does not expose the extension installer API.")

    original_module_name = _utils_addon_module_name(refresh = True)
    was_enabled = bool(original_module_name and addon_utils.check(original_module_name)[1])
    if was_enabled:
        addon_utils.disable(original_module_name, default_set = True)

    try:
        try:
            result = install(
                "EXEC_DEFAULT",
                filepath = filepath,
                repo = "user_default",
                enable_on_install = True,
            )
        except TypeError:
            result = install("EXEC_DEFAULT", filepath = filepath, repo = "user_default")
        if "FINISHED" not in result:
            raise RuntimeError("Blender did not finish installing Roblox Animator Utils.")

        installed_module_name = _utils_addon_module_name(refresh = True)
        if installed_module_name is None:
            raise RuntimeError("Blender installed Utils but could not locate its module.")
        if not addon_utils.check(installed_module_name)[1]:
            try:
                addon_utils.enable(installed_module_name, default_set = True, persistent = True)
            except TypeError:
                addon_utils.enable(installed_module_name, default_set = True)
    except Exception:
        if (
            was_enabled
            and original_module_name
            and not addon_utils.check(original_module_name)[1]
        ):
            try:
                addon_utils.enable(original_module_name, default_set = True, persistent = True)
            except TypeError:
                addon_utils.enable(original_module_name, default_set = True)
        raise


def _iter_roblox_rig_armatures():
    seen = set()

    for collection in bpy.data.collections:
        if not collection.name.startswith("RIG: "):
            continue

        rig_name = _strip_blender_numeric_suffix(collection.name[5:].strip())
        if not rig_name or collection.children.get("Parts") is None:
            continue

        armature_name = f"__{rig_name}_Armature"
        meta_name = f"__{rig_name}Meta"
        armature = None
        has_meta = False

        for obj in collection.all_objects:
            obj_name = _strip_blender_numeric_suffix(obj.name)
            if obj.type == "ARMATURE" and obj_name == armature_name:
                armature = obj
            elif obj.type == "EMPTY" and obj_name == meta_name:
                has_meta = True

        if armature is not None and has_meta and armature.as_pointer() not in seen:
            seen.add(armature.as_pointer())
            yield armature


def _set_roblox_bone_visibility(armature, collection_name, predicate, hidden):
    bones = [bone for bone in armature.data.bones if predicate(bone)]
    if not bones:
        return 0

    # A bone can belong to multiple collections, so collection visibility alone
    # does not guarantee that Blender hides it in the viewport.
    for bone in bones:
        bone.hide = hidden

    try:
        bone_collections = armature.data.collections
        use_collections = True
    except Exception:
        bone_collections = None
        use_collections = False

    if use_collections:
        bone_collection = bone_collections.get(collection_name)
        if bone_collection is None:
            bone_collection = bone_collections.new(collection_name)
        for bone in bones:
            try:
                bone_collection.assign(bone)
            except RuntimeError:
                pass
        bone_collection.is_visible = not hidden
    return len(bones)


def _find_generated_roblox_armature(context, meta, previous_armatures):
    active = context.view_layer.objects.active
    if (
        active is not None
        and active.type == "ARMATURE"
        and active.as_pointer() not in previous_armatures
    ):
        return active

    settings = getattr(context.scene, "rbx_anim_settings", None)
    configured_name = getattr(settings, "rbx_anim_armature", "") if settings else ""
    configured = context.scene.objects.get(configured_name) if configured_name else None
    if (
        configured is not None
        and configured.type == "ARMATURE"
        and configured.as_pointer() not in previous_armatures
    ):
        return configured

    try:
        source_collections = tuple(meta.users_collection) if meta is not None else ()
    except ReferenceError:
        source_collections = ()

    for collection in source_collections:
        for obj in collection.all_objects:
            if obj.type == "ARMATURE" and obj.as_pointer() not in previous_armatures:
                return obj

    for obj in context.scene.objects:
        if obj.type == "ARMATURE" and obj.as_pointer() not in previous_armatures:
            return obj

    return None


def _find_roblox_parts_collection(armature):
    visited = set()
    pending = list(armature.users_collection)

    while pending:
        collection = pending.pop(0)
        pointer = collection.as_pointer()
        if pointer in visited:
            continue
        visited.add(pointer)
        if collection.name == "Parts" or collection.name.endswith("_Parts"):
            return collection
        pending.extend(collection.children)

    return None


def _normalize_roblox_part_constraints(armature):
    parts_collection = _find_roblox_parts_collection(armature)
    if parts_collection is None:
        return 0

    normalized = 0
    channel_names = (
        "use_location_x",
        "use_location_y",
        "use_location_z",
        "use_rotation_x",
        "use_rotation_y",
        "use_rotation_z",
        "use_scale_x",
        "use_scale_y",
        "use_scale_z",
    )

    for obj in parts_collection.all_objects:
        if obj.type != "MESH":
            continue

        constraints = [
            constraint for constraint in obj.constraints
            if constraint.type == "CHILD_OF" and constraint.target == armature
        ]
        if not constraints:
            continue

        valid_constraints = [
            constraint for constraint in constraints
            if constraint.subtarget and armature.data.bones.get(constraint.subtarget) is not None
        ]
        keep = valid_constraints[0] if valid_constraints else constraints[0]
        for constraint in constraints:
            if constraint is not keep:
                obj.constraints.remove(constraint)

        keep.influence = 1.0
        for channel_name in channel_names:
            if hasattr(keep, channel_name):
                setattr(keep, channel_name, True)

        bone = armature.data.bones.get(keep.subtarget)
        if bone is not None:
            bone_matrix = getattr(bone, "matrix_local", None)
            if bone_matrix is None:
                bone_matrix = bone.matrix
            if hasattr(bone_matrix, "to_4x4"):
                bone_matrix = bone_matrix.to_4x4()
            keep.inverse_matrix = (armature.matrix_world @ bone_matrix).inverted()
        normalized += 1

    return normalized


def _apply_roblox_compatibility(scene):
    if not _roblox_addon_is_enabled():
        return

    wm = getattr(bpy.context, "window_manager", None)
    if wm is None:
        return

    advanced_mode = getattr(wm, "roblox_compat_advanced_mode", False)
    hide_welds = not advanced_mode
    hide_face_bones = not advanced_mode

    for armature in _iter_roblox_rig_armatures():
        pointer = armature.as_pointer()
        if pointer not in _state["roblox_constraints_normalized"]:
            _normalize_roblox_part_constraints(armature)
            _state["roblox_constraints_normalized"].add(pointer)
        _set_roblox_bone_visibility(
            armature,
            "_StaticalizaWeldBones",
            lambda bone: bone.get("rbx_joint_type") in {"Weld", "WeldConstraint"},
            hide_welds,
        )
        _set_roblox_bone_visibility(
            armature,
            "_StaticalizaFaceBones",
            lambda bone: bool(bone.get("rbx_face_deform_bone")),
            hide_face_bones,
        )


def _on_roblox_compatibility_setting_change(self, context):
    _apply_roblox_compatibility(context.scene)
    _tag_redraw_all_view3d()


def _on_hide_advanced_panels_change(self, context):
    window_manager = getattr(context, "window_manager", None)
    if window_manager is None:
        return
    for window in window_manager.windows:
        screen = window.screen
        if screen is None:
            continue
        for area in screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


def _on_advanced_mode_change(self, context):
    _apply_roblox_compatibility(context.scene)
    _on_hide_advanced_panels_change(self, context)


@persistent
def _roblox_compatibility_depsgraph_update(scene, depsgraph):
    normalized = _state.get("roblox_constraints_normalized", set())
    for update in depsgraph.updates:
        datablock = getattr(update, "id", None)
        if not isinstance(datablock, bpy.types.Object):
            continue
        if datablock.type == "ARMATURE" and datablock.as_pointer() not in normalized:
            _schedule_roblox_compatibility_scan()
            return


def _run_roblox_compatibility_scan():
    _state["roblox_compatibility_scan_pending"] = False
    context = bpy.context
    if context and context.scene:
        _apply_roblox_compatibility(context.scene)
    return None


def _schedule_roblox_compatibility_scan(delay = 0.15):
    if _state.get("roblox_compatibility_scan_pending", False):
        return
    _state["roblox_compatibility_scan_pending"] = True
    try:
        bpy.app.timers.register(
            _run_roblox_compatibility_scan,
            first_interval = delay,
        )
    except Exception:
        _state["roblox_compatibility_scan_pending"] = False


def _show_extension_update_result(message, icon):
    window_manager = getattr(bpy.context, "window_manager", None)
    if window_manager is None:
        print(f"[Roblox Animator Utils] {message}")
        return

    def draw(self, context):
        self.layout.label(text = message)

    window_manager.popup_menu(draw, title = "Extension Update", icon = icon)


def _perform_combined_extension_update():
    roblox_filepath = None
    utils_filepath = None

    if _extension_repository_is_locked():
        _state["extension_update_lock_waits"] += 1
        if _state["extension_update_lock_waits"] <= 20:
            return 0.5

        _show_extension_update_result(
            "Update paused because the User Default repository is still locked. "
            "Wait for the current install to finish or use Force Unlock Repository.",
            "ERROR",
        )
        _state["extension_update_running"] = False
        _state["extension_update_lock_waits"] = 0
        return None

    _state["extension_update_lock_waits"] = 0

    try:
        tag, asset_name, asset_url = _get_roblox_release_asset()
        roblox_filepath = _download_release_asset(asset_name, asset_url)
        utils_filepath, utils_version = _download_utils_package()

        # Keep Roblox Animator above Utils in the N-panel category order.
        _install_roblox_addon(roblox_filepath)
        _install_utils_addon(utils_filepath)
        _show_extension_update_result(
            f"Installed Roblox Animator {tag} and Roblox Animator Utils v{utils_version}.",
            "CHECKMARK",
        )
    except Exception as exc:
        _show_extension_update_result(f"Update failed: {exc}", "ERROR")
    finally:
        for filepath in (roblox_filepath, utils_filepath):
            if filepath and os.path.exists(filepath):
                try:
                    os.remove(filepath)
                except OSError:
                    pass
        _state["extension_update_running"] = False
        _state["extension_update_lock_waits"] = 0

    return None


class STATICALIZA_OT_install_roblox_animations(bpy.types.Operator):
    bl_idname = "staticaliza.install_roblox_animations"
    bl_label = "Install Latest Extension"
    bl_description = "Install or update Roblox Animator first, then Roblox Animator Utils"
    bl_options = {"REGISTER"}

    def execute(self, context):
        if not getattr(bpy.app, "online_access", True):
            self.report({"ERROR"}, "Blender online access is disabled in Preferences.")
            return {"CANCELLED"}

        if _state["extension_update_running"]:
            self.report({"WARNING"}, "An extension update is already running.")
            return {"CANCELLED"}

        _state["extension_update_running"] = True
        _state["extension_update_lock_waits"] = 0
        try:
            bpy.app.timers.register(_perform_combined_extension_update, first_interval = 0.1)
        except Exception as exc:
            _state["extension_update_running"] = False
            self.report({"ERROR"}, f"Could not start extension update: {exc}")
            return {"CANCELLED"}

        self.report({"INFO"}, "Downloading the latest Roblox Animator and Utils releases.")
        return {"FINISHED"}


class STATICALIZA_OT_set_transform_orientation(bpy.types.Operator):
    bl_idname = "staticaliza.set_transform_orientation"
    bl_label = "Set Transform Orientation"
    bl_description = "Set or toggle the 3D View transform orientation between Global and Local"
    bl_options = {"REGISTER"}

    orientation: bpy.props.EnumProperty(
        items = (
            ("TOGGLE", "Toggle", "Toggle between Global and Local"),
            ("GLOBAL", "Global", "Use Global transform orientation"),
            ("LOCAL", "Local", "Use Local transform orientation"),
        ),
        default = "TOGGLE",
        options = {"SKIP_SAVE"},
    )

    def execute(self, context):
        slot = context.scene.transform_orientation_slots[0]
        target = self.orientation
        if target == "TOGGLE":
            target = "GLOBAL" if slot.type == "LOCAL" else "LOCAL"
        slot.type = target
        self.report({"INFO"}, f"Transform orientation: {target.title()}")
        return {"FINISHED"}


class STATICALIZA_OT_load_template(bpy.types.Operator):
    bl_idname = "staticaliza.load_template"
    bl_label = "Load Template"
    bl_description = "Replace the current Blender file with the bundled animation template"

    def draw(self, context):
        layout = self.layout
        layout.label(text = "This replaces the entire current Blender file.", icon = "ERROR")
        layout.label(text = "All unsaved changes will be permanently lost.")
        layout.separator()
        layout.label(text = "Continue and load the animation template?")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width = 440)

    def execute(self, context):
        template_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "templates",
            "generic.blend",
        )
        if not os.path.isfile(template_path):
            self.report({"ERROR"}, "The bundled animation template is missing.")
            return {"CANCELLED"}

        bpy.ops.wm.read_homefile(filepath = template_path, load_ui = True)
        return {"FINISHED"}


def _dynamic_unparent_ui_state(context):
    if context.mode != "POSE":
        return (False, False, False, False)

    arm = _active_armature(context)
    bones = _selected_pose_bones_only(context)
    if not arm or not bones:
        return (False, False, False, False)

    action = arm.animation_data.action if arm.animation_data else None
    frame = int(context.scene.frame_current)
    can_start = False
    can_end = False
    can_clear = False
    can_bake = False

    for pose_bone in bones:
        if not pose_bone:
            continue
        active = bool(
            action
            and _unparent_eval(
                action,
                pose_bone.name,
                frame,
                pb_default = 0.0,
            ) >= 0.5
        )
        has_parent = bool(
            pose_bone.parent
            or str(pose_bone.bone.get(REL_K_PARENT, ""))
        )
        has_markers = bool(action and _unparent_has_marker_keys(action, pose_bone.name))
        can_start = can_start or (has_parent and not active)
        can_end = can_end or active
        can_clear = can_clear or has_markers
        can_bake = can_bake or has_markers

    return (can_start, can_end, can_clear, can_bake)


def _dynamic_parent_target(context):
    if context.mode == "POSE":
        return context.active_pose_bone
    if context.mode == "OBJECT":
        return context.active_object
    return None


def _dynamic_parent_has_data(target):
    if target is None:
        return False
    return any(constraint.name.startswith("DP_") for constraint in target.constraints)


def _dynamic_parent_can_create(context):
    target = _dynamic_parent_target(context)
    if target is None or get_last_dynamic_parent_constraint(target) is not None:
        return False
    if context.mode == "OBJECT":
        return len(context.selected_objects) == 2
    if context.mode == "POSE":
        selected_pose_bones = context.selected_pose_bones or ()
        selected_objects = context.selected_objects or ()
        return len(selected_pose_bones) >= 2 or len(selected_objects) == 2
    return False


def _dynamic_parent_can_end(context):
    target = _dynamic_parent_target(context)
    return bool(target and get_last_dynamic_parent_constraint(target))

class VIEW3D_PT_staticaliza_roblox_animator_anchor(bpy.types.Panel):
    bl_label = "Roblox Animator"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Roblox Animator"
    bl_options = {"HIDE_HEADER"}

    @classmethod
    def poll(cls, context):
        return False

    def draw(self, context):
        pass


class VIEW3D_PT_staticaliza_main(bpy.types.Panel):
    bl_label = "Roblox Animator Utils (v" + ".".join(str(part) for part in ADDON_VERSION) + ")"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Roblox Animator Utils"

    def draw(self, context):
        wm = context.window_manager
        layout = self.layout
        advanced_mode = getattr(wm, "roblox_compat_advanced_mode", False)
        hide_advanced = not advanced_mode

        template = layout.box()
        template.label(text = "Template")
        template.operator("staticaliza.load_template", text = "Load Template")

        onion = layout.box()
        onion.label(text = "Onion Skin (F)")

        row = onion.row(align = True)
        row.prop(wm, "onion_skin_enabled", toggle = True, text = "Onion Skin")

        if advanced_mode:
            col = onion.column()
            col.prop(wm, "onion_skin_opacity", text = "Opacity")

            row2 = col.row(align = True)
            row2.prop(wm, "onion_skin_include_meshes", text = "Meshes")
            row2.prop(wm, "onion_skin_include_bones", text = "Bones")

            col.prop(wm, "onion_skin_raycast", text = "Raycast")
            col.prop(wm, "onion_skin_skip_hidden", text = "Skip Hidden")

        if _state["last_error"]:
            err = onion.box()
            err.label(text = "Last Error:")
            err.label(text = _state["last_error"])

        yellow = layout.box()
        yellow.label(text = "Onion Pin (Shift + F)")
        yellow.prop(wm, "yellow_pin_mode", text = "Position")
        rowy = yellow.row(align = True)
        rowy.operator("staticaliza.yellow_menu", text = "Onion Pin")
        yellow.operator("staticaliza.yellow_clear_all", text = "Clear")
        if advanced_mode:
            yellow.label(text = f"Pinned: {len(_state.get('yellow_modes', {}))} | Hidden: {bool(_state.get('yellow_hidden', False))}")

        dp = layout.box()
        dp.label(text = "Dynamic Parent (Alt + F)")

        rowdp = dp.row(align = True)
        parent_start = rowdp.column(align = True)
        parent_start.enabled = _dynamic_parent_can_create(context)
        parent_start.operator("dynamic_parent.create", text = "Create Start")
        parent_end = rowdp.column(align = True)
        parent_end.enabled = _dynamic_parent_can_end(context)
        parent_end.operator("dynamic_parent.disable", text = "Create End")

        if hide_advanced:
            parent_clear = dp.column(align = True)
            parent_clear.enabled = _dynamic_parent_has_data(
                _dynamic_parent_target(context)
            )
            parent_clear.operator("dynamic_parent.clear", text = "Clear")
        else:
            rowdp2 = dp.row(align = True)
            parent_clear = rowdp2.column(align = True)
            parent_clear.enabled = _dynamic_parent_has_data(
                _dynamic_parent_target(context)
            )
            parent_clear.operator("dynamic_parent.clear", text = "Clear")
            parent_bake = rowdp2.column(align = True)
            parent_bake.enabled = _dynamic_parent_has_data(
                _dynamic_parent_target(context)
            )
            parent_bake.operator("dynamic_parent.bake", text = "Bake")

        unparent = layout.box()
        unparent.label(text = "Dynamic Unparent (Alt + F)")
        can_unparent_start, can_unparent_end, can_unparent_clear, can_unparent_bake = (
            _dynamic_unparent_ui_state(context)
        )
        unparent_actions = unparent.row(align = True)
        unparent_start = unparent_actions.column(align = True)
        unparent_start.enabled = can_unparent_start
        start_operator = unparent_start.operator(
            "staticaliza.unparent_action",
            text = "Create Start",
        )
        start_operator.action = "START"
        unparent_end = unparent_actions.column(align = True)
        unparent_end.enabled = can_unparent_end
        end_operator = unparent_end.operator(
            "staticaliza.unparent_action",
            text = "Create End",
        )
        end_operator.action = "END"

        if hide_advanced:
            unparent_clear = unparent.column(align = True)
            unparent_clear.enabled = can_unparent_clear
            clear_operator = unparent_clear.operator(
                "staticaliza.unparent_action",
                text = "Clear",
            )
            clear_operator.action = "CLEAR"
        else:
            unparent_tools = unparent.row(align = True)
            unparent_clear = unparent_tools.column(align = True)
            unparent_clear.enabled = can_unparent_clear
            clear_operator = unparent_clear.operator(
                "staticaliza.unparent_action",
                text = "Clear",
            )
            clear_operator.action = "CLEAR"
            unparent_bake = unparent_tools.column(align = True)
            unparent_bake.enabled = can_unparent_bake
            bake_operator = unparent_bake.operator(
                "staticaliza.unparent_action",
                text = "Bake",
            )
            bake_operator.action = "BAKE_TO_ENDING"

        materials = layout.box()
        materials.label(text = "Materials")
        if advanced_mode:
            materials.prop(wm, "smart_material_import_enabled", text = "Smart Material Import")
        materials.operator("dynamic_parent.clear_material_links", text = "Clear")

        transform_orientation = layout.box()
        transform_orientation.label(text = "Transform Orientation (Y)")
        orientation = context.scene.transform_orientation_slots[0].type
        orientation_row = transform_orientation.row(align = True)
        global_op = orientation_row.operator(
            "staticaliza.set_transform_orientation",
            text = "Global",
            depress = orientation == "GLOBAL",
        )
        global_op.orientation = "GLOBAL"
        local_op = orientation_row.operator(
            "staticaliza.set_transform_orientation",
            text = "Local",
            depress = orientation == "LOCAL",
        )
        local_op.orientation = "LOCAL"

        roblox = layout.box()
        roblox.label(text = "Roblox Animator")
        roblox.operator("staticaliza.install_roblox_animations", text = "Install Latest Extension")
        plugin_link = roblox.operator("wm.url_open", text = "Install Roblox Plugin")
        plugin_link.url = "https://create.roblox.com/store/asset/118148792788940"
        roblox.prop(wm, "roblox_compat_advanced_mode", text = "Advanced Mode")


_ADVANCED_ROBLOX_PANEL_HEADERS = frozenset({"Roblox Account", "UGC Emote Validation"})
_FACE_ROBLOX_PANEL_HEADERS = frozenset({"Face Controls"})
_ADVANCED_ROBLOX_OPERATORS = frozenset({
    "object.rbxanims_autoconstraint",
    "object.rbxanims_manualconstraint",
    "object.rbxanims_toggle_weld_bones",
    "object.rbxanims_toggle_com",
    "object.rbxanims_toggle_com_grid",
    "object.rbxanims_edit_com_weights",
    "object.rbxanims_mapkeyframes",
    "object.rbxanims_applytransform",
    "object.rbxanims_bake_file",
    "object.rbxanims_importfbxanimation",
})
_ADVANCED_ROBLOX_PROPERTIES = frozenset({
    "rbx_auto_deform_scale",
    "rbx_deform_rig_scale",
    "rbx_full_range_bake",
})
_ADVANCED_ROBLOX_LABELS = frozenset({"Center of Mass:"})


def _roblox_operator_ui_kwargs(operator_id, kwargs):
    if operator_id != "object.rbxanims_bake":
        return kwargs
    updated = dict(kwargs)
    updated["text"] = "Export"
    return updated


class _NullOperatorProperties:
    def __setattr__(self, name, value):
        pass


class _NullUILayout:
    def __setattr__(self, name, value):
        pass

    def row(self, *args, **kwargs):
        return self

    def column(self, *args, **kwargs):
        return self

    def column_flow(self, *args, **kwargs):
        return self

    def grid_flow(self, *args, **kwargs):
        return self

    def split(self, *args, **kwargs):
        return self

    def box(self, *args, **kwargs):
        return self

    def operator(self, *args, **kwargs):
        return _NullOperatorProperties()

    def __getattr__(self, name):
        return lambda *args, **kwargs: None


_NULL_UI_LAYOUT = _NullUILayout()
_UI_CONTAINER_METHODS = frozenset({"row", "column", "column_flow", "grid_flow", "split"})


class _UILayoutProxy:
    __slots__ = ("_layout", "_hidden_headers", "_hide_advanced")

    def __init__(self, layout, hidden_headers, hide_advanced = False):
        object.__setattr__(self, "_layout", layout)
        object.__setattr__(self, "_hidden_headers", hidden_headers)
        object.__setattr__(self, "_hide_advanced", hide_advanced)

    def box(self, *args, **kwargs):
        return _LazyBoxProxy(
            self._layout,
            self._hidden_headers,
            self._hide_advanced,
            args,
            kwargs,
        )

    def label(self, *args, **kwargs):
        text = kwargs.get("text", args[0] if args else "")
        if self._hide_advanced and text in _ADVANCED_ROBLOX_LABELS:
            return None
        return self._layout.label(*args, **kwargs)

    def operator(self, *args, **kwargs):
        operator_id = args[0] if args else kwargs.get("operator", "")
        if self._hide_advanced and operator_id in _ADVANCED_ROBLOX_OPERATORS:
            return _NullOperatorProperties()
        kwargs = _roblox_operator_ui_kwargs(operator_id, kwargs)
        return self._layout.operator(*args, **kwargs)

    def prop(self, *args, **kwargs):
        property_name = args[1] if len(args) > 1 else kwargs.get("property", "")
        if self._hide_advanced and property_name in _ADVANCED_ROBLOX_PROPERTIES:
            return None
        return self._layout.prop(*args, **kwargs)

    def __getattr__(self, name):
        attribute = getattr(self._layout, name)
        if not callable(attribute) or name not in _UI_CONTAINER_METHODS:
            return attribute

        def call_container(*args, **kwargs):
            return _UILayoutProxy(
                attribute(*args, **kwargs),
                self._hidden_headers,
                self._hide_advanced,
            )

        return call_container

    def __setattr__(self, name, value):
        setattr(self._layout, name, value)


class _LazyBoxProxy:
    __slots__ = (
        "_parent_layout",
        "_hidden_headers",
        "_hide_advanced",
        "_box_args",
        "_box_kwargs",
        "_layout_proxy",
        "_suppressed",
    )

    def __init__(self, parent_layout, hidden_headers, hide_advanced, box_args, box_kwargs):
        object.__setattr__(self, "_parent_layout", parent_layout)
        object.__setattr__(self, "_hidden_headers", hidden_headers)
        object.__setattr__(self, "_hide_advanced", hide_advanced)
        object.__setattr__(self, "_box_args", box_args)
        object.__setattr__(self, "_box_kwargs", box_kwargs)
        object.__setattr__(self, "_layout_proxy", None)
        object.__setattr__(self, "_suppressed", False)

    def _materialize(self):
        if self._layout_proxy is None:
            layout = self._parent_layout.box(*self._box_args, **self._box_kwargs)
            object.__setattr__(
                self,
                "_layout_proxy",
                _UILayoutProxy(layout, self._hidden_headers, self._hide_advanced),
            )
        return self._layout_proxy

    def label(self, *args, **kwargs):
        if self._suppressed:
            return None
        text = kwargs.get("text", args[0] if args else "")
        if text in self._hidden_headers:
            object.__setattr__(self, "_suppressed", True)
            return None
        if self._hide_advanced and text in _ADVANCED_ROBLOX_LABELS:
            return None
        return self._materialize().label(*args, **kwargs)

    def __getattr__(self, name):
        if self._suppressed:
            return getattr(_NULL_UI_LAYOUT, name)
        if name in _UI_CONTAINER_METHODS:
            def call_container(*args, **kwargs):
                return _DeferredLayoutProxy(self, name, args, kwargs)

            return call_container
        return getattr(self._materialize(), name)

    def __setattr__(self, name, value):
        if not self._suppressed:
            setattr(self._materialize(), name, value)


class _DeferredLayoutProxy:
    __slots__ = ("_root", "_parent", "_method", "_args", "_kwargs", "_layout")

    def __init__(self, root, method, args, kwargs, parent = None):
        object.__setattr__(self, "_root", root)
        object.__setattr__(self, "_parent", parent)
        object.__setattr__(self, "_method", method)
        object.__setattr__(self, "_args", args)
        object.__setattr__(self, "_kwargs", kwargs)
        object.__setattr__(self, "_layout", None)

    def _materialize(self):
        if self._layout is None:
            parent_layout = self._parent._materialize() if self._parent else self._root._materialize()
            layout = getattr(parent_layout, self._method)(*self._args, **self._kwargs)
            object.__setattr__(self, "_layout", layout)
        return self._layout

    def _hide_if_needed(self, args, kwargs):
        text = kwargs.get("text", args[0] if args else "")
        if text not in self._root._hidden_headers:
            return False
        object.__setattr__(self._root, "_suppressed", True)
        return True

    def label(self, *args, **kwargs):
        if self._root._suppressed:
            return None
        if self._hide_if_needed(args, kwargs):
            return None
        text = kwargs.get("text", args[0] if args else "")
        if self._root._hide_advanced and text in _ADVANCED_ROBLOX_LABELS:
            return None
        return self._materialize().label(*args, **kwargs)

    def prop(self, *args, **kwargs):
        if self._root._suppressed:
            return None
        if self._hide_if_needed((), kwargs):
            return None
        property_name = args[1] if len(args) > 1 else kwargs.get("property", "")
        if (
            self._root._hide_advanced
            and property_name in _ADVANCED_ROBLOX_PROPERTIES
        ):
            return None
        return self._materialize().prop(*args, **kwargs)

    def operator(self, *args, **kwargs):
        if self._root._suppressed:
            return _NullOperatorProperties()
        if self._hide_if_needed(args, kwargs):
            return _NullOperatorProperties()
        operator_id = args[0] if args else kwargs.get("operator", "")
        if self._root._hide_advanced and operator_id in _ADVANCED_ROBLOX_OPERATORS:
            return _NullOperatorProperties()
        kwargs = _roblox_operator_ui_kwargs(operator_id, kwargs)
        return self._materialize().operator(*args, **kwargs)

    def __getattr__(self, name):
        if self._root._suppressed:
            return getattr(_NULL_UI_LAYOUT, name)
        if name in _UI_CONTAINER_METHODS:
            def call_container(*args, **kwargs):
                return _DeferredLayoutProxy(
                    self._root,
                    name,
                    args,
                    kwargs,
                    parent = self,
                )

            return call_container
        return getattr(self._materialize(), name)

    def __setattr__(self, name, value):
        if not self._root._suppressed:
            setattr(self._materialize(), name, value)


class _PanelDrawProxy:
    __slots__ = ("_panel", "layout")

    def __init__(self, panel, layout):
        object.__setattr__(self, "_panel", panel)
        object.__setattr__(self, "layout", layout)

    def __getattr__(self, name):
        return getattr(self._panel, name)


def _restore_roblox_advanced_panel_filter():
    patch = _state.pop("roblox_advanced_panel_patch", None)
    if patch is None:
        return

    panel_class, original_draw, patched_draw = patch
    if getattr(panel_class, "draw", None) is patched_draw:
        panel_class.draw = original_draw


def _patch_roblox_advanced_panels():
    panel_class = getattr(bpy.types, "OBJECT_PT_RbxAnimations", None)
    if panel_class is None:
        return False

    existing = _state.get("roblox_advanced_panel_patch")
    if existing is not None:
        if existing[0] is panel_class and panel_class.draw is existing[2]:
            return True
        _restore_roblox_advanced_panel_filter()

    original_draw = panel_class.draw

    def draw_with_advanced_panel_filter(self, context):
        advanced_mode = getattr(
            context.window_manager,
            "roblox_compat_advanced_mode",
            False,
        )
        hide_advanced = not advanced_mode
        hide_face_controls = not advanced_mode
        hidden_headers = set()
        if hide_advanced:
            hidden_headers.update(_ADVANCED_ROBLOX_PANEL_HEADERS)
        if hide_face_controls:
            hidden_headers.update(_FACE_ROBLOX_PANEL_HEADERS)
        if not hidden_headers:
            return original_draw(self, context)

        layout = _UILayoutProxy(
            self.layout,
            frozenset(hidden_headers),
            hide_advanced = hide_advanced,
        )
        return original_draw(_PanelDrawProxy(self, layout), context)

    draw_with_advanced_panel_filter.__name__ = original_draw.__name__
    draw_with_advanced_panel_filter.__doc__ = original_draw.__doc__
    draw_with_advanced_panel_filter.__module__ = original_draw.__module__
    draw_with_advanced_panel_filter.__qualname__ = original_draw.__qualname__

    panel_class.draw = draw_with_advanced_panel_filter
    _state["roblox_advanced_panel_patch"] = (
        panel_class,
        original_draw,
        draw_with_advanced_panel_filter,
    )
    return True


def _restore_roblox_nodes_only_default():
    invoke_patch = _state.pop("roblox_genrig_invoke_patch", None)
    if invoke_patch is not None:
        operator_class, original_invoke, patched_invoke = invoke_patch
        if getattr(operator_class, "invoke", None) is patched_invoke:
            operator_class.invoke = original_invoke

    execute_patch = _state.pop("roblox_genrig_execute_patch", None)
    if execute_patch is not None:
        operator_class, original_execute, patched_execute = execute_patch
        if getattr(operator_class, "execute", None) is patched_execute:
            operator_class.execute = original_execute


def _restore_roblox_import_patch():
    patch = _state.pop("roblox_import_execute_patch", None)
    if patch is None:
        return

    operator_class, original_execute, patched_execute = patch
    if getattr(operator_class, "execute", None) is patched_execute:
        operator_class.execute = original_execute


def _patch_roblox_import_auto_generation():
    module_name = _roblox_addon_module_name()
    if module_name is None:
        return False

    try:
        import_ops = importlib.import_module(f"{module_name}.operators.import_ops")
        rig_ops = importlib.import_module(f"{module_name}.operators.rig_ops")
        operator_class = import_ops.OBJECT_OT_ImportModel
    except (AttributeError, ImportError):
        return False

    existing = _state.get("roblox_import_execute_patch")
    if existing is not None:
        if existing[0] is operator_class and operator_class.execute is existing[2]:
            return True
        _restore_roblox_import_patch()

    original_execute = operator_class.execute

    def execute_with_local_y_auto_generation(self, context):
        hide_advanced = not getattr(
            context.window_manager,
            "roblox_compat_advanced_mode",
            False,
        )
        previous_armatures = {
            obj.as_pointer() for obj in context.scene.objects if obj.type == "ARMATURE"
        }
        previous_meta = {
            obj.as_pointer()
            for obj in context.scene.objects
            if obj.type == "EMPTY" and "RigMeta" in obj
        }

        original_create_rig = import_ops.create_rig
        if hide_advanced:
            def create_local_y_rig(_rigging_type, rig_meta_name):
                return original_create_rig("LOCAL_YAXIS_EXTEND", rig_meta_name)

            import_ops.create_rig = create_local_y_rig

        try:
            result = original_execute(self, context)
        finally:
            if hide_advanced:
                import_ops.create_rig = original_create_rig

        if "FINISHED" not in result or not hide_advanced:
            return result

        new_armatures = [
            obj
            for obj in context.scene.objects
            if obj.type == "ARMATURE" and obj.as_pointer() not in previous_armatures
        ]
        new_meta_names = [
            obj.name
            for obj in context.scene.objects
            if obj.type == "EMPTY"
            and "RigMeta" in obj
            and obj.as_pointer() not in previous_meta
        ]

        if new_armatures or not new_meta_names:
            _schedule_roblox_compatibility_scan(delay = 0.05)
            _schedule_smart_material_import_scan(delay = 0.05)
            return result

        scene_name = context.scene.name

        def generate_imported_rig():
            scene = bpy.data.scenes.get(scene_name)
            if scene is None:
                return None

            for meta_name in new_meta_names:
                meta = scene.objects.get(meta_name)
                if meta is None or "RigMeta" not in meta:
                    continue
                try:
                    rig_ops.create_rig("LOCAL_YAXIS_EXTEND", meta_name)
                except Exception as exc:
                    print(
                        f"[Roblox Animator Utils] Automatic Local Y-axis rig generation failed: {exc}"
                    )

            _schedule_roblox_compatibility_scan(delay = 0.05)
            _schedule_smart_material_import_scan(delay = 0.05)
            return None

        bpy.app.timers.register(generate_imported_rig, first_interval = 0.1)
        return result

    execute_with_local_y_auto_generation.__name__ = original_execute.__name__
    execute_with_local_y_auto_generation.__doc__ = original_execute.__doc__
    execute_with_local_y_auto_generation.__module__ = original_execute.__module__
    execute_with_local_y_auto_generation.__qualname__ = original_execute.__qualname__

    operator_class.execute = execute_with_local_y_auto_generation
    _state["roblox_import_execute_patch"] = (
        operator_class,
        original_execute,
        execute_with_local_y_auto_generation,
    )
    return True


def _restore_roblox_serializer_patch():
    patch = _state.pop("roblox_serializer_patch", None)
    if patch is None:
        return

    serialization_module, original_function, patched_function = patch
    if serialization_module.get_all_constrained_bones is patched_function:
        serialization_module.get_all_constrained_bones = original_function


def _restore_dynamic_unparent_export_metadata(saved_metadata):
    for bone, had_worldspace, worldspace_value, had_parent, parent_value in saved_metadata:
        try:
            if had_worldspace:
                bone["worldspace_bone"] = worldspace_value
            elif "worldspace_bone" in bone:
                del bone["worldspace_bone"]

            if had_parent:
                bone["worldspace_original_parent"] = parent_value
            elif "worldspace_original_parent" in bone:
                del bone["worldspace_original_parent"]
        except Exception:
            pass


def _apply_dynamic_unparent_export_metadata(armature):
    saved_metadata = []
    if not armature or armature.type != "ARMATURE":
        return saved_metadata

    for bone_name in _unparent_rel_scan_arm(armature):
        bone = armature.data.bones.get(bone_name)
        if bone is None:
            continue
        parent_name = str(bone.get(REL_K_PARENT, ""))
        if not parent_name:
            continue

        had_worldspace = "worldspace_bone" in bone
        worldspace_value = bone.get("worldspace_bone")
        had_parent = "worldspace_original_parent" in bone
        parent_value = bone.get("worldspace_original_parent")
        saved_metadata.append(
            (bone, had_worldspace, worldspace_value, had_parent, parent_value)
        )
        bone["worldspace_bone"] = True
        bone["worldspace_original_parent"] = parent_name

    return saved_metadata


def _restore_roblox_export_patch():
    patches = _state.pop("roblox_export_execute_patch", None)
    if not patches:
        return

    for operator_class, original_execute, patched_execute in patches:
        if getattr(operator_class, "execute", None) is patched_execute:
            operator_class.execute = original_execute


def _patch_roblox_export():
    module_name = _roblox_addon_module_name()
    if module_name is None:
        return False

    try:
        animation_ops = importlib.import_module(f"{module_name}.operators.animation_ops")
    except ImportError:
        return False

    operator_classes = [
        getattr(animation_ops, "OBJECT_OT_Bake", None),
        getattr(animation_ops, "OBJECT_OT_Bake_File", None),
    ]
    operator_classes = [operator_class for operator_class in operator_classes if operator_class]
    if not operator_classes:
        return False

    existing = _state.get("roblox_export_execute_patch")
    if existing and all(
        getattr(operator_class, "execute", None) is patched_execute
        for operator_class, _original_execute, patched_execute in existing
    ):
        return True
    _restore_roblox_export_patch()

    patches = []
    for operator_class in operator_classes:
        original_execute = operator_class.execute

        def make_export_execute(execute_function):
            def execute_with_dynamic_unparent(self, context):
                settings = getattr(context.scene, "rbx_anim_settings", None)
                armature_name = getattr(settings, "rbx_anim_armature", "") if settings else ""
                armature = context.scene.objects.get(armature_name) if armature_name else None
                if armature is None and armature_name:
                    armature = bpy.data.objects.get(armature_name)

                saved_frame = int(context.scene.frame_current)
                previous_export_armature = _state.get("unparent_export_armature")
                saved_metadata = _apply_dynamic_unparent_export_metadata(armature)
                _state["unparent_export_armature"] = armature

                try:
                    if armature is not None:
                        _unparent_frame_change_post(context.scene, None)
                    return execute_function(self, context)
                finally:
                    try:
                        context.scene.frame_set(saved_frame)
                        if armature is not None:
                            _unparent_frame_change_post(context.scene, None)
                    except Exception:
                        pass
                    _state["unparent_export_armature"] = previous_export_armature
                    _restore_dynamic_unparent_export_metadata(saved_metadata)
                    try:
                        context.view_layer.update()
                    except Exception:
                        pass

            execute_with_dynamic_unparent.__name__ = execute_function.__name__
            execute_with_dynamic_unparent.__doc__ = execute_function.__doc__
            execute_with_dynamic_unparent.__module__ = execute_function.__module__
            execute_with_dynamic_unparent.__qualname__ = execute_function.__qualname__
            return execute_with_dynamic_unparent

        patched_execute = make_export_execute(original_execute)
        operator_class.execute = patched_execute
        patches.append((operator_class, original_execute, patched_execute))

    _state["roblox_export_execute_patch"] = patches
    return True


def _patch_roblox_serializer():
    module_name = _roblox_addon_module_name()
    if module_name is None:
        return False

    try:
        serialization_module = importlib.import_module(
            f"{module_name}.animation.serialization"
        )
    except ImportError:
        return False

    existing = _state.get("roblox_serializer_patch")
    if existing is not None:
        if (
            existing[0] is serialization_module
            and serialization_module.get_all_constrained_bones is existing[2]
        ):
            return True
        _restore_roblox_serializer_patch()

    original_function = serialization_module.get_all_constrained_bones

    def get_all_constrained_bones_with_dynamic_unparent(armature_obj):
        constrained = set(original_function(armature_obj))
        constrained.update(_unparent_rel_scan_arm(armature_obj))
        return constrained

    get_all_constrained_bones_with_dynamic_unparent.__name__ = original_function.__name__
    get_all_constrained_bones_with_dynamic_unparent.__doc__ = original_function.__doc__
    get_all_constrained_bones_with_dynamic_unparent.__module__ = original_function.__module__
    get_all_constrained_bones_with_dynamic_unparent.__qualname__ = original_function.__qualname__

    serialization_module.get_all_constrained_bones = get_all_constrained_bones_with_dynamic_unparent
    _state["roblox_serializer_patch"] = (
        serialization_module,
        original_function,
        get_all_constrained_bones_with_dynamic_unparent,
    )
    return True


def _patch_roblox_nodes_only_default():
    module_name = _roblox_addon_module_name()
    if module_name is None:
        return False

    try:
        rig_ops = importlib.import_module(f"{module_name}.operators.rig_ops")
        operator_class = rig_ops.OBJECT_OT_GenRig
    except (AttributeError, ImportError):
        return False

    invoke_patch = _state.get("roblox_genrig_invoke_patch")
    execute_patch = _state.get("roblox_genrig_execute_patch")
    if invoke_patch is not None or execute_patch is not None:
        invoke_current = (
            invoke_patch is None
            or (invoke_patch[0] is operator_class and operator_class.invoke is invoke_patch[2])
        )
        execute_current = (
            execute_patch is not None
            and execute_patch[0] is operator_class
            and operator_class.execute is execute_patch[2]
        )
        if invoke_current and execute_current:
            return True
        _restore_roblox_nodes_only_default()

    original_execute = operator_class.execute

    def execute_with_staticaliza_compatibility(self, context):
        source = context.scene.objects.get(self.pr_rig_meta_name)
        previous_armatures = {
            obj.as_pointer() for obj in context.scene.objects if obj.type == "ARMATURE"
        }
        result = original_execute(self, context)
        if "FINISHED" not in result:
            return result

        armature = _find_generated_roblox_armature(context, source, previous_armatures)
        if armature is None:
            self.report({"WARNING"}, "Generated armature could not be located for compatibility cleanup.")
            return result

        armature_pointer = armature.as_pointer()

        def apply_after_native_constraints():
            _state["roblox_constraints_normalized"].discard(armature_pointer)
            _schedule_roblox_compatibility_scan(delay = 0.05)
            _schedule_smart_material_import_scan(delay = 0.05)
            return None

        bpy.app.timers.register(apply_after_native_constraints, first_interval = 0.1)
        return result

    execute_with_staticaliza_compatibility.__name__ = original_execute.__name__
    execute_with_staticaliza_compatibility.__doc__ = original_execute.__doc__
    execute_with_staticaliza_compatibility.__module__ = original_execute.__module__
    execute_with_staticaliza_compatibility.__qualname__ = original_execute.__qualname__

    operator_class.execute = execute_with_staticaliza_compatibility
    _state["roblox_genrig_execute_patch"] = (
        operator_class,
        original_execute,
        execute_with_staticaliza_compatibility,
    )
    return True


def _normalize_version_text(version):
    if isinstance(version, (tuple, list)):
        text = ".".join(str(part) for part in version)
    elif version is None:
        return ""
    else:
        text = str(version).strip()
    return "" if not text or text.lower() == "unknown" else text.lstrip("vV")


def _roblox_version_text(module_name):
    try:
        roblox_module = importlib.import_module(module_name)
    except ImportError:
        return ""

    bl_info_data = getattr(roblox_module, "bl_info", None)
    if isinstance(bl_info_data, dict):
        version_text = _normalize_version_text(bl_info_data.get("version"))
        if version_text:
            return version_text

    try:
        panels_module = importlib.import_module(f"{module_name}.ui.panels")
        version_text = _normalize_version_text(
            getattr(panels_module, "ADDON_VERSION_TEXT", None)
        )
        if version_text:
            return version_text
    except ImportError:
        pass

    module_file = getattr(roblox_module, "__file__", "")
    search_dir = os.path.dirname(os.path.abspath(module_file)) if module_file else ""
    for _ in range(5):
        if not search_dir:
            break
        manifest_path = os.path.join(search_dir, "blender_manifest.toml")
        try:
            with open(manifest_path, "rb") as manifest_file:
                version_text = _normalize_version_text(
                    tomllib.load(manifest_file).get("version")
                )
            if version_text:
                return version_text
        except (OSError, tomllib.TOMLDecodeError):
            pass
        parent_dir = os.path.dirname(search_dir)
        if parent_dir == search_dir:
            break
        search_dir = parent_dir

    return ""


def _configure_roblox_sidebar_tabs():
    if not _roblox_addon_is_enabled():
        return None

    _patch_roblox_nodes_only_default()
    _patch_roblox_import_auto_generation()
    _patch_roblox_advanced_panels()
    _patch_roblox_serializer()
    _patch_roblox_export()

    module_name = _roblox_addon_module_name()
    version_text = ""
    if module_name:
        try:
            roblox_module = importlib.import_module(module_name)
            if isinstance(getattr(roblox_module, "bl_info", None), dict):
                roblox_module.bl_info["name"] = "Roblox Animator"
        except ImportError:
            pass

        version_text = _roblox_version_text(module_name)

        try:
            animation_ops = importlib.import_module(f"{module_name}.operators.animation_ops")
            animation_ops.OBJECT_OT_Bake.bl_label = "Export"
            animation_ops.OBJECT_OT_Bake.bl_description = "Export animation to clipboard"
        except (AttributeError, ImportError):
            pass

    roblox_panel = getattr(bpy.types, "OBJECT_PT_RbxAnimations", None)
    if roblox_panel is not None:
        panel_label = "Roblox Animator"
        if version_text:
            panel_label += f" (v{version_text})"
        if roblox_panel.bl_label != panel_label:
            roblox_panel.bl_label = panel_label
        if roblox_panel.bl_category != "Roblox Animator":
            roblox_panel.bl_category = "Roblox Animator"

    tool_panel = getattr(bpy.types, "OBJECT_PT_RbxAnimations_Tool", None)
    if tool_panel is not None:
        tool_panel.bl_label = "Roblox Animator"
        if version_text:
            tool_panel.bl_label += f" (v{version_text})"

    return None


classes = (
    ONION_SKIN_OT_ghost_toggle,
    STATICALIZA_OT_yellow_resync_all,
    STATICALIZA_OT_yellow_clear_all,
    STATICALIZA_OT_yellow_hide_all,
    STATICALIZA_OT_yellow_show,
    STATICALIZA_OT_yellow_apply,
    STATICALIZA_MT_yellow_pin_menu,
    STATICALIZA_MT_yellow_hidden_menu,
    STATICALIZA_MT_yellow_no_selection_menu,
    STATICALIZA_OT_yellow_menu,
    STATICALIZA_OT_unparent_action,
    STATICALIZA_MT_unparent_menu_inactive,
    STATICALIZA_MT_unparent_menu_active,
    STATICALIZA_OT_unparent_menu,
    STATICALIZA_OT_install_roblox_animations,
    STATICALIZA_OT_set_transform_orientation,
    STATICALIZA_OT_load_template,
    VIEW3D_PT_staticaliza_roblox_animator_anchor,
    VIEW3D_PT_staticaliza_main
)

class DYNAMIC_PARENT_OT_menu(bpy.types.Operator):
    bl_idname = "dynamic_parent.menu"
    bl_label = "Dynamic Tools"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.mode in ("OBJECT", "POSE")

    def execute(self, context):
        bpy.ops.wm.call_menu(name = "DYNAMIC_PARENT_MT_hotkey_menu")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)

class DYNAMIC_PARENT_MT_hotkey_menu(bpy.types.Menu):
    bl_label = "Dynamic Tools"
    bl_idname = "DYNAMIC_PARENT_MT_hotkey_menu"

    def draw(self, context):
        layout = self.layout
        advanced_mode = getattr(
            context.window_manager,
            "roblox_compat_advanced_mode",
            False,
        )

        layout.label(text = "Dynamic Parent")
        layout.operator("dynamic_parent.create", text = "Create Start", icon = "KEY_HLT")
        layout.operator("dynamic_parent.disable", text = "Create End", icon = "KEY_DEHLT")
        layout.operator("dynamic_parent.clear", text = "Clear", icon = "X")
        if advanced_mode:
            layout.operator("dynamic_parent.bake", text = "Bake", icon = "REC")

        layout.separator()
        layout.label(text = "Dynamic Unparent")
        can_start, can_end, can_clear, can_bake = _dynamic_unparent_ui_state(context)

        start_row = layout.row()
        start_row.enabled = can_start
        start_operator = start_row.operator(
            "staticaliza.unparent_action",
            text = "Create Start",
            icon = "KEY_HLT",
        )
        start_operator.action = "START"

        end_row = layout.row()
        end_row.enabled = can_end
        end_operator = end_row.operator(
            "staticaliza.unparent_action",
            text = "Create End",
            icon = "KEY_DEHLT",
        )
        end_operator.action = "END"

        clear_row = layout.row()
        clear_row.enabled = can_clear
        clear_operator = clear_row.operator(
            "staticaliza.unparent_action",
            text = "Clear",
            icon = "X",
        )
        clear_operator.action = "CLEAR"

        if advanced_mode:
            bake_row = layout.row()
            bake_row.enabled = can_bake
            bake_operator = bake_row.operator(
                "staticaliza.unparent_action",
                text = "Bake",
                icon = "REC",
            )
            bake_operator.action = "BAKE_TO_ENDING"

class DYNAMIC_PARENT_OT_create(bpy.types.Operator):
    bl_idname = "dynamic_parent.create"
    bl_label = "Create Constraint"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _dynamic_parent_can_create(context)

    def execute(self, context):
        obj = context.active_object
        frame = context.scene.frame_current

        if obj.type == "ARMATURE":
            if obj.mode != "POSE":
                self.report({"ERROR"}, "Armature objects must be in Pose mode.")
                return {"CANCELLED"}
            obj = bpy.context.active_pose_bone
            const = get_last_dynamic_parent_constraint(obj)
            if const:
                disable_constraint(obj, const, frame)
            dp_create_dynamic_parent_pbone(self)
        else:
            const = get_last_dynamic_parent_constraint(obj)
            if const:
                disable_constraint(obj, const, frame)
            dp_create_dynamic_parent_obj(self)

        return {"FINISHED"}

class DYNAMIC_PARENT_OT_disable(bpy.types.Operator):
    bl_idname = "dynamic_parent.disable"
    bl_label = "Disable Constraint"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _dynamic_parent_can_end(context)

    def execute(self, context):
        frame = context.scene.frame_current
        objects = get_selected_objects(context)
        counter = 0

        if not objects:
            self.report({"ERROR"}, "Nothing selected.")
            return {"CANCELLED"}

        for obj in objects:
            const = get_last_dynamic_parent_constraint(obj)
            if const is None:
                continue
            disable_constraint(obj, const, frame)
            counter += 1

        self.report({"INFO"}, f"{counter} constraints were disabled.")
        return {"FINISHED"}

class DYNAMIC_PARENT_OT_clear(bpy.types.Operator):
    bl_idname = "dynamic_parent.clear"
    bl_label = "Clear Dynamic Parent"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _dynamic_parent_has_data(_dynamic_parent_target(context))

    def execute(self, context):
        pbone = None
        obj = bpy.context.active_object
        if obj.type == "ARMATURE":
            pbone = bpy.context.active_pose_bone

        dp_clear(obj, pbone)

        return {"FINISHED"}

class DYNAMIC_PARENT_OT_bake(bpy.types.Operator):
    bl_idname = "dynamic_parent.bake"
    bl_label = "Bake Dynamic Parent"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _dynamic_parent_has_data(_dynamic_parent_target(context))

    def execute(self, context):
        obj = bpy.context.active_object
        scn = bpy.context.scene

        if obj.type == "ARMATURE":
            obj = bpy.context.active_pose_bone
            bpy.ops.nla.bake(
                frame_start = scn.frame_start,
                frame_end = scn.frame_end,
                step = 1,
                only_selected = True,
                visual_keying = True,
                clear_constraints = False,
                clear_parents = False,
                bake_types = {"POSE"},
            )
            for const in obj.constraints[:]:
                if const.name.startswith("DP_"):
                    obj.constraints.remove(const)
        else:
            bpy.ops.nla.bake(
                frame_start = scn.frame_start,
                frame_end = scn.frame_end,
                step = 1,
                only_selected = True,
                visual_keying = True,
                clear_constraints = False,
                clear_parents = False,
                bake_types = {"OBJECT"},
            )
            for const in obj.constraints[:]:
                if const.name.startswith("DP_"):
                    obj.constraints.remove(const)

        return {"FINISHED"}

class DYNAMIC_PARENT_OT_clear_material_links(bpy.types.Operator):
    bl_idname = "dynamic_parent.clear_material_links"
    bl_label = "Clear Material Links"
    bl_description = "Disconnect Base Color and Alpha links for all materials in the current file"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        removed = dp_clear_material_links()

        if removed:
            self.report({"INFO"}, f"Removed {removed} Base Color/Alpha link(s).")
        else:
            self.report({"INFO"}, "No Base Color or Alpha links were connected.")

        return {"FINISHED"}

class DYNAMIC_PARENT_MT_clear_menu(bpy.types.Menu):
    bl_label = "Clear Dynamic Parent?"
    bl_idname = "DYNAMIC_PARENT_MT_clear_menu"

    def draw(self, context):
        layout = self.layout
        layout.operator("dynamic_parent.clear", text = "Clear", icon = "X")
        layout.operator("dynamic_parent.bake", text = "Bake and clear", icon = "REC")

class DYNAMIC_PARENT_PT_ui(bpy.types.Panel):
    bl_label = "Dynamic Parent {}.{}.{}".format(*DP_BL_INFO["version"])
    bl_idname = "DYNAMIC_PARENT_PT_ui"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Dynamic Parent"

    def draw(self, context):
        layout = self.layout
        col = layout.column(align = True)
        col.operator("dynamic_parent.create", text = "Create", icon = "KEY_HLT")
        col.operator("dynamic_parent.disable", text = "Disable", icon = "KEY_DEHLT")
        col.menu("DYNAMIC_PARENT_MT_clear_menu", text = "Clear")

        layout.separator()
        layout.label(text = "Materials")
        layout.operator("dynamic_parent.clear_material_links", text = "Clear")

def _dp_register():
    for c in (
        DYNAMIC_PARENT_OT_menu,
        DYNAMIC_PARENT_MT_hotkey_menu,
        DYNAMIC_PARENT_OT_create,
        DYNAMIC_PARENT_OT_disable,
        DYNAMIC_PARENT_OT_clear,
        DYNAMIC_PARENT_OT_bake,
        DYNAMIC_PARENT_OT_clear_material_links,
        DYNAMIC_PARENT_MT_clear_menu,
    ):
        try:
            bpy.utils.register_class(c)
        except Exception:
            pass

def _dp_unregister():
    for c in reversed((
        DYNAMIC_PARENT_OT_menu,
        DYNAMIC_PARENT_MT_hotkey_menu,
        DYNAMIC_PARENT_OT_create,
        DYNAMIC_PARENT_OT_disable,
        DYNAMIC_PARENT_OT_clear,
        DYNAMIC_PARENT_OT_bake,
        DYNAMIC_PARENT_OT_clear_material_links,
        DYNAMIC_PARENT_MT_clear_menu,
    )):
        try:
            bpy.utils.unregister_class(c)
        except Exception:
            pass

def register():
    for name in (
        "onion_skin_enabled",
        "onion_skin_opacity",
        "onion_skin_include_meshes",
        "onion_skin_include_bones",
        "onion_skin_raycast",
        "onion_skin_skip_hidden"
    ):
        if hasattr(bpy.types.Scene, name):
            delattr(bpy.types.Scene, name)

    if hasattr(bpy.types.WindowManager, "smart_material_import_enabled"):
        delattr(bpy.types.WindowManager, "smart_material_import_enabled")
    if hasattr(bpy.types.WindowManager, "yellow_pin_mode"):
        delattr(bpy.types.WindowManager, "yellow_pin_mode")
    for name in (
        "roblox_compat_hide_weld_bones",
        "roblox_compat_hide_face_bones",
        "roblox_compat_hide_advanced_panels",
        "roblox_compat_advanced_mode",
    ):
        if hasattr(bpy.types.WindowManager, name):
            delattr(bpy.types.WindowManager, name)

    bpy.types.WindowManager.onion_skin_enabled = bpy.props.BoolProperty(
        name = "Ghost",
        default = False,
        options = {"SKIP_SAVE"},
        update = _on_enabled_toggle
    )
    bpy.types.WindowManager.onion_skin_opacity = bpy.props.FloatProperty(
        name = "Opacity",
        default = 0.10,
        min = 0.001,
        max = 1.0,
        update = _on_setting_change
    )
    bpy.types.WindowManager.onion_skin_include_meshes = bpy.props.BoolProperty(
        name = "Meshes",
        default = True,
        update = _on_setting_change
    )
    bpy.types.WindowManager.onion_skin_include_bones = bpy.props.BoolProperty(
        name = "Bones",
        default = False,
        update = _on_setting_change
    )
    bpy.types.WindowManager.onion_skin_raycast = bpy.props.BoolProperty(
        name = "Raycast",
        default = True,
        update = _on_setting_change
    )
    bpy.types.WindowManager.onion_skin_skip_hidden = bpy.props.BoolProperty(
        name = "Skip Hidden",
        default = True,
        update = _on_setting_change
    )
    bpy.types.WindowManager.smart_material_import_enabled = bpy.props.BoolProperty(
        name = "Smart Material Import",
        description = "Automatically remove Base Color links from imported rig parts that also use a Normal link",
        default = True,
        update = _on_smart_material_import_toggle
    )
    bpy.types.WindowManager.yellow_pin_mode = bpy.props.EnumProperty(
        name = "Pin Position",
        description = "Choose where new and updated pins are placed",
        items = (
            ("MODE_3", "Smart", "Use the bottom center of the bone's visible geometry"),
            ("MODE_1", "Bone End", "Use the bone tail"),
            ("MODE_2", "Bone Center", "Use the center of the weighted geometry"),
        ),
        default = "MODE_3",
    )
    bpy.types.WindowManager.roblox_compat_advanced_mode = bpy.props.BoolProperty(
        name = "Advanced Mode",
        description = "Show advanced Roblox Animator panels, weld bones, face bones, and detailed Utils controls",
        default = False,
        update = _on_advanced_mode_change
    )

    for c in classes:
        bpy.utils.register_class(c)

    _dp_register()

    _state["yellow_fixed"] = {}
    _state["yellow_modes"] = {}
    _state["yellow_hidden"] = False
    _state["unparent_rel_cache"] = {}
    _state["unparent_handler_mute"] = False
    _state["last_error"] = ""
    _state["smart_material_processed_rigs"] = set()
    _state["extension_update_lock_waits"] = 0
    _state["roblox_constraints_normalized"] = set()
    _state["unparent_export_armature"] = None
    _state["smart_material_scan_pending"] = False
    _state["roblox_compatibility_scan_pending"] = False

    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon if wm and wm.keyconfigs else None
    if kc:
        km = kc.keymaps.new(name = "Pose", space_type = "EMPTY", region_type = "WINDOW")
        _keymaps.append((km, km.keymap_items.new("onion_skin.ghost_toggle", type = "F", value = "PRESS")))
        _keymaps.append((km, km.keymap_items.new("staticaliza.yellow_menu", type = "F", value = "PRESS", shift = True)))
        _keymaps.append((km, km.keymap_items.new("dynamic_parent.menu", type = "F", value = "PRESS", alt = True)))
        _keymaps.append((km, km.keymap_items.new("staticaliza.set_transform_orientation", type = "Y", value = "PRESS")))

        km = kc.keymaps.new(name = "Object Mode", space_type = "EMPTY", region_type = "WINDOW")
        _keymaps.append((km, km.keymap_items.new("dynamic_parent.menu", type = "F", value = "PRESS", alt = True)))
        _keymaps.append((km, km.keymap_items.new("staticaliza.set_transform_orientation", type = "Y", value = "PRESS")))

        km = kc.keymaps.new(name = "3D View", space_type = "VIEW_3D", region_type = "WINDOW")
        _keymaps.append((km, km.keymap_items.new("onion_skin.ghost_toggle", type = "F", value = "PRESS")))
        _keymaps.append((km, km.keymap_items.new("staticaliza.yellow_menu", type = "F", value = "PRESS", shift = True)))
        _keymaps.append((km, km.keymap_items.new("dynamic_parent.menu", type = "F", value = "PRESS", alt = True)))

        km = kc.keymaps.new(name = "Dopesheet Generic", space_type = "DOPESHEET_EDITOR", region_type = "WINDOW")
        _keymaps.append((km, km.keymap_items.new("onion_skin.ghost_toggle", type = "F", value = "PRESS")))
        _keymaps.append((km, km.keymap_items.new("staticaliza.yellow_menu", type = "F", value = "PRESS", shift = True)))
        _keymaps.append((km, km.keymap_items.new("dynamic_parent.menu", type = "F", value = "PRESS", alt = True)))

        km = kc.keymaps.new(name = "Graph Editor", space_type = "GRAPH_EDITOR", region_type = "WINDOW")
        _keymaps.append((km, km.keymap_items.new("onion_skin.ghost_toggle", type = "F", value = "PRESS")))
        _keymaps.append((km, km.keymap_items.new("staticaliza.yellow_menu", type = "F", value = "PRESS", shift = True)))
        _keymaps.append((km, km.keymap_items.new("dynamic_parent.menu", type = "F", value = "PRESS", alt = True)))

    for h in list(bpy.app.handlers.frame_change_post):
        if getattr(h, "__name__", "") == "_unparent_frame_change_post":
            bpy.app.handlers.frame_change_post.remove(h)
    bpy.app.handlers.frame_change_post.append(_unparent_frame_change_post)

    for h in list(bpy.app.handlers.load_post):
        if getattr(h, "__name__", "") == "_load_post":
            bpy.app.handlers.load_post.remove(h)
    bpy.app.handlers.load_post.append(_load_post)

    for h in list(bpy.app.handlers.depsgraph_update_post):
        if getattr(h, "__name__", "") == "_smart_material_import_depsgraph_update":
            bpy.app.handlers.depsgraph_update_post.remove(h)
    bpy.app.handlers.depsgraph_update_post.append(_smart_material_import_depsgraph_update)

    for h in list(bpy.app.handlers.depsgraph_update_post):
        if getattr(h, "__name__", "") == "_roblox_compatibility_depsgraph_update":
            bpy.app.handlers.depsgraph_update_post.remove(h)
    bpy.app.handlers.depsgraph_update_post.append(_roblox_compatibility_depsgraph_update)

    bpy.app.timers.register(lambda: (_yellow_refresh_runtime(bpy.context), None)[1], first_interval = 0.1)
    bpy.app.timers.register(lambda: (_smart_material_import_scan(bpy.context.scene), None)[1], first_interval = 0.2)
    bpy.app.timers.register(lambda: (_apply_roblox_compatibility(bpy.context.scene), None)[1], first_interval = 0.3)
    bpy.app.timers.register(_configure_roblox_sidebar_tabs, first_interval = 0.5)

def unregister():
    for km, kmi in _keymaps:
        try:
            km.keymap_items.remove(kmi)
        except Exception:
            pass
    _keymaps.clear()
    _restore_roblox_nodes_only_default()
    _restore_roblox_import_patch()
    _restore_roblox_advanced_panel_filter()
    _restore_roblox_serializer_patch()
    _restore_roblox_export_patch()

    for timer_function in (
        _run_smart_material_import_scan,
        _run_roblox_compatibility_scan,
    ):
        try:
            if bpy.app.timers.is_registered(timer_function):
                bpy.app.timers.unregister(timer_function)
        except Exception:
            pass

    try:
        if bpy.context and bpy.context.window_manager:
            bpy.context.window_manager.onion_skin_enabled = False
    except Exception:
        pass

    try:
        for h in list(bpy.app.handlers.frame_change_post):
            if getattr(h, "__name__", "") == "_unparent_frame_change_post":
                bpy.app.handlers.frame_change_post.remove(h)

        for h in list(bpy.app.handlers.load_post):
            if getattr(h, "__name__", "") == "_load_post":
                bpy.app.handlers.load_post.remove(h)

        for h in list(bpy.app.handlers.depsgraph_update_post):
            if getattr(h, "__name__", "") == "_smart_material_import_depsgraph_update":
                bpy.app.handlers.depsgraph_update_post.remove(h)
            if getattr(h, "__name__", "") == "_roblox_compatibility_depsgraph_update":
                bpy.app.handlers.depsgraph_update_post.remove(h)
    except Exception:
        pass

    _disable_runtime()

    _dp_unregister()

    for c in reversed(classes):
        bpy.utils.unregister_class(c)

    for name in (
        "onion_skin_enabled",
        "onion_skin_opacity",
        "onion_skin_include_meshes",
        "onion_skin_include_bones",
        "onion_skin_raycast",
        "onion_skin_skip_hidden",
        "smart_material_import_enabled",
        "yellow_pin_mode",
        "roblox_compat_advanced_mode",
    ):
        if hasattr(bpy.types.WindowManager, name):
            delattr(bpy.types.WindowManager, name)
