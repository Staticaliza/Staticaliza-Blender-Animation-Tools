# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

"""Roblox Animator Utils Blender extension entry point.

Feature implementations live in focused subpackages.  This module loads them
in the original definition order, links their callback namespaces, and exposes
the same top-level API that the pre-refactor single-file addon provided.
"""

from __future__ import annotations

import importlib
import sys


_WAS_LOADED = "_FEATURE_MODULES" in globals()

if _WAS_LOADED:
    # Live Python reloads are uncommon for installed extensions, but developer
    # reloads must release the old module objects before they are replaced.
    _previous_namespace = globals().get("_SHARED_NAMESPACE", {})
    _previous_state = (
        _previous_namespace.get("_state", {})
        if isinstance(_previous_namespace, dict)
        else {}
    )
    _previous_unregister = globals().get("unregister")
    if (
        _previous_state.get("extension_registered", False)
        and callable(_previous_unregister)
    ):
        _previous_unregister()
    for _previous_module_name in tuple(
        globals().get("_FEATURE_MODULE_NAMES", ())
    ):
        sys.modules.pop(f"{__package__}.{_previous_module_name}", None)


def _load_module(relative_name: str):
    full_name = f"{__package__}.{relative_name}"
    if _WAS_LOADED:
        # A fresh module object avoids stale globals surviving Python's normal
        # in-place reload when an extension update removes or renames symbols.
        sys.modules.pop(full_name, None)
    return importlib.import_module(full_name)


_version = _load_module("core.version")
_module_registry = _load_module("core.module_registry")
ADDON_VERSION = _version.ADDON_VERSION

bl_info = {
    "name": "Roblox Animator Utils",
    "blender": (4, 2, 0),
    # Keep this literal so Blender's legacy addon scanner can parse metadata
    # without importing the extension. The architecture test enforces parity.
    "version": (1, 6, 410),
    "category": "Animation",
}

if bl_info["version"] != ADDON_VERSION:
    raise RuntimeError("Utils bl_info and core version are out of sync")

_FEATURE_MODULE_NAMES = _module_registry.FEATURE_MODULE_NAMES
_FEATURE_MODULES = tuple(_load_module(name) for name in _FEATURE_MODULE_NAMES)

_namespace_tools = _load_module("core.namespace")
_class_registry = _load_module("core.class_registry")
_LINK_RESULT = _namespace_tools.link_modules(_FEATURE_MODULES, globals())
_SHARED_NAMESPACE = _LINK_RESULT.namespace
MODULE_DEPENDENCIES = _LINK_RESULT.dependencies
SYMBOL_OWNERS = _LINK_RESULT.owners

classes = _class_registry.resolve_classes(_SHARED_NAMESPACE)
_namespace_tools.publish("classes", classes, _FEATURE_MODULES)

# Blender calls these exact package-level entry points when enabling/disabling
# the extension.  Explicit aliases also keep static inspection straightforward.
register = _SHARED_NAMESPACE["register"]
unregister = _SHARED_NAMESPACE["unregister"]
