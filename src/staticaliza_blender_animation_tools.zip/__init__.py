# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# <pep8 compliant>

# Credits to Staticaliza for most features.
# Credits to Roman Volodin, roman.volodin@gmail.com for their "Dynamic Parent" 2.0.2 (Blender 4 compatable) extension.

ADDON_VERSION = (1, 6, 43)

bl_info = {
    "name": "Roblox Animator Utils",
    "blender": (4, 2, 0),
    "version": ADDON_VERSION,
    "category": "Animation"
}

import bpy
import blf
import gpu
import addon_utils
import hashlib
import importlib
import json
import math
import os
import sys
import tempfile
import time
import tomllib
import urllib.error
import urllib.request
import zipfile
from mathutils import Color, Vector, Matrix, Quaternion
from gpu_extras.batch import batch_for_shader
from bpy.app.handlers import persistent

_state = {
    "enabled": False,
    "handle_view": None,
    "handle_pixel": None,
    "shader_3d": None,
    "shader_3d_mode": "UNIFORM",
    "shader_2d": None,
    "mesh_batches": {},
    "raycast_fixed": {},
    "yellow_fixed": {},
    "yellow_modes": {},
    "yellow_hidden": set(),
    "onion_enabled_owners": set(),
    "onion_property_syncing": False,
    "unparent_rel_cache": {},
    "unparent_handler_mute": False,
    "dynamic_space_reconciling": False,
    "dynamic_space_reconcile_pending": False,
    "dynamic_space_calibrating": False,
    "dynamic_space_export_sampling": False,
    "dynamic_space_last_action_update": 0.0,
    "dynamic_space_marker_signature": None,
    "last_error": "",
    "smart_material_processed_rigs": set(),
    "material_import_baseline": None,
    "extension_update_running": False,
    "extension_update_status": "",
    "extension_update_lock_waits": 0,
    "roblox_constraints_normalized": set(),
    "roblox_constraints_new_rigs": set(),
    "roblox_serializer_patch": None,
    "roblox_export_execute_patch": None,
    "roblox_import_execute_patch": None,
    "roblox_bone_color_patches": None,
    "unparent_export_armature": None,
    "smart_material_scan_pending": False,
    "roblox_compatibility_scan_pending": False,
    "roblox_armature_list_signature": None,
    "armature_overlay_saved": {},
    "part_pivot_syncing": False,
    "part_pivot_armature": 0,
    "part_pivot_bone": "",
    "part_pivot_last_armature": 0,
    "part_pivot_last_bone": "",
    "part_pivot_object": "",
    "part_pivot_object_local": None,
    "part_pivot_saved": None,
    "part_pivot_last_signature": None,
    "part_pivot_cursor_visibility": {},
    "camera_fov_syncing": False,
    "camera_view_spaces": {},
    "free_view_master": None,
    "free_view_space_states": {},
    "free_view_settings_master": None,
    "free_view_setting_states": {},
    "free_view_syncing": False,
    "free_view_draw_handle": None,
    "pose_mode_pending_rigs": set(),
    "pose_mode_pending_attempts": 0,
    "expanded_animation_channels": set(),
    "animation_channel_content": {},
    "animation_channel_expand_pending": False,
    "animation_channel_expand_attempts": 0,
    "bone_label_selection_signature": None,
    "pose_hidden_armatures": {},
    "pose_visibility_resume_after_save": False,
    "rig_hover_mouse": {},
    "surface_contact_syncing": False,
    "surface_contact_reconciling": False,
    "surface_contact_solver_syncing": False,
    "pin_target_dragging": False,
    "pin_snap_transform_active": False,
    "pin_snap_transform_operator": "",
    "pin_snap_syncing": False,
    "pin_snap_latches": set(),
    "pin_snap_departing": set(),
    "pin_snap_detached": set(),
    "pin_snap_transform_seen": set(),
    "pin_snap_last_depsgraph_sync": 0.0,
    "pin_gizmo_axes_visible": {},
    "pin_gizmo_selection_keys": (),
    "pin_gizmo_selected_key": "",
    "pin_gizmo_pending_click": None,
    "pin_gizmo_selection_epoch": 0,
    "pin_gizmo_claim_serial": 0,
    "pin_gizmo_last_claim": None,
    "pin_gizmo_extend_selection_until": 0.0,
    "pin_gizmo_deferred_finishes": [],
    "pin_keyboard_transform_active": False,
    "pin_yellow_history_fallbacks": {},
    "pin_history_active": False,
    "pin_history_contact_snapshot": None,
    "pin_history_syncing": False,
    "pin_clipboard": None,
}

ARMATURE_OVERLAY_STATE_KEY = "_staticaliza_advanced_overlay_state"
CLOTHING_LAYER_OFFSET_MODIFIER = "Staticaliza Clothing Offset"
RIG_TEXTURE_SOURCE_KEY = "staticaliza_rig_texture_source"
RIG_TEXTURE_OWNER_KEY = "staticaliza_rig_texture_owner"
IMPORTED_MATERIAL_DISPLAY_COLOR = tuple(
    Color((231.0 / 255.0,) * 3).from_srgb_to_scene_linear()
) + (1.0,)

_keymaps = []
LEGACY_ALT_F_OPERATOR_IDS = frozenset((
    "staticaliza.unparent_menu",
    "stattools.unparent_bake",
))

UNP_PROP = "Dynamic Unparent"
UNP_SPLIT_VALUE = 2.0
LEGACY_UNP_PROPS = ("staticaliza_unparent_marker",)
UNP_STATE_KEY = "staticaliza_unparent_state"
REL_K_PARENT = "staticaliza_rel_saved_parent"
REL_K_CONNECT = "staticaliza_rel_saved_connect"
UNP_VIS_CONSTRAINT = "STATICALIZA_UNPARENT_VIS"
DP_AUTO_UNPARENT_START_KEY = "staticaliza_auto_unparent_start"
DP_AUTO_UNPARENT_PROPERTY_PREFIX = "staticaliza_dp_unp_"
DP_SEGMENT_PROPERTY_PREFIX = "DP Segment "
DP_TARGET_PROPERTY_PREFIX = "DP Target "
DP_SUBTARGET_PROPERTY_PREFIX = "DP Subtarget "
DP_BOUNDARY_CALIBRATED_PROPERTY_PREFIX = "DP Boundary Calibrated "
SPACE_CONSTRAINT_PREFIX = "_DynamicSpace_"
SPACE_ROLE_PROPERTY_PREFIX = "Dynamic Space Role "
SPACE_SOURCE_PROPERTY_PREFIX = "Dynamic Space Source "
SPACE_ROLE_NORMAL = "NORMAL"
SPACE_ROLE_UNPARENT = "UNPARENT"
SPACE_ROLE_WORLD = "WORLD"
SPACE_MIN_FRAME = -1048574
SPACE_SOURCE_BASE = "BASE"
SPACE_SOURCE_UNPARENT_PREFIX = "UNPARENT:"
SPACE_SOURCE_DYNAMIC_PARENT_PREFIX = "DYNAMIC_PARENT:"
SPACE_HELPER_COLLECTION = "_Roblox Animator Utils Helpers"
SPACE_HELPER_OBJECT_PREFIX = "_DynamicSpaceHelper_"
SPACE_HELPER_PROPERTY = "Dynamic Space Helper"
ATTACHED_CAMERA_OWNER_NAME_PROPERTY = "Staticaliza Camera Owner"
ATTACHED_CAMERA_OWNER_UID_PROPERTY = "Staticaliza Camera Owner Session UID"
DYNAMIC_COLOR_PALETTE_KEY = "Dynamic Color Palette"
DYNAMIC_COLOR_CUSTOM_KEY = "Dynamic Color Custom"
DYNAMIC_PARENT_COLOR = (0.08, 0.72, 0.16)
DYNAMIC_UNPARENT_COLOR = (0.08, 0.32, 1.0)
DYNAMIC_CONTACT_COLOR = (1.0, 0.0, 1.0)

SURFACE_CONTACT_GUIDE_PROPERTY = "Surface Contact Guide"
SURFACE_CONTACT_ARMATURE_PROPERTY = "Contact Armature"
SURFACE_CONTACT_BONE_PROPERTY = "Contact Bone"
SURFACE_CONTACT_CONTROL_OBJECT_PROPERTY = "Contact Control Object"
SURFACE_CONTACT_CONTROL_BONE_PROPERTY = "Contact Control Bone"
SURFACE_CONTACT_PRIMARY_PROPERTY = "Contact Primary Constraint"
SURFACE_CONTACT_SECONDARY_PROPERTY = "Contact Secondary Constraint"
SURFACE_CONTACT_KIND_PROPERTY = "Contact Kind"
SURFACE_CONTACT_CHAIN_PROPERTY = "Contact Chain Count"
SURFACE_CONTACT_START_PROPERTY = "Contact Start"
SURFACE_CONTACT_END_PROPERTY = "Contact End"
SURFACE_CONTACT_SURFACE_PROPERTY = "Contact Surface"
SURFACE_CONTACT_POINT_PROPERTY = "Contact Surface Point"
SURFACE_CONTACT_NORMAL_PROPERTY = "Contact Surface Normal"
SURFACE_CONTACT_SIZE_PROPERTY = "Contact Guide Size"
SURFACE_CONTACT_OBJECT_PROPERTY = "Contact Object"
SURFACE_CONTACT_SUPPORT_PROPERTY = "Contact Bone Local Support"
SURFACE_CONTACT_SMART_OBJECT_PROPERTY = "Contact Smart Object"
SURFACE_CONTACT_SMART_LOCAL_PROPERTY = "Contact Smart Object Local Point"
SURFACE_CONTACT_AIM_PROPERTY = "Contact Aim Influence"
SURFACE_CONTACT_RELEASE_OBJECT_PROPERTY = "Contact Release Control Object"
SURFACE_CONTACT_RELEASE_BONE_PROPERTY = "Contact Release Control Bone"
SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY = "Contact Guide Surface Matrix"
SURFACE_CONTACT_FOLLOW_OBJECT_PROPERTY = "Contact Follow Object"
SURFACE_CONTACT_FOLLOW_BONE_PROPERTY = "Contact Follow Bone"
SURFACE_CONTACT_GEOMETRY_BONE_PROPERTY = "Contact Geometry Bone"
SURFACE_CONTACT_CONSTRAINT_OBJECT_PROPERTY = "Contact Constraint Object"
SURFACE_CONTACT_CONSTRAINT_BONE_PROPERTY = "Contact Constraint Bone"
SURFACE_CONTACT_SOLVER_OBJECT_PROPERTY = "Contact Solver Object"
SURFACE_CONTACT_SOLVER_PROPERTY = "Surface Contact Solver"
SURFACE_CONTACT_SOLVER_LOCAL_MATRIX_PROPERTY = "Contact Solver Guide Matrix"
SURFACE_CONTACT_ROTATION_BINDING_PROPERTY = "Contact Rotation Binding Version"
SURFACE_CONTACT_LABEL_PROPERTY = "Contact Surface Label"
SURFACE_CONTACT_TARGET_FRAMES_PROPERTY = "Contact Target Frames"
SURFACE_CONTACT_STRETCH_STATE_PROPERTY = "Contact Stretch State"
SURFACE_CONTACT_DETACHED_PROPERTY = "Contact Endpoint Detached"
SURFACE_CONTACT_MARKER_PROPERTY = "Surface Contact"
SURFACE_CONTACT_CONSTRAINT_PREFIX = "_SurfaceContact_"
SURFACE_CONTACT_KIND_CONTROL = "CONTROL"
SURFACE_CONTACT_KIND_IK = "IK"
SURFACE_CONTACT_KIND_SIMULATED = "SIMULATED"
SURFACE_CONTACT_KIND_OBJECT = "OBJECT"
YELLOW_PIN_TARGET_PROPERTY = "Onion Pin Target"
ONION_PIN_COLOR = (1.0, 1.0, 0.0, 1.0)
SURFACE_CONTACT_HOT_PINK = (1.0, 0.0, 1.0, 1.0)
SURFACE_CONTACT_OVERLAP_COLOR = tuple(
    math.sqrt(((first * first) + (second * second)) * 0.5)
    for first, second in zip(ONION_PIN_COLOR, SURFACE_CONTACT_HOT_PINK)
)
SURFACE_CONTACT_AIM_INFLUENCE = 1.0
PIN_GIZMO_DIAMOND_SCALE = 0.095
PIN_GIZMO_AXIS_SCALE = 0.34
PIN_GIZMO_LOCKED_ALPHA = 0.16
PIN_GIZMO_TARGET_POOL_SIZE = 128
PIN_DOT_PIXEL_RADIUS = 5.0
PIN_SNAP_RING_PIXEL_RADIUS = 8.0
PIN_SNAP_PIXEL_RADIUS = PIN_SNAP_RING_PIXEL_RADIUS
PIN_SNAP_RELEASE_PIXEL_RADIUS = 11.0
PIN_GIZMO_DRAG_PIXEL_THRESHOLD = 3.0

REL_K_HEAD = "staticaliza_rel_saved_head"
REL_K_TAIL = "staticaliza_rel_saved_tail"
REL_K_ROLL = "staticaliza_rel_saved_roll"

DP_BL_INFO = {
    "name": "Dynamic Parent",
    "author": "Roman Volodin, roman.volodin@gmail.com",
    "version": (2, 0, 2),
    "blender": (4, 0, 0),
    "location": "View3D > Tool Panel",
    "description": "Allows to create and disable an animated ChildOf constraint",
    "category": "Animation",
}

def get_rotation_mode(obj):
    if obj.rotation_mode in ("QUATERNION", "AXIS_ANGLE"):
        return obj.rotation_mode.lower()
    return "euler"

def get_selected_objects(context):
    if context.mode not in ("OBJECT", "POSE"):
        return

    if context.mode == "OBJECT":
        active = context.active_object
        selected = [obj for obj in context.selected_objects if obj != active]

    if context.mode == "POSE":
        active = context.active_pose_bone
        selected = [bone for bone in context.selected_pose_bones if bone != active]

    selected.append(active)
    return selected

def _dynamic_parent_owner_action(owner):
    animated_id = getattr(owner, "id_data", None) or owner
    animation_data = getattr(animated_id, "animation_data", None)
    return getattr(animation_data, "action", None)


def _dynamic_parent_segment_property_name(constraint):
    digest = hashlib.sha1(str(constraint.name).encode("utf-8")).hexdigest()[:16]
    return f"{DP_SEGMENT_PROPERTY_PREFIX}{digest}"


def _dynamic_parent_boundary_property_name(constraint):
    digest = hashlib.sha1(str(constraint.name).encode("utf-8")).hexdigest()[:16]
    return f"{DP_BOUNDARY_CALIBRATED_PROPERTY_PREFIX}{digest}"


def _mark_dynamic_parent_boundary_calibrated(owner, constraint, start):
    if owner is None or constraint is None or start is None:
        return False
    property_name = _dynamic_parent_boundary_property_name(constraint)
    value = int(start)
    if owner.get(property_name) == value:
        return False
    owner[property_name] = value
    return True


def _dynamic_parent_boundary_is_calibrated(owner, constraint, start):
    if owner is None or constraint is None or start is None:
        return False
    try:
        return int(owner.get(
            _dynamic_parent_boundary_property_name(constraint),
            SPACE_MIN_FRAME - 1,
        )) == int(start)
    except (TypeError, ValueError):
        return False


def _is_dynamic_state_constraint(constraint):
    name = str(getattr(constraint, "name", ""))
    return name.startswith("DP_") or name.startswith(SPACE_CONSTRAINT_PREFIX)


def _dynamic_space_role_property_name(constraint):
    digest = hashlib.sha1(str(constraint.name).encode("utf-8")).hexdigest()[:16]
    return f"{SPACE_ROLE_PROPERTY_PREFIX}{digest}"


def _store_dynamic_space_role(owner, constraint, role):
    owner[_dynamic_space_role_property_name(constraint)] = str(role)


def _dynamic_space_role(owner, constraint):
    return str(owner.get(_dynamic_space_role_property_name(constraint), ""))


def _dynamic_space_source_property_name(constraint):
    digest = hashlib.sha1(str(constraint.name).encode("utf-8")).hexdigest()[:16]
    return f"{SPACE_SOURCE_PROPERTY_PREFIX}{digest}"


def _store_dynamic_space_source(owner, constraint, source):
    owner[_dynamic_space_source_property_name(constraint)] = str(source)


def _dynamic_space_source(owner, constraint):
    return str(owner.get(_dynamic_space_source_property_name(constraint), ""))


def _dynamic_parent_target_property_names(constraint):
    digest = hashlib.sha1(str(constraint.name).encode("utf-8")).hexdigest()[:16]
    return (
        f"{DP_TARGET_PROPERTY_PREFIX}{digest}",
        f"{DP_SUBTARGET_PROPERTY_PREFIX}{digest}",
    )


def _store_dynamic_parent_constraint_target(owner, constraint):
    if owner is None or constraint is None or constraint.target is None:
        return False
    target_property, subtarget_property = _dynamic_parent_target_property_names(
        constraint
    )
    try:
        owner[target_property] = constraint.target
        owner[subtarget_property] = str(constraint.subtarget)
        return True
    except (AttributeError, RuntimeError, TypeError):
        return False


def _restore_dynamic_parent_constraint_target(owner, constraint):
    if constraint.target is not None:
        return True
    target_property, subtarget_property = _dynamic_parent_target_property_names(
        constraint
    )
    target = owner.get(target_property, None)
    if target is None:
        return False
    constraint.target = target
    constraint.subtarget = str(owner.get(subtarget_property, ""))
    return True


def _dynamic_parent_constraint_target(owner, constraint):
    if constraint is None:
        return None
    if constraint.target is not None:
        return constraint.target
    target_property, _subtarget_property = _dynamic_parent_target_property_names(
        constraint
    )
    return owner.get(target_property, None)


def _dynamic_parent_constraint_subtarget(owner, constraint):
    if constraint is None:
        return ""
    if constraint.target is not None:
        return str(constraint.subtarget)
    _target_property, subtarget_property = _dynamic_parent_target_property_names(
        constraint
    )
    return str(owner.get(subtarget_property, ""))


def _remove_dynamic_parent_constraint_metadata(owner, constraint):
    property_names = (
        _dynamic_parent_segment_property_name(constraint),
        _dynamic_parent_boundary_property_name(constraint),
        _dynamic_space_role_property_name(constraint),
        _dynamic_space_source_property_name(constraint),
        *_dynamic_parent_target_property_names(constraint),
    )
    for property_name in property_names:
        if property_name in owner:
            del owner[property_name]


def _restore_all_dynamic_parent_constraint_targets():
    for obj in tuple(bpy.data.objects):
        owners = [obj]
        if obj.type == "ARMATURE" and getattr(obj, "pose", None) is not None:
            owners.extend(obj.pose.bones)
        for owner in owners:
            for constraint in getattr(owner, "constraints", ()):
                if not _is_dynamic_state_constraint(constraint):
                    continue
                _restore_dynamic_parent_constraint_target(owner, constraint)
                constraint.mute = False


def _store_dynamic_parent_constraint_segment(owner, constraint, start, end = None):
    if owner is None or constraint is None:
        return False
    try:
        property_name = _dynamic_parent_segment_property_name(constraint)
        existing = owner.get(property_name)
        existing_start = (
            int(existing[0])
            if existing is not None and len(existing) >= 1
            else None
        )
        if existing_start is not None and existing_start != int(start):
            calibrated_property = _dynamic_parent_boundary_property_name(
                constraint
            )
            if calibrated_property in owner:
                del owner[calibrated_property]
        owner[property_name] = [
            int(start),
            int(end) if end is not None else -1,
        ]
        return True
    except (AttributeError, RuntimeError, TypeError):
        return False


def _stored_dynamic_parent_constraint_segment(owner, constraint):
    if constraint is None or not _is_dynamic_state_constraint(constraint):
        return (None, None)

    metadata = owner.get(
        _dynamic_parent_segment_property_name(constraint),
        None,
    )
    try:
        start = metadata[0] if metadata is not None and len(metadata) >= 1 else None
        end = metadata[1] if metadata is not None and len(metadata) >= 2 else None
    except TypeError:
        start = None
        end = None
    try:
        start = int(start) if start is not None else None
    except (TypeError, ValueError):
        start = None
    try:
        end = int(end) if end is not None and int(end) >= 0 else None
    except (TypeError, ValueError):
        end = None
    return (start, end)


def _dynamic_parent_constraint_segment(owner, constraint, persist = False):
    if constraint is None or not _is_dynamic_state_constraint(constraint):
        return (None, None)

    start, end = _stored_dynamic_parent_constraint_segment(owner, constraint)

    action = _dynamic_parent_owner_action(owner)
    fcurve = None
    is_dynamic_parent = constraint.name.startswith("DP_")
    if is_dynamic_parent:
        try:
            data_path = constraint.path_from_id("influence")
        except (AttributeError, TypeError, ValueError):
            data_path = ""
        fcurve = _fcurve_find(action, data_path) if action and data_path else None
    if is_dynamic_parent and (fcurve is None or not fcurve.keyframe_points):
        return (None, None)
    if fcurve is not None and fcurve.keyframe_points:
        curve_start = None
        curve_end = None
        active = False
        for key in sorted(
            fcurve.keyframe_points,
            key = lambda point: float(point.co.x),
        ):
            key_frame = int(round(float(key.co.x)))
            next_active = float(key.co.y) > 0.5
            if next_active and not active and curve_start is None:
                curve_start = key_frame
            elif active and not next_active and curve_start is not None:
                curve_end = key_frame
                break
            active = next_active
        if curve_start is None:
            return (None, None)
        start = curve_start
        end = curve_end

    if persist and start is not None:
        _store_dynamic_parent_constraint_segment(
            owner,
            constraint,
            start,
            end,
        )
    return (start, end)


def _dynamic_parent_constraint_active_at(owner, constraint, frame):
    start, end = _dynamic_parent_constraint_segment(owner, constraint)
    if start is None:
        if constraint.name.startswith("DP_"):
            return False
        return float(getattr(constraint, "influence", 0.0)) > 0.5
    frame = int(frame)
    return frame >= int(start) and (end is None or frame < int(end))


def _constraint_segment_start(owner, constraint):
    start, _end = _stored_dynamic_parent_constraint_segment(owner, constraint)
    return int(start) if start is not None else SPACE_MIN_FRAME


def _marker_aware_internal_constraint(owner, constraints, frame):
    active_by_segment = [
        constraint
        for constraint in constraints
        if _dynamic_parent_constraint_active_at(owner, constraint, frame)
    ]
    if not isinstance(owner, bpy.types.PoseBone):
        return (active_by_segment or [None])[-1]

    action = _dynamic_parent_owner_action(owner)
    points = _unparent_points(action, owner.name) if action is not None else []
    has_unparent_spaces = any(
        _dynamic_space_role(owner, constraint) == SPACE_ROLE_UNPARENT
        for constraint in constraints
    )
    if not points and not has_unparent_spaces:
        return (active_by_segment or [None])[-1]

    state = False
    active_start = None
    last_transition = None
    for point_frame, value in points:
        if int(point_frame) > int(frame):
            break
        next_state = float(value) >= 0.5
        if next_state and not state:
            active_start = int(point_frame)
        elif state and not next_state:
            active_start = None
        state = next_state
        last_transition = (int(point_frame), float(value))

    if state:
        candidates = [
            constraint
            for constraint in constraints
            if _dynamic_space_role(owner, constraint) == SPACE_ROLE_UNPARENT
        ]
        eligible = [
            constraint
            for constraint in candidates
            if _constraint_segment_start(owner, constraint) <= int(frame)
            and (
                active_start is None
                or _constraint_segment_start(owner, constraint) >= int(active_start)
            )
        ]
        if eligible:
            return max(
                eligible,
                key = lambda constraint: _constraint_segment_start(owner, constraint),
            )
        if active_start is not None:
            return min(
                candidates,
                key = lambda constraint: abs(
                    _constraint_segment_start(owner, constraint) - int(active_start)
                ),
                default = None,
            )
        return (candidates or [None])[-1]

    normal_roles = {SPACE_ROLE_NORMAL, SPACE_ROLE_WORLD}
    candidates = [
        constraint
        for constraint in constraints
        if _dynamic_space_role(owner, constraint) in normal_roles
    ]
    if last_transition is None:
        base = next(
            (
                constraint
                for constraint in candidates
                if _dynamic_space_source(owner, constraint) == SPACE_SOURCE_BASE
            ),
            None,
        )
        return base or (active_by_segment or candidates or [None])[-1]

    transition_frame = int(last_transition[0])
    return min(
        candidates,
        key = lambda constraint: (
            abs(_constraint_segment_start(owner, constraint) - transition_frame),
            -_constraint_segment_start(owner, constraint),
        ),
        default = None,
    )


def _chosen_dynamic_parent_constraint(owner, frame):
    constraints = [
        constraint
        for constraint in getattr(owner, "constraints", ())
        if _is_dynamic_state_constraint(constraint)
    ]
    active_dynamic_parent = [
        constraint
        for constraint in constraints
        if constraint.name.startswith("DP_")
        and _dynamic_parent_constraint_active_at(owner, constraint, frame)
    ]
    internal = [
        constraint
        for constraint in constraints
        if constraint.name.startswith(SPACE_CONSTRAINT_PREFIX)
    ]
    return (
        active_dynamic_parent
        or [_marker_aware_internal_constraint(owner, internal, frame)]
    )[-1]


def _set_dynamic_parent_owner_constraint(owner, chosen):
    changed = False
    constraints = [
        constraint
        for constraint in getattr(owner, "constraints", ())
        if _is_dynamic_state_constraint(constraint)
    ]

    for constraint in constraints:
        active = constraint == chosen
        disconnect_inactive_parent = bool(
            constraint.name.startswith("DP_") and not active
        )
        if disconnect_inactive_parent and constraint.target is not None:
            _store_dynamic_parent_constraint_target(owner, constraint)
            constraint.target = None
            constraint.subtarget = ""
            changed = True
        elif not disconnect_inactive_parent and constraint.target is None:
            changed = _restore_dynamic_parent_constraint_target(
                owner,
                constraint,
            ) or changed
        elif active:
            _store_dynamic_parent_constraint_target(owner, constraint)
        influence = 1.0 if active else 0.0
        if abs(float(constraint.influence) - influence) > 1.0e-6:
            constraint.influence = influence
            changed = True
        if bool(constraint.mute) == bool(active):
            constraint.mute = not active
            changed = True
    return changed


def _restore_dynamic_pose_bone_color(pose_bone):
    if pose_bone is None or DYNAMIC_COLOR_PALETTE_KEY not in pose_bone:
        return False

    color = getattr(pose_bone, "color", None)
    if color is None:
        return False
    palette = str(pose_bone.get(DYNAMIC_COLOR_PALETTE_KEY, "DEFAULT"))
    custom_values = tuple(pose_bone.get(DYNAMIC_COLOR_CUSTOM_KEY, ()))
    try:
        if len(custom_values) >= 10:
            color.palette = "CUSTOM"
            color.custom.normal = tuple(custom_values[0:3])
            color.custom.select = tuple(custom_values[3:6])
            color.custom.active = tuple(custom_values[6:9])
            color.custom.show_colored_constraints = bool(custom_values[9])
        color.palette = palette
    except (AttributeError, TypeError, ValueError):
        return False
    finally:
        for property_name in (
            DYNAMIC_COLOR_PALETTE_KEY,
            DYNAMIC_COLOR_CUSTOM_KEY,
        ):
            if property_name in pose_bone:
                del pose_bone[property_name]
    return True


def _restore_all_dynamic_pose_bone_colors():
    changed = False
    for obj in tuple(bpy.data.objects):
        if obj.type != "ARMATURE" or getattr(obj, "pose", None) is None:
            continue
        for pose_bone in obj.pose.bones:
            changed = _restore_dynamic_pose_bone_color(pose_bone) or changed
    return changed


def _surface_contact_guides_for_pose_bone(pose_bone, frame = None):
    armature = getattr(pose_bone, "id_data", None)
    armature_name = str(getattr(armature, "name", ""))
    if not armature_name:
        return ()
    guides = tuple(
        guide
        for guide in _surface_contact_guides()
        if (
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
            == armature_name
            and str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
            == pose_bone.name
            and (
                frame is None
                or _surface_contact_guide_active_at(guide, int(frame))
            )
        )
    )
    return tuple(
        sorted(
            guides,
            key = lambda guide: int(
                guide.get(SURFACE_CONTACT_START_PROPERTY, SPACE_MIN_FRAME)
            ),
        )
    )


def _surface_contact_active_for_pose_bone(pose_bone, frame):
    return bool(_surface_contact_guides_for_pose_bone(pose_bone, frame))


def _active_dynamic_parent_constraint(pose_bone, frame, chosen = None):
    if (
        chosen is not None
        and chosen.name.startswith("DP_")
        and _dynamic_parent_constraint_active_at(pose_bone, chosen, frame)
    ):
        return chosen
    candidates = tuple(
        constraint
        for constraint in getattr(pose_bone, "constraints", ())
        if (
            constraint.name.startswith("DP_")
            and _dynamic_parent_constraint_active_at(
                pose_bone,
                constraint,
                int(frame),
            )
        )
    )
    return max(
        candidates,
        key = lambda constraint: _constraint_segment_start(
            pose_bone,
            constraint,
        ),
        default = None,
    )


def _surface_contact_target_effects(pose_bone, frame):
    armature = getattr(pose_bone, "id_data", None)
    if armature is None:
        return ()
    effects = []
    for guide in _surface_contact_guides():
        if not _surface_contact_guide_active_at(guide, int(frame)):
            continue
        if (
            str(guide.get(SURFACE_CONTACT_FOLLOW_OBJECT_PROPERTY, ""))
            != armature.name
            or str(guide.get(SURFACE_CONTACT_FOLLOW_BONE_PROPERTY, ""))
            != pose_bone.name
        ):
            continue
        source_name = str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
        if source_name and source_name != pose_bone.name:
            effects.append(
                (
                    "CONTACT_TARGET",
                    "Contacted by "
                    + json.dumps(source_name, ensure_ascii = False),
                    DYNAMIC_CONTACT_COLOR,
                )
            )
    return tuple(effects)


def _dynamic_pose_bone_effects(pose_bone, frame, chosen = None):
    effects = []
    parent_constraint = _active_dynamic_parent_constraint(
        pose_bone,
        int(frame),
        chosen,
    )
    if parent_constraint is not None:
        target = _dynamic_parent_constraint_target(
            pose_bone,
            parent_constraint,
        )
        target_name = _dynamic_parent_constraint_subtarget(
            pose_bone,
            parent_constraint,
        )
        if not target_name:
            target_name = str(getattr(target, "name", "")) or "World"
        effects.append(
            (
                "PARENT",
                f"Parented to {json.dumps(target_name, ensure_ascii = False)}",
                DYNAMIC_PARENT_COLOR,
            )
        )

    action = _dynamic_parent_owner_action(pose_bone)
    if (
        _unparent_points(action, pose_bone.name)
        and _unparent_eval(
            action,
            pose_bone.name,
            int(frame),
            pb_default = 0.0,
        ) >= 0.5
    ):
        original_parent = str(
            pose_bone.bone.get(REL_K_PARENT, "")
        ) or str(getattr(getattr(pose_bone, "parent", None), "name", ""))
        effects.append(
            (
                "UNPARENT",
                "Unparented from "
                + json.dumps(
                    original_parent or "original parent",
                    ensure_ascii = False,
                ),
                DYNAMIC_UNPARENT_COLOR,
            )
        )

    active_contacts = _surface_contact_guides_for_pose_bone(
        pose_bone,
        int(frame),
    )
    if active_contacts:
        effects.append(
            (
                "CONTACT",
                "Contact with "
                + json.dumps(
                    _surface_contact_guide_surface_label(active_contacts[-1]),
                    ensure_ascii = False,
                ),
                DYNAMIC_CONTACT_COLOR,
            )
        )
    effects.extend(_surface_contact_target_effects(pose_bone, int(frame)))

    pin_owner = _pose_bone_owner(bpy.context, pose_bone)
    if (
        pin_owner is not None
        and _owner_bone_key(pin_owner, pose_bone.name)
        in _state.get("yellow_modes", {})
    ):
        effects.append(("PIN", "Onion Pinned", ONION_PIN_COLOR[:3]))
    return tuple(effects)


def _dynamic_pose_bone_native_effect(pose_bone, native_color = None):
    name = str(getattr(pose_bone, "name", ""))
    joint_type = str(getattr(pose_bone, "bone", {}).get("rbx_joint_type", ""))
    if name.endswith("-IKTarget"):
        label = "IK Target"
    elif name.endswith("-IKPole"):
        label = "IK Pole"
    elif joint_type in {"Weld", "WeldConstraint"}:
        label = "Weld Bone"
    else:
        return None
    return (
        "NATIVE",
        label,
        tuple(native_color or (0.65, 0.65, 0.65)),
    )


def _dynamic_pose_bone_base_color(pose_bone):
    color = getattr(pose_bone, "color", None)
    if color is None:
        return None
    palette = str(
        pose_bone.get(DYNAMIC_COLOR_PALETTE_KEY, str(color.palette))
    )
    custom_values = tuple(pose_bone.get(DYNAMIC_COLOR_CUSTOM_KEY, ()))
    if palette == "CUSTOM":
        values = custom_values[0:3] if len(custom_values) >= 3 else color.custom.normal
        return tuple(float(value) for value in values)
    if not palette.startswith("THEME"):
        return None
    try:
        palette_index = int(palette[5:]) - 1
        theme = bpy.context.preferences.themes[0]
        return tuple(
            float(value)
            for value in theme.bone_color_sets[palette_index].normal
        )
    except (AttributeError, IndexError, TypeError, ValueError):
        return None


def _blend_bone_effect_colors(colors):
    colors = tuple(tuple(float(value) for value in color[:3]) for color in colors)
    if not colors:
        return None
    return tuple(
        min(
            1.0,
            math.sqrt(
                sum(max(0.0, color[channel]) ** 2 for color in colors)
                / len(colors)
            ),
        )
        for channel in range(3)
    )


def _dynamic_pose_bone_label_effects(pose_bone, frame, chosen = None):
    effects = list(_dynamic_pose_bone_effects(pose_bone, frame, chosen))
    armature = getattr(pose_bone, "id_data", None)
    scene = getattr(bpy.context, "scene", None)
    if armature is not None and scene is not None:
        try:
            camera = _camera_for_bone(scene, armature, pose_bone.name)
        except (AttributeError, NameError, ReferenceError, RuntimeError):
            camera = None
        if camera is not None:
            effects.append(("CAMERA", "Camera attached", (0.0, 0.0, 0.0)))
    native_color = _dynamic_pose_bone_base_color(pose_bone)
    native_effect = _dynamic_pose_bone_native_effect(pose_bone, native_color)
    if native_effect is not None:
        effects.append(native_effect)
    order = {
        "PIN": 0,
        "PARENT": 1,
        "UNPARENT": 2,
        "CONTACT": 3,
        "CONTACT_TARGET": 3,
        "CAMERA": 4,
        "NATIVE": 5,
    }
    return tuple(
        effect
        for _index, effect in sorted(
            enumerate(effects),
            key = lambda item: (order.get(item[1][0], 99), item[0]),
        )
    )


def _sync_dynamic_pose_bone_color(pose_bone, chosen, frame):
    effects = _dynamic_pose_bone_effects(pose_bone, frame, chosen)
    color_effects = tuple(
        effect
        for effect in effects
        if effect[0] not in {"PIN", "CAMERA", "NATIVE"}
    )
    if not color_effects:
        return _restore_dynamic_pose_bone_color(pose_bone)
    color = getattr(pose_bone, "color", None)
    if color is None:
        return False
    native_color = _dynamic_pose_bone_base_color(pose_bone)
    changed = False
    if DYNAMIC_COLOR_PALETTE_KEY not in pose_bone:
        custom = color.custom
        pose_bone[DYNAMIC_COLOR_PALETTE_KEY] = str(color.palette)
        pose_bone[DYNAMIC_COLOR_CUSTOM_KEY] = [
            *tuple(custom.normal),
            *tuple(custom.select),
            *tuple(custom.active),
            1.0 if custom.show_colored_constraints else 0.0,
        ]
        changed = True

    effect_colors = [effect[2] for effect in color_effects]
    if native_color is not None:
        effect_colors.append(native_color)
    desired_normal = _blend_bone_effect_colors(effect_colors)
    desired_select = tuple(min(1.0, component * 1.2 + 0.08) for component in desired_normal)
    desired_active = tuple(min(1.0, component * 1.35 + 0.12) for component in desired_normal)
    try:
        if color.palette != "CUSTOM":
            color.palette = "CUSTOM"
            changed = True
        for attribute, desired in (
            ("normal", desired_normal),
            ("select", desired_select),
            ("active", desired_active),
        ):
            current = tuple(getattr(color.custom, attribute))
            if any(
                abs(float(a) - float(b)) > 1.0e-6
                for a, b in zip(current, desired)
            ):
                setattr(color.custom, attribute, desired)
                changed = True
        if bool(color.custom.show_colored_constraints):
            color.custom.show_colored_constraints = False
            changed = True
    except (AttributeError, IndexError, TypeError, ValueError):
        return False
    return changed


def _sync_all_dynamic_pose_bone_colors(frame, armature = None):
    changed = False
    armatures = (
        (armature,)
        if armature is not None
        else tuple(
            obj
            for obj in bpy.data.objects
            if obj.type == "ARMATURE" and getattr(obj, "pose", None) is not None
        )
    )
    for current_armature in armatures:
        if current_armature is None or getattr(current_armature, "pose", None) is None:
            continue
        for pose_bone in current_armature.pose.bones:
            chosen = _chosen_dynamic_parent_constraint(pose_bone, int(frame))
            changed = (
                _sync_dynamic_pose_bone_color(
                    pose_bone,
                    chosen,
                    int(frame),
                )
                or changed
            )
    return changed


def _sync_dynamic_parent_owner(owner, frame):
    chosen = _chosen_dynamic_parent_constraint(owner, frame)
    changed = _set_dynamic_parent_owner_constraint(owner, chosen)
    if isinstance(owner, bpy.types.PoseBone):
        changed = _sync_dynamic_pose_bone_color(owner, chosen, frame) or changed
    return changed


def _matrices_nearly_equal(first, second, tolerance = 1.0e-6):
    return all(
        abs(float(first[row][column]) - float(second[row][column])) <= tolerance
        for row in range(4)
        for column in range(4)
    )


def _calibrate_pose_dynamic_boundary(context, armature, pose_bone, frame):
    if pose_bone is None or int(frame) <= SPACE_MIN_FRAME:
        return False

    incoming = _chosen_dynamic_parent_constraint(pose_bone, int(frame))
    outgoing = _chosen_dynamic_parent_constraint(pose_bone, int(frame) - 1)
    if incoming is None or outgoing is None or incoming == outgoing:
        return False

    incoming_start, _incoming_end = _dynamic_parent_constraint_segment(
        pose_bone,
        incoming,
    )
    if _dynamic_parent_boundary_is_calibrated(
        pose_bone,
        incoming,
        incoming_start,
    ):
        return False

    outgoing_target = _dynamic_parent_constraint_target(pose_bone, outgoing)
    incoming_target = _dynamic_parent_constraint_target(pose_bone, incoming)
    if outgoing_target is None or incoming_target is None:
        return False

    outgoing_target_matrix = _pose_space_target_matrix(
        context,
        armature,
        outgoing_target,
        _dynamic_parent_constraint_subtarget(pose_bone, outgoing),
    )
    desired_factor = outgoing_target_matrix @ outgoing.inverse_matrix
    incoming_target_matrix = _pose_space_target_matrix(
        context,
        armature,
        incoming_target,
        _dynamic_parent_constraint_subtarget(pose_bone, incoming),
    )
    inverse_matrix = incoming_target_matrix.inverted_safe() @ desired_factor
    changed = not _matrices_nearly_equal(
        incoming.inverse_matrix,
        inverse_matrix,
    )
    if changed:
        incoming.inverse_matrix = inverse_matrix
    _mark_dynamic_parent_boundary_calibrated(
        pose_bone,
        incoming,
        incoming_start,
    )
    return changed


def _calibrate_dynamic_space_boundaries(context, frame, armature = None):
    scene = getattr(context, "scene", None)
    if (
        _state.get("dynamic_space_calibrating", False)
        or _state.get("dynamic_space_export_sampling", False)
        or abs(float(getattr(scene, "frame_subframe", 0.0))) > 1.0e-7
    ):
        return False

    _state["dynamic_space_calibrating"] = True
    changed = False
    try:
        armatures = (
            (armature,)
            if armature is not None
            else tuple(
                obj
                for obj in bpy.data.objects
                if obj.type == "ARMATURE" and getattr(obj, "pose", None) is not None
            )
        )
        for current_armature in armatures:
            if current_armature is None or getattr(current_armature, "pose", None) is None:
                continue
            for pose_bone in current_armature.pose.bones:
                if not any(
                    _is_dynamic_state_constraint(constraint)
                    for constraint in pose_bone.constraints
                ):
                    continue
                changed = _calibrate_pose_dynamic_boundary(
                    context,
                    current_armature,
                    pose_bone,
                    int(frame),
                ) or changed
        return changed
    finally:
        _state["dynamic_space_calibrating"] = False


def _sync_dynamic_parent_constraints(frame, armature = None):
    changed = False
    objects = (armature,) if armature is not None else tuple(bpy.data.objects)
    for obj in objects:
        if obj is None:
            continue
        changed = _sync_dynamic_parent_owner(obj, frame) or changed
        if obj.type != "ARMATURE" or getattr(obj, "pose", None) is None:
            continue
        for pose_bone in obj.pose.bones:
            changed = _sync_dynamic_parent_owner(pose_bone, frame) or changed
    return changed


def _internal_space_constraints(owner):
    return tuple(
        constraint
        for constraint in getattr(owner, "constraints", ())
        if constraint.name.startswith(SPACE_CONSTRAINT_PREFIX)
    )


def _pose_space_managed(pose_bone):
    return bool(pose_bone and _internal_space_constraints(pose_bone))


def _pose_space_input_matrix(pose_bone):
    return pose_bone.bone.matrix_local @ pose_bone.matrix_basis


def _pose_space_output_matrix(context, armature, pose_bone):
    context.view_layer.update()
    try:
        evaluated_armature = armature.evaluated_get(
            context.evaluated_depsgraph_get()
        )
        evaluated_bone = evaluated_armature.pose.bones.get(pose_bone.name)
        if evaluated_bone is not None:
            return evaluated_bone.matrix.copy()
    except (AttributeError, ReferenceError, RuntimeError):
        pass
    return pose_bone.matrix.copy()


def _pose_space_factor(context, armature, pose_bone):
    output_matrix = _pose_space_output_matrix(
        context,
        armature,
        pose_bone,
    )
    return output_matrix @ _pose_space_input_matrix(pose_bone).inverted_safe()


def _pose_space_target_matrix(context, armature, target, subtarget = ""):
    if target is None:
        return Matrix.Identity(4)

    context.view_layer.update()
    depsgraph = context.evaluated_depsgraph_get()
    evaluated_armature = armature.evaluated_get(depsgraph)
    evaluated_target = target.evaluated_get(depsgraph)
    target_world = evaluated_target.matrix_world.copy()
    if evaluated_target.type == "ARMATURE" and subtarget:
        target_bone = evaluated_target.pose.bones.get(subtarget)
        if target_bone is None:
            raise ValueError(f'Bone "{subtarget}" is not available on the target rig.')
        target_world = target_world @ target_bone.matrix
    return evaluated_armature.matrix_world.inverted_safe() @ target_world


def _ensure_space_helper_collection(context):
    collection = bpy.data.collections.get(SPACE_HELPER_COLLECTION)
    if collection is None:
        collection = bpy.data.collections.new(SPACE_HELPER_COLLECTION)
    if not any(
        child == collection
        for child in context.scene.collection.children
    ):
        try:
            context.scene.collection.children.link(collection)
        except RuntimeError:
            pass
    collection.hide_render = True
    try:
        collection.hide_select = True
    except AttributeError:
        pass
    return collection


def _create_space_helper(context, armature, pose_bone, role, frame, factor):
    collection = _ensure_space_helper_collection(context)
    helper = bpy.data.objects.new(
        f"{SPACE_HELPER_OBJECT_PREFIX}{pose_bone.name}_{role}_{int(frame)}",
        None,
    )
    collection.objects.link(helper)
    helper[SPACE_HELPER_PROPERTY] = True
    helper.empty_display_type = "PLAIN_AXES"
    helper.empty_display_size = 0.01
    helper.hide_render = True
    helper.hide_select = True
    helper.parent = armature
    helper.matrix_parent_inverse = Matrix.Identity(4)
    helper.matrix_basis = factor
    try:
        helper.hide_set(True)
    except RuntimeError:
        pass
    context.view_layer.update()
    return helper


def _remove_space_constraint(owner, constraint):
    if owner is None or constraint is None:
        return False
    target = _dynamic_parent_constraint_target(owner, constraint)
    is_helper = bool(
        target is not None
        and bool(target.get(SPACE_HELPER_PROPERTY, False))
    )
    _remove_dynamic_parent_constraint_metadata(owner, constraint)
    try:
        owner.constraints.remove(constraint)
    except (ReferenceError, RuntimeError, ValueError):
        return False
    if is_helper and target.name in bpy.data.objects:
        bpy.data.objects.remove(target, do_unlink = True)
    return True


def _space_constraint_source_for_unparent(start_frame):
    return f"{SPACE_SOURCE_UNPARENT_PREFIX}{int(start_frame)}"


def _space_constraint_source_for_dynamic_parent(constraint, start_frame):
    identity = f"{constraint.name}:{int(start_frame)}"
    digest = hashlib.sha1(identity.encode("utf-8")).hexdigest()[:16]
    return f"{SPACE_SOURCE_DYNAMIC_PARENT_PREFIX}{digest}"


def _create_pose_space_constraint(
    context,
    armature,
    pose_bone,
    role,
    start_frame,
    end_frame = None,
    desired_factor = None,
    source = SPACE_SOURCE_BASE,
):
    if desired_factor is None:
        desired_factor = _pose_space_factor(
            context,
            armature,
            pose_bone,
        )

    parent_name = str(pose_bone.bone.get(REL_K_PARENT, ""))
    if role == SPACE_ROLE_NORMAL and not parent_name:
        role = SPACE_ROLE_WORLD

    constraint = pose_bone.constraints.new("CHILD_OF")
    constraint.name = f"{SPACE_CONSTRAINT_PREFIX}{role}_{int(start_frame)}"
    if role == SPACE_ROLE_NORMAL:
        constraint.target = armature
        constraint.subtarget = parent_name
        target_matrix = _pose_space_target_matrix(
            context,
            armature,
            armature,
            parent_name,
        )
        constraint.inverse_matrix = target_matrix.inverted_safe() @ desired_factor
    else:
        helper = _create_space_helper(
            context,
            armature,
            pose_bone,
            role,
            start_frame,
            desired_factor,
        )
        constraint.target = helper
        constraint.subtarget = ""
        constraint.inverse_matrix = Matrix.Identity(4)

    _store_dynamic_space_role(pose_bone, constraint, role)
    _store_dynamic_space_source(pose_bone, constraint, source)
    _store_dynamic_parent_constraint_segment(
        pose_bone,
        constraint,
        int(start_frame),
        int(end_frame) if end_frame is not None else None,
    )
    _store_dynamic_parent_constraint_target(pose_bone, constraint)
    _mark_dynamic_parent_boundary_calibrated(
        pose_bone,
        constraint,
        int(start_frame),
    )
    constraint.influence = 0.0
    constraint.mute = True
    return constraint


def _active_internal_space_constraint(pose_bone, frame):
    active = [
        constraint
        for constraint in _internal_space_constraints(pose_bone)
        if _dynamic_parent_constraint_active_at(pose_bone, constraint, frame)
    ]
    return active[-1] if active else None


def _ensure_pose_space_system(context, armature, pose_bone, frame):
    if pose_bone is None:
        return None
    bone_name = pose_bone.name
    if _pose_space_managed(pose_bone):
        if pose_bone.parent is not None:
            _rel_saved_parent(pose_bone)
            if not _unparent_apply_relation(
                context,
                armature,
                bone_name,
                True,
            ):
                return None
        _sync_dynamic_parent_constraints(int(frame), armature)
        context.view_layer.update()
        return armature.pose.bones.get(bone_name)

    desired_factor = _pose_space_factor(
        context,
        armature,
        pose_bone,
    )
    parent_name = _rel_saved_parent(pose_bone)
    if pose_bone.parent is not None and not _unparent_apply_relation(
        context,
        armature,
        bone_name,
        True,
    ):
        return None

    context.view_layer.update()
    pose_bone = armature.pose.bones.get(bone_name)
    if pose_bone is None:
        return None
    role = SPACE_ROLE_NORMAL if parent_name else SPACE_ROLE_WORLD
    _create_pose_space_constraint(
        context,
        armature,
        pose_bone,
        role,
        SPACE_MIN_FRAME,
        desired_factor = desired_factor,
        source = SPACE_SOURCE_BASE,
    )
    _sync_dynamic_parent_constraints(int(frame), armature)
    context.view_layer.update()
    return armature.pose.bones.get(bone_name)


def _switch_pose_underlying_space(
    context,
    armature,
    pose_bone,
    role,
    frame,
    desired_factor,
    source,
):
    pose_bone = _ensure_pose_space_system(
        context,
        armature,
        pose_bone,
        frame,
    )
    if pose_bone is None:
        return None

    current = _active_internal_space_constraint(pose_bone, int(frame))
    if current is not None:
        start_frame, _end_frame = _dynamic_parent_constraint_segment(
            pose_bone,
            current,
        )
        if start_frame is not None and int(start_frame) == int(frame):
            _remove_space_constraint(pose_bone, current)
        else:
            _store_dynamic_parent_constraint_segment(
                pose_bone,
                current,
                int(start_frame) if start_frame is not None else SPACE_MIN_FRAME,
                int(frame),
            )

    constraint = _create_pose_space_constraint(
        context,
        armature,
        pose_bone,
        role,
        int(frame),
        desired_factor = desired_factor,
        source = source,
    )
    _sync_dynamic_parent_constraints(int(frame), armature)
    context.view_layer.update()
    return constraint


def _remove_future_space_constraints(owner, source, after_frame):
    removed = False
    for constraint in list(_internal_space_constraints(owner)):
        if _dynamic_space_source(owner, constraint) != source:
            continue
        start_frame, _end_frame = _dynamic_parent_constraint_segment(
            owner,
            constraint,
        )
        if start_frame is None or int(start_frame) <= int(after_frame):
            continue
        removed = _remove_space_constraint(owner, constraint) or removed
    return removed


def _space_constraints_with_source(owner, source):
    return tuple(
        constraint
        for constraint in _internal_space_constraints(owner)
        if _dynamic_space_source(owner, constraint) == source
    )


def _remove_pose_space_source(owner, source):
    matching = _space_constraints_with_source(owner, source)
    if not matching:
        return False

    matching_pointers = {int(constraint.as_pointer()) for constraint in matching}
    remaining = [
        constraint
        for constraint in _internal_space_constraints(owner)
        if int(constraint.as_pointer()) not in matching_pointers
    ]
    matching_starts = [
        start
        for constraint in matching
        for start, _end in (
            _stored_dynamic_parent_constraint_segment(owner, constraint),
        )
        if start is not None
    ]
    boundary = min(matching_starts) if matching_starts else SPACE_MIN_FRAME

    fallback = next(
        (
            constraint
            for constraint in reversed(remaining)
            if _dynamic_parent_constraint_active_at(owner, constraint, boundary)
        ),
        None,
    )
    previous = next(
        (
            constraint
            for constraint in reversed(remaining)
            if _dynamic_parent_constraint_active_at(
                owner,
                constraint,
                boundary - 1,
            )
        ),
        None,
    )
    next_starts = [
        start
        for constraint in remaining
        for start, _end in (
            _stored_dynamic_parent_constraint_segment(owner, constraint),
        )
        if start is not None and int(start) > int(boundary)
    ]

    removed = False
    for constraint in matching:
        removed = _remove_space_constraint(owner, constraint) or removed

    if fallback is None and previous is not None:
        previous_start, _previous_end = (
            _stored_dynamic_parent_constraint_segment(owner, previous)
        )
        _store_dynamic_parent_constraint_segment(
            owner,
            previous,
            int(previous_start) if previous_start is not None else SPACE_MIN_FRAME,
            min(next_starts) if next_starts else None,
        )
    return removed


def _teardown_pose_space_system(context, armature, pose_bone):
    if pose_bone is None or not _pose_space_managed(pose_bone):
        return False

    bone_name = pose_bone.name
    output_matrix = _pose_space_output_matrix(
        context,
        armature,
        pose_bone,
    )
    previous_autokey = _autokey_push(context)
    try:
        if pose_bone.parent is None and str(
            pose_bone.bone.get(REL_K_PARENT, "")
        ):
            if not _unparent_apply_relation(
                context,
                armature,
                bone_name,
                False,
            ):
                return False

        context.view_layer.update()
        pose_bone = armature.pose.bones.get(bone_name)
        if pose_bone is None:
            return False
        for constraint in list(_internal_space_constraints(pose_bone)):
            _remove_space_constraint(pose_bone, constraint)
        _unparent_remove_visual_constraint(pose_bone)
        context.view_layer.update()
        pose_bone = armature.pose.bones.get(bone_name)
        if pose_bone is None:
            return False
        try:
            pose_bone.matrix = output_matrix
        except (AttributeError, RuntimeError, ValueError):
            pass
        if UNP_PROP in pose_bone:
            del pose_bone[UNP_PROP]
        _unparent_clear_start_frame(pose_bone)
        _unparent_rel_set_cached(armature.name, bone_name, False)
        context.view_layer.update()
        return True
    finally:
        _autokey_pop(context, previous_autokey)


def _dynamic_marker_value(action, data_path, frame):
    values = []
    for fcurve in _fcurves_find_all(action, data_path):
        key = _fcurve_key_at(fcurve, int(frame))
        if key is not None:
            values.append(float(key.co.y))
    return max(values) if values else None


def _normalize_dynamic_marker_fcurve(fcurve):
    if fcurve is None:
        return False
    changed = False
    for key in fcurve.keyframe_points:
        if key.interpolation != "CONSTANT":
            key.interpolation = "CONSTANT"
            changed = True
        if key.handle_left_type != "AUTO":
            key.handle_left_type = "AUTO"
            changed = True
        if key.handle_right_type != "AUTO":
            key.handle_right_type = "AUTO"
            changed = True
    if changed:
        fcurve.update()
    return changed


def _set_dynamic_marker_value(action, data_path, frame, value):
    changed = False
    for fcurve in _fcurves_find_all(action, data_path):
        key = _fcurve_key_at(fcurve, int(frame))
        if key is None:
            continue
        value_changed = False
        if abs(float(key.co.y) - float(value)) > 1.0e-6:
            key.co.y = float(value)
            changed = True
            value_changed = True
        normalized = _normalize_dynamic_marker_fcurve(fcurve)
        if value_changed and not normalized:
            fcurve.update()
        changed = normalized or changed
    return changed


def _managed_unparent_segments(pose_bone):
    segments = []
    for constraint in _internal_space_constraints(pose_bone):
        source = _dynamic_space_source(pose_bone, constraint)
        if not source.startswith(SPACE_SOURCE_UNPARENT_PREFIX):
            continue
        if _dynamic_space_role(pose_bone, constraint) != SPACE_ROLE_UNPARENT:
            continue
        start, end = _stored_dynamic_parent_constraint_segment(
            pose_bone,
            constraint,
        )
        try:
            source_start = int(source.split(":", 1)[1])
        except (IndexError, TypeError, ValueError):
            source_start = start
        if source_start is None:
            continue
        segments.append(
            {
                "source": source,
                "start": int(source_start),
                "end": int(end) if end is not None else None,
            }
        )
    segments.sort(key = lambda segment: segment["start"])
    return segments


def _remove_dynamic_marker_pair(action, data_path, start, end = None):
    frames = {int(start)}
    if end is not None:
        frames.add(int(end))
    removed = False
    for fcurve in list(_fcurves_find_all(action, data_path)):
        for key in list(fcurve.keyframe_points):
            if int(round(float(key.co.x))) not in frames:
                continue
            fcurve.keyframe_points.remove(key)
            removed = True
        if not fcurve.keyframe_points:
            _action_remove_fcurve(action, fcurve)
        else:
            fcurve.update()
    return removed


def _prune_orphan_unparent_markers(action, bone_name):
    if action is None:
        return False

    data_path = _unparent_dp(bone_name)
    points = _unparent_points(action, bone_name)
    active = False
    orphan_frames = set()
    for frame, value in points:
        next_active = float(value) >= 0.5
        if next_active:
            active = True
        elif active:
            active = False
        else:
            orphan_frames.add(int(frame))

    if not orphan_frames:
        return False

    changed = False
    for fcurve in list(_fcurves_find_all(action, data_path)):
        for key in list(fcurve.keyframe_points):
            if int(round(float(key.co.x))) not in orphan_frames:
                continue
            fcurve.keyframe_points.remove(key)
            changed = True
        if not fcurve.keyframe_points:
            _action_remove_fcurve(action, fcurve)
        else:
            fcurve.update()
    return changed


def _prune_orphan_dynamic_parent_markers(action, owner):
    if action is None or owner is None:
        return False

    changed = False
    for constraint in getattr(owner, "constraints", ()):
        if not constraint.name.startswith("DP_"):
            continue
        try:
            data_path = constraint.path_from_id("influence")
        except (AttributeError, TypeError, ValueError):
            continue
        fcurve = _fcurve_find(action, data_path)
        if fcurve is None or any(
            float(key.co.y) > 0.5 for key in fcurve.keyframe_points
        ):
            continue
        changed = _action_remove_fcurve(action, fcurve) or changed
    return changed


def _prune_orphan_dynamic_markers():
    changed = False
    for armature in tuple(bpy.data.objects):
        action = armature.animation_data.action if armature.animation_data else None
        if action is None:
            continue
        changed = _prune_orphan_dynamic_parent_markers(
            action,
            armature,
        ) or changed
        if armature.type != "ARMATURE" or getattr(armature, "pose", None) is None:
            continue
        for pose_bone in armature.pose.bones:
            changed = _prune_orphan_unparent_markers(
                action,
                pose_bone.name,
            ) or changed
            changed = _prune_orphan_dynamic_parent_markers(
                action,
                pose_bone,
            ) or changed
    return changed


def _remove_pose_dynamic_parent_segment(
    context,
    armature,
    pose_bone,
    constraint,
):
    start, _end = _stored_dynamic_parent_constraint_segment(
        pose_bone,
        constraint,
    )
    action = armature.animation_data.action if armature.animation_data else None
    try:
        influence_path = constraint.path_from_id("influence")
    except (AttributeError, TypeError, ValueError):
        influence_path = ""
    if action is not None and influence_path:
        for fcurve in list(_fcurves_find_all(action, influence_path)):
            _action_remove_fcurve(action, fcurve)

    if start is not None:
        _remove_pose_space_source(
            pose_bone,
            _space_constraint_source_for_dynamic_parent(constraint, start),
        )
    for property_name in _dp_auto_unparent_property_names(constraint):
        if property_name in pose_bone:
            del pose_bone[property_name]
    _remove_dynamic_parent_constraint_metadata(pose_bone, constraint)
    try:
        pose_bone.constraints.remove(constraint)
    except (ReferenceError, RuntimeError, ValueError):
        return False
    context.view_layer.update()
    return True


def _reconcile_dynamic_parent_space_source(
    pose_bone,
    constraint,
    stored_start,
    curve_start,
    curve_end,
):
    sources = {
        _space_constraint_source_for_dynamic_parent(constraint, int(start))
        for start in (stored_start, curve_start)
        if start is not None
    }
    if not sources:
        return False

    if curve_end is None:
        changed = False
        for source in sources:
            changed = _remove_pose_space_source(pose_bone, source) or changed
        return changed

    new_source = _space_constraint_source_for_dynamic_parent(
        constraint,
        int(curve_start),
    )
    changed = False
    for space_constraint in _internal_space_constraints(pose_bone):
        if _dynamic_space_source(pose_bone, space_constraint) not in sources:
            continue
        if _dynamic_space_source(pose_bone, space_constraint) != new_source:
            _store_dynamic_space_source(
                pose_bone,
                space_constraint,
                new_source,
            )
            changed = True
        current_start, current_end = _stored_dynamic_parent_constraint_segment(
            pose_bone,
            space_constraint,
        )
        adjusted_end = current_end
        if adjusted_end is not None and int(adjusted_end) <= int(curve_end):
            adjusted_end = None
        if (
            current_start is None
            or int(current_start) != int(curve_end)
            or adjusted_end != current_end
        ):
            _store_dynamic_parent_constraint_segment(
                pose_bone,
                space_constraint,
                int(curve_end),
                adjusted_end,
            )
            changed = True
    return changed


def _reconcile_pose_bone_dynamic_markers(context, armature, bone_name):
    pose_bone = armature.pose.bones.get(bone_name)
    if pose_bone is None:
        return False
    action = armature.animation_data.action if armature.animation_data else None
    changed = False

    for constraint in list(pose_bone.constraints):
        if not constraint.name.startswith("DP_"):
            continue
        stored_start, stored_end = _stored_dynamic_parent_constraint_segment(
            pose_bone,
            constraint,
        )
        curve_start, curve_end = _dynamic_parent_constraint_segment(
            pose_bone,
            constraint,
        )
        if curve_start is not None:
            try:
                influence_path = constraint.path_from_id("influence")
            except (AttributeError, TypeError, ValueError):
                influence_path = ""
            if action is not None and influence_path:
                for fcurve in _fcurves_find_all(action, influence_path):
                    changed = _normalize_dynamic_marker_fcurve(fcurve) or changed
            changed = _reconcile_dynamic_parent_space_source(
                pose_bone,
                constraint,
                stored_start,
                curve_start,
                curve_end,
            ) or changed
            if (stored_start, stored_end) != (curve_start, curve_end):
                _store_dynamic_parent_constraint_segment(
                    pose_bone,
                    constraint,
                    int(curve_start),
                    int(curve_end) if curve_end is not None else None,
                )
                changed = True
            continue
        changed = _remove_pose_dynamic_parent_segment(
            context,
            armature,
            pose_bone,
            constraint,
        ) or changed
        pose_bone = armature.pose.bones.get(bone_name)
        if pose_bone is None:
            return changed

    valid_dp_sources = set()
    valid_dp_paths = set()
    for constraint in pose_bone.constraints:
        if not constraint.name.startswith("DP_"):
            continue
        start, _end = _stored_dynamic_parent_constraint_segment(
            pose_bone,
            constraint,
        )
        if start is not None:
            valid_dp_sources.add(
                _space_constraint_source_for_dynamic_parent(constraint, start)
            )
        try:
            valid_dp_paths.add(constraint.path_from_id("influence"))
        except (AttributeError, TypeError, ValueError):
            pass

    for source in {
        _dynamic_space_source(pose_bone, constraint)
        for constraint in _internal_space_constraints(pose_bone)
        if _dynamic_space_source(pose_bone, constraint).startswith(
            SPACE_SOURCE_DYNAMIC_PARENT_PREFIX
        )
    } - valid_dp_sources:
        changed = _remove_pose_space_source(pose_bone, source) or changed

    if action is not None:
        try:
            constraint_prefix = pose_bone.path_from_id() + '.constraints["DP_'
        except (AttributeError, TypeError, ValueError):
            constraint_prefix = ""
        if constraint_prefix:
            for fcurve in list(_action_fcurves(action, armature)):
                if (
                    fcurve.data_path.startswith(constraint_prefix)
                    and fcurve.data_path.endswith(".influence")
                    and fcurve.data_path not in valid_dp_paths
                ):
                    changed = _action_remove_fcurve(action, fcurve) or changed

    data_path = _unparent_dp(bone_name)
    while True:
        segments = _managed_unparent_segments(pose_bone)
        starts = {segment["start"] for segment in segments}
        invalid = []
        for segment in segments:
            start_value = _dynamic_marker_value(
                action,
                data_path,
                segment["start"],
            ) if action is not None else None
            valid = bool(start_value is not None and start_value >= 0.5)
            if valid and segment["end"] is not None:
                end_value = _dynamic_marker_value(
                    action,
                    data_path,
                    segment["end"],
                ) if action is not None else None
                if segment["end"] in starts:
                    valid = bool(end_value is not None and end_value >= 0.5)
                else:
                    valid = bool(end_value is not None and end_value < 0.5)
            if not valid:
                invalid.append(segment)
        if not invalid:
            break
        for segment in invalid:
            if action is not None:
                changed = _remove_dynamic_marker_pair(
                    action,
                    data_path,
                    segment["start"],
                    segment["end"],
                ) or changed
            changed = _remove_pose_space_source(
                pose_bone,
                segment["source"],
            ) or changed

    segments = _managed_unparent_segments(pose_bone)
    valid_unparent_sources = {segment["source"] for segment in segments}
    for source in {
        _dynamic_space_source(pose_bone, constraint)
        for constraint in _internal_space_constraints(pose_bone)
        if _dynamic_space_source(pose_bone, constraint).startswith(
            SPACE_SOURCE_UNPARENT_PREFIX
        )
    } - valid_unparent_sources:
        changed = _remove_pose_space_source(pose_bone, source) or changed

    if action is not None:
        starts = {segment["start"] for segment in segments}
        shared_boundaries = {
            segment["end"]
            for segment in segments
            if segment["end"] is not None and segment["end"] in starts
        }
        for frame in shared_boundaries:
            changed = _set_dynamic_marker_value(
                action,
                data_path,
                frame,
                UNP_SPLIT_VALUE,
            ) or changed
        for frame in starts - shared_boundaries:
            value = _dynamic_marker_value(action, data_path, frame)
            if value is not None and value >= UNP_SPLIT_VALUE - 0.5:
                changed = _set_dynamic_marker_value(
                    action,
                    data_path,
                    frame,
                    1.0,
                ) or changed

        expected_frames = starts | {
            segment["end"]
            for segment in segments
            if segment["end"] is not None
        }
        for fcurve in list(_fcurves_find_all(action, data_path)):
            for key in list(fcurve.keyframe_points):
                if int(round(float(key.co.x))) in expected_frames:
                    continue
                fcurve.keyframe_points.remove(key)
                changed = True
            if not fcurve.keyframe_points:
                changed = _action_remove_fcurve(action, fcurve) or changed
            else:
                fcurve.update()

    has_dynamic_parent = any(
        constraint.name.startswith("DP_")
        for constraint in pose_bone.constraints
    )
    has_unparent = bool(_managed_unparent_segments(pose_bone))
    if not has_unparent and action is not None:
        for fcurve in list(_fcurves_find_all(action, data_path)):
            changed = _action_remove_fcurve(action, fcurve) or changed
    if not has_dynamic_parent and not has_unparent:
        changed = _teardown_pose_space_system(
            context,
            armature,
            pose_bone,
        ) or changed
    return changed


def _reconcile_dynamic_space_markers(context, armature = None):
    if _state.get("dynamic_space_reconciling", False):
        return False
    _state["dynamic_space_reconciling"] = True
    try:
        marker_changed = _prune_orphan_dynamic_markers()
        marker_changed = (
            _reconcile_surface_contact_markers(context, armature)
            or marker_changed
        )
        armatures = (
            (armature,)
            if armature is not None
            else tuple(
                obj
                for obj in bpy.data.objects
                if obj.type == "ARMATURE" and getattr(obj, "pose", None) is not None
            )
        )
        for current_armature in armatures:
            if current_armature is None or getattr(current_armature, "pose", None) is None:
                continue
            bone_names = tuple(
                pose_bone.name
                for pose_bone in current_armature.pose.bones
                if any(
                    _is_dynamic_state_constraint(constraint)
                    for constraint in pose_bone.constraints
                )
            )
            for bone_name in bone_names:
                marker_changed = _reconcile_pose_bone_dynamic_markers(
                    context,
                    current_armature,
                    bone_name,
                ) or marker_changed
        frame = int(context.scene.frame_current)
        calibrated = _calibrate_dynamic_space_boundaries(
            context,
            frame,
            armature,
        )
        changed = _sync_dynamic_parent_constraints(frame, armature)
        changed = bool(marker_changed or calibrated or changed)
        if changed:
            context.view_layer.update()
            _tag_redraw_all_view3d()
        return changed
    finally:
        _state["dynamic_space_reconciling"] = False


def _dynamic_parent_pose_target(context, armature, child_bone):
    selected_children = tuple(context.selected_pose_bones or ())
    if child_bone is None or child_bone not in selected_children:
        return (None, "", "Select the child bone")

    selected_objects = tuple(context.selected_objects or ())
    other_objects = tuple(obj for obj in selected_objects if obj != armature)
    if other_objects:
        if len(selected_children) != 1 or len(other_objects) != 1:
            return (None, "", "Select one child bone and one target object")
        target = other_objects[0]
        subtarget = ""
        if target.type == "ARMATURE":
            selected_targets = tuple(
                pose_bone
                for pose_bone in target.pose.bones
                if bool(
                    getattr(
                        pose_bone,
                        "select",
                        getattr(pose_bone.bone, "select", False),
                    )
                )
            )
            if len(selected_targets) != 1:
                return (None, "", "Select exactly one target bone")
            subtarget = selected_targets[0].name
        return (target, subtarget, "")

    selected_bones = tuple(
        pose_bone
        for pose_bone in (context.selected_pose_bones or ())
        if pose_bone != child_bone
    )
    if len(selected_children) != 2 or len(selected_bones) != 1:
        return (None, "", "Select exactly two bones")
    return (armature, selected_bones[0].name, "")


def _create_pose_dynamic_parent(
    context,
    armature,
    pose_bone,
    target,
    subtarget,
    frame,
):
    pose_bone = _ensure_pose_space_system(
        context,
        armature,
        pose_bone,
        frame,
    )
    if pose_bone is None:
        return None
    desired_factor = _pose_space_factor(
        context,
        armature,
        pose_bone,
    )
    target_matrix = _pose_space_target_matrix(
        context,
        armature,
        target,
        subtarget,
    )
    constraint = pose_bone.constraints.new("CHILD_OF")
    target_label = target.name if target is not None else "Target"
    constraint.name = (
        f"DP_{target_label}.{subtarget}" if subtarget else f"DP_{target_label}"
    )
    constraint.target = target
    constraint.subtarget = subtarget
    constraint.inverse_matrix = target_matrix.inverted_safe() @ desired_factor
    _store_dynamic_parent_constraint_segment(
        pose_bone,
        constraint,
        int(frame),
    )
    _store_dynamic_parent_constraint_target(pose_bone, constraint)
    _mark_dynamic_parent_boundary_calibrated(
        pose_bone,
        constraint,
        int(frame),
    )
    constraint.influence = 1.0
    constraint.mute = False
    insert_keyframe_constraint(constraint, int(frame), pose_bone)
    _sync_dynamic_parent_constraints(int(frame), armature)
    context.view_layer.update()
    return constraint


def _end_pose_dynamic_parent(
    context,
    armature,
    pose_bone,
    constraint,
    frame,
    allow_split = True,
):
    if pose_bone is None or constraint is None:
        return False
    start_frame, existing_end = _dynamic_parent_constraint_segment(
        pose_bone,
        constraint,
    )
    start_frame = int(start_frame) if start_frame is not None else int(frame)
    existing_end = int(existing_end) if existing_end is not None else None
    if (
        allow_split
        and existing_end is not None
        and int(frame) + 1 < existing_end
    ):
        return _split_pose_dynamic_parent_segment(
            context,
            armature,
            pose_bone,
            constraint,
            int(frame),
            existing_end,
        )

    source = _space_constraint_source_for_dynamic_parent(
        constraint,
        start_frame,
    )
    replacing_existing_end = bool(
        existing_end is not None and int(frame) < existing_end
    )
    if replacing_existing_end:
        _remove_future_space_constraints(
            pose_bone,
            source,
            int(frame),
        )
    desired_factor = _pose_space_factor(
        context,
        armature,
        pose_bone,
    )
    _store_dynamic_parent_constraint_target(pose_bone, constraint)
    _store_dynamic_parent_constraint_segment(
        pose_bone,
        constraint,
        start_frame,
        int(frame),
    )
    constraint.influence = 0.0
    insert_keyframe_constraint(constraint, int(frame), pose_bone)
    if replacing_existing_end:
        action = armature.animation_data.action if armature.animation_data else None
        try:
            influence_path = constraint.path_from_id("influence")
        except (AttributeError, TypeError, ValueError):
            influence_path = ""
        if influence_path:
            _fcurve_remove_key_all(action, influence_path, existing_end)

    action = armature.animation_data.action if armature.animation_data else None
    unparented = _unparent_eval(
        action,
        pose_bone.name,
        int(frame),
        pb_default = _pb_prop_get(pose_bone, UNP_PROP, 0.0),
    ) >= 0.5
    parent_name = str(pose_bone.bone.get(REL_K_PARENT, ""))
    role = (
        SPACE_ROLE_UNPARENT
        if unparented
        else (SPACE_ROLE_NORMAL if parent_name else SPACE_ROLE_WORLD)
    )
    _switch_pose_underlying_space(
        context,
        armature,
        pose_bone,
        role,
        int(frame),
        desired_factor,
        source,
    )
    _sync_dynamic_parent_constraints(int(frame), armature)
    context.view_layer.update()
    return True


def _split_pose_dynamic_parent_segment(
    context,
    armature,
    pose_bone,
    constraint,
    split_frame,
    original_end,
):
    scene = context.scene
    saved_frame = int(scene.frame_current)
    previous_mute = bool(_state.get("unparent_handler_mute", False))
    target = _dynamic_parent_constraint_target(pose_bone, constraint)
    subtarget = str(constraint.subtarget)
    if target is None:
        return False

    _state["unparent_handler_mute"] = True
    try:
        if not _end_pose_dynamic_parent(
            context,
            armature,
            pose_bone,
            constraint,
            int(split_frame),
            allow_split = False,
        ):
            return False

        second_start = int(split_frame)
        scene.frame_set(second_start)
        _sync_dynamic_parent_constraints(second_start, armature)
        context.view_layer.update()
        pose_bone = armature.pose.bones.get(pose_bone.name)
        second_constraint = _create_pose_dynamic_parent(
            context,
            armature,
            pose_bone,
            target,
            subtarget,
            second_start,
        )
        if second_constraint is None:
            return False

        scene.frame_set(int(original_end))
        _sync_dynamic_parent_constraints(int(original_end), armature)
        context.view_layer.update()
        pose_bone = armature.pose.bones.get(pose_bone.name)
        return _end_pose_dynamic_parent(
            context,
            armature,
            pose_bone,
            second_constraint,
            int(original_end),
            allow_split = False,
        )
    finally:
        scene.frame_set(saved_frame)
        _sync_dynamic_parent_constraints(saved_frame, armature)
        context.view_layer.update()
        _state["unparent_handler_mute"] = previous_mute


def get_last_dynamic_parent_constraint(obj, frame = None):
    if obj is None or not getattr(obj, "constraints", None):
        return None
    if frame is None:
        frame = int(bpy.context.scene.frame_current)
    for constraint in reversed(obj.constraints):
        if (
            constraint.name.startswith("DP_")
            and _dynamic_parent_constraint_active_at(obj, constraint, frame)
        ):
            return constraint
    return None


def _dp_auto_unparent_property_name(constraint):
    name = str(getattr(constraint, "name", ""))
    digest = hashlib.sha1(name.encode("utf-8")).hexdigest()[:16]
    return f"{DP_AUTO_UNPARENT_PROPERTY_PREFIX}{digest}"


def _dp_auto_unparent_property_names(constraint):
    if constraint is None:
        return ()
    return (
        _dp_auto_unparent_property_name(constraint),
        f"{DP_AUTO_UNPARENT_START_KEY}::{constraint.name}",
    )


def _dp_auto_unparent_start(owner, constraint):
    if not isinstance(owner, bpy.types.PoseBone) or constraint is None:
        return None
    for property_name in _dp_auto_unparent_property_names(constraint):
        try:
            value = owner.get(property_name, None)
            if value is not None:
                segment_start, _segment_end = (
                    _dynamic_parent_constraint_segment(owner, constraint)
                )
                return int(segment_start) if segment_start is not None else int(value)
        except (AttributeError, KeyError, TypeError, ValueError):
            continue
    return None


def _dp_auto_unparent_start_frames(owner):
    if not isinstance(owner, bpy.types.PoseBone):
        return set()

    prefixes = (
        DP_AUTO_UNPARENT_PROPERTY_PREFIX,
        f"{DP_AUTO_UNPARENT_START_KEY}::",
    )
    frames = set()
    matched_properties = set()
    for constraint in getattr(owner, "constraints", ()):
        if not constraint.name.startswith("DP_"):
            continue
        property_names = _dp_auto_unparent_property_names(constraint)
        if not any(property_name in owner for property_name in property_names):
            continue
        matched_properties.update(property_names)
        start_frame, _end_frame = _dynamic_parent_constraint_segment(
            owner,
            constraint,
        )
        if start_frame is not None:
            frames.add(int(start_frame))

    try:
        property_names = tuple(owner.keys())
    except (AttributeError, TypeError):
        return frames

    for property_name in property_names:
        if not str(property_name).startswith(prefixes):
            continue
        if property_name in matched_properties:
            continue
        try:
            frames.add(int(owner[property_name]))
        except (KeyError, TypeError, ValueError):
            continue
    return frames


def _action_channelbags(action, animated_id = None):
    if action is None or hasattr(action, "fcurves"):
        return ()

    target_handle = None
    animation_data = getattr(animated_id, "animation_data", None)
    if animation_data is not None and animation_data.action is action:
        target_handle = int(getattr(animation_data, "action_slot_handle", 0) or 0)

    channelbags = []
    for layer in getattr(action, "layers", ()):
        for strip in getattr(layer, "strips", ()):
            if getattr(strip, "type", "") != "KEYFRAME":
                continue
            for channelbag in getattr(strip, "channelbags", ()):
                if (
                    target_handle
                    and int(getattr(channelbag, "slot_handle", 0)) != target_handle
                ):
                    continue
                channelbags.append(channelbag)

    if target_handle and not channelbags:
        return _action_channelbags(action)
    return tuple(channelbags)


def _action_fcurves(action, animated_id = None):
    if action is None:
        return ()
    legacy_fcurves = getattr(action, "fcurves", None)
    if legacy_fcurves is not None:
        return tuple(legacy_fcurves)
    return tuple(
        fcurve
        for channelbag in _action_channelbags(action, animated_id)
        for fcurve in channelbag.fcurves
    )


def _action_remove_fcurve(action, fcurve):
    if action is None or fcurve is None:
        return False
    legacy_fcurves = getattr(action, "fcurves", None)
    if legacy_fcurves is not None:
        try:
            legacy_fcurves.remove(fcurve)
            return True
        except (RuntimeError, ValueError):
            return False

    for channelbag in _action_channelbags(action):
        channel_curves = tuple(channelbag.fcurves)
        try:
            target_pointer = int(fcurve.as_pointer())
        except (AttributeError, ReferenceError):
            target_pointer = 0
        candidate = next(
            (
                curve
                for curve in channel_curves
                if curve is fcurve
                or (
                    target_pointer
                    and int(curve.as_pointer()) == target_pointer
                )
            ),
            None,
        )
        if candidate is None:
            continue
        channelbag.fcurves.remove(candidate)
        return True
    return False


def _action_group_owners(action):
    if action is None:
        return ()
    legacy_groups = getattr(action, "groups", None)
    if legacy_groups is not None:
        return (legacy_groups,)
    return tuple(channelbag.groups for channelbag in _action_channelbags(action))


def _action_ensure_channelbag(action, animated_id):
    if action is None or animated_id is None or hasattr(action, "fcurves"):
        return None

    animation_data = getattr(animated_id, "animation_data", None)
    if animation_data is None:
        animation_data = animated_id.animation_data_create()

    slot = None
    if animation_data.action is action:
        slot = getattr(animation_data, "action_slot", None)
    if slot is None:
        suitable_slots = tuple(getattr(animation_data, "action_suitable_slots", ()))
        slot = suitable_slots[0] if suitable_slots else None
    if slot is None:
        slot = action.slots.new(animated_id.id_type, animated_id.name)
    if animation_data.action is action and animation_data.action_slot is not slot:
        animation_data.action_slot = slot

    for layer in action.layers:
        for strip in layer.strips:
            if getattr(strip, "type", "") != "KEYFRAME":
                continue
            channelbag = strip.channelbag(slot)
            if channelbag is not None:
                return channelbag

    layer = action.layers[0] if action.layers else action.layers.new("Layer")
    strip = next(
        (
            candidate
            for candidate in layer.strips
            if getattr(candidate, "type", "") == "KEYFRAME"
        ),
        None,
    )
    if strip is None:
        strip = layer.strips.new(type = "KEYFRAME")
    return strip.channelbag(slot, ensure = True)


def _action_new_fcurve(action, data_path, animated_id = None, index = 0):
    legacy_fcurves = getattr(action, "fcurves", None)
    if legacy_fcurves is not None:
        return legacy_fcurves.new(data_path, index = int(index))

    channelbag = _action_ensure_channelbag(action, animated_id)
    if channelbag is None:
        raise RuntimeError("Unable to create an animation channel for this Action.")
    return channelbag.fcurves.new(data_path = data_path, index = int(index))


def _set_keyframe_handles_auto(target, frame):
    id_data = getattr(target, "id_data", None) or target
    animation_data = getattr(id_data, "animation_data", None)
    action = getattr(animation_data, "action", None)
    if action is None:
        return 0

    changed = 0
    target_frame = float(frame)
    target_path = ""
    if target is not id_data:
        try:
            target_path = target.path_from_id()
        except (AttributeError, TypeError, ValueError):
            target_path = ""
    for fcurve in _action_fcurves(action, id_data):
        if target_path and not (
            fcurve.data_path == target_path
            or fcurve.data_path.startswith(target_path + ".")
            or fcurve.data_path.startswith(target_path + "[")
        ):
            continue
        curve_changed = False
        for key in fcurve.keyframe_points:
            if abs(float(key.co.x) - target_frame) > 1.0e-5:
                continue
            if key.handle_left_type != "AUTO":
                key.handle_left_type = "AUTO"
                changed += 1
                curve_changed = True
            if key.handle_right_type != "AUTO":
                key.handle_right_type = "AUTO"
                changed += 1
                curve_changed = True
        if curve_changed:
            fcurve.update()
    return changed


def _set_fcurve_key_interpolation(target, data_path, frame, interpolation):
    id_data = getattr(target, "id_data", None) or target
    animation_data = getattr(id_data, "animation_data", None)
    action = getattr(animation_data, "action", None)
    if action is None:
        return 0

    changed = 0
    target_frame = float(frame)
    for fcurve in _action_fcurves(action, id_data):
        if fcurve.data_path != data_path:
            continue
        for key in fcurve.keyframe_points:
            if abs(float(key.co.x) - target_frame) > 1.0e-5:
                continue
            key.interpolation = interpolation
            changed += 1
        fcurve.update()
    return changed


def insert_keyframe(obj, frame):
    rotation_mode = get_rotation_mode(obj)
    data_paths = (
        "location",
        f"rotation_{rotation_mode}",
        "scale",
    )
    for data_path in data_paths:
        obj.keyframe_insert(data_path = data_path, frame = frame)
    _set_keyframe_handles_auto(obj, frame)


def _insert_evaluated_transform_key(obj, frame):
    scene = bpy.context.scene
    saved_frame = int(scene.frame_current)
    try:
        if saved_frame != int(frame):
            scene.frame_set(int(frame))
            bpy.context.view_layer.update()
        insert_keyframe(obj, int(frame))
    finally:
        if int(scene.frame_current) != saved_frame:
            scene.frame_set(saved_frame)
            bpy.context.view_layer.update()

def insert_keyframe_constraint(constraint, frame, owner = None):
    constraint.keyframe_insert(data_path = "influence", frame = frame)
    _set_keyframe_handles_auto(constraint, frame)
    _set_fcurve_key_interpolation(
        constraint,
        constraint.path_from_id("influence"),
        frame,
        "CONSTANT",
    )
    if owner is not None:
        _set_dynamic_parent_fcurve_group(owner, constraint)

def dp_keyframe_insert_obj(obj):
    obj.keyframe_insert(data_path = "location")
    if obj.rotation_mode == "QUATERNION":
        obj.keyframe_insert(data_path = "rotation_quaternion")
    elif obj.rotation_mode == "AXIS_ANGLE":
        obj.keyframe_insert(data_path = "rotation_axis_angle")
    else:
        obj.keyframe_insert(data_path = "rotation_euler")
    obj.keyframe_insert(data_path = "scale")
    _set_keyframe_handles_auto(obj, bpy.context.scene.frame_current)

def dp_keyframe_insert_pbone(arm, pbone):
    arm.keyframe_insert(data_path = 'pose.bones["' + pbone.name + '"].location')
    if pbone.rotation_mode == "QUATERNION":
        arm.keyframe_insert(
            data_path = 'pose.bones["' + pbone.name + '"].rotation_quaternion'
        )
    elif pbone.rotation_mode == "AXIS_ANGLE":
        arm.keyframe_insert(
            data_path = 'pose.bones["' + pbone.name + '"].rotation_axis_angle'
        )
    else:
        arm.keyframe_insert(data_path = 'pose.bones["' + pbone.name + '"].rotation_euler')
    arm.keyframe_insert(data_path = 'pose.bones["' + pbone.name + '"].scale')
    _set_keyframe_handles_auto(pbone, bpy.context.scene.frame_current)

def dp_create_dynamic_parent_obj(op):
    obj = bpy.context.active_object
    scn = bpy.context.scene
    list_selected_obj = bpy.context.selected_objects

    if len(list_selected_obj) == 2:
        i = list_selected_obj.index(obj)
        list_selected_obj.pop(i)
        parent_obj = list_selected_obj[0]

        dp_keyframe_insert_obj(obj)
        bpy.ops.object.constraint_add_with_targets(type = "CHILD_OF")
        last_constraint = obj.constraints[-1]

        if parent_obj.type == "ARMATURE":
            last_constraint.subtarget = parent_obj.data.bones.active.name
            last_constraint.name = "DP_" + last_constraint.target.name + "." + last_constraint.subtarget
        else:
            last_constraint.name = "DP_" + last_constraint.target.name

        C = bpy.context.copy()
        C["constraint"] = last_constraint
        bpy.ops.constraint.childof_set_inverse(
            constraint = last_constraint.name,
            owner = "OBJECT"
        )

        current_frame = int(scn.frame_current)
        _store_dynamic_parent_constraint_segment(
            obj,
            last_constraint,
            current_frame,
        )
        _store_dynamic_parent_constraint_target(obj, last_constraint)
        obj.constraints[last_constraint.name].influence = 1
        last_constraint.mute = False
        insert_keyframe_constraint(last_constraint, current_frame, obj)

        for ob in list_selected_obj:
            ob.select_set(False)

        obj.select_set(True)
    else:
        op.report({"ERROR"}, "Two objects must be selected")

def dp_create_dynamic_parent_pbone(op):
    arm = bpy.context.active_object
    pbone = bpy.context.active_pose_bone
    scn = bpy.context.scene
    list_selected_obj = bpy.context.selected_objects

    if len(list_selected_obj) == 2 or len(list_selected_obj) == 1:
        if len(list_selected_obj) == 2:
            i = list_selected_obj.index(arm)
            list_selected_obj.pop(i)
            parent_obj = list_selected_obj[0]
            if parent_obj.type == "ARMATURE":
                parent_obj_pbone = parent_obj.data.bones.active
                parent_pose_bone = (
                    parent_obj.pose.bones.get(parent_obj_pbone.name)
                    if parent_obj_pbone is not None
                    else None
                )
                parent_selected = bool(
                    getattr(
                        parent_obj_pbone,
                        "select",
                        getattr(parent_pose_bone, "select", False),
                    )
                )
                if not parent_selected:
                    op.report({"ERROR"}, "At least two bones must be selected")
                    return
        else:
            parent_obj = arm
            selected_bones = bpy.context.selected_pose_bones
            selected_bones.remove(pbone)
            if not selected_bones:
                op.report({"ERROR"}, "At least two bones must be selected")
                return
            parent_obj_pbone = selected_bones[0]

        dp_keyframe_insert_pbone(arm, pbone)
        bpy.ops.pose.constraint_add_with_targets(type = "CHILD_OF")
        last_constraint = pbone.constraints[-1]

        if parent_obj.type == "ARMATURE":
            last_constraint.subtarget = parent_obj_pbone.name
            last_constraint.name = "DP_" + last_constraint.target.name + "." + last_constraint.subtarget
        else:
            last_constraint.name = "DP_" + last_constraint.target.name

        C = bpy.context.copy()
        C["constraint"] = last_constraint
        bpy.ops.constraint.childof_set_inverse(
            constraint = last_constraint.name,
            owner = "BONE"
        )

        current_frame = int(scn.frame_current)
        _store_dynamic_parent_constraint_segment(
            pbone,
            last_constraint,
            current_frame,
        )
        _store_dynamic_parent_constraint_target(pbone, last_constraint)
        pbone.constraints[last_constraint.name].influence = 1
        last_constraint.mute = False
        insert_keyframe_constraint(last_constraint, current_frame, pbone)
    else:
        op.report({"ERROR"}, "Two objects must be selected")

def disable_constraint(obj, const, frame):
    if isinstance(obj, bpy.types.PoseBone):
        matrix_final = obj.matrix.copy()
    else:
        matrix_final = obj.matrix_world.copy()

    frame = int(frame)
    start_frame, _end_frame = _dynamic_parent_constraint_segment(obj, const)
    _store_dynamic_parent_constraint_segment(
        obj,
        const,
        start_frame if start_frame is not None else frame,
        frame,
    )
    const.influence = 0
    if isinstance(obj, bpy.types.PoseBone):
        obj.matrix = matrix_final
    else:
        obj.matrix_world = matrix_final

    insert_keyframe(obj, frame)
    insert_keyframe_constraint(const, frame, obj)
    const.mute = True
    return

def _dp_curve_distance_from_frame(fcurve, frame):
    points = sorted(
        (
            int(round(float(key.co.x))),
            float(key.co.y),
        )
        for key in fcurve.keyframe_points
    )
    if not points:
        return float("inf")

    active_frames = [point_frame for point_frame, value in points if value > 0.5]
    if not active_frames:
        return min(abs(int(frame) - point_frame) for point_frame, _ in points)

    start_frame = min(active_frames)
    end_candidates = [
        point_frame
        for point_frame, value in points
        if point_frame > start_frame and value <= 0.5
    ]
    end_frame = min(end_candidates) if end_candidates else max(active_frames)
    if start_frame <= int(frame) <= end_frame:
        return 0
    return min(abs(int(frame) - start_frame), abs(int(frame) - end_frame))


def _dp_constraint_active_start_frame(action, constraint, frame):
    if action is None or constraint is None:
        return None
    try:
        data_path = constraint.path_from_id("influence")
    except Exception:
        return None
    fcurve = _fcurve_find(action, data_path)
    if fcurve is None:
        return None

    active = False
    active_start = None
    for key in sorted(fcurve.keyframe_points, key = lambda point: point.co.x):
        key_frame = int(round(float(key.co.x)))
        if key_frame > int(frame):
            break
        next_active = float(key.co.y) > 0.5
        if next_active and not active:
            active_start = key_frame
        elif active and not next_active:
            active_start = None
        active = next_active
    return int(active_start) if active and active_start is not None else None


def dp_clear(obj, pbone):
    if not obj:
        return False

    target = pbone if pbone else obj
    frame = int(bpy.context.scene.frame_current)
    constraint = get_last_dynamic_parent_constraint(target, frame)
    if constraint is None:
        return False

    action = obj.animation_data.action if obj.animation_data else None
    start_frame, end_frame = _dynamic_parent_constraint_segment(target, constraint)
    start_frame = int(start_frame) if start_frame is not None else frame

    if pbone is not None and _pose_space_managed(pbone):
        removed = _remove_pose_dynamic_parent_segment(
            bpy.context,
            obj,
            pbone,
            constraint,
        )
        pbone = obj.pose.bones.get(pbone.name)
        has_unparent = bool(
            pbone is not None and _managed_unparent_segments(pbone)
        )
        has_dynamic_parent = bool(
            pbone is not None
            and any(
                current.name.startswith("DP_")
                for current in pbone.constraints
            )
        )
        if pbone is not None and not has_unparent and not has_dynamic_parent:
            _teardown_pose_space_system(bpy.context, obj, pbone)
        _sync_dynamic_parent_constraints(frame, obj)
        bpy.context.view_layer.update()
        return bool(removed)

    auto_unparent_start = _dp_auto_unparent_start(pbone, constraint)
    auto_unparent_properties = (
        _dp_auto_unparent_property_names(constraint)
        if auto_unparent_start is not None
        else ()
    )
    object_matrix = target.matrix_world.copy() if pbone is None else None

    captured = None
    if pbone is not None and action is not None:
        captured = _capture_pose_world_matrices_with_arm_mw(
            bpy.context,
            obj,
            pbone.name,
            _transition_key_frames(
                action,
                pbone.name,
                start_frame,
                end_exclusive = end_frame,
            ),
        )

    fcurve = None
    if action is not None:
        try:
            fcurve = _fcurve_find(action, constraint.path_from_id("influence"))
        except (AttributeError, TypeError, ValueError):
            pass
    if fcurve is not None:
        _action_remove_fcurve(action, fcurve)

    _remove_dynamic_parent_constraint_metadata(target, constraint)
    target.constraints.remove(constraint)

    if pbone is None and object_matrix is not None:
        target.matrix_world = object_matrix
        insert_keyframe(target, frame)

    if pbone is not None and auto_unparent_start is not None and action is not None:
        auto_unparent_end = _unparent_find_end_frame(
            action,
            pbone.name,
            int(auto_unparent_start),
        )
        _unparent_delete_segment_markers(
            action,
            pbone.name,
            int(auto_unparent_start),
            auto_unparent_end,
        )
        for property_name in auto_unparent_properties:
            if property_name in pbone:
                del pbone[property_name]

    if pbone is not None and captured:
        current_bone = obj.pose.bones.get(pbone.name)
        if current_bone is not None:
            has_markers = _unparent_has_marker_keys(action, current_bone.name)
            _pb_prop_set(
                current_bone,
                UNP_PROP,
                _unparent_eval(
                    action,
                    current_bone.name,
                    frame,
                    0.0,
                ) if has_markers else 0.0,
            )
        _restore_pose_world_span(bpy.context, obj, pbone.name, captured)
        current_bone = obj.pose.bones.get(pbone.name)
        if current_bone is not None and not _unparent_has_marker_keys(
            action,
            current_bone.name,
        ):
            _unparent_remove_visual_constraint(current_bone)
            if UNP_PROP in current_bone:
                del current_bone[UNP_PROP]
            _unparent_clear_start_frame(current_bone)
    return True

def _tag_redraw_all_view3d():
    wm = bpy.context.window_manager
    for window in wm.windows:
        for area in window.screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()

def _ensure_shader_3d():
    if _state["shader_3d"] is not None:
        return _state["shader_3d"]

    _state["last_error"] = ""
    try:
        _state["shader_3d"] = gpu.shader.from_builtin("UNIFORM_COLOR")
        _state["shader_3d_mode"] = "UNIFORM"
    except Exception:
        _state["shader_3d"] = gpu.shader.from_builtin("FLAT_COLOR")
        _state["shader_3d_mode"] = "VERTEX"

    return _state["shader_3d"]

def _ensure_shader_2d():
    if _state["shader_2d"] is not None:
        return _state["shader_2d"]

    vertex_body = """
    void main()
    {
        vec2 ndc = (pos / u_viewport) * 2.0 - 1.0;
        gl_Position = vec4(ndc.xy, 0.0, 1.0);
    }
    """
    fragment_body = """
    void main()
    {
        FragColor = color;
    }
    """
    try:
        shader_info = gpu.types.GPUShaderCreateInfo()
        shader_info.vertex_in(0, "VEC2", "pos")
        shader_info.push_constant("VEC2", "u_viewport")
        shader_info.push_constant("VEC4", "color")
        shader_info.fragment_out(0, "VEC4", "FragColor")
        shader_info.vertex_source(vertex_body)
        shader_info.fragment_source(fragment_body)
        _state["shader_2d"] = gpu.shader.create_from_info(shader_info)
    except Exception:
        legacy_vertex_source = "in vec2 pos;\nuniform vec2 u_viewport;\n" + vertex_body
        legacy_fragment_source = (
            "uniform vec4 color;\nout vec4 FragColor;\n" + fragment_body
        )
        _state["shader_2d"] = gpu.types.GPUShader(
            legacy_vertex_source,
            legacy_fragment_source,
        )
    return _state["shader_2d"]

def _as_p4(v):
    try:
        if isinstance(v, Vector):
            if len(v) == 4:
                return Vector((float(v.x), float(v.y), float(v.z), float(v.w)))
            if len(v) == 3:
                return Vector((float(v.x), float(v.y), float(v.z), 1.0))
    except Exception:
        pass

    if isinstance(v, (list, tuple)) and len(v) >= 3:
        try:
            return Vector((float(v[0]), float(v[1]), float(v[2]), 1.0))
        except Exception:
            pass

    return Vector((0.0, 0.0, 0.0, 1.0))

def _world_to_bone_local_p4(eval_arm, pb, world_point):
    arm_mw = eval_arm.matrix_world
    try:
        arm_inv = arm_mw.inverted()
    except Exception:
        arm_inv = Matrix.Identity(4)

    try:
        pb_inv = pb.matrix.inverted()
    except Exception:
        pb_inv = Matrix.Identity(4)

    return pb_inv @ (arm_inv @ _as_p4(world_point))

def _bone_local_to_world(eval_arm, pb, local_p4):
    arm_mw = eval_arm.matrix_world
    try:
        out = arm_mw @ (pb.matrix @ _as_p4(local_p4))
    except Exception:
        out = arm_mw @ _as_p4((0.0, 0.0, 0.0))
    return Vector((float(out.x), float(out.y), float(out.z)))

def _is_object_visible(obj, context):
    wm = getattr(context, "window_manager", None)
    scn = getattr(context, "scene", None)
    if wm and not getattr(wm, "onion_skin_skip_hidden", True):
        return True
    if not scn:
        return True
    if obj.hide_viewport:
        return False
    if obj.hide_get():
        return False
    try:
        if hasattr(obj, "visible_get"):
            return obj.visible_get(view_layer=context.view_layer)
    except TypeError:
        try:
            return obj.visible_get()
        except Exception:
            return True
    return True

def _active_armature(context):
    active_pose_bone = getattr(context, "active_pose_bone", None)
    if getattr(context, "mode", "") == "POSE" and active_pose_bone is not None:
        try:
            active_pointer = int(active_pose_bone.as_pointer())
        except (AttributeError, ReferenceError, TypeError, ValueError):
            active_pointer = 0
        try:
            pose_armatures = tuple(context.objects_in_mode or ())
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            pose_armatures = ()
        for armature in pose_armatures:
            if getattr(armature, "type", "") != "ARMATURE":
                continue
            candidate = getattr(getattr(armature, "pose", None), "bones", {}).get(
                str(active_pose_bone.name)
            )
            if candidate is None:
                continue
            try:
                if candidate == active_pose_bone or (
                    active_pointer and int(candidate.as_pointer()) == active_pointer
                ):
                    return armature
            except (AttributeError, ReferenceError, TypeError, ValueError):
                continue
    ob = context.active_object
    if ob and ob.type == "ARMATURE":
        return ob
    for ob in context.selected_objects:
        if ob.type == "ARMATURE":
            return ob
    ob = context.active_object
    if ob and hasattr(ob, "find_armature"):
        arm = ob.find_armature()
        if arm and arm.type == "ARMATURE":
            return arm
    return None


def _armature_session_uid(armature):
    if armature is None:
        return 0
    try:
        uid = int(armature.session_uid)
    except (AttributeError, ReferenceError, TypeError, ValueError):
        uid = 0
    if uid:
        return uid
    try:
        return int(armature.as_pointer())
    except (AttributeError, ReferenceError, TypeError, ValueError):
        return 0


def _armature_from_session_uid(session_uid):
    session_uid = int(session_uid or 0)
    if not session_uid:
        return None
    for obj in bpy.data.objects:
        if obj.type == "ARMATURE" and _armature_session_uid(obj) == session_uid:
            return obj
    return None


def _pose_scope_armatures(context):
    if context is None or getattr(context, "mode", "") != "POSE":
        return ()
    candidates = []
    try:
        candidates.extend(tuple(context.objects_in_mode or ()))
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        pass
    if not candidates:
        try:
            candidates.extend(tuple(context.selected_objects or ()))
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            pass
    active = _active_armature(context)
    if active is not None:
        candidates.insert(0, active)
    result = []
    seen = set()
    for armature in candidates:
        if (
            armature is None
            or getattr(armature, "type", "") != "ARMATURE"
            or getattr(armature, "mode", "") != "POSE"
        ):
            continue
        uid = _armature_session_uid(armature)
        if not uid or uid in seen:
            continue
        seen.add(uid)
        result.append(armature)
    return tuple(result)


def _pose_bone_owner(context, pose_bone, armatures = None):
    if pose_bone is None:
        return None
    candidates = tuple(armatures or _pose_scope_armatures(context))
    if not candidates:
        active = _active_armature(context) if context is not None else None
        candidates = (active,) if active is not None else ()
    candidate_uids = {
        _armature_session_uid(armature)
        for armature in candidates
        if armature is not None
    }
    candidates = tuple(candidates) + tuple(
            obj
            for obj in bpy.data.objects
            if (
                obj.type == "ARMATURE"
                and getattr(obj, "pose", None)
                and _armature_session_uid(obj) not in candidate_uids
            )
        )
    pointer = 0
    try:
        pointer = int(pose_bone.as_pointer())
    except (AttributeError, ReferenceError, TypeError, ValueError):
        pass
    for armature in candidates:
        if armature is None or getattr(armature, "pose", None) is None:
            continue
        candidate = armature.pose.bones.get(str(pose_bone.name))
        if candidate is None:
            continue
        try:
            if candidate == pose_bone or (pointer and candidate.as_pointer() == pointer):
                return armature
        except (AttributeError, ReferenceError, TypeError, ValueError):
            continue
    return None


def _owner_bone_key(armature, bone_name):
    return (_armature_session_uid(armature), str(bone_name))


def _yellow_owner_map(state_name, armature):
    uid = _armature_session_uid(armature)
    return {
        bone_name: value
        for (owner_uid, bone_name), value in _state.get(state_name, {}).items()
        if int(owner_uid) == uid
    }


def _yellow_replace_owner_map(state_name, armature, values):
    uid = _armature_session_uid(armature)
    combined = {
        key: value
        for key, value in _state.get(state_name, {}).items()
        if int(key[0]) != uid
    }
    combined.update(
        (((uid, str(name)), value) for name, value in values.items())
    )
    _state[state_name] = combined


def _yellow_owner_hidden(armature):
    return _armature_session_uid(armature) in _state.get("yellow_hidden", set())


def _yellow_set_owner_hidden(armature, hidden):
    owners = set(_state.get("yellow_hidden", set()))
    uid = _armature_session_uid(armature)
    if hidden:
        owners.add(uid)
    else:
        owners.discard(uid)
    _state["yellow_hidden"] = owners


def _onion_owner_enabled(armature):
    return _armature_session_uid(armature) in _state.get(
        "onion_enabled_owners",
        set(),
    )


def _set_onion_property(window_manager, enabled):
    if window_manager is None or not hasattr(window_manager, "onion_skin_enabled"):
        return
    _state["onion_property_syncing"] = True
    try:
        window_manager.onion_skin_enabled = bool(enabled)
    finally:
        _state["onion_property_syncing"] = False


def _targets(context, armature = None):
    arm = armature or _active_armature(context)
    items = []

    if arm and _is_object_visible(arm, context):
        items.append(arm)

    if not arm:
        return items, None

    for obj in context.view_layer.objects:
        if obj == arm:
            continue
        if not _is_object_visible(obj, context):
            continue

        include = False

        if obj.parent == arm:
            include = True
        if obj.parent_type == "BONE" and obj.parent == arm:
            include = True

        if not include:
            for m in obj.modifiers:
                if m.type == "ARMATURE" and getattr(m, "object", None) == arm:
                    include = True
                    break

        if not include:
            for c in obj.constraints:
                t = getattr(c, "target", None)
                st = getattr(c, "subtarget", "")
                if t == arm and st:
                    include = True
                    break
                if c.type == "CHILD_OF" and t == arm:
                    include = True
                    break
                if c.type == "COPY_TRANSFORMS" and t == arm:
                    include = True
                    break
                if c.type == "COPY_LOCATION" and t == arm:
                    include = True
                    break
                if c.type == "COPY_ROTATION" and t == arm:
                    include = True
                    break
                if c.type == "COPY_SCALE" and t == arm:
                    include = True
                    break

        if include:
            items.append(obj)

    return list(dict.fromkeys(items)), arm

def _is_unmovable(pb):
    locked_loc = all(pb.lock_location)
    locked_scale = all(pb.lock_scale)
    locked_rot = all(pb.lock_rotation)
    if hasattr(pb, "lock_rotation_w"):
        locked_rot = locked_rot and bool(pb.lock_rotation_w)
    return locked_loc and locked_rot and locked_scale


def _selected_bone_label_target(context):
    window_manager = getattr(context, "window_manager", None)
    if (
        window_manager is None
        or not getattr(window_manager, "show_bone_names_enabled", True)
        or getattr(context, "mode", "") != "POSE"
    ):
        return None, None

    armatures = _pose_scope_armatures(context)
    if not armatures:
        return None, None

    selected_by_owner = _selected_pose_bones_by_owner(context)
    active_bone = getattr(context, "active_pose_bone", None)
    active_armature = _pose_bone_owner(context, active_bone, armatures)
    if (
        active_armature is not None
        and active_bone in selected_by_owner.get(active_armature, ())
    ):
        return active_armature, active_bone

    selected = tuple(
        (armature, pose_bone)
        for armature, pose_bones in selected_by_owner.items()
        for pose_bone in pose_bones
    )
    return selected[0] if len(selected) == 1 else (None, None)


def _pose_bone_is_visible(pose_bone):
    bone = getattr(pose_bone, "bone", None)
    if bone is None or bool(getattr(bone, "hide", False)):
        return False

    collections = getattr(bone, "collections", ())
    if collections:
        visible_collections = (
            collection for collection in collections
            if bool(getattr(collection, "is_visible", True))
        )
        if not any(visible_collections):
            return False
    return True


def _pose_bone_is_label_root(pose_bone):
    return bool(
        pose_bone.parent is None
        and not str(pose_bone.bone.get(REL_K_PARENT, ""))
    )


def _custom_bone_label_targets(context):
    window_manager = getattr(context, "window_manager", None)
    if (
        window_manager is None
        or not getattr(window_manager, "show_bone_names_enabled", True)
        or getattr(context, "mode", "") != "POSE"
    ):
        return None, ()
    selected_armature, selected_bone = _selected_bone_label_target(context)
    if selected_armature is not None and selected_bone is not None:
        if not _pose_bone_is_visible(selected_bone):
            return selected_armature, ()
        return selected_armature, ((selected_armature, selected_bone),)
    return selected_armature, tuple(
        (armature, pose_bone)
        for armature in _pose_scope_armatures(context)
        for pose_bone in armature.pose.bones
        if _pose_bone_is_visible(pose_bone)
        and not _pose_bone_is_label_root(pose_bone)
    )


def _dynamic_parent_visible_relationships(context):
    if getattr(context, "mode", "") != "POSE":
        return ()

    selected_by_owner = {
        _armature_session_uid(armature): {
            pose_bone.name for pose_bone in pose_bones
        }
        for armature, pose_bones in _selected_pose_bones_by_owner(
            context
        ).items()
    }
    if not selected_by_owner:
        return ()

    frame = int(context.scene.frame_current)
    relationships = []
    seen = set()
    for child_armature in tuple(bpy.data.objects):
        if (
            child_armature.type != "ARMATURE"
            or getattr(child_armature, "pose", None) is None
        ):
            continue
        for child_bone in child_armature.pose.bones:
            constraint = _active_dynamic_parent_constraint(
                child_bone,
                frame,
                _chosen_dynamic_parent_constraint(child_bone, frame),
            )
            if constraint is None:
                continue
            target = _dynamic_parent_constraint_target(
                child_bone,
                constraint,
            )
            if target is None:
                continue
            subtarget = _dynamic_parent_constraint_subtarget(
                child_bone,
                constraint,
            )
            child_selected = bool(
                child_bone.name
                in selected_by_owner.get(
                    _armature_session_uid(child_armature),
                    set(),
                )
            )
            target_selected = bool(
                subtarget
                in selected_by_owner.get(
                    _armature_session_uid(target),
                    set(),
                )
            )
            if not (child_selected or target_selected):
                continue
            key = (
                int(child_armature.as_pointer()),
                child_bone.name,
                int(target.as_pointer()),
                subtarget,
            )
            if key in seen:
                continue
            seen.add(key)
            relationships.append(
                (child_armature, child_bone.name, target, subtarget)
            )
    return tuple(
        sorted(
            relationships,
            key = lambda relationship: (
                relationship[0].name.casefold(),
                relationship[1].casefold(),
                relationship[2].name.casefold(),
                relationship[3].casefold(),
            ),
        )
    )


def _dynamic_parent_bone_pivot_world(
    context,
    armature,
    bone_name,
    draw_cache,
):
    pivot_mode = str(
        getattr(context.window_manager, "staticaliza_pivot_mode", "BONE")
    )
    key = (int(armature.as_pointer()), str(bone_name), pivot_mode)
    if key in draw_cache["points"]:
        return draw_cache["points"][key]

    depsgraph = draw_cache["depsgraph"]
    try:
        evaluated_armature = armature.evaluated_get(depsgraph)
        evaluated_bone = evaluated_armature.pose.bones.get(str(bone_name))
        if evaluated_bone is None:
            return None

        world_point = None
        if pivot_mode == "PART":
            part = _part_pivot_connected_object(
                context,
                armature,
                evaluated_armature,
                draw_cache["objects"],
                evaluated_bone,
            )
            if part is not None:
                evaluated_part = part.evaluated_get(depsgraph)
                corners = tuple(Vector(corner) for corner in evaluated_part.bound_box)
                if corners:
                    local_min = Vector((
                        min(corner.x for corner in corners),
                        min(corner.y for corner in corners),
                        min(corner.z for corner in corners),
                    ))
                    local_max = Vector((
                        max(corner.x for corner in corners),
                        max(corner.y for corner in corners),
                        max(corner.z for corner in corners),
                    ))
                    world_point = evaluated_part.matrix_world @ (
                        (local_min + local_max) * 0.5
                    )

        if world_point is None:
            world_point = (
                evaluated_armature.matrix_world @ evaluated_bone.head
            )
        world_point = Vector(world_point[:3])
        draw_cache["points"][key] = world_point
        return world_point
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return None


def _dynamic_parent_target_pivot_world(
    context,
    target,
    subtarget,
    draw_cache,
):
    if target.type == "ARMATURE" and subtarget:
        return _dynamic_parent_bone_pivot_world(
            context,
            target,
            subtarget,
            draw_cache,
        )
    try:
        evaluated_target = target.evaluated_get(draw_cache["depsgraph"])
        return evaluated_target.matrix_world.to_translation()
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return None


def _draw_outlined_bone_text(
    font_id,
    text,
    center_x,
    text_y,
    font_size,
    text_color,
    outline_color = None,
    left_x = None,
):
    blf.size(font_id, float(font_size))
    rgb = tuple(float(value) for value in text_color[:3])
    alpha = float(text_color[3]) if len(text_color) >= 4 else 1.0
    if outline_color is None:
        outline_rgb = (0.0, 0.0, 0.0)
    else:
        outline_rgb = tuple(float(value) for value in outline_color[:3])
    text_width, text_height = blf.dimensions(font_id, text)
    text_x = (
        float(left_x)
        if left_x is not None
        else float(center_x) - (float(text_width) * 0.5)
    )
    blf.color(font_id, *outline_rgb, 1.0)
    for offset_x, offset_y in (
        (-1.5, 0.0),
        (1.5, 0.0),
        (0.0, -1.5),
        (0.0, 1.5),
        (-1.1, -1.1),
        (-1.1, 1.1),
        (1.1, -1.1),
        (1.1, 1.1),
    ):
        blf.position(font_id, text_x + offset_x, text_y + offset_y, 2.0)
        blf.draw(font_id, text)
    blf.color(font_id, *rgb, alpha)
    blf.position(font_id, text_x, text_y, 2.0)
    blf.draw(font_id, text)
    return float(text_height)


def _bone_status_text_color(effect, color):
    if effect == "CAMERA":
        return (0.64, 0.64, 0.64)
    tint = 0.5
    return tuple(
        min(1.0, float(component) + ((1.0 - float(component)) * tint))
        for component in color[:3]
    )


def _draw_bone_label(context, armature, pose_bone):
    region = getattr(context, "region", None)
    region_data = getattr(context, "region_data", None)
    if region is None or region_data is None:
        return

    from bpy_extras import view3d_utils

    try:
        depsgraph = context.evaluated_depsgraph_get()
        evaluated_armature = armature.evaluated_get(depsgraph)
        evaluated_bone = evaluated_armature.pose.bones.get(pose_bone.name)
        if evaluated_bone is None:
            return
        label_world = evaluated_armature.matrix_world @ (
            (evaluated_bone.head + evaluated_bone.tail) * 0.5
        )
        label_position = view3d_utils.location_3d_to_region_2d(
            region,
            region_data,
            label_world,
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return
    if label_position is None:
        return

    font_id = 0
    selected_armature, selected_bone = _selected_bone_label_target(context)
    is_selected = bool(
        _armature_session_uid(selected_armature) == _armature_session_uid(armature)
        and selected_bone is not None
        and _owner_bone_key(selected_armature, selected_bone.name)
        == _owner_bone_key(armature, pose_bone.name)
    )
    try:
        font_size = float(context.preferences.ui_styles[0].widget.points) + 2.0
    except (AttributeError, IndexError, TypeError, ValueError):
        font_size = 11.0
    base_font_size = font_size
    if is_selected:
        font_size += 5.0
    try:
        text_color = tuple(
            float(channel)
            for channel in context.preferences.themes[0].view_3d.space.text_hi
        )
    except (AttributeError, IndexError, TypeError, ValueError):
        text_color = (1.0, 1.0, 1.0)
    try:
        center_x = float(label_position.x) + 10.0
        blf.size(font_id, font_size)
        text_width, text_height = blf.dimensions(font_id, pose_bone.name)
        name_left_x = center_x - (float(text_width) * 0.5)
        text_y = float(label_position.y) - (float(text_height) * 0.5)
        _draw_outlined_bone_text(
            font_id,
            pose_bone.name,
            center_x,
            text_y,
            font_size,
            (*text_color, 1.0),
        )

        if is_selected:
            subtitle_size = max(10.0, float(base_font_size) + 1.0)
            subtitle_y = text_y - subtitle_size - 3.0
            chosen = _chosen_dynamic_parent_constraint(
                pose_bone,
                int(context.scene.frame_current),
            )
            for effect, label, color in _dynamic_pose_bone_label_effects(
                pose_bone,
                int(context.scene.frame_current),
                chosen,
            ):
                status_color = _bone_status_text_color(effect, color)
                height = _draw_outlined_bone_text(
                    font_id,
                    label,
                    center_x,
                    subtitle_y,
                    subtitle_size,
                    (*status_color, 1.0),
                    outline_color = (0.0, 0.0, 0.0),
                    left_x = name_left_x,
                )
                subtitle_y -= max(height, subtitle_size) + 2.0
    except (AttributeError, RuntimeError, TypeError, ValueError):
        return


def _rig_screen_bounds(context, armature):
    region = getattr(context, "region", None)
    region_data = getattr(context, "region_data", None)
    if region is None or region_data is None or armature is None:
        return None

    from bpy_extras import view3d_utils

    try:
        depsgraph = context.evaluated_depsgraph_get()
        objects, _owner = _targets(context, armature)
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        return None

    projected = []
    for obj in objects:
        if obj == armature or getattr(obj, "type", "") not in {
            "MESH",
            "CURVE",
            "SURFACE",
            "META",
            "FONT",
        }:
            continue
        if not _is_object_visible(obj, context):
            continue
        try:
            evaluated_object = obj.evaluated_get(depsgraph)
            matrix_world = evaluated_object.matrix_world
            for corner in evaluated_object.bound_box:
                point = view3d_utils.location_3d_to_region_2d(
                    region,
                    region_data,
                    matrix_world @ Vector(corner),
                )
                if point is not None:
                    projected.append((float(point.x), float(point.y)))
        except (
            AttributeError,
            ReferenceError,
            RuntimeError,
            TypeError,
            ValueError,
        ):
            continue

    if not projected:
        try:
            evaluated_armature = armature.evaluated_get(depsgraph)
            for pose_bone in evaluated_armature.pose.bones:
                for local_point in (pose_bone.head, pose_bone.tail):
                    point = view3d_utils.location_3d_to_region_2d(
                        region,
                        region_data,
                        evaluated_armature.matrix_world @ local_point,
                    )
                    if point is not None:
                        projected.append((float(point.x), float(point.y)))
        except (
            AttributeError,
            ReferenceError,
            RuntimeError,
            TypeError,
            ValueError,
        ):
            return None
    if not projected:
        return None
    return (
        min(point[0] for point in projected),
        min(point[1] for point in projected),
        max(point[0] for point in projected),
        max(point[1] for point in projected),
    )


def _rig_hover_region_point(context):
    window = getattr(context, "window", None)
    region = getattr(context, "region", None)
    if window is None or region is None:
        return None
    mouse = _state.get("rig_hover_mouse", {}).get(int(window.as_pointer()))
    if mouse is None:
        return None
    point = (
        float(mouse[0]) - float(region.x),
        float(mouse[1]) - float(region.y),
    )
    if not (0.0 <= point[0] <= region.width and 0.0 <= point[1] <= region.height):
        return None
    return point


def _draw_rig_labels(context, selected_armature):
    if getattr(context, "mode", "") != "POSE":
        return
    scope = _pose_scope_armatures(context)
    scope_uids = {_armature_session_uid(armature) for armature in scope}
    hover_point = _rig_hover_region_point(context)
    try:
        base_size = float(context.preferences.ui_styles[0].widget.points) + 4.0
    except (AttributeError, IndexError, TypeError, ValueError):
        base_size = 13.0

    font_id = 0
    selected_uid = _armature_session_uid(selected_armature)
    for armature in _pose_panel_armatures(context):
        uid = _armature_session_uid(armature)
        if selected_armature is not None and uid != selected_uid:
            continue
        bounds = _rig_screen_bounds(context, armature)
        if bounds is None:
            continue
        enabled = uid in scope_uids
        hovered = bool(
            hover_point is not None
            and bounds[0] <= hover_point[0] <= bounds[2]
            and bounds[1] <= hover_point[1] <= bounds[3]
        )
        if not enabled and not hovered:
            continue
        font_size = base_size + (2.0 if enabled and uid == selected_uid else 0.0)
        center_x = (float(bounds[0]) + float(bounds[2])) * 0.5
        text_y = min(
            float(context.region.height) - font_size - 2.0,
            float(bounds[3]) + 8.0,
        )
        _draw_outlined_bone_text(
            font_id,
            _rig_display_name(armature.name),
            center_x,
            text_y,
            font_size,
            (1.0, 0.72, 0.03, 1.0 if enabled else 0.82),
        )


def _runtime_needed(context):
    wm = getattr(context, "window_manager", None)
    if not wm:
        return bool(
            _state["yellow_modes"]
            or _state.get("onion_enabled_owners", set())
        )
    return (
        bool(_state.get("onion_enabled_owners", set()))
        or bool(_state["yellow_modes"])
        or bool(_pose_scope_armatures(context))
        or bool(_custom_bone_label_targets(context)[1])
        or bool(_surface_contact_guides())
        or bool(_dynamic_parent_visible_relationships(context))
    )

def _enable_runtime():
    if _state["enabled"]:
        return
    _state["enabled"] = True
    _state["handle_view"] = bpy.types.SpaceView3D.draw_handler_add(_draw_view, (), "WINDOW", "POST_VIEW")
    _state["handle_pixel"] = bpy.types.SpaceView3D.draw_handler_add(_draw_pixel, (), "WINDOW", "POST_PIXEL")
    _tag_redraw_all_view3d()

def _disable_runtime():
    if not _state["enabled"]:
        return

    _state["enabled"] = False

    if _state["handle_view"] is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_state["handle_view"], "WINDOW")
        _state["handle_view"] = None

    if _state["handle_pixel"] is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_state["handle_pixel"], "WINDOW")
        _state["handle_pixel"] = None

    _state["mesh_batches"] = {}
    _state["raycast_fixed"] = {}
    _tag_redraw_all_view3d()

def _circle_tris_2d(center_xy, radius, segments = 18):
    if radius <= 0.0:
        return []

    cx, cy = center_xy
    verts = []

    for i in range(segments):
        a0 = (i / segments) * (math.pi * 2.0)
        a1 = ((i + 1) / segments) * (math.pi * 2.0)

        v0 = (cx, cy)
        v1 = (cx + math.cos(a0) * radius, cy + math.sin(a0) * radius)
        v2 = (cx + math.cos(a1) * radius, cy + math.sin(a1) * radius)

        verts.extend((v0, v1, v2))

    return verts


def _circle_lines_2d(center_xy, radius, segments = 24):
    if radius <= 0.0:
        return []

    cx, cy = center_xy
    verts = []
    for index in range(segments):
        angle_a = (index / segments) * math.tau
        angle_b = ((index + 1) / segments) * math.tau
        verts.extend((
            (cx + math.cos(angle_a) * radius, cy + math.sin(angle_a) * radius),
            (cx + math.cos(angle_b) * radius, cy + math.sin(angle_b) * radius),
        ))
    return verts

def _circle_scale_from_dist(dist_px):
    min_scale = 1.25
    max_scale = 3.0
    min_px = 14.0
    max_px = 120.0

    if dist_px <= min_px:
        return min_scale
    if dist_px >= max_px:
        return max_scale

    t = (dist_px - min_px) / (max_px - min_px)
    t = t * t * (3.0 - (2.0 * t))
    return min_scale + (t * (max_scale - min_scale))

def _bounds_init(p):
    return [p.x, p.y, p.z, p.x, p.y, p.z]

def _bounds_add(b, p):
    if p.x < b[0]:
        b[0] = p.x
    if p.y < b[1]:
        b[1] = p.y
    if p.z < b[2]:
        b[2] = p.z
    if p.x > b[3]:
        b[3] = p.x
    if p.y > b[4]:
        b[4] = p.y
    if p.z > b[5]:
        b[5] = p.z

def _bounds_center(b):
    return Vector(((b[0] + b[3]) * 0.5, (b[1] + b[4]) * 0.5, (b[2] + b[5]) * 0.5))

def _collect_world_shape_from_largest_components(context, depsgraph, arm, eval_arm, only_names, objs = None):
    if objs is None:
        objs, _ = _targets(context)

    min_w = 0.05
    per_bone = {bn: [] for bn in only_names}

    for obj in objs:
        if obj.type != "MESH":
            continue
        if not _is_object_visible(obj, context):
            continue

        eval_obj = obj.evaluated_get(depsgraph)
        mw = eval_obj.matrix_world

        mesh = eval_obj.to_mesh(preserve_all_data_layers = False, depsgraph = depsgraph)
        if not mesh:
            continue

        for bn in only_names:
            vg = None
            try:
                vg = obj.vertex_groups.get(bn)
            except Exception:
                vg = None
            if not vg:
                continue

            vg_i = int(vg.index)

            b_world = None
            for v in mesh.vertices:
                w = 0.0
                for g in v.groups:
                    if int(g.group) == vg_i:
                        w = float(g.weight)
                        break
                if w < float(min_w):
                    continue

                p_world = mw @ v.co
                if b_world is None:
                    b_world = _bounds_init(p_world)
                else:
                    _bounds_add(b_world, p_world)

            if b_world is None:
                continue

            dx = float(b_world[3] - b_world[0])
            dy = float(b_world[4] - b_world[1])
            dz = float(b_world[5] - b_world[2])
            vol = max(0.0, dx) * max(0.0, dy) * max(0.0, dz)

            per_bone[bn].append((vol, b_world))

        eval_obj.to_mesh_clear()

    out = {}
    keep_ratio = 0.25
    keep_max = 6

    for bn, items in per_bone.items():
        if not items:
            continue

        items.sort(key = lambda x: float(x[0]), reverse = True)
        max_vol = float(items[0][0])
        cutoff = max_vol * keep_ratio

        keep = []
        for vol, b in items:
            if len(keep) >= keep_max:
                break
            if len(keep) == 0 or float(vol) >= cutoff:
                keep.append(b)

        merged = None
        for b in keep:
            if merged is None:
                merged = list(b)
            else:
                merged[0] = min(merged[0], b[0])
                merged[1] = min(merged[1], b[1])
                merged[2] = min(merged[2], b[2])
                merged[3] = max(merged[3], b[3])
                merged[4] = max(merged[4], b[4])
                merged[5] = max(merged[5], b[5])

        if merged is not None:
            out[bn] = merged

    return out

def _rig_local_bottom_center(matrix_world, points):
    try:
        matrix_inverse = matrix_world.inverted()
    except Exception:
        matrix_inverse = Matrix.Identity(4)

    rig_bounds = None
    for point in points:
        local = matrix_inverse @ Vector((point.x, point.y, point.z, 1.0))
        local_point = Vector((float(local.x), float(local.y), float(local.z)))
        if rig_bounds is None:
            rig_bounds = _bounds_init(local_point)
        else:
            _bounds_add(rig_bounds, local_point)

    if rig_bounds is None:
        return None

    center_x = (float(rig_bounds[0]) + float(rig_bounds[3])) * 0.5
    center_y = (float(rig_bounds[1]) + float(rig_bounds[4])) * 0.5
    bottom_z = float(rig_bounds[2])
    world = matrix_world @ Vector((center_x, center_y, bottom_z, 1.0))
    return Vector((float(world.x), float(world.y), float(world.z)))


def _rig_local_lower_bone_endpoint(eval_arm, pose_bone):
    endpoint = pose_bone.head if pose_bone.head.z <= pose_bone.tail.z else pose_bone.tail
    return eval_arm.matrix_world @ endpoint


def _pose_bone_numeric_family_levels(eval_arm, pose_bone):
    canonical_name = _strip_blender_numeric_suffix(pose_bone.name)
    levels = []

    canonical_bone = eval_arm.pose.bones.get(canonical_name)
    if canonical_bone is not None:
        levels.append({canonical_bone.name})

    prefix = f"{canonical_name}."
    variants = []
    for bone in eval_arm.pose.bones:
        if not bone.name.startswith(prefix):
            continue
        suffix = bone.name[len(prefix):]
        if suffix.isdigit():
            variants.append((int(suffix), bone.name))

    if variants:
        variants.sort(key = lambda item: (item[0], item[1]))
        levels.append({name for _number, name in variants})

    if not levels:
        levels.append({pose_bone.name})

    return levels


def _node_tree_has_linked_base_color(node_tree, visited = None):
    if node_tree is None:
        return False
    if visited is None:
        visited = set()

    pointer = node_tree.as_pointer()
    if pointer in visited:
        return False
    visited.add(pointer)

    for node in node_tree.nodes:
        if node.type == "BSDF_PRINCIPLED":
            base_color = node.inputs.get("Base Color")
            if base_color and base_color.is_linked:
                return True
        if (
            node.type == "GROUP"
            and getattr(node, "node_tree", None)
            and _node_tree_has_linked_base_color(node.node_tree, visited)
        ):
            return True
    return False


def _object_has_linked_base_color(obj):
    materials = getattr(getattr(obj, "data", None), "materials", ())
    return any(
        _node_tree_has_linked_base_color(getattr(material, "node_tree", None))
        for material in materials
        if material is not None
    )


def _rigid_object_smart_anchor(arm, eval_arm, eval_obj, controller_bone_name):
    local_points = [Vector(corner) for corner in eval_obj.bound_box]
    points = [eval_obj.matrix_world @ point for point in local_points]
    if not local_points:
        return None, points, 0.0

    local_bounds = _bounds_init(local_points[0])
    for point in local_points[1:]:
        _bounds_add(local_bounds, point)

    # Smart pins historically use the connected object's local lower face.
    # Keeping the anchor in object space makes rotated parts follow that face.
    local_anchor = Vector((
        (float(local_bounds[0]) + float(local_bounds[3])) * 0.5,
        float(local_bounds[1]),
        (float(local_bounds[2]) + float(local_bounds[5])) * 0.5,
        1.0,
    ))

    dx = float(local_bounds[3] - local_bounds[0])
    dy = float(local_bounds[4] - local_bounds[1])
    dz = float(local_bounds[5] - local_bounds[2])
    volume = max(0.0, dx) * max(0.0, dy) * max(0.0, dz)
    return local_anchor, points, volume


def _yellow_mode3_anchor(context, depsgraph, arm, eval_arm, objs, bone_name):
    pb = eval_arm.pose.bones.get(bone_name)
    if not pb:
        return None, "", None

    fallback = _rig_local_lower_bone_endpoint(eval_arm, pb)
    canonical_name = _strip_blender_numeric_suffix(pb.name)

    keep_ratio = 0.25
    keep_max = 6
    candidates = []

    level_name_sets = list(_pose_bone_numeric_family_levels(eval_arm, pb))
    existing_names = set().union(*level_name_sets)
    connected_family = _surface_contact_bone_family_names(eval_arm, pb)
    weld_names = connected_family - existing_names
    if weld_names:
        level_name_sets.append(weld_names)

    search_objects = list(objs or ())
    for connected_object in _surface_contact_connected_objects(
        context,
        arm,
        connected_family,
    ):
        if connected_object not in search_objects:
            search_objects.append(connected_object)

    # Prefer the canonical non-numbered bone. Only fall back through connected
    # numeric variants and weld-only descendants, never articulated limbs.
    for level_names in level_name_sets:
        level_candidates = []

        for obj in search_objects:
            if obj.type != "MESH":
                continue
            if not _is_object_visible(obj, context):
                continue

            controller_bone_name = ""
            rigid_match = (
                obj.parent == arm
                and obj.parent_type == "BONE"
                and getattr(obj, "parent_bone", "") in level_names
            )
            if rigid_match:
                controller_bone_name = getattr(obj, "parent_bone", "")
            for constraint in obj.constraints:
                if (
                    getattr(constraint, "target", None) == arm
                    and getattr(constraint, "subtarget", "") in level_names
                ):
                    rigid_match = True
                    controller_bone_name = getattr(constraint, "subtarget", "")
                    break

            vertex_group_indices = set()
            if not rigid_match:
                try:
                    for descendant_name in level_names:
                        vertex_group = obj.vertex_groups.get(descendant_name)
                        if vertex_group:
                            vertex_group_indices.add(int(vertex_group.index))
                except Exception:
                    vertex_group_indices.clear()

            points = []
            object_local_anchor = None
            volume = 0.0

            if rigid_match:
                eval_obj = obj.evaluated_get(depsgraph)
                object_local_anchor, points, volume = _rigid_object_smart_anchor(
                    arm,
                    eval_arm,
                    eval_obj,
                    controller_bone_name,
                )
            elif vertex_group_indices:
                eval_obj = obj.evaluated_get(depsgraph)
                mesh = eval_obj.to_mesh(preserve_all_data_layers = False, depsgraph = depsgraph)
                if not mesh:
                    continue

                mw = eval_obj.matrix_world

                for min_w in (0.35, 0.2, 0.05):
                    points = []
                    for vertex in mesh.vertices:
                        weight = 0.0
                        for group in vertex.groups:
                            if int(group.group) in vertex_group_indices:
                                weight = max(weight, float(group.weight))
                        if weight >= float(min_w):
                            points.append(mw @ vertex.co)

                    if len(points) >= 12:
                        break

                eval_obj.to_mesh_clear()
            else:
                continue

            if not points:
                continue

            if object_local_anchor is None:
                bounds = _bounds_init(points[0])
                for point in points[1:]:
                    _bounds_add(bounds, point)

                dx = float(bounds[3] - bounds[0])
                dy = float(bounds[4] - bounds[1])
                dz = float(bounds[5] - bounds[2])
                volume = max(0.0, dx) * max(0.0, dy) * max(0.0, dz)
            level_candidates.append(
                (
                    volume,
                    points,
                    obj,
                    _object_has_linked_base_color(obj),
                    object_local_anchor,
                    _strip_blender_numeric_suffix(obj.name) == canonical_name,
                    obj.name == canonical_name,
                )
            )

        if level_candidates:
            exact_name = [
                candidate for candidate in level_candidates if candidate[6]
            ]
            matching_name = [
                candidate for candidate in level_candidates if candidate[5]
            ]
            preferred_candidates = exact_name or matching_name or level_candidates
            without_linked_base_color = [
                candidate for candidate in preferred_candidates if not candidate[3]
            ]
            candidates = without_linked_base_color or preferred_candidates
            break

    if not candidates:
        return fallback.copy(), "", None

    candidates.sort(key = lambda x: float(x[0]), reverse = True)
    max_vol = float(candidates[0][0])
    cutoff = max_vol * keep_ratio

    primary = candidates[0]
    if primary[4] is not None:
        eval_obj = primary[2].evaluated_get(depsgraph)
        local_anchor = primary[4].copy()
        world_anchor = eval_obj.matrix_world @ local_anchor
        return (
            Vector((float(world_anchor.x), float(world_anchor.y), float(world_anchor.z))),
            primary[2].name,
            local_anchor,
        )

    cloud = []
    kept = 0
    for (
        vol,
        points,
        _obj,
        _has_linked_base_color,
        _local_anchor,
        _matching_name,
        _exact_name,
    ) in candidates:
        if kept >= keep_max:
            break
        if kept == 0 or float(vol) >= cutoff:
            cloud.extend(points)
            kept += 1

    if not cloud:
        return fallback.copy(), "", None

    if len(cloud) > 8000:
        step = int(len(cloud) / 8000) + 1
        cloud = cloud[::step]

    reference_object = primary[2].evaluated_get(depsgraph)
    try:
        reference_inverse = reference_object.matrix_world.inverted()
    except Exception:
        reference_inverse = Matrix.Identity(4)

    local_bounds = None
    for point in cloud:
        local = reference_inverse @ _as_p4(point)
        local_point = Vector((float(local.x), float(local.y), float(local.z)))
        if local_bounds is None:
            local_bounds = _bounds_init(local_point)
        else:
            _bounds_add(local_bounds, local_point)

    if local_bounds is None:
        return fallback.copy(), "", None

    local_anchor = Vector((
        (float(local_bounds[0]) + float(local_bounds[3])) * 0.5,
        float(local_bounds[1]),
        (float(local_bounds[2]) + float(local_bounds[5])) * 0.5,
        1.0,
    ))
    world_anchor = reference_object.matrix_world @ local_anchor
    return (
        Vector((float(world_anchor.x), float(world_anchor.y), float(world_anchor.z))),
        "",
        None,
    )


def _yellow_mode3_point(context, depsgraph, arm, eval_arm, objs, bone_name):
    return _yellow_mode3_anchor(
        context,
        depsgraph,
        arm,
        eval_arm,
        objs,
        bone_name,
    )[0]

def _yellow_capture(context, depsgraph, arm, eval_arm, objs, bone_name, mode, bounds_world_map):
    pb = eval_arm.pose.bones.get(bone_name)
    if not pb:
        return None

    arm_mw = eval_arm.matrix_world
    head = arm_mw @ pb.head
    tail = arm_mw @ pb.tail

    smart_object_name = ""
    smart_object_local = None

    if mode == 1:
        end = tail
    elif mode == 2:
        b_world = bounds_world_map.get(bone_name, None) if bounds_world_map else None
        if b_world:
            end = _bounds_center(b_world)
        else:
            end = (head + tail) * 0.5
    elif mode == 4:
        end = head
    else:
        end, smart_object_name, smart_object_local = _yellow_mode3_anchor(
            context,
            depsgraph,
            arm,
            eval_arm,
            objs,
            bone_name,
        )
        if end is None:
            end = tail

    draw_dots = True
    if _is_unmovable(pb):
        draw_dots = False

    if mode == 4:
        local_p4 = Vector((0.0, 0.0, 0.0, 1.0))
    else:
        try:
            local_p4 = _world_to_bone_local_p4(eval_arm, pb, end)
        except Exception:
            local_p4 = Vector((0.0, 0.0, 0.0, 1.0))

    packed = (end.copy(), local_p4.copy(), draw_dots, int(mode))
    if mode == 3 and smart_object_name and smart_object_local is not None:
        packed += (smart_object_name, smart_object_local.copy())
    return packed

def _yellow_refresh_runtime(context):
    if not getattr(context, "window_manager", None):
        return
    scene = getattr(context, "scene", None)
    if scene is not None:
        _sync_all_dynamic_pose_bone_colors(int(scene.frame_current))
    if _runtime_needed(context):
        _enable_runtime()
    else:
        _disable_runtime()
    _tag_redraw_all_view3d()

def _build_snapshot_data(context, armature = None):
    scn = context.scene
    wm = context.window_manager
    depsgraph = context.evaluated_depsgraph_get()
    objs, arm = _targets(context, armature)

    include_meshes = wm.onion_skin_include_meshes
    include_bones = wm.onion_skin_include_bones
    raycast = wm.onion_skin_raycast

    shader3d = _ensure_shader_3d()
    vertex_color = (_state["shader_3d_mode"] == "VERTEX")

    mesh_alpha = wm.onion_skin_opacity
    mesh_color = (1.0, 0.0, 0.0, mesh_alpha)

    mesh_batches = []
    raycast_fixed = {}

    if include_meshes:
        for obj in objs:
            if obj.type != "MESH":
                continue
            if not _is_object_visible(obj, context):
                continue

            eval_obj = obj.evaluated_get(depsgraph)
            mesh = eval_obj.to_mesh(preserve_all_data_layers = False, depsgraph = depsgraph)
            if not mesh:
                continue

            mw = eval_obj.matrix_world

            try:
                mesh.calc_loop_triangles()
            except Exception:
                eval_obj.to_mesh_clear()
                continue

            tri_pos = []
            verts = mesh.vertices
            for tri in mesh.loop_triangles:
                v0, v1, v2 = tri.vertices
                tri_pos.append(mw @ verts[v0].co)
                tri_pos.append(mw @ verts[v1].co)
                tri_pos.append(mw @ verts[v2].co)

            if tri_pos:
                if vertex_color:
                    cols = [mesh_color] * len(tri_pos)
                    mesh_batches.append(batch_for_shader(shader3d, "TRIS", {"pos": tri_pos, "color": cols}))
                else:
                    mesh_batches.append(batch_for_shader(shader3d, "TRIS", {"pos": tri_pos}))

            eval_obj.to_mesh_clear()

    if not arm or not include_bones or not raycast:
        return mesh_batches, raycast_fixed

    arm_eval = arm.evaluated_get(depsgraph)
    arm_mw = arm_eval.matrix_world

    for pb in arm_eval.pose.bones:
        head = arm_mw @ pb.head
        tail = arm_mw @ pb.tail
        end = tail

        draw_dots = True
        if pb.parent is None:
            draw_dots = False
        elif _is_unmovable(pb):
            draw_dots = False

        try:
            local_p4 = _world_to_bone_local_p4(arm_eval, pb, end)
        except Exception:
            local_p4 = Vector((0.0, 0.0, 0.0, 1.0))

        raycast_fixed[pb.name] = (end.copy(), local_p4.copy(), draw_dots, 1)

    return mesh_batches, raycast_fixed

def _capture_or_clear(context, enable_ghost, armatures = None):
    _state["last_error"] = ""
    scope = tuple(armatures or _pose_scope_armatures(context))
    if not scope:
        active = _active_armature(context)
        scope = (active,) if active is not None else ()

    enabled_owners = set(_state.get("onion_enabled_owners", set()))
    mesh_batches_by_owner = dict(_state.get("mesh_batches", {}))
    raycast_by_owner = dict(_state.get("raycast_fixed", {}))

    if enable_ghost:
        _enable_runtime()
        for armature in scope:
            uid = _armature_session_uid(armature)
            try:
                bpy.context.view_layer.update()
                mesh_batches, raycast_fixed = _build_snapshot_data(
                    context,
                    armature,
                )
                mesh_batches_by_owner[uid] = mesh_batches
                raycast_by_owner[uid] = raycast_fixed
                enabled_owners.add(uid)
            except Exception as exc:
                _state["last_error"] = str(exc)
                mesh_batches_by_owner.pop(uid, None)
                raycast_by_owner.pop(uid, None)
                enabled_owners.discard(uid)
    else:
        for armature in scope:
            uid = _armature_session_uid(armature)
            mesh_batches_by_owner.pop(uid, None)
            raycast_by_owner.pop(uid, None)
            enabled_owners.discard(uid)

    _state["mesh_batches"] = mesh_batches_by_owner
    _state["raycast_fixed"] = raycast_by_owner
    _state["onion_enabled_owners"] = enabled_owners
    _set_onion_property(context.window_manager, bool(enabled_owners))

    if not _runtime_needed(context):
        _disable_runtime()

    _tag_redraw_all_view3d()

def _on_enabled_toggle(self, context):
    if _state.get("onion_property_syncing", False):
        return
    _capture_or_clear(
        context,
        self.onion_skin_enabled,
        armatures = _pose_scope_armatures(context),
    )

def _on_setting_change(self, context):
    scope = tuple(
        armature
        for armature in _pose_scope_armatures(context)
        if _onion_owner_enabled(armature)
    )
    if not scope:
        return
    _capture_or_clear(context, True, armatures = scope)


def _capture_gpu_draw_state():
    return (
        gpu.state.depth_test_get(),
        gpu.state.depth_mask_get(),
        gpu.state.blend_get(),
        gpu.state.line_width_get(),
    )


def _restore_gpu_draw_state(state):
    depth_test, depth_mask, blend, line_width = state
    gpu.state.depth_test_set(depth_test)
    gpu.state.depth_mask_set(depth_mask)
    gpu.state.blend_set(blend)
    gpu.state.line_width_set(line_width)


def _surface_contact_anchor_world(context, guide, depsgraph = None):
    depsgraph = depsgraph or context.evaluated_depsgraph_get()
    smart_object = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_SMART_OBJECT_PROPERTY, ""))
    )
    smart_local = guide.get(SURFACE_CONTACT_SMART_LOCAL_PROPERTY)
    if smart_object is not None and smart_local is not None and len(smart_local) >= 3:
        try:
            evaluated_object = smart_object.evaluated_get(depsgraph)
            local_point = Vector(
                (
                    float(smart_local[0]),
                    float(smart_local[1]),
                    float(smart_local[2]),
                    1.0,
                )
            )
            current = evaluated_object.matrix_world @ local_point
            return Vector(
                (float(current.x), float(current.y), float(current.z))
            )
        except (
            AttributeError,
            ReferenceError,
            RuntimeError,
            TypeError,
            ValueError,
        ):
            pass

    armature = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
    )
    support_data = guide.get(SURFACE_CONTACT_SUPPORT_PROPERTY)
    geometry_bone_name = str(
        guide.get(
            SURFACE_CONTACT_GEOMETRY_BONE_PROPERTY,
            guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""),
        )
    )
    if armature is None or support_data is None or len(support_data) < 3:
        return None
    try:
        evaluated_armature = armature.evaluated_get(depsgraph)
        evaluated_bone = evaluated_armature.pose.bones.get(geometry_bone_name)
        if evaluated_bone is None:
            return None
        return (
            evaluated_armature.matrix_world
            @ evaluated_bone.matrix
            @ Vector(tuple(float(value) for value in support_data[:3]))
        )
    except (
        AttributeError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ):
        return None


def _surface_contact_world_point_normal(context, guide):
    depsgraph = context.evaluated_depsgraph_get()
    try:
        evaluated_guide = guide.evaluated_get(depsgraph)
        guide_world = evaluated_guide.matrix_world.copy()
    except (AttributeError, ReferenceError, RuntimeError):
        guide_world = guide.matrix_world.copy()
    point = guide_world.translation.copy()
    normal = guide_world.to_3x3().col[2]
    if normal.length_squared <= 1.0e-12:
        normal = Vector((0.0, 0.0, 1.0))
    else:
        normal.normalize()
    anchor = _surface_contact_anchor_world(context, guide, depsgraph)
    if anchor is None:
        anchor = guide_world.translation.copy()
    return point, normal, anchor


def _draw_surface_contact_guides(context):
    region = getattr(context, "region", None)
    rv3d = getattr(context, "region_data", None)
    if region is None or rv3d is None:
        return

    from bpy_extras import view3d_utils

    frame = int(context.scene.frame_current)
    line_positions = []
    overlap_line_positions = []
    dot_positions = []
    overlap_dot_positions = []
    snap_rings = []
    overlap_snap_rings = []
    circle_base = PIN_DOT_PIXEL_RADIUS
    depsgraph = context.evaluated_depsgraph_get()
    evaluated_armatures = {}
    pose_scope_names = {
        armature.name for armature in _pose_scope_armatures(context)
    }
    for guide in _surface_contact_guides():
        guide_armature_name = str(
            guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, "")
        )
        if (
            guide_armature_name not in pose_scope_names
            or not _surface_contact_guide_active_at(guide, frame)
        ):
            continue
        point, _normal, anchor = _surface_contact_world_point_normal(
            context,
            guide,
        )
        if point is None or anchor is None:
            continue

        point_2d = view3d_utils.location_3d_to_region_2d(
            region,
            rv3d,
            point,
        )
        anchor_2d = view3d_utils.location_3d_to_region_2d(
            region,
            rv3d,
            anchor,
        )
        if point_2d is None or anchor_2d is None:
            continue

        fixed = (float(point_2d.x), float(point_2d.y))
        current = (float(anchor_2d.x), float(anchor_2d.y))
        distance_pixels = math.hypot(
            fixed[0] - current[0],
            fixed[1] - current[1],
        )
        snapped = _pin_points_within_snap_radius(context, point, anchor)
        current_radius = (
            circle_base
            if snapped
            else circle_base * _circle_scale_from_dist(distance_pixels)
        )
        onion_fixed = None
        onion_current = None
        bone_name = str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
        guide_armature = bpy.data.objects.get(guide_armature_name)
        owner_uid = _armature_session_uid(guide_armature)
        packed = _state["yellow_fixed"].get((owner_uid, bone_name))
        evaluated_armature = evaluated_armatures.get(owner_uid)
        if evaluated_armature is None and guide_armature is not None:
            evaluated_armature = guide_armature.evaluated_get(depsgraph)
            evaluated_armatures[owner_uid] = evaluated_armature
        if (
            packed
            and len(packed) >= 2
            and guide_armature is not None
            and evaluated_armature is not None
        ):
            onion_bone = evaluated_armature.pose.bones.get(bone_name)
            if onion_bone is not None:
                onion_fixed = Vector(packed[0])
                onion_current = _yellow_current_world_point(
                    depsgraph,
                    evaluated_armature,
                    onion_bone,
                    packed,
                )

        fixed_overlap = bool(
            onion_fixed is not None and (point - onion_fixed).length <= 0.025
        )
        current_overlap = bool(
            onion_current is not None and (anchor - onion_current).length <= 0.025
        )
        target_lines = (
            overlap_line_positions
            if fixed_overlap and current_overlap
            else line_positions
        )
        target_lines.extend((fixed, current))
        (overlap_dot_positions if fixed_overlap else dot_positions).extend(
            _circle_tris_2d(fixed, circle_base)
        )
        (overlap_dot_positions if current_overlap else dot_positions).extend(
            _circle_tris_2d(current, current_radius)
        )
        if snapped:
            (overlap_snap_rings if fixed_overlap else snap_rings).extend(
                _circle_lines_2d(fixed, PIN_SNAP_RING_PIXEL_RADIUS)
            )

    if not (
        line_positions
        or overlap_line_positions
        or dot_positions
        or overlap_dot_positions
    ):
        return

    shader = _ensure_shader_2d()
    shader.bind()
    shader.uniform_float(
        "u_viewport",
        (float(region.width), float(region.height)),
    )
    shader.uniform_float("color", SURFACE_CONTACT_HOT_PINK)
    if line_positions:
        batch_for_shader(
            shader,
            "LINES",
            {"pos": line_positions},
        ).draw(shader)
    if overlap_line_positions:
        shader.uniform_float("color", SURFACE_CONTACT_OVERLAP_COLOR)
        batch_for_shader(
            shader,
            "LINES",
            {"pos": overlap_line_positions},
        ).draw(shader)
        shader.uniform_float("color", SURFACE_CONTACT_HOT_PINK)
    if dot_positions:
        batch_for_shader(
            shader,
            "TRIS",
            {"pos": dot_positions},
        ).draw(shader)
    if overlap_dot_positions:
        shader.uniform_float("color", SURFACE_CONTACT_OVERLAP_COLOR)
        batch_for_shader(
            shader,
            "TRIS",
            {"pos": overlap_dot_positions},
        ).draw(shader)
    if snap_rings:
        gpu.state.line_width_set(1.25)
        shader.uniform_float("color", SURFACE_CONTACT_HOT_PINK)
        batch_for_shader(
            shader,
            "LINES",
            {"pos": snap_rings},
        ).draw(shader)
    if overlap_snap_rings:
        gpu.state.line_width_set(1.25)
        shader.uniform_float("color", SURFACE_CONTACT_OVERLAP_COLOR)
        batch_for_shader(
            shader,
            "LINES",
            {"pos": overlap_snap_rings},
        ).draw(shader)
    if snap_rings or overlap_snap_rings:
        gpu.state.line_width_set(4.0)


def _draw_view():
    context = bpy.context
    wm = getattr(context, "window_manager", None)
    pose_scope_uids = {
        _armature_session_uid(armature)
        for armature in _pose_scope_armatures(context)
    }
    draw_onion = bool(
        wm
        and pose_scope_uids
        and _state.get("onion_enabled_owners", set())
        and _state["mesh_batches"]
    )
    if not draw_onion:
        return

    previous_state = _capture_gpu_draw_state()
    try:
        gpu.state.depth_mask_set(False)
        gpu.state.blend_set("ALPHA")
        if draw_onion:
            gpu.state.depth_test_set("LESS_EQUAL")
            shader = _ensure_shader_3d()
            color = (1.0, 0.0, 0.0, wm.onion_skin_opacity)
            if _state["shader_3d_mode"] == "UNIFORM":
                shader.bind()
                shader.uniform_float("color", color)
            for owner_uid, batches in _state["mesh_batches"].items():
                if (
                    owner_uid not in pose_scope_uids
                    or owner_uid not in _state.get("onion_enabled_owners", set())
                ):
                    continue
                for batch in batches:
                    batch.draw(shader)

    finally:
        _restore_gpu_draw_state(previous_state)


def _yellow_current_world_point(depsgraph, eval_arm, pose_bone, packed):
    mode = int(packed[3]) if len(packed) >= 4 else 1
    if mode == 3 and len(packed) >= 6 and packed[4]:
        smart_object = bpy.data.objects.get(packed[4])
        if smart_object is not None:
            eval_object = smart_object.evaluated_get(depsgraph)
            current = eval_object.matrix_world @ _as_p4(packed[5])
            return Vector((float(current.x), float(current.y), float(current.z)))

    if mode == 4:
        return eval_arm.matrix_world @ pose_bone.matrix.to_translation()

    try:
        return _bone_local_to_world(eval_arm, pose_bone, packed[1])
    except Exception:
        return eval_arm.matrix_world @ pose_bone.tail


def _draw_raycast_layer(context, fixed_map, color_rgba, armature = None):
    if not fixed_map:
        return

    region = getattr(context, "region", None)
    rv3d = getattr(context, "region_data", None)
    if not region or not rv3d:
        return

    from bpy_extras import view3d_utils

    arm = armature or _active_armature(context)
    if not arm:
        return

    depsgraph = context.evaluated_depsgraph_get()
    eval_arm = arm.evaluated_get(depsgraph)

    shader2d = _ensure_shader_2d()
    shader2d.bind()
    shader2d.uniform_float("u_viewport", (float(region.width), float(region.height)))

    line_pos = []
    tri_pos = []
    snap_rings = []

    circle_base = PIN_DOT_PIXEL_RADIUS
    for name, packed in fixed_map.items():
        if not packed or len(packed) < 2:
            continue

        fixed3d = packed[0]
        draw_dots = bool(packed[2]) if len(packed) >= 3 else True

        pb = eval_arm.pose.bones.get(name)
        if not pb:
            continue

        current3d = _yellow_current_world_point(depsgraph, eval_arm, pb, packed)

        fixed2d = view3d_utils.location_3d_to_region_2d(region, rv3d, fixed3d)
        curr2d = view3d_utils.location_3d_to_region_2d(region, rv3d, current3d)
        if not fixed2d or not curr2d:
            continue

        a = (fixed2d.x, fixed2d.y)
        b = (curr2d.x, curr2d.y)

        dx = a[0] - b[0]
        dy = a[1] - b[1]
        dist_px = math.sqrt((dx * dx) + (dy * dy))

        snapped = _pin_points_within_snap_radius(
            context,
            fixed3d,
            current3d,
        )

        line_pos.extend((a, b))

        if draw_dots:
            radius = (
                circle_base
                if snapped
                else circle_base * _circle_scale_from_dist(dist_px)
            )
            tri_pos.extend(_circle_tris_2d(a, circle_base))
            tri_pos.extend(_circle_tris_2d(b, radius))
            if snapped:
                snap_rings.extend(
                    _circle_lines_2d(a, PIN_SNAP_RING_PIXEL_RADIUS)
                )

    if line_pos:
        shader2d.uniform_float("color", color_rgba)
        batch_for_shader(shader2d, "LINES", {"pos": line_pos}).draw(shader2d)

    if tri_pos:
        shader2d.uniform_float("color", color_rgba)
        batch_for_shader(shader2d, "TRIS", {"pos": tri_pos}).draw(shader2d)

    if snap_rings:
        gpu.state.line_width_set(1.25)
        shader2d.uniform_float("color", color_rgba)
        batch_for_shader(shader2d, "LINES", {"pos": snap_rings}).draw(shader2d)
        gpu.state.line_width_set(4.0)


def _draw_dynamic_parent_relationships(context, relationships):
    if not relationships:
        return

    region = getattr(context, "region", None)
    region_data = getattr(context, "region_data", None)
    if region is None or region_data is None:
        return

    from bpy_extras import view3d_utils

    draw_cache = {
        "depsgraph": context.evaluated_depsgraph_get(),
        "objects": tuple(context.view_layer.objects),
        "points": {},
    }
    line_positions = []
    dot_positions = []
    dot_radius = 5.0
    for child_armature, child_name, target, subtarget in relationships:
        child_world = _dynamic_parent_bone_pivot_world(
            context,
            child_armature,
            child_name,
            draw_cache,
        )
        target_world = _dynamic_parent_target_pivot_world(
            context,
            target,
            subtarget,
            draw_cache,
        )
        if child_world is None or target_world is None:
            continue
        child_2d = view3d_utils.location_3d_to_region_2d(
            region,
            region_data,
            child_world,
        )
        target_2d = view3d_utils.location_3d_to_region_2d(
            region,
            region_data,
            target_world,
        )
        if child_2d is None or target_2d is None:
            continue
        child_point = (float(child_2d.x), float(child_2d.y))
        target_point = (float(target_2d.x), float(target_2d.y))
        line_positions.extend((target_point, child_point))
        dot_positions.extend(_circle_tris_2d(target_point, dot_radius))
        dot_positions.extend(_circle_tris_2d(child_point, dot_radius))

    if not line_positions and not dot_positions:
        return
    shader = _ensure_shader_2d()
    shader.bind()
    shader.uniform_float(
        "u_viewport",
        (float(region.width), float(region.height)),
    )
    color = (*DYNAMIC_PARENT_COLOR, 1.0)
    shader.uniform_float("color", color)
    if line_positions:
        gpu.state.line_width_set(2.0)
        batch_for_shader(
            shader,
            "LINES",
            {"pos": line_positions},
        ).draw(shader)
    if dot_positions:
        batch_for_shader(
            shader,
            "TRIS",
            {"pos": dot_positions},
        ).draw(shader)
    gpu.state.line_width_set(4.0)

def _draw_pixel():
    context = bpy.context
    wm = getattr(context, "window_manager", None)
    if not wm:
        return
    selected_label_armature, label_targets = _custom_bone_label_targets(context)
    parent_relationships = _dynamic_parent_visible_relationships(context)
    pose_scope_uids = {
        _armature_session_uid(armature)
        for armature in _pose_scope_armatures(context)
    }
    if (
        (not _state.get("onion_enabled_owners", set()))
        and (not _state["yellow_modes"])
        and not label_targets
        and not _surface_contact_guides()
        and not parent_relationships
        and getattr(context, "mode", "") != "POSE"
    ):
        return

    previous_state = _capture_gpu_draw_state()
    try:
        gpu.state.depth_test_set("NONE")
        gpu.state.depth_mask_set(False)
        gpu.state.blend_set("ALPHA")
        gpu.state.line_width_set(4.0)

        if wm.onion_skin_include_bones and wm.onion_skin_raycast:
            for owner_uid in tuple(_state.get("onion_enabled_owners", set())):
                if owner_uid not in pose_scope_uids:
                    continue
                armature = _armature_from_session_uid(owner_uid)
                fixed_map = _state.get("raycast_fixed", {}).get(owner_uid, {})
                if armature is not None and fixed_map:
                    _draw_raycast_layer(
                        context,
                        fixed_map,
                        (1.0, 0.0, 0.0, 1.0),
                        armature = armature,
                    )

        for owner_uid in {
            int(key[0]) for key in _state.get("yellow_modes", {})
        }:
            if owner_uid not in pose_scope_uids:
                continue
            armature = _armature_from_session_uid(owner_uid)
            fixed_map = (
                _yellow_owner_map("yellow_fixed", armature)
                if armature is not None
                else {}
            )
            if armature is not None and fixed_map and not _yellow_owner_hidden(armature):
                _draw_raycast_layer(
                    context,
                    fixed_map,
                    ONION_PIN_COLOR,
                    armature = armature,
                )

        if _surface_contact_guides():
            _draw_surface_contact_guides(context)

        if parent_relationships:
            _draw_dynamic_parent_relationships(
                context,
                parent_relationships,
            )

        for label_armature, label_bone in label_targets:
            _draw_bone_label(context, label_armature, label_bone)
        _draw_rig_labels(context, selected_label_armature)
    finally:
        _restore_gpu_draw_state(previous_state)

class ONION_SKIN_OT_ghost_toggle(bpy.types.Operator):
    bl_idname = "onion_skin.ghost_toggle"
    bl_label = "Toggle Ghost"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def execute(self, context):
        wm = context.window_manager
        scope = _pose_scope_armatures(context)
        if not scope:
            return {"CANCELLED"}
        enabling = any(not _onion_owner_enabled(armature) for armature in scope)

        if enabling:
            wm.onion_skin_include_meshes = True
            wm.onion_skin_include_bones = False

        _capture_or_clear(context, enabling, armatures = scope)

        return {"FINISHED"}

def _pose_bone_selected(pose_bone):
    if pose_bone is None:
        return False
    try:
        if hasattr(pose_bone, "select"):
            return bool(pose_bone.select)
    except (AttributeError, ReferenceError, RuntimeError):
        pass
    try:
        bone = pose_bone.bone
        return bool(bone.select or bone.select_head or bone.select_tail)
    except (AttributeError, ReferenceError, RuntimeError):
        return False


def _selected_pose_bones_or_active(context):
    selected = _selected_pose_bones_only(context)
    if selected:
        return selected
    if context.active_pose_bone:
        return [context.active_pose_bone]
    return []

def _selected_pose_bones_only(context):
    selected = []
    seen = set()
    for armature in _pose_scope_armatures(context):
        for pose_bone in getattr(getattr(armature, "pose", None), "bones", ()):
            if not _pose_bone_selected(pose_bone):
                continue
            try:
                pointer = int(pose_bone.as_pointer())
            except (AttributeError, ReferenceError, TypeError, ValueError):
                pointer = id(pose_bone)
            if pointer in seen:
                continue
            seen.add(pointer)
            selected.append(pose_bone)
    if selected:
        return selected
    try:
        return [
            pose_bone
            for pose_bone in tuple(context.selected_pose_bones or ())
            if pose_bone is not None
        ]
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        return []


def _selected_pose_bones_by_owner(context, include_active_fallback = False):
    armatures = _pose_scope_armatures(context)
    grouped = {}
    for armature in armatures:
        selected = tuple(
            pose_bone
            for pose_bone in getattr(
                getattr(armature, "pose", None),
                "bones",
                (),
            )
            if _pose_bone_selected(pose_bone)
        )
        if selected:
            grouped[armature] = list(selected)
    if not grouped and include_active_fallback:
        active_bone = getattr(context, "active_pose_bone", None)
        active_armature = _pose_bone_owner(context, active_bone, armatures)
        if active_armature is not None and active_bone is not None:
            grouped[active_armature] = [active_bone]
    return grouped


def _selected_owner_bone_keys(context):
    return {
        _owner_bone_key(armature, pose_bone.name)
        for armature, pose_bones in _selected_pose_bones_by_owner(context).items()
        for pose_bone in pose_bones
    }


def _single_active_pose_bone(context):
    selected = _selected_pose_bones_only(context)
    if len(selected) != 1:
        return None
    active = context.active_pose_bone
    return active if active in selected else selected[0]


def _yellow_resync_armature(context, armature):
    pins = _yellow_owner_map("yellow_modes", armature)
    if not pins:
        return 0
    depsgraph = context.evaluated_depsgraph_get()
    evaluated_armature = armature.evaluated_get(depsgraph)
    objects, _active = _targets(context, armature)
    need_bounds = {
        name for name, mode in pins.items() if int(mode) in (2, 3)
    }
    bounds_world = {}
    if need_bounds:
        bounds_world = _collect_world_shape_from_largest_components(
            context,
            depsgraph,
            armature,
            evaluated_armature,
            need_bounds,
            objs = objects,
        )
    fixed = {}
    for bone_name, mode in pins.items():
        captured = _yellow_capture(
            context,
            depsgraph,
            armature,
            evaluated_armature,
            objects,
            bone_name,
            int(mode),
            bounds_world,
        )
        if captured:
            fixed[bone_name] = captured
            _yellow_store_target_property(
                armature,
                bone_name,
                captured[0],
            )
    _yellow_replace_owner_map("yellow_fixed", armature, fixed)
    _yellow_set_owner_hidden(armature, False)
    return len(fixed)

class STATICALIZA_OT_yellow_resync_all(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_resync_all"
    bl_label = "Update Pins"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE" and any(
            _yellow_owner_map("yellow_modes", armature)
            for armature in _pose_scope_armatures(context)
        )

    def execute(self, context):
        if not _state["yellow_modes"]:
            return {"CANCELLED"}
        updated = sum(
            _yellow_resync_armature(context, armature)
            for armature in _pose_scope_armatures(context)
        )
        if not updated:
            return {"CANCELLED"}
        _yellow_refresh_runtime(context)
        return {"FINISHED"}

class STATICALIZA_OT_yellow_clear_all(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_clear_all"
    bl_label = "Clear"
    bl_description = "Remove every Onion Pin"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE" and any(
            _yellow_owner_map("yellow_modes", armature)
            for armature in _pose_scope_armatures(context)
        )

    def execute(self, context):
        removed = 0
        for armature in _pose_scope_armatures(context):
            pins = _yellow_owner_map("yellow_modes", armature)
            for bone_name in pins:
                _yellow_clear_target_property(armature, bone_name)
            removed += len(pins)
            _yellow_replace_owner_map("yellow_modes", armature, {})
            _yellow_replace_owner_map("yellow_fixed", armature, {})
            _yellow_set_owner_hidden(armature, False)
        _yellow_refresh_runtime(context)
        self.report({"INFO"}, f"Cleared {removed} Onion Pin(s).")
        return {"FINISHED"}

class STATICALIZA_OT_yellow_hide_all(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_hide_all"
    bl_label = "Hide Pins"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def execute(self, context):
        for armature in _pose_scope_armatures(context):
            _yellow_set_owner_hidden(armature, True)
        _yellow_refresh_runtime(context)
        return {"FINISHED"}

class STATICALIZA_OT_yellow_show(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_show"
    bl_label = "Show Pins"
    bl_options = {"REGISTER"}

    resync: bpy.props.BoolProperty(default = False)

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def execute(self, context):
        for armature in _pose_scope_armatures(context):
            _yellow_set_owner_hidden(armature, False)
            if self.resync:
                _yellow_resync_armature(context, armature)

        _yellow_refresh_runtime(context)
        return {"FINISHED"}


def _yellow_apply_to_armature(context, armature, bones, action):
    pins = _yellow_owner_map("yellow_modes", armature)
    fixed = _yellow_owner_map("yellow_fixed", armature)
    selected_names = {bone.name for bone in bones if bone is not None}
    if not selected_names:
        return 0, 0

    if action in {"PIVOT", "PIVOT_FROM_START"}:
        depsgraph = context.evaluated_depsgraph_get()
        evaluated_armature = armature.evaluated_get(depsgraph)
        frame = int(context.scene.frame_current)
        changed = 0
        unreachable = 0
        for bone_name in selected_names:
            packed = fixed.get(bone_name)
            evaluated_bone = evaluated_armature.pose.bones.get(bone_name)
            pose_bone = armature.pose.bones.get(bone_name)
            if not packed or evaluated_bone is None or pose_bone is None:
                continue
            current = _yellow_current_world_point(
                depsgraph,
                evaluated_armature,
                evaluated_bone,
                packed,
            )
            if current is None:
                continue
            fixed_point = Vector(packed[0])
            if action == "PIVOT_FROM_START":
                armature_world = evaluated_armature.matrix_world.copy()
                head_world = armature_world @ evaluated_bone.head
                current_vector = current - head_world
                target_vector = fixed_point - head_world
                if (
                    current_vector.length <= 1.0e-8
                    or target_vector.length <= 1.0e-8
                ):
                    continue
                rotation = current_vector.rotation_difference(target_vector)
                stretch = target_vector.length / current_vector.length
                pivot_matrix = (
                    Matrix.Translation(head_world)
                    @ Matrix.Scale(stretch, 4)
                    @ rotation.to_matrix().to_4x4()
                    @ Matrix.Translation(-head_world)
                )
                bone_world = armature.matrix_world @ pose_bone.matrix
                pose_bone.matrix = armature.matrix_world.inverted() @ (
                    pivot_matrix @ bone_world
                )
                context.view_layer.update()

                depsgraph = context.evaluated_depsgraph_get()
                evaluated_armature = armature.evaluated_get(depsgraph)
                evaluated_bone = evaluated_armature.pose.bones.get(bone_name)
                if evaluated_bone is not None:
                    moved_head_world = (
                        evaluated_armature.matrix_world @ evaluated_bone.head
                    )
                    head_correction = head_world - moved_head_world
                    if head_correction.length > 1.0e-8:
                        correction_armature = (
                            armature.matrix_world.inverted().to_3x3()
                            @ head_correction
                        )
                        corrected = pose_bone.matrix.copy()
                        corrected.translation += correction_armature
                        pose_bone.matrix = corrected
                        context.view_layer.update()

                depsgraph = context.evaluated_depsgraph_get()
                evaluated_armature = armature.evaluated_get(depsgraph)
                evaluated_bone = evaluated_armature.pose.bones.get(bone_name)
                if evaluated_bone is not None:
                    solved = _yellow_current_world_point(
                        depsgraph,
                        evaluated_armature,
                        evaluated_bone,
                        packed,
                    )
                    if solved is not None and (fixed_point - solved).length > 0.05:
                        unreachable += 1
            else:
                delta = fixed_point - current
                try:
                    delta_armature = (
                        evaluated_armature.matrix_world.inverted().to_3x3()
                        @ delta
                    )
                except (ValueError, ZeroDivisionError):
                    delta_armature = Vector((0.0, 0.0, 0.0))
                matrix = pose_bone.matrix.copy()
                matrix.translation += delta_armature
                pose_bone.matrix = matrix
                context.view_layer.update()
            _insert_bone_keys(pose_bone, frame)
            changed += 1
        return changed, unreachable

    if action == "REMOVE":
        removed = 0
        for bone_name in selected_names:
            if bone_name in pins:
                removed += 1
            pins.pop(bone_name, None)
            fixed.pop(bone_name, None)
            _yellow_clear_target_property(armature, bone_name)
        _yellow_replace_owner_map("yellow_modes", armature, pins)
        _yellow_replace_owner_map("yellow_fixed", armature, fixed)
        return removed, 0

    mode = 1
    if action == "MODE_2":
        mode = 2
    elif action == "MODE_3":
        mode = 3
    depsgraph = context.evaluated_depsgraph_get()
    evaluated_armature = armature.evaluated_get(depsgraph)
    objects, _active = _targets(context, armature)
    need_bounds = selected_names if mode in (2, 3) else set()
    bounds_world = {}
    if need_bounds:
        bounds_world = _collect_world_shape_from_largest_components(
            context,
            depsgraph,
            armature,
            evaluated_armature,
            need_bounds,
            objs = objects,
        )
    captured_count = 0
    for bone_name in selected_names:
        pins[bone_name] = int(mode)
        captured = _yellow_capture(
            context,
            depsgraph,
            armature,
            evaluated_armature,
            objects,
            bone_name,
            int(mode),
            bounds_world,
        )
        if captured:
            fixed[bone_name] = captured
            _yellow_store_target_property(
                armature,
                bone_name,
                captured[0],
            )
            captured_count += 1
    fixed = {name: value for name, value in fixed.items() if name in pins}
    _yellow_replace_owner_map("yellow_modes", armature, pins)
    _yellow_replace_owner_map("yellow_fixed", armature, fixed)
    return captured_count, 0

class STATICALIZA_OT_yellow_apply(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_apply"
    bl_label = "Apply Yellow Pin"
    bl_options = {"REGISTER"}

    action: bpy.props.EnumProperty(
        items = (
            ("MODE_1", "Bone End", ""),
            ("MODE_2", "Bone Center", ""),
            ("MODE_3", "Smart Bottom", ""),
            ("PIVOT", "Pivot", ""),
            ("PIVOT_FROM_START", "Pivot from Bone Start", ""),
            ("REMOVE", "Remove", "")
        )
    )

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def execute(self, context):
        grouped = _selected_pose_bones_by_owner(
            context,
            include_active_fallback = True,
        )
        if not grouped:
            return {"CANCELLED"}
        changed = 0
        unreachable = 0
        for armature, bones in grouped.items():
            owner_changed, owner_unreachable = _yellow_apply_to_armature(
                context,
                armature,
                bones,
                self.action,
            )
            changed += owner_changed
            unreachable += owner_unreachable
        if unreachable:
            self.report(
                {"WARNING"},
                f"{unreachable} pin(s) could not be solved from the bone start.",
            )
        if not changed and self.action not in {"PIVOT", "PIVOT_FROM_START"}:
            return {"CANCELLED"}
        _yellow_refresh_runtime(context)
        return {"FINISHED"}
    
class STATICALIZA_MT_yellow_pin_menu(bpy.types.Menu):
    bl_label = "Onion Pin"

    def draw(self, context):
        sel_set = _selected_owner_bone_keys(context)
        pinned = set(_state.get("yellow_modes", {}).keys())

        any_pinned = bool(sel_set.intersection(pinned))

        layout = self.layout
        mode = getattr(context.window_manager, "yellow_pin_mode", "MODE_3")
        selected_pins = len(sel_set.intersection(pinned))
        update_text = "Update Selected Pin" if selected_pins == 1 else "Update Selected Pins"
        layout.operator("staticaliza.yellow_apply", text = update_text).action = mode

        if any_pinned:
            layout.separator()
            txt_piv = "Pivot Selected Pin" if len(sel_set) == 1 else "Pivot Selected Pins"
            layout.operator("staticaliza.yellow_apply", text = txt_piv).action = "PIVOT"

            txt_start = (
                "Pivot Selected Pin from Bone Start"
                if len(sel_set) == 1
                else "Pivot Selected Pins from Bone Start"
            )
            layout.operator(
                "staticaliza.yellow_apply",
                text = txt_start,
            ).action = "PIVOT_FROM_START"

            layout.separator()
            txt_rem = "Remove Selected Pin" if len(sel_set) == 1 else "Remove Selected Pins"
            layout.operator("staticaliza.yellow_apply", text = txt_rem).action = "REMOVE"

class STATICALIZA_MT_yellow_hidden_menu(bpy.types.Menu):
    bl_label = "Onion Pin"

    def draw(self, context):
        layout = self.layout
        op = layout.operator("staticaliza.yellow_show", text = "Show Pins")
        op.resync = False
        op2 = layout.operator("staticaliza.yellow_show", text = "Show and Update Pins")
        op2.resync = True

class STATICALIZA_MT_empty_cancel(bpy.types.Menu):
    bl_label = "Cancel"

    def draw(self, context):
        pass

class STATICALIZA_MT_yellow_no_selection_menu(bpy.types.Menu):
    bl_label = "Onion Pin"

    def draw(self, context):
        layout = self.layout
        layout.operator("staticaliza.yellow_hide_all", text = "Hide Pins")
        layout.operator("staticaliza.yellow_resync_all", text = "Update Pins")

class STATICALIZA_OT_yellow_menu(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_menu"
    bl_label = "Onion Pin"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def invoke(self, context, event):
        bones = _selected_pose_bones_only(context)
        scope = _pose_scope_armatures(context)
        scope_uids = {_armature_session_uid(armature) for armature in scope}
        scoped_pins = {
            key: value
            for key, value in _state.get("yellow_modes", {}).items()
            if int(key[0]) in scope_uids
        }

        if not bones:
            if not scoped_pins:
                return {"CANCELLED"}

            if any(_yellow_owner_hidden(armature) for armature in scope):
                bpy.ops.wm.call_menu(name = "STATICALIZA_MT_yellow_hidden_menu")
                return {"FINISHED"}

            bpy.ops.wm.call_menu(name = "STATICALIZA_MT_yellow_no_selection_menu")
            return {"FINISHED"}

        pinned = set(_state.get("yellow_modes", {}).keys())
        selected_keys = _selected_owner_bone_keys(context)
        if selected_keys.intersection(pinned):
            bpy.ops.wm.call_menu(name = "STATICALIZA_MT_yellow_pin_menu")
            return {"FINISHED"}

        mode = getattr(context.window_manager, "yellow_pin_mode", "MODE_3")
        return bpy.ops.staticaliza.yellow_apply("EXEC_DEFAULT", action = mode)

def _ensure_object_action(obj):
    if not obj.animation_data:
        obj.animation_data_create()
    if not obj.animation_data.action:
        obj.animation_data.action = bpy.data.actions.new(name = f"{obj.name}Action")
    _action_ensure_channelbag(obj.animation_data.action, obj)
    return obj.animation_data.action

def _fcurve_find(action, data_path):
    if not action:
        return None
    for fc in _action_fcurves(action):
        if fc.data_path == data_path:
            return fc
    return None

def _fcurves_find_all(action, data_path, animated_id = None):
    if not action:
        return []
    return [
        fc
        for fc in _action_fcurves(action, animated_id)
        if fc.data_path == data_path
    ]


def _fcurve_group_collection(action, fcurve):
    legacy_fcurves = getattr(action, "fcurves", None)
    if legacy_fcurves is not None:
        return action.groups

    try:
        target_pointer = int(fcurve.as_pointer())
    except (AttributeError, ReferenceError):
        target_pointer = 0
    for channelbag in _action_channelbags(action):
        if any(
            candidate is fcurve
            or (
                target_pointer
                and int(candidate.as_pointer()) == target_pointer
            )
            for candidate in channelbag.fcurves
        ):
            return channelbag.groups
    return None


def _set_fcurve_group(fcurve, action, group_name):
    groups = _fcurve_group_collection(action, fcurve)
    if groups is None:
        return False

    current_group = getattr(fcurve, "group", None)
    if (
        current_group is not None
        and str(getattr(current_group, "name", "")) == group_name
    ):
        return False
    target_group = groups.get(group_name)
    if target_group is None:
        target_group = groups.new(group_name)
    if current_group is target_group:
        return False

    fcurve.group = target_group
    if current_group is not None:
        try:
            if not tuple(current_group.channels):
                groups.remove(current_group)
        except (AttributeError, ReferenceError, RuntimeError, ValueError):
            pass
    return True


def _set_dynamic_parent_fcurve_group(owner, constraint):
    if owner is None or constraint is None:
        return False
    action = _dynamic_parent_owner_action(owner)
    if action is None:
        return False
    try:
        data_path = constraint.path_from_id("influence")
    except (AttributeError, TypeError, ValueError):
        return False
    animated_id = getattr(owner, "id_data", None) or owner
    changed = False
    for fcurve in _fcurves_find_all(action, data_path, animated_id):
        changed = _set_fcurve_group(
            fcurve,
            action,
            f"Dynamic Parent ({owner.name})",
        ) or changed
    return changed


def _set_dynamic_unparent_fcurve_group(armature, bone_name):
    if (
        armature is None
        or getattr(armature, "type", None) != "ARMATURE"
        or not bone_name
    ):
        return False
    animation_data = getattr(armature, "animation_data", None)
    action = getattr(animation_data, "action", None)
    if action is None:
        return False

    changed = False
    data_path = _unparent_dp(bone_name)
    for fcurve in _fcurves_find_all(action, data_path, armature):
        changed = _normalize_dynamic_marker_fcurve(fcurve) or changed
        changed = _set_fcurve_group(
            fcurve,
            action,
            f"Dynamic Unparent ({bone_name})",
        ) or changed
    return changed

def _fcurve_key_at(fc, frame):
    if not fc:
        return None
    for kp in fc.keyframe_points:
        if abs(float(kp.co.x) - float(frame)) <= 0.0001:
            return kp
    return None


def _migrate_dynamic_keyframe_names():
    try:
        actions = tuple(bpy.data.actions)
        objects = tuple(bpy.data.objects)
    except AttributeError:
        return False

    legacy_tokens = tuple(
        (f'["{legacy_name}"]', f'["{UNP_PROP}"]')
        for legacy_name in LEGACY_UNP_PROPS
    )

    for action in actions:
        for fcurve in tuple(_action_fcurves(action)):
            target_path = str(fcurve.data_path)
            for legacy_token, current_token in legacy_tokens:
                target_path = target_path.replace(legacy_token, current_token)
            if target_path == fcurve.data_path:
                continue

            curve_scope = tuple(_action_fcurves(action))
            if not hasattr(action, "fcurves"):
                for channelbag in _action_channelbags(action):
                    channel_curves = tuple(channelbag.fcurves)
                    if any(candidate is fcurve for candidate in channel_curves):
                        curve_scope = channel_curves
                        break

            duplicate = next(
                (
                    candidate
                    for candidate in curve_scope
                    if candidate is not fcurve
                    and candidate.data_path == target_path
                    and int(candidate.array_index) == int(fcurve.array_index)
                ),
                None,
            )
            if duplicate is None:
                try:
                    fcurve.data_path = target_path
                    fcurve.update()
                except (AttributeError, RuntimeError, TypeError, ValueError):
                    pass
                continue

            for source_key in tuple(fcurve.keyframe_points):
                frame = float(source_key.co.x)
                value = float(source_key.co.y)
                target_key = next(
                    (
                        key
                        for key in duplicate.keyframe_points
                        if abs(float(key.co.x) - frame) <= 1.0e-5
                    ),
                    None,
                )
                if target_key is None:
                    target_key = duplicate.keyframe_points.insert(frame, value)
                else:
                    target_key.co.y = value
                for attribute in (
                    "interpolation",
                    "type",
                    "handle_left_type",
                    "handle_right_type",
                ):
                    try:
                        setattr(target_key, attribute, getattr(source_key, attribute))
                    except (AttributeError, TypeError, ValueError):
                        pass
            duplicate.update()
            _action_remove_fcurve(action, fcurve)

    for obj in objects:
        for constraint in getattr(obj, "constraints", ()):
            if constraint.name.startswith("DP_"):
                _set_dynamic_parent_fcurve_group(obj, constraint)
        if obj.type != "ARMATURE" or getattr(obj, "pose", None) is None:
            continue
        for pose_bone in obj.pose.bones:
            _set_dynamic_unparent_fcurve_group(obj, pose_bone.name)
            for constraint in pose_bone.constraints:
                if constraint.name.startswith("DP_"):
                    _set_dynamic_parent_fcurve_group(pose_bone, constraint)
            for legacy_name in LEGACY_UNP_PROPS:
                if legacy_name not in pose_bone:
                    continue
                if UNP_PROP not in pose_bone:
                    pose_bone[UNP_PROP] = pose_bone[legacy_name]
                try:
                    del pose_bone[legacy_name]
                except (KeyError, TypeError):
                    pass
    return True


def _run_dynamic_keyframe_name_migration():
    return None if _migrate_dynamic_keyframe_names() else 0.1


def _animation_channel_entries():
    try:
        actions = tuple(bpy.data.actions)
    except AttributeError:
        return ()

    entries = []
    for action in actions:
        try:
            action_has_content = bool(_action_fcurves(action))
            entries.append(
                (("ACTION", int(action.as_pointer())), action, action_has_content)
            )
        except (AttributeError, ReferenceError):
            action_has_content = False
        for slot in getattr(action, "slots", ()):
            try:
                slot_handle = int(getattr(slot, "handle", 0))
                has_content = any(
                    int(getattr(channelbag, "slot_handle", 0)) == slot_handle
                    and bool(tuple(channelbag.fcurves))
                    for channelbag in _action_channelbags(action)
                )
                entries.append(
                    (("SLOT", int(slot.as_pointer())), slot, has_content)
                )
            except (AttributeError, ReferenceError):
                pass
        for groups in _action_group_owners(action):
            for group in groups:
                try:
                    entries.append(
                        (("GROUP", int(group.as_pointer())), group, True)
                    )
                except (AttributeError, ReferenceError):
                    pass
    return tuple(entries)


def _capture_animation_channel_baseline():
    entries = _animation_channel_entries()
    _state["expanded_animation_channels"] = {
        key for key, _channel, _has_content in entries
    }
    _state["animation_channel_content"] = {
        key: bool(has_content)
        for key, _channel, has_content in entries
    }
    expansion_requested = any(
        key[0] == "ACTION" and bool(has_content)
        for key, _channel, has_content in entries
    )
    _state["animation_channel_expand_pending"] = expansion_requested
    _state["animation_channel_expand_attempts"] = (
        3 if expansion_requested else 0
    )


def _expand_dopesheet_hierarchy():
    window_manager = getattr(bpy.context, "window_manager", None)
    if window_manager is None:
        return False

    attempted = False
    for window in window_manager.windows:
        for area in window.screen.areas:
            if area.type != "DOPESHEET_EDITOR":
                continue
            space = area.spaces.active
            if (
                str(getattr(area, "ui_type", "")) == "TIMELINE"
                or str(getattr(space, "mode", "")) == "TIMELINE"
            ):
                continue
            channel_region = next(
                (region for region in area.regions if region.type == "CHANNELS"),
                None,
            )
            if channel_region is None:
                continue
            dopesheet = getattr(space, "dopesheet", None)
            if dopesheet is not None:
                dopesheet.show_expanded_summary = True
            try:
                with bpy.context.temp_override(
                    window = window,
                    area = area,
                    region = channel_region,
                    space_data = space,
                ):
                    if bpy.ops.anim.channels_expand.poll():
                        result = bpy.ops.anim.channels_expand(all = True)
                        attempted = "FINISHED" in result or attempted
            except (AttributeError, RuntimeError, TypeError):
                continue

    # The operator opens Blender's private object/action hierarchy state. Keep
    # pose-bone transform channels folded so only the useful first level shows.
    for action in tuple(bpy.data.actions):
        for slot in getattr(action, "slots", ()):
            try:
                slot.show_expanded = True
            except (AttributeError, ReferenceError, TypeError):
                pass
        for groups in _action_group_owners(action):
            for group in groups:
                try:
                    group.show_expanded = False
                except (AttributeError, ReferenceError, TypeError):
                    pass

    if attempted:
        for window in window_manager.windows:
            for area in window.screen.areas:
                if (
                    area.type == "DOPESHEET_EDITOR"
                    and str(getattr(area, "ui_type", "")) != "TIMELINE"
                ):
                    area.tag_redraw()
    return attempted


def _expand_new_animation_channels():
    entries = _animation_channel_entries()
    if not entries:
        return 0.15

    seen = _state.setdefault("expanded_animation_channels", set())
    content_state = _state.setdefault("animation_channel_content", {})
    live = {key for key, _channel, _has_content in entries}
    expansion_requested = False
    for key, channel, has_content in entries:
        is_new = key not in seen
        gained_content = bool(has_content) and not bool(
            content_state.get(key, False)
        )
        try:
            # Reveal the action hierarchy, but keep each bone's transform
            # F-curves collapsed until the user explicitly expands that bone.
            if key[0] == "ACTION" and (
                gained_content or (is_new and has_content)
            ):
                expansion_requested = True
            elif key[0] == "SLOT" and (
                gained_content or (is_new and has_content)
            ):
                channel.show_expanded = True
                expansion_requested = True
            elif key[0] == "GROUP" and is_new:
                channel.show_expanded = False
                expansion_requested = True
        except (AttributeError, ReferenceError, TypeError):
            pass
        seen.add(key)
        content_state[key] = bool(has_content)
    seen.intersection_update(live)
    for key in tuple(content_state):
        if key not in live:
            content_state.pop(key, None)

    if expansion_requested:
        _state["animation_channel_expand_pending"] = True
        _state["animation_channel_expand_attempts"] = 3
    if _state.get("animation_channel_expand_pending", False):
        if _expand_dopesheet_hierarchy():
            attempts = max(
                0,
                int(_state.get("animation_channel_expand_attempts", 0)) - 1,
            )
            _state["animation_channel_expand_attempts"] = attempts
            _state["animation_channel_expand_pending"] = attempts > 0
    return 0.15


def _fcurve_remove_key_all(action, data_path, frame):
    if not action:
        return

    frame = int(frame)

    for fc in list(_fcurves_find_all(action, data_path)):
        removed = False

        for kp in list(fc.keyframe_points):
            try:
                fr = int(round(float(kp.co.x)))
            except Exception:
                continue

            if int(fr) != int(frame):
                continue

            try:
                fc.keyframe_points.remove(kp)
                removed = True
            except Exception:
                pass

        if removed:
            if not fc.keyframe_points:
                try:
                    _action_remove_fcurve(action, fc)
                except Exception:
                    pass
            else:
                try:
                    fc.update()
                except Exception:
                    pass

def _fcurve_set_constant(action, data_path, frame):
    if not action:
        return

    frame = float(int(frame))

    for fc in _fcurves_find_all(action, data_path):
        kp = _fcurve_key_at(fc, frame)
        if not kp:
            continue

        try:
            kp.interpolation = "CONSTANT"
        except Exception:
            pass

        try:
            kp.handle_left_type = "AUTO"
            kp.handle_right_type = "AUTO"
        except Exception:
            pass

        try:
            kp.type = "KEYFRAME"
        except Exception:
            pass

        try:
            fc.update()
        except Exception:
            pass

def _unparent_next_transform_keyframe(action, bone_name, after_frame):
    if not action:
        return None

    after_frame = int(after_frame)
    prefix = f'pose.bones["{bone_name}"].'
    best = None

    for prop in (
        "location",
        "scale",
        "rotation_euler",
        "rotation_quaternion",
        "rotation_axis_angle"
    ):
        for fc in _fcurves_find_all(action, prefix + prop):
            for kp in fc.keyframe_points:
                try:
                    fr = int(round(float(kp.co.x)))
                except Exception:
                    continue

                if fr <= after_frame:
                    continue

                if best is None or fr < best:
                    best = fr

    return int(best) if best is not None else None

def _unparent_next_start_after(action, bone_name, start_frame):
    if not action:
        return None

    s = int(start_frame)
    pts = _unparent_points(action, bone_name)
    if not pts:
        return None

    state = False
    inside = False

    for fr, v in pts:
        fr = int(fr)
        new_state = float(v) >= 0.5

        if fr <= s:
            state = new_state
            continue

        if inside:
            if new_state and not state:
                return int(fr)
        else:
            if state:
                inside = True

        state = new_state

    return None

def _unparent_allow_settle(action, bone_name, frame):
    nxt = _unparent_next_start_after(action, bone_name, int(frame))
    if nxt is None:
        return True
    return int(frame + 1) < int(nxt)

def _unparent_insert_hold_keys(context, arm, action, bone_name, frame, world_m, snap_pose, allow_next = True):
    scn = context.scene

    try:
        arm_inv = arm.matrix_world.inverted()
    except Exception:
        arm_inv = Matrix.Identity(4)

    f0 = int(frame)
    f1 = int(f0 + 1)

    do_f1 = bool(allow_next)
    if do_f1 and action:
        do_f1 = _unparent_allow_settle(action, bone_name, int(f0))
    if int(f1) > int(scn.frame_end):
        do_f1 = False

    scn.frame_set(int(f0))
    context.view_layer.update()

    pb0 = arm.pose.bones.get(bone_name)
    if pb0 and world_m is not None:
        try:
            pb0.matrix = arm_inv @ world_m
        except Exception:
            pass
        context.view_layer.update()
        _insert_bone_keys(pb0, int(f0))
        _set_pose_keys_vector_handles_new_only(action, bone_name, int(f0), snap_pose)

    if do_f1:
        scn.frame_set(int(f1))
        context.view_layer.update()

        pb1 = arm.pose.bones.get(bone_name)
        if pb1 and world_m is not None:
            try:
                pb1.matrix = arm_inv @ world_m
            except Exception:
                pass
            context.view_layer.update()
            _insert_bone_keys(pb1, int(f1))
            _set_pose_keys_vector_handles_new_only(action, bone_name, int(f1), snap_pose)

    lock_frames = {int(f0)}
    if do_f1:
        lock_frames.add(int(f1))

    for lf in sorted(lock_frames):
        _lock_pose_key_handles(action, bone_name, int(lf))

def _unparent_bake_to_end_target(context, action, bone_name, current_frame):
    scn = context.scene
    f_end = int(scn.frame_end)

    nxt_t = _unparent_next_transform_keyframe(action, bone_name, int(current_frame))
    nxt_s = _unparent_find_next_start_frame_from_points(action, bone_name, int(current_frame))

    targets = [f_end]
    if nxt_t is not None:
        targets.append(int(nxt_t))
    
    if nxt_s is not None:
        targets.append(int(nxt_s) - 1)

    return min(targets)

def _unparent_dp(bone_name):
    return f'pose.bones["{bone_name}"]["{UNP_PROP}"]'

def _pose_dp(bone_name, prop):
    return f'pose.bones["{bone_name}"].{prop}'

def _pb_prop_get(pb, key, default_value = 0.0):
    try:
        return float(pb.get(key, default_value))
    except Exception:
        return float(default_value)

def _pb_prop_set(pb, key, value):
    try:
        pb[key] = float(value)
    except Exception:
        pass

def _pb_prop_key(pb, key, frame):
    try:
        pb.keyframe_insert(data_path = f'["{key}"]', frame = int(frame), options = {"INSERTKEY_NEEDED"})
    except Exception:
        try:
            pb.keyframe_insert(data_path = f'["{key}"]', frame = int(frame))
        except Exception:
            pass
    _set_keyframe_handles_auto(pb, frame)
    if key == UNP_PROP:
        _set_dynamic_unparent_fcurve_group(pb.id_data, pb.name)

def _unparent_eval(action, bone_name, frame, pb_default = 0.0):
    if not action:
        return float(pb_default)

    dp = _unparent_dp(bone_name)
    fcs = _fcurves_find_all(action, dp)
    if not fcs:
        return float(pb_default)

    f = int(frame)
    v_best = None

    for fc in fcs:
        last_x = None
        last_v = None

        for kp in fc.keyframe_points:
            try:
                x = int(round(float(kp.co.x)))
                y = float(kp.co.y)
            except Exception:
                continue

            if x > f:
                continue

            if last_x is None or x > int(last_x):
                last_x = int(x)
                last_v = float(y)

        v = 0.0 if last_v is None else float(last_v)

        if v_best is None or float(v) > float(v_best):
            v_best = float(v)

    if v_best is None:
        return float(pb_default)
    return 1.0 if float(v_best) >= 0.5 else 0.0

def _unparent_remove_pose_keys_at(action, bone_name, frame):
    if not action:
        return

    for dp in (
        _pose_dp(bone_name, "location"),
        _pose_dp(bone_name, "scale"),
        _pose_dp(bone_name, "rotation_euler"),
        _pose_dp(bone_name, "rotation_quaternion"),
        _pose_dp(bone_name, "rotation_axis_angle")
    ):
        _fcurve_remove_key_all(action, dp, int(frame))

def _arm_pose_mtx_eval(context, arm, bone_name):
    depsgraph = context.evaluated_depsgraph_get()
    eval_arm = arm.evaluated_get(depsgraph)
    pb_eval = eval_arm.pose.bones.get(bone_name)
    if not pb_eval:
        return None
    try:
        return pb_eval.matrix.copy()
    except Exception:
        return None
    
def _insert_bone_keys(pb, frame, visual = True):
    frame = int(frame)
    opts = {"INSERTKEY_VISUAL"} if visual else set()

    pb.keyframe_insert(data_path = "location", frame = frame, options = opts)

    if pb.rotation_mode == "QUATERNION":
        pb.keyframe_insert(data_path = "rotation_quaternion", frame = frame, options = opts)
    elif pb.rotation_mode == "AXIS_ANGLE":
        pb.keyframe_insert(data_path = "rotation_axis_angle", frame = frame, options = opts)
    else:
        pb.keyframe_insert(data_path = "rotation_euler", frame = frame, options = opts)

    pb.keyframe_insert(data_path = "scale", frame = frame, options = opts)
    _set_keyframe_handles_auto(pb, frame)

def _rel_saved_parent(pb):
    b = pb.bone
    if REL_K_PARENT not in b:
        b[REL_K_PARENT] = pb.parent.name if pb.parent else ""
        try:
            b[REL_K_CONNECT] = 1 if bool(b.use_connect) else 0
        except Exception:
            b[REL_K_CONNECT] = 0
    return str(b.get(REL_K_PARENT, ""))

def _unparent_ensure_visual_constraint(arm, pb):
    c = pb.constraints.get(UNP_VIS_CONSTRAINT)
    if c and c.type != "LIMIT_LOCATION":
        try:
            pb.constraints.remove(c)
        except Exception:
            pass
        c = None

    if not c:
        c = pb.constraints.new("LIMIT_LOCATION")
        c.name = UNP_VIS_CONSTRAINT

    try:
        c.owner_space = "WORLD"
    except Exception:
        pass

    try:
        c.use_min_x = False
        c.use_min_y = False
        c.use_min_z = False
        c.use_max_x = False
        c.use_max_y = False
        c.use_max_z = False
    except Exception:
        pass

    try:
        c.mute = False
    except Exception:
        pass

    try:
        c.influence = 1.0
    except Exception:
        pass

    return c

def _unparent_remove_visual_constraint(pb):
    c = pb.constraints.get(UNP_VIS_CONSTRAINT)
    if not c:
        return
    try:
        pb.constraints.remove(c)
    except Exception:
        pass

def _safe_mode_set(mode):
    try:
        bpy.ops.object.mode_set(mode = mode)
        return True
    except Exception:
        return False

def _unparent_apply_relation(context, arm, bone_name, detach):
    if not arm or arm.type != "ARMATURE":
        return False

    saved_active = context.view_layer.objects.active
    saved_mode = bpy.context.mode

    try:
        try:
            context.view_layer.objects.active = arm
        except Exception:
            pass

        if not _safe_mode_set("EDIT"):
            return False

        eb = arm.data.edit_bones.get(bone_name)
        if not eb:
            return False

        b = arm.data.bones.get(bone_name)
        if not b:
            return False

        if detach:
            eb.parent = None
            try:
                eb.use_connect = False
            except Exception:
                pass
            return True

        parent_name = str(b.get(REL_K_PARENT, ""))
        try:
            connect_val = bool(int(b.get(REL_K_CONNECT, 0)))
        except Exception:
            connect_val = False

        if parent_name:
            eb.parent = arm.data.edit_bones.get(parent_name)
        else:
            eb.parent = None

        try:
            eb.use_connect = bool(connect_val)
        except Exception:
            pass

        return True

    except Exception:
        return False

    finally:
        try:
            if saved_mode.startswith("POSE"):
                _safe_mode_set("POSE")
            else:
                _safe_mode_set("OBJECT")
        except Exception:
            pass

        try:
            if saved_active:
                context.view_layer.objects.active = saved_active
        except Exception:
            pass

def _unparent_rel_get_cached(arm_name, bone_name):
    return bool(_state["unparent_rel_cache"].get(f"{arm_name}::{bone_name}", False))

def _unparent_rel_set_cached(arm_name, bone_name, detached):
    _state["unparent_rel_cache"][f"{arm_name}::{bone_name}"] = bool(detached)

def _unparent_relation_is_detached(pb):
    if pb is None:
        return False
    saved_parent_name = str(pb.bone.get(REL_K_PARENT, ""))
    return bool(saved_parent_name and pb.parent is None)

def _unparent_switch_preserve_pose(context, arm, pb, detach):
    action = arm.animation_data.action if arm.animation_data else None
    object_keys_before = _snapshot_object_keys_all(action)
    previous_autokey = _autokey_push(context)
    try:
        bone_name = pb.name
        pose_m = _arm_pose_mtx_eval(context, arm, bone_name)
        if pose_m is None:
            return False

        _rel_saved_parent(pb)
        _unparent_ensure_visual_constraint(arm, pb)

        if not _unparent_apply_relation(context, arm, bone_name, detach):
            return False

        context.view_layer.update()

        current_pb = arm.pose.bones.get(bone_name)
        if current_pb is None:
            return False
        try:
            current_pb.matrix = pose_m
        except Exception:
            return False

        context.view_layer.update()
        return _unparent_relation_is_detached(current_pb) == bool(detach)
    finally:
        current_action = arm.animation_data.action if arm.animation_data else None
        _cleanup_new_object_keys_all(current_action, object_keys_before)
        _autokey_pop(context, previous_autokey)

def _capture_pose_matrices(context, arm, bone_name, frames):
    scn = context.scene
    saved_frame = int(scn.frame_current)
    mats = {}

    try:
        for f in sorted({int(x) for x in frames}):
            scn.frame_set(int(f))
            context.view_layer.update()

            depsgraph = context.evaluated_depsgraph_get()
            eval_arm = arm.evaluated_get(depsgraph)
            pb_eval = eval_arm.pose.bones.get(bone_name)
            if not pb_eval:
                continue

            mats[int(f)] = (eval_arm.matrix_world @ pb_eval.matrix).copy()

    finally:
        scn.frame_set(saved_frame)
        context.view_layer.update()

    return mats

def _unparent_start_frame(pb):
    try:
        v = pb.bone.get(UNP_STATE_KEY, None)
    except Exception:
        v = None
    if v is None:
        return None
    try:
        return int(v)
    except Exception:
        return None

def _unparent_clear_start_frame(pb):
    try:
        if UNP_STATE_KEY in pb.bone:
            del pb.bone[UNP_STATE_KEY]
    except Exception:
        pass

def _unparent_is_active_at(context, arm, pb, frame):
    action = arm.animation_data.action if arm.animation_data else None
    if not action:
        return False
    v = _unparent_eval(action, pb.name, int(frame), pb_default = 0.0)
    return float(v) >= 0.5

def _unparent_points(action, bone_name):
    if not action:
        return []

    dp = _unparent_dp(bone_name)
    merged = {}

    for fc in _fcurves_find_all(action, dp):
        for kp in fc.keyframe_points:
            try:
                fr = int(round(float(kp.co.x)))
                v = float(kp.co.y)
            except Exception:
                continue

            if fr not in merged or v > float(merged[fr]):
                merged[fr] = float(v)

    out = [(int(fr), float(v)) for fr, v in merged.items()]
    out.sort(key = lambda x: int(x[0]))
    return out

def _unparent_find_active_start_frame(action, bone_name, frame):
    if not action:
        return None

    f = int(frame)
    pts = _unparent_points(action, bone_name)
    if not pts:
        return None

    state = False
    last_start = None

    for fr, v in pts:
        if fr > f:
            break

        new_state = float(v) >= 0.5
        if new_state and (not state or float(v) >= UNP_SPLIT_VALUE - 0.5):
            last_start = int(fr)

        state = new_state

    return int(last_start) if state and last_start is not None else None

def _unparent_find_end_frame(action, bone_name, start_frame):
    if not action:
        return None

    s = int(start_frame)
    pts = _unparent_points(action, bone_name)
    if not pts:
        return None

    for fr, v in pts:
        if int(fr) <= s:
            continue
        if float(v) < 0.5 or float(v) >= UNP_SPLIT_VALUE - 0.5:
            return int(fr)

    return None

def _unparent_find_start_frame_fallback(action, bone_name):
    if not action:
        return None

    pts = _unparent_points(action, bone_name)
    if not pts:
        return None

    for fr, v in pts:
        if float(v) >= 0.5:
            return int(fr)

    return None

def _unparent_find_next_start_frame_from_points(action, bone_name, frame):
    if not action:
        return None

    f = int(frame)
    pts = _unparent_points(action, bone_name)
    if not pts:
        return None

    state = False

    for fr, v in pts:
        if int(fr) <= f:
            state = float(v) >= 0.5
            continue

        new_state = float(v) >= 0.5
        if new_state and (not state or float(v) >= UNP_SPLIT_VALUE - 0.5):
            return int(fr)

        state = new_state

    return None

def _unparent_remove_window_keys_only(action, bone_name, start_f, end_f):
    if not action:
        return

    s = int(start_f)
    e = int(end_f)

    if e < s:
        s, e = e, s

    dp = _unparent_dp(bone_name)

    for fc in list(_fcurves_find_all(action, dp)):
        idxs = []

        try:
            kps = fc.keyframe_points
        except Exception:
            continue

        for i in range(len(kps)):
            try:
                fr = int(round(float(kps[i].co.x)))
            except Exception:
                continue

            if fr < s or fr > e:
                continue

            idxs.append(i)

        if not idxs:
            continue

        for i in reversed(idxs):
            try:
                fc.keyframe_points.remove(fc.keyframe_points[i])
            except RuntimeError:
                pass
            except Exception:
                pass

        try:
            if not fc.keyframe_points:
                try:
                    _action_remove_fcurve(action, fc)
                except Exception:
                    pass
            else:
                try:
                    fc.update()
                except Exception:
                    pass
        except Exception:
            pass

def _unparent_clear_cached_start_if_matches(pb, start_frame):
    if not pb:
        return
    sf = _unparent_start_frame(pb)
    if sf is None:
        return
    if int(sf) == int(start_frame):
        _unparent_clear_start_frame(pb)

def _autokey_push(context):
    ts = getattr(getattr(context, "scene", None), "tool_settings", None)
    if not ts:
        return None

    prev_auto = getattr(ts, "use_keyframe_insert_auto", None)
    prev_ks = getattr(ts, "use_keyframe_insert_keyingset", None)

    if prev_auto is not None:
        ts.use_keyframe_insert_auto = False

    if prev_ks is not None:
        ts.use_keyframe_insert_keyingset = False

    return (prev_auto, prev_ks)

def _autokey_pop(context, prev):
    ts = getattr(getattr(context, "scene", None), "tool_settings", None)
    if not ts or prev is None:
        return

    prev_auto, prev_ks = prev

    if prev_auto is not None:
        ts.use_keyframe_insert_auto = bool(prev_auto)

    if prev_ks is not None:
        ts.use_keyframe_insert_keyingset = bool(prev_ks)

def _obj_transform_dps():
    return (
        "location",
        "scale",
        "rotation_euler",
        "rotation_quaternion",
        "rotation_axis_angle",
        "delta_location",
        "delta_scale",
        "delta_rotation_euler",
        "delta_rotation_quaternion"
    )

def _snapshot_object_keys_all(action):
    out = {}
    if not action:
        return out
    for prop in _obj_transform_dps():
        keys = set()
        for fc in _fcurves_find_all(action, prop):
            idx = int(getattr(fc, "array_index", 0))
            for kp in fc.keyframe_points:
                keys.add((prop, idx, int(round(float(kp.co.x)))))
        out[prop] = keys
    return out

def _cleanup_new_object_keys_all(action, snap):
    if not action:
        return
    for prop in _obj_transform_dps():
        before = snap.get(prop, set()) if snap else set()
        for fc in list(_fcurves_find_all(action, prop)):
            idx = int(getattr(fc, "array_index", 0))
            removed_any = False
            for kp in list(fc.keyframe_points):
                x = int(round(float(kp.co.x)))
                key_id = (prop, idx, x)
                if key_id in before:
                    continue
                fc.keyframe_points.remove(kp)
                removed_any = True
            if removed_any:
                if not fc.keyframe_points:
                    try:
                        _action_remove_fcurve(action, fc)
                    except Exception:
                        pass
                else:
                    try:
                        fc.update()
                    except Exception:
                        pass
    for group_owner in _action_group_owners(action):
        for group in list(group_owner):
            if group.name != "Object Transforms":
                continue
            if len(group.channels) == 0:
                try:
                    group_owner.remove(group)
                except Exception:
                    pass

def _snapshot_bone_pose_keys(action, bone_name):
    out = set()
    if not action:
        return out

    for dp in (
        _pose_dp(bone_name, "location"),
        _pose_dp(bone_name, "scale"),
        _pose_dp(bone_name, "rotation_euler"),
        _pose_dp(bone_name, "rotation_quaternion"),
        _pose_dp(bone_name, "rotation_axis_angle")
    ):
        for fc in _fcurves_find_all(action, dp):
            idx = int(getattr(fc, "array_index", 0))
            for kp in fc.keyframe_points:
                out.add((dp, idx, int(round(float(kp.co.x)))))

    return out

def _set_pose_keys_vector_handles_new_only(action, bone_name, frame, snap):
    if not action:
        return

    frame = int(frame)

    for dp in (
        _pose_dp(bone_name, "location"),
        _pose_dp(bone_name, "scale"),
        _pose_dp(bone_name, "rotation_euler"),
        _pose_dp(bone_name, "rotation_quaternion"),
        _pose_dp(bone_name, "rotation_axis_angle")
    ):
        for fc in _fcurves_find_all(action, dp):
            idx = int(getattr(fc, "array_index", 0))

            if snap and (dp, idx, frame) in snap:
                continue

            kp = _fcurve_key_at(fc, frame)
            if not kp:
                continue

            try:
                kp.interpolation = "BEZIER"
            except Exception:
                pass

            try:
                kp.handle_left_type = "AUTO"
                kp.handle_right_type = "AUTO"
            except Exception:
                pass

            try:
                fc.update()
            except Exception:
                pass

def _unparent_has_marker_keys(action, bone_name):
    if not action:
        return False
    dp = _unparent_dp(bone_name)
    for fc in _fcurves_find_all(action, dp):
        try:
            if fc.keyframe_points and len(fc.keyframe_points) > 0:
                return True
        except Exception:
            pass
    return False

def _unparent_segment_at_frame(action, bone_name, frame):
    if not action:
        return (None, None, None, False)

    f = int(frame)
    start_f = _unparent_find_active_start_frame(action, bone_name, f)
    if start_f is None:
        return (None, None, None, False)

    start_f = int(start_f)
    end_f = _unparent_find_end_frame(action, bone_name, start_f)
    end_f = int(end_f) if end_f is not None else None

    next_start = _unparent_find_next_start_frame_from_points(action, bone_name, start_f)
    next_start = int(next_start) if next_start is not None else None

    conjoined = False
    if end_f is not None and next_start is not None:
        conjoined = int(end_f) == int(next_start)

    return (start_f, end_f, next_start, bool(conjoined))


def _unparent_nearest_segment(action, bone_name, frame, excluded_starts = None):
    points = _unparent_points(action, bone_name)
    if not points:
        return (None, None)

    excluded_starts = set(excluded_starts or ())
    segments = []
    active = False
    start_frame = None
    for point_frame, value in points:
        next_active = float(value) >= 0.5
        is_split = float(value) >= UNP_SPLIT_VALUE - 0.5
        if next_active and active and is_split and start_frame is not None:
            if int(start_frame) not in excluded_starts:
                segments.append((int(start_frame), int(point_frame)))
            start_frame = int(point_frame)
        elif next_active and not active:
            start_frame = int(point_frame)
        elif active and not next_active and start_frame is not None:
            if int(start_frame) not in excluded_starts:
                segments.append((int(start_frame), int(point_frame)))
            start_frame = None
        active = next_active

    if (
        active
        and start_frame is not None
        and int(start_frame) not in excluded_starts
    ):
        segments.append((int(start_frame), None))
    if not segments:
        return (None, None)

    current_frame = int(frame)

    def distance(segment):
        segment_start, segment_end = segment
        effective_end = segment_end if segment_end is not None else segment_start
        if segment_end is not None and segment_start <= current_frame <= segment_end:
            return 0
        return min(
            abs(current_frame - segment_start),
            abs(current_frame - effective_end),
        )

    return min(segments, key = lambda segment: (distance(segment), segment[0]))

def _unparent_cleanup_orphans(context, arm, action):
    for pb in arm.pose.bones:
        has_vis = bool(pb.constraints.get(UNP_VIS_CONSTRAINT))
        has_prop = (UNP_PROP in pb)

        if (not has_vis) and (not has_prop) and (not _unparent_relation_is_detached(pb)):
            continue

        fc = _fcurve_find(action, _unparent_dp(pb.name))
        if fc:
            continue

        saved_parent_name = str(pb.bone.get(REL_K_PARENT, ""))
        if saved_parent_name and (pb.parent is None):
            _unparent_switch_preserve_pose(context, arm, pb, False)

        _unparent_remove_visual_constraint(pb)

        if UNP_PROP in pb:
            try:
                del pb[UNP_PROP]
            except Exception:
                pass

        _unparent_rel_set_cached(arm.name, pb.name, False)
        _unparent_clear_start_frame(pb)

def _unparent_has_end_between(action, bone_name, a_frame, b_frame):
    if not action:
        return False

    dp = _unparent_dp(bone_name)
    fcs = _fcurves_find_all(action, dp)
    if not fcs:
        return False

    a = int(a_frame)
    b = int(b_frame)

    for fc in fcs:
        for kp in fc.keyframe_points:
            try:
                fr = int(round(float(kp.co.x)))
                v = float(kp.co.y)
            except Exception:
                continue
            if fr <= a or fr >= b:
                continue
            if float(v) < 0.5:
                return True

    return False

def _fcurve_prev_next_keyframes(fc, frame):
    prev_kp = None
    next_kp = None
    f = float(frame)

    for kp in fc.keyframe_points:
        x = float(kp.co.x)
        if x < f and (prev_kp is None or x > float(prev_kp.co.x)):
            prev_kp = kp
        if x > f and (next_kp is None or x < float(next_kp.co.x)):
            next_kp = kp

    return prev_kp, next_kp

def _lock_pose_key_handles(action, bone_name, frame):
    if not action:
        return

    frame = int(frame)

    for dp in (
        _pose_dp(bone_name, "location"),
        _pose_dp(bone_name, "scale"),
        _pose_dp(bone_name, "rotation_euler"),
        _pose_dp(bone_name, "rotation_quaternion"),
        _pose_dp(bone_name, "rotation_axis_angle")
    ):
        for fc in _fcurves_find_all(action, dp):
            kp = _fcurve_key_at(fc, frame)
            prev_kp, next_kp = _fcurve_prev_next_keyframes(fc, frame)

            for k in (prev_kp, kp, next_kp):
                if not k:
                    continue

                try:
                    k.interpolation = "BEZIER"
                except Exception:
                    pass

                try:
                    k.handle_left_type = "AUTO"
                    k.handle_right_type = "AUTO"
                except Exception:
                    pass

            try:
                fc.update()
            except Exception:
                pass

def _unparent_bake_window(context, arm, pb, start_frame, end_frame):
    scn = context.scene
    action = _ensure_object_action(arm)

    start_f = int(start_frame)
    end_f = int(end_frame)
    if end_f < start_f:
        start_f, end_f = end_f, start_f

    nxt_s = _unparent_find_next_start_frame_from_points(action, pb.name, start_f)
    
    is_abutting = False
    if nxt_s is not None:
        if int(end_f) >= int(nxt_s):
            end_f = int(nxt_s) - 1
            is_abutting = True
        elif int(end_f) == int(nxt_s) - 1:
            is_abutting = True

    obj_action = arm.animation_data.action if arm.animation_data else None
    obj_snap_all = _snapshot_object_keys_all(obj_action)

    if start_f < int(scn.frame_start) or start_f > int(scn.frame_end):
        return False

    end_f = max(int(scn.frame_start), min(int(end_f), int(scn.frame_end)))
    if end_f <= start_f:
        return False

    end_is_off = False
    if not is_abutting:
        try:
            end_is_off = _unparent_eval(action, pb.name, int(end_f), pb_default = 0.0) < 0.5
        except Exception:
            end_is_off = False

    baseline_f = int(start_f)
    bake_first = int(start_f + 1)
    bake_last = int(end_f - 1) if end_is_off else int(end_f)

    if bake_last < bake_first:
        bake_first = int(baseline_f)
        bake_last = int(baseline_f)

    snap_pose_before = _snapshot_bone_pose_keys(action, pb.name)
    had_end_plus_1 = any(int(fr) == int(end_f + 1) for _dp, _idx, fr in snap_pose_before)

    saved_frame = int(scn.frame_current)

    write_frames = {int(baseline_f)}
    if bake_last >= bake_first:
        write_frames.update(set(range(int(bake_first), int(bake_last) + 1)))
    if end_is_off:
        write_frames.add(int(end_f))

    capture_frames_list = sorted(list(write_frames))
    mats = {}

    _state["unparent_handler_mute"] = False
    
    try:
        pre_warm_f = int(capture_frames_list[0] - 1)
        if pre_warm_f >= int(scn.frame_start):
            scn.frame_set(pre_warm_f)
            context.view_layer.update()

        for f in capture_frames_list:
            scn.frame_set(int(f))
            context.view_layer.update()
            
            depsgraph = context.evaluated_depsgraph_get()
            eval_arm = arm.evaluated_get(depsgraph)
            pb_eval = eval_arm.pose.bones.get(pb.name)
            
            if pb_eval:
                try:
                    arm_mw = eval_arm.matrix_world.copy()
                    world_m = (arm_mw @ pb_eval.matrix).copy()
                    mats[int(f)] = (arm_mw, world_m)
                except Exception:
                    pass

    finally:
        try:
            scn.frame_set(int(saved_frame))
        except Exception:
            pass
        context.view_layer.update()

    if not mats:
        return False

    if end_is_off:
        last_on = int(end_f - 1)
        if int(last_on) in mats and int(end_f) in mats:
            mats[int(end_f)] = mats[int(last_on)]

    _state["unparent_handler_mute"] = True
    
    try:
        _fcurve_remove_key_all(action, _unparent_dp(pb.name), int(start_f))
        
        _unparent_remove_window_keys_only(action, pb.name, int(start_f) + 1, int(end_f))

        for fr in sorted(write_frames):
            _unparent_remove_pose_keys_at(action, pb.name, int(fr))

        context.view_layer.update()

        if not _unparent_switch_preserve_pose(context, arm, pb, False):
            return False

        _unparent_rel_set_cached(arm.name, pb.name, False)
        _unparent_remove_visual_constraint(pb)
        _unparent_clear_start_frame(pb)

        if action and (not _unparent_has_marker_keys(action, pb.name)):
            if UNP_PROP in pb:
                try:
                    del pb[UNP_PROP]
                except Exception:
                    pass

        context.view_layer.update()

        snap_pose = _snapshot_bone_pose_keys(action, pb.name)

        for fr in sorted(write_frames):
            if int(fr) not in mats:
                continue

            arm_mw, world_m = mats[int(fr)]

            scn.frame_set(int(fr))
            context.view_layer.update()

            pb2 = arm.pose.bones.get(pb.name)
            if not pb2:
                continue

            try:
                inv = arm_mw.inverted()
            except Exception:
                inv = Matrix.Identity(4)

            try:
                pb2.matrix = inv @ world_m
            except Exception:
                continue

            context.view_layer.update()
            
            _insert_bone_keys(pb2, int(fr))

            if int(fr) == int(baseline_f):
                _lock_pose_key_handles(action, pb.name, int(fr))
            elif end_is_off and int(fr) == int(end_f):
                _lock_pose_key_handles(action, pb.name, int(fr))
            else:
                _set_pose_keys_vector_handles_new_only(action, pb.name, int(fr), snap_pose)

        if (not had_end_plus_1) and int(end_f + 1) <= int(scn.frame_end):
            if not is_abutting:
                if not _unparent_is_active_at(context, arm, pb, int(end_f + 1)):
                    _unparent_remove_pose_keys_at(action, pb.name, int(end_f + 1))

        a0 = max(int(start_f), int(baseline_f - 2))
        a1 = min(int(end_f), int(baseline_f + 2))
        for lf in range(int(a0), int(a1) + 1):
            _lock_pose_key_handles(action, pb.name, int(lf))

        if bake_last >= bake_first:
            b0 = max(int(start_f), int(bake_last - 2))
            b1 = min(int(end_f), int(bake_last + 2))
            for lf in range(int(b0), int(b1) + 1):
                _lock_pose_key_handles(action, pb.name, int(lf))

        context.view_layer.update()
        _cleanup_new_object_keys_all(obj_action, obj_snap_all)

    finally:
        _state["unparent_handler_mute"] = False
        try:
            scn.frame_set(int(saved_frame))
        except Exception:
            pass
        context.view_layer.update()

    f_now = int(scn.frame_current)
    want_detached = _unparent_is_active_at(context, arm, pb, int(f_now))
    have_detached = _unparent_relation_is_detached(pb)

    _state["unparent_handler_mute"] = True
    try:
        if bool(want_detached) != bool(have_detached):
            if _unparent_switch_preserve_pose(context, arm, pb, bool(want_detached)):
                _unparent_rel_set_cached(arm.name, pb.name, bool(want_detached))

        if want_detached:
            _unparent_ensure_visual_constraint(arm, pb)
        else:
            _unparent_remove_visual_constraint(pb)

    finally:
        _state["unparent_handler_mute"] = False
        context.view_layer.update()
        _cleanup_new_object_keys_all(obj_action, obj_snap_all)

    return True

def _unparent_toggle(context, arm, pb, frame):
    scn = context.scene
    action = _ensure_object_action(arm)

    f = int(frame)
    f_prev = max(0, int(f - 1))

    saved_parent_name = str(pb.bone.get(REL_K_PARENT, ""))
    if pb.parent is None and not saved_parent_name:
        return False

    _unparent_ensure_visual_constraint(arm, pb)

    v_now = _unparent_eval(action, pb.name, int(f), pb_default = _pb_prop_get(pb, UNP_PROP, 0.0))
    in_window = float(v_now) >= 0.5

    dp = _unparent_dp(pb.name)
    fc_prop = _ddm_ensure_fcurve(action, dp, arm)

    if not in_window:
        snap_before = _snapshot_bone_pose_keys(action, pb.name)

        m_prev = _eval_pose_matrix_at_frame(context, arm, pb.name, int(f_prev))
        m_now = _eval_pose_matrix_at_frame(context, arm, pb.name, int(f))

        if m_prev is not None:
            _insert_stability_keys(context, arm, pb.name, int(f_prev), m_prev)

        _pb_prop_set(pb, UNP_PROP, 1.0)
        _ddm_insert_key(fc_prop, int(f), 1.0)

        try:
            fc_prop.update()
        except Exception:
            pass

        _unparent_inject_end_before_start(context, arm, pb, int(f))

        if _unparent_switch_preserve_pose(context, arm, pb, True):
            _unparent_rel_set_cached(arm.name, pb.name, True)

            if m_now is not None:
                _insert_stability_keys(context, arm, pb.name, int(f), m_now)

            for dp2 in (
                _pose_dp(pb.name, "location"),
                _pose_dp(pb.name, "scale"),
                _pose_dp(pb.name, "rotation_euler"),
                _pose_dp(pb.name, "rotation_quaternion"),
                _pose_dp(pb.name, "rotation_axis_angle")
            ):
                for fc in _fcurves_find_all(action, dp2):
                    idx = int(getattr(fc, "array_index", 0))

                    for src, dst in ((int(f), int(f + 1)), (int(f_prev), int(f))):
                        if (dp2, idx, int(src)) in snap_before:
                            continue
                        
                        kp_src = _fcurve_key_at(fc, int(src))
                        if not kp_src:
                            continue

                        kp_dst = _fcurve_key_at(fc, int(dst))
                        if kp_dst and (dp2, idx, int(dst)) not in snap_before:
                            try:
                                fc.keyframe_points.remove(kp_dst)
                            except Exception:
                                pass

                        try:
                            kp_src.co.x = float(dst)
                        except Exception:
                            pass

                    try:
                        fc.update()
                    except Exception:
                        pass

            return True

        return False

    snap_before = _snapshot_bone_pose_keys(action, pb.name)
    packs = _capture_pose_world_matrices_with_arm_mw(context, arm, pb.name, {int(f_prev), int(f)})
    world_prev = None
    arm_mw_f = None

    try:
        if int(f_prev) in packs:
            world_prev = packs[int(f_prev)][1]
        if int(f) in packs:
            arm_mw_f = packs[int(f)][0]
    except Exception:
        pass

    m_end_fix = None
    if world_prev is not None and arm_mw_f is not None:
        try:
            inv_f = arm_mw_f.inverted()
            m_end_fix = (inv_f @ world_prev).copy()
        except Exception:
            pass

    m_prev = _eval_pose_matrix_at_frame(context, arm, pb.name, int(f_prev))
    if m_prev is not None:
        _insert_stability_keys(context, arm, pb.name, int(f_prev), m_prev)

    _pb_prop_set(pb, UNP_PROP, 0.0)
    _ddm_insert_key(fc_prop, int(f_prev), 1.0)
    _ddm_insert_key(fc_prop, int(f), 0.0)

    try:
        fc_prop.update()
    except Exception:
        pass

    if _unparent_switch_preserve_pose(context, arm, pb, False):
        _unparent_rel_set_cached(arm.name, pb.name, False)
        if m_end_fix is None:
            m_end_fix = _eval_pose_matrix_at_frame(context, arm, pb.name, int(f))

        if m_end_fix is not None:
            _insert_stability_keys(context, arm, pb.name, int(f), m_end_fix)

        for dp2 in (
            _pose_dp(pb.name, "location"),
            _pose_dp(pb.name, "scale"),
            _pose_dp(pb.name, "rotation_euler"),
            _pose_dp(pb.name, "rotation_quaternion"),
            _pose_dp(pb.name, "rotation_axis_angle")
        ):
            for fc in _fcurves_find_all(action, dp2):
                idx = int(getattr(fc, "array_index", 0))
                for src, dst in ((int(f), int(f + 1)), (int(f_prev), int(f))):
                    if (dp2, idx, int(src)) in snap_before:
                        continue
                    kp_src = _fcurve_key_at(fc, int(src))
                    if not kp_src:
                        continue
                    kp_dst = _fcurve_key_at(fc, int(dst))
                    if kp_dst and (dp2, idx, int(dst)) not in snap_before:
                        try:
                            fc.keyframe_points.remove(kp_dst)
                        except Exception:
                            pass
                    try:
                        kp_src.co.x = float(dst)
                    except Exception:
                        pass
                try:
                    fc.update()
                except Exception:
                    pass
        return True
    return False

def _ddm_ensure_fcurve(action, data_path, animated_id = None):
    fc = _fcurve_find(action, data_path)
    if not fc:
        fc = _action_new_fcurve(action, data_path, animated_id)
    if (
        animated_id is not None
        and getattr(animated_id, "type", None) == "ARMATURE"
        and getattr(animated_id, "pose", None) is not None
    ):
        for pose_bone in animated_id.pose.bones:
            if data_path != _unparent_dp(pose_bone.name):
                continue
            _set_dynamic_unparent_fcurve_group(animated_id, pose_bone.name)
            fc = _fcurve_find(action, data_path) or fc
            break
    return fc

def _ddm_insert_key(fc, frame, value):
    for kp in fc.keyframe_points:
        if abs(kp.co.x - frame) < 0.001:
            try:
                fc.keyframe_points.remove(kp)
            except:
                pass
            break
    kp = fc.keyframe_points.insert(frame, value)
    kp.interpolation = "CONSTANT"
    kp.handle_left_type = "AUTO"
    kp.handle_right_type = "AUTO"
    return kp

def _unparent_inject_end_before_start(context, arm, pb, new_start_frame):
    action = arm.animation_data.action if arm.animation_data else None
    if not action:
        return
    dp = _unparent_dp(pb.name)
    fc = _ddm_ensure_fcurve(action, dp, arm)

    s_next = None
    sorted_pts = sorted(fc.keyframe_points, key = lambda k: k.co.x)

    for kp in sorted_pts:
        if kp.co.x > float(new_start_frame) + 0.1 and float(kp.co.y) > 0.5:
            s_next = int(round(float(kp.co.x)))
            break

    if s_next is None:
        return

    if int(s_next) <= int(new_start_frame) + 1:
        return

    mats = _capture_pose_matrices(context, arm, pb.name, {int(new_start_frame)})
    m_hold = mats.get(int(new_start_frame))
    if m_hold is None:
        return

    end_frame = int(s_next) - 1

    _unparent_remove_window_keys_only(action, pb.name, int(new_start_frame) + 1, end_frame)

    for fr in range(int(new_start_frame) + 1, end_frame + 1):
        _unparent_remove_pose_keys_at(action, pb.name, int(fr))

    snap_pose = _snapshot_bone_pose_keys(action, pb.name)
    _unparent_insert_hold_keys(context, arm, action, pb.name, end_frame, m_hold, snap_pose, allow_next = False)

    _lock_pose_key_handles(action, pb.name, end_frame)

    try:
        fc.update()
    except Exception:
        pass

def _unparent_remove_start_key(context, arm, pb, start_frame):
    action = arm.animation_data.action if arm.animation_data else None
    start_frame = int(start_frame)

    if action:
        end_key = _unparent_find_end_frame(action, pb.name, int(start_frame))
        next_start = _unparent_find_next_start_frame_from_points(action, pb.name, int(start_frame))

        conjoined = False
        if end_key is not None and next_start is not None:
            conjoined = int(end_key) == int(next_start) - 1

        dp = _unparent_dp(pb.name)

        if conjoined and end_key is not None:
            end_key = int(end_key)

            _unparent_remove_window_keys_only(action, pb.name, int(start_frame - 1), int(end_key))

            for fr in (int(start_frame - 1), int(start_frame), int(start_frame + 1)):
                _unparent_remove_pose_keys_at(action, pb.name, int(fr))

            for fr in (int(end_key - 1), int(end_key), int(end_key + 1)):
                _unparent_remove_pose_keys_at(action, pb.name, int(fr))

        else:
            for fr in (int(start_frame - 1), int(start_frame)):
                _fcurve_remove_key_all(action, dp, int(fr))

            if end_key is not None:
                end_key = int(end_key)
                for fr in (int(end_key - 1), int(end_key)):
                    _fcurve_remove_key_all(action, dp, int(fr))

            for fr in (int(start_frame - 1), int(start_frame), int(start_frame + 1)):
                _unparent_remove_pose_keys_at(action, pb.name, int(fr))

            if end_key is not None:
                for fr in (int(end_key - 1), int(end_key), int(end_key + 1)):
                    _unparent_remove_pose_keys_at(action, pb.name, int(fr))

    context.view_layer.update()

    f_now = int(context.scene.frame_current)
    want_detached = _unparent_is_active_at(context, arm, pb, int(f_now)) if action else False
    have_detached = _unparent_relation_is_detached(pb)

    _state["unparent_handler_mute"] = True
    try:
        if want_detached:
            _unparent_ensure_visual_constraint(arm, pb)
        else:
            _unparent_remove_visual_constraint(pb)

        if bool(want_detached) != bool(have_detached):
            _rel_saved_parent(pb)
            world_m = _arm_pose_mtx_eval(context, arm, pb.name)

            if _unparent_apply_relation(context, arm, pb.name, bool(want_detached)):
                context.view_layer.update()

                if world_m is not None:
                    try:
                        arm_inv = arm.matrix_world.inverted()
                    except Exception:
                        arm_inv = Matrix.Identity(4)

                    pb2 = arm.pose.bones.get(pb.name)
                    if pb2:
                        try:
                            pb2.matrix = arm_inv @ world_m
                        except Exception:
                            pass
                        context.view_layer.update()

                _unparent_rel_set_cached(arm.name, pb.name, bool(want_detached))

    finally:
        _state["unparent_handler_mute"] = False
        context.view_layer.update()

    if action and (not _unparent_has_marker_keys(action, pb.name)):
        if UNP_PROP in pb:
            try:
                del pb[UNP_PROP]
            except Exception:
                pass
        _unparent_clear_start_frame(pb)
    else:
        _unparent_clear_cached_start_if_matches(pb, int(start_frame))

    return True

def _unparent_remove_end_key(context, arm, pb, end_frame):
    action = arm.animation_data.action if arm.animation_data else None
    if not action:
        return False

    scn = context.scene
    f_now = int(scn.frame_current)
    end_frame = int(end_frame)

    prev_start = _unparent_find_active_start_frame(action, pb.name, int(end_frame - 1))
    next_start = None
    if prev_start is not None:
        next_start = _unparent_find_next_start_frame_from_points(action, pb.name, int(prev_start))

    _fcurve_remove_key_all(action, _unparent_dp(pb.name), int(end_frame))
    _fcurve_remove_key_all(action, _unparent_dp(pb.name), int(end_frame - 1))

    for fr in (int(end_frame - 1), int(end_frame), int(end_frame + 1)):
        _unparent_remove_pose_keys_at(action, pb.name, int(fr))

    context.view_layer.update()

    if prev_start is not None and next_start is not None:
        if not _unparent_has_end_between(action, pb.name, int(prev_start), int(next_start)):
            _fcurve_remove_key_all(action, _unparent_dp(pb.name), int(prev_start))
            _fcurve_remove_key_all(action, _unparent_dp(pb.name), int(prev_start - 1))

            for fr in (int(prev_start - 1), int(prev_start), int(prev_start + 1)):
                _unparent_remove_pose_keys_at(action, pb.name, int(fr))

            off_f = int(next_start - 1)
            if off_f >= int(scn.frame_start) and off_f <= int(scn.frame_end):
                pb_now = arm.pose.bones.get(pb.name)
                if pb_now:
                    _pb_prop_set(pb_now, UNP_PROP, 0.0)
                    _pb_prop_key(pb_now, UNP_PROP, int(off_f))
                    _fcurve_set_constant(action, _unparent_dp(pb.name), int(off_f))

    context.view_layer.update()

    want_detached = _unparent_is_active_at(context, arm, pb, int(f_now))
    have_detached = _unparent_relation_is_detached(pb)

    _state["unparent_handler_mute"] = True
    try:
        if want_detached:
            _unparent_ensure_visual_constraint(arm, pb)
        else:
            _unparent_remove_visual_constraint(pb)

        if bool(want_detached) != bool(have_detached):
            _rel_saved_parent(pb)

            world_m = _arm_pose_mtx_eval(context, arm, pb.name)

            if _unparent_apply_relation(context, arm, pb.name, bool(want_detached)):
                context.view_layer.update()

                if world_m is not None:
                    try:
                        arm_inv = arm.matrix_world.inverted()
                    except Exception:
                        arm_inv = Matrix.Identity(4)

                    pb2 = arm.pose.bones.get(pb.name)
                    if pb2:
                        try:
                            pb2.matrix = arm_inv @ world_m
                        except Exception:
                            pass
                        context.view_layer.update()

                _unparent_rel_set_cached(arm.name, pb.name, bool(want_detached))

    finally:
        _state["unparent_handler_mute"] = False
        context.view_layer.update()

    return True

def _capture_pose_world_matrices_with_arm_mw(context, arm, bone_name, frames):
    scn = context.scene
    saved_frame = int(scn.frame_current)
    mats = {}
    action = arm.animation_data.action if arm.animation_data else None

    try:
        for f in sorted({int(x) for x in frames}):
            scn.frame_set(int(f))
            _sync_dynamic_parent_constraints(int(f), arm)
            _set_unparent_relation_for_frame(
                context,
                arm,
                bone_name,
                action,
                int(f),
            )
            context.view_layer.update()

            depsgraph = context.evaluated_depsgraph_get()
            eval_arm = arm.evaluated_get(depsgraph)
            pb_eval = eval_arm.pose.bones.get(bone_name)
            if not pb_eval:
                continue

            try:
                arm_mw = eval_arm.matrix_world.copy()
                world_m = (arm_mw @ pb_eval.matrix).copy()
                source_bone = arm.pose.bones.get(bone_name)
                channels = None
                if source_bone is not None:
                    rotation_mode = source_bone.rotation_mode
                    rotation_property = get_rotation_mode(source_bone)
                    channels = {
                        "location": tuple(source_bone.location),
                        "scale": tuple(source_bone.scale),
                        "rotation_mode": rotation_mode,
                        "rotation_property": rotation_property,
                        "rotation": tuple(
                            getattr(source_bone, f"rotation_{rotation_property}")
                        ),
                    }
                mats[int(f)] = (arm_mw, world_m, channels)
            except Exception:
                pass

    finally:
        scn.frame_set(saved_frame)
        _sync_dynamic_parent_constraints(saved_frame, arm)
        _set_unparent_relation_for_frame(
            context,
            arm,
            bone_name,
            action,
            saved_frame,
        )
        context.view_layer.update()

    return mats

def _unparent_rel_scan_arm(arm):
    out = set()
    if not arm or arm.type != "ARMATURE":
        return out

    if getattr(arm, "pose", None) is not None:
        out.update(
            pose_bone.name
            for pose_bone in arm.pose.bones
            if _pose_space_managed(pose_bone)
        )

    action = arm.animation_data.action if arm.animation_data else None
    if not action:
        return out

    needle = f'["{UNP_PROP}"]'

    for fc in _action_fcurves(action, arm):
        dp = str(getattr(fc, "data_path", ""))
        if not dp or needle not in dp:
            continue
        if not dp.startswith('pose.bones["'):
            continue

        try:
            name = dp.split('pose.bones["', 1)[1].split('"]', 1)[0]
        except Exception:
            name = ""

        if name:
            out.add(name)

    return out

def _eval_pose_matrix_at_frame(context, arm, bone_name, frame):
    scn = context.scene
    saved = int(scn.frame_current)

    try:
        scn.frame_set(int(frame))
        context.view_layer.update()

        depsgraph = context.evaluated_depsgraph_get()
        eval_arm = arm.evaluated_get(depsgraph)
        pb_eval = eval_arm.pose.bones.get(bone_name)
        if not pb_eval:
            return None

        try:
            return pb_eval.matrix.copy()
        except Exception:
            return None

    finally:
        scn.frame_set(saved)
        context.view_layer.update()

def _insert_stability_keys(context, arm, bone_name, frame, matrix_value):
    if matrix_value is None:
        return

    scn = context.scene
    saved_frame = int(scn.frame_current)
    saved_mtx = _arm_pose_mtx_eval(context, arm, bone_name)

    try:
        scn.frame_set(int(frame))
        context.view_layer.update()

        pb = arm.pose.bones.get(bone_name)
        if not pb:
            return

        try:
            pb.matrix = matrix_value
        except Exception:
            return

        context.view_layer.update()
        _insert_bone_keys(pb, int(frame))

    finally:
        scn.frame_set(saved_frame)
        context.view_layer.update()

        if saved_mtx is not None:
            pb2 = arm.pose.bones.get(bone_name)
            if pb2:
                try:
                    pb2.matrix = saved_mtx
                except Exception:
                    pass

        context.view_layer.update()


def _pose_transform_key_frames(action, bone_name):
    frames = set()
    for data_path in (
        _pose_dp(bone_name, "location"),
        _pose_dp(bone_name, "scale"),
        _pose_dp(bone_name, "rotation_euler"),
        _pose_dp(bone_name, "rotation_quaternion"),
        _pose_dp(bone_name, "rotation_axis_angle"),
    ):
        for fcurve in _fcurves_find_all(action, data_path):
            frames.update(
                int(round(float(key.co.x)))
                for key in fcurve.keyframe_points
            )
    return frames


def _pose_transition_span_start(action, bone_name, frame):
    frame = int(frame)
    previous_frames = [
        key_frame
        for key_frame in _pose_transform_key_frames(action, bone_name)
        if int(key_frame) < frame
    ]
    if previous_frames:
        return max(previous_frames)
    return max(int(bpy.context.scene.frame_start), frame - 1)


def _transition_key_frames(action, bone_name, frame, end_exclusive = None):
    frame = int(frame)
    frames = {frame}
    for key_frame in _pose_transform_key_frames(action, bone_name):
        if int(key_frame) < frame:
            continue
        if end_exclusive is not None and int(key_frame) >= int(end_exclusive):
            continue
        frames.add(int(key_frame))
    return frames


def _set_unparent_relation_for_frame(context, arm, bone_name, action, frame):
    pose_bone = arm.pose.bones.get(bone_name)
    if pose_bone is None:
        return None

    if _pose_space_managed(pose_bone):
        pose_bone = _ensure_pose_space_system(
            context,
            arm,
            pose_bone,
            int(frame),
        )
        if pose_bone is not None:
            _unparent_remove_visual_constraint(pose_bone)
            _unparent_rel_set_cached(arm.name, bone_name, True)
        return pose_bone

    want_detached = _unparent_eval(
        action,
        bone_name,
        int(frame),
        pb_default = _pb_prop_get(pose_bone, UNP_PROP, 0.0),
    ) >= 0.5
    have_detached = _unparent_relation_is_detached(pose_bone)
    if bool(want_detached) != bool(have_detached):
        _rel_saved_parent(pose_bone)
        if not _unparent_apply_relation(
            context,
            arm,
            bone_name,
            bool(want_detached),
        ):
            return None
        context.view_layer.update()
        pose_bone = arm.pose.bones.get(bone_name)

    if pose_bone is None:
        return None
    if want_detached:
        _unparent_ensure_visual_constraint(arm, pose_bone)
    else:
        _unparent_remove_visual_constraint(pose_bone)
    _unparent_rel_set_cached(arm.name, bone_name, bool(want_detached))
    return pose_bone


def _dynamic_parent_input_matrix(context, arm, constraint, output_matrix):
    if (
        constraint is None
        or constraint.type != "CHILD_OF"
        or constraint.target is None
        or float(constraint.influence) <= 0.5
    ):
        return output_matrix

    depsgraph = context.evaluated_depsgraph_get()
    target = constraint.target.evaluated_get(depsgraph)
    if target.type == "ARMATURE" and constraint.subtarget:
        target_bone = target.pose.bones.get(constraint.subtarget)
        if target_bone is None:
            return output_matrix
        target_world = target.matrix_world @ target_bone.matrix
    else:
        target_world = target.matrix_world.copy()

    try:
        target_in_armature_space = arm.matrix_world.inverted() @ target_world
        child_of_matrix = target_in_armature_space @ constraint.inverse_matrix
        return child_of_matrix.inverted_safe() @ output_matrix
    except Exception:
        return output_matrix


def _restore_pose_world_span(context, arm, bone_name, captured_matrices):
    if not captured_matrices:
        return False

    scene = context.scene
    saved_frame = int(scene.frame_current)
    action = arm.animation_data.action if arm.animation_data else None
    object_keys_before = _snapshot_object_keys_all(action)
    previous_mute = bool(_state.get("unparent_handler_mute", False))
    _state["unparent_handler_mute"] = True
    restored = False
    try:
        for frame in sorted(captured_matrices):
            scene.frame_set(int(frame))
            _sync_dynamic_parent_constraints(int(frame), arm)
            context.view_layer.update()
            pose_bone = _set_unparent_relation_for_frame(
                context,
                arm,
                bone_name,
                action,
                int(frame),
            )
            if pose_bone is None:
                continue

            capture = captured_matrices[int(frame)]
            _captured_arm_world, world_matrix = capture[:2]
            try:
                armature_inverse = arm.matrix_world.inverted()
            except Exception:
                armature_inverse = Matrix.Identity(4)
            output_matrix = armature_inverse @ world_matrix
            dynamic_constraint = get_last_dynamic_parent_constraint(
                pose_bone,
                int(frame),
            )
            input_matrix = _dynamic_parent_input_matrix(
                context,
                arm,
                dynamic_constraint,
                output_matrix,
            )
            constraint_was_muted = bool(
                getattr(dynamic_constraint, "mute", False)
            ) if dynamic_constraint is not None else False
            try:
                if dynamic_constraint is not None:
                    dynamic_constraint.mute = True
                    context.view_layer.update()
                    pose_bone = arm.pose.bones.get(bone_name)
                pose_bone.matrix = input_matrix
            except Exception:
                if dynamic_constraint is not None:
                    dynamic_constraint.mute = constraint_was_muted
                    context.view_layer.update()
                continue

            context.view_layer.update()
            _insert_bone_keys(pose_bone, int(frame), visual = False)
            if dynamic_constraint is not None:
                dynamic_constraint.mute = constraint_was_muted
                context.view_layer.update()
            restored = True
    finally:
        scene.frame_set(saved_frame)
        _sync_dynamic_parent_constraints(saved_frame, arm)
        context.view_layer.update()
        _set_unparent_relation_for_frame(
            context,
            arm,
            bone_name,
            action,
            saved_frame,
        )
        _state["unparent_handler_mute"] = previous_mute
        _cleanup_new_object_keys_all(action, object_keys_before)
        context.view_layer.update()

    return restored


def _split_pose_unparent_segment(
    context,
    arm,
    pb,
    action,
    active_start,
    split_frame,
    original_end,
    split_factor,
):
    scene = context.scene
    saved_frame = int(scene.frame_current)
    previous_mute = bool(_state.get("unparent_handler_mute", False))
    first_source = _space_constraint_source_for_unparent(active_start)
    second_start = int(split_frame)
    second_source = _space_constraint_source_for_unparent(second_start)
    parent_name = str(pb.bone.get(REL_K_PARENT, ""))
    normal_role = SPACE_ROLE_NORMAL if parent_name else SPACE_ROLE_WORLD
    marker_curve = _ddm_ensure_fcurve(action, _unparent_dp(pb.name), arm)

    _state["unparent_handler_mute"] = True
    try:
        _remove_future_space_constraints(pb, first_source, int(split_frame))
        _ddm_insert_key(marker_curve, int(split_frame), UNP_SPLIT_VALUE)
        _set_dynamic_unparent_fcurve_group(arm, pb.name)
        if _switch_pose_underlying_space(
            context,
            arm,
            pb,
            normal_role,
            int(split_frame),
            split_factor,
            first_source,
        ) is None:
            return False

        scene.frame_set(second_start)
        _sync_dynamic_parent_constraints(second_start, arm)
        context.view_layer.update()
        pb = arm.pose.bones.get(pb.name)
        second_factor = _pose_space_factor(context, arm, pb)
        if _create_pose_space_constraint(
            context,
            arm,
            pb,
            SPACE_ROLE_UNPARENT,
            second_start,
            desired_factor = second_factor,
            source = second_source,
        ) is None:
            return False

        scene.frame_set(int(original_end))
        _sync_dynamic_parent_constraints(int(original_end), arm)
        context.view_layer.update()
        pb = arm.pose.bones.get(pb.name)
        end_factor = _pose_space_factor(context, arm, pb)
        if _switch_pose_underlying_space(
            context,
            arm,
            pb,
            normal_role,
            int(original_end),
            end_factor,
            second_source,
        ) is None:
            return False
        marker_curve.update()
        return True
    finally:
        scene.frame_set(saved_frame)
        _sync_dynamic_parent_constraints(saved_frame, arm)
        context.view_layer.update()
        pb = arm.pose.bones.get(pb.name)
        if pb is not None:
            _pb_prop_set(
                pb,
                UNP_PROP,
                _unparent_eval(action, pb.name, saved_frame, 0.0),
            )
        _state["unparent_handler_mute"] = previous_mute


def _unparent_toggle(context, arm, pb, frame):
    action = _ensure_object_action(arm)
    f = int(frame)
    saved_parent_name = str(pb.bone.get(REL_K_PARENT, ""))
    if pb.parent is None and not saved_parent_name:
        return False
    pb = _ensure_pose_space_system(
        context,
        arm,
        pb,
        f,
    )
    if pb is None:
        return False

    desired_factor = _pose_space_factor(context, arm, pb)
    v_now = _unparent_eval(
        action,
        pb.name,
        f,
        pb_default = _pb_prop_get(pb, UNP_PROP, 0.0),
    )
    in_window = float(v_now) >= 0.5
    active_start = _unparent_find_active_start_frame(action, pb.name, f)
    if in_window and active_start is None:
        return False

    existing_end = (
        _unparent_find_end_frame(action, pb.name, int(active_start))
        if in_window and active_start is not None
        else None
    )
    if existing_end is not None and f + 1 < int(existing_end):
        return _split_pose_unparent_segment(
            context,
            arm,
            pb,
            action,
            int(active_start),
            f,
            int(existing_end),
            desired_factor,
        )

    fc_prop = _ddm_ensure_fcurve(action, _unparent_dp(pb.name), arm)
    next_value = 0.0 if in_window else 1.0
    _pb_prop_set(pb, UNP_PROP, next_value)
    _ddm_insert_key(fc_prop, f, next_value)
    _set_dynamic_unparent_fcurve_group(arm, pb.name)
    if existing_end is not None and f < int(existing_end):
        _fcurve_remove_key_all(
            action,
            _unparent_dp(pb.name),
            int(existing_end),
        )
        _remove_future_space_constraints(
            pb,
            _space_constraint_source_for_unparent(active_start),
            f,
        )
    fc_prop.update()

    source_start = int(active_start) if in_window else f
    parent_name = str(pb.bone.get(REL_K_PARENT, ""))
    role = (
        SPACE_ROLE_UNPARENT
        if not in_window
        else (SPACE_ROLE_NORMAL if parent_name else SPACE_ROLE_WORLD)
    )
    constraint = _switch_pose_underlying_space(
        context,
        arm,
        pb,
        role,
        f,
        desired_factor,
        _space_constraint_source_for_unparent(source_start),
    )
    if constraint is None:
        return False

    context.scene.frame_set(f)
    _sync_dynamic_parent_constraints(f, arm)
    context.view_layer.update()
    return True


def _unparent_delete_segment_markers(action, bone_name, start_frame, end_frame = None):
    if action is None:
        return False
    start_frame = int(start_frame)
    end_frame = int(end_frame) if end_frame is not None else None
    removed = False
    data_path = _unparent_dp(bone_name)
    for fcurve in list(_fcurves_find_all(action, data_path)):
        points = {
            int(round(float(key.co.x))): float(key.co.y)
            for key in fcurve.keyframe_points
        }
        frames_to_remove = {start_frame}
        if end_frame is not None:
            frames_to_remove.add(end_frame)
            legacy_end_hold = end_frame - 1
            if legacy_end_hold != start_frame and points.get(legacy_end_hold, 0.0) > 0.5:
                frames_to_remove.add(legacy_end_hold)
        legacy_start_hold = start_frame - 1
        if points.get(legacy_start_hold, 1.0) < 0.5:
            frames_to_remove.add(legacy_start_hold)

        remove_indices = []
        for index, key in enumerate(fcurve.keyframe_points):
            key_frame = int(round(float(key.co.x)))
            if key_frame not in frames_to_remove:
                continue
            key_value = float(key.co.y)
            if (
                key_frame == start_frame
                and key_value >= UNP_SPLIT_VALUE - 0.5
            ):
                key.co.y = 0.0
                key.interpolation = "CONSTANT"
                removed = True
                continue
            if (
                end_frame is not None
                and key_frame == end_frame
                and key_value >= UNP_SPLIT_VALUE - 0.5
            ):
                key.co.y = 1.0
                key.interpolation = "CONSTANT"
                removed = True
                continue
            remove_indices.append(index)
        for index in reversed(remove_indices):
            fcurve.keyframe_points.remove(fcurve.keyframe_points[index])
            removed = True
        if not fcurve.keyframe_points:
            _action_remove_fcurve(action, fcurve)
        else:
            fcurve.update()
    return removed


def _clear_pose_space_unparent_segment(
    context,
    arm,
    pb,
    start_frame,
    end_frame,
):
    source = _space_constraint_source_for_unparent(start_frame)
    if not _space_constraints_with_source(pb, source):
        return None
    removed_space = _remove_pose_space_source(pb, source)

    action = arm.animation_data.action if arm.animation_data else None
    removed = _unparent_delete_segment_markers(
        action,
        pb.name,
        int(start_frame),
        int(end_frame) if end_frame is not None else None,
    )
    has_markers = _unparent_has_marker_keys(action, pb.name)
    if has_markers:
        _pb_prop_set(
            pb,
            UNP_PROP,
            _unparent_eval(
                action,
                pb.name,
                int(context.scene.frame_current),
                0.0,
            ),
        )
    elif UNP_PROP in pb:
        del pb[UNP_PROP]
    _unparent_remove_visual_constraint(pb)
    _unparent_clear_start_frame(pb)
    has_dynamic_parent = any(
        constraint.name.startswith("DP_")
        for constraint in pb.constraints
    )
    if not has_markers and not has_dynamic_parent:
        _teardown_pose_space_system(context, arm, pb)
    _sync_dynamic_parent_constraints(int(context.scene.frame_current), arm)
    context.view_layer.update()
    return bool(removed or removed_space)


def _unparent_clear_segment(context, arm, pb, start_frame, end_frame = None):
    action = arm.animation_data.action if arm.animation_data else None
    if action is None or pb is None:
        return False

    start_frame = int(start_frame)
    if end_frame is None:
        end_frame = _unparent_find_end_frame(action, pb.name, start_frame)
    end_frame = int(end_frame) if end_frame is not None else None

    space_result = _clear_pose_space_unparent_segment(
        context,
        arm,
        pb,
        start_frame,
        end_frame,
    )
    if space_result is not None:
        return space_result

    captured = _capture_pose_world_matrices_with_arm_mw(
        context,
        arm,
        pb.name,
        _transition_key_frames(
            action,
            pb.name,
            start_frame,
            end_exclusive = end_frame,
        ),
    )

    removed = _unparent_delete_segment_markers(
        action,
        pb.name,
        start_frame,
        end_frame,
    )

    current_frame = int(context.scene.frame_current)
    has_markers = _unparent_has_marker_keys(action, pb.name)
    current_bone = arm.pose.bones.get(pb.name)
    if current_bone is not None:
        _pb_prop_set(
            current_bone,
            UNP_PROP,
            _unparent_eval(action, pb.name, current_frame, 0.0)
            if has_markers
            else 0.0,
        )
    restored = _restore_pose_world_span(context, arm, pb.name, captured)
    current_bone = arm.pose.bones.get(pb.name)
    if current_bone is not None:
        if has_markers:
            _pb_prop_set(
                current_bone,
                UNP_PROP,
                _unparent_eval(action, pb.name, current_frame, 0.0),
            )
        else:
            _unparent_remove_visual_constraint(current_bone)
            if UNP_PROP in current_bone:
                del current_bone[UNP_PROP]
            _unparent_clear_start_frame(current_bone)
    return removed and (restored or bool(captured))


def _unparent_remove_end_marker(context, arm, pb, start_frame, end_frame):
    action = arm.animation_data.action if arm.animation_data else None
    if action is None or pb is None:
        return False

    start_frame = int(start_frame)
    end_frame = int(end_frame)
    captured = _capture_pose_world_matrices_with_arm_mw(
        context,
        arm,
        pb.name,
        _transition_key_frames(action, pb.name, end_frame),
    )

    data_path = _unparent_dp(pb.name)
    removed = False
    for fcurve in list(_fcurves_find_all(action, data_path)):
        remove_indices = []
        for index, key in enumerate(fcurve.keyframe_points):
            key_frame = int(round(float(key.co.x)))
            is_end = key_frame == end_frame
            is_legacy_hold = (
                key_frame == end_frame - 1
                and key_frame != start_frame
                and float(key.co.y) > 0.5
            )
            if is_end or is_legacy_hold:
                remove_indices.append(index)
        for index in reversed(remove_indices):
            fcurve.keyframe_points.remove(fcurve.keyframe_points[index])
            removed = True
        if not fcurve.keyframe_points:
            _action_remove_fcurve(action, fcurve)
        else:
            fcurve.update()

    if removed:
        _restore_pose_world_span(context, arm, pb.name, captured)
        current_bone = arm.pose.bones.get(pb.name)
        if current_bone is not None:
            _pb_prop_set(
                current_bone,
                UNP_PROP,
                _unparent_eval(
                    action,
                    pb.name,
                    int(context.scene.frame_current),
                    0.0,
                ),
            )
    return removed

def _unparent_cleanup_orphans(context, arm, action):
    for pb in arm.pose.bones:
        if _pose_space_managed(pb):
            _unparent_remove_visual_constraint(pb)
            continue
        has_vis = bool(pb.constraints.get(UNP_VIS_CONSTRAINT))
        has_prop = (UNP_PROP in pb)

        if (not has_vis) and (not has_prop) and (not _unparent_relation_is_detached(pb)):
            continue

        if action and _unparent_has_marker_keys(action, pb.name):
            continue

        saved_parent_name = str(pb.bone.get(REL_K_PARENT, ""))
        if saved_parent_name and (pb.parent is None):
            _unparent_switch_preserve_pose(context, arm, pb, False)

        _unparent_remove_visual_constraint(pb)

        if UNP_PROP in pb:
            try:
                del pb[UNP_PROP]
            except Exception:
                pass

        _unparent_rel_set_cached(arm.name, pb.name, False)
        _unparent_clear_start_frame(pb)

class STATICALIZA_OT_unparent_action(bpy.types.Operator):
    bl_idname = "staticaliza.unparent_action"
    bl_label = "Unparent Action"
    bl_options = {"REGISTER", "UNDO"}
    action: bpy.props.EnumProperty(
    items = (
            ("START", "Start", ""),
            ("END", "End", ""),
            ("BAKE", "Bake", ""),
            ("BAKE_TO_NEAREST", "Bake To Nearest", ""),
            ("BAKE_TO_ENDING", "Bake To End", ""),
            ("CLEAR", "Clear", ""),
            ("REMOVE_START", "Remove Start", ""),
            ("REMOVE_END", "Remove End", "")
        )
    )

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE" and _single_active_pose_bone(context) is not None

    def execute(self, context):
        prev_autokey = _autokey_push(context)
        previous_handler_mute = bool(_state.get("unparent_handler_mute", False))
        _state["unparent_handler_mute"] = True
        try:
            active_bone = _single_active_pose_bone(context)
            if active_bone is None:
                return {"CANCELLED"}
            arm = _pose_bone_owner(context, active_bone) or _active_armature(context)
            if not arm:
                return {"CANCELLED"}
            bones = (active_bone,)

            scn = context.scene
            f = int(scn.frame_current)
            action = arm.animation_data.action if arm.animation_data else None

            any_done = False

            if self.action in {"START", "END"}:
                for pb in bones:
                    if not pb:
                        continue

                    if (
                        action is not None
                        and _dynamic_marker_value(
                            action,
                            _unparent_dp(pb.name),
                            int(f),
                        ) is not None
                    ):
                        self.report(
                            {"ERROR"},
                            "A Dynamic Unparent marker already exists on this frame.",
                        )
                        continue

                    auto_starts = _dp_auto_unparent_start_frames(pb)
                    active_now = False
                    active_start = None
                    if action:
                        active_now = _unparent_eval(action, pb.name, int(f), pb_default = 0.0) >= 0.5
                        active_start = _unparent_find_active_start_frame(
                            action,
                            pb.name,
                            int(f),
                        )
                    active_is_auto = bool(
                        active_now
                        and active_start is not None
                        and int(active_start) in auto_starts
                    )

                    if self.action == "START" and (not active_now):
                        if _unparent_toggle(context, arm, pb, int(f)):
                            any_done = True

                    if (
                        self.action == "END"
                        and active_now
                        and not active_is_auto
                        and active_start is not None
                        and int(f) > int(active_start)
                    ):
                        if _unparent_toggle(context, arm, pb, int(f)):
                            any_done = True

                context.view_layer.update()
                _tag_redraw_all_view3d()
                return {"FINISHED"} if any_done else {"CANCELLED"}

            for pb in bones:
                if not pb:
                    continue

                auto_starts = _dp_auto_unparent_start_frames(pb)
                active_start = (
                    _unparent_find_active_start_frame(
                        action,
                        pb.name,
                        int(f),
                    )
                    if action
                    else None
                )
                if active_start is not None and int(active_start) in auto_starts:
                    continue

                if self.action == "CLEAR":
                    if not action:
                        continue
                    start_frame, end_frame, _next_start, _conjoined = (
                        _unparent_segment_at_frame(
                            action,
                            pb.name,
                            int(f),
                        )
                    )
                    if (
                        start_frame is not None
                        and int(start_frame) not in auto_starts
                        and _unparent_clear_segment(
                            context,
                            arm,
                            pb,
                            int(start_frame),
                            end_frame,
                        )
                    ):
                        any_done = True
                    continue

                active_now = _unparent_is_active_at(context, arm, pb, int(f))

                seg_start = None
                seg_end = None
                seg_next = None
                seg_conjoined = False

                if action:
                    seg_start, seg_end, seg_next, seg_conjoined = _unparent_segment_at_frame(action, pb.name, int(f))
                    if (
                        seg_start is not None
                        and int(seg_start) in auto_starts
                    ):
                        continue

                start_f = seg_start
                if start_f is None:
                    start_f = _unparent_start_frame(pb)
                if start_f is None and action:
                    start_f = _unparent_find_start_frame_fallback(action, pb.name)

                if self.action == "REMOVE_START":
                    if action and seg_start is not None:
                        if _unparent_clear_segment(
                            context,
                            arm,
                            pb,
                            int(seg_start),
                            seg_end,
                        ):
                            any_done = True
                    elif start_f is not None:
                        fallback_end = _unparent_find_end_frame(
                            action,
                            pb.name,
                            int(start_f),
                        ) if action else None
                        if _unparent_clear_segment(
                            context,
                            arm,
                            pb,
                            int(start_f),
                            fallback_end,
                        ):
                            any_done = True

                elif self.action == "REMOVE_END":
                    if action and seg_start is not None:
                        end_key = _unparent_find_end_frame(action, pb.name, int(seg_start))
                        if end_key is not None:
                            if _unparent_remove_end_marker(
                                context,
                                arm,
                                pb,
                                int(seg_start),
                                int(end_key),
                            ):
                                any_done = True

                elif self.action == "BAKE":
                    if action and seg_start is not None:
                        end_key = _unparent_find_end_frame(action, pb.name, int(seg_start))
                        if end_key is not None and int(end_key) != int(seg_start):
                            if _unparent_bake_window(context, arm, pb, int(seg_start), int(end_key)):
                                any_done = True

                elif self.action == "BAKE_TO_NEAREST":
                    if action and seg_start is not None:
                        end_key = _unparent_find_end_frame(action, pb.name, int(seg_start))

                        if end_key is not None:
                            end_f = int(end_key)
                        else:
                            end_f = int(_unparent_bake_to_end_target(context, action, pb.name, int(f)))

                        if int(end_f) != int(seg_start):
                            if _unparent_bake_window(context, arm, pb, int(seg_start), int(end_f)):
                                any_done = True

                elif self.action == "BAKE_TO_ENDING":
                    if action and seg_start is not None:
                        end_key = _unparent_find_end_frame(action, pb.name, int(seg_start))
                        
                        if end_key is not None:
                            end_f = int(end_key)
                        else:
                            end_f = int(scn.frame_end)

                        if int(end_f) != int(seg_start):
                            if _unparent_bake_window(context, arm, pb, int(seg_start), int(end_f)):
                                any_done = True

            context.view_layer.update()
            _tag_redraw_all_view3d()
            return {"FINISHED"} if any_done else {"CANCELLED"}

        finally:
            _state["unparent_handler_mute"] = previous_handler_mute
            _autokey_pop(context, prev_autokey)
            
class STATICALIZA_MT_unparent_menu_inactive(bpy.types.Menu):
    bl_label = "Dynamic Unparent"

    def draw(self, context):
        layout = self.layout
        layout.operator("staticaliza.unparent_action", text = "Create Start").action = "START"

class STATICALIZA_MT_unparent_menu_active(bpy.types.Menu):
    bl_label = "Dynamic Unparent Active"
    def draw(self, context):
        arm = _active_armature(context)
        pb = context.active_pose_bone
        action = arm.animation_data.action if (arm and arm.animation_data) else None
        f = int(context.scene.frame_current)
        hide_advanced = not getattr(
            context.window_manager,
            "roblox_compat_advanced_mode",
            False,
        )

        layout = self.layout

        if not arm or not pb or not action:
            layout.operator("staticaliza.unparent_action", text = "Create Start").action = "START"
            return

        start_f, end_f, next_start, conjoined = _unparent_segment_at_frame(action, pb.name, int(f))

        if (
            start_f is not None
            and int(start_f) in _dp_auto_unparent_start_frames(pb)
        ):
            layout.label(text = "Managed by Dynamic Parent")
            return

        if start_f is None:
            layout.operator("staticaliza.unparent_action", text = "Create Start").action = "START"
            return

        if end_f is None:
            layout.operator("staticaliza.unparent_action", text = "Create End").action = "END"
            layout.operator("staticaliza.unparent_action", text = "Clear").action = "CLEAR"
            if hide_advanced:
                return
            layout.operator("staticaliza.unparent_action", text = "Remove Start").action = "REMOVE_START"
            layout.separator()

            target_near = _unparent_bake_to_end_target(context, action, pb.name, int(f))
            if int(target_near) != int(start_f):
                layout.operator("staticaliza.unparent_action", text = "Bake To Nearest").action = "BAKE_TO_NEAREST"

            target_end = int(context.scene.frame_end)
            if int(target_end) != int(start_f):
                layout.operator("staticaliza.unparent_action", text = "Bake To End").action = "BAKE_TO_ENDING"
            return

        if conjoined:
            layout.operator("staticaliza.unparent_action", text = "Clear").action = "CLEAR"
            if hide_advanced:
                return
            layout.operator("staticaliza.unparent_action", text = "Remove Start").action = "REMOVE_START"
            layout.separator()
            layout.operator("staticaliza.unparent_action", text = "Bake").action = "BAKE"
            return

        layout.operator("staticaliza.unparent_action", text = "Clear").action = "CLEAR"
        if hide_advanced:
            return
        layout.operator("staticaliza.unparent_action", text = "Remove End").action = "REMOVE_END"
        layout.operator("staticaliza.unparent_action", text = "Remove Start").action = "REMOVE_START"
        layout.separator()
        layout.operator("staticaliza.unparent_action", text = "Bake").action = "BAKE"
        
class STATICALIZA_OT_unparent_menu(bpy.types.Operator):
    bl_idname = "staticaliza.unparent_menu"
    bl_label = "Retired Dynamic Unparent Shortcut"
    bl_description = "Alt+F was retired; use Ctrl+F for Animation Tools"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        return False

    def invoke(self, context, event):
        return {"CANCELLED"}

    def execute(self, context):
        return {"CANCELLED"}


def _unparent_apply_action_pose_channels(action, pose_bone, frame):
    if action is None or pose_bone is None:
        return False

    applied = False
    for property_name in (
        "location",
        "scale",
        "rotation_euler",
        "rotation_quaternion",
        "rotation_axis_angle",
    ):
        curves = _fcurves_find_all(
            action,
            _pose_dp(pose_bone.name, property_name),
        )
        if not curves:
            continue

        current_value = getattr(pose_bone, property_name, None)
        if current_value is None:
            continue
        values = list(current_value)
        for curve in curves:
            index = int(getattr(curve, "array_index", 0))
            if 0 <= index < len(values):
                values[index] = float(curve.evaluate(float(frame)))
                applied = True
        try:
            setattr(pose_bone, property_name, values)
        except (AttributeError, TypeError, ValueError):
            continue
    return applied


def _dynamic_space_marker_signature():
    signature = []
    for obj in tuple(bpy.data.objects):
        action = _dynamic_parent_owner_action(obj)
        if action is None:
            continue
        for fcurve in _action_fcurves(action, obj):
            data_path = str(fcurve.data_path)
            if not (
                (
                    'constraints["DP_' in data_path
                    and data_path.endswith(".influence")
                )
                or data_path.endswith(f'["{UNP_PROP}"]')
                or data_path.endswith(
                    f'["{SURFACE_CONTACT_MARKER_PROPERTY}"]'
                )
            ):
                continue
            points = tuple(
                (
                    round(float(key.co.x), 6),
                    round(float(key.co.y), 6),
                )
                for key in fcurve.keyframe_points
            )
            signature.append(
                (
                    int(obj.as_pointer()),
                    data_path,
                    int(getattr(fcurve, "array_index", 0)),
                    points,
                )
            )
    return tuple(signature)


def _dynamic_space_marker_watch_timer():
    if (
        _state.get("unparent_handler_mute", False)
        or _state.get("dynamic_space_export_sampling", False)
    ):
        return 0.25
    try:
        signature = _dynamic_space_marker_signature()
    except (AttributeError, ReferenceError, RuntimeError):
        return 0.25
    previous = _state.get("dynamic_space_marker_signature")
    _state["dynamic_space_marker_signature"] = signature
    if previous is None:
        _schedule_dynamic_space_reconcile(0.15)
    elif signature != previous:
        _schedule_dynamic_space_reconcile()
    return 0.25


def _run_scheduled_dynamic_space_reconcile():
    if (
        _state.get("unparent_handler_mute", False)
        or _state.get("dynamic_space_export_sampling", False)
    ):
        return 0.05

    quiet_time = time.monotonic() - float(
        _state.get("dynamic_space_last_action_update", 0.0)
    )
    if quiet_time < 0.15:
        return max(0.02, 0.15 - quiet_time)

    _state["dynamic_space_reconcile_pending"] = False
    context = bpy.context
    if context is None or context.scene is None:
        return None
    try:
        _reconcile_dynamic_space_markers(context)
        _state["dynamic_space_marker_signature"] = (
            _dynamic_space_marker_signature()
        )
    except Exception as exc:
        print(f"[Roblox Animator Utils] Dynamic marker sync failed: {exc}")
    return None


def _schedule_dynamic_space_reconcile(delay = 0.03):
    _state["dynamic_space_last_action_update"] = time.monotonic()
    if _state.get("dynamic_space_reconcile_pending", False):
        return
    _state["dynamic_space_reconcile_pending"] = True
    bpy.app.timers.register(
        _run_scheduled_dynamic_space_reconcile,
        first_interval = max(0.15, float(delay)),
    )


@persistent
def _dynamic_space_depsgraph_update(_scene, depsgraph):
    if (
        _state.get("unparent_handler_mute", False)
        or _state.get("dynamic_space_reconciling", False)
        or _state.get("dynamic_space_export_sampling", False)
    ):
        return
    for update in depsgraph.updates:
        if isinstance(getattr(update, "id", None), bpy.types.Action):
            _schedule_dynamic_space_reconcile()
            return


@persistent
def _dynamic_space_frame_change_pre(scene, _depsgraph):
    if _state.get("unparent_handler_mute", False) or scene is None:
        return
    _sync_dynamic_parent_constraints(int(scene.frame_current))


@persistent
def _unparent_frame_change_post(scene, depsgraph):
    if _state.get("unparent_handler_mute", False):
        return

    context = bpy.context
    if not context or not context.scene:
        return

    f = int(context.scene.frame_current)
    _calibrate_dynamic_space_boundaries(context, f)
    dynamic_parent_changed = _sync_dynamic_parent_constraints(f)
    if dynamic_parent_changed:
        context.view_layer.update()

    export_armature = _state.get("unparent_export_armature")
    if export_armature and getattr(export_armature, "type", None) == "ARMATURE":
        armatures = (export_armature,)
    else:
        armatures = tuple(
            obj
            for obj in bpy.data.objects
            if obj.type == "ARMATURE" and getattr(obj, "pose", None) is not None
        )

    changed = dynamic_parent_changed
    for arm in armatures:
        action = arm.animation_data.action if arm.animation_data else None
        if not action:
            for pose_bone in arm.pose.bones:
                if _pose_space_managed(pose_bone):
                    _ensure_pose_space_system(
                        context,
                        arm,
                        pose_bone,
                        f,
                    )
                _unparent_remove_visual_constraint(pose_bone)
            continue

        _unparent_cleanup_orphans(context, arm, action)
        for name in _unparent_rel_scan_arm(arm):
            pose_bone = arm.pose.bones.get(name)
            if pose_bone is None:
                continue

            if _pose_space_managed(pose_bone):
                pose_bone = _ensure_pose_space_system(
                    context,
                    arm,
                    pose_bone,
                    f,
                )
                if pose_bone is None:
                    continue
                if _unparent_has_marker_keys(action, name):
                    _pb_prop_set(
                        pose_bone,
                        UNP_PROP,
                        _unparent_eval(action, name, f, 0.0),
                    )
                elif UNP_PROP in pose_bone:
                    del pose_bone[UNP_PROP]
                _unparent_remove_visual_constraint(pose_bone)
                _unparent_rel_set_cached(arm.name, name, True)
                continue

            want_detached = _unparent_eval(
                action,
                name,
                f,
                pb_default = _pb_prop_get(pose_bone, UNP_PROP, 0.0),
            ) >= 0.5
            have_detached = _unparent_relation_is_detached(pose_bone)

            if want_detached:
                _unparent_ensure_visual_constraint(arm, pose_bone)
            else:
                _unparent_remove_visual_constraint(pose_bone)

            if bool(want_detached) == bool(have_detached):
                continue

            if _unparent_switch_preserve_pose(
                context,
                arm,
                pose_bone,
                bool(want_detached),
            ):
                _unparent_rel_set_cached(arm.name, name, bool(want_detached))
                current_bone = arm.pose.bones.get(name)
                _unparent_apply_action_pose_channels(action, current_bone, f)
                changed = True
                context.view_layer.update()

    if changed:
        try:
            bpy.context.view_layer.update()
        except (AttributeError, RuntimeError):
            pass
        _tag_redraw_all_view3d()

@persistent
def _load_post(*_):
    _state["yellow_fixed"] = {}
    _state["yellow_modes"] = {}
    _state["yellow_hidden"] = set()
    _state["onion_enabled_owners"] = set()
    _state["onion_property_syncing"] = False
    _state["mesh_batches"] = {}
    _state["raycast_fixed"] = {}
    _state["unparent_rel_cache"] = {}
    _state["unparent_handler_mute"] = False
    _state["dynamic_space_reconciling"] = False
    _state["dynamic_space_reconcile_pending"] = False
    _state["dynamic_space_calibrating"] = False
    _state["dynamic_space_export_sampling"] = False
    _state["dynamic_space_last_action_update"] = 0.0
    _state["dynamic_space_marker_signature"] = None
    _state["unparent_export_armature"] = None
    _state["smart_material_scan_pending"] = False
    _state["roblox_compatibility_scan_pending"] = False
    _state["roblox_armature_list_signature"] = None
    _state["armature_overlay_saved"] = {}
    _state["part_pivot_syncing"] = False
    _state["part_pivot_armature"] = 0
    _state["part_pivot_bone"] = ""
    _state["part_pivot_last_armature"] = 0
    _state["part_pivot_last_bone"] = ""
    _state["part_pivot_object"] = ""
    _state["part_pivot_object_local"] = None
    _state["part_pivot_saved"] = None
    _state["part_pivot_last_signature"] = None
    _state["part_pivot_cursor_visibility"] = {}
    _state["camera_view_spaces"] = {}
    _state["free_view_master"] = None
    _state["free_view_space_states"] = {}
    _state["free_view_settings_master"] = None
    _state["free_view_setting_states"] = {}
    _state["free_view_syncing"] = False
    _state["pose_mode_pending_rigs"] = set()
    _state["pose_mode_pending_attempts"] = 0
    _state["bone_label_selection_signature"] = None
    _state["pose_hidden_armatures"] = {}
    _state["pose_visibility_resume_after_save"] = False
    _state["rig_hover_mouse"] = {}
    _state["surface_contact_syncing"] = False
    _state["surface_contact_reconciling"] = False
    _state["surface_contact_solver_syncing"] = False
    _state["pin_target_dragging"] = False
    _state["pin_snap_transform_active"] = False
    _state["pin_snap_transform_operator"] = ""
    _state["pin_snap_syncing"] = False
    _state["pin_snap_latches"] = set()
    _state["pin_snap_departing"] = set()
    _state["pin_snap_detached"] = set()
    _state["pin_snap_transform_seen"] = set()
    _state["pin_snap_last_depsgraph_sync"] = 0.0
    _state["pin_gizmo_axes_visible"] = {}
    _state["pin_gizmo_selection_keys"] = ()
    _state["pin_gizmo_selected_key"] = ""
    _state["pin_gizmo_pending_click"] = None
    _state["pin_gizmo_selection_epoch"] = 0
    _state["pin_gizmo_claim_serial"] = 0
    _state["pin_gizmo_last_claim"] = None
    _state["pin_gizmo_extend_selection_until"] = 0.0
    _state["pin_gizmo_deferred_finishes"] = []
    _state["pin_keyboard_transform_active"] = False
    _state["pin_yellow_history_fallbacks"] = {}
    _state["pin_history_active"] = False
    _state["pin_history_contact_snapshot"] = None
    _state["pin_history_syncing"] = False
    _state["pin_clipboard"] = None
    _state["last_error"] = ""
    _state["surface_contact_solver_syncing"] = True
    try:
        bpy.context.view_layer.update()
        _surface_contact_restore_snap_detached(bpy.context)
    except (AttributeError, RuntimeError):
        pass
    finally:
        _state["surface_contact_solver_syncing"] = False
    _set_default_keyframe_handle_type()
    _migrate_dynamic_keyframe_names()
    _capture_animation_channel_baseline()
    window_manager = getattr(bpy.context, "window_manager", None)
    _set_onion_property(window_manager, False)
    if window_manager is not None and hasattr(
        window_manager,
        "staticaliza_pivot_mode",
    ):
        window_manager.staticaliza_pivot_mode = "BONE"
    _yellow_refresh_runtime(bpy.context)
    _state["smart_material_processed_rigs"] = set()
    _capture_material_import_baseline()
    _state["roblox_constraints_normalized"] = set()
    _state["roblox_constraints_new_rigs"] = set()
    _smart_material_import_scan(bpy.context.scene)
    _apply_roblox_compatibility(bpy.context.scene)
    _refresh_roblox_armature_list(bpy.context, force = True)
    _sync_view3d_relationship_lines(bpy.context)
    _sync_all_attached_camera_object_visibility()
    _unparent_frame_change_post(bpy.context.scene, None)
    _sync_surface_contact_constraints(bpy.context.scene)
    _unregister_addon_keymaps()
    if not _register_addon_keymaps():
        bpy.app.timers.register(
            _register_addon_keymaps_timer,
            first_interval = 0.05,
        )

def _clear_material_input_links(node_tree, socket_names, visited = None):
    if node_tree is None:
        return 0
    if getattr(node_tree, "library", None) is not None:
        return 0

    if visited is None:
        visited = set()

    tree_id = node_tree.as_pointer()
    if tree_id in visited:
        return 0
    visited.add(tree_id)

    removed = 0

    for node in node_tree.nodes:
        for socket_name in socket_names:
            socket = node.inputs.get(socket_name)
            if not socket or not socket.is_linked:
                continue

            for link in tuple(socket.links):
                node_tree.links.remove(link)
                removed += 1

        if node.type == "GROUP" and getattr(node, "node_tree", None):
            removed += _clear_material_input_links(node.node_tree, socket_names, visited)

    return removed

def dp_clear_material_links():
    removed = 0
    visited = set()

    for material in bpy.data.materials:
        if getattr(material, "library", None) is not None:
            continue
        if _is_bundled_template_baseplate_material(material):
            continue
        node_tree = getattr(material, "node_tree", None)
        if node_tree is None:
            continue
        removed += _clear_material_input_links(node_tree, {"Base Color", "Alpha"}, visited)

    return removed


def _is_bundled_template_baseplate_material(material):
    if material is None or material.name != "Baseplate":
        return False
    node_tree = getattr(material, "node_tree", None)
    if node_tree is None or not any(
        node.type == "TEX_IMAGE"
        and getattr(getattr(node, "image", None), "name", "") == "Baseplate.png"
        for node in node_tree.nodes
    ):
        return False

    baseplate = bpy.data.objects.get("Baseplate")
    if baseplate is None or baseplate.type != "MESH":
        return False
    return any(slot.material == material for slot in baseplate.material_slots)

def _strip_blender_numeric_suffix(name):
    base, separator, suffix = str(name).rpartition(".")
    if separator and suffix.isdigit():
        return base
    return name


def _find_child_collection_by_base_name(collection, base_name):
    if collection is None:
        return None
    for child in collection.children:
        if _strip_blender_numeric_suffix(child.name) == base_name:
            return child
    return None


def _object_world_bounds_center(obj):
    if not getattr(obj, "bound_box", None):
        return obj.matrix_world.to_translation()
    center = Vector((0.0, 0.0, 0.0))
    for corner in obj.bound_box:
        center += Vector(corner)
    return obj.matrix_world @ (center / 8.0)


def _is_matching_clothing_layer(base_obj, candidate):
    base_dimensions = tuple(abs(float(axis)) for axis in base_obj.dimensions)
    candidate_dimensions = tuple(abs(float(axis)) for axis in candidate.dimensions)
    if min(base_dimensions) <= 1.0e-6 or min(candidate_dimensions) <= 1.0e-6:
        return False

    for base_axis, candidate_axis in zip(base_dimensions, candidate_dimensions):
        if abs(base_axis - candidate_axis) / max(base_axis, candidate_axis) > 0.08:
            return False

    largest_dimension = max(max(base_dimensions), max(candidate_dimensions))
    center_distance = (
        _object_world_bounds_center(base_obj)
        - _object_world_bounds_center(candidate)
    ).length
    return center_distance <= largest_dimension * 0.03


def _set_imported_clothing_layer_offsets(parts_collection, enabled):
    mesh_objects = [
        obj for obj in parts_collection.all_objects if obj.type == "MESH"
    ]
    if not enabled:
        removed = 0
        for obj in mesh_objects:
            modifier = obj.modifiers.get(CLOTHING_LAYER_OFFSET_MODIFIER)
            if modifier is not None:
                obj.modifiers.remove(modifier)
                removed += 1
        return -removed

    families = {}
    for obj in mesh_objects:
        families.setdefault(_strip_blender_numeric_suffix(obj.name), []).append(obj)

    adjusted = 0
    for canonical_name, family in families.items():
        if len(family) < 2:
            continue

        linked_candidates = [
            obj for obj in family if _object_has_linked_base_color(obj)
        ]
        unlinked_candidates = [
            obj for obj in family if not _object_has_linked_base_color(obj)
        ]
        has_material_signal = bool(linked_candidates and unlinked_candidates)
        body_candidates = unlinked_candidates if has_material_signal else family
        body_candidates.sort(
            key = lambda obj: (
                float(obj.dimensions.x * obj.dimensions.y * obj.dimensions.z),
                obj.name != canonical_name,
                obj.name,
            )
        )
        body_obj = body_candidates[0]
        body_volume = abs(float(
            body_obj.dimensions.x
            * body_obj.dimensions.y
            * body_obj.dimensions.z
        ))

        for obj in family:
            if (
                obj == body_obj
                or (
                    has_material_signal
                    and not _object_has_linked_base_color(obj)
                )
                or not _is_matching_clothing_layer(body_obj, obj)
            ):
                continue
            if not has_material_signal:
                candidate_volume = abs(float(
                    obj.dimensions.x * obj.dimensions.y * obj.dimensions.z
                ))
                if candidate_volume <= body_volume * 1.0001:
                    continue

            modifier = obj.modifiers.get(CLOTHING_LAYER_OFFSET_MODIFIER)
            if modifier is None:
                modifier = obj.modifiers.new(
                    name = CLOTHING_LAYER_OFFSET_MODIFIER,
                    type = "DISPLACE",
                )
                adjusted += 1
            positive_dimensions = [
                abs(float(axis)) for axis in body_obj.dimensions if abs(float(axis)) > 1.0e-6
            ]
            reference_dimension = min(positive_dimensions, default = 1.0)
            modifier.direction = "NORMAL"
            modifier.mid_level = 0.0
            modifier.strength = max(0.001, min(0.02, reference_dimension * 0.005))

    return adjusted

def _get_smart_material_rig(collection):
    if not collection.name.startswith("RIG: "):
        return None

    rig_name = _strip_blender_numeric_suffix(collection.name[5:].strip())
    parts_collection = _find_child_collection_by_base_name(collection, "Parts")
    if not rig_name or parts_collection is None:
        return None

    armature_name = f"__{rig_name}_Armature"
    meta_name = f"__{rig_name}Meta"
    armature = None
    meta = None

    for obj in collection.all_objects:
        obj_name = _strip_blender_numeric_suffix(obj.name)
        if obj.type == "ARMATURE" and obj_name == armature_name:
            armature = obj
        elif obj.type == "EMPTY" and obj_name == meta_name:
            meta = obj

    if armature is None or meta is None:
        return None

    return rig_name, parts_collection


def _image_source_path(image):
    stored_path = str(image.get(RIG_TEXTURE_SOURCE_KEY, "")).strip()
    if stored_path and os.path.isfile(stored_path):
        return os.path.normcase(os.path.realpath(stored_path))

    raw_path = str(getattr(image, "filepath_raw", "") or image.filepath).strip()
    if not raw_path:
        return ""
    try:
        absolute_path = bpy.path.abspath(raw_path, library=image.library)
    except (AttributeError, RuntimeError, TypeError, ValueError):
        absolute_path = bpy.path.abspath(raw_path)
    return os.path.normcase(os.path.realpath(absolute_path))


def _safe_rig_texture_name(name):
    safe_name = "".join(
        character if character.isalnum() or character in {"-", "_", "."} else "_"
        for character in str(name)
    ).strip("._")
    return safe_name or "texture"


def _copy_image_color_settings(source, destination):
    for attribute in ("alpha_mode", "use_view_as_render"):
        try:
            setattr(destination, attribute, getattr(source, attribute))
        except (AttributeError, TypeError, ValueError):
            pass
    try:
        destination.colorspace_settings.name = source.colorspace_settings.name
    except (AttributeError, TypeError, ValueError):
        pass


def _isolated_rig_image(source_image, rig_name, rig_token, image_cache):
    source_path = _image_source_path(source_image)
    cache_key = source_path or f"IMAGE:{source_image.as_pointer()}"
    cached = image_cache.get(cache_key)
    if cached is not None:
        return cached

    isolated = None
    if source_path and os.path.isfile(source_path):
        try:
            isolated = bpy.data.images.load(source_path, check_existing=False)
        except (RuntimeError, OSError):
            isolated = None
    if isolated is None:
        isolated = source_image.copy()

    _copy_image_color_settings(source_image, isolated)
    source_filename = os.path.basename(source_path) if source_path else source_image.name
    source_filename = _safe_rig_texture_name(source_filename)
    isolated.name = f"{rig_name}::{source_filename}"
    isolated[RIG_TEXTURE_SOURCE_KEY] = source_path
    isolated[RIG_TEXTURE_OWNER_KEY] = rig_name
    if isolated.packed_file is None:
        try:
            isolated.pack()
        except (RuntimeError, OSError):
            pass
    if isolated.packed_file is not None:
        isolated.filepath = (
            f"//.staticaliza_rig_textures/{rig_token}/{source_filename}"
        )
    image_cache[cache_key] = isolated
    return isolated


def _isolate_node_tree_images(
    node_tree,
    rig_name,
    rig_token,
    image_cache,
    group_cache,
    visited=None,
):
    if node_tree is None:
        return 0
    if visited is None:
        visited = set()
    pointer = node_tree.as_pointer()
    if pointer in visited:
        return 0
    visited.add(pointer)

    replaced = 0
    for node in node_tree.nodes:
        if node.type == "TEX_IMAGE" and node.image is not None:
            isolated = _isolated_rig_image(
                node.image,
                rig_name,
                rig_token,
                image_cache,
            )
            if isolated is not node.image:
                node.image = isolated
                replaced += 1
            continue

        if node.type != "GROUP" or getattr(node, "node_tree", None) is None:
            continue
        original_group = node.node_tree
        group_pointer = original_group.as_pointer()
        isolated_group = group_cache.get(group_pointer)
        if isolated_group is None:
            isolated_group = original_group.copy()
            isolated_group.name = f"{rig_name}::{original_group.name}"
            group_cache[group_pointer] = isolated_group
        node.node_tree = isolated_group
        replaced += _isolate_node_tree_images(
            isolated_group,
            rig_name,
            rig_token,
            image_cache,
            group_cache,
            visited,
        )
    return replaced


def _isolate_imported_rig_textures(rig_collection, parts_collection):
    rig_name = _strip_blender_numeric_suffix(rig_collection.name[5:].strip())
    token_source = (
        f"{rig_collection.name}|{rig_collection.as_pointer()}|{time.time_ns()}"
    )
    rig_token = hashlib.sha1(token_source.encode("utf-8")).hexdigest()[:12]
    material_cache = {}
    image_cache = {}
    group_cache = {}
    original_materials = set()
    original_images = set()
    replaced_images = 0

    for obj in parts_collection.all_objects:
        if obj.type != "MESH":
            continue
        for slot in obj.material_slots:
            source_material = slot.material
            if source_material is None:
                continue
            material_pointer = source_material.as_pointer()
            isolated_material = material_cache.get(material_pointer)
            if isolated_material is None:
                isolated_material = source_material.copy()
                isolated_material.name = f"{rig_name}::{source_material.name}"
                original_materials.add(source_material)
                for node in getattr(
                    getattr(source_material, "node_tree", None),
                    "nodes",
                    (),
                ):
                    if node.type == "TEX_IMAGE" and node.image is not None:
                        original_images.add(node.image)
                replaced_images += _isolate_node_tree_images(
                    isolated_material.node_tree,
                    rig_name,
                    rig_token,
                    image_cache,
                    group_cache,
                )
                material_cache[material_pointer] = isolated_material
            slot.material = isolated_material

    for material in original_materials:
        if material.users == 0:
            bpy.data.materials.remove(material)
    for image in original_images:
        if image.users == 0 and image.name != "Baseplate.png":
            bpy.data.images.remove(image)

    return replaced_images, len(material_cache)


def _isolate_newly_imported_rig_textures(previous_collection_pointers):
    isolated_images = 0
    isolated_materials = 0
    for collection in bpy.data.collections:
        if collection.as_pointer() in previous_collection_pointers:
            continue
        if not collection.name.startswith("RIG: "):
            continue
        parts_collection = _find_child_collection_by_base_name(
            collection,
            "Parts",
        )
        if parts_collection is None:
            continue
        image_count, material_count = _isolate_imported_rig_textures(
            collection,
            parts_collection,
        )
        isolated_images += image_count
        isolated_materials += material_count
    return isolated_images, isolated_materials

def _smart_disconnect_base_color_links(node_tree, visited = None):
    if node_tree is None or getattr(node_tree, "library", None) is not None:
        return 0

    if visited is None:
        visited = set()

    tree_id = node_tree.as_pointer()
    if tree_id in visited:
        return 0
    visited.add(tree_id)

    removed = 0
    for node in node_tree.nodes:
        if node.type == "BSDF_PRINCIPLED":
            base_color = node.inputs.get("Base Color")
            normal = node.inputs.get("Normal")
            if base_color and base_color.is_linked and normal and normal.is_linked:
                for link in tuple(base_color.links):
                    node_tree.links.remove(link)
                    removed += 1

        if node.type == "GROUP" and getattr(node, "node_tree", None):
            removed += _smart_disconnect_base_color_links(node.node_tree, visited)

    return removed


def _capture_material_import_baseline():
    try:
        materials = bpy.data.materials
    except AttributeError:
        return False
    _state["material_import_baseline"] = {
        int(material.as_pointer()) for material in materials
    }
    return True


def _initialize_material_import_tracking():
    return None if _capture_material_import_baseline() else 0.1


def _standardize_imported_material_display(material):
    material.diffuse_color = IMPORTED_MATERIAL_DISPLAY_COLOR
    material.metallic = 0.0
    material.roughness = 0.5

def _smart_material_import_scan(scene):
    context = bpy.context
    wm = getattr(context, "window_manager", None)
    if wm is None:
        return

    smart_enabled = getattr(wm, "smart_material_import_enabled", True)
    display_enabled = getattr(
        wm,
        "standardize_imported_material_display_enabled",
        True,
    )
    clothing_offset_enabled = getattr(
        wm,
        "prevent_clothing_layer_clipping_enabled",
        False,
    )

    processed = _state.setdefault("smart_material_processed_rigs", set())
    material_baseline = _state.get("material_import_baseline")
    if material_baseline is None:
        if not _capture_material_import_baseline():
            return
        material_baseline = _state["material_import_baseline"]
    current_rigs = set()

    for collection in bpy.data.collections:
        rig = _get_smart_material_rig(collection)
        if rig is None:
            continue

        rig_name, parts_collection = rig
        rig_id = collection.as_pointer()
        current_rigs.add(rig_id)
        if rig_id in processed:
            continue

        removed = 0
        standardized = 0
        adjusted_layers = 0
        material_ids = set()
        visited_trees = set()

        for obj in parts_collection.all_objects:
            if obj.type != "MESH":
                continue
            for slot in obj.material_slots:
                material = slot.material
                if material is None or getattr(material, "library", None) is not None:
                    continue
                material_id = material.as_pointer()
                if material_id in material_ids:
                    continue
                material_ids.add(material_id)
                if smart_enabled:
                    removed += _smart_disconnect_base_color_links(
                        material.node_tree,
                        visited_trees,
                    )
                if display_enabled and material_id not in material_baseline:
                    _standardize_imported_material_display(material)
                    standardized += 1

        adjusted_layers = _set_imported_clothing_layer_offsets(
            parts_collection,
            clothing_offset_enabled,
        )

        processed.add(rig_id)
        if removed:
            print(f"[Smart Material Import] Removed {removed} Base Color link(s) from '{rig_name}'.")
        if standardized:
            print(
                f"[Smart Material Import] Standardized {standardized} viewport "
                f"material(s) on '{rig_name}'."
            )
        if adjusted_layers > 0:
            print(
                f"[Smart Material Import] Offset {adjusted_layers} clothing "
                f"layer(s) on '{rig_name}' to prevent clipping."
            )
        elif adjusted_layers < 0:
            print(
                f"[Smart Material Import] Removed {-adjusted_layers} clothing "
                f"layer offset(s) from '{rig_name}'."
            )

    processed.intersection_update(current_rigs)

def _on_smart_material_import_toggle(self, context):
    _state["smart_material_processed_rigs"] = set()
    _smart_material_import_scan(context.scene)

@persistent
def _smart_material_import_depsgraph_update(scene, depsgraph):
    for update in depsgraph.updates:
        datablock = getattr(update, "id", None)
        if not isinstance(datablock, bpy.types.Object):
            continue
        if datablock.type == "ARMATURE" or (
            datablock.type == "EMPTY"
            and datablock.name.startswith("__")
            and "Meta" in datablock.name
        ):
            _schedule_smart_material_import_scan()
            return


def _run_smart_material_import_scan():
    _state["smart_material_scan_pending"] = False
    context = bpy.context
    if context and context.scene:
        _smart_material_import_scan(context.scene)
    return None


def _schedule_smart_material_import_scan(delay = 0.15):
    if _state.get("smart_material_scan_pending", False):
        return
    _state["smart_material_scan_pending"] = True
    try:
        bpy.app.timers.register(
            _run_smart_material_import_scan,
            first_interval = delay,
        )
    except Exception:
        _state["smart_material_scan_pending"] = False


RBX_RELEASE_API_URL = "https://api.github.com/repos/Cautioned/Blender-Animations-Plugin/releases/latest"
RBX_ADDON_ID = "roblox_animations_importer_exporter"
UTILS_ADDON_ID = "staticaliza_blender_animation_tools"
UTILS_PACKAGE_URL = (
    "https://raw.githubusercontent.com/Staticaliza/"
    "Staticaliza-Blender-Animation-Tools/main/src/"
    "staticaliza_blender_animation_tools.zip"
)


def _roblox_addon_module_name(refresh = False):
    try:
        modules = addon_utils.modules(refresh = refresh)
    except Exception:
        return None

    for module in modules:
        module_name = getattr(module, "__name__", "")
        if module_name == RBX_ADDON_ID or module_name.endswith(f".{RBX_ADDON_ID}"):
            return module_name
    return None


def _roblox_addon_is_enabled():
    return hasattr(bpy.types, "OBJECT_PT_RbxAnimations")


def _refresh_roblox_armature_list(context = None, force = False):
    """Invalidate Cautioned's cached enum as soon as rig objects change."""
    signature = tuple(sorted(
        (_armature_session_uid(obj), obj.name)
        for obj in bpy.data.objects
        if obj.type == "ARMATURE"
    ))
    if (
        not force
        and signature == _state.get("roblox_armature_list_signature")
    ):
        return False
    _state["roblox_armature_list_signature"] = signature

    module_name = _roblox_addon_module_name()
    if module_name is None:
        return False
    try:
        core_utils = importlib.import_module(f"{module_name}.core.utils")
        core_utils.invalidate_armature_cache()
        names = tuple(core_utils.get_cached_armatures())
    except (AttributeError, ImportError, RuntimeError):
        return False

    context = context or bpy.context
    scene = getattr(context, "scene", None)
    settings = getattr(scene, "rbx_anim_settings", None) if scene else None
    if settings is not None:
        current = str(getattr(settings, "rbx_anim_armature", ""))
        if current not in names and names:
            active = _active_armature(context)
            replacement = (
                active.name
                if active is not None and active.name in names
                else names[0]
            )
            try:
                settings.rbx_anim_armature = replacement
            except (AttributeError, RuntimeError, TypeError, ValueError):
                pass
    _tag_redraw_all_view3d()
    return True


def _download_json(url):
    separator = "&" if "?" in url else "?"
    request = urllib.request.Request(
        f"{url}{separator}_staticaliza_cache_bust={time.time_ns()}",
        headers = {
            "Accept": "application/vnd.github+json",
            "Cache-Control": "no-cache, no-store, max-age=0",
            "Pragma": "no-cache",
            "User-Agent": "Staticaliza-Blender-Animation-Tools",
        },
    )
    with urllib.request.urlopen(request, timeout = 20) as response:
        return json.loads(response.read().decode("utf-8"))


def _get_roblox_release_asset():
    release = _download_json(RBX_RELEASE_API_URL)
    assets = [
        asset for asset in release.get("assets", [])
        if str(asset.get("name", "")).lower().endswith(".zip")
    ]
    if not assets:
        raise RuntimeError("The latest release has no ZIP package.")

    use_legacy = bpy.app.version < (4, 1, 0)
    preferred = [
        asset for asset in assets
        if ("legacy" in str(asset.get("name", "")).lower()) == use_legacy
    ]
    asset = preferred[0] if preferred else assets[0]
    asset_url = asset.get("browser_download_url")
    if not asset_url:
        raise RuntimeError("The release package has no download URL.")

    return release.get("tag_name", "latest"), asset.get("name", "package.zip"), asset_url


def _download_release_asset(asset_name, asset_url):
    safe_name = os.path.basename(asset_name) or "roblox_animations.zip"
    destination = os.path.join(tempfile.gettempdir(), f"staticaliza_{safe_name}")
    separator = "&" if "?" in asset_url else "?"
    request = urllib.request.Request(
        f"{asset_url}{separator}_staticaliza_cache_bust={time.time_ns()}",
        headers = {
            "Cache-Control": "no-cache, no-store, max-age=0",
            "Pragma": "no-cache",
            "User-Agent": "Staticaliza-Blender-Animation-Tools",
        },
    )

    try:
        with urllib.request.urlopen(request, timeout = 60) as response, open(destination, "wb") as output:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                output.write(chunk)

        return _prepare_roblox_addon_zip(destination)
    except Exception:
        if os.path.exists(destination):
            try:
                os.remove(destination)
            except OSError:
                pass
        raise


def _download_utils_package():
    handle, destination = tempfile.mkstemp(prefix = "staticaliza_utils_", suffix = ".zip")
    os.close(handle)
    separator = "&" if "?" in UTILS_PACKAGE_URL else "?"
    request = urllib.request.Request(
        f"{UTILS_PACKAGE_URL}{separator}_staticaliza_cache_bust={time.time_ns()}",
        headers = {
            "Cache-Control": "no-cache, no-store, max-age=0",
            "Pragma": "no-cache",
            "User-Agent": "Staticaliza-Blender-Animation-Tools",
        },
    )

    try:
        with urllib.request.urlopen(request, timeout = 60) as response, open(destination, "wb") as output:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                output.write(chunk)

        with zipfile.ZipFile(destination) as package:
            if package.testzip() is not None:
                raise RuntimeError("The downloaded Utils ZIP failed its integrity check.")
            manifest_names = [
                name for name in package.namelist()
                if name.replace("\\", "/").endswith("blender_manifest.toml")
            ]
            if not manifest_names:
                raise RuntimeError("The downloaded Utils ZIP has no Blender manifest.")
            manifest_name = min(manifest_names, key = lambda name: name.count("/"))
            manifest = tomllib.loads(package.read(manifest_name).decode("utf-8"))
            if manifest.get("id") != UTILS_ADDON_ID:
                raise RuntimeError("The downloaded ZIP is not Roblox Animator Utils.")
            version = str(manifest.get("version", "unknown"))
        return destination, version
    except Exception:
        try:
            os.remove(destination)
        except OSError:
            pass
        raise


def _extension_repository_is_locked():
    try:
        from bl_pkg import cookie_from_session
        from bl_pkg.bl_extension_utils import repo_lock_directory_query
    except ImportError:
        return False

    extensions = getattr(bpy.context.preferences, "extensions", None)
    repositories = getattr(extensions, "repos", ())
    repository = next(
        (repo for repo in repositories if repo.module == "user_default"),
        None,
    )
    if repository is None:
        return False

    return repo_lock_directory_query(
        repository.directory,
        cookie_from_session(),
    ) is not None


def _replace_manifest_display_name(data, display_name):
    text = data.decode("utf-8")
    lines = text.splitlines(keepends = True)

    for index, line in enumerate(lines):
        if not line.lstrip().startswith("name ="):
            continue
        indent = line[:len(line) - len(line.lstrip())]
        newline = "\r\n" if line.endswith("\r\n") else "\n" if line.endswith("\n") else ""
        lines[index] = f'{indent}name = "{display_name}"{newline}'
        return "".join(lines).encode("utf-8")

    raise RuntimeError("Downloaded Blender manifest has no name field.")


def _replace_bl_info_display_name(data, display_name):
    text = data.decode("utf-8")
    lines = text.splitlines(keepends = True)
    in_bl_info = False

    for index, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith("bl_info") and "{" in stripped:
            in_bl_info = True
            continue
        if not in_bl_info:
            continue
        if stripped == "}":
            break
        if not (stripped.startswith('"name"') or stripped.startswith("'name'")):
            continue

        indent = line[:len(line) - len(line.lstrip())]
        newline = "\r\n" if line.endswith("\r\n") else "\n" if line.endswith("\n") else ""
        lines[index] = f'{indent}"name": "{display_name}",{newline}'
        return "".join(lines).encode("utf-8")

    raise RuntimeError("Downloaded add-on metadata has no name field.")


def _replace_roblox_panel_display_name(data):
    text = data.decode("utf-8")
    text = text.replace(
        'bl_label = "Rbx Animations"',
        'bl_label = "Roblox Animator" + (f" (v{ADDON_VERSION_TEXT})" if ADDON_VERSION_TEXT.lower() != "unknown" else "")',
    )
    text = text.replace(
        "bl_label = 'Rbx Animations'",
        'bl_label = "Roblox Animator" + (f" (v{ADDON_VERSION_TEXT})" if ADDON_VERSION_TEXT.lower() != "unknown" else "")',
    )
    text = text.replace('"Rbx Animations"', '"Roblox Animator"')
    text = text.replace("'Rbx Animations'", "'Roblox Animator'")
    text = text.replace('text="Bake (Clipboard)"', 'text="Export"')
    text = text.replace("text='Bake (Clipboard)'", "text='Export'")
    version_block = (
        "        version_row = layout.row()\n"
        "        version_row.alignment = \"RIGHT\"\n"
        "        version_row.label(text=f\"v{ADDON_VERSION_TEXT}\")\n\n"
    )
    text = text.replace(version_block, "")
    text = text.replace(version_block.replace("\n", "\r\n"), "")
    return text.encode("utf-8")


def _replace_roblox_export_metadata(data):
    text = data.decode("utf-8")
    text = text.replace(
        'class OBJECT_OT_Bake(bpy.types.Operator):\n'
        '    bl_label = "Bake"\n'
        '    bl_idname = "object.rbxanims_bake"\n'
        '    bl_description = "Bake animation for export to clipboard"',
        'class OBJECT_OT_Bake(bpy.types.Operator):\n'
        '    bl_label = "Export"\n'
        '    bl_idname = "object.rbxanims_bake"\n'
        '    bl_description = "Export animation to clipboard"',
    )
    text = text.replace(
        'bl_description = "Bake animation for export to clipboard"',
        'bl_description = "Export animation to clipboard"',
    )
    return text.encode("utf-8")


def _prepare_roblox_addon_zip(filepath):
    repacked_path = f"{filepath}.install.zip"

    try:
        with zipfile.ZipFile(filepath) as package:
            infos = [info for info in package.infolist() if info.filename]
            normalized_names = []

            for info in infos:
                normalized = info.filename.replace("\\", "/").lstrip("/")
                parts = [part for part in normalized.split("/") if part]
                if not parts or ".." in parts:
                    raise RuntimeError("Downloaded ZIP contains an unsafe path.")
                normalized_names.append(normalized)

            if not any(name.endswith("__init__.py") for name in normalized_names):
                raise RuntimeError("Downloaded ZIP is not a Blender add-on package.")

            manifest_names = [
                name for name in normalized_names if name.endswith("blender_manifest.toml")
            ]
            if not manifest_names:
                raise RuntimeError("Downloaded ZIP has no Blender manifest.")
            manifest_name = min(manifest_names, key = lambda name: name.count("/"))
            manifest_parent = manifest_name.rsplit("/", 1)[0] if "/" in manifest_name else ""
            package_init_name = f"{manifest_parent}/__init__.py" if manifest_parent else "__init__.py"
            if package_init_name not in normalized_names:
                raise RuntimeError("Downloaded ZIP has no package __init__.py beside its manifest.")
            with zipfile.ZipFile(repacked_path, "w", compression = zipfile.ZIP_DEFLATED) as output:
                for info, normalized in zip(infos, normalized_names):
                    if info.is_dir():
                        output.writestr(f"{normalized.rstrip('/')}/", b"")
                        continue

                    data = package.read(info)
                    if normalized == manifest_name:
                        data = _replace_manifest_display_name(data, "Roblox Animator")
                    elif normalized == package_init_name:
                        data = _replace_bl_info_display_name(data, "Roblox Animator")
                    elif normalized.endswith("ui/panels.py"):
                        data = _replace_roblox_panel_display_name(data)
                    elif normalized.endswith("operators/animation_ops.py"):
                        data = _replace_roblox_export_metadata(data)
                    output.writestr(normalized, data)
    except Exception:
        if os.path.exists(repacked_path):
            try:
                os.remove(repacked_path)
            except OSError:
                pass
        raise

    os.remove(filepath)
    return repacked_path


def _install_roblox_addon(filepath):
    extension_ops = getattr(bpy.ops, "extensions", None)
    install = getattr(extension_ops, "package_install_files", None)
    if install is None:
        raise RuntimeError("This Blender build does not expose the extension installer API.")

    existing_module = _roblox_addon_module_name(refresh = True)
    was_enabled = bool(existing_module and addon_utils.check(existing_module)[1])
    if was_enabled:
        addon_utils.disable(existing_module, default_set = True)

    try:
        try:
            result = install(
                "EXEC_DEFAULT",
                filepath = filepath,
                repo = "user_default",
                enable_on_install = True,
            )
        except TypeError:
            result = install("EXEC_DEFAULT", filepath = filepath, repo = "user_default")
        if "FINISHED" not in result:
            raise RuntimeError("Blender did not finish installing Roblox Animator.")

        module_name = _roblox_addon_module_name(refresh = True)
        if module_name is None:
            raise RuntimeError("Blender installed Roblox Animator but could not locate its module.")
        if not addon_utils.check(module_name)[1]:
            try:
                addon_utils.enable(module_name, default_set = True, persistent = True)
            except TypeError:
                addon_utils.enable(module_name, default_set = True)
    except Exception:
        if (
            was_enabled
            and existing_module
            and not addon_utils.check(existing_module)[1]
        ):
            try:
                addon_utils.enable(existing_module, default_set = True, persistent = True)
            except TypeError:
                addon_utils.enable(existing_module, default_set = True)
        raise

    bpy.app.timers.register(_configure_roblox_sidebar_tabs, first_interval = 0.1)


def _utils_addon_module_name(refresh = False):
    for module in addon_utils.modules(refresh = refresh):
        module_name = getattr(module, "__name__", "")
        if module_name == UTILS_ADDON_ID or module_name.endswith(f".{UTILS_ADDON_ID}"):
            return module_name
    return None


def _install_utils_addon(filepath):
    extension_ops = getattr(bpy.ops, "extensions", None)
    install = getattr(extension_ops, "package_install_files", None)
    if install is None:
        raise RuntimeError("This Blender build does not expose the extension installer API.")

    original_module_name = _utils_addon_module_name(refresh = True)
    was_enabled = bool(original_module_name and addon_utils.check(original_module_name)[1])
    if was_enabled:
        addon_utils.disable(original_module_name, default_set = True)

    try:
        try:
            result = install(
                "EXEC_DEFAULT",
                filepath = filepath,
                repo = "user_default",
                enable_on_install = True,
            )
        except TypeError:
            result = install("EXEC_DEFAULT", filepath = filepath, repo = "user_default")
        if "FINISHED" not in result:
            raise RuntimeError("Blender did not finish installing Roblox Animator Utils.")

        installed_module_name = _utils_addon_module_name(refresh = True)
        if installed_module_name is None:
            raise RuntimeError("Blender installed Utils but could not locate its module.")
        if not addon_utils.check(installed_module_name)[1]:
            try:
                addon_utils.enable(installed_module_name, default_set = True, persistent = True)
            except TypeError:
                addon_utils.enable(installed_module_name, default_set = True)
    except Exception:
        if (
            was_enabled
            and original_module_name
            and not addon_utils.check(original_module_name)[1]
        ):
            try:
                addon_utils.enable(original_module_name, default_set = True, persistent = True)
            except TypeError:
                addon_utils.enable(original_module_name, default_set = True)
        raise


def _iter_roblox_rigs():
    seen = set()

    for collection in bpy.data.collections:
        if not collection.name.startswith("RIG: "):
            continue

        rig_name = _strip_blender_numeric_suffix(collection.name[5:].strip())
        if (
            not rig_name
            or _find_child_collection_by_base_name(collection, "Parts") is None
        ):
            continue

        armature_name = f"__{rig_name}_Armature"
        meta_name = f"__{rig_name}Meta"
        armature = None
        meta = None

        for obj in collection.all_objects:
            obj_name = _strip_blender_numeric_suffix(obj.name)
            if obj.type == "ARMATURE" and obj_name == armature_name:
                armature = obj
            elif obj.type == "EMPTY" and obj_name == meta_name:
                meta = obj

        if armature is not None and meta is not None and armature.as_pointer() not in seen:
            seen.add(armature.as_pointer())
            yield collection, armature, meta


def _iter_roblox_rig_armatures():
    for _collection, armature, _meta in _iter_roblox_rigs():
        yield armature


def _rig_display_name(armature_name):
    name = str(armature_name or "")
    if name.startswith("__"):
        name = name[2:]
    marker = "_Armature"
    marker_index = name.rfind(marker)
    if marker_index >= 0:
        suffix = name[marker_index + len(marker):]
        if not suffix or (
            suffix.startswith(".") and suffix[1:].isdigit()
        ):
            name = name[:marker_index] + suffix
    return name or str(armature_name or "Armature")


def _pose_panel_armatures(context):
    scene = getattr(context, "scene", None)
    if scene is None:
        return ()

    preferred = []
    seen = set()
    for armature in _iter_roblox_rig_armatures():
        try:
            if armature.name not in scene.objects:
                continue
            pointer = int(armature.as_pointer())
        except (AttributeError, ReferenceError):
            continue
        if pointer in seen:
            continue
        seen.add(pointer)
        preferred.append(armature)

    for armature in scene.objects:
        if armature.type != "ARMATURE":
            continue
        pointer = int(armature.as_pointer())
        if pointer in seen:
            continue
        seen.add(pointer)
        preferred.append(armature)

    return tuple(sorted(
        preferred,
        key = lambda armature: (
            _rig_display_name(armature.name).casefold(),
            armature.name.casefold(),
        ),
    ))


def _pose_armature_managed_hidden(armature):
    return _armature_session_uid(armature) in _state.get(
        "pose_hidden_armatures",
        {},
    )


def _restore_pose_session_armature_visibility():
    managed = dict(_state.get("pose_hidden_armatures", {}))
    _state["pose_hidden_armatures"] = {}
    changed = False
    for owner_uid, saved_hidden in managed.items():
        armature = _armature_from_session_uid(owner_uid)
        if armature is None:
            continue
        try:
            desired = bool(saved_hidden)
            if bool(armature.hide_get()) != desired:
                armature.hide_set(desired)
                changed = True
        except (AttributeError, ReferenceError, RuntimeError):
            continue
    if changed:
        _tag_redraw_all_view3d()
    return changed


def _sync_pose_session_armature_visibility(context):
    if context is None or getattr(context, "mode", "") != "POSE":
        return _restore_pose_session_armature_visibility()

    scope_uids = {
        _armature_session_uid(armature)
        for armature in _pose_scope_armatures(context)
    }
    managed = dict(_state.get("pose_hidden_armatures", {}))
    changed = False
    candidates = _pose_panel_armatures(context)
    candidate_uids = {_armature_session_uid(armature) for armature in candidates}

    for owner_uid in tuple(managed):
        if owner_uid in candidate_uids:
            continue
        armature = _armature_from_session_uid(owner_uid)
        if armature is not None:
            try:
                armature.hide_set(bool(managed[owner_uid]))
                changed = True
            except (AttributeError, ReferenceError, RuntimeError):
                pass
        managed.pop(owner_uid, None)

    for armature in candidates:
        owner_uid = _armature_session_uid(armature)
        if not owner_uid:
            continue
        if owner_uid in scope_uids:
            if owner_uid in managed:
                try:
                    if armature.hide_get():
                        armature.hide_set(False)
                        changed = True
                except (AttributeError, ReferenceError, RuntimeError):
                    pass
            continue

        if owner_uid not in managed:
            try:
                if armature.hide_viewport or armature.hide_get():
                    continue
                managed[owner_uid] = bool(armature.hide_get())
            except (AttributeError, ReferenceError, RuntimeError):
                continue
        try:
            if not armature.hide_get():
                armature.hide_set(True)
                changed = True
        except (AttributeError, ReferenceError, RuntimeError):
            continue

    _state["pose_hidden_armatures"] = managed
    if changed:
        _tag_redraw_all_view3d()
    return changed


@persistent
def _pose_visibility_save_pre(*_):
    _state["pose_visibility_resume_after_save"] = bool(
        getattr(bpy.context, "mode", "") == "POSE"
        and _state.get("pose_hidden_armatures", {})
    )
    _restore_pose_session_armature_visibility()


@persistent
def _pose_visibility_save_post(*_):
    resume = bool(_state.get("pose_visibility_resume_after_save", False))
    _state["pose_visibility_resume_after_save"] = False
    if resume:
        _sync_pose_session_armature_visibility(bpy.context)


def _rig_delete_bundle(armature):
    if armature is None or getattr(armature, "type", "") != "ARMATURE":
        return None
    candidates = []
    for collection in bpy.data.collections:
        if not collection.name.startswith("RIG: "):
            continue
        try:
            if collection.all_objects.get(armature.name) != armature:
                continue
        except (AttributeError, ReferenceError, RuntimeError):
            continue
        parts = tuple(
            child
            for child in collection.children
            if _strip_blender_numeric_suffix(child.name).casefold() == "parts"
        )
        metas = tuple(obj for obj in collection.all_objects if "RigMeta" in obj)
        if len(parts) == 1 and len(metas) == 1:
            candidates.append((collection, parts[0], metas[0]))
    if len(candidates) != 1:
        return None
    master, parts, meta = candidates[0]
    return {
        "armature": armature,
        "master": master,
        "parts": parts,
        "meta": meta,
    }


def _rig_delete_collection_parents(collection):
    return {
        parent
        for parent in bpy.data.collections
        if parent.children.get(collection.name) == collection
    }


def _rig_delete_collection_scene_links(collection):
    return {
        scene
        for scene in bpy.data.scenes
        if scene.collection.children.get(collection.name) == collection
    }


def _rig_delete_owned_collections(master):
    descendants = set()
    pending = [master]
    while pending:
        collection = pending.pop()
        if collection in descendants:
            continue
        descendants.add(collection)
        pending.extend(tuple(collection.children))

    owned = {master}
    changed = True
    while changed:
        changed = False
        for collection in descendants - owned:
            parents = _rig_delete_collection_parents(collection)
            if (
                parents
                and parents.issubset(owned)
                and not _rig_delete_collection_scene_links(collection)
            ):
                owned.add(collection)
                changed = True
    return owned


def _rig_delete_owned_objects(bundle, owned_collections):
    armature = bundle["armature"]
    meta = bundle["meta"]
    objects = set()
    for collection in owned_collections:
        for obj in collection.objects:
            try:
                external_links = {
                    linked
                    for linked in obj.users_collection
                    if linked not in owned_collections
                }
            except (AttributeError, ReferenceError, RuntimeError):
                external_links = {None}
            if not external_links or obj in {armature, meta}:
                objects.add(obj)
    objects.update((armature, meta))
    return objects


def _rig_delete_resource_inventory():
    return {
        "actions": set(),
        "armatures": set(),
        "cameras": set(),
        "curves": set(),
        "images": set(),
        "lights": set(),
        "materials": set(),
        "meshes": set(),
        "node_groups": set(),
        "textures": set(),
        # IDs found only through a global/name-based search are deliberately
        # more conservative than data reached from an owned rig object.
        "direct": set(),
        "heuristic": set(),
    }


def _rig_delete_inventory_add(
    inventory,
    resource_name,
    datablock,
    heuristic = False,
):
    if datablock is None:
        return
    inventory[resource_name].add(datablock)
    if heuristic:
        inventory["heuristic"].add(datablock)
    else:
        inventory["direct"].add(datablock)


def _rig_delete_collect_actions(id_block, inventory, heuristic = False):
    if id_block is None:
        return
    animation_data = getattr(id_block, "animation_data", None)
    if animation_data is None:
        return
    action = getattr(animation_data, "action", None)
    if action is not None:
        _rig_delete_inventory_add(
            inventory,
            "actions",
            action,
            heuristic,
        )
    for track in getattr(animation_data, "nla_tracks", ()):
        for strip in getattr(track, "strips", ()):
            action = getattr(strip, "action", None)
            if action is not None:
                _rig_delete_inventory_add(
                    inventory,
                    "actions",
                    action,
                    heuristic,
                )


def _rig_delete_collect_node_tree(
    node_tree,
    inventory,
    visited = None,
    heuristic = False,
):
    if node_tree is None:
        return
    visited = visited if visited is not None else set()
    try:
        pointer = int(node_tree.as_pointer())
    except (AttributeError, ReferenceError, TypeError, ValueError):
        pointer = id(node_tree)
    if pointer in visited:
        return
    visited.add(pointer)
    _rig_delete_collect_actions(node_tree, inventory, heuristic)
    for node in getattr(node_tree, "nodes", ()):
        image = getattr(node, "image", None)
        if image is not None:
            _rig_delete_inventory_add(
                inventory,
                "images",
                image,
                heuristic,
            )
        texture = getattr(node, "texture", None)
        if texture is not None:
            _rig_delete_inventory_add(
                inventory,
                "textures",
                texture,
                heuristic,
            )
            texture_image = getattr(texture, "image", None)
            if texture_image is not None:
                _rig_delete_inventory_add(
                    inventory,
                    "images",
                    texture_image,
                    heuristic,
                )
        child_tree = getattr(node, "node_tree", None)
        if child_tree is None or child_tree == node_tree:
            continue
        try:
            if bpy.data.node_groups.get(child_tree.name) == child_tree:
                _rig_delete_inventory_add(
                    inventory,
                    "node_groups",
                    child_tree,
                    heuristic,
                )
        except (AttributeError, ReferenceError, TypeError):
            pass
        _rig_delete_collect_node_tree(
            child_tree,
            inventory,
            visited,
            heuristic,
        )


def _rig_delete_collect_object_resources(
    obj,
    inventory,
    heuristic = False,
):
    if obj is None:
        return
    _rig_delete_collect_actions(obj, inventory, heuristic)
    data = getattr(obj, "data", None)
    if data is not None:
        _rig_delete_collect_actions(data, inventory, heuristic)
        if isinstance(data, bpy.types.Armature):
            resource_name = "armatures"
        elif isinstance(data, bpy.types.Camera):
            resource_name = "cameras"
        elif isinstance(data, bpy.types.Curve):
            resource_name = "curves"
        elif isinstance(data, bpy.types.Light):
            resource_name = "lights"
        elif isinstance(data, bpy.types.Mesh):
            resource_name = "meshes"
            shape_keys = getattr(data, "shape_keys", None)
            _rig_delete_collect_actions(shape_keys, inventory, heuristic)
        else:
            resource_name = ""
        if resource_name:
            _rig_delete_inventory_add(
                inventory,
                resource_name,
                data,
                heuristic,
            )

    materials = set()
    for slot in getattr(obj, "material_slots", ()):
        material = getattr(slot, "material", None)
        if material is not None:
            materials.add(material)
    for material in getattr(data, "materials", ()) if data is not None else ():
        if material is not None:
            materials.add(material)
    for material in materials:
        _rig_delete_inventory_add(
            inventory,
            "materials",
            material,
            heuristic,
        )
        _rig_delete_collect_actions(material, inventory, heuristic)
        _rig_delete_collect_node_tree(
            getattr(material, "node_tree", None),
            inventory,
            heuristic = heuristic,
        )


def _rig_delete_real_users(datablock):
    try:
        users = max(0, int(datablock.users))
        if bool(getattr(datablock, "use_fake_user", False)):
            users = max(0, users - 1)
        return users
    except (AttributeError, ReferenceError, TypeError, ValueError):
        return 1


def _rig_delete_collect_rebuild_orphans(armature, inventory):
    armature_data = getattr(armature, "data", None)
    if armature_data is None:
        return
    canonical_name = _strip_blender_numeric_suffix(armature_data.name)
    for datablock in bpy.data.armatures:
        if (
            _strip_blender_numeric_suffix(datablock.name) == canonical_name
            and _rig_delete_real_users(datablock) == 0
        ):
            _rig_delete_inventory_add(
                inventory,
                "armatures",
                datablock,
                heuristic = True,
            )


def _rig_delete_guide_linked_to_objects(guide, object_names):
    for property_name in (
        SURFACE_CONTACT_ARMATURE_PROPERTY,
        SURFACE_CONTACT_CONTROL_OBJECT_PROPERTY,
        SURFACE_CONTACT_OBJECT_PROPERTY,
        SURFACE_CONTACT_SURFACE_PROPERTY,
        SURFACE_CONTACT_SMART_OBJECT_PROPERTY,
        SURFACE_CONTACT_RELEASE_OBJECT_PROPERTY,
        SURFACE_CONTACT_FOLLOW_OBJECT_PROPERTY,
        SURFACE_CONTACT_CONSTRAINT_OBJECT_PROPERTY,
        SURFACE_CONTACT_SOLVER_OBJECT_PROPERTY,
    ):
        if str(guide.get(property_name, "")) in object_names:
            return True
    return False


def _attached_camera_owner_marker(camera):
    try:
        owner_name = str(camera.get(ATTACHED_CAMERA_OWNER_NAME_PROPERTY, ""))
        owner_uid = int(camera.get(ATTACHED_CAMERA_OWNER_UID_PROPERTY, 0) or 0)
    except (AttributeError, ReferenceError, TypeError, ValueError):
        return False, "", 0
    return bool(owner_name or owner_uid), owner_name, owner_uid


def _attached_camera_marker_matches(camera, armature):
    marked, owner_name, owner_uid = _attached_camera_owner_marker(camera)
    if not marked or armature is None:
        return False
    try:
        parent = getattr(camera, "parent", None)
        has_live_bone_parent = bool(
            parent is not None
            and getattr(parent, "type", "") == "ARMATURE"
            and getattr(camera, "parent_type", "") == "BONE"
            and bool(getattr(camera, "parent_bone", ""))
            and bpy.data.objects.get(parent.name) == parent
        )
    except (AttributeError, ReferenceError, TypeError):
        parent = None
        has_live_bone_parent = False
    if has_live_bone_parent:
        return parent == armature
    return bool(
        (owner_uid and owner_uid == _armature_session_uid(armature))
        or (owner_name and owner_name == armature.name)
    )


def _rig_delete_external_helpers(armature, owned_objects):
    helpers = set()
    heuristic_helpers = set()
    for obj in tuple(bpy.data.objects):
        if obj in owned_objects:
            continue
        if (
            bool(obj.get(SPACE_HELPER_PROPERTY, False))
            and getattr(obj, "parent", None) == armature
        ):
            helpers.add(obj)
            continue
        if obj.type != "CAMERA":
            continue
        marked, _owner_name, _owner_uid = _attached_camera_owner_marker(obj)
        if marked:
            if _attached_camera_marker_matches(obj, armature):
                helpers.add(obj)
            continue
        if (
            obj.name.startswith("Camera - ")
            and getattr(obj, "parent", None) == armature
            and getattr(obj, "parent_type", "") == "BONE"
        ):
            helpers.add(obj)
            heuristic_helpers.add(obj)
    return helpers, heuristic_helpers


def _rig_delete_weld_helpers(armature):
    helpers = set()
    pose = getattr(armature, "pose", None)
    for pose_bone in getattr(pose, "bones", ()):
        helper = getattr(pose_bone, "custom_shape", None)
        if (
            helper is not None
            and helper.name.startswith("__WeldBoneShape")
            and helper.type == "CURVE"
            and not tuple(helper.users_collection)
        ):
            helpers.add(helper)
    return helpers


def _rig_delete_weld_helper_still_used(helper):
    for obj in bpy.data.objects:
        if obj.type != "ARMATURE" or getattr(obj, "pose", None) is None:
            continue
        for pose_bone in obj.pose.bones:
            if getattr(pose_bone, "custom_shape", None) == helper:
                return True
    return False


def _rig_delete_clear_runtime(
    armature,
    bundle = None,
    delete_object_names = (),
):
    owner_uid = _armature_session_uid(armature)
    armature_name = str(getattr(armature, "name", ""))
    armature_pointer = 0
    armature_data_pointer = 0
    try:
        armature_pointer = int(armature.as_pointer())
        armature_data_pointer = int(armature.data.as_pointer())
    except (AttributeError, ReferenceError, TypeError, ValueError):
        pass
    for state_name in ("yellow_fixed", "yellow_modes"):
        _state[state_name] = {
            key: value
            for key, value in _state.get(state_name, {}).items()
            if int(key[0]) != owner_uid
        }
    for state_name in ("yellow_hidden", "onion_enabled_owners"):
        owners = set(_state.get(state_name, set()))
        owners.discard(owner_uid)
        _state[state_name] = owners
    for state_name in ("mesh_batches", "raycast_fixed"):
        values = dict(_state.get(state_name, {}))
        values.pop(owner_uid, None)
        _state[state_name] = values

    managed_hidden = dict(_state.get("pose_hidden_armatures", {}))
    managed_hidden.pop(owner_uid, None)
    _state["pose_hidden_armatures"] = managed_hidden

    overlay_saved = dict(_state.get("armature_overlay_saved", {}))
    overlay_saved.pop(armature_data_pointer, None)
    _state["armature_overlay_saved"] = overlay_saved
    for state_name in (
        "roblox_constraints_normalized",
        "roblox_constraints_new_rigs",
    ):
        values = set(_state.get(state_name, set()))
        values.discard(armature_pointer)
        _state[state_name] = values
    if bundle is not None:
        try:
            master_pointer = int(bundle["master"].as_pointer())
        except (AttributeError, KeyError, ReferenceError, TypeError, ValueError):
            master_pointer = 0
        processed = set(_state.get("smart_material_processed_rigs", set()))
        processed.discard(master_pointer)
        _state["smart_material_processed_rigs"] = processed

    pending_rigs = set(_state.get("pose_mode_pending_rigs", set()))
    pending_rigs.discard(armature_name)
    _state["pose_mode_pending_rigs"] = pending_rigs
    _state["unparent_rel_cache"] = {
        key: value
        for key, value in _state.get("unparent_rel_cache", {}).items()
        if not str(key).startswith(f"{armature_name}::")
    }
    if _state.get("unparent_export_armature") == armature:
        _state["unparent_export_armature"] = None
    _state["bone_label_selection_signature"] = None

    delete_object_names = {str(name) for name in delete_object_names}
    if (
        int(_state.get("part_pivot_armature", 0) or 0) == armature_pointer
        or str(_state.get("part_pivot_object", "")) in delete_object_names
    ):
        try:
            _disable_part_pivot(bpy.context)
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            _state["part_pivot_armature"] = 0
            _state["part_pivot_bone"] = ""
            _state["part_pivot_object"] = ""
            _state["part_pivot_object_local"] = None
            _state["part_pivot_saved"] = None
            _state["part_pivot_last_signature"] = None

    for state_name in (
        "pin_snap_latches",
        "pin_snap_departing",
        "pin_snap_detached",
        "pin_snap_transform_seen",
    ):
        _state[state_name] = set(_state.get(state_name, set()))
    contact_keys = {
        _surface_contact_snap_key(guide)
        for guide in _surface_contact_guides()
        if str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, "")) == armature_name
    }
    target_prefixes = (
        f"YELLOW:{owner_uid}:",
        f"CONTACT:{owner_uid}:",
    )

    def is_target_key(key):
        key = str(key)
        return key in contact_keys or key.startswith(target_prefixes)

    for state_name in (
        "pin_snap_latches",
        "pin_snap_departing",
        "pin_snap_detached",
        "pin_snap_transform_seen",
    ):
        _state[state_name] = {
            key
            for key in _state.get(state_name, set())
            if not is_target_key(key)
        }

    selected_key = _pin_selected_target_key()
    if selected_key and is_target_key(selected_key):
        _pin_deselect_target()
    else:
        _state["pin_gizmo_axes_visible"] = {
            key: value
            for key, value in _state.get(
                "pin_gizmo_axes_visible",
                {},
            ).items()
            if not is_target_key(key)
        }

    signature = _state.get("pin_gizmo_selection_keys", ())
    if isinstance(signature, (tuple, list)) and len(signature) >= 3:
        scope = tuple(
            uid for uid in signature[0] if int(uid) != owner_uid
        )
        selected = tuple(
            key for key in signature[1] if int(key[0]) != owner_uid
        )
        active = signature[2]
        if active and int(active[0]) == owner_uid:
            active = (0, "")
        _state["pin_gizmo_selection_keys"] = (scope, selected, active)

    pending_click = _state.get("pin_gizmo_pending_click")
    if pending_click and is_target_key(pending_click[0]):
        _state["pin_gizmo_pending_click"] = None
    _state["pin_gizmo_deferred_finishes"] = [
        item
        for item in _state.get("pin_gizmo_deferred_finishes", ())
        if (
            int(item.get("armature_uid", 0) or 0) != owner_uid
            and str(item.get("armature_name", "")) != armature_name
            and not is_target_key(item.get("target_key", ""))
        )
    ]
    _state["pin_yellow_history_fallbacks"] = {
        key: value
        for key, value in _state.get(
            "pin_yellow_history_fallbacks",
            {},
        ).items()
        if int(key[0]) != owner_uid
    }

    snapshot = _state.get("pin_history_contact_snapshot")
    if isinstance(snapshot, dict):
        filtered_snapshot = dict(snapshot)
        for field in ("targets", "engaged", "selected"):
            values = snapshot.get(field, {})
            if isinstance(values, dict):
                filtered_snapshot[field] = {
                    key: value
                    for key, value in values.items()
                    if int(key[0]) != owner_uid
                }
            else:
                filtered_snapshot[field] = {
                    key for key in values if int(key[0]) != owner_uid
                }
        _state["pin_history_contact_snapshot"] = filtered_snapshot

    clipboard = _state.get("pin_clipboard")
    if isinstance(clipboard, dict):
        owners = tuple(clipboard.get("owners", ()))
        if owners:
            remaining_owners = [
                entry
                for entry in owners
                if (
                    int(entry.get("session_uid", 0) or 0) != owner_uid
                    and str(entry.get("armature_name", "")) != armature_name
                )
            ]
            if remaining_owners:
                clipboard = dict(clipboard)
                clipboard["owners"] = remaining_owners
                _state["pin_clipboard"] = clipboard
            else:
                _state["pin_clipboard"] = None
    _set_onion_property(
        getattr(bpy.context, "window_manager", None),
        bool(_state.get("onion_enabled_owners", set())),
    )


def _rig_delete_purge_datablock_runtime(resource_name, datablock):
    try:
        pointer = int(datablock.as_pointer())
    except (AttributeError, ReferenceError, TypeError, ValueError):
        return
    if resource_name == "armatures":
        saved = dict(_state.get("armature_overlay_saved", {}))
        saved.pop(pointer, None)
        _state["armature_overlay_saved"] = saved
    elif resource_name == "materials":
        baseline = _state.get("material_import_baseline")
        if baseline is not None:
            baseline = set(baseline)
            baseline.discard(pointer)
            _state["material_import_baseline"] = baseline
    elif resource_name == "actions":
        pointers = {pointer}
        for slot in getattr(datablock, "slots", ()):
            try:
                pointers.add(int(slot.as_pointer()))
            except (AttributeError, ReferenceError, TypeError, ValueError):
                pass
        for groups in _action_group_owners(datablock):
            for group in groups:
                try:
                    pointers.add(int(group.as_pointer()))
                except (AttributeError, ReferenceError, TypeError, ValueError):
                    pass
        _state["expanded_animation_channels"] = {
            key
            for key in _state.get("expanded_animation_channels", set())
            if int(key[1]) not in pointers
        }
        _state["animation_channel_content"] = {
            key: value
            for key, value in _state.get(
                "animation_channel_content",
                {},
            ).items()
            if int(key[1]) not in pointers
        }


def _rig_delete_remove_orphans(inventory):
    removed = 0
    direct = set(inventory.get("direct", set()))
    heuristic = set(inventory.get("heuristic", set()))
    collections = (
        ("armatures", bpy.data.armatures),
        ("cameras", bpy.data.cameras),
        ("curves", bpy.data.curves),
        ("lights", bpy.data.lights),
        ("meshes", bpy.data.meshes),
        ("materials", bpy.data.materials),
        ("node_groups", bpy.data.node_groups),
        ("textures", bpy.data.textures),
        ("images", bpy.data.images),
        ("actions", bpy.data.actions),
    )
    for resource_name, data_collection in collections:
        for datablock in tuple(inventory.get(resource_name, ())):
            try:
                if data_collection.get(datablock.name) != datablock:
                    continue
                if getattr(datablock, "library", None) is not None:
                    continue
                if _rig_delete_real_users(datablock) != 0:
                    continue
                fake_user = bool(getattr(datablock, "use_fake_user", False))
                if (
                    fake_user
                    and datablock in heuristic
                    and datablock not in direct
                ):
                    continue
                if fake_user:
                    datablock.use_fake_user = False
                if _rig_delete_real_users(datablock) != 0:
                    continue
                _rig_delete_purge_datablock_runtime(
                    resource_name,
                    datablock,
                )
                data_collection.remove(datablock)
                removed += 1
            except (AttributeError, ReferenceError, RuntimeError, TypeError):
                continue
    return removed


def _rig_delete_reenter_pose(context, survivor_names, active_name):
    survivors = tuple(
        obj
        for name in survivor_names
        if (
            (obj := bpy.data.objects.get(name)) is not None
            and obj.type == "ARMATURE"
        )
    )
    if not survivors:
        return False
    for obj in context.view_layer.objects:
        try:
            obj.select_set(False)
        except (AttributeError, ReferenceError, RuntimeError):
            pass
    selected = []
    for armature in survivors:
        try:
            armature.hide_set(False)
            armature.select_set(True)
            if armature.select_get():
                selected.append(armature)
        except (AttributeError, ReferenceError, RuntimeError):
            continue
    if not selected:
        return False
    active = bpy.data.objects.get(active_name) if active_name else None
    if active not in selected:
        active = selected[0]
    context.view_layer.objects.active = active
    try:
        bpy.ops.object.mode_set(mode = "POSE")
    except (AttributeError, RuntimeError):
        return False
    _sync_pose_session_armature_visibility(context)
    return True


def _hide_roblox_rig_meta(meta):
    if meta is None:
        return
    meta.hide_viewport = True
    meta.hide_render = True
    meta.hide_select = True
    try:
        meta.hide_set(True)
    except (AttributeError, RuntimeError):
        pass


def _is_roblox_auxiliary_bone_collection(collection):
    base_name = _strip_blender_numeric_suffix(collection.name).casefold()
    compact_name = "".join(character for character in base_name if character.isalnum())
    return any(
        token in compact_name
        for token in ("weldbones", "facebones", "helperbones")
    )


def _set_roblox_auxiliary_bone_collections_visibility(armature, visible):
    changed = 0
    for bone_collection in getattr(armature.data, "collections", ()):
        if not _is_roblox_auxiliary_bone_collection(bone_collection):
            continue
        if bool(bone_collection.is_visible) != bool(visible):
            bone_collection.is_visible = bool(visible)
            changed += 1
    return changed


def _set_roblox_bone_visibility(armature, collection_name, predicate, hidden):
    bones = [bone for bone in armature.data.bones if predicate(bone)]
    if not bones:
        return 0

    # A bone can belong to multiple collections, so collection visibility alone
    # does not guarantee that Blender hides it in the viewport.
    for bone in bones:
        bone.hide = hidden

    try:
        bone_collections = armature.data.collections
        use_collections = True
    except Exception:
        bone_collections = None
        use_collections = False

    if use_collections:
        bone_collection = bone_collections.get(collection_name)
        if bone_collection is None:
            bone_collection = bone_collections.new(collection_name)
        for bone in bones:
            try:
                bone_collection.assign(bone)
            except RuntimeError:
                pass
        bone_collection.is_visible = not hidden
    return len(bones)


def _is_numbered_helper_bone(armature, bone):
    base_name = _strip_blender_numeric_suffix(bone.name)
    return (
        base_name != bone.name
        and armature.data.bones.get(base_name) is not None
    )


def _is_roblox_weld_bone(armature, bone):
    joint_type = str(bone.get("rbx_joint_type", "")).casefold()
    if joint_type in {"weld", "weldconstraint"}:
        return True

    pose_bone = armature.pose.bones.get(bone.name)
    custom_shape = getattr(pose_bone, "custom_shape", None) if pose_bone else None
    return bool(
        custom_shape
        and _strip_blender_numeric_suffix(custom_shape.name) == "__WeldBoneShape"
    )


def _find_generated_roblox_armature(context, meta, previous_armatures):
    active = context.view_layer.objects.active
    if (
        active is not None
        and active.type == "ARMATURE"
        and active.as_pointer() not in previous_armatures
    ):
        return active

    settings = getattr(context.scene, "rbx_anim_settings", None)
    configured_name = getattr(settings, "rbx_anim_armature", "") if settings else ""
    configured = context.scene.objects.get(configured_name) if configured_name else None
    if (
        configured is not None
        and configured.type == "ARMATURE"
        and configured.as_pointer() not in previous_armatures
    ):
        return configured

    try:
        source_collections = tuple(meta.users_collection) if meta is not None else ()
    except ReferenceError:
        source_collections = ()

    for collection in source_collections:
        for obj in collection.all_objects:
            if obj.type == "ARMATURE" and obj.as_pointer() not in previous_armatures:
                return obj

    for obj in context.scene.objects:
        if obj.type == "ARMATURE" and obj.as_pointer() not in previous_armatures:
            return obj

    return None


def _enter_pending_roblox_rigs_pose_mode():
    pending = _state.setdefault("pose_mode_pending_rigs", set())
    if not pending:
        _state["pose_mode_pending_attempts"] = 0
        return None

    context = bpy.context
    scene = getattr(context, "scene", None)
    view_layer = getattr(context, "view_layer", None)
    if scene is None or view_layer is None:
        _state["pose_mode_pending_attempts"] += 1
        if _state["pose_mode_pending_attempts"] < 20:
            return 0.05
        pending.clear()
        _state["pose_mode_pending_attempts"] = 0
        return None

    armatures = []
    for armature_name in tuple(pending):
        armature = scene.objects.get(armature_name)
        if armature is None or armature.type != "ARMATURE":
            pending.discard(armature_name)
            continue
        try:
            if armature.name not in view_layer.objects:
                continue
        except (AttributeError, ReferenceError):
            continue
        armatures.append(armature)

    if not armatures:
        _state["pose_mode_pending_attempts"] += 1
        if pending and _state["pose_mode_pending_attempts"] < 20:
            return 0.05
        pending.clear()
        _state["pose_mode_pending_attempts"] = 0
        return None

    try:
        if getattr(context, "mode", "OBJECT") != "OBJECT":
            bpy.ops.object.mode_set(mode = "OBJECT")
        for obj in view_layer.objects:
            try:
                obj.select_set(False)
            except (AttributeError, RuntimeError):
                pass
        selectable = []
        for armature in armatures:
            try:
                if (
                    armature.hide_get()
                    or armature.hide_viewport
                    or armature.hide_select
                ):
                    continue
                armature.select_set(True)
                if not armature.select_get():
                    continue
                selectable.append(armature)
            except (AttributeError, ReferenceError, RuntimeError):
                continue
        if not selectable:
            raise RuntimeError("Generated rig is not selectable in this view layer")
        view_layer.objects.active = selectable[0]
        bpy.ops.object.mode_set(mode = "POSE")
    except (AttributeError, ReferenceError, RuntimeError):
        _state["pose_mode_pending_attempts"] += 1
        if _state["pose_mode_pending_attempts"] < 20:
            return 0.05
        pending.clear()
        _state["pose_mode_pending_attempts"] = 0
        return None

    for armature in selectable:
        pending.discard(armature.name)
    _state["pose_mode_pending_attempts"] = 0
    return 0.05 if pending else None


def _schedule_roblox_rigs_pose_mode(armatures, delay = 0.15):
    pending = _state.setdefault("pose_mode_pending_rigs", set())
    for armature in armatures:
        try:
            if armature is not None and armature.type == "ARMATURE":
                pending.add(armature.name)
        except (AttributeError, ReferenceError):
            continue
    if not pending:
        return
    _state["pose_mode_pending_attempts"] = 0
    if not bpy.app.timers.is_registered(_enter_pending_roblox_rigs_pose_mode):
        bpy.app.timers.register(
            _enter_pending_roblox_rigs_pose_mode,
            first_interval = max(0.01, float(delay)),
        )


def _find_roblox_parts_collection(armature):
    visited = set()
    pending = list(armature.users_collection)

    while pending:
        collection = pending.pop(0)
        pointer = collection.as_pointer()
        if pointer in visited:
            continue
        visited.add(pointer)
        collection_name = _strip_blender_numeric_suffix(collection.name)
        if collection_name == "Parts" or collection_name.endswith("_Parts"):
            return collection
        pending.extend(collection.children)

    return None


def _normalize_roblox_part_constraints(armature, preserve_world = True):
    parts_collection = _find_roblox_parts_collection(armature)
    if parts_collection is None:
        return 0

    normalized = 0
    preserved_world = []
    channel_names = (
        "use_location_x",
        "use_location_y",
        "use_location_z",
        "use_rotation_x",
        "use_rotation_y",
        "use_rotation_z",
        "use_scale_x",
        "use_scale_y",
        "use_scale_z",
    )

    for obj in parts_collection.all_objects:
        if obj.type != "MESH":
            continue

        if preserve_world:
            try:
                preserved_world.append((obj, obj.matrix_world.copy()))
            except (AttributeError, ReferenceError, RuntimeError):
                pass

        constraints = [
            constraint for constraint in obj.constraints
            if constraint.type == "CHILD_OF" and constraint.target == armature
        ]
        if not constraints:
            continue

        valid_constraints = [
            constraint for constraint in constraints
            if constraint.subtarget and armature.data.bones.get(constraint.subtarget) is not None
        ]
        keep = valid_constraints[0] if valid_constraints else constraints[0]
        for constraint in constraints:
            if constraint is not keep:
                obj.constraints.remove(constraint)

        keep.influence = 1.0
        for channel_name in channel_names:
            if hasattr(keep, channel_name):
                setattr(keep, channel_name, True)

        bone = armature.data.bones.get(keep.subtarget)
        if bone is not None and not preserve_world:
            # Newly generated rigs are still at their bind transform, so this
            # repairs native constraints that were created without an inverse.
            # Existing constraints already store the armature/bone transform
            # from binding time. Rebuilding that inverse from the armature's
            # *current* world matrix would cancel any later rig relocation and
            # snap the mesh back to its original world-space coordinates.
            bone_matrix = getattr(bone, "matrix_local", None)
            if bone_matrix is None:
                bone_matrix = bone.matrix
            if hasattr(bone_matrix, "to_4x4"):
                bone_matrix = bone_matrix.to_4x4()
            keep.inverse_matrix = (armature.matrix_world @ bone_matrix).inverted()
        normalized += 1

    if preserve_world and preserved_world:
        try:
            bpy.context.view_layer.update()
        except (AttributeError, RuntimeError):
            pass
        restored = False
        for obj, world_matrix in preserved_world:
            try:
                if any(
                    abs(
                        float(obj.matrix_world[row][column])
                        - float(world_matrix[row][column])
                    )
                    > 1.0e-8
                    for row in range(4)
                    for column in range(4)
                ):
                    obj.matrix_world = world_matrix
                    restored = True
            except (AttributeError, ReferenceError, RuntimeError, TypeError):
                pass
        if restored:
            try:
                bpy.context.view_layer.update()
            except (AttributeError, RuntimeError):
                pass

    return normalized


def _sync_armature_debug_overlays(advanced_mode, show_bone_names = None):
    runtime_saved = _state.setdefault("armature_overlay_saved", {})

    for armature_data in bpy.data.armatures:
        pointer = int(armature_data.as_pointer())
        persisted = armature_data.get(ARMATURE_OVERLAY_STATE_KEY)

        if not advanced_mode:
            if persisted is None and pointer not in runtime_saved:
                original = (
                    bool(armature_data.show_axes),
                    bool(armature_data.show_names),
                )
                runtime_saved[pointer] = (armature_data, original)
                try:
                    armature_data[ARMATURE_OVERLAY_STATE_KEY] = list(original)
                except (AttributeError, RuntimeError, TypeError):
                    pass
            try:
                armature_data.show_axes = False
                if show_bone_names is not None:
                    armature_data.show_names = show_bone_names
            except (AttributeError, RuntimeError, TypeError):
                pass
            continue

        original = None
        if persisted is not None and len(persisted) >= 2:
            original = (bool(persisted[0]), bool(persisted[1]))
        elif pointer in runtime_saved:
            original = runtime_saved[pointer][1]

        if original is not None:
            try:
                armature_data.show_axes = original[0]
                if show_bone_names is None:
                    armature_data.show_names = original[1]
            except (AttributeError, RuntimeError, TypeError):
                pass
        if show_bone_names is not None:
            try:
                armature_data.show_names = show_bone_names
            except (AttributeError, RuntimeError, TypeError):
                pass
        try:
            if ARMATURE_OVERLAY_STATE_KEY in armature_data:
                del armature_data[ARMATURE_OVERLAY_STATE_KEY]
        except (AttributeError, RuntimeError, TypeError):
            pass
        runtime_saved.pop(pointer, None)


def _apply_roblox_compatibility(scene):
    wm = getattr(bpy.context, "window_manager", None)
    if wm is None:
        return

    advanced_mode = getattr(wm, "roblox_compat_advanced_mode", False)
    _sync_armature_debug_overlays(advanced_mode, False)

    rigs = tuple(_iter_roblox_rigs())
    for _collection, armature, meta in rigs:
        _hide_roblox_rig_meta(meta)
        _set_roblox_auxiliary_bone_collections_visibility(
            armature,
            advanced_mode,
        )

    if not _roblox_addon_is_enabled():
        return

    hide_welds = not advanced_mode
    hide_face_bones = not advanced_mode
    hide_helper_bones = not advanced_mode

    for _collection, armature, _meta in rigs:
        pointer = armature.as_pointer()
        if pointer not in _state["roblox_constraints_normalized"]:
            new_rigs = _state.setdefault("roblox_constraints_new_rigs", set())
            is_new_rig = pointer in new_rigs
            _normalize_roblox_part_constraints(
                armature,
                preserve_world = not is_new_rig,
            )
            new_rigs.discard(pointer)
            _state["roblox_constraints_normalized"].add(pointer)
        _set_roblox_bone_visibility(
            armature,
            "_StaticalizaWeldBones",
            lambda bone: _is_roblox_weld_bone(armature, bone),
            hide_welds,
        )
        _set_roblox_bone_visibility(
            armature,
            "_StaticalizaFaceBones",
            lambda bone: bool(bone.get("rbx_face_deform_bone")),
            hide_face_bones,
        )
        _set_roblox_bone_visibility(
            armature,
            "_StaticalizaHelperBones",
            lambda bone: _is_numbered_helper_bone(armature, bone),
            hide_helper_bones,
        )


def _on_roblox_compatibility_setting_change(self, context):
    _apply_roblox_compatibility(context.scene)
    _tag_redraw_all_view3d()


def _on_hide_advanced_panels_change(self, context):
    window_manager = getattr(context, "window_manager", None)
    if window_manager is None:
        return
    for window in window_manager.windows:
        screen = window.screen
        if screen is None:
            continue
        for area in screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


def _sync_view3d_relationship_lines(context):
    window_manager = getattr(context, "window_manager", None)
    if window_manager is None:
        return

    show_lines = bool(
        getattr(window_manager, "roblox_compat_advanced_mode", False)
    )
    for window in window_manager.windows:
        screen = getattr(window, "screen", None)
        if screen is None:
            continue
        for area in screen.areas:
            if area.type != "VIEW_3D":
                continue
            for space in area.spaces:
                if space.type == "VIEW_3D":
                    space.overlay.show_relationship_lines = show_lines
            area.tag_redraw()


def _on_advanced_mode_change(self, context):
    _apply_roblox_compatibility(context.scene)
    _sync_view3d_relationship_lines(context)
    _on_hide_advanced_panels_change(self, context)


@persistent
def _roblox_compatibility_depsgraph_update(scene, depsgraph):
    _refresh_roblox_armature_list(bpy.context)
    normalized = _state.get("roblox_constraints_normalized", set())
    for update in depsgraph.updates:
        datablock = getattr(update, "id", None)
        if isinstance(datablock, bpy.types.Armature):
            advanced_mode = bool(getattr(
                getattr(bpy.context, "window_manager", None),
                "roblox_compat_advanced_mode",
                False,
            ))
            auxiliary_visibility_changed = any(
                _is_roblox_auxiliary_bone_collection(collection)
                and bool(collection.is_visible) != advanced_mode
                for collection in getattr(datablock, "collections", ())
            )
            if auxiliary_visibility_changed:
                _schedule_roblox_compatibility_scan()
                return
            continue
        if not isinstance(datablock, bpy.types.Object):
            continue
        if datablock.type == "ARMATURE" and datablock.as_pointer() not in normalized:
            _schedule_roblox_compatibility_scan()
            return


def _run_roblox_compatibility_scan():
    _state["roblox_compatibility_scan_pending"] = False
    context = bpy.context
    if context and context.scene:
        _apply_roblox_compatibility(context.scene)
    return None


def _schedule_roblox_compatibility_scan(delay = 0.15):
    if _state.get("roblox_compatibility_scan_pending", False):
        return
    _state["roblox_compatibility_scan_pending"] = True
    try:
        bpy.app.timers.register(
            _run_roblox_compatibility_scan,
            first_interval = delay,
        )
    except Exception:
        _state["roblox_compatibility_scan_pending"] = False


def _show_extension_update_result(message, icon):
    window_manager = getattr(bpy.context, "window_manager", None)
    if window_manager is None:
        print(f"[Roblox Animator Utils] {message}")
        return

    def draw(self, context):
        self.layout.label(text = message)

    window_manager.popup_menu(draw, title = "Extension Update", icon = icon)


def _perform_combined_extension_update():
    roblox_filepath = None
    utils_filepath = None

    if _extension_repository_is_locked():
        _state["extension_update_lock_waits"] += 1
        if _state["extension_update_lock_waits"] <= 20:
            _state["extension_update_status"] = "Waiting for Blender's extension repository..."
            _tag_redraw_all_view3d()
            return 0.5

        _show_extension_update_result(
            "Update paused because the User Default repository is still locked. "
            "Wait for the current install to finish or use Force Unlock Repository.",
            "ERROR",
        )
        _state["extension_update_running"] = False
        _state["extension_update_status"] = ""
        _state["extension_update_lock_waits"] = 0
        _tag_redraw_all_view3d()
        return None

    _state["extension_update_lock_waits"] = 0

    try:
        _state["extension_update_status"] = "Downloading Roblox Animator and Utils..."
        _tag_redraw_all_view3d()
        tag, asset_name, asset_url = _get_roblox_release_asset()
        roblox_filepath = _download_release_asset(asset_name, asset_url)
        utils_filepath, utils_version = _download_utils_package()

        # Keep Roblox Animator above Utils in the N-panel category order.
        _state["extension_update_status"] = "Installing the downloaded extensions..."
        _tag_redraw_all_view3d()
        _install_roblox_addon(roblox_filepath)
        _install_utils_addon(utils_filepath)
        _show_extension_update_result(
            f"Installed Roblox Animator {tag} and Roblox Animator Utils v{utils_version}.",
            "CHECKMARK",
        )
    except Exception as exc:
        _show_extension_update_result(f"Update failed: {exc}", "ERROR")
    finally:
        for filepath in (roblox_filepath, utils_filepath):
            if filepath and os.path.exists(filepath):
                try:
                    os.remove(filepath)
                except OSError:
                    pass
        _state["extension_update_running"] = False
        _state["extension_update_status"] = ""
        _state["extension_update_lock_waits"] = 0
        _tag_redraw_all_view3d()

    return None


class STATICALIZA_OT_install_roblox_animations(bpy.types.Operator):
    bl_idname = "staticaliza.install_roblox_animations"
    bl_label = "Install Latest Extension"
    bl_description = "Install or update Roblox Animator first, then Roblox Animator Utils"
    bl_options = {"REGISTER"}

    def execute(self, context):
        if not getattr(bpy.app, "online_access", True):
            self.report({"ERROR"}, "Blender online access is disabled in Preferences.")
            return {"CANCELLED"}

        if _state["extension_update_running"]:
            self.report({"WARNING"}, "An extension update is already running.")
            return {"CANCELLED"}

        _state["extension_update_running"] = True
        _state["extension_update_status"] = "Preparing the extension update..."
        _state["extension_update_lock_waits"] = 0
        _tag_redraw_all_view3d()
        try:
            bpy.app.timers.register(_perform_combined_extension_update, first_interval = 0.35)
        except Exception as exc:
            _state["extension_update_running"] = False
            _state["extension_update_status"] = ""
            _tag_redraw_all_view3d()
            self.report({"ERROR"}, f"Could not start extension update: {exc}")
            return {"CANCELLED"}

        self.report({"INFO"}, "Downloading the latest Roblox Animator and Utils releases.")
        return {"FINISHED"}


class STATICALIZA_OT_open_roblox_plugins(bpy.types.Operator):
    bl_idname = "staticaliza.open_roblox_plugins"
    bl_label = "Install Roblox Plugins"
    bl_description = "Open both recommended Roblox animation plugins in the Creator Store"

    def execute(self, context):
        for url in (
            "https://create.roblox.com/store/asset/118148792788940",
            "https://create.roblox.com/store/asset/16708835782",
        ):
            bpy.ops.wm.url_open(url = url)
        return {"FINISHED"}


def _part_pivot_selected_bone(context):
    selected = _selected_pose_bones_only(context)
    active_bone = context.active_pose_bone
    if active_bone not in selected:
        active_bone = selected[0] if selected else None
    if active_bone is None and context.mode == "POSE":
        # Blender retains an active pose bone after its selection flag is
        # cleared.  Object pivot mode can still resolve that bone without
        # changing the user's visible selection.
        retained_active = getattr(context, "active_pose_bone", None)
        if _pose_bone_owner(context, retained_active) is not None:
            active_bone = retained_active
    if active_bone is None:
        # A virtual pin owns an active bone even though its normal-click
        # selection intentionally leaves every Pose selection flag clear.
        # Keep Object-pivot matching alive for that pin-only state.
        try:
            _pin_key, pin_target = _pin_selected_target_data(context)
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            pin_target = None
        if pin_target is not None:
            active_bone = pin_target[2]
    if active_bone is None:
        last_armature = _armature_from_session_uid(
            _state.get("part_pivot_last_armature", 0)
        )
        if last_armature is not None and getattr(last_armature, "pose", None):
            active_bone = last_armature.pose.bones.get(
                str(_state.get("part_pivot_last_bone", ""))
            )
    return active_bone


def _part_pivot_connected_object(context, armature, eval_armature, objects, pose_bone):
    canonical_name = _strip_blender_numeric_suffix(pose_bone.name)
    candidates = {}

    family_levels = list(
        _pose_bone_numeric_family_levels(eval_armature, pose_bone)
    )
    numbered_names = set().union(*family_levels)
    family_names = _surface_contact_bone_family_names(
        eval_armature,
        pose_bone,
    )
    weld_names = family_names - numbered_names
    if weld_names:
        family_levels.append(weld_names)

    target_objects = set(objects or ())
    target_objects.update(_surface_contact_rig_objects(armature))
    parts_collection = _find_roblox_parts_collection(armature)
    if parts_collection is not None:
        target_objects.update(parts_collection.all_objects)
    connected_objects = set(
        _surface_contact_connected_objects(
            context,
            armature,
            family_names,
        )
    )
    target_objects.update(connected_objects)
    search_objects = tuple(
        obj
        for obj in context.view_layer.objects
        if obj in target_objects and obj != armature
    )

    for level_index, level_names in enumerate(family_levels):
        for obj in search_objects:
            if obj.type != "MESH" or not _is_object_visible(obj, context):
                continue

            exact_name = obj.name == canonical_name
            matching_name = _strip_blender_numeric_suffix(obj.name) == canonical_name
            object_bone_names = _surface_contact_object_bone_names(
                obj,
                armature,
            )
            directly_connected = bool(object_bone_names & level_names)
            family_connected = bool(object_bone_names & family_names)
            belongs_to_family = (
                directly_connected
                or family_connected
                or obj in connected_objects
            )
            if not (exact_name or matching_name or directly_connected):
                continue
            if not belongs_to_family and obj not in target_objects:
                continue

            score = (
                0
                if directly_connected
                else 1
                if family_connected or obj in connected_objects
                else 2,
                0 if exact_name else 1 if matching_name else 2,
                level_index,
                1 if _object_has_linked_base_color(obj) else 0,
                obj.name.casefold(),
            )
            previous = candidates.get(obj.name)
            if previous is None or score < previous[0]:
                candidates[obj.name] = (score, obj)

    if not candidates:
        return None
    return min(candidates.values(), key = lambda item: item[0])[1]


def _part_pivot_target(context):
    if context.mode != "POSE":
        return None

    active_bone = _part_pivot_selected_bone(context)
    depsgraph = context.evaluated_depsgraph_get()
    candidates = []
    if active_bone is not None:
        candidates.append((_pose_bone_owner(context, active_bone), active_bone))
    armatures = list(_pose_scope_armatures(context))
    active_armature = _active_armature(context)
    if active_armature is not None and active_armature not in armatures:
        armatures.insert(0, active_armature)
    for armature in armatures:
        for pose_bone in getattr(getattr(armature, "pose", None), "bones", ()):
            candidates.append((armature, pose_bone))

    seen = set()
    match = None
    for armature, pose_bone in candidates:
        if armature is None or pose_bone is None:
            continue
        owner_key = _owner_bone_key(armature, pose_bone.name)
        if owner_key in seen:
            continue
        seen.add(owner_key)
        eval_armature = armature.evaluated_get(depsgraph)
        eval_pose_bone = eval_armature.pose.bones.get(pose_bone.name)
        if eval_pose_bone is None:
            continue
        objects, _target_armature = _targets(context, armature)
        part = _part_pivot_connected_object(
            context,
            armature,
            eval_armature,
            objects,
            eval_pose_bone,
        )
        if part is not None:
            match = (armature, pose_bone, part)
            break
    if match is None:
        return None
    armature, active_bone, part = match

    eval_part = part.evaluated_get(depsgraph)
    local_bounds = None
    for corner in eval_part.bound_box:
        point = Vector(corner)
        if local_bounds is None:
            local_bounds = _bounds_init(point)
        else:
            _bounds_add(local_bounds, point)
    if local_bounds is None:
        return None

    local_center = Vector((
        (float(local_bounds[0]) + float(local_bounds[3])) * 0.5,
        (float(local_bounds[1]) + float(local_bounds[4])) * 0.5,
        (float(local_bounds[2]) + float(local_bounds[5])) * 0.5,
        1.0,
    ))
    return int(armature.as_pointer()), active_bone.name, part.name, local_center


def _view3d_spaces(context):
    window_manager = getattr(context, "window_manager", None)
    for window in getattr(window_manager, "windows", ()) if window_manager else ():
        screen = getattr(window, "screen", None)
        for area in getattr(screen, "areas", ()) if screen else ():
            if area.type != "VIEW_3D":
                continue
            for space in area.spaces:
                if space.type == "VIEW_3D":
                    yield space


def _hide_part_pivot_cursor(context):
    visibility = _state.setdefault("part_pivot_cursor_visibility", {})
    for space in _view3d_spaces(context):
        pointer = int(space.as_pointer())
        if pointer not in visibility:
            visibility[pointer] = bool(space.overlay.show_cursor)
        if space.overlay.show_cursor:
            space.overlay.show_cursor = False


def _restore_part_pivot_cursor(context):
    visibility = _state.get("part_pivot_cursor_visibility", {})
    for space in _view3d_spaces(context):
        pointer = int(space.as_pointer())
        if pointer in visibility:
            space.overlay.show_cursor = bool(visibility[pointer])
    _state["part_pivot_cursor_visibility"] = {}


def _sync_part_pivot(context, rematch = False):
    window_manager = getattr(context, "window_manager", None)
    if window_manager is None:
        return False
    if getattr(window_manager, "staticaliza_pivot_mode", "BONE") != "PART":
        return False
    if _state.get("part_pivot_syncing", False):
        return True

    _state["part_pivot_syncing"] = True
    try:
        active_bone = _part_pivot_selected_bone(context) if context.mode == "POSE" else None
        armature = (
            _pose_bone_owner(context, active_bone) or _active_armature(context)
            if active_bone is not None
            else _active_armature(context)
        )
        armature_pointer = int(armature.as_pointer()) if armature else 0
        bone_name = active_bone.name if active_bone else ""
        if (
            rematch
            or armature_pointer != _state.get("part_pivot_armature", 0)
            or bone_name != _state.get("part_pivot_bone", "")
            or not _state.get("part_pivot_object", "")
        ):
            _state["part_pivot_armature"] = armature_pointer
            _state["part_pivot_bone"] = bone_name
            _state["part_pivot_object"] = ""
            _state["part_pivot_object_local"] = None
            _state["part_pivot_last_signature"] = None
            target = _part_pivot_target(context)
            if target is None:
                return False
            armature_pointer, bone_name, object_name, local_center = target
            _state["part_pivot_armature"] = armature_pointer
            _state["part_pivot_bone"] = bone_name
            _state["part_pivot_object"] = object_name
            _state["part_pivot_object_local"] = local_center.copy()
            _state["part_pivot_last_signature"] = None
            _state["part_pivot_last_armature"] = armature_pointer
            _state["part_pivot_last_bone"] = bone_name

        part = bpy.data.objects.get(_state.get("part_pivot_object", ""))
        local_center = _state.get("part_pivot_object_local")
        if part is None or local_center is None:
            return False

        depsgraph = context.evaluated_depsgraph_get()
        eval_part = part.evaluated_get(depsgraph)
        matrix_signature = tuple(float(value) for row in eval_part.matrix_world for value in row)
        signature = (armature_pointer, bone_name, part.name, matrix_signature)
        _hide_part_pivot_cursor(context)
        world_center = eval_part.matrix_world @ _as_p4(local_center)
        world_location = Vector(world_center[:3])
        world_rotation = eval_part.matrix_world.to_quaternion().normalized()
        cursor = context.scene.cursor
        same_location = (cursor.location - world_location).length_squared <= 1.0e-16
        same_rotation = (
            cursor.rotation_mode == "QUATERNION"
            and abs(float(cursor.rotation_quaternion.dot(world_rotation)))
            >= 1.0 - 1.0e-10
        )
        if context.scene.tool_settings.transform_pivot_point != "CURSOR":
            context.scene.tool_settings.transform_pivot_point = "CURSOR"
        slot = context.scene.transform_orientation_slots[0]
        if slot.type == "LOCAL":
            slot.type = "CURSOR"
        if (
            signature == _state.get("part_pivot_last_signature")
            and same_location
            and same_rotation
        ):
            return True

        cursor.location = world_location
        context.scene.cursor.rotation_mode = "QUATERNION"
        cursor.rotation_quaternion = world_rotation
        _state["part_pivot_last_signature"] = signature
        return True
    finally:
        _state["part_pivot_syncing"] = False


def _disable_part_pivot(context):
    _restore_part_pivot_cursor(context)
    saved = _state.get("part_pivot_saved")
    if saved is not None:
        cursor = context.scene.cursor
        context.scene.tool_settings.transform_pivot_point = saved["pivot_point"]
        cursor.location = saved["cursor_location"]
        cursor.rotation_mode = "QUATERNION"
        cursor.rotation_quaternion = saved["cursor_rotation"]
        cursor.rotation_mode = saved["cursor_rotation_mode"]

    slot = context.scene.transform_orientation_slots[0]
    if slot.type == "CURSOR":
        slot.type = "LOCAL"

    window_manager = getattr(context, "window_manager", None)
    if window_manager is not None:
        window_manager.staticaliza_pivot_mode = "BONE"
    _state["part_pivot_bone"] = ""
    _state["part_pivot_armature"] = 0
    _state["part_pivot_object"] = ""
    _state["part_pivot_object_local"] = None
    _state["part_pivot_saved"] = None
    _state["part_pivot_last_signature"] = None
    _tag_redraw_all_view3d()


@persistent
def _part_pivot_depsgraph_update(_scene, _depsgraph):
    context = bpy.context
    window_manager = getattr(context, "window_manager", None)
    if (
        window_manager is not None
        and getattr(window_manager, "staticaliza_pivot_mode", "BONE") == "PART"
    ):
        _sync_part_pivot(context)


@persistent
def _part_pivot_frame_change_post(_scene, _depsgraph):
    _part_pivot_depsgraph_update(_scene, _depsgraph)


def _part_pivot_selection_timer():
    context = bpy.context
    window_manager = getattr(context, "window_manager", None)
    if (
        window_manager is None
        or getattr(window_manager, "staticaliza_pivot_mode", "BONE") != "PART"
    ):
        return 0.2

    active_bone = _part_pivot_selected_bone(context) if context.mode == "POSE" else None
    armature = (
        _pose_bone_owner(context, active_bone) or _active_armature(context)
        if active_bone is not None
        else _active_armature(context)
    )
    armature_pointer = int(armature.as_pointer()) if armature else 0
    bone_name = active_bone.name if active_bone else ""
    changed = (
        armature_pointer != _state.get("part_pivot_armature", 0)
        or bone_name != _state.get("part_pivot_bone", "")
    )
    if changed:
        if active_bone is None:
            _state["part_pivot_armature"] = armature_pointer
            _state["part_pivot_bone"] = ""
            _state["part_pivot_object"] = ""
            _state["part_pivot_object_local"] = None
            _state["part_pivot_last_signature"] = None
        else:
            _sync_part_pivot(context, rematch = True)
        _tag_redraw_all_view3d()
    return 0.03


def _bone_label_selection_timer():
    context = bpy.context
    window_manager = getattr(context, "window_manager", None)
    if window_manager is None:
        return 0.1

    visibility_changed = _sync_pose_session_armature_visibility(context)

    if _pin_gizmo_track_selection(context):
        _tag_redraw_all_view3d()

    armature, pose_bone = _selected_bone_label_target(context)
    active_object = getattr(context, "active_object", None)
    selected_keys = tuple(sorted(_selected_owner_bone_keys(context)))
    signature = (
        bool(getattr(window_manager, "show_bone_names_enabled", True)),
        str(getattr(context, "mode", "")),
        _armature_session_uid(armature),
        pose_bone.name if pose_bone is not None else "",
        int(active_object.as_pointer()) if active_object is not None else 0,
        selected_keys,
    )
    if signature == _state.get("bone_label_selection_signature"):
        if (
            (
                _custom_bone_label_targets(context)[1]
                or _dynamic_parent_visible_relationships(context)
            )
            and not _state.get("enabled")
        ):
            _yellow_refresh_runtime(context)
        if visibility_changed:
            _yellow_refresh_runtime(context)
        return 0.03

    _state["bone_label_selection_signature"] = signature
    advanced_mode = bool(
        getattr(window_manager, "roblox_compat_advanced_mode", False)
    )
    _sync_armature_debug_overlays(advanced_mode, False)
    _yellow_refresh_runtime(context)
    return 0.03


class STATICALIZA_OT_set_transform_orientation(bpy.types.Operator):
    bl_idname = "staticaliza.set_transform_orientation"
    bl_label = "Set Transform Orientation"
    bl_description = "Set or toggle the 3D View transform orientation between Global and Local"
    bl_options = {"REGISTER"}

    orientation: bpy.props.EnumProperty(
        items = (
            ("TOGGLE", "Toggle", "Toggle between Global and Local"),
            ("GLOBAL", "Global", "Use Global transform orientation"),
            ("LOCAL", "Local", "Use Local transform orientation"),
        ),
        default = "TOGGLE",
        options = {"SKIP_SAVE"},
    )

    def execute(self, context):
        slot = context.scene.transform_orientation_slots[0]
        target = self.orientation
        part_mode = (
            getattr(context.window_manager, "staticaliza_pivot_mode", "BONE")
            == "PART"
        )
        if target == "TOGGLE":
            local_types = {"CURSOR"} if part_mode else {"LOCAL"}
            target = "GLOBAL" if slot.type in local_types else "LOCAL"

        if target == "LOCAL" and part_mode:
            slot.type = "CURSOR" if _sync_part_pivot(context) else "LOCAL"
        else:
            slot.type = target
        self.report({"INFO"}, f"Transform orientation: {target.title()}")
        return {"FINISHED"}


class STATICALIZA_OT_set_pivot_mode(bpy.types.Operator):
    bl_idname = "staticaliza.set_pivot_mode"
    bl_label = "Set Pivot Mode"
    bl_description = "Toggle between the normal bone pivot and the connected object pivot"
    bl_options = {"REGISTER"}

    pivot_mode: bpy.props.EnumProperty(
        items = (
            ("TOGGLE", "Toggle", "Toggle between Bone and Object pivot modes"),
            ("BONE", "Bone", "Use Blender's normal bone pivot"),
            ("PART", "Object", "Use the center and axes of the first connected rig object"),
        ),
        default = "TOGGLE",
        options = {"SKIP_SAVE"},
    )

    def execute(self, context):
        window_manager = context.window_manager
        current = getattr(window_manager, "staticaliza_pivot_mode", "BONE")
        target = self.pivot_mode
        if target == "TOGGLE":
            target = "PART" if current == "BONE" else "BONE"

        if target == "BONE":
            _disable_part_pivot(context)
            self.report({"INFO"}, "Pivot mode: Bone")
            return {"FINISHED"}

        if current != "PART":
            cursor = context.scene.cursor
            original_rotation_mode = cursor.rotation_mode
            cursor.rotation_mode = "QUATERNION"
            original_rotation = cursor.rotation_quaternion.copy()
            cursor.rotation_mode = original_rotation_mode
            _state["part_pivot_saved"] = {
                "pivot_point": context.scene.tool_settings.transform_pivot_point,
                "cursor_location": cursor.location.copy(),
                "cursor_rotation": original_rotation,
                "cursor_rotation_mode": original_rotation_mode,
            }
        window_manager.staticaliza_pivot_mode = "PART"
        matched = _sync_part_pivot(context, rematch = True)

        slot = context.scene.transform_orientation_slots[0]
        if matched and slot.type == "LOCAL":
            slot.type = "CURSOR"
        self.report({"INFO"}, "Pivot mode: Object")
        _tag_redraw_all_view3d()
        return {"FINISHED"}


CAMERA_ORIENTATION_ITEMS = (
    ("X_POS", "+X", "Point the camera along the bone's positive X axis"),
    ("X_NEG", "-X", "Point the camera along the bone's negative X axis"),
    ("Y_POS", "+Y", "Point the camera along the bone's positive Y axis"),
    ("Y_NEG", "-Y", "Point the camera along the bone's negative Y axis"),
    ("Z_POS", "+Z", "Point the camera along the bone's positive Z axis"),
    ("Z_NEG", "-Z", "Point the camera along the bone's negative Z axis"),
)


CAMERA_FOV_PRESET_ITEMS = (
    ("CINEMATIC", "Cinematic (35°)", "Use a 35-degree horizontal field of view"),
    ("CLASSIC", "Classic (70°)", "Use a 70-degree horizontal field of view"),
    ("CUSTOM", "Custom", "Use the manually selected field of view"),
)


def _camera_bone_binding(camera):
    if camera is None or camera.type != "CAMERA":
        return None, ""
    if (
        camera.parent is not None
        and camera.parent.type == "ARMATURE"
        and camera.parent_type == "BONE"
        and camera.parent_bone
    ):
        return camera.parent, camera.parent_bone
    for constraint in camera.constraints:
        target = getattr(constraint, "target", None)
        subtarget = getattr(constraint, "subtarget", "")
        if constraint.type == "CHILD_OF" and target and target.type == "ARMATURE" and subtarget:
            return target, subtarget
    return None, ""


def _on_camera_fov_preset(window_manager, _context):
    if _state.get("camera_fov_syncing", False):
        return
    preset_angles = {
        "CINEMATIC": math.radians(35.0),
        "CLASSIC": math.radians(70.0),
    }
    angle = preset_angles.get(window_manager.staticaliza_camera_fov_preset)
    if angle is None:
        return
    _state["camera_fov_syncing"] = True
    try:
        window_manager.staticaliza_camera_fov = angle
    finally:
        _state["camera_fov_syncing"] = False


def _on_camera_fov_change(window_manager, _context):
    if _state.get("camera_fov_syncing", False):
        return
    angle = float(window_manager.staticaliza_camera_fov)
    if abs(angle - math.radians(35.0)) <= math.radians(0.01):
        preset = "CINEMATIC"
    elif abs(angle - math.radians(70.0)) <= math.radians(0.01):
        preset = "CLASSIC"
    else:
        preset = "CUSTOM"
    if window_manager.staticaliza_camera_fov_preset == preset:
        return
    _state["camera_fov_syncing"] = True
    try:
        window_manager.staticaliza_camera_fov_preset = preset
    finally:
        _state["camera_fov_syncing"] = False


def _camera_preset_from_angle(angle):
    if abs(float(angle) - math.radians(35.0)) <= math.radians(0.01):
        return "CINEMATIC"
    if abs(float(angle) - math.radians(70.0)) <= math.radians(0.01):
        return "CLASSIC"
    return "CUSTOM"


def _camera_angle_for_preset(preset, custom_angle):
    return {
        "CINEMATIC": math.radians(35.0),
        "CLASSIC": math.radians(70.0),
    }.get(str(preset), float(custom_angle))


def _on_create_camera_preset(operator, _context):
    if operator.preset == "CUSTOM":
        return
    operator.fov = _camera_angle_for_preset(operator.preset, operator.fov)


def _on_attached_camera_preset(camera, _context):
    if _state.get("camera_fov_syncing", False) or camera.type != "CAMERA":
        return
    angle = {
        "CINEMATIC": math.radians(35.0),
        "CLASSIC": math.radians(70.0),
    }.get(camera.staticaliza_camera_fov_preset)
    if angle is not None:
        camera.data.angle = angle


def _sync_attached_camera_preset(camera):
    if camera is None or camera.type != "CAMERA":
        return
    preset = _camera_preset_from_angle(camera.data.angle)
    if camera.staticaliza_camera_fov_preset == preset:
        return
    _state["camera_fov_syncing"] = True
    try:
        camera.staticaliza_camera_fov_preset = preset
    finally:
        _state["camera_fov_syncing"] = False


def _camera_for_bone(scene, armature, bone_name):
    matches = []
    for camera in scene.objects:
        if camera.type != "CAMERA":
            continue
        target, subtarget = _camera_bone_binding(camera)
        if target == armature and subtarget == bone_name:
            matches.append(camera)
    if scene.camera in matches:
        return scene.camera
    return matches[0] if matches else None


def _selected_camera_bone(context):
    if context.mode != "POSE":
        return None, None, None
    selected_by_owner = _selected_pose_bones_by_owner(context)
    active = getattr(context, "active_pose_bone", None)
    active_armature = _pose_bone_owner(context, active)
    ordered = []
    if active in selected_by_owner.get(active_armature, ()):
        ordered.append((active_armature, active))
    ordered.extend(
        (armature, pose_bone)
        for armature, pose_bones in selected_by_owner.items()
        for pose_bone in pose_bones
        if (armature, pose_bone) not in ordered
    )
    for armature, pose_bone in ordered:
        camera = _camera_for_bone(context.scene, armature, pose_bone.name)
        if camera is not None:
            return armature, pose_bone, camera
    return None, None, None


def _standalone_camera(context):
    candidates = []
    active = context.active_object
    if active is not None and active.type == "CAMERA":
        candidates.append(active)
    if context.scene.camera is not None:
        candidates.append(context.scene.camera)
    candidates.extend(obj for obj in context.scene.objects if obj.type == "CAMERA")
    seen = set()
    for camera in candidates:
        pointer = int(camera.as_pointer())
        if pointer in seen:
            continue
        seen.add(pointer)
        target, bone_name = _camera_bone_binding(camera)
        if target is None or not bone_name:
            return camera
    return None


def _view_camera_matrix(context):
    region_data = getattr(context, "region_data", None)
    if region_data is None:
        return None
    try:
        matrix = region_data.view_matrix.inverted()
        location, rotation, _scale = matrix.decompose()
        result = rotation.to_matrix().to_4x4()
        result.translation = location
        return result
    except Exception:
        return None


def _camera_world_at_bone_tip(armature, pose_bone, orientation = "Z_NEG"):
    bone_world = armature.matrix_world @ pose_bone.matrix
    axes = bone_world.to_3x3().normalized()
    local_direction = {
        "X_POS": Vector((1.0, 0.0, 0.0)),
        "X_NEG": Vector((-1.0, 0.0, 0.0)),
        "Y_POS": Vector((0.0, 1.0, 0.0)),
        "Y_NEG": Vector((0.0, -1.0, 0.0)),
        "Z_POS": Vector((0.0, 0.0, 1.0)),
        "Z_NEG": Vector((0.0, 0.0, -1.0)),
    }.get(orientation, Vector((0.0, 0.0, -1.0)))
    forward = (axes @ local_direction).normalized()
    up_reference = axes.col[2].normalized()
    if abs(float(forward.dot(up_reference))) >= 0.999:
        up_reference = axes.col[1].normalized()
    x_axis = forward.cross(up_reference).normalized()
    up_axis = (-forward).cross(x_axis).normalized()
    matrix = Matrix((
        (x_axis.x, up_axis.x, -forward.x, 0.0),
        (x_axis.y, up_axis.y, -forward.y, 0.0),
        (x_axis.z, up_axis.z, -forward.z, 0.0),
        (0.0, 0.0, 0.0, 1.0),
    ))
    matrix.translation = bone_world @ Vector((0.0, pose_bone.length, 0.0))
    return matrix


def _on_attached_camera_orientation(camera, context):
    if camera.type != "CAMERA":
        return
    armature, bone_name = _camera_bone_binding(camera)
    if armature is None or not bone_name:
        return
    pose_bone = armature.pose.bones.get(bone_name)
    if pose_bone is None:
        return
    camera.matrix_world = _camera_world_at_bone_tip(
        armature,
        pose_bone,
        camera.staticaliza_camera_orientation,
    )
    try:
        context.view_layer.update()
    except Exception:
        pass


def _insert_camera_bone_keys(armature, pose_bone, frame):
    frame = int(frame)
    group = pose_bone.name
    options = {"INSERTKEY_VISUAL"}
    base = f'pose.bones["{pose_bone.name}"]'
    armature.keyframe_insert(
        data_path = f"{base}.location",
        frame = frame,
        group = group,
        options = options,
    )
    if pose_bone.rotation_mode == "QUATERNION":
        rotation_path = "rotation_quaternion"
    elif pose_bone.rotation_mode == "AXIS_ANGLE":
        rotation_path = "rotation_axis_angle"
    else:
        rotation_path = "rotation_euler"
    armature.keyframe_insert(
        data_path = f"{base}.{rotation_path}",
        frame = frame,
        group = group,
        options = options,
    )
    armature.keyframe_insert(
        data_path = f"{base}.scale",
        frame = frame,
        group = group,
        options = options,
    )
    _set_keyframe_handles_auto(pose_bone, frame)


def _keyframe_camera_bone(context, armature, pose_bone, camera, camera_world):
    action = armature.animation_data.action if armature.animation_data else None
    object_keys_before = _snapshot_object_keys_all(action)
    previous_autokey = _autokey_push(context)
    try:
        depsgraph = context.evaluated_depsgraph_get()
        evaluated_armature = armature.evaluated_get(depsgraph)
        evaluated_bone = evaluated_armature.pose.bones.get(pose_bone.name)
        if evaluated_bone is None:
            return False
        evaluated_camera = camera.evaluated_get(depsgraph)
        bone_world = evaluated_armature.matrix_world @ evaluated_bone.matrix
        relative_camera = bone_world.inverted() @ evaluated_camera.matrix_world
        desired_bone_world = camera_world @ relative_camera.inverted()
        pose_bone.matrix = armature.matrix_world.inverted() @ desired_bone_world
        context.view_layer.update()
        _insert_camera_bone_keys(
            armature,
            pose_bone,
            int(context.scene.frame_current),
        )
        context.view_layer.update()
        return True
    except Exception:
        return False
    finally:
        current_action = armature.animation_data.action if armature.animation_data else None
        _cleanup_new_object_keys_all(current_action, object_keys_before)
        _autokey_pop(context, previous_autokey)


def _keyframe_standalone_camera(camera, frame, camera_world):
    camera.matrix_world = camera_world
    camera.keyframe_insert(data_path = "location", frame = int(frame))
    if camera.rotation_mode == "QUATERNION":
        camera.keyframe_insert(data_path = "rotation_quaternion", frame = int(frame))
    elif camera.rotation_mode == "AXIS_ANGLE":
        camera.keyframe_insert(data_path = "rotation_axis_angle", frame = int(frame))
    else:
        camera.keyframe_insert(data_path = "rotation_euler", frame = int(frame))
    _set_keyframe_handles_auto(camera, frame)


def _objects_affiliated_with_camera_bone(scene, camera):
    armature, bone_name = _camera_bone_binding(camera)
    if armature is None or not bone_name:
        return []

    pose_bone = armature.pose.bones.get(bone_name)
    if pose_bone is None:
        return []
    family_names = _surface_contact_bone_family_names(armature, pose_bone)
    canonical_name = _strip_blender_numeric_suffix(bone_name)
    parts_collection = _find_roblox_parts_collection(armature)
    parts_objects = (
        set(parts_collection.all_objects)
        if parts_collection is not None
        else set()
    )
    connected = set()
    for obj in scene.objects:
        if obj == camera or obj.type != "MESH":
            continue
        matches = bool(
            _surface_contact_object_bone_names(obj, armature) & family_names
        )
        if (
            not matches
            and obj in parts_objects
            and _strip_blender_numeric_suffix(obj.name) == canonical_name
        ):
            matches = True
        if matches:
            connected.add(obj)

    for _depth in range(16):
        additions = {
            obj
            for obj in scene.objects
            if (
                obj.type == "MESH"
                and obj != camera
                and obj not in connected
                and (
                    obj.parent in connected
                    or any(
                        getattr(constraint, "target", None) in connected
                        for constraint in obj.constraints
                    )
                )
            )
        }
        if not additions:
            break
        connected.update(additions)
    return list(connected)


def _set_attached_camera_object_visibility(scene, camera, hidden):
    for obj in _objects_affiliated_with_camera_bone(scene, camera):
        obj.hide_viewport = bool(hidden)
        obj.hide_render = bool(hidden)


def _sync_all_attached_camera_object_visibility():
    for scene in bpy.data.scenes:
        for camera in (obj for obj in scene.objects if obj.type == "CAMERA"):
            armature, bone_name = _camera_bone_binding(camera)
            if armature is None or not bone_name:
                continue
            hidden = getattr(
                camera,
                "staticaliza_camera_hide_attached_object",
                True,
            )
            _set_attached_camera_object_visibility(scene, camera, hidden)
    return None


def _on_camera_attached_object_hide_change(camera, context):
    scenes = list(camera.users_scene)
    if context and context.scene and context.scene not in scenes:
        scenes.append(context.scene)
    for scene in scenes:
        _set_attached_camera_object_visibility(
            scene,
            camera,
            camera.staticaliza_camera_hide_attached_object,
        )


def _level_free_view_rotation(region_data):
    rotation = region_data.view_rotation.copy()
    direction = (rotation @ Vector((0.0, 0.0, -1.0))).normalized()
    world_up = Vector((0.0, 0.0, 1.0))
    if abs(direction.dot(world_up)) >= 1.0 - 1.0e-10:
        return False
    region_data.view_rotation = direction.to_track_quat("-Z", "Y")
    return True


def _set_default_keyframe_handle_type():
    preferences = getattr(bpy.context, "preferences", None)
    edit_preferences = getattr(preferences, "edit", None)
    if edit_preferences is None or not hasattr(
        edit_preferences,
        "keyframe_new_handle_type",
    ):
        return False
    try:
        edit_preferences.keyframe_new_handle_type = "AUTO"
    except (AttributeError, TypeError, ValueError):
        return False
    return edit_preferences.keyframe_new_handle_type == "AUTO"


def _camera_view_state(previous = None):
    if isinstance(previous, dict):
        return previous
    return {
        "attached": bool(previous),
        "pending_level": False,
        "last_rotation": None,
        "stable_ticks": 0,
    }


_VIEW3D_SPACE_SYNC_PROPERTIES = (
    "lens",
    "clip_start",
    "clip_end",
    "show_gizmo",
    "show_gizmo_navigate",
    "show_gizmo_context",
    "show_gizmo_modifier",
    "show_gizmo_tool",
    "show_gizmo_object_translate",
    "show_gizmo_object_rotate",
    "show_gizmo_object_scale",
)

_VIEW3D_SHADING_SYNC_PROPERTIES = (
    "type",
    "light",
    "studio_light",
    "use_world_space_lighting",
    "show_object_outline",
    "show_backface_culling",
    "show_cavity",
    "cavity_type",
    "curvature_ridge_factor",
    "curvature_valley_factor",
    "cavity_ridge_factor",
    "cavity_valley_factor",
    "studiolight_rotate_z",
    "studiolight_intensity",
    "studiolight_background_alpha",
    "studiolight_background_blur",
    "use_studiolight_view_rotation",
    "color_type",
    "single_color",
    "background_type",
    "background_color",
    "show_shadows",
    "show_xray",
    "show_xray_wireframe",
    "xray_alpha",
    "xray_alpha_wireframe",
    "use_dof",
    "use_scene_lights",
    "use_scene_world",
    "use_scene_lights_render",
    "use_scene_world_render",
    "show_specular_highlight",
    "object_outline_color",
    "shadow_intensity",
    "render_pass",
    "aov_name",
    "use_compositor",
)

_VIEW3D_OVERLAY_SYNC_PROPERTIES = (
    "show_overlays",
    "show_ortho_grid",
    "show_floor",
    "show_axis_x",
    "show_axis_y",
    "show_axis_z",
    "grid_scale",
    "grid_lines",
    "grid_subdivisions",
    "show_outline_selected",
    "show_object_origins",
    "show_object_origins_all",
    "show_relationship_lines",
    "show_cursor",
    "show_text",
    "show_stats",
    "show_performance",
    "show_camera_guides",
    "show_camera_passepartout",
    "show_extras",
    "show_light_colors",
    "show_bones",
    "show_face_orientation",
    "show_fade_inactive",
    "fade_inactive_alpha",
    "show_xray_bone",
    "xray_alpha_bone",
    "bone_wire_alpha",
    "show_motion_paths",
    "show_onion_skins",
    "show_look_dev",
    "show_wireframes",
    "wireframe_threshold",
    "wireframe_opacity",
    "show_annotation",
)


def _view3d_setting_value(owner, name):
    try:
        value = getattr(owner, name)
    except (AttributeError, ReferenceError, RuntimeError):
        return None
    if isinstance(value, (bool, int, float, str)):
        return value
    try:
        return tuple(value)
    except TypeError:
        return None


def _view3d_owner_settings(owner, property_names):
    return tuple(
        (name, value)
        for name in property_names
        if (value := _view3d_setting_value(owner, name)) is not None
    )


def _view3d_settings_snapshot(space):
    try:
        return (
            _view3d_owner_settings(
                space,
                _VIEW3D_SPACE_SYNC_PROPERTIES,
            ),
            _view3d_owner_settings(
                space.shading,
                _VIEW3D_SHADING_SYNC_PROPERTIES,
            ),
            _view3d_owner_settings(
                space.overlay,
                _VIEW3D_OVERLAY_SYNC_PROPERTIES,
            ),
        )
    except (AttributeError, ReferenceError, RuntimeError):
        return None


def _apply_view3d_owner_settings(owner, settings):
    changed = False
    for name, value in settings:
        if _view3d_setting_value(owner, name) == value:
            continue
        try:
            setattr(owner, name, value)
            changed = True
        except (
            AttributeError,
            ReferenceError,
            RuntimeError,
            TypeError,
            ValueError,
        ):
            pass
    return changed


def _apply_view3d_settings_snapshot(space, snapshot):
    if snapshot is None:
        return False
    try:
        return bool(
            _apply_view3d_owner_settings(space, snapshot[0])
            | _apply_view3d_owner_settings(space.shading, snapshot[1])
            | _apply_view3d_owner_settings(space.overlay, snapshot[2])
        )
    except (AttributeError, ReferenceError, RuntimeError):
        return False


def _view3d_setting_records():
    records = []
    for screen in tuple(bpy.data.screens):
        try:
            areas = tuple(screen.areas)
        except (AttributeError, ReferenceError):
            continue
        for area in areas:
            if area.type != "VIEW_3D":
                continue
            for space in tuple(area.spaces):
                if space.type != "VIEW_3D":
                    continue
                try:
                    pointer = int(space.as_pointer())
                except (AttributeError, ReferenceError):
                    continue
                records.append((pointer, screen, area, space))
    return records


def _sync_view3d_settings(context, source_space = None):
    records = _view3d_setting_records()
    live_pointers = {record[0] for record in records}
    previous = _state.setdefault("free_view_setting_states", {})
    window_manager = getattr(context, "window_manager", None)
    current_screens = {
        int(window.screen.as_pointer())
        for window in getattr(window_manager, "windows", ())
        if getattr(window, "screen", None) is not None
    }
    context_window = getattr(context, "window", None)
    context_screen = (
        getattr(context_window, "screen", None)
        if context_window is not None
        else None
    )
    context_screen_pointer = (
        int(context_screen.as_pointer())
        if context_screen is not None
        else 0
    )
    try:
        source_pointer = int(source_space.as_pointer()) if source_space else 0
    except (AttributeError, ReferenceError):
        source_pointer = 0
    forced_master = (
        _view3d_settings_snapshot(source_space)
        if source_space is not None
        else None
    )

    current_records = []
    changed_records = []
    for record in records:
        pointer, screen, _area, space = record
        snapshot = _view3d_settings_snapshot(space)
        if snapshot is None:
            continue
        if int(screen.as_pointer()) in current_screens:
            current_records.append((record, snapshot))
            old_snapshot = previous.get(pointer)
            if old_snapshot is not None and snapshot != old_snapshot:
                changed_records.append((record, snapshot))

    def source_priority(item):
        record, _snapshot = item
        pointer, screen, area, _space = record
        return (
            pointer == source_pointer,
            int(screen.as_pointer()) == context_screen_pointer,
            int(getattr(area, "width", 0)) * int(getattr(area, "height", 0)),
        )

    master = _state.get("free_view_settings_master")
    if forced_master is not None:
        master = forced_master
        _state["free_view_settings_master"] = master
    elif changed_records:
        _record, master = max(changed_records, key = source_priority)
        _state["free_view_settings_master"] = master
    elif master is None and current_records:
        _record, master = max(current_records, key = source_priority)
        _state["free_view_settings_master"] = master

    if master is not None:
        for _pointer, _screen, area, space in records:
            if _apply_view3d_settings_snapshot(space, master):
                try:
                    area.tag_redraw()
                except (AttributeError, ReferenceError):
                    pass

    for pointer, _screen, _area, space in records:
        snapshot = _view3d_settings_snapshot(space)
        if snapshot is not None:
            previous[pointer] = snapshot
    for pointer in tuple(previous):
        if pointer not in live_pointers:
            previous.pop(pointer, None)


def _free_view_records():
    records = []
    for screen in tuple(bpy.data.screens):
        try:
            areas = tuple(screen.areas)
        except (AttributeError, ReferenceError):
            continue
        for area in areas:
            if area.type != "VIEW_3D":
                continue
            for space in tuple(area.spaces):
                if space.type != "VIEW_3D":
                    continue
                region_data = getattr(space, "region_3d", None)
                if region_data is None:
                    continue
                try:
                    pointer = int(region_data.as_pointer())
                except (AttributeError, ReferenceError):
                    continue
                records.append((
                    pointer,
                    int(space.as_pointer()),
                    screen,
                    area,
                    region_data,
                ))
    return records


def _free_view_snapshot(region_data):
    try:
        if region_data.view_perspective == "CAMERA":
            return None
        return {
            "location": region_data.view_location.copy(),
            "rotation": region_data.view_rotation.copy(),
            "distance": float(region_data.view_distance),
            "perspective": str(region_data.view_perspective),
        }
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return None


def _free_view_snapshots_match(first, second):
    if first is None or second is None:
        return first is second
    try:
        return bool(
            first["perspective"] == second["perspective"]
            and abs(float(first["distance"]) - float(second["distance"]))
            <= 1.0e-8
            and (first["location"] - second["location"]).length_squared
            <= 1.0e-16
            and abs(first["rotation"].dot(second["rotation"]))
            >= 1.0 - 1.0e-12
        )
    except (KeyError, TypeError, ValueError):
        return False


def _apply_free_view_snapshot(region_data, snapshot):
    if snapshot is None:
        return False
    current = _free_view_snapshot(region_data)
    if current is None or _free_view_snapshots_match(current, snapshot):
        return False
    try:
        region_data.view_perspective = snapshot["perspective"]
        region_data.view_location = snapshot["location"].copy()
        region_data.view_rotation = snapshot["rotation"].copy()
        region_data.view_distance = float(snapshot["distance"])
        return True
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return False


def _free_view_record_protected(space_pointer, region_data):
    try:
        if region_data.view_perspective == "CAMERA":
            return True
    except (AttributeError, ReferenceError):
        return True
    state = _state.setdefault("camera_view_spaces", {}).get(
        int(space_pointer)
    )
    return bool(
        isinstance(state, dict)
        and (state.get("attached", False) or state.get("pending_level", False))
    )


def _sync_free_viewports(
    context,
    source_region_data = None,
    source_space = None,
):
    if _state.get("free_view_syncing", False):
        return
    _state["free_view_syncing"] = True
    try:
        _sync_view3d_settings(context, source_space = source_space)
        records = _free_view_records()
        live_pointers = {record[0] for record in records}
        previous = _state.setdefault("free_view_space_states", {})
        window_manager = getattr(context, "window_manager", None)
        current_screens = {
            int(window.screen.as_pointer())
            for window in getattr(window_manager, "windows", ())
            if getattr(window, "screen", None) is not None
        }
        context_window = getattr(context, "window", None)
        context_screen = (
            getattr(context_window, "screen", None)
            if context_window is not None
            else None
        )
        context_screen_pointer = (
            int(context_screen.as_pointer())
            if context_screen is not None
            else 0
        )
        context_region = getattr(context, "region_data", None)
        context_region_pointer = (
            int(context_region.as_pointer())
            if context_region is not None
            else 0
        )

        forced_master = None
        if source_region_data is not None and source_space is not None:
            try:
                source_space_pointer = int(source_space.as_pointer())
            except (AttributeError, ReferenceError):
                source_space_pointer = 0
            if not _free_view_record_protected(
                source_space_pointer,
                source_region_data,
            ):
                forced_master = _free_view_snapshot(source_region_data)

        current_records = []
        changed_records = []
        for record in records:
            pointer, space_pointer, screen, area, region_data = record
            if _free_view_record_protected(space_pointer, region_data):
                continue
            snapshot = _free_view_snapshot(region_data)
            if snapshot is None:
                continue
            if int(screen.as_pointer()) in current_screens:
                current_records.append((record, snapshot))
                old_snapshot = previous.get(pointer)
                if (
                    old_snapshot is not None
                    and not _free_view_snapshots_match(snapshot, old_snapshot)
                ):
                    changed_records.append((record, snapshot))

        def source_priority(item):
            record, _snapshot = item
            pointer, _space_pointer, screen, area, _region_data = record
            return (
                pointer == context_region_pointer,
                int(screen.as_pointer()) == context_screen_pointer,
                int(getattr(area, "width", 0)) * int(getattr(area, "height", 0)),
            )

        master = _state.get("free_view_master")
        if forced_master is not None:
            master = forced_master
            _state["free_view_master"] = master
        elif changed_records:
            _record, master = max(changed_records, key = source_priority)
            _state["free_view_master"] = master
        elif master is None and current_records:
            _record, master = max(current_records, key = source_priority)
            _state["free_view_master"] = master

        if master is not None:
            for (
                _pointer,
                space_pointer,
                _screen,
                area,
                region_data,
            ) in records:
                if _free_view_record_protected(space_pointer, region_data):
                    continue
                if _apply_free_view_snapshot(region_data, master):
                    try:
                        area.tag_redraw()
                    except (AttributeError, ReferenceError):
                        pass

        for pointer, space_pointer, _screen, _area, region_data in records:
            if _free_view_record_protected(space_pointer, region_data):
                continue
            snapshot = _free_view_snapshot(region_data)
            if snapshot is not None:
                previous[pointer] = snapshot
        for pointer in tuple(previous):
            if pointer not in live_pointers:
                previous.pop(pointer, None)
    finally:
        _state["free_view_syncing"] = False


def _free_view_draw_sync():
    context = bpy.context
    if (
        getattr(context, "region_data", None) is None
        or getattr(getattr(context, "space_data", None), "type", "")
        != "VIEW_3D"
    ):
        return
    try:
        source_pointer = int(context.region_data.as_pointer())
        source_space_pointer = int(context.space_data.as_pointer())
    except (AttributeError, ReferenceError):
        source_pointer = 0
        source_space_pointer = 0
    settings_snapshot = _view3d_settings_snapshot(context.space_data)
    settings_master = _state.get("free_view_settings_master")
    settings_changed = bool(
        settings_snapshot is not None
        and (
            settings_master is None
            or settings_snapshot != settings_master
        )
    )
    if _free_view_record_protected(source_space_pointer, context.region_data):
        if settings_changed:
            _sync_free_viewports(
                context,
                source_space = context.space_data,
            )
        return
    source_snapshot = _free_view_snapshot(context.region_data)
    if source_snapshot is None:
        return
    master = _state.get("free_view_master")
    if (
        master is not None
        and source_pointer not in _state.get("free_view_space_states", {})
    ):
        _sync_free_viewports(context)
        return
    if (
        not settings_changed
        and master is not None
        and _free_view_snapshots_match(source_snapshot, master)
    ):
        return
    _sync_free_viewports(
        context,
        source_region_data = context.region_data,
        source_space = context.space_data,
    )


def _camera_view_exit_timer():
    context = bpy.context
    window_manager = getattr(context, "window_manager", None)
    states = _state.setdefault("camera_view_spaces", {})
    live_spaces = set()
    if window_manager is not None:
        for window in window_manager.windows:
            scene = window.scene
            for area in window.screen.areas:
                if area.type != "VIEW_3D":
                    continue
                for space in area.spaces:
                    if space.type != "VIEW_3D":
                        continue
                    region_data = getattr(space, "region_3d", None)
                    if region_data is None:
                        continue
                    pointer = int(space.as_pointer())
                    live_spaces.add(pointer)
                    state = _camera_view_state(states.get(pointer))
                    in_camera_view = region_data.view_perspective == "CAMERA"
                    if in_camera_view:
                        camera = getattr(space, "camera", None) or scene.camera
                        armature, bone_name = _camera_bone_binding(camera)
                        state["attached"] = bool(armature is not None and bone_name)
                        state["pending_level"] = False
                        state["last_rotation"] = None
                        state["stable_ticks"] = 0
                    else:
                        current_rotation = region_data.view_rotation.copy()
                        if state["attached"]:
                            state["attached"] = False
                            state["pending_level"] = True
                            state["last_rotation"] = current_rotation
                            state["stable_ticks"] = 0
                        elif state["pending_level"]:
                            last_rotation = state["last_rotation"]
                            changed = (
                                last_rotation is None
                                or abs(current_rotation.dot(last_rotation)) < 1.0 - 1.0e-12
                            )
                            if changed:
                                state["last_rotation"] = current_rotation
                                state["stable_ticks"] = 0
                            else:
                                state["stable_ticks"] += 1
                                if state["stable_ticks"] >= 2:
                                    if _level_free_view_rotation(region_data):
                                        area.tag_redraw()
                                    state["pending_level"] = False
                                    state["last_rotation"] = None
                                    state["stable_ticks"] = 0
                    states[pointer] = state

    for pointer in tuple(states):
        if pointer not in live_spaces:
            states.pop(pointer, None)
    _sync_free_viewports(context)
    return 0.05


class STATICALIZA_OT_add_bone_camera(bpy.types.Operator):
    bl_idname = "staticaliza.add_bone_camera"
    bl_label = "Create Camera"
    bl_description = "Create or remove the camera rigidly attached to the selected pose bone"
    bl_options = {"REGISTER", "UNDO"}

    preset: bpy.props.EnumProperty(
        name = "Preset",
        description = "Choose the camera's horizontal field-of-view preset",
        items = CAMERA_FOV_PRESET_ITEMS,
        default = "CINEMATIC",
        update = _on_create_camera_preset,
    )
    fov: bpy.props.FloatProperty(
        name = "FOV",
        description = "Horizontal field of view for a custom camera preset",
        subtype = "ANGLE",
        default = math.radians(35.0),
        min = math.radians(1.0),
        max = math.radians(179.0),
    )
    orientation: bpy.props.EnumProperty(
        name = "Axis",
        description = "Choose the local bone axis the camera points along",
        items = CAMERA_ORIENTATION_ITEMS,
        default = "Z_NEG",
    )
    hide_attached_object: bpy.props.BoolProperty(
        name = "Hide Attached Object",
        description = "Hide mesh objects driven by the camera bone in the viewport and render",
        default = True,
    )
    removed_existing: bpy.props.BoolProperty(
        default = False,
        options = {"HIDDEN", "SKIP_SAVE"},
    )

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE" and bool(_selected_pose_bones_only(context))

    def draw(self, _context):
        layout = self.layout
        if self.removed_existing:
            layout.label(text = "Camera removed.")
            return
        layout.prop(self, "preset")
        if self.preset == "CUSTOM":
            layout.prop(self, "fov")
        layout.prop(self, "orientation")
        layout.prop(self, "hide_attached_object")

    def invoke(self, context, _event):
        selected = _selected_pose_bones_only(context)
        pose_bone = context.active_pose_bone
        if pose_bone not in selected:
            pose_bone = selected[0] if selected else None
        armature = _pose_bone_owner(context, pose_bone)
        existing_camera = (
            _camera_for_bone(context.scene, armature, pose_bone.name)
            if armature is not None and pose_bone is not None
            else None
        )
        self.removed_existing = existing_camera is not None
        if existing_camera is None:
            window_manager = context.window_manager
            self.preset = window_manager.staticaliza_camera_fov_preset
            self.fov = window_manager.staticaliza_camera_fov
            self.orientation = window_manager.staticaliza_camera_orientation
            self.hide_attached_object = True
        return self.execute(context)

    def execute(self, context):
        selected = _selected_pose_bones_only(context)
        pose_bone = context.active_pose_bone
        if pose_bone not in selected:
            pose_bone = selected[0] if selected else None
        armature = _pose_bone_owner(context, pose_bone)
        if armature is None or pose_bone is None:
            return {"CANCELLED"}

        existing_camera = _camera_for_bone(context.scene, armature, pose_bone.name)
        if existing_camera is not None:
            self.removed_existing = True
            _set_attached_camera_object_visibility(
                context.scene,
                existing_camera,
                False,
            )
            camera_data = existing_camera.data
            if context.scene.camera == existing_camera:
                context.scene.camera = None
            bpy.data.objects.remove(existing_camera, do_unlink = True)
            if camera_data.users == 0:
                bpy.data.cameras.remove(camera_data)
            self.report({"INFO"}, f"Removed camera from {pose_bone.name}.")
            return {"FINISHED"}

        self.removed_existing = False
        camera_angle = _camera_angle_for_preset(self.preset, self.fov)
        _state["camera_fov_syncing"] = True
        try:
            context.window_manager.staticaliza_camera_fov_preset = self.preset
            context.window_manager.staticaliza_camera_fov = camera_angle
            context.window_manager.staticaliza_camera_orientation = self.orientation
        finally:
            _state["camera_fov_syncing"] = False

        camera_data = bpy.data.cameras.new(f"Camera - {pose_bone.name}")
        camera_data.type = "PERSP"
        camera_data.sensor_fit = "HORIZONTAL"
        camera_data.angle = camera_angle

        camera = bpy.data.objects.new(camera_data.name, camera_data)
        context.collection.objects.link(camera)
        camera[ATTACHED_CAMERA_OWNER_NAME_PROPERTY] = armature.name
        camera[ATTACHED_CAMERA_OWNER_UID_PROPERTY] = str(
            _armature_session_uid(armature)
        )
        camera.staticaliza_camera_fov_preset = self.preset
        camera.staticaliza_camera_orientation = self.orientation
        camera_world = _camera_world_at_bone_tip(
            armature,
            pose_bone,
            camera.staticaliza_camera_orientation,
        )
        camera.parent = armature
        camera.parent_type = "BONE"
        camera.parent_bone = pose_bone.name
        camera.matrix_parent_inverse = Matrix.Identity(4)
        camera.matrix_world = camera_world
        camera.staticaliza_camera_hide_attached_object = self.hide_attached_object
        _set_attached_camera_object_visibility(
            context.scene,
            camera,
            self.hide_attached_object,
        )
        context.scene.render.resolution_x = 1920
        context.scene.render.resolution_y = 1080
        context.scene.render.resolution_percentage = 100
        context.scene.camera = camera
        context.view_layer.update()
        self.report({"INFO"}, f"Added camera to {pose_bone.name}.")
        return {"FINISHED"}


class STATICALIZA_OT_keyframe_camera_view(bpy.types.Operator):
    bl_idname = "staticaliza.keyframe_camera_view"
    bl_label = "Keyframe Camera to View"
    bl_description = "Move the selected bone camera to the current view and insert a keyframe"
    bl_options = {"REGISTER", "UNDO"}

    @staticmethod
    def _enter_camera_view(context, camera):
        if camera is None:
            return False
        context.scene.camera = camera
        area = getattr(context, "area", None)
        if getattr(area, "type", "") != "VIEW_3D":
            return False
        space = getattr(context, "space_data", None)
        if getattr(space, "type", "") != "VIEW_3D":
            space = area.spaces.active
        try:
            space.camera = camera
        except (AttributeError, ReferenceError, TypeError):
            pass
        region_data = getattr(space, "region_3d", None)
        if (
            region_data is not None
            and region_data.view_perspective == "CAMERA"
        ):
            return True
        window_region = next(
            (region for region in area.regions if region.type == "WINDOW"),
            None,
        )
        if window_region is None:
            return False
        try:
            with context.temp_override(
                area = area,
                region = window_region,
                space_data = space,
            ):
                if bpy.ops.view3d.view_camera.poll():
                    bpy.ops.view3d.view_camera()
        except (AttributeError, RuntimeError):
            return False
        return bool(
            region_data is not None
            and region_data.view_perspective == "CAMERA"
        )

    def execute(self, context):
        camera_world = _view_camera_matrix(context)
        if camera_world is None:
            return {"FINISHED"}

        armature, pose_bone, camera = _selected_camera_bone(context)
        if camera is not None:
            if _keyframe_camera_bone(context, armature, pose_bone, camera, camera_world):
                context.scene.camera = camera
                context.view_layer.update()
                self._enter_camera_view(context, camera)
                self.report({"INFO"}, f"Keyframed camera bone {pose_bone.name}.")
            return {"FINISHED"}

        camera = _standalone_camera(context)
        if camera is None:
            return {"FINISHED"}
        _keyframe_standalone_camera(camera, context.scene.frame_current, camera_world)
        context.scene.camera = camera
        context.view_layer.update()
        self._enter_camera_view(context, camera)
        self.report({"INFO"}, f"Keyframed camera {camera.name}.")
        return {"FINISHED"}


class STATICALIZA_OT_load_template(bpy.types.Operator):
    bl_idname = "staticaliza.load_template"
    bl_label = "Load Template"
    bl_description = "Replace the current Blender file with the bundled animation template"

    def draw(self, context):
        layout = self.layout
        layout.label(text = "This replaces the entire current Blender file.", icon = "ERROR")
        layout.label(text = "All unsaved changes will be permanently lost.")
        layout.separator()
        layout.label(text = "Continue and load the animation template?")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width = 440)

    def execute(self, context):
        templates_directory = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "templates",
        )
        template_path = os.path.join(templates_directory, "template.blend")
        baseplate_path = os.path.join(templates_directory, "Baseplate.png")
        if not os.path.isfile(template_path):
            self.report({"ERROR"}, "The bundled animation template is missing.")
            return {"CANCELLED"}
        if not os.path.isfile(baseplate_path):
            self.report({"ERROR"}, "The bundled Baseplate.png is missing.")
            return {"CANCELLED"}

        bpy.ops.wm.read_homefile(filepath = template_path, load_ui = True)
        _set_default_keyframe_handle_type()
        _capture_animation_channel_baseline()
        image = bpy.data.images.get("Baseplate.png")
        if image is None:
            image = bpy.data.images.load(baseplate_path, check_existing = True)
            image.pack()
        elif image.packed_file is None:
            image.filepath = baseplate_path
            image.reload()
            image.pack()
        return {"FINISHED"}


def _surface_contact_guides():
    collection = bpy.data.collections.get(SPACE_HELPER_COLLECTION)
    if collection is None:
        return ()
    return tuple(
        obj
        for obj in collection.objects
        if bool(obj.get(SURFACE_CONTACT_GUIDE_PROPERTY, False))
    )


def _surface_contact_guides_for_effector(armature, effector):
    if armature is None or effector is None:
        return ()
    return tuple(
        guide
        for guide in _surface_contact_guides()
        if (
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
            == armature.name
            and str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
            == effector.name
        )
    )


def _surface_contact_endpoint_conflict(armature, effector, frame):
    frame = int(frame)
    for guide in _surface_contact_guides_for_effector(armature, effector):
        if _surface_contact_guide_is_open(guide):
            return guide
        try:
            start = int(guide[SURFACE_CONTACT_START_PROPERTY])
        except (KeyError, TypeError, ValueError):
            continue
        if start >= frame or _surface_contact_guide_active_at(guide, frame):
            return guide
    return None


def _surface_contact_retarget_plan(armature, effector, frame):
    frame = int(frame)
    guides = tuple(
        sorted(
            _surface_contact_guides_for_effector(armature, effector),
            key = lambda guide: int(
                guide.get(SURFACE_CONTACT_START_PROPERTY, SPACE_MIN_FRAME)
            ),
        )
    )
    exact = tuple(
        guide
        for guide in guides
        if int(guide.get(SURFACE_CONTACT_START_PROPERTY, SPACE_MIN_FRAME))
        == frame
    )
    active = tuple(
        guide
        for guide in guides
        if guide not in exact and _surface_contact_guide_active_at(guide, frame)
    )
    previous = active[-1] if active else None
    carried_end = None
    source = exact[-1] if exact else previous
    if source is not None and SURFACE_CONTACT_END_PROPERTY in source:
        carried_end = int(source[SURFACE_CONTACT_END_PROPERTY])
    if carried_end is None:
        future_starts = [
            int(guide.get(SURFACE_CONTACT_START_PROPERTY, SPACE_MIN_FRAME))
            for guide in guides
            if guide not in exact
            and int(guide.get(SURFACE_CONTACT_START_PROPERTY, SPACE_MIN_FRAME))
            > frame
        ]
        carried_end = min(future_starts) if future_starts else None
    return exact, previous, carried_end


def _surface_contact_suspend_guides(guides):
    suspended = []
    for guide in guides:
        for constraint in _surface_contact_constraints(guide):
            if constraint is None:
                continue
            suspended.append((constraint, float(constraint.influence)))
            constraint.influence = 0.0
    try:
        bpy.context.view_layer.update()
    except (AttributeError, RuntimeError):
        pass
    return tuple(suspended)


def _surface_contact_restore_suspended(suspended):
    for constraint, influence in suspended:
        try:
            constraint.influence = float(influence)
        except (AttributeError, ReferenceError):
            pass
    try:
        bpy.context.view_layer.update()
    except (AttributeError, RuntimeError):
        pass


def _surface_contact_guide_active_at(guide, frame):
    try:
        start = int(guide[SURFACE_CONTACT_START_PROPERTY])
    except (KeyError, TypeError, ValueError):
        return False
    if int(frame) < start:
        return False
    if SURFACE_CONTACT_END_PROPERTY not in guide:
        return True
    try:
        return int(frame) < int(guide[SURFACE_CONTACT_END_PROPERTY])
    except (TypeError, ValueError):
        return True


def _surface_contact_guide_is_open(guide):
    return SURFACE_CONTACT_END_PROPERTY not in guide


def _surface_contact_selected_guide(context, active_only = False, open_only = False):
    selected_bone = _single_active_pose_bone(context)
    armature = _pose_bone_owner(context, selected_bone)
    if armature is None or selected_bone is None:
        return None

    frame = int(context.scene.frame_current)
    matches = []
    for guide in _surface_contact_guides():
        if str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, "")) != armature.name:
            continue
        names = {
            str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, "")),
            str(guide.get(SURFACE_CONTACT_CONTROL_BONE_PROPERTY, "")),
            str(guide.get(SURFACE_CONTACT_GEOMETRY_BONE_PROPERTY, "")),
            str(guide.get(SURFACE_CONTACT_CONSTRAINT_BONE_PROPERTY, "")),
            str(guide.get(SURFACE_CONTACT_RELEASE_BONE_PROPERTY, "")),
        }
        if selected_bone.name not in names:
            continue
        if active_only and not _surface_contact_guide_active_at(guide, frame):
            continue
        if open_only and not _surface_contact_guide_is_open(guide):
            continue
        matches.append(guide)
    if not matches:
        return None
    return max(
        matches,
        key = lambda item: int(item.get(SURFACE_CONTACT_START_PROPERTY, -1048574)),
    )


def _surface_contact_chain(ending_bone, chain_count):
    if ending_bone is None:
        return ()
    chain = [ending_bone]
    current = ending_bone.parent
    if int(chain_count) <= 0:
        while current is not None:
            chain.append(current)
            current = current.parent
        return tuple(chain)
    while current is not None and len(chain) < int(chain_count):
        chain.append(current)
        current = current.parent
    return tuple(chain)


def _surface_contact_ik_relation(armature, selected_bone):
    if armature is None or selected_bone is None:
        return None

    candidates = []
    for constrained_bone in armature.pose.bones:
        for constraint in constrained_bone.constraints:
            if constraint.type != "IK" or constraint.target is None:
                continue
            chain = _surface_contact_chain(
                constrained_bone,
                int(getattr(constraint, "chain_count", 0)),
            )
            target_object = constraint.target
            target_bone = None
            if constraint.subtarget and getattr(target_object, "pose", None):
                target_bone = target_object.pose.bones.get(constraint.subtarget)
                if target_bone is None:
                    continue

            score = None
            if selected_bone == constrained_bone:
                score = 0
            elif (
                target_bone is not None
                and target_object == armature
                and selected_bone.name == target_bone.name
            ):
                score = 1
            elif selected_bone in chain:
                score = 2 + chain.index(selected_bone)
            else:
                for selected_constraint in selected_bone.constraints:
                    if (
                        selected_constraint.type in {"COPY_LOCATION", "COPY_ROTATION", "COPY_TRANSFORMS"}
                        and selected_constraint.target == target_object
                        and str(selected_constraint.subtarget) == str(constraint.subtarget)
                    ):
                        score = 1
                        break
            if score is None:
                continue
            candidates.append(
                (
                    score,
                    {
                        "constraint": constraint,
                        "effector": constrained_bone,
                        "chain": chain,
                        "target_object": target_object,
                        "target_bone": target_bone,
                    },
                )
            )

    if not candidates:
        return None
    candidates.sort(key = lambda item: item[0])
    return candidates[0][1]


def _surface_contact_rig_objects(armature):
    objects = {armature}
    for obj in bpy.data.objects:
        if obj == armature or obj.parent == armature:
            objects.add(obj)
            continue
        try:
            if obj.find_armature() == armature:
                objects.add(obj)
                continue
        except (AttributeError, RuntimeError):
            pass
        if any(
            getattr(constraint, "target", None) == armature
            for constraint in getattr(obj, "constraints", ())
        ):
            objects.add(obj)
    return objects


def _surface_contact_object_visible(context, obj):
    if obj is None or bool(getattr(obj, "hide_viewport", False)):
        return False
    try:
        if obj.hide_get(view_layer = context.view_layer):
            return False
    except TypeError:
        if obj.hide_get():
            return False
    except (AttributeError, ReferenceError, RuntimeError):
        return False
    try:
        return bool(obj.visible_get(view_layer = context.view_layer))
    except TypeError:
        try:
            return bool(obj.visible_get())
        except (AttributeError, ReferenceError, RuntimeError):
            return True
    except (AttributeError, ReferenceError, RuntimeError):
        return True


def _surface_contact_ray_cast(context, origin, direction, distance, excluded):
    if direction.length_squared <= 1.0e-12:
        return None
    direction = direction.normalized()
    depsgraph = context.evaluated_depsgraph_get()
    remaining = float(distance)
    cast_origin = origin.copy()
    travelled = 0.0
    epsilon = max(1.0e-5, float(distance) * 1.0e-5)

    for _attempt in range(16):
        hit, location, normal, _face, hit_object, _matrix = context.scene.ray_cast(
            depsgraph,
            cast_origin,
            direction,
            distance = remaining,
        )
        if not hit or hit_object is None:
            return None
        original_object = getattr(hit_object, "original", hit_object)
        segment = max(0.0, float((location - cast_origin).dot(direction)))
        travelled += segment
        if (
            original_object not in excluded
            and _surface_contact_object_visible(context, original_object)
            and not bool(original_object.get(SURFACE_CONTACT_GUIDE_PROPERTY, False))
        ):
            return (
                original_object,
                location.copy(),
                normal.normalized(),
                travelled,
            )
        advance = segment + epsilon
        remaining -= advance
        if remaining <= epsilon:
            return None
        cast_origin = cast_origin + (direction * advance)
        travelled += epsilon
    return None


def _surface_contact_closest_point(surface, world_point, depsgraph, distance):
    evaluated_surface = surface.evaluated_get(depsgraph)
    local_point = evaluated_surface.matrix_world.inverted_safe() @ world_point
    try:
        hit, point, normal, _face = evaluated_surface.closest_point_on_mesh(
            local_point,
            distance = float(distance),
            depsgraph = depsgraph,
        )
    except TypeError:
        hit, point, normal, _face = evaluated_surface.closest_point_on_mesh(
            local_point,
            distance = float(distance),
        )
    if not hit:
        return None
    point = evaluated_surface.matrix_world @ point
    normal = (
        evaluated_surface.matrix_world.to_3x3().inverted_safe().transposed()
        @ normal
    )
    if normal.length_squared <= 1.0e-12:
        return None
    normal.normalize()
    return point, normal


def _surface_contact_bone_family_names(evaluated_armature, pose_bone):
    names = set().union(
        *_pose_bone_numeric_family_levels(evaluated_armature, pose_bone)
    )
    pending = [
        evaluated_armature.pose.bones.get(name)
        for name in tuple(names)
    ]
    while pending:
        parent = pending.pop()
        if parent is None:
            continue
        for child in parent.children:
            source_armature = getattr(
                evaluated_armature,
                "original",
                evaluated_armature,
            )
            source_bone = source_armature.data.bones.get(child.name)
            joint_type = str(
                source_bone.get("rbx_joint_type", "")
                if source_bone is not None
                else ""
            )
            if joint_type not in {"Weld", "WeldConstraint"}:
                continue
            if child.name in names:
                continue
            names.add(child.name)
            pending.append(child)
    return names


def _surface_contact_object_bone_names(obj, armature):
    names = set()
    if (
        obj.parent == armature
        and obj.parent_type == "BONE"
        and getattr(obj, "parent_bone", "")
    ):
        names.add(str(obj.parent_bone))
    for constraint in getattr(obj, "constraints", ()):
        if (
            getattr(constraint, "target", None) == armature
            and getattr(constraint, "subtarget", "")
        ):
            names.add(str(constraint.subtarget))

    uses_armature = False
    try:
        uses_armature = obj.find_armature() == armature
    except (AttributeError, ReferenceError, RuntimeError):
        pass
    if not uses_armature:
        uses_armature = any(
            modifier.type == "ARMATURE"
            and getattr(modifier, "object", None) == armature
            for modifier in getattr(obj, "modifiers", ())
        )
    if uses_armature:
        names.update(group.name for group in getattr(obj, "vertex_groups", ()))
    return names


def _surface_contact_connected_objects(context, armature, family_names):
    visible_objects = tuple(
        obj
        for obj in context.view_layer.objects
        if obj != armature and _surface_contact_object_visible(context, obj)
    )
    connected = {
        obj
        for obj in visible_objects
        if _surface_contact_object_bone_names(obj, armature) & family_names
    }
    if not connected:
        return ()

    # Include visible layers and accessories parented or constrained outward
    # from a directly bone-bound part, without walking upstream into the rig.
    for _depth in range(16):
        additions = set()
        for obj in visible_objects:
            if obj in connected:
                continue
            if obj.parent in connected:
                additions.add(obj)
                continue
            if any(
                getattr(constraint, "target", None) in connected
                for constraint in getattr(obj, "constraints", ())
            ):
                additions.add(obj)
        if not additions:
            break
        connected.update(additions)
    return tuple(connected)


def _surface_contact_part_geometry(context, armature, pose_bone):
    context.view_layer.update()
    depsgraph = context.evaluated_depsgraph_get()
    evaluated_armature = armature.evaluated_get(depsgraph)
    evaluated_bone = evaluated_armature.pose.bones.get(pose_bone.name)
    if evaluated_bone is None:
        return None, None, None, (), ()

    family_names = _surface_contact_bone_family_names(
        evaluated_armature,
        evaluated_bone,
    )
    connected_objects = _surface_contact_connected_objects(
        context,
        armature,
        family_names,
    )
    connected_parts = [
        obj for obj in connected_objects if obj.type == "MESH"
    ]
    if not connected_parts:
        return evaluated_armature, evaluated_bone, None, (), ()

    canonical_name = _strip_blender_numeric_suffix(evaluated_bone.name)
    connected_parts.sort(
        key = lambda obj: (
            0 if obj.name == canonical_name else 1,
            0 if _strip_blender_numeric_suffix(obj.name) == canonical_name else 1,
            1 if _object_has_linked_base_color(obj) else 0,
            obj.name.casefold(),
        )
    )
    part = connected_parts[0]
    points = []
    contributing_parts = []

    for connected_part in connected_parts:
        matching_object_name = (
            _strip_blender_numeric_suffix(connected_part.name) == canonical_name
        )
        rigid_connection = (
            connected_part.parent == armature
            and connected_part.parent_type == "BONE"
            and str(getattr(connected_part, "parent_bone", "")) in family_names
        )
        if not rigid_connection:
            rigid_connection = any(
                getattr(constraint, "target", None) == armature
                and str(getattr(constraint, "subtarget", "")) in family_names
                for constraint in connected_part.constraints
            )
        group_indices = {
            group.index
            for group in connected_part.vertex_groups
            if group.name in family_names
        }
        evaluated_part = connected_part.evaluated_get(depsgraph)
        mesh = None
        part_points = []
        weighted_points = []
        try:
            mesh = evaluated_part.to_mesh(
                preserve_all_data_layers = True,
                depsgraph = depsgraph,
            )
        except TypeError:
            mesh = evaluated_part.to_mesh()

        try:
            if mesh is not None:
                source_vertices = getattr(connected_part.data, "vertices", ())
                same_topology = len(source_vertices) == len(mesh.vertices)
                for index, vertex in enumerate(mesh.vertices):
                    world_point = evaluated_part.matrix_world @ vertex.co
                    if rigid_connection or matching_object_name or not group_indices:
                        part_points.append(world_point.copy())
                        continue

                    weight = 0.0
                    groups = (
                        source_vertices[index].groups
                        if same_topology
                        else getattr(vertex, "groups", ())
                    )
                    for membership in groups:
                        if membership.group in group_indices:
                            weight = max(weight, float(membership.weight))
                    if weight > 0.0:
                        weighted_points.append((weight, world_point.copy()))
        finally:
            if mesh is not None:
                evaluated_part.to_mesh_clear()

        if weighted_points and not part_points:
            peak_weight = max(weight for weight, _point in weighted_points)
            threshold = max(0.05, peak_weight * 0.25)
            part_points = [
                point
                for weight, point in weighted_points
                if weight >= threshold
            ]
        if (
            not part_points
            and connected_part == part
            and (rigid_connection or not group_indices)
        ):
            part_points = [
                evaluated_part.matrix_world @ Vector(corner)
                for corner in evaluated_part.bound_box
            ]
        if part_points:
            contributing_parts.append(connected_part)
        points.extend(part_points)

    # Contact creation is a one-shot operation, but very dense custom meshes
    # should not stall Blender while still retaining a representative hull.
    if len(points) > 20000:
        step = max(1, len(points) // 20000)
        points = points[::step]
    if not points or not contributing_parts:
        return evaluated_armature, evaluated_bone, None, (), ()
    part = contributing_parts[0]
    return (
        evaluated_armature,
        evaluated_bone,
        part,
        tuple(points),
        tuple(contributing_parts),
    )


def _surface_contact_geometry_center(points):
    if not points:
        return None
    center = Vector((0.0, 0.0, 0.0))
    for point in points:
        center += point
    return center / float(len(points))


def _surface_contact_detect_surface(
    context,
    armature,
    evaluated_armature,
    evaluated_bone,
    geometry_points,
    support_objects = (),
    contact_anchor = None,
    smart_object_name = "",
):
    if evaluated_armature is None or evaluated_bone is None or not geometry_points:
        return None, None, None, None
    depsgraph = context.evaluated_depsgraph_get()

    head = evaluated_armature.matrix_world @ evaluated_bone.head
    tail = evaluated_armature.matrix_world @ evaluated_bone.tail
    bone_vector = tail - head
    bone_length = max(bone_vector.length, 0.05)
    bone_direction = (
        bone_vector.normalized()
        if bone_vector.length_squared > 1.0e-12
        else Vector((0.0, 0.0, -1.0))
    )
    center = _surface_contact_geometry_center(geometry_points)
    if center is None:
        return None, None, None, bone_length
    anchor = (
        Vector(contact_anchor)
        if contact_anchor is not None
        else center.copy()
    )
    extent = max(
        (point - center).length
        for point in geometry_points
    )
    reach = max(0.5, bone_length * 4.0, extent * 3.0)
    padding = max(0.005, min(bone_length, max(extent, 0.05)) * 0.04)
    # Smart Pin uses the connected object's local -Y face. Cast along that
    # transformed axis so a rotated hand naturally searches toward a wall and
    # a rotated foot searches toward its own local floor, never a world axis.
    contact_direction = None
    smart_object = bpy.data.objects.get(str(smart_object_name))
    if smart_object is not None:
        try:
            evaluated_object = smart_object.evaluated_get(depsgraph)
            contact_direction = (
                evaluated_object.matrix_world.to_3x3()
                @ Vector((0.0, -1.0, 0.0))
            )
        except (AttributeError, ReferenceError, RuntimeError):
            contact_direction = None
    if contact_direction is None or contact_direction.length_squared <= 1.0e-12:
        contact_direction = anchor - center
    if contact_direction.length_squared <= 1.0e-12:
        contact_direction = bone_direction.copy()
    contact_direction.normalize()

    directions = [contact_direction]
    if abs(contact_direction.dot(bone_direction)) < 0.995:
        directions.append(bone_direction)

    surface_mode = str(
        getattr(
            context.window_manager,
            "staticaliza_surface_contact_mode",
            "AUTO",
        )
    )
    # The contacted limb cannot collide with its own hull, but every other
    # visible rig object remains a valid floor, wall, or obstacle.
    excluded = {armature, *support_objects}
    candidates = []
    near_distance = max(
        padding * 4.0,
        min(reach, max(0.05, bone_length * 0.15, extent * 0.15)),
    )
    for surface in context.view_layer.objects:
        if (
            surface in excluded
            or surface.type != "MESH"
            or not _surface_contact_object_visible(context, surface)
            or bool(surface.get(SURFACE_CONTACT_GUIDE_PROPERTY, False))
        ):
            continue
        closest = _surface_contact_closest_point(
            surface,
            anchor,
            depsgraph,
            near_distance,
        )
        if closest is None:
            continue
        point, normal = closest
        if normal.dot(center - point) < 0.0:
            normal.negate()
        separation_vector = point - anchor
        separation = separation_vector.length
        if (
            separation > padding * 2.0
            and separation_vector.normalized().dot(contact_direction) < 0.35
        ):
            continue
        if normal.dot(contact_direction) > -0.05:
            continue
        if surface_mode == "FLOOR" and normal.z < 0.35:
            continue
        if surface_mode == "WALL" and abs(normal.z) > 0.8:
            continue
        candidates.append(
            (
                separation,
                surface,
                point.copy(),
                normal.copy(),
            )
        )

    unique_directions = []
    for direction_index, direction in enumerate(directions):
        if direction.length_squared <= 1.0e-12:
            continue
        direction = direction.normalized()
        if any(abs(direction.dot(existing)) > 0.9999 for existing in unique_directions):
            continue
        unique_directions.append(direction)

        support = anchor
        casts = (
            (
                support - (direction * padding),
                direction,
                reach + (padding * 2.0),
            ),
            # A planted point can be exactly coplanar. Probe back across the
            # anchor so Blender still returns that same surface on retarget.
            (
                support + (direction * padding),
                -direction,
                padding * 4.0,
            ),
            (center, direction, reach + (padding * 2.0)),
        )
        for cast_origin, cast_direction, cast_distance in casts:
            result = _surface_contact_ray_cast(
                context,
                cast_origin,
                cast_direction,
                cast_distance,
                excluded,
            )
            if result is None:
                continue
            surface, point, normal, _travelled = result
            if surface.type != "MESH":
                continue
            if normal.dot(center - point) < 0.0:
                normal.negate()
            if surface_mode == "FLOOR" and normal.z < 0.35:
                continue
            if surface_mode == "WALL" and abs(normal.z) > 0.8:
                continue
            separation = (point - support).length
            preference = float(direction_index) * reach
            candidates.append(
                (
                    separation + preference,
                    surface,
                    point.copy(),
                    normal.copy(),
                )
            )

    if not candidates:
        return None, None, None, bone_length
    candidates.sort(key = lambda item: item[0])
    _score, surface, point, normal = candidates[0]
    return surface, point, normal, bone_length


def _surface_contact_aim_influence(local_support):
    support = Vector(local_support)
    if support.length_squared <= 1.0e-12:
        return 0.0
    return SURFACE_CONTACT_AIM_INFLUENCE


def _surface_contact_plane_matrix(surface_point, surface_normal, reference_matrix):
    normal = Vector(surface_normal)
    if normal.length_squared <= 1.0e-12:
        normal = Vector((0.0, 0.0, 1.0))
    else:
        normal.normalize()
    reference_axes = (
        reference_matrix.to_3x3().col[0],
        reference_matrix.to_3x3().col[1],
        Vector((1.0, 0.0, 0.0)),
        Vector((0.0, 1.0, 0.0)),
    )
    tangent = None
    for axis in reference_axes:
        projected = axis - (normal * axis.dot(normal))
        if projected.length_squared <= 1.0e-12:
            continue
        tangent = projected.normalized()
        break
    if tangent is None:
        tangent = Vector((1.0, 0.0, 0.0))
    bitangent = normal.cross(tangent).normalized()
    tangent = bitangent.cross(normal).normalized()
    matrix = Matrix((tangent, bitangent, normal)).transposed().to_4x4()
    matrix.translation = surface_point
    return matrix


def _surface_contact_guide_aim_influence(guide):
    support = guide.get(SURFACE_CONTACT_SUPPORT_PROPERTY)
    computed_influence = (
        SURFACE_CONTACT_AIM_INFLUENCE
        if support is None or len(support) < 3
        else _surface_contact_aim_influence(support[:3])
    )
    stored_influence = guide.get(SURFACE_CONTACT_AIM_PROPERTY)
    if stored_influence is None:
        return computed_influence
    # Migrate guides created while the alignment gate could save zero.
    return max(float(stored_influence), computed_influence)


def _surface_contact_target_world_matrix(context, target_object, bone_name = ""):
    context.view_layer.update()
    depsgraph = context.evaluated_depsgraph_get()
    evaluated_object = target_object.evaluated_get(depsgraph)
    if bone_name and getattr(evaluated_object, "pose", None):
        evaluated_bone = evaluated_object.pose.bones.get(bone_name)
        if evaluated_bone is None:
            return None
        return (evaluated_object.matrix_world @ evaluated_bone.matrix).copy()
    return evaluated_object.matrix_world.copy()


def _surface_contact_set_target_world_matrix(
    context,
    target_object,
    bone_name,
    world_matrix,
    frame = None,
    visual_key = False,
):
    if target_object is None or world_matrix is None:
        return False
    if bone_name and getattr(target_object, "pose", None):
        pose_bone = target_object.pose.bones.get(bone_name)
        if pose_bone is None:
            return False
        pose_bone.matrix = target_object.matrix_world.inverted_safe() @ world_matrix
        context.view_layer.update()
        if frame is not None:
            _insert_bone_keys(
                pose_bone,
                int(frame),
                visual = bool(visual_key),
            )
        return True

    target_object.matrix_world = world_matrix
    context.view_layer.update()
    if frame is not None:
        insert_keyframe(target_object, int(frame))
    return True


def _surface_contact_explicit_bone_binding(surface):
    def has_bone(armature, bone_name):
        pose = getattr(armature, "pose", None)
        if pose is not None and pose.bones.get(bone_name) is not None:
            return True
        data = getattr(armature, "data", None)
        return data is not None and data.bones.get(bone_name) is not None

    pending = [surface]
    visited = set()
    for _depth in range(64):
        if not pending:
            break
        current = pending.pop(0)
        if current is None or current in visited:
            continue
        visited.add(current)
        parent = getattr(current, "parent", None)
        if (
            parent is not None
            and parent.type == "ARMATURE"
            and getattr(current, "parent_type", "") == "BONE"
        ):
            bone_name = str(getattr(current, "parent_bone", ""))
            if bone_name and has_bone(parent, bone_name):
                return parent, bone_name
        if parent is not None and parent not in visited:
            pending.append(parent)
        for constraint in getattr(current, "constraints", ()):
            if bool(getattr(constraint, "mute", False)):
                continue
            if float(getattr(constraint, "influence", 1.0)) <= 1.0e-6:
                continue
            target = getattr(constraint, "target", None)
            bone_name = str(getattr(constraint, "subtarget", ""))
            if (
                target is not None
                and target.type == "ARMATURE"
                and bone_name
                and has_bone(target, bone_name)
            ):
                return target, bone_name
            if target is not None and target not in visited:
                pending.append(target)
    return None, ""


def _surface_contact_rig_meta_bone_binding(surface):
    if surface is None:
        return None, ""

    object_name = str(getattr(surface, "name", ""))
    canonical_name = _strip_blender_numeric_suffix(object_name)

    def name_score(candidate):
        candidate = str(candidate or "")
        if candidate.casefold() == object_name.casefold():
            return 0
        if (
            _strip_blender_numeric_suffix(candidate).casefold()
            == canonical_name.casefold()
        ):
            return 1
        return None

    def armature_has_bone(armature, bone_name):
        pose = getattr(armature, "pose", None)
        return bool(
            bone_name
            and pose is not None
            and pose.bones.get(str(bone_name)) is not None
        )

    for collection, armature, meta in _iter_roblox_rigs():
        try:
            if collection.all_objects.get(surface.name) != surface:
                continue
        except (AttributeError, ReferenceError, RuntimeError):
            continue

        candidates = []
        try:
            metadata = json.loads(str(meta.get("RigMeta", "")))
        except (TypeError, ValueError):
            metadata = {}

        mesh_to_bone = metadata.get("meshToBone", {})
        if isinstance(mesh_to_bone, dict):
            for mesh_name, bone_name in mesh_to_bone.items():
                score = name_score(mesh_name)
                if score is not None and armature_has_bone(armature, bone_name):
                    candidates.append((score, 0, str(bone_name)))

        def walk_rig_node(node):
            if not isinstance(node, dict):
                return
            bone_name = str(node.get("jname", ""))
            if armature_has_bone(armature, bone_name):
                linked_names = [node.get("pname"), node.get("jname")]
                linked_names.extend(node.get("aux") or ())
                for linked_name in linked_names:
                    score = name_score(linked_name)
                    if score is not None:
                        candidates.append((score, 1, bone_name))
            for child in node.get("children") or ():
                walk_rig_node(child)

        walk_rig_node(metadata.get("rig"))

        for bone_name in (object_name, canonical_name):
            if armature_has_bone(armature, bone_name):
                candidates.append((name_score(bone_name) or 0, 2, bone_name))

        if candidates:
            _score, _source, bone_name = min(
                candidates,
                key = lambda item: (item[0], item[1], item[2].casefold()),
            )
            return armature, bone_name
    return None, ""


def _surface_contact_normalize_bone_label(armature, bone_name):
    bone_name = str(bone_name or "")
    pose = getattr(armature, "pose", None)
    if not bone_name or pose is None:
        return _strip_blender_numeric_suffix(bone_name)

    pose_bone = pose.bones.get(bone_name)
    visited = set()
    while pose_bone is not None and pose_bone.name not in visited:
        visited.add(pose_bone.name)
        source_bone = getattr(pose_bone, "bone", None)
        joint_type = str(
            source_bone.get("rbx_joint_type", "")
            if source_bone is not None
            else ""
        )
        canonical_name = _strip_blender_numeric_suffix(pose_bone.name)
        canonical_bone = pose.bones.get(canonical_name)
        if (
            canonical_bone is not None
            and canonical_bone != pose_bone
            and str(canonical_bone.bone.get("rbx_joint_type", ""))
            not in {"Weld", "WeldConstraint"}
        ):
            pose_bone = canonical_bone
            continue
        if joint_type not in {"Weld", "WeldConstraint"}:
            return pose_bone.name
        pose_bone = pose_bone.parent

    return _strip_blender_numeric_suffix(bone_name)


def _surface_contact_surface_display_label(surface, world_point, depsgraph):
    if surface is None:
        return "World"
    armature, bone_name = _surface_contact_surface_binding(
        surface,
        Vector(world_point),
        depsgraph,
    )
    if bone_name:
        return _surface_contact_normalize_bone_label(armature, bone_name)
    return _strip_blender_numeric_suffix(str(surface.name)) or "World"


def _surface_contact_guide_surface_label(guide):
    stored_label = str(guide.get(SURFACE_CONTACT_LABEL_PROPERTY, ""))
    if stored_label:
        return stored_label

    follow_object = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_FOLLOW_OBJECT_PROPERTY, ""))
    )
    bone_name = str(guide.get(SURFACE_CONTACT_FOLLOW_BONE_PROPERTY, ""))
    if bone_name:
        return _surface_contact_normalize_bone_label(follow_object, bone_name)
    surface_object = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_SURFACE_PROPERTY, ""))
    )
    if surface_object is not None:
        local_point = guide.get(SURFACE_CONTACT_POINT_PROPERTY)
        world_point = guide.matrix_world.translation.copy()
        if local_point is not None and len(local_point) >= 3:
            try:
                world_point = surface_object.matrix_world @ Vector(local_point[:3])
            except (TypeError, ValueError):
                pass
        try:
            depsgraph = bpy.context.evaluated_depsgraph_get()
            label = _surface_contact_surface_display_label(
                surface_object,
                world_point,
                depsgraph,
            )
            if label:
                return label
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            pass
    return (
        _strip_blender_numeric_suffix(
            str(guide.get(SURFACE_CONTACT_SURFACE_PROPERTY, ""))
        )
        or "World"
    )


def _surface_contact_surface_binding(surface, world_point, depsgraph):
    if surface is None:
        return None, ""

    explicit_armature, explicit_bone = _surface_contact_explicit_bone_binding(
        surface
    )
    if explicit_armature is not None and explicit_bone:
        return explicit_armature, explicit_bone

    armature = None
    try:
        armature = surface.find_armature()
    except (AttributeError, ReferenceError, RuntimeError):
        pass
    if armature is None:
        armature = next(
            (
                modifier.object
                for modifier in getattr(surface, "modifiers", ())
                if modifier.type == "ARMATURE"
                and getattr(modifier, "object", None) is not None
            ),
            None,
        )
    if armature is None or getattr(armature, "pose", None) is None:
        metadata_armature, metadata_bone = (
            _surface_contact_rig_meta_bone_binding(surface)
        )
        if metadata_armature is not None and metadata_bone:
            return metadata_armature, metadata_bone
        return surface, ""

    evaluated_surface = surface.evaluated_get(depsgraph)
    mesh = None
    nearest_index = None
    nearest_distance = float("inf")
    try:
        try:
            mesh = evaluated_surface.to_mesh(
                preserve_all_data_layers = False,
                depsgraph = depsgraph,
            )
        except TypeError:
            mesh = evaluated_surface.to_mesh()
        source_vertices = getattr(getattr(surface, "data", None), "vertices", ())
        if mesh is not None and len(mesh.vertices) == len(source_vertices):
            for vertex in mesh.vertices:
                distance = (
                    evaluated_surface.matrix_world @ vertex.co - world_point
                ).length_squared
                if distance < nearest_distance:
                    nearest_distance = distance
                    nearest_index = int(vertex.index)
    finally:
        if mesh is not None:
            evaluated_surface.to_mesh_clear()

    if nearest_index is not None:
        weighted_bones = []
        source_vertex = surface.data.vertices[nearest_index]
        for membership in source_vertex.groups:
            try:
                group_name = surface.vertex_groups[membership.group].name
            except (IndexError, ReferenceError):
                continue
            if armature.pose.bones.get(group_name) is not None:
                weighted_bones.append((float(membership.weight), group_name))
        if weighted_bones:
            weighted_bones.sort(reverse = True)
            return armature, weighted_bones[0][1]

    metadata_armature, metadata_bone = _surface_contact_rig_meta_bone_binding(
        surface
    )
    if metadata_armature is not None and metadata_bone:
        return metadata_armature, metadata_bone
    return surface, ""


def _surface_contact_parent_guide(guide, follow_object, follow_bone, world_matrix):
    if guide is None or follow_object is None:
        return False
    try:
        guide.parent = follow_object
        if follow_bone:
            guide.parent_type = "BONE"
            guide.parent_bone = str(follow_bone)
        else:
            guide.parent_type = "OBJECT"
            guide.parent_bone = ""
        guide.matrix_world = world_matrix
        guide[SURFACE_CONTACT_FOLLOW_OBJECT_PROPERTY] = follow_object.name
        guide[SURFACE_CONTACT_FOLLOW_BONE_PROPERTY] = str(follow_bone)
        return True
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return False


def _surface_contact_create_guide(
    context,
    armature,
    effector,
    target_object,
    target_bone_name,
    geometry_bone_name,
    anchor_world,
    surface_object,
    surface_point,
    surface_normal,
    bone_length,
    frame,
):
    digest = hashlib.sha1(
        f"{armature.name}:{effector.name}:{int(frame)}:{time.time_ns()}".encode(
            "utf-8"
        )
    ).hexdigest()[:12]
    guide = bpy.data.objects.new(f"_SurfaceContactGuide_{digest}", None)
    _ensure_space_helper_collection(context).objects.link(guide)
    guide[SURFACE_CONTACT_GUIDE_PROPERTY] = True
    guide[SURFACE_CONTACT_ARMATURE_PROPERTY] = armature.name
    guide[SURFACE_CONTACT_BONE_PROPERTY] = effector.name
    guide[SURFACE_CONTACT_CONTROL_OBJECT_PROPERTY] = target_object.name
    guide[SURFACE_CONTACT_CONTROL_BONE_PROPERTY] = target_bone_name
    guide[SURFACE_CONTACT_GEOMETRY_BONE_PROPERTY] = str(geometry_bone_name)
    guide[SURFACE_CONTACT_START_PROPERTY] = int(frame)
    guide[SURFACE_CONTACT_SIZE_PROPERTY] = max(0.04, float(bone_length) * 0.18)
    guide.empty_display_type = "CIRCLE"
    guide.empty_display_size = float(guide[SURFACE_CONTACT_SIZE_PROPERTY])
    guide.color = SURFACE_CONTACT_HOT_PINK
    guide.hide_render = True
    guide.hide_select = True
    guide.rotation_mode = "QUATERNION"

    guide.matrix_world = anchor_world
    if surface_object is not None:
        depsgraph = context.evaluated_depsgraph_get()
        follow_object, follow_bone = _surface_contact_surface_binding(
            surface_object,
            surface_point,
            depsgraph,
        )
        follow_world = surface_object.matrix_world
        if follow_object is not None and follow_bone:
            try:
                evaluated_follow = follow_object.evaluated_get(depsgraph)
                evaluated_bone = evaluated_follow.pose.bones.get(follow_bone)
                if evaluated_bone is not None:
                    follow_world = (
                        evaluated_follow.matrix_world @ evaluated_bone.matrix
                    )
            except (AttributeError, ReferenceError, RuntimeError):
                pass
        elif follow_object is not None:
            try:
                follow_world = follow_object.evaluated_get(depsgraph).matrix_world
            except (AttributeError, ReferenceError, RuntimeError):
                follow_world = follow_object.matrix_world
        local_guide_matrix = follow_world.inverted_safe() @ anchor_world
        guide[SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY] = tuple(
            float(value)
            for row in local_guide_matrix
            for value in row
        )
        guide[SURFACE_CONTACT_SURFACE_PROPERTY] = surface_object.name
        local_point = surface_object.matrix_world.inverted_safe() @ surface_point
        local_normal = surface_object.matrix_world.to_3x3().transposed() @ surface_normal
        if local_normal.length_squared > 1.0e-12:
            local_normal.normalize()
        guide[SURFACE_CONTACT_POINT_PROPERTY] = tuple(local_point)
        guide[SURFACE_CONTACT_NORMAL_PROPERTY] = tuple(local_normal)
        guide[SURFACE_CONTACT_LABEL_PROPERTY] = (
            _surface_contact_surface_display_label(
                surface_object,
                surface_point,
                depsgraph,
            )
        )
        _surface_contact_parent_guide(
            guide,
            follow_object or surface_object,
            follow_bone,
            anchor_world,
        )
    else:
        guide[SURFACE_CONTACT_SURFACE_PROPERTY] = ""
        guide[SURFACE_CONTACT_POINT_PROPERTY] = tuple(surface_point)
        guide[SURFACE_CONTACT_NORMAL_PROPERTY] = tuple(surface_normal)
        guide[SURFACE_CONTACT_FOLLOW_OBJECT_PROPERTY] = ""
        guide[SURFACE_CONTACT_FOLLOW_BONE_PROPERTY] = ""
    try:
        guide.hide_set(True)
    except RuntimeError:
        pass
    context.view_layer.update()
    return guide


def _surface_contact_owner_from_guide(guide):
    target_object = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_CONTROL_OBJECT_PROPERTY, ""))
    )
    if target_object is None:
        return None, None
    bone_name = str(guide.get(SURFACE_CONTACT_CONTROL_BONE_PROPERTY, ""))
    if bone_name and getattr(target_object, "pose", None):
        return target_object, target_object.pose.bones.get(bone_name)
    return target_object, target_object


def _surface_contact_constraint_owner_from_guide(guide):
    target_object = bpy.data.objects.get(
        str(
            guide.get(
                SURFACE_CONTACT_CONSTRAINT_OBJECT_PROPERTY,
                guide.get(SURFACE_CONTACT_CONTROL_OBJECT_PROPERTY, ""),
            )
        )
    )
    if target_object is None:
        return None, None
    bone_name = str(
        guide.get(
            SURFACE_CONTACT_CONSTRAINT_BONE_PROPERTY,
            guide.get(SURFACE_CONTACT_CONTROL_BONE_PROPERTY, ""),
        )
    )
    if bone_name and getattr(target_object, "pose", None):
        return target_object, target_object.pose.bones.get(bone_name)
    return target_object, target_object


def _surface_contact_solver_from_guide(guide):
    return bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_SOLVER_OBJECT_PROPERTY, ""))
    )


def _surface_contact_simulated_pose_bone(guide):
    if (
        guide is None
        or str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
        != SURFACE_CONTACT_KIND_SIMULATED
    ):
        return None
    armature = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
    )
    if armature is None or getattr(armature, "pose", None) is None:
        return None
    return armature.pose.bones.get(
        str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
    )


def _surface_contact_simulated_pose_matrix(guide):
    pose_bone = _surface_contact_simulated_pose_bone(guide)
    return pose_bone.matrix.copy() if pose_bone is not None else None


def _surface_contact_keyframe_simulated_pose(guide, frame):
    pose_bone = _surface_contact_simulated_pose_bone(guide)
    if pose_bone is None:
        return False
    _insert_bone_keys(pose_bone, int(frame))
    return True


def _surface_contact_restore_simulated_pose(
    context,
    guide,
    matrix,
    update_view_layer = True,
):
    if matrix is None:
        return False
    pose_bone = _surface_contact_simulated_pose_bone(guide)
    if pose_bone is None:
        return False
    pose_bone.matrix = matrix.copy()
    if update_view_layer:
        context.view_layer.update()
    return True


def _surface_contact_store_solver_local_matrix(guide):
    solver = _surface_contact_solver_from_guide(guide)
    if solver is None:
        return False
    local_matrix = guide.matrix_world.inverted_safe() @ solver.matrix_world
    guide[SURFACE_CONTACT_SOLVER_LOCAL_MATRIX_PROPERTY] = tuple(
        float(value)
        for row in local_matrix
        for value in row
    )
    return True


def _surface_contact_update_control_solver(guide):
    if (
        str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
        != SURFACE_CONTACT_KIND_CONTROL
    ):
        return False
    solver = _surface_contact_solver_from_guide(guide)
    values = guide.get(SURFACE_CONTACT_SOLVER_LOCAL_MATRIX_PROPERTY)
    if solver is None:
        return False
    if values is None or len(values) < 16:
        return _surface_contact_store_solver_local_matrix(guide)
    try:
        local_matrix = Matrix(
            tuple(
                tuple(
                    float(values[(row * 4) + column])
                    for column in range(4)
                )
                for row in range(4)
            )
        )
        desired_world = guide.matrix_world @ local_matrix
        current_world = solver.matrix_world
        translation_changed = (
            desired_world.translation - current_world.translation
        ).length > 1.0e-7
        rotation_changed = desired_world.to_quaternion().rotation_difference(
            current_world.to_quaternion()
        ).angle > 1.0e-7
        if not translation_changed and not rotation_changed:
            return False
        solver.matrix_world = desired_world
        return True
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return False


def _surface_contact_constraints(guide):
    _target_object, owner = _surface_contact_constraint_owner_from_guide(guide)
    if owner is None:
        return None, None
    primary = owner.constraints.get(
        str(guide.get(SURFACE_CONTACT_PRIMARY_PROPERTY, ""))
    )
    secondary_name = str(guide.get(SURFACE_CONTACT_SECONDARY_PROPERTY, ""))
    secondary = owner.constraints.get(secondary_name) if secondary_name else None
    return primary, secondary


def _surface_contact_configure_rotation_constraint(constraint, solver):
    if constraint is None or solver is None or constraint.type != "COPY_ROTATION":
        return False
    changed = False
    desired = (
        ("target", solver),
        ("owner_space", "WORLD"),
        ("target_space", "WORLD"),
    )
    for property_name, value in desired:
        if getattr(constraint, property_name, None) != value:
            setattr(constraint, property_name, value)
            changed = True
    if hasattr(constraint, "mix_mode") and constraint.mix_mode != "REPLACE":
        constraint.mix_mode = "REPLACE"
        changed = True
    return changed


def _surface_contact_create_rotation_constraint(owner, solver, name):
    if owner is None or solver is None:
        return None
    constraint = owner.constraints.new("COPY_ROTATION")
    constraint.name = str(name)
    _surface_contact_configure_rotation_constraint(constraint, solver)
    constraint.influence = 0.0
    return constraint


def _surface_contact_ensure_control_rotation_constraint(context, guide):
    if (
        str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
        != SURFACE_CONTACT_KIND_CONTROL
    ):
        return False
    solver = _surface_contact_solver_from_guide(guide)
    target_object, owner = _surface_contact_constraint_owner_from_guide(guide)
    if solver is None or target_object is None or owner is None:
        return False

    bone_name = str(
        guide.get(
            SURFACE_CONTACT_CONSTRAINT_BONE_PROPERTY,
            guide.get(SURFACE_CONTACT_CONTROL_BONE_PROPERTY, ""),
        )
    )
    changed = False
    if int(guide.get(SURFACE_CONTACT_ROTATION_BINDING_PROPERTY, 0)) < 1:
        owner_world = _surface_contact_target_world_matrix(
            context,
            target_object,
            bone_name,
        )
        if owner_world is not None:
            solver_world = owner_world.normalized()
            solver_world.translation = solver.matrix_world.translation.copy()
            solver.matrix_world = solver_world
            context.view_layer.update()
            _surface_contact_store_solver_local_matrix(guide)
            changed = True

    _primary, secondary = _surface_contact_constraints(guide)
    if secondary is not None and secondary.type == "COPY_ROTATION":
        changed = (
            _surface_contact_configure_rotation_constraint(secondary, solver)
            or changed
        )
        guide[SURFACE_CONTACT_ROTATION_BINDING_PROPERTY] = 1
        return changed
    if secondary is not None:
        if not _surface_contact_remove_constraint(owner, secondary):
            return changed
        changed = True

    digest = guide.name.rsplit("_", 1)[-1]
    secondary = _surface_contact_create_rotation_constraint(
        owner,
        solver,
        f"{SURFACE_CONTACT_CONSTRAINT_PREFIX}{digest}_Aim",
    )
    if secondary is None:
        return changed
    guide[SURFACE_CONTACT_SECONDARY_PROPERTY] = secondary.name
    guide[SURFACE_CONTACT_ROTATION_BINDING_PROPERTY] = 1
    return True


def _surface_contact_insert_marker(owner, bone_name, frame, value):
    if owner is None:
        return False
    property_path = f'["{SURFACE_CONTACT_MARKER_PROPERTY}"]'
    owner[SURFACE_CONTACT_MARKER_PROPERTY] = float(value)
    owner.keyframe_insert(data_path = property_path, frame = int(frame))
    action = _dynamic_parent_owner_action(owner)
    animated_id = getattr(owner, "id_data", None) or owner
    if action is not None:
        data_path = owner.path_from_id(property_path)
        for fcurve in _fcurves_find_all(action, data_path, animated_id):
            for key in fcurve.keyframe_points:
                if abs(float(key.co.x) - float(frame)) > 1.0e-5:
                    continue
                key.handle_left_type = "AUTO"
                key.handle_right_type = "AUTO"
                key.interpolation = "CONSTANT"
            _set_fcurve_group(
                fcurve,
                action,
                f"Surface Contact ({bone_name})",
            )
            fcurve.update()
    return True


def _surface_contact_target_frames(guide):
    values = guide.get(SURFACE_CONTACT_TARGET_FRAMES_PROPERTY, ())
    frames = []
    for value in values:
        try:
            frames.append(int(value))
        except (TypeError, ValueError):
            continue
    return tuple(sorted(set(frames)))


def _surface_contact_set_target_frames(guide, frames):
    guide[SURFACE_CONTACT_TARGET_FRAMES_PROPERTY] = sorted(
        {int(frame) for frame in frames}
    )


def _surface_contact_strip_scale_animation(guide):
    action = _dynamic_parent_owner_action(guide)
    if action is None:
        return False
    changed = False
    animated_id = getattr(guide, "id_data", None) or guide
    for fcurve in tuple(_fcurves_find_all(action, "scale", animated_id)):
        changed = _action_remove_fcurve(action, fcurve) or changed
    return changed


def _surface_contact_keyframe_guide_transform(guide, frame, bone_name):
    frame = int(frame)
    _surface_contact_strip_scale_animation(guide)
    rotation_path = (
        "rotation_quaternion"
        if guide.rotation_mode == "QUATERNION"
        else "rotation_axis_angle"
        if guide.rotation_mode == "AXIS_ANGLE"
        else "rotation_euler"
    )
    guide.keyframe_insert(data_path = "location", frame = frame)
    guide.keyframe_insert(data_path = rotation_path, frame = frame)

    action = _dynamic_parent_owner_action(guide)
    if action is None:
        return False
    animated_id = getattr(guide, "id_data", None) or guide
    for data_path in ("location", rotation_path):
        for fcurve in _fcurves_find_all(action, data_path, animated_id):
            _set_fcurve_group(
                fcurve,
                action,
                f"Surface Contact Target ({bone_name})",
            )
            for key in fcurve.keyframe_points:
                if abs(float(key.co.x) - float(frame)) > 1.0e-5:
                    continue
                if key.interpolation == "BEZIER":
                    key.handle_left_type = "AUTO"
                    key.handle_right_type = "AUTO"
            fcurve.update()
    return True


def _surface_contact_delete_guide_transform_keys(guide, frame):
    action = _dynamic_parent_owner_action(guide)
    if action is None:
        return False
    changed = False
    animated_id = getattr(guide, "id_data", None) or guide
    paths = ("location", "rotation_euler", "rotation_quaternion", "rotation_axis_angle")
    for data_path in paths:
        for fcurve in tuple(_fcurves_find_all(action, data_path, animated_id)):
            for key in tuple(fcurve.keyframe_points):
                if abs(float(key.co.x) - float(frame)) <= 1.0e-5:
                    fcurve.keyframe_points.remove(key)
                    changed = True
            if not fcurve.keyframe_points:
                _action_remove_fcurve(action, fcurve)
            else:
                fcurve.update()
    return changed


def _surface_contact_marker_points(owner):
    action = _dynamic_parent_owner_action(owner)
    if action is None:
        return {}
    try:
        data_path = (
            owner.path_from_id()
            + f'["{SURFACE_CONTACT_MARKER_PROPERTY}"]'
        )
    except (AttributeError, TypeError, ValueError):
        return {}
    points = {}
    animated_id = getattr(owner, "id_data", None) or owner
    for fcurve in _fcurves_find_all(action, data_path, animated_id):
        for key in fcurve.keyframe_points:
            points[int(round(float(key.co.x)))] = float(key.co.y)
    return points


def _surface_contact_guide_matches_owner(guide, owner):
    animated_id = getattr(owner, "id_data", None) or owner
    return bool(
        str(guide.get(SURFACE_CONTACT_CONTROL_OBJECT_PROPERTY, ""))
        == str(getattr(animated_id, "name", ""))
        and str(guide.get(SURFACE_CONTACT_CONTROL_BONE_PROPERTY, ""))
        == str(getattr(owner, "name", ""))
    )


def _surface_contact_expected_markers(owner, excluded_guide = None):
    expected = {}
    matching_guides = tuple(
        guide
        for guide in _surface_contact_guides()
        if guide != excluded_guide
        and _surface_contact_guide_matches_owner(guide, owner)
    )
    for guide in matching_guides:
        if SURFACE_CONTACT_END_PROPERTY in guide:
            expected[int(guide[SURFACE_CONTACT_END_PROPERTY])] = 0.0
    # A retarget boundary is both an old release and a new contact. One start
    # marker wins so the Dope Sheet contains a single key at that frame.
    for guide in matching_guides:
        expected[int(guide.get(SURFACE_CONTACT_START_PROPERTY, 0))] = 1.0
        for frame in _surface_contact_target_frames(guide):
            expected[int(frame)] = 1.0
    return expected


def _surface_contact_rebuild_markers(owner, bone_name, excluded_guide = None):
    if owner is None:
        return False
    action = _dynamic_parent_owner_action(owner)
    property_path = f'["{SURFACE_CONTACT_MARKER_PROPERTY}"]'
    try:
        data_path = owner.path_from_id() + property_path
    except (AttributeError, TypeError, ValueError):
        return False
    animated_id = getattr(owner, "id_data", None) or owner
    expected = _surface_contact_expected_markers(owner, excluded_guide)
    if not expected:
        changed = False
        if action is not None:
            for fcurve in tuple(
                _fcurves_find_all(action, data_path, animated_id)
            ):
                changed = _action_remove_fcurve(action, fcurve) or changed
        if SURFACE_CONTACT_MARKER_PROPERTY in owner:
            del owner[SURFACE_CONTACT_MARKER_PROPERTY]
            changed = True
        return changed

    if action is None:
        first_frame, first_value = min(expected.items())
        owner[SURFACE_CONTACT_MARKER_PROPERTY] = float(first_value)
        owner.keyframe_insert(
            data_path = property_path,
            frame = int(first_frame),
        )
        action = _dynamic_parent_owner_action(owner)
    if action is None:
        return False

    fcurves = list(_fcurves_find_all(action, data_path, animated_id))
    if fcurves:
        fcurve = fcurves[0]
        for duplicate in fcurves[1:]:
            _action_remove_fcurve(action, duplicate)
    else:
        fcurve = _action_new_fcurve(action, data_path, animated_id)
    while fcurve.keyframe_points:
        fcurve.keyframe_points.remove(fcurve.keyframe_points[-1])
    for frame, value in sorted(expected.items()):
        fcurve.keyframe_points.insert(
            float(frame),
            float(value),
            options = {"FAST"},
        )
    _normalize_dynamic_marker_fcurve(fcurve)
    _set_fcurve_group(
        fcurve,
        action,
        f"Surface Contact ({bone_name})",
    )
    fcurve.update()

    current_frame = int(getattr(bpy.context.scene, "frame_current", 0))
    owner[SURFACE_CONTACT_MARKER_PROPERTY] = 1.0 if any(
        _surface_contact_guide_matches_owner(guide, owner)
        and guide != excluded_guide
        and _surface_contact_guide_active_at(guide, current_frame)
        for guide in _surface_contact_guides()
    ) else 0.0
    return True


def _surface_contact_remove_markers(guide, owner):
    if owner is None:
        return False
    return _surface_contact_rebuild_markers(
        owner,
        str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, getattr(owner, "name", ""))),
        excluded_guide = guide,
    )


def _surface_contact_update_guide_transform(guide):
    if getattr(guide, "parent", None) is not None:
        return False
    follow_object = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_FOLLOW_OBJECT_PROPERTY, ""))
    )
    if follow_object is None:
        follow_object = bpy.data.objects.get(
            str(guide.get(SURFACE_CONTACT_SURFACE_PROPERTY, ""))
        )
    follow_bone = str(guide.get(SURFACE_CONTACT_FOLLOW_BONE_PROPERTY, ""))
    values = guide.get(SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY)
    if follow_object is None:
        return False
    world_matrix = guide.matrix_world.copy()
    try:
        if values is not None and len(values) >= 16:
            local_matrix = Matrix(
                tuple(
                    tuple(
                        float(values[(row * 4) + column])
                        for column in range(4)
                    )
                    for row in range(4)
                )
            )
            if follow_bone and getattr(follow_object, "pose", None) is not None:
                follow_pose_bone = follow_object.pose.bones.get(follow_bone)
                if follow_pose_bone is not None:
                    follow_world = follow_object.matrix_world @ follow_pose_bone.matrix
                else:
                    follow_world = follow_object.matrix_world
            else:
                follow_world = follow_object.matrix_world
            world_matrix = follow_world @ local_matrix
        return _surface_contact_parent_guide(
            guide,
            follow_object,
            follow_bone,
            world_matrix,
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return False


def _surface_contact_order_constraints(owner, secondary, primary):
    if owner is None:
        return False
    changed = False
    for constraint in (secondary, primary):
        if constraint is None:
            continue
        try:
            current_index = owner.constraints.find(constraint.name)
            desired_index = len(owner.constraints) - 1
            if current_index >= 0 and current_index != desired_index:
                owner.constraints.move(current_index, desired_index)
                changed = True
        except (AttributeError, ReferenceError, RuntimeError, ValueError):
            pass
    return changed


def _sync_surface_contact_constraints(
    scene,
    depsgraph = None,
    respect_selected = False,
    force_unselected = True,
    force_guide_names = (),
    solve_simulated = True,
):
    if _state.get("surface_contact_syncing", False):
        return False
    _state["surface_contact_syncing"] = True
    try:
        frame = int(getattr(scene, "frame_current", 0))
        forced_names = {str(name) for name in force_guide_names}
        changed = _sync_dynamic_parent_constraints(frame)
        guides = tuple(_surface_contact_guides())
        changed = _surface_contact_sync_stretch_policy(guides, frame) or changed
        for guide in guides:
            changed = _surface_contact_update_guide_transform(guide) or changed
            changed = (
                _surface_contact_migrate_legacy_ik_guide(bpy.context, guide)
                or changed
            )
            changed = (
                _surface_contact_ensure_control_rotation_constraint(
                    bpy.context,
                    guide,
                )
                or changed
            )
            active = _surface_contact_guide_active_at(guide, frame)
            primary, secondary = _surface_contact_constraints(guide)
            desired_influences = (
                (primary, 1.0 if active else 0.0),
                (
                    secondary,
                    _surface_contact_guide_aim_influence(guide)
                    if active
                    else 0.0,
                ),
            )
            for constraint, desired in desired_influences:
                if (
                    constraint is not None
                    and abs(float(constraint.influence) - desired) > 1.0e-6
                ):
                    constraint.influence = desired
                    changed = True
            if active:
                if (
                    primary is not None
                    and primary.type == "IK"
                    and hasattr(primary, "use_stretch")
                    and bool(primary.use_stretch)
                ):
                    primary.use_stretch = False
                    changed = True
                contact_kind = str(
                    guide.get(SURFACE_CONTACT_KIND_PROPERTY, "")
                )
                directly_selected = bool(
                    respect_selected
                    and _surface_contact_guide_directly_selected(
                        bpy.context,
                        guide,
                    )
                )
                detached = bool(
                    contact_kind == SURFACE_CONTACT_KIND_SIMULATED
                    and _surface_contact_snap_departure_active(
                        bpy.context,
                        guide,
                    )
                )
                force_contact = bool(
                    guide.name in forced_names
                    or (
                        force_unselected
                        and not directly_selected
                        and not detached
                    )
                )
                if force_contact:
                    _surface_contact_clear_snap_departure(guide)
                if solve_simulated or contact_kind != SURFACE_CONTACT_KIND_SIMULATED:
                    changed = _surface_contact_enforce_guide(
                        bpy.context,
                        guide,
                        force_contact = force_contact,
                        use_snap_hysteresis = directly_selected,
                        allow_snap = not detached,
                    ) or changed
                _target_object, owner = _surface_contact_constraint_owner_from_guide(
                    guide
                )
                changed = (
                    _surface_contact_order_constraints(owner, secondary, primary)
                    or changed
                )
        if changed:
            _tag_redraw_all_view3d()
        return changed
    finally:
        _state["surface_contact_syncing"] = False


def _surface_contact_active_simulated_guides(scene):
    frame = int(getattr(scene, "frame_current", 0))
    return tuple(
        guide
        for guide in _surface_contact_guides()
        if (
            str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
            == SURFACE_CONTACT_KIND_SIMULATED
            and _surface_contact_guide_active_at(guide, frame)
        )
    )


def _surface_contact_guide_directly_selected(context, guide):
    if context is None or getattr(context, "mode", "") != "POSE":
        return False
    armature = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
    )
    if _pin_selected_target_key() == (
        f"CONTACT:{_armature_session_uid(armature)}:"
        f"{getattr(guide, 'name', '')}"
    ):
        return True
    if (
        armature is None
        or armature.name
        != str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
    ):
        return False
    selected_names = {
        pose_bone.name
        for pose_bone in _selected_pose_bones_by_owner(context).get(
            armature,
            (),
        )
    }
    return bool(
        selected_names
        and _surface_contact_related_bone_names(guide) & selected_names
    )


def _surface_contact_depsgraph_update_is_relevant(guides, depsgraph):
    if not guides or depsgraph is None:
        return False
    referenced_pointers = set()
    action_pointers = set()
    object_properties = (
        SURFACE_CONTACT_ARMATURE_PROPERTY,
        SURFACE_CONTACT_SURFACE_PROPERTY,
        SURFACE_CONTACT_FOLLOW_OBJECT_PROPERTY,
        SURFACE_CONTACT_SMART_OBJECT_PROPERTY,
        SURFACE_CONTACT_CONTROL_OBJECT_PROPERTY,
        SURFACE_CONTACT_CONSTRAINT_OBJECT_PROPERTY,
        SURFACE_CONTACT_SOLVER_OBJECT_PROPERTY,
    )

    def add_id(value):
        if value is None:
            return
        value = getattr(value, "original", value)
        try:
            referenced_pointers.add(int(value.as_pointer()))
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            return

    def add_owner(value):
        if value is None:
            return
        add_id(value)
        data = getattr(value, "data", None)
        add_id(data)
        for action_owner in (value, data):
            if action_owner is None:
                continue
            action = _dynamic_parent_owner_action(action_owner)
            if action is None:
                continue
            action = getattr(action, "original", action)
            try:
                action_pointers.add(int(action.as_pointer()))
            except (AttributeError, ReferenceError, RuntimeError, TypeError):
                pass

    for guide in guides:
        add_owner(guide)
        for property_name in object_properties:
            object_name = str(guide.get(property_name, ""))
            if object_name:
                add_owner(bpy.data.objects.get(object_name))

    try:
        updates = tuple(depsgraph.updates)
    except (AttributeError, ReferenceError, RuntimeError):
        return True
    for update in updates:
        updated_id = getattr(update, "id", None)
        updated_id = getattr(updated_id, "original", updated_id)
        try:
            pointer = int(updated_id.as_pointer())
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            continue
        if isinstance(updated_id, bpy.types.Action):
            if pointer in action_pointers:
                return True
        elif pointer in referenced_pointers:
            return True
    return False


def _surface_contact_enforce_active_simulated(
    context,
    scene,
    guides = None,
    respect_selected = False,
):
    if (
        context is None
        or scene is None
        or _state.get("surface_contact_solver_syncing", False)
        or _state.get("surface_contact_syncing", False)
    ):
        return False
    guides = tuple(
        guides
        if guides is not None
        else _surface_contact_active_simulated_guides(scene)
    )
    if not guides:
        return False

    _state["surface_contact_solver_syncing"] = True
    changed = False
    try:
        for guide in guides:
            changed = _surface_contact_update_guide_transform(guide) or changed
            directly_selected = bool(
                respect_selected
                and _surface_contact_guide_directly_selected(context, guide)
            )
            detached = bool(
                _surface_contact_snap_departure_active(context, guide)
            )
            changed = _surface_contact_enforce_guide(
                context,
                guide,
                force_contact = not directly_selected and not detached,
                use_snap_hysteresis = directly_selected,
                allow_snap = not detached,
            ) or changed
        if changed:
            _tag_redraw_all_view3d()
        return changed
    finally:
        _state["surface_contact_solver_syncing"] = False


@persistent
def _surface_contact_frame_change_post(scene, _depsgraph = None):
    _sync_surface_contact_constraints(scene, _depsgraph)


@persistent
def _surface_contact_depsgraph_update_post(scene, depsgraph):
    context = bpy.context
    if (
        context is None
        or getattr(context, "scene", None) != scene
        or getattr(context, "mode", "") != "POSE"
        or _state.get("pin_target_dragging", False)
        or _state.get("pin_snap_syncing", False)
        or _state.get("pin_history_syncing", False)
        or _state.get("surface_contact_solver_syncing", False)
        or _state.get("surface_contact_reconciling", False)
        or _state.get("dynamic_space_reconciling", False)
    ):
        return None
    transform_operator = _pin_active_transform_operator(context)
    if transform_operator or _state.get("pin_snap_transform_active", False):
        if transform_operator:
            _pin_track_transform(transform_operator)
        _state["pin_snap_last_depsgraph_sync"] = time.perf_counter()
        _state["surface_contact_solver_syncing"] = True
        try:
            _snap_selected_pin_endpoints(
                context,
                insert_keys = False,
                use_snap_hysteresis = True,
            )
        finally:
            _state["surface_contact_solver_syncing"] = False
        return None

    guides = _surface_contact_active_simulated_guides(scene)
    if _surface_contact_depsgraph_update_is_relevant(guides, depsgraph):
        _surface_contact_enforce_active_simulated(
            context,
            scene,
            guides,
            respect_selected = True,
        )
    return None


def _surface_contact_remove_constraint(owner, constraint):
    if owner is None or constraint is None:
        return False
    action = _dynamic_parent_owner_action(owner)
    try:
        data_path = constraint.path_from_id("influence")
    except (AttributeError, TypeError, ValueError):
        data_path = ""
    if action is not None and data_path:
        for fcurve in tuple(
            _fcurves_find_all(
                action,
                data_path,
                getattr(owner, "id_data", None) or owner,
            )
        ):
            _action_remove_fcurve(action, fcurve)
    try:
        owner.constraints.remove(constraint)
    except (AttributeError, ReferenceError, RuntimeError):
        return False
    return True


def _surface_contact_create_solver(context, guide, world_matrix):
    digest = guide.name.rsplit("_", 1)[-1]
    solver = bpy.data.objects.new(f"_SurfaceContactSolver_{digest}", None)
    _ensure_space_helper_collection(context).objects.link(solver)
    solver[SURFACE_CONTACT_SOLVER_PROPERTY] = True
    solver.empty_display_type = "PLAIN_AXES"
    solver.empty_display_size = 0.01
    solver.hide_render = True
    solver.hide_select = True
    solver.parent = guide
    solver.matrix_world = world_matrix
    try:
        solver.hide_set(True)
    except RuntimeError:
        pass
    guide[SURFACE_CONTACT_SOLVER_OBJECT_PROPERTY] = solver.name
    context.view_layer.update()
    return solver


def _surface_contact_stretch_state(guide):
    encoded = guide.get(SURFACE_CONTACT_STRETCH_STATE_PROPERTY)
    if not encoded:
        return {}
    try:
        state = json.loads(str(encoded))
    except (TypeError, ValueError):
        return {}
    return state if isinstance(state, dict) else {}


def _surface_contact_disable_stretch(
    guide,
    armature,
    bones,
    existing_constraint = None,
    existing_constraint_bone = "",
):
    if guide is None or armature is None:
        return False
    other_states = tuple(
        _surface_contact_stretch_state(other)
        for other in _surface_contact_guides()
        if other != guide
    )
    bone_state = {}
    for pose_bone in bones:
        if pose_bone is None:
            continue
        baseline = float(getattr(pose_bone, "ik_stretch", 0.0))
        for state in other_states:
            if str(state.get("armature", "")) != armature.name:
                continue
            stored = state.get("bones", {}).get(pose_bone.name)
            if stored is not None:
                baseline = float(stored)
                break
        bone_state[pose_bone.name] = baseline
        try:
            pose_bone.ik_stretch = 0.0
        except (AttributeError, RuntimeError, TypeError, ValueError):
            pass

    state = {
        "armature": armature.name,
        "bones": bone_state,
    }
    if existing_constraint is not None and hasattr(
        existing_constraint,
        "use_stretch",
    ):
        baseline = bool(existing_constraint.use_stretch)
        for other_state in other_states:
            stored = other_state.get("constraint", {})
            if (
                str(other_state.get("armature", "")) == armature.name
                and str(stored.get("bone", "")) == existing_constraint_bone
                and str(stored.get("name", "")) == existing_constraint.name
            ):
                baseline = bool(stored.get("use_stretch", baseline))
                break
        state["constraint"] = {
            "bone": str(existing_constraint_bone),
            "name": existing_constraint.name,
            "use_stretch": baseline,
        }
        existing_constraint.use_stretch = False

    guide[SURFACE_CONTACT_STRETCH_STATE_PROPERTY] = json.dumps(
        state,
        separators = (",", ":"),
        sort_keys = True,
    )
    return True


def _surface_contact_restore_stretch(guide):
    state = _surface_contact_stretch_state(guide)
    armature = bpy.data.objects.get(str(state.get("armature", "")))
    if armature is None or getattr(armature, "pose", None) is None:
        return False
    other_states = tuple(
        _surface_contact_stretch_state(other)
        for other in _surface_contact_guides()
        if other != guide
    )
    changed = False
    for bone_name, baseline in state.get("bones", {}).items():
        still_needed = any(
            str(other.get("armature", "")) == armature.name
            and bone_name in other.get("bones", {})
            for other in other_states
        )
        if still_needed:
            continue
        pose_bone = armature.pose.bones.get(str(bone_name))
        if pose_bone is None:
            continue
        try:
            pose_bone.ik_stretch = float(baseline)
            changed = True
        except (AttributeError, RuntimeError, TypeError, ValueError):
            pass

    stored_constraint = state.get("constraint", {})
    constraint_bone = str(stored_constraint.get("bone", ""))
    constraint_name = str(stored_constraint.get("name", ""))
    if constraint_bone and constraint_name:
        still_needed = any(
            str(other.get("armature", "")) == armature.name
            and str(other.get("constraint", {}).get("bone", ""))
            == constraint_bone
            and str(other.get("constraint", {}).get("name", ""))
            == constraint_name
            for other in other_states
        )
        owner = armature.pose.bones.get(constraint_bone)
        constraint = (
            owner.constraints.get(constraint_name)
            if owner is not None
            else None
        )
        if not still_needed and constraint is not None and hasattr(
            constraint,
            "use_stretch",
        ):
            constraint.use_stretch = bool(
                stored_constraint.get("use_stretch", False)
            )
            changed = True
    return changed


def _surface_contact_enforce_no_stretch(guide):
    state = _surface_contact_stretch_state(guide)
    armature = bpy.data.objects.get(str(state.get("armature", "")))
    if armature is None or getattr(armature, "pose", None) is None:
        return False
    changed = False
    for bone_name in state.get("bones", {}):
        pose_bone = armature.pose.bones.get(str(bone_name))
        if pose_bone is None:
            continue
        if abs(float(getattr(pose_bone, "ik_stretch", 0.0))) > 1.0e-8:
            pose_bone.ik_stretch = 0.0
            changed = True
    stored_constraint = state.get("constraint", {})
    owner = armature.pose.bones.get(str(stored_constraint.get("bone", "")))
    constraint = (
        owner.constraints.get(str(stored_constraint.get("name", "")))
        if owner is not None
        else None
    )
    if (
        constraint is not None
        and hasattr(constraint, "use_stretch")
        and bool(constraint.use_stretch)
    ):
        constraint.use_stretch = False
        changed = True
    return changed


def _surface_contact_sync_stretch_policy(guides, frame):
    bone_policy = {}
    constraint_policy = {}
    for guide in guides:
        state = _surface_contact_stretch_state(guide)
        armature_name = str(state.get("armature", ""))
        if not armature_name:
            continue
        active = _surface_contact_guide_active_at(guide, int(frame))
        for bone_name, baseline in state.get("bones", {}).items():
            key = (armature_name, str(bone_name))
            policy = bone_policy.setdefault(
                key,
                {"baseline": float(baseline), "active": False},
            )
            policy["active"] = bool(policy["active"] or active)
        stored = state.get("constraint", {})
        if stored:
            key = (
                armature_name,
                str(stored.get("bone", "")),
                str(stored.get("name", "")),
            )
            policy = constraint_policy.setdefault(
                key,
                {
                    "baseline": bool(stored.get("use_stretch", False)),
                    "active": False,
                },
            )
            policy["active"] = bool(policy["active"] or active)

    changed = False
    for (armature_name, bone_name), policy in bone_policy.items():
        armature = bpy.data.objects.get(armature_name)
        pose_bone = (
            armature.pose.bones.get(bone_name)
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is None:
            continue
        desired = 0.0 if policy["active"] else float(policy["baseline"])
        if abs(float(getattr(pose_bone, "ik_stretch", 0.0)) - desired) > 1.0e-8:
            pose_bone.ik_stretch = desired
            changed = True
    for (armature_name, bone_name, constraint_name), policy in constraint_policy.items():
        armature = bpy.data.objects.get(armature_name)
        owner = (
            armature.pose.bones.get(bone_name)
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        constraint = (
            owner.constraints.get(constraint_name)
            if owner is not None
            else None
        )
        if constraint is None or not hasattr(constraint, "use_stretch"):
            continue
        desired = False if policy["active"] else bool(policy["baseline"])
        if bool(constraint.use_stretch) != desired:
            constraint.use_stretch = desired
            changed = True
    return changed


def _surface_contact_add_dot_constraint(
    context,
    guide,
    armature,
    effector,
    relation,
):
    digest = guide.name.rsplit("_", 1)[-1]
    control_object, control_bone_name, uses_existing_ik = (
        _surface_contact_control_target(relation, armature, effector)
    )
    control_world = _surface_contact_target_world_matrix(
        context,
        control_object,
        control_bone_name,
    )
    if control_world is None:
        return None, None

    # Preserve the existing control orientation when Contact is enabled. The
    # guide-relative solver matrix will carry later surface-normal changes.
    solver_world = control_world.normalized()
    solver_world.translation = guide.matrix_world.translation.copy()
    solver = _surface_contact_create_solver(context, guide, solver_world)

    rotation_constraint = None
    if uses_existing_ik:
        owner = (
            control_object.pose.bones.get(control_bone_name)
            if control_bone_name and getattr(control_object, "pose", None)
            else control_object
        )
        if owner is None:
            bpy.data.objects.remove(solver, do_unlink = True)
            return None, None
        constraint = owner.constraints.new("COPY_LOCATION")
        constraint.name = f"{SURFACE_CONTACT_CONSTRAINT_PREFIX}{digest}_Target"
        constraint.target = solver
        constraint.owner_space = "WORLD"
        constraint.target_space = "WORLD"
        if hasattr(constraint, "use_offset"):
            constraint.use_offset = False
        rotation_constraint = _surface_contact_create_rotation_constraint(
            owner,
            solver,
            f"{SURFACE_CONTACT_CONSTRAINT_PREFIX}{digest}_Aim",
        )
        guide[SURFACE_CONTACT_KIND_PROPERTY] = SURFACE_CONTACT_KIND_CONTROL
        guide[SURFACE_CONTACT_CHAIN_PROPERTY] = int(
            getattr(relation.get("constraint"), "chain_count", 1)
        )
    else:
        owner = effector
        constraint = None
        control_object = armature
        control_bone_name = effector.name
        guide[SURFACE_CONTACT_KIND_PROPERTY] = SURFACE_CONTACT_KIND_SIMULATED
        guide[SURFACE_CONTACT_CHAIN_PROPERTY] = 1

    existing_ik = relation.get("constraint") if uses_existing_ik else None
    existing_ik_bone = (
        relation.get("effector").name
        if uses_existing_ik and relation.get("effector") is not None
        else ""
    )
    stretch_bones = (
        relation.get("chain", ())
        if uses_existing_ik
        else (effector,)
    )
    _surface_contact_disable_stretch(
        guide,
        armature,
        stretch_bones,
        existing_ik,
        existing_ik_bone,
    )

    if constraint is not None:
        constraint.influence = 0.0
    if rotation_constraint is not None:
        rotation_constraint.influence = 0.0
    guide[SURFACE_CONTACT_PRIMARY_PROPERTY] = (
        constraint.name if constraint is not None else ""
    )
    guide[SURFACE_CONTACT_SECONDARY_PROPERTY] = (
        rotation_constraint.name if rotation_constraint is not None else ""
    )
    guide[SURFACE_CONTACT_ROTATION_BINDING_PROPERTY] = (
        1 if rotation_constraint is not None else 0
    )
    guide[SURFACE_CONTACT_CONSTRAINT_OBJECT_PROPERTY] = control_object.name
    guide[SURFACE_CONTACT_CONSTRAINT_BONE_PROPERTY] = control_bone_name
    guide[SURFACE_CONTACT_RELEASE_OBJECT_PROPERTY] = control_object.name
    guide[SURFACE_CONTACT_RELEASE_BONE_PROPERTY] = control_bone_name
    return constraint, solver


def _surface_contact_migrate_legacy_ik_guide(context, guide):
    if (
        str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
        != SURFACE_CONTACT_KIND_IK
    ):
        return False
    _constraint_object, owner = _surface_contact_constraint_owner_from_guide(
        guide
    )
    primary, _secondary = _surface_contact_constraints(guide)
    if (
        owner is None
        or primary is None
        or primary.type != "IK"
        or not primary.name.startswith(SURFACE_CONTACT_CONSTRAINT_PREFIX)
    ):
        return False

    armature = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
    )
    bone_name = str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
    preserved_world = (
        _surface_contact_target_world_matrix(context, armature, bone_name)
        if armature is not None
        else None
    )
    _surface_contact_remove_constraint(owner, primary)
    guide[SURFACE_CONTACT_PRIMARY_PROPERTY] = ""
    guide[SURFACE_CONTACT_KIND_PROPERTY] = SURFACE_CONTACT_KIND_SIMULATED
    guide[SURFACE_CONTACT_CHAIN_PROPERTY] = 1
    context.view_layer.update()
    if preserved_world is not None and armature is not None:
        _surface_contact_set_target_world_matrix(
            context,
            armature,
            bone_name,
            preserved_world,
        )
    return True


def _surface_contact_solver_reach(context, guide):
    armature = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
    )
    if armature is None or getattr(armature, "pose", None) is None:
        return None
    try:
        depsgraph = context.evaluated_depsgraph_get()
        evaluated_armature = armature.evaluated_get(depsgraph)
        effector = evaluated_armature.pose.bones.get(
            str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
        )
        if effector is None:
            return None
        chain_count = int(guide.get(SURFACE_CONTACT_CHAIN_PROPERTY, 1))
        chain = _surface_contact_chain(effector, chain_count)
        if not chain:
            return None
        root = chain[-1]
        pivot = evaluated_armature.matrix_world @ root.head
        reach = sum(
            (
                (evaluated_armature.matrix_world @ bone.tail)
                - (evaluated_armature.matrix_world @ bone.head)
            ).length
            for bone in chain
        )
        fallback = (
            (evaluated_armature.matrix_world @ effector.tail) - pivot
        )
        if reach <= 1.0e-8:
            return None
        exact_radius = bool(
            str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
            == SURFACE_CONTACT_KIND_IK
            and len(chain) == 1
        )
        return pivot, reach, fallback, exact_radius
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return None


def _surface_contact_clamp_solver_matrix(context, guide, world_matrix):
    reach_data = _surface_contact_solver_reach(context, guide)
    if reach_data is None:
        return world_matrix.copy()
    pivot, reach, fallback, exact_radius = reach_data
    result = world_matrix.copy()
    direction = result.translation - pivot
    distance = direction.length
    if distance <= 1.0e-8:
        direction = fallback.copy()
        if direction.length_squared <= 1.0e-12:
            direction = Vector((0.0, 0.0, -1.0))
        direction.normalize()
        distance = 0.0
    else:
        direction.normalize()
    if exact_radius:
        distance = reach
    else:
        distance = min(distance, reach)
    result.translation = pivot + (direction * distance)
    return result


def _surface_contact_rotate_simulated_pose_toward(
    context,
    guide,
    armature,
    pose_bone,
    anchor,
    target,
):
    if _surface_contact_guide_aim_influence(guide) <= 1.0e-8:
        return False
    try:
        depsgraph = context.evaluated_depsgraph_get()
        evaluated_armature = armature.evaluated_get(depsgraph)
        evaluated_bone = evaluated_armature.pose.bones.get(pose_bone.name)
        if evaluated_bone is None:
            return False
        pivot = evaluated_armature.matrix_world @ evaluated_bone.head
        current_vector = Vector(anchor) - pivot
        target_vector = Vector(target) - pivot
        if (
            current_vector.length_squared <= 1.0e-12
            or target_vector.length_squared <= 1.0e-12
        ):
            return False
        rotation = current_vector.rotation_difference(target_vector)
        if abs(float(rotation.angle)) <= 1.0e-7:
            return False
        bone_world = armature.matrix_world @ pose_bone.matrix
        rotated_world = (
            Matrix.Translation(pivot)
            @ rotation.to_matrix().to_4x4()
            @ Matrix.Translation(-pivot)
            @ bone_world
        )
        pose_bone.matrix = armature.matrix_world.inverted_safe() @ rotated_world
        context.view_layer.update()
        return True
    except (
        AttributeError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ):
        return False


def _surface_contact_update_simulated_solver(
    context,
    guide,
    desired_point = None,
    insert_keys = False,
    max_iterations = 4,
):
    if (
        str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
        != SURFACE_CONTACT_KIND_SIMULATED
    ):
        return False
    armature = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
    )
    pose_bone = (
        armature.pose.bones.get(
            str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
        )
        if armature is not None and getattr(armature, "pose", None)
        else None
    )
    if armature is None or pose_bone is None:
        return False

    target = (
        Vector(desired_point)
        if desired_point is not None
        else guide.matrix_world.translation.copy()
    )
    tolerance = max(
        1.0e-7,
        float(guide.get(SURFACE_CONTACT_SIZE_PROPERTY, 0.05)) * 1.0e-6,
    )
    changed = False
    previous_error = float("inf")
    for _iteration in range(max(1, int(max_iterations))):
        anchor = _surface_contact_stored_anchor_world(context, guide)
        if anchor is None:
            break
        delta = target - anchor
        error = delta.length
        if error <= tolerance:
            break
        if error >= previous_error - (tolerance * 0.05):
            break
        previous_error = error
        if _surface_contact_rotate_simulated_pose_toward(
            context,
            guide,
            armature,
            pose_bone,
            anchor,
            target,
        ):
            changed = True
            anchor = _surface_contact_stored_anchor_world(context, guide)
            if anchor is None:
                break
            delta = target - anchor
            if delta.length <= tolerance:
                break
        armature_delta = (
            armature.matrix_world.inverted_safe().to_3x3() @ delta
        )
        matrix = pose_bone.matrix.copy()
        matrix.translation += armature_delta
        pose_bone.matrix = matrix
        context.view_layer.update()
        changed = True

    if (
        changed
        and insert_keys
        and bool(
            getattr(context.scene.tool_settings, "use_keyframe_insert_auto", False)
        )
    ):
        _insert_bone_keys(
            pose_bone,
            int(context.scene.frame_current),
        )
    return changed


def _surface_contact_refine_control_solver(
    context,
    guide,
    desired_point = None,
    max_iterations = 8,
):
    if (
        str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
        != SURFACE_CONTACT_KIND_CONTROL
    ):
        return False
    solver = _surface_contact_solver_from_guide(guide)
    if solver is None:
        return False

    target = (
        Vector(desired_point)
        if desired_point is not None
        else guide.matrix_world.translation.copy()
    )
    tolerance = max(
        1.0e-7,
        float(guide.get(SURFACE_CONTACT_SIZE_PROPERTY, 0.05)) * 1.0e-6,
    )
    changed = _surface_contact_update_control_solver(guide)
    if changed:
        context.view_layer.update()
    best_matrix = solver.matrix_world.copy()
    best_error = float("inf")
    stalled = 0
    for _iteration in range(max(1, int(max_iterations))):
        anchor = _surface_contact_stored_anchor_world(context, guide)
        if anchor is None:
            break
        delta = target - anchor
        error = delta.length
        if error < best_error:
            improvement = best_error - error
            best_error = error
            best_matrix = solver.matrix_world.copy()
            stalled = 0 if improvement > tolerance * 0.1 else stalled + 1
        else:
            stalled += 1
        if error <= tolerance or stalled >= 3:
            break
        matrix = solver.matrix_world.copy()
        matrix.translation += delta
        solver.matrix_world = matrix
        context.view_layer.update()
        changed = True

    anchor = _surface_contact_stored_anchor_world(context, guide)
    final_error = (target - anchor).length if anchor is not None else float("inf")
    if best_error < final_error:
        solver.matrix_world = best_matrix
        context.view_layer.update()
        changed = True
    if changed:
        _surface_contact_store_solver_local_matrix(guide)
    return changed


def _surface_contact_seed_fallback_solver(
    context,
    guide,
    armature,
    geometry_bone_name,
    support_objects,
):
    if str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, "")) != SURFACE_CONTACT_KIND_IK:
        return False
    solver = _surface_contact_solver_from_guide(guide)
    if solver is None:
        return False

    evaluated_armature, _geometry_bone, current_anchor = (
        _surface_contact_smart_anchor_world(
            context,
            armature,
            geometry_bone_name,
            support_objects,
        )
    )
    effector = evaluated_armature.pose.bones.get(
        str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
    )
    if effector is None or current_anchor is None:
        return False

    pivot = evaluated_armature.matrix_world @ effector.head
    current_tail = evaluated_armature.matrix_world @ effector.tail
    current_vector = current_anchor - pivot
    target_vector = guide.matrix_world.translation - pivot
    tail_vector = current_tail - pivot
    if (
        current_vector.length_squared <= 1.0e-12
        or target_vector.length_squared <= 1.0e-12
        or tail_vector.length_squared <= 1.0e-12
    ):
        return False

    rotation = current_vector.rotation_difference(target_vector)
    solver_world = solver.matrix_world.copy()
    solver_world.translation = pivot + (rotation @ tail_vector)
    solver.matrix_world = _surface_contact_clamp_solver_matrix(
        context,
        guide,
        solver_world,
    )
    context.view_layer.update()
    return True


def _surface_contact_update_fallback_solver(context, guide):
    if (
        str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
        != SURFACE_CONTACT_KIND_IK
    ):
        return False
    solver = _surface_contact_solver_from_guide(guide)
    armature = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
    )
    support = guide.get(SURFACE_CONTACT_SUPPORT_PROPERTY)
    if (
        solver is None
        or armature is None
        or getattr(armature, "pose", None) is None
        or support is None
        or len(support) < 3
    ):
        return False

    try:
        depsgraph = context.evaluated_depsgraph_get()
        evaluated_armature = armature.evaluated_get(depsgraph)
        effector = evaluated_armature.pose.bones.get(
            str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
        )
        geometry_bone = evaluated_armature.pose.bones.get(
            str(
                guide.get(
                    SURFACE_CONTACT_GEOMETRY_BONE_PROPERTY,
                    guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""),
                )
            )
        )
        if effector is None or geometry_bone is None:
            return False

        pivot = evaluated_armature.matrix_world @ effector.head
        tail = evaluated_armature.matrix_world @ effector.tail
        anchor = (
            evaluated_armature.matrix_world
            @ geometry_bone.matrix
            @ Vector(tuple(float(value) for value in support[:3]))
        )
        current_vector = anchor - pivot
        target_vector = guide.matrix_world.translation - pivot
        tail_vector = tail - pivot
        if (
            current_vector.length_squared <= 1.0e-12
            or target_vector.length_squared <= 1.0e-12
            or tail_vector.length_squared <= 1.0e-12
        ):
            return False

        rotation = current_vector.rotation_difference(target_vector)
        desired_tail = pivot + (rotation @ tail_vector)
        if (desired_tail - solver.matrix_world.translation).length <= 1.0e-7:
            return False
        solver_world = solver.matrix_world.copy()
        solver_world.translation = desired_tail
        solver.matrix_world = solver_world
        return True
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return False


def _surface_contact_align_solver(
    context,
    guide,
    armature,
    geometry_bone_name,
    support_objects,
):
    solver = _surface_contact_solver_from_guide(guide)
    primary, _secondary = _surface_contact_constraints(guide)
    contact_kind = str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
    if (
        solver is None
        or (
            primary is None
            and contact_kind != SURFACE_CONTACT_KIND_SIMULATED
        )
    ):
        return None, None

    stored_support = guide.get(SURFACE_CONTACT_SUPPORT_PROPERTY)
    if stored_support is None or len(stored_support) < 3:
        return None, None

    if contact_kind == SURFACE_CONTACT_KIND_SIMULATED:
        target_point = guide.matrix_world.translation.copy()
        _surface_contact_update_simulated_solver(
            context,
            guide,
            desired_point = target_point,
            max_iterations = 8,
        )
        contact_anchor = _surface_contact_stored_anchor_world(context, guide)
        if contact_anchor is None:
            return None, None
        tolerance = max(
            1.0e-6,
            float(guide.get(SURFACE_CONTACT_SIZE_PROPERTY, 0.05)) * 1.0e-5,
        )
        if (target_point - contact_anchor).length > tolerance:
            return None, None
        _surface_contact_store_solver_local_matrix(guide)
        guide[SURFACE_CONTACT_AIM_PROPERTY] = 1.0
        return contact_anchor, Vector(tuple(stored_support[:3]))

    if (
        contact_kind == SURFACE_CONTACT_KIND_IK
    ):
        primary.influence = 0.0
        context.view_layer.update()
        if not _surface_contact_seed_fallback_solver(
            context,
            guide,
            armature,
            geometry_bone_name,
            support_objects,
        ):
            return None, None
        primary.influence = 1.0
        context.view_layer.update()
        contact_anchor = _surface_contact_stored_anchor_world(context, guide)
        if contact_anchor is None:
            return None, None
        _surface_contact_store_solver_local_matrix(guide)
        guide[SURFACE_CONTACT_AIM_PROPERTY] = 1.0
        return contact_anchor, Vector(tuple(stored_support[:3]))

    primary.influence = 1.0
    context.view_layer.update()
    _surface_contact_seed_fallback_solver(
        context,
        guide,
        armature,
        geometry_bone_name,
        support_objects,
    )
    target_point = guide.matrix_world.translation.copy()
    tolerance = max(
        1.0e-5,
        float(guide.get(SURFACE_CONTACT_SIZE_PROPERTY, 0.05)) * 0.00025,
    )
    best_error = float("inf")
    best_solver_world = solver.matrix_world.copy()
    best_anchor = None
    stalled_iterations = 0
    for _iteration in range(16):
        evaluated_armature, evaluated_geometry_bone, contact_anchor = (
            _surface_contact_smart_anchor_world(
                context,
                armature,
                geometry_bone_name,
                support_objects,
            )
        )
        if evaluated_geometry_bone is None or contact_anchor is None:
            return None, None
        delta = target_point - contact_anchor
        if delta.length < best_error:
            improvement = best_error - delta.length
            best_error = delta.length
            best_solver_world = solver.matrix_world.copy()
            best_anchor = contact_anchor.copy()
            stalled_iterations = 0 if improvement > tolerance * 0.1 else stalled_iterations + 1
        else:
            stalled_iterations += 1
        if delta.length <= tolerance:
            break
        solver_world = solver.matrix_world.copy()
        solver_world.translation += delta
        solver_world = _surface_contact_clamp_solver_matrix(
            context,
            guide,
            solver_world,
        )
        if (solver_world.translation - solver.matrix_world.translation).length <= 1.0e-8:
            break
        solver.matrix_world = solver_world
        context.view_layer.update()
        if stalled_iterations >= 4:
            break

    evaluated_armature, evaluated_geometry_bone, contact_anchor = (
        _surface_contact_smart_anchor_world(
            context,
            armature,
            geometry_bone_name,
            support_objects,
        )
    )
    final_error = (
        (target_point - contact_anchor).length
        if evaluated_geometry_bone is not None and contact_anchor is not None
        else float("inf")
    )
    if best_anchor is not None and best_error < final_error:
        solver.matrix_world = best_solver_world
        context.view_layer.update()
        evaluated_armature, evaluated_geometry_bone, contact_anchor = (
            _surface_contact_smart_anchor_world(
                context,
                armature,
                geometry_bone_name,
                support_objects,
            )
        )
        final_error = (
            (target_point - contact_anchor).length
            if evaluated_geometry_bone is not None and contact_anchor is not None
            else float("inf")
        )
    if evaluated_geometry_bone is None or contact_anchor is None:
        return None, None
    local_support = Vector(tuple(float(value) for value in stored_support[:3]))
    _surface_contact_store_solver_local_matrix(guide)
    guide[SURFACE_CONTACT_AIM_PROPERTY] = 1.0
    return contact_anchor, local_support


def _surface_contact_remove_guide(context, guide, preserve_frame = None):
    _surface_contact_clear_snap_departure(guide)
    _marker_object, marker_owner = _surface_contact_owner_from_guide(guide)
    constraint_object, constraint_owner = _surface_contact_constraint_owner_from_guide(
        guide
    )
    primary, secondary = _surface_contact_constraints(guide)
    release_object = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_RELEASE_OBJECT_PROPERTY, ""))
    ) or constraint_object
    release_bone_name = str(
        guide.get(
            SURFACE_CONTACT_RELEASE_BONE_PROPERTY,
            guide.get(SURFACE_CONTACT_CONSTRAINT_BONE_PROPERTY, ""),
        )
    )
    target_world = None
    if preserve_frame is not None and release_object is not None:
        target_world = _surface_contact_target_world_matrix(
            context,
            release_object,
            release_bone_name,
        )

    _surface_contact_remove_markers(guide, marker_owner)
    _surface_contact_remove_constraint(constraint_owner, secondary)
    _surface_contact_remove_constraint(constraint_owner, primary)
    _surface_contact_restore_stretch(guide)
    solver = _surface_contact_solver_from_guide(guide)
    if solver is not None:
        bpy.data.objects.remove(solver, do_unlink = True)
    context.view_layer.update()

    if target_world is not None and release_object is not None:
        _surface_contact_set_target_world_matrix(
            context,
            release_object,
            release_bone_name,
            target_world,
        )

    guide_action = _dynamic_parent_owner_action(guide)
    bpy.data.objects.remove(guide, do_unlink = True)
    if guide_action is not None and guide_action.users == 0:
        bpy.data.actions.remove(guide_action)
    _surface_contact_sync_stretch_policy(
        tuple(_surface_contact_guides()),
        int(getattr(context.scene, "frame_current", 0)),
    )
    _yellow_refresh_runtime(context)
    return True


def _reconcile_surface_contact_markers(context, armature = None):
    if _state.get("surface_contact_reconciling", False):
        return False
    _state["surface_contact_reconciling"] = True
    try:
        changed = False
        guides = tuple(_surface_contact_guides())
        for guide in guides:
            if (
                armature is not None
                and str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
                != armature.name
            ):
                continue
            _target_object, owner = _surface_contact_owner_from_guide(guide)
            if owner is None:
                _surface_contact_remove_guide(
                    context,
                    guide,
                    preserve_frame = int(context.scene.frame_current),
                )
                changed = True
                continue
            changed = _surface_contact_strip_scale_animation(guide) or changed
            marker_points = _surface_contact_marker_points(owner)
            start = int(guide.get(SURFACE_CONTACT_START_PROPERTY, 0))
            start_value = marker_points.get(start)
            if start_value is None or float(start_value) < 0.5:
                _surface_contact_remove_guide(
                    context,
                    guide,
                    preserve_frame = int(context.scene.frame_current),
                )
                changed = True
                continue
            if SURFACE_CONTACT_END_PROPERTY in guide:
                end = int(guide[SURFACE_CONTACT_END_PROPERTY])
                if end not in marker_points:
                    del guide[SURFACE_CONTACT_END_PROPERTY]
                    changed = True
            target_frames = _surface_contact_target_frames(guide)
            retained_target_frames = tuple(
                frame
                for frame in target_frames
                if frame in marker_points and float(marker_points[frame]) >= 0.5
            )
            if retained_target_frames != target_frames:
                for removed_frame in set(target_frames) - set(retained_target_frames):
                    _surface_contact_delete_guide_transform_keys(
                        guide,
                        removed_frame,
                    )
                _surface_contact_set_target_frames(
                    guide,
                    retained_target_frames,
                )
                changed = True

        armatures = (
            (armature,)
            if armature is not None
            else tuple(
                obj
                for obj in bpy.data.objects
                if obj.type == "ARMATURE" and getattr(obj, "pose", None)
            )
        )
        for current_armature in armatures:
            if current_armature is None or getattr(current_armature, "pose", None) is None:
                continue
            for pose_bone in current_armature.pose.bones:
                if SURFACE_CONTACT_MARKER_PROPERTY not in pose_bone:
                    continue
                if _surface_contact_expected_markers(pose_bone):
                    continue
                changed = _surface_contact_rebuild_markers(
                    pose_bone,
                    pose_bone.name,
                ) or changed

        if changed:
            context.view_layer.update()
            _sync_surface_contact_constraints(
                context.scene,
                respect_selected = True,
                force_unselected = False,
                solve_simulated = False,
            )
            # Flush metadata/constraint dirtiness while reconciliation guards
            # are still active, so no queued next-tick depsgraph event can
            # become a delayed SIMULATED pose correction.
            context.view_layer.update()
            _tag_redraw_all_view3d()
        return changed
    finally:
        _state["surface_contact_reconciling"] = False


def _surface_contact_geometry_bone_candidates(selected_bone, relation):
    ordered = []
    if selected_bone is not None:
        ordered.append(selected_bone)
    if relation is not None:
        ordered.append(relation.get("effector"))
        ordered.extend(relation.get("chain", ()))

    seen = set()
    result = []
    for pose_bone in ordered:
        if pose_bone is None or pose_bone.name in seen:
            continue
        seen.add(pose_bone.name)
        result.append(pose_bone)
    return tuple(result)


def _surface_contact_smart_anchor_world(
    context,
    armature,
    bone_name,
    support_objects,
):
    context.view_layer.update()
    depsgraph = context.evaluated_depsgraph_get()
    evaluated_armature = armature.evaluated_get(depsgraph)
    evaluated_bone = evaluated_armature.pose.bones.get(bone_name)
    if evaluated_bone is None:
        return evaluated_armature, None, None
    anchor, _object_name, _object_local = _yellow_mode3_anchor(
        context,
        depsgraph,
        armature,
        evaluated_armature,
        support_objects,
        bone_name,
    )
    return evaluated_armature, evaluated_bone, anchor


def _surface_contact_control_target(relation, armature, effector):
    if relation is not None:
        target_object = relation.get("target_object")
        target_bone = relation.get("target_bone")
        if target_object is not None and target_bone is not None:
            return target_object, target_bone.name, True
        if (
            target_object is not None
            and getattr(target_object, "type", "") != "ARMATURE"
        ):
            return target_object, "", True
    return armature, effector.name, False


class STATICALIZA_OT_surface_contact_create(bpy.types.Operator):
    bl_idname = "staticaliza.surface_contact_create"
    bl_label = "Contact"
    bl_description = "Place the selected limb's Smart endpoint directly on the nearest detected surface"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE" and _single_active_pose_bone(context) is not None

    def execute(self, context):
        selected_bone = _single_active_pose_bone(context)
        armature = _pose_bone_owner(context, selected_bone)
        if armature is None or selected_bone is None:
            return {"CANCELLED"}
        relation = _surface_contact_ik_relation(armature, selected_bone)
        effector = relation["effector"] if relation is not None else selected_bone
        frame = int(context.scene.frame_current)
        exact_guides, previous_guide, carried_end = (
            _surface_contact_retarget_plan(armature, effector, frame)
        )

        evaluated_armature = None
        evaluated_geometry_bone = None
        part = None
        geometry_points = ()
        support_objects = ()
        for geometry_bone in _surface_contact_geometry_bone_candidates(
            selected_bone,
            relation,
        ):
            (
                evaluated_armature,
                evaluated_geometry_bone,
                part,
                geometry_points,
                support_objects,
            ) = _surface_contact_part_geometry(
                context,
                armature,
                geometry_bone,
            )
            if part is not None and geometry_points:
                break
        if part is None or not geometry_points:
            self.report(
                {"ERROR"},
                "No connected mesh object was found for the selected endpoint.",
            )
            return {"CANCELLED"}
        geometry_bone_name = evaluated_geometry_bone.name
        depsgraph = context.evaluated_depsgraph_get()
        contact_anchor, smart_object_name, smart_object_local = (
            _yellow_mode3_anchor(
                context,
                depsgraph,
                armature,
                evaluated_armature,
                support_objects,
                geometry_bone_name,
            )
        )
        if contact_anchor is None:
            self.report(
                {"ERROR"},
                "Unable to find the connected object's Smart Pin contact point.",
            )
            return {"CANCELLED"}
        surface, surface_point, surface_normal, bone_length = (
            _surface_contact_detect_surface(
                context,
                armature,
                evaluated_armature,
                evaluated_geometry_bone,
                geometry_points,
                support_objects,
                contact_anchor,
                smart_object_name,
            )
        )
        if surface is None or surface_point is None or surface_normal is None:
            self.report(
                {"ERROR"},
                "No nearby mesh surface was found for the connected object.",
            )
            return {"CANCELLED"}

        transition_guides = list(exact_guides)
        if previous_guide is not None and previous_guide not in transition_guides:
            transition_guides.append(previous_guide)
        suspended = _surface_contact_suspend_guides(transition_guides)
        plane_world = _surface_contact_plane_matrix(
            surface_point,
            surface_normal,
            _surface_contact_target_world_matrix(
                context,
                armature,
                effector.name,
            ),
        )

        guide = _surface_contact_create_guide(
            context,
            armature,
            effector,
            armature,
            effector.name,
            geometry_bone_name,
            plane_world,
            surface,
            surface_point,
            surface_normal,
            bone_length,
            frame,
        )
        guide[SURFACE_CONTACT_OBJECT_PROPERTY] = part.name
        if smart_object_name and smart_object_local is not None:
            guide[SURFACE_CONTACT_SMART_OBJECT_PROPERTY] = smart_object_name
            guide[SURFACE_CONTACT_SMART_LOCAL_PROPERTY] = tuple(
                float(value) for value in smart_object_local
            )
        geometry_world = (
            evaluated_armature.matrix_world @ evaluated_geometry_bone.matrix
        )
        guide[SURFACE_CONTACT_SUPPORT_PROPERTY] = tuple(
            geometry_world.inverted_safe() @ contact_anchor
        )
        try:
            primary, _solver = _surface_contact_add_dot_constraint(
                context,
                guide,
                armature,
                effector,
                relation,
            )
        except Exception:
            _surface_contact_remove_guide(context, guide)
            _surface_contact_restore_suspended(suspended)
            raise

        if _solver is None or (
            primary is None
            and str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
            != SURFACE_CONTACT_KIND_SIMULATED
        ):
            _surface_contact_remove_guide(context, guide)
            _surface_contact_restore_suspended(suspended)
            self.report({"ERROR"}, "Unable to create the contact target constraint.")
            return {"CANCELLED"}
        reachable_target = _surface_contact_project_reachable_target(
            context,
            guide,
            surface_point,
            surface_normal,
            align_initial = True,
        )
        if reachable_target is not None:
            _surface_contact_set_guide_surface_point(
                context,
                guide,
                reachable_target[0],
                reachable_target[1],
            )
        solved_anchor, final_support = _surface_contact_align_solver(
            context,
            guide,
            armature,
            geometry_bone_name,
            support_objects,
        )
        if solved_anchor is None or final_support is None:
            _surface_contact_remove_guide(context, guide)
            _surface_contact_restore_suspended(suspended)
            self.report(
                {"ERROR"},
                "Unable to align the contact dots for this bone.",
            )
            return {"CANCELLED"}

        _surface_contact_insert_marker(
            effector,
            effector.name,
            frame,
            1.0,
        )
        _surface_contact_keyframe_guide_transform(
            guide,
            frame,
            effector.name,
        )
        _surface_contact_keyframe_simulated_pose(guide, frame)
        if previous_guide is not None:
            previous_guide[SURFACE_CONTACT_END_PROPERTY] = int(frame)
        for existing_guide in exact_guides:
            _surface_contact_remove_guide(
                context,
                existing_guide,
            )
        if carried_end is not None and int(carried_end) > frame:
            guide[SURFACE_CONTACT_END_PROPERTY] = int(carried_end)
        _surface_contact_rebuild_markers(
            effector,
            effector.name,
        )
        _sync_surface_contact_constraints(context.scene)
        context.view_layer.update()

        _yellow_refresh_runtime(context)
        _tag_redraw_all_view3d()
        self.report(
            {"INFO"},
            f"Contact enabled for {part.name} against {surface.name}.",
        )
        return {"FINISHED"}


class STATICALIZA_OT_surface_contact_release(bpy.types.Operator):
    bl_idname = "staticaliza.surface_contact_release"
    bl_label = "Release Surface Contact"
    bl_description = "Release the selected planted endpoint without changing its visible pose"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        guide = _surface_contact_selected_guide(context, active_only = True)
        if guide is None:
            return False
        return int(context.scene.frame_current) > int(
            guide.get(SURFACE_CONTACT_START_PROPERTY, context.scene.frame_current)
        )

    def execute(self, context):
        guide = _surface_contact_selected_guide(context, active_only = True)
        if guide is None:
            return {"CANCELLED"}
        frame = int(context.scene.frame_current)
        start = int(guide.get(SURFACE_CONTACT_START_PROPERTY, frame))
        if frame <= start:
            self.report({"ERROR"}, "Release must be after the contact start frame.")
            return {"CANCELLED"}

        _marker_object, marker_owner = _surface_contact_owner_from_guide(guide)
        primary, _secondary = _surface_contact_constraints(guide)
        if (
            marker_owner is None
            or (
                primary is None
                and str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
                != SURFACE_CONTACT_KIND_SIMULATED
            )
        ):
            self.report({"ERROR"}, "The contact constraint is missing.")
            return {"CANCELLED"}

        effector_name = str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
        target_object = bpy.data.objects.get(
            str(guide.get(SURFACE_CONTACT_RELEASE_OBJECT_PROPERTY, ""))
        )
        target_bone_name = str(
            guide.get(SURFACE_CONTACT_RELEASE_BONE_PROPERTY, "")
        )
        target_world = _surface_contact_target_world_matrix(
            context,
            target_object,
            target_bone_name,
        ) if target_object is not None else None
        guide[SURFACE_CONTACT_END_PROPERTY] = frame
        _surface_contact_rebuild_markers(
            marker_owner,
            effector_name,
        )
        _sync_surface_contact_constraints(context.scene)
        if target_world is not None and target_object is not None:
            _surface_contact_set_target_world_matrix(
                context,
                target_object,
                target_bone_name,
                target_world,
            )
        context.view_layer.update()

        _tag_redraw_all_view3d()
        self.report({"INFO"}, f"Released {effector_name} at frame {frame}.")
        return {"FINISHED"}


class STATICALIZA_OT_surface_contact_clear(bpy.types.Operator):
    bl_idname = "staticaliza.surface_contact_clear"
    bl_label = "Clear Surface Contact"
    bl_description = "Remove the active Surface Contact segment while preserving the current pose"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _surface_contact_selected_guide(context, active_only = True) is not None

    def execute(self, context):
        guide = _surface_contact_selected_guide(context, active_only = True)
        if guide is None:
            return {"CANCELLED"}
        bone_name = str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, "endpoint"))
        _surface_contact_remove_guide(
            context,
            guide,
            preserve_frame = int(context.scene.frame_current),
        )
        _tag_redraw_all_view3d()
        self.report({"INFO"}, f"Cleared Surface Contact for {bone_name}.")
        return {"FINISHED"}


def _surface_contact_stored_anchor_world(context, guide):
    return _surface_contact_anchor_world(context, guide)


def _pin_points_within_snap_radius(
    context,
    target,
    current,
    pixel_radius = PIN_SNAP_PIXEL_RADIUS,
):
    pixel_radius = max(1.0, float(pixel_radius))
    region = getattr(context, "region", None)
    region_data = getattr(context, "region_data", None)
    area = getattr(context, "area", None)
    if (
        area is None
        or getattr(area, "type", "") != "VIEW_3D"
        or region is None
        or region_data is None
    ):
        region = None
        region_data = None
        screen = getattr(context, "screen", None)
        for candidate_area in getattr(screen, "areas", ()) if screen else ():
            if candidate_area.type != "VIEW_3D":
                continue
            candidate_region = next(
                (
                    item
                    for item in candidate_area.regions
                    if item.type == "WINDOW"
                ),
                None,
            )
            candidate_space = getattr(candidate_area.spaces, "active", None)
            candidate_region_data = getattr(candidate_space, "region_3d", None)
            if candidate_region is not None and candidate_region_data is not None:
                region = candidate_region
                region_data = candidate_region_data
                break
    if region is None or region_data is None:
        return False

    from bpy_extras import view3d_utils

    target_2d = view3d_utils.location_3d_to_region_2d(
        region,
        region_data,
        Vector(target),
    )
    current_2d = view3d_utils.location_3d_to_region_2d(
        region,
        region_data,
        Vector(current),
    )
    if target_2d is None or current_2d is None:
        return False
    if (target_2d - current_2d).length > pixel_radius:
        return False
    edge_world = view3d_utils.region_2d_to_location_3d(
        region,
        region_data,
        target_2d + Vector((pixel_radius, 0.0)),
        Vector(target),
    )
    world_radius = (Vector(edge_world) - Vector(target)).length
    return (Vector(target) - Vector(current)).length <= max(
        1.0e-5,
        world_radius * 1.25,
    )


def _pin_snap_should_engage(
    context,
    snap_key,
    target,
    current,
    use_hysteresis = False,
):
    if not use_hysteresis:
        return _pin_points_within_snap_radius(context, target, current)

    latches = _state.setdefault("pin_snap_latches", set())
    snap_key = str(snap_key)
    pixel_radius = (
        PIN_SNAP_RELEASE_PIXEL_RADIUS
        if snap_key in latches
        else PIN_SNAP_PIXEL_RADIUS
    )
    engaged = _pin_points_within_snap_radius(
        context,
        target,
        current,
        pixel_radius = pixel_radius,
    )
    if engaged:
        latches.add(snap_key)
    else:
        latches.discard(snap_key)
    return engaged


def _surface_contact_snap_key(guide):
    armature = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
    )
    return (
        f"CONTACT:{_armature_session_uid(armature)}:"
        f"{getattr(guide, 'name', '')}"
    )


def _surface_contact_set_snap_detached(guide, detached):
    key = _surface_contact_snap_key(guide)
    detached_keys = _state.setdefault("pin_snap_detached", set())
    if detached:
        detached_keys.add(key)
        try:
            if not bool(guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)):
                guide[SURFACE_CONTACT_DETACHED_PROPERTY] = True
        except (ReferenceError, RuntimeError, TypeError):
            pass
    else:
        detached_keys.discard(key)
        try:
            if SURFACE_CONTACT_DETACHED_PROPERTY in guide:
                del guide[SURFACE_CONTACT_DETACHED_PROPERTY]
        except (KeyError, ReferenceError, RuntimeError, TypeError):
            pass


def _surface_contact_restore_snap_detached(
    context,
    infer_missing = True,
    reset_runtime = True,
):
    """Restore the saved/runtime detach latch before contact enforcement."""
    detached_keys = _state.setdefault("pin_snap_detached", set())
    if reset_runtime:
        detached_keys.clear()
    scene = getattr(context, "scene", None) if context is not None else None
    if scene is None:
        return False

    active_guides = set(_surface_contact_active_simulated_guides(scene))
    changed = False
    for guide in _surface_contact_guides():
        if (
            str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
            != SURFACE_CONTACT_KIND_SIMULATED
        ):
            continue
        if bool(guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)):
            detached_keys.add(_surface_contact_snap_key(guide))
            continue
        if not infer_missing or guide not in active_guides:
            continue

        target, _normal, anchor = _surface_contact_world_point_normal(
            context,
            guide,
        )
        if target is None or anchor is None:
            continue
        tolerance = max(
            1.0e-6,
            float(guide.get(SURFACE_CONTACT_SIZE_PROPERTY, 0.05)) * 1.0e-5,
        )
        if (
            (Vector(target) - Vector(anchor)).length > tolerance
            and not _pin_points_within_snap_radius(
                context,
                target,
                anchor,
            )
        ):
            # Older files have no persistent latch. Their keyed guide and
            # endpoint poses still distinguish an engaged contact from a
            # deliberately moved endpoint, so migrate that state on load.
            _surface_contact_set_snap_detached(guide, True)
            changed = True
    return changed


def _surface_contact_clear_snap_departure(guide):
    key = _surface_contact_snap_key(guide)
    _state.setdefault("pin_snap_departing", set()).discard(key)
    _surface_contact_set_snap_detached(guide, False)
    _state.setdefault("pin_snap_transform_seen", set()).discard(key)
    _state.setdefault("pin_snap_latches", set()).discard(key)


def _surface_contact_snap_departure_active(
    context,
    guide,
    start_if_close = False,
):
    key = _surface_contact_snap_key(guide)
    departing = _state.setdefault("pin_snap_departing", set())
    detached = _state.setdefault("pin_snap_detached", set())
    seen = _state.setdefault("pin_snap_transform_seen", set())
    target, _normal, anchor = _surface_contact_world_point_normal(
        context,
        guide,
    )
    if target is None or anchor is None:
        return key in departing or key in detached

    distance = (Vector(target) - Vector(anchor)).length
    if key in detached:
        tolerance = max(
            1.0e-6,
            float(guide.get(SURFACE_CONTACT_SIZE_PROPERTY, 0.05)) * 1.0e-5,
        )
        if (
            distance <= tolerance
            or _pin_points_within_snap_radius(context, target, anchor)
        ):
            # Re-entering the smaller magnetic ring intentionally re-engages
            # contact, even when another bone is now selected.
            _surface_contact_clear_snap_departure(guide)
            return False
        return True
    if start_if_close and key not in seen:
        seen.add(key)
        if (
            distance <= 1.0e-7
            or _pin_points_within_snap_radius(
                context,
                target,
                anchor,
                pixel_radius = PIN_SNAP_RELEASE_PIXEL_RADIUS,
            )
        ):
            departing.add(key)
        else:
            # A depsgraph callback may first observe a fast transform only
            # after the endpoint has already crossed the release ring. Treat
            # that first far sample as the same deliberate detach instead of
            # leaving a selection-change window that can force it back.
            _surface_contact_set_snap_detached(guide, True)

    if key in detached:
        return True

    if key not in departing:
        return False
    if distance <= 1.0e-7:
        return True
    if _pin_points_within_snap_radius(
        context,
        target,
        anchor,
        pixel_radius = PIN_SNAP_RELEASE_PIXEL_RADIUS,
    ):
        return True

    # Leaving the wider release ring completes a deliberate detach. Keep that
    # state across bone selection changes; otherwise the unselected-contact
    # reconciliation path would force the cached contact pose back instantly.
    departing.discard(key)
    _surface_contact_set_snap_detached(guide, True)
    _state.setdefault("pin_snap_latches", set()).discard(key)
    return True


def _surface_contact_finalize_snap_departures(context):
    departing = _state.setdefault("pin_snap_departing", set())
    seen = _state.setdefault("pin_snap_transform_seen", set())
    if not departing and not seen:
        return False
    changed = False
    for guide in _surface_contact_active_simulated_guides(context.scene):
        key = _surface_contact_snap_key(guide)
        if key not in departing and key not in seen:
            continue
        target, _normal, anchor = _surface_contact_world_point_normal(
            context,
            guide,
        )
        if (
            target is not None
            and anchor is not None
            and (
                (Vector(target) - Vector(anchor)).length <= 1.0e-7
                or _pin_points_within_snap_radius(context, target, anchor)
            )
        ):
            _surface_contact_clear_snap_departure(guide)
        else:
            departing.discard(key)
            seen.discard(key)
            _surface_contact_set_snap_detached(guide, True)
            _state.setdefault("pin_snap_latches", set()).discard(key)
        changed = True
    return changed


def _surface_contact_enforce_guide(
    context,
    guide,
    force_contact = False,
    insert_keys = False,
    use_snap_hysteresis = False,
    allow_snap = True,
):
    changed = _surface_contact_migrate_legacy_ik_guide(context, guide)
    target, normal, anchor = _surface_contact_world_point_normal(context, guide)
    if target is None or anchor is None or normal is None:
        return changed

    desired = None
    if force_contact:
        desired = target
    else:
        snap_close = bool(
            allow_snap
            and _pin_snap_should_engage(
                context,
                _surface_contact_snap_key(guide),
                target,
                anchor,
                use_hysteresis = use_snap_hysteresis,
            )
        )
        if snap_close:
            desired = target
        else:
            signed_distance = (anchor - target).dot(normal)
            penetration_tolerance = max(
                1.0e-6,
                float(guide.get(SURFACE_CONTACT_SIZE_PROPERTY, 0.05)) * 1.0e-5,
            )
            if signed_distance < -penetration_tolerance:
                # Resolve only the surface-normal component so the endpoint can
                # continue gliding tangentially instead of snapping backward.
                desired = anchor - (normal * signed_distance)
    if desired is None:
        return changed

    contact_kind = str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
    if contact_kind == SURFACE_CONTACT_KIND_SIMULATED:
        return _surface_contact_update_simulated_solver(
            context,
            guide,
            desired_point = desired,
            insert_keys = insert_keys,
        ) or changed
    if contact_kind == SURFACE_CONTACT_KIND_CONTROL:
        return _surface_contact_refine_control_solver(
            context,
            guide,
            desired_point = desired,
        ) or changed
    return _surface_contact_update_fallback_solver(context, guide) or changed


def _surface_contact_project_reachable_target(
    context,
    guide,
    point,
    normal,
    align_initial = False,
):
    point = Vector(point)
    normal = Vector(normal)
    if normal.length_squared <= 1.0e-12:
        return None
    normal.normalize()
    if (
        not align_initial
        or str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
        != SURFACE_CONTACT_KIND_IK
    ):
        return point, normal

    anchor = _surface_contact_stored_anchor_world(context, guide)
    reach_data = _surface_contact_solver_reach(context, guide)
    if anchor is None or reach_data is None:
        return point, normal
    pivot = Vector(reach_data[0])
    support_radius = (anchor - pivot).length
    signed_distance = normal.dot(pivot - point)
    if support_radius <= 1.0e-8 or abs(signed_distance) > support_radius:
        return point, normal

    circle_center = pivot - (normal * signed_distance)
    tangent = point - circle_center
    tangent -= normal * tangent.dot(normal)
    if tangent.length_squared <= 1.0e-12:
        tangent = anchor - circle_center
        tangent -= normal * tangent.dot(normal)
    if tangent.length_squared <= 1.0e-12:
        tangent = normal.orthogonal()
    tangent.normalize()
    circle_radius = math.sqrt(
        max(0.0, (support_radius * support_radius) - (signed_distance * signed_distance))
    )
    reachable = circle_center + (tangent * circle_radius)

    surface = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_SURFACE_PROPERTY, ""))
    )
    if surface is not None:
        closest = _surface_contact_closest_point(
            surface,
            reachable,
            context.evaluated_depsgraph_get(),
            max(1.0, (reachable - point).length * 4.0),
        )
        if closest is not None:
            closest_point, closest_normal = closest
            tolerance = max(
                1.0e-4,
                float(guide.get(SURFACE_CONTACT_SIZE_PROPERTY, 0.05)) * 0.1,
            )
            if abs((closest_point - pivot).length - support_radius) <= tolerance:
                return closest_point, closest_normal
    return reachable, normal


def _surface_contact_set_guide_surface_point(context, guide, point, normal):
    surface = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_SURFACE_PROPERTY, ""))
    )
    if surface is None:
        return False
    point = Vector(point)
    normal = Vector(normal)
    if normal.length_squared <= 1.0e-12:
        return False
    normal.normalize()
    anchor = _surface_contact_stored_anchor_world(context, guide)
    if anchor is not None and normal.dot(anchor - point) < 0.0:
        normal.negate()

    world_matrix = _surface_contact_plane_matrix(
        point,
        normal,
        guide.matrix_world,
    )
    guide.matrix_world = world_matrix
    local_point = surface.matrix_world.inverted_safe() @ point
    local_normal = surface.matrix_world.to_3x3().transposed() @ normal
    if local_normal.length_squared > 1.0e-12:
        local_normal.normalize()
    guide[SURFACE_CONTACT_POINT_PROPERTY] = tuple(local_point)
    guide[SURFACE_CONTACT_NORMAL_PROPERTY] = tuple(local_normal)

    follow_object = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_FOLLOW_OBJECT_PROPERTY, ""))
    )
    follow_bone = str(guide.get(SURFACE_CONTACT_FOLLOW_BONE_PROPERTY, ""))
    if follow_object is not None:
        depsgraph = context.evaluated_depsgraph_get()
        evaluated_follow = follow_object.evaluated_get(depsgraph)
        follow_world = evaluated_follow.matrix_world.copy()
        if follow_bone and getattr(evaluated_follow, "pose", None):
            evaluated_bone = evaluated_follow.pose.bones.get(follow_bone)
            if evaluated_bone is not None:
                follow_world = follow_world @ evaluated_bone.matrix
        local_matrix = follow_world.inverted_safe() @ world_matrix
        guide[SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY] = tuple(
            float(value)
            for row in local_matrix
            for value in row
        )
    context.view_layer.update()
    return True


def _surface_contact_move_guide_to_surface(context, guide, point, normal):
    reachable_target = _surface_contact_project_reachable_target(
        context,
        guide,
        point,
        normal,
    )
    if reachable_target is None:
        return False

    previous_guide_world = guide.matrix_world.copy()
    if (
        str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
        == SURFACE_CONTACT_KIND_CONTROL
        and SURFACE_CONTACT_SOLVER_LOCAL_MATRIX_PROPERTY not in guide
    ):
        _surface_contact_store_solver_local_matrix(guide)
    previous_normal = previous_guide_world.to_3x3().col[2]
    next_normal = Vector(reachable_target[1])
    if previous_normal.length_squared > 1.0e-12:
        previous_normal.normalize()
    if next_normal.length_squared > 1.0e-12:
        next_normal.normalize()
    point_changed = (
        Vector(reachable_target[0]) - previous_guide_world.translation
    ).length > 1.0e-5
    normal_changed = (
        previous_normal.length_squared > 1.0e-12
        and next_normal.length_squared > 1.0e-12
        and previous_normal.dot(next_normal) < (1.0 - 1.0e-6)
    )
    if not point_changed and not normal_changed:
        return False
    # Moving the pink target is authoritative and must re-arm exact contact;
    # a departure gate belongs only to direct bone manipulation.
    _surface_contact_clear_snap_departure(guide)
    if not _surface_contact_set_guide_surface_point(
        context,
        guide,
        reachable_target[0],
        reachable_target[1],
    ):
        return False

    solver = _surface_contact_solver_from_guide(guide)
    if solver is not None:
        contact_kind = str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
        if contact_kind == SURFACE_CONTACT_KIND_SIMULATED:
            _surface_contact_update_simulated_solver(
                context,
                guide,
                desired_point = guide.matrix_world.translation,
            )
        elif contact_kind == SURFACE_CONTACT_KIND_IK:
            _surface_contact_update_fallback_solver(context, guide)
        else:
            _surface_contact_update_control_solver(guide)
            _surface_contact_refine_control_solver(context, guide)
    context.view_layer.update()
    _tag_redraw_all_view3d()
    return True


def _surface_contact_move_guide_world(context, guide, point):
    """Move a Contact target freely while preserving its surface-relative frame."""
    normal = _surface_contact_world_point_normal(context, guide)[1]
    return _surface_contact_move_guide_to_surface(context, guide, point, normal)


def _surface_contact_mouse_surface_point(context, guide, mouse_position):
    region = getattr(context, "region", None)
    region_data = getattr(context, "region_data", None)
    surface = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_SURFACE_PROPERTY, ""))
    )
    if region is None or region_data is None or surface is None:
        return None

    from bpy_extras import view3d_utils

    mouse = Vector(mouse_position)
    origin = view3d_utils.region_2d_to_origin_3d(region, region_data, mouse)
    direction = view3d_utils.region_2d_to_vector_3d(region, region_data, mouse)
    depsgraph = context.evaluated_depsgraph_get()
    evaluated_surface = surface.evaluated_get(depsgraph)
    inverse = evaluated_surface.matrix_world.inverted_safe()
    local_origin = inverse @ origin
    local_direction = inverse.to_3x3() @ direction
    if local_direction.length_squared <= 1.0e-12:
        return None
    local_direction.normalize()
    try:
        hit, location, normal, _face = evaluated_surface.ray_cast(
            local_origin,
            local_direction,
            distance = 1000000.0,
            depsgraph = depsgraph,
        )
    except TypeError:
        hit, location, normal, _face = evaluated_surface.ray_cast(
            local_origin,
            local_direction,
            distance = 1000000.0,
        )
    if not hit:
        current_point = guide.matrix_world.translation.copy()
        plane_normal = guide.matrix_world.to_3x3().col[2]
        denominator = float(direction.dot(plane_normal))
        if abs(denominator) <= 1.0e-6:
            return None
        distance = float((current_point - origin).dot(plane_normal) / denominator)
        candidate = origin + (direction * distance)
        closest = _surface_contact_closest_point(
            surface,
            candidate,
            depsgraph,
            max(1.0, (candidate - current_point).length * 4.0),
        )
        return closest

    world_point = evaluated_surface.matrix_world @ location
    world_normal = (
        evaluated_surface.matrix_world.to_3x3().inverted_safe().transposed()
        @ normal
    )
    if world_normal.length_squared <= 1.0e-12:
        return None
    world_normal.normalize()
    return world_point, world_normal


def _surface_contact_commit_target_key(context, guide):
    frame = int(context.scene.frame_current)
    bone_name = str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, "Contact"))
    _surface_contact_keyframe_guide_transform(guide, frame, bone_name)
    start = int(guide.get(SURFACE_CONTACT_START_PROPERTY, frame))
    if frame != start:
        target_frames = set(_surface_contact_target_frames(guide))
        target_frames.add(frame)
        _surface_contact_set_target_frames(guide, target_frames)
    _marker_object, marker_owner = _surface_contact_owner_from_guide(guide)
    if marker_owner is not None:
        _surface_contact_insert_marker(
            marker_owner,
            bone_name,
            frame,
            1.0,
        )
        _surface_contact_rebuild_markers(marker_owner, bone_name)
    if (
        str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
        == SURFACE_CONTACT_KIND_SIMULATED
    ):
        # A simulated contact has no Blender constraint to preserve its solved
        # pose. Key the final solve together with the pink target so later
        # animation evaluation and undo/redo cannot restore a stale pose first.
        _surface_contact_update_simulated_solver(
            context,
            guide,
            desired_point = guide.matrix_world.translation,
            max_iterations = 8,
        )
        _surface_contact_keyframe_simulated_pose(guide, frame)
    context.view_layer.update()
    _sync_surface_contact_constraints(context.scene)
    _tag_redraw_all_view3d()


_PIN_GIZMO_DIAMOND_VERTICES = (
    (0.0, 0.0, 1.0), (1.0, 0.0, 0.0), (0.0, 1.0, 0.0),
    (0.0, 0.0, 1.0), (0.0, 1.0, 0.0), (-1.0, 0.0, 0.0),
    (0.0, 0.0, 1.0), (-1.0, 0.0, 0.0), (0.0, -1.0, 0.0),
    (0.0, 0.0, 1.0), (0.0, -1.0, 0.0), (1.0, 0.0, 0.0),
    (0.0, 0.0, -1.0), (0.0, 1.0, 0.0), (1.0, 0.0, 0.0),
    (0.0, 0.0, -1.0), (-1.0, 0.0, 0.0), (0.0, 1.0, 0.0),
    (0.0, 0.0, -1.0), (0.0, -1.0, 0.0), (-1.0, 0.0, 0.0),
    (0.0, 0.0, -1.0), (1.0, 0.0, 0.0), (0.0, -1.0, 0.0),
)


_PIN_MOVE_ARROW_VERTICES = (
    (-0.03, -0.03, 0.0), (0.03, -0.03, 0.0), (0.03, -0.03, 0.68),
    (-0.03, -0.03, 0.0), (0.03, -0.03, 0.68), (-0.03, -0.03, 0.68),
    (-0.03, 0.03, 0.0), (0.03, 0.03, 0.68), (0.03, 0.03, 0.0),
    (-0.03, 0.03, 0.0), (-0.03, 0.03, 0.68), (0.03, 0.03, 0.68),
    (-0.03, -0.03, 0.0), (-0.03, 0.03, 0.68), (-0.03, 0.03, 0.0),
    (-0.03, -0.03, 0.0), (-0.03, -0.03, 0.68), (-0.03, 0.03, 0.68),
    (0.03, -0.03, 0.0), (0.03, 0.03, 0.0), (0.03, 0.03, 0.68),
    (0.03, -0.03, 0.0), (0.03, 0.03, 0.68), (0.03, -0.03, 0.68),
    (0.0, 0.0, 1.0), (-0.10, -0.10, 0.66), (0.10, -0.10, 0.66),
    (0.0, 0.0, 1.0), (0.10, -0.10, 0.66), (0.10, 0.10, 0.66),
    (0.0, 0.0, 1.0), (0.10, 0.10, 0.66), (-0.10, 0.10, 0.66),
    (0.0, 0.0, 1.0), (-0.10, 0.10, 0.66), (-0.10, -0.10, 0.66),
)


def _pin_gizmo_axis_matrix(point, axis):
    axis = Vector(axis)
    if axis.length_squared <= 1.0e-12:
        axis = Vector((0.0, 0.0, 1.0))
    axis.normalize()
    matrix = Vector((0.0, 0.0, 1.0)).rotation_difference(axis).to_matrix().to_4x4()
    matrix.translation = Vector(point)
    return matrix


def _pin_rest_orientation_world(target_data):
    if target_data is None:
        return Matrix.Identity(3)
    try:
        _kind, armature, pose_bone, _payload = target_data
        if armature is None or pose_bone is None or pose_bone.bone is None:
            return Matrix.Identity(3)
        armature_rotation = armature.matrix_world.to_quaternion().normalized()
        rest_rotation = (
            pose_bone.bone.matrix_local.to_quaternion().normalized()
        )
        return (armature_rotation @ rest_rotation).normalized().to_matrix()
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return Matrix.Identity(3)


def _pin_transform_orientation_matrix(
    context,
    target_data,
    pin_matrix = None,
):
    try:
        orientation_type = str(
            context.scene.transform_orientation_slots[0].type
        )
    except (AttributeError, IndexError, ReferenceError):
        orientation_type = "GLOBAL"
    part_mode = bool(
        getattr(
            getattr(context, "window_manager", None),
            "staticaliza_pivot_mode",
            "BONE",
        ) == "PART"
    )
    if orientation_type == "GLOBAL":
        return Matrix.Identity(3)
    if part_mode and orientation_type in {"LOCAL", "CURSOR"}:
        # Object pivot mode stores the connected object's world axes on the
        # cursor. Refresh them for pin-only selection before drawing/using the
        # pin handles so they cannot fall back to the bone's rest axes.
        try:
            _sync_part_pivot(context)
            return context.scene.cursor.matrix.to_3x3().normalized()
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            pass
    if orientation_type == "LOCAL":
        # Bone.matrix_local already includes the original parent rest chain.
        return _pin_rest_orientation_world(target_data)
    if orientation_type == "VIEW":
        region_data = getattr(context, "region_data", None)
        if region_data is not None:
            try:
                return (
                    region_data.view_matrix.inverted_safe()
                    .to_3x3()
                    .normalized()
                )
            except (AttributeError, RuntimeError, TypeError, ValueError):
                pass
    if orientation_type == "CURSOR":
        try:
            return context.scene.cursor.matrix.to_3x3().normalized()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            pass
    if pin_matrix is None and target_data is not None:
        try:
            kind, armature, pose_bone, payload = target_data
            pin_matrix = (
                payload.matrix_world.copy()
                if kind == "CONTACT"
                else (armature.matrix_world @ pose_bone.matrix).normalized()
            )
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            pin_matrix = None
    try:
        return pin_matrix.to_3x3().normalized()
    except (AttributeError, RuntimeError, TypeError, ValueError):
        return Matrix.Identity(3)


def _pin_gizmo_center_matrix(point):
    return Matrix.Translation(Vector(point))


def _pin_gizmo_locked_axes(context):
    pose_bone = _single_active_pose_bone(context)
    if pose_bone is None:
        return (False, False, False)
    try:
        return tuple(bool(value) for value in pose_bone.lock_location[:3])
    except (AttributeError, TypeError, ValueError):
        return (False, False, False)


def _pin_gizmo_apply_axis_locks(
    candidate,
    origin,
    locked_axes,
    orientation = None,
):
    result = Vector(candidate)
    origin = Vector(origin)
    if orientation is None:
        orientation = Matrix.Identity(3)
    try:
        orientation = orientation.to_3x3().normalized()
    except (AttributeError, RuntimeError, TypeError, ValueError):
        orientation = Matrix.Identity(3)
    local_delta = orientation.inverted_safe() @ (result - origin)
    for axis_index, locked in enumerate(tuple(locked_axes or ())[:3]):
        if locked:
            local_delta[axis_index] = 0.0
    return origin + (orientation @ local_delta)


def _pin_gizmo_mouse_plane_point(context, point, mouse_position):
    region = getattr(context, "region", None)
    region_data = getattr(context, "region_data", None)
    if region is None or region_data is None:
        return None
    from bpy_extras import view3d_utils

    try:
        return view3d_utils.region_2d_to_location_3d(
            region,
            region_data,
            Vector(mouse_position),
            Vector(point),
        )
    except (AttributeError, RuntimeError, TypeError, ValueError):
        return None


def _pin_gizmo_mouse_surface_point(context, mouse_position, excluded_names = ()):
    region = getattr(context, "region", None)
    region_data = getattr(context, "region_data", None)
    if region is None or region_data is None:
        return None
    from bpy_extras import view3d_utils

    mouse = Vector(mouse_position)
    origin = view3d_utils.region_2d_to_origin_3d(region, region_data, mouse)
    direction = view3d_utils.region_2d_to_vector_3d(region, region_data, mouse)
    excluded = {
        obj
        for name in tuple(excluded_names or ())
        if (obj := bpy.data.objects.get(str(name))) is not None
    }
    hit = _surface_contact_ray_cast(
        context,
        origin,
        direction,
        1000000.0,
        excluded,
    )
    return hit[1].copy() if hit is not None else None


def _pin_gizmo_axis_mouse_point(context, point, axis, mouse_position):
    region = getattr(context, "region", None)
    region_data = getattr(context, "region_data", None)
    if region is None or region_data is None:
        return None
    from bpy_extras import view3d_utils
    from mathutils.geometry import intersect_line_line

    mouse = Vector(mouse_position)
    ray_origin = view3d_utils.region_2d_to_origin_3d(region, region_data, mouse)
    ray_direction = view3d_utils.region_2d_to_vector_3d(region, region_data, mouse)
    axis = Vector(axis)
    if axis.length_squared <= 1.0e-12 or ray_direction.length_squared <= 1.0e-12:
        return None
    axis.normalize()
    pair = intersect_line_line(
        Vector(point) - axis,
        Vector(point) + axis,
        ray_origin,
        ray_origin + ray_direction,
    )
    return pair[0] if pair is not None else None


def _surface_contact_axis_surface_point(context, guide, candidate):
    surface = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_SURFACE_PROPERTY, ""))
    )
    if surface is None:
        return None
    current = guide.matrix_world.translation
    return _surface_contact_closest_point(
        surface,
        Vector(candidate),
        context.evaluated_depsgraph_get(),
        max(1.0, (Vector(candidate) - current).length * 4.0),
    )


def _pin_gizmo_group(gizmo):
    try:
        return gizmo.group
    except (AttributeError, ReferenceError, RuntimeError):
        return None


def _pin_gizmo_stable_target_mapping(group, target_keys):
    """Keep each live pin bound to the same pooled Gizmo across redraws."""
    target_keys = {str(key) for key in target_keys}
    pool = tuple(getattr(group, "target_gizmo_pool", ()))
    pool_ids = {id(gizmo) for gizmo in pool}
    retained = {
        str(key): gizmo
        for key, gizmo in dict(
            getattr(group, "target_gizmos", {})
        ).items()
        if str(key) in target_keys and id(gizmo) in pool_ids
    }
    used_ids = {id(gizmo) for gizmo in retained.values()}
    free_gizmos = [gizmo for gizmo in pool if id(gizmo) not in used_ids]
    for target_key in sorted(target_keys):
        if target_key in retained or not free_gizmos:
            continue
        retained[target_key] = free_gizmos.pop(0)
    group.target_gizmos = retained
    return retained


def _pin_available_target_data(context):
    """Return every pin that can be selected in the current Pose viewport."""
    if context is None or getattr(context, "mode", "") != "POSE":
        return {}
    armatures = _pose_scope_armatures(context)
    if not armatures:
        return {}

    targets = {}
    frame = int(context.scene.frame_current)
    armatures_by_name = {armature.name: armature for armature in armatures}
    selected_owner_bones = _selected_owner_bone_keys(context)
    active_pose_bone = getattr(context, "active_pose_bone", None)
    active_armature = _pose_bone_owner(
        context,
        active_pose_bone,
        armatures,
    )
    active_owner_bone = (
        _owner_bone_key(active_armature, active_pose_bone.name)
        if active_armature is not None and active_pose_bone is not None
        else None
    )
    selected_pin_key = str(_state.get("pin_gizmo_selected_key", ""))
    for guide in _surface_contact_guides():
        armature = armatures_by_name.get(
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
        )
        if armature is None or not _surface_contact_guide_active_at(guide, frame):
            continue
        pose_bone = armature.pose.bones.get(
            str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
        )
        if pose_bone is None:
            continue
        key = _surface_contact_snap_key(guide)
        associated_owner_bone = _owner_bone_key(
            armature,
            pose_bone.name,
        )
        if (
            key != selected_pin_key
            and associated_owner_bone not in selected_owner_bones
            and active_owner_bone != associated_owner_bone
        ):
            continue
        targets[key] = ("CONTACT", armature, pose_bone, guide)

    for armature in armatures:
        if _yellow_owner_hidden(armature):
            continue
        for bone_name, packed in _yellow_owner_map(
            "yellow_fixed",
            armature,
        ).items():
            pose_bone = armature.pose.bones.get(str(bone_name))
            if pose_bone is None or not packed:
                continue
            key = (
                f"YELLOW:{_armature_session_uid(armature)}:"
                f"{pose_bone.name}"
            )
            targets[key] = ("YELLOW", armature, pose_bone, packed)
    return targets


def _pin_selected_target_key(context = None, validate = False):
    key = str(_state.get("pin_gizmo_selected_key", ""))
    if key and validate and key not in _pin_available_target_data(context):
        return ""
    return key


def _pin_selected_target_data(context):
    key = _pin_selected_target_key(context, validate = True)
    return key, _pin_available_target_data(context).get(key)


def _pin_target_locked_axes(target_data):
    pose_bone = target_data[2] if target_data else None
    if pose_bone is None:
        return (False, False, False)
    try:
        return tuple(bool(value) for value in pose_bone.lock_location[:3])
    except (AttributeError, ReferenceError, TypeError, ValueError):
        return (False, False, False)


def _pin_pose_selection_signature(context):
    armatures = _pose_scope_armatures(context)
    if not armatures:
        return ((), (), (0, ""))
    selected_names = tuple(sorted(_selected_owner_bone_keys(context)))
    active = getattr(context, "active_pose_bone", None)
    active_armature = _pose_bone_owner(context, active, armatures)
    active_key = (
        _owner_bone_key(active_armature, active.name)
        if active is not None and active_armature is not None
        else (0, "")
    )
    return (
        tuple(sorted(_armature_session_uid(armature) for armature in armatures)),
        selected_names,
        active_key,
    )


def _pin_deselect_pose_bones(
    context,
    active_armature = None,
    active_pose_bone = None,
):
    changed = False
    for armature in _pose_scope_armatures(context):
        armature_data = getattr(armature, "data", None)
        pose = getattr(armature, "pose", None)
        for pose_bone in getattr(pose, "bones", ()):
            bone = getattr(pose_bone, "bone", None)
            try:
                if hasattr(pose_bone, "select"):
                    if pose_bone.select:
                        changed = True
                    pose_bone.select = False
                elif bone is not None:
                    if bone.select or bone.select_head or bone.select_tail:
                        changed = True
                    bone.select = False
                    bone.select_head = False
                    bone.select_tail = False
            except (AttributeError, ReferenceError, RuntimeError):
                pass
        try:
            desired_active = (
                getattr(active_pose_bone, "bone", None)
                if armature == active_armature
                else None
            )
            if (
                armature_data is not None
                and armature_data.bones.active != desired_active
            ):
                armature_data.bones.active = desired_active
                changed = True
        except (AttributeError, ReferenceError, RuntimeError):
            pass
    if active_armature is not None:
        try:
            if context.view_layer.objects.active != active_armature:
                context.view_layer.objects.active = active_armature
                changed = True
        except (AttributeError, ReferenceError, RuntimeError):
            pass
    if changed:
        try:
            context.view_layer.update()
        except (AttributeError, ReferenceError, RuntimeError):
            pass
    return changed


def _pin_select_target(
    context,
    target_key,
    extend = False,
    defer_pose_selection = False,
):
    target_key = str(target_key)
    target_data = _pin_available_target_data(context).get(target_key)
    if target_data is None:
        return False
    if target_data[0] == "YELLOW":
        _state.setdefault("pin_yellow_history_fallbacks", {})[
            _owner_bone_key(target_data[1], target_data[2].name)
        ] = tuple(float(value) for value in Vector(target_data[3][0]))
    changed = target_key != str(_state.get("pin_gizmo_selected_key", ""))
    _state["pin_gizmo_selected_key"] = target_key
    if changed:
        _state["pin_gizmo_selection_epoch"] = int(
            _state.get("pin_gizmo_selection_epoch", 0)
        ) + 1
    _state["pin_gizmo_pending_click"] = None
    _state["pin_gizmo_axes_visible"] = {target_key: True}
    if not extend and not defer_pose_selection:
        # A normal click selects the virtual pin exclusively. Set the pin key
        # first so contact reconciliation continues treating its guide as the
        # actively manipulated target while Blender clears the Pose selection.
        # Retaining only the associated active-bone pointer preserves logical
        # ownership without giving Blender a selected bone for its native
        # transform gizmo to draw.
        _pin_deselect_pose_bones(
            context,
            active_armature = target_data[1],
            active_pose_bone = target_data[2],
        )
    _state["pin_gizmo_selection_keys"] = _pin_pose_selection_signature(context)
    if changed:
        _tag_redraw_all_view3d()
    return True


def _pin_deselect_target():
    if not str(_state.get("pin_gizmo_selected_key", "")):
        _state["pin_gizmo_pending_click"] = None
        return False
    _state["pin_gizmo_selected_key"] = ""
    _state["pin_gizmo_pending_click"] = None
    _state["pin_gizmo_selection_epoch"] = int(
        _state.get("pin_gizmo_selection_epoch", 0)
    ) + 1
    _state["pin_gizmo_axes_visible"] = {}
    _state["pin_gizmo_selection_keys"] = ()
    _state["pin_gizmo_extend_selection_until"] = 0.0
    _tag_redraw_all_view3d()
    return True


def _pin_gizmo_claim_pointer(event):
    _state["pin_gizmo_claim_serial"] = int(
        _state.get("pin_gizmo_claim_serial", 0)
    ) + 1
    _state["pin_gizmo_pending_click"] = None
    _state["pin_gizmo_last_claim"] = (
        int(getattr(getattr(bpy.context, "window", None), "as_pointer", lambda: 0)()),
        int(getattr(event, "mouse_x", -2147483648)),
        int(getattr(event, "mouse_y", -2147483648)),
        float(time.perf_counter()),
    )


def _pin_gizmo_saved_axes_visible(group, target_key = None):
    key = str(
        target_key
        if target_key is not None
        else getattr(group, "active_target_key", "")
    )
    if not key:
        return bool(getattr(group, "axes_visible", False))
    if key != _pin_selected_target_key():
        return False
    return bool(_state.setdefault("pin_gizmo_axes_visible", {}).get(key, True))


def _pin_gizmo_set_axes_visible(group, visible):
    if group is None:
        return
    visible = bool(visible)
    group.axes_visible = visible
    key = str(getattr(group, "active_target_key", ""))
    if key:
        _state.setdefault("pin_gizmo_axes_visible", {})[key] = visible


def _pin_gizmo_selected_target_keys(context):
    key = _pin_selected_target_key(context, validate = True)
    return (key,) if key else ()


def _pin_gizmo_track_selection(context, preserve_visibility = False):
    if (
        preserve_visibility
        or _state.get("pin_history_active", False)
        or _state.get("pin_target_dragging", False)
        or _state.get("pin_keyboard_transform_active", False)
    ):
        # History evaluation and undoable gizmo commits can expose a transient
        # empty context. Do not consume the uninterrupted-selection baseline.
        return False
    selected = _pin_selected_target_key()
    if not selected:
        _state["pin_gizmo_selection_keys"] = ()
        return False
    extend_until = float(
        _state.get("pin_gizmo_extend_selection_until", 0.0)
    )
    if extend_until > 0.0:
        # Shift-click selection is completed by Blender after our pass-through
        # keymap item. Accept each intermediate signature until it settles.
        _state["pin_gizmo_selection_keys"] = _pin_pose_selection_signature(
            context
        )
        if time.perf_counter() < extend_until:
            return False
        _state["pin_gizmo_extend_selection_until"] = 0.0
    try:
        valid = selected in _pin_available_target_data(context)
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        valid = False
    if valid:
        current_signature = _pin_pose_selection_signature(context)
        saved_signature = _state.get("pin_gizmo_selection_keys", ())
        if saved_signature and current_signature != saved_signature:
            return _pin_deselect_target()
        _state["pin_gizmo_selection_keys"] = current_signature
        return False
    return _pin_deselect_target()


def _pin_gizmo_begin_interaction(gizmo, event, context = None):
    group = _pin_gizmo_group(gizmo)
    _pin_gizmo_claim_pointer(event)
    target_key = str(getattr(gizmo, "target_key", ""))
    gizmo.extend_selection = bool(getattr(event, "shift", False))
    if target_key and context is not None:
        _pin_select_target(
            context,
            target_key,
            extend = gizmo.extend_selection,
            # Changing Pose selection while Blender's C-side gizmo-tweak
            # operator owns this gizmo can rebuild its gizmo map underneath
            # that modal operator. Finalize exclusive pin selection after the
            # tweak handler has returned instead.
            defer_pose_selection = True,
        )
    if group is not None and target_key:
        group.active_target_key = target_key
        _pin_gizmo_set_axes_visible(group, True)
    gizmo.initial_mouse = (
        float(event.mouse_region_x),
        float(event.mouse_region_y),
    )
    gizmo.drag_started = False
    gizmo.axes_were_visible = _pin_gizmo_saved_axes_visible(group)
    if group is None:
        return
    axis_index = int(getattr(gizmo, "axis_index", -1))
    group.center_dragging = False
    if axis_index >= 0:
        group.active_axis_index = axis_index
    else:
        group.active_axis_index = -1


def _pin_gizmo_drag_ready(gizmo, event):
    if bool(getattr(gizmo, "drag_started", False)):
        return True
    initial_mouse = Vector(getattr(gizmo, "initial_mouse", (0.0, 0.0)))
    current_mouse = Vector(
        (float(event.mouse_region_x), float(event.mouse_region_y))
    )
    if (current_mouse - initial_mouse).length < PIN_GIZMO_DRAG_PIXEL_THRESHOLD:
        return False
    gizmo.drag_started = True
    group = _pin_gizmo_group(gizmo)
    if group is not None:
        axis_index = int(getattr(gizmo, "axis_index", -1))
        if axis_index >= 0:
            group.active_axis_index = axis_index
        else:
            group.center_dragging = True
    _tag_redraw_all_view3d()
    return True


def _pin_gizmo_finish_interaction(gizmo, cancel):
    group = _pin_gizmo_group(gizmo)
    if group is None:
        return
    axis_index = int(getattr(gizmo, "axis_index", -1))
    group.active_axis_index = -1
    group.center_dragging = False
    if str(getattr(group, "active_target_key", "")) == _pin_selected_target_key():
        _pin_gizmo_set_axes_visible(group, True)


def _pin_gizmo_push_undo_step(message):
    """Push legacy Gizmo undo only after the native modal handler returns."""
    message = str(message)
    try:
        if not bpy.ops.ed.undo_push.poll():
            print(
                "[Roblox Animator Utils] Legacy pin undo was requested but "
                f"ed.undo_push is unavailable: {message}"
            )
            return False
        return "FINISHED" in bpy.ops.ed.undo_push(message = message)
    except (AttributeError, RuntimeError, TypeError, ValueError) as exc:
        print(
            "[Roblox Animator Utils] Legacy pin undo failed for "
            f"{message}: {exc}"
        )
        return False


def _pin_gizmo_configure_undo(gizmo, enabled, legacy_message = ""):
    """Use native Gizmo undo when available, otherwise request safe fallback."""
    enabled = bool(enabled)
    try:
        gizmo.use_undo = enabled
        return ""
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        # Blender 4.2-4.3 do not expose Gizmo.use_undo to Python. Their undo
        # step is pushed by our zero-delay post-modal timer instead.
        return str(legacy_message) if enabled else ""


def _pin_gizmo_run_deferred_finishes():
    """Finish pin clicks after Blender releases its native tweak handler."""
    pending = list(_state.get("pin_gizmo_deferred_finishes", ()))
    _state["pin_gizmo_deferred_finishes"] = []
    context = bpy.context
    for item in pending:
        message = str(item.get("undo_message", ""))
        if message:
            _pin_gizmo_push_undo_step(message)

        target_key = str(item.get("target_key", ""))
        if (
            bool(item.get("extend_selection", False))
            or not target_key
            or target_key != _pin_selected_target_key()
            or context is None
            or getattr(context, "mode", "") != "POSE"
        ):
            continue
        armature = _armature_from_session_uid(
            int(item.get("armature_uid", 0))
        )
        if armature is None:
            armature = bpy.data.objects.get(str(item.get("armature_name", "")))
        pose_bone = (
            armature.pose.bones.get(str(item.get("bone_name", "")))
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is None or armature not in _pose_scope_armatures(context):
            continue
        _pin_deselect_pose_bones(
            context,
            active_armature = armature,
            active_pose_bone = pose_bone,
        )
        # This selection change belongs to the pin click itself, so it must
        # become the new baseline instead of looking like a later click-away.
        _state["pin_gizmo_selection_keys"] = _pin_pose_selection_signature(
            context
        )
    _tag_redraw_all_view3d()
    return None


def _pin_gizmo_defer_finish(gizmo, target_data, undo_message = ""):
    """Queue work that must not run from Gizmo.exit's C modal stack."""
    armature = target_data[1] if target_data else None
    pose_bone = target_data[2] if target_data else None
    _state.setdefault("pin_gizmo_deferred_finishes", []).append({
        "target_key": str(getattr(gizmo, "target_key", "")),
        "armature_uid": _armature_session_uid(armature),
        "armature_name": armature.name if armature is not None else "",
        "bone_name": pose_bone.name if pose_bone is not None else "",
        "extend_selection": bool(
            getattr(gizmo, "extend_selection", False)
        ),
        "undo_message": str(undo_message),
    })
    try:
        if not bpy.app.timers.is_registered(_pin_gizmo_run_deferred_finishes):
            bpy.app.timers.register(
                _pin_gizmo_run_deferred_finishes,
                first_interval = 0.0,
            )
    except (AttributeError, ReferenceError, RuntimeError, ValueError) as exc:
        # Never let timer setup unwind through Blender's native
        # gizmo_tweak_modal stack. Stale finalizers are more dangerous than a
        # skipped selection/legacy-undo finish because they could affect a
        # later, unrelated pin interaction.
        discarded = len(_state.get("pin_gizmo_deferred_finishes", ()))
        _state["pin_gizmo_deferred_finishes"] = []
        print(
            "[Roblox Animator Utils] Pin post-modal finalization could not "
            f"be scheduled; discarded {discarded} pending action(s): {exc}"
        )


def _pin_gizmo_test_select(gizmo, context, location):
    if bool(getattr(gizmo, "hide", False)) or bool(
        getattr(gizmo, "hide_select", False)
    ):
        return -1
    region = getattr(context, "region", None)
    region_data = getattr(context, "region_data", None)
    if region is None or region_data is None:
        return -1
    from bpy_extras import view3d_utils

    try:
        point = gizmo.matrix_world @ Vector((0.0, 0.0, 0.0))
    except (AttributeError, ReferenceError, RuntimeError):
        point = gizmo.matrix_basis.translation.copy()
    point_2d = view3d_utils.location_3d_to_region_2d(
        region,
        region_data,
        point,
    )
    if point_2d is None:
        return -1
    mouse = Vector((float(location[0]), float(location[1])))
    is_contact = str(getattr(gizmo, "target_key", "")).startswith(
        "CONTACT:"
    )
    center_radius = 20.0 if is_contact else 13.0
    if int(getattr(gizmo, "axis_index", -1)) < 0:
        distance = (mouse - point_2d).length
        return 0 if distance <= center_radius else -1

    if (mouse - point_2d).length <= center_radius + 2.0:
        # The free-drag target owns its whole center hit area; an overlapping
        # arrow must not steal an exact-center or near-center click.
        return -1

    try:
        end_point = gizmo.matrix_world @ Vector((0.0, 0.0, 1.0))
    except (AttributeError, ReferenceError, RuntimeError):
        axis = Vector(getattr(gizmo, "axis_world", (0.0, 0.0, 1.0)))
        if axis.length_squared <= 1.0e-12:
            return -1
        axis.normalize()
        end_point = point + (axis * PIN_GIZMO_AXIS_SCALE)
    end_2d = view3d_utils.location_3d_to_region_2d(
        region,
        region_data,
        end_point,
    )
    if end_2d is None:
        return -1
    segment = end_2d - point_2d
    length_squared = segment.length_squared
    if length_squared <= 1.0e-8:
        return -1
    factor = max(0.18, min(1.15, (mouse - point_2d).dot(segment) / length_squared))
    closest = point_2d + (segment * factor)
    distance = (mouse - closest).length
    return 0 if distance <= 8.0 else -1


class STATICALIZA_GT_surface_contact_target(bpy.types.Gizmo):
    bl_idname = "STATICALIZA_GT_surface_contact_target"

    __slots__ = (
        "diamond_shape",
        "arrow_shape",
        "target_key",
        "guide_name",
        "axis_index",
        "axis_world",
        "axis_locked",
        "locked_axes",
        "orientation_basis",
        "axis_offset",
        "initial_matrix",
        "initial_solver_matrix",
        "initial_simulated_pose_matrix",
        "initial_point",
        "initial_normal",
        "initial_local_matrix",
        "initial_mouse",
        "extend_selection",
        "axes_were_visible",
        "drag_started",
        "interaction_valid",
        "moved",
    )

    def setup(self):
        if not hasattr(self, "diamond_shape"):
            self.diamond_shape = self.new_custom_shape(
                "TRIS",
                _PIN_GIZMO_DIAMOND_VERTICES,
            )
            self.arrow_shape = self.new_custom_shape(
                "TRIS",
                _PIN_MOVE_ARROW_VERTICES,
            )

    def draw(self, context):
        shape = self.arrow_shape if getattr(self, "axis_index", -1) >= 0 else self.diamond_shape
        self.draw_custom_shape(shape)

    def test_select(self, context, location):
        return _pin_gizmo_test_select(self, context, location)

    def invoke(self, context, event):
        self.interaction_valid = False
        _pin_gizmo_configure_undo(self, False)
        if bool(getattr(self, "axis_locked", False)):
            return {"CANCELLED"}
        target_key = str(getattr(self, "target_key", ""))
        target_data = _pin_available_target_data(context).get(target_key)
        guide = bpy.data.objects.get(str(getattr(self, "guide_name", "")))
        if (
            guide is None
            or target_data is None
            or target_data[0] != "CONTACT"
            or target_data[3] != guide
            or (
                getattr(self, "axis_index", -1) >= 0
                and target_key != _pin_selected_target_key()
            )
        ):
            return {"CANCELLED"}
        _state["pin_target_dragging"] = True
        _pin_gizmo_begin_interaction(self, event, context)
        self.initial_matrix = guide.matrix_world.copy()
        self.orientation_basis = _pin_transform_orientation_matrix(
            context,
            target_data,
            self.initial_matrix,
        )
        solver = _surface_contact_solver_from_guide(guide)
        self.initial_solver_matrix = (
            solver.matrix_world.copy() if solver is not None else None
        )
        self.initial_simulated_pose_matrix = (
            _surface_contact_simulated_pose_matrix(guide)
        )
        self.initial_point = tuple(guide.get(SURFACE_CONTACT_POINT_PROPERTY, ()))
        self.initial_normal = tuple(guide.get(SURFACE_CONTACT_NORMAL_PROPERTY, ()))
        self.initial_local_matrix = tuple(
            guide.get(SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY, ())
        )
        self.axis_offset = Vector((0.0, 0.0, 0.0))
        if getattr(self, "axis_index", -1) >= 0:
            axis_point = _pin_gizmo_axis_mouse_point(
                context,
                guide.matrix_world.translation,
                self.axis_world,
                (event.mouse_region_x, event.mouse_region_y),
            )
            if axis_point is not None:
                self.axis_offset = guide.matrix_world.translation - axis_point
        else:
            plane_point = _pin_gizmo_mouse_plane_point(
                context,
                guide.matrix_world.translation,
                (event.mouse_region_x, event.mouse_region_y),
            )
            if plane_point is not None:
                self.axis_offset = guide.matrix_world.translation - plane_point
        self.moved = False
        self.interaction_valid = True
        return {"RUNNING_MODAL"}

    def modal(self, context, event, tweak):
        if not bool(getattr(self, "interaction_valid", False)):
            return {"CANCELLED"}
        guide = bpy.data.objects.get(str(getattr(self, "guide_name", "")))
        if guide is None:
            return {"CANCELLED"}
        if not _pin_gizmo_drag_ready(self, event):
            return {"RUNNING_MODAL"}
        if getattr(self, "axis_index", -1) >= 0:
            axis_point = _pin_gizmo_axis_mouse_point(
                context,
                self.initial_matrix.translation,
                self.axis_world,
                (event.mouse_region_x, event.mouse_region_y),
            )
            candidate = axis_point + self.axis_offset if axis_point is not None else None
            if candidate is not None:
                candidate = _pin_gizmo_apply_axis_locks(
                    candidate,
                    self.initial_matrix.translation,
                    getattr(self, "locked_axes", (False, False, False)),
                    getattr(self, "orientation_basis", Matrix.Identity(3)),
                )
            if (
                candidate is not None
                and (Vector(candidate) - guide.matrix_world.translation).length > 1.0e-6
                and _surface_contact_move_guide_world(context, guide, candidate)
            ):
                self.moved = True
            return {"RUNNING_MODAL"}
        else:
            result = _surface_contact_mouse_surface_point(
                context,
                guide,
                (event.mouse_region_x, event.mouse_region_y),
            )
            if result is None:
                plane_point = _pin_gizmo_mouse_plane_point(
                    context,
                    self.initial_matrix.translation,
                    (event.mouse_region_x, event.mouse_region_y),
                )
                result = (
                    _surface_contact_axis_surface_point(
                        context,
                        guide,
                        plane_point + self.axis_offset,
                    )
                    if plane_point is not None
                    else None
                )
        if result is not None:
            locked_point = _pin_gizmo_apply_axis_locks(
                result[0],
                self.initial_matrix.translation,
                getattr(self, "locked_axes", (False, False, False)),
                getattr(self, "orientation_basis", Matrix.Identity(3)),
            )
            result = _surface_contact_axis_surface_point(
                context,
                guide,
                locked_point,
            )
        if result is not None and _surface_contact_move_guide_to_surface(
            context,
            guide,
            result[0],
            result[1],
        ):
            self.moved = True
        return {"RUNNING_MODAL"}

    def exit(self, context, cancel):
        if not bool(getattr(self, "interaction_valid", False)):
            _tag_redraw_all_view3d()
            return
        _pin_gizmo_finish_interaction(self, cancel)
        guide = bpy.data.objects.get(str(getattr(self, "guide_name", "")))
        if guide is None:
            _state["pin_target_dragging"] = False
            return
        target_data = _pin_available_target_data(context).get(
            str(getattr(self, "target_key", ""))
        )
        try:
            if cancel:
                guide.matrix_world = self.initial_matrix
                if self.initial_point:
                    guide[SURFACE_CONTACT_POINT_PROPERTY] = self.initial_point
                if self.initial_normal:
                    guide[SURFACE_CONTACT_NORMAL_PROPERTY] = self.initial_normal
                if self.initial_local_matrix:
                    guide[SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY] = (
                        self.initial_local_matrix
                    )
                solver = _surface_contact_solver_from_guide(guide)
                if solver is not None and self.initial_solver_matrix is not None:
                    solver.matrix_world = self.initial_solver_matrix
                _surface_contact_restore_simulated_pose(
                    context,
                    guide,
                    self.initial_simulated_pose_matrix,
                    update_view_layer = False,
                )
            if self.moved and not cancel:
                try:
                    _surface_contact_commit_target_key(context, guide)
                except (
                    AttributeError,
                    ReferenceError,
                    RuntimeError,
                    TypeError,
                    ValueError,
                ) as exc:
                    print(
                        "[Roblox Animator Utils] Contact target commit failed: "
                        f"{exc}"
                    )
            # Never call an operator or rebuild Pose selection from Gizmo.exit:
            # Blender's native gizmo_tweak_modal still owns this RNA gizmo
            # until exit returns. The zero-delay timer runs on the next event
            # loop iteration, after that C-side pointer has been released.
            # `use_undo` asks Blender to push the settled state itself, after
            # this callback returns; nesting ed.undo_push here is unsafe.
            undo_message = _pin_gizmo_configure_undo(
                self,
                self.moved and not cancel,
                "Move Contact Pin",
            )
            _pin_gizmo_defer_finish(self, target_data, undo_message)
        finally:
            _state["pin_target_dragging"] = False
            _tag_redraw_all_view3d()


class STATICALIZA_GGT_surface_contact_target(bpy.types.GizmoGroup):
    bl_idname = "STATICALIZA_GGT_surface_contact_target"
    bl_label = "Surface Contact Target"
    bl_space_type = "VIEW_3D"
    bl_region_type = "WINDOW"
    bl_options = {"3D", "SELECT", "PERSISTENT", "SHOW_MODAL_ALL"}

    @classmethod
    def poll(cls, context):
        _pin_gizmo_track_selection(context)
        # Keep the group alive throughout Pose Mode. Selection, history, and
        # depsgraph evaluation can briefly invalidate the selected guide while
        # Blender still has one of this group's gizmos highlighted. The draw
        # pass disables both drawing and picking when no valid target exists.
        return getattr(context, "mode", "") == "POSE"

    def setup(self, context):
        self.target_gizmos = {}
        self.target_gizmo = None
        self.target_gizmo_pool = []
        for _index in range(PIN_GIZMO_TARGET_POOL_SIZE):
            gizmo = self.gizmos.new(
                STATICALIZA_GT_surface_contact_target.bl_idname
            )
            gizmo.axis_index = -1
            gizmo.color = SURFACE_CONTACT_HOT_PINK[:3]
            gizmo.color_highlight = (1.0, 0.45, 1.0)
            gizmo.alpha_highlight = 0.36
            gizmo.select_bias = 0.0
            gizmo.use_draw_modal = True
            gizmo.hide = True
            gizmo.hide_select = True
            self.target_gizmo_pool.append(gizmo)
        self.axis_gizmos = []
        for axis_index, color in enumerate(
            ((0.95, 0.18, 0.16), (0.30, 0.80, 0.18), (0.18, 0.42, 1.0))
        ):
            axis_gizmo = self.gizmos.new(
                STATICALIZA_GT_surface_contact_target.bl_idname
            )
            axis_gizmo.axis_index = axis_index
            axis_gizmo.color = color
            axis_gizmo.alpha = 0.75
            axis_gizmo.color_highlight = color
            axis_gizmo.alpha_highlight = 1.0
            axis_gizmo.select_bias = 0.0
            axis_gizmo.use_draw_modal = True
            self.axis_gizmos.append(axis_gizmo)
        self.active_target_key = ""
        self.axes_visible = False
        self.active_axis_index = -1
        self.center_dragging = False

    def draw_prepare(self, context):
        _pin_gizmo_track_selection(context)
        targets = {
            key: data
            for key, data in _pin_available_target_data(context).items()
            if data[0] == "CONTACT"
        }
        selected_key = _pin_selected_target_key()
        modal_active = bool(
            _state.get("pin_target_dragging", False)
            and selected_key
            and str(getattr(self, "active_target_key", "")) == selected_key
        )
        if modal_active and selected_key not in targets:
            # Let the gizmo's next modal callback cancel cleanly. Rebinding or
            # hiding it here would invalidate Blender's active C gizmo pointer.
            return
        if (
            _state.get("pin_history_active", False)
            and selected_key.startswith("CONTACT:")
            and selected_key not in targets
            and selected_key in self.target_gizmos
        ):
            for gizmo in self.target_gizmos.values():
                gizmo.hide_select = True
            for axis_gizmo in self.axis_gizmos:
                axis_gizmo.hide_select = True
            return
        modal_center = (
            self.target_gizmos.get(selected_key)
            if modal_active and int(self.active_axis_index) < 0
            else None
        )
        for pooled_gizmo in self.target_gizmo_pool:
            if pooled_gizmo != modal_center:
                pooled_gizmo.hide = True
                pooled_gizmo.hide_select = True
            if not modal_active:
                pooled_gizmo.select = False
        _pin_gizmo_stable_target_mapping(self, targets)
        for target_key in sorted(targets):
            gizmo = self.target_gizmos.get(target_key)
            if gizmo is None:
                continue
            target_data = targets[target_key]
            guide = target_data[3]
            gizmo.target_key = target_key
            gizmo.guide_name = guide.name
            gizmo.locked_axes = _pin_target_locked_axes(target_data)
            if gizmo != modal_center:
                gizmo.hide = False
                gizmo.hide_select = False
            gizmo.alpha = 0.36
            gizmo.matrix_basis = _pin_gizmo_center_matrix(
                guide.matrix_world.translation
            )
            gizmo.scale_basis = PIN_GIZMO_DIAMOND_SCALE

        target_data = targets.get(selected_key)
        if self.active_target_key != (selected_key if target_data else ""):
            self.active_target_key = selected_key if target_data else ""
            self.active_axis_index = -1
            self.center_dragging = False
            for axis_gizmo in self.axis_gizmos:
                axis_gizmo.select = False
        self.target_gizmo = self.target_gizmos.get(selected_key)
        self.axes_visible = bool(target_data)
        show_axes = bool(target_data and not self.center_dragging)
        guide = target_data[3] if target_data else None
        point = (
            guide.matrix_world.translation.copy()
            if guide
            else Vector((0.0, 0.0, 0.0))
        )
        locked_axes = _pin_target_locked_axes(target_data)
        orientation_basis = _pin_transform_orientation_matrix(
            context,
            target_data,
            guide.matrix_world if guide is not None else None,
        )
        for axis_index, axis_gizmo in enumerate(self.axis_gizmos):
            modal_axis = bool(
                modal_active and int(self.active_axis_index) == axis_index
            )
            axis = orientation_basis.col[axis_index].copy()
            if axis.length_squared <= 1.0e-12:
                axis = Vector((0.0, 0.0, 1.0))
            axis.normalize()
            if not modal_axis:
                axis_gizmo.hide = not show_axes
            if not show_axes and not modal_axis:
                axis_gizmo.select = False
            axis_gizmo.target_key = selected_key if target_data else ""
            axis_gizmo.guide_name = guide.name if guide else ""
            axis_gizmo.axis_world = tuple(axis)
            axis_gizmo.axis_locked = bool(locked_axes[axis_index])
            axis_gizmo.locked_axes = locked_axes
            if not modal_axis:
                axis_gizmo.hide_select = bool(
                    not show_axes or locked_axes[axis_index]
                )
            axis_gizmo.alpha = (
                PIN_GIZMO_LOCKED_ALPHA
                if locked_axes[axis_index]
                else 0.82
            )
            axis_gizmo.alpha_highlight = (
                PIN_GIZMO_LOCKED_ALPHA
                if locked_axes[axis_index]
                else 1.0
            )
            axis_gizmo.matrix_basis = _pin_gizmo_axis_matrix(point, axis)
            axis_gizmo.scale_basis = PIN_GIZMO_AXIS_SCALE


def _yellow_selected_pin(context):
    if context.mode != "POSE":
        return None, None, None
    pose_bone = _single_active_pose_bone(context)
    armature = _pose_bone_owner(context, pose_bone)
    if armature is None or _yellow_owner_hidden(armature):
        return None, None, None
    packed = (
        _state.get("yellow_fixed", {}).get(
            _owner_bone_key(armature, pose_bone.name)
        )
        if pose_bone is not None
        else None
    )
    if armature is None or pose_bone is None or not packed:
        return None, None, None
    return armature, pose_bone, packed


def _yellow_pin_surface_excluded_names(context, armature, pose_bone):
    excluded = {armature.name}
    try:
        depsgraph = context.evaluated_depsgraph_get()
        evaluated_armature = armature.evaluated_get(depsgraph)
        evaluated_bone = evaluated_armature.pose.bones.get(pose_bone.name)
        if evaluated_bone is not None:
            family_names = _surface_contact_bone_family_names(
                evaluated_armature,
                evaluated_bone,
            )
            excluded.update(
                obj.name
                for obj in _surface_contact_connected_objects(
                    context,
                    armature,
                    family_names,
                )
            )
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        pass
    return tuple(sorted(excluded))


def _yellow_set_pin_target(armature, bone_name, point):
    fixed = dict(_state.get("yellow_fixed", {}))
    key = _owner_bone_key(armature, bone_name)
    packed = fixed.get(key)
    if not packed:
        return False
    point = Vector(point)
    if (point - Vector(packed[0])).length <= 1.0e-8:
        return False
    values = list(packed)
    values[0] = point.copy()
    fixed[key] = tuple(values)
    _state["yellow_fixed"] = fixed
    return True


def _yellow_store_target_property(armature, bone_name, point):
    pose_bone = (
        armature.pose.bones.get(str(bone_name))
        if armature is not None and getattr(armature, "pose", None)
        else None
    )
    if pose_bone is None:
        return False
    pose_bone[YELLOW_PIN_TARGET_PROPERTY] = tuple(
        float(value) for value in Vector(point)
    )
    return True


def _yellow_clear_target_property(armature, bone_name):
    pose_bone = (
        armature.pose.bones.get(str(bone_name))
        if armature is not None and getattr(armature, "pose", None)
        else None
    )
    if pose_bone is None or YELLOW_PIN_TARGET_PROPERTY not in pose_bone:
        return False
    try:
        del pose_bone[YELLOW_PIN_TARGET_PROPERTY]
        return True
    except (KeyError, TypeError):
        return False


def _yellow_sync_targets_from_properties(context):
    if not _state.get("yellow_fixed"):
        return False
    fixed = dict(_state.get("yellow_fixed", {}))
    changed = False
    for key, packed in tuple(fixed.items()):
        owner_uid, bone_name = key
        armature = _armature_from_session_uid(owner_uid)
        if armature is None or getattr(armature, "pose", None) is None:
            continue
        pose_bone = armature.pose.bones.get(str(bone_name))
        stored = (
            pose_bone.get(YELLOW_PIN_TARGET_PROPERTY)
            if pose_bone is not None
            else None
        )
        if stored is None:
            stored = _state.setdefault(
                "pin_yellow_history_fallbacks",
                {},
            ).get(key)
        if stored is None or len(stored) < 3:
            continue
        point = Vector(tuple(float(value) for value in stored[:3]))
        if (point - Vector(packed[0])).length <= 1.0e-8:
            continue
        values = list(packed)
        values[0] = point
        fixed[key] = tuple(values)
        changed = True
    if changed:
        _state["yellow_fixed"] = fixed
        _yellow_refresh_runtime(context)
    return changed


def _clear_pin_history_visibility():
    context = bpy.context
    try:
        _yellow_sync_targets_from_properties(context)
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        pass
    # Undo and redo are allowed to restore Blender's pose selection without
    # treating that history-owned change as a click away from the virtual pin.
    # Native Gizmo undo is pushed before our post-modal selection timer runs,
    # so re-apply pin-only selection when that was the saved runtime state.
    selected_key = _pin_selected_target_key()
    saved_signature = _state.get("pin_gizmo_selection_keys", ())
    exclusive_pin = bool(
        selected_key
        and len(saved_signature) >= 2
        and not tuple(saved_signature[1])
    )
    if exclusive_pin and context is not None:
        target_data = _pin_available_target_data(context).get(selected_key)
        if target_data is not None:
            _pin_deselect_pose_bones(
                context,
                active_armature = target_data[1],
                active_pose_bone = target_data[2],
            )
    if selected_key:
        _state["pin_gizmo_selection_keys"] = _pin_pose_selection_signature(
            context
        )
    _state["pin_history_active"] = False
    if context is not None and _pin_gizmo_track_selection(context):
        _tag_redraw_all_view3d()
    return None


def _schedule_pin_history_visibility_clear():
    if bpy.app.timers.is_registered(_clear_pin_history_visibility):
        bpy.app.timers.unregister(_clear_pin_history_visibility)
    try:
        bpy.app.timers.register(
            _clear_pin_history_visibility,
            first_interval = 0.1,
        )
    except (RuntimeError, ValueError):
        _state["pin_history_active"] = False


def _pin_click_away_timer():
    pending = _state.get("pin_gizmo_pending_click")
    if not pending:
        return None
    if _state.get("pin_history_active", False):
        return 0.05
    _state["pin_gizmo_pending_click"] = None
    if (
        _state.get("pin_target_dragging", False)
        or _state.get("pin_keyboard_transform_active", False)
    ):
        return None
    key, epoch, claim_serial = pending
    if (
        str(_state.get("pin_gizmo_selected_key", "")) == str(key)
        and int(_state.get("pin_gizmo_selection_epoch", 0)) == int(epoch)
        and int(_state.get("pin_gizmo_claim_serial", 0)) == int(claim_serial)
    ):
        _pin_deselect_target()
    return None


class STATICALIZA_OT_pin_click_away(bpy.types.Operator):
    bl_idname = "staticaliza.pin_click_away"
    bl_label = "Deselect Pin"
    bl_description = "Clear pin selection while preserving Blender's normal click action"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        return (
            getattr(context, "mode", "") == "POSE"
            and getattr(getattr(context, "area", None), "type", "") == "VIEW_3D"
        )

    def invoke(self, context, event):
        selected_key = _pin_selected_target_key()
        if not selected_key:
            return {"PASS_THROUGH"}
        window_pointer = int(context.window.as_pointer()) if context.window else 0
        mouse_x = int(getattr(event, "mouse_x", -2147483648))
        mouse_y = int(getattr(event, "mouse_y", -2147483648))
        last_claim = _state.get("pin_gizmo_last_claim")
        if (
            last_claim
            and int(last_claim[0]) == window_pointer
            and int(last_claim[1]) == mouse_x
            and int(last_claim[2]) == mouse_y
            and time.perf_counter() - float(last_claim[3]) <= 0.1
        ):
            return {"PASS_THROUGH"}
        if bool(getattr(event, "shift", False)):
            # Let Blender add/toggle bones without consuming the virtual pin.
            # Selection events settle after this pass-through operator, so the
            # tracker temporarily accepts each intermediate signature.
            _state["pin_gizmo_extend_selection_until"] = (
                time.perf_counter() + 0.25
            )
            _state["pin_gizmo_selection_keys"] = ()
            return {"PASS_THROUGH"}
        _state["pin_gizmo_pending_click"] = (
            selected_key,
            int(_state.get("pin_gizmo_selection_epoch", 0)),
            int(_state.get("pin_gizmo_claim_serial", 0)),
        )
        if bpy.app.timers.is_registered(_pin_click_away_timer):
            bpy.app.timers.unregister(_pin_click_away_timer)
        try:
            bpy.app.timers.register(_pin_click_away_timer, first_interval = 0.0)
        except (RuntimeError, ValueError):
            _pin_click_away_timer()
        return {"PASS_THROUGH"}


def _pin_keyboard_target_matrix(target_data):
    if target_data is None:
        return None
    kind, armature, pose_bone, payload = target_data
    if kind == "CONTACT":
        return payload.matrix_world.copy()
    matrix = (
        (armature.matrix_world @ pose_bone.matrix).normalized()
        if armature is not None and pose_bone is not None
        else Matrix.Identity(4)
    )
    matrix.translation = Vector(payload[0])
    return matrix


def _pin_keyboard_orientation_matrix(context, target_data, pin_matrix):
    return _pin_transform_orientation_matrix(
        context,
        target_data,
        pin_matrix,
    )


def _pin_keyboard_view_axis(context):
    region_data = getattr(context, "region_data", None)
    if region_data is None:
        return Vector((0.0, 0.0, 1.0))
    axis = region_data.view_matrix.inverted_safe().to_3x3() @ Vector(
        (0.0, 0.0, 1.0)
    )
    return axis.normalized() if axis.length_squared > 1.0e-12 else Vector(
        (0.0, 0.0, 1.0)
    )


def _pin_keyboard_pivot(context, pin_matrix, armature, bone_states):
    if (
        getattr(
            getattr(context, "window_manager", None),
            "staticaliza_pivot_mode",
            "BONE",
        ) == "PART"
    ):
        # Object pivot mode is independent of Blender's last generic pivot
        # enum. Its matched object center remains the pivot for pin-only and
        # combined pin+bone rotation/scale transforms.
        try:
            if _sync_part_pivot(context):
                part = bpy.data.objects.get(
                    str(_state.get("part_pivot_object", ""))
                )
                local_center = _state.get("part_pivot_object_local")
                if part is not None and local_center is not None:
                    evaluated_part = part.evaluated_get(
                        context.evaluated_depsgraph_get()
                    )
                    world_center = (
                        evaluated_part.matrix_world @ _as_p4(local_center)
                    )
                    return Vector(world_center[:3]), False
                return context.scene.cursor.location.copy(), False
        except (
            AttributeError,
            ReferenceError,
            RuntimeError,
            TypeError,
            ValueError,
        ):
            pass
    pivot_mode = str(context.scene.tool_settings.transform_pivot_point)
    pin_point = pin_matrix.translation.copy()
    if pivot_mode == "CURSOR":
        return context.scene.cursor.location.copy(), False
    if pivot_mode in {"ACTIVE_ELEMENT", "INDIVIDUAL_ORIGINS"}:
        return pin_point, pivot_mode == "INDIVIDUAL_ORIGINS"

    points = [pin_point]
    for state in bone_states.values():
        points.append((armature.matrix_world @ state["matrix"]).translation)
    if pivot_mode == "BOUNDING_BOX_CENTER" and points:
        lower = Vector((
            min(point.x for point in points),
            min(point.y for point in points),
            min(point.z for point in points),
        ))
        upper = Vector((
            max(point.x for point in points),
            max(point.y for point in points),
            max(point.z for point in points),
        ))
        return (lower + upper) * 0.5, False
    return sum(points, Vector((0.0, 0.0, 0.0))) / len(points), False


def _pin_keyboard_around_origin(core_matrix, origin):
    return (
        Matrix.Translation(Vector(origin))
        @ core_matrix
        @ Matrix.Translation(-Vector(origin))
    )


def _pin_keyboard_matrix_changed(matrix, epsilon = 1.0e-9):
    identity = Matrix.Identity(4)
    return any(
        abs(float(matrix[row][column]) - float(identity[row][column])) > epsilon
        for row in range(4)
        for column in range(4)
    )


def _pin_keyboard_matrices_differ(first, second, epsilon = 1.0e-7):
    if first is None or second is None:
        return first is not second
    return any(
        abs(float(first[row][column]) - float(second[row][column])) > epsilon
        for row in range(4)
        for column in range(4)
    )


def _pin_keyboard_apply_contact_matrix(
    context,
    guide,
    desired_matrix,
    solver_matrix = None,
):
    normal = desired_matrix.to_3x3().inverted_safe().transposed() @ Vector(
        (0.0, 0.0, 1.0)
    )
    if normal.length_squared <= 1.0e-12:
        normal = desired_matrix.to_3x3().col[2]
    if normal.length_squared <= 1.0e-12:
        normal = Vector((0.0, 0.0, 1.0))
    normal.normalize()
    _surface_contact_clear_snap_departure(guide)
    reference_matrix = desired_matrix.normalized()
    reference_matrix.translation = desired_matrix.translation
    guide.matrix_world = reference_matrix
    if not _surface_contact_set_guide_surface_point(
        context,
        guide,
        desired_matrix.translation,
        normal,
    ):
        return False
    solver = _surface_contact_solver_from_guide(guide)
    if solver is not None and solver_matrix is not None:
        solver.matrix_world = solver_matrix
    context.view_layer.update()
    return True


def _pin_keyboard_apply_pose_locks(pose_bone, state, transform_mode):
    if transform_mode == "TRANSLATE":
        for index, locked in enumerate(tuple(pose_bone.lock_location[:3])):
            if locked:
                pose_bone.location[index] = state["location"][index]
    elif transform_mode == "SCALE":
        for index, locked in enumerate(tuple(pose_bone.lock_scale[:3])):
            if locked:
                pose_bone.scale[index] = state["scale"][index]
    elif transform_mode == "ROTATE":
        locked_axes = tuple(bool(value) for value in pose_bone.lock_rotation[:3])
        if pose_bone.rotation_mode == "QUATERNION":
            current = pose_bone.rotation_quaternion.copy()
            initial = state["rotation_quaternion"].copy()
            if bool(getattr(pose_bone, "lock_rotations_4d", False)):
                if bool(getattr(pose_bone, "lock_rotation_w", False)):
                    current.w = initial.w
                for index, locked in enumerate(locked_axes):
                    if locked:
                        current[index + 1] = initial[index + 1]
                if sum(float(value) * float(value) for value in current) > 1.0e-12:
                    current.normalize()
                pose_bone.rotation_quaternion = current
            elif any(locked_axes):
                initial_euler = initial.to_euler("XYZ")
                current_euler = current.to_euler("XYZ", initial_euler)
                for index, locked in enumerate(locked_axes):
                    if locked:
                        current_euler[index] = initial_euler[index]
                pose_bone.rotation_quaternion = current_euler.to_quaternion()
        elif pose_bone.rotation_mode == "AXIS_ANGLE":
            current_values = list(pose_bone.rotation_axis_angle)
            initial_values = state["rotation_axis_angle"]
            if bool(getattr(pose_bone, "lock_rotations_4d", False)):
                if bool(getattr(pose_bone, "lock_rotation_w", False)):
                    current_values[0] = initial_values[0]
                for index, locked in enumerate(locked_axes):
                    if locked:
                        current_values[index + 1] = initial_values[index + 1]
                pose_bone.rotation_axis_angle = current_values
            elif any(locked_axes):
                current_axis = Vector(current_values[1:4])
                initial_axis = Vector(initial_values[1:4])
                if current_axis.length_squared <= 1.0e-12:
                    current_axis = Vector((0.0, 1.0, 0.0))
                if initial_axis.length_squared <= 1.0e-12:
                    initial_axis = Vector((0.0, 1.0, 0.0))
                current = Quaternion(current_axis.normalized(), current_values[0])
                initial = Quaternion(initial_axis.normalized(), initial_values[0])
                initial_euler = initial.to_euler("XYZ")
                current_euler = current.to_euler("XYZ", initial_euler)
                for index, locked in enumerate(locked_axes):
                    if locked:
                        current_euler[index] = initial_euler[index]
                locked_quaternion = current_euler.to_quaternion()
                pose_bone.rotation_axis_angle = (
                    locked_quaternion.angle,
                    *locked_quaternion.axis,
                )
        else:
            for index, locked in enumerate(locked_axes):
                if locked:
                    pose_bone.rotation_euler[index] = state["rotation_euler"][index]


class STATICALIZA_OT_transform_selected_pin(bpy.types.Operator):
    bl_idname = "staticaliza.transform_selected_pin"
    bl_label = "Transform Selected Pin"
    bl_description = "Transform the selected pin together with selected pose bones"
    bl_options = {"REGISTER", "UNDO", "BLOCKING"}

    transform_mode: bpy.props.EnumProperty(
        items = (
            ("TRANSLATE", "Move", "Move the selected pin"),
            ("ROTATE", "Rotate", "Rotate the selected pin"),
            ("SCALE", "Scale", "Scale the selected pin around the current pivot"),
        ),
        options = {"HIDDEN", "SKIP_SAVE"},
    )

    @classmethod
    def poll(cls, context):
        return (
            getattr(context, "mode", "") == "POSE"
            and getattr(getattr(context, "area", None), "type", "") == "VIEW_3D"
        )

    def _header_text(self, context):
        label = {
            "TRANSLATE": "Move",
            "ROTATE": "Rotate",
            "SCALE": "Scale",
        }[self.transform_mode]
        constraint = (
            ""
            if self.axis_index < 0
            else f" {('X', 'Y', 'Z')[self.axis_index]}"
        )
        try:
            context.area.header_text_set(
                f"{label} Pin{constraint}: move mouse, X/Y/Z constrain, "
                "Left Click/Enter confirm, Right Click/Esc cancel"
            )
        except (AttributeError, RuntimeError):
            pass

    def _clear_header(self, context):
        try:
            context.area.header_text_set(None)
        except (AttributeError, RuntimeError):
            pass

    def _release_modal_state(self, context):
        self._clear_header(context)
        _state["pin_keyboard_transform_active"] = False
        _state["pin_target_dragging"] = False
        _pin_clear_transform_state()
        _tag_redraw_all_view3d()

    def _restore_initial(self, context):
        target_data = _pin_available_target_data(context).get(self.target_key)
        armature = (
            target_data[1]
            if target_data is not None
            else bpy.data.objects.get(str(getattr(self, "armature_name", "")))
        )
        kind = str(getattr(self, "target_kind", ""))
        payload = (
            target_data[3]
            if target_data is not None and target_data[0] == "CONTACT"
            else bpy.data.objects.get(
                str(getattr(self, "contact_guide_name", ""))
            )
        )
        if kind == "YELLOW":
            fixed = dict(_state.get("yellow_fixed", {}))
            fixed[_owner_bone_key(armature, self.target_bone_name)] = tuple(
                value.copy() if hasattr(value, "copy") else value
                for value in self.initial_yellow_packed
            )
            _state["yellow_fixed"] = fixed
            pose_bone = (
                armature.pose.bones.get(self.target_bone_name)
                if armature is not None and getattr(armature, "pose", None)
                else None
            )
            if pose_bone is not None:
                if self.initial_yellow_property_exists:
                    pose_bone[YELLOW_PIN_TARGET_PROPERTY] = (
                        self.initial_yellow_property
                    )
                elif YELLOW_PIN_TARGET_PROPERTY in pose_bone:
                    del pose_bone[YELLOW_PIN_TARGET_PROPERTY]
        elif payload is not None:
            guide = payload
            guide.matrix_world = self.initial_pin_matrix.copy()
            if self.initial_contact_point_exists:
                guide[SURFACE_CONTACT_POINT_PROPERTY] = self.initial_contact_point
            elif SURFACE_CONTACT_POINT_PROPERTY in guide:
                del guide[SURFACE_CONTACT_POINT_PROPERTY]
            if self.initial_contact_normal_exists:
                guide[SURFACE_CONTACT_NORMAL_PROPERTY] = self.initial_contact_normal
            elif SURFACE_CONTACT_NORMAL_PROPERTY in guide:
                del guide[SURFACE_CONTACT_NORMAL_PROPERTY]
            if self.initial_contact_local_matrix_exists:
                guide[SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY] = (
                    self.initial_contact_local_matrix
                )
            elif SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY in guide:
                del guide[SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY]
            solver = _surface_contact_solver_from_guide(guide)
            if solver is not None and self.initial_solver_matrix is not None:
                solver.matrix_world = self.initial_solver_matrix.copy()
            _surface_contact_restore_simulated_pose(
                context,
                guide,
                self.initial_simulated_pose_matrix,
                update_view_layer = False,
            )

        if armature is not None and getattr(armature, "pose", None):
            for bone_name in self.bone_order:
                state = self.bone_states[bone_name]
                pose_bone = armature.pose.bones.get(bone_name)
                if pose_bone is not None:
                    pose_bone.matrix_basis = state["matrix_basis"].copy()
        try:
            context.view_layer.update()
        except (AttributeError, RuntimeError):
            pass
        return bool(armature is not None or payload is not None)

    def _mouse_transform(self, context, event):
        mouse = (float(event.mouse_region_x), float(event.mouse_region_y))
        if self.transform_mode == "TRANSLATE":
            if self.axis_index >= 0:
                axis = self.orientation.col[self.axis_index].normalized()
                start = _pin_gizmo_axis_mouse_point(
                    context,
                    self.pivot,
                    axis,
                    self.initial_mouse,
                )
                current = _pin_gizmo_axis_mouse_point(
                    context,
                    self.pivot,
                    axis,
                    mouse,
                )
                delta = (
                    axis * (current - start).dot(axis)
                    if start is not None and current is not None
                    else Vector((0.0, 0.0, 0.0))
                )
            else:
                start = _pin_gizmo_mouse_plane_point(
                    context,
                    self.pivot,
                    self.initial_mouse,
                )
                current = _pin_gizmo_mouse_plane_point(
                    context,
                    self.pivot,
                    mouse,
                )
                delta = (
                    current - start
                    if start is not None and current is not None
                    else Vector((0.0, 0.0, 0.0))
                )
            if event.shift:
                delta *= 0.1
            if event.ctrl:
                for index in range(3):
                    delta[index] = round(float(delta[index]) * 10.0) / 10.0
            return Matrix.Translation(delta)

        from bpy_extras import view3d_utils

        center = view3d_utils.location_3d_to_region_2d(
            context.region,
            context.region_data,
            self.pivot,
        )
        if center is None:
            return Matrix.Identity(4)
        start_vector = Vector(self.initial_mouse) - center
        current_vector = Vector(mouse) - center
        if self.transform_mode == "ROTATE":
            if self.mouse_started_at_pivot:
                mouse_delta = Vector(mouse) - Vector(self.initial_mouse)
                angle = (mouse_delta.x + mouse_delta.y) * 0.01
            elif start_vector.length_squared <= 1.0e-8 or current_vector.length_squared <= 1.0e-8:
                angle = 0.0
            else:
                angle = math.atan2(
                    (start_vector.x * current_vector.y)
                    - (start_vector.y * current_vector.x),
                    start_vector.dot(current_vector),
                )
            if event.shift:
                angle *= 0.1
            if event.ctrl:
                increment = math.radians(5.0)
                angle = round(angle / increment) * increment
            axis = (
                self.orientation.col[self.axis_index].normalized()
                if self.axis_index >= 0
                else _pin_keyboard_view_axis(context)
            )
            return Matrix.Rotation(angle, 4, axis)

        if self.mouse_started_at_pivot:
            mouse_delta = Vector(mouse) - Vector(self.initial_mouse)
            factor = 1.0 + ((mouse_delta.x + mouse_delta.y) * 0.01)
        else:
            start_distance = max(1.0e-6, start_vector.length)
            factor = current_vector.length / start_distance
            if start_vector.dot(current_vector) < 0.0:
                factor = -factor
        if event.shift:
            factor = 1.0 + ((factor - 1.0) * 0.1)
        if event.ctrl:
            factor = round(factor * 10.0) / 10.0
        factors = [factor, factor, factor]
        if self.axis_index >= 0:
            factors = [1.0, 1.0, 1.0]
            factors[self.axis_index] = factor
        oriented_scale = (
            self.orientation.to_4x4()
            @ Matrix.Diagonal((*factors, 1.0))
            @ self.orientation.inverted_safe().to_4x4()
        )
        return oriented_scale

    def _apply(self, context, event):
        if not self._restore_initial(context):
            return False
        target_data = _pin_available_target_data(context).get(self.target_key)
        if target_data is None:
            return False
        kind, armature, _connected_bone, payload = target_data
        core_matrix = self._mouse_transform(context, event)
        shared_delta = _pin_keyboard_around_origin(core_matrix, self.pivot)

        for bone_name in self.bone_order:
            state = self.bone_states[bone_name]
            pose_bone = armature.pose.bones.get(bone_name)
            if pose_bone is None:
                continue
            origin = (
                (armature.matrix_world @ state["matrix"]).translation
                if self.individual_origins and self.transform_mode != "TRANSLATE"
                else self.pivot
            )
            delta = (
                _pin_keyboard_around_origin(core_matrix, origin)
                if self.individual_origins and self.transform_mode != "TRANSLATE"
                else shared_delta
            )
            world_matrix = armature.matrix_world @ state["matrix"]
            pose_bone.matrix = armature.matrix_world.inverted_safe() @ (
                delta @ world_matrix
            )
            _pin_keyboard_apply_pose_locks(
                pose_bone,
                state,
                self.transform_mode,
            )
        context.view_layer.update()

        pin_origin = (
            self.initial_pin_matrix.translation
            if self.individual_origins and self.transform_mode != "TRANSLATE"
            else self.pivot
        )
        pin_delta = (
            _pin_keyboard_around_origin(core_matrix, pin_origin)
            if self.individual_origins and self.transform_mode != "TRANSLATE"
            else shared_delta
        )
        desired_matrix = pin_delta @ self.initial_pin_matrix
        locked_axes = _pin_target_locked_axes(target_data)
        if self.transform_mode == "TRANSLATE":
            desired_matrix.translation = _pin_gizmo_apply_axis_locks(
                desired_matrix.translation,
                self.initial_pin_matrix.translation,
                locked_axes,
                self.orientation,
            )

        if kind == "YELLOW":
            changed = _yellow_set_pin_target(
                armature,
                self.target_bone_name,
                desired_matrix.translation,
            )
            _yellow_store_target_property(
                armature,
                self.target_bone_name,
                desired_matrix.translation,
            )
        else:
            if self.bone_states or self.transform_mode != "TRANSLATE":
                solver_matrix = (
                    pin_delta @ self.initial_solver_matrix
                    if self.initial_solver_matrix is not None
                    else None
                )
                if solver_matrix is not None and self.transform_mode == "SCALE":
                    transformed_translation = solver_matrix.translation.copy()
                    solver_matrix = self.initial_solver_matrix.copy()
                    solver_matrix.translation = transformed_translation
                changed = _pin_keyboard_apply_contact_matrix(
                    context,
                    payload,
                    desired_matrix,
                    solver_matrix = solver_matrix,
                )
            else:
                normal = desired_matrix.to_3x3().col[2]
                changed = _surface_contact_move_guide_to_surface(
                    context,
                    payload,
                    desired_matrix.translation,
                    normal,
                )
            if not changed:
                changed = (
                    desired_matrix.translation
                    - self.initial_pin_matrix.translation
                ).length <= 1.0e-7
        context.view_layer.update()
        if kind == "YELLOW":
            current = _state.get("yellow_fixed", {}).get(
                _owner_bone_key(armature, self.target_bone_name)
            )
            pin_changed = bool(
                current
                and (
                    Vector(current[0]) - self.initial_pin_matrix.translation
                ).length > 1.0e-7
            )
        else:
            pin_changed = _pin_keyboard_matrices_differ(
                payload.matrix_world,
                self.initial_pin_matrix,
            )
            solver = _surface_contact_solver_from_guide(payload)
            if solver is not None and self.initial_solver_matrix is not None:
                pin_changed = pin_changed or _pin_keyboard_matrices_differ(
                    solver.matrix_world,
                    self.initial_solver_matrix,
                )
            simulated_pose = _surface_contact_simulated_pose_matrix(payload)
            if (
                simulated_pose is not None
                and self.initial_simulated_pose_matrix is not None
            ):
                pin_changed = pin_changed or _pin_keyboard_matrices_differ(
                    simulated_pose,
                    self.initial_simulated_pose_matrix,
                )
        bone_changed = any(
            (
                (pose_bone := armature.pose.bones.get(bone_name)) is not None
                and _pin_keyboard_matrices_differ(
                    pose_bone.matrix_basis,
                    self.bone_states[bone_name]["matrix_basis"],
                )
            )
            for bone_name in self.bone_order
        )
        self.changed = bool(pin_changed or bone_changed)
        _tag_redraw_all_view3d()
        return True

    def invoke(self, context, event):
        self.target_key, target_data = _pin_selected_target_data(context)
        if not self.target_key or target_data is None:
            return {"PASS_THROUGH"}
        kind, armature, pose_bone, payload = target_data
        self.initial_pin_matrix = _pin_keyboard_target_matrix(target_data)
        if self.initial_pin_matrix is None:
            return {"PASS_THROUGH"}
        self.target_kind = kind
        self.armature_name = armature.name
        self.contact_guide_name = payload.name if kind == "CONTACT" else ""
        self.target_bone_name = pose_bone.name if pose_bone is not None else ""
        self.initial_yellow_packed = None
        self.initial_yellow_property_exists = False
        self.initial_yellow_property = ()
        self.initial_contact_point = ()
        self.initial_contact_point_exists = False
        self.initial_contact_normal = ()
        self.initial_contact_normal_exists = False
        self.initial_contact_local_matrix = ()
        self.initial_contact_local_matrix_exists = False
        self.initial_solver_matrix = None
        self.initial_simulated_pose_matrix = None
        if kind == "YELLOW":
            self.initial_yellow_packed = tuple(
                value.copy() if hasattr(value, "copy") else value
                for value in payload
            )
            self.initial_yellow_property_exists = bool(
                pose_bone is not None
                and YELLOW_PIN_TARGET_PROPERTY in pose_bone
            )
            if self.initial_yellow_property_exists:
                self.initial_yellow_property = tuple(
                    pose_bone[YELLOW_PIN_TARGET_PROPERTY]
                )
        else:
            self.initial_contact_point_exists = (
                SURFACE_CONTACT_POINT_PROPERTY in payload
            )
            self.initial_contact_point = tuple(
                payload.get(SURFACE_CONTACT_POINT_PROPERTY, ())
            )
            self.initial_contact_normal_exists = (
                SURFACE_CONTACT_NORMAL_PROPERTY in payload
            )
            self.initial_contact_normal = tuple(
                payload.get(SURFACE_CONTACT_NORMAL_PROPERTY, ())
            )
            self.initial_contact_local_matrix_exists = (
                SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY in payload
            )
            self.initial_contact_local_matrix = tuple(
                payload.get(SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY, ())
            )
            solver = _surface_contact_solver_from_guide(payload)
            self.initial_solver_matrix = (
                solver.matrix_world.copy() if solver is not None else None
            )
            self.initial_simulated_pose_matrix = (
                _surface_contact_simulated_pose_matrix(payload)
            )

        selected_bones = list(
            _selected_pose_bones_by_owner(context).get(armature, ())
        )

        def hierarchy_depth(selected_bone):
            depth = 0
            parent = selected_bone.parent
            while parent is not None:
                depth += 1
                parent = parent.parent
            return depth

        selected_bones.sort(key = hierarchy_depth)
        self.bone_states = {}
        self.bone_order = []
        for selected_bone in selected_bones:
            self.bone_order.append(selected_bone.name)
            self.bone_states[selected_bone.name] = {
                "matrix": selected_bone.matrix.copy(),
                "matrix_basis": selected_bone.matrix_basis.copy(),
                "location": selected_bone.location.copy(),
                "rotation_euler": selected_bone.rotation_euler.copy(),
                "rotation_quaternion": selected_bone.rotation_quaternion.copy(),
                "rotation_axis_angle": tuple(selected_bone.rotation_axis_angle),
                "scale": selected_bone.scale.copy(),
            }
        self.pivot, self.individual_origins = _pin_keyboard_pivot(
            context,
            self.initial_pin_matrix,
            armature,
            self.bone_states,
        )
        self.orientation = _pin_keyboard_orientation_matrix(
            context,
            target_data,
            self.initial_pin_matrix,
        )
        self.initial_mouse = (
            float(event.mouse_region_x),
            float(event.mouse_region_y),
        )
        self.mouse_started_at_pivot = False
        try:
            from bpy_extras import view3d_utils

            pivot_2d = view3d_utils.location_3d_to_region_2d(
                context.region,
                context.region_data,
                self.pivot,
            )
            self.mouse_started_at_pivot = bool(
                pivot_2d is not None
                and (Vector(self.initial_mouse) - pivot_2d).length <= 4.0
            )
        except (AttributeError, RuntimeError, TypeError, ValueError):
            pass
        self.axis_index = -1
        self.changed = False
        _state["pin_keyboard_transform_active"] = True
        _state["pin_target_dragging"] = True
        _state["pin_gizmo_pending_click"] = None
        context.window_manager.modal_handler_add(self)
        self._header_text(context)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        if event.type in {"ESC", "RIGHTMOUSE"} and event.value == "PRESS":
            try:
                self._restore_initial(context)
            finally:
                self._release_modal_state(context)
            return {"CANCELLED"}
        if event.type in {"LEFTMOUSE", "RET", "NUMPAD_ENTER", "SPACE"} and event.value == "PRESS":
            target_data = _pin_available_target_data(context).get(self.target_key)
            if target_data is None:
                try:
                    self._restore_initial(context)
                finally:
                    self._release_modal_state(context)
                return {"CANCELLED"}
            if not self.changed:
                try:
                    self._restore_initial(context)
                finally:
                    self._release_modal_state(context)
                return {"CANCELLED"}
            kind, armature, _pose_bone, payload = target_data
            try:
                if kind == "YELLOW":
                    current = _state.get("yellow_fixed", {}).get(
                        _owner_bone_key(armature, self.target_bone_name)
                    )
                    if current:
                        _yellow_store_target_property(
                            armature,
                            self.target_bone_name,
                            current[0],
                        )
                        _yellow_refresh_runtime(context)
                else:
                    _surface_contact_commit_target_key(context, payload)
                if bool(
                    getattr(context.scene.tool_settings, "use_keyframe_insert_auto", False)
                ):
                    frame = int(context.scene.frame_current)
                    for bone_name in self.bone_order:
                        pose_bone = armature.pose.bones.get(bone_name)
                        if pose_bone is not None:
                            _insert_bone_keys(pose_bone, frame)
            except Exception as exc:
                print(f"[Roblox Animator Utils] Pin transform commit failed: {exc}")
                try:
                    self._restore_initial(context)
                finally:
                    self._release_modal_state(context)
                return {"CANCELLED"}
            self._release_modal_state(context)
            return {"FINISHED" if self.changed else "CANCELLED"}
        if event.value == "PRESS" and event.type in {"X", "Y", "Z"}:
            axis_index = {"X": 0, "Y": 1, "Z": 2}[event.type]
            self.axis_index = -1 if self.axis_index == axis_index else axis_index
            self._header_text(context)
            try:
                if not self._apply(context, event):
                    raise RuntimeError("The selected pin is no longer available")
            except Exception as exc:
                print(f"[Roblox Animator Utils] Pin transform cancelled: {exc}")
                try:
                    self._restore_initial(context)
                finally:
                    self._release_modal_state(context)
                return {"CANCELLED"}
            return {"RUNNING_MODAL"}
        if event.type == "MOUSEMOVE":
            try:
                if not self._apply(context, event):
                    raise RuntimeError("The selected pin is no longer available")
            except Exception as exc:
                print(f"[Roblox Animator Utils] Pin transform cancelled: {exc}")
                try:
                    self._restore_initial(context)
                finally:
                    self._release_modal_state(context)
                return {"CANCELLED"}
            return {"RUNNING_MODAL"}
        return {"RUNNING_MODAL"}

    def cancel(self, context):
        try:
            self._restore_initial(context)
        finally:
            self._release_modal_state(context)


def _surface_contact_history_snapshot(context):
    scene = getattr(context, "scene", None) if context is not None else None
    if scene is None:
        return {"targets": {}, "engaged": set(), "selected": set()}
    targets = {}
    engaged = set()
    selected = set()
    depsgraph = context.evaluated_depsgraph_get()
    for guide in _surface_contact_active_simulated_guides(scene):
        armature = bpy.data.objects.get(
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
        )
        owner_key = (_armature_session_uid(armature), guide.name)
        try:
            evaluated = guide.evaluated_get(depsgraph)
            matrix = evaluated.matrix_world.copy()
        except (AttributeError, ReferenceError, RuntimeError):
            matrix = guide.matrix_world.copy()
        targets[owner_key] = tuple(
            round(float(value), 8)
            for row in matrix
            for value in row
        )
        if _surface_contact_guide_directly_selected(context, guide):
            selected.add(owner_key)
        target, _normal, anchor = _surface_contact_world_point_normal(
            context,
            guide,
        )
        tolerance = max(
            1.0e-6,
            float(guide.get(SURFACE_CONTACT_SIZE_PROPERTY, 0.05)) * 1.0e-5,
        )
        if (
            target is not None
            and anchor is not None
            and (Vector(target) - Vector(anchor)).length <= tolerance
            and _surface_contact_snap_key(guide)
            not in _state.setdefault("pin_snap_departing", set())
            and _surface_contact_snap_key(guide)
            not in _state.setdefault("pin_snap_detached", set())
        ):
            engaged.add(owner_key)
    return {"targets": targets, "engaged": engaged, "selected": selected}


@persistent
def _pin_history_pre(*_):
    # Gizmo groups can be rebuilt before undo_post/redo_post. Mark history up
    # front so that rebuilds preserve runtime-only handle visibility.
    _state["pin_history_active"] = True
    _state["pin_history_syncing"] = True
    if bpy.app.timers.is_registered(_clear_pin_history_visibility):
        bpy.app.timers.unregister(_clear_pin_history_visibility)
    try:
        _state["pin_history_contact_snapshot"] = (
            _surface_contact_history_snapshot(bpy.context)
        )
    except (
        AttributeError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ) as exc:
        print(f"[Roblox Animator Utils] Pin history snapshot skipped: {exc}")
        _state["pin_history_contact_snapshot"] = {
            "targets": {},
            "engaged": set(),
            "selected": set(),
        }


@persistent
def _pin_undo_post(*_):
    _state["pin_history_active"] = True
    _state["pin_history_syncing"] = True
    try:
        context = bpy.context
        _state["pin_target_dragging"] = False
        _pin_clear_transform_state()
        _yellow_sync_targets_from_properties(context)
        # Finish history evaluation and restore active contacts before Blender
        # can redraw the transient Action pose.
        context.view_layer.update()
        # Blender restores guide ID properties as part of undo/redo, while the
        # runtime latch is intentionally not in history. Rebuild saved latches
        # before deciding whether a changed target should be force-solved.
        _surface_contact_restore_snap_detached(
            context,
            infer_missing = False,
            reset_runtime = True,
        )
        previous_snapshot = (
            _state.get("pin_history_contact_snapshot")
            or {"targets": {}, "engaged": set(), "selected": set()}
        )
        current_snapshot = _surface_contact_history_snapshot(context)
        previous_targets = previous_snapshot.get("targets", {})
        current_targets = current_snapshot.get("targets", {})
        # Preserve the semantic state of a manual endpoint move across
        # history. Undoing back onto an unchanged target re-engages it; redoing
        # the same move away records a detach instead of force-solving it back.
        history_departure_changed = False
        previous_engaged = set(previous_snapshot.get("engaged", set()))
        for guide in _surface_contact_active_simulated_guides(context.scene):
            armature = bpy.data.objects.get(
                str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
            )
            owner_key = (_armature_session_uid(armature), guide.name)
            if previous_targets.get(owner_key) != current_targets.get(owner_key):
                continue
            target, _normal, anchor = _surface_contact_world_point_normal(
                context,
                guide,
            )
            if target is None or anchor is None:
                continue
            tolerance = max(
                1.0e-6,
                float(guide.get(SURFACE_CONTACT_SIZE_PROPERTY, 0.05))
                * 1.0e-5,
            )
            if (Vector(target) - Vector(anchor)).length <= tolerance:
                _surface_contact_clear_snap_departure(guide)
                history_departure_changed = True
            elif owner_key in previous_engaged:
                snap_key = _surface_contact_snap_key(guide)
                _state.setdefault("pin_snap_departing", set()).discard(
                    snap_key
                )
                _state.setdefault("pin_snap_transform_seen", set()).discard(
                    snap_key
                )
                _state.setdefault("pin_snap_latches", set()).discard(snap_key)
                _surface_contact_set_snap_detached(guide, True)
                history_departure_changed = True
        if history_departure_changed:
            current_snapshot = _surface_contact_history_snapshot(context)
            current_targets = current_snapshot.get("targets", {})
        detached_owner_keys = set()
        detached_snap_keys = _state.setdefault("pin_snap_detached", set())
        for guide in _surface_contact_active_simulated_guides(context.scene):
            if _surface_contact_snap_key(guide) not in detached_snap_keys:
                continue
            armature = bpy.data.objects.get(
                str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
            )
            detached_owner_keys.add(
                (_armature_session_uid(armature), guide.name)
            )
        force_keys = {
            key
            for key, signature in current_targets.items()
            if (
                previous_targets.get(key) != signature
                and key not in detached_owner_keys
            )
        }
        force_names = {str(key[1]) for key in force_keys}
        _sync_surface_contact_constraints(
            context.scene,
            respect_selected = True,
            force_unselected = False,
            force_guide_names = force_names,
        )
        # Marker maintenance may settle later, but it must never perform a
        # second SIMULATED pose correction on a separate event-loop tick.
        _schedule_dynamic_space_reconcile(0.15)
        _schedule_pin_history_visibility_clear()
        _refresh_roblox_armature_list(context, force = True)
        _tag_redraw_all_view3d()
    except (
        AttributeError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ) as exc:
        print(f"[Roblox Animator Utils] Pin history sync failed: {exc}")
        _state["pin_history_active"] = False
    finally:
        _state["pin_history_contact_snapshot"] = None
        _state["pin_history_syncing"] = False


class STATICALIZA_OT_move_pin_target(bpy.types.Operator):
    bl_idname = "staticaliza.move_pin_target"
    bl_label = "Move Pin Target"
    bl_description = "Move the selected pin target with an undoable displacement"
    bl_options = {"REGISTER", "UNDO"}

    pin_kind: bpy.props.EnumProperty(
        items = (
            ("CONTACT", "Contact", ""),
            ("YELLOW", "Onion Pin", ""),
        ),
        options = {"HIDDEN", "SKIP_SAVE"},
    )
    armature_name: bpy.props.StringProperty(
        options = {"HIDDEN", "SKIP_SAVE"},
    )
    target_name: bpy.props.StringProperty(
        options = {"HIDDEN", "SKIP_SAVE"},
    )
    surface_name: bpy.props.StringProperty(
        options = {"HIDDEN", "SKIP_SAVE"},
    )
    surface_constrained: bpy.props.BoolProperty(
        default = True,
        options = {"HIDDEN", "SKIP_SAVE"},
    )
    base_location: bpy.props.FloatVectorProperty(
        size = 3,
        subtype = "TRANSLATION",
        options = {"HIDDEN", "SKIP_SAVE"},
    )
    displacement: bpy.props.FloatVectorProperty(
        name = "Displacement",
        description = "World-space offset from the pin's position before this move",
        size = 3,
        subtype = "TRANSLATION",
        unit = "LENGTH",
    )

    def draw(self, context):
        self.layout.prop(self, "displacement")

    def execute(self, context):
        candidate = Vector(self.base_location) + Vector(self.displacement)
        if self.pin_kind == "CONTACT":
            guide = bpy.data.objects.get(str(self.target_name))
            if guide is None:
                self.report({"ERROR"}, "The Contact target no longer exists.")
                return {"CANCELLED"}
            current = guide.matrix_world.translation.copy()
            if self.surface_constrained:
                result = _surface_contact_axis_surface_point(
                    context,
                    guide,
                    candidate,
                )
                if result is None:
                    self.report({"ERROR"}, "No point was found on the Contact surface.")
                    return {"CANCELLED"}
                candidate = Vector(result[0])
                moved = (
                    _surface_contact_move_guide_to_surface(
                        context,
                        guide,
                        candidate,
                        result[1],
                    )
                    or (candidate - current).length <= 1.0e-6
                )
            else:
                moved = (
                    _surface_contact_move_guide_world(context, guide, candidate)
                    or (candidate - current).length <= 1.0e-6
                )
            if not moved:
                self.report({"ERROR"}, "Unable to move the Contact target.")
                return {"CANCELLED"}
            _surface_contact_commit_target_key(context, guide)
            return {"FINISHED"}

        armature = bpy.data.objects.get(str(self.armature_name))
        pose_bone = (
            armature.pose.bones.get(str(self.target_name))
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        packed = _state.get("yellow_fixed", {}).get(
            _owner_bone_key(armature, self.target_name)
        )
        if armature is None or pose_bone is None or not packed:
            self.report({"ERROR"}, "The Onion Pin target no longer exists.")
            return {"CANCELLED"}
        current = Vector(packed[0])
        moved = (
            _yellow_set_pin_target(armature, pose_bone.name, candidate)
            or (candidate - current).length <= 1.0e-6
        )
        if not moved:
            return {"CANCELLED"}
        _yellow_store_target_property(armature, pose_bone.name, candidate)
        _yellow_refresh_runtime(context)
        return {"FINISHED"}


def _pin_parent_world_matrix(armature, pose_bone):
    if armature is None:
        return Matrix.Identity(4)
    if pose_bone is not None and pose_bone.parent is not None:
        return armature.matrix_world @ pose_bone.parent.matrix
    return armature.matrix_world.copy()


def _pin_clipboard_capture(context):
    grouped = _selected_pose_bones_by_owner(context)
    if not grouped:
        return None
    frame = int(context.scene.frame_current)
    owners = []
    for armature, pose_bones in grouped.items():
        entries = []
        for pose_bone in pose_bones:
            parent_world = _pin_parent_world_matrix(armature, pose_bone)
            parent_inverse = parent_world.inverted_safe()
            packed = _state.get("yellow_fixed", {}).get(
                _owner_bone_key(armature, pose_bone.name)
            )
            if packed:
                entries.append({
                    "kind": "YELLOW",
                    "bone_name": pose_bone.name,
                    "parent_name": (
                        pose_bone.parent.name if pose_bone.parent else ""
                    ),
                    "local_offset": tuple(parent_inverse @ Vector(packed[0])),
                })
            contact_guides = _surface_contact_guides_for_selected_bone(
                armature,
                pose_bone,
                frame,
            )
            if contact_guides:
                guide = max(
                    contact_guides,
                    key = lambda item: int(
                        item.get(
                            SURFACE_CONTACT_START_PROPERTY,
                            SPACE_MIN_FRAME,
                        )
                    ),
                )
                entries.append({
                    "kind": "CONTACT",
                    "bone_name": pose_bone.name,
                    "parent_name": (
                        pose_bone.parent.name if pose_bone.parent else ""
                    ),
                    "local_offset": tuple(
                        parent_inverse @ guide.matrix_world.translation
                    ),
                })
        owners.append({
            "session_uid": _armature_session_uid(armature),
            "armature_name": armature.name,
            "entries": entries,
        })
    return {"owners": owners}


def _pin_flipped_name(name):
    try:
        return bpy.utils.flip_name(str(name), strip_digits = False)
    except (AttributeError, TypeError):
        return str(name)


def _pin_clipboard_apply(context, flipped = False):
    clipboard = _state.get("pin_clipboard")
    scope = _pose_scope_armatures(context)
    if not clipboard or not scope:
        return 0
    frame = int(context.scene.frame_current)
    changed = 0
    owner_entries = tuple(clipboard.get("owners", ()))
    if not owner_entries and "entries" in clipboard:
        owner_entries = ({
            "session_uid": 0,
            "armature_name": str(clipboard.get("armature_name", "")),
            "entries": tuple(clipboard.get("entries", ())),
        },)
    scope_by_uid = {
        _armature_session_uid(armature): armature for armature in scope
    }
    scope_by_name = {armature.name: armature for armature in scope}
    for owner_entry in owner_entries:
        armature = scope_by_uid.get(int(owner_entry.get("session_uid", 0)))
        if armature is None:
            armature = scope_by_name.get(str(owner_entry.get("armature_name", "")))
        if armature is None and len(owner_entries) == 1 and len(scope) == 1:
            armature = scope[0]
        if armature is None:
            continue
        for entry in owner_entry.get("entries", ()):
            source_name = str(entry.get("bone_name", ""))
            target_name = _pin_flipped_name(source_name) if flipped else source_name
            pose_bone = armature.pose.bones.get(target_name)
            if pose_bone is None:
                continue
            local_offset = Vector(
                tuple(entry.get("local_offset", (0.0, 0.0, 0.0)))
            )
            if flipped:
                local_offset.x = -local_offset.x
            target = _pin_parent_world_matrix(armature, pose_bone) @ local_offset

            if str(entry.get("kind", "")) == "YELLOW":
                packed = _state.get("yellow_fixed", {}).get(
                    _owner_bone_key(armature, target_name)
                )
                if not packed:
                    continue
                if _yellow_set_pin_target(armature, target_name, target):
                    _yellow_store_target_property(armature, target_name, target)
                    changed += 1
                continue

            guides = _surface_contact_guides_for_selected_bone(
                armature,
                pose_bone,
                frame,
            )
            if not guides:
                continue
            guide = max(
                guides,
                key = lambda item: int(
                    item.get(SURFACE_CONTACT_START_PROPERTY, SPACE_MIN_FRAME)
                ),
            )
            result = _surface_contact_axis_surface_point(context, guide, target)
            if result is None:
                continue
            current = guide.matrix_world.translation.copy()
            if (
                (Vector(result[0]) - current).length <= 1.0e-6
                or _surface_contact_move_guide_to_surface(
                    context,
                    guide,
                    result[0],
                    result[1],
                )
            ):
                _surface_contact_commit_target_key(context, guide)
                changed += 1
    if changed:
        _yellow_refresh_runtime(context)
        context.view_layer.update()
        _tag_redraw_all_view3d()
    return changed


class STATICALIZA_OT_pose_pin_clipboard(bpy.types.Operator):
    bl_idname = "staticaliza.pose_pin_clipboard"
    bl_label = "Pose and Pin Clipboard"
    bl_description = "Copy or paste the pose and its pin targets"
    bl_options = {"REGISTER", "UNDO"}

    action: bpy.props.EnumProperty(
        items = (
            ("COPY", "Copy", ""),
            ("PASTE", "Paste", ""),
            ("PASTE_FLIPPED", "Paste Flipped", ""),
        ),
        options = {"HIDDEN", "SKIP_SAVE"},
    )

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE" and _active_armature(context) is not None

    def execute(self, context):
        if self.action == "COPY":
            try:
                bpy.ops.pose.copy()
            except RuntimeError:
                pass
            _state["pin_clipboard"] = _pin_clipboard_capture(context)
            return {"FINISHED"}

        flipped = self.action == "PASTE_FLIPPED"
        try:
            bpy.ops.pose.paste(flipped = flipped, selected_mask = False)
        except RuntimeError:
            pass
        context.view_layer.update()
        _pin_clipboard_apply(context, flipped = flipped)
        return {"FINISHED"}


class STATICALIZA_GT_yellow_pin_target(bpy.types.Gizmo):
    bl_idname = "STATICALIZA_GT_yellow_pin_target"

    __slots__ = (
        "diamond_shape",
        "arrow_shape",
        "target_key",
        "armature_name",
        "bone_name",
        "axis_index",
        "axis_world",
        "axis_locked",
        "locked_axes",
        "orientation_basis",
        "axis_offset",
        "initial_packed",
        "initial_point",
        "initial_mouse",
        "extend_selection",
        "axes_were_visible",
        "drag_started",
        "interaction_valid",
        "surface_excluded_names",
        "moved",
    )

    def setup(self):
        if not hasattr(self, "diamond_shape"):
            self.diamond_shape = self.new_custom_shape(
                "TRIS",
                _PIN_GIZMO_DIAMOND_VERTICES,
            )
            self.arrow_shape = self.new_custom_shape(
                "TRIS",
                _PIN_MOVE_ARROW_VERTICES,
            )

    def draw(self, context):
        shape = self.arrow_shape if getattr(self, "axis_index", -1) >= 0 else self.diamond_shape
        self.draw_custom_shape(shape)

    def test_select(self, context, location):
        return _pin_gizmo_test_select(self, context, location)

    def invoke(self, context, event):
        self.interaction_valid = False
        _pin_gizmo_configure_undo(self, False)
        if bool(getattr(self, "axis_locked", False)):
            return {"CANCELLED"}
        group = _pin_gizmo_group(self)
        target_key = str(getattr(self, "target_key", ""))
        target_data = _pin_available_target_data(context).get(target_key)
        if target_data is None or target_data[0] != "YELLOW":
            return {"CANCELLED"}
        _kind, armature, pose_bone, packed = target_data
        if (
            armature is None
            or pose_bone is None
            or pose_bone.name != str(getattr(self, "bone_name", ""))
            or (
                getattr(self, "axis_index", -1) >= 0
                and (
                    (
                        group is not None
                        and str(getattr(group, "active_target_key", ""))
                        != target_key
                    )
                    or target_key != _pin_selected_target_key()
                )
            )
        ):
            return {"CANCELLED"}
        _state["pin_target_dragging"] = True
        _pin_gizmo_begin_interaction(self, event, context)
        self.armature_name = armature.name
        self.initial_packed = tuple(
            value.copy() if hasattr(value, "copy") else value
            for value in packed
        )
        self.initial_point = Vector(packed[0]).copy()
        pin_matrix = (armature.matrix_world @ pose_bone.matrix).normalized()
        pin_matrix.translation = self.initial_point
        self.orientation_basis = _pin_transform_orientation_matrix(
            context,
            target_data,
            pin_matrix,
        )
        self.surface_excluded_names = _yellow_pin_surface_excluded_names(
            context,
            armature,
            pose_bone,
        )
        _yellow_store_target_property(
            armature,
            pose_bone.name,
            self.initial_point,
        )
        self.axis_offset = Vector((0.0, 0.0, 0.0))
        if getattr(self, "axis_index", -1) >= 0:
            axis_point = _pin_gizmo_axis_mouse_point(
                context,
                self.initial_point,
                self.axis_world,
                (event.mouse_region_x, event.mouse_region_y),
            )
            if axis_point is not None:
                self.axis_offset = self.initial_point - axis_point
        else:
            plane_point = _pin_gizmo_mouse_plane_point(
                context,
                self.initial_point,
                (event.mouse_region_x, event.mouse_region_y),
            )
            if plane_point is not None:
                self.axis_offset = self.initial_point - plane_point
        self.moved = False
        self.interaction_valid = True
        return {"RUNNING_MODAL"}

    def modal(self, context, event, tweak):
        if not bool(getattr(self, "interaction_valid", False)):
            return {"CANCELLED"}
        armature = bpy.data.objects.get(str(getattr(self, "armature_name", "")))
        packed = _state.get("yellow_fixed", {}).get(
            _owner_bone_key(armature, getattr(self, "bone_name", ""))
        )
        if not packed:
            return {"CANCELLED"}
        if not _pin_gizmo_drag_ready(self, event):
            return {"RUNNING_MODAL"}
        current = Vector(packed[0])
        if getattr(self, "axis_index", -1) >= 0:
            axis_point = _pin_gizmo_axis_mouse_point(
                context,
                self.initial_point,
                self.axis_world,
                (event.mouse_region_x, event.mouse_region_y),
            )
            candidate = axis_point + self.axis_offset if axis_point is not None else None
        else:
            candidate = _pin_gizmo_mouse_surface_point(
                context,
                (event.mouse_region_x, event.mouse_region_y),
                getattr(self, "surface_excluded_names", ()),
            )
        if candidate is not None:
            candidate = _pin_gizmo_apply_axis_locks(
                candidate,
                self.initial_point,
                getattr(self, "locked_axes", (False, False, False)),
                getattr(self, "orientation_basis", Matrix.Identity(3)),
            )
        if candidate is not None and (Vector(candidate) - current).length > 1.0e-6:
            self.moved = _yellow_set_pin_target(
                armature,
                self.bone_name,
                candidate,
            ) or self.moved
            _tag_redraw_all_view3d()
        return {"RUNNING_MODAL"}

    def exit(self, context, cancel):
        if not bool(getattr(self, "interaction_valid", False)):
            _tag_redraw_all_view3d()
            return
        _pin_gizmo_finish_interaction(self, cancel)
        target_data = _pin_available_target_data(context).get(
            str(getattr(self, "target_key", ""))
        )
        committed = False
        try:
            armature = bpy.data.objects.get(str(self.armature_name))
            key = _owner_bone_key(armature, self.bone_name)
            packed = _state.get("yellow_fixed", {}).get(key)
            final_location = (
                Vector(packed[0]) if packed else self.initial_point.copy()
            )
            if cancel:
                fixed = dict(_state.get("yellow_fixed", {}))
                fixed[key] = self.initial_packed
                _state["yellow_fixed"] = fixed
            if self.moved and not cancel:
                committed = _yellow_store_target_property(
                    armature,
                    str(self.bone_name),
                    final_location,
                )
                if not committed:
                    fixed = dict(_state.get("yellow_fixed", {}))
                    fixed[key] = self.initial_packed
                    _state["yellow_fixed"] = fixed
                    _yellow_store_target_property(
                        armature,
                        str(self.bone_name),
                        self.initial_point,
                    )
            undo_message = _pin_gizmo_configure_undo(
                self,
                self.moved and not cancel and committed,
                "Move Onion Pin",
            )
            _pin_gizmo_defer_finish(self, target_data, undo_message)
        finally:
            _state["pin_target_dragging"] = False
            _tag_redraw_all_view3d()


class STATICALIZA_GGT_yellow_pin_target(bpy.types.GizmoGroup):
    bl_idname = "STATICALIZA_GGT_yellow_pin_target"
    bl_label = "Onion Pin Target"
    bl_space_type = "VIEW_3D"
    bl_region_type = "WINDOW"
    bl_options = {"3D", "SELECT", "PERSISTENT", "SHOW_MODAL_ALL"}

    @classmethod
    def poll(cls, context):
        _pin_gizmo_track_selection(context)
        # Keep the gizmo map stable across transient selection/history states;
        # draw_prepare owns target visibility and hit-test availability.
        return getattr(context, "mode", "") == "POSE"

    def setup(self, context):
        self.target_gizmos = {}
        self.target_gizmo = None
        self.target_gizmo_pool = []
        for _index in range(PIN_GIZMO_TARGET_POOL_SIZE):
            gizmo = self.gizmos.new(
                STATICALIZA_GT_yellow_pin_target.bl_idname
            )
            gizmo.axis_index = -1
            gizmo.color = ONION_PIN_COLOR[:3]
            gizmo.color_highlight = (1.0, 1.0, 0.45)
            gizmo.alpha_highlight = 0.36
            gizmo.select_bias = 0.0
            gizmo.use_draw_modal = True
            gizmo.hide = True
            gizmo.hide_select = True
            self.target_gizmo_pool.append(gizmo)
        self.axis_gizmos = []
        for axis_index, color in enumerate(
            ((0.95, 0.18, 0.16), (0.30, 0.80, 0.18), (0.18, 0.42, 1.0))
        ):
            axis_gizmo = self.gizmos.new(
                STATICALIZA_GT_yellow_pin_target.bl_idname
            )
            axis_gizmo.axis_index = axis_index
            axis_gizmo.color = color
            axis_gizmo.alpha = 0.75
            axis_gizmo.color_highlight = color
            axis_gizmo.alpha_highlight = 1.0
            axis_gizmo.select_bias = 0.0
            axis_gizmo.use_draw_modal = True
            self.axis_gizmos.append(axis_gizmo)
        self.active_target_key = ""
        self.axes_visible = False
        self.active_axis_index = -1
        self.center_dragging = False

    def draw_prepare(self, context):
        _pin_gizmo_track_selection(context)
        targets = {
            key: data
            for key, data in _pin_available_target_data(context).items()
            if data[0] == "YELLOW"
        }
        selected_key = _pin_selected_target_key()
        modal_active = bool(
            _state.get("pin_target_dragging", False)
            and selected_key
            and str(getattr(self, "active_target_key", "")) == selected_key
        )
        if modal_active and selected_key not in targets:
            # Let the gizmo's next modal callback cancel cleanly. Rebinding or
            # hiding it here would invalidate Blender's active C gizmo pointer.
            return
        if (
            _state.get("pin_history_active", False)
            and selected_key.startswith("YELLOW:")
            and selected_key not in targets
            and selected_key in self.target_gizmos
        ):
            for gizmo in self.target_gizmos.values():
                gizmo.hide_select = True
            for axis_gizmo in self.axis_gizmos:
                axis_gizmo.hide_select = True
            return
        modal_center = (
            self.target_gizmos.get(selected_key)
            if modal_active and int(self.active_axis_index) < 0
            else None
        )
        for pooled_gizmo in self.target_gizmo_pool:
            if pooled_gizmo != modal_center:
                pooled_gizmo.hide = True
                pooled_gizmo.hide_select = True
            if not modal_active:
                pooled_gizmo.select = False
        _pin_gizmo_stable_target_mapping(self, targets)
        for target_key in sorted(targets):
            gizmo = self.target_gizmos.get(target_key)
            if gizmo is None:
                continue
            target_data = targets[target_key]
            _kind, armature, pose_bone, packed = target_data
            gizmo.target_key = target_key
            gizmo.armature_name = armature.name
            gizmo.bone_name = pose_bone.name
            gizmo.locked_axes = _pin_target_locked_axes(target_data)
            if gizmo != modal_center:
                gizmo.hide = False
                gizmo.hide_select = False
            gizmo.alpha = 0.36
            gizmo.matrix_basis = _pin_gizmo_center_matrix(Vector(packed[0]))
            gizmo.scale_basis = PIN_GIZMO_DIAMOND_SCALE

        target_data = targets.get(selected_key)
        if self.active_target_key != (selected_key if target_data else ""):
            self.active_target_key = selected_key if target_data else ""
            self.active_axis_index = -1
            self.center_dragging = False
            for axis_gizmo in self.axis_gizmos:
                axis_gizmo.select = False
        self.target_gizmo = self.target_gizmos.get(selected_key)
        self.axes_visible = bool(target_data)
        show_axes = bool(target_data and not self.center_dragging)
        armature = target_data[1] if target_data else None
        pose_bone = target_data[2] if target_data else None
        packed = target_data[3] if target_data else None
        point = (
            Vector(packed[0])
            if packed
            else Vector((0.0, 0.0, 0.0))
        )
        locked_axes = _pin_target_locked_axes(target_data)
        orientation_basis = _pin_transform_orientation_matrix(
            context,
            target_data,
        )
        for axis_index, axis_gizmo in enumerate(self.axis_gizmos):
            modal_axis = bool(
                modal_active and int(self.active_axis_index) == axis_index
            )
            axis = orientation_basis.col[axis_index].copy()
            if axis.length_squared <= 1.0e-12:
                axis = Vector((0.0, 0.0, 1.0))
            axis.normalize()
            if not modal_axis:
                axis_gizmo.hide = not show_axes
            if not show_axes and not modal_axis:
                axis_gizmo.select = False
            axis_gizmo.target_key = selected_key if target_data else ""
            axis_gizmo.armature_name = armature.name if armature else ""
            axis_gizmo.bone_name = pose_bone.name if pose_bone else ""
            axis_gizmo.axis_world = tuple(axis)
            axis_gizmo.axis_locked = bool(locked_axes[axis_index])
            axis_gizmo.locked_axes = locked_axes
            if not modal_axis:
                axis_gizmo.hide_select = bool(
                    not show_axes or locked_axes[axis_index]
                )
            axis_gizmo.alpha = (
                PIN_GIZMO_LOCKED_ALPHA
                if locked_axes[axis_index]
                else 0.82
            )
            axis_gizmo.alpha_highlight = (
                PIN_GIZMO_LOCKED_ALPHA
                if locked_axes[axis_index]
                else 1.0
            )
            axis_gizmo.matrix_basis = _pin_gizmo_axis_matrix(point, axis)
            axis_gizmo.scale_basis = PIN_GIZMO_AXIS_SCALE


def _pin_active_transform_operator(context):
    window = getattr(context, "window", None)
    if window is None:
        return ""
    try:
        for operator in window.modal_operators:
            identifier = str(getattr(operator, "bl_idname", ""))
            if (
                identifier.upper().startswith("TRANSFORM_OT_")
                or identifier.lower().startswith("transform.")
            ):
                return identifier
    except (AttributeError, ReferenceError, RuntimeError):
        pass
    return ""


def _pin_track_transform(transform_operator):
    if not _state.get("pin_snap_transform_active", False):
        _state.setdefault("pin_snap_latches", set()).clear()
        _state.setdefault("pin_snap_transform_seen", set()).clear()
    _state["pin_snap_transform_active"] = True
    _state["pin_snap_transform_operator"] = str(transform_operator)


def _pin_clear_transform_state():
    _state["pin_snap_transform_active"] = False
    _state["pin_snap_transform_operator"] = ""
    _state.setdefault("pin_snap_latches", set()).clear()
    _state.setdefault("pin_snap_transform_seen", set()).clear()
    _state["pin_snap_last_depsgraph_sync"] = 0.0


def _yellow_snap_pose_bone(
    context,
    armature,
    pose_bone,
    packed,
    insert_keys = True,
    update_view_layer = True,
    use_snap_hysteresis = False,
):
    target = Vector(packed[0])
    depsgraph = context.evaluated_depsgraph_get()
    evaluated_armature = armature.evaluated_get(depsgraph)
    evaluated_bone = evaluated_armature.pose.bones.get(pose_bone.name)
    current = (
        _yellow_current_world_point(
            depsgraph,
            evaluated_armature,
            evaluated_bone,
            packed,
        )
        if evaluated_bone is not None
        else None
    )
    if current is None:
        return False
    snap_close = _pin_snap_should_engage(
        context,
        f"YELLOW:{_armature_session_uid(armature)}:{pose_bone.name}",
        target,
        current,
        use_hysteresis = use_snap_hysteresis,
    )
    if not snap_close or (target - current).length <= 1.0e-7:
        return False

    locked_axes = tuple(bool(value) for value in pose_bone.lock_location[:3])
    changed = False
    previous_error = float("inf")
    for _iteration in range(4):
        depsgraph = context.evaluated_depsgraph_get()
        evaluated_armature = armature.evaluated_get(depsgraph)
        evaluated_bone = evaluated_armature.pose.bones.get(pose_bone.name)
        if evaluated_bone is None:
            break
        current = _yellow_current_world_point(
            depsgraph,
            evaluated_armature,
            evaluated_bone,
            packed,
        )
        if current is None:
            break
        delta = target - current
        error = delta.length
        if error <= 1.0e-7 or error >= previous_error - 1.0e-9:
            break
        previous_error = error
        try:
            armature_delta = (
                armature.matrix_world.inverted_safe().to_3x3() @ delta
            )
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            break
        for axis_index, locked in enumerate(locked_axes):
            if locked:
                armature_delta[axis_index] = 0.0
        if armature_delta.length_squared <= 1.0e-12:
            break
        matrix = pose_bone.matrix.copy()
        matrix.translation += armature_delta
        pose_bone.matrix = matrix
        context.view_layer.update()
        changed = True
    if (
        changed
        and insert_keys
        and bool(
            getattr(context.scene.tool_settings, "use_keyframe_insert_auto", False)
        )
    ):
        _insert_bone_keys(
            pose_bone,
            int(context.scene.frame_current),
        )
    if changed and update_view_layer:
        context.view_layer.update()
    return changed


def _surface_contact_guides_for_selected_bone(armature, pose_bone, frame):
    if armature is None or pose_bone is None:
        return ()
    property_names = (
        SURFACE_CONTACT_BONE_PROPERTY,
        SURFACE_CONTACT_CONTROL_BONE_PROPERTY,
        SURFACE_CONTACT_GEOMETRY_BONE_PROPERTY,
        SURFACE_CONTACT_CONSTRAINT_BONE_PROPERTY,
        SURFACE_CONTACT_RELEASE_BONE_PROPERTY,
    )
    return tuple(
        guide
        for guide in _surface_contact_guides()
        if (
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
            == armature.name
            and pose_bone.name
            in {str(guide.get(name, "")) for name in property_names}
            and _surface_contact_guide_active_at(guide, int(frame))
        )
    )


def _surface_contact_related_bone_names(guide):
    return {
        str(guide.get(property_name, ""))
        for property_name in (
            SURFACE_CONTACT_BONE_PROPERTY,
            SURFACE_CONTACT_CONTROL_BONE_PROPERTY,
            SURFACE_CONTACT_GEOMETRY_BONE_PROPERTY,
            SURFACE_CONTACT_CONSTRAINT_BONE_PROPERTY,
            SURFACE_CONTACT_RELEASE_BONE_PROPERTY,
        )
        if str(guide.get(property_name, ""))
    }


def _snap_selected_pin_endpoints(
    context,
    insert_keys = True,
    update_view_layer = True,
    use_snap_hysteresis = False,
):
    if (
        _state.get("pin_snap_syncing", False)
        or _state.get("pin_target_dragging", False)
        or context is None
        or getattr(context, "mode", "") != "POSE"
    ):
        return False
    screen = getattr(context, "screen", None)
    if screen is not None and bool(getattr(screen, "is_animation_playing", False)):
        return False
    grouped = _selected_pose_bones_by_owner(context)
    if not grouped:
        return False

    _state["pin_snap_syncing"] = True
    changed = False
    try:
        frame = int(context.scene.frame_current)
        selected_by_name = {
            armature.name: {pose_bone.name for pose_bone in selected}
            for armature, selected in grouped.items()
        }
        for guide in _surface_contact_guides():
            guide_armature_name = str(
                guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, "")
            )
            selected_names = selected_by_name.get(guide_armature_name)
            if (
                selected_names is None
                or not _surface_contact_guide_active_at(guide, frame)
            ):
                continue
            directly_selected = bool(
                _surface_contact_related_bone_names(guide) & selected_names
            )
            detached = bool(
                str(
                    guide.get(SURFACE_CONTACT_KIND_PROPERTY, "")
                ) == SURFACE_CONTACT_KIND_SIMULATED
                and _surface_contact_snap_departure_active(
                    context,
                    guide,
                    start_if_close = bool(
                        directly_selected
                        and _state.get("pin_snap_transform_active", False)
                    ),
                )
            )
            changed = _surface_contact_enforce_guide(
                context,
                guide,
                force_contact = not directly_selected and not detached,
                insert_keys = bool(insert_keys and directly_selected),
                use_snap_hysteresis = use_snap_hysteresis,
                allow_snap = not detached,
            ) or changed
        for armature, selected in grouped.items():
            for pose_bone in selected:
                active_contacts = _surface_contact_guides_for_selected_bone(
                    armature,
                    pose_bone,
                    frame,
                )
                if active_contacts:
                    # Contact owns the endpoint while active. Do not let a
                    # second, purely visual Onion Pin compete with that lock.
                    continue

                packed = _state.get("yellow_fixed", {}).get(
                    _owner_bone_key(armature, pose_bone.name)
                )
                if packed:
                    changed = _yellow_snap_pose_bone(
                        context,
                        armature,
                        pose_bone,
                        packed,
                        insert_keys = insert_keys,
                        update_view_layer = update_view_layer,
                        use_snap_hysteresis = use_snap_hysteresis,
                    ) or changed
        if changed:
            if update_view_layer:
                context.view_layer.update()
            _tag_redraw_all_view3d()
        return changed
    finally:
        _state["pin_snap_syncing"] = False


def _pin_snap_timer():
    context = bpy.context
    if context is None:
        return 0.04
    transform_operator = _pin_active_transform_operator(context)
    if transform_operator:
        if (
            _pin_selected_target_key()
            and not _state.get("pin_keyboard_transform_active", False)
            and not _state.get("pin_target_dragging", False)
        ):
            # A native transform gizmo belongs to Blender's bone/object
            # selection, so it is the same as clicking away from the pin.
            _pin_deselect_target()
        _pin_track_transform(transform_operator)
        if (
            time.perf_counter()
            - float(_state.get("pin_snap_last_depsgraph_sync", 0.0))
            <= 0.03
        ):
            return 0.016
        try:
            _snap_selected_pin_endpoints(
                context,
                insert_keys = False,
                use_snap_hysteresis = True,
            )
        except (
            AttributeError,
            ReferenceError,
            RuntimeError,
            TypeError,
            ValueError,
        ) as exc:
            print(f"[Roblox Animator Utils] Live pin snap skipped: {exc}")
        return 0.016

    if _state.get("pin_snap_transform_active", False):
        try:
            _snap_selected_pin_endpoints(
                context,
                insert_keys = True,
                use_snap_hysteresis = True,
            )
            _surface_contact_finalize_snap_departures(context)
        except (
            AttributeError,
            ReferenceError,
            RuntimeError,
            TypeError,
            ValueError,
        ) as exc:
            print(f"[Roblox Animator Utils] Pin snap skipped: {exc}")
        finally:
            _pin_clear_transform_state()
    return 0.04


def _surface_contact_ui_state(context):
    if context.mode != "POSE":
        return False, False, False, "Select one endpoint bone"
    selected_bone = _single_active_pose_bone(context)
    armature = _pose_bone_owner(context, selected_bone)
    if armature is None or selected_bone is None:
        return False, False, False, "Select one endpoint bone"
    relation = _surface_contact_ik_relation(armature, selected_bone)
    effector = relation["effector"] if relation is not None else selected_bone
    frame = int(context.scene.frame_current)
    endpoint_guides = _surface_contact_guides_for_effector(armature, effector)
    active_guides = tuple(
        guide
        for guide in endpoint_guides
        if _surface_contact_guide_active_at(guide, frame)
    )
    active_guide = (
        max(
            active_guides,
            key = lambda guide: int(
                guide.get(SURFACE_CONTACT_START_PROPERTY, -1048574)
            ),
        )
        if active_guides
        else None
    )
    if active_guide is not None:
        surface_name = _surface_contact_guide_surface_label(active_guide)
        status = f"{selected_bone.name}: Contact on {surface_name}"
    else:
        status = f"{selected_bone.name}: Free"
    can_create = armature is not None and effector is not None
    can_release = bool(
        active_guide is not None
        and int(context.scene.frame_current)
        > int(active_guide.get(SURFACE_CONTACT_START_PROPERTY, context.scene.frame_current))
    )
    return can_create, can_release, active_guide is not None, status


def _dynamic_unparent_ui_state(context):
    if context.mode != "POSE":
        return (False, False, False, False)

    selected_bone = _single_active_pose_bone(context)
    arm = _pose_bone_owner(context, selected_bone)
    if not arm or selected_bone is None:
        return (False, False, False, False)

    action = arm.animation_data.action if arm.animation_data else None
    frame = int(context.scene.frame_current)
    can_start = False
    can_end = False
    can_clear = False
    can_bake = False

    for pose_bone in (selected_bone,):
        marker_at_frame = bool(
            action is not None
            and _dynamic_marker_value(
                action,
                _unparent_dp(pose_bone.name),
                frame,
            ) is not None
        )
        auto_starts = _dp_auto_unparent_start_frames(pose_bone)
        active_start = (
            _unparent_find_active_start_frame(
                action,
                pose_bone.name,
                frame,
            )
            if action
            else None
        )
        active = bool(
            action
            and _unparent_eval(
                action,
                pose_bone.name,
                frame,
                pb_default = 0.0,
            ) >= 0.5
        )
        active_is_manual = bool(
            active
            and active_start is not None
            and int(active_start) not in auto_starts
        )
        active_is_auto = bool(
            active
            and active_start is not None
            and int(active_start) in auto_starts
        )
        if active_is_auto:
            continue
        has_parent = bool(
            pose_bone.parent
            or str(pose_bone.bone.get(REL_K_PARENT, ""))
        )
        manual_start, _manual_end = _unparent_nearest_segment(
            action,
            pose_bone.name,
            frame,
            excluded_starts = auto_starts,
        )
        has_markers = manual_start is not None
        can_start = can_start or (
            has_parent
            and not active
            and not marker_at_frame
        )
        can_end = can_end or bool(
            active_is_manual
            and active_start is not None
            and frame > int(active_start)
            and not marker_at_frame
        )
        can_clear = can_clear or active_is_manual
        can_bake = can_bake or has_markers

    return (can_start, can_end, can_clear, can_bake)


def _dynamic_parent_target(context):
    if context.mode == "POSE":
        return context.active_pose_bone
    if context.mode == "OBJECT":
        return context.active_object
    return None


def _dynamic_parent_has_data(target):
    if target is None:
        return False
    return any(
        constraint.name.startswith("DP_")
        and _dynamic_parent_constraint_segment(target, constraint)[0] is not None
        for constraint in target.constraints
    )


def _dynamic_parent_has_active_segment(target, frame = None):
    return get_last_dynamic_parent_constraint(target, frame) is not None


def _dynamic_parent_has_marker_at(target, frame):
    if target is None:
        return False
    action = _dynamic_parent_owner_action(target)
    if action is None:
        return False
    for constraint in getattr(target, "constraints", ()):
        if not constraint.name.startswith("DP_"):
            continue
        try:
            data_path = constraint.path_from_id("influence")
        except (AttributeError, TypeError, ValueError):
            continue
        if _dynamic_marker_value(action, data_path, int(frame)) is not None:
            return True
    return False


def _dynamic_parent_can_create(context):
    target = _dynamic_parent_target(context)
    if (
        target is None
        or _dynamic_parent_has_marker_at(
            target,
            int(context.scene.frame_current),
        )
        or get_last_dynamic_parent_constraint(target) is not None
    ):
        return False
    if context.mode == "OBJECT":
        selected_objects = tuple(context.selected_objects or ())
        return len(selected_objects) == 2 and context.active_object in selected_objects
    if context.mode == "POSE":
        armature = context.active_object
        if armature is None or armature.type != "ARMATURE":
            return False
        _target, _subtarget, error = _dynamic_parent_pose_target(
            context,
            armature,
            context.active_pose_bone,
        )
        return not error
    return False


def _dynamic_parent_can_end(context):
    target = _dynamic_parent_target(context)
    if _dynamic_parent_has_marker_at(
        target,
        int(context.scene.frame_current),
    ):
        return False
    constraint = get_last_dynamic_parent_constraint(target)
    if constraint is None:
        return False
    start_frame, _end_frame = _dynamic_parent_constraint_segment(
        target,
        constraint,
    )
    return start_frame is None or int(context.scene.frame_current) > int(start_frame)

class STATICALIZA_OT_toggle_pose_rig(bpy.types.Operator):
    bl_idname = "staticaliza.toggle_pose_rig"
    bl_label = "Toggle Rig Pose Access"
    bl_description = "Include or exclude this rig from the current multi-rig Pose Mode session"
    bl_options = {"REGISTER"}

    armature_name: bpy.props.StringProperty(options = {"HIDDEN"})

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def execute(self, context):
        target = context.scene.objects.get(self.armature_name)
        if (
            target is None
            or target.type != "ARMATURE"
            or target.name not in context.view_layer.objects
        ):
            self.report({"WARNING"}, "Rig is not available in this view layer.")
            return {"CANCELLED"}

        pose_armatures = [
            obj
            for obj in getattr(context, "objects_in_mode", ())
            if obj.type == "ARMATURE" and obj.mode == "POSE"
        ]
        if not pose_armatures:
            active = context.active_object
            if active is not None and active.type == "ARMATURE":
                pose_armatures = [active]

        original_pose_armatures = list(pose_armatures)
        original_active = context.view_layer.objects.active
        original_selected = [
            obj
            for obj in context.view_layer.objects
            if obj.select_get()
        ]

        enabling = target not in pose_armatures
        desired = list(pose_armatures)
        if enabling:
            desired.append(target)
        else:
            desired = [armature for armature in desired if armature != target]
            if not desired:
                self.report({"WARNING"}, "At least one rig must remain in Pose Mode.")
                return {"CANCELLED"}

        active = context.active_object
        if active not in desired:
            active = desired[0]

        unavailable = []
        for armature in set(original_pose_armatures + desired):
            try:
                available = bool(
                    armature.name in context.view_layer.objects
                    and (
                        not armature.hide_get()
                        or _pose_armature_managed_hidden(armature)
                    )
                    and not armature.hide_viewport
                    and not armature.hide_select
                )
            except (AttributeError, ReferenceError):
                available = False
            if not available:
                unavailable.append(_rig_display_name(armature.name))
        if unavailable:
            self.report(
                {"WARNING"},
                "Rig is hidden or selection-locked: " + ", ".join(unavailable),
            )
            return {"CANCELLED"}

        def select_armatures(armatures, active_armature):
            for obj in context.view_layer.objects:
                try:
                    obj.select_set(False)
                except (AttributeError, RuntimeError):
                    pass
            selected = []
            for armature in armatures:
                armature.select_set(True)
                if not armature.select_get():
                    raise RuntimeError(
                        f"{_rig_display_name(armature.name)} is not selectable"
                    )
                selected.append(armature)
            if not selected:
                raise RuntimeError("No selectable rigs remain")
            if active_armature not in selected:
                active_armature = selected[0]
            context.view_layer.objects.active = active_armature
            return selected

        try:
            if _pose_armature_managed_hidden(target):
                target.hide_set(False)
            bpy.ops.object.mode_set(mode = "OBJECT")
            select_armatures(desired, active)
            bpy.ops.object.mode_set(mode = "POSE")
        except (AttributeError, ReferenceError, RuntimeError) as exc:
            try:
                if context.mode != "OBJECT":
                    bpy.ops.object.mode_set(mode = "OBJECT")
                select_armatures(
                    original_pose_armatures,
                    original_active,
                )
                bpy.ops.object.mode_set(mode = "POSE")
                for obj in original_selected:
                    if obj.mode == "POSE":
                        obj.select_set(True)
                if (
                    original_active is not None
                    and original_active.mode == "POSE"
                ):
                    context.view_layer.objects.active = original_active
            except (AttributeError, ReferenceError, RuntimeError):
                pass
            self.report({"WARNING"}, f"Could not update Active Armatures: {exc}")
            return {"CANCELLED"}

        _sync_pose_session_armature_visibility(context)
        _tag_redraw_all_view3d()
        return {"FINISHED"}


class STATICALIZA_OT_delete_rig(bpy.types.Operator):
    bl_idname = "staticaliza.delete_rig"
    bl_label = "Delete Rig"
    bl_description = (
        "Permanently delete this imported rig and only its unshared owned data"
    )
    bl_options = {"REGISTER", "UNDO"}

    armature_name: bpy.props.StringProperty(options = {"HIDDEN"})
    @classmethod
    def poll(cls, context):
        return getattr(context, "scene", None) is not None

    def draw(self, context):
        layout = self.layout
        armature = bpy.data.objects.get(self.armature_name)
        display_name = _rig_display_name(
            armature.name if armature is not None else self.armature_name
        )
        warning = layout.box()
        warning.label(
            text = f'Delete rig "{display_name}"?',
            icon = "ERROR",
        )
        warning.label(text = "Its collection, parts, armature, metadata, and helpers will be removed.")
        warning.label(text = "Materials, images, actions, and helper data shared by another rig are kept.")
        warning.label(text = "You can undo this deletion.", icon = "LOOP_BACK")

    def invoke(self, context, _event):
        armature = bpy.data.objects.get(self.armature_name)
        if _rig_delete_bundle(armature) is None:
            self.report(
                {"ERROR"},
                "This armature is not owned by one unambiguous imported RIG collection.",
            )
            return {"CANCELLED"}
        return context.window_manager.invoke_props_dialog(self, width = 500)

    def execute(self, context):
        armature = bpy.data.objects.get(self.armature_name)
        bundle = _rig_delete_bundle(armature)
        if bundle is None:
            self.report(
                {"ERROR"},
                "The selected imported rig no longer exists or has ambiguous ownership.",
            )
            return {"CANCELLED"}
        pose_scope = _pose_scope_armatures(context)
        survivor_names = tuple(
            current.name for current in pose_scope if current != armature
        )
        active_before = _active_armature(context)
        active_name = (
            active_before.name
            if active_before is not None and active_before != armature
            else (survivor_names[0] if survivor_names else "")
        )
        resume_pose = bool(getattr(context, "mode", "") == "POSE")

        owned_collections = _rig_delete_owned_collections(bundle["master"])
        owned_objects = _rig_delete_owned_objects(bundle, owned_collections)
        external_helpers, heuristic_helpers = _rig_delete_external_helpers(
            armature,
            owned_objects,
        )
        weld_helpers = _rig_delete_weld_helpers(armature)
        delete_objects = set(owned_objects) | set(external_helpers)
        delete_object_names = {obj.name for obj in delete_objects}
        inventory = _rig_delete_resource_inventory()
        for obj in delete_objects:
            _rig_delete_collect_object_resources(
                obj,
                inventory,
                heuristic = obj in heuristic_helpers,
            )
        _rig_delete_collect_rebuild_orphans(armature, inventory)

        if getattr(context, "mode", "") != "OBJECT":
            try:
                bpy.ops.object.mode_set(mode = "OBJECT")
            except (AttributeError, RuntimeError):
                if resume_pose and getattr(context, "mode", "") != "POSE":
                    rollback_names = tuple(
                        current.name for current in pose_scope
                    )
                    rollback_active_name = (
                        active_before.name if active_before is not None else ""
                    )
                    _rig_delete_reenter_pose(
                        context,
                        rollback_names,
                        rollback_active_name,
                    )
                elif resume_pose:
                    _sync_pose_session_armature_visibility(context)
                self.report({"ERROR"}, "Could not leave Pose Mode to delete the rig.")
                return {"CANCELLED"}
        _restore_pose_session_armature_visibility()
        _rig_delete_clear_runtime(
            armature,
            bundle,
            delete_object_names,
        )

        for guide in tuple(_surface_contact_guides()):
            if not _rig_delete_guide_linked_to_objects(
                guide,
                delete_object_names,
            ):
                continue
            try:
                _surface_contact_remove_guide(context, guide)
            except (AttributeError, ReferenceError, RuntimeError, ValueError):
                try:
                    bpy.data.objects.remove(guide, do_unlink = True)
                except (ReferenceError, RuntimeError):
                    pass

        removed_objects = 0
        for obj in sorted(
            delete_objects,
            key = lambda candidate: candidate == armature,
        ):
            try:
                if obj.type == "CAMERA":
                    _set_attached_camera_object_visibility(
                        context.scene,
                        obj,
                        False,
                    )
                    for scene in bpy.data.scenes:
                        if scene.camera == obj:
                            scene.camera = None
                if bpy.data.objects.get(obj.name) == obj:
                    bpy.data.objects.remove(obj, do_unlink = True)
                    removed_objects += 1
            except (AttributeError, ReferenceError, RuntimeError, TypeError):
                continue

        for helper in tuple(weld_helpers):
            try:
                if (
                    bpy.data.objects.get(helper.name) == helper
                    and getattr(helper, "library", None) is None
                    and not bool(getattr(helper, "use_fake_user", False))
                    and _rig_delete_real_users(helper) == 0
                    and not _rig_delete_weld_helper_still_used(helper)
                ):
                    _rig_delete_collect_object_resources(
                        helper,
                        inventory,
                        heuristic = True,
                    )
                    bpy.data.objects.remove(helper, do_unlink = True)
                    removed_objects += 1
            except (AttributeError, ReferenceError, RuntimeError, TypeError):
                continue

        removed_collections = 0
        master = bundle["master"]
        for collection in sorted(
            owned_collections,
            key = lambda candidate: candidate == master,
        ):
            try:
                if bpy.data.collections.get(collection.name) == collection:
                    bpy.data.collections.remove(collection, do_unlink = True)
                    removed_collections += 1
            except (AttributeError, ReferenceError, RuntimeError, TypeError):
                continue

        helper_collection = bpy.data.collections.get(SPACE_HELPER_COLLECTION)
        if (
            helper_collection is not None
            and not tuple(helper_collection.objects)
            and not tuple(helper_collection.children)
        ):
            try:
                bpy.data.collections.remove(helper_collection, do_unlink = True)
                removed_collections += 1
            except (ReferenceError, RuntimeError):
                pass

        removed_data = _rig_delete_remove_orphans(inventory)
        if resume_pose:
            _rig_delete_reenter_pose(context, survivor_names, active_name)
        _refresh_roblox_armature_list(context, force = True)
        _yellow_refresh_runtime(context)
        _tag_redraw_all_view3d()
        self.report(
            {"INFO"},
            f"Deleted {_rig_display_name(self.armature_name)}: "
            f"{removed_objects} objects, {removed_collections} collections, "
            f"and {removed_data} orphan data-blocks.",
        )
        return {"FINISHED"}


class STATICALIZA_OT_track_rig_hover(bpy.types.Operator):
    bl_idname = "staticaliza.track_rig_hover"
    bl_label = "Track Rig Hover"
    bl_description = "Track viewport hover for inactive rig labels"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        return getattr(context, "window", None) is not None

    def invoke(self, context, event):
        window = getattr(context, "window", None)
        if window is None:
            return {"PASS_THROUGH"}
        key = int(window.as_pointer())
        point = (
            int(getattr(event, "mouse_x", -2147483648)),
            int(getattr(event, "mouse_y", -2147483648)),
        )
        hover = dict(_state.get("rig_hover_mouse", {}))
        if hover.get(key) != point:
            hover[key] = point
            _state["rig_hover_mouse"] = hover
            if getattr(context, "mode", "") == "POSE":
                _tag_redraw_all_view3d()
        return {"PASS_THROUGH"}


class VIEW3D_PT_staticaliza_roblox_animator_anchor(bpy.types.Panel):
    bl_label = "Roblox Animator"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Roblox Animator"
    bl_options = {"HIDE_HEADER"}

    @classmethod
    def poll(cls, context):
        return False

    def draw(self, context):
        pass


class VIEW3D_PT_staticaliza_main(bpy.types.Panel):
    bl_label = "Roblox Animator Utils (v" + ".".join(str(part) for part in ADDON_VERSION) + ")"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Roblox Animator Utils"

    def draw(self, context):
        wm = context.window_manager
        layout = self.layout
        if _state.get("extension_update_running", False):
            update_box = layout.box()
            update_box.label(text = "Extension Update", icon = "FILE_REFRESH")
            update_box.label(
                text = _state.get("extension_update_status", "")
                or "Updating extensions..."
            )
            locked_layout = layout.column()
            locked_layout.enabled = False
            layout = locked_layout
        advanced_mode = getattr(wm, "roblox_compat_advanced_mode", False)
        hide_advanced = not advanced_mode

        if context.mode == "POSE":
            pose_rigs = layout.box()
            pose_rigs.label(text = "Active Armatures")
            armatures = _pose_panel_armatures(context)
            try:
                pose_session = set(context.objects_in_mode or ())
            except (AttributeError, ReferenceError, RuntimeError, TypeError):
                pose_session = set()
            if not armatures:
                pose_rigs.label(text = "No rigs in this scene.")
            for armature in armatures:
                row = pose_rigs.row(align = True)
                try:
                    available = (
                        armature.name in context.view_layer.objects
                        and (
                            not armature.hide_get()
                            or _pose_armature_managed_hidden(armature)
                        )
                        and not armature.hide_viewport
                        and not armature.hide_select
                    )
                except (AttributeError, ReferenceError):
                    available = False
                row.enabled = available
                operator = row.operator(
                    "staticaliza.toggle_pose_rig",
                    text = _rig_display_name(armature.name),
                    icon = "ARMATURE_DATA",
                    depress = armature in pose_session,
                )
                operator.armature_name = armature.name
                if _rig_delete_bundle(armature) is not None:
                    delete_column = row.column(align = True)
                    delete_column.operator_context = "INVOKE_DEFAULT"
                    delete_operator = delete_column.operator(
                        "staticaliza.delete_rig",
                        text = "",
                        icon = "TRASH",
                    )
                    delete_operator.armature_name = armature.name

        onion_tools = layout.box()
        onion_tools.label(text = "Onion Tools")

        onion = onion_tools.column(align = True)
        onion.label(text = "Onion Skin (F)")

        pose_scope = _pose_scope_armatures(context)
        row = onion.row(align = True)
        row.operator(
            "onion_skin.ghost_toggle",
            text = "Toggle",
            depress = bool(pose_scope) and all(
                _onion_owner_enabled(armature)
                for armature in pose_scope
            ),
        )

        if advanced_mode:
            col = onion.column()
            col.prop(wm, "onion_skin_opacity", text = "Opacity")

            row2 = col.row(align = True)
            row2.prop(wm, "onion_skin_include_meshes", text = "Meshes")
            row2.prop(wm, "onion_skin_include_bones", text = "Bones")

            col.prop(wm, "onion_skin_raycast", text = "Raycast")
            col.prop(wm, "onion_skin_skip_hidden", text = "Skip Hidden")

        if _state["last_error"]:
            err = onion.box()
            err.label(text = "Last Error:")
            err.label(text = _state["last_error"])

        onion_tools.separator()
        yellow = onion_tools.column(align = True)
        yellow.label(text = "Onion Pin (Shift + F)")
        yellow.prop(wm, "yellow_pin_mode", text = "Position")
        rowy = yellow.row(align = True)
        rowy.operator("staticaliza.yellow_menu", text = "Create Pin")
        yellow.operator("staticaliza.yellow_clear_all", text = "Clear", icon = "X")
        if advanced_mode:
            pinned_count = sum(
                len(_yellow_owner_map("yellow_modes", armature))
                for armature in pose_scope
            )
            hidden_scope = any(
                _yellow_owner_hidden(armature)
                for armature in pose_scope
            )
            yellow.label(
                text = f"Pinned: {pinned_count} | Hidden: {hidden_scope}"
            )

        dynamic_tools = layout.box()
        dynamic_tools.label(text = "Animation Tools (Ctrl + F)")

        dp = dynamic_tools.column(align = True)
        dp.label(text = "Dynamic Parent")

        rowdp = dp.row(align = True)
        parent_start = rowdp.column(align = True)
        parent_start.enabled = _dynamic_parent_can_create(context)
        parent_start.operator(
            "dynamic_parent.create",
            text = "Create Start",
            icon = "KEY_HLT",
        )
        parent_end = rowdp.column(align = True)
        parent_end.enabled = _dynamic_parent_can_end(context)
        parent_end.operator(
            "dynamic_parent.disable",
            text = "Create End",
            icon = "KEY_DEHLT",
        )

        if hide_advanced:
            parent_clear = dp.column(align = True)
            parent_clear.enabled = _dynamic_parent_has_active_segment(
                _dynamic_parent_target(context)
            )
            parent_clear.operator(
                "dynamic_parent.clear",
                text = "Clear",
                icon = "X",
            )
        else:
            rowdp2 = dp.row(align = True)
            parent_clear = rowdp2.column(align = True)
            parent_clear.enabled = _dynamic_parent_has_active_segment(
                _dynamic_parent_target(context)
            )
            parent_clear.operator(
                "dynamic_parent.clear",
                text = "Clear",
                icon = "X",
            )
            parent_bake = rowdp2.column(align = True)
            parent_bake.enabled = _dynamic_parent_has_data(
                _dynamic_parent_target(context)
            )
            parent_bake.operator(
                "dynamic_parent.bake",
                text = "Bake",
                icon = "REC",
            )

        dynamic_tools.separator()
        unparent = dynamic_tools.column(align = True)
        unparent.label(text = "Dynamic Unparent")
        can_unparent_start, can_unparent_end, can_unparent_clear, can_unparent_bake = (
            _dynamic_unparent_ui_state(context)
        )
        unparent_actions = unparent.row(align = True)
        unparent_start = unparent_actions.column(align = True)
        unparent_start.enabled = can_unparent_start
        start_operator = unparent_start.operator(
            "staticaliza.unparent_action",
            text = "Create Start",
            icon = "KEY_HLT",
        )
        start_operator.action = "START"
        unparent_end = unparent_actions.column(align = True)
        unparent_end.enabled = can_unparent_end
        end_operator = unparent_end.operator(
            "staticaliza.unparent_action",
            text = "Create End",
            icon = "KEY_DEHLT",
        )
        end_operator.action = "END"

        if hide_advanced:
            unparent_clear = unparent.column(align = True)
            unparent_clear.enabled = can_unparent_clear
            clear_operator = unparent_clear.operator(
                "staticaliza.unparent_action",
                text = "Clear",
                icon = "X",
            )
            clear_operator.action = "CLEAR"
        else:
            unparent_tools = unparent.row(align = True)
            unparent_clear = unparent_tools.column(align = True)
            unparent_clear.enabled = can_unparent_clear
            clear_operator = unparent_clear.operator(
                "staticaliza.unparent_action",
                text = "Clear",
                icon = "X",
            )
            clear_operator.action = "CLEAR"
            unparent_bake = unparent_tools.column(align = True)
            unparent_bake.enabled = can_unparent_bake
            bake_operator = unparent_bake.operator(
                "staticaliza.unparent_action",
                text = "Bake",
                icon = "REC",
            )
            bake_operator.action = "BAKE_TO_ENDING"

        dynamic_tools.separator()
        contact_tools = dynamic_tools.column(align = True)
        contact_tools.label(text = "Surface Contact")
        can_contact_create, can_contact_release, can_contact_clear, contact_status = (
            _surface_contact_ui_state(context)
        )
        contact_tools.label(text = contact_status)
        contact_action_row = contact_tools.row(align = True)
        contact_create = contact_action_row.column(align = True)
        contact_create.enabled = can_contact_create
        contact_create.operator(
            "staticaliza.surface_contact_create",
            text = "Contact",
            icon = "SNAP_ON",
        )
        contact_release = contact_action_row.column(align = True)
        contact_release.enabled = can_contact_release
        contact_release.operator(
            "staticaliza.surface_contact_release",
            text = "Release",
            icon = "SNAP_OFF",
        )
        contact_clear = contact_tools.column(align = True)
        contact_clear.enabled = can_contact_clear
        contact_clear.operator(
            "staticaliza.surface_contact_clear",
            text = "Clear",
            icon = "X",
        )
        if advanced_mode:
            contact_tools.prop(
                wm,
                "staticaliza_surface_contact_mode",
                text = "Surface",
            )

        dynamic_tools.separator()
        camera_tools = dynamic_tools.column(align = True)
        camera_tools.label(text = "Camera")
        _camera_armature, _camera_bone, attached_camera = _selected_camera_bone(context)
        if attached_camera is not None:
            _sync_attached_camera_preset(attached_camera)
            camera_tools.prop(
                attached_camera,
                "staticaliza_camera_fov_preset",
                text = "Preset",
            )
            if attached_camera.staticaliza_camera_fov_preset == "CUSTOM":
                camera_tools.prop(attached_camera.data, "angle", text = "FOV")
            camera_tools.prop(
                attached_camera,
                "staticaliza_camera_orientation",
                text = "Axis",
            )
            camera_tools.prop(
                attached_camera,
                "staticaliza_camera_hide_attached_object",
                text = "Hide Attached Object",
            )
        else:
            camera_tools.prop(wm, "staticaliza_camera_fov_preset", text = "Preset")
            if wm.staticaliza_camera_fov_preset == "CUSTOM":
                camera_tools.prop(wm, "staticaliza_camera_fov", text = "FOV")
            camera_tools.prop(
                wm,
                "staticaliza_camera_orientation",
                text = "Axis",
            )
        add_camera = camera_tools.column(align = True)
        add_camera.enabled = context.mode == "POSE" and bool(
            _selected_pose_bones_only(context)
        )
        add_camera.operator_context = "INVOKE_DEFAULT"
        add_camera.operator(
            "staticaliza.add_bone_camera",
            text = "Remove Camera" if attached_camera is not None else "Create Camera",
            icon = "TRASH" if attached_camera is not None else "CAMERA_DATA",
        )
        keyframe_camera = camera_tools.column(align = True)
        keyframe_camera.enabled = (
            getattr(context.area, "type", "") == "VIEW_3D"
            and (
                attached_camera is not None
                or _standalone_camera(context) is not None
            )
        )
        keyframe_camera.operator(
            "staticaliza.keyframe_camera_view",
            text = "Keyframe View",
            icon = "KEY_HLT",
        )

        transform_tools = layout.box()
        transform_tools.label(text = "Transform Tools")
        transform_tools.label(text = "Orientation (Y)")
        orientation = context.scene.transform_orientation_slots[0].type
        pivot_mode = getattr(wm, "staticaliza_pivot_mode", "BONE")
        orientation_row = transform_tools.row(align = True)
        global_op = orientation_row.operator(
            "staticaliza.set_transform_orientation",
            text = "Global",
            depress = orientation == "GLOBAL",
        )
        global_op.orientation = "GLOBAL"
        local_op = orientation_row.operator(
            "staticaliza.set_transform_orientation",
            text = "Local",
            depress = orientation == ("CURSOR" if pivot_mode == "PART" else "LOCAL"),
        )
        local_op.orientation = "LOCAL"

        transform_tools.label(text = "Pivot (Shift + Y)")
        pivot_row = transform_tools.row(align = True)
        bone_pivot = pivot_row.operator(
            "staticaliza.set_pivot_mode",
            text = "Bone",
            depress = pivot_mode == "BONE",
        )
        bone_pivot.pivot_mode = "BONE"
        part_pivot_column = pivot_row.column(align = True)
        part_pivot_column.enabled = (
            pivot_mode == "PART"
            or (context.mode == "POSE" and bool(_selected_pose_bones_only(context)))
        )
        part_pivot = part_pivot_column.operator(
            "staticaliza.set_pivot_mode",
            text = "Object",
            depress = pivot_mode == "PART",
        )
        part_pivot.pivot_mode = "PART"

        scene_setup = layout.box()
        scene_setup.label(text = "Scene Setup")
        scene_setup.operator_context = "INVOKE_DEFAULT"
        scene_setup.operator("staticaliza.load_template", text = "Load Template")

        if advanced_mode:
            materials = layout.box()
            materials.label(text = "Materials")
            materials.prop(wm, "smart_material_import_enabled", text = "Smart Material Import")
            materials.prop(
                wm,
                "standardize_imported_material_display_enabled",
                text = "Standardize Viewport Display",
            )
            materials.prop(
                wm,
                "prevent_clothing_layer_clipping_enabled",
                text = "Prevent Clothing Clipping",
            )
            materials.operator(
                "dynamic_parent.clear_material_links",
                text = "Clear",
                icon = "X",
            )

            miscellaneous = layout.box()
            miscellaneous.label(text = "Miscellaneous")
            miscellaneous.prop(
                wm,
                "show_bone_names_enabled",
                text = "Show Bone Names",
            )

        roblox = layout.box()
        roblox.label(text = "Extension")
        roblox.operator("staticaliza.install_roblox_animations", text = "Install Latest Extension")
        roblox.operator("staticaliza.open_roblox_plugins", text = "Install Roblox Plugins")
        roblox.prop(wm, "roblox_compat_advanced_mode", text = "Advanced Mode")


_ADVANCED_ROBLOX_PANEL_HEADERS = frozenset({"Roblox Account", "UGC Emote Validation"})
_FACE_ROBLOX_PANEL_HEADERS = frozenset({"Face Controls"})
_ADVANCED_ROBLOX_OPERATORS = frozenset({
    "object.rbxanims_genrig",
    "object.rbxanims_autoconstraint",
    "object.rbxanims_manualconstraint",
    "object.rbxanims_toggle_weld_bones",
    "object.rbxanims_toggle_com",
    "object.rbxanims_toggle_com_grid",
    "object.rbxanims_edit_com_weights",
    "object.rbxanims_mapkeyframes",
    "object.rbxanims_applytransform",
    "object.rbxanims_bake_file",
    "object.rbxanims_importfbxanimation",
})
_ADVANCED_ROBLOX_PROPERTIES = frozenset({
    "rbx_auto_deform_scale",
    "rbx_deform_rig_scale",
    "rbx_full_range_bake",
})
_ADVANCED_ROBLOX_LABELS = frozenset({"Center of Mass:"})


def _roblox_operator_ui_kwargs(operator_id, kwargs):
    updated = dict(kwargs)
    if operator_id == "object.rbxanims_bake":
        updated["text"] = "Export"
    elif operator_id == "object.rbxanims_importmodel":
        updated["text"] = "Import Rig"
    return updated


class _NullOperatorProperties:
    def __setattr__(self, name, value):
        pass


class _NullUILayout:
    def __setattr__(self, name, value):
        pass

    def row(self, *args, **kwargs):
        return self

    def column(self, *args, **kwargs):
        return self

    def column_flow(self, *args, **kwargs):
        return self

    def grid_flow(self, *args, **kwargs):
        return self

    def split(self, *args, **kwargs):
        return self

    def box(self, *args, **kwargs):
        return self

    def operator(self, *args, **kwargs):
        return _NullOperatorProperties()

    def __getattr__(self, name):
        return lambda *args, **kwargs: None


_NULL_UI_LAYOUT = _NullUILayout()
_UI_CONTAINER_METHODS = frozenset({"row", "column", "column_flow", "grid_flow", "split"})


class _UILayoutProxy:
    __slots__ = ("_layout", "_hidden_headers", "_hide_advanced")

    def __init__(self, layout, hidden_headers, hide_advanced = False):
        object.__setattr__(self, "_layout", layout)
        object.__setattr__(self, "_hidden_headers", hidden_headers)
        object.__setattr__(self, "_hide_advanced", hide_advanced)

    def box(self, *args, **kwargs):
        return _LazyBoxProxy(
            self._layout,
            self._hidden_headers,
            self._hide_advanced,
            args,
            kwargs,
        )

    def label(self, *args, **kwargs):
        text = kwargs.get("text", args[0] if args else "")
        if self._hide_advanced and text in _ADVANCED_ROBLOX_LABELS:
            return None
        return self._layout.label(*args, **kwargs)

    def operator(self, *args, **kwargs):
        operator_id = args[0] if args else kwargs.get("operator", "")
        if self._hide_advanced and operator_id in _ADVANCED_ROBLOX_OPERATORS:
            return _NullOperatorProperties()
        kwargs = _roblox_operator_ui_kwargs(operator_id, kwargs)
        return self._layout.operator(*args, **kwargs)

    def prop(self, *args, **kwargs):
        property_name = args[1] if len(args) > 1 else kwargs.get("property", "")
        if self._hide_advanced and property_name in _ADVANCED_ROBLOX_PROPERTIES:
            return None
        return self._layout.prop(*args, **kwargs)

    def __getattr__(self, name):
        attribute = getattr(self._layout, name)
        if not callable(attribute) or name not in _UI_CONTAINER_METHODS:
            return attribute

        def call_container(*args, **kwargs):
            return _UILayoutProxy(
                attribute(*args, **kwargs),
                self._hidden_headers,
                self._hide_advanced,
            )

        return call_container

    def __setattr__(self, name, value):
        setattr(self._layout, name, value)


class _LazyBoxProxy:
    __slots__ = (
        "_parent_layout",
        "_hidden_headers",
        "_hide_advanced",
        "_box_args",
        "_box_kwargs",
        "_layout_proxy",
        "_suppressed",
    )

    def __init__(self, parent_layout, hidden_headers, hide_advanced, box_args, box_kwargs):
        object.__setattr__(self, "_parent_layout", parent_layout)
        object.__setattr__(self, "_hidden_headers", hidden_headers)
        object.__setattr__(self, "_hide_advanced", hide_advanced)
        object.__setattr__(self, "_box_args", box_args)
        object.__setattr__(self, "_box_kwargs", box_kwargs)
        object.__setattr__(self, "_layout_proxy", None)
        object.__setattr__(self, "_suppressed", False)

    def _materialize(self):
        if self._layout_proxy is None:
            layout = self._parent_layout.box(*self._box_args, **self._box_kwargs)
            object.__setattr__(
                self,
                "_layout_proxy",
                _UILayoutProxy(layout, self._hidden_headers, self._hide_advanced),
            )
        return self._layout_proxy

    def label(self, *args, **kwargs):
        if self._suppressed:
            return None
        text = kwargs.get("text", args[0] if args else "")
        if text in self._hidden_headers:
            object.__setattr__(self, "_suppressed", True)
            return None
        if self._hide_advanced and text in _ADVANCED_ROBLOX_LABELS:
            return None
        return self._materialize().label(*args, **kwargs)

    def __getattr__(self, name):
        if self._suppressed:
            return getattr(_NULL_UI_LAYOUT, name)
        if name in _UI_CONTAINER_METHODS:
            def call_container(*args, **kwargs):
                return _DeferredLayoutProxy(self, name, args, kwargs)

            return call_container
        return getattr(self._materialize(), name)

    def __setattr__(self, name, value):
        if not self._suppressed:
            setattr(self._materialize(), name, value)


class _DeferredLayoutProxy:
    __slots__ = ("_root", "_parent", "_method", "_args", "_kwargs", "_layout")

    def __init__(self, root, method, args, kwargs, parent = None):
        object.__setattr__(self, "_root", root)
        object.__setattr__(self, "_parent", parent)
        object.__setattr__(self, "_method", method)
        object.__setattr__(self, "_args", args)
        object.__setattr__(self, "_kwargs", kwargs)
        object.__setattr__(self, "_layout", None)

    def _materialize(self):
        if self._layout is None:
            parent_layout = self._parent._materialize() if self._parent else self._root._materialize()
            layout = getattr(parent_layout, self._method)(*self._args, **self._kwargs)
            object.__setattr__(self, "_layout", layout)
        return self._layout

    def _hide_if_needed(self, args, kwargs):
        text = kwargs.get("text", args[0] if args else "")
        if text not in self._root._hidden_headers:
            return False
        object.__setattr__(self._root, "_suppressed", True)
        return True

    def label(self, *args, **kwargs):
        if self._root._suppressed:
            return None
        if self._hide_if_needed(args, kwargs):
            return None
        text = kwargs.get("text", args[0] if args else "")
        if self._root._hide_advanced and text in _ADVANCED_ROBLOX_LABELS:
            return None
        return self._materialize().label(*args, **kwargs)

    def prop(self, *args, **kwargs):
        if self._root._suppressed:
            return None
        if self._hide_if_needed((), kwargs):
            return None
        property_name = args[1] if len(args) > 1 else kwargs.get("property", "")
        if (
            self._root._hide_advanced
            and property_name in _ADVANCED_ROBLOX_PROPERTIES
        ):
            return None
        return self._materialize().prop(*args, **kwargs)

    def operator(self, *args, **kwargs):
        if self._root._suppressed:
            return _NullOperatorProperties()
        if self._hide_if_needed(args, kwargs):
            return _NullOperatorProperties()
        operator_id = args[0] if args else kwargs.get("operator", "")
        if self._root._hide_advanced and operator_id in _ADVANCED_ROBLOX_OPERATORS:
            return _NullOperatorProperties()
        kwargs = _roblox_operator_ui_kwargs(operator_id, kwargs)
        return self._materialize().operator(*args, **kwargs)

    def __getattr__(self, name):
        if self._root._suppressed:
            return getattr(_NULL_UI_LAYOUT, name)
        if name in _UI_CONTAINER_METHODS:
            def call_container(*args, **kwargs):
                return _DeferredLayoutProxy(
                    self._root,
                    name,
                    args,
                    kwargs,
                    parent = self,
                )

            return call_container
        return getattr(self._materialize(), name)

    def __setattr__(self, name, value):
        if not self._root._suppressed:
            setattr(self._materialize(), name, value)


class _PanelDrawProxy:
    __slots__ = ("_panel", "layout")

    def __init__(self, panel, layout):
        object.__setattr__(self, "_panel", panel)
        object.__setattr__(self, "layout", layout)

    def __getattr__(self, name):
        return getattr(self._panel, name)


def _restore_roblox_advanced_panel_filter():
    patch = _state.pop("roblox_advanced_panel_patch", None)
    if patch is None:
        return

    panel_class, original_draw, patched_draw = patch
    if getattr(panel_class, "draw", None) is patched_draw:
        panel_class.draw = original_draw


def _patch_roblox_advanced_panels():
    panel_class = getattr(bpy.types, "OBJECT_PT_RbxAnimations", None)
    if panel_class is None:
        return False

    existing = _state.get("roblox_advanced_panel_patch")
    if existing is not None:
        if existing[0] is panel_class and panel_class.draw is existing[2]:
            return True
        _restore_roblox_advanced_panel_filter()

    original_draw = panel_class.draw

    def draw_with_advanced_panel_filter(self, context):
        advanced_mode = getattr(
            context.window_manager,
            "roblox_compat_advanced_mode",
            False,
        )
        hide_advanced = not advanced_mode
        hide_face_controls = not advanced_mode
        hidden_headers = set()
        if hide_advanced:
            hidden_headers.update(_ADVANCED_ROBLOX_PANEL_HEADERS)
        if hide_face_controls:
            hidden_headers.update(_FACE_ROBLOX_PANEL_HEADERS)
        if not hidden_headers:
            return original_draw(self, context)

        layout = _UILayoutProxy(
            self.layout,
            frozenset(hidden_headers),
            hide_advanced = hide_advanced,
        )
        return original_draw(_PanelDrawProxy(self, layout), context)

    draw_with_advanced_panel_filter.__name__ = original_draw.__name__
    draw_with_advanced_panel_filter.__doc__ = original_draw.__doc__
    draw_with_advanced_panel_filter.__module__ = original_draw.__module__
    draw_with_advanced_panel_filter.__qualname__ = original_draw.__qualname__

    panel_class.draw = draw_with_advanced_panel_filter
    _state["roblox_advanced_panel_patch"] = (
        panel_class,
        original_draw,
        draw_with_advanced_panel_filter,
    )
    return True


def _restore_roblox_nodes_only_default():
    invoke_patch = _state.pop("roblox_genrig_invoke_patch", None)
    if invoke_patch is not None:
        operator_class, original_invoke, patched_invoke = invoke_patch
        if getattr(operator_class, "invoke", None) is patched_invoke:
            operator_class.invoke = original_invoke

    execute_patch = _state.pop("roblox_genrig_execute_patch", None)
    if execute_patch is not None:
        operator_class, original_execute, patched_execute = execute_patch
        if getattr(operator_class, "execute", None) is patched_execute:
            operator_class.execute = original_execute


def _restore_roblox_import_patch():
    patch = _state.pop("roblox_import_execute_patch", None)
    if patch is None:
        return

    operator_class, original_execute, patched_execute = patch
    if getattr(operator_class, "execute", None) is patched_execute:
        operator_class.execute = original_execute


def _patch_roblox_import_auto_generation():
    module_name = _roblox_addon_module_name()
    if module_name is None:
        return False

    try:
        import_ops = importlib.import_module(f"{module_name}.operators.import_ops")
        rig_ops = importlib.import_module(f"{module_name}.operators.rig_ops")
        operator_class = import_ops.OBJECT_OT_ImportModel
    except (AttributeError, ImportError):
        return False

    existing = _state.get("roblox_import_execute_patch")
    if existing is not None:
        if existing[0] is operator_class and operator_class.execute is existing[2]:
            return True
        _restore_roblox_import_patch()

    original_execute = operator_class.execute

    def execute_with_local_y_auto_generation(self, context):
        hide_advanced = not getattr(
            context.window_manager,
            "roblox_compat_advanced_mode",
            False,
        )
        previous_armatures = {
            obj.as_pointer() for obj in context.scene.objects if obj.type == "ARMATURE"
        }
        previous_meta = {
            obj.as_pointer()
            for obj in context.scene.objects
            if obj.type == "EMPTY" and "RigMeta" in obj
        }
        previous_collections = {
            collection.as_pointer() for collection in bpy.data.collections
        }

        original_create_rig = import_ops.create_rig
        if hide_advanced:
            def create_local_y_rig(_rigging_type, rig_meta_name):
                return original_create_rig("LOCAL_YAXIS_EXTEND", rig_meta_name)

            import_ops.create_rig = create_local_y_rig

        try:
            result = original_execute(self, context)
        finally:
            if hide_advanced:
                import_ops.create_rig = original_create_rig

        if "FINISHED" in result:
            isolated_images, isolated_materials = (
                _isolate_newly_imported_rig_textures(previous_collections)
            )
            if isolated_images:
                print(
                    "[Roblox Animator Utils] Isolated "
                    f"{isolated_images} texture node(s) across "
                    f"{isolated_materials} imported material(s)."
                )

        if "FINISHED" not in result:
            return result

        new_armatures = [
            obj
            for obj in context.scene.objects
            if obj.type == "ARMATURE" and obj.as_pointer() not in previous_armatures
        ]
        if new_armatures:
            _state.setdefault("roblox_constraints_new_rigs", set()).update(
                armature.as_pointer() for armature in new_armatures
            )
            _refresh_roblox_armature_list(context, force = True)
            _schedule_roblox_rigs_pose_mode(new_armatures)
        if not hide_advanced:
            return result

        new_meta_names = [
            obj.name
            for obj in context.scene.objects
            if obj.type == "EMPTY"
            and "RigMeta" in obj
            and obj.as_pointer() not in previous_meta
        ]

        if new_armatures or not new_meta_names:
            _schedule_roblox_compatibility_scan(delay = 0.05)
            _schedule_smart_material_import_scan(delay = 0.05)
            return result

        scene_name = context.scene.name

        def generate_imported_rig():
            scene = bpy.data.scenes.get(scene_name)
            if scene is None:
                return None

            armatures_before_generation = {
                obj.as_pointer()
                for obj in scene.objects
                if obj.type == "ARMATURE"
            }

            for meta_name in new_meta_names:
                meta = scene.objects.get(meta_name)
                if meta is None or "RigMeta" not in meta:
                    continue
                try:
                    rig_ops.create_rig("LOCAL_YAXIS_EXTEND", meta_name)
                except Exception as exc:
                    print(
                        f"[Roblox Animator Utils] Automatic Local Y-axis rig generation failed: {exc}"
                    )

            generated_armatures = [
                obj
                for obj in scene.objects
                if obj.type == "ARMATURE"
                and obj.as_pointer() not in armatures_before_generation
            ]

            if generated_armatures:
                _state.setdefault("roblox_constraints_new_rigs", set()).update(
                    armature.as_pointer() for armature in generated_armatures
                )

            _schedule_roblox_compatibility_scan(delay = 0.05)
            _schedule_smart_material_import_scan(delay = 0.05)
            if generated_armatures:
                _schedule_roblox_rigs_pose_mode(generated_armatures)
            return None

        bpy.app.timers.register(generate_imported_rig, first_interval = 0.1)
        return result

    execute_with_local_y_auto_generation.__name__ = original_execute.__name__
    execute_with_local_y_auto_generation.__doc__ = original_execute.__doc__
    execute_with_local_y_auto_generation.__module__ = original_execute.__module__
    execute_with_local_y_auto_generation.__qualname__ = original_execute.__qualname__

    operator_class.execute = execute_with_local_y_auto_generation
    _state["roblox_import_execute_patch"] = (
        operator_class,
        original_execute,
        execute_with_local_y_auto_generation,
    )
    return True


STATICALIZA_PATCH_KIND_ATTR = "_staticaliza_roblox_utils_patch_kind"
STATICALIZA_PATCH_ORIGINAL_ATTR = "_staticaliza_roblox_utils_original"
STATICALIZA_EXPORT_DEPTH_ATTR = "_staticaliza_dynamic_export_depth"
DYNAMIC_EXPORT_TARGET_FPS = 240.0
DYNAMIC_EXPORT_MAX_SAMPLE_FACTOR = 16


def _surface_contact_export_bones(armature_obj):
    if armature_obj is None or getattr(armature_obj, "pose", None) is None:
        return set()
    bone_names = set()
    for guide in _surface_contact_guides():
        if str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, "")) != armature_obj.name:
            continue
        effector = armature_obj.pose.bones.get(
            str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
        )
        if effector is None:
            continue
        chain_count = int(guide.get(SURFACE_CONTACT_CHAIN_PROPERTY, 1))
        bone_names.update(
            pose_bone.name
            for pose_bone in _surface_contact_chain(effector, chain_count)
        )
    return bone_names


def _unwrap_staticaliza_patch(
    function,
    patch_kind,
    legacy_code_names = (),
    legacy_original_names = (),
):
    current = function
    visited = set()
    while callable(current) and id(current) not in visited:
        visited.add(id(current))
        candidate = None
        if getattr(current, STATICALIZA_PATCH_KIND_ATTR, "") == patch_kind:
            candidate = getattr(current, STATICALIZA_PATCH_ORIGINAL_ATTR, None)
        else:
            code = getattr(current, "__code__", None)
            if code is not None and code.co_name in legacy_code_names:
                closure = getattr(current, "__closure__", None) or ()
                for name, cell in zip(code.co_freevars, closure):
                    if name not in legacy_original_names:
                        continue
                    try:
                        value = cell.cell_contents
                    except ValueError:
                        continue
                    if callable(value):
                        candidate = value
                        break
        if not callable(candidate) or candidate is current:
            break
        current = candidate
    return current


def _tag_staticaliza_patch(function, original, patch_kind):
    setattr(function, STATICALIZA_PATCH_KIND_ATTR, patch_kind)
    setattr(function, STATICALIZA_PATCH_ORIGINAL_ATTR, original)
    return function


def _restore_roblox_bone_color_patch():
    patches = _state.pop("roblox_bone_color_patches", None)
    if not patches:
        return
    for module, attribute, original_function, patched_function in patches:
        if getattr(module, attribute, None) is patched_function:
            setattr(module, attribute, original_function)


def _patch_roblox_bone_color_updates():
    module_name = _roblox_addon_module_name()
    if module_name is None:
        return False

    patch_targets = (
        (f"{module_name}.rig.creation", "_configure_weld_bones"),
        (f"{module_name}.rig.ik", "create_ik_config"),
        (f"{module_name}.rig.ik", "remove_ik_config"),
        (f"{module_name}.rig", "create_ik_config"),
        (f"{module_name}.rig", "remove_ik_config"),
        (f"{module_name}.operators.rig_ops", "create_ik_config"),
        (f"{module_name}.operators.rig_ops", "remove_ik_config"),
    )
    resolved_targets = []
    for target_module_name, attribute in patch_targets:
        try:
            target_module = importlib.import_module(target_module_name)
        except ImportError:
            continue
        if callable(getattr(target_module, attribute, None)):
            resolved_targets.append((target_module, attribute))
    if not resolved_targets:
        return False

    existing = _state.get("roblox_bone_color_patches")
    if existing and all(
        getattr(module, attribute, None) is patched_function
        for module, attribute, _original_function, patched_function in existing
    ):
        return True
    _restore_roblox_bone_color_patch()

    patches = []
    for target_module, attribute in resolved_targets:
        original_function = _unwrap_staticaliza_patch(
            getattr(target_module, attribute),
            "roblox_bone_color",
        )

        def make_color_update(function):
            def update_with_combined_bone_colors(*args, **kwargs):
                _restore_all_dynamic_pose_bone_colors()
                try:
                    return function(*args, **kwargs)
                finally:
                    scene = getattr(bpy.context, "scene", None)
                    if scene is not None:
                        _sync_all_dynamic_pose_bone_colors(
                            int(scene.frame_current)
                        )
                    _tag_redraw_all_view3d()

            update_with_combined_bone_colors.__name__ = function.__name__
            update_with_combined_bone_colors.__doc__ = function.__doc__
            update_with_combined_bone_colors.__module__ = function.__module__
            update_with_combined_bone_colors.__qualname__ = function.__qualname__
            return _tag_staticaliza_patch(
                update_with_combined_bone_colors,
                function,
                "roblox_bone_color",
            )

        patched_function = make_color_update(original_function)
        setattr(target_module, attribute, patched_function)
        patches.append(
            (target_module, attribute, original_function, patched_function)
        )

    _state["roblox_bone_color_patches"] = patches
    return bool(patches)


def _restore_roblox_serializer_patch():
    patch = _state.pop("roblox_serializer_patch", None)
    if patch is None:
        return

    serialization_module, original_function, patched_function = patch[:3]
    if serialization_module.get_all_constrained_bones is patched_function:
        serialization_module.get_all_constrained_bones = original_function
    if len(patch) >= 5:
        original_serialize, patched_serialize = patch[3:5]
        if getattr(serialization_module, "serialize", None) is patched_serialize:
            serialization_module.serialize = original_serialize
        consumer_names = patch[5] if len(patch) >= 6 else ()
        for module_name in consumer_names:
            consumer = sys.modules.get(module_name)
            if consumer is not None and getattr(
                consumer,
                "serialize",
                None,
            ) is patched_serialize:
                consumer.serialize = original_serialize


def _linearize_dynamic_export_samples(result, bone_names):
    if not isinstance(result, dict) or not bone_names:
        return result
    for keyframe in result.get("kfs", ()):
        if not isinstance(keyframe, dict):
            continue
        states = keyframe.get("kf", {})
        if not isinstance(states, dict):
            continue
        for bone_name in bone_names:
            state = states.get(bone_name)
            if not isinstance(state, (list, tuple)) or len(state) < 3:
                continue
            if isinstance(state, tuple):
                state = list(state)
                states[bone_name] = state
            if str(state[1]) == "Constant":
                continue
            state[1] = "Linear"
            state[2] = "Out"
    return result


def _orthonormalize_dynamic_export_cframe(components):
    if not isinstance(components, (list, tuple)) or len(components) != 12:
        return list(components) if isinstance(components, (list, tuple)) else components

    try:
        transform = Matrix.Identity(4)
        transform.translation = (
            float(components[0]),
            float(components[1]),
            float(components[2]),
        )
        transform[0][0:3] = tuple(float(value) for value in components[3:6])
        transform[1][0:3] = tuple(float(value) for value in components[6:9])
        transform[2][0:3] = tuple(float(value) for value in components[9:12])
        location, rotation, _scale = transform.decompose()
        rotation.normalize()
        normalized = rotation.to_matrix().to_4x4()
        normalized.translation = location
        return [
            float(normalized[0][3]),
            float(normalized[1][3]),
            float(normalized[2][3]),
            float(normalized[0][0]),
            float(normalized[0][1]),
            float(normalized[0][2]),
            float(normalized[1][0]),
            float(normalized[1][1]),
            float(normalized[1][2]),
            float(normalized[2][0]),
            float(normalized[2][1]),
            float(normalized[2][2]),
        ]
    except (ArithmeticError, TypeError, ValueError):
        return list(components)


def _snapshot_dynamic_export_constraint_state(armature_obj):
    if armature_obj is None or getattr(armature_obj, "pose", None) is None:
        return []

    owners = [armature_obj]
    owners.extend(armature_obj.pose.bones)
    snapshot = []
    for owner in owners:
        for constraint in getattr(owner, "constraints", ()):
            if not (
                _is_dynamic_state_constraint(constraint)
                or str(getattr(constraint, "name", "")).startswith(
                    SURFACE_CONTACT_CONSTRAINT_PREFIX
                )
            ):
                continue
            inverse_matrix = getattr(constraint, "inverse_matrix", None)
            snapshot.append(
                (
                    constraint,
                    getattr(constraint, "target", None),
                    str(getattr(constraint, "subtarget", "")),
                    float(getattr(constraint, "influence", 0.0)),
                    bool(getattr(constraint, "mute", False)),
                    inverse_matrix.copy() if inverse_matrix is not None else None,
                )
            )
    return snapshot


def _restore_dynamic_export_constraint_state(snapshot):
    for constraint, target, subtarget, influence, mute, inverse_matrix in snapshot:
        try:
            constraint.target = target
            constraint.subtarget = subtarget
            if inverse_matrix is not None and hasattr(constraint, "inverse_matrix"):
                constraint.inverse_matrix = inverse_matrix
            constraint.influence = influence
            constraint.mute = mute
        except (AttributeError, ReferenceError, RuntimeError):
            pass


def _dynamic_export_face_context(serialization_module, armature_obj):
    build_context = getattr(
        serialization_module,
        "_build_face_control_export_context",
        None,
    )
    if not callable(build_context):
        return None

    animation_data = getattr(armature_obj, "animation_data", None)
    action = getattr(animation_data, "action", None)
    actions = {action} if action is not None else set()
    action_slots = {}
    get_slot = getattr(serialization_module, "get_animation_data_action_slot", None)
    if action is not None and callable(get_slot):
        try:
            action_slots[action] = get_slot(animation_data, action = action)
        except Exception:
            pass
    try:
        return build_context(armature_obj, actions, action_slots)
    except Exception:
        return None


def _dense_dynamic_export_samples(
    serialization_module,
    armature_obj,
    result,
    managed_bones,
):
    if not isinstance(result, dict) or not managed_bones:
        return result

    serialize_state = getattr(
        serialization_module,
        "serialize_combined_animation_state",
        None,
    )
    if not callable(serialize_state):
        return _linearize_dynamic_export_samples(result, managed_bones)

    original_keyframes = [
        keyframe
        for keyframe in result.get("kfs", ())
        if isinstance(keyframe, dict)
    ]
    export_bones = set(managed_bones)
    for keyframe in original_keyframes:
        states = keyframe.get("kf", {})
        if isinstance(states, dict):
            export_bones.update(states)
    if not export_bones:
        return result

    scene = bpy.context.scene
    export_info = result.get("export_info", {})
    if not isinstance(export_info, dict):
        export_info = {}
        result["export_info"] = export_info

    try:
        fps = float(export_info.get("fps", 0.0))
    except (TypeError, ValueError):
        fps = 0.0
    if fps <= 0.0:
        fps_base = float(getattr(scene.render, "fps_base", 1.0) or 1.0)
        fps = max(float(getattr(scene.render, "fps", 30.0)) / fps_base, 1.0)

    # A dynamically detached bone is still stored below its original Roblox
    # parent. Its inverse-parent compensation is nonlinear between samples, so
    # 60 Hz leaves a small world-space wobble after Roblox interpolates both
    # tracks. Four sub-samples per 60 Hz display interval keeps that residual
    # below visible precision without changing the Blender animation itself.
    sample_factor = max(
        1,
        int(math.ceil(DYNAMIC_EXPORT_TARGET_FPS / (fps * 1.000001))),
    )
    sample_factor = min(sample_factor, DYNAMIC_EXPORT_MAX_SAMPLE_FACTOR)
    frame_start = int(export_info.get("frame_start", scene.frame_start))
    frame_end = int(export_info.get("frame_end", scene.frame_end))
    if frame_end < frame_start:
        return _linearize_dynamic_export_samples(result, managed_bones)

    required_api = (
        "get_transform_to_blender",
        "is_deform_bone_rig",
        "resolve_deform_rig_scale_factor",
        "identity_cf",
    )
    if any(not hasattr(serialization_module, name) for name in required_api):
        return _linearize_dynamic_export_samples(result, managed_bones)

    settings = getattr(scene, "rbx_anim_settings", None)
    force_deform = bool(
        getattr(settings, "force_deform_bone_serialization", False)
    )
    is_skinned_rig = bool(
        serialization_module.is_deform_bone_rig(armature_obj) or force_deform
    )
    is_face_control_bone = getattr(
        serialization_module,
        "is_face_control_bone",
        lambda _bone: False,
    )
    has_new_bones = any(
        not (
            "transform" in pose_bone.bone
            and "transform1" in pose_bone.bone
            and "nicetransform" in pose_bone.bone
        )
        and not is_face_control_bone(pose_bone)
        for pose_bone in armature_obj.pose.bones
    )
    run_deform_path = is_skinned_rig or has_new_bones

    back_transform = serialization_module.get_transform_to_blender().inverted()
    world_transform = back_transform @ armature_obj.matrix_world
    try:
        scale_factor = float(export_info.get("deform_scale_factor"))
    except (TypeError, ValueError):
        scale_factor = serialization_module.resolve_deform_rig_scale_factor(
            armature_obj,
            settings,
        )

    face_context = _dynamic_export_face_context(
        serialization_module,
        armature_obj,
    )
    excluded_face_bones = set(
        (face_context or {}).get("face_bone_names", ())
    )
    serialize_face = getattr(
        serialization_module,
        "_serialize_face_control_state_for_frame",
        None,
    )

    original_keyframes.sort(key = lambda keyframe: float(keyframe.get("t", 0.0)))
    style_cursor = 0
    bone_styles = {}
    face_styles = {}
    dense_keyframes = []
    identity_cframe = list(serialization_module.identity_cf)
    static_cache = {}
    motor_state_reuse = {}
    deform_state_reuse = {}
    last_face_state = None
    saved_frame = int(scene.frame_current)
    saved_subframe = float(getattr(scene, "frame_subframe", 0.0))
    previous_export_sampling = bool(
        _state.get("dynamic_space_export_sampling", False)
    )

    _state["dynamic_space_export_sampling"] = True
    try:
        step_count = (frame_end - frame_start) * sample_factor
        for step in range(step_count + 1):
            frame = frame_start + (step / sample_factor)
            frame_int = int(math.floor(frame))
            frame_subframe = float(frame - frame_int)
            scene.frame_set(frame_int, subframe = frame_subframe)

            depsgraph = bpy.context.evaluated_depsgraph_get()
            evaluated_armature = armature_obj.evaluated_get(depsgraph)
            current_state = serialize_state(
                armature_obj,
                evaluated_armature,
                depsgraph,
                run_deform_path,
                is_skinned_rig,
                back_transform,
                world_transform,
                scale_factor,
                static_cache,
                motor_state_reuse,
                deform_state_reuse,
                excluded_face_bones,
            )

            time_seconds = (frame - frame_start) / fps
            while style_cursor < len(original_keyframes):
                source_keyframe = original_keyframes[style_cursor]
                source_time = float(source_keyframe.get("t", 0.0))
                if source_time > time_seconds + 1e-7:
                    break
                source_states = source_keyframe.get("kf", {})
                if isinstance(source_states, dict):
                    for bone_name, state in source_states.items():
                        if isinstance(state, (list, tuple)) and len(state) >= 3:
                            bone_styles[bone_name] = str(state[1])
                source_face = source_keyframe.get("fc", {})
                if isinstance(source_face, dict):
                    for control_name, state in source_face.items():
                        if isinstance(state, dict):
                            face_styles[control_name] = str(
                                state.get("easingStyle", "Linear")
                            )
                style_cursor += 1

            wrapped_state = {}
            for bone_name in sorted(export_bones):
                cframe = current_state.get(bone_name, identity_cframe)
                style = (
                    "Constant"
                    if bone_styles.get(bone_name) == "Constant"
                    else "Linear"
                )
                wrapped_state[bone_name] = [
                    _orthonormalize_dynamic_export_cframe(cframe),
                    style,
                    "Out",
                ]

            keyframe_payload = {
                "t": time_seconds,
                "kf": wrapped_state,
            }
            if callable(serialize_face) and face_context:
                face_state, last_face_state = serialize_face(
                    armature_obj,
                    face_context,
                    float(frame),
                    last_face_state,
                )
                if face_state:
                    for control_name, state in face_state.items():
                        state["easingStyle"] = (
                            "Constant"
                            if face_styles.get(control_name) == "Constant"
                            else "Linear"
                        )
                        state["easingDirection"] = "Out"
                    keyframe_payload["fc"] = face_state
            dense_keyframes.append(keyframe_payload)
    except Exception as exc:
        print(
            "[Roblox Animator Utils] Dynamic export oversampling failed; "
            f"using standard samples: {exc}"
        )
        return _linearize_dynamic_export_samples(result, managed_bones)
    finally:
        try:
            scene.frame_set(saved_frame, subframe = saved_subframe)
        except Exception:
            pass
        _state["dynamic_space_export_sampling"] = previous_export_sampling

    result["kfs"] = dense_keyframes
    result["t"] = (frame_end - frame_start) / fps
    export_info["dynamic_space_sample_factor"] = sample_factor
    export_info["dynamic_space_sample_fps"] = fps * sample_factor
    return result


def _restore_dynamic_unparent_export_metadata(saved_metadata):
    for bone, had_worldspace, worldspace_value, had_parent, parent_value in saved_metadata:
        try:
            if had_worldspace:
                bone["worldspace_bone"] = worldspace_value
            elif "worldspace_bone" in bone:
                del bone["worldspace_bone"]

            if had_parent:
                bone["worldspace_original_parent"] = parent_value
            elif "worldspace_original_parent" in bone:
                del bone["worldspace_original_parent"]
        except Exception:
            pass


def _apply_dynamic_unparent_export_metadata(armature):
    saved_metadata = []
    if not armature or armature.type != "ARMATURE":
        return saved_metadata

    for bone_name in _unparent_rel_scan_arm(armature):
        bone = armature.data.bones.get(bone_name)
        if bone is None:
            continue
        parent_name = str(bone.get(REL_K_PARENT, ""))
        if not parent_name:
            continue

        had_worldspace = "worldspace_bone" in bone
        worldspace_value = bone.get("worldspace_bone")
        had_parent = "worldspace_original_parent" in bone
        parent_value = bone.get("worldspace_original_parent")
        saved_metadata.append(
            (bone, had_worldspace, worldspace_value, had_parent, parent_value)
        )
        bone["worldspace_bone"] = True
        bone["worldspace_original_parent"] = parent_name

    return saved_metadata


def _restore_roblox_export_patch():
    patches = _state.pop("roblox_export_execute_patch", None)
    if not patches:
        return

    for operator_class, original_execute, patched_execute in patches:
        if getattr(operator_class, "execute", None) is patched_execute:
            operator_class.execute = original_execute


def _patch_roblox_export():
    module_name = _roblox_addon_module_name()
    if module_name is None:
        return False

    try:
        animation_ops = importlib.import_module(f"{module_name}.operators.animation_ops")
    except ImportError:
        return False

    operator_classes = [
        getattr(animation_ops, "OBJECT_OT_Bake", None),
        getattr(animation_ops, "OBJECT_OT_Bake_File", None),
    ]
    operator_classes = [operator_class for operator_class in operator_classes if operator_class]
    if not operator_classes:
        return False

    existing = _state.get("roblox_export_execute_patch")
    if existing and all(
        getattr(operator_class, "execute", None) is patched_execute
        for operator_class, _original_execute, patched_execute in existing
    ):
        return True
    _restore_roblox_export_patch()

    patches = []
    for operator_class in operator_classes:
        original_execute = _unwrap_staticaliza_patch(
            operator_class.execute,
            "roblox_export_execute",
            legacy_code_names = ("execute_with_dynamic_unparent",),
            legacy_original_names = ("execute_function",),
        )

        def make_export_execute(execute_function):
            def execute_with_dynamic_unparent(self, context):
                settings = getattr(context.scene, "rbx_anim_settings", None)
                armature_name = getattr(settings, "rbx_anim_armature", "") if settings else ""
                armature = context.scene.objects.get(armature_name) if armature_name else None
                if armature is None and armature_name:
                    armature = bpy.data.objects.get(armature_name)

                saved_frame = int(context.scene.frame_current)
                previous_export_armature = _state.get("unparent_export_armature")
                previous_handler_mute = bool(
                    _state.get("unparent_handler_mute", False)
                )
                saved_metadata = _apply_dynamic_unparent_export_metadata(armature)
                _state["unparent_export_armature"] = armature
                _state["unparent_handler_mute"] = False

                try:
                    if armature is not None:
                        _unparent_frame_change_post(context.scene, None)
                    return execute_function(self, context)
                finally:
                    try:
                        context.scene.frame_set(saved_frame)
                        if armature is not None:
                            _unparent_frame_change_post(context.scene, None)
                    except Exception:
                        pass
                    _state["unparent_export_armature"] = previous_export_armature
                    _state["unparent_handler_mute"] = previous_handler_mute
                    _restore_dynamic_unparent_export_metadata(saved_metadata)
                    try:
                        context.view_layer.update()
                    except Exception:
                        pass

            execute_with_dynamic_unparent.__name__ = execute_function.__name__
            execute_with_dynamic_unparent.__doc__ = execute_function.__doc__
            execute_with_dynamic_unparent.__module__ = execute_function.__module__
            execute_with_dynamic_unparent.__qualname__ = execute_function.__qualname__
            return _tag_staticaliza_patch(
                execute_with_dynamic_unparent,
                execute_function,
                "roblox_export_execute",
            )

        patched_execute = make_export_execute(original_execute)
        operator_class.execute = patched_execute
        patches.append((operator_class, original_execute, patched_execute))

    _state["roblox_export_execute_patch"] = patches
    return True


def _patch_roblox_serializer():
    module_name = _roblox_addon_module_name()
    if module_name is None:
        return False

    try:
        serialization_module = importlib.import_module(
            f"{module_name}.animation.serialization"
        )
    except ImportError:
        return False

    existing = _state.get("roblox_serializer_patch")
    if existing is not None:
        if (
            existing[0] is serialization_module
            and serialization_module.get_all_constrained_bones is existing[2]
            and len(existing) >= 5
            and getattr(serialization_module, "serialize", None) is existing[4]
            and all(
                sys.modules.get(consumer_name) is None
                or getattr(
                    sys.modules[consumer_name],
                    "serialize",
                    None,
                ) is existing[4]
                for consumer_name in (existing[5] if len(existing) >= 6 else ())
            )
        ):
            return True
        _restore_roblox_serializer_patch()

    original_function = _unwrap_staticaliza_patch(
        serialization_module.get_all_constrained_bones,
        "roblox_constrained_bones",
        legacy_code_names = (
            "get_all_constrained_bones_with_dynamic_unparent",
        ),
        legacy_original_names = ("original_function",),
    )
    original_serialize = _unwrap_staticaliza_patch(
        serialization_module.serialize,
        "roblox_serialize",
        legacy_code_names = ("serialize_with_dynamic_spaces",),
        legacy_original_names = ("original_serialize",),
    )

    def get_all_constrained_bones_with_dynamic_unparent(armature_obj):
        constrained = set(original_function(armature_obj))
        constrained.update(_unparent_rel_scan_arm(armature_obj))
        constrained.update(_surface_contact_export_bones(armature_obj))
        return constrained

    get_all_constrained_bones_with_dynamic_unparent.__name__ = original_function.__name__
    get_all_constrained_bones_with_dynamic_unparent.__doc__ = original_function.__doc__
    get_all_constrained_bones_with_dynamic_unparent.__module__ = original_function.__module__
    get_all_constrained_bones_with_dynamic_unparent.__qualname__ = original_function.__qualname__
    _tag_staticaliza_patch(
        get_all_constrained_bones_with_dynamic_unparent,
        original_function,
        "roblox_constrained_bones",
    )

    def serialize_with_dynamic_spaces(*args, **kwargs):
        armature_obj = args[0] if args else kwargs.get("ao")
        export_depth = int(
            getattr(serialization_module, STATICALIZA_EXPORT_DEPTH_ATTR, 0)
            or 0
        )
        if export_depth > 0:
            return original_serialize(*args, **kwargs)

        scene = bpy.context.scene
        saved_frame = int(scene.frame_current)
        saved_subframe = float(getattr(scene, "frame_subframe", 0.0))
        constraint_snapshot = _snapshot_dynamic_export_constraint_state(
            armature_obj
        )
        previous_export_sampling = bool(
            _state.get("dynamic_space_export_sampling", False)
        )
        setattr(
            serialization_module,
            STATICALIZA_EXPORT_DEPTH_ATTR,
            export_depth + 1,
        )
        _state["dynamic_space_export_sampling"] = True
        try:
            result = original_serialize(*args, **kwargs)
            if armature_obj is None or getattr(armature_obj, "pose", None) is None:
                return result
            managed_bones = {
                pose_bone.name
                for pose_bone in armature_obj.pose.bones
                if _pose_space_managed(pose_bone)
            }
            managed_bones.update(_surface_contact_export_bones(armature_obj))
            return _dense_dynamic_export_samples(
                serialization_module,
                armature_obj,
                result,
                managed_bones,
            )
        finally:
            try:
                scene.frame_set(saved_frame, subframe = saved_subframe)
            except Exception:
                pass
            _restore_dynamic_export_constraint_state(constraint_snapshot)
            _state["dynamic_space_export_sampling"] = previous_export_sampling
            setattr(
                serialization_module,
                STATICALIZA_EXPORT_DEPTH_ATTR,
                export_depth,
            )
            try:
                bpy.context.view_layer.update()
            except Exception:
                pass

    serialize_with_dynamic_spaces.__name__ = original_serialize.__name__
    serialize_with_dynamic_spaces.__doc__ = original_serialize.__doc__
    serialize_with_dynamic_spaces.__module__ = original_serialize.__module__
    serialize_with_dynamic_spaces.__qualname__ = original_serialize.__qualname__
    _tag_staticaliza_patch(
        serialize_with_dynamic_spaces,
        original_serialize,
        "roblox_serialize",
    )

    serialization_module.get_all_constrained_bones = get_all_constrained_bones_with_dynamic_unparent
    serialization_module.serialize = serialize_with_dynamic_spaces
    serialize_consumer_names = (
        f"{module_name}.animation",
        f"{module_name}.operators.animation_ops",
        f"{module_name}.server.requests",
    )
    try:
        importlib.import_module(f"{module_name}.operators.animation_ops")
    except ImportError:
        pass
    for consumer_name in serialize_consumer_names:
        consumer = sys.modules.get(consumer_name)
        if consumer is None:
            continue
        consumer_serialize = getattr(consumer, "serialize", None)
        consumer_original = _unwrap_staticaliza_patch(
            consumer_serialize,
            "roblox_serialize",
            legacy_code_names = ("serialize_with_dynamic_spaces",),
            legacy_original_names = ("original_serialize",),
        )
        if consumer_original is original_serialize:
            consumer.serialize = serialize_with_dynamic_spaces
    _state["roblox_serializer_patch"] = (
        serialization_module,
        original_function,
        get_all_constrained_bones_with_dynamic_unparent,
        original_serialize,
        serialize_with_dynamic_spaces,
        serialize_consumer_names,
    )
    return True


def _patch_roblox_nodes_only_default():
    module_name = _roblox_addon_module_name()
    if module_name is None:
        return False

    try:
        rig_ops = importlib.import_module(f"{module_name}.operators.rig_ops")
        operator_class = rig_ops.OBJECT_OT_GenRig
    except (AttributeError, ImportError):
        return False

    invoke_patch = _state.get("roblox_genrig_invoke_patch")
    execute_patch = _state.get("roblox_genrig_execute_patch")
    if invoke_patch is not None or execute_patch is not None:
        invoke_current = (
            invoke_patch is None
            or (invoke_patch[0] is operator_class and operator_class.invoke is invoke_patch[2])
        )
        execute_current = (
            execute_patch is not None
            and execute_patch[0] is operator_class
            and operator_class.execute is execute_patch[2]
        )
        if invoke_current and execute_current:
            return True
        _restore_roblox_nodes_only_default()

    original_execute = operator_class.execute

    def execute_with_staticaliza_compatibility(self, context):
        source = context.scene.objects.get(self.pr_rig_meta_name)
        previous_armatures = {
            obj.as_pointer() for obj in context.scene.objects if obj.type == "ARMATURE"
        }
        result = original_execute(self, context)
        if "FINISHED" not in result:
            return result

        armature = _find_generated_roblox_armature(context, source, previous_armatures)
        if armature is None:
            self.report({"WARNING"}, "Generated armature could not be located for compatibility cleanup.")
            return result

        armature_pointer = armature.as_pointer()
        _state.setdefault("roblox_constraints_new_rigs", set()).add(
            armature_pointer
        )

        def apply_after_native_constraints():
            _state["roblox_constraints_normalized"].discard(armature_pointer)
            _schedule_roblox_compatibility_scan(delay = 0.05)
            _schedule_smart_material_import_scan(delay = 0.05)
            _schedule_roblox_rigs_pose_mode((armature,), delay = 0.05)
            return None

        bpy.app.timers.register(apply_after_native_constraints, first_interval = 0.1)
        return result

    execute_with_staticaliza_compatibility.__name__ = original_execute.__name__
    execute_with_staticaliza_compatibility.__doc__ = original_execute.__doc__
    execute_with_staticaliza_compatibility.__module__ = original_execute.__module__
    execute_with_staticaliza_compatibility.__qualname__ = original_execute.__qualname__

    operator_class.execute = execute_with_staticaliza_compatibility
    _state["roblox_genrig_execute_patch"] = (
        operator_class,
        original_execute,
        execute_with_staticaliza_compatibility,
    )
    return True


def _normalize_version_text(version):
    if isinstance(version, (tuple, list)):
        text = ".".join(str(part) for part in version)
    elif version is None:
        return ""
    else:
        text = str(version).strip()
    return "" if not text or text.lower() == "unknown" else text.lstrip("vV")


def _roblox_version_text(module_name):
    try:
        roblox_module = importlib.import_module(module_name)
    except ImportError:
        return ""

    bl_info_data = getattr(roblox_module, "bl_info", None)
    if isinstance(bl_info_data, dict):
        version_text = _normalize_version_text(bl_info_data.get("version"))
        if version_text:
            return version_text

    try:
        panels_module = importlib.import_module(f"{module_name}.ui.panels")
        version_text = _normalize_version_text(
            getattr(panels_module, "ADDON_VERSION_TEXT", None)
        )
        if version_text:
            return version_text
    except ImportError:
        pass

    module_file = getattr(roblox_module, "__file__", "")
    search_dir = os.path.dirname(os.path.abspath(module_file)) if module_file else ""
    for _ in range(5):
        if not search_dir:
            break
        manifest_path = os.path.join(search_dir, "blender_manifest.toml")
        try:
            with open(manifest_path, "rb") as manifest_file:
                version_text = _normalize_version_text(
                    tomllib.load(manifest_file).get("version")
                )
            if version_text:
                return version_text
        except (OSError, tomllib.TOMLDecodeError):
            pass
        parent_dir = os.path.dirname(search_dir)
        if parent_dir == search_dir:
            break
        search_dir = parent_dir

    return ""


def _configure_roblox_sidebar_tabs():
    if not _roblox_addon_is_enabled():
        return None

    _patch_roblox_nodes_only_default()
    _patch_roblox_import_auto_generation()
    _patch_roblox_advanced_panels()
    _patch_roblox_bone_color_updates()
    _patch_roblox_serializer()
    _patch_roblox_export()

    module_name = _roblox_addon_module_name()
    version_text = ""
    if module_name:
        try:
            roblox_module = importlib.import_module(module_name)
            if isinstance(getattr(roblox_module, "bl_info", None), dict):
                roblox_module.bl_info["name"] = "Roblox Animator"
        except ImportError:
            pass

        version_text = _roblox_version_text(module_name)

        try:
            animation_ops = importlib.import_module(f"{module_name}.operators.animation_ops")
            animation_ops.OBJECT_OT_Bake.bl_label = "Export"
            animation_ops.OBJECT_OT_Bake.bl_description = "Export animation to clipboard"
        except (AttributeError, ImportError):
            pass

    roblox_panel = getattr(bpy.types, "OBJECT_PT_RbxAnimations", None)
    if roblox_panel is not None:
        panel_label = "Roblox Animator"
        if version_text:
            panel_label += f" (v{version_text})"
        if roblox_panel.bl_label != panel_label:
            roblox_panel.bl_label = panel_label
        if roblox_panel.bl_category != "Roblox Animator":
            roblox_panel.bl_category = "Roblox Animator"

    tool_panel = getattr(bpy.types, "OBJECT_PT_RbxAnimations_Tool", None)
    if tool_panel is not None:
        tool_panel.bl_label = "Roblox Animator"
        if version_text:
            tool_panel.bl_label += f" (v{version_text})"

    _refresh_roblox_armature_list(bpy.context, force = True)
    return None


classes = (
    STATICALIZA_OT_pin_click_away,
    STATICALIZA_OT_transform_selected_pin,
    STATICALIZA_OT_move_pin_target,
    STATICALIZA_OT_pose_pin_clipboard,
    STATICALIZA_GT_surface_contact_target,
    STATICALIZA_GGT_surface_contact_target,
    STATICALIZA_GT_yellow_pin_target,
    STATICALIZA_GGT_yellow_pin_target,
    ONION_SKIN_OT_ghost_toggle,
    STATICALIZA_OT_yellow_resync_all,
    STATICALIZA_OT_yellow_clear_all,
    STATICALIZA_OT_yellow_hide_all,
    STATICALIZA_OT_yellow_show,
    STATICALIZA_OT_yellow_apply,
    STATICALIZA_MT_yellow_pin_menu,
    STATICALIZA_MT_yellow_hidden_menu,
    STATICALIZA_MT_yellow_no_selection_menu,
    STATICALIZA_OT_yellow_menu,
    STATICALIZA_OT_unparent_action,
    STATICALIZA_MT_unparent_menu_inactive,
    STATICALIZA_MT_unparent_menu_active,
    STATICALIZA_OT_unparent_menu,
    STATICALIZA_OT_surface_contact_create,
    STATICALIZA_OT_surface_contact_release,
    STATICALIZA_OT_surface_contact_clear,
    STATICALIZA_OT_install_roblox_animations,
    STATICALIZA_OT_open_roblox_plugins,
    STATICALIZA_OT_set_transform_orientation,
    STATICALIZA_OT_set_pivot_mode,
    STATICALIZA_OT_add_bone_camera,
    STATICALIZA_OT_keyframe_camera_view,
    STATICALIZA_OT_load_template,
    STATICALIZA_OT_toggle_pose_rig,
    STATICALIZA_OT_delete_rig,
    STATICALIZA_OT_track_rig_hover,
    VIEW3D_PT_staticaliza_roblox_animator_anchor,
    VIEW3D_PT_staticaliza_main
)

class DYNAMIC_PARENT_OT_menu(bpy.types.Operator):
    bl_idname = "dynamic_parent.menu"
    bl_label = "Animation Tools"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def execute(self, context):
        bpy.ops.wm.call_menu(name = "DYNAMIC_PARENT_MT_hotkey_menu")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)

class DYNAMIC_PARENT_MT_hotkey_menu(bpy.types.Menu):
    bl_label = "Animation Tools"
    bl_idname = "DYNAMIC_PARENT_MT_hotkey_menu"

    def draw(self, context):
        layout = self.layout
        advanced_mode = getattr(
            context.window_manager,
            "roblox_compat_advanced_mode",
            False,
        )

        layout.label(text = "Dynamic Parent")
        layout.operator("dynamic_parent.create", text = "Create Start", icon = "KEY_HLT")
        layout.operator("dynamic_parent.disable", text = "Create End", icon = "KEY_DEHLT")
        layout.operator("dynamic_parent.clear", text = "Clear", icon = "X")
        if advanced_mode:
            layout.operator("dynamic_parent.bake", text = "Bake", icon = "REC")

        layout.separator()
        layout.label(text = "Dynamic Unparent")
        can_start, can_end, can_clear, can_bake = _dynamic_unparent_ui_state(context)

        start_row = layout.row()
        start_row.enabled = can_start
        start_operator = start_row.operator(
            "staticaliza.unparent_action",
            text = "Create Start",
            icon = "KEY_HLT",
        )
        start_operator.action = "START"

        end_row = layout.row()
        end_row.enabled = can_end
        end_operator = end_row.operator(
            "staticaliza.unparent_action",
            text = "Create End",
            icon = "KEY_DEHLT",
        )
        end_operator.action = "END"

        clear_row = layout.row()
        clear_row.enabled = can_clear
        clear_operator = clear_row.operator(
            "staticaliza.unparent_action",
            text = "Clear",
            icon = "X",
        )
        clear_operator.action = "CLEAR"

        if advanced_mode:
            bake_row = layout.row()
            bake_row.enabled = can_bake
            bake_operator = bake_row.operator(
                "staticaliza.unparent_action",
                text = "Bake",
                icon = "REC",
            )
            bake_operator.action = "BAKE_TO_ENDING"

        layout.separator()
        layout.label(text = "Surface Contact")
        can_contact, can_release, can_contact_clear, _contact_status = (
            _surface_contact_ui_state(context)
        )
        contact_action_row = layout.row(align = True)
        contact_column = contact_action_row.column(align = True)
        contact_column.enabled = can_contact
        contact_column.operator(
            "staticaliza.surface_contact_create",
            text = "Contact",
            icon = "SNAP_ON",
        )
        release_column = contact_action_row.column(align = True)
        release_column.enabled = can_release
        release_column.operator(
            "staticaliza.surface_contact_release",
            text = "Release",
            icon = "SNAP_OFF",
        )
        contact_clear = layout.row()
        contact_clear.enabled = can_contact_clear
        contact_clear.operator(
            "staticaliza.surface_contact_clear",
            text = "Clear",
            icon = "X",
        )
        if advanced_mode:
            layout.prop(
                context.window_manager,
                "staticaliza_surface_contact_mode",
                text = "Surface",
            )

        layout.separator()
        layout.label(text = "Camera")
        _camera_armature, _camera_bone, attached_camera = _selected_camera_bone(
            context
        )
        camera_toggle = layout.column(align = True)
        camera_toggle.enabled = (
            context.mode == "POSE" and bool(_selected_pose_bones_only(context))
        )
        camera_toggle.operator_context = "INVOKE_DEFAULT"
        camera_toggle.operator(
            "staticaliza.add_bone_camera",
            text = "Remove Camera" if attached_camera is not None else "Create Camera",
            icon = "TRASH" if attached_camera is not None else "CAMERA_DATA",
        )
        camera_keyframe = layout.column(align = True)
        camera_keyframe.enabled = (
            getattr(context.area, "type", "") == "VIEW_3D"
            and (
                attached_camera is not None
                or _standalone_camera(context) is not None
            )
        )
        camera_keyframe.operator(
            "staticaliza.keyframe_camera_view",
            text = "Keyframe View",
            icon = "KEY_HLT",
        )

def _dynamic_parent_pose_operation_begin(context, armature):
    action = armature.animation_data.action if armature.animation_data else None
    state = {
        "frame": int(context.scene.frame_current),
        "handler_mute": bool(_state.get("unparent_handler_mute", False)),
        "autokey": _autokey_push(context),
        "object_keys": _snapshot_object_keys_all(action),
    }
    if not state["handler_mute"]:
        _unparent_frame_change_post(context.scene, None)
    _state["unparent_handler_mute"] = True
    return state


def _dynamic_parent_pose_operation_end(context, armature, state):
    try:
        if int(context.scene.frame_current) != int(state["frame"]):
            context.scene.frame_set(int(state["frame"]))
        context.view_layer.update()
    finally:
        _state["unparent_handler_mute"] = bool(state["handler_mute"])
        if not state["handler_mute"]:
            _unparent_frame_change_post(context.scene, None)
        action = armature.animation_data.action if armature.animation_data else None
        _cleanup_new_object_keys_all(action, state["object_keys"])
        _autokey_pop(context, state["autokey"])
        _yellow_refresh_runtime(context)


def _dynamic_parent_begin_auto_unparent(context, armature, pose_bone, frame):
    if pose_bone is None:
        return False
    saved_parent = str(pose_bone.bone.get(REL_K_PARENT, ""))
    if pose_bone.parent is None and not saved_parent:
        return False

    action = armature.animation_data.action if armature.animation_data else None
    already_detached = _unparent_relation_is_detached(pose_bone)
    already_active = bool(
        action
        and _unparent_eval(
            action,
            pose_bone.name,
            int(frame),
            pb_default = _pb_prop_get(pose_bone, UNP_PROP, 0.0),
        ) >= 0.5
    )
    if already_detached or already_active:
        return False

    started = _unparent_toggle(context, armature, pose_bone, int(frame))
    _state["unparent_handler_mute"] = True
    return bool(started)


def _dynamic_parent_end_auto_unparent(
    context,
    armature,
    pose_bone,
    constraint,
    frame,
):
    if (
        pose_bone is None
        or constraint is None
        or _dp_auto_unparent_start(pose_bone, constraint) is None
    ):
        return False

    action = armature.animation_data.action if armature.animation_data else None
    active = bool(
        action
        and _unparent_eval(
            action,
            pose_bone.name,
            int(frame),
            pb_default = _pb_prop_get(pose_bone, UNP_PROP, 0.0),
        ) >= 0.5
    )
    if not active and not _unparent_relation_is_detached(pose_bone):
        return False

    ended = _unparent_toggle(context, armature, pose_bone, int(frame))
    _state["unparent_handler_mute"] = True
    return bool(ended)


class DYNAMIC_PARENT_OT_create(bpy.types.Operator):
    bl_idname = "dynamic_parent.create"
    bl_label = "Create Constraint"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _dynamic_parent_can_create(context)

    def execute(self, context):
        obj = context.active_object
        frame = context.scene.frame_current
        operation_state = None
        pose_parent_target = None
        pose_parent_subtarget = ""

        dynamic_target = _dynamic_parent_target(context)
        if _dynamic_parent_has_marker_at(dynamic_target, int(frame)):
            self.report(
                {"ERROR"},
                "A Dynamic Parent marker already exists on this frame.",
            )
            return {"CANCELLED"}

        if obj.type == "ARMATURE":
            if obj.mode != "POSE":
                self.report({"ERROR"}, "Armature objects must be in Pose mode.")
                return {"CANCELLED"}
            pose_bone = context.active_pose_bone
            if pose_bone is None:
                return {"CANCELLED"}
            (
                pose_parent_target,
                pose_parent_subtarget,
                target_error,
            ) = _dynamic_parent_pose_target(context, obj, pose_bone)
            if target_error:
                self.report({"ERROR"}, target_error)
                return {"CANCELLED"}
            operation_state = _dynamic_parent_pose_operation_begin(context, obj)

        try:
            if obj.type == "ARMATURE":
                created_constraint = _create_pose_dynamic_parent(
                    context,
                    obj,
                    pose_bone,
                    pose_parent_target,
                    pose_parent_subtarget,
                    int(frame),
                )
                if created_constraint is None:
                    self.report({"ERROR"}, "Unable to create Dynamic Parent.")
                    return {"CANCELLED"}
            else:
                const = get_last_dynamic_parent_constraint(obj)
                if const:
                    disable_constraint(obj, const, frame)
                dp_create_dynamic_parent_obj(self)
        finally:
            if operation_state is not None:
                _dynamic_parent_pose_operation_end(context, obj, operation_state)

        return {"FINISHED"}

class DYNAMIC_PARENT_OT_disable(bpy.types.Operator):
    bl_idname = "dynamic_parent.disable"
    bl_label = "Disable Constraint"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _dynamic_parent_can_end(context)

    def execute(self, context):
        frame = context.scene.frame_current
        dynamic_target = _dynamic_parent_target(context)
        if _dynamic_parent_has_marker_at(dynamic_target, int(frame)):
            self.report(
                {"ERROR"},
                "A Dynamic Parent marker already exists on this frame.",
            )
            return {"CANCELLED"}
        armature = context.active_object if context.mode == "POSE" else None
        operation_state = (
            _dynamic_parent_pose_operation_begin(context, armature)
            if armature is not None and armature.type == "ARMATURE"
            else None
        )
        objects = get_selected_objects(context)
        counter = 0

        try:
            if not objects:
                self.report({"ERROR"}, "Nothing selected.")
                return {"CANCELLED"}

            for obj in objects:
                const = get_last_dynamic_parent_constraint(obj)
                if const is None:
                    continue
                if armature is not None and isinstance(obj, bpy.types.PoseBone):
                    if not _end_pose_dynamic_parent(
                        context,
                        armature,
                        obj,
                        const,
                        int(frame),
                    ):
                        continue
                else:
                    disable_constraint(obj, const, frame)
                counter += 1
        finally:
            if operation_state is not None:
                _dynamic_parent_pose_operation_end(context, armature, operation_state)

        self.report({"INFO"}, f"{counter} constraints were disabled.")
        return {"FINISHED"}

class DYNAMIC_PARENT_OT_clear(bpy.types.Operator):
    bl_idname = "dynamic_parent.clear"
    bl_label = "Clear Dynamic Parent"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _dynamic_parent_has_active_segment(
            _dynamic_parent_target(context),
            int(context.scene.frame_current),
        )

    def execute(self, context):
        pbone = None
        obj = bpy.context.active_object
        if obj.type == "ARMATURE":
            pbone = bpy.context.active_pose_bone

        dp_clear(obj, pbone)
        _yellow_refresh_runtime(context)

        return {"FINISHED"}

class DYNAMIC_PARENT_OT_bake(bpy.types.Operator):
    bl_idname = "dynamic_parent.bake"
    bl_label = "Bake Dynamic Parent"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _dynamic_parent_has_data(_dynamic_parent_target(context))

    def execute(self, context):
        obj = bpy.context.active_object
        scn = bpy.context.scene

        if obj.type == "ARMATURE":
            obj = bpy.context.active_pose_bone
            bpy.ops.nla.bake(
                frame_start = scn.frame_start,
                frame_end = scn.frame_end,
                step = 1,
                only_selected = True,
                visual_keying = True,
                clear_constraints = False,
                clear_parents = False,
                bake_types = {"POSE"},
            )
            for const in obj.constraints[:]:
                if const.name.startswith("DP_"):
                    _remove_dynamic_parent_constraint_metadata(obj, const)
                    obj.constraints.remove(const)
        else:
            bpy.ops.nla.bake(
                frame_start = scn.frame_start,
                frame_end = scn.frame_end,
                step = 1,
                only_selected = True,
                visual_keying = True,
                clear_constraints = False,
                clear_parents = False,
                bake_types = {"OBJECT"},
            )
            for const in obj.constraints[:]:
                if const.name.startswith("DP_"):
                    _remove_dynamic_parent_constraint_metadata(obj, const)
                    obj.constraints.remove(const)

        return {"FINISHED"}

class DYNAMIC_PARENT_OT_clear_material_links(bpy.types.Operator):
    bl_idname = "dynamic_parent.clear_material_links"
    bl_label = "Clear Material Links"
    bl_description = "Disconnect Base Color and Alpha links for all materials in the current file"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        removed = dp_clear_material_links()

        if removed:
            self.report({"INFO"}, f"Removed {removed} Base Color/Alpha link(s).")
        else:
            self.report({"INFO"}, "No Base Color or Alpha links were connected.")

        return {"FINISHED"}

class DYNAMIC_PARENT_MT_clear_menu(bpy.types.Menu):
    bl_label = "Clear Dynamic Parent?"
    bl_idname = "DYNAMIC_PARENT_MT_clear_menu"

    def draw(self, context):
        layout = self.layout
        layout.operator("dynamic_parent.clear", text = "Clear", icon = "X")
        layout.operator("dynamic_parent.bake", text = "Bake and clear", icon = "REC")

class DYNAMIC_PARENT_PT_ui(bpy.types.Panel):
    bl_label = "Dynamic Parent {}.{}.{}".format(*DP_BL_INFO["version"])
    bl_idname = "DYNAMIC_PARENT_PT_ui"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Dynamic Parent"

    def draw(self, context):
        layout = self.layout
        col = layout.column(align = True)
        col.operator("dynamic_parent.create", text = "Create", icon = "KEY_HLT")
        col.operator("dynamic_parent.disable", text = "Disable", icon = "KEY_DEHLT")
        col.menu("DYNAMIC_PARENT_MT_clear_menu", text = "Clear")

        layout.separator()
        layout.label(text = "Materials")
        layout.operator("dynamic_parent.clear_material_links", text = "Clear")

def _dp_register():
    for c in (
        DYNAMIC_PARENT_OT_menu,
        DYNAMIC_PARENT_MT_hotkey_menu,
        DYNAMIC_PARENT_OT_create,
        DYNAMIC_PARENT_OT_disable,
        DYNAMIC_PARENT_OT_clear,
        DYNAMIC_PARENT_OT_bake,
        DYNAMIC_PARENT_OT_clear_material_links,
        DYNAMIC_PARENT_MT_clear_menu,
    ):
        try:
            bpy.utils.register_class(c)
        except Exception:
            pass

def _dp_unregister():
    for c in reversed((
        DYNAMIC_PARENT_OT_menu,
        DYNAMIC_PARENT_MT_hotkey_menu,
        DYNAMIC_PARENT_OT_create,
        DYNAMIC_PARENT_OT_disable,
        DYNAMIC_PARENT_OT_clear,
        DYNAMIC_PARENT_OT_bake,
        DYNAMIC_PARENT_OT_clear_material_links,
        DYNAMIC_PARENT_MT_clear_menu,
    )):
        try:
            bpy.utils.unregister_class(c)
        except Exception:
            pass


def _unregister_addon_keymaps():
    for km, kmi in _keymaps:
        try:
            km.keymap_items.remove(kmi)
        except (ReferenceError, RuntimeError):
            pass
    _keymaps.clear()


def _remove_legacy_alt_f_keymaps(keyconfig):
    if keyconfig is None:
        return 0
    removed = 0
    for keymap in keyconfig.keymaps:
        for keymap_item in tuple(keymap.keymap_items):
            if keymap_item.idname not in LEGACY_ALT_F_OPERATOR_IDS:
                continue
            if not (
                keymap_item.type == "F"
                and keymap_item.value == "PRESS"
                and keymap_item.alt
                and not keymap_item.ctrl
                and not keymap_item.shift
            ):
                continue
            try:
                keymap.keymap_items.remove(keymap_item)
                removed += 1
            except (ReferenceError, RuntimeError):
                pass
    return removed


def _register_addon_keymaps():
    try:
        wm = bpy.context.window_manager
    except AttributeError:
        return False
    keyconfigs = wm.keyconfigs if wm else None
    kc = keyconfigs.addon if keyconfigs else None
    if kc is None:
        return False

    _remove_legacy_alt_f_keymaps(kc)
    _remove_legacy_alt_f_keymaps(getattr(keyconfigs, "user", None))
    if _keymaps:
        return True

    km = kc.keymaps.new(name = "Window", space_type = "EMPTY", region_type = "WINDOW")
    _keymaps.append((km, km.keymap_items.new(
        "staticaliza.track_rig_hover",
        type = "MOUSEMOVE",
        value = "ANY",
        any = True,
        head = True,
    )))

    km = kc.keymaps.new(name = "Pose", space_type = "EMPTY", region_type = "WINDOW")
    for event_type, transform_mode in (
        ("G", "TRANSLATE"),
        ("R", "ROTATE"),
        ("S", "SCALE"),
    ):
        transform_pin = km.keymap_items.new(
            "staticaliza.transform_selected_pin",
            type = event_type,
            value = "PRESS",
            head = True,
        )
        transform_pin.properties.transform_mode = transform_mode
        _keymaps.append((km, transform_pin))
    copy_pins = km.keymap_items.new(
        "staticaliza.pose_pin_clipboard",
        type = "C",
        value = "PRESS",
        ctrl = True,
        head = True,
    )
    copy_pins.properties.action = "COPY"
    _keymaps.append((km, copy_pins))
    paste_pins = km.keymap_items.new(
        "staticaliza.pose_pin_clipboard",
        type = "V",
        value = "PRESS",
        ctrl = True,
        head = True,
    )
    paste_pins.properties.action = "PASTE"
    _keymaps.append((km, paste_pins))
    paste_flipped_pins = km.keymap_items.new(
        "staticaliza.pose_pin_clipboard",
        type = "V",
        value = "PRESS",
        ctrl = True,
        shift = True,
        head = True,
    )
    paste_flipped_pins.properties.action = "PASTE_FLIPPED"
    _keymaps.append((km, paste_flipped_pins))
    _keymaps.append((km, km.keymap_items.new(
        "staticaliza.keyframe_camera_view",
        type = "NUMPAD_0",
        value = "PRESS",
        ctrl = True,
        alt = True,
        head = True,
    )))
    _keymaps.append((km, km.keymap_items.new(
        "onion_skin.ghost_toggle",
        type = "F",
        value = "PRESS",
        head = True,
    )))
    _keymaps.append((km, km.keymap_items.new(
        "staticaliza.yellow_menu",
        type = "F",
        value = "PRESS",
        shift = True,
        head = True,
    )))
    _keymaps.append((km, km.keymap_items.new(
        "dynamic_parent.menu",
        type = "F",
        value = "PRESS",
        ctrl = True,
        head = True,
    )))
    _keymaps.append((km, km.keymap_items.new("staticaliza.set_transform_orientation", type = "Y", value = "PRESS")))
    _keymaps.append((km, km.keymap_items.new("staticaliza.set_pivot_mode", type = "Y", value = "PRESS", shift = True)))

    km = kc.keymaps.new(name = "Object Mode", space_type = "EMPTY", region_type = "WINDOW")
    _keymaps.append((km, km.keymap_items.new("staticaliza.set_transform_orientation", type = "Y", value = "PRESS")))

    km = kc.keymaps.new(name = "3D View", space_type = "VIEW_3D", region_type = "WINDOW")
    _keymaps.append((km, km.keymap_items.new(
        "staticaliza.pin_click_away",
        type = "LEFTMOUSE",
        value = "PRESS",
        any = True,
        head = True,
    )))
    _keymaps.append((km, km.keymap_items.new(
        "staticaliza.keyframe_camera_view",
        type = "NUMPAD_0",
        value = "PRESS",
        ctrl = True,
        alt = True,
        head = True,
    )))
    km = kc.keymaps.new(name = "Dopesheet Generic", space_type = "DOPESHEET_EDITOR", region_type = "WINDOW")
    _keymaps.append((km, km.keymap_items.new("onion_skin.ghost_toggle", type = "F", value = "PRESS")))
    _keymaps.append((km, km.keymap_items.new("staticaliza.yellow_menu", type = "F", value = "PRESS", shift = True)))
    _keymaps.append((km, km.keymap_items.new("dynamic_parent.menu", type = "F", value = "PRESS", ctrl = True)))

    km = kc.keymaps.new(name = "Graph Editor", space_type = "GRAPH_EDITOR", region_type = "WINDOW")
    _keymaps.append((km, km.keymap_items.new("onion_skin.ghost_toggle", type = "F", value = "PRESS")))
    _keymaps.append((km, km.keymap_items.new("staticaliza.yellow_menu", type = "F", value = "PRESS", shift = True)))
    _keymaps.append((km, km.keymap_items.new("dynamic_parent.menu", type = "F", value = "PRESS", ctrl = True)))
    return True


def _register_addon_keymaps_timer():
    return None if _register_addon_keymaps() else 0.1


def register():
    _set_default_keyframe_handle_type()
    if not _migrate_dynamic_keyframe_names():
        bpy.app.timers.register(
            _run_dynamic_keyframe_name_migration,
            first_interval = 0.1,
        )
    _capture_animation_channel_baseline()
    for name in (
        "onion_skin_enabled",
        "onion_skin_opacity",
        "onion_skin_include_meshes",
        "onion_skin_include_bones",
        "onion_skin_raycast",
        "onion_skin_skip_hidden"
    ):
        if hasattr(bpy.types.Scene, name):
            delattr(bpy.types.Scene, name)

    if hasattr(bpy.types.WindowManager, "smart_material_import_enabled"):
        delattr(bpy.types.WindowManager, "smart_material_import_enabled")
    if hasattr(
        bpy.types.WindowManager,
        "standardize_imported_material_display_enabled",
    ):
        delattr(
            bpy.types.WindowManager,
            "standardize_imported_material_display_enabled",
        )
    if hasattr(
        bpy.types.WindowManager,
        "prevent_clothing_layer_clipping_enabled",
    ):
        delattr(
            bpy.types.WindowManager,
            "prevent_clothing_layer_clipping_enabled",
        )
    if hasattr(bpy.types.WindowManager, "yellow_pin_mode"):
        delattr(bpy.types.WindowManager, "yellow_pin_mode")
    for name in (
        "roblox_compat_hide_weld_bones",
        "roblox_compat_hide_face_bones",
        "roblox_compat_hide_advanced_panels",
        "roblox_compat_advanced_mode",
        "staticaliza_pivot_mode",
        "staticaliza_camera_fov_mode",
        "staticaliza_camera_custom_fov",
        "staticaliza_camera_fov_preset",
        "staticaliza_camera_fov",
        "staticaliza_camera_orientation",
        "staticaliza_surface_contact_mode",
    ):
        if hasattr(bpy.types.WindowManager, name):
            delattr(bpy.types.WindowManager, name)
    for name in (
        "staticaliza_camera_fov_preset",
        "staticaliza_camera_orientation",
        "staticaliza_camera_hide_attached_preview",
        "staticaliza_camera_hide_attached_object",
    ):
        if hasattr(bpy.types.Object, name):
            delattr(bpy.types.Object, name)

    bpy.types.WindowManager.onion_skin_enabled = bpy.props.BoolProperty(
        name = "Ghost",
        default = False,
        options = {"SKIP_SAVE"},
        update = _on_enabled_toggle
    )
    bpy.types.WindowManager.onion_skin_opacity = bpy.props.FloatProperty(
        name = "Opacity",
        default = 0.10,
        min = 0.001,
        max = 1.0,
        update = _on_setting_change
    )
    bpy.types.WindowManager.onion_skin_include_meshes = bpy.props.BoolProperty(
        name = "Meshes",
        default = True,
        update = _on_setting_change
    )
    bpy.types.WindowManager.onion_skin_include_bones = bpy.props.BoolProperty(
        name = "Bones",
        default = False,
        update = _on_setting_change
    )
    bpy.types.WindowManager.onion_skin_raycast = bpy.props.BoolProperty(
        name = "Raycast",
        default = True,
        update = _on_setting_change
    )
    bpy.types.WindowManager.onion_skin_skip_hidden = bpy.props.BoolProperty(
        name = "Skip Hidden",
        default = True,
        update = _on_setting_change
    )
    bpy.types.WindowManager.smart_material_import_enabled = bpy.props.BoolProperty(
        name = "Smart Material Import",
        description = "Automatically remove Base Color links from imported rig parts that also use a Normal link",
        default = True,
        update = _on_smart_material_import_toggle
    )
    bpy.types.WindowManager.standardize_imported_material_display_enabled = bpy.props.BoolProperty(
        name = "Standardize Viewport Display",
        description = "Set newly imported rig materials to #E7E7E7, metallic 0, and roughness 0.5 in Viewport Display",
        default = True,
        update = _on_smart_material_import_toggle,
    )
    bpy.types.WindowManager.prevent_clothing_layer_clipping_enabled = bpy.props.BoolProperty(
        name = "Prevent Clothing Clipping",
        description = "Offset imported clothing overlay meshes slightly so the underlying body does not clip through",
        default = False,
        update = _on_smart_material_import_toggle,
    )
    bpy.types.WindowManager.yellow_pin_mode = bpy.props.EnumProperty(
        name = "Pin Position",
        description = "Choose where new and updated pins are placed",
        items = (
            ("MODE_3", "Smart", "Use the bottom center of the bone's visible geometry"),
            ("MODE_1", "Bone End", "Use the bone tail"),
            ("MODE_2", "Bone Center", "Use the center of the weighted geometry"),
        ),
        default = "MODE_3",
    )
    bpy.types.WindowManager.roblox_compat_advanced_mode = bpy.props.BoolProperty(
        name = "Advanced Mode",
        description = "Show advanced panels, weld and face bones, bone axes, and detailed Utils controls",
        default = False,
        update = _on_advanced_mode_change
    )
    bpy.types.WindowManager.show_bone_names_enabled = bpy.props.BoolProperty(
        name = "Show Bone Names",
        description = "Show bone name text in the 3D Viewport",
        default = True,
        update = _on_roblox_compatibility_setting_change,
    )
    bpy.types.WindowManager.staticaliza_pivot_mode = bpy.props.EnumProperty(
        name = "Pivot Mode",
        description = "Use Blender's bone pivot or the first connected object's center and axes",
        items = (
            ("BONE", "Bone", "Use Blender's normal bone pivot"),
            ("PART", "Object", "Use the center and axes of the first connected rig object"),
        ),
        default = "BONE",
        options = {"SKIP_SAVE"},
    )
    bpy.types.WindowManager.staticaliza_surface_contact_mode = bpy.props.EnumProperty(
        name = "Surface Detection",
        description = "Choose which nearby mesh surfaces Surface Contact may detect",
        items = (
            ("AUTO", "Automatic", "Detect nearby floors, walls, slopes, and custom meshes"),
            ("FLOOR", "Floor", "Only detect upward-facing floor and slope surfaces"),
            ("WALL", "Wall", "Only detect mostly vertical surfaces"),
        ),
        default = "AUTO",
    )
    bpy.types.WindowManager.staticaliza_camera_fov_preset = bpy.props.EnumProperty(
        name = "Camera Preset",
        description = "Choose a field-of-view preset for newly attached cameras",
        items = CAMERA_FOV_PRESET_ITEMS,
        default = "CINEMATIC",
        update = _on_camera_fov_preset,
    )
    bpy.types.WindowManager.staticaliza_camera_fov = bpy.props.FloatProperty(
        name = "FOV",
        description = "Horizontal field of view used for newly attached cameras",
        subtype = "ANGLE",
        default = math.radians(35.0),
        min = math.radians(1.0),
        max = math.radians(179.0),
        update = _on_camera_fov_change,
    )
    bpy.types.WindowManager.staticaliza_camera_orientation = bpy.props.EnumProperty(
        name = "Camera Orientation",
        description = "Choose the local bone axis the camera points along",
        items = CAMERA_ORIENTATION_ITEMS,
        default = "Z_NEG",
    )
    bpy.types.Object.staticaliza_camera_fov_preset = bpy.props.EnumProperty(
        name = "Camera Preset",
        description = "Choose the field-of-view preset for this camera",
        items = CAMERA_FOV_PRESET_ITEMS,
        default = "CINEMATIC",
        update = _on_attached_camera_preset,
    )
    bpy.types.Object.staticaliza_camera_orientation = bpy.props.EnumProperty(
        name = "Camera Orientation",
        description = "Choose the local bone axis this camera points along",
        items = CAMERA_ORIENTATION_ITEMS,
        default = "Z_NEG",
        update = _on_attached_camera_orientation,
    )
    bpy.types.Object.staticaliza_camera_hide_attached_object = bpy.props.BoolProperty(
        name = "Hide Attached Object",
        description = "Hide mesh objects driven by this camera bone in the viewport and final render",
        default = True,
        update = _on_camera_attached_object_hide_change,
    )

    for c in classes:
        bpy.utils.register_class(c)

    _dp_register()

    _state["yellow_fixed"] = {}
    _state["yellow_modes"] = {}
    _state["yellow_hidden"] = set()
    _state["onion_enabled_owners"] = set()
    _state["onion_property_syncing"] = False
    _state["mesh_batches"] = {}
    _state["raycast_fixed"] = {}
    _state["unparent_rel_cache"] = {}
    _state["unparent_handler_mute"] = False
    _state["dynamic_space_export_sampling"] = False
    _state["last_error"] = ""
    _state["smart_material_processed_rigs"] = set()
    _state["material_import_baseline"] = None
    if not _capture_material_import_baseline():
        bpy.app.timers.register(
            _initialize_material_import_tracking,
            first_interval = 0.05,
        )
    _state["extension_update_lock_waits"] = 0
    _state["extension_update_running"] = False
    _state["extension_update_status"] = ""
    _state["roblox_constraints_normalized"] = set()
    _state["roblox_constraints_new_rigs"] = set()
    _state["unparent_export_armature"] = None
    _state["smart_material_scan_pending"] = False
    _state["roblox_compatibility_scan_pending"] = False
    _state["roblox_armature_list_signature"] = None
    _state["armature_overlay_saved"] = {}
    _state["part_pivot_syncing"] = False
    _state["part_pivot_armature"] = 0
    _state["part_pivot_bone"] = ""
    _state["part_pivot_last_armature"] = 0
    _state["part_pivot_last_bone"] = ""
    _state["part_pivot_object"] = ""
    _state["part_pivot_object_local"] = None
    _state["part_pivot_saved"] = None
    _state["part_pivot_last_signature"] = None
    _state["part_pivot_cursor_visibility"] = {}
    _state["camera_view_spaces"] = {}
    _state["free_view_master"] = None
    _state["free_view_space_states"] = {}
    _state["free_view_settings_master"] = None
    _state["free_view_setting_states"] = {}
    _state["free_view_syncing"] = False
    _state["pose_mode_pending_rigs"] = set()
    _state["pose_mode_pending_attempts"] = 0
    _state["bone_label_selection_signature"] = None
    _state["pose_hidden_armatures"] = {}
    _state["pose_visibility_resume_after_save"] = False
    _state["rig_hover_mouse"] = {}
    _state["surface_contact_syncing"] = False
    _state["surface_contact_reconciling"] = False
    _state["surface_contact_solver_syncing"] = False
    _state["pin_target_dragging"] = False
    _state["pin_snap_transform_active"] = False
    _state["pin_snap_transform_operator"] = ""
    _state["pin_snap_syncing"] = False
    _state["pin_snap_latches"] = set()
    _state["pin_snap_departing"] = set()
    _state["pin_snap_detached"] = set()
    _state["pin_snap_transform_seen"] = set()
    _state["pin_snap_last_depsgraph_sync"] = 0.0
    _state["pin_gizmo_axes_visible"] = {}
    _state["pin_gizmo_selection_keys"] = ()
    _state["pin_gizmo_selected_key"] = ""
    _state["pin_gizmo_pending_click"] = None
    _state["pin_gizmo_selection_epoch"] = 0
    _state["pin_gizmo_claim_serial"] = 0
    _state["pin_gizmo_last_claim"] = None
    _state["pin_gizmo_extend_selection_until"] = 0.0
    _state["pin_gizmo_deferred_finishes"] = []
    _state["pin_keyboard_transform_active"] = False
    _state["pin_yellow_history_fallbacks"] = {}
    _state["pin_history_active"] = False
    _state["pin_history_contact_snapshot"] = None
    _state["pin_history_syncing"] = False
    _state["pin_clipboard"] = None
    _state["surface_contact_solver_syncing"] = True
    try:
        bpy.context.view_layer.update()
        _surface_contact_restore_snap_detached(bpy.context)
    except (AttributeError, RuntimeError):
        pass
    finally:
        _state["surface_contact_solver_syncing"] = False
    if not _register_addon_keymaps():
        bpy.app.timers.register(
            _register_addon_keymaps_timer,
            first_interval = 0.05,
        )

    for h in list(bpy.app.handlers.frame_change_pre):
        if getattr(h, "__name__", "") == "_dynamic_space_frame_change_pre":
            bpy.app.handlers.frame_change_pre.remove(h)
    bpy.app.handlers.frame_change_pre.append(_dynamic_space_frame_change_pre)

    for h in list(bpy.app.handlers.frame_change_post):
        if getattr(h, "__name__", "") in {
            "_unparent_frame_change_post",
            "_part_pivot_frame_change_post",
            "_surface_contact_frame_change_post",
        }:
            bpy.app.handlers.frame_change_post.remove(h)
    bpy.app.handlers.frame_change_post.append(_unparent_frame_change_post)
    bpy.app.handlers.frame_change_post.append(_part_pivot_frame_change_post)
    bpy.app.handlers.frame_change_post.append(_surface_contact_frame_change_post)

    for h in list(bpy.app.handlers.load_post):
        if getattr(h, "__name__", "") == "_load_post":
            bpy.app.handlers.load_post.remove(h)
    bpy.app.handlers.load_post.append(_load_post)

    for handler_list, handler_function in (
        (bpy.app.handlers.save_pre, _pose_visibility_save_pre),
        (bpy.app.handlers.save_post, _pose_visibility_save_post),
    ):
        for handler in list(handler_list):
            if getattr(handler, "__name__", "") == handler_function.__name__:
                handler_list.remove(handler)
        handler_list.append(handler_function)

    for handler_list in (
        bpy.app.handlers.undo_pre,
        bpy.app.handlers.redo_pre,
    ):
        for handler in list(handler_list):
            if getattr(handler, "__name__", "") == "_pin_history_pre":
                handler_list.remove(handler)
        handler_list.append(_pin_history_pre)

    for handler_list in (
        bpy.app.handlers.undo_post,
        bpy.app.handlers.redo_post,
    ):
        for handler in list(handler_list):
            if getattr(handler, "__name__", "") == "_pin_undo_post":
                handler_list.remove(handler)
        handler_list.append(_pin_undo_post)

    for h in list(bpy.app.handlers.depsgraph_update_post):
        if getattr(h, "__name__", "") == "_smart_material_import_depsgraph_update":
            bpy.app.handlers.depsgraph_update_post.remove(h)
    bpy.app.handlers.depsgraph_update_post.append(_smart_material_import_depsgraph_update)

    for h in list(bpy.app.handlers.depsgraph_update_post):
        if getattr(h, "__name__", "") in {
            "_roblox_compatibility_depsgraph_update",
            "_part_pivot_depsgraph_update",
            "_surface_contact_depsgraph_update_post",
            "_dynamic_space_depsgraph_update",
        }:
            bpy.app.handlers.depsgraph_update_post.remove(h)
    bpy.app.handlers.depsgraph_update_post.append(_roblox_compatibility_depsgraph_update)
    bpy.app.handlers.depsgraph_update_post.append(_part_pivot_depsgraph_update)
    if bpy.app.timers.is_registered(_run_scheduled_dynamic_space_reconcile):
        bpy.app.timers.unregister(_run_scheduled_dynamic_space_reconcile)
    _state["dynamic_space_reconciling"] = False
    _state["dynamic_space_reconcile_pending"] = False
    _state["dynamic_space_calibrating"] = False
    _state["dynamic_space_export_sampling"] = False
    _state["dynamic_space_last_action_update"] = 0.0
    _state["dynamic_space_marker_signature"] = None
    bpy.app.handlers.depsgraph_update_post.append(_dynamic_space_depsgraph_update)
    bpy.app.handlers.depsgraph_update_post.append(
        _surface_contact_depsgraph_update_post
    )
    if bpy.app.timers.is_registered(_dynamic_space_marker_watch_timer):
        bpy.app.timers.unregister(_dynamic_space_marker_watch_timer)
    bpy.app.timers.register(
        _dynamic_space_marker_watch_timer,
        first_interval = 0.25,
        persistent = True,
    )

    bpy.app.timers.register(lambda: (_yellow_refresh_runtime(bpy.context), None)[1], first_interval = 0.1)
    bpy.app.timers.register(lambda: (_sync_view3d_relationship_lines(bpy.context), None)[1], first_interval = 0.1)
    old_free_view_handle = _state.get("free_view_draw_handle")
    if old_free_view_handle is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(
                old_free_view_handle,
                "WINDOW",
            )
        except (ReferenceError, RuntimeError, ValueError):
            pass
    try:
        _state["free_view_draw_handle"] = (
            bpy.types.SpaceView3D.draw_handler_add(
                _free_view_draw_sync,
                (),
                "WINDOW",
                "PRE_VIEW",
            )
        )
    except (ReferenceError, RuntimeError, ValueError):
        _state["free_view_draw_handle"] = None
    bpy.app.timers.register(
        _camera_view_exit_timer,
        first_interval = 0.05,
        persistent = True,
    )
    bpy.app.timers.register(_sync_all_attached_camera_object_visibility, first_interval = 0.2)
    bpy.app.timers.register(
        _part_pivot_selection_timer,
        first_interval = 0.05,
        persistent = True,
    )
    bpy.app.timers.register(
        _bone_label_selection_timer,
        first_interval = 0.05,
        persistent = True,
    )
    if bpy.app.timers.is_registered(_pin_snap_timer):
        bpy.app.timers.unregister(_pin_snap_timer)
    bpy.app.timers.register(
        _pin_snap_timer,
        first_interval = 0.04,
        persistent = True,
    )
    bpy.app.timers.register(lambda: (_smart_material_import_scan(bpy.context.scene), None)[1], first_interval = 0.2)
    bpy.app.timers.register(lambda: (_apply_roblox_compatibility(bpy.context.scene), None)[1], first_interval = 0.3)
    bpy.app.timers.register(_configure_roblox_sidebar_tabs, first_interval = 0.5)
    bpy.app.timers.register(
        _expand_new_animation_channels,
        first_interval = 0.15,
        persistent = True,
    )

def unregister():
    _unregister_addon_keymaps()
    _restore_pose_session_armature_visibility()
    if bpy.context and bpy.context.scene:
        _sync_dynamic_parent_constraints(int(bpy.context.scene.frame_current))
    _restore_roblox_bone_color_patch()
    _restore_all_dynamic_pose_bone_colors()
    _restore_roblox_nodes_only_default()
    _restore_roblox_import_patch()
    _restore_roblox_advanced_panel_filter()
    _restore_roblox_serializer_patch()
    _restore_roblox_export_patch()
    _sync_armature_debug_overlays(True)

    for timer_function in (
        _run_smart_material_import_scan,
        _run_roblox_compatibility_scan,
        _camera_view_exit_timer,
        _enter_pending_roblox_rigs_pose_mode,
        _part_pivot_selection_timer,
        _bone_label_selection_timer,
        _initialize_material_import_tracking,
        _register_addon_keymaps_timer,
        _run_dynamic_keyframe_name_migration,
        _expand_new_animation_channels,
        _dynamic_space_marker_watch_timer,
        _clear_pin_history_visibility,
        _pin_gizmo_run_deferred_finishes,
        _pin_click_away_timer,
        _pin_snap_timer,
    ):
        try:
            if bpy.app.timers.is_registered(timer_function):
                bpy.app.timers.unregister(timer_function)
        except Exception:
            pass

    try:
        if bpy.context and bpy.context.window_manager:
            if getattr(
                bpy.context.window_manager,
                "staticaliza_pivot_mode",
                "BONE",
            ) == "PART":
                _disable_part_pivot(bpy.context)
            bpy.context.window_manager.onion_skin_enabled = False
    except Exception:
        pass

    try:
        for h in list(bpy.app.handlers.frame_change_pre):
            if getattr(h, "__name__", "") == "_dynamic_space_frame_change_pre":
                bpy.app.handlers.frame_change_pre.remove(h)

        for h in list(bpy.app.handlers.frame_change_post):
            if getattr(h, "__name__", "") in {
                "_unparent_frame_change_post",
                "_part_pivot_frame_change_post",
                "_surface_contact_frame_change_post",
            }:
                bpy.app.handlers.frame_change_post.remove(h)

        for h in list(bpy.app.handlers.load_post):
            if getattr(h, "__name__", "") == "_load_post":
                bpy.app.handlers.load_post.remove(h)

        for handler_list, handler_name in (
            (bpy.app.handlers.save_pre, "_pose_visibility_save_pre"),
            (bpy.app.handlers.save_post, "_pose_visibility_save_post"),
        ):
            for handler in list(handler_list):
                if getattr(handler, "__name__", "") == handler_name:
                    handler_list.remove(handler)

        for handler_list in (
            bpy.app.handlers.undo_pre,
            bpy.app.handlers.redo_pre,
        ):
            for handler in list(handler_list):
                if getattr(handler, "__name__", "") == "_pin_history_pre":
                    handler_list.remove(handler)

        for handler_list in (
            bpy.app.handlers.undo_post,
            bpy.app.handlers.redo_post,
        ):
            for handler in list(handler_list):
                if getattr(handler, "__name__", "") == "_pin_undo_post":
                    handler_list.remove(handler)

        for h in list(bpy.app.handlers.depsgraph_update_post):
            if getattr(h, "__name__", "") == "_smart_material_import_depsgraph_update":
                bpy.app.handlers.depsgraph_update_post.remove(h)
            if getattr(h, "__name__", "") == "_roblox_compatibility_depsgraph_update":
                bpy.app.handlers.depsgraph_update_post.remove(h)
            if getattr(h, "__name__", "") == "_part_pivot_depsgraph_update":
                bpy.app.handlers.depsgraph_update_post.remove(h)
            if getattr(h, "__name__", "") == "_surface_contact_depsgraph_update_post":
                bpy.app.handlers.depsgraph_update_post.remove(h)
            if getattr(h, "__name__", "") == "_dynamic_space_depsgraph_update":
                bpy.app.handlers.depsgraph_update_post.remove(h)
        if bpy.app.timers.is_registered(_run_scheduled_dynamic_space_reconcile):
            bpy.app.timers.unregister(_run_scheduled_dynamic_space_reconcile)
        _state["dynamic_space_reconciling"] = False
        _state["dynamic_space_reconcile_pending"] = False
        _state["dynamic_space_calibrating"] = False
        _state["dynamic_space_export_sampling"] = False
        _state["dynamic_space_last_action_update"] = 0.0
        _state["dynamic_space_marker_signature"] = None
        _state["surface_contact_syncing"] = False
        _state["surface_contact_solver_syncing"] = False
        _state["pin_snap_departing"] = set()
        _state["pin_snap_detached"] = set()
        _state["pin_snap_transform_seen"] = set()
        _state["pin_gizmo_selection_keys"] = ()
        _state["pin_gizmo_selected_key"] = ""
        _state["pin_gizmo_pending_click"] = None
        _state["pin_gizmo_last_claim"] = None
        _state["pin_gizmo_extend_selection_until"] = 0.0
        _state["pin_gizmo_deferred_finishes"] = []
        _state["pin_keyboard_transform_active"] = False
        _state["pin_yellow_history_fallbacks"] = {}
        _state["pin_history_active"] = False
        _state["pin_history_contact_snapshot"] = None
        _state["pin_history_syncing"] = False
    except Exception:
        pass

    free_view_handle = _state.get("free_view_draw_handle")
    if free_view_handle is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(
                free_view_handle,
                "WINDOW",
            )
        except (ReferenceError, RuntimeError, ValueError):
            pass
        _state["free_view_draw_handle"] = None

    _disable_runtime()

    _dp_unregister()

    for c in reversed(classes):
        bpy.utils.unregister_class(c)

    for name in (
        "onion_skin_enabled",
        "onion_skin_opacity",
        "onion_skin_include_meshes",
        "onion_skin_include_bones",
        "onion_skin_raycast",
        "onion_skin_skip_hidden",
        "smart_material_import_enabled",
        "standardize_imported_material_display_enabled",
        "prevent_clothing_layer_clipping_enabled",
        "yellow_pin_mode",
        "roblox_compat_advanced_mode",
        "show_bone_names_enabled",
        "staticaliza_pivot_mode",
        "staticaliza_camera_fov_preset",
        "staticaliza_camera_fov",
        "staticaliza_camera_orientation",
        "staticaliza_surface_contact_mode",
    ):
        if hasattr(bpy.types.WindowManager, name):
            delattr(bpy.types.WindowManager, name)
    for name in (
        "staticaliza_camera_fov_preset",
        "staticaliza_camera_orientation",
        "staticaliza_camera_hide_attached_preview",
        "staticaliza_camera_hide_attached_object",
    ):
        if hasattr(bpy.types.Object, name):
            delattr(bpy.types.Object, name)
