"""External Roblox Animator compatibility and updating."""
