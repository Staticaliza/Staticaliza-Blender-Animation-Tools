"""Roblox Animator and Utils download, installation, and update integration."""

from ..core.runtime import *  # noqa: F403

RBX_RELEASE_API_URL = "https://api.github.com/repos/Cautioned/Blender-Animations-Plugin/releases/latest"
RBX_ADDON_ID = "roblox_animations_importer_exporter"
UTILS_ADDON_ID = "staticaliza_blender_animation_tools"
UTILS_PACKAGE_URL = (
    "https://raw.githubusercontent.com/Staticaliza/"
    "Staticaliza-Blender-Animation-Tools/main/src/"
    "staticaliza_blender_animation_tools.zip"
)


def _roblox_addon_module_name(refresh = False):
    try:
        modules = addon_utils.modules(refresh = refresh)
    except Exception:
        return None

    for module in modules:
        module_name = getattr(module, "__name__", "")
        if module_name == RBX_ADDON_ID or module_name.endswith(f".{RBX_ADDON_ID}"):
            return module_name
    return None


def _roblox_addon_is_enabled():
    return hasattr(bpy.types, "OBJECT_PT_RbxAnimations")


def _refresh_roblox_armature_list(context = None, force = False):
    """Invalidate Cautioned's cached enum as soon as rig objects change."""
    signature = tuple(sorted(
        (_armature_session_uid(obj), obj.name)
        for obj in bpy.data.objects
        if obj.type == "ARMATURE"
    ))
    if (
        not force
        and signature == _state.get("roblox_armature_list_signature")
    ):
        return False
    _state["roblox_armature_list_signature"] = signature

    module_name = _roblox_addon_module_name()
    if module_name is None:
        return False
    try:
        core_utils = importlib.import_module(f"{module_name}.core.utils")
        core_utils.invalidate_armature_cache()
        names = tuple(core_utils.get_cached_armatures())
    except (AttributeError, ImportError, RuntimeError):
        return False

    context = context or bpy.context
    scene = getattr(context, "scene", None)
    settings = getattr(scene, "rbx_anim_settings", None) if scene else None
    if settings is not None:
        current = str(getattr(settings, "rbx_anim_armature", ""))
        if current not in names and names:
            active = _active_armature(context)
            replacement = (
                active.name
                if active is not None and active.name in names
                else names[0]
            )
            try:
                settings.rbx_anim_armature = replacement
            except (AttributeError, RuntimeError, TypeError, ValueError):
                pass
    _tag_redraw_all_view3d()
    return True


def _download_json(url):
    separator = "&" if "?" in url else "?"
    request = urllib.request.Request(
        f"{url}{separator}_staticaliza_cache_bust={time.time_ns()}",
        headers = {
            "Accept": "application/vnd.github+json",
            "Cache-Control": "no-cache, no-store, max-age=0",
            "Pragma": "no-cache",
            "User-Agent": "Staticaliza-Blender-Animation-Tools",
        },
    )
    with urllib.request.urlopen(request, timeout = 20) as response:
        return json.loads(response.read().decode("utf-8"))


def _get_roblox_release_asset():
    release = _download_json(RBX_RELEASE_API_URL)
    assets = [
        asset for asset in release.get("assets", [])
        if str(asset.get("name", "")).lower().endswith(".zip")
    ]
    if not assets:
        raise RuntimeError("The latest release has no ZIP package.")

    use_legacy = bpy.app.version < (4, 1, 0)
    preferred = [
        asset for asset in assets
        if ("legacy" in str(asset.get("name", "")).lower()) == use_legacy
    ]
    asset = preferred[0] if preferred else assets[0]
    asset_url = asset.get("browser_download_url")
    if not asset_url:
        raise RuntimeError("The release package has no download URL.")

    return release.get("tag_name", "latest"), asset.get("name", "package.zip"), asset_url


def _download_release_asset(asset_name, asset_url):
    safe_name = os.path.basename(asset_name) or "roblox_animations.zip"
    destination = os.path.join(tempfile.gettempdir(), f"staticaliza_{safe_name}")
    separator = "&" if "?" in asset_url else "?"
    request = urllib.request.Request(
        f"{asset_url}{separator}_staticaliza_cache_bust={time.time_ns()}",
        headers = {
            "Cache-Control": "no-cache, no-store, max-age=0",
            "Pragma": "no-cache",
            "User-Agent": "Staticaliza-Blender-Animation-Tools",
        },
    )

    try:
        with urllib.request.urlopen(request, timeout = 60) as response, open(destination, "wb") as output:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                output.write(chunk)

        return _prepare_roblox_addon_zip(destination)
    except Exception:
        if os.path.exists(destination):
            try:
                os.remove(destination)
            except OSError:
                pass
        raise


def _utils_package_version(filepath, source_label):
    with zipfile.ZipFile(filepath) as package:
        if package.testzip() is not None:
            raise RuntimeError(f"The {source_label} Utils ZIP failed its integrity check.")
        manifest_names = [
            name for name in package.namelist()
            if name.replace("\\", "/").endswith("blender_manifest.toml")
        ]
        if not manifest_names:
            raise RuntimeError(f"The {source_label} Utils ZIP has no Blender manifest.")
        manifest_name = min(manifest_names, key = lambda name: name.count("/"))
        manifest = tomllib.loads(package.read(manifest_name).decode("utf-8"))
        if manifest.get("id") != UTILS_ADDON_ID:
            raise RuntimeError(f"The {source_label} ZIP is not Roblox Animator Utils.")
        return str(manifest.get("version", "unknown"))


def _utils_version_key(version):
    parts = []
    for token in str(version).strip().split("."):
        digits = ""
        for character in token:
            if not character.isdigit():
                break
            digits += character
        if not digits:
            break
        parts.append(int(digits))
    return tuple(parts) if parts else (-1,)


def _copy_local_utils_package(local_package, destination):
    staged_destination = f"{destination}.dev"
    try:
        with open(local_package, "rb") as source, open(staged_destination, "wb") as output:
            while True:
                chunk = source.read(1024 * 1024)
                if not chunk:
                    break
                output.write(chunk)
        with zipfile.ZipFile(
            staged_destination,
            "a",
            compression = zipfile.ZIP_DEFLATED,
        ) as package:
            if ".staticaliza_dev_build" not in package.namelist():
                package.writestr(
                    ".staticaliza_dev_build",
                    "Installed from the local developer source ZIP.\n",
                )
        os.replace(staged_destination, destination)
    finally:
        if os.path.exists(staged_destination):
            try:
                os.remove(staged_destination)
            except OSError:
                pass


def _download_utils_package():
    handle, destination = tempfile.mkstemp(prefix = "staticaliza_utils_", suffix = ".zip")
    os.close(handle)

    windows_user = str(os.environ.get("USERNAME", "")).strip().casefold()
    home_user = os.path.basename(os.path.expanduser("~")).strip().casefold()
    local_package = None
    local_version = None
    local_error = None
    if "41358" in {windows_user, home_user}:
        local_package = (
            r"C:\Users\41358\Documents\_Blender\ExtensionsDev\src"
            r"\staticaliza_blender_animation_tools.zip"
        )
        if os.path.isfile(local_package):
            try:
                local_version = _utils_package_version(local_package, "local")
            except Exception as exc:
                local_error = exc
                local_package = None

    separator = "&" if "?" in UTILS_PACKAGE_URL else "?"
    request = urllib.request.Request(
        f"{UTILS_PACKAGE_URL}{separator}_staticaliza_cache_bust={time.time_ns()}",
        headers = {
            "Cache-Control": "no-cache, no-store, max-age=0",
            "Pragma": "no-cache",
            "User-Agent": "Staticaliza-Blender-Animation-Tools",
        },
    )

    remote_version = None
    remote_error = None
    try:
        with urllib.request.urlopen(request, timeout = 60) as response, open(destination, "wb") as output:
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                output.write(chunk)

        remote_version = _utils_package_version(destination, "downloaded")
    except Exception as exc:
        remote_error = exc

    if (
        local_package is not None
        and local_version is not None
        and (
            remote_version is None
            or _utils_version_key(local_version)
            >= _utils_version_key(remote_version)
        )
    ):
        try:
            _copy_local_utils_package(local_package, destination)
            return destination, f"{local_version} (DEV)"
        except Exception as exc:
            local_error = exc

    if remote_version is not None:
        return destination, remote_version

    try:
        os.remove(destination)
    except OSError:
        pass
    details = []
    if local_error is not None:
        details.append(f"local: {local_error}")
    if remote_error is not None:
        details.append(f"GitHub: {remote_error}")
    raise RuntimeError(
        "No valid Roblox Animator Utils package was available"
        + (f" ({'; '.join(details)})" if details else ".")
    )


def _extension_repository_is_locked():
    try:
        from bl_pkg import cookie_from_session
        from bl_pkg.bl_extension_utils import repo_lock_directory_query
    except ImportError:
        return False

    extensions = getattr(bpy.context.preferences, "extensions", None)
    repositories = getattr(extensions, "repos", ())
    repository = next(
        (repo for repo in repositories if repo.module == "user_default"),
        None,
    )
    if repository is None:
        return False

    return repo_lock_directory_query(
        repository.directory,
        cookie_from_session(),
    ) is not None


def _replace_manifest_display_name(data, display_name):
    text = data.decode("utf-8")
    lines = text.splitlines(keepends = True)

    for index, line in enumerate(lines):
        if not line.lstrip().startswith("name ="):
            continue
        indent = line[:len(line) - len(line.lstrip())]
        newline = "\r\n" if line.endswith("\r\n") else "\n" if line.endswith("\n") else ""
        lines[index] = f'{indent}name = "{display_name}"{newline}'
        return "".join(lines).encode("utf-8")

    raise RuntimeError("Downloaded Blender manifest has no name field.")


def _replace_bl_info_display_name(data, display_name):
    text = data.decode("utf-8")
    lines = text.splitlines(keepends = True)
    in_bl_info = False

    for index, line in enumerate(lines):
        stripped = line.strip()
        if stripped.startswith("bl_info") and "{" in stripped:
            in_bl_info = True
            continue
        if not in_bl_info:
            continue
        if stripped == "}":
            break
        if not (stripped.startswith('"name"') or stripped.startswith("'name'")):
            continue

        indent = line[:len(line) - len(line.lstrip())]
        newline = "\r\n" if line.endswith("\r\n") else "\n" if line.endswith("\n") else ""
        lines[index] = f'{indent}"name": "{display_name}",{newline}'
        return "".join(lines).encode("utf-8")

    raise RuntimeError("Downloaded add-on metadata has no name field.")


def _replace_roblox_panel_display_name(data):
    text = data.decode("utf-8")
    text = text.replace(
        'bl_label = "Rbx Animations"',
        'bl_label = "Roblox Animator" + (f" (v{ADDON_VERSION_TEXT})" if ADDON_VERSION_TEXT.lower() != "unknown" else "")',
    )
    text = text.replace(
        "bl_label = 'Rbx Animations'",
        'bl_label = "Roblox Animator" + (f" (v{ADDON_VERSION_TEXT})" if ADDON_VERSION_TEXT.lower() != "unknown" else "")',
    )
    text = text.replace('"Rbx Animations"', '"Roblox Animator"')
    text = text.replace("'Rbx Animations'", "'Roblox Animator'")
    text = text.replace('text="Bake (Clipboard)"', 'text="Export"')
    text = text.replace("text='Bake (Clipboard)'", "text='Export'")
    version_block = (
        "        version_row = layout.row()\n"
        "        version_row.alignment = \"RIGHT\"\n"
        "        version_row.label(text=f\"v{ADDON_VERSION_TEXT}\")\n\n"
    )
    text = text.replace(version_block, "")
    text = text.replace(version_block.replace("\n", "\r\n"), "")
    return text.encode("utf-8")


def _replace_roblox_export_metadata(data):
    text = data.decode("utf-8")
    text = text.replace(
        'class OBJECT_OT_Bake(bpy.types.Operator):\n'
        '    bl_label = "Bake"\n'
        '    bl_idname = "object.rbxanims_bake"\n'
        '    bl_description = "Bake animation for export to clipboard"',
        'class OBJECT_OT_Bake(bpy.types.Operator):\n'
        '    bl_label = "Export"\n'
        '    bl_idname = "object.rbxanims_bake"\n'
        '    bl_description = "Export animation to clipboard"',
    )
    text = text.replace(
        'bl_description = "Bake animation for export to clipboard"',
        'bl_description = "Export animation to clipboard"',
    )
    return text.encode("utf-8")


def _prepare_roblox_addon_zip(filepath):
    repacked_path = f"{filepath}.install.zip"

    try:
        with zipfile.ZipFile(filepath) as package:
            infos = [info for info in package.infolist() if info.filename]
            normalized_names = []

            for info in infos:
                normalized = info.filename.replace("\\", "/").lstrip("/")
                parts = [part for part in normalized.split("/") if part]
                if not parts or ".." in parts:
                    raise RuntimeError("Downloaded ZIP contains an unsafe path.")
                normalized_names.append(normalized)

            if not any(name.endswith("__init__.py") for name in normalized_names):
                raise RuntimeError("Downloaded ZIP is not a Blender add-on package.")

            manifest_names = [
                name for name in normalized_names if name.endswith("blender_manifest.toml")
            ]
            if not manifest_names:
                raise RuntimeError("Downloaded ZIP has no Blender manifest.")
            manifest_name = min(manifest_names, key = lambda name: name.count("/"))
            manifest_parent = manifest_name.rsplit("/", 1)[0] if "/" in manifest_name else ""
            package_init_name = f"{manifest_parent}/__init__.py" if manifest_parent else "__init__.py"
            if package_init_name not in normalized_names:
                raise RuntimeError("Downloaded ZIP has no package __init__.py beside its manifest.")
            with zipfile.ZipFile(repacked_path, "w", compression = zipfile.ZIP_DEFLATED) as output:
                for info, normalized in zip(infos, normalized_names):
                    if info.is_dir():
                        output.writestr(f"{normalized.rstrip('/')}/", b"")
                        continue

                    data = package.read(info)
                    if normalized == manifest_name:
                        data = _replace_manifest_display_name(data, "Roblox Animator")
                    elif normalized == package_init_name:
                        data = _replace_bl_info_display_name(data, "Roblox Animator")
                    elif normalized.endswith("ui/panels.py"):
                        data = _replace_roblox_panel_display_name(data)
                    elif normalized.endswith("operators/animation_ops.py"):
                        data = _replace_roblox_export_metadata(data)
                    output.writestr(normalized, data)
    except Exception:
        if os.path.exists(repacked_path):
            try:
                os.remove(repacked_path)
            except OSError:
                pass
        raise

    os.remove(filepath)
    return repacked_path


def _purge_addon_module_tree(module_name):
    """Drop an installed add-on's cached Python modules before re-enabling it."""
    if not module_name:
        return
    prefix = f"{module_name}."
    for cached_name in tuple(sys.modules):
        if cached_name == module_name or cached_name.startswith(prefix):
            sys.modules.pop(cached_name, None)
    importlib.invalidate_caches()


def _enable_freshly_installed_addon(module_finder, previous_module_name, label):
    # package_install_files replaces files but does not evict Python's module
    # cache. Enabling that cache would silently run the pre-update build again.
    _purge_addon_module_tree(previous_module_name)
    module_name = module_finder(refresh = True)
    if module_name is None:
        raise RuntimeError(f"Blender installed {label} but could not locate its module.")
    if not addon_utils.check(module_name)[1]:
        try:
            addon_utils.enable(module_name, default_set = True, persistent = True)
        except TypeError:
            addon_utils.enable(module_name, default_set = True)
    if not addon_utils.check(module_name)[1]:
        raise RuntimeError(f"Blender installed {label} but could not enable it.")
    return module_name


def _install_roblox_addon(filepath):
    extension_ops = getattr(bpy.ops, "extensions", None)
    install = getattr(extension_ops, "package_install_files", None)
    if install is None:
        raise RuntimeError("This Blender build does not expose the extension installer API.")

    existing_module = _roblox_addon_module_name(refresh = True)
    was_enabled = bool(existing_module and addon_utils.check(existing_module)[1])
    if was_enabled:
        addon_utils.disable(existing_module, default_set = True)

    try:
        try:
            result = install(
                "EXEC_DEFAULT",
                filepath = filepath,
                repo = "user_default",
                enable_on_install = False,
                overwrite = True,
            )
        except TypeError:
            result = install("EXEC_DEFAULT", filepath = filepath, repo = "user_default")
        if "FINISHED" not in result:
            raise RuntimeError("Blender did not finish installing Roblox Animator.")

        _enable_freshly_installed_addon(
            _roblox_addon_module_name,
            existing_module,
            "Roblox Animator",
        )
    except Exception:
        if (
            was_enabled
            and existing_module
            and not addon_utils.check(existing_module)[1]
        ):
            try:
                addon_utils.enable(existing_module, default_set = True, persistent = True)
            except TypeError:
                addon_utils.enable(existing_module, default_set = True)
        raise

    register_owned_timer(_configure_roblox_sidebar_tabs, first_interval = 0.1)


def _utils_addon_module_name(refresh = False):
    for module in addon_utils.modules(refresh = refresh):
        module_name = getattr(module, "__name__", "")
        if module_name == UTILS_ADDON_ID or module_name.endswith(f".{UTILS_ADDON_ID}"):
            return module_name
    return None


def _capture_utils_contact_update_poses():
    """Capture exact pink poses across Blender's disable/install cycle."""
    snapshots = []
    try:
        guides = tuple(_surface_contact_active_simulated_guides(
            bpy.context.scene
        ))
    except (AttributeError, ReferenceError, RuntimeError):
        guides = ()
    seen = set()
    for guide in guides:
        armature, pose_bone = _surface_contact_pose_bone(guide)
        if armature is None or pose_bone is None:
            continue
        owner = (armature.name, pose_bone.name)
        if owner in seen:
            continue
        seen.add(owner)
        snapshots.append((
            armature.name,
            pose_bone.name,
            pose_bone.matrix_basis.copy(),
        ))
    return tuple(snapshots)


def _restore_utils_contact_update_poses(snapshots):
    """Restore authored pink bases after the new module has registered."""
    restored = []
    for armature_name, bone_name, matrix_basis in tuple(snapshots or ()):
        armature = bpy.data.objects.get(str(armature_name))
        pose_bone = (
            armature.pose.bones.get(str(bone_name))
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is None:
            continue
        pose_bone.matrix_basis = Matrix(matrix_basis).copy()
        restored.append(pose_bone)
    context = getattr(bpy, "context", None)
    if restored and context is not None:
        context.view_layer.update()
        # Make the restored side the only recovery value the new module can
        # observe. This prevents its delayed registration timer from replaying
        # the pose produced midway through disable/re-enable.
        for pose_bone in restored:
            packed = tuple(
                float(value)
                for row in pose_bone.matrix_basis
                for value in row
            )
            pose_bone[SURFACE_CONTACT_SAVED_POSE_PROPERTY] = packed
        for guide in tuple(_surface_contact_guides()):
            armature, pose_bone = _surface_contact_pose_bone(guide)
            if pose_bone not in restored:
                continue
            guide[SURFACE_CONTACT_SAVED_POSE_PROPERTY] = tuple(
                float(value)
                for row in pose_bone.matrix_basis
                for value in row
            )
    return bool(restored)


def _install_utils_addon(filepath):
    extension_ops = getattr(bpy.ops, "extensions", None)
    install = getattr(extension_ops, "package_install_files", None)
    if install is None:
        raise RuntimeError("This Blender build does not expose the extension installer API.")

    original_module_name = _utils_addon_module_name(refresh = True)
    was_enabled = bool(original_module_name and addon_utils.check(original_module_name)[1])
    contact_update_poses = _capture_utils_contact_update_poses()
    if was_enabled:
        addon_utils.disable(original_module_name, default_set = True)

    try:
        try:
            result = install(
                "EXEC_DEFAULT",
                filepath = filepath,
                repo = "user_default",
                enable_on_install = False,
                overwrite = True,
            )
        except TypeError:
            result = install("EXEC_DEFAULT", filepath = filepath, repo = "user_default")
        if "FINISHED" not in result:
            raise RuntimeError("Blender did not finish installing Roblox Animator Utils.")

        _enable_freshly_installed_addon(
            _utils_addon_module_name,
            original_module_name,
            "Roblox Animator Utils",
        )
        _restore_utils_contact_update_poses(contact_update_poses)
        if not hasattr(bpy.types, "VIEW3D_PT_animator_utils_main"):
            raise RuntimeError(
                "Roblox Animator Utils enabled without registering its sidebar panel."
            )
    except Exception:
        if (
            was_enabled
            and original_module_name
            and not addon_utils.check(original_module_name)[1]
        ):
            try:
                addon_utils.enable(original_module_name, default_set = True, persistent = True)
            except TypeError:
                addon_utils.enable(original_module_name, default_set = True)
        raise
