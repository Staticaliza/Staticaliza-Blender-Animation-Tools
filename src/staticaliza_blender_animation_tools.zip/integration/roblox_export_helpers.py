"""Roblox export discovery, keyed-bone filtering, and patch metadata helpers."""

from ..core.runtime import *  # noqa: F403

ROBLOX_UTILS_PATCH_KIND_ATTR = "_roblox_animator_utils_patch_kind"
ROBLOX_UTILS_PATCH_ORIGINAL_ATTR = "_roblox_animator_utils_original"
ROBLOX_UTILS_EXPORT_DEPTH_ATTR = "_roblox_animator_utils_export_depth"
DYNAMIC_EXPORT_TARGET_FPS = 240.0
DYNAMIC_EXPORT_MAX_SAMPLE_FACTOR = 16
ROBLOX_ANIMATION_LOOP_METADATA_KEYS = (
    # Canonical custom-payload spelling used by Animator Utils.
    "loop",
    # Roblox exposes AnimationClip/KeyframeSequence.Loop, while some importer
    # adapters serialize the property name without changing its case.
    "Loop",
    # AnimationTrack uses Looped; keep both JSON naming conventions so an
    # importer can consume the metadata without requiring a Blender re-export.
    "looped",
    "Looped",
)


def _apply_roblox_animation_metadata(result, scene):
    """Attach compatible animation-level loop metadata to an export."""
    if not isinstance(result, dict):
        return result
    loop = bool(getattr(scene, ROBLOX_ANIMATION_LOOP_PROPERTY, False))
    export_info = result.get("export_info")
    if not isinstance(export_info, dict):
        export_info = {}
        result["export_info"] = export_info
    for key in ROBLOX_ANIMATION_LOOP_METADATA_KEYS:
        result[key] = loop
        export_info[key] = loop
    return result


def _surface_contact_export_bones(armature_obj):
    if armature_obj is None or getattr(armature_obj, "pose", None) is None:
        return set()
    bone_names = set()
    for guide in _surface_contact_guides():
        if str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, "")) != armature_obj.name:
            continue
        effector = armature_obj.pose.bones.get(
            str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
        )
        if effector is None:
            continue
        chain_count = int(guide.get(SURFACE_CONTACT_CHAIN_PROPERTY, 1))
        bone_names.update(
            pose_bone.name
            for pose_bone in _surface_contact_chain(effector, chain_count)
        )
    return bone_names


def _roblox_export_source_actions(armature_obj):
    """Return only actions that contribute to the armature's current export."""
    animation_data = getattr(armature_obj, "animation_data", None)
    if animation_data is None:
        return ()

    actions = []
    seen = set()

    def add_action(action):
        if action is None:
            return
        try:
            key = int(action.as_pointer())
        except (AttributeError, ReferenceError, TypeError, ValueError):
            key = id(action)
        if key in seen:
            return
        seen.add(key)
        actions.append(action)

    add_action(getattr(animation_data, "action", None))
    if bool(getattr(animation_data, "use_nla", False)):
        for track in getattr(animation_data, "nla_tracks", ()):
            if bool(getattr(track, "mute", False)):
                continue
            for strip in getattr(track, "strips", ()):
                if bool(getattr(strip, "mute", False)):
                    continue
                add_action(getattr(strip, "action", None))
    return tuple(actions)


def _pose_bone_name_from_animation_path(data_path):
    """Extract and unescape the leading pose-bone name in an RNA path."""
    prefix = 'pose.bones["'
    data_path = str(data_path or "")
    if not data_path.startswith(prefix):
        return ""

    encoded = data_path[len(prefix):]
    characters = []
    escaped = False
    for index, character in enumerate(encoded):
        if escaped:
            characters.append(character)
            escaped = False
            continue
        if character == "\\":
            escaped = True
            continue
        if character == '"' and encoded[index:index + 2] == '"]':
            return "".join(characters)
        characters.append(character)
    return ""


def _roblox_export_keyed_pose_bones(armature_obj):
    """Find bones with at least one authored key in current source actions."""
    keyed_bones = set()
    for action in _roblox_export_source_actions(armature_obj):
        for fcurve in _action_fcurves(action, armature_obj):
            try:
                if len(fcurve.keyframe_points) < 1:
                    continue
            except (AttributeError, ReferenceError, TypeError):
                continue
            bone_name = _pose_bone_name_from_animation_path(
                getattr(fcurve, "data_path", "")
            )
            if bone_name:
                keyed_bones.add(bone_name)
    return keyed_bones


def _filter_unkeyed_bones_from_roblox_export(result, authored_bones):
    """Remove pose payloads that have no authored animation source."""
    if not isinstance(result, dict):
        return result

    authored_bones = set(authored_bones or ())
    filtered_keyframes = []
    for keyframe in result.get("kfs", ()):
        if not isinstance(keyframe, dict):
            continue
        states = keyframe.get("kf")
        if isinstance(states, dict):
            for bone_name in tuple(states):
                if bone_name not in authored_bones:
                    states.pop(bone_name, None)
        if states or keyframe.get("fc"):
            filtered_keyframes.append(keyframe)
    result["kfs"] = filtered_keyframes
    return result


def _unwrap_animator_utils_patch(
    function,
    patch_kind,
    legacy_code_names = (),
    legacy_original_names = (),
):
    current = function
    visited = set()
    while callable(current) and id(current) not in visited:
        visited.add(id(current))
        candidate = None
        if getattr(current, ROBLOX_UTILS_PATCH_KIND_ATTR, "") == patch_kind:
            candidate = getattr(current, ROBLOX_UTILS_PATCH_ORIGINAL_ATTR, None)
        else:
            code = getattr(current, "__code__", None)
            if code is not None and code.co_name in legacy_code_names:
                closure = getattr(current, "__closure__", None) or ()
                for name, cell in zip(code.co_freevars, closure):
                    if name not in legacy_original_names:
                        continue
                    try:
                        value = cell.cell_contents
                    except ValueError:
                        continue
                    if callable(value):
                        candidate = value
                        break
        if not callable(candidate) or candidate is current:
            break
        current = candidate
    return current


def _tag_animator_utils_patch(function, original, patch_kind):
    setattr(function, ROBLOX_UTILS_PATCH_KIND_ATTR, patch_kind)
    setattr(function, ROBLOX_UTILS_PATCH_ORIGINAL_ATTR, original)
    return function
