"""Roblox preview drawing and bone-color monkey patches."""

from ..core.runtime import *  # noqa: F403

_ROBLOX_PREVIEW_DRAW_PATCH_KIND = "roblox_preview_draw"
_ROBLOX_PREVIEW_DRAW_TARGETS = (
    (
        "rig.com",
        "_draw_com_callback",
        "_com_draw_handler",
        "POST_VIEW",
    ),
    (
        "rig.physics",
        "_draw_physics_callback",
        "_physics_draw_handler",
        "POST_VIEW",
    ),
    (
        "operators.validation_ops",
        "_draw_motionpath_violations",
        "_violation_draw_handler",
        "POST_VIEW",
    ),
    (
        "operators.validation_ops",
        "_draw_motionpath_labels",
        "_violation_label_draw_handler",
        "POST_PIXEL",
    ),
    (
        "operators.validation_ops",
        "_draw_motionpath_keyframes",
        "_keyframe_points_draw_handler",
        "POST_VIEW",
    ),
    (
        "operators.validation_ops",
        "_draw_floor_limit",
        "_floor_limit_draw_handler",
        "POST_VIEW",
    ),
)


def _sync_roblox_animation_loop_mode(scene):
    """Use Blender's native playback stop mode where the API provides it."""
    if scene is None or not hasattr(scene, "playback_loop_mode"):
        return False
    baselines = _state.setdefault("roblox_animation_loop_modes", {})
    try:
        scene_key = int(scene.as_pointer())
        baselines.setdefault(scene_key, str(scene.playback_loop_mode))
        scene.playback_loop_mode = (
            "INFINITE"
            if bool(getattr(scene, ROBLOX_ANIMATION_LOOP_PROPERTY, False))
            else "STOP_END_FRAME"
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return False
    return True


def _restore_roblox_animation_loop_modes():
    baselines = _state.pop("roblox_animation_loop_modes", {})
    if not baselines:
        return
    for scene in tuple(bpy.data.scenes):
        if not hasattr(scene, "playback_loop_mode"):
            continue
        try:
            baseline = baselines.get(int(scene.as_pointer()))
            if baseline is not None:
                scene.playback_loop_mode = baseline
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            continue


def _on_roblox_animation_loop_change(scene, _context):
    _sync_roblox_animation_loop_mode(scene)


def _hide_animation_playback_statusbars(*_):
    """Compatibility no-op: playback must not hide the user's whole statusbar."""
    return False


def _restore_animation_playback_statusbars(*_):
    baselines = _state.pop("roblox_animation_statusbars", {})
    for screen in tuple(bpy.data.screens):
        baseline = baselines.get(int(screen.as_pointer()))
        if baseline is not None:
            screen.show_statusbar = bool(baseline)


def _roblox_preview_playback_handlers():
    return ()


def _restore_roblox_preview_state():
    _restore_roblox_preview_draw_callbacks()
    _restore_roblox_animation_loop_modes()
    _restore_animation_playback_statusbars()


def _cancel_animation_playback(window, screen):
    try:
        with bpy.context.temp_override(window = window, screen = screen):
            if bpy.ops.screen.animation_cancel.poll():
                bpy.ops.screen.animation_cancel(restore_frame = False)
                return True
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        pass
    return False


def _roblox_animation_loop_timer():
    """Backport stop-at-end playback to Blender versions before 5.2."""
    context = getattr(bpy, "context", None)
    window_manager = getattr(context, "window_manager", None)
    scene = getattr(context, "scene", None)
    if window_manager is None or scene is None:
        return 0.1
    if (
        _pin_primary_mouse_pressed()
        or _window_manager_has_modal_operator(context)
    ):
        return 0.1

    if hasattr(scene, "playback_loop_mode"):
        _sync_roblox_animation_loop_mode(scene)
        return 0.25

    playing_windows = [
        window
        for window in tuple(getattr(window_manager, "windows", ()))
        if bool(getattr(getattr(window, "screen", None), "is_animation_playing", False))
    ]
    current_frame = int(scene.frame_current)
    previous_frame = int(
        _state.get("roblox_animation_playback_frame", current_frame)
    )
    _state["roblox_animation_playback_frame"] = current_frame
    if not playing_windows:
        return 0.1
    if bool(getattr(scene, ROBLOX_ANIMATION_LOOP_PROPERTY, False)):
        return 0.02

    reached_end = current_frame >= int(scene.frame_end)
    wrapped_to_start = current_frame < previous_frame
    if reached_end or wrapped_to_start:
        if wrapped_to_start:
            try:
                scene.frame_set(int(scene.frame_end))
            except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
                pass
        for window in playing_windows:
            _cancel_animation_playback(window, window.screen)
    return 0.01


def _restore_roblox_preview_draw_patch_record(
    record,
    preserve_active = True,
):
    module = record["module"]
    module_name = record["module_name"]
    callback_name = record["callback_name"]
    handle_name = record["handle_name"]
    draw_type = record["draw_type"]
    original_callback = record["original_callback"]
    patched_callback = record["patched_callback"]

    # Only replace a handler that still belongs to this wrapper. If Cautioned
    # reloaded the module before our compatibility scan ran, its new callback
    # and handler must be left alone for the next patch pass to adopt.
    if getattr(module, callback_name, None) is not patched_callback:
        return

    active_handle = getattr(module, handle_name, None)
    if active_handle is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(
                active_handle,
                "WINDOW",
            )
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            pass
        try:
            setattr(module, handle_name, None)
        except (AttributeError, ReferenceError, TypeError):
            pass

    try:
        setattr(module, callback_name, original_callback)
    except (AttributeError, ReferenceError, TypeError):
        return

    module_is_current = sys.modules.get(module_name) is module
    if not (preserve_active and active_handle is not None and module_is_current):
        return

    try:
        restored_handle = bpy.types.SpaceView3D.draw_handler_add(
            original_callback,
            (),
            "WINDOW",
            draw_type,
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        restored_handle = None
    try:
        setattr(module, handle_name, restored_handle)
    except (AttributeError, ReferenceError, TypeError):
        pass


def _restore_roblox_preview_draw_callbacks():
    patches = _state.pop("roblox_preview_draw_patches", None)
    if not patches:
        _state["roblox_preview_draw_patches"] = {}
        return
    for record in tuple(patches.values()):
        _restore_roblox_preview_draw_patch_record(record)
    _state["roblox_preview_draw_patches"] = {}


def _patch_roblox_preview_draw_callbacks():
    module_name = _roblox_addon_module_name()
    if module_name is None:
        return False

    patches = _state.setdefault("roblox_preview_draw_patches", {})
    patched_any = False
    for (
        module_suffix,
        callback_name,
        handle_name,
        draw_type,
    ) in _ROBLOX_PREVIEW_DRAW_TARGETS:
        target_module_name = f"{module_name}.{module_suffix}"
        try:
            target_module = importlib.import_module(target_module_name)
        except ImportError:
            continue

        current_callback = getattr(target_module, callback_name, None)
        if not callable(current_callback):
            continue

        patch_key = (module_suffix, callback_name)
        existing = patches.get(patch_key)
        if (
            existing is not None
            and existing["module"] is target_module
            and current_callback is existing["patched_callback"]
        ):
            patched_any = True
            continue

        if existing is not None:
            # A module reload can replace functions in-place or replace the
            # entire module. Retire only an old wrapper we still own; the new
            # handler is adopted and replaced below.
            _restore_roblox_preview_draw_patch_record(
                existing,
                preserve_active = False,
            )
            patches.pop(patch_key, None)
            current_callback = getattr(target_module, callback_name, None)
            if not callable(current_callback):
                continue

        original_callback = _unwrap_animator_utils_patch(
            current_callback,
            _ROBLOX_PREVIEW_DRAW_PATCH_KIND,
        )

        def make_preview_guard(callback):
            def draw_without_preview(*args, **kwargs):
                if _context_is_presentation_view(getattr(bpy, "context", None)):
                    return None
                return callback(*args, **kwargs)

            draw_without_preview.__name__ = callback.__name__
            draw_without_preview.__doc__ = callback.__doc__
            draw_without_preview.__module__ = callback.__module__
            draw_without_preview.__qualname__ = callback.__qualname__
            return _tag_animator_utils_patch(
                draw_without_preview,
                callback,
                _ROBLOX_PREVIEW_DRAW_PATCH_KIND,
            )

        patched_callback = make_preview_guard(original_callback)
        active_handle = getattr(target_module, handle_name, None)
        if active_handle is not None:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(
                    active_handle,
                    "WINDOW",
                )
            except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
                pass
            try:
                setattr(target_module, handle_name, None)
            except (AttributeError, ReferenceError, TypeError):
                pass

        try:
            setattr(target_module, callback_name, patched_callback)
        except (AttributeError, ReferenceError, TypeError):
            continue

        if active_handle is not None:
            try:
                replacement_handle = bpy.types.SpaceView3D.draw_handler_add(
                    patched_callback,
                    (),
                    "WINDOW",
                    draw_type,
                )
            except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
                # Keep Cautioned's feature active if installing the guarded
                # replacement fails for an unexpected Blender/API state.
                setattr(target_module, callback_name, original_callback)
                try:
                    replacement_handle = bpy.types.SpaceView3D.draw_handler_add(
                        original_callback,
                        (),
                        "WINDOW",
                        draw_type,
                    )
                except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
                    replacement_handle = None
                try:
                    setattr(target_module, handle_name, replacement_handle)
                except (AttributeError, ReferenceError, TypeError):
                    pass
                continue
            try:
                setattr(target_module, handle_name, replacement_handle)
            except (AttributeError, ReferenceError, TypeError):
                pass

        patches[patch_key] = {
            "module": target_module,
            "module_name": target_module_name,
            "callback_name": callback_name,
            "handle_name": handle_name,
            "draw_type": draw_type,
            "original_callback": original_callback,
            "patched_callback": patched_callback,
        }
        patched_any = True

    return patched_any


def _restore_roblox_bone_color_patch():
    patches = _state.pop("roblox_bone_color_patches", None)
    if not patches:
        return
    for module, attribute, original_function, patched_function in patches:
        if getattr(module, attribute, None) is patched_function:
            setattr(module, attribute, original_function)


def _patch_roblox_bone_color_updates():
    module_name = _roblox_addon_module_name()
    if module_name is None:
        return False

    patch_targets = (
        (f"{module_name}.rig.creation", "_configure_weld_bones"),
        (f"{module_name}.rig.ik", "create_ik_config"),
        (f"{module_name}.rig.ik", "remove_ik_config"),
        (f"{module_name}.rig", "create_ik_config"),
        (f"{module_name}.rig", "remove_ik_config"),
        (f"{module_name}.operators.rig_ops", "create_ik_config"),
        (f"{module_name}.operators.rig_ops", "remove_ik_config"),
    )
    resolved_targets = []
    for target_module_name, attribute in patch_targets:
        try:
            target_module = importlib.import_module(target_module_name)
        except ImportError:
            continue
        if callable(getattr(target_module, attribute, None)):
            resolved_targets.append((target_module, attribute))
    if not resolved_targets:
        return False

    existing = _state.get("roblox_bone_color_patches")
    if existing and all(
        getattr(module, attribute, None) is patched_function
        for module, attribute, _original_function, patched_function in existing
    ):
        return True
    _restore_roblox_bone_color_patch()

    patches = []
    for target_module, attribute in resolved_targets:
        original_function = _unwrap_animator_utils_patch(
            getattr(target_module, attribute),
            "roblox_bone_color",
        )

        def make_color_update(function):
            def update_with_combined_bone_colors(*args, **kwargs):
                _restore_all_dynamic_pose_bone_colors()
                try:
                    return function(*args, **kwargs)
                finally:
                    scene = getattr(bpy.context, "scene", None)
                    if scene is not None:
                        _sync_all_dynamic_pose_bone_colors(
                            int(scene.frame_current)
                        )
                    _tag_redraw_all_view3d()

            update_with_combined_bone_colors.__name__ = function.__name__
            update_with_combined_bone_colors.__doc__ = function.__doc__
            update_with_combined_bone_colors.__module__ = function.__module__
            update_with_combined_bone_colors.__qualname__ = function.__qualname__
            return _tag_animator_utils_patch(
                update_with_combined_bone_colors,
                function,
                "roblox_bone_color",
            )

        patched_function = make_color_update(original_function)
        setattr(target_module, attribute, patched_function)
        patches.append(
            (target_module, attribute, original_function, patched_function)
        )

    _state["roblox_bone_color_patches"] = patches
    return bool(patches)
