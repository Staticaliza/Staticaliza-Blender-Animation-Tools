"""Non-destructive monkey patches for the external Roblox Animator add-on."""

from ..core.runtime import *  # noqa: F403

_ADVANCED_ROBLOX_PANEL_HEADERS = frozenset({"Roblox Account", "UGC Emote Validation"})
_FACE_ROBLOX_PANEL_HEADERS = frozenset({"Face Controls"})
_ADVANCED_ROBLOX_OPERATORS = frozenset({
    "object.rbxanims_genrig",
    "object.rbxanims_autoconstraint",
    "object.rbxanims_manualconstraint",
    "object.rbxanims_toggle_weld_bones",
    "object.rbxanims_toggle_com",
    "object.rbxanims_toggle_com_grid",
    "object.rbxanims_edit_com_weights",
    "object.rbxanims_mapkeyframes",
    "object.rbxanims_applytransform",
    "object.rbxanims_bake_file",
    "object.rbxanims_importfbxanimation",
})
_ADVANCED_ROBLOX_PROPERTIES = frozenset({
    "rbx_auto_deform_scale",
    "rbx_deform_rig_scale",
    "rbx_full_range_bake",
})
_ADVANCED_ROBLOX_LABELS = frozenset({"Center of Mass:"})
ROBLOX_ANIMATION_LOOP_PROPERTY = "roblox_animation_loop"


class ROBLOX_ANIMATOR_UTILS_OT_edit_animation_length(bpy.types.Operator):
    bl_idname = "roblox_animator_utils.edit_animation_length"
    bl_label = "Animation Length"
    bl_description = "Edit animation length as frames or frame-accurate time"
    bl_options = {"REGISTER", "UNDO"}

    value: bpy.props.StringProperty(name = "Time")

    def invoke(self, context, _event):
        self.value = _get_roblox_animation_length(context.scene)
        return context.window_manager.invoke_props_dialog(self, width = 220)

    def draw(self, _context):
        self.layout.prop(self, "value", text = "Time")

    def execute(self, context):
        try:
            _parse_animation_length(
                self.value,
                _scene_nominal_fps(context.scene),
            )
        except (TypeError, ValueError) as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        setattr(context.scene, ROBLOX_ANIMATION_LENGTH_PROPERTY, self.value)
        return {"FINISHED"}


def _roblox_operator_ui_kwargs(operator_id, kwargs):
    updated = dict(kwargs)
    if operator_id == "object.rbxanims_bake":
        updated["text"] = "Export"
    elif operator_id == "object.rbxanims_importmodel":
        updated["text"] = "Import Rig"
    return updated


def _draw_roblox_loop_setting(layout, operator_id):
    """Place playback settings immediately above Cautioned's Export."""
    if operator_id != "object.rbxanims_bake":
        return
    scene = getattr(bpy.context, "scene", None)
    if scene is None or not hasattr(scene, ROBLOX_ANIMATION_LOOP_PROPERTY):
        return
    layout.prop(scene, ROBLOX_ANIMATION_LOOP_PROPERTY, text = "Loop")
    if hasattr(scene, ROBLOX_ANIMATION_LENGTH_PROPERTY):
        length = _animation_length_frames(scene)
        timecode = _get_roblox_animation_length(scene)
        split = layout.split(factor = 0.3, align = True)
        split.label(text = "Length:")
        split.operator(
            "roblox_animator_utils.edit_animation_length",
            text = f"{timecode} ({length}f)",
        )


class _NullOperatorProperties:
    def __setattr__(self, name, value):
        pass


class _NullUILayout:
    def __setattr__(self, name, value):
        pass

    def row(self, *args, **kwargs):
        return self

    def column(self, *args, **kwargs):
        return self

    def column_flow(self, *args, **kwargs):
        return self

    def grid_flow(self, *args, **kwargs):
        return self

    def split(self, *args, **kwargs):
        return self

    def box(self, *args, **kwargs):
        return self

    def operator(self, *args, **kwargs):
        return _NullOperatorProperties()

    def __getattr__(self, name):
        return lambda *args, **kwargs: None


_NULL_UI_LAYOUT = _NullUILayout()
_UI_CONTAINER_METHODS = frozenset({"row", "column", "column_flow", "grid_flow", "split"})


class _UILayoutProxy:
    __slots__ = ("_layout", "_hidden_headers", "_hide_advanced")

    def __init__(self, layout, hidden_headers, hide_advanced = False):
        object.__setattr__(self, "_layout", layout)
        object.__setattr__(self, "_hidden_headers", hidden_headers)
        object.__setattr__(self, "_hide_advanced", hide_advanced)

    def box(self, *args, **kwargs):
        return _LazyBoxProxy(
            self._layout,
            self._hidden_headers,
            self._hide_advanced,
            args,
            kwargs,
        )

    def label(self, *args, **kwargs):
        text = kwargs.get("text", args[0] if args else "")
        if self._hide_advanced and text in _ADVANCED_ROBLOX_LABELS:
            return None
        return self._layout.label(*args, **kwargs)

    def operator(self, *args, **kwargs):
        operator_id = args[0] if args else kwargs.get("operator", "")
        if self._hide_advanced and operator_id in _ADVANCED_ROBLOX_OPERATORS:
            return _NullOperatorProperties()
        _draw_roblox_loop_setting(self._layout, operator_id)
        kwargs = _roblox_operator_ui_kwargs(operator_id, kwargs)
        return self._layout.operator(*args, **kwargs)

    def prop(self, *args, **kwargs):
        property_name = args[1] if len(args) > 1 else kwargs.get("property", "")
        if self._hide_advanced and property_name in _ADVANCED_ROBLOX_PROPERTIES:
            return None
        return self._layout.prop(*args, **kwargs)

    def __getattr__(self, name):
        attribute = getattr(self._layout, name)
        if not callable(attribute) or name not in _UI_CONTAINER_METHODS:
            return attribute

        def call_container(*args, **kwargs):
            return _UILayoutProxy(
                attribute(*args, **kwargs),
                self._hidden_headers,
                self._hide_advanced,
            )

        return call_container

    def __setattr__(self, name, value):
        setattr(self._layout, name, value)


class _LazyBoxProxy:
    __slots__ = (
        "_parent_layout",
        "_hidden_headers",
        "_hide_advanced",
        "_box_args",
        "_box_kwargs",
        "_layout_proxy",
        "_suppressed",
    )

    def __init__(self, parent_layout, hidden_headers, hide_advanced, box_args, box_kwargs):
        object.__setattr__(self, "_parent_layout", parent_layout)
        object.__setattr__(self, "_hidden_headers", hidden_headers)
        object.__setattr__(self, "_hide_advanced", hide_advanced)
        object.__setattr__(self, "_box_args", box_args)
        object.__setattr__(self, "_box_kwargs", box_kwargs)
        object.__setattr__(self, "_layout_proxy", None)
        object.__setattr__(self, "_suppressed", False)

    def _materialize(self):
        if self._layout_proxy is None:
            layout = self._parent_layout.box(*self._box_args, **self._box_kwargs)
            object.__setattr__(
                self,
                "_layout_proxy",
                _UILayoutProxy(layout, self._hidden_headers, self._hide_advanced),
            )
        return self._layout_proxy

    def label(self, *args, **kwargs):
        if self._suppressed:
            return None
        text = kwargs.get("text", args[0] if args else "")
        if text in self._hidden_headers:
            object.__setattr__(self, "_suppressed", True)
            return None
        if self._hide_advanced and text in _ADVANCED_ROBLOX_LABELS:
            return None
        return self._materialize().label(*args, **kwargs)

    def __getattr__(self, name):
        if self._suppressed:
            return getattr(_NULL_UI_LAYOUT, name)
        if name in _UI_CONTAINER_METHODS:
            def call_container(*args, **kwargs):
                return _DeferredLayoutProxy(self, name, args, kwargs)

            return call_container
        return getattr(self._materialize(), name)

    def __setattr__(self, name, value):
        if not self._suppressed:
            setattr(self._materialize(), name, value)


class _DeferredLayoutProxy:
    __slots__ = ("_root", "_parent", "_method", "_args", "_kwargs", "_layout")

    def __init__(self, root, method, args, kwargs, parent = None):
        object.__setattr__(self, "_root", root)
        object.__setattr__(self, "_parent", parent)
        object.__setattr__(self, "_method", method)
        object.__setattr__(self, "_args", args)
        object.__setattr__(self, "_kwargs", kwargs)
        object.__setattr__(self, "_layout", None)

    def _materialize(self):
        if self._layout is None:
            parent_layout = self._parent._materialize() if self._parent else self._root._materialize()
            layout = getattr(parent_layout, self._method)(*self._args, **self._kwargs)
            object.__setattr__(self, "_layout", layout)
        return self._layout

    def _hide_if_needed(self, args, kwargs):
        text = kwargs.get("text", args[0] if args else "")
        if text not in self._root._hidden_headers:
            return False
        object.__setattr__(self._root, "_suppressed", True)
        return True

    def label(self, *args, **kwargs):
        if self._root._suppressed:
            return None
        if self._hide_if_needed(args, kwargs):
            return None
        text = kwargs.get("text", args[0] if args else "")
        if self._root._hide_advanced and text in _ADVANCED_ROBLOX_LABELS:
            return None
        return self._materialize().label(*args, **kwargs)

    def prop(self, *args, **kwargs):
        if self._root._suppressed:
            return None
        if self._hide_if_needed((), kwargs):
            return None
        property_name = args[1] if len(args) > 1 else kwargs.get("property", "")
        if (
            self._root._hide_advanced
            and property_name in _ADVANCED_ROBLOX_PROPERTIES
        ):
            return None
        return self._materialize().prop(*args, **kwargs)

    def operator(self, *args, **kwargs):
        if self._root._suppressed:
            return _NullOperatorProperties()
        if self._hide_if_needed(args, kwargs):
            return _NullOperatorProperties()
        operator_id = args[0] if args else kwargs.get("operator", "")
        if self._root._hide_advanced and operator_id in _ADVANCED_ROBLOX_OPERATORS:
            return _NullOperatorProperties()
        layout = self._materialize()
        kwargs = _roblox_operator_ui_kwargs(operator_id, kwargs)
        return layout.operator(*args, **kwargs)

    def __getattr__(self, name):
        if self._root._suppressed:
            return getattr(_NULL_UI_LAYOUT, name)
        if name in _UI_CONTAINER_METHODS:
            def call_container(*args, **kwargs):
                return _DeferredLayoutProxy(
                    self._root,
                    name,
                    args,
                    kwargs,
                    parent = self,
                )

            return call_container
        return getattr(self._materialize(), name)

    def __setattr__(self, name, value):
        if not self._root._suppressed:
            setattr(self._materialize(), name, value)


class _PanelDrawProxy:
    __slots__ = ("_panel", "layout")

    def __init__(self, panel, layout):
        object.__setattr__(self, "_panel", panel)
        object.__setattr__(self, "layout", layout)

    def __getattr__(self, name):
        return getattr(self._panel, name)


def _restore_roblox_advanced_panel_filter():
    patches = _state.pop("roblox_advanced_panel_patch", None)
    if patches is None:
        return
    if isinstance(patches, tuple) and len(patches) == 3:
        patches = (patches,)
    for panel_class, original_draw, patched_draw in tuple(patches):
        if getattr(panel_class, "draw", None) is patched_draw:
            panel_class.draw = original_draw


def _patch_roblox_advanced_panels():
    panel_classes = tuple(
        panel_class
        for panel_name in (
            "OBJECT_PT_RbxAnimations",
            "OBJECT_PT_RbxAnimations_Tool",
        )
        if (panel_class := getattr(bpy.types, panel_name, None)) is not None
    )
    if not panel_classes:
        return False

    existing = _state.get("roblox_advanced_panel_patch")
    if existing is not None:
        existing_records = (
            (existing,)
            if isinstance(existing, tuple) and len(existing) == 3
            else tuple(existing)
        )
        if (
            len(existing_records) == len(panel_classes)
            and all(
                panel_class is record[0]
                and panel_class.draw is record[2]
                for panel_class, record in zip(panel_classes, existing_records)
            )
        ):
            return True
        _restore_roblox_advanced_panel_filter()

    patches = []
    for panel_class in panel_classes:
        original_draw = panel_class.draw

        def make_filtered_draw(draw_function):
            def draw_with_advanced_panel_filter(self, context):
                advanced_mode = getattr(
                    context.window_manager,
                    "roblox_compat_advanced_mode",
                    False,
                )
                hide_advanced = not advanced_mode
                hide_face_controls = not advanced_mode
                hidden_headers = set()
                if hide_advanced:
                    hidden_headers.update(_ADVANCED_ROBLOX_PANEL_HEADERS)
                if hide_face_controls:
                    hidden_headers.update(_FACE_ROBLOX_PANEL_HEADERS)
                layout = _UILayoutProxy(
                    self.layout,
                    frozenset(hidden_headers),
                    hide_advanced = hide_advanced,
                )
                return draw_function(_PanelDrawProxy(self, layout), context)

            draw_with_advanced_panel_filter.__name__ = draw_function.__name__
            draw_with_advanced_panel_filter.__doc__ = draw_function.__doc__
            draw_with_advanced_panel_filter.__module__ = draw_function.__module__
            draw_with_advanced_panel_filter.__qualname__ = draw_function.__qualname__
            return draw_with_advanced_panel_filter

        patched_draw = make_filtered_draw(original_draw)
        panel_class.draw = patched_draw
        patches.append((panel_class, original_draw, patched_draw))

    _state["roblox_advanced_panel_patch"] = tuple(patches)
    return True


def _restore_roblox_nodes_only_default():
    invoke_patch = _state.pop("roblox_genrig_invoke_patch", None)
    if invoke_patch is not None:
        operator_class, original_invoke, patched_invoke = invoke_patch
        if getattr(operator_class, "invoke", None) is patched_invoke:
            operator_class.invoke = original_invoke

    execute_patch = _state.pop("roblox_genrig_execute_patch", None)
    if execute_patch is not None:
        operator_class, original_execute, patched_execute = execute_patch
        if getattr(operator_class, "execute", None) is patched_execute:
            operator_class.execute = original_execute


def _restore_roblox_import_patch():
    patch = _state.pop("roblox_import_execute_patch", None)
    if patch is None:
        return

    operator_class, original_execute, patched_execute = patch
    if getattr(operator_class, "execute", None) is patched_execute:
        operator_class.execute = original_execute


def _patch_roblox_import_auto_generation():
    module_name = _roblox_addon_module_name()
    if module_name is None:
        return False

    try:
        import_ops = importlib.import_module(f"{module_name}.operators.import_ops")
        rig_ops = importlib.import_module(f"{module_name}.operators.rig_ops")
        operator_class = import_ops.OBJECT_OT_ImportModel
    except (AttributeError, ImportError):
        return False

    existing = _state.get("roblox_import_execute_patch")
    if existing is not None:
        if existing[0] is operator_class and operator_class.execute is existing[2]:
            return True
        _restore_roblox_import_patch()

    original_execute = operator_class.execute

    def execute_with_local_y_auto_generation(self, context):
        hide_advanced = not getattr(
            context.window_manager,
            "roblox_compat_advanced_mode",
            False,
        )
        previous_armatures = {
            obj.as_pointer() for obj in context.scene.objects if obj.type == "ARMATURE"
        }
        previous_meta = {
            obj.as_pointer()
            for obj in context.scene.objects
            if obj.type == "EMPTY" and "RigMeta" in obj
        }
        previous_collections = {
            collection.as_pointer() for collection in bpy.data.collections
        }

        original_create_rig = import_ops.create_rig
        if hide_advanced:
            def create_local_y_rig(_rigging_type, rig_meta_name):
                return original_create_rig("LOCAL_YAXIS_EXTEND", rig_meta_name)

            import_ops.create_rig = create_local_y_rig

        try:
            result = original_execute(self, context)
        finally:
            if hide_advanced:
                import_ops.create_rig = original_create_rig

        if "FINISHED" in result:
            isolated_images, isolated_materials = (
                _isolate_newly_imported_rig_textures(previous_collections)
            )
            if isolated_images:
                print(
                    "[Roblox Animator Utils] Isolated "
                    f"{isolated_images} texture node(s) across "
                    f"{isolated_materials} imported material(s)."
                )

        if "FINISHED" not in result:
            return result

        new_armatures = [
            obj
            for obj in context.scene.objects
            if obj.type == "ARMATURE" and obj.as_pointer() not in previous_armatures
        ]
        if new_armatures:
            _state.setdefault("roblox_constraints_new_rigs", set()).update(
                armature.as_pointer() for armature in new_armatures
            )
            _refresh_roblox_armature_list(context, force = True)
            _schedule_imported_rig_framing(new_armatures, context)
            _schedule_roblox_rigs_pose_mode(new_armatures)
        if not hide_advanced:
            return result

        new_meta_names = [
            obj.name
            for obj in context.scene.objects
            if obj.type == "EMPTY"
            and "RigMeta" in obj
            and obj.as_pointer() not in previous_meta
        ]

        if new_armatures or not new_meta_names:
            _schedule_roblox_compatibility_scan(delay = 0.05)
            _schedule_smart_material_import_scan(delay = 0.05)
            return result

        scene_name = context.scene.name

        def generate_imported_rig():
            scene = bpy.data.scenes.get(scene_name)
            if scene is None:
                return None

            armatures_before_generation = {
                obj.as_pointer()
                for obj in scene.objects
                if obj.type == "ARMATURE"
            }

            for meta_name in new_meta_names:
                meta = scene.objects.get(meta_name)
                if meta is None or "RigMeta" not in meta:
                    continue
                try:
                    rig_ops.create_rig("LOCAL_YAXIS_EXTEND", meta_name)
                except Exception as exc:
                    print(
                        f"[Roblox Animator Utils] Automatic Local Y-axis rig generation failed: {exc}"
                    )

            generated_armatures = [
                obj
                for obj in scene.objects
                if obj.type == "ARMATURE"
                and obj.as_pointer() not in armatures_before_generation
            ]

            if generated_armatures:
                _state.setdefault("roblox_constraints_new_rigs", set()).update(
                    armature.as_pointer() for armature in generated_armatures
                )

            _schedule_roblox_compatibility_scan(delay = 0.05)
            _schedule_smart_material_import_scan(delay = 0.05)
            if generated_armatures:
                _schedule_imported_rig_framing(
                    generated_armatures,
                    bpy.context,
                )
                _schedule_roblox_rigs_pose_mode(generated_armatures)
            return None

        register_owned_timer(generate_imported_rig, first_interval = 0.1)
        return result

    execute_with_local_y_auto_generation.__name__ = original_execute.__name__
    execute_with_local_y_auto_generation.__doc__ = original_execute.__doc__
    execute_with_local_y_auto_generation.__module__ = original_execute.__module__
    execute_with_local_y_auto_generation.__qualname__ = original_execute.__qualname__

    operator_class.execute = execute_with_local_y_auto_generation
    _state["roblox_import_execute_patch"] = (
        operator_class,
        original_execute,
        execute_with_local_y_auto_generation,
    )
    return True
