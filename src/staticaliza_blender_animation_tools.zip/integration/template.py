"""Bundled animation-template loading operator."""

from ..core.runtime import *  # noqa: F403


def _lock_bundled_template_baseplate():
    """Keep the bundled Baseplate out of normal selection and transforms."""
    baseplate = bpy.data.objects.get("Baseplate")
    if baseplate is None or baseplate.type != "MESH":
        return False
    try:
        bundled = any(
            _is_bundled_template_baseplate_material(slot.material)
            for slot in baseplate.material_slots
            if slot.material is not None
        )
    except (AttributeError, ReferenceError, RuntimeError):
        bundled = False
    if not bundled:
        return False

    try:
        baseplate.select_set(False)
    except (AttributeError, ReferenceError, RuntimeError):
        pass
    baseplate.hide_select = True
    baseplate.lock_location = (True, True, True)
    baseplate.lock_rotation = (True, True, True)
    baseplate.lock_scale = (True, True, True)
    return True


class ANIMATOR_UTILS_OT_load_template(bpy.types.Operator):
    bl_idname = "staticaliza.load_template"
    bl_label = "Load Template"
    bl_description = "Replace the current Blender file with the bundled animation template"

    def draw(self, context):
        layout = self.layout
        layout.label(text = "This replaces the entire current Blender file.", icon = "ERROR")
        layout.label(text = "All unsaved changes will be permanently lost.")
        layout.separator()
        layout.label(text = "Continue and load the animation template?")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width = 440)

    def execute(self, context):
        templates_directory = os.path.join(
            PACKAGE_ROOT,
            "templates",
        )
        template_path = os.path.join(templates_directory, "template.blend")
        baseplate_path = os.path.join(templates_directory, "Baseplate.png")
        if not os.path.isfile(template_path):
            self.report({"ERROR"}, "The bundled animation template is missing.")
            return {"CANCELLED"}
        if not os.path.isfile(baseplate_path):
            self.report({"ERROR"}, "The bundled Baseplate.png is missing.")
            return {"CANCELLED"}

        bpy.ops.wm.read_homefile(filepath = template_path, load_ui = True)
        _animator_utils_apply_file_defaults(bpy.context, force=True)
        _set_default_keyframe_handle_type()
        _capture_animation_channel_baseline()
        image = bpy.data.images.get("Baseplate.png")
        if image is None:
            image = bpy.data.images.load(baseplate_path, check_existing = True)
            image.pack()
        elif image.packed_file is None:
            image.filepath = baseplate_path
            image.reload()
            image.pack()
        _lock_bundled_template_baseplate()
        return {"FINISHED"}
