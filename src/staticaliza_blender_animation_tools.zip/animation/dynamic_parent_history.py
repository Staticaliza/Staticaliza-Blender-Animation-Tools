"""Undo/Redo pairing for follower keys committed after native transforms."""

from ..core.runtime import *  # noqa: F403


_DYNAMIC_PARENT_POSE_PROPERTIES = (
    "location",
    "scale",
    "rotation_euler",
    "rotation_quaternion",
    "rotation_axis_angle",
)


def _dynamic_parent_pose_keyed_at(armature, bone_name, frame):
    action = (
        armature.animation_data.action
        if armature is not None and armature.animation_data
        else None
    )
    if action is None:
        return False
    return any(
        _fcurve_key_at(curve, int(frame)) is not None
        for property_name in _DYNAMIC_PARENT_POSE_PROPERTIES
        for curve in _fcurves_find_all(
            action,
            _pose_dp(bone_name, property_name),
        )
    )


def _dynamic_parent_clear_pose_keys_at(armature, bone_name, frame):
    action = (
        armature.animation_data.action
        if armature is not None and armature.animation_data
        else None
    )
    if action is None:
        return False
    changed = False
    for property_name in _DYNAMIC_PARENT_POSE_PROPERTIES:
        data_path = _pose_dp(bone_name, property_name)
        if any(
            _fcurve_key_at(curve, int(frame)) is not None
            for curve in _fcurves_find_all(action, data_path)
        ):
            _fcurve_remove_key_all(action, data_path, int(frame))
            changed = True
    return changed


def _dynamic_parent_store_native_history_transition(entries):
    entries = tuple(entry for entry in entries if entry is not None)
    if not entries:
        return False
    _state["dynamic_parent_native_history_transition"] = {
        "entries": entries,
        "current_index": 1,
    }
    _state["dynamic_parent_native_history_expected_index"] = None
    return True


def _dynamic_parent_prepare_native_history_transition():
    transition = _state.get("dynamic_parent_native_history_transition")
    direction = str(_state.get("pin_history_direction", ""))
    expected = (
        0 if direction == "UNDO"
        else 1 if direction == "REDO"
        else None
    )
    _state["dynamic_parent_native_history_expected_index"] = (
        expected if transition else None
    )
    return expected is not None and transition is not None


def _dynamic_parent_history_parent_matches(entry, index):
    armature = _armature_from_session_uid(entry["parent_uid"])
    parent = (
        armature.pose.bones.get(entry["parent_bone"])
        if armature is not None and getattr(armature, "pose", None)
        else None
    )
    expected = (
        entry["parent_before_basis"]
        if int(index) == 0
        else entry["parent_after_basis"]
    )
    return bool(
        parent is not None
        and _matrices_nearly_equal(
            parent.matrix_basis,
            expected,
            tolerance=2.0e-5,
        )
    )


def _dynamic_parent_restore_native_history_transition(context):
    transition = _state.get("dynamic_parent_native_history_transition")
    index = _state.get("dynamic_parent_native_history_expected_index")
    _state["dynamic_parent_native_history_expected_index"] = None
    if not transition or index not in (0, 1):
        return False
    entries = tuple(transition.get("entries", ()))
    if not entries or not all(
        _dynamic_parent_history_parent_matches(entry, index)
        for entry in entries
    ):
        return False

    previous_mute = bool(_state.get("unparent_handler_mute", False))
    _state["unparent_handler_mute"] = True
    changed = False
    try:
        for entry in entries:
            armature = _armature_from_session_uid(entry["armature_uid"])
            pose_bone = (
                armature.pose.bones.get(entry["bone_name"])
                if armature is not None and getattr(armature, "pose", None)
                else None
            )
            if pose_bone is None:
                continue
            frame = int(entry["frame"])
            basis = (
                entry["child_before_basis"]
                if int(index) == 0
                else entry["child_after_basis"]
            )
            keyed = bool(
                entry["child_before_keyed"]
                if int(index) == 0
                else entry["child_after_keyed"]
            )
            changed = (
                _dynamic_parent_clear_pose_keys_at(
                    armature,
                    pose_bone.name,
                    frame,
                )
                or changed
            )
            pose_bone.matrix_basis = basis.copy()
            context.view_layer.update()
            if keyed:
                _dynamic_parent_force_pose_key(
                    pose_bone,
                    frame,
                    visual=False,
                )
            changed = True
        if changed:
            context.view_layer.update()
            _store_dynamic_parent_animation_signature()
        transition["current_index"] = int(index)
    finally:
        _state["unparent_handler_mute"] = previous_mute
    return changed


def _dynamic_parent_capture_history_snapshot(context):
    scene = getattr(context, "scene", None)
    frame = int(getattr(scene, "frame_current", 0))
    entries = []
    if scene is None:
        _state["dynamic_parent_history_snapshot"] = ()
        return False
    for armature in tuple(scene.objects):
        if (
            armature.type != "ARMATURE"
            or getattr(armature, "pose", None) is None
        ):
            continue
        for pose_bone in armature.pose.bones:
            constraint = _active_dynamic_parent_constraint(
                pose_bone,
                frame,
            )
            if constraint is None:
                continue
            target = _dynamic_parent_constraint_target(
                pose_bone,
                constraint,
            )
            subtarget = _dynamic_parent_constraint_subtarget(
                pose_bone,
                constraint,
            )
            if target is None:
                continue
            try:
                target_matrix = _pose_space_target_matrix(
                    context,
                    armature,
                    target,
                    subtarget,
                )
                output_matrix = _pose_space_output_matrix(
                    context,
                    armature,
                    pose_bone,
                )
            except (
                AttributeError,
                ReferenceError,
                RuntimeError,
                ValueError,
            ):
                continue
            entries.append({
                "armature_uid": _armature_session_uid(armature),
                "bone_name": pose_bone.name,
                "frame": frame,
                "target_matrix": target_matrix.copy(),
                "output_matrix": output_matrix.copy(),
            })
    _state["dynamic_parent_history_snapshot"] = tuple(entries)
    return bool(entries)


def _dynamic_parent_restore_history_followers(context):
    """Rebuild followers from the parent delta even without a transition."""

    entries = tuple(_state.get("dynamic_parent_history_snapshot", ()))
    scene = getattr(context, "scene", None)
    if not entries or scene is None:
        return False
    frame = int(scene.frame_current)
    previous_mute = bool(_state.get("unparent_handler_mute", False))
    _state["unparent_handler_mute"] = True
    changed = False
    try:
        for entry in entries:
            if int(entry["frame"]) != frame:
                continue
            armature = _armature_from_session_uid(entry["armature_uid"])
            pose_bone = (
                armature.pose.bones.get(entry["bone_name"])
                if armature is not None and getattr(armature, "pose", None)
                else None
            )
            constraint = (
                _active_dynamic_parent_constraint(pose_bone, frame)
                if pose_bone is not None
                else None
            )
            if constraint is None:
                continue
            target = _dynamic_parent_constraint_target(
                pose_bone,
                constraint,
            )
            if target is None:
                continue
            target_matrix = _pose_space_target_matrix(
                context,
                armature,
                target,
                _dynamic_parent_constraint_subtarget(
                    pose_bone,
                    constraint,
                ),
            )
            previous_target = entry["target_matrix"]
            if _matrices_nearly_equal(
                target_matrix,
                previous_target,
                tolerance=2.0e-5,
            ):
                continue
            desired_output = (
                target_matrix
                @ previous_target.inverted_safe()
                @ entry["output_matrix"]
            )
            input_matrix = _dynamic_parent_input_matrix(
                context,
                armature,
                constraint,
                desired_output,
            )
            constraint_mute = bool(constraint.mute)
            try:
                constraint.mute = True
                context.view_layer.update()
                pose_bone = armature.pose.bones.get(entry["bone_name"])
                pose_bone.matrix = input_matrix
                context.view_layer.update()
                _dynamic_parent_force_pose_key(
                    pose_bone,
                    frame,
                    visual=False,
                )
            finally:
                constraint.mute = constraint_mute
                context.view_layer.update()
            changed = True
        if changed:
            _store_dynamic_parent_animation_signature()
    finally:
        _state["unparent_handler_mute"] = previous_mute
    return changed
