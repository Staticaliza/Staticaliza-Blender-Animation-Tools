"""Undo/Redo pairing for follower keys committed after native transforms."""

from ..core.runtime import *  # noqa: F403

_DYNAMIC_PARENT_POSE_PROPERTIES = (
    "location",
    "scale",
    "rotation_euler",
    "rotation_quaternion",
    "rotation_axis_angle",
)
_DYNAMIC_PARENT_HISTORY_TOLERANCE = 2.0e-5
_DYNAMIC_PARENT_HISTORY_TRANSITION_TOLERANCE = 2.0e-5
_DYNAMIC_PARENT_HISTORY_KEY_EPSILON = 1.0e-5
_DYNAMIC_PARENT_HISTORY_PARENT_ROLE = "DYNAMIC_PARENT"
def _dynamic_parent_pose_key_paths(bone_name):
    return tuple(
        _pose_dp(bone_name, name) for name in _DYNAMIC_PARENT_POSE_PROPERTIES
    )
def _dynamic_parent_pose_key_snapshot(armature, bone_name, frame):
    action = (
        armature.animation_data.action
        if armature is not None and armature.animation_data
        else None
    )
    frame = float(frame)
    paths = set(_dynamic_parent_pose_key_paths(bone_name))
    curves = []
    keys = []
    for fcurve in _action_fcurves(action, armature):
        data_path = str(fcurve.data_path)
        if data_path not in paths:
            continue
        group = getattr(fcurve, "group", None)
        curves.append({
            "path": data_path,
            "index": int(fcurve.array_index),
            "group": str(getattr(group, "name", "")) if group else "",
            "extrapolation": str(getattr(fcurve, "extrapolation", "")),
            "color_mode": str(getattr(fcurve, "color_mode", "")),
            "auto_smoothing": str(getattr(fcurve, "auto_smoothing", "")),
        })
        for key in fcurve.keyframe_points:
            if abs(float(key.co.x) - frame) > _DYNAMIC_PARENT_HISTORY_KEY_EPSILON:
                continue
            keys.append({
                "path": data_path,
                "index": int(fcurve.array_index),
                "frame": float(key.co.x),
                "value": float(key.co.y),
                "interpolation": str(getattr(key, "interpolation", "")),
                "easing": str(getattr(key, "easing", "")),
                "type": str(getattr(key, "type", "")),
                "handle_left_type": str(getattr(key, "handle_left_type", "")),
                "handle_right_type": str(getattr(key, "handle_right_type", "")),
                "handle_left": tuple(float(value) for value in key.handle_left),
                "handle_right": tuple(float(value) for value in key.handle_right),
                "amplitude": float(getattr(key, "amplitude", 0.0)),
                "back": float(getattr(key, "back", 0.0)),
                "period": float(getattr(key, "period", 0.0)),
            })
    curves.sort(key=lambda item: (item["path"], item["index"]))
    keys.sort(key=lambda item: (item["path"], item["index"]))
    return {
        "frame": frame,
        "curves": tuple(curves),
        "keys": tuple(keys),
    }
def _dynamic_parent_pose_key_snapshot_present(snapshot):
    return bool(snapshot and snapshot.get("keys"))
def _dynamic_parent_history_rounded(value):
    return round(float(value), 10)
def _dynamic_parent_pose_key_snapshot_signature(snapshot):
    if snapshot is None:
        return None
    curves = tuple(
        (
            str(item.get("path", "")),
            int(item.get("index", 0)),
            str(item.get("group", "")),
            str(item.get("extrapolation", "")),
            str(item.get("color_mode", "")),
            str(item.get("auto_smoothing", "")),
        )
        for item in snapshot.get("curves", ())
    )
    keys = tuple(
        (
            str(item.get("path", "")),
            int(item.get("index", 0)),
            _dynamic_parent_history_rounded(item.get("frame", 0.0)),
            _dynamic_parent_history_rounded(item.get("value", 0.0)),
            str(item.get("interpolation", "")),
            str(item.get("easing", "")),
            str(item.get("type", "")),
            str(item.get("handle_left_type", "")),
            str(item.get("handle_right_type", "")),
            tuple(
                _dynamic_parent_history_rounded(value)
                for value in item.get("handle_left", ())
            ),
            tuple(
                _dynamic_parent_history_rounded(value)
                for value in item.get("handle_right", ())
            ),
            _dynamic_parent_history_rounded(item.get("amplitude", 0.0)),
            _dynamic_parent_history_rounded(item.get("back", 0.0)),
            _dynamic_parent_history_rounded(item.get("period", 0.0)),
        )
        for item in snapshot.get("keys", ())
    )
    return (
        _dynamic_parent_history_rounded(snapshot.get("frame", 0.0)),
        curves,
        keys,
    )
def _dynamic_parent_pose_key_snapshot_matches(
    armature,
    bone_name,
    frame,
    snapshot,
):
    return _dynamic_parent_pose_key_snapshot_signature(
        _dynamic_parent_pose_key_snapshot(armature, bone_name, frame)
    ) == _dynamic_parent_pose_key_snapshot_signature(snapshot)
def _dynamic_parent_set_history_fcurve_group(action, fcurve, group_name):
    group_name = str(group_name or "")
    if group_name:
        return _set_fcurve_group(fcurve, action, group_name)
    current_group = getattr(fcurve, "group", None)
    if current_group is None:
        return False
    groups = _fcurve_group_collection(action, fcurve)
    fcurve.group = None
    if groups is not None:
        try:
            if not tuple(current_group.channels):
                groups.remove(current_group)
        except (AttributeError, ReferenceError, RuntimeError, ValueError):
            pass
    return True
def _dynamic_parent_apply_history_curve_state(action, fcurve, saved):
    changed = _dynamic_parent_set_history_fcurve_group(
        action,
        fcurve,
        saved.get("group", ""),
    )
    for attribute in ("extrapolation", "color_mode", "auto_smoothing"):
        value = saved.get(attribute)
        if not value or not hasattr(fcurve, attribute):
            continue
        try:
            if str(getattr(fcurve, attribute)) != str(value):
                setattr(fcurve, attribute, value)
                changed = True
        except (AttributeError, RuntimeError, TypeError, ValueError):
            continue
    return changed
def _dynamic_parent_restore_pose_key_snapshot(
    armature,
    bone_name,
    snapshot,
):
    if armature is None or snapshot is None:
        return False
    frame = float(snapshot.get("frame", 0.0))
    if _dynamic_parent_pose_key_snapshot_matches(
        armature,
        bone_name,
        frame,
        snapshot,
    ):
        return False

    expected_curves = {
        (str(item.get("path", "")), int(item.get("index", 0))): item
        for item in snapshot.get("curves", ())
    }
    expected_keys = tuple(snapshot.get("keys", ()))
    action = armature.animation_data.action if armature.animation_data else None
    if action is None:
        if not expected_curves and not expected_keys:
            return False
        action = _ensure_object_action(armature)

    paths = set(_dynamic_parent_pose_key_paths(bone_name))
    changed = False
    for fcurve in tuple(_action_fcurves(action, armature)):
        if str(fcurve.data_path) not in paths:
            continue
        for key in tuple(fcurve.keyframe_points):
            if abs(float(key.co.x) - frame) <= _DYNAMIC_PARENT_HISTORY_KEY_EPSILON:
                fcurve.keyframe_points.remove(key)
                changed = True
        curve_id = (str(fcurve.data_path), int(fcurve.array_index))
        if not fcurve.keyframe_points and curve_id not in expected_curves:
            changed = _action_remove_fcurve(action, fcurve) or changed
        else:
            fcurve.update()

    def find_curve(data_path, array_index):
        return next(
            (
                candidate
                for candidate in _action_fcurves(action, armature)
                if str(candidate.data_path) == data_path
                and int(candidate.array_index) == array_index
            ),
            None,
        )

    for curve_id, saved_curve in expected_curves.items():
        fcurve = find_curve(*curve_id)
        if fcurve is None:
            fcurve = _action_new_fcurve(
                action,
                curve_id[0],
                animated_id=armature,
                index=curve_id[1],
                group_name=saved_curve.get("group", ""),
            )
            changed = True
        changed = _dynamic_parent_apply_history_curve_state(
            action, fcurve, saved_curve
        ) or changed

    for saved in expected_keys:
        data_path = str(saved.get("path", ""))
        array_index = int(saved.get("index", 0))
        fcurve = find_curve(data_path, array_index)
        if fcurve is None:
            curve_state = expected_curves.get(
                (data_path, array_index), {}
            )
            fcurve = _action_new_fcurve(
                action,
                data_path,
                animated_id=armature,
                index=array_index,
                group_name=curve_state.get("group", ""),
            )
            _dynamic_parent_apply_history_curve_state(
                action,
                fcurve,
                curve_state,
            )
        key = fcurve.keyframe_points.insert(
            float(saved.get("frame", frame)),
            float(saved.get("value", 0.0)),
        )
        for attribute in (
            "interpolation",
            "easing",
            "type",
            "handle_left_type",
            "handle_right_type",
            "amplitude",
            "back",
            "period",
        ):
            value = saved.get(attribute)
            if value in (None, ""):
                continue
            try:
                setattr(key, attribute, value)
            except (AttributeError, RuntimeError, TypeError, ValueError):
                pass
        if len(saved.get("handle_left", ())) == 2:
            key.handle_left = saved["handle_left"]
        if len(saved.get("handle_right", ())) == 2:
            key.handle_right = saved["handle_right"]
        fcurve.update()
        changed = True
    return changed
def _dynamic_parent_pose_keyed_at(armature, bone_name, frame):
    return _dynamic_parent_pose_key_snapshot_present(
        _dynamic_parent_pose_key_snapshot(armature, bone_name, frame)
    )
def _dynamic_parent_clear_pose_keys_at(armature, bone_name, frame):
    snapshot = dict(_dynamic_parent_pose_key_snapshot(armature, bone_name, frame))
    if not snapshot.get("keys"):
        return False
    snapshot["keys"] = ()
    return _dynamic_parent_restore_pose_key_snapshot(
        armature,
        bone_name,
        snapshot,
    )

def _dynamic_parent_history_driver_constraint(pose_bone, frame, chosen):
    if chosen is None:
        return (None, "")
    if chosen.name.startswith("DP_"):
        return (chosen, _DYNAMIC_PARENT_HISTORY_PARENT_ROLE)
    if (
        chosen.name.startswith(SPACE_CONSTRAINT_PREFIX)
        and _dynamic_space_role(pose_bone, chosen) == SPACE_ROLE_UNPARENT
    ):
        start, _end = _dynamic_parent_constraint_segment(pose_bone, chosen)
        if start is None:
            return (None, "")
        return (
            _chosen_dynamic_parent_constraint(pose_bone, int(start) - 1),
            SPACE_ROLE_UNPARENT,
        )
    return (None, "")

def _dynamic_parent_history_driver_selection_keys(target, subtarget):
    if (
        target is None
        or getattr(target, "type", "") != "ARMATURE"
        or not subtarget
        or getattr(target, "pose", None) is None
    ):
        return ()
    pose_bone = target.pose.bones.get(str(subtarget))
    target_uid = _armature_session_uid(target)
    keys = []
    while pose_bone is not None:
        keys.append((target_uid, pose_bone.name))
        pose_bone = pose_bone.parent
    return tuple(keys)


def _dynamic_parent_history_driver_pose_snapshots(target, subtarget, frame):
    snapshots = []
    for armature_uid, bone_name in (
        _dynamic_parent_history_driver_selection_keys(target, subtarget)
    ):
        armature = _armature_from_session_uid(armature_uid)
        pose_bone = (
            armature.pose.bones.get(bone_name)
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is None:
            continue
        snapshots.append({
            "armature_uid": int(armature_uid),
            "bone_name": str(bone_name),
            "pose": _dynamic_parent_pose_state(pose_bone),
            "keys": _dynamic_parent_pose_key_snapshot(
                armature,
                pose_bone.name,
                int(frame),
            ),
        })
    return tuple(snapshots)

def _dynamic_parent_history_space_identity(pose_bone, frame, chosen=None):
    chosen = chosen or _chosen_dynamic_parent_constraint(pose_bone, int(frame))
    driver, role = _dynamic_parent_history_driver_constraint(
        pose_bone,
        int(frame),
        chosen,
    )
    if chosen is None or driver is None or not role:
        return None
    target = _dynamic_parent_constraint_target(pose_bone, driver)
    if target is None:
        return None
    start, _end = _dynamic_parent_constraint_segment(pose_bone, chosen)
    source = (
        f"{chosen.name}:{int(start) if start is not None else SPACE_MIN_FRAME}"
        if role == _DYNAMIC_PARENT_HISTORY_PARENT_ROLE
        else _dynamic_space_source(pose_bone, chosen)
    )
    return (
        role,
        str(source),
        int(_armature_session_uid(target)),
        str(getattr(target, "name", "")),
        str(_dynamic_parent_constraint_subtarget(pose_bone, driver)),
    )

def _dynamic_parent_history_relation(context, armature, pose_bone, frame):
    chosen = _chosen_dynamic_parent_constraint(pose_bone, int(frame))
    driver, role = _dynamic_parent_history_driver_constraint(
        pose_bone,
        int(frame),
        chosen,
    )
    identity = _dynamic_parent_history_space_identity(
        pose_bone,
        int(frame),
        chosen,
    )
    if driver is None or identity is None:
        return None
    target = _dynamic_parent_constraint_target(pose_bone, driver)
    if target is None:
        return None
    subtarget = _dynamic_parent_constraint_subtarget(pose_bone, driver)
    try:
        driver_matrix = _pose_space_target_matrix(
            context,
            armature,
            target,
            subtarget,
        )
    except (AttributeError, ReferenceError, RuntimeError, ValueError):
        return None
    return {
        "constraint": chosen,
        "driver_matrix": driver_matrix.copy(),
        "driver_selection_keys": (
            _dynamic_parent_history_driver_selection_keys(target, subtarget)
        ),
        "identity": identity,
        "role": role,
    }

def _dynamic_parent_history_entry_pose_bone(entry):
    armature = _armature_from_session_uid(entry.get("armature_uid", 0))
    pose_bone = (
        armature.pose.bones.get(str(entry.get("bone_name", "")))
        if armature is not None and getattr(armature, "pose", None)
        else None
    )
    return (armature, pose_bone)

def _dynamic_parent_history_entry_parent(entry):
    armature = _armature_from_session_uid(entry.get("parent_uid", 0))
    parent = (
        armature.pose.bones.get(str(entry.get("parent_bone", "")))
        if armature is not None and getattr(armature, "pose", None)
        else None
    )
    return (armature, parent)

def _dynamic_parent_history_enrich_entry(entry):
    entry = dict(entry)
    frame = int(entry.get("frame", 0))
    armature, pose_bone = _dynamic_parent_history_entry_pose_bone(entry)
    if pose_bone is not None:
        entry.setdefault(
            "space_identity",
            _dynamic_parent_history_space_identity(pose_bone, frame),
        )
        if "child_after_pose" not in entry:
            entry["child_after_pose"] = _dynamic_parent_pose_state(pose_bone)
        if "child_after_space" not in entry:
            entry["child_after_space"] = _dynamic_parent_space_state(pose_bone)
        if (
            "child_after_keys" not in entry
            and not entry.get("child_after_pending", False)
        ):
            entry["child_after_keys"] = _dynamic_parent_pose_key_snapshot(
                armature,
                pose_bone.name,
                frame,
            )
    entry.setdefault("parent_key_owned", False)
    parent_armature, parent = _dynamic_parent_history_entry_parent(entry)
    if (
        parent is not None
        and entry["parent_key_owned"]
        and "parent_after_keys" not in entry
        and not entry.get("parent_after_pending", False)
    ):
        entry["parent_after_keys"] = _dynamic_parent_pose_key_snapshot(
            parent_armature,
            parent.name,
            frame,
        )
    entry["child_before_keyed"] = _dynamic_parent_pose_key_snapshot_present(
        entry.get("child_before_keys")
    )
    entry["child_after_keyed"] = bool(
        entry.get("child_after_pending", False)
        or _dynamic_parent_pose_key_snapshot_present(entry.get("child_after_keys"))
    )
    entry["parent_before_keyed"] = _dynamic_parent_pose_key_snapshot_present(
        entry.get("parent_before_keys")
    )
    entry["parent_after_keyed"] = bool(
        entry.get("parent_after_pending", False)
        or _dynamic_parent_pose_key_snapshot_present(entry.get("parent_after_keys"))
    )
    return entry

def _dynamic_parent_clear_prepared_history_transition():
    _state["dynamic_parent_native_history_transition"] = None
    _state["dynamic_parent_native_history_expected_index"] = None
    _state["dynamic_parent_native_history_source_index"] = None
    _state["dynamic_parent_native_history_source_matches"] = False

def _dynamic_parent_store_native_history_transition(entries):
    entries = tuple(
        _dynamic_parent_history_enrich_entry(entry)
        for entry in entries
        if entry is not None
    )
    if not entries:
        return False
    serial = int(_state.get("dynamic_parent_native_history_serial", 0)) + 1
    _state["dynamic_parent_native_history_serial"] = serial
    transition = {
        "entries": entries,
        "current_index": 1,
        "serial": serial,
    }
    _state.setdefault(
        "dynamic_parent_native_history_transitions",
        [],
    ).append(transition)
    _state.setdefault(
        "dynamic_parent_native_history_redo_stack",
        [],
    ).clear()
    _dynamic_parent_clear_prepared_history_transition()
    return True

def _dynamic_parent_discard_pending_transform_runtime():
    _state["dynamic_parent_indirect_visual_commits"] = {}
    _state.setdefault(
        "dynamic_parent_dual_selection_translate_sessions",
        {},
    ).clear()
    _state.setdefault("dynamic_parent_indirect_parent_baselines", {}).clear()
    _state["dynamic_parent_boundary_refresh_pending"] = False
    try:
        if bpy.app.timers.is_registered(_run_dynamic_parent_boundary_refresh):
            bpy.app.timers.unregister(_run_dynamic_parent_boundary_refresh)
    except (ReferenceError, RuntimeError, ValueError):
        pass

def _dynamic_parent_stage_pending_history_transition(context):
    entries = {}
    commits = dict(
        _state.get("dynamic_parent_indirect_visual_commits", {})
    )
    for key, commit in commits.items():
        history = commit.get("history")
        if history is None:
            continue
        armature = _armature_from_session_uid(commit["armature_uid"])
        pose_bone = (
            armature.pose.bones.get(commit["bone_name"])
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is None:
            continue
        entry = dict(history)
        entry["child_after_basis"] = pose_bone.matrix_basis.copy()
        entry["child_after_matrix"] = pose_bone.matrix.copy()
        entry["child_after_pose"] = _dynamic_parent_pose_state(pose_bone)
        entry["child_after_space"] = _dynamic_parent_space_state(pose_bone)
        entry["child_after_keys"] = None
        entry["child_after_keyed"] = True
        entry["child_after_pending"] = True
        entries[key] = entry

    sessions = dict(
        _state.get("dynamic_parent_dual_selection_translate_sessions", {})
    )
    for key, session in sessions.items():
        if key in entries:
            continue
        armature = _armature_from_session_uid(session["armature_uid"])
        pose_bone = (
            armature.pose.bones.get(session["bone_name"])
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        target = _armature_from_session_uid(session["parent_uid"])
        parent_bone = (
            target.pose.bones.get(session["parent_bone"])
            if target is not None and getattr(target, "pose", None)
            else None
        )
        if pose_bone is None or parent_bone is None:
            continue
        parent_matrix = target.matrix_world @ parent_bone.matrix
        if _matrices_nearly_equal(
            parent_matrix,
            session["parent_matrix"],
            tolerance=_DYNAMIC_PARENT_HISTORY_TOLERANCE,
        ):
            continue
        parent_key_owned = bool(session.get("key_parent", False))
        entries[key] = {
            "armature_uid": session["armature_uid"],
            "bone_name": session["bone_name"],
            "frame": session["frame"],
            "child_before_basis": session["child_basis"].copy(),
            "child_before_matrix": session["child_matrix"].copy(),
            "child_before_pose": session.get("child_pose"),
            "child_before_space": session.get("child_space"),
            "child_before_keys": session.get("child_before_keys"),
            "child_after_basis": pose_bone.matrix_basis.copy(),
            "child_after_matrix": pose_bone.matrix.copy(),
            "child_after_pose": _dynamic_parent_pose_state(pose_bone),
            "child_after_space": _dynamic_parent_space_state(pose_bone),
            "child_after_keys": None,
            "child_after_keyed": True,
            "child_after_pending": True,
            "parent_uid": session["parent_uid"],
            "parent_bone": session["parent_bone"],
            "parent_before_basis": session["parent_basis"].copy(),
            "parent_before_pose": session.get("parent_pose"),
            "parent_before_matrix": session["parent_matrix"].copy(),
            "parent_before_keys": session.get("parent_before_keys"),
            "driver_before_states": session.get("driver_before_states", ()),
            "parent_after_basis": parent_bone.matrix_basis.copy(),
            "parent_after_pose": _dynamic_parent_pose_state(parent_bone),
            "parent_after_matrix": parent_matrix.copy(),
            "parent_after_keys": None,
            "parent_key_owned": parent_key_owned,
            "parent_after_pending": parent_key_owned,
            "driver_after_states": _dynamic_parent_history_driver_pose_snapshots(
                target,
                parent_bone.name,
                session["frame"],
            ),
        }

    if not entries:
        return False
    _dynamic_parent_store_native_history_transition(entries.values())
    _dynamic_parent_discard_pending_transform_runtime()
    return True

def _dynamic_parent_history_identity_matches(entry, frame):
    expected = entry.get("space_identity")
    if expected is None:
        return True
    _armature, pose_bone = _dynamic_parent_history_entry_pose_bone(entry)
    return bool(
        pose_bone is not None
        and _dynamic_parent_history_space_identity(
            pose_bone,
            int(frame),
        ) == tuple(expected)
    )

def _dynamic_parent_history_entry_tolerance(entry):
    identity = entry.get("space_identity") or ()
    return (
        _DYNAMIC_PARENT_HISTORY_TRANSITION_TOLERANCE
        if identity and str(identity[0]) == _DYNAMIC_PARENT_HISTORY_PARENT_ROLE
        else _DYNAMIC_PARENT_HISTORY_TOLERANCE
    )

def _dynamic_parent_history_parent_matches(entry, index):
    armature, parent = _dynamic_parent_history_entry_parent(entry)
    if parent is None:
        return False
    index = int(index)
    tolerance = _dynamic_parent_history_entry_tolerance(entry)
    expected_matrix = entry.get(
        "parent_before_matrix" if index == 0 else "parent_after_matrix"
    )
    if expected_matrix is not None:
        return _matrices_nearly_equal(
            armature.matrix_world @ parent.matrix,
            expected_matrix,
            tolerance=tolerance,
        )
    expected_basis = entry.get(
        "parent_before_basis" if index == 0 else "parent_after_basis"
    )
    return bool(
        expected_basis is not None
        and _matrices_nearly_equal(
            parent.matrix_basis,
            expected_basis,
            tolerance=tolerance,
        )
    )

def _dynamic_parent_history_parent_changed(entry):
    before = entry.get("parent_before_matrix")
    after = entry.get("parent_after_matrix")
    if before is not None and after is not None:
        return not _matrices_nearly_equal(
            before,
            after,
            tolerance=_DYNAMIC_PARENT_HISTORY_TRANSITION_TOLERANCE,
        )
    before = entry.get("parent_before_basis")
    after = entry.get("parent_after_basis")
    return bool(
        before is not None
        and after is not None
        and not _matrices_nearly_equal(
            before,
            after,
            tolerance=_DYNAMIC_PARENT_HISTORY_TRANSITION_TOLERANCE,
        )
    )

def _dynamic_parent_history_child_matches(context, entry, index):
    armature, pose_bone = _dynamic_parent_history_entry_pose_bone(entry)
    if pose_bone is None:
        return False
    if not _dynamic_parent_history_identity_matches(entry, entry["frame"]):
        return False
    index = int(index)
    tolerance = _dynamic_parent_history_entry_tolerance(entry)
    identity = entry.get("space_identity") or ()
    if identity and str(identity[0]) == _DYNAMIC_PARENT_HISTORY_PARENT_ROLE:
        pose_state = entry.get(
            "child_before_pose" if index == 0 else "child_after_pose"
        )
        space_state = entry.get(
            "child_before_space" if index == 0 else "child_after_space"
        )
        if pose_state is not None and not _dynamic_parent_pose_state_matches(
            pose_bone, pose_state,
            tolerance=tolerance,
        ):
            return False
        if space_state is not None and not _dynamic_parent_space_state_matches(
            pose_bone, space_state,
            tolerance=tolerance,
        ):
            return False
    expected_basis = entry.get(
        "child_before_basis" if index == 0 else "child_after_basis"
    )
    if expected_basis is not None:
        return _matrices_nearly_equal(
            pose_bone.matrix_basis,
            expected_basis,
            tolerance=tolerance,
        )
    expected_output = entry.get(
        "child_before_matrix" if index == 0 else "child_after_matrix"
    )
    if expected_output is None:
        return False
    try:
        output = _pose_space_output_matrix(context, armature, pose_bone)
    except (AttributeError, ReferenceError, RuntimeError, ValueError):
        return False
    return _matrices_nearly_equal(
        output,
        expected_output,
        tolerance=tolerance,
    )


def _dynamic_parent_history_transition_side_matches(context, entry, index):
    """Match a complete authored side, not merely its unchanged parent."""
    return bool(
        _dynamic_parent_history_parent_matches(entry, index)
        and (
            _dynamic_parent_history_parent_changed(entry)
            or _dynamic_parent_history_child_matches(context, entry, index)
        )
        and _dynamic_parent_history_side_keys_match(entry, index)
    )

def _dynamic_parent_prepare_native_history_transition(context=None):
    direction = str(_state.get("pin_history_direction", ""))
    if direction == "UNDO":
        stack = _state.setdefault(
            "dynamic_parent_native_history_transitions",
            [],
        )
        source_index = 1
        expected_index = 0
    elif direction == "REDO":
        stack = _state.setdefault(
            "dynamic_parent_native_history_redo_stack",
            [],
        )
        source_index = 0
        expected_index = 1
    else:
        _dynamic_parent_clear_prepared_history_transition()
        return False

    context = context or bpy.context
    transition = stack[-1] if stack else None
    entries = tuple(transition.get("entries", ())) if transition else ()
    selected = _dynamic_parent_history_selected_keys(
        _state.get(
            "pin_history_pre_pose_selection_signature",
            _pin_pose_selection_signature(context) if context is not None else (),
        )
    )
    participants = set()
    for entry in entries:
        participants.add((
            int(entry.get("armature_uid", 0)),
            str(entry.get("bone_name", "")),
        ))
        parent_armature, parent = _dynamic_parent_history_entry_parent(entry)
        if parent_armature is not None and parent is not None:
            participants.update(
                _dynamic_parent_history_driver_selection_keys(
                    parent_armature,
                    parent.name,
                )
            )
    selection_relevant = bool(selected.intersection(participants))
    source_matches = bool(
        context is not None
        and transition
        and entries
        and selection_relevant
        and int(transition.get("current_index", -1)) == source_index
        and all(
            _dynamic_parent_history_transition_side_matches(
                context, entry, source_index
            )
            for entry in entries
        )
    )
    _state["dynamic_parent_native_history_transition"] = transition
    _state["dynamic_parent_native_history_expected_index"] = expected_index
    _state["dynamic_parent_native_history_source_index"] = source_index
    _state["dynamic_parent_native_history_source_matches"] = source_matches
    return source_matches

def _dynamic_parent_advance_history_transition(transition, index):
    direction = str(_state.get("pin_history_direction", ""))
    transitions = _state.setdefault(
        "dynamic_parent_native_history_transitions",
        [],
    )
    redo_stack = _state.setdefault(
        "dynamic_parent_native_history_redo_stack",
        [],
    )
    transition["current_index"] = int(index)
    if direction == "UNDO" and int(index) == 0:
        if transitions and transitions[-1] is transition:
            transitions.pop()
        if not redo_stack or redo_stack[-1] is not transition:
            redo_stack.append(transition)
    elif direction == "REDO" and int(index) == 1:
        if redo_stack and redo_stack[-1] is transition:
            redo_stack.pop()
        if not transitions or transitions[-1] is not transition:
            transitions.append(transition)
