"""Animation data, dynamic parenting, unparenting, and onion tools."""
