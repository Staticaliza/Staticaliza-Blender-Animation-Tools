"""Dope Sheet channel discovery and automatic hierarchy expansion."""

from ..core.runtime import *  # noqa: F403


_ANIMATION_EDITOR_POSE_WORKSPACES = frozenset({
    "animate",
    "graph",
    "audio",
    "preview",
})


def _capture_animation_editor_filters(area):
    filters = []
    for space in tuple(getattr(area, "spaces", ())):
        dopesheet = getattr(space, "dopesheet", None)
        if dopesheet is None:
            continue
        try:
            filters.append(
                (
                    space,
                    str(dopesheet.filter_text),
                    bool(dopesheet.use_filter_invert),
                    bool(dopesheet.show_only_selected),
                    bool(dopesheet.show_only_errors),
                )
            )
        except (AttributeError, ReferenceError, TypeError, ValueError):
            pass
    return tuple(filters)


def _hide_animation_editor_keys(area):
    """Blank an animation editor using Blender's native filter toggles."""
    changed = False
    for space in tuple(getattr(area, "spaces", ())):
        dopesheet = getattr(space, "dopesheet", None)
        if dopesheet is None:
            continue
        try:
            if str(dopesheet.filter_text):
                dopesheet.filter_text = ""
                changed = True
            if dopesheet.use_filter_invert:
                dopesheet.use_filter_invert = False
                changed = True
            if not dopesheet.show_only_selected:
                dopesheet.show_only_selected = True
                changed = True
            if not dopesheet.show_only_errors:
                dopesheet.show_only_errors = True
                changed = True
            if dopesheet.show_summary:
                dopesheet.show_summary = False
                changed = True
            if dopesheet.show_expanded_summary:
                dopesheet.show_expanded_summary = False
                changed = True
        except (AttributeError, ReferenceError, TypeError, ValueError):
            pass
    return changed


def _disable_animation_editor_summary(area):
    """Keep Blender's redundant Summary channel out of animator editors."""
    changed = False
    for space in tuple(getattr(area, "spaces", ())):
        dopesheet = getattr(space, "dopesheet", None)
        if dopesheet is None:
            continue
        try:
            if dopesheet.show_summary:
                dopesheet.show_summary = False
                changed = True
            if dopesheet.show_expanded_summary:
                dopesheet.show_expanded_summary = False
                changed = True
        except (AttributeError, ReferenceError, TypeError, ValueError):
            pass
    return changed


def _animation_editor_workspace_supported(workspace):
    if workspace is None:
        return False
    try:
        name = _strip_blender_numeric_suffix(workspace.name)
    except (AttributeError, ReferenceError, TypeError, ValueError):
        return False
    return str(name).strip().casefold() in _ANIMATION_EDITOR_POSE_WORKSPACES


def _animation_editor_screen_sources(context = None):
    """Return live and stored animator screens, with active windows first."""
    context = context or bpy.context
    sources = []
    seen = set()
    window_manager = getattr(context, "window_manager", None)
    for window in tuple(getattr(window_manager, "windows", ())):
        workspace = getattr(window, "workspace", None)
        screen = getattr(window, "screen", None)
        if screen is None or not _animation_editor_workspace_supported(workspace):
            continue
        try:
            pointer = int(screen.as_pointer())
        except (AttributeError, ReferenceError, TypeError, ValueError):
            continue
        if pointer in seen:
            continue
        seen.add(pointer)
        sources.append((workspace, screen))
    for workspace in tuple(bpy.data.workspaces):
        if not _animation_editor_workspace_supported(workspace):
            continue
        for screen in tuple(getattr(workspace, "screens", ())):
            try:
                pointer = int(screen.as_pointer())
            except (AttributeError, ReferenceError, TypeError, ValueError):
                continue
            if pointer in seen:
                continue
            seen.add(pointer)
            sources.append((workspace, screen))
    return tuple(sources)


def _canonical_animation_editor_area(workspace, screen):
    """Force Animate/Graph's large lower editor back to its named type."""
    try:
        workspace_name = str(
            _strip_blender_numeric_suffix(workspace.name)
        ).strip().casefold()
    except (AttributeError, ReferenceError, TypeError, ValueError):
        return None, False
    desired = {
        "animate": ("DOPESHEET_EDITOR", "DOPESHEET"),
        "graph": ("GRAPH_EDITOR", "FCURVES"),
    }.get(workspace_name)
    if desired is None:
        return None, False
    candidates = [
        area
        for area in tuple(getattr(screen, "areas", ()))
        if area.type in {"DOPESHEET_EDITOR", "GRAPH_EDITOR"}
    ]
    if not candidates:
        return None, False
    area = max(
        candidates,
        key = lambda candidate: int(candidate.width) * int(candidate.height),
    )
    desired_type, desired_mode = desired
    changed = False
    try:
        if area.type != desired_type:
            area.type = desired_type
            changed = True
        current_mode = str(
            getattr(area, "ui_type", "")
            or getattr(area.spaces.active, "mode", "")
        )
        if current_mode != desired_mode:
            area.ui_type = desired_mode
            changed = True
        if _disable_animation_editor_summary(area):
            changed = True
        if changed:
            area.tag_redraw()
    except (
        AttributeError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ):
        return area, changed
    return area, changed


def _canonicalize_animation_editor_layouts(context = None):
    changed = False
    for workspace, screen in _animation_editor_screen_sources(context):
        _area, area_changed = _canonical_animation_editor_area(
            workspace,
            screen,
        )
        changed = area_changed or changed
        for area in tuple(getattr(screen, "areas", ())):
            if area.type not in {"DOPESHEET_EDITOR", "GRAPH_EDITOR"}:
                continue
            if _disable_animation_editor_summary(area):
                changed = True
                try:
                    area.tag_redraw()
                except (AttributeError, ReferenceError, RuntimeError):
                    pass
    return changed


def _restore_animation_editor_pose_states():
    """Restore editor filters saved before the Object Mode content lock."""
    states = _state.setdefault("animation_editor_pose_states", {})
    changed = False
    for key, state in tuple(states.items()):
        area, original_type, original_mode, original_filters = state
        area_changed = False
        try:
            if area.type != original_type:
                area.type = original_type
                changed = True
                area_changed = True
            if original_mode:
                current_mode = str(
                    getattr(area, "ui_type", "")
                    or getattr(area.spaces.active, "mode", "")
                )
                if current_mode != original_mode:
                    area.ui_type = original_mode
                    changed = True
                    area_changed = True
                for space in tuple(area.spaces):
                    if (
                        getattr(space, "type", "") == original_type
                        and hasattr(space, "mode")
                        and str(space.mode) != original_mode
                    ):
                        space.mode = original_mode
                        changed = True
                        area_changed = True
            for filter_state in original_filters:
                try:
                    space, filter_text, use_filter_invert = filter_state[:3]
                    show_only_selected = (
                        bool(filter_state[3])
                        if len(filter_state) >= 4
                        else False
                    )
                    show_only_errors = (
                        bool(filter_state[4])
                        if len(filter_state) >= 5
                        else False
                    )
                    dopesheet = space.dopesheet
                    if str(dopesheet.filter_text) != filter_text:
                        dopesheet.filter_text = filter_text
                        changed = True
                        area_changed = True
                    if bool(dopesheet.use_filter_invert) != use_filter_invert:
                        dopesheet.use_filter_invert = use_filter_invert
                        changed = True
                        area_changed = True
                    if (
                        bool(dopesheet.show_only_selected)
                        != show_only_selected
                    ):
                        dopesheet.show_only_selected = show_only_selected
                        changed = True
                        area_changed = True
                    if bool(dopesheet.show_only_errors) != show_only_errors:
                        dopesheet.show_only_errors = show_only_errors
                        changed = True
                        area_changed = True
                    if dopesheet.show_summary:
                        dopesheet.show_summary = False
                        changed = True
                        area_changed = True
                    if dopesheet.show_expanded_summary:
                        dopesheet.show_expanded_summary = False
                        changed = True
                        area_changed = True
                except (AttributeError, ReferenceError, TypeError, ValueError):
                    pass
            if area_changed:
                area.tag_redraw()
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            pass
        states.pop(key, None)
    return changed


def _sync_animation_editors_pose_mode(context):
    """Expose animation channels only while the animator is in Pose Mode."""
    if context is None or _window_manager_has_modal_operator(context):
        return False
    now = time.perf_counter()
    topology = tuple(
        (
            int(screen.as_pointer()),
            tuple(
                (
                    int(area.as_pointer()),
                    str(area.type),
                    str(getattr(area, "ui_type", "")),
                )
                for area in tuple(getattr(screen, "areas", ()))
            ),
        )
        for _workspace, screen in _animation_editor_screen_sources(context)
    )
    signature = (str(getattr(context, "mode", "")), topology)
    if (
        signature == _state.get("animation_editor_sync_signature")
        and now - float(_state.get("animation_editor_sync_time", 0.0)) < 0.5
    ):
        return False
    _state["animation_editor_sync_signature"] = signature
    _state["animation_editor_sync_time"] = now
    if getattr(context, "mode", "") != "OBJECT":
        changed = _restore_animation_editor_pose_states()
        return _canonicalize_animation_editor_layouts(context) or changed

    states = _state.setdefault("animation_editor_pose_states", {})
    changed = _canonicalize_animation_editor_layouts(context)
    for _workspace, screen in _animation_editor_screen_sources(context):
        for area in tuple(getattr(screen, "areas", ())):
            if area.type not in {
                "DOPESHEET_EDITOR",
                "GRAPH_EDITOR",
                "NLA_EDITOR",
            }:
                continue
            key = int(area.as_pointer())
            current_mode = str(
                getattr(area, "ui_type", "")
                or getattr(area.spaces.active, "mode", "")
            )
            if key not in states:
                if (
                    area.type == "DOPESHEET_EDITOR"
                    and current_mode == "TIMELINE"
                ):
                    continue
                states[key] = (
                    area,
                    str(area.type),
                    current_mode,
                    _capture_animation_editor_filters(area),
                )
            area_changed = False
            try:
                if _hide_animation_editor_keys(area):
                    changed = True
                    area_changed = True
                if area_changed:
                    area.tag_redraw()
            except (
                AttributeError,
                ReferenceError,
                RuntimeError,
                TypeError,
                ValueError,
            ):
                continue
    return changed


def _animation_channel_entries():
    try:
        actions = tuple(bpy.data.actions)
    except AttributeError:
        return ()

    entries = []
    for action in actions:
        try:
            action_has_content = bool(_action_fcurves(action))
            entries.append(
                (("ACTION", int(action.as_pointer())), action, action_has_content)
            )
        except (AttributeError, ReferenceError):
            action_has_content = False
        for slot in getattr(action, "slots", ()):
            try:
                slot_handle = int(getattr(slot, "handle", 0))
                has_content = any(
                    int(getattr(channelbag, "slot_handle", 0)) == slot_handle
                    and bool(tuple(channelbag.fcurves))
                    for channelbag in _action_channelbags(action)
                )
                entries.append(
                    (("SLOT", int(slot.as_pointer())), slot, has_content)
                )
            except (AttributeError, ReferenceError):
                pass
        for groups in _action_group_owners(action):
            for group in groups:
                try:
                    entries.append(
                        (("GROUP", int(group.as_pointer())), group, True)
                    )
                except (AttributeError, ReferenceError):
                    pass
    return tuple(entries)


def _capture_animation_channel_baseline():
    entries = _animation_channel_entries()
    _state["expanded_animation_channels"] = {
        key for key, _channel, _has_content in entries
    }
    _state["animation_channel_content"] = {
        key: bool(has_content)
        for key, _channel, has_content in entries
    }
    expansion_requested = any(
        key[0] == "ACTION" and bool(has_content)
        for key, _channel, has_content in entries
    )
    _state["animation_channel_expand_pending"] = expansion_requested
    _state["animation_channel_expand_attempts"] = (
        3 if expansion_requested else 0
    )


def _expand_dopesheet_hierarchy():
    window_manager = getattr(bpy.context, "window_manager", None)
    if window_manager is None:
        return False

    attempted = False
    for window in window_manager.windows:
        for area in window.screen.areas:
            if area.type != "DOPESHEET_EDITOR":
                continue
            space = area.spaces.active
            if (
                str(getattr(area, "ui_type", "")) == "TIMELINE"
                or str(getattr(space, "mode", "")) == "TIMELINE"
            ):
                continue
            channel_region = next(
                (region for region in area.regions if region.type == "CHANNELS"),
                None,
            )
            if channel_region is None:
                continue
            dopesheet = getattr(space, "dopesheet", None)
            if dopesheet is not None:
                dopesheet.show_summary = False
                dopesheet.show_expanded_summary = False
            try:
                with bpy.context.temp_override(
                    window = window,
                    area = area,
                    region = channel_region,
                    space_data = space,
                ):
                    if bpy.ops.anim.channels_expand.poll():
                        result = bpy.ops.anim.channels_expand(all = True)
                        attempted = "FINISHED" in result or attempted
            except (AttributeError, RuntimeError, TypeError):
                continue

    # The operator opens Blender's private object/action hierarchy state. Keep
    # pose-bone transform channels folded so only the useful first level shows.
    for action in tuple(bpy.data.actions):
        for slot in getattr(action, "slots", ()):
            try:
                slot.show_expanded = True
            except (AttributeError, ReferenceError, TypeError):
                pass
        for groups in _action_group_owners(action):
            for group in groups:
                try:
                    group.show_expanded = False
                except (AttributeError, ReferenceError, TypeError):
                    pass

    if attempted:
        for window in window_manager.windows:
            for area in window.screen.areas:
                if (
                    area.type == "DOPESHEET_EDITOR"
                    and str(getattr(area, "ui_type", "")) != "TIMELINE"
                ):
                    area.tag_redraw()
    return attempted


def _expand_new_animation_channels():
    if (
        _pin_primary_mouse_pressed()
        or _window_manager_has_modal_operator(bpy.context)
        or _animation_playback_active()
    ):
        return 0.25
    entries = _animation_channel_entries()
    if not entries:
        return 0.15

    seen = _state.setdefault("expanded_animation_channels", set())
    content_state = _state.setdefault("animation_channel_content", {})
    live = {key for key, _channel, _has_content in entries}
    expansion_requested = False
    for key, channel, has_content in entries:
        is_new = key not in seen
        gained_content = bool(has_content) and not bool(
            content_state.get(key, False)
        )
        try:
            # Reveal the action hierarchy, but keep each bone's transform
            # F-curves collapsed until the user explicitly expands that bone.
            if key[0] == "ACTION" and (
                gained_content or (is_new and has_content)
            ):
                expansion_requested = True
            elif key[0] == "SLOT" and (
                gained_content or (is_new and has_content)
            ):
                channel.show_expanded = True
                expansion_requested = True
            elif key[0] == "GROUP" and is_new:
                channel.show_expanded = False
                expansion_requested = True
        except (AttributeError, ReferenceError, TypeError):
            pass
        seen.add(key)
        content_state[key] = bool(has_content)
    seen.intersection_update(live)
    for key in tuple(content_state):
        if key not in live:
            content_state.pop(key, None)

    if expansion_requested:
        _state["animation_channel_expand_pending"] = True
        _state["animation_channel_expand_attempts"] = 3
    if _state.get("animation_channel_expand_pending", False):
        if _expand_dopesheet_hierarchy():
            attempts = max(
                0,
                int(_state.get("animation_channel_expand_attempts", 0)) - 1,
            )
            _state["animation_channel_expand_attempts"] = attempts
            _state["animation_channel_expand_pending"] = attempts > 0
    return 0.15
