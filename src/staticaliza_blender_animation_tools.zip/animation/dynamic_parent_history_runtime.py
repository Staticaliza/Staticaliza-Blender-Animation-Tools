"""History-side restoration for Dynamic Parent and Dynamic Unparent."""

from ..core.runtime import *  # noqa: F403


_DYNAMIC_PARENT_HISTORY_RESTORE_TOLERANCE = 5.0e-7


def _dynamic_parent_history_side_keys_match(entry, index):
    index = int(index)
    child_pending = entry.get(
        "child_before_pending" if index == 0 else "child_after_pending",
        False,
    )
    child_snapshot = entry.get(
        "child_before_keys" if index == 0 else "child_after_keys"
    )
    child_armature, child = _dynamic_parent_history_entry_pose_bone(entry)
    if (
        not child_pending
        and child_snapshot is not None
        and (
            child is None
            or not _dynamic_parent_pose_key_snapshot_matches(
                child_armature,
                child.name,
                entry["frame"],
                child_snapshot,
            )
        )
    ):
        return False
    if not entry.get("parent_key_owned", False):
        return True
    parent_pending = entry.get(
        "parent_before_pending" if index == 0 else "parent_after_pending",
        False,
    )
    parent_snapshot = entry.get(
        "parent_before_keys" if index == 0 else "parent_after_keys"
    )
    parent_armature, parent = _dynamic_parent_history_entry_parent(entry)
    return bool(
        parent_pending
        or parent_snapshot is None
        or parent is not None
        and _dynamic_parent_pose_key_snapshot_matches(
            parent_armature,
            parent.name,
            entry["frame"],
            parent_snapshot,
        )
    )


def _dynamic_parent_restore_history_parent_keys(context, entry, index):
    if not entry.get("parent_key_owned", False):
        return False
    armature, parent = _dynamic_parent_history_entry_parent(entry)
    if parent is None:
        return False
    index = int(index)
    pending_key = "parent_before_pending" if index == 0 else "parent_after_pending"
    snapshot_key = "parent_before_keys" if index == 0 else "parent_after_keys"
    pose_key = "parent_before_pose" if index == 0 else "parent_after_pose"
    # This is the user-transformed driver, regardless of whether the follower
    # is currently in Dynamic Parent or Dynamic Unparent space.  Restoring
    # only its keys is insufficient on Redo because Blender can evaluate the
    # raw native checkpoint before those deferred keys; always restore the
    # exact recorded driver pose as well.
    pose_state = entry.get(pose_key)
    if entry.get(pending_key, False):
        _dynamic_parent_restore_pose_state(parent, pose_state)
        context.view_layer.update()
        _dynamic_parent_force_pose_key(parent, int(entry["frame"]), visual=False)
        context.view_layer.update()
        snapshot = _dynamic_parent_pose_key_snapshot(
            armature, parent.name, entry["frame"],
        )
        entry[snapshot_key] = snapshot
        entry[pending_key] = False
        entry[
            "parent_before_keyed" if index == 0 else "parent_after_keyed"
        ] = _dynamic_parent_pose_key_snapshot_present(snapshot)
        return True
    snapshot = entry.get(snapshot_key)
    changed = False
    if snapshot is not None:
        changed = _dynamic_parent_restore_pose_key_snapshot(
            armature, parent.name, snapshot,
        )
        if changed:
            context.view_layer.update()
    changed = _dynamic_parent_restore_pose_state(parent, pose_state) or changed
    if changed:
        context.view_layer.update()
    return changed


def _dynamic_parent_history_output_matrix(context, armature, pose_bone):
    try:
        return _pose_space_output_matrix(context, armature, pose_bone)
    except (AttributeError, ReferenceError, RuntimeError, ValueError):
        return pose_bone.matrix.copy()


def _dynamic_parent_set_history_pose(
    context,
    armature,
    pose_bone,
    frame,
    basis,
    output_matrix,
    key_snapshot=None,
    force_keys=False,
    pose_state=None,
    space_state=None,
    direct_input=False,
    tolerance=_DYNAMIC_PARENT_HISTORY_RESTORE_TOLERANCE,
):
    frame = int(frame)
    current_output = _dynamic_parent_history_output_matrix(
        context,
        armature,
        pose_bone,
    )
    basis_changed = bool(
        pose_state is None
        and basis is not None
        and not _matrices_nearly_equal(
            pose_bone.matrix_basis,
            basis,
            tolerance=tolerance,
        )
    )
    output_changed = bool(
        output_matrix is not None
        and not _matrices_nearly_equal(
            current_output,
            output_matrix,
            tolerance=tolerance,
        )
    )
    key_changed = bool(
        key_snapshot is not None
        and not _dynamic_parent_pose_key_snapshot_matches(
            armature,
            pose_bone.name,
            frame,
            key_snapshot,
        )
    )
    changed = False
    if key_snapshot is not None and key_changed:
        changed = _dynamic_parent_restore_pose_key_snapshot(
            armature,
            pose_bone.name,
            key_snapshot,
        ) or changed
        context.view_layer.update()
        pose_bone = armature.pose.bones.get(pose_bone.name)

    if pose_state is not None:
        changed = _dynamic_parent_restore_pose_state(
            pose_bone,
            pose_state,
        ) or changed
    elif basis_changed:
        pose_bone.matrix_basis = basis.copy()
        changed = True
    if changed:
        context.view_layer.update()
        pose_bone = armature.pose.bones.get(pose_bone.name)

    if space_state is not None:
        space_changed = _dynamic_parent_restore_space_state(
            pose_bone,
            space_state,
        )
        changed = space_changed or changed
        if space_changed:
            context.view_layer.update()
            pose_bone = armature.pose.bones.get(pose_bone.name)

    # Exact Dynamic Parent sides are authoritative snapshots. Never derive a
    # replacement inverse from a transient post-Undo evaluation; later native
    # history steps may still be restoring the target or one of its ancestors.
    exact_state = pose_state is not None and space_state is not None
    if output_matrix is not None and not exact_state:
        solve_passes = 3 if direct_input else 2
        for _pass in range(solve_passes):
            current_output = _dynamic_parent_history_output_matrix(
                context,
                armature,
                pose_bone,
            )
            if _matrices_nearly_equal(
                current_output,
                output_matrix,
                tolerance=tolerance,
            ):
                break
            constraint = _chosen_dynamic_parent_constraint(pose_bone, frame)
            input_matrix = _dynamic_parent_input_matrix(
                context,
                armature,
                constraint,
                output_matrix,
            )
            if direct_input:
                pose_bone.matrix_basis = (
                    pose_bone.bone.matrix_local.inverted_safe() @ input_matrix
                )
                context.view_layer.update()
            else:
                constraint_mute = bool(
                    getattr(constraint, "mute", False)
                ) if constraint is not None else False
                try:
                    if constraint is not None:
                        constraint.mute = True
                        context.view_layer.update()
                        pose_bone = armature.pose.bones.get(pose_bone.name)
                    pose_bone.matrix = input_matrix
                    context.view_layer.update()
                finally:
                    if constraint is not None:
                        constraint.mute = constraint_mute
                        context.view_layer.update()
            changed = True
            pose_bone = armature.pose.bones.get(pose_bone.name)

    if force_keys:
        _dynamic_parent_force_pose_key(
            pose_bone,
            frame,
            visual=False,
        )
        changed = True
        context.view_layer.update()
    return bool(changed or output_changed and not exact_state)


def _dynamic_parent_restore_history_child(context, entry, index):
    armature, pose_bone = _dynamic_parent_history_entry_pose_bone(entry)
    if pose_bone is None:
        return False
    index = int(index)
    pending_key = "child_before_pending" if index == 0 else "child_after_pending"
    snapshot_key = "child_before_keys" if index == 0 else "child_after_keys"
    pose_key = "child_before_pose" if index == 0 else "child_after_pose"
    space_key = "child_before_space" if index == 0 else "child_after_space"
    identity = entry.get("space_identity") or ()
    regular_parent = bool(
        identity and str(identity[0]) == _DYNAMIC_PARENT_HISTORY_PARENT_ROLE
    )
    pending = bool(entry.get(pending_key, False))
    exact_state = bool(
        regular_parent
        and entry.get(pose_key) is not None
        and entry.get(space_key) is not None
    )
    changed = _dynamic_parent_set_history_pose(
        context,
        armature,
        pose_bone,
        entry["frame"],
        entry.get("child_before_basis" if index == 0 else "child_after_basis"),
        entry.get("child_before_matrix" if index == 0 else "child_after_matrix"),
        key_snapshot=None if pending else entry.get(snapshot_key),
        force_keys=pending,
        pose_state=entry.get(pose_key) if exact_state else None,
        space_state=entry.get(space_key) if exact_state else None,
        direct_input=regular_parent,
        tolerance=(
            _DYNAMIC_PARENT_HISTORY_RESTORE_TOLERANCE
            if regular_parent
            else _DYNAMIC_PARENT_HISTORY_TOLERANCE
        ),
    )
    if pending:
        pose_bone = armature.pose.bones.get(pose_bone.name)
        snapshot = _dynamic_parent_pose_key_snapshot(
            armature,
            pose_bone.name,
            entry["frame"],
        )
        entry[snapshot_key] = snapshot
        entry[pending_key] = False
        entry[pose_key] = _dynamic_parent_pose_state(pose_bone)
        if regular_parent:
            entry[space_key] = _dynamic_parent_space_state(pose_bone)
        entry[
            "child_before_keyed" if index == 0 else "child_after_keyed"
        ] = _dynamic_parent_pose_key_snapshot_present(snapshot)
    return changed


def _dynamic_parent_restore_native_history_transition(context):
    _state["dynamic_parent_history_restored_owner_keys"] = set()
    transition = _state.get("dynamic_parent_native_history_transition")
    expected_index = _state.get("dynamic_parent_native_history_expected_index")
    source_index = _state.get("dynamic_parent_native_history_source_index")
    source_matches = bool(
        _state.get("dynamic_parent_native_history_source_matches", False)
    )
    try:
        if (
            not transition
            or expected_index not in (0, 1)
            or source_index not in (0, 1)
            or not source_matches
        ):
            return False
        entries = tuple(transition.get("entries", ()))
        if not entries or not all(
            _dynamic_parent_history_identity_matches(entry, entry["frame"])
            for entry in entries
        ):
            return False

        destination_matches = all(
            _dynamic_parent_history_transition_side_matches(
                context, entry, expected_index
            )
            for entry in entries
        )
        source_still_matches = all(
            _dynamic_parent_history_transition_side_matches(
                context, entry, source_index
            )
            for entry in entries
        )
        selection_changed = bool(
            _state.get("pin_history_pre_pose_selection_signature", ())
            != _pin_pose_selection_signature(context)
        )
        if destination_matches:
            # Selection commonly changes between two consecutive transforms.
            # Blender restores that selection together with the transform;
            # it is not a separate history step when the complete authored
            # destination side already matches.
            restore_index = int(expected_index)
            advance = True
        elif selection_changed and source_still_matches:
            # A native selection checkpoint can expose the raw pose stored by
            # the preceding transform before our deferred follower correction
            # settled.  Selection is the authoritative discriminator here:
            # keep the verified source side and leave the transform transition
            # pending for the next Undo/Redo instead of consuming both steps.
            restore_index = int(source_index)
            advance = False
        elif source_still_matches:
            # Redo may restore the raw native pose and then immediately
            # evaluate it against the preceding side's keys, leaving the
            # parent matrix apparently unchanged.  A verified relevant
            # selection with no selection transition is still the paired
            # transform step; selection-only history must remain inert.
            if (
                str(_state.get("pin_history_direction", "")).upper()
                == "REDO"
                and not selection_changed
            ):
                restore_index = int(expected_index)
                advance = True
            else:
                restore_index = int(source_index)
                advance = False
        else:
            # Native G/R/S commits its raw pose before the deferred follower
            # keys and boundary-space correction settle.  Undo/Redo can
            # therefore rebuild an intermediate state that matches neither
            # authoritative side (for example, the restored pose channels
            # are evaluated against keys authored just after that native
            # checkpoint).  The source side was verified synchronously in
            # undo_pre/redo_pre, so a changed, non-source result is the paired
            # native transform and must advance to the expected exact side.
            restore_index = int(expected_index)
            advance = True

        previous_mute = bool(_state.get("unparent_handler_mute", False))
        _state["unparent_handler_mute"] = True
        changed = False
        try:
            parent_changed = False
            for entry in entries:
                restored = _dynamic_parent_restore_transition_drivers(
                    context,
                    entry,
                    restore_index,
                )
                parent_changed = restored or parent_changed
                restored = _dynamic_parent_restore_history_parent_keys(
                    context, entry, restore_index,
                )
                parent_changed = restored or parent_changed
            changed = parent_changed or changed
            if parent_changed:
                context.view_layer.update()
                # Rebuild derived parent-space inverses before replaying the
                # child's exact side so calibration cannot move it afterward.
                _recalibrate_all_dynamic_space_boundaries(
                    context,
                    parent_only=True,
                )
            for entry in entries:
                changed = (
                    _dynamic_parent_restore_history_child(
                        context,
                        entry,
                        restore_index,
                    )
                    or changed
                )
            context.view_layer.update()
            if changed:
                _store_dynamic_parent_animation_signature()
            if advance:
                _dynamic_parent_advance_history_transition(
                    transition,
                    restore_index,
                )
            _state["dynamic_parent_history_restored_owner_keys"] = {
                (int(entry["armature_uid"]), str(entry["bone_name"]))
                for entry in entries
            }
        finally:
            _state["unparent_handler_mute"] = previous_mute
        return True
    finally:
        _dynamic_parent_clear_prepared_history_transition()


def _dynamic_parent_restore_transition_drivers(context, entry, index):
    snapshots = tuple(entry.get(
        "driver_before_states" if int(index) == 0 else "driver_after_states",
        (),
    ))
    changed = False
    for snapshot in snapshots:
        armature = _armature_from_session_uid(snapshot["armature_uid"])
        pose_bone = (
            armature.pose.bones.get(snapshot["bone_name"])
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is None:
            continue
        keys = snapshot.get("keys")
        key_changed = bool(
            keys is not None
            and _dynamic_parent_restore_pose_key_snapshot(
                armature,
                pose_bone.name,
                keys,
            )
        )
        pose_changed = _dynamic_parent_restore_pose_state(
            pose_bone,
            snapshot.get("pose"),
        )
        changed = bool(key_changed or pose_changed or changed)
    if changed:
        context.view_layer.update()
    return changed


def _dynamic_parent_restore_history_after_native_undo(context):
    previous_markers = _state.pop(
        "dynamic_space_history_pre_marker_signature", None,
    )
    if previous_markers is None:
        # Direct structural edits and compatibility callers can reach the
        # post reconciler without the native pre handler. The watcher baseline
        # is still the last accepted authored structure and is sufficient to
        # detect a marker removal/addition without touching pose history.
        previous_markers = _state.get("dynamic_space_marker_signature")
    _state.pop("dynamic_parent_history_pre_driver_signature", None)
    current_markers = _dynamic_space_marker_signature()
    markers_changed = bool(
        previous_markers is not None and previous_markers != current_markers
    )
    if markers_changed:
        changed = bool(_reconcile_dynamic_space_markers(context))
    else:
        changed = bool(
            _sync_dynamic_parent_constraints(
                int(context.scene.frame_current)
            )
        )
    if changed:
        context.view_layer.update()

    # Native history restores the directly transformed bones and their Action
    # channels.  A jointly selected Dynamic Parent follower, however, was
    # compensated against its selected parent during the same G/R/S commit.
    # Restore that recorded exact side now and advance the paired transition
    # once.  These assignments run inside Blender's history callback and do
    # not push another native step; keeping the transition stacks is required
    # for the matching Redo.
    restored = _dynamic_parent_restore_native_history_transition(context)
    changed = bool(restored or changed)
    _state["dynamic_parent_history_snapshot"] = ()
    if markers_changed:
        # Relationship edits invalidate pose transitions captured for the old
        # identity.  Pure transforms retain both stacks for exact Redo.
        _state["dynamic_parent_native_history_transitions"] = []
        _state["dynamic_parent_native_history_redo_stack"] = []
        _state["dynamic_parent_history_restored_owner_keys"] = set()
        _dynamic_parent_clear_prepared_history_transition()
    _state["dynamic_space_marker_signature"] = _dynamic_space_marker_signature()
    _store_dynamic_parent_animation_signature()
    return bool(changed)


def _dynamic_parent_history_driver_change_roles(context):
    entries = tuple(_state.get("dynamic_parent_history_snapshot", ()))
    scene = getattr(context, "scene", None)
    if not entries or scene is None:
        return set()
    frame = int(scene.frame_current)
    roles = set()
    for entry in entries:
        if int(entry.get("frame", frame)) != frame:
            continue
        armature, pose_bone = _dynamic_parent_history_entry_pose_bone(entry)
        if pose_bone is None:
            continue
        relation = _dynamic_parent_history_relation(
            context,
            armature,
            pose_bone,
            frame,
        )
        if (
            relation is None
            or relation["identity"] != tuple(entry.get("space_identity") or ())
        ):
            continue
        tolerance = (
            _DYNAMIC_PARENT_HISTORY_RESTORE_TOLERANCE
            if relation["role"] == _DYNAMIC_PARENT_HISTORY_PARENT_ROLE
            else _DYNAMIC_PARENT_HISTORY_TOLERANCE
        )
        if not _matrices_nearly_equal(
            relation["driver_matrix"],
            entry["driver_matrix"],
            tolerance=tolerance,
        ):
            roles.add(str(relation["role"]))
    return roles


def _dynamic_parent_history_reconcile_mode(
    markers_changed,
    driver_signature_changed,
    driver_pose_changed,
):
    if markers_changed:
        return "STRUCTURE"
    if driver_signature_changed or driver_pose_changed:
        return "DRIVER"
    return "NONE"


def _dynamic_parent_history_selected_keys(signature):
    try:
        return set(signature[1])
    except (IndexError, TypeError):
        return set()


def _dynamic_parent_regular_history_mode(
    driver_changed,
    child_selected,
    basis_changed,
    keys_changed,
    output_changed,
    space_changed,
):
    if driver_changed:
        return "DRIVER"
    if child_selected and (basis_changed or keys_changed):
        return "NATIVE_CHILD"
    if basis_changed or keys_changed or output_changed or space_changed:
        return "RESTORE"
    return "UNCHANGED"


def _dynamic_parent_capture_history_snapshot(context):
    scene = getattr(context, "scene", None)
    if scene is None:
        _state["dynamic_parent_history_snapshot"] = ()
        return False
    _state["dynamic_space_history_pre_marker_signature"] = (
        _dynamic_space_marker_signature()
    )
    _state["dynamic_parent_history_pre_driver_signature"] = (
        _dynamic_parent_driver_animation_signature()
    )
    frame = int(scene.frame_current)
    selection_signature = _state.get(
        "pin_history_pre_pose_selection_signature",
        _pin_pose_selection_signature(context),
    )
    selected = _dynamic_parent_history_selected_keys(selection_signature)
    entries = []
    for armature in tuple(scene.objects):
        if (
            armature.type != "ARMATURE"
            or getattr(armature, "pose", None) is None
        ):
            continue
        armature_uid = _armature_session_uid(armature)
        for pose_bone in armature.pose.bones:
            relation = _dynamic_parent_history_relation(
                context,
                armature,
                pose_bone,
                frame,
            )
            if relation is None:
                continue
            try:
                output_matrix = _pose_space_output_matrix(
                    context,
                    armature,
                    pose_bone,
                )
            except (AttributeError, ReferenceError, RuntimeError, ValueError):
                continue
            driver_selection_keys = tuple(
                relation.get("driver_selection_keys", ())
            )
            entries.append({
                "armature_uid": armature_uid,
                "bone_name": pose_bone.name,
                "frame": frame,
                "child_basis": pose_bone.matrix_basis.copy(),
                "child_pose": _dynamic_parent_pose_state(pose_bone),
                "child_space": _dynamic_parent_space_state(pose_bone),
                "child_keys": _dynamic_parent_pose_key_snapshot(
                    armature,
                    pose_bone.name,
                    frame,
                ),
                "driver_matrix": relation["driver_matrix"].copy(),
                "driver_selected": bool(
                    selected.intersection(driver_selection_keys)
                ),
                "driver_selection_keys": driver_selection_keys,
                "output_matrix": output_matrix.copy(),
                "role": relation["role"],
                "selected": (armature_uid, pose_bone.name) in selected,
                "space_identity": relation["identity"],
            })
    _state["dynamic_parent_history_snapshot"] = tuple(entries)
    return bool(entries)


def _dynamic_parent_restore_history_snapshot_entry(
    context,
    entry,
    armature,
    pose_bone,
):
    regular_parent = str(entry.get("role", "")) == (
        _DYNAMIC_PARENT_HISTORY_PARENT_ROLE
    )
    return _dynamic_parent_set_history_pose(
        context,
        armature,
        pose_bone,
        entry["frame"],
        entry["child_basis"],
        entry["output_matrix"],
        key_snapshot=entry["child_keys"],
        pose_state=entry.get("child_pose") if regular_parent else None,
        space_state=entry.get("child_space") if regular_parent else None,
        direct_input=regular_parent,
        tolerance=(
            _DYNAMIC_PARENT_HISTORY_RESTORE_TOLERANCE
            if regular_parent
            else _DYNAMIC_PARENT_HISTORY_TOLERANCE
        ),
    )


def _dynamic_parent_restore_history_followers(context):
    skip_keys = set(
        _state.pop("dynamic_parent_history_restored_owner_keys", set())
    )
    entries = tuple(_state.get("dynamic_parent_history_snapshot", ()))
    scene = getattr(context, "scene", None)
    if not entries or scene is None:
        return False
    frame = int(scene.frame_current)
    previous_selection = _state.get(
        "pin_history_pre_pose_selection_signature",
        (),
    )
    current_selection = _pin_pose_selection_signature(context)
    selection_changed = previous_selection != current_selection
    selected_after = _dynamic_parent_history_selected_keys(current_selection)
    previous_mute = bool(_state.get("unparent_handler_mute", False))
    _state["unparent_handler_mute"] = True
    changed = False
    try:
        for entry in entries:
            if (int(entry["armature_uid"]), str(entry["bone_name"])) in skip_keys:
                continue
            if int(entry["frame"]) != frame:
                continue
            armature, pose_bone = _dynamic_parent_history_entry_pose_bone(entry)
            if pose_bone is None:
                continue
            relation = _dynamic_parent_history_relation(
                context,
                armature,
                pose_bone,
                frame,
            )
            if (
                relation is None
                or relation["identity"] != tuple(entry["space_identity"])
            ):
                continue
            restore_tolerance = (
                _DYNAMIC_PARENT_HISTORY_RESTORE_TOLERANCE
                if relation["role"] == _DYNAMIC_PARENT_HISTORY_PARENT_ROLE
                else _DYNAMIC_PARENT_HISTORY_TOLERANCE
            )
            current_basis = pose_bone.matrix_basis.copy()
            current_output = _dynamic_parent_history_output_matrix(
                context,
                armature,
                pose_bone,
            )
            current_keys = _dynamic_parent_pose_key_snapshot(
                armature,
                pose_bone.name,
                frame,
            )
            regular_parent = relation["role"] == _DYNAMIC_PARENT_HISTORY_PARENT_ROLE
            driver_changed = not _matrices_nearly_equal(
                relation["driver_matrix"],
                entry["driver_matrix"],
                tolerance=restore_tolerance if regular_parent else _DYNAMIC_PARENT_HISTORY_TOLERANCE,
            )
            basis_changed = not _matrices_nearly_equal(
                current_basis, entry["child_basis"], tolerance=restore_tolerance,
            )
            output_changed = not _matrices_nearly_equal(
                current_output, entry["output_matrix"], tolerance=restore_tolerance,
            )
            keys_changed = (
                _dynamic_parent_pose_key_snapshot_signature(current_keys)
                != _dynamic_parent_pose_key_snapshot_signature(entry["child_keys"])
            )
            space_changed = bool(
                regular_parent
                and not _dynamic_parent_space_state_matches(
                    pose_bone, entry.get("child_space"), tolerance=0.0,
                )
            )
            child_key = (entry["armature_uid"], entry["bone_name"])
            child_selected_before = bool(entry.get("selected", False))
            child_selected_after = child_key in selected_after
            child_selected = child_selected_before or child_selected_after
            driver_selection_keys = set(
                entry.get("driver_selection_keys", ())
            ) | set(relation.get("driver_selection_keys", ()))
            driver_selected = bool(
                entry.get("driver_selected", False)
                or selected_after.intersection(driver_selection_keys)
            )

            if regular_parent:
                history_mode = _dynamic_parent_regular_history_mode(
                    driver_changed,
                    child_selected,
                    basis_changed,
                    keys_changed,
                    output_changed,
                    space_changed,
                )
                if history_mode == "NATIVE_CHILD":
                    space_restored = bool(
                        space_changed
                        and _dynamic_parent_restore_space_state(
                            pose_bone, entry.get("child_space"),
                        )
                    )
                    if space_restored:
                        context.view_layer.update()
                    changed = space_restored or changed
                    continue
                if history_mode == "RESTORE":
                    changed = (
                        _dynamic_parent_restore_history_snapshot_entry(
                            context, entry, armature, pose_bone,
                        )
                        or changed
                    )
                    continue
                if history_mode in {"DRIVER", "UNCHANGED"}:
                    continue

            if not driver_changed:
                if (
                    selection_changed
                    or not child_selected_before and not child_selected_after
                ) and (basis_changed or output_changed or keys_changed):
                    changed = (
                        _dynamic_parent_restore_history_snapshot_entry(
                            context, entry, armature, pose_bone,
                        )
                        or changed
                    )
                continue

            if not selection_changed and child_selected and not driver_selected:
                continue
            desired_output = entry["output_matrix"]
            if _matrices_nearly_equal(
                current_output, desired_output, tolerance=restore_tolerance,
            ):
                continue
            changed = (
                _dynamic_parent_set_history_pose(
                    context, armature, pose_bone, frame, None, desired_output,
                    force_keys=True, tolerance=restore_tolerance,
                )
                or changed
            )
        if changed:
            context.view_layer.update()
            _store_dynamic_parent_animation_signature()
    finally:
        _state["unparent_handler_mute"] = previous_mute
        _state["dynamic_parent_history_restored_owner_keys"] = set()
    return changed
