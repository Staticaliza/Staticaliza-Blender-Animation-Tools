"""Dynamic Parent dual-selection transform locking and key synchronization."""

from ..core.runtime import *  # noqa: F403

def _dynamic_parent_dual_selection_key(armature, pose_bone):
    return (_armature_session_uid(armature), pose_bone.name)


def _restore_dynamic_parent_dual_selection_locks():
    """Restore location locks temporarily owned by dual-parent selection."""

    records = _state.setdefault("dynamic_parent_dual_selection_locks", {})
    changed = False
    for (armature_uid, bone_name), original_locks in tuple(records.items()):
        armature = _armature_from_session_uid(armature_uid)
        pose_bone = (
            armature.pose.bones.get(bone_name)
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is None:
            continue
        try:
            pose_bone.lock_location = tuple(bool(value) for value in original_locks)
            changed = True
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            continue
    records.clear()
    _state.setdefault("dynamic_parent_dual_selection_translate_sessions", {}).clear()
    _state.setdefault("dynamic_parent_indirect_parent_baselines", {}).clear()
    _state["dynamic_parent_history_snapshot"] = ()
    return changed


def _dynamic_parent_force_pose_key(pose_bone, frame, visual=False):
    """Insert a child key regardless of Needed/Available preference flags."""

    preferences = getattr(getattr(bpy.context, "preferences", None), "edit", None)
    property_names = (
        "use_auto_keyframe_insert_needed",
        "use_keyframe_insert_available",
        "use_keyframe_insert_needed",
    )
    saved = {}
    if preferences is not None:
        for property_name in property_names:
            if not hasattr(preferences, property_name):
                continue
            saved[property_name] = bool(getattr(preferences, property_name))
            setattr(preferences, property_name, False)
    try:
        _insert_bone_keys(pose_bone, int(frame), visual=bool(visual))
    finally:
        for property_name, value in saved.items():
            setattr(preferences, property_name, value)


def _dynamic_parent_apply_indirect_visual_commits(context):
    """Key captured follower previews after boundary inverses are rebuilt."""

    commits = dict(
        _state.get("dynamic_parent_indirect_visual_commits", {})
    )
    _state["dynamic_parent_indirect_visual_commits"] = {}
    if not commits:
        return False
    changed = False
    history_entries = []
    previous_mute = bool(_state.get("unparent_handler_mute", False))
    _state["unparent_handler_mute"] = True
    try:
        for commit in commits.values():
            armature = _armature_from_session_uid(commit["armature_uid"])
            pose_bone = (
                armature.pose.bones.get(commit["bone_name"])
                if armature is not None and getattr(armature, "pose", None)
                else None
            )
            if pose_bone is None:
                continue
            basis = commit.get("basis")
            if basis is not None:
                pose_bone.matrix_basis = basis.copy()
                context.view_layer.update()
                _dynamic_parent_force_pose_key(
                    pose_bone,
                    commit["frame"],
                    visual=False,
                )
            else:
                constraint = (
                    _chosen_dynamic_parent_constraint(
                        pose_bone,
                        int(commit["frame"]),
                    )
                    if commit.get("managed_space", False)
                    else get_last_dynamic_parent_constraint(
                        pose_bone,
                        int(commit["frame"]),
                    )
                )
                input_matrix = _dynamic_parent_input_matrix(
                    context,
                    armature,
                    constraint,
                    commit["matrix"],
                )
                constraint_mute = bool(
                    getattr(constraint, "mute", False)
                ) if constraint is not None else False
                try:
                    if constraint is not None:
                        constraint.mute = True
                        context.view_layer.update()
                        pose_bone = armature.pose.bones.get(
                            commit["bone_name"]
                        )
                    pose_bone.matrix = input_matrix
                    context.view_layer.update()
                    _dynamic_parent_force_pose_key(
                        pose_bone,
                        commit["frame"],
                        visual=False,
                    )
                finally:
                    if constraint is not None:
                        constraint.mute = constraint_mute
                        context.view_layer.update()
            changed = True
            history = commit.get("history")
            if history is not None:
                history["child_after_basis"] = (
                    pose_bone.matrix_basis.copy()
                )
                history["child_after_keyed"] = (
                    _dynamic_parent_pose_keyed_at(
                        armature,
                        pose_bone.name,
                        commit["frame"],
                    )
                )
                history_entries.append(history)
        if changed:
            context.view_layer.update()
        _dynamic_parent_store_native_history_transition(history_entries)
    finally:
        _state["unparent_handler_mute"] = previous_mute
    return changed


def _dynamic_parent_baseline_matrix(record):
    if isinstance(record, dict):
        return record.get("matrix")
    return record


def _sync_dynamic_parent_dual_selection_keys(
    context,
    desired,
    capture_unsessioned=False,
):
    """Commit selected parents and their followers from the final live pose."""

    sessions = _state.setdefault(
        "dynamic_parent_dual_selection_translate_sessions",
        {},
    )
    operator_id = _pin_active_transform_operator(context)
    operator_name = operator_id.casefold()
    transforming = any(
        name in operator_name for name in ("translate", "rotate", "resize")
    )
    delta_state = (
        _pin_transform_operator_delta_state(context, operator_id)
        if transforming
        else None
    )
    baselines = _state.setdefault(
        "dynamic_parent_indirect_parent_baselines",
        {},
    )
    frame = int(context.scene.frame_current)

    if transforming:
        if desired and not sessions:
            _state["dynamic_parent_native_history_transition"] = None
            _state["dynamic_parent_native_history_expected_index"] = None
        for key, (
            armature,
            pose_bone,
            target,
            parent_bone,
            visual,
            compensate,
            managed_space,
            key_parent,
        ) in desired.items():
            session = sessions.get(key)
            if session is None:
                baseline = _dynamic_parent_baseline_matrix(
                    baselines.get(key)
                )
                session = {
                    "armature_uid": _armature_session_uid(armature),
                    "bone_name": pose_bone.name,
                    "parent_uid": _armature_session_uid(target),
                    "parent_bone": parent_bone.name,
                    "parent_matrix": (
                        target.matrix_world
                        @ (
                            baseline
                            if baseline is not None
                            else parent_bone.matrix
                        )
                    ).copy(),
                    "child_basis": pose_bone.matrix_basis.copy(),
                    "child_before_keyed": (
                        _dynamic_parent_pose_keyed_at(
                            armature,
                            pose_bone.name,
                            frame,
                        )
                    ),
                    "parent_basis": parent_bone.matrix_basis.copy(),
                    "frame": frame,
                    "moved": False,
                    "visual": bool(visual),
                    "compensate": bool(compensate),
                    "managed_space": bool(managed_space),
                    "key_parent": bool(key_parent),
                    "visual_matrix": None,
                }
                sessions[key] = session
            parent_world = target.matrix_world @ parent_bone.matrix
            moved = bool(
                session["moved"]
                or (
                    delta_state is True
                    and session["key_parent"]
                )
                or not _matrices_nearly_equal(
                    parent_world,
                    session["parent_matrix"],
                )
            )
            session["moved"] = moved
            if moved and session["compensate"]:
                # Blender directly transforms every selected bone and also
                # moves this child through Child Of, producing a double delta.
                # Restore the captured local pose; the constraint then supplies
                # exactly the parent's one intended world-space displacement.
                pose_bone.matrix_basis = session["child_basis"].copy()
                context.view_layer.update()
            if moved and session["visual"]:
                session["visual_matrix"] = pose_bone.matrix.copy()
        return False

    changed = False
    processed_keys = set()
    for key, session in tuple(sessions.items()):
        processed_keys.add(key)
        armature = _armature_from_session_uid(session["armature_uid"])
        pose_bone = (
            armature.pose.bones.get(session["bone_name"])
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        target = _armature_from_session_uid(session["parent_uid"])
        parent_bone = (
            target.pose.bones.get(session["parent_bone"])
            if target is not None and getattr(target, "pose", None)
            else None
        )
        parent_world = (
            target.matrix_world @ parent_bone.matrix
            if target is not None and parent_bone is not None
            else None
        )
        moved = bool(
            parent_bone is not None
            and parent_world is not None
            and not _matrices_nearly_equal(
                parent_world,
                session["parent_matrix"],
            )
        )
        if moved and pose_bone is not None:
            if session["compensate"]:
                pose_bone.matrix_basis = session["child_basis"].copy()
                context.view_layer.update()
            if session["visual"]:
                session["visual_matrix"] = pose_bone.matrix.copy()
            if parent_bone is not None and session["key_parent"]:
                _dynamic_parent_force_pose_key(
                    parent_bone,
                    session["frame"],
                    visual=False,
                )
            if session["visual"]:
                _state.setdefault(
                    "dynamic_parent_indirect_visual_commits",
                    {},
                )[key] = {
                    "armature_uid": session["armature_uid"],
                    "bone_name": session["bone_name"],
                    "frame": session["frame"],
                    "matrix": session["visual_matrix"].copy(),
                    "basis": (
                        session["child_basis"].copy()
                        if session["compensate"]
                        else None
                    ),
                    "managed_space": session["managed_space"],
                    "history": (
                        {
                            "armature_uid": session["armature_uid"],
                            "bone_name": session["bone_name"],
                            "frame": session["frame"],
                            "child_before_basis": (
                                session["child_basis"].copy()
                            ),
                            "child_before_keyed": (
                                session["child_before_keyed"]
                            ),
                            "parent_uid": session["parent_uid"],
                            "parent_bone": session["parent_bone"],
                            "parent_before_basis": (
                                session["parent_basis"].copy()
                            ),
                            "parent_after_basis": (
                                parent_bone.matrix_basis.copy()
                            ),
                        }
                        if not session["managed_space"]
                        else None
                    ),
                }
                _schedule_dynamic_parent_boundary_refresh()
            changed = True
        sessions.pop(key, None)

    if capture_unsessioned:
        for key, (
            armature,
            pose_bone,
            target,
            parent_bone,
            visual,
            _compensate,
            managed_space,
            key_parent,
        ) in desired.items():
            baseline = baselines.get(key)
            baseline_matrix = _dynamic_parent_baseline_matrix(baseline)
            if (
                key in processed_keys
                or not visual
                or baseline_matrix is None
                or not isinstance(baseline, dict)
                or int(baseline.get("frame", frame)) != frame
            ):
                continue
            parent_world = target.matrix_world @ parent_bone.matrix
            baseline_world = target.matrix_world @ baseline_matrix
            if _matrices_nearly_equal(parent_world, baseline_world):
                continue
            if key_parent:
                _dynamic_parent_force_pose_key(
                    parent_bone,
                    frame,
                    visual=False,
                )
            if not managed_space:
                _state["dynamic_parent_native_history_transition"] = None
                _state[
                    "dynamic_parent_native_history_expected_index"
                ] = None
            _state.setdefault(
                "dynamic_parent_indirect_visual_commits",
                {},
            )[key] = {
                "armature_uid": _armature_session_uid(armature),
                "bone_name": pose_bone.name,
                "frame": frame,
                "matrix": pose_bone.matrix.copy(),
                "basis": None,
                "managed_space": bool(managed_space),
                "history": (
                    {
                        "armature_uid": _armature_session_uid(
                            armature
                        ),
                        "bone_name": pose_bone.name,
                        "frame": frame,
                        "child_before_basis": baseline[
                            "child_basis"
                        ].copy(),
                        "child_before_keyed": bool(
                            baseline["child_keyed"]
                        ),
                        "parent_uid": _armature_session_uid(target),
                        "parent_bone": parent_bone.name,
                        "parent_before_basis": baseline[
                            "parent_basis"
                        ].copy(),
                        "parent_after_basis": (
                            parent_bone.matrix_basis.copy()
                        ),
                    }
                    if not managed_space
                    and all(
                        name in baseline
                        for name in (
                            "child_basis",
                            "child_keyed",
                            "parent_basis",
                        )
                    )
                    else None
                ),
            }
            _schedule_dynamic_parent_boundary_refresh()
            changed = True

    baselines.clear()
    baselines.update({
        key: {
            "matrix": parent_bone.matrix.copy(),
            "frame": frame,
            "child_basis": _pose_bone.matrix_basis.copy(),
            "child_keyed": _dynamic_parent_pose_keyed_at(
                _armature,
                _pose_bone.name,
                frame,
            ),
            "parent_basis": parent_bone.matrix_basis.copy(),
        }
        for key, (
            _armature,
            _pose_bone,
            _target,
            parent_bone,
            _visual,
            _compensate,
            _managed_space,
            _key_parent,
        )
        in desired.items()
    })
    return changed


def _sync_dynamic_parent_dual_selection_locks(
    context,
    capture_unsessioned=False,
):
    """Keep jointly selected Dynamic Parent pairs on one native transform.

    Blender normally translates every selected pose bone directly. A selected
    Child Of target also moves its selected child through the constraint, which
    doubles the child's translation. Preserve the child's captured local pose
    during the transform instead of changing lock_location: native Blender
    gizmos then remain available for either active bone.
    """

    if _state.get("dynamic_parent_dual_selection_save_paused", False):
        return False

    records = _state.setdefault("dynamic_parent_dual_selection_locks", {})
    desired = {}
    indirect = {}
    if context is not None and getattr(context, "mode", "") == "POSE":
        grouped = _selected_pose_bones_by_owner(context)
        selected_keys = {
            _dynamic_parent_dual_selection_key(armature, pose_bone)
            for armature, pose_bones in grouped.items()
            for pose_bone in pose_bones
        }
        frame = int(context.scene.frame_current)
        for armature in _pose_scope_armatures(context):
            for pose_bone in armature.pose.bones:
                child_key = _dynamic_parent_dual_selection_key(
                    armature,
                    pose_bone,
                )
                if child_key in selected_keys:
                    continue
                constraint = _active_dynamic_parent_constraint(
                    pose_bone,
                    frame,
                )
                if constraint is not None:
                    target = _dynamic_parent_constraint_target(
                        pose_bone,
                        constraint,
                    )
                    subtarget = _dynamic_parent_constraint_subtarget(
                        pose_bone,
                        constraint,
                    )
                    parent_bone = (
                        target.pose.bones.get(subtarget)
                        if target is not None
                        and getattr(target, "type", "") == "ARMATURE"
                        and subtarget
                        else None
                    )
                    if (
                        parent_bone is not None
                        and _dynamic_parent_dual_selection_key(
                            target,
                            parent_bone,
                        )
                        in selected_keys
                    ):
                        indirect[child_key] = (
                            armature,
                            pose_bone,
                            target,
                            parent_bone,
                            True,
                            False,
                            False,
                            True,
                        )
                    continue

                # Dynamic Unparent owns the exact displayed world pose while
                # its world-space helper is active. A later Action refresh
                # recalibrates that boundary from the edited normal parent;
                # capture the live output so confirmation can key the input
                # pose back under the rebuilt helper instead of snapping.
                chosen = _chosen_dynamic_parent_constraint(pose_bone, frame)
                if (
                    chosen is None
                    or not chosen.name.startswith(SPACE_CONSTRAINT_PREFIX)
                    or _dynamic_space_role(pose_bone, chosen)
                    != SPACE_ROLE_UNPARENT
                ):
                    continue
                start, _end = _dynamic_parent_constraint_segment(
                    pose_bone,
                    chosen,
                )
                if start is None:
                    continue
                normal_constraint = _chosen_dynamic_parent_constraint(
                    pose_bone,
                    int(start) - 1,
                )
                target = _dynamic_parent_constraint_target(
                    pose_bone,
                    normal_constraint,
                )
                subtarget = _dynamic_parent_constraint_subtarget(
                    pose_bone,
                    normal_constraint,
                )
                parent_bone = (
                    target.pose.bones.get(subtarget)
                    if target is not None
                    and getattr(target, "type", "") == "ARMATURE"
                    and subtarget
                    else None
                )
                if parent_bone is None:
                    continue
                indirect[child_key] = (
                    armature,
                    pose_bone,
                    target,
                    parent_bone,
                    True,
                    False,
                    True,
                    (
                        _dynamic_parent_dual_selection_key(
                            target,
                            parent_bone,
                        )
                        in selected_keys
                    ),
                )
        for armature, pose_bones in grouped.items():
            for pose_bone in pose_bones:
                constraint = _active_dynamic_parent_constraint(pose_bone, frame)
                if constraint is None:
                    continue
                target = _dynamic_parent_constraint_target(
                    pose_bone,
                    constraint,
                )
                subtarget = _dynamic_parent_constraint_subtarget(
                    pose_bone,
                    constraint,
                )
                if (
                    target is None
                    or getattr(target, "type", "") != "ARMATURE"
                    or not subtarget
                ):
                    continue
                parent_bone = target.pose.bones.get(subtarget)
                if parent_bone is None:
                    continue
                if (
                    _dynamic_parent_dual_selection_key(target, parent_bone)
                    not in selected_keys
                ):
                    continue
                desired[_dynamic_parent_dual_selection_key(armature, pose_bone)] = (
                    armature,
                    pose_bone,
                    target,
                    parent_bone,
                    True,
                    True,
                    False,
                    True,
                )

    changed = False
    for key, original_locks in tuple(records.items()):
        armature_uid, bone_name = key
        armature = _armature_from_session_uid(armature_uid)
        pose_bone = (
            armature.pose.bones.get(bone_name)
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is not None:
            try:
                pose_bone.lock_location = tuple(
                    bool(value) for value in original_locks
                )
                changed = True
            except (AttributeError, ReferenceError, RuntimeError, TypeError):
                pass
        records.pop(key, None)

    key_targets = dict(indirect)
    key_targets.update(desired)
    return (
        _sync_dynamic_parent_dual_selection_keys(
            context,
            key_targets,
            capture_unsessioned=capture_unsessioned,
        )
        or changed
    )
