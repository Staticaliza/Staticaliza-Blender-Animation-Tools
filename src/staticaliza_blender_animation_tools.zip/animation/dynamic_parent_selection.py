"""Dynamic Parent dual-selection transform locking and key synchronization."""

from ..core.runtime import *  # noqa: F403

def _dynamic_parent_dual_selection_key(armature, pose_bone):
    return (_armature_session_uid(armature), pose_bone.name)


def _restore_dynamic_parent_dual_selection_locks():
    """Restore location locks temporarily owned by dual-parent selection."""

    records = _state.setdefault("dynamic_parent_dual_selection_locks", {})
    changed = False
    for (armature_uid, bone_name), original_locks in tuple(records.items()):
        armature = _armature_from_session_uid(armature_uid)
        pose_bone = (
            armature.pose.bones.get(bone_name)
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is None:
            continue
        try:
            pose_bone.lock_location = tuple(bool(value) for value in original_locks)
            changed = True
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            continue
    records.clear()
    _state.setdefault("dynamic_parent_dual_selection_translate_sessions", {}).clear()
    _state.setdefault("dynamic_parent_indirect_parent_baselines", {}).clear()
    _state["dynamic_parent_history_snapshot"] = ()
    _dynamic_parent_clear_prepared_history_transition()
    return changed

def _dynamic_parent_force_pose_key(pose_bone, frame, visual=False):
    """Insert a child key regardless of Needed/Available preference flags."""

    preferences = getattr(getattr(bpy.context, "preferences", None), "edit", None)
    property_names = (
        "use_auto_keyframe_insert_needed",
        "use_keyframe_insert_available",
        "use_keyframe_insert_needed",
    )
    saved = {}
    if preferences is not None:
        for property_name in property_names:
            if not hasattr(preferences, property_name):
                continue
            saved[property_name] = bool(getattr(preferences, property_name))
            setattr(preferences, property_name, False)
    try:
        _insert_bone_keys(pose_bone, int(frame), visual=bool(visual))
    finally:
        for property_name, value in saved.items():
            setattr(preferences, property_name, value)

def _dynamic_parent_apply_indirect_visual_commits(context):
    """Key captured follower previews after boundary inverses are rebuilt."""

    commits = dict(
        _state.get("dynamic_parent_indirect_visual_commits", {})
    )
    _state["dynamic_parent_indirect_visual_commits"] = {}
    if not commits:
        return False
    changed = False
    history_entries = []
    previous_mute = bool(_state.get("unparent_handler_mute", False))
    _state["unparent_handler_mute"] = True
    try:
        for commit in commits.values():
            armature = _armature_from_session_uid(commit["armature_uid"])
            pose_bone = (
                armature.pose.bones.get(commit["bone_name"])
                if armature is not None and getattr(armature, "pose", None)
                else None
            )
            if pose_bone is None:
                continue
            basis = commit.get("basis")
            if basis is not None:
                pose_bone.matrix_basis = basis.copy()
                context.view_layer.update()
                _dynamic_parent_force_pose_key(
                    pose_bone,
                    commit["frame"],
                    visual=False,
                )
            else:
                constraint = (
                    _chosen_dynamic_parent_constraint(
                        pose_bone,
                        int(commit["frame"]),
                    )
                    if commit.get("managed_space", False)
                    else get_last_dynamic_parent_constraint(
                        pose_bone,
                        int(commit["frame"]),
                    )
                )
                input_matrix = _dynamic_parent_input_matrix(
                    context,
                    armature,
                    constraint,
                    commit["matrix"],
                )
                constraint_mute = bool(
                    getattr(constraint, "mute", False)
                ) if constraint is not None else False
                try:
                    if constraint is not None:
                        constraint.mute = True
                        context.view_layer.update()
                        pose_bone = armature.pose.bones.get(
                            commit["bone_name"]
                        )
                    pose_bone.matrix = input_matrix
                    context.view_layer.update()
                    _dynamic_parent_force_pose_key(
                        pose_bone,
                        commit["frame"],
                        visual=False,
                    )
                finally:
                    if constraint is not None:
                        constraint.mute = constraint_mute
                        context.view_layer.update()
            changed = True
            history = commit.get("history")
            if history is not None:
                history["child_after_basis"] = pose_bone.matrix_basis.copy()
                history["child_after_pose"] = _dynamic_parent_pose_state(pose_bone)
                history["child_after_space"] = _dynamic_parent_space_state(pose_bone)
                # Boundary recalibration and selected-pair compensation can
                # change the final evaluated output from the live modal
                # sample. History must replay what the user actually sees
                # after the commit has settled.
                history["child_after_matrix"] = pose_bone.matrix.copy()
                history["child_after_keys"] = _dynamic_parent_pose_key_snapshot(
                    armature,
                    pose_bone.name,
                    commit["frame"],
                )
                history["child_after_keyed"] = (
                    _dynamic_parent_pose_key_snapshot_present(
                        history["child_after_keys"]
                    )
                )
                history["child_after_pending"] = False
                history_entries.append(history)
        if changed:
            context.view_layer.update()
        _dynamic_parent_store_native_history_transition(history_entries)
    finally:
        _state["unparent_handler_mute"] = previous_mute
    return changed


def _dynamic_parent_commit_active_transform_sample(context):
    """Commit dependent pose data while Blender still owns the transform.

    A native G/R/S operator pushes its undo checkpoint when the modal operator
    finishes.  Any follower key authored by the idle timer afterwards belongs
    to no native history entry and makes Undo skip or Redo truncate a visible
    state.  Keep the live compensation and its keys inside that same modal
    transaction.  The deferred refresh may still rebuild derived constraint
    inverses, but it no longer authors pose data.
    """

    operator_id = _pin_active_transform_operator(context)
    if not operator_id:
        return False
    synced = _sync_dynamic_parent_dual_selection_locks(context)
    sessions = _state.setdefault(
        "dynamic_parent_dual_selection_translate_sessions",
        {},
    )
    delta_signature = _pin_transform_operator_delta_signature(
        context,
        operator_id,
    )
    active = []
    for key, session in tuple(sessions.items()):
        if (
            not session.get("moved", False)
            or not session.get("visual", False)
            or session.get("visual_matrix") is None
            or session.get("live_commit_signature") == delta_signature
        ):
            continue
        armature = _armature_from_session_uid(session["armature_uid"])
        pose_bone = (
            armature.pose.bones.get(session["bone_name"])
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        target = _armature_from_session_uid(session["parent_uid"])
        parent_bone = (
            target.pose.bones.get(session["parent_bone"])
            if target is not None and getattr(target, "pose", None)
            else None
        )
        if pose_bone is None or parent_bone is None:
            continue
        active.append((key, session, armature, pose_bone, target, parent_bone))
    if not active:
        return synced

    previous_mute = bool(_state.get("unparent_handler_mute", False))
    _state["unparent_handler_mute"] = True
    changed = False
    try:
        # Only the visible boundary is needed for the modal transaction.  A
        # chronological all-boundary refresh remains deferred and inverse-only.
        calibrated = set()
        for _key, session, armature, _pose_bone, _target, _parent_bone in active:
            if not session.get("managed_space", False):
                continue
            calibration_key = (
                _armature_session_uid(armature),
                int(session["frame"]),
            )
            if calibration_key in calibrated:
                continue
            calibrated.add(calibration_key)
            changed = (
                _calibrate_dynamic_space_boundaries(
                    context,
                    int(session["frame"]),
                    armature,
                )
                or changed
            )

        for _key, session, armature, pose_bone, target, parent_bone in active:
            if session.get("compensate", False):
                pose_bone.matrix_basis = session["child_basis"].copy()
                context.view_layer.update()
            else:
                constraint = (
                    _chosen_dynamic_parent_constraint(
                        pose_bone,
                        int(session["frame"]),
                    )
                    if session.get("managed_space", False)
                    else get_last_dynamic_parent_constraint(
                        pose_bone,
                        int(session["frame"]),
                    )
                )
                input_matrix = _dynamic_parent_input_matrix(
                    context,
                    armature,
                    constraint,
                    session["visual_matrix"],
                )
                constraint_mute = bool(
                    getattr(constraint, "mute", False)
                ) if constraint is not None else False
                try:
                    if constraint is not None:
                        constraint.mute = True
                        context.view_layer.update()
                        pose_bone = armature.pose.bones.get(session["bone_name"])
                    pose_bone.matrix = input_matrix
                    context.view_layer.update()
                finally:
                    if constraint is not None:
                        constraint.mute = constraint_mute
                        context.view_layer.update()
            _dynamic_parent_force_pose_key(
                pose_bone,
                int(session["frame"]),
                visual=False,
            )
            if session.get("key_parent", False):
                _dynamic_parent_force_pose_key(
                    parent_bone,
                    int(session["frame"]),
                    visual=False,
                )
            context.view_layer.update()
            session["visual_matrix"] = pose_bone.matrix.copy()
            session["live_commit_signature"] = delta_signature
            session["modal_committed"] = True
            changed = True
        if changed:
            _store_dynamic_parent_animation_signature()
    finally:
        _state["unparent_handler_mute"] = previous_mute
    return bool(synced or changed)

def _dynamic_parent_baseline_matrix(record):
    if isinstance(record, dict):
        return record.get("matrix")
    return record


def _sync_dynamic_parent_dual_selection_keys(
    context,
    desired,
    capture_unsessioned=False,
):
    """Commit selected parents and their followers from the final live pose."""

    sessions = _state.setdefault(
        "dynamic_parent_dual_selection_translate_sessions",
        {},
    )
    operator_id = _pin_active_transform_operator(context)
    operator_name = operator_id.casefold()
    transforming = any(
        name in operator_name
        for name in ("translate", "rotate", "trackball", "resize")
    )
    delta_state = (
        _pin_transform_operator_delta_state(context, operator_id)
        if transforming
        else None
    )
    baselines = _state.setdefault(
        "dynamic_parent_indirect_parent_baselines",
        {},
    )
    frame = int(context.scene.frame_current)

    if transforming:
        if desired and not sessions:
            # A boundary refresh is deferred so Blender's native transform
            # checkpoint remains authoritative.  If another transform starts
            # first, preserve that completed transition now; otherwise a new
            # commit for the same follower key overwrites the prior move and
            # redo skips the intervening parent/ancestor displacement.
            if _state.get("dynamic_parent_indirect_visual_commits"):
                _dynamic_parent_stage_pending_history_transition(context)
                sessions = _state.setdefault(
                    "dynamic_parent_dual_selection_translate_sessions",
                    {},
                )
                baselines = _state.setdefault(
                    "dynamic_parent_indirect_parent_baselines",
                    {},
                )
            _dynamic_parent_clear_prepared_history_transition()
        for key, (
            armature,
            pose_bone,
            target,
            parent_bone,
            visual,
            compensate,
            managed_space,
            key_parent,
        ) in desired.items():
            session = sessions.get(key)
            if session is None:
                baseline = _dynamic_parent_baseline_matrix(
                    baselines.get(key)
                )
                child_before_keys = _dynamic_parent_pose_key_snapshot(
                    armature,
                    pose_bone.name,
                    frame,
                )
                parent_before_keys = _dynamic_parent_pose_key_snapshot(
                    target,
                    parent_bone.name,
                    frame,
                )
                session = {
                    "armature_uid": _armature_session_uid(armature),
                    "bone_name": pose_bone.name,
                    "parent_uid": _armature_session_uid(target),
                    "parent_bone": parent_bone.name,
                    "parent_matrix": (
                        target.matrix_world
                        @ (
                            baseline
                            if baseline is not None
                            else parent_bone.matrix
                        )
                    ).copy(),
                    "child_basis": pose_bone.matrix_basis.copy(),
                    "child_matrix": pose_bone.matrix.copy(),
                    "child_pose": _dynamic_parent_pose_state(pose_bone),
                    "child_space": _dynamic_parent_space_state(pose_bone),
                    "child_before_keys": child_before_keys,
                    "child_before_keyed": _dynamic_parent_pose_key_snapshot_present(child_before_keys),
                    "parent_basis": parent_bone.matrix_basis.copy(),
                    "parent_pose": _dynamic_parent_pose_state(parent_bone),
                    "parent_before_keys": parent_before_keys,
                    "parent_before_keyed": _dynamic_parent_pose_key_snapshot_present(parent_before_keys),
                    "driver_before_states": _dynamic_parent_history_driver_pose_snapshots(
                        target,
                        parent_bone.name,
                        frame,
                    ),
                    "frame": frame,
                    "moved": False,
                    "visual": bool(visual),
                    "compensate": bool(compensate),
                    "managed_space": bool(managed_space),
                    "key_parent": bool(key_parent),
                    "visual_matrix": None,
                }
                sessions[key] = session
            parent_world = target.matrix_world @ parent_bone.matrix
            moved = bool(
                session["moved"]
                or (
                    delta_state is True
                    and session["key_parent"]
                )
                or not _matrices_nearly_equal(
                    parent_world,
                    session["parent_matrix"],
                )
            )
            session["moved"] = moved
            if moved and session["compensate"]:
                # Blender directly transforms every selected bone and also
                # moves this child through Child Of, producing a double delta.
                # Restore the captured local pose; the constraint then supplies
                # exactly the parent's one intended world-space displacement.
                pose_bone.matrix_basis = session["child_basis"].copy()
                context.view_layer.update()
            if moved and session["visual"]:
                session["visual_matrix"] = pose_bone.matrix.copy()
        return False

    changed = False
    processed_keys = set()
    for key, session in tuple(sessions.items()):
        processed_keys.add(key)
        armature = _armature_from_session_uid(session["armature_uid"])
        pose_bone = (
            armature.pose.bones.get(session["bone_name"])
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        target = _armature_from_session_uid(session["parent_uid"])
        parent_bone = (
            target.pose.bones.get(session["parent_bone"])
            if target is not None and getattr(target, "pose", None)
            else None
        )
        parent_world = (
            target.matrix_world @ parent_bone.matrix
            if target is not None and parent_bone is not None
            else None
        )
        moved = bool(
            parent_bone is not None
            and parent_world is not None
            and not _matrices_nearly_equal(
                parent_world,
                session["parent_matrix"],
            )
        )
        if moved and pose_bone is not None:
            modal_committed = bool(session.get("modal_committed", False))
            if session["compensate"] and not modal_committed:
                pose_bone.matrix_basis = session["child_basis"].copy()
                context.view_layer.update()
            if modal_committed:
                if session.get("managed_space", False):
                    _schedule_dynamic_parent_boundary_refresh()
            elif session["visual"]:
                session["visual_matrix"] = pose_bone.matrix.copy()
            if (
                not modal_committed
                and parent_bone is not None
                and session["key_parent"]
            ):
                _dynamic_parent_force_pose_key(
                    parent_bone,
                    session["frame"],
                    visual=False,
                )
            parent_after_keys = (
                _dynamic_parent_pose_key_snapshot(
                    target,
                    parent_bone.name,
                    session["frame"],
                )
                if parent_bone is not None
                else None
            )
            if session["visual"] and not modal_committed:
                _state.setdefault(
                    "dynamic_parent_indirect_visual_commits",
                    {},
                )[key] = {
                    "armature_uid": session["armature_uid"],
                    "bone_name": session["bone_name"],
                    "frame": session["frame"],
                    "matrix": session["visual_matrix"].copy(),
                    "basis": (
                        session["child_basis"].copy()
                        if session["compensate"]
                        else None
                    ),
                    "managed_space": session["managed_space"],
                    "history": (
                        {
                            "armature_uid": session["armature_uid"],
                            "bone_name": session["bone_name"],
                            "frame": session["frame"],
                            "child_before_basis": session["child_basis"].copy(),
                            "child_before_matrix": session["child_matrix"].copy(),
                            "child_before_pose": session.get("child_pose"),
                            "child_before_space": session.get("child_space"),
                            "child_before_keys": session["child_before_keys"],
                            "child_before_keyed": session["child_before_keyed"],
                            "parent_uid": session["parent_uid"],
                            "parent_bone": session["parent_bone"],
                            "parent_key_owned": session["key_parent"],
                            "parent_before_basis": session["parent_basis"].copy(),
                            "parent_before_pose": session.get("parent_pose"),
                            "parent_before_matrix": session["parent_matrix"].copy(),
                            "parent_before_keys": session["parent_before_keys"],
                            "parent_before_keyed": session["parent_before_keyed"],
                            "driver_before_states": session.get(
                                "driver_before_states", ()
                            ),
                            "parent_after_basis": (
                                parent_bone.matrix_basis.copy()
                            ),
                            "parent_after_pose": _dynamic_parent_pose_state(parent_bone),
                            "parent_after_matrix": (
                                target.matrix_world @ parent_bone.matrix
                            ).copy(),
                            "parent_after_keys": parent_after_keys,
                            "parent_after_keyed": (
                                _dynamic_parent_pose_key_snapshot_present(
                                    parent_after_keys
                                )
                            ),
                            "driver_after_states": _dynamic_parent_history_driver_pose_snapshots(
                                target,
                                parent_bone.name,
                                session["frame"],
                            ),
                        }
                    ),
                }
                _schedule_dynamic_parent_boundary_refresh()
            changed = True
        sessions.pop(key, None)

    if capture_unsessioned:
        for key, (
            armature,
            pose_bone,
            target,
            parent_bone,
            visual,
            _compensate,
            managed_space,
            key_parent,
        ) in desired.items():
            baseline = baselines.get(key)
            baseline_matrix = _dynamic_parent_baseline_matrix(baseline)
            if (
                key in processed_keys
                or not visual
                or baseline_matrix is None
                or not isinstance(baseline, dict)
                or int(baseline.get("frame", frame)) != frame
            ):
                continue
            parent_world = target.matrix_world @ parent_bone.matrix
            baseline_world = target.matrix_world @ baseline_matrix
            if _matrices_nearly_equal(parent_world, baseline_world):
                continue
            if key_parent:
                _dynamic_parent_force_pose_key(
                    parent_bone,
                    frame,
                    visual=False,
                )
            parent_after_keys = _dynamic_parent_pose_key_snapshot(
                target,
                parent_bone.name,
                frame,
            )
            if not managed_space:
                _dynamic_parent_clear_prepared_history_transition()
            _state.setdefault(
                "dynamic_parent_indirect_visual_commits",
                {},
            )[key] = {
                "armature_uid": _armature_session_uid(armature),
                "bone_name": pose_bone.name,
                "frame": frame,
                "matrix": pose_bone.matrix.copy(),
                "basis": None,
                "managed_space": bool(managed_space),
                "history": (
                    {
                        "armature_uid": _armature_session_uid(
                            armature
                        ),
                        "bone_name": pose_bone.name,
                        "frame": frame,
                        "child_before_basis": baseline[
                            "child_basis"
                        ].copy(),
                        "child_before_matrix": baseline[
                            "child_matrix"
                        ].copy(),
                        "child_before_pose": baseline.get("child_pose"),
                        "child_before_space": baseline.get("child_space"),
                        "child_before_keys": baseline["child_keys"],
                        "child_before_keyed": bool(
                            baseline["child_keyed"]
                        ),
                        "parent_uid": _armature_session_uid(target),
                        "parent_bone": parent_bone.name,
                        "parent_key_owned": bool(key_parent),
                        "parent_before_basis": baseline[
                            "parent_basis"
                        ].copy(),
                        "parent_before_pose": baseline.get("parent_pose"),
                        "parent_before_matrix": baseline[
                            "parent_world_matrix"
                        ].copy(),
                        "parent_before_keys": baseline["parent_keys"],
                        "parent_before_keyed": bool(
                            baseline["parent_keyed"]
                        ),
                        "driver_before_states": baseline.get(
                            "driver_states", ()
                        ),
                        "parent_after_basis": (
                            parent_bone.matrix_basis.copy()
                        ),
                        "parent_after_pose": _dynamic_parent_pose_state(parent_bone),
                        "parent_after_matrix": (
                            target.matrix_world @ parent_bone.matrix
                        ).copy(),
                        "parent_after_keys": parent_after_keys,
                        "parent_after_keyed": (
                            _dynamic_parent_pose_key_snapshot_present(
                                parent_after_keys
                            )
                        ),
                        "driver_after_states": _dynamic_parent_history_driver_pose_snapshots(
                            target,
                            parent_bone.name,
                            frame,
                        ),
                    }
                    if all(
                        name in baseline
                        for name in (
                            "child_basis",
                            "child_matrix",
                            "child_keyed",
                            "child_keys",
                            "parent_basis",
                            "parent_world_matrix",
                            "parent_keys",
                            "parent_keyed",
                        )
                    )
                    else None
                ),
            }
            _schedule_dynamic_parent_boundary_refresh()
            changed = True

    baselines.clear()
    baselines.update({
        key: {
            "matrix": parent_bone.matrix.copy(),
            "frame": frame,
            "child_basis": _pose_bone.matrix_basis.copy(),
            "child_matrix": _pose_bone.matrix.copy(),
            "child_pose": _dynamic_parent_pose_state(_pose_bone),
            "child_space": _dynamic_parent_space_state(_pose_bone),
            "child_keys": _dynamic_parent_pose_key_snapshot(
                _armature,
                _pose_bone.name,
                frame,
            ),
            "child_keyed": _dynamic_parent_pose_keyed_at(
                _armature,
                _pose_bone.name,
                frame,
            ),
            "parent_basis": parent_bone.matrix_basis.copy(),
            "parent_pose": _dynamic_parent_pose_state(parent_bone),
            "parent_world_matrix": (
                _target.matrix_world @ parent_bone.matrix
            ).copy(),
            "parent_keys": _dynamic_parent_pose_key_snapshot(
                _target,
                parent_bone.name,
                frame,
            ),
            "parent_keyed": _dynamic_parent_pose_keyed_at(
                _target,
                parent_bone.name,
                frame,
            ),
            "driver_states": _dynamic_parent_history_driver_pose_snapshots(
                _target,
                parent_bone.name,
                frame,
            ),
        }
        for key, (
            _armature,
            _pose_bone,
            _target,
            parent_bone,
            _visual,
            _compensate,
            _managed_space,
            _key_parent,
        )
        in desired.items()
    })
    return changed


def _sync_dynamic_parent_dual_selection_locks(
    context,
    capture_unsessioned=False,
):
    """Keep jointly selected Dynamic Parent pairs on one native transform.

    Blender normally translates every selected pose bone directly. A selected
    Child Of target also moves its selected child through the constraint, which
    doubles the child's translation. Preserve the child's captured local pose
    during the transform instead of changing lock_location: native Blender
    gizmos then remain available for either active bone.
    """

    if _state.get("dynamic_parent_dual_selection_save_paused", False):
        return False

    records = _state.setdefault("dynamic_parent_dual_selection_locks", {})
    desired = {}
    indirect = {}
    if context is not None and getattr(context, "mode", "") == "POSE":
        grouped = _selected_pose_bones_by_owner(context)
        selected_keys = {
            _dynamic_parent_dual_selection_key(armature, pose_bone)
            for armature, pose_bones in grouped.items()
            for pose_bone in pose_bones
        }
        frame = int(context.scene.frame_current)
        # Dynamic Unparent bones are physically detached and follow their
        # managed world-space constraint. They already remain independent
        # during an ordinary parent/ancestor transform. Authoring follower
        # keys after that transform created a second, non-native history state
        # and was the source of blank Undo entries and truncated Redo stacks.
        # Only an explicitly selected Dynamic Parent pair below needs modal
        # double-transform compensation.
        for armature, pose_bones in grouped.items():
            for pose_bone in pose_bones:
                constraint = _active_dynamic_parent_constraint(pose_bone, frame)
                if constraint is None:
                    continue
                target = _dynamic_parent_constraint_target(
                    pose_bone,
                    constraint,
                )
                subtarget = _dynamic_parent_constraint_subtarget(
                    pose_bone,
                    constraint,
                )
                if (
                    target is None
                    or getattr(target, "type", "") != "ARMATURE"
                    or not subtarget
                ):
                    continue
                parent_bone = target.pose.bones.get(subtarget)
                if parent_bone is None:
                    continue
                if (
                    _dynamic_parent_dual_selection_key(target, parent_bone)
                    not in selected_keys
                ):
                    continue
                desired[_dynamic_parent_dual_selection_key(armature, pose_bone)] = (
                    armature,
                    pose_bone,
                    target,
                    parent_bone,
                    True,
                    True,
                    False,
                    True,
                )

    changed = False
    for key, original_locks in tuple(records.items()):
        armature_uid, bone_name = key
        armature = _armature_from_session_uid(armature_uid)
        pose_bone = (
            armature.pose.bones.get(bone_name)
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is not None:
            try:
                pose_bone.lock_location = tuple(
                    bool(value) for value in original_locks
                )
                changed = True
            except (AttributeError, ReferenceError, RuntimeError, TypeError):
                pass
        records.pop(key, None)

    key_targets = dict(indirect)
    key_targets.update(desired)
    return (
        _sync_dynamic_parent_dual_selection_keys(
            context,
            key_targets,
            capture_unsessioned=capture_unsessioned,
        )
        or changed
    )
