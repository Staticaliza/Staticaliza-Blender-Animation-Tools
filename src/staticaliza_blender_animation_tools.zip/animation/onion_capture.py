"""Yellow-pin capture and onion-skin snapshot construction."""

from ..core.runtime import *  # noqa: F403

def _yellow_mode3_anchor(
    context,
    depsgraph,
    arm,
    eval_arm,
    objs,
    bone_name,
    axis = "Y_NEG",
):
    pb = eval_arm.pose.bones.get(bone_name)
    if not pb:
        return None, "", None

    fallback = _rig_local_lower_bone_endpoint(eval_arm, pb)
    canonical_name = _strip_blender_numeric_suffix(pb.name)

    keep_ratio = 0.25
    keep_max = 6
    candidates = []

    level_name_sets = list(_pose_bone_numeric_family_levels(eval_arm, pb))
    existing_names = set().union(*level_name_sets)
    connected_family = _surface_contact_bone_family_names(eval_arm, pb)
    weld_names = connected_family - existing_names
    if weld_names:
        level_name_sets.append(weld_names)

    search_objects = list(objs or ())
    for connected_object in _surface_contact_connected_objects(
        context,
        arm,
        connected_family,
    ):
        if connected_object not in search_objects:
            search_objects.append(connected_object)

    # Prefer the canonical non-numbered bone. Only fall back through connected
    # numeric variants and weld-only descendants, never articulated limbs.
    for level_names in level_name_sets:
        level_candidates = []

        for obj in search_objects:
            if obj.type != "MESH":
                continue
            if not _is_object_visible(obj, context):
                continue

            controller_bone_name = ""
            rigid_match = (
                obj.parent == arm
                and obj.parent_type == "BONE"
                and getattr(obj, "parent_bone", "") in level_names
            )
            if rigid_match:
                controller_bone_name = getattr(obj, "parent_bone", "")
            for constraint in obj.constraints:
                if (
                    getattr(constraint, "target", None) == arm
                    and getattr(constraint, "subtarget", "") in level_names
                ):
                    rigid_match = True
                    controller_bone_name = getattr(constraint, "subtarget", "")
                    break

            vertex_group_indices = set()
            if not rigid_match:
                try:
                    for descendant_name in level_names:
                        vertex_group = obj.vertex_groups.get(descendant_name)
                        if vertex_group:
                            vertex_group_indices.add(int(vertex_group.index))
                except Exception:
                    vertex_group_indices.clear()

            points = []
            object_local_anchor = None
            volume = 0.0

            if rigid_match:
                eval_obj = obj.evaluated_get(depsgraph)
                object_local_anchor, points, volume = _rigid_object_smart_anchor(
                    arm,
                    eval_arm,
                    eval_obj,
                    controller_bone_name,
                    axis = axis,
                )
            elif vertex_group_indices:
                eval_obj = obj.evaluated_get(depsgraph)
                mesh = eval_obj.to_mesh(preserve_all_data_layers = False, depsgraph = depsgraph)
                if not mesh:
                    continue

                mw = eval_obj.matrix_world

                for min_w in (0.35, 0.2, 0.05):
                    points = []
                    for vertex in mesh.vertices:
                        weight = 0.0
                        for group in vertex.groups:
                            if int(group.group) in vertex_group_indices:
                                weight = max(weight, float(group.weight))
                        if weight >= float(min_w):
                            points.append(mw @ vertex.co)

                    if len(points) >= 12:
                        break

                eval_obj.to_mesh_clear()
            else:
                continue

            if not points:
                continue

            if object_local_anchor is None:
                bounds = _bounds_init(points[0])
                for point in points[1:]:
                    _bounds_add(bounds, point)

                dx = float(bounds[3] - bounds[0])
                dy = float(bounds[4] - bounds[1])
                dz = float(bounds[5] - bounds[2])
                volume = max(0.0, dx) * max(0.0, dy) * max(0.0, dz)
            level_candidates.append(
                (
                    volume,
                    points,
                    obj,
                    _object_has_linked_base_color(obj),
                    object_local_anchor,
                    _strip_blender_numeric_suffix(obj.name) == canonical_name,
                    obj.name == canonical_name,
                )
            )

        if level_candidates:
            exact_name = [
                candidate for candidate in level_candidates if candidate[6]
            ]
            matching_name = [
                candidate for candidate in level_candidates if candidate[5]
            ]
            preferred_candidates = exact_name or matching_name or level_candidates
            without_linked_base_color = [
                candidate for candidate in preferred_candidates if not candidate[3]
            ]
            candidates = without_linked_base_color or preferred_candidates
            break

    if not candidates:
        return fallback.copy(), "", None

    candidates.sort(key = lambda x: float(x[0]), reverse = True)
    max_vol = float(candidates[0][0])
    cutoff = max_vol * keep_ratio

    primary = candidates[0]
    if primary[4] is not None:
        eval_obj = primary[2].evaluated_get(depsgraph)
        local_anchor = primary[4].copy()
        world_anchor = eval_obj.matrix_world @ local_anchor
        return (
            Vector((float(world_anchor.x), float(world_anchor.y), float(world_anchor.z))),
            primary[2].name,
            local_anchor,
        )

    cloud = []
    kept = 0
    for (
        vol,
        points,
        _obj,
        _has_linked_base_color,
        _local_anchor,
        _matching_name,
        _exact_name,
    ) in candidates:
        if kept >= keep_max:
            break
        if kept == 0 or float(vol) >= cutoff:
            cloud.extend(points)
            kept += 1

    if not cloud:
        return fallback.copy(), "", None

    if len(cloud) > 8000:
        step = int(len(cloud) / 8000) + 1
        cloud = cloud[::step]

    reference_object = primary[2].evaluated_get(depsgraph)
    try:
        reference_inverse = reference_object.matrix_world.inverted()
    except Exception:
        reference_inverse = Matrix.Identity(4)

    local_bounds = None
    for point in cloud:
        local = reference_inverse @ _as_p4(point)
        local_point = Vector((float(local.x), float(local.y), float(local.z)))
        if local_bounds is None:
            local_bounds = _bounds_init(local_point)
        else:
            _bounds_add(local_bounds, local_point)

    if local_bounds is None:
        return fallback.copy(), "", None

    local_anchor = Vector((
        (float(local_bounds[0]) + float(local_bounds[3])) * 0.5,
        (float(local_bounds[1]) + float(local_bounds[4])) * 0.5,
        (float(local_bounds[2]) + float(local_bounds[5])) * 0.5,
        1.0,
    ))
    axis_index, bound_index = {
        "X_POS": (0, 3),
        "X_NEG": (0, 0),
        "Y_POS": (1, 4),
        "Y_NEG": (1, 1),
        "Z_POS": (2, 5),
        "Z_NEG": (2, 2),
    }.get(str(axis), (1, 1))
    local_anchor[axis_index] = float(local_bounds[bound_index])
    world_anchor = reference_object.matrix_world @ local_anchor
    return (
        Vector((float(world_anchor.x), float(world_anchor.y), float(world_anchor.z))),
        primary[2].name,
        local_anchor,
    )


def _yellow_capture(
    context, depsgraph, arm, eval_arm, objs, bone_name, mode,
    bounds_world_map, axis="Y_NEG",
):
    pb = eval_arm.pose.bones.get(bone_name)
    if not pb:
        return None

    arm_mw = eval_arm.matrix_world
    head = arm_mw @ pb.head
    tail = arm_mw @ pb.tail

    smart_object_name = ""
    smart_object_local = None

    if mode == 1:
        end = tail
    elif mode == 2:
        b_world = bounds_world_map.get(bone_name, None) if bounds_world_map else None
        if b_world:
            end = _bounds_center(b_world)
        else:
            end = (head + tail) * 0.5
    elif mode == 4:
        end = head
    else:
        end, smart_object_name, smart_object_local = _yellow_mode3_anchor(
            context,
            depsgraph,
            arm,
            eval_arm,
            objs,
            bone_name,
            axis=axis,
        )
        if end is None:
            end = tail

    draw_dots = True
    if _is_unmovable(pb):
        draw_dots = False

    if mode == 4:
        local_p4 = Vector((0.0, 0.0, 0.0, 1.0))
    else:
        try:
            local_p4 = _world_to_bone_local_p4(eval_arm, pb, end)
        except Exception:
            local_p4 = Vector((0.0, 0.0, 0.0, 1.0))

    packed = (end.copy(), local_p4.copy(), draw_dots, int(mode))
    if mode == 3 and smart_object_name and smart_object_local is not None:
        packed += (smart_object_name, smart_object_local.copy())
    return packed

def _yellow_refresh_runtime(context):
    if not getattr(context, "window_manager", None):
        return
    scene = getattr(context, "scene", None)
    if scene is not None:
        _sync_all_dynamic_pose_bone_colors(int(scene.frame_current))
    if _runtime_needed(context):
        _enable_runtime()
    else:
        _disable_runtime()
    _tag_redraw_all_view3d()

def _build_snapshot_data(context, armature = None):
    scn = context.scene
    wm = context.window_manager
    depsgraph = context.evaluated_depsgraph_get()
    objs, arm = _targets(context, armature)

    include_meshes = wm.onion_skin_include_meshes
    include_bones = wm.onion_skin_include_bones
    raycast = wm.onion_skin_raycast

    shader3d = _ensure_shader_3d()
    vertex_color = (_state["shader_3d_mode"] == "VERTEX")

    mesh_alpha = wm.onion_skin_opacity
    mesh_color = (1.0, 0.0, 0.0, mesh_alpha)

    mesh_batches = []
    raycast_fixed = {}

    if include_meshes:
        for obj in objs:
            if obj.type != "MESH":
                continue
            if not _is_object_visible(obj, context):
                continue

            eval_obj = obj.evaluated_get(depsgraph)
            mesh = eval_obj.to_mesh(preserve_all_data_layers = False, depsgraph = depsgraph)
            if not mesh:
                continue

            mw = eval_obj.matrix_world

            try:
                mesh.calc_loop_triangles()
            except Exception:
                eval_obj.to_mesh_clear()
                continue

            tri_pos = []
            verts = mesh.vertices
            for tri in mesh.loop_triangles:
                v0, v1, v2 = tri.vertices
                tri_pos.append(mw @ verts[v0].co)
                tri_pos.append(mw @ verts[v1].co)
                tri_pos.append(mw @ verts[v2].co)

            if tri_pos:
                if vertex_color:
                    cols = [mesh_color] * len(tri_pos)
                    mesh_batches.append(batch_for_shader(shader3d, "TRIS", {"pos": tri_pos, "color": cols}))
                else:
                    mesh_batches.append(batch_for_shader(shader3d, "TRIS", {"pos": tri_pos}))

            eval_obj.to_mesh_clear()

    if not arm or not include_bones or not raycast:
        return mesh_batches, raycast_fixed

    arm_eval = arm.evaluated_get(depsgraph)
    arm_mw = arm_eval.matrix_world

    for pb in arm_eval.pose.bones:
        head = arm_mw @ pb.head
        tail = arm_mw @ pb.tail
        end = tail

        draw_dots = True
        if pb.parent is None:
            draw_dots = False
        elif _is_unmovable(pb):
            draw_dots = False

        try:
            local_p4 = _world_to_bone_local_p4(arm_eval, pb, end)
        except Exception:
            local_p4 = Vector((0.0, 0.0, 0.0, 1.0))

        raycast_fixed[pb.name] = (end.copy(), local_p4.copy(), draw_dots, 1)

    return mesh_batches, raycast_fixed
