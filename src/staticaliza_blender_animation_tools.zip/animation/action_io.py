"""Blender action/F-curve compatibility and keyframe insertion helpers."""

from ..core.runtime import *  # noqa: F403

def get_rotation_mode(obj):
    if obj.rotation_mode in ("QUATERNION", "AXIS_ANGLE"):
        return obj.rotation_mode.lower()
    return "euler"

def _action_channelbags(action, animated_id = None):
    if action is None or hasattr(action, "fcurves"):
        return ()

    target_handle = None
    animation_data = getattr(animated_id, "animation_data", None)
    if animation_data is not None and animation_data.action is action:
        target_handle = int(getattr(animation_data, "action_slot_handle", 0) or 0)

    channelbags = []
    for layer in getattr(action, "layers", ()):
        for strip in getattr(layer, "strips", ()):
            if getattr(strip, "type", "") != "KEYFRAME":
                continue
            for channelbag in getattr(strip, "channelbags", ()):
                if (
                    target_handle
                    and int(getattr(channelbag, "slot_handle", 0)) != target_handle
                ):
                    continue
                channelbags.append(channelbag)

    if target_handle and not channelbags:
        return _action_channelbags(action)
    return tuple(channelbags)


def _action_fcurves(action, animated_id = None):
    if action is None:
        return ()
    legacy_fcurves = getattr(action, "fcurves", None)
    if legacy_fcurves is not None:
        return tuple(legacy_fcurves)
    return tuple(
        fcurve
        for channelbag in _action_channelbags(action, animated_id)
        for fcurve in channelbag.fcurves
    )


def _action_remove_fcurve(action, fcurve):
    if action is None or fcurve is None:
        return False
    legacy_fcurves = getattr(action, "fcurves", None)
    if legacy_fcurves is not None:
        try:
            legacy_fcurves.remove(fcurve)
            return True
        except (RuntimeError, ValueError):
            return False

    for channelbag in _action_channelbags(action):
        channel_curves = tuple(channelbag.fcurves)
        try:
            target_pointer = int(fcurve.as_pointer())
        except (AttributeError, ReferenceError):
            target_pointer = 0
        candidate = next(
            (
                curve
                for curve in channel_curves
                if curve is fcurve
                or (
                    target_pointer
                    and int(curve.as_pointer()) == target_pointer
                )
            ),
            None,
        )
        if candidate is None:
            continue
        channelbag.fcurves.remove(candidate)
        return True
    return False


def _action_group_owners(action, animated_id = None):
    if action is None:
        return ()
    legacy_groups = getattr(action, "groups", None)
    if legacy_groups is not None:
        return (legacy_groups,)
    return tuple(
        channelbag.groups
        for channelbag in _action_channelbags(action, animated_id)
    )


def _action_ensure_channelbag(action, animated_id):
    if action is None or animated_id is None or hasattr(action, "fcurves"):
        return None

    animation_data = getattr(animated_id, "animation_data", None)
    if animation_data is None:
        animation_data = animated_id.animation_data_create()

    slot = None
    if animation_data.action is action:
        slot = getattr(animation_data, "action_slot", None)
    if slot is None:
        suitable_slots = tuple(getattr(animation_data, "action_suitable_slots", ()))
        slot = suitable_slots[0] if suitable_slots else None
    if slot is None:
        slot = action.slots.new(animated_id.id_type, animated_id.name)
    if animation_data.action is action and animation_data.action_slot is not slot:
        animation_data.action_slot = slot

    for layer in action.layers:
        for strip in layer.strips:
            if getattr(strip, "type", "") != "KEYFRAME":
                continue
            channelbag = strip.channelbag(slot)
            if channelbag is not None:
                return channelbag

    layer = action.layers[0] if action.layers else action.layers.new("Layer")
    strip = next(
        (
            candidate
            for candidate in layer.strips
            if getattr(candidate, "type", "") == "KEYFRAME"
        ),
        None,
    )
    if strip is None:
        strip = layer.strips.new(type = "KEYFRAME")
    return strip.channelbag(slot, ensure = True)

def _action_new_fcurve(action, data_path, animated_id = None, index = 0):
    legacy_fcurves = getattr(action, "fcurves", None)
    if legacy_fcurves is not None:
        return legacy_fcurves.new(data_path, index = int(index))

    channelbag = _action_ensure_channelbag(action, animated_id)
    if channelbag is None:
        raise RuntimeError("Unable to create an animation channel for this Action.")
    return channelbag.fcurves.new(data_path = data_path, index = int(index))


def _set_keyframe_handles_auto(target, frame):
    id_data = getattr(target, "id_data", None) or target
    animation_data = getattr(id_data, "animation_data", None)
    action = getattr(animation_data, "action", None)
    if action is None:
        return 0

    changed = 0
    target_frame = float(frame)
    target_path = ""
    if target is not id_data:
        try:
            target_path = target.path_from_id()
        except (AttributeError, TypeError, ValueError):
            target_path = ""
    for fcurve in _action_fcurves(action, id_data):
        if target_path and not (
            fcurve.data_path == target_path
            or fcurve.data_path.startswith(target_path + ".")
            or fcurve.data_path.startswith(target_path + "[")
        ):
            continue
        curve_changed = False
        for key in fcurve.keyframe_points:
            if abs(float(key.co.x) - target_frame) > 1.0e-5:
                continue
            if key.handle_left_type != "AUTO":
                key.handle_left_type = "AUTO"
                changed += 1
                curve_changed = True
            if key.handle_right_type != "AUTO":
                key.handle_right_type = "AUTO"
                changed += 1
                curve_changed = True
        if curve_changed:
            fcurve.update()
    return changed


def _set_fcurve_key_interpolation(target, data_path, frame, interpolation):
    id_data = getattr(target, "id_data", None) or target
    animation_data = getattr(id_data, "animation_data", None)
    action = getattr(animation_data, "action", None)
    if action is None:
        return 0

    changed = 0
    target_frame = float(frame)
    for fcurve in _action_fcurves(action, id_data):
        if fcurve.data_path != data_path:
            continue
        for key in fcurve.keyframe_points:
            if abs(float(key.co.x) - target_frame) > 1.0e-5:
                continue
            key.interpolation = interpolation
            changed += 1
        fcurve.update()
    return changed


def insert_keyframe(obj, frame):
    rotation_mode = get_rotation_mode(obj)
    data_paths = (
        "location",
        f"rotation_{rotation_mode}",
        "scale",
    )
    for data_path in data_paths:
        obj.keyframe_insert(data_path = data_path, frame = frame)
    _set_keyframe_handles_auto(obj, frame)


def insert_keyframe_constraint(constraint, frame, owner = None):
    if owner is None:
        return
    marker_property = _dynamic_parent_marker_property_name(constraint)
    marker_path = _dynamic_parent_marker_data_path(constraint)
    owner[marker_property] = float(constraint.influence)
    animated_id = getattr(owner, "id_data", None) or owner
    animated_id.keyframe_insert(data_path = marker_path, frame = frame)
    _set_keyframe_handles_auto(owner, frame)
    _set_fcurve_key_interpolation(
        owner,
        marker_path,
        frame,
        "CONSTANT",
    )
    if owner is not None:
        _set_dynamic_parent_fcurve_group(owner, constraint)

def dp_keyframe_insert_obj(obj):
    obj.keyframe_insert(data_path = "location")
    if obj.rotation_mode == "QUATERNION":
        obj.keyframe_insert(data_path = "rotation_quaternion")
    elif obj.rotation_mode == "AXIS_ANGLE":
        obj.keyframe_insert(data_path = "rotation_axis_angle")
    else:
        obj.keyframe_insert(data_path = "rotation_euler")
    obj.keyframe_insert(data_path = "scale")
    _set_keyframe_handles_auto(obj, bpy.context.scene.frame_current)

def dp_keyframe_insert_pbone(arm, pbone):
    arm.keyframe_insert(data_path = 'pose.bones["' + pbone.name + '"].location')
    if pbone.rotation_mode == "QUATERNION":
        arm.keyframe_insert(
            data_path = 'pose.bones["' + pbone.name + '"].rotation_quaternion'
        )
    elif pbone.rotation_mode == "AXIS_ANGLE":
        arm.keyframe_insert(
            data_path = 'pose.bones["' + pbone.name + '"].rotation_axis_angle'
        )
    else:
        arm.keyframe_insert(data_path = 'pose.bones["' + pbone.name + '"].rotation_euler')
    arm.keyframe_insert(data_path = 'pose.bones["' + pbone.name + '"].scale')
    _set_keyframe_handles_auto(pbone, bpy.context.scene.frame_current)
