"""Runtime indexes for Dynamic Parent and Dynamic Unparent frame handlers."""

from ..core.runtime import *  # noqa: F403


def _dynamic_space_invalidate_runtime_cache():
    _state["dynamic_space_runtime_cache_generation"] = int(
        _state.get("dynamic_space_runtime_cache_generation", 0)
    ) + 1
    _state["dynamic_space_runtime_cache_key"] = None
    _state["dynamic_space_runtime_constraint_owners"] = ()
    _state["dynamic_space_runtime_unparent_armatures"] = ()
    _state["dynamic_space_runtime_cache_validation_deadline"] = 0.0
    _state["dynamic_space_runtime_cache_hot"] = False


def _dynamic_space_owner_has_constraints(owner):
    try:
        return any(
            _is_dynamic_state_constraint(constraint)
            for constraint in owner.constraints
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        return False


def _dynamic_space_action_has_unparent(action, armature):
    if action is None:
        return False
    needle = f'["{UNP_PROP}"]'
    try:
        return any(
            needle in str(getattr(fcurve, "data_path", ""))
            for fcurve in _action_fcurves(action, armature)
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        return False


def _dynamic_space_runtime_hot(now=None):
    now = time.perf_counter() if now is None else float(now)
    context = getattr(bpy, "context", None)
    return bool(
        context is not None
        and (
            _animation_playback_active(context)
            or now < float(
                _state.get("dynamic_space_frame_evaluation_until", 0.0)
            )
        )
    )


def _dynamic_space_rebuild_runtime_cache():
    constraint_owner_keys = []
    unparent_armature_names = []
    for obj in tuple(bpy.data.objects):
        if _dynamic_space_owner_has_constraints(obj):
            constraint_owner_keys.append(("OBJECT", obj.name, ""))
        if obj.type != "ARMATURE" or getattr(obj, "pose", None) is None:
            continue
        unparent_managed = False
        for pose_bone in obj.pose.bones:
            if _dynamic_space_owner_has_constraints(pose_bone):
                constraint_owner_keys.append(
                    ("POSE_BONE", obj.name, pose_bone.name)
                )
            if (
                _pose_space_managed(pose_bone)
                or UNP_PROP in pose_bone
                or pose_bone.constraints.get(UNP_VIS_CONSTRAINT) is not None
            ):
                unparent_managed = True
        action = obj.animation_data.action if obj.animation_data else None
        if _dynamic_space_action_has_unparent(action, obj):
            unparent_managed = True
        if unparent_managed:
            unparent_armature_names.append(obj.name)
    generation = int(_state.get("dynamic_space_runtime_cache_generation", 0))
    now = time.perf_counter()
    hot = _dynamic_space_runtime_hot(now)
    _state["dynamic_space_runtime_cache_key"] = (
        generation,
        len(bpy.data.objects),
    )
    _state["dynamic_space_runtime_constraint_owners"] = tuple(
        constraint_owner_keys
    )
    _state["dynamic_space_runtime_unparent_armatures"] = tuple(
        unparent_armature_names
    )
    _state["dynamic_space_runtime_cache_validation_deadline"] = (
        now + (2.0 if hot else 0.35)
    )
    _state["dynamic_space_runtime_cache_hot"] = hot


def _dynamic_space_runtime_cache_current():
    generation = int(_state.get("dynamic_space_runtime_cache_generation", 0))
    current_key = generation, len(bpy.data.objects)
    now = time.perf_counter()
    hot = _dynamic_space_runtime_hot(now)
    cached_hot = bool(_state.get("dynamic_space_runtime_cache_hot", False))
    deadline = float(
        _state.get("dynamic_space_runtime_cache_validation_deadline", 0.0)
    )
    if (
        _state.get("dynamic_space_runtime_cache_key") != current_key
        or hot != cached_hot
        or now >= deadline
    ):
        _dynamic_space_rebuild_runtime_cache()


def _dynamic_space_constraint_owners(armature=None):
    if armature is not None:
        owners = []
        if _dynamic_space_owner_has_constraints(armature):
            owners.append(armature)
        pose = getattr(armature, "pose", None)
        if pose is not None:
            owners.extend(
                pose_bone
                for pose_bone in pose.bones
                if _dynamic_space_owner_has_constraints(pose_bone)
            )
        return tuple(owners)
    _dynamic_space_runtime_cache_current()
    owners = []
    for owner_type, object_name, bone_name in tuple(
        _state.get("dynamic_space_runtime_constraint_owners", ())
    ):
        obj = bpy.data.objects.get(str(object_name))
        if obj is None:
            continue
        if owner_type == "OBJECT":
            owners.append(obj)
            continue
        pose = getattr(obj, "pose", None)
        pose_bone = pose.bones.get(str(bone_name)) if pose is not None else None
        if pose_bone is not None:
            owners.append(pose_bone)
    return tuple(owners)


def _dynamic_space_unparent_armatures():
    _dynamic_space_runtime_cache_current()
    return tuple(
        armature
        for name in tuple(
            _state.get("dynamic_space_runtime_unparent_armatures", ())
        )
        if (armature := bpy.data.objects.get(str(name))) is not None
        and armature.type == "ARMATURE"
    )
