"""Dynamic animation-channel grouping and name migration."""

from ..core.runtime import *  # noqa: F403

def _set_fcurve_group(fcurve, action, group_name):
    groups = _fcurve_group_collection(action, fcurve)
    if groups is None:
        return False

    current_group = getattr(fcurve, "group", None)
    if (
        current_group is not None
        and str(getattr(current_group, "name", "")) == group_name
    ):
        return False
    target_group = groups.get(group_name)
    if target_group is None:
        target_group = groups.new(group_name)
    if current_group is target_group:
        return False

    fcurve.group = target_group
    if current_group is not None:
        try:
            if not tuple(current_group.channels):
                groups.remove(current_group)
        except (AttributeError, ReferenceError, RuntimeError, ValueError):
            pass
    return True


def _set_dynamic_parent_fcurve_group(owner, constraint):
    if owner is None or constraint is None:
        return False
    action = _dynamic_parent_owner_action(owner)
    if action is None:
        return False
    data_path = _dynamic_parent_marker_data_path(constraint)
    if not data_path:
        return False
    animated_id = getattr(owner, "id_data", None) or owner
    changed = False
    for fcurve in _fcurves_find_all(action, data_path, animated_id):
        changed = _set_fcurve_group(
            fcurve,
            action,
            f"Dynamic Parent ({owner.name})",
        ) or changed
    return changed


def _migrate_dynamic_parent_marker_channel(owner, constraint):
    """Move legacy influence keys onto a non-transforming marker property."""

    if owner is None or constraint is None:
        return False
    action = _dynamic_parent_owner_action(owner)
    if action is None:
        return False
    marker_path = _dynamic_parent_marker_data_path(constraint)
    legacy_path = _dynamic_parent_marker_data_path(constraint, legacy = True)
    if not marker_path or not legacy_path:
        return False

    animated_id = getattr(owner, "id_data", None) or owner
    marker_curve = _fcurve_find(action, marker_path)
    legacy_curves = tuple(_fcurves_find_all(action, legacy_path, animated_id))
    changed = False
    if marker_curve is None and legacy_curves:
        marker_curve = _action_new_fcurve(action, marker_path, animated_id)
    if marker_curve is not None:
        owner[_dynamic_parent_marker_property_name(constraint)] = float(
            constraint.influence
        )
    for legacy_curve in legacy_curves:
        for source_key in tuple(legacy_curve.keyframe_points):
            frame = float(source_key.co.x)
            target_key = _fcurve_key_at(marker_curve, int(round(frame)))
            if target_key is None:
                target_key = marker_curve.keyframe_points.insert(
                    frame,
                    float(source_key.co.y),
                )
            else:
                target_key.co.y = float(source_key.co.y)
            for attribute in (
                "interpolation",
                "type",
                "handle_left_type",
                "handle_right_type",
                "easing",
            ):
                try:
                    setattr(target_key, attribute, getattr(source_key, attribute))
                except (AttributeError, TypeError, ValueError):
                    pass
        marker_curve.update()
        changed = _action_remove_fcurve(action, legacy_curve) or changed
    if marker_curve is not None:
        changed = _set_dynamic_parent_fcurve_group(
            owner,
            constraint,
        ) or changed
    return changed


def _set_dynamic_unparent_fcurve_group(armature, bone_name):
    if (
        armature is None
        or getattr(armature, "type", None) != "ARMATURE"
        or not bone_name
    ):
        return False
    animation_data = getattr(armature, "animation_data", None)
    action = getattr(animation_data, "action", None)
    if action is None:
        return False

    changed = False
    data_path = _unparent_dp(bone_name)
    for fcurve in _fcurves_find_all(action, data_path, armature):
        changed = _normalize_dynamic_marker_fcurve(fcurve) or changed
        changed = _set_fcurve_group(
            fcurve,
            action,
            f"Dynamic Unparent ({bone_name})",
        ) or changed
    return changed

def _fcurve_key_at(fc, frame):
    if not fc:
        return None
    for kp in fc.keyframe_points:
        if abs(float(kp.co.x) - float(frame)) <= 0.0001:
            return kp
    return None


def _migrate_dynamic_keyframe_names():
    try:
        actions = tuple(bpy.data.actions)
        objects = tuple(bpy.data.objects)
    except AttributeError:
        return False

    legacy_tokens = tuple(
        (f'["{legacy_name}"]', f'["{UNP_PROP}"]')
        for legacy_name in LEGACY_UNP_PROPS
    )

    for action in actions:
        for fcurve in tuple(_action_fcurves(action)):
            target_path = str(fcurve.data_path)
            for legacy_token, current_token in legacy_tokens:
                target_path = target_path.replace(legacy_token, current_token)
            if target_path == fcurve.data_path:
                continue

            curve_scope = tuple(_action_fcurves(action))
            if not hasattr(action, "fcurves"):
                for channelbag in _action_channelbags(action):
                    channel_curves = tuple(channelbag.fcurves)
                    if any(candidate is fcurve for candidate in channel_curves):
                        curve_scope = channel_curves
                        break

            duplicate = next(
                (
                    candidate
                    for candidate in curve_scope
                    if candidate is not fcurve
                    and candidate.data_path == target_path
                    and int(candidate.array_index) == int(fcurve.array_index)
                ),
                None,
            )
            if duplicate is None:
                try:
                    fcurve.data_path = target_path
                    fcurve.update()
                except (AttributeError, RuntimeError, TypeError, ValueError):
                    pass
                continue

            for source_key in tuple(fcurve.keyframe_points):
                frame = float(source_key.co.x)
                value = float(source_key.co.y)
                target_key = next(
                    (
                        key
                        for key in duplicate.keyframe_points
                        if abs(float(key.co.x) - frame) <= 1.0e-5
                    ),
                    None,
                )
                if target_key is None:
                    target_key = duplicate.keyframe_points.insert(frame, value)
                else:
                    target_key.co.y = value
                for attribute in (
                    "interpolation",
                    "type",
                    "handle_left_type",
                    "handle_right_type",
                ):
                    try:
                        setattr(target_key, attribute, getattr(source_key, attribute))
                    except (AttributeError, TypeError, ValueError):
                        pass
            duplicate.update()
            _action_remove_fcurve(action, fcurve)

    for obj in objects:
        for constraint in getattr(obj, "constraints", ()):
            if constraint.name.startswith("DP_"):
                _migrate_dynamic_parent_marker_channel(obj, constraint)
                _set_dynamic_parent_fcurve_group(obj, constraint)
        if obj.type != "ARMATURE" or getattr(obj, "pose", None) is None:
            continue
        for pose_bone in obj.pose.bones:
            _set_dynamic_unparent_fcurve_group(obj, pose_bone.name)
            for constraint in pose_bone.constraints:
                if constraint.name.startswith("DP_"):
                    _migrate_dynamic_parent_marker_channel(
                        pose_bone,
                        constraint,
                    )
                    _set_dynamic_parent_fcurve_group(pose_bone, constraint)
            for legacy_name in LEGACY_UNP_PROPS:
                if legacy_name not in pose_bone:
                    continue
                if UNP_PROP not in pose_bone:
                    pose_bone[UNP_PROP] = pose_bone[legacy_name]
                try:
                    del pose_bone[legacy_name]
                except (KeyError, TypeError):
                    pass
    return True


def _run_dynamic_keyframe_name_migration():
    return None if _migrate_dynamic_keyframe_names() else 0.1
