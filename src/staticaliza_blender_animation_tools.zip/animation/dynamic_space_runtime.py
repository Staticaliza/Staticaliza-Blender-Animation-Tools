"""Dynamic-space reconciliation timers, handlers, and file-load restoration."""

from ..core.runtime import *  # noqa: F403

def _unparent_apply_action_pose_channels(action, pose_bone, frame):
    if action is None or pose_bone is None:
        return False

    applied = False
    for property_name in (
        "location",
        "scale",
        "rotation_euler",
        "rotation_quaternion",
        "rotation_axis_angle",
    ):
        curves = _fcurves_find_all(
            action,
            _pose_dp(pose_bone.name, property_name),
        )
        if not curves:
            continue

        current_value = getattr(pose_bone, property_name, None)
        if current_value is None:
            continue
        values = list(current_value)
        for curve in curves:
            index = int(getattr(curve, "array_index", 0))
            if 0 <= index < len(values):
                values[index] = float(curve.evaluate(float(frame)))
                applied = True
        try:
            setattr(pose_bone, property_name, values)
        except (AttributeError, TypeError, ValueError):
            continue
    return applied


def _dynamic_space_marker_signature():
    signature = []
    for obj in tuple(bpy.data.objects):
        action = _dynamic_parent_owner_action(obj)
        if action is None:
            continue
        for fcurve in _action_fcurves(action, obj):
            data_path = str(fcurve.data_path)
            if not (
                (
                    'constraints["DP_' in data_path
                    and data_path.endswith(".influence")
                )
                or DP_MARKER_PROPERTY_PREFIX in data_path
                or data_path.endswith(f'["{UNP_PROP}"]')
                or data_path.endswith(
                    f'["{SURFACE_CONTACT_MARKER_PROPERTY}"]'
                )
            ):
                continue
            points = tuple(
                (
                    round(float(key.co.x), 6),
                    round(float(key.co.y), 6),
                    str(getattr(key, "interpolation", "")),
                    str(getattr(key, "easing", "")),
                    str(getattr(key, "handle_left_type", "")),
                    str(getattr(key, "handle_right_type", "")),
                    round(float(getattr(key, "amplitude", 0.0)), 6),
                    round(float(getattr(key, "back", 0.0)), 6),
                    round(float(getattr(key, "period", 0.0)), 6),
                )
                for key in fcurve.keyframe_points
            )
            signature.append(
                (
                    int(obj.as_pointer()),
                    data_path,
                    int(getattr(fcurve, "array_index", 0)),
                    points,
                )
            )
    return tuple(signature)


def _dynamic_space_marker_watch_timer():
    if (
        _pin_primary_mouse_pressed()
        or _window_manager_has_modal_operator(bpy.context)
        or _state.get("unparent_handler_mute", False)
        or _state.get("dynamic_space_export_sampling", False)
        or _animation_playback_active()
    ):
        return 0.25
    try:
        signature = _dynamic_space_marker_signature()
    except (AttributeError, ReferenceError, RuntimeError):
        return 0.25
    previous = _state.get("dynamic_space_marker_signature")
    _state["dynamic_space_marker_signature"] = signature
    if previous is None:
        _schedule_dynamic_space_reconcile(0.15)
    elif signature != previous:
        _schedule_dynamic_space_reconcile(
            0.01,
            immediate = _dynamic_space_marker_deletion_pending(),
        )
    return 0.25


def _run_scheduled_dynamic_space_reconcile():
    if (
        _pin_primary_mouse_pressed()
        or _window_manager_has_modal_operator(bpy.context)
        or _state.get("unparent_handler_mute", False)
        or _state.get("dynamic_space_export_sampling", False)
    ):
        return 0.05

    immediate = bool(_state.get("dynamic_space_reconcile_immediate", False))
    quiet_time = time.monotonic() - float(
        _state.get("dynamic_space_last_action_update", 0.0)
    )
    if not immediate and quiet_time < 0.45:
        return max(0.05, 0.45 - quiet_time)

    _state["dynamic_space_reconcile_pending"] = False
    _state["dynamic_space_reconcile_immediate"] = False
    context = bpy.context
    if context is None or context.scene is None:
        return None
    try:
        _reconcile_dynamic_space_markers(context)
        _state["dynamic_space_marker_signature"] = (
            _dynamic_space_marker_signature()
        )
        _state["dynamic_parent_cleanup_pending"] = False
    except Exception as exc:
        print(f"[Roblox Animator Utils] Dynamic marker sync failed: {exc}")
    return None


def _schedule_dynamic_space_reconcile(delay = 0.03, immediate = False):
    _state["dynamic_space_last_action_update"] = time.monotonic()
    if immediate:
        _state["dynamic_space_reconcile_immediate"] = True
        try:
            if bpy.app.timers.is_registered(_run_scheduled_dynamic_space_reconcile):
                bpy.app.timers.unregister(_run_scheduled_dynamic_space_reconcile)
        except (ReferenceError, RuntimeError, ValueError):
            pass
        _state["dynamic_space_reconcile_pending"] = False
    if _state.get("dynamic_space_reconcile_pending", False):
        return
    _state["dynamic_space_reconcile_pending"] = True
    register_owned_timer(
        _run_scheduled_dynamic_space_reconcile,
        first_interval = max(0.0 if immediate else 0.45, float(delay)),
    )


def _dynamic_space_marker_deletion_pending():
    if _dynamic_parent_marker_deletion_pending():
        return True
    for armature in tuple(bpy.data.objects):
        if armature.type != "ARMATURE" or getattr(armature, "pose", None) is None:
            continue
        action = armature.animation_data.action if armature.animation_data else None
        for pose_bone in armature.pose.bones:
            unparent_frames = {
                int(frame)
                for frame, _value in _unparent_points(action, pose_bone.name)
            }
            for segment in _managed_unparent_segments(pose_bone):
                if int(segment["start"]) not in unparent_frames:
                    return True
                if (
                    segment["end"] is not None
                    and int(segment["end"]) not in unparent_frames
                ):
                    return True
    return False


def _recalibrate_all_dynamic_space_boundaries(
    context,
    armature = None,
    parent_only = False,
):
    """Rebuild derived switch inverses chronologically after Action edits."""

    scene = getattr(context, "scene", None)
    if scene is None or _state.get("dynamic_space_export_sampling", False):
        return False
    armatures = (
        (armature,)
        if armature is not None
        else tuple(
            obj
            for obj in bpy.data.objects
            if obj.type == "ARMATURE" and getattr(obj, "pose", None) is not None
        )
    )
    boundaries_by_armature = []
    for current_armature in armatures:
        if current_armature is None or getattr(current_armature, "pose", None) is None:
            continue
        boundaries = {
            int(start)
            for pose_bone in current_armature.pose.bones
            for constraint in pose_bone.constraints
            if _is_dynamic_state_constraint(constraint)
            and (
                not parent_only
                or constraint.name.startswith("DP_")
                or _dynamic_space_source(
                    pose_bone,
                    constraint,
                ).startswith(SPACE_SOURCE_DYNAMIC_PARENT_PREFIX)
            )
            for start, _end in (
                _dynamic_parent_constraint_segment(pose_bone, constraint),
            )
            if start is not None and int(start) > SPACE_MIN_FRAME
        }
        if boundaries:
            boundaries_by_armature.append(
                (current_armature, tuple(sorted(boundaries)))
            )
    if not boundaries_by_armature:
        return False

    saved_frame = int(scene.frame_current)
    saved_subframe = float(getattr(scene, "frame_subframe", 0.0))
    previous_mute = bool(_state.get("unparent_handler_mute", False))
    changed = False
    _state["unparent_handler_mute"] = True
    try:
        for current_armature, boundaries in boundaries_by_armature:
            for boundary in boundaries:
                scene.frame_set(int(boundary))
                _sync_dynamic_parent_constraints(boundary, current_armature)
                context.view_layer.update()
                changed = _calibrate_dynamic_space_boundaries(
                    context,
                    boundary,
                    current_armature,
                ) or changed
    finally:
        scene.frame_set(saved_frame, subframe = saved_subframe)
        _sync_dynamic_parent_constraints(saved_frame, armature)
        context.view_layer.update()
        _state["unparent_handler_mute"] = previous_mute
    return changed



@persistent
def _dynamic_space_depsgraph_update(_scene, depsgraph):
    if (
        _state.get("unparent_handler_mute", False)
        or _state.get("dynamic_space_reconciling", False)
        or _state.get("dynamic_space_depsgraph_syncing", False)
        or _state.get("dynamic_space_export_sampling", False)
    ):
        return
    action_updated = False
    for update in depsgraph.updates:
        updated_id = getattr(update, "id", None)
        if isinstance(updated_id, bpy.types.Action):
            action_updated = True

    if action_updated:
        current_signature = _dynamic_space_marker_signature()
        previous_signature = _state.get("dynamic_space_marker_signature")
        markers_changed = bool(
            previous_signature is not None
            and current_signature != previous_signature
        )
        current_transform_signature = _dynamic_parent_animation_signature()
        previous_transform_signature = _state.get(
            "dynamic_parent_animation_signature"
        )
        transforms_changed = bool(
            previous_transform_signature is not None
            and current_transform_signature != previous_transform_signature
        )
        parent_start_deleted = _hold_dynamic_parent_start_deletions(_scene)
        parent_marker_deleted = bool(
            parent_start_deleted
            or _dynamic_parent_marker_deletion_pending()
        )
        marker_deleted = bool(
            parent_marker_deleted
            or _dynamic_space_marker_deletion_pending()
        )

        # Ordinary pose-key edits do not need structural marker work. Refresh
        # Parent boundary inverses directly so a later target/child key cannot
        # invalidate the attachment offset at Start or End.
        if transforms_changed and not markers_changed:
            _schedule_dynamic_parent_boundary_refresh()

        # Dropping a marker must stop affecting the rig on the same
        # depsgraph pass. Full structural removal stays in the deferred
        # reconciler, but active constraint selection is safe and cheap.
        # For Parent Start deletion, switching to the fallback helper before
        # teardown creates a one-tick wrong pose. Keep the current constraint
        # stable until the zero-delay structural cleanup completes.
        if not parent_marker_deleted:
            _state["dynamic_space_depsgraph_syncing"] = True
            try:
                frame = int(getattr(_scene, "frame_current", 0))
                _sync_dynamic_parent_constraints(frame)
            finally:
                _state["dynamic_space_depsgraph_syncing"] = False
        else:
            _state["dynamic_parent_cleanup_pending"] = True
        if markers_changed or marker_deleted:
            _schedule_dynamic_space_reconcile(
                0.0,
                immediate = marker_deleted,
            )


@persistent
def _dynamic_space_undo_post(*_):
    """Immediately reconcile marker-owned state after Undo or Redo."""

    context = bpy.context
    if context is None or context.scene is None:
        return
    try:
        # Let Blender retire any constraint/F-Curve wrappers restored or
        # removed by history before structural reconciliation inspects them.
        context.view_layer.update()
        _reconcile_dynamic_space_markers(context)
        _dynamic_parent_restore_native_history_transition(context)
        _dynamic_parent_restore_history_followers(context)
        _state["dynamic_space_marker_signature"] = (
            _dynamic_space_marker_signature()
        )
        _state["dynamic_parent_cleanup_pending"] = False
    except (AttributeError, ReferenceError, RuntimeError):
        _schedule_dynamic_space_reconcile(0.0)


@persistent
def _dynamic_space_frame_change_pre(scene, _depsgraph):
    if _state.get("unparent_handler_mute", False) or scene is None:
        return
    if (
        _state.get("dynamic_parent_cleanup_pending", False)
        or _dynamic_parent_marker_deletion_pending()
    ):
        _hold_dynamic_parent_start_deletions(scene)
        _state["dynamic_parent_cleanup_pending"] = True
        _schedule_dynamic_space_reconcile(0.0, immediate = True)
    # Do not switch active dynamic-space constraints here. During an
    # interactive timeline scrub Blender can evaluate the requested frame
    # before dependency changes made by frame_change_pre settle. The post
    # handler performs the switch and a synchronous view-layer update, so the
    # frame displayed under the mouse is the fully evaluated final pose.


@persistent
def _dynamic_parent_playback_pre(_scene, _depsgraph = None):
    """Rebuild dynamic-space inverses before the first playback frame."""

    if _state.get("unparent_handler_mute", False):
        return
    if _state.get("dynamic_parent_boundary_refresh_pending", False):
        _flush_dynamic_parent_boundary_refresh(bpy.context)
    else:
        _recalibrate_all_dynamic_space_boundaries(
            bpy.context,
            parent_only = False,
        )
        _store_dynamic_parent_animation_signature()


@persistent
def _unparent_frame_change_post(scene, depsgraph):
    if _state.get("unparent_handler_mute", False):
        return

    context = bpy.context
    if not context or not context.scene:
        return

    if _state.get("dynamic_parent_cleanup_pending", False):
        _schedule_dynamic_space_reconcile(0.0, immediate = True)
        return
    if _state.get("dynamic_parent_boundary_refresh_pending", False):
        # Scrubbing can begin before the short refresh timer is serviced.
        # Rebuild only after Blender has evaluated the requested cursor frame;
        # doing this in frame_change_pre samples stale pose/action data.
        _flush_dynamic_parent_boundary_refresh(context)
        context.view_layer.update()
    elif not _animation_playback_active():
        if _refresh_dynamic_parent_for_scrub(context):
            context.view_layer.update()

    f = int(context.scene.frame_current)
    dynamic_parent_changed = _sync_dynamic_parent_constraints(f)
    if dynamic_parent_changed:
        context.view_layer.update()

    export_armature = _state.get("unparent_export_armature")
    if export_armature and getattr(export_armature, "type", None) == "ARMATURE":
        armatures = (export_armature,)
    else:
        armatures = tuple(
            obj
            for obj in bpy.data.objects
            if obj.type == "ARMATURE" and getattr(obj, "pose", None) is not None
        )

    changed = dynamic_parent_changed
    for arm in armatures:
        action = arm.animation_data.action if arm.animation_data else None
        if not action:
            for pose_bone in arm.pose.bones:
                if _pose_space_managed(pose_bone):
                    _ensure_pose_space_system(
                        context,
                        arm,
                        pose_bone,
                        f,
                    )
                _unparent_remove_visual_constraint(pose_bone)
            continue

        _unparent_cleanup_orphans(context, arm, action)
        for name in _unparent_rel_scan_arm(arm):
            pose_bone = arm.pose.bones.get(name)
            if pose_bone is None:
                continue

            if _pose_space_managed(pose_bone):
                pose_bone = _ensure_pose_space_system(
                    context,
                    arm,
                    pose_bone,
                    f,
                )
                if pose_bone is None:
                    continue
                if _unparent_has_marker_keys(action, name):
                    _pb_prop_set(
                        pose_bone,
                        UNP_PROP,
                        _unparent_eval(action, name, f, 0.0),
                    )
                elif UNP_PROP in pose_bone:
                    del pose_bone[UNP_PROP]
                _unparent_remove_visual_constraint(pose_bone)
                _unparent_rel_set_cached(arm.name, name, True)
                continue

            want_detached = _unparent_eval(
                action,
                name,
                f,
                pb_default = _pb_prop_get(pose_bone, UNP_PROP, 0.0),
            ) >= 0.5
            have_detached = _unparent_relation_is_detached(pose_bone)

            if want_detached:
                _unparent_ensure_visual_constraint(arm, pose_bone)
            else:
                _unparent_remove_visual_constraint(pose_bone)

            if bool(want_detached) == bool(have_detached):
                continue

            if _unparent_switch_preserve_pose(
                context,
                arm,
                pose_bone,
                bool(want_detached),
            ):
                _unparent_rel_set_cached(arm.name, name, bool(want_detached))
                current_bone = arm.pose.bones.get(name)
                _unparent_apply_action_pose_channels(action, current_bone, f)
                changed = True
                context.view_layer.update()

    if changed:
        try:
            bpy.context.view_layer.update()
        except (AttributeError, RuntimeError):
            pass
        _tag_redraw_all_view3d()

@persistent
def _load_pre(*_):
    """Block contact evaluation until Blender finishes restoring the file."""
    _state["surface_contact_load_restoring"] = True


@persistent
def _load_post(*_):

    _state["surface_contact_load_restoring"] = True
    _state["yellow_fixed"] = {}
    _state["yellow_modes"] = {}
    _state["yellow_hidden"] = set()
    _state["onion_enabled_owners"] = set()
    _state["onion_property_syncing"] = False
    _state["persistent_runtime_restored"] = False
    _state["persistent_pose_scope_signature"] = ()
    _state["mesh_batches"] = {}
    _state["raycast_fixed"] = {}
    _state["unparent_rel_cache"] = {}
    _state["unparent_handler_mute"] = False
    _state["dynamic_space_reconciling"] = False
    _state["dynamic_space_reconcile_pending"] = False
    _state["dynamic_space_reconcile_immediate"] = False
    _state["dynamic_space_depsgraph_syncing"] = False
    _state["dynamic_space_calibrating"] = False
    _state["dynamic_space_export_sampling"] = False
    _state["dynamic_space_last_action_update"] = 0.0
    _state["dynamic_space_marker_signature"] = None
    _state["dynamic_parent_boundary_refresh_pending"] = False
    _state["dynamic_parent_boundary_refresh_last_update"] = 0.0
    _state["dynamic_parent_animation_signature"] = None
    _state["dynamic_parent_cleanup_pending"] = False
    _state["dynamic_parent_dual_selection_locks"] = {}
    _state["dynamic_parent_dual_selection_translate_sessions"] = {}
    _state["dynamic_parent_indirect_parent_baselines"] = {}
    _state["dynamic_parent_indirect_visual_commits"] = {}
    _state["dynamic_parent_native_history_transition"] = None
    _state["dynamic_parent_native_history_expected_index"] = None
    _state["dynamic_parent_history_snapshot"] = ()
    _state["dynamic_parent_dual_selection_save_paused"] = False
    _state["unparent_export_armature"] = None
    _state["smart_material_scan_pending"] = False
    _state["roblox_compatibility_scan_pending"] = False
    _state["roblox_armature_list_signature"] = None
    _state["armature_overlay_saved"] = {}
    _state["part_pivot_syncing"] = False
    _state["part_pivot_armature"] = 0
    _state["part_pivot_bone"] = ""
    _state["part_pivot_last_armature"] = 0
    _state["part_pivot_last_bone"] = ""
    _state["part_pivot_object"] = ""
    _state["part_pivot_object_local"] = None
    _state["part_pivot_objects"] = ()
    _state["part_pivot_selection_signature"] = ()
    _state["part_pivot_saved"] = None
    _state["part_pivot_last_signature"] = None
    _state["part_pivot_cursor_visibility"] = {}
    _state["camera_view_spaces"] = {}
    _state["free_view_master"] = None
    _state["free_view_space_states"] = {}
    _state["free_view_settings_master"] = None
    _state["free_view_setting_states"] = {}
    _state["view3d_n_panel_master"] = None
    _state["view3d_n_panel_states"] = {}
    _state["view3d_n_panel_window_screens"] = {}
    _state["animation_editor_pose_states"] = {}
    _state["animation_editor_sync_signature"] = None
    _state["animation_editor_sync_time"] = 0.0
    _state["animation_channel_maintenance_last_time"] = 0.0
    _state["special_action_order_attempts"] = {}
    _state["free_view_syncing"] = False
    _state["pose_mode_pending_rigs"] = set()
    _state["pose_mode_pending_attempts"] = 0
    _state["bone_label_selection_signature"] = None
    _state["pose_hidden_armatures"] = {}
    _state["pose_visibility_resume_after_save"] = False
    _state["rig_hover_mouse"] = {}
    _state["rig_hover_redraw_times"] = {}
    _state["rig_hover_targets"] = {}
    _state["rig_hover_poll_time"] = 0.0
    _state["surface_contact_syncing"] = False
    _state["surface_contact_reconciling"] = False
    _state["surface_contact_solver_syncing"] = False
    _state["surface_contact_creation_active"] = False
    _state["surface_contact_valid_poses"] = {}
    _state["surface_contact_owner_pose_bases"] = {}
    _state["surface_contact_transform_signatures"] = {}
    _state["surface_contact_guide_cache"] = ()
    _state["surface_contact_guide_cache_object_count"] = -1
    _state["surface_contact_rotation_axes"] = {}
    _state["surface_contact_smart_aim_branches"] = {}
    _state["surface_contact_roll_frames"] = {}
    _state["surface_contact_collision_tangents"] = {}
    _state["surface_contact_last_frames"] = {
        int(scene.as_pointer()): int(scene.frame_current)
        for scene in tuple(getattr(bpy.data, "scenes", ()))
    }
    _state["pin_target_dragging"] = False
    _state["pin_snap_transform_active"] = False
    _state["pin_snap_transform_initializing"] = False
    _state["pin_snap_transform_operator"] = ""
    _state["pin_snap_transform_start_poses"] = {}
    _state["pin_snap_transform_changed"] = False
    _state["pin_snap_transform_delta_supported"] = False
    _state["pin_snap_transform_delta_observed"] = False
    _state["pin_snap_transform_last_delta_signature"] = None
    _state["pin_snap_contact_target_locks"] = {}
    _state["pin_snap_parent_transform_guides"] = set()
    _state["pin_snap_parent_attachment_states"] = {}
    _state["pin_snap_syncing"] = False
    _state["pin_snap_latches"] = set()
    _state["pin_snap_departing"] = set()
    _state["pin_snap_detached"] = set()
    _state["pin_snap_transform_seen"] = set()
    _state["pin_snap_last_depsgraph_sync"] = 0.0
    _state["pin_snap_transform_dirty"] = False
    _state["pin_snap_live_pose_matrices"] = {}
    _state["pin_snap_contact_transform_start_poses"] = {}
    _state["pin_snap_native_history_transition"] = None
    _state["pin_snap_native_history_pre_selected"] = {}
    _state["pin_snap_initial_latches"] = set()
    _state["pin_snap_transform_engaged"] = set()
    _state["pin_snap_engage_translate_origins"] = {}
    _state["pin_snap_transform_releasing"] = set()
    _state["pin_snap_release_reentry_armed"] = set()
    _state["pin_snap_pressure_tangents"] = {}
    _state["pin_snap_pressure_active"] = set()
    _state["pin_snap_transform_finalize_pending"] = None
    _state["pin_gizmo_axes_visible"] = {}
    _state["pin_gizmo_selection_keys"] = ()
    _state["pin_gizmo_selected_key"] = ""
    _state["pin_gizmo_selected_keys"] = set()
    _state["pin_gizmo_selected_keys_active"] = ""
    _state["pin_gizmo_pending_click"] = None
    _state["pin_gizmo_selection_epoch"] = 0
    _state["pin_gizmo_claim_serial"] = 0
    _state["pin_gizmo_last_claim"] = None
    _state["pin_gizmo_extend_selection_until"] = 0.0
    _state["pin_gizmo_deferred_finishes"] = []
    _state["pin_keyboard_transform_active"] = False
    _state["pin_transform_from_gizmo"] = False
    _state["pin_yellow_history_fallbacks"] = {}
    _state["pin_history_active"] = False
    _state["pin_history_contact_pose_lock"] = ()
    _state["pin_history_pose_lock_syncing"] = False
    _state["pin_history_pose_release_pending"] = False
    _state["pin_history_pose_release_frame"] = None
    _state["pin_history_pose_release_deadline"] = 0.0
    _state["pin_history_pose_release_last_event"] = 0.0
    _state["pin_history_pose_release_observed"] = False
    _state["pin_history_contact_snapshot"] = None
    _state["pin_history_syncing"] = False
    _state["pin_clipboard"] = None
    _state["last_error"] = ""
    _state["roblox_animation_loop_modes"] = {}
    _state["roblox_animation_playback_frame"] = 0
    _state["surface_contact_solver_syncing"] = True
    try:
        _surface_contact_store_persistent_pose_snapshots(
            only_missing = True,
        )
        bpy.context.view_layer.update()
        _surface_contact_restore_snap_detached(bpy.context)
        _surface_contact_seed_valid_poses()
        _surface_contact_seed_runtime_signatures(bpy.context)
    except (AttributeError, RuntimeError):
        pass
    finally:
        _state["surface_contact_solver_syncing"] = False
    _set_default_keyframe_handle_type()
    _migrate_dynamic_keyframe_names()
    _capture_animation_channel_baseline()
    window_manager = getattr(bpy.context, "window_manager", None)
    _set_onion_property(window_manager, False)
    if window_manager is not None and hasattr(
        window_manager,
        "staticaliza_pivot_mode",
    ):
        window_manager.staticaliza_pivot_mode = "BONE"
    _yellow_refresh_runtime(bpy.context)
    _state["smart_material_processed_rigs"] = set()
    _capture_material_import_baseline()
    _state["roblox_constraints_normalized"] = set()
    _state["roblox_constraints_new_rigs"] = set()
    _smart_material_import_scan(bpy.context.scene)
    _apply_roblox_compatibility(bpy.context.scene)
    _refresh_roblox_armature_list(bpy.context, force = True)
    _sync_view3d_relationship_lines(bpy.context)
    _sync_all_attached_camera_object_visibility()
    _unparent_frame_change_post(bpy.context.scene, None)
    # Preserve the exact keyed contact pose on reopen or extension reload.
    # Only rebuild contact metadata/influences; solving or reapplying dynamic
    # parenting here would mutate the pose after Blender evaluated its keys.
    _sync_surface_contact_constraints(
        bpy.context.scene,
        solve_simulated = False,
        solve_guides = False,
        sync_dynamic_parent = False,
    )
    # Blender's evaluated pose owns file load and extension reload. Seed
    # legacy files that lack a snapshot without replaying an older pink pose.
    _surface_contact_store_persistent_pose_snapshots(only_missing=True)
    for scene in tuple(bpy.data.scenes):
        _sync_roblox_animation_loop_mode(scene)
    _schedule_persistent_runtime_restore(0.1)
    _unregister_addon_keymaps()
    if not _register_addon_keymaps():
        register_owned_timer(
            _register_addon_keymaps_timer,
            first_interval = 0.05,
        )
    _state["surface_contact_registration_guard_until"] = (
        time.perf_counter() + 0.75
    )
    _state["surface_contact_load_restoring"] = False
