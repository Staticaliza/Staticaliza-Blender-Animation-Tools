"""Dynamic-unparent toggle, clear, marker removal, and orphan cleanup operations."""

from ..core.runtime import *  # noqa: F403

def _unparent_toggle(context, arm, pb, frame):
    action = _ensure_object_action(arm)
    f = int(frame)
    saved_parent_name = str(pb.bone.get(REL_K_PARENT, ""))
    if pb.parent is None and not saved_parent_name:
        return False
    desired_output = _pose_space_output_matrix(context, arm, pb)
    pb = _ensure_pose_space_system(
        context,
        arm,
        pb,
        f,
    )
    if pb is None:
        return False

    v_now = _unparent_eval(
        action,
        pb.name,
        f,
        pb_default = _pb_prop_get(pb, UNP_PROP, 0.0),
    )
    in_window = float(v_now) >= 0.5
    desired_factor = desired_output @ _pose_space_input_matrix(
        pb
    ).inverted_safe()
    active_start = _unparent_find_active_start_frame(action, pb.name, f)
    if in_window and active_start is None:
        return False

    existing_end = (
        _unparent_find_end_frame(action, pb.name, int(active_start))
        if in_window and active_start is not None
        else None
    )
    if existing_end is not None and f + 1 < int(existing_end):
        return _split_pose_unparent_segment(
            context,
            arm,
            pb,
            action,
            int(active_start),
            f,
            int(existing_end),
            desired_factor,
        )

    fc_prop = _ddm_ensure_fcurve(action, _unparent_dp(pb.name), arm)
    next_value = 0.0 if in_window else 1.0
    _pb_prop_set(pb, UNP_PROP, next_value)
    _ddm_insert_key(fc_prop, f, next_value)
    _set_dynamic_unparent_fcurve_group(arm, pb.name)
    if existing_end is not None and f < int(existing_end):
        _fcurve_remove_key_all(
            action,
            _unparent_dp(pb.name),
            int(existing_end),
        )
        _remove_future_space_constraints(
            pb,
            _space_constraint_source_for_unparent(active_start),
            f,
        )
    fc_prop.update()

    source_start = int(active_start) if in_window else f
    parent_name = str(pb.bone.get(REL_K_PARENT, ""))
    role = (
        SPACE_ROLE_UNPARENT
        if not in_window
        else (SPACE_ROLE_NORMAL if parent_name else SPACE_ROLE_WORLD)
    )
    constraint = _switch_pose_underlying_space(
        context,
        arm,
        pb,
        role,
        f,
        desired_factor,
        _space_constraint_source_for_unparent(source_start),
    )
    if constraint is None:
        return False

    context.scene.frame_set(f)
    _sync_dynamic_parent_constraints(f, arm)
    context.view_layer.update()
    _store_dynamic_parent_animation_signature()
    return True


def _unparent_delete_segment_markers(action, bone_name, start_frame, end_frame = None):
    if action is None:
        return False
    start_frame = int(start_frame)
    end_frame = int(end_frame) if end_frame is not None else None
    removed = False
    data_path = _unparent_dp(bone_name)
    for fcurve in list(_fcurves_find_all(action, data_path)):
        points = {
            int(round(float(key.co.x))): float(key.co.y)
            for key in fcurve.keyframe_points
        }
        frames_to_remove = {start_frame}
        if end_frame is not None:
            frames_to_remove.add(end_frame)
            legacy_end_hold = end_frame - 1
            if legacy_end_hold != start_frame and points.get(legacy_end_hold, 0.0) > 0.5:
                frames_to_remove.add(legacy_end_hold)
        legacy_start_hold = start_frame - 1
        if points.get(legacy_start_hold, 1.0) < 0.5:
            frames_to_remove.add(legacy_start_hold)

        remove_indices = []
        for index, key in enumerate(fcurve.keyframe_points):
            key_frame = int(round(float(key.co.x)))
            if key_frame not in frames_to_remove:
                continue
            key_value = float(key.co.y)
            if (
                key_frame == start_frame
                and key_value >= UNP_SPLIT_VALUE - 0.5
            ):
                key.co.y = 0.0
                key.interpolation = "CONSTANT"
                removed = True
                continue
            if (
                end_frame is not None
                and key_frame == end_frame
                and key_value >= UNP_SPLIT_VALUE - 0.5
            ):
                key.co.y = 1.0
                key.interpolation = "CONSTANT"
                removed = True
                continue
            remove_indices.append(index)
        for index in reversed(remove_indices):
            fcurve.keyframe_points.remove(fcurve.keyframe_points[index])
            removed = True
        if not fcurve.keyframe_points:
            _action_remove_fcurve(action, fcurve)
        else:
            fcurve.update()
    return removed


def _clear_pose_space_unparent_segment(
    context,
    arm,
    pb,
    start_frame,
    end_frame,
):
    source = _space_constraint_source_for_unparent(start_frame)
    if not _space_constraints_with_source(pb, source):
        return None
    removed_space = _remove_pose_space_source(pb, source)

    action = arm.animation_data.action if arm.animation_data else None
    removed = _unparent_delete_segment_markers(
        action,
        pb.name,
        int(start_frame),
        int(end_frame) if end_frame is not None else None,
    )

    has_markers = _unparent_has_marker_keys(action, pb.name)
    if has_markers:
        _pb_prop_set(
            pb,
            UNP_PROP,
            _unparent_eval(
                action,
                pb.name,
                int(context.scene.frame_current),
                0.0,
            ),
        )
    elif UNP_PROP in pb:
        del pb[UNP_PROP]
    _unparent_remove_visual_constraint(pb)
    _unparent_clear_start_frame(pb)
    has_dynamic_parent = any(
        constraint.name.startswith("DP_")
        for constraint in pb.constraints
    )
    if not has_markers and not has_dynamic_parent:
        _teardown_pose_space_system(context, arm, pb)
    _sync_dynamic_parent_constraints(int(context.scene.frame_current), arm)
    context.view_layer.update()
    return bool(removed or removed_space)


def _unparent_clear_segment(context, arm, pb, start_frame, end_frame = None):
    action = arm.animation_data.action if arm.animation_data else None
    if action is None or pb is None:
        return False

    start_frame = int(start_frame)
    if end_frame is None:
        end_frame = _unparent_find_end_frame(action, pb.name, start_frame)
    end_frame = int(end_frame) if end_frame is not None else None

    space_result = _clear_pose_space_unparent_segment(
        context,
        arm,
        pb,
        start_frame,
        end_frame,
    )
    if space_result is not None:
        return space_result

    captured = _capture_pose_world_matrices_with_arm_mw(
        context,
        arm,
        pb.name,
        _transition_key_frames(
            action,
            pb.name,
            start_frame,
            end_exclusive = end_frame,
        ),
    )

    removed = _unparent_delete_segment_markers(
        action,
        pb.name,
        start_frame,
        end_frame,
    )

    current_frame = int(context.scene.frame_current)
    has_markers = _unparent_has_marker_keys(action, pb.name)
    current_bone = arm.pose.bones.get(pb.name)
    if current_bone is not None:
        _pb_prop_set(
            current_bone,
            UNP_PROP,
            _unparent_eval(action, pb.name, current_frame, 0.0)
            if has_markers
            else 0.0,
        )
    restored = _restore_pose_world_span(context, arm, pb.name, captured)
    current_bone = arm.pose.bones.get(pb.name)
    if current_bone is not None:
        if has_markers:
            _pb_prop_set(
                current_bone,
                UNP_PROP,
                _unparent_eval(action, pb.name, current_frame, 0.0),
            )
        else:
            _unparent_remove_visual_constraint(current_bone)
            if UNP_PROP in current_bone:
                del current_bone[UNP_PROP]
            _unparent_clear_start_frame(current_bone)
    return removed and (restored or bool(captured))


def _unparent_remove_end_marker(context, arm, pb, start_frame, end_frame):
    action = arm.animation_data.action if arm.animation_data else None
    if action is None or pb is None:
        return False

    start_frame = int(start_frame)
    end_frame = int(end_frame)
    captured = _capture_pose_world_matrices_with_arm_mw(
        context,
        arm,
        pb.name,
        _transition_key_frames(action, pb.name, end_frame),
    )

    data_path = _unparent_dp(pb.name)
    removed = False
    for fcurve in list(_fcurves_find_all(action, data_path)):
        remove_indices = []
        for index, key in enumerate(fcurve.keyframe_points):
            key_frame = int(round(float(key.co.x)))
            is_end = key_frame == end_frame
            is_legacy_hold = (
                key_frame == end_frame - 1
                and key_frame != start_frame
                and float(key.co.y) > 0.5
            )
            if is_end or is_legacy_hold:
                remove_indices.append(index)
        for index in reversed(remove_indices):
            fcurve.keyframe_points.remove(fcurve.keyframe_points[index])
            removed = True
        if not fcurve.keyframe_points:
            _action_remove_fcurve(action, fcurve)
        else:
            fcurve.update()

    if removed:
        _restore_pose_world_span(context, arm, pb.name, captured)
        current_bone = arm.pose.bones.get(pb.name)
        if current_bone is not None:
            _pb_prop_set(
                current_bone,
                UNP_PROP,
                _unparent_eval(
                    action,
                    pb.name,
                    int(context.scene.frame_current),
                    0.0,
                ),
            )
    return removed

def _unparent_cleanup_orphans(context, arm, action):
    for pb in arm.pose.bones:
        if _pose_space_managed(pb):
            _unparent_remove_visual_constraint(pb)
            continue
        has_vis = bool(pb.constraints.get(UNP_VIS_CONSTRAINT))
        has_prop = (UNP_PROP in pb)

        if (not has_vis) and (not has_prop) and (not _unparent_relation_is_detached(pb)):
            continue

        if action and _unparent_has_marker_keys(action, pb.name):
            continue

        saved_parent_name = str(pb.bone.get(REL_K_PARENT, ""))
        if saved_parent_name and (pb.parent is None):
            _unparent_switch_preserve_pose(context, arm, pb, False)

        _unparent_remove_visual_constraint(pb)

        if UNP_PROP in pb:
            try:
                del pb[UNP_PROP]
            except Exception:
                pass

        _unparent_rel_set_cached(arm.name, pb.name, False)
        _unparent_clear_start_frame(pb)
