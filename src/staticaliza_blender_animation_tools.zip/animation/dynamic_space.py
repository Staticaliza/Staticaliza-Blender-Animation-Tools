"""Managed dynamic-space helpers, constraints, switching, and teardown."""

from ..core.runtime import *  # noqa: F403

def _matrices_nearly_equal(first, second, tolerance = 1.0e-6):
    return all(
        abs(float(first[row][column]) - float(second[row][column])) <= tolerance
        for row in range(4)
        for column in range(4)
    )


def _calibrate_pose_dynamic_boundary(context, armature, pose_bone, frame):
    if pose_bone is None or int(frame) <= SPACE_MIN_FRAME:
        return False

    incoming = _chosen_dynamic_parent_constraint(pose_bone, int(frame))
    outgoing = _chosen_dynamic_parent_constraint(pose_bone, int(frame) - 1)
    if incoming is None or outgoing is None or incoming == outgoing:
        return False

    incoming_start, _incoming_end = _dynamic_parent_constraint_segment(
        pose_bone,
        incoming,
    )

    outgoing_target = _dynamic_parent_constraint_target(pose_bone, outgoing)
    incoming_target = _dynamic_parent_constraint_target(pose_bone, incoming)
    if outgoing_target is None or incoming_target is None:
        return False

    incoming_target_matrix = _pose_space_target_matrix(
        context,
        armature,
        incoming_target,
        _dynamic_parent_constraint_subtarget(pose_bone, incoming),
    )
    outgoing_target_matrix = _pose_space_target_matrix(
        context,
        armature,
        outgoing_target,
        _dynamic_parent_constraint_subtarget(pose_bone, outgoing),
    )
    desired_factor = outgoing_target_matrix @ outgoing.inverse_matrix
    inverse_matrix = incoming_target_matrix.inverted_safe() @ desired_factor
    changed = not _matrices_nearly_equal(
        incoming.inverse_matrix,
        inverse_matrix,
    )
    if changed:
        incoming.inverse_matrix = inverse_matrix
    _mark_dynamic_parent_boundary_calibrated(
        pose_bone,
        incoming,
        incoming_start,
    )
    return changed


def _calibrate_dynamic_space_boundaries(context, frame, armature = None):
    scene = getattr(context, "scene", None)
    if (
        _state.get("dynamic_space_calibrating", False)
        or _state.get("dynamic_space_export_sampling", False)
        or abs(float(getattr(scene, "frame_subframe", 0.0))) > 1.0e-7
    ):
        return False

    _state["dynamic_space_calibrating"] = True
    changed = False
    try:
        armatures = (
            (armature,)
            if armature is not None
            else tuple(
                obj
                for obj in bpy.data.objects
                if obj.type == "ARMATURE" and getattr(obj, "pose", None) is not None
            )
        )
        for current_armature in armatures:
            if current_armature is None or getattr(current_armature, "pose", None) is None:
                continue
            pose_bones = tuple(
                pose_bone
                for pose_bone in current_armature.pose.bones
                if any(
                    _is_dynamic_state_constraint(constraint)
                    for constraint in pose_bone.constraints
                )
            )
            for _pass in range(3):
                pass_changed = False
                for pose_bone in pose_bones:
                    bone_changed = _calibrate_pose_dynamic_boundary(
                        context,
                        current_armature,
                        pose_bone,
                        int(frame),
                    )
                    pass_changed = bone_changed or pass_changed
                    if bone_changed:
                        context.view_layer.update()
                changed = pass_changed or changed
                if not pass_changed:
                    break
        return changed
    finally:
        _state["dynamic_space_calibrating"] = False


def _sync_dynamic_parent_constraints(frame, armature = None):
    changed = False
    objects = (armature,) if armature is not None else tuple(bpy.data.objects)
    for obj in objects:
        if obj is None:
            continue
        changed = _sync_dynamic_parent_owner(obj, frame) or changed
        if obj.type != "ARMATURE" or getattr(obj, "pose", None) is None:
            continue
        for pose_bone in obj.pose.bones:
            changed = _sync_dynamic_parent_owner(pose_bone, frame) or changed
    return changed


def _internal_space_constraints(owner):
    return tuple(

        constraint
        for constraint in getattr(owner, "constraints", ())
        if constraint.name.startswith(SPACE_CONSTRAINT_PREFIX)
    )


def _pose_space_managed(pose_bone):
    return bool(pose_bone and _internal_space_constraints(pose_bone))


def _pose_space_input_matrix(pose_bone):
    return pose_bone.bone.matrix_local @ pose_bone.matrix_basis


def _pose_space_output_matrix(context, armature, pose_bone):
    context.view_layer.update()
    try:
        evaluated_armature = armature.evaluated_get(
            context.evaluated_depsgraph_get()
        )
        evaluated_bone = evaluated_armature.pose.bones.get(pose_bone.name)
        if evaluated_bone is not None:
            return evaluated_bone.matrix.copy()
    except (AttributeError, ReferenceError, RuntimeError):
        pass
    return pose_bone.matrix.copy()


def _pose_space_factor(context, armature, pose_bone):
    output_matrix = _pose_space_output_matrix(
        context,
        armature,
        pose_bone,
    )
    return output_matrix @ _pose_space_input_matrix(pose_bone).inverted_safe()


def _pose_space_target_matrix(context, armature, target, subtarget = ""):
    if target is None:
        return Matrix.Identity(4)

    context.view_layer.update()
    depsgraph = context.evaluated_depsgraph_get()
    evaluated_armature = armature.evaluated_get(depsgraph)
    evaluated_target = target.evaluated_get(depsgraph)
    target_world = evaluated_target.matrix_world.copy()
    if evaluated_target.type == "ARMATURE" and subtarget:
        target_bone = evaluated_target.pose.bones.get(subtarget)
        if target_bone is None:
            raise ValueError(f'Bone "{subtarget}" is not available on the target rig.')
        target_world = target_world @ target_bone.matrix
    return evaluated_armature.matrix_world.inverted_safe() @ target_world


def _ensure_space_helper_collection(context, armature = None):
    owner_uid = _armature_session_uid(armature) if armature is not None else 0
    collection = next(
        (
            candidate
            for candidate in bpy.data.collections
            if int(candidate.get(SPACE_HELPER_OWNER_UID_PROPERTY, 0) or 0)
            == int(owner_uid)
            and owner_uid
        ),
        None,
    )
    if collection is None:
        collection = bpy.data.collections.new(SPACE_HELPER_COLLECTION)
        if owner_uid:
            collection[SPACE_HELPER_OWNER_UID_PROPERTY] = int(owner_uid)

    parent_collection = None
    if armature is not None:
        try:
            bundle = _rig_delete_bundle(armature)
            parent_collection = bundle["master"] if bundle is not None else None
        except (AttributeError, KeyError, ReferenceError, RuntimeError):
            parent_collection = None
    if parent_collection is None:
        parent_collection = context.scene.collection

    if not any(child == collection for child in parent_collection.children):
        try:
            parent_collection.children.link(collection)
        except RuntimeError:
            pass
    # Keep helper collections nested only under their owning rig instead of
    # exposing one global collection beside every imported RIG collection.
    for scene in bpy.data.scenes:
        if scene.collection == parent_collection:
            continue
        try:
            if any(child == collection for child in scene.collection.children):
                scene.collection.children.unlink(collection)
        except (ReferenceError, RuntimeError):
            pass
    for candidate_parent in bpy.data.collections:
        if candidate_parent == parent_collection:
            continue
        try:
            if any(child == collection for child in candidate_parent.children):
                candidate_parent.children.unlink(collection)
        except (ReferenceError, RuntimeError):
            pass
    collection.hide_render = True
    try:
        collection.hide_select = True
    except AttributeError:
        pass
    return collection


def _helper_object_armature(helper):
    if helper is None:
        return None
    if bool(helper.get(SPACE_HELPER_PROPERTY, False)):
        parent = getattr(helper, "parent", None)
        return parent if getattr(parent, "type", "") == "ARMATURE" else None
    if bool(helper.get(SURFACE_CONTACT_GUIDE_PROPERTY, False)):
        return bpy.data.objects.get(
            str(helper.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
        )
    if bool(helper.get(SURFACE_CONTACT_SOLVER_PROPERTY, False)):
        return _helper_object_armature(getattr(helper, "parent", None))
    return None

def _organize_helper_collections(context):
    if context is None or getattr(context, "scene", None) is None:
        return False
    changed = False
    helpers = tuple(
        obj
        for obj in bpy.data.objects
        if (
            bool(obj.get(SPACE_HELPER_PROPERTY, False))
            or bool(obj.get(SURFACE_CONTACT_GUIDE_PROPERTY, False))
            or bool(obj.get(SURFACE_CONTACT_SOLVER_PROPERTY, False))
        )
    )
    for helper in helpers:
        armature = _helper_object_armature(helper)
        if armature is None:
            continue
        target = _ensure_space_helper_collection(context, armature)
        if target not in tuple(helper.users_collection):
            target.objects.link(helper)
            changed = True
        for collection in tuple(helper.users_collection):
            if collection == target:
                continue
            if (
                collection.name.startswith(LEGACY_SPACE_HELPER_COLLECTION)
                or SPACE_HELPER_OWNER_UID_PROPERTY in collection
            ):
                try:
                    collection.objects.unlink(helper)
                    changed = True
                except (ReferenceError, RuntimeError):
                    pass
    for collection in tuple(bpy.data.collections):
        if (
            not collection.name.startswith(LEGACY_SPACE_HELPER_COLLECTION)
            and SPACE_HELPER_OWNER_UID_PROPERTY not in collection
        ):
            continue
        if tuple(collection.objects) or tuple(collection.children):
            continue
        try:
            bpy.data.collections.remove(collection)
            changed = True
        except (ReferenceError, RuntimeError):
            pass
    return changed


def _create_space_helper(context, armature, pose_bone, role, frame, factor):
    collection = _ensure_space_helper_collection(context, armature)
    helper = bpy.data.objects.new(
        f"{SPACE_HELPER_OBJECT_PREFIX}{pose_bone.name}_{role}_{int(frame)}",
        None,
    )
    collection.objects.link(helper)
    helper[SPACE_HELPER_PROPERTY] = True
    helper.empty_display_type = "PLAIN_AXES"
    helper.empty_display_size = 0.01
    helper.hide_render = True
    helper.hide_select = True
    helper.parent = armature
    helper.matrix_parent_inverse = Matrix.Identity(4)
    helper.matrix_basis = factor
    try:
        helper.hide_set(True)
    except RuntimeError:
        pass
    context.view_layer.update()
    return helper


def _remove_space_constraint(owner, constraint):
    if owner is None or constraint is None:
        return False
    target = _dynamic_parent_constraint_target(owner, constraint)
    is_helper = bool(
        target is not None
        and bool(target.get(SPACE_HELPER_PROPERTY, False))
    )
    _remove_dynamic_parent_constraint_metadata(owner, constraint)
    try:
        owner.constraints.remove(constraint)
    except (ReferenceError, RuntimeError, ValueError):
        return False
    if is_helper and target.name in bpy.data.objects:
        bpy.data.objects.remove(target, do_unlink = True)
    return True


def _space_constraint_source_for_unparent(start_frame):
    return f"{SPACE_SOURCE_UNPARENT_PREFIX}{int(start_frame)}"


def _space_constraint_source_for_dynamic_parent(constraint, start_frame):
    identity = f"{constraint.name}:{int(start_frame)}"
    digest = hashlib.sha1(identity.encode("utf-8")).hexdigest()[:16]
    return f"{SPACE_SOURCE_DYNAMIC_PARENT_PREFIX}{digest}"


def _create_pose_space_constraint(
    context,
    armature,
    pose_bone,
    role,
    start_frame,
    end_frame = None,
    desired_factor = None,
    source = SPACE_SOURCE_BASE,
):
    if desired_factor is None:
        desired_factor = _pose_space_factor(
            context,
            armature,
            pose_bone,
        )

    parent_name = str(pose_bone.bone.get(REL_K_PARENT, ""))
    if role == SPACE_ROLE_NORMAL and not parent_name:
        role = SPACE_ROLE_WORLD

    constraint = pose_bone.constraints.new("CHILD_OF")
    _show_dynamic_pose_bone_native_color(pose_bone)
    constraint.name = f"{SPACE_CONSTRAINT_PREFIX}{role}_{int(start_frame)}"
    if role == SPACE_ROLE_NORMAL:
        constraint.target = armature
        constraint.subtarget = parent_name

        target_matrix = _pose_space_target_matrix(
            context,
            armature,
            armature,
            parent_name,
        )
        constraint.inverse_matrix = target_matrix.inverted_safe() @ desired_factor
    else:
        helper = _create_space_helper(
            context,
            armature,
            pose_bone,
            role,
            start_frame,
            desired_factor,
        )
        constraint.target = helper
        constraint.subtarget = ""
        constraint.inverse_matrix = Matrix.Identity(4)

    _store_dynamic_space_role(pose_bone, constraint, role)
    _store_dynamic_space_source(pose_bone, constraint, source)
    _store_dynamic_parent_constraint_segment(
        pose_bone,
        constraint,
        int(start_frame),
        int(end_frame) if end_frame is not None else None,
    )
    _store_dynamic_parent_constraint_target(pose_bone, constraint)
    _mark_dynamic_parent_boundary_calibrated(
        pose_bone,
        constraint,
        int(start_frame),
    )
    constraint.influence = 0.0
    constraint.mute = True
    return constraint


def _active_internal_space_constraint(pose_bone, frame):
    active = [
        constraint
        for constraint in _internal_space_constraints(pose_bone)
        if _dynamic_parent_constraint_active_at(pose_bone, constraint, frame)
    ]
    return active[-1] if active else None


def _ensure_pose_space_system(context, armature, pose_bone, frame):
    if pose_bone is None:
        return None
    bone_name = pose_bone.name
    if _pose_space_managed(pose_bone):
        if pose_bone.parent is not None:
            _rel_saved_parent(pose_bone)
            if not _unparent_apply_relation(
                context,
                armature,
                bone_name,
                True,
            ):
                return None
        _sync_dynamic_parent_constraints(int(frame), armature)
        context.view_layer.update()
        return armature.pose.bones.get(bone_name)

    desired_factor = _pose_space_factor(
        context,
        armature,
        pose_bone,
    )
    parent_name = _rel_saved_parent(pose_bone)
    if pose_bone.parent is not None and not _unparent_apply_relation(
        context,
        armature,
        bone_name,
        True,
    ):
        return None

    context.view_layer.update()
    pose_bone = armature.pose.bones.get(bone_name)
    if pose_bone is None:
        return None
    role = SPACE_ROLE_NORMAL if parent_name else SPACE_ROLE_WORLD
    _create_pose_space_constraint(
        context,
        armature,
        pose_bone,
        role,
        SPACE_MIN_FRAME,
        desired_factor = desired_factor,
        source = SPACE_SOURCE_BASE,
    )
    _sync_dynamic_parent_constraints(int(frame), armature)
    context.view_layer.update()
    return armature.pose.bones.get(bone_name)


def _switch_pose_underlying_space(
    context,
    armature,
    pose_bone,
    role,
    frame,
    desired_factor,
    source,
):
    pose_bone = _ensure_pose_space_system(
        context,
        armature,
        pose_bone,
        frame,
    )
    if pose_bone is None:
        return None

    current = _active_internal_space_constraint(pose_bone, int(frame))
    if current is not None:
        start_frame, _end_frame = _dynamic_parent_constraint_segment(
            pose_bone,
            current,
        )
        if start_frame is not None and int(start_frame) == int(frame):
            _remove_space_constraint(pose_bone, current)
        else:
            _store_dynamic_parent_constraint_segment(
                pose_bone,
                current,
                int(start_frame) if start_frame is not None else SPACE_MIN_FRAME,

                int(frame),
            )

    constraint = _create_pose_space_constraint(
        context,
        armature,
        pose_bone,
        role,
        int(frame),
        desired_factor = desired_factor,
        source = source,
    )
    _sync_dynamic_parent_constraints(int(frame), armature)
    context.view_layer.update()
    return constraint


def _remove_future_space_constraints(owner, source, after_frame):
    removed = False
    for constraint in list(_internal_space_constraints(owner)):
        if _dynamic_space_source(owner, constraint) != source:
            continue
        start_frame, _end_frame = _dynamic_parent_constraint_segment(
            owner,
            constraint,
        )
        if start_frame is None or int(start_frame) <= int(after_frame):
            continue
        removed = _remove_space_constraint(owner, constraint) or removed
    return removed


def _space_constraints_with_source(owner, source):
    return tuple(
        constraint
        for constraint in _internal_space_constraints(owner)
        if _dynamic_space_source(owner, constraint) == source
    )


def _remove_pose_space_source(owner, source):
    matching = _space_constraints_with_source(owner, source)
    if not matching:
        return False

    matching_pointers = {int(constraint.as_pointer()) for constraint in matching}
    remaining = [
        constraint
        for constraint in _internal_space_constraints(owner)
        if int(constraint.as_pointer()) not in matching_pointers
    ]
    matching_starts = [
        start
        for constraint in matching
        for start, _end in (
            _stored_dynamic_parent_constraint_segment(owner, constraint),
        )
        if start is not None
    ]
    boundary = min(matching_starts) if matching_starts else SPACE_MIN_FRAME

    fallback = next(
        (
            constraint
            for constraint in reversed(remaining)
            if _dynamic_parent_constraint_active_at(owner, constraint, boundary)
        ),
        None,
    )
    previous = next(
        (
            constraint
            for constraint in reversed(remaining)
            if _dynamic_parent_constraint_active_at(
                owner,
                constraint,
                boundary - 1,
            )
        ),
        None,
    )
    next_starts = [
        start
        for constraint in remaining
        for start, _end in (
            _stored_dynamic_parent_constraint_segment(owner, constraint),
        )
        if start is not None and int(start) > int(boundary)
    ]

    removed = False
    for constraint in matching:
        removed = _remove_space_constraint(owner, constraint) or removed

    if fallback is None and previous is not None:
        previous_start, _previous_end = (
            _stored_dynamic_parent_constraint_segment(owner, previous)
        )
        _store_dynamic_parent_constraint_segment(
            owner,
            previous,
            int(previous_start) if previous_start is not None else SPACE_MIN_FRAME,
            min(next_starts) if next_starts else None,
        )
    return removed


def _teardown_pose_space_system(context, armature, pose_bone):
    if pose_bone is None or not _pose_space_managed(pose_bone):
        return False

    bone_name = pose_bone.name
    previous_autokey = _autokey_push(context)
    try:
        if pose_bone.parent is None and str(
            pose_bone.bone.get(REL_K_PARENT, "")
        ):
            if not _unparent_apply_relation(
                context,
                armature,
                bone_name,
                False,
            ):
                return False

        context.view_layer.update()
        pose_bone = armature.pose.bones.get(bone_name)
        if pose_bone is None:
            return False
        for constraint in list(_internal_space_constraints(pose_bone)):
            _remove_space_constraint(pose_bone, constraint)
        _unparent_remove_visual_constraint(pose_bone)
        context.view_layer.update()
        pose_bone = armature.pose.bones.get(bone_name)
        if pose_bone is None:
            return False
        # Clearing the last dynamic marker restores the native relation and
        # its keyed/local pose. Reapplying the helper-space output here baked
        # a phantom offset even when the bone had no transform keys.
        context.view_layer.update()
        if UNP_PROP in pose_bone:
            del pose_bone[UNP_PROP]
        _unparent_clear_start_frame(pose_bone)
        _unparent_rel_set_cached(armature.name, bone_name, False)
        context.view_layer.update()
        return True
    finally:
        _autokey_pop(context, previous_autokey)
