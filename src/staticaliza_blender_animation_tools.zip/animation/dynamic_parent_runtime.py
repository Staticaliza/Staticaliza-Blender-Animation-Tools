"""Runtime refresh and deletion guards specific to Dynamic Parent."""

from ..core.runtime import *  # noqa: F403


def _dynamic_parent_animation_signature():
    """Fingerprint transform curves that can affect dynamic-space boundaries."""

    animated_ids = {}
    for armature in tuple(bpy.data.objects):
        if armature.type != "ARMATURE" or getattr(armature, "pose", None) is None:
            continue
        constraints = tuple(
            constraint
            for pose_bone in armature.pose.bones
            for constraint in pose_bone.constraints
            if _is_dynamic_state_constraint(constraint)
        )
        if not constraints:
            continue
        animated_ids[int(armature.as_pointer())] = armature
        for pose_bone in armature.pose.bones:
            for constraint in pose_bone.constraints:
                if not _is_dynamic_state_constraint(constraint):
                    continue
                target = _dynamic_parent_constraint_target(
                    pose_bone,
                    constraint,
                )
                if target is not None:
                    animated_ids[int(target.as_pointer())] = target

    transform_suffixes = (
        "location",
        "scale",
        "rotation_euler",
        "rotation_quaternion",
        "rotation_axis_angle",
    )
    signature = []
    for animated_id in animated_ids.values():
        action = _dynamic_parent_owner_action(animated_id)
        if action is None:
            continue
        curves = []
        for fcurve in _action_fcurves(action, animated_id):
            data_path = str(fcurve.data_path)
            if not data_path.endswith(transform_suffixes):
                continue
            points = []
            for key in fcurve.keyframe_points:
                left_type = str(key.handle_left_type)
                right_type = str(key.handle_right_type)
                # AUTO/VECTOR handles are derived from the key coordinates
                # and Blender may finish updating them on a later depsgraph
                # pass. Fingerprinting those calculated coordinates makes an
                # unchanged Action look dirty on the next scrubbed frame.
                left = (
                    (
                        round(float(key.handle_left.x), 6),
                        round(float(key.handle_left.y), 7),
                    )
                    if left_type in {"FREE", "ALIGNED"}
                    else None
                )
                right = (
                    (
                        round(float(key.handle_right.x), 6),
                        round(float(key.handle_right.y), 7),
                    )
                    if right_type in {"FREE", "ALIGNED"}
                    else None
                )
                points.append(
                    (
                        round(float(key.co.x), 6),
                        round(float(key.co.y), 7),
                        left_type,
                        left,
                        right_type,
                        right,
                        str(key.interpolation),
                        str(key.easing),
                        round(float(getattr(key, "amplitude", 0.0)), 7),
                        round(float(getattr(key, "back", 0.0)), 7),
                        round(float(getattr(key, "period", 0.0)), 7),
                    )
                )
            curves.append(
                (
                    data_path,
                    int(getattr(fcurve, "array_index", 0)),
                    tuple(points),
                )
            )
        signature.append(
            (
                int(animated_id.as_pointer()),
                tuple(sorted(curves)),
            )
        )
    return tuple(sorted(signature))


def _store_dynamic_parent_animation_signature():
    _state["dynamic_parent_animation_signature"] = (
        _dynamic_parent_animation_signature()
    )


def _run_dynamic_parent_boundary_refresh():
    if (
        _pin_primary_mouse_pressed()
        or _window_manager_has_modal_operator(bpy.context)
        or _state.get("unparent_handler_mute", False)
        or _state.get("dynamic_space_export_sampling", False)
        or _animation_playback_active()
    ):
        return 0.05

    quiet_time = time.monotonic() - float(
        _state.get("dynamic_parent_boundary_refresh_last_update", 0.0)
    )
    if quiet_time < 0.03:
        return max(0.01, 0.03 - quiet_time)

    context = bpy.context
    if context is None or context.scene is None:
        _state["dynamic_parent_boundary_refresh_pending"] = False
        return None
    try:
        # Complete any indirectly driven child session before changing a
        # boundary inverse. Keeping the pending flag set prevents that
        # finalizer from scheduling a redundant second refresh.
        _sync_dynamic_parent_dual_selection_locks(
            context,
            capture_unsessioned=True,
        )
        _state["dynamic_parent_boundary_refresh_pending"] = False
        _recalibrate_all_dynamic_space_boundaries(
            context,
            parent_only=False,
        )
        _dynamic_parent_apply_indirect_visual_commits(context)
        _store_dynamic_parent_animation_signature()
    except (AttributeError, ReferenceError, RuntimeError, ValueError) as exc:
        print(f"[Roblox Animator Utils] Parent boundary refresh failed: {exc}")
    return None


def _flush_dynamic_parent_boundary_refresh(context=None):
    if not _state.get("dynamic_parent_boundary_refresh_pending", False):
        return False
    try:
        if bpy.app.timers.is_registered(_run_dynamic_parent_boundary_refresh):
            bpy.app.timers.unregister(_run_dynamic_parent_boundary_refresh)
    except (ReferenceError, RuntimeError, ValueError):
        pass
    context = context or bpy.context
    if context is None or context.scene is None:
        _state["dynamic_parent_boundary_refresh_pending"] = False
        return False
    _sync_dynamic_parent_dual_selection_locks(
        context,
        capture_unsessioned=True,
    )
    _state["dynamic_parent_boundary_refresh_pending"] = False
    changed = bool(
        _recalibrate_all_dynamic_space_boundaries(
            context,
            parent_only=False,
        )
    )
    changed = (
        _dynamic_parent_apply_indirect_visual_commits(context)
        or changed
    )
    _store_dynamic_parent_animation_signature()
    return changed


def _schedule_dynamic_parent_boundary_refresh():
    """Refresh Parent inverses after an ordinary pose/key edit settles."""

    _state["dynamic_parent_boundary_refresh_last_update"] = time.monotonic()
    if _state.get("dynamic_parent_boundary_refresh_pending", False):
        return
    _state["dynamic_parent_boundary_refresh_pending"] = True
    register_owned_timer(
        _run_dynamic_parent_boundary_refresh,
        first_interval=0.03,
    )


def _refresh_dynamic_parent_for_scrub(context):
    """Rebuild once when scrub starts after a missed Action notification."""

    current = _dynamic_parent_animation_signature()
    previous = _state.get("dynamic_parent_animation_signature")
    if previous is not None and current == previous:
        return False
    changed = bool(
        _recalibrate_all_dynamic_space_boundaries(
            context,
            parent_only=False,
        )
    )
    _store_dynamic_parent_animation_signature()
    return changed


def _dynamic_parent_marker_deletion_pending():
    for armature in tuple(bpy.data.objects):
        if armature.type != "ARMATURE" or getattr(armature, "pose", None) is None:
            continue
        action = armature.animation_data.action if armature.animation_data else None
        for pose_bone in armature.pose.bones:
            for constraint in pose_bone.constraints:
                if not constraint.name.startswith("DP_"):
                    continue
                start, end = _stored_dynamic_parent_constraint_segment(
                    pose_bone,
                    constraint,
                )
                path = _dynamic_parent_marker_data_path(constraint)
                marker_frames = {
                    int(round(float(key.co.x)))
                    for fcurve in _fcurves_find_all(action, path)
                    for key in fcurve.keyframe_points
                } if action is not None and path else set()
                if start is not None and int(start) not in marker_frames:
                    return True
                if end is not None and int(end) not in marker_frames:
                    return True
    return False


def _hold_dynamic_parent_start_deletions(scene):
    """Keep the active relation stable until deleted Start cleanup runs."""

    frame = int(getattr(scene, "frame_current", 0))
    found = False
    for armature in tuple(bpy.data.objects):
        if armature.type != "ARMATURE" or getattr(armature, "pose", None) is None:
            continue
        action = armature.animation_data.action if armature.animation_data else None
        for pose_bone in armature.pose.bones:
            for constraint in pose_bone.constraints:
                if not constraint.name.startswith("DP_"):
                    continue
                start, end = _stored_dynamic_parent_constraint_segment(
                    pose_bone,
                    constraint,
                )
                if start is None:
                    continue
                path = _dynamic_parent_marker_data_path(constraint)
                curves = (
                    tuple(_fcurves_find_all(action, path))
                    if action is not None and path
                    else ()
                )
                marker_frames = {
                    int(round(float(key.co.x)))
                    for fcurve in curves
                    for key in fcurve.keyframe_points
                }
                if int(start) in marker_frames:
                    continue
                found = True
                was_active = frame >= int(start) and (
                    end is None or frame < int(end)
                )
                if not was_active:
                    continue
                _restore_dynamic_parent_constraint_target(
                    pose_bone,
                    constraint,
                )
                constraint.influence = 1.0
                constraint.mute = False
    return found
