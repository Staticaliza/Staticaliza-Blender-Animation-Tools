"""Onion-skin settings, snapshots, and yellow-pin restoration."""

from ..core.runtime import *  # noqa: F403

def _matrix_flat_values(matrix):
    return [
        float(matrix[row][column])
        for row in range(4)
        for column in range(4)
    ]


def _matrix_from_flat_values(values):
    values = tuple(float(value) for value in values)
    if len(values) != 16:
        raise ValueError("Expected a 4x4 matrix")
    return Matrix(tuple(
        values[index:index + 4]
        for index in range(0, 16, 4)
    ))


def _store_onion_settings(context):
    scene = getattr(context, "scene", None)
    window_manager = getattr(context, "window_manager", None)
    if scene is None or window_manager is None:
        return False
    payload = {
        "mode": str(getattr(window_manager, "onion_skin_mode", "SINGLE")),
        "opacity": float(getattr(window_manager, "onion_skin_opacity", 0.35)),
        "include_meshes": bool(getattr(window_manager, "onion_skin_include_meshes", True)),
        "include_bones": bool(getattr(window_manager, "onion_skin_include_bones", False)),
        "raycast": bool(getattr(window_manager, "onion_skin_raycast", True)),
        "skip_hidden": bool(getattr(window_manager, "onion_skin_skip_hidden", True)),
    }
    try:
        scene[ONION_SKIN_SETTINGS_PROPERTY] = json.dumps(payload, separators = (",", ":"))
        return True
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return False


def _restore_onion_settings(context):
    scene = getattr(context, "scene", None)
    window_manager = getattr(context, "window_manager", None)
    if scene is None or window_manager is None:
        return False
    raw = scene.get(ONION_SKIN_SETTINGS_PROPERTY)
    if not raw:
        return False
    try:
        payload = json.loads(str(raw))
    except (TypeError, ValueError):
        return False
    changed = False
    for property_name, payload_name in (
        ("onion_skin_mode", "mode"),
        ("onion_skin_opacity", "opacity"),
        ("onion_skin_include_meshes", "include_meshes"),
        ("onion_skin_include_bones", "include_bones"),
        ("onion_skin_raycast", "raycast"),
        ("onion_skin_skip_hidden", "skip_hidden"),
    ):
        if payload_name not in payload or not hasattr(window_manager, property_name):
            continue
        try:
            setattr(window_manager, property_name, payload[payload_name])
            changed = True
        except (AttributeError, RuntimeError, TypeError, ValueError):
            pass
    return changed


def _store_onion_snapshot(context, armature):
    if armature is None or getattr(armature, "pose", None) is None:
        return False
    payload = {
        "version": 1,
        "frame": int(getattr(context.scene, "frame_current", 0)),
        "matrix_world": _matrix_flat_values(armature.matrix_world),
        "bones": {
            pose_bone.name: _matrix_flat_values(pose_bone.matrix_basis)
            for pose_bone in armature.pose.bones
        },
    }
    try:
        armature[ONION_SKIN_ENABLED_PROPERTY] = True
        armature[ONION_SKIN_SNAPSHOT_PROPERTY] = json.dumps(
            payload,
            separators = (",", ":"),
        )
        return True
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return False


def _clear_onion_snapshot(armature):
    if armature is None:
        return False
    removed = False
    for property_name in (
        ONION_SKIN_ENABLED_PROPERTY,
        ONION_SKIN_SNAPSHOT_PROPERTY,
    ):
        try:
            if property_name in armature:
                del armature[property_name]
                removed = True
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            pass
    return removed


def _restore_onion_snapshot(context, armature):
    if not bool(armature.get(ONION_SKIN_ENABLED_PROPERTY, False)):
        return False
    payload = None
    raw = armature.get(ONION_SKIN_SNAPSHOT_PROPERTY)
    if raw:
        try:
            payload = json.loads(str(raw))
        except (TypeError, ValueError):
            payload = None

    current_frame = int(context.scene.frame_current)
    current_world = armature.matrix_world.copy()
    current_basis = {
        pose_bone.name: pose_bone.matrix_basis.copy()
        for pose_bone in armature.pose.bones
    }
    try:
        if isinstance(payload, dict):
            saved_frame = int(payload.get("frame", current_frame))
            if saved_frame != current_frame:
                context.scene.frame_set(saved_frame)
            matrix_world = payload.get("matrix_world")
            if matrix_world is not None:
                armature.matrix_world = _matrix_from_flat_values(matrix_world)
            for bone_name, values in payload.get("bones", {}).items():
                pose_bone = armature.pose.bones.get(str(bone_name))
                if pose_bone is not None:
                    pose_bone.matrix_basis = _matrix_from_flat_values(values)
        context.view_layer.update()
        mesh_batches, raycast_fixed = _build_snapshot_data(context, armature)
    except (
        AttributeError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ):
        return False
    finally:
        try:
            if int(context.scene.frame_current) != current_frame:
                context.scene.frame_set(current_frame)
            armature.matrix_world = current_world
            for bone_name, matrix_basis in current_basis.items():
                pose_bone = armature.pose.bones.get(bone_name)
                if pose_bone is not None:
                    pose_bone.matrix_basis = matrix_basis
            context.view_layer.update()
        except (AttributeError, ReferenceError, RuntimeError):
            pass

    uid = _armature_session_uid(armature)
    mesh_batches_by_owner = dict(_state.get("mesh_batches", {}))
    raycast_by_owner = dict(_state.get("raycast_fixed", {}))
    mesh_batches_by_owner[uid] = mesh_batches
    raycast_by_owner[uid] = raycast_fixed
    _state["mesh_batches"] = mesh_batches_by_owner
    _state["raycast_fixed"] = raycast_by_owner
    enabled = set(_state.get("onion_enabled_owners", set()))
    enabled.add(uid)
    _state["onion_enabled_owners"] = enabled
    return True


def _restore_yellow_pins(context):
    restored = 0
    for armature in tuple(getattr(context.scene, "objects", ())):
        if armature.type != "ARMATURE" or getattr(armature, "pose", None) is None:
            continue
        stored = {}
        for pose_bone in armature.pose.bones:
            target = pose_bone.get(YELLOW_PIN_TARGET_PROPERTY)
            try:
                target_values = tuple(float(value) for value in target[:3])
            except (IndexError, TypeError, ValueError):
                continue
            if len(target_values) < 3:
                continue
            try:
                mode = int(pose_bone.get(YELLOW_PIN_MODE_PROPERTY, 1))
            except (TypeError, ValueError):
                mode = 1
            if mode == 5:
                mode = 3
                pose_bone[YELLOW_PIN_MODE_PROPERTY] = mode
            stored[pose_bone.name] = (
                max(1, min(5, mode)),
                Vector(target_values),
            )
        if not stored:
            continue

        fixed = {}
        depsgraph = context.evaluated_depsgraph_get()
        evaluated_armature = armature.evaluated_get(depsgraph)
        objects, _active = _targets(context, armature)
        need_bounds = {
            bone_name
            for bone_name, (mode, _target) in stored.items()
            if mode in (2, 3)
        }
        bounds_world = (
            _collect_world_shape_from_largest_components(
                context,
                depsgraph,
                armature,
                evaluated_armature,
                need_bounds,
                objs = objects,
            )
            if need_bounds else {}
        )
        for bone_name, (mode, target) in stored.items():
            pose_bone = armature.pose.bones.get(bone_name)
            if (
                pose_bone is not None
                and YELLOW_PIN_INITIAL_TARGET_PROPERTY not in pose_bone
            ):
                pose_bone[YELLOW_PIN_INITIAL_TARGET_PROPERTY] = tuple(target)
            captured = _yellow_capture(
                context,
                depsgraph,
                armature,
                evaluated_armature,
                objects,
                bone_name,
                mode,
                bounds_world,
                axis=str(
                    pose_bone.get(YELLOW_PIN_AXIS_PROPERTY, "Y_NEG")
                    if pose_bone is not None
                    else "Y_NEG"
                ),
            )
            if captured is None:
                continue
            values = list(captured)
            values[0] = target.copy()
            fixed[bone_name] = tuple(values)
            restored += 1
        _yellow_replace_owner_map(
            "yellow_modes",
            armature,
            {bone_name: mode for bone_name, (mode, _target) in stored.items()},
        )
        _yellow_replace_owner_map("yellow_fixed", armature, fixed)
        stored_hidden = bool(
            armature.get(YELLOW_PIN_HIDDEN_PROPERTY, False)
        )
        if _yellow_owner_hidden(armature) != stored_hidden:
            _yellow_set_owner_hidden(armature, stored_hidden)
            changed = True
    return restored
