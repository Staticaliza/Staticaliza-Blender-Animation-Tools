"""Dynamic-unparent operators and menus."""

from ..core.runtime import *  # noqa: F403

class ANIMATOR_UTILS_OT_unparent_action(bpy.types.Operator):
    bl_idname = "staticaliza.unparent_action"
    bl_label = "Unparent Action"
    bl_description = "Edit the active bone's Dynamic Unparent segment"
    bl_options = {"UNDO", "INTERNAL"}
    action: bpy.props.EnumProperty(
    items = (
            ("START", "Start", ""),
            ("END", "End", ""),
            ("BAKE", "Bake", ""),
            ("BAKE_TO_NEAREST", "Bake To Nearest", ""),
            ("BAKE_TO_ENDING", "Bake To End", ""),
            ("CLEAR", "Clear", ""),
            ("REMOVE_START", "Remove Start", ""),
            ("REMOVE_END", "Remove End", "")
        ),
        options = {"HIDDEN", "SKIP_SAVE"},
    )

    @classmethod
    def description(cls, _context, properties):
        descriptions = {
            "START": "Start a Dynamic Unparent segment at the current frame",
            "END": "End the active Dynamic Unparent segment at the current frame",
            "BAKE": "Bake the active Dynamic Unparent segment to keyframes",
            "BAKE_TO_NEAREST": (
                "Bake the active Dynamic Unparent segment to its nearest boundary"
            ),
            "BAKE_TO_ENDING": (
                "Bake the active Dynamic Unparent segment through its ending frame"
            ),
            "CLEAR": "Remove the active Dynamic Unparent segment without baking it",
            "REMOVE_START": "Remove the active Dynamic Unparent start marker",
            "REMOVE_END": "Remove the active Dynamic Unparent end marker",
        }
        return descriptions.get(getattr(properties, "action", ""), cls.bl_description)

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE" and bool(_selected_pose_bones_only(context))

    def execute(self, context):
        prev_autokey = _autokey_push(context)
        previous_handler_mute = bool(_state.get("unparent_handler_mute", False))
        _state["unparent_handler_mute"] = True
        try:
            active_bone = context.active_pose_bone
            if active_bone is None:
                return {"CANCELLED"}
            arm = _pose_bone_owner(context, active_bone) or _active_armature(context)
            if not arm:
                return {"CANCELLED"}
            bone_names = tuple(
                pose_bone.name
                for pose_bone in _selected_pose_bones_only(context)
                if _pose_bone_owner(context, pose_bone) == arm
            )
            if not bone_names:
                return {"CANCELLED"}

            scn = context.scene
            f = int(scn.frame_current)
            action = arm.animation_data.action if arm.animation_data else None

            any_done = False

            if self.action in {"START", "END"}:
                for bone_name in bone_names:
                    pb = arm.pose.bones.get(bone_name)
                    if not pb:
                        continue

                    if (
                        action is not None
                        and _dynamic_marker_value(
                            action,
                            _unparent_dp(pb.name),
                            int(f),
                        ) is not None
                    ):
                        self.report(
                            {"ERROR"},
                            "A Dynamic Unparent marker already exists on this frame.",
                        )
                        continue

                    auto_starts = _dp_auto_unparent_start_frames(pb)
                    active_now = False
                    active_start = None
                    if action:
                        active_now = _unparent_eval(action, pb.name, int(f), pb_default = 0.0) >= 0.5
                        active_start = _unparent_find_active_start_frame(
                            action,
                            pb.name,
                            int(f),
                        )
                    active_is_auto = bool(
                        active_now
                        and active_start is not None
                        and int(active_start) in auto_starts
                    )

                    if self.action == "START" and (not active_now):
                        if _unparent_toggle(context, arm, pb, int(f)):
                            any_done = True

                    if (
                        self.action == "END"
                        and active_now
                        and not active_is_auto
                        and active_start is not None
                        and int(f) > int(active_start)
                    ):
                        if _unparent_toggle(context, arm, pb, int(f)):
                            any_done = True

                context.view_layer.update()
                _tag_redraw_all_view3d()
                return {"FINISHED"} if any_done else {"CANCELLED"}

            for bone_name in bone_names:
                pb = arm.pose.bones.get(bone_name)
                if not pb:
                    continue

                auto_starts = _dp_auto_unparent_start_frames(pb)
                active_start = (
                    _unparent_find_active_start_frame(
                        action,
                        pb.name,
                        int(f),
                    )
                    if action
                    else None
                )
                if active_start is not None and int(active_start) in auto_starts:
                    continue

                if self.action == "CLEAR":
                    if not action:
                        continue
                    start_frame, end_frame, _next_start, _conjoined = (
                        _unparent_segment_at_frame(
                            action,
                            pb.name,
                            int(f),
                        )
                    )
                    if (
                        start_frame is not None
                        and int(start_frame) not in auto_starts
                        and _unparent_clear_segment(
                            context,
                            arm,
                            pb,
                            int(start_frame),
                            end_frame,
                        )
                    ):
                        any_done = True
                    continue

                active_now = _unparent_is_active_at(context, arm, pb, int(f))

                seg_start = None
                seg_end = None
                seg_next = None
                seg_conjoined = False

                if action:
                    seg_start, seg_end, seg_next, seg_conjoined = _unparent_segment_at_frame(action, pb.name, int(f))
                    if (
                        seg_start is not None
                        and int(seg_start) in auto_starts
                    ):
                        continue

                start_f = seg_start
                if start_f is None:
                    start_f = _unparent_start_frame(pb)
                if start_f is None and action:
                    start_f = _unparent_find_start_frame_fallback(action, pb.name)


                if self.action == "REMOVE_START":
                    if action and seg_start is not None:
                        if _unparent_clear_segment(
                            context,
                            arm,
                            pb,
                            int(seg_start),
                            seg_end,
                        ):
                            any_done = True
                    elif start_f is not None:
                        fallback_end = _unparent_find_end_frame(
                            action,
                            pb.name,
                            int(start_f),
                        ) if action else None
                        if _unparent_clear_segment(
                            context,
                            arm,
                            pb,
                            int(start_f),
                            fallback_end,
                        ):
                            any_done = True

                elif self.action == "REMOVE_END":
                    if action and seg_start is not None:
                        end_key = _unparent_find_end_frame(action, pb.name, int(seg_start))
                        if end_key is not None:
                            if _unparent_remove_end_marker(
                                context,
                                arm,
                                pb,
                                int(seg_start),
                                int(end_key),
                            ):
                                any_done = True

                elif self.action == "BAKE":
                    if action and seg_start is not None:
                        end_key = _unparent_find_end_frame(action, pb.name, int(seg_start))
                        if end_key is not None and int(end_key) != int(seg_start):
                            if _unparent_bake_window(context, arm, pb, int(seg_start), int(end_key)):
                                any_done = True

                elif self.action == "BAKE_TO_NEAREST":
                    if action and seg_start is not None:
                        end_key = _unparent_find_end_frame(action, pb.name, int(seg_start))

                        if end_key is not None:
                            end_f = int(end_key)
                        else:
                            end_f = int(_unparent_bake_to_end_target(context, action, pb.name, int(f)))

                        if int(end_f) != int(seg_start):
                            if _unparent_bake_window(context, arm, pb, int(seg_start), int(end_f)):
                                any_done = True

                elif self.action == "BAKE_TO_ENDING":
                    if action and seg_start is not None:
                        end_key = _unparent_find_end_frame(action, pb.name, int(seg_start))

                        if end_key is not None:
                            end_f = int(end_key)
                        else:
                            end_f = int(scn.frame_end)

                        if int(end_f) != int(seg_start):
                            if _unparent_bake_window(context, arm, pb, int(seg_start), int(end_f)):
                                any_done = True

            context.view_layer.update()
            _tag_redraw_all_view3d()
            return {"FINISHED"} if any_done else {"CANCELLED"}

        finally:
            _state["unparent_handler_mute"] = previous_handler_mute
            _autokey_pop(context, prev_autokey)
            scene = getattr(context, "scene", None)
            if scene is not None:
                _sync_all_dynamic_pose_bone_colors(
                    int(scene.frame_current)
                )
            _tag_redraw_all_view3d()

class ANIMATOR_UTILS_MT_unparent_menu_inactive(bpy.types.Menu):
    bl_label = "Dynamic Unparent"

    def draw(self, context):
        layout = self.layout
        layout.operator("staticaliza.unparent_action", text = "Key Start").action = "START"

class ANIMATOR_UTILS_MT_unparent_menu_active(bpy.types.Menu):
    bl_label = "Dynamic Unparent Active"
    def draw(self, context):
        arm = _active_armature(context)
        pb = context.active_pose_bone
        action = arm.animation_data.action if (arm and arm.animation_data) else None
        f = int(context.scene.frame_current)
        hide_advanced = not getattr(
            context.window_manager,
            "roblox_compat_advanced_mode",
            False,
        )

        layout = self.layout

        if not arm or not pb or not action:
            layout.operator("staticaliza.unparent_action", text = "Key Start").action = "START"
            return

        start_f, end_f, next_start, conjoined = _unparent_segment_at_frame(action, pb.name, int(f))

        if (
            start_f is not None
            and int(start_f) in _dp_auto_unparent_start_frames(pb)
        ):
            layout.label(text = "Managed by Dynamic Parent")
            return

        if start_f is None:
            layout.operator("staticaliza.unparent_action", text = "Key Start").action = "START"
            return

        if end_f is None:
            layout.operator("staticaliza.unparent_action", text = "Key End").action = "END"
            layout.operator("staticaliza.unparent_action", text = "Clear").action = "CLEAR"
            if hide_advanced:
                return
            layout.operator("staticaliza.unparent_action", text = "Remove Start").action = "REMOVE_START"
            layout.separator()

            target_near = _unparent_bake_to_end_target(context, action, pb.name, int(f))
            if int(target_near) != int(start_f):
                layout.operator("staticaliza.unparent_action", text = "Bake To Nearest").action = "BAKE_TO_NEAREST"

            target_end = int(context.scene.frame_end)
            if int(target_end) != int(start_f):
                layout.operator("staticaliza.unparent_action", text = "Bake To End").action = "BAKE_TO_ENDING"
            return

        if conjoined:
            layout.operator("staticaliza.unparent_action", text = "Clear").action = "CLEAR"
            if hide_advanced:
                return
            layout.operator("staticaliza.unparent_action", text = "Remove Start").action = "REMOVE_START"
            layout.separator()
            layout.operator("staticaliza.unparent_action", text = "Bake").action = "BAKE"
            return

        layout.operator("staticaliza.unparent_action", text = "Clear").action = "CLEAR"
        if hide_advanced:
            return
        layout.operator("staticaliza.unparent_action", text = "Remove End").action = "REMOVE_END"
        layout.operator("staticaliza.unparent_action", text = "Remove Start").action = "REMOVE_START"
        layout.separator()
        layout.operator("staticaliza.unparent_action", text = "Bake").action = "BAKE"

class ANIMATOR_UTILS_OT_unparent_menu(bpy.types.Operator):
    bl_idname = "staticaliza.unparent_menu"
    bl_label = "Retired Dynamic Unparent Shortcut"
    bl_description = "Alt+F was retired; use Ctrl+F for Animation Tools"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        return False

    def invoke(self, context, event):
        return {"CANCELLED"}

    def execute(self, context):
        return {"CANCELLED"}
