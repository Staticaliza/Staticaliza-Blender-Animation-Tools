"""Onion-skin capture, clear, and settings update callbacks."""

from ..core.runtime import *  # noqa: F403


def _pin_virtual_selected_target_data(context):
    key = str(_state.get("pin_gizmo_selected_key", ""))
    if not key:
        return None
    for guide in _surface_contact_guides():
        if _surface_contact_snap_key(guide) != key:
            continue
        armature = bpy.data.objects.get(
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
        )
        pose_bone = (
            armature.pose.bones.get(
                str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
            )
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        return ("CONTACT", armature, pose_bone, guide) if pose_bone else None
    for armature in _pose_scope_armatures(context):
        for bone_name, packed in _yellow_owner_map(
            "yellow_fixed",
            armature,
        ).items():
            pose_bone = armature.pose.bones.get(str(bone_name))
            if (
                pose_bone is not None
                and key
                == f"YELLOW:{_armature_session_uid(armature)}:{pose_bone.name}"
            ):
                return ("YELLOW", armature, pose_bone, packed)
    return None

def _capture_or_clear(context, enable_ghost, armatures = None):
    _state["last_error"] = ""
    scope = tuple(armatures or _pose_scope_armatures(context))
    if not scope:
        active = _active_armature(context)
        scope = (active,) if active is not None else ()

    enabled_owners = set(_state.get("onion_enabled_owners", set()))
    mesh_batches_by_owner = dict(_state.get("mesh_batches", {}))
    raycast_by_owner = dict(_state.get("raycast_fixed", {}))

    if enable_ghost:
        _enable_runtime()
        for armature in scope:
            uid = _armature_session_uid(armature)
            try:
                bpy.context.view_layer.update()
                mesh_batches, raycast_fixed = _build_snapshot_data(
                    context,
                    armature,
                )
                mesh_batches_by_owner[uid] = mesh_batches
                raycast_by_owner[uid] = raycast_fixed
                enabled_owners.add(uid)
                _store_onion_snapshot(context, armature)
            except Exception as exc:
                _state["last_error"] = str(exc)
                mesh_batches_by_owner.pop(uid, None)
                raycast_by_owner.pop(uid, None)
                enabled_owners.discard(uid)
                _clear_onion_snapshot(armature)
    else:
        for armature in scope:
            uid = _armature_session_uid(armature)
            mesh_batches_by_owner.pop(uid, None)
            raycast_by_owner.pop(uid, None)
            enabled_owners.discard(uid)
            _clear_onion_snapshot(armature)

    _state["mesh_batches"] = mesh_batches_by_owner
    _state["raycast_fixed"] = raycast_by_owner
    _state["onion_enabled_owners"] = enabled_owners
    _store_onion_settings(context)
    _set_onion_property(context.window_manager, bool(enabled_owners))

    if not _runtime_needed(context):
        _disable_runtime()

    _tag_redraw_all_view3d()

def _on_enabled_toggle(self, context):
    if _state.get("onion_property_syncing", False):
        return
    _capture_or_clear(
        context,
        self.onion_skin_enabled,
        armatures = _pose_scope_armatures(context),
    )

def _on_setting_change(self, context):
    scope = tuple(
        armature
        for armature in _pose_scope_armatures(context)
        if _onion_owner_enabled(armature)
    )
    if not scope:
        return
    _capture_or_clear(context, True, armatures = scope)


def _on_yellow_pin_mode_change(self, context):
    """Treat the N-panel position selector as a live selected-pin config."""
    if (
        context is None
        or context.mode != "POSE"
        or _state.get("yellow_pin_mode_syncing", False)
    ):
        return
    mode = str(getattr(self, "yellow_pin_mode", "MODE_3"))
    pinned = set(_state.get("yellow_modes", {}))
    grouped = {}
    for armature, pose_bones in _selected_pose_bones_by_owner(
        context,
        include_active_fallback=True,
        include_virtual_pin=True,
    ).items():
        selected_pins = tuple(
            pose_bone
            for pose_bone in pose_bones
            if _owner_bone_key(armature, pose_bone.name) in pinned
        )
        if selected_pins:
            grouped[armature] = selected_pins
    if not grouped:
        return
    _state["yellow_pin_mode_syncing"] = True
    try:
        for armature, pose_bones in grouped.items():
            _yellow_apply_to_armature(
                context,
                armature,
                pose_bones,
                mode,
            )
        _yellow_refresh_runtime(context)
        _tag_redraw_all_view3d()
    finally:
        _state["yellow_pin_mode_syncing"] = False


def _on_yellow_pin_axis_change(self, context):
    if (
        context is None
        or context.mode != "POSE"
        or str(getattr(self, "yellow_pin_mode", "MODE_3")) != "MODE_3"
        or _state.get("yellow_pin_axis_syncing", False)
    ):
        return
    grouped = _selected_pose_bones_by_owner(
        context,
        include_active_fallback=True,
        include_virtual_pin=True,
    )
    _state["yellow_pin_axis_syncing"] = True
    try:
        for armature, pose_bones in grouped.items():
            for pose_bone in pose_bones:
                if YELLOW_PIN_TARGET_PROPERTY not in pose_bone:
                    continue
                mode = int(pose_bone.get(YELLOW_PIN_MODE_PROPERTY, 3))
                if mode == 5:
                    mode = 3
                _yellow_apply_to_armature(
                    context,
                    armature,
                    (pose_bone,),
                    f"MODE_{mode}",
                    pin_axis=str(getattr(self, "yellow_pin_axis", "Y_NEG")),
                )
        _yellow_refresh_runtime(context)
        _tag_redraw_all_view3d()
    finally:
        _state["yellow_pin_axis_syncing"] = False


class ANIMATOR_UTILS_OT_yellow_remove(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_remove"
    bl_label = "Remove Onion Pin"
    bl_description = "Remove Onion Pins from the selected bones"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def execute(self, context):
        grouped = _selected_pose_bones_by_owner(
            context,
            include_active_fallback=True,
        )
        removed = 0
        for armature, pose_bones in grouped.items():
            owner_removed, _unreachable = _yellow_apply_to_armature(
                context,
                armature,
                pose_bones,
                "REMOVE",
            )
            removed += owner_removed
        if not removed:
            return {"CANCELLED"}
        _yellow_refresh_runtime(context)
        return {"FINISHED"}


class ANIMATOR_UTILS_OT_yellow_clear_all(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_clear_all"
    bl_label = "Remove Onion Pin"
    bl_description = "Remove selected Onion Pins or every Onion Pin"
    bl_options = {"REGISTER", "UNDO"}

    clear_scope: bpy.props.EnumProperty(
        name = "Clear Scope",
        description = "Choose which Onion Pins to remove",
        items = (
            ("SELECTED", "Selected Pin", "Remove only the selected Onion Pin"),
            ("ALL", "All Pins", "Remove every Onion Pin in the current pose scope"),
        ),
        default = "SELECTED",
    )

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE" and any(
            _yellow_owner_map("yellow_modes", armature)
            for armature in _pose_scope_armatures(context)
        )

    def draw(self, context):
        self.layout.prop(self, "clear_scope", text = "Scope")

    def execute(self, context):
        selected_keys = set(_selected_owner_bone_keys(context))
        _selected_pin_key, selected_pin = _pin_selected_target_data(context)
        if selected_pin is not None and selected_pin[0] == "YELLOW":
            selected_keys.add(
                _owner_bone_key(selected_pin[1], selected_pin[2].name)
            )
        removed = 0
        for armature in _pose_scope_armatures(context):
            pins = _yellow_owner_map("yellow_modes", armature)
            bone_names = tuple(
                bone_name
                for bone_name in pins
                if (
                    self.clear_scope == "ALL"
                    or _owner_bone_key(armature, bone_name) in selected_keys
                )
            )
            for bone_name in bone_names:
                _yellow_clear_target_property(armature, bone_name)
            if not bone_names:
                continue
            removed += len(bone_names)
            _yellow_replace_owner_map(
                "yellow_modes",
                armature,
                {
                    bone_name: mode
                    for bone_name, mode in pins.items()
                    if bone_name not in bone_names
                },
            )
            fixed = _yellow_owner_map("yellow_fixed", armature)
            _yellow_replace_owner_map(
                "yellow_fixed",
                armature,
                {
                    bone_name: packed
                    for bone_name, packed in fixed.items()
                    if bone_name not in bone_names
                },
            )
            if self.clear_scope == "ALL":
                _yellow_set_owner_hidden(armature, False)
        if not removed:
            self.report({"WARNING"}, "No selected Onion Pin to remove.")
            return {"CANCELLED"}
        _yellow_refresh_runtime(context)
        self.report({"INFO"}, f"Removed {removed} Onion Pin(s).")
        return {"FINISHED"}


class ANIMATOR_UTILS_OT_yellow_menu(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_menu"
    bl_label = "Onion Pin"
    bl_description = "Open Onion Pin actions for the current Pose Mode selection"
    bl_options = {"REGISTER", "UNDO"}

    position_mode: bpy.props.EnumProperty(
        name = "Pin Position",
        description = "Choose where this Onion Pin is placed",
        items = (
            ("MODE_3", "Smart", "Use the selected welded-object face"),
            ("MODE_4", "Bone Start", "Use the bone head"),
            ("MODE_2", "Bone Center", "Use the center of the weighted geometry"),
            ("MODE_1", "Bone End", "Use the bone tail"),
        ),
        default = "MODE_3",
    )
    pin_axis: bpy.props.EnumProperty(
        name = "Axis",
        description = "Choose the welded-object face used by Smart",
        items = PIN_AXIS_ITEMS,
        default = "Y_NEG",
    )

    def draw(self, context):
        self.layout.prop(self, "position_mode", text = "Position")
        if self.position_mode == "MODE_3":
            self.layout.prop(self, "pin_axis", text = "Axis")
        else:
            axis_row = self.layout.row()
            axis_row.enabled = False
            axis_row.label(text = "Axis: N/A")

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def invoke(self, context, event):
        selected_pin = _pin_virtual_selected_target_data(context)
        bones = _selected_pose_bones_only(context)
        if not bones and selected_pin is None:
            return {"CANCELLED"}
        pinned = set(_state.get("yellow_modes", {}).keys())
        selected_keys = _selected_owner_bone_keys(
            context,
            include_virtual_pin=True,
        )
        if selected_keys.intersection(pinned):
            bpy.ops.wm.call_menu(name = "ANIMATOR_UTILS_MT_yellow_pin_menu")
            return {"CANCELLED"}
        self.position_mode = str(
            getattr(context.window_manager, "yellow_pin_mode", "MODE_3")
        )
        self.pin_axis = str(
            getattr(context.window_manager, "yellow_pin_axis", "Y_NEG")
        )
        return self.execute(context)

    def execute(self, context):
        grouped = _selected_pose_bones_by_owner(
            context,
            include_active_fallback=True,
        )
        if not grouped:
            return {"CANCELLED"}
        changed = 0
        for armature, pose_bones in grouped.items():
            owner_changed, _unreachable = _yellow_apply_to_armature(
                context,
                armature,
                pose_bones,
                self.position_mode,
                pin_axis=self.pin_axis,
            )
            changed += owner_changed
        if not changed:
            return {"CANCELLED"}
        _yellow_refresh_runtime(context)
        return {"FINISHED"}
