"""Onion-skin geometry collection and smart anchor helpers."""

from ..core.runtime import *  # noqa: F403

def _collect_world_shape_from_largest_components(context, depsgraph, arm, eval_arm, only_names, objs = None):
    if objs is None:
        objs, _ = _targets(context)

    min_w = 0.05
    per_bone = {bn: [] for bn in only_names}

    for obj in objs:
        if obj.type != "MESH":
            continue
        if not _is_object_visible(obj, context):
            continue

        eval_obj = obj.evaluated_get(depsgraph)
        mw = eval_obj.matrix_world

        mesh = eval_obj.to_mesh(preserve_all_data_layers = False, depsgraph = depsgraph)
        if not mesh:
            continue

        for bn in only_names:
            vg = None
            try:
                vg = obj.vertex_groups.get(bn)
            except Exception:
                vg = None
            if not vg:
                continue

            vg_i = int(vg.index)

            b_world = None
            for v in mesh.vertices:
                w = 0.0
                for g in v.groups:
                    if int(g.group) == vg_i:
                        w = float(g.weight)
                        break
                if w < float(min_w):
                    continue

                p_world = mw @ v.co
                if b_world is None:
                    b_world = _bounds_init(p_world)
                else:
                    _bounds_add(b_world, p_world)

            if b_world is None:
                continue

            dx = float(b_world[3] - b_world[0])
            dy = float(b_world[4] - b_world[1])
            dz = float(b_world[5] - b_world[2])
            vol = max(0.0, dx) * max(0.0, dy) * max(0.0, dz)

            per_bone[bn].append((vol, b_world))

        eval_obj.to_mesh_clear()

    out = {}
    keep_ratio = 0.25
    keep_max = 6

    for bn, items in per_bone.items():
        if not items:
            continue

        items.sort(key = lambda x: float(x[0]), reverse = True)
        max_vol = float(items[0][0])
        cutoff = max_vol * keep_ratio

        keep = []
        for vol, b in items:
            if len(keep) >= keep_max:
                break
            if len(keep) == 0 or float(vol) >= cutoff:
                keep.append(b)

        merged = None
        for b in keep:
            if merged is None:
                merged = list(b)
            else:
                merged[0] = min(merged[0], b[0])
                merged[1] = min(merged[1], b[1])
                merged[2] = min(merged[2], b[2])
                merged[3] = max(merged[3], b[3])
                merged[4] = max(merged[4], b[4])
                merged[5] = max(merged[5], b[5])

        if merged is not None:
            out[bn] = merged

    return out


def _rig_local_lower_bone_endpoint(eval_arm, pose_bone):
    endpoint = pose_bone.head if pose_bone.head.z <= pose_bone.tail.z else pose_bone.tail
    return eval_arm.matrix_world @ endpoint


def _pose_bone_numeric_family_levels(eval_arm, pose_bone):
    canonical_name = _strip_blender_numeric_suffix(pose_bone.name)
    levels = []

    canonical_bone = eval_arm.pose.bones.get(canonical_name)
    if canonical_bone is not None:
        levels.append({canonical_bone.name})

    prefix = f"{canonical_name}."
    variants = []
    for bone in eval_arm.pose.bones:
        if not bone.name.startswith(prefix):
            continue
        suffix = bone.name[len(prefix):]
        if suffix.isdigit():
            variants.append((int(suffix), bone.name))

    if variants:
        variants.sort(key = lambda item: (item[0], item[1]))
        levels.append({name for _number, name in variants})

    if not levels:
        levels.append({pose_bone.name})

    return levels


def _node_tree_has_linked_base_color(node_tree, visited = None):
    if node_tree is None:
        return False
    if visited is None:
        visited = set()

    pointer = node_tree.as_pointer()
    if pointer in visited:
        return False
    visited.add(pointer)

    for node in node_tree.nodes:
        if node.type == "BSDF_PRINCIPLED":
            base_color = node.inputs.get("Base Color")
            if base_color and base_color.is_linked:
                return True
        if (
            node.type == "GROUP"
            and getattr(node, "node_tree", None)
            and _node_tree_has_linked_base_color(node.node_tree, visited)
        ):
            return True
    return False


def _object_has_linked_base_color(obj):
    materials = getattr(getattr(obj, "data", None), "materials", ())
    return any(
        _node_tree_has_linked_base_color(getattr(material, "node_tree", None))
        for material in materials
        if material is not None
    )


def _rigid_object_smart_anchor(
    arm,
    eval_arm,
    eval_obj,
    controller_bone_name,
    axis = "Y_NEG",
):
    local_points = [Vector(corner) for corner in eval_obj.bound_box]
    points = [eval_obj.matrix_world @ point for point in local_points]
    if not local_points:
        return None, points, 0.0

    local_bounds = _bounds_init(local_points[0])
    for point in local_points[1:]:
        _bounds_add(local_bounds, point)

    center = Vector((
        (float(local_bounds[0]) + float(local_bounds[3])) * 0.5,
        (float(local_bounds[1]) + float(local_bounds[4])) * 0.5,
        (float(local_bounds[2]) + float(local_bounds[5])) * 0.5,
        1.0,
    ))
    axis_index, bound_index = {
        "X_POS": (0, 3),
        "X_NEG": (0, 0),
        "Y_POS": (1, 4),
        "Y_NEG": (1, 1),
        "Z_POS": (2, 5),
        "Z_NEG": (2, 2),
    }.get(str(axis), (1, 1))
    center[axis_index] = float(local_bounds[bound_index])
    local_anchor = center

    dx = float(local_bounds[3] - local_bounds[0])
    dy = float(local_bounds[4] - local_bounds[1])
    dz = float(local_bounds[5] - local_bounds[2])
    volume = max(0.0, dx) * max(0.0, dy) * max(0.0, dz)
    return local_anchor, points, volume
