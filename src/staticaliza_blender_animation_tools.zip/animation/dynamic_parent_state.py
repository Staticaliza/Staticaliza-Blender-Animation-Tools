"""Dynamic Parent constraint metadata, segments, and active-state selection."""

from ..core.runtime import *  # noqa: F403

def _dynamic_parent_owner_action(owner):
    if owner is None:
        return None
    try:
        animated_id = getattr(owner, "id_data", None) or owner
        animation_data = getattr(animated_id, "animation_data", None)
    except ReferenceError:
        return None
    return getattr(animation_data, "action", None)


def _dynamic_parent_segment_property_name(constraint):
    digest = hashlib.sha1(str(constraint.name).encode("utf-8")).hexdigest()[:16]
    return f"{DP_SEGMENT_PROPERTY_PREFIX}{digest}"


def _dynamic_parent_boundary_property_name(constraint):
    digest = hashlib.sha1(str(constraint.name).encode("utf-8")).hexdigest()[:16]
    return f"{DP_BOUNDARY_CALIBRATED_PROPERTY_PREFIX}{digest}"


def _dynamic_parent_marker_property_name(constraint):
    digest = hashlib.sha1(str(constraint.name).encode("utf-8")).hexdigest()[:16]
    return f"{DP_MARKER_PROPERTY_PREFIX}{digest}"


def _dynamic_parent_marker_data_path(constraint, legacy = False):
    if constraint is None:
        return ""
    if legacy:
        try:
            return constraint.path_from_id("influence")
        except (AttributeError, ReferenceError, TypeError, ValueError):
            return ""
    try:
        constraint_path = constraint.path_from_id()
    except (AttributeError, ReferenceError, TypeError, ValueError):
        return ""
    owner_path = constraint_path.split(".constraints[", 1)[0]
    if constraint_path.startswith("constraints["):
        owner_path = ""
    property_path = f'["{_dynamic_parent_marker_property_name(constraint)}"]'
    return f"{owner_path}{property_path}" if owner_path else property_path


def _dynamic_parent_marker_fcurves(owner, constraint):
    action = _dynamic_parent_owner_action(owner)
    marker_path = _dynamic_parent_marker_data_path(constraint)
    marker_curves = (
        tuple(_fcurves_find_all(action, marker_path))
        if action is not None and marker_path
        else ()
    )
    if marker_curves:
        return marker_curves
    legacy_path = _dynamic_parent_marker_data_path(constraint, legacy = True)
    return (
        tuple(_fcurves_find_all(action, legacy_path))
        if action is not None and legacy_path
        else ()
    )


def _mark_dynamic_parent_boundary_calibrated(owner, constraint, start):
    if owner is None or constraint is None or start is None:
        return False
    property_name = _dynamic_parent_boundary_property_name(constraint)
    value = int(start)
    if owner.get(property_name) == value:
        return False
    owner[property_name] = value
    return True


def _dynamic_parent_boundary_is_calibrated(owner, constraint, start):
    if owner is None or constraint is None or start is None:
        return False
    try:
        return int(owner.get(
            _dynamic_parent_boundary_property_name(constraint),
            SPACE_MIN_FRAME - 1,
        )) == int(start)
    except (TypeError, ValueError):
        return False


def _is_dynamic_state_constraint(constraint):
    name = str(getattr(constraint, "name", ""))
    return name.startswith("DP_") or name.startswith(SPACE_CONSTRAINT_PREFIX)


def _dynamic_space_role_property_name(constraint):
    digest = hashlib.sha1(str(constraint.name).encode("utf-8")).hexdigest()[:16]
    return f"{SPACE_ROLE_PROPERTY_PREFIX}{digest}"


def _store_dynamic_space_role(owner, constraint, role):
    owner[_dynamic_space_role_property_name(constraint)] = str(role)


def _dynamic_space_role(owner, constraint):
    return str(owner.get(_dynamic_space_role_property_name(constraint), ""))


def _dynamic_space_source_property_name(constraint):
    digest = hashlib.sha1(str(constraint.name).encode("utf-8")).hexdigest()[:16]
    return f"{SPACE_SOURCE_PROPERTY_PREFIX}{digest}"


def _store_dynamic_space_source(owner, constraint, source):
    owner[_dynamic_space_source_property_name(constraint)] = str(source)


def _dynamic_space_source(owner, constraint):
    return str(owner.get(_dynamic_space_source_property_name(constraint), ""))


def _dynamic_parent_pose_state(pose_bone):
    if pose_bone is None:
        return None
    rotation_mode = str(pose_bone.rotation_mode)
    if rotation_mode == "QUATERNION":
        rotation_property = "rotation_quaternion"
    elif rotation_mode == "AXIS_ANGLE":
        rotation_property = "rotation_axis_angle"
    else:
        rotation_property = "rotation_euler"
    return {
        "location": tuple(float(value) for value in pose_bone.location),
        "scale": tuple(float(value) for value in pose_bone.scale),
        "rotation_mode": rotation_mode,
        "rotation_property": rotation_property,
        "rotation": tuple(
            float(value) for value in getattr(pose_bone, rotation_property)
        ),
    }


def _dynamic_parent_restore_pose_state(pose_bone, state):
    if pose_bone is None or not state:
        return False
    changed = False
    rotation_mode = str(state.get("rotation_mode", pose_bone.rotation_mode))
    if str(pose_bone.rotation_mode) != rotation_mode:
        pose_bone.rotation_mode = rotation_mode
        changed = True
    location = tuple(state.get("location", ()))
    if len(location) == 3 and any(
        abs(float(pose_bone.location[index]) - float(location[index]))
        > 0.0
        for index in range(3)
    ):
        pose_bone.location = location
        changed = True
    scale = tuple(state.get("scale", ()))
    if len(scale) == 3 and any(
        abs(float(pose_bone.scale[index]) - float(scale[index]))
        > 0.0
        for index in range(3)
    ):
        pose_bone.scale = scale
        changed = True
    rotation_property = str(state.get("rotation_property", ""))
    rotation = tuple(state.get("rotation", ()))
    current_rotation = getattr(pose_bone, rotation_property, ())
    if len(rotation) == len(current_rotation) and any(
        abs(float(current_rotation[index]) - float(rotation[index]))
        > 0.0
        for index in range(len(rotation))
    ):
        setattr(pose_bone, rotation_property, rotation)
        changed = True
    return changed


def _dynamic_parent_pose_state_matches(pose_bone, state, tolerance=0.0):
    if pose_bone is None or not state:
        return False
    rotation_mode = str(state.get("rotation_mode", ""))
    rotation_property = str(state.get("rotation_property", ""))
    if (
        str(pose_bone.rotation_mode) != rotation_mode
        or not rotation_property
        or not hasattr(pose_bone, rotation_property)
    ):
        return False
    current_groups = (
        tuple(float(value) for value in pose_bone.location),
        tuple(float(value) for value in pose_bone.scale),
        tuple(float(value) for value in getattr(pose_bone, rotation_property)),
    )
    saved_groups = (
        tuple(float(value) for value in state.get("location", ())),
        tuple(float(value) for value in state.get("scale", ())),
        tuple(float(value) for value in state.get("rotation", ())),
    )
    return all(
        len(current) == len(saved)
        and all(
            abs(float(current[index]) - float(saved[index])) <= tolerance
            for index in range(len(saved))
        )
        for current, saved in zip(current_groups, saved_groups)
    )


def _dynamic_parent_space_state(pose_bone):
    if pose_bone is None:
        return None
    constraints = []
    for constraint in pose_bone.constraints:
        if not _is_dynamic_state_constraint(constraint):
            continue
        if not (
            str(constraint.name).startswith("DP_")
            or _dynamic_space_source(pose_bone, constraint).startswith(
                SPACE_SOURCE_DYNAMIC_PARENT_PREFIX
            )
        ):
            continue
        target = _dynamic_parent_constraint_target(pose_bone, constraint)
        constraints.append({
            "name": str(constraint.name),
            "target": str(getattr(target, "name", "")),
            "subtarget": str(
                _dynamic_parent_constraint_subtarget(pose_bone, constraint)
            ),
            "connected": constraint.target is not None,
            "inverse": constraint.inverse_matrix.copy(),
            "influence": float(constraint.influence),
            "mute": bool(constraint.mute),
        })
    return tuple(constraints)


def _dynamic_parent_restore_space_state(pose_bone, state):
    if pose_bone is None or state is None:
        return False
    by_name = {str(constraint.name): constraint for constraint in pose_bone.constraints}
    changed = False
    for saved in state:
        constraint = by_name.get(str(saved.get("name", "")))
        if constraint is None or constraint.type != "CHILD_OF":
            continue
        target = _dynamic_parent_constraint_target(pose_bone, constraint)
        if (
            str(getattr(target, "name", "")) != str(saved.get("target", ""))
            or str(_dynamic_parent_constraint_subtarget(pose_bone, constraint))
            != str(saved.get("subtarget", ""))
        ):
            continue
        connected = bool(saved.get("connected", True))
        if connected and constraint.target is None:
            changed = _restore_dynamic_parent_constraint_target(
                pose_bone, constraint,
            ) or changed
        elif not connected and constraint.target is not None:
            _store_dynamic_parent_constraint_target(pose_bone, constraint)
            constraint.target = None
            constraint.subtarget = ""
            changed = True
        inverse = saved.get("inverse")
        if inverse is not None and not _matrices_nearly_equal(
            constraint.inverse_matrix,
            inverse,
            tolerance=0.0,
        ):
            constraint.inverse_matrix = inverse.copy()
            changed = True
        influence = float(saved.get("influence", constraint.influence))
        if abs(float(constraint.influence) - influence) > 0.0:
            constraint.influence = influence
            changed = True
        mute = bool(saved.get("mute", constraint.mute))
        if bool(constraint.mute) != mute:
            constraint.mute = mute
            changed = True
    return changed


def _dynamic_parent_space_state_matches(pose_bone, state, tolerance=0.0):
    if pose_bone is None or state is None:
        return False
    current = {saved["name"]: saved for saved in _dynamic_parent_space_state(pose_bone)}
    if len(current) != len(state):
        return False
    for saved in state:
        live = current.get(str(saved.get("name", "")))
        if live is None:
            return False
        if (
            live["target"] != str(saved.get("target", ""))
            or live["subtarget"] != str(saved.get("subtarget", ""))
            or live["connected"] != bool(saved.get("connected", True))
            or live["mute"] != bool(saved.get("mute", False))
            or abs(live["influence"] - float(saved.get("influence", 0.0))) > tolerance
        ):
            return False
        inverse = saved.get("inverse")
        if inverse is None or not _matrices_nearly_equal(
            live["inverse"], inverse, tolerance=tolerance,
        ):
            return False
    return True




def _dynamic_parent_target_property_names(constraint):
    digest = hashlib.sha1(str(constraint.name).encode("utf-8")).hexdigest()[:16]
    return (
        f"{DP_TARGET_PROPERTY_PREFIX}{digest}",
        f"{DP_SUBTARGET_PROPERTY_PREFIX}{digest}",
    )


def _store_dynamic_parent_constraint_target(owner, constraint):
    if owner is None or constraint is None or constraint.target is None:
        return False
    target_property, subtarget_property = _dynamic_parent_target_property_names(
        constraint
    )
    try:
        owner[target_property] = constraint.target
        owner[subtarget_property] = str(constraint.subtarget)
        return True
    except (AttributeError, RuntimeError, TypeError):
        return False


def _restore_dynamic_parent_constraint_target(owner, constraint):
    if constraint.target is not None:
        return True
    target_property, subtarget_property = _dynamic_parent_target_property_names(
        constraint
    )
    target = owner.get(target_property, None)
    if target is None:
        return False
    constraint.target = target
    constraint.subtarget = str(owner.get(subtarget_property, ""))
    return True


def _dynamic_parent_constraint_target(owner, constraint):
    if constraint is None:
        return None
    if constraint.target is not None:
        return constraint.target
    target_property, _subtarget_property = _dynamic_parent_target_property_names(
        constraint
    )
    return owner.get(target_property, None)


def _dynamic_parent_constraint_subtarget(owner, constraint):
    if constraint is None:
        return ""
    if constraint.target is not None:
        return str(constraint.subtarget)
    _target_property, subtarget_property = _dynamic_parent_target_property_names(
        constraint
    )
    return str(owner.get(subtarget_property, ""))


def _remove_dynamic_parent_constraint_metadata(owner, constraint):
    property_names = (
        _dynamic_parent_segment_property_name(constraint),
        _dynamic_parent_boundary_property_name(constraint),
        _dynamic_parent_marker_property_name(constraint),
        _dynamic_space_role_property_name(constraint),
        _dynamic_space_source_property_name(constraint),
        *_dynamic_parent_target_property_names(constraint),
    )
    for property_name in property_names:
        if property_name in owner:
            del owner[property_name]


def _restore_all_dynamic_parent_constraint_targets():
    for obj in tuple(bpy.data.objects):
        owners = [obj]
        if obj.type == "ARMATURE" and getattr(obj, "pose", None) is not None:
            owners.extend(obj.pose.bones)

        for owner in owners:
            for constraint in getattr(owner, "constraints", ()):
                if not _is_dynamic_state_constraint(constraint):
                    continue
                _restore_dynamic_parent_constraint_target(owner, constraint)
                constraint.mute = False


def _store_dynamic_parent_constraint_segment(owner, constraint, start, end = None):
    if owner is None or constraint is None:
        return False
    try:
        property_name = _dynamic_parent_segment_property_name(constraint)
        existing = owner.get(property_name)
        existing_start = (
            int(existing[0])
            if existing is not None and len(existing) >= 1
            else None
        )
        if existing_start is not None and existing_start != int(start):
            calibrated_property = _dynamic_parent_boundary_property_name(
                constraint
            )
            if calibrated_property in owner:
                del owner[calibrated_property]
        owner[property_name] = [
            int(start),
            int(end) if end is not None else -1,
        ]
        return True
    except (AttributeError, RuntimeError, TypeError):
        return False


def _stored_dynamic_parent_constraint_segment(owner, constraint):
    if constraint is None or not _is_dynamic_state_constraint(constraint):
        return (None, None)

    metadata = owner.get(
        _dynamic_parent_segment_property_name(constraint),
        None,
    )
    try:
        start = metadata[0] if metadata is not None and len(metadata) >= 1 else None
        end = metadata[1] if metadata is not None and len(metadata) >= 2 else None
    except TypeError:
        start = None
        end = None
    try:
        start = int(start) if start is not None else None
    except (TypeError, ValueError):
        start = None
    try:
        end = int(end) if end is not None and int(end) >= 0 else None
    except (TypeError, ValueError):
        end = None
    return (start, end)


def _dynamic_parent_constraint_segment(owner, constraint, persist = False):
    if constraint is None or not _is_dynamic_state_constraint(constraint):
        return (None, None)

    start, end = _stored_dynamic_parent_constraint_segment(owner, constraint)

    action = _dynamic_parent_owner_action(owner)
    fcurve = None
    is_dynamic_parent = constraint.name.startswith("DP_")
    if is_dynamic_parent:
        fcurves = _dynamic_parent_marker_fcurves(owner, constraint)
        fcurve = fcurves[0] if fcurves else None
    if is_dynamic_parent and (fcurve is None or not fcurve.keyframe_points):
        return (None, None)
    if fcurve is not None and fcurve.keyframe_points:
        curve_start = None
        curve_end = None
        active = False
        for key in sorted(
            fcurve.keyframe_points,
            key = lambda point: float(point.co.x),
        ):
            key_frame = int(round(float(key.co.x)))
            next_active = float(key.co.y) > 0.5
            if next_active and not active and curve_start is None:
                curve_start = key_frame
            elif active and not next_active and curve_start is not None:
                curve_end = key_frame
                break
            active = next_active
        if curve_start is None:
            return (None, None)
        start = curve_start
        end = curve_end

    if persist and start is not None:
        _store_dynamic_parent_constraint_segment(
            owner,
            constraint,
            start,
            end,
        )
    return (start, end)


def _dynamic_parent_constraint_active_at(owner, constraint, frame):
    start, end = _dynamic_parent_constraint_segment(owner, constraint)
    if start is None:
        if constraint.name.startswith("DP_"):
            return False
        return float(getattr(constraint, "influence", 0.0)) > 0.5
    frame = int(frame)
    return frame >= int(start) and (end is None or frame < int(end))


def _constraint_segment_start(owner, constraint):
    start, _end = _stored_dynamic_parent_constraint_segment(owner, constraint)
    return int(start) if start is not None else SPACE_MIN_FRAME


def _marker_aware_internal_constraint(owner, constraints, frame):
    active_by_segment = [
        constraint
        for constraint in constraints
        if _dynamic_parent_constraint_active_at(owner, constraint, frame)
    ]
    if not isinstance(owner, bpy.types.PoseBone):
        return (active_by_segment or [None])[-1]

    action = _dynamic_parent_owner_action(owner)
    points = _unparent_points(action, owner.name) if action is not None else []
    has_unparent_spaces = any(
        _dynamic_space_role(owner, constraint) == SPACE_ROLE_UNPARENT
        for constraint in constraints
    )
    if not points and not has_unparent_spaces:
        return (active_by_segment or [None])[-1]

    state = False
    active_start = None
    last_transition = None
    for point_frame, value in points:
        if int(point_frame) > int(frame):
            break
        next_state = float(value) >= 0.5
        if next_state and not state:
            active_start = int(point_frame)
        elif state and not next_state:

            active_start = None
        state = next_state
        last_transition = (int(point_frame), float(value))

    if state:
        candidates = [
            constraint
            for constraint in constraints
            if _dynamic_space_role(owner, constraint) == SPACE_ROLE_UNPARENT
        ]
        eligible = [
            constraint
            for constraint in candidates
            if _constraint_segment_start(owner, constraint) <= int(frame)
            and (
                active_start is None
                or _constraint_segment_start(owner, constraint) >= int(active_start)
            )
        ]
        if eligible:
            return max(
                eligible,
                key = lambda constraint: _constraint_segment_start(owner, constraint),
            )
        if active_start is not None:
            return min(
                candidates,
                key = lambda constraint: abs(
                    _constraint_segment_start(owner, constraint) - int(active_start)
                ),
                default = None,
            )
        return (candidates or [None])[-1]

    normal_roles = {SPACE_ROLE_NORMAL, SPACE_ROLE_WORLD}
    candidates = [
        constraint
        for constraint in constraints
        if _dynamic_space_role(owner, constraint) in normal_roles
    ]
    if last_transition is None:
        base = next(
            (
                constraint
                for constraint in candidates
                if _dynamic_space_source(owner, constraint) == SPACE_SOURCE_BASE
            ),
            None,
        )
        return base or (active_by_segment or candidates or [None])[-1]

    transition_frame = int(last_transition[0])
    return min(
        candidates,
        key = lambda constraint: (
            abs(_constraint_segment_start(owner, constraint) - transition_frame),
            -_constraint_segment_start(owner, constraint),
        ),
        default = None,
    )


def _chosen_dynamic_parent_constraint(owner, frame):
    constraints = [
        constraint
        for constraint in getattr(owner, "constraints", ())
        if _is_dynamic_state_constraint(constraint)
    ]
    active_dynamic_parent = [
        constraint
        for constraint in constraints
        if constraint.name.startswith("DP_")
        and _dynamic_parent_constraint_active_at(owner, constraint, frame)
    ]
    internal = [
        constraint
        for constraint in constraints
        if constraint.name.startswith(SPACE_CONSTRAINT_PREFIX)
    ]
    return (
        active_dynamic_parent
        or [_marker_aware_internal_constraint(owner, internal, frame)]
    )[-1]


def _set_dynamic_parent_owner_constraint(owner, chosen):
    changed = False
    constraints = [
        constraint
        for constraint in getattr(owner, "constraints", ())
        if _is_dynamic_state_constraint(constraint)
    ]

    for constraint in constraints:
        active = constraint == chosen
        disconnect_inactive_parent = bool(
            constraint.name.startswith("DP_") and not active
        )
        if disconnect_inactive_parent and constraint.target is not None:
            _store_dynamic_parent_constraint_target(owner, constraint)
            constraint.target = None
            constraint.subtarget = ""
            changed = True
        elif not disconnect_inactive_parent and constraint.target is None:
            changed = _restore_dynamic_parent_constraint_target(
                owner,
                constraint,
            ) or changed
        elif active:
            _store_dynamic_parent_constraint_target(owner, constraint)
        influence = 1.0 if active else 0.0
        if abs(float(constraint.influence) - influence) > 1.0e-6:
            constraint.influence = influence
            changed = True
        if bool(constraint.mute) == bool(active):
            constraint.mute = not active
            changed = True
    return changed

def get_last_dynamic_parent_constraint(obj, frame = None):
    if obj is None or not getattr(obj, "constraints", None):
        return None
    if frame is None:
        frame = int(bpy.context.scene.frame_current)
    for constraint in reversed(obj.constraints):
        if (
            constraint.name.startswith("DP_")
            and _dynamic_parent_constraint_active_at(obj, constraint, frame)
        ):
            return constraint
    return None
