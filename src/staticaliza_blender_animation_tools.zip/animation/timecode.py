"""Frame-accurate animation length parsing and viewport timecode formatting."""

from ..core.runtime import *  # noqa: F403


ROBLOX_ANIMATION_LENGTH_PROPERTY = "roblox_animation_length"


def _redraw_animation_length_controls():
    """Refresh every viewport panel when Blender's range fields change."""
    _tag_redraw_all_view3d()


def _unsubscribe_animation_range_redraw():
    owner = _state.pop("animation_range_msgbus_owner", None)
    if owner is None:
        return
    try:
        bpy.msgbus.clear_by_owner(owner)
    except (AttributeError, ReferenceError, RuntimeError):
        pass


def _subscribe_animation_range_redraw():
    _unsubscribe_animation_range_redraw()
    owner = object()
    _state["animation_range_msgbus_owner"] = owner
    for property_name in ("frame_start", "frame_end"):
        bpy.msgbus.subscribe_rna(
            key = (bpy.types.Scene, property_name),
            owner = owner,
            args = (),
            notify = _redraw_animation_length_controls,
            options = {"PERSISTENT"},
        )


def _scene_nominal_fps(scene):
    render = getattr(scene, "render", None)
    fps = float(getattr(render, "fps", 60.0) or 60.0)
    fps_base = float(getattr(render, "fps_base", 1.0) or 1.0)
    return max(1, int(round(fps / fps_base)))


def _animation_length_frames(scene):
    frame_start = int(getattr(scene, "frame_start", 0))
    frame_end = int(getattr(scene, "frame_end", frame_start))
    return max(0, frame_end - frame_start)


def _format_frame_timecode(frame_count, fps, reference_frames = None):
    frames = max(0, int(frame_count))
    nominal_fps = max(1, int(fps))
    reference = frames if reference_frames is None else max(0, int(reference_frames))
    whole_seconds, subframe = divmod(frames, nominal_fps)
    reference_seconds = reference // nominal_fps
    frame_width = max(2, len(str(nominal_fps - 1)))

    hours, remainder = divmod(whole_seconds, 3600)
    minutes, seconds = divmod(remainder, 60)
    if reference_seconds >= 3600 or hours:
        return (
            f"{hours}:{minutes:02d}:{seconds:02d}:"
            f"{subframe:0{frame_width}d}"
        )
    if reference_seconds >= 60 or minutes:
        return f"{minutes}:{seconds:02d}:{subframe:0{frame_width}d}"
    if reference_seconds >= 10:
        return f"{seconds:02d}:{subframe:0{frame_width}d}"
    return f"{seconds}:{subframe:0{frame_width}d}"


def _parse_animation_length(text, fps):
    value = str(text).strip()
    if not value:
        raise ValueError("Animation length cannot be empty")
    nominal_fps = max(1, int(fps))
    if ":" not in value:
        frame_text = value[:-1] if value.casefold().endswith("f") else value
        return max(0, int(frame_text.strip()))

    fields = value.split(":")
    if len(fields) not in {2, 3, 4}:
        raise ValueError("Use SS:FF, MM:SS:FF, or HH:MM:SS:FF")
    values = [int(field.strip() or "0") for field in fields]
    if any(number < 0 for number in values):
        raise ValueError("Animation length cannot be negative")

    subframe = values[-1]
    time_fields = values[:-1]
    if len(time_fields) == 1:
        seconds = time_fields[0]
    elif len(time_fields) == 2:
        seconds = (time_fields[0] * 60) + time_fields[1]
    else:
        seconds = (
            (time_fields[0] * 3600)
            + (time_fields[1] * 60)
            + time_fields[2]
        )
    return max(0, (seconds * nominal_fps) + subframe)


def _get_roblox_animation_length(scene):
    length = _animation_length_frames(scene)
    return _format_frame_timecode(
        length,
        _scene_nominal_fps(scene),
        reference_frames = length,
    )


def _set_roblox_animation_length(scene, value):
    try:
        length = _parse_animation_length(value, _scene_nominal_fps(scene))
    except (TypeError, ValueError):
        return
    frame_start = int(getattr(scene, "frame_start", 0))
    scene.frame_end = frame_start + length
    _tag_redraw_all_view3d()


def _pose_timecode_text(scene):
    frame_start = int(getattr(scene, "frame_start", 0))
    current = max(0, int(getattr(scene, "frame_current", frame_start)) - frame_start)
    length = _animation_length_frames(scene)
    timecode = _format_frame_timecode(
        current,
        _scene_nominal_fps(scene),
        reference_frames = length,
    )
    looped = bool(getattr(scene, ROBLOX_ANIMATION_LOOP_PROPERTY, False))
    return f"{timecode} | {current}f | Looped: {str(looped).lower()}"
