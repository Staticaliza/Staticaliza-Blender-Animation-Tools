"""Shared runtime state and Blender registration lifecycle."""
