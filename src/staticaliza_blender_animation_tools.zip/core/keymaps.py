"""Addon keymap registration and legacy shortcut cleanup."""

from .runtime import *  # noqa: F403


class ANIMATOR_UTILS_OT_toggle_loop_tab(bpy.types.Operator):
    bl_idname = "staticaliza.toggle_loop_tab"
    bl_label = "Toggle Animation Loop"
    bl_description = "Toggle animation looping in the Animate and Graph workspaces"

    @classmethod
    def poll(cls, context):
        if getattr(context, "mode", "") == "POSE":
            return True
        # Selecting an object row in the Outliner can make that area's
        # context report OBJECT even while the animation workspace remains
        # in the rig's Pose workflow. Keep Tab available for that case only.
        area = getattr(context, "area", None)
        workspace = getattr(context, "workspace", None) or getattr(
            getattr(context, "window", None),
            "workspace",
            None,
        )
        workspace_name = _strip_blender_numeric_suffix(
            str(getattr(workspace, "name", ""))
        ).casefold()
        return (
            getattr(area, "type", "") == "OUTLINER"
            and workspace_name in {"animate", "animation", "graph"}
        )

    def execute(self, context):
        workspace = getattr(context, "workspace", None) or getattr(
            getattr(context, "window", None),
            "workspace",
            None,
        )
        workspace_name = str(getattr(workspace, "name", ""))
        workspace_name = _strip_blender_numeric_suffix(workspace_name)
        if workspace_name.casefold() in {"animate", "animation", "graph"}:
            scene = getattr(context, "scene", None)
            if scene is not None and hasattr(scene, ROBLOX_ANIMATION_LOOP_PROPERTY):
                setattr(
                    scene,
                    ROBLOX_ANIMATION_LOOP_PROPERTY,
                    not bool(getattr(scene, ROBLOX_ANIMATION_LOOP_PROPERTY)),
                )
        return {"FINISHED"}


def _register_loop_tab_keymap(keyconfig, name, space_type):
    keymap = keyconfig.keymaps.new(
        name = name,
        space_type = space_type,
        region_type = "WINDOW",
    )
    item = keymap.keymap_items.new(
        ANIMATOR_UTILS_OT_toggle_loop_tab.bl_idname,
        type = "TAB",
        value = "PRESS",
        head = True,
    )
    _keymaps.append((keymap, item))
    return keymap

def _unregister_addon_keymaps():
    for km, kmi in _keymaps:
        try:
            km.keymap_items.remove(kmi)
        except (ReferenceError, RuntimeError):
            pass
    _keymaps.clear()
    _state["pin_click_away_keymap_item"] = None


def _remove_legacy_alt_f_keymaps(keyconfig):
    if keyconfig is None:
        return 0
    removed = 0
    for keymap in keyconfig.keymaps:
        for keymap_item in tuple(keymap.keymap_items):
            if keymap_item.idname not in LEGACY_ALT_F_OPERATOR_IDS:
                continue
            if not (
                keymap_item.type == "F"
                and keymap_item.value == "PRESS"
                and keymap_item.alt
                and not keymap_item.ctrl
                and not keymap_item.shift
            ):
                continue
            try:
                keymap.keymap_items.remove(keymap_item)
                removed += 1
            except (ReferenceError, RuntimeError):
                pass
    return removed


def _remove_stale_mouse_keymaps(keyconfig):
    """Remove mouse hooks left behind by an older live-installed build."""
    if keyconfig is None:
        return 0
    removed = 0
    operator_ids = {
        "staticaliza.track_rig_hover",
        "staticaliza.pin_click_away",
    }
    for keymap in keyconfig.keymaps:
        for keymap_item in tuple(keymap.keymap_items):
            if keymap_item.idname not in operator_ids:
                continue
            try:
                keymap.keymap_items.remove(keymap_item)
                removed += 1
            except (ReferenceError, RuntimeError):
                pass
    return removed


def _remove_legacy_editor_tab_keymaps(keyconfig):
    """Remove Blender/user Tab actions that conflict with Loop in editors."""
    if keyconfig is None:
        return 0
    target_maps = frozenset({
        "Dopesheet Generic",
        "Dopesheet",
        "Graph Editor",
        "Graph Editor Generic",
        "Outliner",
        "Property Editor",
        "Animation",
    })
    removed = 0
    for keymap in keyconfig.keymaps:
        if keymap.name not in target_maps:
            continue
        for keymap_item in tuple(keymap.keymap_items):
            if keymap_item.type != "TAB" or keymap_item.value != "PRESS":
                continue
            try:
                keymap.keymap_items.remove(keymap_item)
                removed += 1
            except (ReferenceError, RuntimeError):
                pass
    return removed


def _remove_legacy_editor_shortcut_keymaps(keyconfig):
    """Clear editor-local F/Y conflicts before installing our bindings."""
    if keyconfig is None:
        return 0
    target_maps = frozenset({
        "Dopesheet Generic",
        "Dopesheet",
        "Graph Editor",
        "Graph Editor Generic",
    })
    targets = {
        ("F", False, False),
        ("Y", False, False),
        ("Y", True, False),
    }
    removed = 0
    for keymap in keyconfig.keymaps:
        if keymap.name not in target_maps:
            continue
        for keymap_item in tuple(keymap.keymap_items):
            signature = (
                str(keymap_item.type),
                bool(keymap_item.shift),
                bool(keymap_item.ctrl),
            )
            if (
                signature not in targets
                or keymap_item.value != "PRESS"
                or bool(keymap_item.alt)
            ):
                continue
            try:
                keymap.keymap_items.remove(keymap_item)
                removed += 1
            except (ReferenceError, RuntimeError):
                pass
    return removed


def _register_editor_animation_shortcuts(keymap):
    for operator_id, event_type, shift in (
        ("onion_skin.ghost_toggle", "F", False),
        ("staticaliza.set_transform_orientation", "Y", False),
        ("staticaliza.set_pivot_mode", "Y", True),
    ):
        item = keymap.keymap_items.new(
            operator_id,
            type=event_type,
            value="PRESS",
            shift=shift,
            head=True,
        )
        _keymaps.append((keymap, item))


def _register_addon_keymaps():
    try:
        wm = bpy.context.window_manager
    except AttributeError:
        return False
    keyconfigs = wm.keyconfigs if wm else None
    kc = keyconfigs.addon if keyconfigs else None
    if kc is None:
        return False

    # Pointer hooks from older live-installed builds can survive in Blender's
    # effective user keyconfig after their add-on keymap items are removed.
    # Purge both copies before the early return so updating the extension in a
    # running Blender session cannot leave Pose Mode on the Python event path.
    _remove_legacy_alt_f_keymaps(kc)
    _remove_legacy_alt_f_keymaps(getattr(keyconfigs, "user", None))
    _remove_stale_mouse_keymaps(kc)
    _remove_stale_mouse_keymaps(getattr(keyconfigs, "user", None))
    _remove_legacy_editor_tab_keymaps(getattr(keyconfigs, "user", None))
    _remove_legacy_editor_shortcut_keymaps(getattr(keyconfigs, "user", None))

    # A live extension update can retain the old registration list while the
    # module code has gained new bindings. Rebuild the add-on keyconfig so
    # newly introduced editor shortcuts are not skipped until Blender restarts.
    if _keymaps:
        _unregister_addon_keymaps()

    km = _register_loop_tab_keymap(kc, "Pose", "EMPTY")
    for event_type, transform_mode in (
        ("G", "TRANSLATE"),
        ("R", "ROTATE"),
        ("S", "SCALE"),
    ):
        transform_pin = km.keymap_items.new(
            "staticaliza.transform_selected_pin",
            type = event_type,
            value = "PRESS",
            head = True,
        )
        transform_pin.properties.transform_mode = transform_mode
        _keymaps.append((km, transform_pin))
    for event_type, transform_mode in (
        ("G", "TRANSLATE"),
        ("R", "ROTATE"),
    ):
        transform_dragger = km.keymap_items.new(
            "staticaliza.smart_dragger_transform",
            type = event_type,
            value = "PRESS",
            head = True,
        )
        transform_dragger.properties.transform_mode = transform_mode
        _keymaps.append((km, transform_dragger))
    for event_type, reset_mode in (
        ("G", "LOCATION"),
        ("R", "ROTATION"),
        ("S", "SCALE"),
    ):
        clear_contact_transform = km.keymap_items.new(
            "staticaliza.clear_contact_pose_transform",
            type = event_type,
            value = "PRESS",
            alt = True,
            head = True,
        )
        clear_contact_transform.properties.reset_mode = reset_mode
        _keymaps.append((km, clear_contact_transform))
    copy_pins = km.keymap_items.new(
        "staticaliza.pose_pin_clipboard",
        type = "C",
        value = "PRESS",
        ctrl = True,
        head = True,
    )
    copy_pins.properties.action = "COPY"
    _keymaps.append((km, copy_pins))
    paste_pins = km.keymap_items.new(
        "staticaliza.pose_pin_clipboard",
        type = "V",
        value = "PRESS",
        ctrl = True,
        head = True,
    )
    paste_pins.properties.action = "PASTE"
    _keymaps.append((km, paste_pins))
    paste_flipped_pins = km.keymap_items.new(
        "staticaliza.pose_pin_clipboard",
        type = "V",
        value = "PRESS",
        ctrl = True,
        shift = True,
        head = True,
    )
    paste_flipped_pins.properties.action = "PASTE_FLIPPED"
    _keymaps.append((km, paste_flipped_pins))
    # Do not bind LEFTMOUSE. Box Select can consume both CLICK and RELEASE,
    # and a head-priority Python binding can intermittently steal the same
    # press from Blender's native move/rotate gizmos. Click-away is observed
    # by the read-only pointer timer instead.
    _state["pin_click_away_keymap_item"] = None
    _keymaps.append((km, km.keymap_items.new(
        "staticaliza.keyframe_camera_view",
        type = "NUMPAD_0",
        value = "PRESS",
        ctrl = True,
        alt = True,
        head = True,
    )))
    _keymaps.append((km, km.keymap_items.new(
        "onion_skin.ghost_toggle",
        type = "F",
        value = "PRESS",
        head = True,
    )))
    _keymaps.append((km, km.keymap_items.new(
        "staticaliza.yellow_menu",
        type = "F",
        value = "PRESS",
        shift = True,
        head = True,
    )))
    _keymaps.append((km, km.keymap_items.new(
        "dynamic_parent.menu",
        type = "F",
        value = "PRESS",
        ctrl = True,
        head = True,
    )))
    _keymaps.append((km, km.keymap_items.new("staticaliza.set_transform_orientation", type = "Y", value = "PRESS")))
    _keymaps.append((km, km.keymap_items.new("staticaliza.set_pivot_mode", type = "Y", value = "PRESS", shift = True)))
    # Pin selection is owned directly by its tightly bounded
    # Gizmo.test_select callback. The release-only binding above polls false
    # while a bone/native gizmo is selected and exists only for click-away
    # cleanup after a virtual pin has exclusive selection.

    km = kc.keymaps.new(name = "Object Mode", space_type = "EMPTY", region_type = "WINDOW")
    _keymaps.append((km, km.keymap_items.new("staticaliza.set_transform_orientation", type = "Y", value = "PRESS")))

    km = kc.keymaps.new(name = "3D View", space_type = "VIEW_3D", region_type = "WINDOW")
    _keymaps.append((km, km.keymap_items.new(
        "staticaliza.toggle_attached_camera_view",
        type = "NUMPAD_0",
        value = "PRESS",
        head = True,
    )))
    for wheel_type in ("WHEELUPMOUSE", "WHEELDOWNMOUSE"):
        _keymaps.append((km, km.keymap_items.new(
            "staticaliza.attached_camera_wheel_exit",
            type = wheel_type,
            value = "PRESS",
            any = True,
            head = True,
        )))
    middle_mouse_exit = km.keymap_items.new(
        "staticaliza.attached_camera_wheel_exit",
        type = "MIDDLEMOUSE",
        value = "PRESS",
        any = True,
        head = True,
    )
    middle_mouse_exit.properties.begin_orbit = True
    _keymaps.append((km, middle_mouse_exit))
    # These pass through normally everywhere else, but the operator consumes
    # them in the dedicated Preview and Audio camera areas. This prevents a
    # one-frame pan/orbit/zoom or camera exit before the presentation sync
    # timer can restore the view.
    for navigation_type, navigation_value in (
        ("WHEELINMOUSE", "PRESS"),
        ("WHEELOUTMOUSE", "PRESS"),
        ("TRACKPADPAN", "ANY"),
        ("TRACKPADZOOM", "ANY"),
        ("MOUSEROTATE", "ANY"),
        ("NDOF_MOTION", "ANY"),
        ("NUMPAD_1", "PRESS"),
        ("NUMPAD_2", "PRESS"),
        ("NUMPAD_3", "PRESS"),
        ("NUMPAD_4", "PRESS"),
        ("NUMPAD_5", "PRESS"),
        ("NUMPAD_6", "PRESS"),
        ("NUMPAD_7", "PRESS"),
        ("NUMPAD_8", "PRESS"),
        ("NUMPAD_9", "PRESS"),
        ("NUMPAD_PLUS", "PRESS"),
        ("NUMPAD_MINUS", "PRESS"),
        ("NUMPAD_PERIOD", "PRESS"),
        ("HOME", "PRESS"),
    ):
        _keymaps.append((km, km.keymap_items.new(
            "staticaliza.attached_camera_wheel_exit",
            type = navigation_type,
            value = navigation_value,
            any = True,
            head = True,
        )))
    _keymaps.append((km, km.keymap_items.new(
        "staticaliza.keyframe_camera_view",
        type = "NUMPAD_0",
        value = "PRESS",
        ctrl = True,
        alt = True,
        head = True,
    )))
    km = _register_loop_tab_keymap(
        kc,
        "Dopesheet Generic",
        "DOPESHEET_EDITOR",
    )
    for event_type, action, shift in (
        ("C", "COPY", False),
        ("V", "PASTE", False),
        ("V", "PASTE_FLIPPED", True),
    ):
        item = km.keymap_items.new(
            "staticaliza.pose_pin_clipboard",
            type=event_type,
            value="PRESS",
            ctrl=True,
            shift=shift,
            head=True,
        )
        item.properties.action = action
        _keymaps.append((km, item))
    _register_editor_animation_shortcuts(km)
    _keymaps.append((km, km.keymap_items.new("staticaliza.yellow_menu", type = "F", value = "PRESS", shift = True, head = True)))
    _keymaps.append((km, km.keymap_items.new("dynamic_parent.menu", type = "F", value = "PRESS", ctrl = True)))

    km = _register_loop_tab_keymap(kc, "Graph Editor", "GRAPH_EDITOR")
    for event_type, action, shift in (
        ("C", "COPY", False),
        ("V", "PASTE", False),
        ("V", "PASTE_FLIPPED", True),
    ):
        item = km.keymap_items.new(
            "staticaliza.pose_pin_clipboard",
            type=event_type,
            value="PRESS",
            ctrl=True,
            shift=shift,
            head=True,
        )
        item.properties.action = action
        _keymaps.append((km, item))
    _register_editor_animation_shortcuts(km)
    _keymaps.append((km, km.keymap_items.new("staticaliza.yellow_menu", type = "F", value = "PRESS", shift = True, head = True)))
    _keymaps.append((km, km.keymap_items.new("dynamic_parent.menu", type = "F", value = "PRESS", ctrl = True)))
    for name, space_type in (
        ("Window", "EMPTY"),
        ("Dopesheet", "DOPESHEET_EDITOR"),
        ("Graph Editor Generic", "GRAPH_EDITOR"),
        ("Property Editor", "PROPERTIES"),
        ("Animation", "EMPTY"),
        ("Outliner", "OUTLINER"),
        ("3D View Generic", "VIEW_3D"),
        ("3D View", "VIEW_3D"),
        ("Image Generic", "IMAGE_EDITOR"),
        ("Image", "IMAGE_EDITOR"),
        ("Node Generic", "NODE_EDITOR"),
        ("Node Editor", "NODE_EDITOR"),
        ("NLA Generic", "NLA_EDITOR"),
        ("NLA Tracks", "NLA_EDITOR"),
        ("NLA Editor", "NLA_EDITOR"),
        ("Text Generic", "TEXT_EDITOR"),
        ("Text", "TEXT_EDITOR"),
        ("Video Sequence Editor", "SEQUENCE_EDITOR"),
        ("Sequencer", "SEQUENCE_EDITOR"),
        ("Sequencer Channels", "SEQUENCE_EDITOR"),
        ("Console", "CONSOLE"),
        ("Info", "INFO"),
        ("File Browser", "FILE_BROWSER"),
        ("File Browser Main", "FILE_BROWSER"),
        ("File Browser Buttons", "FILE_BROWSER"),
        ("Preferences", "PREFERENCES"),
        ("Spreadsheet Generic", "SPREADSHEET"),
    ):
        keymap = _register_loop_tab_keymap(kc, name, space_type)
        # Keep these Pose Mode animation actions available from every editor
        # in the Animate and Graph workspaces, matching the Tab loop toggle.
        # A focused Outliner, Properties panel, or other auxiliary editor has
        # its own keymap and never dispatches the Dope Sheet/Graph bindings.
        _register_editor_animation_shortcuts(keymap)
    return True


def _register_addon_keymaps_timer():
    return None if _register_addon_keymaps() else 0.1
