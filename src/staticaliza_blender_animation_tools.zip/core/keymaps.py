"""Addon keymap registration and legacy shortcut cleanup."""

from .runtime import *  # noqa: F403

def _unregister_addon_keymaps():
    for km, kmi in _keymaps:
        try:
            km.keymap_items.remove(kmi)
        except (ReferenceError, RuntimeError):
            pass
    _keymaps.clear()
    _state["pin_click_away_keymap_item"] = None


def _remove_legacy_alt_f_keymaps(keyconfig):
    if keyconfig is None:
        return 0
    removed = 0
    for keymap in keyconfig.keymaps:
        for keymap_item in tuple(keymap.keymap_items):
            if keymap_item.idname not in LEGACY_ALT_F_OPERATOR_IDS:
                continue
            if not (
                keymap_item.type == "F"
                and keymap_item.value == "PRESS"
                and keymap_item.alt
                and not keymap_item.ctrl
                and not keymap_item.shift
            ):
                continue
            try:
                keymap.keymap_items.remove(keymap_item)
                removed += 1
            except (ReferenceError, RuntimeError):
                pass
    return removed


def _remove_stale_mouse_keymaps(keyconfig):
    """Remove mouse hooks left behind by an older live-installed build."""
    if keyconfig is None:
        return 0
    removed = 0
    operator_ids = {
        "staticaliza.track_rig_hover",
        "staticaliza.pin_click_away",
    }
    for keymap in keyconfig.keymaps:
        for keymap_item in tuple(keymap.keymap_items):
            if keymap_item.idname not in operator_ids:
                continue
            try:
                keymap.keymap_items.remove(keymap_item)
                removed += 1
            except (ReferenceError, RuntimeError):
                pass
    return removed


def _register_addon_keymaps():
    try:
        wm = bpy.context.window_manager
    except AttributeError:
        return False
    keyconfigs = wm.keyconfigs if wm else None
    kc = keyconfigs.addon if keyconfigs else None
    if kc is None:
        return False

    # Pointer hooks from older live-installed builds can survive in Blender's
    # effective user keyconfig after their add-on keymap items are removed.
    # Purge both copies before the early return so updating the extension in a
    # running Blender session cannot leave Pose Mode on the Python event path.
    _remove_legacy_alt_f_keymaps(kc)
    _remove_legacy_alt_f_keymaps(getattr(keyconfigs, "user", None))
    _remove_stale_mouse_keymaps(kc)
    _remove_stale_mouse_keymaps(getattr(keyconfigs, "user", None))

    if _keymaps:
        return True

    km = kc.keymaps.new(name = "Pose", space_type = "EMPTY", region_type = "WINDOW")
    for event_type, transform_mode in (
        ("G", "TRANSLATE"),
        ("R", "ROTATE"),
        ("S", "SCALE"),
    ):
        transform_pin = km.keymap_items.new(
            "staticaliza.transform_selected_pin",
            type = event_type,
            value = "PRESS",
            head = True,
        )
        transform_pin.properties.transform_mode = transform_mode
        _keymaps.append((km, transform_pin))
    for event_type, transform_mode in (
        ("G", "TRANSLATE"),
        ("R", "ROTATE"),
    ):
        transform_dragger = km.keymap_items.new(
            "staticaliza.smart_dragger_transform",
            type = event_type,
            value = "PRESS",
            head = True,
        )
        transform_dragger.properties.transform_mode = transform_mode
        _keymaps.append((km, transform_dragger))
    for event_type, reset_mode in (
        ("G", "LOCATION"),
        ("R", "ROTATION"),
        ("S", "SCALE"),
    ):
        clear_contact_transform = km.keymap_items.new(
            "staticaliza.clear_contact_pose_transform",
            type = event_type,
            value = "PRESS",
            alt = True,
            head = True,
        )
        clear_contact_transform.properties.reset_mode = reset_mode
        _keymaps.append((km, clear_contact_transform))
    copy_pins = km.keymap_items.new(
        "staticaliza.pose_pin_clipboard",
        type = "C",
        value = "PRESS",
        ctrl = True,
        head = True,
    )
    copy_pins.properties.action = "COPY"
    _keymaps.append((km, copy_pins))
    paste_pins = km.keymap_items.new(
        "staticaliza.pose_pin_clipboard",
        type = "V",
        value = "PRESS",
        ctrl = True,
        head = True,
    )
    paste_pins.properties.action = "PASTE"
    _keymaps.append((km, paste_pins))
    paste_flipped_pins = km.keymap_items.new(
        "staticaliza.pose_pin_clipboard",
        type = "V",
        value = "PRESS",
        ctrl = True,
        shift = True,
        head = True,
    )
    paste_flipped_pins.properties.action = "PASTE_FLIPPED"
    _keymaps.append((km, paste_flipped_pins))
    # Do not bind LEFTMOUSE. Box Select can consume both CLICK and RELEASE,
    # and a head-priority Python binding can intermittently steal the same
    # press from Blender's native move/rotate gizmos. Click-away is observed
    # by the read-only pointer timer instead.
    _state["pin_click_away_keymap_item"] = None
    _keymaps.append((km, km.keymap_items.new(
        "staticaliza.keyframe_camera_view",
        type = "NUMPAD_0",
        value = "PRESS",
        ctrl = True,
        alt = True,
        head = True,
    )))
    _keymaps.append((km, km.keymap_items.new(
        "onion_skin.ghost_toggle",
        type = "F",
        value = "PRESS",
        head = True,
    )))
    _keymaps.append((km, km.keymap_items.new(
        "staticaliza.yellow_menu",
        type = "F",
        value = "PRESS",
        shift = True,
        head = True,
    )))
    _keymaps.append((km, km.keymap_items.new(
        "dynamic_parent.menu",
        type = "F",
        value = "PRESS",
        ctrl = True,
        head = True,
    )))
    _keymaps.append((km, km.keymap_items.new("staticaliza.set_transform_orientation", type = "Y", value = "PRESS")))
    _keymaps.append((km, km.keymap_items.new("staticaliza.set_pivot_mode", type = "Y", value = "PRESS", shift = True)))
    # Pin selection is owned directly by its tightly bounded
    # Gizmo.test_select callback. The release-only binding above polls false
    # while a bone/native gizmo is selected and exists only for click-away
    # cleanup after a virtual pin has exclusive selection.

    km = kc.keymaps.new(name = "Object Mode", space_type = "EMPTY", region_type = "WINDOW")
    _keymaps.append((km, km.keymap_items.new("staticaliza.set_transform_orientation", type = "Y", value = "PRESS")))

    km = kc.keymaps.new(name = "3D View", space_type = "VIEW_3D", region_type = "WINDOW")
    _keymaps.append((km, km.keymap_items.new(
        "staticaliza.toggle_attached_camera_view",
        type = "NUMPAD_0",
        value = "PRESS",
        head = True,
    )))
    for wheel_type in ("WHEELUPMOUSE", "WHEELDOWNMOUSE"):
        _keymaps.append((km, km.keymap_items.new(
            "staticaliza.attached_camera_wheel_exit",
            type = wheel_type,
            value = "PRESS",
            head = True,
        )))
    middle_mouse_exit = km.keymap_items.new(
        "staticaliza.attached_camera_wheel_exit",
        type = "MIDDLEMOUSE",
        value = "PRESS",
        head = True,
    )
    middle_mouse_exit.properties.begin_orbit = True
    _keymaps.append((km, middle_mouse_exit))
    _keymaps.append((km, km.keymap_items.new(
        "staticaliza.keyframe_camera_view",
        type = "NUMPAD_0",
        value = "PRESS",
        ctrl = True,
        alt = True,
        head = True,
    )))
    km = kc.keymaps.new(name = "Dopesheet Generic", space_type = "DOPESHEET_EDITOR", region_type = "WINDOW")
    _keymaps.append((km, km.keymap_items.new("onion_skin.ghost_toggle", type = "F", value = "PRESS")))
    _keymaps.append((km, km.keymap_items.new("staticaliza.yellow_menu", type = "F", value = "PRESS", shift = True)))
    _keymaps.append((km, km.keymap_items.new("dynamic_parent.menu", type = "F", value = "PRESS", ctrl = True)))

    km = kc.keymaps.new(name = "Graph Editor", space_type = "GRAPH_EDITOR", region_type = "WINDOW")
    _keymaps.append((km, km.keymap_items.new("onion_skin.ghost_toggle", type = "F", value = "PRESS")))
    _keymaps.append((km, km.keymap_items.new("staticaliza.yellow_menu", type = "F", value = "PRESS", shift = True)))
    _keymaps.append((km, km.keymap_items.new("dynamic_parent.menu", type = "F", value = "PRESS", ctrl = True)))
    return True


def _register_addon_keymaps_timer():
    return None if _register_addon_keymaps() else 0.1
