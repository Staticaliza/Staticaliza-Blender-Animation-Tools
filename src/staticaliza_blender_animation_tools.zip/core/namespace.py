"""Collision-safe compatibility linking for extracted feature modules.

The pre-refactor extension was one Python module. Feature callbacks therefore
still reference helpers owned by other files. This linker resolves only the
globals each module actually loads, records their providers for diagnostics,
and keeps the historical package-level API without flooding every module with
the complete compatibility namespace.
"""

from __future__ import annotations

import builtins
from dataclasses import dataclass
import dis
import inspect
from types import CodeType, MappingProxyType, ModuleType
from typing import Any, Iterable, Mapping, MutableMapping


LATE_BOUND_GLOBALS = frozenset({"classes"})


class NamespaceCollisionError(RuntimeError):
    """Raised when two implementation modules own different values by one name."""


@dataclass(frozen=True)
class LinkResult:
    """The public namespace and exact callback dependencies created by linking."""

    namespace: dict[str, Any]
    dependencies: Mapping[str, Mapping[str, tuple[str, ...]]]
    owners: Mapping[str, str]


def _code_objects(code: CodeType):
    yield code
    for value in code.co_consts:
        if isinstance(value, CodeType):
            yield from _code_objects(value)


def _module_functions(module: ModuleType):
    """Yield Python functions whose global namespace belongs to *module*."""

    seen: set[int] = set()
    for value in tuple(vars(module).values()):
        functions = []
        if inspect.isfunction(value) and value.__module__ == module.__name__:
            functions.append(value)
        elif inspect.isclass(value) and value.__module__ == module.__name__:
            for member in tuple(vars(value).values()):
                if isinstance(member, (staticmethod, classmethod)):
                    member = member.__func__
                elif isinstance(member, property):
                    functions.extend(
                        function
                        for function in (member.fget, member.fset, member.fdel)
                        if function is not None
                    )
                    continue
                if inspect.isfunction(member):
                    functions.append(member)
        for function in functions:
            pointer = id(function)
            if pointer in seen:
                continue
            seen.add(pointer)
            yield function


def _loaded_global_names(module: ModuleType) -> set[str]:
    result: set[str] = set()
    for function in _module_functions(module):
        for code in _code_objects(function.__code__):
            result.update(
                instruction.argval
                for instruction in dis.get_instructions(code)
                if instruction.opname == "LOAD_GLOBAL"
            )
    return result


def _module_exports(module: ModuleType) -> dict[str, Any]:
    return {
        name: value
        for name, value in vars(module).items()
        if not name.startswith("__")
    }


def _collect_namespace(modules: tuple[ModuleType, ...]):
    providers: dict[str, list[tuple[ModuleType, Any]]] = {}
    for module in modules:
        for name, value in _module_exports(module).items():
            providers.setdefault(name, []).append((module, value))

    namespace: dict[str, Any] = {}
    owners: dict[str, str] = {}
    for name, candidates in providers.items():
        first_module, first_value = candidates[0]
        conflicting = [
            module.__name__
            for module, value in candidates[1:]
            if value is not first_value
        ]
        if conflicting:
            module_names = ", ".join(
                [first_module.__name__, *conflicting]
            )
            raise NamespaceCollisionError(
                f"Utils implementation symbol {name!r} has conflicting "
                f"providers: {module_names}"
            )
        namespace[name] = first_value
        owners[name] = first_module.__name__
    return namespace, owners


def _remove_stale_exports(
    target: MutableMapping[str, Any],
    namespace: Mapping[str, Any],
) -> None:
    previous = target.get("_SHARED_NAMESPACE")
    if not isinstance(previous, dict):
        return
    for name, previous_value in tuple(previous.items()):
        if name in namespace:
            continue
        if target.get(name) is previous_value:
            target.pop(name, None)


def link_modules(
    modules: Iterable[ModuleType],
    target: MutableMapping[str, Any],
) -> LinkResult:
    """Resolve callback globals and publish a collision-checked root API."""

    module_list = tuple(modules)
    namespace, owners = _collect_namespace(module_list)
    dependency_report: dict[str, Mapping[str, tuple[str, ...]]] = {}

    for module in module_list:
        missing = sorted(
            name
            for name in _loaded_global_names(module)
            if name not in module.__dict__
            and name not in LATE_BOUND_GLOBALS
            and not hasattr(builtins, name)
        )
        unresolved = [name for name in missing if name not in namespace]
        if unresolved:
            raise RuntimeError(
                f"Unresolved callback globals in {module.__name__}: "
                + ", ".join(unresolved)
            )

        dependencies: dict[str, list[str]] = {}
        for name in missing:
            module.__dict__[name] = namespace[name]
            dependencies.setdefault(owners[name], []).append(name)
        frozen_dependencies = MappingProxyType({
            owner: tuple(names)
            for owner, names in sorted(dependencies.items())
        })
        module.__dict__["_MODULE_DEPENDENCIES"] = frozen_dependencies
        dependency_report[module.__name__] = frozen_dependencies

    _remove_stale_exports(target, namespace)
    target.update(namespace)
    return LinkResult(
        namespace=namespace,
        dependencies=MappingProxyType(dependency_report),
        owners=MappingProxyType(owners),
    )


def publish(name: str, value: Any, modules: Iterable[ModuleType]) -> None:
    """Publish a deliberately late-bound value such as the class registry."""

    for module in modules:
        if name in _loaded_global_names(module):
            module.__dict__[name] = value

