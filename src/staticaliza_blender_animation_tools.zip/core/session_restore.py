"""Persistent cross-feature runtime state restoration and scheduling."""

from .runtime import *  # noqa: F403

def _persist_runtime_session_state(context):
    if context is None or getattr(context, "scene", None) is None:
        return False
    _surface_contact_store_persistent_pose_snapshots()
    _store_onion_settings(context)
    enabled = set(_state.get("onion_enabled_owners", set()))
    for armature in tuple(getattr(context.scene, "objects", ())):
        if armature.type != "ARMATURE" or getattr(armature, "pose", None) is None:
            continue
        try:
            modes = _yellow_owner_map("yellow_modes", armature)
            for bone_name, mode in modes.items():
                pose_bone = armature.pose.bones.get(bone_name)
                if pose_bone is not None:
                    pose_bone[YELLOW_PIN_MODE_PROPERTY] = int(mode)
            armature[YELLOW_PIN_HIDDEN_PROPERTY] = _yellow_owner_hidden(armature)
            if _armature_session_uid(armature) in enabled:
                armature[ONION_SKIN_ENABLED_PROPERTY] = True
                if ONION_SKIN_SNAPSHOT_PROPERTY not in armature:
                    _store_onion_snapshot(context, armature)
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            continue
    return True


def _restore_persistent_runtime_state(context):
    if context is None or getattr(context, "scene", None) is None:
        return False
    previous_solver_guard = bool(
        _state.get("surface_contact_solver_syncing", False)
    )
    _state["surface_contact_solver_syncing"] = True
    try:
        return _restore_persistent_runtime_state_guarded(context)
    finally:
        _state["surface_contact_solver_syncing"] = previous_solver_guard


def _restore_persistent_runtime_state_guarded(context):
    _surface_contact_clear_orphaned_pose_snapshots()
    _lock_bundled_template_baseplate()
    _restore_onion_settings(context)
    _restore_yellow_pins(context)

    for armature in tuple(getattr(context.scene, "objects", ())):
        if armature.type == "ARMATURE" and getattr(armature, "pose", None) is not None:
            _restore_onion_snapshot(context, armature)

    _organize_helper_collections(context)

    _restore_all_dynamic_parent_constraint_targets()
    _sync_dynamic_parent_constraints(int(context.scene.frame_current))
    _surface_contact_restore_snap_detached(
        context,
        # During undo/redo, Blender has already restored the explicit detach
        # property. Inferring from the transient target/limb mismatch here
        # would turn an engaged target move into a detached contact before the
        # post-history solver gets a chance to settle it synchronously.
        infer_missing = not bool(_state.get("pin_history_syncing", False)),
    )
    _migrate_dynamic_keyframe_names()
    _maintain_armature_action_channels(context, force = True)
    _set_onion_property(
        context.window_manager,
        bool(_state.get("onion_enabled_owners", set())),
    )
    _refresh_attached_camera_transforms(context)
    _sync_surface_contact_constraints(
        context.scene,
        solve_simulated = False,
        solve_guides = False,
        sync_dynamic_parent = False,
    )
    if not _state.get("pin_history_syncing", False):
        # Registration/update happens after Blender has already evaluated the
        # current scene. That live pose is authoritative. Reapplying a saved
        # pink matrix here made merely updating the extension move the limb,
        # and the delayed timer could replay it after unrelated history.
        _surface_contact_store_persistent_pose_snapshots(only_missing=True)
    _state["persistent_runtime_restored"] = True
    _yellow_refresh_runtime(context)
    return True


def _ensure_persistent_pose_runtime(context):
    scope = _pose_scope_armatures(context)
    signature = tuple(sorted(
        _armature_session_uid(armature)
        for armature in scope
    ))
    previous_signature = tuple(
        _state.get("persistent_pose_scope_signature", ())
    )
    _state["persistent_pose_scope_signature"] = signature
    if not scope:
        return False

    needs_yellow_restore = any(
        any(
            YELLOW_PIN_TARGET_PROPERTY in pose_bone
            for pose_bone in armature.pose.bones
        )
        and (
            not _yellow_owner_map("yellow_modes", armature)
            or not _yellow_owner_map("yellow_fixed", armature)
        )
        for armature in scope
    )
    changed = False
    if needs_yellow_restore:
        changed = bool(_restore_yellow_pins(context))

    enabled = set(_state.get("onion_enabled_owners", set()))
    for armature in scope:
        uid = _armature_session_uid(armature)
        if (
            bool(armature.get(ONION_SKIN_ENABLED_PROPERTY, False))
            and uid not in enabled
            and _restore_onion_snapshot(context, armature)
        ):
            changed = True
            enabled.add(uid)
        stored_hidden = bool(
            armature.get(YELLOW_PIN_HIDDEN_PROPERTY, False)
        )
        if _yellow_owner_hidden(armature) != stored_hidden:
            _yellow_set_owner_hidden(armature, stored_hidden)
            changed = True

    if signature != previous_signature:
        changed = _organize_helper_collections(context) or changed
        _surface_contact_restore_snap_detached(context)

    _set_onion_property(
        context.window_manager,
        bool(_state.get("onion_enabled_owners", set())),
    )
    if changed:
        _yellow_refresh_runtime(context)
    return changed


def _restore_persistent_runtime_timer():
    context = bpy.context
    if (
        context is None
        or getattr(context, "scene", None) is None
        or getattr(context, "window_manager", None) is None
    ):
        return 0.1
    try:
        _restore_persistent_runtime_state(context)
    except Exception as exc:
        _state["last_error"] = str(exc)
    return None


def _schedule_persistent_runtime_restore(delay = 0.1):
    if bpy.app.timers.is_registered(_restore_persistent_runtime_timer):
        bpy.app.timers.unregister(_restore_persistent_runtime_timer)
    register_owned_timer(
        _restore_persistent_runtime_timer,
        first_interval = max(0.01, float(delay)),
        persistent = True,
    )
