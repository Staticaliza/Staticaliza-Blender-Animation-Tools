"""Shared imports, constants, and mutable runtime state.

Feature modules import this module so stateful containers keep one identity.
"""

from .version import ADDON_VERSION

import bpy
import blf
import gpu
import addon_utils
import hashlib
import importlib
import json
import math
import os
import sys
import tempfile
import time
import tomllib
import urllib.error
import urllib.request
import zipfile
from mathutils import Color, Vector, Matrix, Quaternion
from gpu_extras.batch import batch_for_shader
from bpy.app.handlers import persistent

PACKAGE_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXTENSION_UPDATE_GUARD_KEY = "__staticaliza_utils_extension_update_guard"
SURFACE_CONTACT_LIVE_UPDATE_POSES_KEY = (
    "__staticaliza_utils_live_update_contact_poses"
)


def extension_update_guard_active():
    """Read the reload guard from Blender-owned persistent state."""
    try:
        namespace = bpy.app.driver_namespace
        value = namespace.get(EXTENSION_UPDATE_GUARD_KEY)
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            if time.perf_counter() >= float(value):
                namespace.pop(EXTENSION_UPDATE_GUARD_KEY, None)
                return False
        return bool(value)
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        return False

DEVELOPER_BUILD = os.path.isfile(os.path.join(
    PACKAGE_ROOT,
    ".staticaliza_dev_build",
))
ADDON_VERSION_DISPLAY = ".".join(
    str(part) for part in ADDON_VERSION
)
ADDON_BUILD_DISPLAY = " (DEV)" if DEVELOPER_BUILD else ""

_state = {
    "extension_registered": False,
    "owned_timers": set(),
    "owned_handlers": [],
    "owned_draw_handlers": {},
    "owned_classes": [],
    "enabled": False,
    "handle_view": None,
    "handle_pixel": None,
    "shader_3d": None,
    "shader_3d_mode": "UNIFORM",
    "shader_2d": None,
    "mesh_batches": {},
    "raycast_fixed": {},
    "yellow_fixed": {},
    "yellow_modes": {},
    "yellow_hidden": set(),
    "onion_enabled_owners": set(),
    "onion_property_syncing": False,
    "onion_multiple_updating": False,
    "onion_multiple_refresh_after_playback": False,
    "onion_multiple_signatures": {},
    "onion_multiple_mesh_batches": {},
    "onion_multiple_raycast_fixed": {},
    "persistent_runtime_restored": False,
    "persistent_pose_scope_signature": (),
    "unparent_rel_cache": {},
    "unparent_handler_mute": False,
    "dynamic_space_reconciling": False,
    "dynamic_space_reconcile_pending": False,
    "dynamic_space_calibrating": False,
    "dynamic_space_export_sampling": False,
    "dynamic_space_last_action_update": 0.0,
    "dynamic_space_marker_signature": None,
    "dynamic_space_frame_evaluation_until": 0.0,
    "dynamic_space_runtime_cache_generation": 0,
    "dynamic_space_runtime_cache_key": None,
    "dynamic_space_runtime_constraint_owners": (),
    "dynamic_space_runtime_unparent_armatures": (),
    "dynamic_space_runtime_cache_validation_deadline": 0.0,
    "dynamic_parent_boundary_refresh_pending": False,
    "dynamic_parent_boundary_refresh_last_update": 0.0,
    "dynamic_parent_animation_signature": None,
    "dynamic_parent_playback_session_active": False,
    "dynamic_parent_cleanup_pending": False,
    "dynamic_parent_dual_selection_locks": {},
    "dynamic_parent_dual_selection_translate_sessions": {},
    "dynamic_parent_indirect_parent_baselines": {},
    "dynamic_parent_indirect_visual_commits": {},
    "dynamic_parent_selection_order": {},
    "dynamic_parent_native_history_transition": None,
    "dynamic_parent_native_history_expected_index": None,
    "dynamic_parent_native_history_source_index": None,
    "dynamic_parent_native_history_source_matches": False,
    "dynamic_parent_native_history_transitions": [],
    "dynamic_parent_native_history_redo_stack": [],
    "dynamic_parent_native_history_serial": 0,
    "dynamic_parent_history_restored_owner_keys": set(),
    "dynamic_parent_history_snapshot": (),
    "dynamic_parent_dual_selection_save_paused": False,
    "last_error": "",
    "smart_material_processed_rigs": set(),
    "material_import_baseline": None,
    "extension_update_running": False,
    "extension_update_status": "",
    "extension_update_lock_waits": 0,
    "roblox_constraints_normalized": set(),
    "roblox_constraints_new_rigs": set(),
    "roblox_serializer_patch": None,
    "roblox_export_execute_patch": None,
    "roblox_import_execute_patch": None,
    "roblox_bone_color_patches": None,
    "roblox_preview_draw_patches": {},
    "roblox_metadata_patches": [],
    "roblox_animation_loop_modes": {},
    "roblox_animation_playback_frame": 0,
    "roblox_animation_statusbars": {},
    "animation_range_msgbus_owner": None,
    "unparent_export_armature": None,
    "smart_material_scan_pending": False,
    "smart_material_scan_not_before": 0.0,
    "roblox_compatibility_scan_pending": False,
    "roblox_armature_list_signature": None,
    "armature_overlay_saved": {},
    "part_pivot_syncing": False,
    "transform_gizmo_refresh_pending": False,
    "part_pivot_armature": 0,
    "part_pivot_bone": "",
    "part_pivot_last_armature": 0,
    "part_pivot_last_bone": "",
    "part_pivot_object": "",
    "part_pivot_object_local": None,
    "part_pivot_objects": (),
    "part_pivot_selection_signature": (),
    "part_pivot_saved": None,
    "part_pivot_last_signature": None,
    "part_pivot_cursor_visibility": {},
    "camera_fov_syncing": False,
    "camera_view_spaces": {},
    "animation_camera_view_master": None,
    "animation_camera_view_states": {},
    "animation_camera_view_syncing": False,
    "attached_camera_last_name": "",
    "attached_camera_last_pointer": 0,
    "free_view_master": None,
    "free_view_space_states": {},
    "free_view_settings_master": None,
    "free_view_setting_states": {},
    "view3d_n_panel_master": None,
    "view3d_n_panel_states": {},
    "view3d_n_panel_window_screens": {},
    "free_view_syncing": False,
    "pose_mode_pending_rigs": set(),
    "pose_mode_pending_attempts": 0,
    "rig_view_frame_request": None,
    "rig_view_frame_serial": 0,
    "expanded_animation_channels": set(),
    "animation_channel_content": {},
    "animation_channel_expand_pending": False,
    "animation_channel_expand_attempts": 0,
    "animation_editor_pose_states": {},
    "animation_editor_sync_signature": None,
    "animation_editor_sync_time": 0.0,
    "animation_channel_maintenance_last_time": 0.0,
    "animation_channel_maintenance_syncing": False,
    "animation_channel_structure_signatures": {},
    "special_action_order_attempts": {},
    "bone_label_selection_signature": None,
    "pose_hidden_armatures": {},
    "pose_visibility_resume_after_save": False,
    "rig_hover_mouse": {},
    "rig_hover_redraw_times": {},
    "rig_hover_targets": {},
    "rig_hover_poll_time": 0.0,
    "rig_hover_cursor_position": None,
    "rig_hover_cursor_changed_at": 0.0,
    "rig_hover_available": False,
    "surface_contact_syncing": False,
    "surface_contact_reconciling": False,
    "surface_contact_solver_syncing": False,
    "surface_contact_creation_active": False,
    "surface_contact_load_restoring": False,
    "surface_contact_registration_guard_until": 0.0,
    "surface_contact_valid_poses": {},
    "surface_contact_owner_pose_bases": {},
    "surface_contact_transform_signatures": {},
    "surface_contact_guide_cache": (),
    "surface_contact_guide_cache_object_count": -1,
    "surface_contact_guide_cache_identity": (),
    "surface_contact_guide_cache_validation_deadline": 0.0,
    "surface_contact_guide_cache_generation": 0,
    "surface_contact_detached_cache_revision": 0,
    "surface_contact_active_guide_cache": {},
    "surface_contact_effector_guide_cache": {},
    "surface_contact_pose_bone_cache": {},
    "surface_contact_resolved_guide_cache": {},
    "surface_contact_attached_frame_cache": {},
    "surface_contact_attached_frame_cache_scope": None,
    "surface_contact_detached_fcurve_cache": {},
    "surface_contact_detached_key_cache": {},
    "surface_contact_depsgraph_guide_index": None,
    "surface_contact_playback_settle_signature": None,
    "surface_contact_rotation_axes": {},
    "surface_contact_smart_aim_branches": {},
    "surface_contact_roll_frames": {},
    "surface_contact_collision_tangents": {},
    "surface_contact_last_frames": {},
    "pin_target_dragging": False,
    "pin_snap_transform_active": False,
    "pin_snap_sample_syncing": False,
    "pin_snap_transform_initializing": False,
    "pin_snap_transform_operator": "",
    "pin_snap_transform_start_poses": {},
    "pin_snap_transform_changed": False,
    "pin_snap_transform_delta_supported": False,
    "pin_snap_transform_delta_observed": False,
    "pin_snap_transform_last_delta_signature": None,
    "pin_snap_last_solved_pose_signature": None,
    "pin_snap_engage_anchor_origins": {},
    "pin_snap_grip_directions": {},
    "pin_snap_raw_anchor_samples": {},
    "pin_snap_raw_pose_matrices": {},
    "pin_snap_raw_basis_matrices": {},
    "pin_snap_native_after_poses": {},
    "pin_snap_magnetic_anchor_samples": {},
    "pin_snap_magnetic_aim_anchor_samples": {},
    "pin_snap_magnetic_aim_pose_matrices": {},
    "pin_snap_pre_solve_anchor_samples": {},
    "pin_snap_contact_target_locks": {},
    "pin_snap_direct_transform_guides": set(),
    "pin_snap_parent_transform_guides": set(),
    "pin_snap_target_transform_guides": set(),
    "pin_snap_parent_attachment_states": {},
    "pin_snap_collision_min_distances": {},
    "pin_snap_collision_started_clipped": set(),
    "pin_snap_live_detached_keyed": {},
    "pin_snap_syncing": False,
    "pin_snap_latches": set(),
    "pin_snap_departing": set(),
    "pin_snap_detached": set(),
    "pin_snap_transform_seen": set(),
    "pin_snap_initial_detached": {},
    "pin_snap_last_depsgraph_sync": 0.0,
    "pin_snap_transform_dirty": False,
    "pin_snap_live_pose_matrices": {},
    "pin_snap_live_pose_dirty_guides": set(),
    "pin_snap_contact_transform_start_poses": {},
    "pin_snap_contact_start_action_keys": {},
    "pin_snap_native_history_tokens": {},
    "pin_snap_native_history_token_serial": -1,
    "pin_snap_native_history_transition": None,
    "pin_snap_native_history_transition_backup": None,
    "pin_snap_native_history_transitions": [],
    "pin_snap_native_history_redo_stack": [],
    "pin_snap_native_history_pre_selected": {},
    "pin_snap_initial_latches": set(),
    "pin_snap_initial_attachment_states": {},
    "pin_snap_transform_engaged": set(),
    "pin_snap_proximity_engaged": set(),
    "pin_snap_engage_translate_origins": {},
    "pin_snap_transform_releasing": set(),
    "pin_snap_release_reentry_armed": set(),
    "pin_snap_release_anchor_origins": {},
    "pin_snap_pressure_tangents": {},
    "pin_snap_pressure_active": set(),
    "pin_snap_pressure_release_session": set(),
    "pin_snap_pressure_release_origins": {},
    "pin_snap_pressure_release_pose_matrices": {},
    "pin_snap_pressure_release_raw_translations": {},
    "pin_snap_transform_finalize_pending": None,
    "pin_gizmo_axes_visible": {},
    "pin_gizmo_active_axis_index": -1,
    "pin_gizmo_available_kinds": frozenset(),
    "pin_gizmo_selection_keys": (),
    "pin_gizmo_selected_key": "",
    "pin_gizmo_selected_keys": set(),
    "pin_gizmo_selected_keys_active": "",
    "pin_gizmo_pending_click": None,
    "pin_gizmo_selection_epoch": 0,
    "pin_gizmo_claim_serial": 0,
    "pin_gizmo_last_claim": None,
    "pin_pointer_pending_click": None,
    "pin_pointer_was_pressed": False,
    "pin_pointer_pressed_tool_id": "",
    "pin_workspace_tool_id": "",
    "pin_cpu_pick_targets": {},
    "pin_gizmo_extend_selection_until": 0.0,
    "pin_gizmo_deferred_finishes": [],
    "pin_keyboard_transform_active": False,
    "pin_transform_from_gizmo": False,
    "pin_transform_constraint": None,
    "smart_dragger_selected_side": -1,
    "smart_dragger_owner": None,
    "smart_dragger_transform_active": False,
    "smart_dragger_cache": {},
    "pin_yellow_history_fallbacks": {},
    "pin_history_active": False,
    "pin_history_contact_snapshot": None,
    "pin_history_nonhistory_snapshot": None,
    "pin_history_selection_snapshot": None,
    "pin_history_direction": "",
    "pin_history_pre_pose_selection_signature": (),
    "pin_history_pre_attached_camera_signature": (),
    "pin_history_selection_only": False,
    "pin_history_selection_only_step": False,
    "pin_history_native_transition_restored": False,
    "pin_history_syncing": False,
    "pin_history_contact_pose_lock": (),
    "pin_history_pre_contact_pose_lock": (),
    "pin_history_pre_active_contact_pose_lock": (),
    "pin_history_pre_contact_runtime_snapshot": None,
    "pin_history_contact_transition": None,
    "pin_history_contact_transition_predicted": False,
    "pin_history_contact_transition_source_index": None,
    "pin_history_contact_transition_target_index": None,
    "pin_history_contact_transition_selected": {},
    "pin_history_contact_transition_runtime_before": (),
    "pin_history_pose_lock_syncing": False,
    "pin_history_pose_lock_relevant_pointers": None,
    "pin_history_pose_release_pending": False,
    "pin_history_pose_release_frame": None,
    "pin_history_pose_release_started": 0.0,
    "pin_history_pose_release_minimum_deadline": 0.0,
    "pin_history_pose_release_deadline": 0.0,
    "pin_history_pose_release_require_update": False,
    "pin_history_pose_release_last_event": 0.0,
    "pin_history_pose_release_observed": False,
    "pin_history_pose_release_stable_ticks": 0,
    "pin_history_pose_release_last_signature": None,
    "pin_snap_native_history_expected_index": None,
    "pin_snap_native_history_pre_tokens": {},
    "animator_utils_file_defaults_syncing": False,
    "pin_native_group_session": None,
    "pin_native_group_applying": False,
    "pin_clipboard": None,
}

ARMATURE_OVERLAY_STATE_KEY = "_staticaliza_advanced_overlay_state"
CLOTHING_LAYER_OFFSET_MODIFIER = "Staticaliza Clothing Offset"
RIG_TEXTURE_SOURCE_KEY = "staticaliza_rig_texture_source"
RIG_TEXTURE_OWNER_KEY = "staticaliza_rig_texture_owner"
IMPORTED_MATERIAL_DISPLAY_COLOR = tuple(
    Color((231.0 / 255.0,) * 3).from_srgb_to_scene_linear()
) + (1.0,)

_keymaps = []
LEGACY_ALT_F_OPERATOR_IDS = frozenset((
    "staticaliza.unparent_menu",
    "stattools.unparent_bake",
))

UNP_PROP = "Dynamic Unparent"
UNP_SPLIT_VALUE = 2.0
LEGACY_UNP_PROPS = ("staticaliza_unparent_marker",)
UNP_STATE_KEY = "staticaliza_unparent_state"
REL_K_PARENT = "staticaliza_rel_saved_parent"
REL_K_CONNECT = "staticaliza_rel_saved_connect"
UNP_VIS_CONSTRAINT = "ANIMATOR_UTILS_UNPARENT_VIS"
DP_AUTO_UNPARENT_START_KEY = "staticaliza_auto_unparent_start"
DP_AUTO_UNPARENT_PROPERTY_PREFIX = "staticaliza_dp_unp_"
DP_SEGMENT_PROPERTY_PREFIX = "DP Segment "
DP_TARGET_PROPERTY_PREFIX = "DP Target "
DP_SUBTARGET_PROPERTY_PREFIX = "DP Subtarget "
DP_BOUNDARY_CALIBRATED_PROPERTY_PREFIX = "DP Boundary Calibrated "
DP_MARKER_PROPERTY_PREFIX = "Dynamic Parent Marker "
SPACE_CONSTRAINT_PREFIX = "_DynamicSpace_"
SPACE_ROLE_PROPERTY_PREFIX = "Dynamic Space Role "
SPACE_SOURCE_PROPERTY_PREFIX = "Dynamic Space Source "
SPACE_ROLE_NORMAL = "NORMAL"
SPACE_ROLE_UNPARENT = "UNPARENT"
SPACE_ROLE_WORLD = "WORLD"
SPACE_MIN_FRAME = -1048574
SPACE_SOURCE_BASE = "BASE"
SPACE_SOURCE_UNPARENT_PREFIX = "UNPARENT:"
SPACE_SOURCE_DYNAMIC_PARENT_PREFIX = "DYNAMIC_PARENT:"
SPACE_HELPER_COLLECTION = "_Animator Helpers"
LEGACY_SPACE_HELPER_COLLECTION = "_Roblox Animator Utils Helpers"
SPACE_HELPER_OWNER_UID_PROPERTY = "Staticaliza Helper Owner Session UID"
SPACE_HELPER_OBJECT_PREFIX = "_DynamicSpaceHelper_"
SPACE_HELPER_PROPERTY = "Dynamic Space Helper"
ATTACHED_CAMERA_OWNER_NAME_PROPERTY = "Staticaliza Camera Owner"
ATTACHED_CAMERA_OWNER_UID_PROPERTY = "Staticaliza Camera Owner Session UID"
ATTACHED_CAMERA_BONE_PROPERTY = "Staticaliza Camera Bone"
ATTACHED_CAMERA_LOCAL_MATRIX_PROPERTY = "Staticaliza Camera Bone Local Matrix"
DYNAMIC_COLOR_PALETTE_KEY = "Dynamic Color Palette"
DYNAMIC_COLOR_CUSTOM_KEY = "Dynamic Color Custom"
DYNAMIC_PARENT_COLOR = (0.08, 0.72, 0.16)
DYNAMIC_UNPARENT_COLOR = (0.08, 0.32, 1.0)
DYNAMIC_CONTACT_COLOR = (1.0, 0.0, 1.0)
DYNAMIC_CAMERA_COLOR = (0.22, 0.22, 0.22)

SURFACE_CONTACT_GUIDE_PROPERTY = "Surface Contact Guide"
SURFACE_CONTACT_ARMATURE_PROPERTY = "Contact Armature"
SURFACE_CONTACT_BONE_PROPERTY = "Contact Bone"
SURFACE_CONTACT_CONTROL_OBJECT_PROPERTY = "Contact Control Object"
SURFACE_CONTACT_CONTROL_BONE_PROPERTY = "Contact Control Bone"
SURFACE_CONTACT_PRIMARY_PROPERTY = "Contact Primary Constraint"
SURFACE_CONTACT_SECONDARY_PROPERTY = "Contact Secondary Constraint"
SURFACE_CONTACT_KIND_PROPERTY = "Contact Kind"
SURFACE_CONTACT_CHAIN_PROPERTY = "Contact Chain Count"
SURFACE_CONTACT_START_PROPERTY = "Contact Start"
SURFACE_CONTACT_END_PROPERTY = "Contact End"
SURFACE_CONTACT_SURFACE_PROPERTY = "Contact Surface"
SURFACE_CONTACT_POINT_PROPERTY = "Contact Surface Point"
SURFACE_CONTACT_NORMAL_PROPERTY = "Contact Surface Normal"
SURFACE_CONTACT_SIZE_PROPERTY = "Contact Guide Size"
SURFACE_CONTACT_OBJECT_PROPERTY = "Contact Object"
SURFACE_CONTACT_SUPPORT_PROPERTY = "Contact Bone Local Support"
SURFACE_CONTACT_SMART_OBJECT_PROPERTY = "Contact Smart Object"
SURFACE_CONTACT_SMART_LOCAL_PROPERTY = "Contact Smart Object Local Point"
SURFACE_CONTACT_SMART_ROLL_PROPERTY = "Contact Smart Object Roll Axis"
SURFACE_CONTACT_CAST_AXIS_PROPERTY = "Contact Cast Axis"
SURFACE_CONTACT_PIN_MODE_PROPERTY = "Contact Pin Mode"
SURFACE_CONTACT_AIM_PROPERTY = "Contact Aim Influence"
SURFACE_CONTACT_RELEASE_OBJECT_PROPERTY = "Contact Release Control Object"
SURFACE_CONTACT_RELEASE_BONE_PROPERTY = "Contact Release Control Bone"
SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY = "Contact Guide Surface Matrix"
SURFACE_CONTACT_INITIAL_GUIDE_MATRIX_PROPERTY = "Contact Initial Guide Matrix"
SURFACE_CONTACT_FOLLOW_OBJECT_PROPERTY = "Contact Follow Object"
SURFACE_CONTACT_FOLLOW_BONE_PROPERTY = "Contact Follow Bone"
SURFACE_CONTACT_GEOMETRY_BONE_PROPERTY = "Contact Geometry Bone"
SURFACE_CONTACT_CONSTRAINT_OBJECT_PROPERTY = "Contact Constraint Object"
SURFACE_CONTACT_CONSTRAINT_BONE_PROPERTY = "Contact Constraint Bone"
SURFACE_CONTACT_SOLVER_OBJECT_PROPERTY = "Contact Solver Object"
SURFACE_CONTACT_SOLVER_PROPERTY = "Surface Contact Solver"
SURFACE_CONTACT_SOLVER_LOCAL_MATRIX_PROPERTY = "Contact Solver Guide Matrix"
SURFACE_CONTACT_ROTATION_BINDING_PROPERTY = "Contact Rotation Binding Version"
SURFACE_CONTACT_LABEL_PROPERTY = "Contact Surface Label"
SURFACE_CONTACT_TARGET_FRAMES_PROPERTY = "Contact Target Frames"
SURFACE_CONTACT_STRETCH_STATE_PROPERTY = "Contact Stretch State"
SURFACE_CONTACT_DETACHED_PROPERTY = "Contact Endpoint Detached"
SURFACE_CONTACT_SAVED_POSE_PROPERTY = "Contact Saved Pose Matrix"
SURFACE_CONTACT_MARKER_PROPERTY = "Surface Contact"
SURFACE_CONTACT_CONSTRAINT_PREFIX = "_SurfaceContact_"
SURFACE_CONTACT_KIND_CONTROL = "CONTROL"
SURFACE_CONTACT_KIND_IK = "IK"
SURFACE_CONTACT_KIND_SIMULATED = "SIMULATED"
SURFACE_CONTACT_KIND_OBJECT = "OBJECT"
YELLOW_PIN_TARGET_PROPERTY = "Onion Pin Target"
YELLOW_PIN_MODE_PROPERTY = "Onion Pin Mode"
YELLOW_PIN_AXIS_PROPERTY = "Onion Pin Axis"
YELLOW_PIN_INITIAL_TARGET_PROPERTY = "Onion Pin Initial Target"
SMART_DRAGGER_INITIAL_BASIS_PROPERTY = "Smart Dragger Initial Bone Basis"
YELLOW_PIN_HIDDEN_PROPERTY = "Onion Pins Hidden"
ONION_SKIN_ENABLED_PROPERTY = "Onion Skin Enabled"
ONION_SKIN_SNAPSHOT_PROPERTY = "Onion Skin Snapshot"
ONION_SKIN_SETTINGS_PROPERTY = "Onion Skin Settings"
PIN_SELECTION_HISTORY_PROPERTY = "Staticaliza Pin Selection History"
ONION_PIN_COLOR = (1.0, 1.0, 0.0, 1.0)
SURFACE_CONTACT_HOT_PINK = (1.0, 0.0, 1.0, 1.0)
PIN_AXIS_ITEMS = (
    ("X_POS", "+X", "Use the welded object's positive X face"),
    ("X_NEG", "-X", "Use the welded object's negative X face"),
    ("Y_POS", "+Y", "Use the welded object's positive Y face"),
    ("Y_NEG", "-Y", "Use the welded object's negative Y face"),
    ("Z_POS", "+Z", "Use the welded object's positive Z face"),
    ("Z_NEG", "-Z", "Use the welded object's negative Z face"),
)
SURFACE_CONTACT_LIVE_SOLVER_ITERATIONS = 2
SURFACE_CONTACT_FINAL_SOLVER_ITERATIONS = 16
SURFACE_CONTACT_OVERLAP_COLOR = tuple(
    math.sqrt(((first * first) + (second * second)) * 0.5)
    for first, second in zip(ONION_PIN_COLOR, SURFACE_CONTACT_HOT_PINK)
)
SURFACE_CONTACT_AIM_INFLUENCE = 1.0
SURFACE_CONTACT_MAX_AIM_STEP = math.radians(45.0)
PIN_GIZMO_DIAMOND_SCALE = 0.095
PIN_GIZMO_AXIS_SCALE = 0.42
# Pin diamonds are the user's direct manipulation targets. Keep their
# selection depth ahead of both Blender's default transform gizmos and this
# extension's axis handles (bias 1.0) when their screen-space hits overlap.
PIN_GIZMO_CENTER_SELECT_BIAS = 16.0 / 3.0
PIN_GIZMO_CENTER_HIT_RADIUS = 12.0
PIN_GIZMO_LOCKED_ALPHA = 0.16
# Each pink/yellow group grows beyond this floor only when the current Pose
# selection exposes more pin targets.  A fixed pool of 128 per group created
# hundreds of selectable Python gizmos in every viewport, even with no pins.
PIN_GIZMO_TARGET_POOL_SIZE = 8
PIN_DOT_PIXEL_RADIUS = 5.0
PIN_SNAP_RING_PIXEL_RADIUS = 8.0
PIN_SNAP_PIXEL_RADIUS = 16.0
# A modest 25% release buffer gives yellow Onion and pink Contact pins a
# little more grip without changing how close the dots must be to snap.
PIN_SNAP_RELEASE_PIXEL_RADIUS = PIN_SNAP_PIXEL_RADIUS * 1.25
# A release sample must primarily move away from the socket. Perspective can
# make a circular ball-joint arc grow by a few pixels even though the user's
# motion is sideways around the pin; treating that growth alone as release
# made an attached pink limb intermittently slide off its surface pin.
PIN_SNAP_RELEASE_RADIAL_INTENT_RATIO = 0.5
PIN_SNAP_WORLD_RADIUS = 0.04
PIN_GIZMO_DRAG_PIXEL_THRESHOLD = 3.0
SURFACE_CONTACT_HISTORY_TOKEN_PROPERTY = "staticaliza_contact_history_token"

REL_K_HEAD = "staticaliza_rel_saved_head"
REL_K_TAIL = "staticaliza_rel_saved_tail"
REL_K_ROLL = "staticaliza_rel_saved_roll"

DP_BL_INFO = {
    "name": "Dynamic Parent",
    "author": "Roman Volodin, roman.volodin@gmail.com",
    "version": (2, 0, 2),
    "blender": (4, 0, 0),
    "location": "View3D > Tool Panel",
    "description": "Allows to create and disable an animated ChildOf constraint",
    "category": "Animation",
}


def _reset_dynamic_parent_history_state():
    _state["dynamic_parent_native_history_transition"] = None
    _state["dynamic_parent_native_history_expected_index"] = None
    _state["dynamic_parent_native_history_source_index"] = None
    _state["dynamic_parent_native_history_source_matches"] = False
    _state["dynamic_parent_native_history_transitions"] = []
    _state["dynamic_parent_native_history_redo_stack"] = []
    _state["dynamic_parent_native_history_serial"] = 0
    _state["dynamic_parent_history_restored_owner_keys"] = set()
    _state["dynamic_parent_history_snapshot"] = ()


def _animation_playback_active(context = None):
    """Return whether any open Blender window is currently playing animation."""
    context = context or bpy.context
    window_manager = getattr(context, "window_manager", None)
    return any(
        bool(getattr(getattr(window, "screen", None), "is_animation_playing", False))
        for window in tuple(getattr(window_manager, "windows", ()))
    )

# Private runtime names are intentionally exported to feature modules.
__all__ = tuple(name for name in globals() if not name.startswith('__'))
