"""Ownership helpers for Blender resources created by the extension.

Timers are tracked by function identity so every delayed callback—including
anonymous one-shot callbacks—can be cancelled during disable or live reload.
"""

from .runtime import *  # noqa: F403


_HANDLER_OWNER_ATTRIBUTE = "_roblox_animator_utils_handler_key"
_LEGACY_HANDLER_OWNER_ATTRIBUTE = "_staticaliza_utils_handler"


def _owned_handler_key(function):
    return (
        str(getattr(function, "__module__", "")),
        str(getattr(function, "__name__", "")),
    )


def register_owned_timer(function, *, first_interval=0.0, persistent=False):
    """Register a timer once and remember it for deterministic teardown."""

    owned = _state.setdefault("owned_timers", set())
    # Blender removes one-shot timers after they return None, but the owner
    # set previously retained every completed closure until the extension was
    # disabled. Repeated pin commits and history updates could therefore keep
    # whole operator/context graphs alive for the rest of the session.
    for completed in tuple(owned):
        try:
            if not bpy.app.timers.is_registered(completed):
                owned.discard(completed)
        except (ReferenceError, RuntimeError, ValueError):
            owned.discard(completed)
    try:
        already_registered = bpy.app.timers.is_registered(function)
    except (ReferenceError, RuntimeError, ValueError):
        already_registered = False
    if already_registered:
        owned.add(function)
        return False
    bpy.app.timers.register(
        function,
        first_interval=first_interval,
        persistent=persistent,
    )
    owned.add(function)
    return True


def unregister_owned_timers():
    """Cancel every timer registered through :func:`register_owned_timer`."""

    owned = _state.setdefault("owned_timers", set())
    for function in tuple(owned):
        try:
            if bpy.app.timers.is_registered(function):
                bpy.app.timers.unregister(function)
        except (ReferenceError, RuntimeError, ValueError):
            pass
    owned.clear()


def register_owned_handler(handler_list, function):
    """Append one owned handler without deleting another add-on's namesake."""

    handler_key = _owned_handler_key(function)
    setattr(function, _HANDLER_OWNER_ATTRIBUTE, handler_key)
    for handler in tuple(handler_list):
        same_handler = (
            handler is function
            or getattr(handler, _HANDLER_OWNER_ATTRIBUTE, None) == handler_key
        )
        legacy_handler = bool(
            getattr(handler, _LEGACY_HANDLER_OWNER_ATTRIBUTE, False)
        )
        if same_handler or legacy_handler:
            try:
                handler_list.remove(handler)
            except (ReferenceError, RuntimeError, ValueError):
                pass
    handler_list.append(function)
    owned = _state.setdefault("owned_handlers", [])
    owned.append((handler_list, function))


def unregister_owned_handlers():
    """Remove all handlers owned by this extension generation."""

    owned = _state.setdefault("owned_handlers", [])
    for handler_list, function in reversed(tuple(owned)):
        handler_key = _owned_handler_key(function)
        for handler in tuple(handler_list):
            same_handler = (
                handler is function
                or getattr(handler, _HANDLER_OWNER_ATTRIBUTE, None)
                == handler_key
            )
            legacy_handler = bool(
                getattr(handler, _LEGACY_HANDLER_OWNER_ATTRIBUTE, False)
            )
            if same_handler or legacy_handler:
                try:
                    handler_list.remove(handler)
                except (ReferenceError, RuntimeError, ValueError):
                    pass
    owned.clear()


def register_owned_draw_handler(
    state_key,
    function,
    arguments,
    region_type,
    draw_type,
):
    """Register and track one SpaceView3D draw callback by runtime-state key."""

    unregister_owned_draw_handler(state_key)
    handle = bpy.types.SpaceView3D.draw_handler_add(
        function,
        arguments,
        region_type,
        draw_type,
    )
    _state.setdefault("owned_draw_handlers", {})[state_key] = (
        handle,
        region_type,
    )
    _state[state_key] = handle
    return handle


def unregister_owned_draw_handler(state_key):
    """Remove one tracked SpaceView3D draw callback if it still exists."""

    owned = _state.setdefault("owned_draw_handlers", {})
    record = owned.pop(state_key, None)
    handle = record[0] if record is not None else _state.get(state_key)
    region_type = record[1] if record is not None else "WINDOW"
    if handle is not None:
        try:
            bpy.types.SpaceView3D.draw_handler_remove(handle, region_type)
        except (ReferenceError, RuntimeError, ValueError):
            pass
    _state[state_key] = None


def unregister_owned_draw_handlers():
    """Remove every SpaceView3D draw callback owned by this generation."""

    for state_key in tuple(
        _state.setdefault("owned_draw_handlers", {}).keys()
    ):
        unregister_owned_draw_handler(state_key)


def register_owned_classes(class_sequence):
    """Register Blender classes transactionally in their declared order."""

    unregister_owned_classes()
    registered = _state.setdefault("owned_classes", [])
    try:
        for class_type in class_sequence:
            bpy.utils.register_class(class_type)
            registered.append(class_type)
    except Exception:
        unregister_owned_classes()
        raise


def unregister_owned_classes():
    """Unregister every successfully registered class in reverse order."""

    registered = _state.setdefault("owned_classes", [])
    for class_type in reversed(tuple(registered)):
        try:
            bpy.utils.unregister_class(class_type)
        except (RuntimeError, ValueError):
            pass
    registered.clear()
