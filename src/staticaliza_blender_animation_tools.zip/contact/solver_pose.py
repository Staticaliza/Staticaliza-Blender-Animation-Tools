"""Surface-contact solver pose evaluation and cleanup."""

from ..core.runtime import *  # noqa: F403

def _surface_contact_stored_anchor_world(context, guide):
    return _surface_contact_anchor_world(context, guide)

def _surface_contact_solver_reach(context, guide):
    armature = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
    )
    if armature is None or getattr(armature, "pose", None) is None:
        return None
    try:
        depsgraph = context.evaluated_depsgraph_get()
        evaluated_armature = armature.evaluated_get(depsgraph)
        effector = evaluated_armature.pose.bones.get(
            str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
        )
        if effector is None:
            return None
        chain_count = int(guide.get(SURFACE_CONTACT_CHAIN_PROPERTY, 1))
        chain = _surface_contact_chain(effector, chain_count)
        if not chain:
            return None
        root = chain[-1]
        pivot = evaluated_armature.matrix_world @ root.head
        reach = sum(
            (
                (evaluated_armature.matrix_world @ bone.tail)
                - (evaluated_armature.matrix_world @ bone.head)
            ).length
            for bone in chain
        )
        fallback = (
            (evaluated_armature.matrix_world @ effector.tail) - pivot
        )
        if reach <= 1.0e-8:
            return None
        exact_radius = bool(
            str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
            == SURFACE_CONTACT_KIND_IK
            and len(chain) == 1
        )
        return pivot, reach, fallback, exact_radius
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return None


def _surface_contact_clamp_solver_matrix(context, guide, world_matrix):
    reach_data = _surface_contact_solver_reach(context, guide)
    if reach_data is None:
        return world_matrix.copy()
    pivot, reach, fallback, exact_radius = reach_data
    result = world_matrix.copy()
    direction = result.translation - pivot
    distance = direction.length
    if distance <= 1.0e-8:
        direction = fallback.copy()
        if direction.length_squared <= 1.0e-12:
            direction = Vector((0.0, 0.0, -1.0))
        direction.normalize()
        distance = 0.0
    else:
        direction.normalize()
    if exact_radius:
        distance = reach
    else:
        distance = min(distance, reach)
    result.translation = pivot + (direction * distance)
    return result


def _surface_contact_rotate_simulated_pose_toward(
    context,
    guide,
    armature,
    pose_bone,
    anchor,
    target,
    *,
    stabilize_smart_roll=True,
):
    if _surface_contact_guide_aim_influence(guide) <= 1.0e-8:
        return False
    try:
        # A direct pin drag is relative to the pose at mouse-down. The old
        # absolute aim solve treated every target sample as a fresh contact
        # and could pull a torso-rotated leg back toward the global front
        # direction. Apply only the delta from the captured opposite rod end
        # to the current target, using the captured pose as the base.
        reference = (
            _state.get("pin_target_drag_references", {}).get(guide.name)
            if _state.get("pin_target_dragging", False)
            else None
        )
        if reference is not None:
            reference_target = Vector(reference["target"])
            reference_opposite = Vector(reference["opposite"])
            reference_pose = Matrix(reference["pose_world"])
            reference_vector = reference_target - reference_opposite
            current_vector = Vector(target) - reference_opposite
            if (
                reference_vector.length_squared > 1.0e-12
                and current_vector.length_squared > 1.0e-12
            ):
                rotation = reference_vector.normalized().rotation_difference(
                    current_vector.normalized()
                )
                if abs(float(rotation.angle)) > 1.0e-7:
                    rotated_world = (
                        Matrix.Translation(reference_opposite)
                        @ rotation.to_matrix().to_4x4()
                        @ Matrix.Translation(-reference_opposite)
                        @ reference_pose
                    )
                    _set_pose_bone_constrained_output_matrix(
                        context,
                        armature,
                        pose_bone,
                        armature.matrix_world.inverted_safe()
                        @ rotated_world,
                    )
                    return True
            return False
        changed = False
        current_anchor = Vector(anchor)
        support = guide.get(SURFACE_CONTACT_SUPPORT_PROPERTY)
        geometry_name = str(
            guide.get(
                SURFACE_CONTACT_GEOMETRY_BONE_PROPERTY,
                pose_bone.name,
            )
        )
        geometry_bone = armature.pose.bones.get(geometry_name)
        contact_at_head = None
        if (
            support is not None
            and len(support) >= 3
            and geometry_bone is not None
        ):
            support_y = float(support[1])
            geometry_length = max(
                1.0e-8,
                float(geometry_bone.length),
            )
            contact_at_head = (
                abs(support_y) <= abs(support_y - geometry_length)
            )
        smart_aim = _surface_contact_preserves_rigid_orientation(guide)
        smooth_detached_aim = bool(
            smart_aim
            and (
                guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)
                or _surface_contact_snap_key(guide)
                in _state.setdefault("pin_snap_detached", set())
                or guide.name in _state.setdefault(
                    "pin_snap_parent_transform_guides", set()
                )
            )
        )
        # At coincidence there is no magnetic direction to solve. In
        # particular, do not feed an identity aim into Smart roll
        # stabilization: its antiparallel fallback can manufacture a 180
        # degree flip when an indirectly moved limb returns to the pin.
        if (
            smooth_detached_aim
            and (Vector(target) - current_anchor).length_squared <= 1.0e-12
        ):
            return False
        # One pass is mathematically exact for an unconstrained bone. A second
        # bounded pass removes any small residual introduced by constraints or
        # Blender's pose evaluation without creating a feedback loop.
        for _correction in range(1 if smooth_detached_aim else 2):
            bone_world = armature.matrix_world @ pose_bone.matrix
            head = bone_world.translation.copy()
            tail = bone_world @ Vector(
                (0.0, max(1.0e-8, float(pose_bone.length)), 0.0)
            )
            # Aim the linked object's saved support pin, not the visible
            # pose-bone endpoint. The support is intentionally allowed to sit
            # off the bone axis on welded or asymmetrical geometry.
            use_head = (
                contact_at_head
                if contact_at_head is not None
                else (
                    (current_anchor - head).length_squared
                    <= (current_anchor - tail).length_squared
                )
            )
            pivot = tail if use_head else head
            if smart_aim:
                rod_opposite = _surface_contact_opposite_anchor_world(
                    context,
                    guide,
                )
                if rod_opposite is not None:
                    # The saved surface point and the opposite face point are
                    # the two ends of one rigid rod. Turning around the bone's
                    # head/tail can put the pink line at an angle to that rod
                    # when the welded object is offset from the bone. Use the
                    # actual opposite rod end so target, pink point, and rod
                    # stay on one straight line.
                    pivot = Vector(rod_opposite)
            current_vector = current_anchor - pivot
            smart_direction = (
                _surface_contact_smart_cast_direction_world(context, guide)
                if smart_aim
                else None
            )
            # A loose pink limb must be able to turn through a full circle.
            # The cast-ray intersection below is useful while creating a
            # contact, but it has no solution for some detached angles and
            # used to stop torso-driven limbs at that boundary. Detached
            # motion instead uses the exact support-point direction.
            smart_vectors = (
                _surface_contact_smart_aim_vectors(
                    pivot,
                    current_anchor,
                    target,
                    smart_direction,
                    guide=guide,
                )
                if smart_direction is not None and not smooth_detached_aim
                else None
            )
            target_vector = Vector(target) - pivot
            if (
                current_vector.length_squared <= 1.0e-12
                or target_vector.length_squared <= 1.0e-12
            ):
                break
            current_direction, target_direction = (
                smart_vectors
                if smart_vectors is not None
                else (current_vector.normalized(), target_vector.normalized())
            )
            aligned = current_direction.dot(target_direction) >= 1.0 - 1.0e-10
            if aligned and not smart_aim:
                break
            rotation = Quaternion() if aligned else (
                _surface_contact_stable_rotation(
                    guide, bone_world, current_direction, target_direction
                )
            )
            if rotation is None:
                break
            # Detached translation is rebuilt from the immutable raw release
            # pose on every mouse sample. Capping pressure-release aim to one
            # small step therefore never accumulated: the limb repeated the
            # same angle forever and appeared to lose magnetism after passing
            # the pin. Runtime suppresses this call while the authored pink
            # endpoint is below the surface; once it is above, the exact
            # shortest-arc turn is the continuous collision-safe solution.
            if smart_aim and stabilize_smart_roll:
                rotation = _surface_contact_stabilize_smart_roll(
                    context, guide, rotation, target_direction
                )
            if abs(float(rotation.angle)) <= 1.0e-7:
                break
            rotated_world = (
                Matrix.Translation(pivot)
                @ rotation.to_matrix().to_4x4()
                @ Matrix.Translation(-pivot)
                @ bone_world
            )
            _set_pose_bone_constrained_output_matrix(
                context,
                armature,
                pose_bone,
                armature.matrix_world.inverted_safe() @ rotated_world,
            )
            changed = True
            current_anchor = _surface_contact_bone_anchor_world(
                context,
                guide,
                live_pose = True,
            )
            if current_anchor is None:
                break
        return changed
    except (
        AttributeError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ):
        return False


def _surface_contact_update_simulated_solver(
    context,
    guide,
    desired_point = None,
    insert_keys = False,
    max_iterations = SURFACE_CONTACT_LIVE_SOLVER_ITERATIONS,
    rotate_pose = True,
    exact_target = False,
):
    if (
        str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
        != SURFACE_CONTACT_KIND_SIMULATED
    ):
        return False
    armature = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
    )
    pose_bone = (
        armature.pose.bones.get(
            str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
        )
        if armature is not None and getattr(armature, "pose", None)
        else None
    )
    if armature is None or pose_bone is None:
        return False

    target = (
        Vector(desired_point)
        if desired_point is not None
        else guide.matrix_world.translation.copy()
    )
    # Blender's evaluated mesh/pose round-trip is noisier than 1e-7. A
    # sub-micron threshold causes every unrelated depsgraph update to apply
    # another tiny correction, accumulating into visible contact drift.
    tolerance = _surface_contact_settle_tolerance(guide)
    if exact_target:
        tolerance = min(tolerance, 1.0e-7)
    changed = False
    rotated = False
    previous_error = float("inf")
    for _iteration in range(max(1, int(max_iterations))):
        anchor = _surface_contact_stored_anchor_world(context, guide)
        if anchor is None:
            break
        delta = target - anchor
        error = delta.length
        if error <= tolerance:
            break
        if error >= previous_error - (tolerance * 0.05):
            break
        previous_error = error
        if (
            rotate_pose
            and not rotated
            and _surface_contact_rotate_simulated_pose_toward(
                context,
                guide,
                armature,
                pose_bone,
                anchor,
                target,
            )
        ):
            changed = True
            rotated = True
            anchor = _surface_contact_stored_anchor_world(context, guide)
            if anchor is None:
                break
            delta = target - anchor
            if delta.length <= tolerance:
                break
        armature_delta = (
            armature.matrix_world.inverted_safe().to_3x3() @ delta
        )
        matrix = pose_bone.matrix.copy()
        matrix.translation += armature_delta
        _set_pose_bone_constrained_output_matrix(
            context,
            armature,
            pose_bone,
            matrix,
        )
        changed = True

    if (
        changed
        and insert_keys
        and bool(
            getattr(context.scene.tool_settings, "use_keyframe_insert_auto", False)
        )
    ):
        _insert_bone_keys(
            pose_bone,
            int(context.scene.frame_current),
        )
    return changed


def _surface_contact_refine_control_solver(
    context,
    guide,
    desired_point = None,
    max_iterations = 8,
):
    if (
        str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
        != SURFACE_CONTACT_KIND_CONTROL
    ):
        return False
    solver = _surface_contact_solver_from_guide(guide)
    if solver is None:
        return False

    target = (
        Vector(desired_point)
        if desired_point is not None
        else guide.matrix_world.translation.copy()
    )
    tolerance = max(
        1.0e-7,
        float(guide.get(SURFACE_CONTACT_SIZE_PROPERTY, 0.05)) * 1.0e-6,
    )
    changed = _surface_contact_update_control_solver(guide)
    if changed:
        context.view_layer.update()
    best_matrix = solver.matrix_world.copy()
    best_error = float("inf")
    stalled = 0
    for _iteration in range(max(1, int(max_iterations))):
        anchor = _surface_contact_stored_anchor_world(context, guide)
        if anchor is None:
            break
        delta = target - anchor
        error = delta.length
        if error < best_error:
            improvement = best_error - error
            best_error = error
            best_matrix = solver.matrix_world.copy()
            stalled = 0 if improvement > tolerance * 0.1 else stalled + 1
        else:
            stalled += 1
        if error <= tolerance or stalled >= 3:
            break
        matrix = solver.matrix_world.copy()
        matrix.translation += delta
        solver.matrix_world = matrix
        context.view_layer.update()
        changed = True

    anchor = _surface_contact_stored_anchor_world(context, guide)
    final_error = (target - anchor).length if anchor is not None else float("inf")
    if best_error < final_error:
        solver.matrix_world = best_matrix
        context.view_layer.update()
        changed = True
    if changed:
        _surface_contact_store_solver_local_matrix(guide)
    return changed


def _surface_contact_seed_fallback_solver(
    context,
    guide,
    armature,
    geometry_bone_name,
    support_objects,
):
    if str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, "")) != SURFACE_CONTACT_KIND_IK:
        return False
    solver = _surface_contact_solver_from_guide(guide)
    if solver is None:
        return False

    evaluated_armature, _geometry_bone, current_anchor = (
        _surface_contact_smart_anchor_world(
            context,
            armature,
            geometry_bone_name,
            support_objects,
        )
    )
    effector = evaluated_armature.pose.bones.get(
        str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
    )
    if effector is None or current_anchor is None:
        return False

    pivot = evaluated_armature.matrix_world @ effector.head
    current_tail = evaluated_armature.matrix_world @ effector.tail
    current_vector = current_anchor - pivot
    target_vector = guide.matrix_world.translation - pivot
    tail_vector = current_tail - pivot
    if (
        current_vector.length_squared <= 1.0e-12
        or target_vector.length_squared <= 1.0e-12
        or tail_vector.length_squared <= 1.0e-12
    ):
        return False

    rotation = current_vector.rotation_difference(target_vector)
    solver_world = solver.matrix_world.copy()
    solver_world.translation = pivot + (rotation @ tail_vector)
    solver.matrix_world = _surface_contact_clamp_solver_matrix(
        context,
        guide,
        solver_world,
    )
    context.view_layer.update()
    return True


def _surface_contact_update_fallback_solver(context, guide):
    if (
        str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
        != SURFACE_CONTACT_KIND_IK
    ):
        return False
    solver = _surface_contact_solver_from_guide(guide)
    armature = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
    )
    support = guide.get(SURFACE_CONTACT_SUPPORT_PROPERTY)
    if (
        solver is None
        or armature is None
        or getattr(armature, "pose", None) is None
        or support is None
        or len(support) < 3
    ):
        return False

    try:
        depsgraph = context.evaluated_depsgraph_get()
        evaluated_armature = armature.evaluated_get(depsgraph)
        effector = evaluated_armature.pose.bones.get(
            str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
        )
        geometry_bone = evaluated_armature.pose.bones.get(
            str(
                guide.get(
                    SURFACE_CONTACT_GEOMETRY_BONE_PROPERTY,
                    guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""),
                )
            )
        )
        if effector is None or geometry_bone is None:
            return False

        pivot = evaluated_armature.matrix_world @ effector.head
        tail = evaluated_armature.matrix_world @ effector.tail
        anchor = (
            evaluated_armature.matrix_world
            @ geometry_bone.matrix
            @ Vector(tuple(float(value) for value in support[:3]))
        )
        current_vector = anchor - pivot
        target_vector = guide.matrix_world.translation - pivot
        tail_vector = tail - pivot
        if (
            current_vector.length_squared <= 1.0e-12
            or target_vector.length_squared <= 1.0e-12
            or tail_vector.length_squared <= 1.0e-12
        ):
            return False

        rotation = current_vector.rotation_difference(target_vector)
        desired_tail = pivot + (rotation @ tail_vector)
        if (desired_tail - solver.matrix_world.translation).length <= 1.0e-7:
            return False
        solver_world = solver.matrix_world.copy()
        solver_world.translation = desired_tail
        solver.matrix_world = solver_world
        return True
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return False


def _surface_contact_align_solver(
    context,
    guide,
    armature,
    geometry_bone_name,
    support_objects,
):
    solver = _surface_contact_solver_from_guide(guide)
    primary, _secondary = _surface_contact_constraints(guide)
    contact_kind = str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
    if (
        solver is None
        or (
            primary is None
            and contact_kind != SURFACE_CONTACT_KIND_SIMULATED
        )
    ):
        return None, None

    stored_support = guide.get(SURFACE_CONTACT_SUPPORT_PROPERTY)
    if stored_support is None or len(stored_support) < 3:
        return None, None

    if contact_kind == SURFACE_CONTACT_KIND_SIMULATED:
        target_point = guide.matrix_world.translation.copy()
        _surface_contact_update_simulated_solver(
            context,
            guide,
            desired_point = target_point,
            # Smart Pin is a rigid point on this single pose bone. Initial
            # contact therefore needs only a bounded translation settle; a
            # rotational multi-pass is expensive and unstable when the limb
            # begins slightly inside the detected surface.
            max_iterations = 2,
            rotate_pose = False,
            exact_target = True,
        )
        contact_anchor = _surface_contact_stored_anchor_world(context, guide)
        if contact_anchor is None:
            return None, None
        tolerance = _surface_contact_settle_tolerance(guide)
        if (target_point - contact_anchor).length > tolerance:
            return None, None
        _surface_contact_store_solver_local_matrix(guide)
        guide[SURFACE_CONTACT_AIM_PROPERTY] = 1.0
        return contact_anchor, Vector(tuple(stored_support[:3]))

    if (
        contact_kind == SURFACE_CONTACT_KIND_IK
    ):
        primary.influence = 0.0
        context.view_layer.update()
        if not _surface_contact_seed_fallback_solver(
            context,
            guide,
            armature,
            geometry_bone_name,
            support_objects,
        ):
            return None, None
        primary.influence = 1.0
        context.view_layer.update()
        contact_anchor = _surface_contact_stored_anchor_world(context, guide)
        if contact_anchor is None:
            return None, None
        _surface_contact_store_solver_local_matrix(guide)
        guide[SURFACE_CONTACT_AIM_PROPERTY] = 1.0
        return contact_anchor, Vector(tuple(stored_support[:3]))

    primary.influence = 1.0
    context.view_layer.update()
    _surface_contact_seed_fallback_solver(
        context,
        guide,
        armature,
        geometry_bone_name,
        support_objects,
    )
    target_point = guide.matrix_world.translation.copy()
    tolerance = max(
        1.0e-5,
        float(guide.get(SURFACE_CONTACT_SIZE_PROPERTY, 0.05)) * 0.00025,
    )
    best_error = float("inf")
    best_solver_world = solver.matrix_world.copy()
    best_anchor = None
    stalled_iterations = 0
    for _iteration in range(16):
        evaluated_armature, evaluated_geometry_bone, contact_anchor = (
            _surface_contact_smart_anchor_world(
                context,
                armature,
                geometry_bone_name,
                support_objects,
            )
        )
        if evaluated_geometry_bone is None or contact_anchor is None:
            return None, None
        delta = target_point - contact_anchor
        if delta.length < best_error:
            improvement = best_error - delta.length
            best_error = delta.length
            best_solver_world = solver.matrix_world.copy()
            best_anchor = contact_anchor.copy()
            stalled_iterations = 0 if improvement > tolerance * 0.1 else stalled_iterations + 1
        else:
            stalled_iterations += 1
        if delta.length <= tolerance:
            break
        solver_world = solver.matrix_world.copy()
        solver_world.translation += delta
        solver_world = _surface_contact_clamp_solver_matrix(
            context,
            guide,
            solver_world,
        )
        if (solver_world.translation - solver.matrix_world.translation).length <= 1.0e-8:
            break
        solver.matrix_world = solver_world
        context.view_layer.update()
        if stalled_iterations >= 4:
            break

    evaluated_armature, evaluated_geometry_bone, contact_anchor = (
        _surface_contact_smart_anchor_world(
            context,
            armature,
            geometry_bone_name,
            support_objects,
        )
    )
    final_error = (
        (target_point - contact_anchor).length
        if evaluated_geometry_bone is not None and contact_anchor is not None
        else float("inf")
    )
    if best_anchor is not None and best_error < final_error:
        solver.matrix_world = best_solver_world
        context.view_layer.update()
        evaluated_armature, evaluated_geometry_bone, contact_anchor = (
            _surface_contact_smart_anchor_world(
                context,
                armature,
                geometry_bone_name,
                support_objects,
            )
        )
        final_error = (
            (target_point - contact_anchor).length
            if evaluated_geometry_bone is not None and contact_anchor is not None
            else float("inf")
        )
    if evaluated_geometry_bone is None or contact_anchor is None:
        return None, None
    local_support = Vector(tuple(float(value) for value in stored_support[:3]))
    _surface_contact_store_solver_local_matrix(guide)
    guide[SURFACE_CONTACT_AIM_PROPERTY] = 1.0
    return contact_anchor, local_support


def _surface_contact_remove_guide(context, guide, preserve_frame = None):
    cache_key = _surface_contact_pose_cache_key(guide)
    guide_name = getattr(guide, "name", "")
    # Save this before marker/solver cleanup. Legacy or stale files can point
    # the solver property back at the Contact guide itself; cleanup must still
    # be able to remove the guide without reading an invalid StructRNA.
    guide_action = _dynamic_parent_owner_action(guide)
    guide_action_name = (
        str(getattr(guide_action, "name", ""))
        if guide_action is not None
        else ""
    )
    armature = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
    )
    bone_name = str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
    _surface_contact_remove_history_pose_lock(getattr(armature, "name", ""), bone_name)
    removed_snap_key = _surface_contact_purge_removed_runtime(
        guide,
        armature,
        bone_name,
    )
    # Explicit deletion invalidates a paired transform record. During native
    # Undo/Redo, however, Blender can briefly remove and recreate non-history
    # guide objects while the paired contact pose still has to be restored.
    # Do not discard that transition during this temporary history rebuild.
    if not (
        _state.get("pin_history_active", False)
        or _state.get("pin_history_syncing", False)
    ):
        _state["pin_snap_native_history_transition"] = None
        _state["pin_snap_native_history_transition_backup"] = None
        _state["pin_snap_native_history_pre_selected"] = {}
        _state["pin_snap_native_history_expected_index"] = None
    for cache_name in (
        "surface_contact_valid_poses",
        "surface_contact_owner_pose_bases",
        "surface_contact_transform_signatures",
        "surface_contact_rotation_axes",
    ):
        _state.setdefault(cache_name, {}).pop(cache_key, None)
    _state.setdefault("pin_snap_contact_target_locks", {}).pop(
        guide_name,
        None,
    )
    _state.setdefault("pin_snap_parent_attachment_states", {}).pop(
        guide_name,
        None,
    )
    for state_name in (
        "pin_snap_parent_transform_guides",
        "pin_snap_latches",
        "pin_snap_detached",
        "pin_snap_departing",
    ):
        values = _state.setdefault(state_name, set())
        values.discard(guide_name)
        values.discard(cache_key)
    if armature is not None:
        _state.setdefault("pin_snap_live_pose_matrices", {}).pop(
            (_armature_session_uid(armature), bone_name),
            None,
        )
    selected_key = _pin_selected_target_key()
    if selected_key.startswith("CONTACT:") and selected_key.endswith(
        f":{guide_name}"
    ):
        _pin_deselect_target(push_history = False)
    _surface_contact_clear_snap_departure(guide)
    _marker_object, marker_owner = _surface_contact_owner_from_guide(guide)
    constraint_object, constraint_owner = _surface_contact_constraint_owner_from_guide(
        guide
    )
    primary, secondary = _surface_contact_constraints(guide)
    release_object = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_RELEASE_OBJECT_PROPERTY, ""))
    ) or constraint_object
    release_bone_name = str(
        guide.get(
            SURFACE_CONTACT_RELEASE_BONE_PROPERTY,
            guide.get(SURFACE_CONTACT_CONSTRAINT_BONE_PROPERTY, ""),
        )
    )
    target_world = None
    if preserve_frame is not None and release_object is not None:
        target_world = _surface_contact_target_world_matrix(
            context,
            release_object,
            release_bone_name,
        )

    _surface_contact_remove_markers(guide, marker_owner)
    _surface_contact_remove_constraint(constraint_owner, secondary)
    _surface_contact_remove_constraint(constraint_owner, primary)
    _surface_contact_restore_stretch(guide)
    solver = _surface_contact_solver_from_guide(guide)
    _surface_contact_remove_solver_constraints(
        constraint_owner,
        guide,
        solver,
    )
    if solver is not None and solver != guide:
        bpy.data.objects.remove(solver, do_unlink = True)
    context.view_layer.update()

    if target_world is not None and release_object is not None:
        _surface_contact_set_target_world_matrix(
            context,
            release_object,
            release_bone_name,
            target_world,
        )

    live_guide = bpy.data.objects.get(guide_name)
    if live_guide is not None:
        bpy.data.objects.remove(live_guide, do_unlink = True)
    _surface_contact_invalidate_guide_cache()
    _surface_contact_clear_orphaned_pose_snapshots()
    _state.setdefault("pin_snap_latches", set()).discard(removed_snap_key)
    # Marker rebuilding may already remove an unused guide Action. Resolve it
    # again by name instead of dereferencing the stale StructRNA retained at
    # function entry.
    remaining_action = (
        bpy.data.actions.get(guide_action_name)
        if guide_action_name
        else None
    )
    if remaining_action is not None and remaining_action.users == 0:
        bpy.data.actions.remove(remaining_action)
    _surface_contact_sync_stretch_policy(
        tuple(_surface_contact_guides()),
        int(getattr(context.scene, "frame_current", 0)),
    )
    _surface_contact_store_persistent_pose_snapshots()
    _yellow_refresh_runtime(context)
    return True
