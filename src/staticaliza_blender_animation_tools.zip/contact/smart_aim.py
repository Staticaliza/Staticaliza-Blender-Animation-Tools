"""Continuous Smart-contact aim branch selection."""

from ..core.runtime import *  # noqa: F403


def _surface_contact_smart_aim_vectors(
    pivot, anchor, target, cast_direction, guide=None
):
    """Choose one continuous exact ray root through forward/backward motion."""
    ray_origin = Vector(anchor) - Vector(pivot)
    target_vector = Vector(target) - Vector(pivot)
    cast_direction = Vector(cast_direction).normalized()
    if (
        ray_origin.length_squared <= 1.0e-12
        or target_vector.length_squared <= 1.0e-12
    ):
        return None
    projection = ray_origin.dot(cast_direction)
    discriminant = (
        projection * projection
        - (ray_origin.length_squared - target_vector.length_squared)
    )
    if discriminant < 0.0:
        return None
    root = math.sqrt(max(0.0, discriminant))
    all_candidates = tuple(
        (
            distance,
            (ray_origin + cast_direction * distance).normalized(),
        )
        for distance in (-projection + root, -projection - root)
    )
    candidates = tuple(
        item for item in all_candidates if item[0] >= -1.0e-8
    ) or all_candidates
    if not candidates:
        return None
    target_direction = target_vector.normalized()
    branches = _state.setdefault("surface_contact_smart_aim_branches", {})
    branch_key = (
        _surface_contact_pose_cache_key(guide)
        if guide is not None
        else None
    )
    previous = branches.get(branch_key) if branch_key is not None else None
    chosen = max(
        candidates,
        key=lambda item: item[1].dot(
            Vector(previous) if previous is not None else target_direction
        ),
    )
    if branch_key is not None:
        branches[branch_key] = chosen[1].copy()
    return chosen[1], target_direction
