"""Surface-contact solver and state management."""
