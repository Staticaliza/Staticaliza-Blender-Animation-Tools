"""Surface-contact creation, release, and clear operators."""

from ..core.runtime import *  # noqa: F403
def _reconcile_surface_contact_markers(context, armature = None):
    if _state.get("surface_contact_reconciling", False):
        return False
    _state["surface_contact_reconciling"] = True
    try:
        _surface_contact_invalidate_detached_key_cache()
        changed = False
        guides = tuple(_surface_contact_guides())
        for guide in guides:
            if (
                armature is not None
                and str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
                != armature.name
            ):
                continue
            _target_object, owner = _surface_contact_owner_from_guide(guide)
            if owner is None:
                _surface_contact_remove_guide(
                    context,
                    guide,
                    preserve_frame = int(context.scene.frame_current),
                )
                changed = True
                continue
            changed = _surface_contact_strip_scale_animation(guide) or changed
            marker_points = _surface_contact_marker_points(owner)
            start = int(guide.get(SURFACE_CONTACT_START_PROPERTY, 0))
            start_value = marker_points.get(start)
            if start_value is None or float(start_value) < 0.5:
                _surface_contact_remove_guide(
                    context,
                    guide,
                    preserve_frame = int(context.scene.frame_current),
                )
                changed = True
                continue
            next_starts = tuple(
                int(other.get(SURFACE_CONTACT_START_PROPERTY, 0))
                for other in guides
                if other != guide
                and _surface_contact_guide_matches_owner(other, owner)
                and int(other.get(SURFACE_CONTACT_START_PROPERTY, 0)) > start
            )
            next_start = min(next_starts) if next_starts else None
            release_frames = tuple(sorted(
                frame
                for frame, value in marker_points.items()
                if frame > start
                and float(value) < 0.5
                and (next_start is None or frame < next_start)
            ))
            marker_end = release_frames[0] if release_frames else None
            stored_end = (
                int(guide[SURFACE_CONTACT_END_PROPERTY])
                if SURFACE_CONTACT_END_PROPERTY in guide
                else None
            )
            if marker_end is None:
                if stored_end is not None:
                    del guide[SURFACE_CONTACT_END_PROPERTY]
                    changed = True
            elif stored_end != marker_end:
                guide[SURFACE_CONTACT_END_PROPERTY] = marker_end
                changed = True
            target_frames = _surface_contact_target_frames(guide)
            retained_target_frames = tuple(
                frame
                for frame in target_frames
                if frame in marker_points and float(marker_points[frame]) >= 0.5
            )
            if retained_target_frames != target_frames:
                for removed_frame in set(target_frames) - set(retained_target_frames):
                    _surface_contact_delete_guide_transform_keys(
                        guide,
                        removed_frame,
                    )
                _surface_contact_set_target_frames(
                    guide,
                    retained_target_frames,
                )
                changed = True
            changed = (
                _surface_contact_sync_guide_key_styles(owner, guide)
                or changed
            )

        armatures = (
            (armature,)
            if armature is not None
            else tuple(
                obj
                for obj in bpy.data.objects
                if obj.type == "ARMATURE" and getattr(obj, "pose", None)
            )
        )
        for current_armature in armatures:
            if current_armature is None or getattr(current_armature, "pose", None) is None:
                continue
            for pose_bone in current_armature.pose.bones:
                if SURFACE_CONTACT_MARKER_PROPERTY not in pose_bone:
                    continue
                if _surface_contact_expected_markers(pose_bone):
                    continue
                changed = _surface_contact_rebuild_markers(
                    pose_bone,
                    pose_bone.name,
                ) or changed

        if changed:
            _surface_contact_invalidate_guide_cache()
            context.view_layer.update()
            _sync_surface_contact_constraints(
                context.scene,
                respect_selected = True,
                force_unselected = False,
                solve_simulated = False,
                solve_guides = False,
                sync_dynamic_parent = False,
            )
            # Flush metadata/constraint dirtiness while reconciliation guards
            # are still active, so no queued next-tick depsgraph event can
            # become a delayed SIMULATED pose correction.
            context.view_layer.update()
            _tag_redraw_all_view3d()
        return changed
    finally:
        _state["surface_contact_reconciling"] = False


def _surface_contact_geometry_bone_candidates(selected_bone, relation):
    ordered = []
    if selected_bone is not None:
        ordered.append(selected_bone)
    if relation is not None:
        ordered.append(relation.get("effector"))
        ordered.extend(relation.get("chain", ()))

    seen = set()
    result = []
    for pose_bone in ordered:
        if pose_bone is None or pose_bone.name in seen:
            continue
        seen.add(pose_bone.name)
        result.append(pose_bone)
    return tuple(result)


def _surface_contact_smart_anchor_world(
    context,
    armature,
    bone_name,
    support_objects,
):
    context.view_layer.update()
    depsgraph = context.evaluated_depsgraph_get()
    evaluated_armature = armature.evaluated_get(depsgraph)
    evaluated_bone = evaluated_armature.pose.bones.get(bone_name)
    if evaluated_bone is None:
        return evaluated_armature, None, None
    anchor, _object_name, _object_local = _yellow_mode3_anchor(
        context,
        depsgraph,
        armature,
        evaluated_armature,
        support_objects,
        bone_name,
    )
    return evaluated_armature, evaluated_bone, anchor


def _surface_contact_control_target(relation, armature, effector):
    if relation is not None:
        target_object = relation.get("target_object")
        target_bone = relation.get("target_bone")
        if target_object is not None and target_bone is not None:
            return target_object, target_bone.name, True
        if (
            target_object is not None
            and getattr(target_object, "type", "") != "ARMATURE"
        ):
            return target_object, "", True
    return armature, effector.name, False

class ANIMATOR_UTILS_OT_surface_contact_create(bpy.types.Operator):
    bl_idname = "staticaliza.surface_contact_create"
    bl_label = "Keyframe Start"
    bl_description = (
        "Place the selected limb's configured contact point on the nearest "
        "detected surface without snapping across an air gap"
    )
    bl_options = {"REGISTER", "UNDO"}

    pin_mode: bpy.props.EnumProperty(
        name = "Pin Position",
        description = "Choose the linked-limb point used by this contact",
        items = (
            ("MODE_3", "Smart", "Use the selected welded-object face"),
            ("MODE_4", "Bone Start", "Use the selected contact bone's head"),
            ("MODE_2", "Bone Center", "Use the center of the linked weighted geometry"),
            ("MODE_1", "Bone End", "Use the selected contact bone's tail"),
        ),
        default = "MODE_3",
    )
    cast_axis: bpy.props.EnumProperty(
        name = "Axis",
        description = "Choose the axis cast toward the contact surface",
        items = PIN_AXIS_ITEMS,
        default = "Y_NEG",
    )
    @classmethod
    def poll(cls, context):
        return bool(
            context.mode == "POSE"
            and _selected_pose_bones_by_owner(context, include_virtual_pin=True)
        )
    def draw(self, context):
        self.layout.prop(self, "pin_mode", text = "Position")
        self.layout.prop(self, "cast_axis", text = "Axis")
    def execute(self, context):
        if not self.properties.is_property_set("pin_mode"):
            self.pin_mode = str(
                getattr(
                    context.window_manager,
                    "surface_contact_pin_mode",
                    "MODE_3",
                )
            )
        if not self.properties.is_property_set("cast_axis"):
            self.cast_axis = str(
                getattr(
                    context.window_manager,
                    "surface_contact_cast_axis",
                    "Y_NEG",
                )
            )
        context.window_manager.surface_contact_cast_axis = self.cast_axis
        if _state.get("surface_contact_creation_active", False):
            return {"CANCELLED"}
        previous_solver_guard = bool(
            _state.get("surface_contact_solver_syncing", False)
        )
        _state["surface_contact_creation_active"] = True
        _state["surface_contact_solver_syncing"] = True
        try:
            return self._execute_guarded(context)
        finally:
            _state["surface_contact_solver_syncing"] = previous_solver_guard
            _state["surface_contact_creation_active"] = False
    def _execute_guarded(self, context):
        targets = tuple(
            (armature, pose_bone)
            for armature, pose_bones in _selected_pose_bones_by_owner(
                context, include_virtual_pin=True
            ).items()
            for pose_bone in pose_bones
        )
        if not targets:
            return {"CANCELLED"}
        completed = 0
        for armature, selected_bone in targets:
            result = self._execute_bone(
                context,
                armature,
                selected_bone,
            )
            if result == {"FINISHED"}:
                completed += 1
        if completed > 1:
            self.report(
                {"INFO"},
                f"Contact enabled for {completed} selected bones.",
            )
        return {"FINISHED"} if completed else {"CANCELLED"}

    def _execute_bone(self, context, armature, selected_bone):
        relation = _surface_contact_ik_relation(armature, selected_bone)
        effector = relation["effector"] if relation is not None else selected_bone
        initial_effector_matrix = effector.matrix.copy()
        frame = int(context.scene.frame_current)
        exact_guides, previous_guide, carried_end = (
            _surface_contact_retarget_plan(armature, effector, frame)
        )

        evaluated_armature = None
        evaluated_geometry_bone = None
        part = None
        geometry_points = ()
        support_objects = ()
        for geometry_bone in _surface_contact_geometry_bone_candidates(
            selected_bone,
            relation,
        ):
            (
                evaluated_armature,
                evaluated_geometry_bone,
                part,
                geometry_points,
                support_objects,
            ) = _surface_contact_part_geometry(
                context,
                armature,
                geometry_bone,
            )
            if part is not None and geometry_points:
                break
        if part is None or not geometry_points:
            self.report(
                {"ERROR"},
                "No connected mesh object was found for the selected endpoint.",
            )
            return {"CANCELLED"}
        geometry_bone_name = evaluated_geometry_bone.name
        depsgraph = context.evaluated_depsgraph_get()
        contact_anchor, smart_object_name, smart_object_local = (
            _surface_contact_creation_anchor(
                context,
                depsgraph,
                armature,
                evaluated_armature,
                evaluated_geometry_bone,
                part,
                geometry_points,
                support_objects,
                pin_mode=self.pin_mode,
                pin_axis=self.cast_axis,
            )
        )
        if contact_anchor is None:
            self.report(
                {"ERROR"},
                "Unable to find the connected object's Smart Pin contact point.",
            )
            return {"CANCELLED"}
        surface, surface_point, surface_normal, bone_length = (
            _surface_contact_detect_surface(
                context,
                armature,
                evaluated_armature,
                evaluated_geometry_bone,
                geometry_points,
                support_objects,
                contact_anchor,
                smart_object_name,
                cast_axis=self.cast_axis,
            )
        )
        if surface is None or surface_point is None or surface_normal is None:
            self.report(
                {"ERROR"},
                "No contact surface was found along the selected axis.",
            )
            return {"CANCELLED"}

        transition_guides = list(exact_guides)
        if previous_guide is not None and previous_guide not in transition_guides:
            transition_guides.append(previous_guide)
        suspended = _surface_contact_suspend_guides(transition_guides)
        plane_world = _surface_contact_plane_matrix(
            surface_point,
            surface_normal,
            _surface_contact_target_world_matrix(
                context,
                armature,
                effector.name,
            ),
        )

        guide = _surface_contact_create_guide(
            context,
            armature,
            effector,
            armature,
            effector.name,
            geometry_bone_name,
            plane_world,
            surface,
            surface_point,
            surface_normal,
            bone_length,
            frame,
        )
        guide[SURFACE_CONTACT_PIN_MODE_PROPERTY] = self.pin_mode
        guide[SURFACE_CONTACT_OBJECT_PROPERTY] = part.name
        guide[SURFACE_CONTACT_CAST_AXIS_PROPERTY] = self.cast_axis
        if smart_object_name and smart_object_local is not None:
            guide[SURFACE_CONTACT_SMART_OBJECT_PROPERTY] = smart_object_name
            guide[SURFACE_CONTACT_SMART_LOCAL_PROPERTY] = tuple(
                float(value) for value in smart_object_local
            )
        geometry_world = (
            evaluated_armature.matrix_world @ evaluated_geometry_bone.matrix
        )
        guide[SURFACE_CONTACT_SUPPORT_PROPERTY] = tuple(
            geometry_world.inverted_safe() @ contact_anchor
        )
        try:
            primary, _solver = _surface_contact_add_dot_constraint(
                context,
                guide,
                armature,
                effector,
                relation,
            )
        except Exception:
            _surface_contact_remove_guide(context, guide)
            _surface_contact_restore_suspended(suspended)
            raise

        if _solver is None or (
            primary is None
            and str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
            != SURFACE_CONTACT_KIND_SIMULATED
        ):
            _surface_contact_remove_guide(context, guide)
            _surface_contact_restore_suspended(suspended)
            self.report({"ERROR"}, "Unable to create the contact target constraint.")
            return {"CANCELLED"}
        initially_attached = _surface_contact_creation_is_attached(
            guide,
            contact_anchor,
            surface_point,
            surface_normal,
            bone_length,
        )
        if initially_attached:
            reachable_target = _surface_contact_project_reachable_target(
                context,
                guide,
                surface_point,
                surface_normal,
                align_initial = True,
            )
            if reachable_target is not None:
                _surface_contact_set_guide_surface_point(
                    context,
                    guide,
                    reachable_target[0],
                    reachable_target[1],
                )
            solved_anchor, final_support = _surface_contact_align_solver(
                context,
                guide,
                armature,
                geometry_bone_name,
                support_objects,
            )
            if solved_anchor is None or final_support is None:
                effector.matrix = initial_effector_matrix
                context.view_layer.update()
                _surface_contact_remove_guide(context, guide)
                _surface_contact_restore_suspended(suspended)
                self.report(
                    {"ERROR"},
                    "Unable to align the contact dots for this bone.",
                )
                return {"CANCELLED"}
        else:
            # Creating a target across an air gap must never author movement
            # into the selected limb or an unrelated regular control bone.
            effector.matrix = initial_effector_matrix
        # Creation has already decided and, when applicable, solved the
        # endpoint dot-to-dot. Publish that complete state before any
        # keyframe/depsgraph callback can observe an in-between contact.
        _surface_contact_publish_creation_attachment(
            guide,
            initially_attached,
        )

        _surface_contact_insert_marker(
            effector,
            effector.name,
            frame,
            1.0,
        )
        _surface_contact_keyframe_guide_transform(
            guide,
            frame,
            effector.name,
        )
        _surface_contact_keyframe_detached_state(
            guide,
            frame,
            not initially_attached,
        )
        _surface_contact_keyframe_simulated_pose(guide, frame)
        if previous_guide is not None:
            previous_guide[SURFACE_CONTACT_END_PROPERTY] = int(frame)
        for existing_guide in exact_guides:
            _surface_contact_remove_guide(
                context,
                existing_guide,
            )
        if carried_end is not None and int(carried_end) > frame:
            guide[SURFACE_CONTACT_END_PROPERTY] = int(carried_end)
        _surface_contact_rebuild_markers(
            effector,
            effector.name,
        )
        _sync_surface_contact_constraints(
            context.scene,
            solve_simulated = False,
            solve_guides = False,
            sync_dynamic_parent = False,
        )
        context.view_layer.update()
        # The freshly aligned pose is the collision rollback baseline. Seed
        # it before the user's first transform so a single large mouse sample
        # cannot enter the linked mesh or pass through the contacted surface.
        _surface_contact_store_valid_pose(guide)
        _surface_contact_store_owner_pose_base(guide)
        _surface_contact_seed_runtime_signatures(context, (guide,))

        _yellow_refresh_runtime(context)
        _tag_redraw_all_view3d()
        self.report(
            {"INFO"},
            (
                f"Contact enabled for {part.name} against {surface.name}."
                if initially_attached
                else (
                    f"Contact target placed on {surface.name}; "
                    "move the limb to attach."
                )
            ),
        )
        return {"FINISHED"}


class ANIMATOR_UTILS_OT_surface_contact_release(bpy.types.Operator):
    bl_idname = "staticaliza.surface_contact_release"
    bl_label = "Keyframe End"
    bl_description = "Release the selected planted endpoint without changing its visible pose"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        guide = _surface_contact_selected_guide(context, active_only = True)
        if guide is None:
            return False
        return int(context.scene.frame_current) > int(
            guide.get(SURFACE_CONTACT_START_PROPERTY, context.scene.frame_current)
        )

    def execute(self, context):
        guide = _surface_contact_selected_guide(context, active_only = True)
        if guide is None:
            return {"CANCELLED"}
        frame = int(context.scene.frame_current)
        start = int(guide.get(SURFACE_CONTACT_START_PROPERTY, frame))
        if frame <= start:
            self.report({"ERROR"}, "Release must be after the contact start frame.")
            return {"CANCELLED"}

        _marker_object, marker_owner = _surface_contact_owner_from_guide(guide)
        primary, _secondary = _surface_contact_constraints(guide)
        if (
            marker_owner is None
            or (
                primary is None
                and str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
                != SURFACE_CONTACT_KIND_SIMULATED
            )
        ):
            self.report({"ERROR"}, "The contact constraint is missing.")
            return {"CANCELLED"}

        effector_name = str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
        target_object = bpy.data.objects.get(
            str(guide.get(SURFACE_CONTACT_RELEASE_OBJECT_PROPERTY, ""))
        )
        target_bone_name = str(
            guide.get(SURFACE_CONTACT_RELEASE_BONE_PROPERTY, "")
        )
        target_world = _surface_contact_target_world_matrix(
            context,
            target_object,
            target_bone_name,
        ) if target_object is not None else None
        guide[SURFACE_CONTACT_END_PROPERTY] = frame
        _surface_contact_invalidate_guide_cache()
        _surface_contact_rebuild_markers(
            marker_owner,
            effector_name,
        )
        _sync_surface_contact_constraints(
            context.scene,
            solve_simulated = False,
            solve_guides = False,
            sync_dynamic_parent = False,
        )
        if target_world is not None and target_object is not None:
            _surface_contact_set_target_world_matrix(
                context,
                target_object,
                target_bone_name,
                target_world,
            )
        context.view_layer.update()

        _yellow_refresh_runtime(context)
        _tag_redraw_all_view3d()
        self.report({"INFO"}, f"Released {effector_name} at frame {frame}.")
        return {"FINISHED"}


class ANIMATOR_UTILS_OT_surface_contact_pivot(bpy.types.Operator):
    bl_idname = "staticaliza.surface_contact_pivot"
    bl_label = "Pivot Surface Contact Pin"
    bl_description = "Move the selected bone onto its Surface Contact pin"
    bl_options = {"REGISTER", "UNDO"}

    initial_state_json: bpy.props.StringProperty(options = {"HIDDEN"})
    pivot_method: bpy.props.EnumProperty(
        name = "Pivot Method",
        description = "Choose which side moves to the Surface Contact",
        items = (
            (
                "DIRECT",
                "Direct",
                "Move the linked bone onto the Surface Contact pin",
            ),
            (
                "INVERSE",
                "Inverse",
                "Move only the active Surface Contact pin onto its connected point",
            ),
        ),
        default = "DIRECT",
    )

    @classmethod
    def poll(cls, context):
        return (
            context.mode == "POSE"
            and bool(_surface_contact_selected_guides(
                context,
                active_only=True,
            ))
        )

    def draw(self, _context):
        self.layout.prop(self, "pivot_method", text = "Method")

    def invoke(self, context, _event):
        self.initial_state_json = _pin_pivot_capture_initial(
            context,
            "CONTACT",
        )
        return self.execute(context)

    def execute(self, context):
        if not self.initial_state_json:
            self.initial_state_json = _pin_pivot_capture_initial(
                context,
                "CONTACT",
            )
        if self.pivot_method == "INVERSE":
            previous_guard = bool(_state.get("surface_contact_reconciling", False))
            _state["surface_contact_reconciling"] = True
            try:
                _pin_pivot_restore_initial(context, self.initial_state_json)
                return _surface_contact_inverse_pivot_active(
                    context, self, self.initial_state_json,
                )
            finally:
                _state["surface_contact_reconciling"] = previous_guard
        _pin_pivot_restore_initial(context, self.initial_state_json)
        return _surface_contact_pivot_selected(context, self)


class ANIMATOR_UTILS_OT_surface_contact_clear(bpy.types.Operator):
    bl_idname = "staticaliza.surface_contact_clear"
    bl_label = "Clear Surface Contact"
    bl_description = "Remove the active Surface Contact segment while preserving the current pose"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return bool(_surface_contact_selected_guides(
            context,
            active_only = True,
        ))

    def execute(self, context):
        return _surface_contact_clear_selected(context, self)


class ANIMATOR_UTILS_OT_clear_contact_pose_transform(bpy.types.Operator):
    """Atomically clear a pose transform and settle any selected Contact."""

    bl_idname = "staticaliza.clear_contact_pose_transform"
    bl_label = "Clear Pose Transform"
    bl_description = (
        "Clear the selected pose transform and settle linked Surface Contacts"
    )
    bl_options = {"UNDO", "INTERNAL"}

    reset_mode: bpy.props.EnumProperty(
        items = (
            ("LOCATION", "Location", "Clear selected pose-bone locations"),
            ("ROTATION", "Rotation", "Clear selected pose-bone rotations"),
            ("SCALE", "Scale", "Clear selected pose-bone scales"),
        ),
        options = {"HIDDEN", "SKIP_SAVE"},
    )

    @classmethod
    def poll(cls, context):
        return bool(
            getattr(context, "mode", "") == "POSE"
            and (
                _pin_selected_target_key(context, validate=True)
                or int(_state.get("smart_dragger_selected_side", -1))
                in (0, 1)
                or _selected_pose_bones_by_owner(context)
            )
        )

    def execute(self, context):
        smart_side = int(_state.get("smart_dragger_selected_side", -1))
        if smart_side in (0, 1):
            # A selected Smart Dragger role owns Alt-G/Alt-R even if Blender's
            # previous virtual pin selection has not been cleared yet.
            selected_key, selected_target = "", None
        else:
            selected_key, selected_target = _pin_selected_target_data(context)
        if selected_key and selected_target is not None:
            kind, armature, pose_bone, payload = selected_target
            if kind == "YELLOW":
                if self.reset_mode == "LOCATION":
                    initial = (
                        pose_bone.get(YELLOW_PIN_INITIAL_TARGET_PROPERTY)
                        if pose_bone is not None else None
                    )
                    if initial is None or len(initial) < 3:
                        return {"CANCELLED"}
                    fixed = dict(_state.get("yellow_fixed", {}))
                    packed = fixed.get(_owner_bone_key(
                        armature, pose_bone.name
                    ))
                    if not packed:
                        return {"CANCELLED"}
                    values = list(packed)
                    values[0] = Vector(tuple(float(v) for v in initial[:3]))
                    fixed[_owner_bone_key(armature, pose_bone.name)] = tuple(
                        values
                    )
                    _state["yellow_fixed"] = fixed
                    _yellow_store_target_property(
                        armature, pose_bone.name, values[0]
                    )
                    context.view_layer.update()
                    _tag_redraw_all_view3d()
                # Onion pins have no independent rotation or scale.
                return {"FINISHED"}
            if kind == "CONTACT" and payload is not None:
                packed = payload.get(
                    SURFACE_CONTACT_INITIAL_GUIDE_MATRIX_PROPERTY
                )
                if packed is None or len(packed) < 16:
                    # Existing pre-reset pins have no recoverable creation
                    # transform. Seed once without moving them; subsequent
                    # resets remain persistent across file reloads.
                    payload[SURFACE_CONTACT_INITIAL_GUIDE_MATRIX_PROPERTY] = (
                        tuple(
                            float(value)
                            for row in payload.matrix_world
                            for value in row
                        )
                    )
                    return {"FINISHED"}
                initial = Matrix((
                    packed[0:4], packed[4:8], packed[8:12], packed[12:16]
                ))
                current_location, current_rotation, current_scale = (
                    payload.matrix_world.decompose()
                )
                initial_location, initial_rotation, initial_scale = (
                    initial.decompose()
                )
                if self.reset_mode == "LOCATION":
                    current_location = initial_location
                elif self.reset_mode == "ROTATION":
                    current_rotation = initial_rotation
                else:
                    current_scale = initial_scale
                payload.matrix_world = Matrix.LocRotScale(
                    current_location, current_rotation, current_scale
                )
                surface = bpy.data.objects.get(str(payload.get(
                    SURFACE_CONTACT_SURFACE_PROPERTY, ""
                )))
                if surface is not None:
                    _surface_contact_bind_guide_surface(
                        context, payload, surface,
                        payload.matrix_world.translation,
                    )
                context.view_layer.update()
                # Resetting a Contact handle is also a request to restore its
                # linked pink limb to that handle. The old path only moved
                # the guide, leaving the limb in its previous pose until a
                # later unrelated update (or never solving it at all).
                previous_solver_guard = bool(
                    _state.get("surface_contact_solver_syncing", False)
                )
                previous_snap_guard = bool(
                    _state.get("pin_snap_syncing", False)
                )
                _state["surface_contact_solver_syncing"] = True
                _state["pin_snap_syncing"] = True
                try:
                    _surface_contact_clear_snap_departure(payload)
                    _surface_contact_enforce_guide(
                        context,
                        payload,
                        force_contact = True,
                        allow_snap = True,
                        rotate_detached = False,
                        rotate_snap = True,
                    )
                    context.view_layer.update()
                    _surface_contact_seed_runtime_signatures(context, (payload,))
                finally:
                    _state["surface_contact_solver_syncing"] = previous_solver_guard
                    _state["pin_snap_syncing"] = previous_snap_guard
                _tag_redraw_all_view3d()
                return {"FINISHED"}

        if int(_state.get("smart_dragger_selected_side", -1)) in (0, 1):
            owner = _state.get("smart_dragger_owner")
            armature = bpy.data.objects.get(str(owner[0])) if owner else None
            pose_bone = (
                armature.pose.bones.get(str(owner[1]))
                if armature is not None and owner else None
            )
            packed = (
                pose_bone.get(SMART_DRAGGER_INITIAL_BASIS_PROPERTY)
                if pose_bone is not None else None
            )
            if packed is None or len(packed) < 16:
                return {"CANCELLED"}
            initial = Matrix((
                packed[0:4], packed[4:8], packed[8:12], packed[12:16]
            ))
            location, rotation, scale = pose_bone.matrix_basis.decompose()
            initial_location, initial_rotation, initial_scale = (
                initial.decompose()
            )
            if self.reset_mode == "LOCATION":
                location = initial_location
            elif self.reset_mode == "ROTATION":
                rotation = initial_rotation
            else:
                scale = initial_scale
            pose_bone.matrix_basis = Matrix.LocRotScale(
                location, rotation, scale
            )
            context.view_layer.update()
            _state["smart_dragger_cache"] = {}
            _tag_redraw_all_view3d()
            return {"FINISHED"}

        grouped = _selected_pose_bones_by_owner(context)
        if not grouped:
            return {"CANCELLED"}

        frame = int(context.scene.frame_current)
        attachment_states = {}
        for guide in _surface_contact_guides():
            if (
                str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
                != SURFACE_CONTACT_KIND_SIMULATED
                or not _surface_contact_guide_active_at(guide, frame)
            ):
                continue
            snap_key = _surface_contact_snap_key(guide)
            animated_detached = _surface_contact_animated_detached_state(
                guide,
                frame,
            )
            runtime_detached = bool(
                snap_key in _state.setdefault("pin_snap_detached", set())
                or guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)
            )
            attachment_states[guide.name] = bool(
                animated_detached is False
                or (
                    animated_detached is None
                    and not runtime_detached
                    and _pin_contact_is_attached(context, guide)
                )
            )

        previous_solver_guard = bool(
            _state.get("surface_contact_solver_syncing", False)
        )
        previous_snap_guard = bool(_state.get("pin_snap_syncing", False))
        _state["surface_contact_solver_syncing"] = True
        _state["pin_snap_syncing"] = True
        try:
            selected_by_armature = {}
            for armature, pose_bones in grouped.items():
                selected_by_armature[armature.name] = {
                    pose_bone.name for pose_bone in pose_bones
                }
                for pose_bone in pose_bones:
                    if self.reset_mode == "LOCATION":
                        pose_bone.location = (0.0, 0.0, 0.0)
                    elif self.reset_mode == "SCALE":
                        pose_bone.scale = (1.0, 1.0, 1.0)
                    elif pose_bone.rotation_mode == "QUATERNION":
                        pose_bone.rotation_quaternion = (1.0, 0.0, 0.0, 0.0)
                    elif pose_bone.rotation_mode == "AXIS_ANGLE":
                        pose_bone.rotation_axis_angle = (0.0, 0.0, 1.0, 0.0)
                    else:
                        pose_bone.rotation_euler = (0.0, 0.0, 0.0)
            context.view_layer.update()

            affected = []
            for guide in _surface_contact_guides():
                if (
                    str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
                    != SURFACE_CONTACT_KIND_SIMULATED
                    or not _surface_contact_guide_active_at(guide, frame)
                ):
                    continue
                selected_names = selected_by_armature.get(
                    str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
                )
                armature = bpy.data.objects.get(str(guide.get(
                    SURFACE_CONTACT_ARMATURE_PROPERTY,
                    "",
                )))
                if not selected_names or not (
                    _surface_contact_related_bone_names(guide) & selected_names
                    or _surface_contact_selected_bones_drive_guide(
                        armature,
                        guide,
                        selected_names,
                    )
                ):
                    continue
                affected.append(guide)
                snap_key = _surface_contact_snap_key(guide)
                _state.setdefault(
                    "pin_snap_parent_transform_guides", set()
                ).discard(guide.name)
                _state.setdefault(
                    "pin_snap_parent_attachment_states", {}
                ).pop(guide.name, None)
                if attachment_states.get(guide.name, False):
                    _surface_contact_set_snap_detached(guide, False)
                    _state.setdefault("pin_snap_latches", set()).add(snap_key)
                else:
                    _surface_contact_set_snap_detached(guide, True)
                    _state.setdefault("pin_snap_latches", set()).discard(
                        snap_key
                    )
                _surface_contact_enforce_guide(
                    context,
                    guide,
                    # A clear changes pose channels, not Contact mode. Keep
                    # the attachment state captured before the clear: an
                    # ancestor reset must move an attached pink limb back to
                    # its fixed pin, while a free limb must remain free.
                    force_contact = attachment_states.get(guide.name, False),
                    allow_snap = False,
                    rotate_detached = False,
                    collision_only = not attachment_states.get(
                        guide.name,
                        False,
                    ),
                    rotate_snap = False,
                )
            context.view_layer.update()
            if affected:
                _surface_contact_seed_runtime_signatures(context, affected)
                for guide in affected:
                    _surface_contact_store_valid_pose(guide)
                    _surface_contact_store_owner_pose_base(guide)
                    _surface_contact_capture_live_pose(guide)
                _surface_contact_store_persistent_pose_snapshots(affected)
                _tag_redraw_all_view3d()
            return {"FINISHED"}
        finally:
            _state["surface_contact_solver_syncing"] = previous_solver_guard
            _state["pin_snap_syncing"] = previous_snap_guard
