"""Contact guide surface binding and stable normal persistence."""

from ..core.runtime import *  # noqa: F403


def _surface_contact_set_guide_surface_point(
    context,
    guide,
    point,
    normal,
    update_view_layer=True,
    preserve_orientation=False,
):
    surface = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_SURFACE_PROPERTY, ""))
    )
    if surface is None:
        return False
    point = Vector(point)
    normal = _surface_contact_align_surface_normal(guide, normal)

    if preserve_orientation:
        world_matrix = guide.matrix_world.copy()
        world_matrix.translation = point
    else:
        world_matrix = _surface_contact_plane_matrix(
            point,
            normal,
            guide.matrix_world,
        )
    guide.matrix_world = world_matrix
    local_point = surface.matrix_world.inverted_safe() @ point
    local_normal = surface.matrix_world.to_3x3().transposed() @ normal
    if local_normal.length_squared > 1.0e-12:
        local_normal.normalize()
    guide[SURFACE_CONTACT_POINT_PROPERTY] = tuple(local_point)
    guide[SURFACE_CONTACT_NORMAL_PROPERTY] = tuple(local_normal)

    follow_object = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_FOLLOW_OBJECT_PROPERTY, ""))
    )
    follow_bone = str(guide.get(SURFACE_CONTACT_FOLLOW_BONE_PROPERTY, ""))
    if follow_object is not None:
        depsgraph = context.evaluated_depsgraph_get()
        evaluated_follow = follow_object.evaluated_get(depsgraph)
        follow_world = evaluated_follow.matrix_world.copy()
        if follow_bone and getattr(evaluated_follow, "pose", None):
            evaluated_bone = evaluated_follow.pose.bones.get(follow_bone)
            if evaluated_bone is not None:
                follow_world = follow_world @ evaluated_bone.matrix
        local_matrix = follow_world.inverted_safe() @ world_matrix
        guide[SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY] = tuple(
            float(value)
            for row in local_matrix
            for value in row
        )
    if update_view_layer:
        context.view_layer.update()
    return True


def _surface_contact_bind_guide_surface(context, guide, surface, world_point):
    """Rebind a Contact guide while preserving its current world transform."""
    if guide is None or surface is None:
        return False
    if surface in _surface_contact_linked_collision_objects(context, guide):
        return False
    try:
        depsgraph = context.evaluated_depsgraph_get()
        previous_surface_name = str(
            guide.get(SURFACE_CONTACT_SURFACE_PROPERTY, "")
        )
        follow_object, follow_bone = _surface_contact_surface_binding(
            surface,
            Vector(world_point),
            depsgraph,
        )
        world_matrix = guide.matrix_world.copy()
        guide[SURFACE_CONTACT_SURFACE_PROPERTY] = surface.name
        if previous_surface_name != surface.name:
            closest = _surface_contact_closest_point(
                surface,
                Vector(world_point),
                depsgraph,
                max(
                    1.0,
                    (Vector(world_point) - world_matrix.translation).length * 4.0,
                ),
            )
            if closest is not None:
                local_normal = (
                    surface.matrix_world.to_3x3().transposed() @ closest[1]
                )
                if local_normal.length_squared > 1.0e-12:
                    local_normal.normalize()
                    guide[SURFACE_CONTACT_NORMAL_PROPERTY] = tuple(local_normal)
            elif SURFACE_CONTACT_NORMAL_PROPERTY in guide:
                del guide[SURFACE_CONTACT_NORMAL_PROPERTY]
        guide[SURFACE_CONTACT_LABEL_PROPERTY] = (
            _surface_contact_surface_display_label(
                surface,
                Vector(world_point),
                depsgraph,
            )
        )
        if not _surface_contact_parent_guide(
            guide,
            follow_object or surface,
            follow_bone,
            world_matrix,
        ):
            return False
        context.view_layer.update()
        return True
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return False
