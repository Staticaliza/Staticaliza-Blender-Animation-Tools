"""Multi-selection actions for Surface Contact pins."""

from ..core.runtime import *  # noqa: F403


def _surface_contact_pivot_selected(context, operator = None):
    guides = _surface_contact_selected_guides(
        context,
        active_only = True,
    )
    if not guides:
        return {"CANCELLED"}
    selection = _pin_selection_runtime_snapshot()
    changed = False
    try:
        for guide in guides:
            _surface_contact_clear_snap_departure(guide)
            changed = _surface_contact_enforce_guide(
                context,
                guide,
                force_contact = True,
                insert_keys = True,
                allow_snap = True,
            ) or changed
            _surface_contact_store_valid_pose(guide)
            _surface_contact_store_owner_pose_base(guide)
        context.view_layer.update()
        _surface_contact_seed_runtime_signatures(context, guides)
        _yellow_refresh_runtime(context)
        _tag_redraw_all_view3d()
    finally:
        _pin_selection_runtime_restore(context, selection)
    if operator is not None and changed:
        operator.report(
            {"INFO"},
            f"Pivoted {len(guides)} Surface Contact pin(s).",
        )
    return {"FINISHED"} if changed else {"CANCELLED"}


def _surface_contact_inverse_pivot_active(
    context,
    operator = None,
    initial_state_json = "",
):
    """Move only the active pink dragger onto its linked contact point."""
    target_data = _pin_virtual_selected_target_data(context)
    if target_data is None or target_data[0] != "CONTACT":
        guide = _surface_contact_selected_guide(
            context,
            active_only = True,
        )
        if guide is None:
            try:
                active_target = str(
                    json.loads(initial_state_json).get("active_target", "")
                )
            except (TypeError, ValueError):
                active_target = ""
            kind, separator, guide_name = active_target.partition("\n")
            guide = (
                bpy.data.objects.get(guide_name)
                if separator and kind == "CONTACT"
                else None
            )
        if guide is not None:
            armature, pose_bone = _surface_contact_pose_bone(guide)
            target_data = (
                ("CONTACT", armature, pose_bone, guide)
                if armature is not None and pose_bone is not None
                else None
            )
    if target_data is None or target_data[0] != "CONTACT":
        if operator is not None:
            operator.report(
                {"WARNING"},
                "Select a bone with Surface Contact or its dragger.",
            )
        return {"CANCELLED"}
    _kind, _armature, pose_bone, guide = target_data
    anchor = _surface_contact_anchor_world(context, guide)
    if anchor is None:
        if operator is not None:
            operator.report({"WARNING"}, "The connected point is unavailable.")
        return {"CANCELLED"}
    normal = _surface_contact_reference_normal(guide)

    selection = _pin_selection_runtime_snapshot()
    original_basis = pose_bone.matrix_basis.copy()
    previous_guard = bool(_state.get("surface_contact_reconciling", False))
    _state["surface_contact_reconciling"] = True
    try:
        moved = _surface_contact_set_guide_surface_point(
            context,
            guide,
            anchor,
            normal,
            preserve_orientation = True,
        )
        if not moved:
            # Released/legacy contacts may no longer have a live surface
            # object. Inverse is still a target-only placement operation.
            world_matrix = guide.matrix_world.copy()
            world_matrix.translation = anchor
            guide.matrix_world = world_matrix
            context.view_layer.update()
        _surface_contact_clear_snap_departure(guide)
        _surface_contact_commit_target_key(context, guide, detached = False)
        pose_bone.matrix_basis = original_basis
        context.view_layer.update()
        _surface_contact_seed_runtime_signatures(context, (guide,))
    finally:
        _state["surface_contact_reconciling"] = previous_guard
        _pin_selection_runtime_restore(context, selection)
    if operator is not None:
        operator.report({"INFO"}, "Moved the active Surface Contact pin.")
    return {"FINISHED"}


def _surface_contact_clear_selected(context, operator = None):
    guides = _surface_contact_selected_guides(
        context,
        active_only = True,
    )
    if not guides:
        return {"CANCELLED"}
    selection = _pin_selection_runtime_snapshot()
    removed_keys = {
        _surface_contact_snap_key(guide)
        for guide in guides
    }
    bone_names = tuple(
        str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, "endpoint"))
        for guide in guides
    )
    for guide in guides:
        _surface_contact_remove_guide(
            context,
            guide,
            preserve_frame = int(context.scene.frame_current),
        )
    remaining = set(selection["selected"]) - removed_keys
    if remaining:
        active = selection["active"]
        if active not in remaining:
            active = next(iter(sorted(remaining)))
        _pin_selection_runtime_restore(
            context,
            {"active": active, "selected": remaining},
        )
    else:
        _pin_deselect_target(push_history = False)
    _yellow_refresh_runtime(context)
    _tag_redraw_all_view3d()
    if operator is not None:
        label = (
            bone_names[0]
            if len(bone_names) == 1
            else f"{len(bone_names)} selected pins"
        )
        operator.report(
            {"INFO"},
            f"Cleared Surface Contact for {label}.",
        )
    return {"FINISHED"}
