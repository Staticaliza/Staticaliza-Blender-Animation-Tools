"""Surface-contact snapping, projection, and target movement."""

from ..core.runtime import *  # noqa: F403

def _pin_points_within_snap_radius(
    context,
    target,
    current,
    pixel_radius = PIN_SNAP_PIXEL_RADIUS,
):
    # Spatial separation avoids camera-dependent end-on proximity and
    # changes the result whenever the camera zoom or angle changes.
    radius_scale = max(1.0, float(pixel_radius)) / PIN_SNAP_PIXEL_RADIUS
    world_radius = PIN_SNAP_WORLD_RADIUS * radius_scale
    return (Vector(target) - Vector(current)).length <= world_radius

def _surface_contact_snap_key(guide):
    armature = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
    )
    return f"CONTACT:{_armature_session_uid(armature)}:{getattr(guide, 'name', '')}"


def _surface_contact_new_snap_allowed(context, guide):
    """Allow entry only during a direct manual pink-bone transform."""
    if (
        context is None
        or getattr(context, "mode", "") != "POSE"
        or _state.get("pin_target_dragging", False)
        or _pin_selected_target_key()
    ):
        return False
    transform_active = bool(
        _state.get("pin_snap_transform_active", False)
        or _state.get("pin_keyboard_transform_active", False)
    )
    if not transform_active:
        try:
            transform_active = bool(_pin_active_transform_operator(context))
        except (
            AttributeError,
            ReferenceError,
            RuntimeError,
            TypeError,
            ValueError,
        ):
            transform_active = False
    if not transform_active:
        return False
    armature = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
    )
    if armature is None:
        return False
    selected_names = {
        pose_bone.name
        for pose_bone in _selected_pose_bones_by_owner(context).get(
            armature,
            (),
        )
    }
    return bool(
        selected_names
        and _surface_contact_direct_bone_names(guide) & selected_names
    )

def _surface_contact_set_snap_detached(guide, detached):
    key = _surface_contact_snap_key(guide)
    detached_keys = _state.setdefault("pin_snap_detached", set())
    if detached:
        detached_keys.add(key)
        _state.setdefault("pin_snap_pressure_active", set()).discard(key)
        # Attached and detached are mutually exclusive semantic states. A
        # stale latch bypasses the detached/new-snap gate and can make the
        # next unrelated or ancestor update force Contact back on.
        _state.setdefault("pin_snap_latches", set()).discard(key)
        _state.setdefault("pin_snap_transform_engaged", set()).discard(key)
        _state.setdefault("pin_snap_engage_translate_origins", {}).pop(
            key, None
        )
        _state.setdefault("pin_snap_engage_anchor_origins", {}).pop(
            key, None
        )
        _state.setdefault("pin_snap_swept_hits", set()).discard(key)
        try:
            if not bool(guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)):
                guide[SURFACE_CONTACT_DETACHED_PROPERTY] = True
        except (ReferenceError, RuntimeError, TypeError):
            pass
    else:
        detached_keys.discard(key)
        try:
            if _surface_contact_detached_fcurves(guide):
                guide[SURFACE_CONTACT_DETACHED_PROPERTY] = 0.0
            elif SURFACE_CONTACT_DETACHED_PROPERTY in guide:
                del guide[SURFACE_CONTACT_DETACHED_PROPERTY]
        except (KeyError, ReferenceError, RuntimeError, TypeError):
            pass

def _surface_contact_restore_snap_detached(
    context,
    infer_missing = True,
    reset_runtime = True,
):
    """Restore the saved/runtime detach latch before contact enforcement."""
    detached_keys = _state.setdefault("pin_snap_detached", set())
    if reset_runtime:
        detached_keys.clear()
    scene = getattr(context, "scene", None) if context is not None else None
    if scene is None:
        return False

    active_guides = set(_surface_contact_active_snap_guides(scene))
    changed = False
    for guide in _surface_contact_guides():
        if not _surface_contact_snap_capable(guide):
            continue
        if bool(guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)):
            detached_keys.add(_surface_contact_snap_key(guide))
            continue
        if not infer_missing or guide not in active_guides:
            continue

        target, _normal, anchor = _surface_contact_world_point_normal(
            context,
            guide,
        )
        if target is None or anchor is None:
            continue
        tolerance = _surface_contact_settle_tolerance(guide)
        if (
            (Vector(target) - Vector(anchor)).length > tolerance
            and not _pin_points_within_snap_radius(
                context,
                target,
                anchor,
            )
        ):
            # Older files have no persistent latch. Their keyed guide and
            # endpoint poses still distinguish an engaged contact from a
            # deliberately moved endpoint, so migrate that state on load.
            _surface_contact_set_snap_detached(guide, True)
            changed = True
    return changed

def _surface_contact_clear_snap_departure(guide, preserve_latch=False):
    key = _surface_contact_snap_key(guide)
    if (
        guide.name
        in _state.get("pin_snap_parent_transform_guides", set())
        and not _state.get("pin_snap_parent_attachment_states", {}).get(
            guide.name,
            False,
        )
    ):
        # Magnetic aim may put detached dots close together during an
        # ancestor transform, but only a direct pink-bone edit may create a
        # new snap. Do not let a later depsgraph callback turn that preview
        # alignment into a latch.
        _surface_contact_set_snap_detached(guide, True)
        _state.setdefault("pin_snap_latches", set()).discard(key)
        return
    _state.setdefault("pin_snap_departing", set()).discard(key)
    _surface_contact_set_snap_detached(guide, False)
    if not _state.get("pin_snap_transform_active", False):
        _state.setdefault("pin_snap_transform_seen", set()).discard(key)
    if not preserve_latch:
        # Clearing the free/departing state is an affirmative attachment
        # transition. Publish that semantic latch immediately; otherwise an
        # evaluated anchor gap before the next modal sample makes the contact
        # indistinguishable from a genuinely hovering limb.
        _state.setdefault("pin_snap_latches", set()).add(key)

def _surface_contact_snap_departure_active(
    context,
    guide,
    start_if_close = False,
):
    key = _surface_contact_snap_key(guide)
    departing = _state.setdefault("pin_snap_departing", set())
    detached = _state.setdefault("pin_snap_detached", set())
    seen = _state.setdefault("pin_snap_transform_seen", set())
    if _pin_yellow_snap_active_for_contact(context, guide):
        detached.add(key)
        return True
    if key in _state.setdefault("pin_snap_transform_releasing", set()):
        return True
    animated_detached = _surface_contact_animated_detached_state(
        guide,
        int(context.scene.frame_current),
    )
    transform_departure_active = bool(
        key in departing
        or key in seen
        or _state.get("pin_snap_transform_active", False)
    )
    if (
        (
            key in detached
            or bool(guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False))
        )
        and not _surface_contact_new_snap_allowed(context, guide)
    ):
        # Runtime/manual detach owns the current frame until the pink bone is
        # directly edited again. An older attached F-curve must not clear this
        # latch during a torso or unrelated-bone update.
        detached.add(key)
        _state.setdefault("pin_snap_latches", set()).discard(key)
        return True
    if (
        animated_detached is not None
        and not start_if_close
        and not transform_departure_active
    ):
        if animated_detached:
            detached.add(key)
        else:
            detached.discard(key)
        return animated_detached
    target, _normal, anchor = _surface_contact_world_point_normal(
        context,
        guide,
    )
    if target is None or anchor is None:
        return key in departing or key in detached

    if key in _state.setdefault("pin_snap_latches", set()):
        # The enforcement pass below owns hysteresis/release debounce. Do not
        # pre-detach the contact before it can confirm a deliberate pull-away.
        return False

    distance = (Vector(target) - Vector(anchor)).length
    swept_close = _pin_snap_sample_with_sweep(
        target,
        anchor,
        key,
    )
    if key in detached:
        if not _surface_contact_new_snap_allowed(context, guide):
            # Only a direct edit of this pink bone may enter Contact. Ancestor,
            # sibling, history, and idle dependency updates must preserve the
            # free pose even if evaluation temporarily places both dots inside
            # the magnetic radius.
            _state.setdefault("pin_snap_latches", set()).discard(key)
            return True
        tolerance = _surface_contact_settle_tolerance(guide)
        if (
            distance <= tolerance
            or swept_close
            or _pin_points_within_snap_radius(context, target, anchor)
        ):
            # A direct pink-bone edit may intentionally re-enter Contact.
            _surface_contact_clear_snap_departure(guide)
            return False
        return True
    if start_if_close and key not in seen:
        _state.setdefault("pin_snap_initial_detached", {})[key] = bool(
            animated_detached
            if animated_detached is not None
            else guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)
        )
        seen.add(key)
        if (
            distance <= 1.0e-7
            or swept_close
            or _pin_points_within_snap_radius(
                context,
                target,
                anchor,
                pixel_radius = PIN_SNAP_RELEASE_PIXEL_RADIUS,
            )
        ):
            departing.add(key)
        else:
            # A depsgraph callback may first observe a fast transform only
            # after the endpoint has already crossed the release ring. Treat
            # that first far sample as the same deliberate detach instead of
            # leaving a selection-change window that can force it back.
            _surface_contact_set_snap_detached(guide, True)

    if key in detached:
        return True

    if key not in departing:
        return False
    if distance <= 1.0e-7:
        return False
    if _pin_points_within_snap_radius(
        context,
        target,
        anchor,
        pixel_radius = PIN_SNAP_RELEASE_PIXEL_RADIUS,
    ):
        # Resolve magnetism live; native G/R/S can still pull beyond the ring.
        # Finalization then records the exact pose already shown to the user.
        return False

    # Leaving the wider release ring completes a deliberate detach. A later
    # direct sample inside the smaller entry ring can still reattach during
    # this transform; until then, keep the detached state across selection
    # changes so reconciliation cannot force the cached pose back.
    departing.discard(key)
    _surface_contact_set_snap_detached(guide, True)
    _state.setdefault("pin_snap_latches", set()).discard(key)
    return True

def _surface_contact_enforce_guide(
    context,
    guide,
    force_contact = False,
    insert_keys = False,
    use_snap_hysteresis = False,
    allow_snap = True,
    rotate_detached = False,
    collision_only = False,
    rotate_snap = True,
    allow_collision_roll = True,
):
    changed = _surface_contact_migrate_legacy_ik_guide(context, guide)
    target, normal, anchor = _surface_contact_world_point_normal(context, guide)
    if target is None or anchor is None or normal is None:
        return changed

    if (
        _surface_contact_snap_capable(guide)
        and not force_contact
        and not _surface_contact_new_snap_allowed(context, guide)
    ):
        allow_snap = False

    snap_close = False
    if not force_contact:
        snap_close = bool(
            allow_snap
            and _pin_snap_should_engage(
                context,
                _surface_contact_snap_key(guide),
                target,
                anchor,
                use_hysteresis = use_snap_hysteresis,
            )
        )
    contact_kind = str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
    detached_contact = bool(
        _surface_contact_snap_capable(guide)
        and not force_contact
        and not snap_close
    )
    changed = (
        _surface_contact_set_constraint_attachment(
            guide,
            bool(force_contact or snap_close),
        )
        or changed
    )
    pose_invalid = False
    if detached_contact:
        pose_invalid = _surface_contact_pose_is_invalid(
            context,
            guide,
            target,
            normal,
            anchor,
        )
        armature = bpy.data.objects.get(
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
        )
        pose_bone = (
            armature.pose.bones.get(
                str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
            )
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        start_world_rotation = (
            (armature.matrix_world @ pose_bone.matrix).to_quaternion()
            if armature is not None and pose_bone is not None
            else None
        )
        if (
            contact_kind == SURFACE_CONTACT_KIND_SIMULATED
            and rotate_detached
            and pose_bone is not None
            and _surface_contact_rotate_simulated_pose_toward(
                context,
                guide,
                armature,
                pose_bone,
                anchor,
                target,
            )
        ):
            changed = True
            target, normal, anchor = _surface_contact_world_point_normal(
                context,
                guide,
            )
            if target is None or anchor is None or normal is None:
                return changed

    if collision_only and not pose_invalid:
        # Collision-only is a guard, not a projection/magnet operation.  A
        # detached endpoint that is touching or still outside the surface is
        # already valid and must retain its inherited parent-transform pose.
        # Solving `desired` here translated it despite no penetration, which
        # looked exactly like an indirect snap.
        if contact_kind == SURFACE_CONTACT_KIND_SIMULATED:
            _surface_contact_store_valid_pose(guide)
        return changed

    collision_target = target
    collision_normal = normal
    if not force_contact and not snap_close:
        endpoint_surface = _surface_contact_bound_surface_point(
            context,
            guide,
            anchor,
        )
        if endpoint_surface is not None:
            collision_target, collision_normal = endpoint_surface

    desired = _surface_contact_endpoint_desired_point(
        guide,
        collision_target,
        collision_normal,
        anchor,
        force_contact = force_contact,
        snap_close = snap_close,
        opposite = _surface_contact_opposite_anchor_world(context, guide),
    )
    if detached_contact and pose_invalid and not collision_only:
        desired = _surface_contact_magnetic_collision_point(
            guide, target, normal,
            desired if desired is not None else anchor,
        )
    if (
        collision_only
        and desired is None
        and pose_invalid
        and contact_kind == SURFACE_CONTACT_KIND_SIMULATED
    ):
        return _surface_contact_resolve_pose_collision(
            context,
            guide,
            target,
            normal,
            anchor,
            allow_planted_roll=allow_collision_roll,
        ) or changed
    if desired is None:
        if (
            detached_contact
            and contact_kind == SURFACE_CONTACT_KIND_SIMULATED
        ):
            _surface_contact_store_valid_pose(guide)
        return changed

    if contact_kind == SURFACE_CONTACT_KIND_SIMULATED:
        solved = _surface_contact_update_simulated_solver(
            context,
            guide,
            desired_point = desired,
            insert_keys = insert_keys,
            rotate_pose = bool(
                rotate_snap
                and (
                    force_contact
                    or snap_close
                    or (
                        pose_invalid
                        and not rotate_detached
                        and not collision_only
                    )
                )
            ),
            exact_target = bool(force_contact or snap_close),
        )
        target, normal, anchor = _surface_contact_world_point_normal(
            context,
            guide,
        )
        collision_rollback = bool(
            target is not None
            and normal is not None
            and anchor is not None
            and _surface_contact_resolve_pose_collision(
                context,
                guide,
                target,
                normal,
                anchor,
                allow_planted_roll=allow_collision_roll,
            )
        )
        parallel_settle = bool(
            detached_contact
            and rotate_detached
            and not collision_only
            and start_world_rotation is not None
            and _surface_contact_settle_parallel_collision(
                context,
                guide,
                armature,
                pose_bone,
                start_world_rotation,
            )
        )
        return solved or collision_rollback or parallel_settle or changed
    if contact_kind == SURFACE_CONTACT_KIND_CONTROL:
        return _surface_contact_refine_control_solver(
            context,
            guide,
            desired_point = desired,
        ) or changed
    return _surface_contact_update_fallback_solver(context, guide) or changed


def _surface_contact_bound_surface_point(context, guide, candidate):
    """Project every non-ray target transform onto its bound mesh surface."""
    surface = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_SURFACE_PROPERTY, ""))
    )
    if (
        surface is None
        or surface in _surface_contact_linked_collision_objects(
            context,
            guide,
        )
    ):
        return None
    candidate = Vector(candidate)
    current = guide.matrix_world.translation.copy()
    reference_normal = _surface_contact_reference_normal(guide)
    depsgraph = context.evaluated_depsgraph_get()

    # Cast from the established outside toward the candidate. This selects
    # the contacted sheet first even if the mouse/transform candidate is deep
    # inside a thick mesh or already beyond its opposite face.
    try:
        evaluated_surface = surface.evaluated_get(depsgraph)
        projected_extent = max(
            abs(
                (
                    (evaluated_surface.matrix_world @ Vector(corner))
                    - candidate
                ).dot(reference_normal)
            )
            for corner in evaluated_surface.bound_box
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        projected_extent = (candidate - current).length
    cast_span = max(
        1.0,
        projected_extent + (candidate - current).length + 1.0,
    )
    hit = _surface_contact_object_ray_cast(
        surface,
        candidate + (reference_normal * cast_span),
        -reference_normal,
        cast_span * 2.0,
        depsgraph,
    )
    if hit is not None and Vector(hit[1]).dot(reference_normal) >= -1.0e-6:
        return hit[0], _surface_contact_align_surface_normal(
            guide,
            hit[1],
            reference_normal,
        )

    # Open/concave meshes may not intersect that ray. Clamp an inward request
    # to the previous tangent sheet before the closest-point fallback, and
    # reject any opposite-facing result rather than jumping to the underside.
    safe_candidate = candidate.copy()
    inward_distance = (safe_candidate - current).dot(reference_normal)
    if inward_distance < 0.0:
        safe_candidate -= reference_normal * inward_distance
    closest = _surface_contact_closest_point(
        surface,
        safe_candidate,
        depsgraph,
        max(1.0, (safe_candidate - current).length * 4.0),
    )
    if closest is None:
        return None
    if Vector(closest[1]).dot(reference_normal) < -1.0e-6:
        return current, reference_normal
    return closest[0], _surface_contact_align_surface_normal(
        guide,
        closest[1],
        reference_normal,
    )


def _surface_contact_solve_target(
    context,
    guide,
    solver_matrix = None,
    max_iterations = SURFACE_CONTACT_FINAL_SOLVER_ITERATIONS, rotate_pose = True,
):
    """Settle the driven endpoint to the guide's authoritative target."""
    previous_guard = bool(_state.get("surface_contact_solver_syncing", False))
    _state["surface_contact_solver_syncing"] = True
    try:
        return _surface_contact_solve_target_guarded(
            context,
            guide,
            solver_matrix = solver_matrix,
            max_iterations = max_iterations,
            rotate_pose = rotate_pose,
        )
    finally:
        _state["surface_contact_solver_syncing"] = previous_guard


def _surface_contact_solve_target_guarded(
    context,
    guide,
    solver_matrix = None,
    max_iterations = SURFACE_CONTACT_FINAL_SOLVER_ITERATIONS, rotate_pose = True,
):
    solver = _surface_contact_solver_from_guide(guide)
    contact_kind = str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
    target = guide.matrix_world.translation.copy()
    if contact_kind == SURFACE_CONTACT_KIND_SIMULATED:
        changed = _surface_contact_update_simulated_solver(
            context,
            guide,
            desired_point = target,
            max_iterations = max_iterations,
            rotate_pose = rotate_pose,
            exact_target = True,
        )
    elif contact_kind == SURFACE_CONTACT_KIND_IK:
        changed = _surface_contact_update_fallback_solver(context, guide)
    else:
        changed = False
        if solver is not None and solver_matrix is not None:
            if any(
                abs(
                    float(solver.matrix_world[row][column])
                    - float(solver_matrix[row][column])
                ) > 1.0e-7
                for row in range(4)
                for column in range(4)
            ):
                solver.matrix_world = solver_matrix.copy()
                context.view_layer.update()
                changed = True
        elif solver is not None:
            changed = _surface_contact_update_control_solver(guide) or changed
            if changed:
                context.view_layer.update()
        changed = _surface_contact_refine_control_solver(
            context,
            guide,
            desired_point = target,
            max_iterations = max_iterations,
        ) or changed
    context.view_layer.update()
    return changed


def _surface_contact_move_guide_to_surface(
    context,
    guide,
    point,
    normal,
    keep_attached = None,
    max_iterations = SURFACE_CONTACT_FINAL_SOLVER_ITERATIONS,
    sweep_collision = True,
):
    previous_guard = bool(_state.get("surface_contact_solver_syncing", False))
    _state["surface_contact_solver_syncing"] = True
    try:
        return _surface_contact_move_guide_to_surface_guarded(
            context,
            guide,
            point,
            normal,
            keep_attached = keep_attached,
            max_iterations = max_iterations,
            sweep_collision = sweep_collision,
        )
    finally:
        _state["surface_contact_solver_syncing"] = previous_guard


def _surface_contact_move_guide_to_surface_guarded(
    context,
    guide,
    point,
    normal,
    keep_attached = None,
    max_iterations = SURFACE_CONTACT_FINAL_SOLVER_ITERATIONS,
    sweep_collision = True,
):
    rotate_pose = not _surface_contact_preserves_rigid_orientation(guide)
    reachable_target = _surface_contact_project_reachable_target(
        context,
        guide,
        point,
        normal,
    )
    if reachable_target is None:
        return False
    previous_guide_world = guide.matrix_world.copy()
    simulated = (
        str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
        == SURFACE_CONTACT_KIND_SIMULATED
    )
    if simulated:
        reachable_target = (
            _surface_contact_clamp_drag_target(
                context,
                guide,
                previous_guide_world.translation,
                reachable_target[0],
                sweep_collision = sweep_collision,
            ),
            reachable_target[1],
        )
    if keep_attached is None and _state.get("pin_target_dragging", False):
        # A target-only drag authors the target, not the linked pose. Even
        # when the drag starts snapped, keep the limb pivot fixed and let the
        # detached Smart solver aim toward the moving target.
        keep_attached = False
    if keep_attached is None:
        target, _target_normal, anchor = _surface_contact_world_point_normal(
            context,
            guide,
        )
        keep_attached = bool(
            target is not None
            and anchor is not None
            and _pin_points_within_snap_radius(
                context,
                target,
                anchor,
            )
        )
    if (
        str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
        == SURFACE_CONTACT_KIND_CONTROL
        and SURFACE_CONTACT_SOLVER_LOCAL_MATRIX_PROPERTY not in guide
    ):
        _surface_contact_store_solver_local_matrix(guide)
    previous_normal = previous_guide_world.to_3x3().col[2]
    next_normal = Vector(reachable_target[1])
    if previous_normal.length_squared > 1.0e-12:
        previous_normal.normalize()
    if next_normal.length_squared > 1.0e-12:
        next_normal.normalize()
    point_changed = (
        Vector(reachable_target[0]) - previous_guide_world.translation
    ).length > 1.0e-5
    normal_changed = (
        previous_normal.length_squared > 1.0e-12
        and next_normal.length_squared > 1.0e-12
        and previous_normal.dot(next_normal) < (1.0 - 1.0e-6)
    )
    if not point_changed and not normal_changed:
        if keep_attached:
            return _surface_contact_solve_target(
                context,
                guide,
                max_iterations = max_iterations,
                rotate_pose = rotate_pose,
            )
        smart_changed = _surface_contact_settle_detached_smart(context, guide)
        if smart_changed is not None:
            return smart_changed
        return _surface_contact_enforce_guide(
            context,
            guide,
            force_contact = False,
            allow_snap = False,
            rotate_detached = rotate_pose,
            rotate_snap = rotate_pose,
        )
    if not _surface_contact_set_guide_surface_point(
        context,
        guide,
        reachable_target[0],
        reachable_target[1],
    ):
        return False

    if keep_attached:
        _surface_contact_clear_snap_departure(guide)
        _surface_contact_solve_target(
            context,
            guide,
            max_iterations = max_iterations,
            rotate_pose = rotate_pose,
        )
    else:
        _surface_contact_set_snap_detached(guide, True)
        if _surface_contact_settle_detached_smart(context, guide) is None:
            _surface_contact_enforce_guide(
                context,
                guide,
                force_contact = False,
                allow_snap = False,
                rotate_detached = rotate_pose,
                rotate_snap = rotate_pose,
            )
    _tag_redraw_all_view3d()
    return True


def _surface_contact_move_guide_world(
    context,
    guide,
    point,
    keep_attached = None,
    max_iterations = SURFACE_CONTACT_FINAL_SOLVER_ITERATIONS,
):
    """Move a Contact target while remaining exactly on its bound surface."""
    projected = _surface_contact_bound_surface_point(context, guide, point)
    if projected is None:
        return False
    return _surface_contact_move_guide_to_surface(
        context,
        guide,
        projected[0],
        projected[1],
        keep_attached = keep_attached,
        max_iterations = max_iterations,
    )


def _surface_contact_mouse_surface_point(context, guide, mouse_position):
    region = getattr(context, "region", None)
    region_data = getattr(context, "region_data", None)
    if region is None or region_data is None or guide is None:
        return None

    from bpy_extras import view3d_utils

    mouse = Vector(mouse_position)
    origin = view3d_utils.region_2d_to_origin_3d(region, region_data, mouse)
    direction = view3d_utils.region_2d_to_vector_3d(region, region_data, mouse)
    hit = _surface_contact_ray_cast(
        context,
        origin,
        direction,
        1000000.0,
        _surface_contact_linked_collision_objects(context, guide),
    )
    if hit is None:
        return None
    surface, world_point, world_normal, _distance = hit
    return surface, world_point, world_normal
