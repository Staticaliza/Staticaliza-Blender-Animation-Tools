"""Collision rules between a fixed Contact pin and its linked limb mesh."""

from ..core.runtime import *  # noqa: F403


def _surface_contact_rod_plane_state(
    target,
    normal,
    anchor,
    opposite=None,
    *,
    previous_min=None,
    tolerance=1.0e-6,
):
    """Return orientation-neutral penetration and clipped-escape state."""
    plane_normal = Vector(normal)
    if plane_normal.length_squared <= 1.0e-12:
        return None
    plane_normal.normalize()
    target = Vector(target)
    distances = [
        (Vector(anchor) - target).dot(plane_normal)
    ]
    if opposite is not None:
        distances.append(
            (Vector(opposite) - target).dot(plane_normal)
        )
    minimum = min(distances)
    escaping_preclipped = bool(
        previous_min is not None
        and float(previous_min) < -float(tolerance)
        and minimum > float(previous_min) + 1.0e-8
    )
    blocked = bool(
        minimum < -float(tolerance)
        and not escaping_preclipped
    )
    return minimum, blocked, escaping_preclipped, tuple(distances)


def _surface_contact_point_inside_object(surface, world_point, depsgraph):
    """Use ray parity so containment does not depend on mesh normal winding."""
    evaluated = surface.evaluated_get(depsgraph)
    inverse = evaluated.matrix_world.inverted_safe()
    origin = inverse @ Vector(world_point)
    direction = Vector((0.723, 0.431, 0.541)).normalized()
    remaining = max(
        ((Vector(corner) - origin).length for corner in evaluated.bound_box),
        default = 0.0,
    ) + 1.0
    epsilon = max(1.0e-6, remaining * 1.0e-7)
    hits = 0
    for _iteration in range(64):
        try:
            hit, point, _normal, _face = evaluated.ray_cast(
                origin,
                direction,
                distance = remaining,
                depsgraph = depsgraph,
            )
        except TypeError:
            hit, point, _normal, _face = evaluated.ray_cast(
                origin,
                direction,
                distance = remaining,
            )
        if not hit:
            break
        travelled = (point - origin).length
        advance = travelled + epsilon
        hits += 1
        remaining -= advance
        if remaining <= epsilon:
            break
        origin = point + (direction * epsilon)
    return bool(hits % 2)


def _surface_contact_target_inside_smart_object(context, guide, target):
    """Return whether the fixed surface point is strictly inside its limb."""
    smart_object = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_SMART_OBJECT_PROPERTY, ""))
    )
    if smart_object is None or smart_object.type != "MESH":
        return False
    depsgraph = context.evaluated_depsgraph_get()
    evaluated = smart_object.evaluated_get(depsgraph)
    target = Vector(target)
    local = evaluated.matrix_world.inverted_safe() @ target
    bounds = tuple(Vector(corner) for corner in evaluated.bound_box)
    tolerance = _surface_contact_settle_tolerance(guide)
    if any(
        local[index] < min(corner[index] for corner in bounds) - tolerance
        or local[index] > max(corner[index] for corner in bounds) + tolerance
        for index in range(3)
    ):
        return False
    extent = max((corner - local).length for corner in bounds) + tolerance
    closest = _surface_contact_closest_point(
        smart_object,
        target,
        depsgraph,
        max(1.0e-4, extent),
    )
    if closest is None or (Vector(closest[0]) - target).length <= tolerance:
        return False
    return _surface_contact_point_inside_object(
        smart_object,
        target,
        depsgraph,
    )


def _surface_contact_clamp_target_before_limb(
    context,
    guide,
    start,
    candidate,
):
    """Clamp a target drag to the linked-mesh boundary without overshoot."""
    candidate = Vector(candidate)
    start = Vector(start)
    segment = candidate - start
    distance = segment.length
    if distance <= 1.0e-12:
        return start
    direction = segment / distance
    tolerance = _surface_contact_settle_tolerance(guide)
    stop_distance = distance
    anchor = _surface_contact_anchor_world(context, guide)
    radius = max(
        tolerance,
        float(guide.get(SURFACE_CONTACT_SIZE_PROPERTY, 0.05)) * 0.25,
    )
    if anchor is not None and (start - anchor).length > radius + tolerance:
        offset = start - anchor
        projection = offset.dot(direction)
        discriminant = (
            projection * projection
            - (offset.length_squared - radius * radius)
        )
        if discriminant >= 0.0:
            entry = -projection - math.sqrt(discriminant)
            if 0.0 <= entry <= distance:
                stop_distance = min(stop_distance, entry)
    smart_object = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_SMART_OBJECT_PROPERTY, ""))
    )
    if smart_object is not None:
        start_inside = _surface_contact_target_inside_smart_object(
            context,
            guide,
            start,
        )
        candidate_inside = _surface_contact_target_inside_smart_object(
            context,
            guide,
            candidate,
        )
        if start_inside:
            return candidate if not candidate_inside else start
        probe_distance = min(distance * 0.25, tolerance * 2.0)
        cast_start = start + (direction * probe_distance)
        hit = _surface_contact_object_ray_cast(
            smart_object,
            cast_start,
            direction,
            max(0.0, distance - probe_distance),
            context.evaluated_depsgraph_get(),
        )
        if hit is not None:
            stop_distance = min(
                stop_distance,
                probe_distance + (Vector(hit[0]) - cast_start).length,
            )
        elif candidate_inside:
            stop_distance = 0.0
    if stop_distance >= distance:
        return candidate
    return start + (direction * max(0.0, stop_distance - tolerance))


def _surface_contact_clamp_drag_target(
    context,
    guide,
    start,
    candidate,
    sweep_collision = True,
):
    """Apply path collision to transforms, never to a direct surface ray."""
    candidate = Vector(candidate)
    if sweep_collision:
        return _surface_contact_clamp_target_before_limb(
            context,
            guide,
            start,
            candidate,
        )
    # Center dragging already ray-casts past every mesh driven by the linked
    # bone and its welded family. Applying the limb containment test again
    # made valid floor samples under a foot silently return the old location,
    # which felt like an invisible snap or a frozen pin.
    return candidate


def _surface_contact_pose_cache_key(guide):
    armature, _pose_bone = _surface_contact_pose_bone(guide)
    return (_armature_session_uid(armature), getattr(guide, "name", ""))


def _surface_contact_pose_bone(guide):
    if guide is None:
        return None, None
    armature_name = str(
        guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, "")
    )
    bone_name = str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
    try:
        key = (
            int(_state.get("surface_contact_guide_cache_generation", 0)),
            int(guide.as_pointer()),
            armature_name,
            bone_name,
        )
    except (ReferenceError, RuntimeError):
        key = None
    cache = _state.setdefault("surface_contact_pose_bone_cache", {})
    cached = cache.get(key) if key is not None else None
    if cached is not None:
        armature, pose_bone = cached
        try:
            if (
                armature.name == armature_name
                and pose_bone.name == bone_name
            ):
                return armature, pose_bone
        except (AttributeError, ReferenceError, RuntimeError):
            pass
    armature = bpy.data.objects.get(armature_name)
    pose_bone = (
        armature.pose.bones.get(bone_name)
        if armature is not None and getattr(armature, "pose", None)
        else None
    )
    if key is not None and armature is not None and pose_bone is not None:
        cache[key] = (armature, pose_bone)
    return armature, pose_bone


def _surface_contact_store_valid_pose(guide):
    _armature, pose_bone = _surface_contact_pose_bone(guide)
    if pose_bone is None:
        return False
    _state.setdefault("surface_contact_valid_poses", {})[
        _surface_contact_pose_cache_key(guide)
    ] = pose_bone.matrix.copy()
    return True


def _surface_contact_store_owner_pose_base(guide):
    """Remember the linked bone pose authored by the user, not an ancestor solve."""
    _armature, pose_bone = _surface_contact_pose_bone(guide)
    if pose_bone is None:
        return False
    _state.setdefault("surface_contact_owner_pose_bases", {})[
        _surface_contact_pose_cache_key(guide)
    ] = pose_bone.matrix_basis.copy()
    return True


def _surface_contact_restore_owner_pose_base(context, guide):
    """Restore the manual local pose before applying an ancestor-driven aim."""
    _armature, pose_bone = _surface_contact_pose_bone(guide)
    if pose_bone is None:
        return False
    cache = _state.setdefault("surface_contact_owner_pose_bases", {})
    key = _surface_contact_pose_cache_key(guide)
    matrix = cache.get(key)
    if matrix is None:
        cache[key] = pose_bone.matrix_basis.copy()
        return False
    differs = any(
        abs(
            float(pose_bone.matrix_basis[row][column])
            - float(matrix[row][column])
        )
        > 1.0e-7
        for row in range(4)
        for column in range(4)
    )
    if not differs:
        return False
    pose_bone.matrix_basis = matrix.copy()
    context.view_layer.update()
    return True


def _surface_contact_seed_owner_pose_bases():
    cache = _state.setdefault("surface_contact_owner_pose_bases", {})
    cache.clear()
    for guide in _surface_contact_guides():
        _surface_contact_store_owner_pose_base(guide)
    return bool(cache)


def _surface_contact_restore_valid_pose(context, guide):
    armature, pose_bone = _surface_contact_pose_bone(guide)
    matrix = _state.setdefault("surface_contact_valid_poses", {}).get(
        _surface_contact_pose_cache_key(guide)
    )
    if armature is None or pose_bone is None or matrix is None:
        return False
    return _set_pose_bone_constrained_output_matrix(
        context,
        armature,
        pose_bone,
        matrix.copy(),
    )


def _surface_contact_magnetic_collision_point(
    guide,
    target,
    normal,
    collision_point,
):
    """Pull a colliding endpoint toward its fixed dot with smooth falloff."""
    target = Vector(target)
    point = Vector(collision_point)
    normal = Vector(normal)
    if normal.length_squared <= 1.0e-12:
        return point
    normal.normalize()
    tangent = target - point
    tangent -= normal * tangent.dot(normal)
    radius = max(
        PIN_SNAP_WORLD_RADIUS * 4.0,
        float(guide.get(SURFACE_CONTACT_SIZE_PROPERTY, 0.05)) * 4.0,
    )
    distance = tangent.length
    if distance <= 1.0e-12:
        return point
    influence = max(0.0, 1.0 - (distance / radius))
    return point + (tangent * influence)


def _surface_contact_resolve_pose_collision(
    context,
    guide,
    target,
    normal,
    anchor,
    *,
    allow_planted_roll=True,
    allow_detached_roll=True,
):
    """Keep a moved limb on the allowed side without cache oscillation.

    Native Pose transforms continuously reapply their requested matrix.  A
    rollback to the previous sample therefore fights Blender's modal operator
    and visibly flickers.  Resolve the requested pose first, then retain the
    last-valid cache only as a fail-safe for concave/self-intersecting meshes.
    """
    invalid = _surface_contact_pose_is_invalid(
        context,
        guide,
        target,
        normal,
        anchor,
    )
    if not invalid:
        surface_normal = Vector(normal)
        opposite = _surface_contact_opposite_anchor_world(context, guide)
        if (
            opposite is not None
            and surface_normal.length_squared > 1.0e-12
        ):
            surface_normal.normalize()
            tangent = Vector(opposite) - Vector(target)
            tangent -= surface_normal * tangent.dot(surface_normal)
            if tangent.length_squared > 1.0e-12:
                _state.setdefault(
                    "surface_contact_collision_tangents", {}
                )[_surface_contact_pose_cache_key(guide)] = (
                    tangent.normalized()
                )
        _surface_contact_store_valid_pose(guide)
        return False
    armature, pose_bone = _surface_contact_pose_bone(guide)
    normal = Vector(normal)
    if (
        armature is None
        or pose_bone is None
        or normal.length_squared <= 1.0e-12
    ):
        return _surface_contact_restore_valid_pose(context, guide)
    normal.normalize()
    tolerance = _surface_contact_settle_tolerance(guide)
    changed = False
    # Resolve containment in a bounded number of monotonic translation
    # passes. Rotation is settled once before this function, so these passes
    # cannot alternate between competing orientations.
    for _iteration in range(3):
        target, _target_normal, anchor = _surface_contact_world_point_normal(
            context,
            guide,
        )
        if target is None or anchor is None:
            break
        opposite = _surface_contact_opposite_anchor_world(context, guide)
        anchor_vector = Vector(anchor) - Vector(target)
        signed_distance = anchor_vector.dot(normal)
        opposite_distance = None
        if opposite is not None:
            opposite_vector = Vector(opposite) - Vector(anchor)
            opposite_distance = (
                Vector(opposite) - Vector(target)
            ).dot(normal)
        anchor_planted = bool(
            (Vector(anchor) - Vector(target)).length
            <= max(PIN_SNAP_WORLD_RADIUS, tolerance * 4.0)
        )
        rod_crosses_plane = bool(
            opposite is not None
            and allow_detached_roll
            and allow_planted_roll
            and opposite_vector.length_squared > 1.0e-12
            and min(signed_distance, opposite_distance) < -tolerance
            and max(signed_distance, opposite_distance) >= -tolerance
            and not _surface_contact_target_inside_smart_object(
                context,
                guide,
                target,
            )
        )
        if rod_crosses_plane:
            # Detached rods may continue past their side even when the endpoint
            # is nowhere near the pink target. Pivot at the segment/plane
            # intersection and reflect only the penetrating portion into the
            # allowed half-space. Rod length is preserved and no latch exists.
            denominator = signed_distance - opposite_distance
            fraction = (
                signed_distance / denominator
                if abs(float(denominator)) > 1.0e-12
                else 0.5
            )
            fraction = max(0.0, min(1.0, float(fraction)))
            intersection = Vector(anchor).lerp(Vector(opposite), fraction)
            penetrating = (
                Vector(anchor)
                if signed_distance < opposite_distance
                else Vector(opposite)
            )
            source = penetrating - intersection
            reflected = source - (2.0 * normal * source.dot(normal))
            if (
                source.length_squared > 1.0e-12
                and reflected.length_squared > 1.0e-12
            ):
                rotation = source.rotation_difference(reflected)
                bone_world = armature.matrix_world @ pose_bone.matrix
                rolled_world = (
                    Matrix.Translation(intersection)
                    @ rotation.to_matrix().to_4x4()
                    @ Matrix.Translation(-intersection)
                    @ bone_world
                )
                # Detached collision may turn the rod, but it must not drag
                # the whole limb sideways along the surface. Keep only the
                # normal part of the rotation-induced origin movement; the
                # animator's native G/R/S owns both surface-tangent axes.
                rolled_delta = (
                    rolled_world.translation - bone_world.translation
                )
                rolled_world.translation = (
                    bone_world.translation
                    + normal * rolled_delta.dot(normal)
                )
                _set_pose_bone_constrained_output_matrix(
                    context,
                    armature,
                    pose_bone,
                    armature.matrix_world.inverted_safe() @ rolled_world,
                )
                changed = True
                continue
        if (
            opposite is not None
            and allow_planted_roll
            and anchor_planted
            and signed_distance >= -tolerance
            and opposite_distance < -tolerance
            and opposite_vector.length_squared > 1.0e-12
            and not _surface_contact_target_inside_smart_object(
                context,
                guide,
                target,
            )
        ):
            # The contact point is already planted but the far side crossed
            # the surface. Roll that side upward around the planted point;
            # translating the whole limb either unpins the contact or lets the
            # next sample jump to the mirrored/front-facing solution.
            bone_world = armature.matrix_world @ pose_bone.matrix
            length = opposite_vector.length
            tangent = opposite_vector - (
                normal * opposite_vector.dot(normal)
            )
            tangent_cache = _state.setdefault(
                "surface_contact_collision_tangents", {}
            )
            cache_key = _surface_contact_pose_cache_key(guide)
            if tangent.length_squared > 1.0e-12:
                tangent.normalize()
                previous_tangent = tangent_cache.get(cache_key)
                if previous_tangent is not None:
                    previous_tangent = Vector(previous_tangent)
                    previous_tangent -= (
                        normal * previous_tangent.dot(normal)
                    )
                    if (
                        previous_tangent.length_squared > 1.0e-12
                        and tangent.dot(previous_tangent) < 0.0
                    ):
                        # The rod crossed the surface-normal singularity.
                        # Its projected tangent has two equivalent signs;
                        # retain the previous hemisphere so the limb rolls
                        # through the boundary instead of teleporting to the
                        # mirrored side.
                        tangent.negate()
                tangent_cache[cache_key] = tangent.copy()
            else:
                tangent = Vector(
                    tangent_cache.get(cache_key, (0.0, 0.0, 0.0))
                )
                tangent -= normal * tangent.dot(normal)
                if tangent.length_squared <= 1.0e-12:
                    roll_frame = _state.setdefault(
                        "surface_contact_roll_frames", {}
                    ).get(cache_key)
                    if roll_frame is not None:
                        tangent = Vector(
                            roll_frame.get("roll", (0.0, 0.0, 0.0))
                        )
                        tangent -= normal * tangent.dot(normal)
                if tangent.length_squared <= 1.0e-12:
                    tangent = bone_world.to_3x3().col[0]
                    tangent -= normal * tangent.dot(normal)
                if tangent.length_squared <= 1.0e-12:
                    tangent = normal.orthogonal()
                tangent.normalize()
                tangent_cache[cache_key] = tangent.copy()
            # Continue through the physical arc instead of flattening the rod
            # at its side. Reflect the far endpoint's penetration depth to the
            # allowed half-space while preserving rod length. At first touch
            # this is continuous with the tangent pose; pushing farther gives
            # side -> diagonal-up -> fully-up rather than translating the
            # whole limb away from the surface.
            lift = min(
                length,
                max(tolerance, -float(opposite_distance)),
            )
            desired_opposite = (
                tangent
                * math.sqrt(max(0.0, (length * length) - (lift * lift)))
                + (normal * lift)
            )
            rotation = opposite_vector.rotation_difference(
                desired_opposite
            )
            rolled_world = (
                Matrix.Translation(Vector(anchor))
                @ rotation.to_matrix().to_4x4()
                @ Matrix.Translation(-Vector(anchor))
                @ bone_world
            )
            _set_pose_bone_constrained_output_matrix(
                context,
                armature,
                pose_bone,
                armature.matrix_world.inverted_safe() @ rolled_world,
            )
            _settled_target, _settled_normal, settled_anchor = (
                _surface_contact_world_point_normal(context, guide)
            )
            if settled_anchor is not None:
                residual = Vector(target) - Vector(settled_anchor)
                if residual.length_squared > 1.0e-14:
                    matrix = pose_bone.matrix.copy()
                    matrix.translation += (
                        armature.matrix_world.inverted_safe().to_3x3()
                        @ residual
                    )
                    _set_pose_bone_constrained_output_matrix(
                        context,
                        armature,
                        pose_bone,
                        matrix,
                    )
            changed = True
            continue
        if opposite_distance is not None:
            signed_distance = min(
                signed_distance,
                opposite_distance,
            )
        correction = normal * max(0.0, tolerance - signed_distance)
        smart_object = bpy.data.objects.get(
            str(guide.get(SURFACE_CONTACT_SMART_OBJECT_PROPERTY, ""))
        )
        if (
            smart_object is not None
            and _surface_contact_target_inside_smart_object(
                context,
                guide,
                target,
            )
        ):
            closest = _surface_contact_closest_point(
                smart_object,
                target,
                context.evaluated_depsgraph_get(),
                max(
                    1.0,
                    float(
                        guide.get(SURFACE_CONTACT_SIZE_PROPERTY, 0.05)
                    ) * 8.0,
                ),
            )
            if closest is not None:
                escape = Vector(target) - Vector(closest[0])
                if escape.length_squared > 1.0e-12:
                    correction += escape.normalized() * (
                        escape.length + tolerance
                    )
        if correction.length_squared <= 1.0e-14:
            break
        matrix = pose_bone.matrix.copy()
        matrix.translation += (
            armature.matrix_world.inverted_safe().to_3x3() @ correction
        )
        _set_pose_bone_constrained_output_matrix(
            context,
            armature,
            pose_bone,
            matrix,
        )
        changed = True
        target, _target_normal, anchor = _surface_contact_world_point_normal(
            context,
            guide,
        )
        if (
            target is not None
            and anchor is not None
            and not _surface_contact_pose_is_invalid(
                context,
                guide,
                target,
                normal,
                anchor,
            )
        ):
            _surface_contact_store_valid_pose(guide)
            return changed
    # Never jump to a stale cached pose after a native transform sample. The
    # next mouse sample starts from Blender's requested transform again, so a
    # rollback alternates between two poses and visibly flickers. Retain the
    # deterministic correction reached above; separation remains free.
    return changed


def _surface_contact_pose_is_invalid(context, guide, target, normal, anchor):
    snap_key = _surface_contact_snap_key(guide)
    attached_transform = bool(
        _state.get("pin_snap_transform_active", False)
        and snap_key
        and snap_key in _state.get("pin_snap_latches", set())
        and snap_key not in _state.get("pin_snap_detached", set())
        and snap_key
        not in _state.get("pin_snap_transform_releasing", set())
    )
    # While an attached limb rolls around its Contact socket, the socket can
    # legitimately enter the limb's own collision proxy. Treating that proxy
    # as a competing obstacle makes the collision correction fight the snap
    # solver and alternate above/below the surface. Other limbs are not part
    # of this query; keep the linked-surface endpoint barrier below as the
    # authoritative collision rule for an attached transform.
    if (
        not attached_transform
        and _surface_contact_target_inside_smart_object(context, guide, target)
    ):
        return True
    normal = Vector(normal)
    if normal.length_squared <= 1.0e-12:
        return False
    normal.normalize()
    tolerance = _surface_contact_settle_tolerance(guide)
    if (Vector(anchor) - Vector(target)).dot(normal) < -tolerance:
        return True
    opposite = _surface_contact_opposite_anchor_world(context, guide)
    return bool(
        opposite is not None
        and (Vector(opposite) - Vector(target)).dot(normal) < -tolerance
    )


def _surface_contact_accept_or_restore_pose(
    context,
    guide,
    target,
    normal,
    anchor,
):
    if _surface_contact_pose_is_invalid(
        context,
        guide,
        target,
        normal,
        anchor,
    ):
        return _surface_contact_restore_valid_pose(context, guide)
    _surface_contact_store_valid_pose(guide)
    return False


def _surface_contact_settle_parallel_collision(
    context,
    guide,
    armature,
    pose_bone,
    start_world_rotation,
):
    """Make detached Smart aim and surface separation agree."""
    changed = False
    for _settle in range(4):
        target, normal, anchor = _surface_contact_world_point_normal(
            context,
            guide,
        )
        if target is None or normal is None or anchor is None:
            break
        changed = bool(
            _surface_contact_rotate_simulated_pose_toward(
                context,
                guide,
                armature,
                pose_bone,
                anchor,
                target,
            )
        ) or changed
        target, normal, anchor = _surface_contact_world_point_normal(
            context,
            guide,
        )
        if (
            target is None
            or normal is None
            or anchor is None
            or not _surface_contact_pose_is_invalid(
                context,
                guide,
                target,
                normal,
                anchor,
            )
        ):
            break
        changed = bool(
            _surface_contact_resolve_pose_collision(
                context,
                guide,
                target,
                normal,
                anchor,
                allow_planted_roll=True,
            )
        ) or changed
    if not (
        _state.get("pin_snap_transform_active", False)
        or _state.get("pin_keyboard_transform_active", False)
        or _state.get("pin_target_dragging", False)
    ):
        bone_world = armature.matrix_world @ pose_bone.matrix
        final_rotation = bone_world.to_quaternion()
        angle = start_world_rotation.rotation_difference(final_rotation).angle
        if angle > SURFACE_CONTACT_MAX_AIM_STEP:
            clamped = start_world_rotation.slerp(
                final_rotation,
                SURFACE_CONTACT_MAX_AIM_STEP / angle,
            )
            location, _rotation, scale = bone_world.decompose()
            _set_pose_bone_constrained_output_matrix(
                context,
                armature,
                pose_bone,
                armature.matrix_world.inverted_safe()
                @ Matrix.LocRotScale(location, clamped, scale),
            )
    return changed


def _surface_contact_seed_valid_poses():
    cache = _state.setdefault("surface_contact_valid_poses", {})
    cache.clear()
    for guide in _surface_contact_guides():
        _surface_contact_store_valid_pose(guide)
    return bool(cache)
