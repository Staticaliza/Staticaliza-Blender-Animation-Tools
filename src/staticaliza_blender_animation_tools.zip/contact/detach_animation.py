"""Frame-aware free-separation state for simulated surface contacts."""

from ..core.runtime import *  # noqa: F403


def _surface_contact_detached_fcurves(guide):
    if guide is None:
        return ()
    action = _dynamic_parent_owner_action(guide)
    if action is None:
        return ()
    data_path = f'["{SURFACE_CONTACT_DETACHED_PROPERTY}"]'
    animated_id = getattr(guide, "id_data", None) or guide
    return tuple(_fcurves_find_all(action, data_path, animated_id))


def _surface_contact_animated_detached_state(guide, frame):
    """Return keyed free state, anticipating a lift until its landing key.

    The state is free throughout a segment touching a detached key. This lets
    the bone's regular F-curves ease away from and back toward the contact,
    while an exact attached key still magnetizes dot-to-dot at the landing.
    """
    frame = float(frame)
    for fcurve in _surface_contact_detached_fcurves(guide):
        keys = tuple(sorted(fcurve.keyframe_points, key = lambda key: key.co.x))
        if not keys:
            continue
        exact = next(
            (key for key in keys if abs(float(key.co.x) - frame) <= 1.0e-5),
            None,
        )
        if exact is not None:
            return float(exact.co.y) >= 0.5
        previous = next(
            (key for key in reversed(keys) if float(key.co.x) < frame),
            None,
        )
        following = next(
            (key for key in keys if float(key.co.x) > frame),
            None,
        )
        if previous is None:
            return float(keys[0].co.y) >= 0.5
        if following is None:
            return float(previous.co.y) >= 0.5
        return bool(float(previous.co.y) >= 0.5 or float(following.co.y) >= 0.5)
    return None


def _surface_contact_keyframe_detached_state(guide, frame, detached):
    if (
        guide is None
        or not _surface_contact_snap_capable(guide)
    ):
        return False
    frame = int(frame)
    data_path = f'["{SURFACE_CONTACT_DETACHED_PROPERTY}"]'
    if not _surface_contact_detached_fcurves(guide):
        start = int(guide.get(SURFACE_CONTACT_START_PROPERTY, frame))
        if start != frame:
            guide[SURFACE_CONTACT_DETACHED_PROPERTY] = 0.0
            guide.keyframe_insert(data_path = data_path, frame = start)
    guide[SURFACE_CONTACT_DETACHED_PROPERTY] = 1.0 if detached else 0.0
    guide.keyframe_insert(data_path = data_path, frame = frame)
    action = _dynamic_parent_owner_action(guide)
    if action is None:
        return False
    bone_name = str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, "Contact"))
    for fcurve in _surface_contact_detached_fcurves(guide):
        _set_fcurve_group(
            fcurve,
            action,
            f"Surface Contact State ({bone_name})",
        )
        for key in fcurve.keyframe_points:
            key.interpolation = "CONSTANT"
            key.handle_left_type = "AUTO"
            key.handle_right_type = "AUTO"
        fcurve.update()
    return True


def _surface_contact_commit_target_key(context, guide, detached = None):
    """Persist the already-previewed target and its attachment state."""

    frame = int(context.scene.frame_current)
    bone_name = str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, "Contact"))
    _surface_contact_keyframe_guide_transform(guide, frame, bone_name)
    if detached is None:
        detached = bool(
            guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)
        )
    _surface_contact_keyframe_detached_state(guide, frame, bool(detached))
    start = int(guide.get(SURFACE_CONTACT_START_PROPERTY, frame))
    if frame != start:
        target_frames = set(_surface_contact_target_frames(guide))
        target_frames.add(frame)
        _surface_contact_set_target_frames(guide, target_frames)
    _marker_object, marker_owner = _surface_contact_owner_from_guide(guide)
    if marker_owner is not None:
        _surface_contact_insert_marker(
            marker_owner,
            bone_name,
            frame,
            1.0,
        )
        _surface_contact_rebuild_markers(marker_owner, bone_name)
    if _surface_contact_snap_capable(guide):
        _surface_contact_keyframe_simulated_pose(guide, frame)
        if (
            str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
            == SURFACE_CONTACT_KIND_SIMULATED
        ):
            _surface_contact_store_owner_pose_base(guide)
    context.view_layer.update()
    _surface_contact_seed_runtime_signatures(context, (guide,))
    _tag_redraw_all_view3d()


def _surface_contact_finalize_snap_departures(context):
    departing = _state.setdefault("pin_snap_departing", set())
    seen = _state.setdefault("pin_snap_transform_seen", set())
    initial_states = _state.setdefault("pin_snap_initial_detached", {})
    if not departing and not seen:
        return False
    changed = False
    frame = int(context.scene.frame_current)
    for guide in _surface_contact_active_snap_guides(context.scene):
        key = _surface_contact_snap_key(guide)
        if key not in departing and key not in seen:
            continue
        target, _normal, anchor = _surface_contact_world_point_normal(
            context,
            guide,
        )
        explicitly_detached = key in _state.setdefault(
            "pin_snap_detached",
            set(),
        )
        initial_detached = initial_states.pop(
            key,
            _surface_contact_animated_detached_state(guide, frame),
        )
        started_attached = bool(
            key in _state.setdefault("pin_snap_initial_latches", set())
            or _state.get("pin_snap_parent_attachment_states", {}).get(
                guide.name,
                False,
            )
            or initial_detached is False
        )
        explicitly_released = key in _state.setdefault(
            "pin_snap_transform_releasing", set()
        )
        geometrically_attached = bool(
            target is not None
            and anchor is not None
            and (
                (Vector(target) - Vector(anchor)).length <= 1.0e-7
                or _pin_points_within_snap_radius(context, target, anchor)
            )
        )
        # A transform that began snapped remains snapped unless the directly
        # edited pink bone explicitly pulled out. Pressure can intentionally
        # lift the visible bottom while the imaginary top pivots, so endpoint
        # overlap is not a valid detach test for torso/ancestor movement.
        attached = bool(
            (started_attached and not explicitly_released)
            or (
                not started_attached
                and not explicitly_detached
                and geometrically_attached
            )
        )
        if attached:
            _surface_contact_clear_snap_departure(guide)
            # Clearing departure also clears transient snap state. Restore the
            # confirmed latch so Contact behaves like Onion after mouse-up:
            # the next transform begins snapped instead of requiring a second
            # click to rediscover the entry radius.
            _state.setdefault("pin_snap_latches", set()).add(key)
            if target is not None:
                _state.setdefault("pin_snap_previous_points", {})[key] = (
                    Vector(target).copy()
                )
        else:
            departing.discard(key)
            seen.discard(key)
            _surface_contact_set_snap_detached(guide, True)
            _state.setdefault("pin_snap_latches", set()).discard(key)
        final_detached = not attached
        if initial_detached is None or bool(initial_detached) != final_detached:
            _surface_contact_keyframe_detached_state(
                guide,
                frame,
                final_detached,
            )
        changed = True
    return changed
