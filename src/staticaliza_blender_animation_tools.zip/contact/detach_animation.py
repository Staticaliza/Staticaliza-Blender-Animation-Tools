"""Frame-aware free-separation state for simulated surface contacts."""

from bisect import bisect_left

from ..core.runtime import *  # noqa: F403


def _surface_contact_detached_fcurves(guide):
    if guide is None:
        return ()
    action = _dynamic_parent_owner_action(guide)
    if action is None:
        return ()
    try:
        key = (
            int(_state.get("surface_contact_guide_cache_generation", 0)),
            int(guide.as_pointer()),
            int(action.as_pointer()),
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        key = None
    cache = _state.setdefault("surface_contact_detached_fcurve_cache", {})
    if key is not None and key in cache:
        return tuple(cache[key])
    data_path = f'["{SURFACE_CONTACT_DETACHED_PROPERTY}"]'
    animated_id = getattr(guide, "id_data", None) or guide
    fcurves = tuple(_fcurves_find_all(action, data_path, animated_id))
    if key is not None:
        cache[key] = fcurves
    return fcurves


def _surface_contact_invalidate_detached_key_cache(guide=None):
    _state["surface_contact_detached_cache_revision"] = int(
        _state.get("surface_contact_detached_cache_revision", 0)
    ) + 1
    cache = _state.setdefault("surface_contact_detached_key_cache", {})
    attached_cache = _state.setdefault("surface_contact_attached_frame_cache", {})
    fcurve_cache = _state.setdefault("surface_contact_detached_fcurve_cache", {})
    attached_cache.clear()
    _state["surface_contact_attached_frame_cache_scope"] = None
    if guide is None:
        cache.clear()
        fcurve_cache.clear()
        return
    pointer = int(guide.as_pointer())
    for key in tuple(cache):
        if key and int(key[0]) == pointer:
            cache.pop(key, None)
    for key in tuple(fcurve_cache):
        if len(key) > 1 and int(key[1]) == pointer:
            fcurve_cache.pop(key, None)


def _surface_contact_cached_detached_keys(guide, fcurve):
    cache = _state.setdefault("surface_contact_detached_key_cache", {})
    key = (int(guide.as_pointer()), int(fcurve.as_pointer()))
    values = cache.get(key)
    if values is None:
        pairs = tuple(sorted(
            (
                (float(point.co.x), float(point.co.y) >= 0.5)
                for point in fcurve.keyframe_points
            ),
            key=lambda item: item[0],
        ))
        values = (
            tuple(item[0] for item in pairs),
            tuple(item[1] for item in pairs),
        )
        cache[key] = values
    return values


def _surface_contact_keyed_detached_state(keys, frame):
    frames, states = keys
    if not frames:
        return None
    frame = float(frame)
    index = bisect_left(frames, frame)
    if index < len(frames) and abs(frames[index] - frame) <= 1.0e-5:
        return bool(states[index])
    if index > 0 and abs(frames[index - 1] - frame) <= 1.0e-5:
        return bool(states[index - 1])
    if index <= 0:
        return bool(states[0])
    if index >= len(frames):
        return bool(states[-1])
    return bool(states[index - 1] or states[index])


def _surface_contact_animated_detached_state(guide, frame):
    """Return keyed free state, anticipating a lift until its landing key."""
    for fcurve in _surface_contact_detached_fcurves(guide):
        state = _surface_contact_keyed_detached_state(
            _surface_contact_cached_detached_keys(guide, fcurve),
            frame,
        )
        if state is not None:
            return state
    return None

def _surface_contact_attached_at_frame(guide, frame):
    """Return whether Contact remains attached at this frame."""
    bypass = bool(_state.get("dynamic_space_export_sampling", False))
    generation = int(_state.get("surface_contact_guide_cache_generation", 0))
    revision = int(_state.get("surface_contact_detached_cache_revision", 0))
    scope = generation, revision, float(frame)
    cache = _state.setdefault("surface_contact_attached_frame_cache", {})
    if not bypass and _state.get(
        "surface_contact_attached_frame_cache_scope"
    ) != scope:
        cache.clear()
        _state["surface_contact_attached_frame_cache_scope"] = scope
    try:
        key = (
            int(guide.as_pointer()),
            bool(guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)),
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        key = None
    if not bypass and key is not None and key in cache:
        return bool(cache[key])
    detached = _surface_contact_animated_detached_state(guide, frame)
    attached = (
        not detached
        if detached is not None
        else not bool(guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False))
    )
    if not bypass and key is not None:
        cache[key] = bool(attached)
    return bool(attached)


def _surface_contact_keyframe_detached_state(guide, frame, detached):
    if (
        guide is None
        or not _surface_contact_snap_capable(guide)
    ):
        return False
    frame = int(frame)
    _surface_contact_invalidate_detached_key_cache(guide)
    data_path = f'["{SURFACE_CONTACT_DETACHED_PROPERTY}"]'
    if not _surface_contact_detached_fcurves(guide):
        start = int(guide.get(SURFACE_CONTACT_START_PROPERTY, frame))
        if start != frame:
            guide[SURFACE_CONTACT_DETACHED_PROPERTY] = 0.0
            guide.keyframe_insert(data_path = data_path, frame = start)
    guide[SURFACE_CONTACT_DETACHED_PROPERTY] = 1.0 if detached else 0.0
    guide.keyframe_insert(data_path = data_path, frame = frame)
    action = _dynamic_parent_owner_action(guide)
    if action is None:
        return False
    bone_name = str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, "Contact"))
    animated_id = getattr(guide, "id_data", None) or guide
    end_key_type = "GENERATED" if bool(detached) else "KEYFRAME"
    for fcurve in _surface_contact_detached_fcurves(guide):
        _set_fcurve_group(
            fcurve,
            action,
            f"Surface Contact State ({bone_name})",
        )
        for key in fcurve.keyframe_points:
            key.interpolation = "CONSTANT"
            key.handle_left_type = "AUTO"
            key.handle_right_type = "AUTO"
        fcurve.update()
    for fcurve in _action_fcurves(action, animated_id):
        if fcurve.data_path not in {
            "location",
            "rotation_euler",
            "rotation_quaternion",
            "rotation_axis_angle",
            data_path,
        }:
            continue
        for key in fcurve.keyframe_points:
            if abs(float(key.co.x) - float(frame)) <= 1.0e-5:
                key.type = end_key_type
        fcurve.update()
    _surface_contact_invalidate_detached_key_cache(guide)
    return True


def _surface_contact_commit_target_key(context, guide, detached = None):
    """Persist the already-previewed target and its attachment state."""

    frame = int(context.scene.frame_current)
    bone_name = str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, "Contact"))
    _surface_contact_keyframe_guide_transform(guide, frame, bone_name)
    if detached is None:
        detached = bool(
            guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)
        )
    _surface_contact_keyframe_detached_state(guide, frame, bool(detached))
    start = int(guide.get(SURFACE_CONTACT_START_PROPERTY, frame))
    if frame != start:
        target_frames = set(_surface_contact_target_frames(guide))
        target_frames.add(frame)
        _surface_contact_set_target_frames(guide, target_frames)
    _marker_object, marker_owner = _surface_contact_owner_from_guide(guide)
    if marker_owner is not None:
        _surface_contact_insert_marker(
            marker_owner,
            bone_name,
            frame,
            1.0,
        )
        _surface_contact_rebuild_markers(marker_owner, bone_name)
    if _surface_contact_snap_capable(guide):
        _surface_contact_keyframe_simulated_pose(guide, frame)
        if (
            str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
            == SURFACE_CONTACT_KIND_SIMULATED
        ):
            _surface_contact_store_owner_pose_base(guide)
    context.view_layer.update()
    _surface_contact_seed_runtime_signatures(context, (guide,))
    _tag_redraw_all_view3d()


def _surface_contact_finalize_snap_departures(context):
    departing = _state.setdefault("pin_snap_departing", set())
    seen = _state.setdefault("pin_snap_transform_seen", set())
    initial_states = _state.setdefault("pin_snap_initial_detached", {})
    if not departing and not seen:
        return False
    changed = False
    frame = int(context.scene.frame_current)
    for guide in _surface_contact_active_snap_guides(context.scene):
        key = _surface_contact_snap_key(guide)
        if key not in departing and key not in seen:
            continue
        target, _normal, anchor = _surface_contact_world_point_normal(
            context,
            guide,
        )
        explicitly_detached = key in _state.setdefault(
            "pin_snap_detached",
            set(),
        )
        directly_engaged = key in _state.setdefault(
            "pin_snap_transform_engaged",
            set(),
        )
        if directly_engaged:
            explicitly_detached = False
        initial_detached = initial_states.pop(
            key,
            _surface_contact_animated_detached_state(guide, frame),
        )
        started_attached = bool(
            key in _state.setdefault("pin_snap_initial_latches", set())
            or _state.get("pin_snap_parent_attachment_states", {}).get(
                guide.name,
                False,
            )
            or initial_detached is False
        )
        explicitly_released = key in _state.setdefault(
            "pin_snap_transform_releasing", set()
        )
        geometrically_attached = bool(
            target is not None
            and anchor is not None
            and (
                (Vector(target) - Vector(anchor)).length <= 1.0e-7
                or _pin_points_within_snap_radius(context, target, anchor)
            )
        )
        direct_geometric_engagement = bool(
            geometrically_attached
            and not explicitly_released
            and _surface_contact_guide_directly_selected(context, guide)
        )
        # A transform that began snapped remains snapped unless the directly
        # edited pink bone explicitly pulled out. Pressure can intentionally
        # lift the visible bottom while the imaginary top pivots, so endpoint
        # overlap is not a valid detach test for torso/ancestor movement.
        attached = bool(
            (directly_engaged and not explicitly_released)
            or direct_geometric_engagement
            or (started_attached and not explicitly_released)
            or (
                not started_attached
                and not explicitly_detached
                and geometrically_attached
            )
        )
        if attached:
            _surface_contact_clear_snap_departure(guide)
            # Clearing departure also clears transient snap state. Restore the
            # confirmed latch so Contact behaves like Onion after mouse-up:
            # the next transform begins snapped instead of requiring a second
            # click to rediscover the entry radius.
            _state.setdefault("pin_snap_latches", set()).add(key)
            if target is not None:
                _state.setdefault("pin_snap_previous_points", {})[key] = (
                    Vector(target).copy()
                )
        else:
            departing.discard(key)
            seen.discard(key)
            _surface_contact_set_snap_detached(guide, True)
            _state.setdefault("pin_snap_latches", set()).discard(key)
        final_detached = not attached
        if initial_detached is None or bool(initial_detached) != final_detached:
            _surface_contact_keyframe_detached_state(
                guide,
                frame,
                final_detached,
            )
        changed = True
    return changed
