"""Stable shortest-arc rotation for high-force contact poses."""

from ..core.runtime import *  # noqa: F403


def _surface_contact_stable_rotation(
    guide,
    bone_world,
    current_direction,
    target_direction,
):
    """Return a continuous rotation without anti-parallel axis flipping."""

    current_direction = Vector(current_direction).normalized()
    target_direction = Vector(target_direction).normalized()
    dot = max(-1.0, min(1.0, current_direction.dot(target_direction)))
    angle = math.acos(dot)
    if angle <= 1.0e-7:
        return None
    detached = bool(
        bool(guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False))
        or _surface_contact_snap_key(guide)
        in _state.setdefault("pin_snap_detached", set())
    )
    interactive = bool(
        _state.get("pin_snap_transform_active", False)
        or _state.get("pin_keyboard_transform_active", False)
        or _state.get("pin_target_dragging", False)
    )
    if detached and not interactive:
        angle = min(angle, SURFACE_CONTACT_MAX_AIM_STEP)

    axes = _state.setdefault("surface_contact_rotation_axes", {})
    key = _surface_contact_pose_cache_key(guide)
    axis = current_direction.cross(target_direction)
    previous_axis = axes.get(key)
    ambiguous_axis = axis.length_squared <= 1.0e-10
    if ambiguous_axis:
        roll_frame = _state.setdefault(
            "surface_contact_roll_frames", {}
        ).get(key)
        if roll_frame is not None:
            axis = Vector(roll_frame.get("roll", (0.0, 0.0, 0.0)))
            axis -= current_direction * axis.dot(current_direction)
        if previous_axis is not None:
            if axis.length_squared <= 1.0e-10:
                axis = Vector(previous_axis)
                axis -= current_direction * axis.dot(current_direction)
        if axis.length_squared <= 1.0e-10:
            surface_normal = guide.matrix_world.to_3x3().col[2]
            axis = current_direction.cross(surface_normal)
        if axis.length_squared <= 1.0e-10:
            axis = bone_world.to_3x3().col[0]
            axis -= current_direction * axis.dot(current_direction)
        if axis.length_squared <= 1.0e-10:
            axis = current_direction.orthogonal()
    axis.normalize()
    if (
        ambiguous_axis
        and previous_axis is not None
        and axis.dot(Vector(previous_axis)) < 0.0
    ):
        axis.negate()
    axes[key] = axis.copy()

    return Quaternion(axis, angle)
