"""Visible Contact marker styles bridged to hidden guide animation keys."""

from ..core.runtime import *  # noqa: F403


def _surface_contact_key_style(key, target_key = True):
    """Capture interpolation settings used by a visible Contact proxy key."""
    if key is None:
        return {
            "type": "KEYFRAME" if target_key else "GENERATED",
            "interpolation": "BEZIER" if target_key else "CONSTANT",
            "easing": "AUTO",
            "handle_left_type": "AUTO",
            "handle_right_type": "AUTO",
        }
    return {
        property_name: getattr(key, property_name, default)
        for property_name, default in (
            ("type", "KEYFRAME" if target_key else "GENERATED"),
            ("interpolation", "BEZIER" if target_key else "CONSTANT"),
            ("easing", "AUTO"),
            ("handle_left_type", "AUTO"),
            ("handle_right_type", "AUTO"),
            ("amplitude", 0.0),
            ("back", 0.0),
            ("period", 0.0),
        )
    }


def _surface_contact_apply_key_style(key, style):
    changed = False
    for property_name, value in dict(style or {}).items():
        try:
            if getattr(key, property_name) == value:
                continue
            setattr(key, property_name, value)
            changed = True
        except (AttributeError, TypeError, ValueError):
            continue
    return changed


def _surface_contact_marker_fcurves(owner):
    if owner is None:
        return ()
    action = _dynamic_parent_owner_action(owner)
    if action is None:
        return ()
    try:
        data_path = owner.path_from_id() + (
            f'["{SURFACE_CONTACT_MARKER_PROPERTY}"]'
        )
    except (AttributeError, TypeError, ValueError):
        return ()
    animated_id = getattr(owner, "id_data", None) or owner
    return tuple(_fcurves_find_all(action, data_path, animated_id))


def _surface_contact_marker_key_style(owner, frame, target_key = None):
    for fcurve in _surface_contact_marker_fcurves(owner):
        key = _fcurve_key_at(fcurve, int(frame))
        if key is not None:
            key_is_target = float(key.co.y) >= 0.5
            if target_key is not None and bool(target_key) != key_is_target:
                return None
            return _surface_contact_key_style(
                key,
                target_key = key_is_target,
            )
    return None


def _surface_contact_sync_guide_key_styles(owner, guide):
    """Bridge visible marker easing to the hidden authoritative guide Action."""
    if owner is None or guide is None:
        return False
    action = _dynamic_parent_owner_action(guide)
    if action is None:
        return False
    animated_id = getattr(guide, "id_data", None) or guide
    rotation_path = (
        "rotation_quaternion"
        if guide.rotation_mode == "QUATERNION"
        else "rotation_axis_angle"
        if guide.rotation_mode == "AXIS_ANGLE"
        else "rotation_euler"
    )
    frames = {
        int(guide.get(SURFACE_CONTACT_START_PROPERTY, 0)),
        *_surface_contact_target_frames(guide),
    }
    changed = False
    for frame in frames:
        style = _surface_contact_marker_key_style(owner, frame, target_key = True)
        if style is None:
            continue
        for data_path in ("location", rotation_path):
            for fcurve in _fcurves_find_all(action, data_path, animated_id):
                key = _fcurve_key_at(fcurve, frame)
                if key is None:
                    continue
                curve_changed = _surface_contact_apply_key_style(key, style)
                changed = curve_changed or changed
                if curve_changed:
                    fcurve.update()
    return changed
