"""Shared attachment state for simulated and existing-IK contacts."""

from ..core.runtime import *  # noqa: F403


def _surface_contact_history_entry_parts(entry):
    values = tuple(entry or ())
    new_format = bool(
        len(values) >= 6
        or len(values) == 5
        and not isinstance(values[0], (tuple, list))
    )
    if new_format:
        armature_name, bone_name, before, native_after, solved_after = values[-5:]
    elif len(values) >= 4:
        armature_name, bone_name, before, native_after = values[-4:]
        solved_after = native_after
    else:
        raise ValueError("Invalid Contact history entry")
    return (
        str(armature_name),
        str(bone_name),
        before,
        native_after,
        solved_after,
    )


def _surface_contact_history_side_matches(entries, index):
    """Match selected or contact history entries against one paired side."""
    index = int(index)
    if index not in (0, 1):
        return False
    for entry in entries:
        armature_name, bone_name, before, native_after, solved_after = (
            _surface_contact_history_entry_parts(entry)
        )
        armature = bpy.data.objects.get(armature_name)
        pose_bone = (
            armature.pose.bones.get(bone_name)
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        expected = (before,) if index == 0 else (native_after, solved_after)
        if pose_bone is None or not any(
            not _pin_keyboard_matrices_differ(
                pose_bone.matrix_basis,
                matrix,
                epsilon=1.0e-5,
            )
            for matrix in expected
        ):
            return False
    return True


def _surface_contact_snap_capable(guide):
    return str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, "")) in {
        SURFACE_CONTACT_KIND_SIMULATED,
        SURFACE_CONTACT_KIND_CONTROL,
    }


def _surface_contact_constraint_history_state(guide):
    """Capture the exact runtime state of Contact-owned constraints."""
    primary, secondary = _surface_contact_constraints(guide)
    entries = []
    for role, constraint in (("PRIMARY", primary), ("SECONDARY", secondary)):
        if constraint is None:
            entries.append((role, "", "", None, None))
            continue
        entries.append((
            role,
            str(getattr(constraint, "name", "")),
            str(getattr(constraint, "type", "")),
            float(getattr(constraint, "influence", 1.0)),
            bool(getattr(constraint, "mute", False)),
        ))
    return tuple(entries)


def _surface_contact_restore_constraint_history_state(guide, snapshot):
    """Restore Contact constraints without reconstructing their state."""
    if guide is None or not snapshot:
        return False
    primary, secondary = _surface_contact_constraints(guide)
    by_role = {"PRIMARY": primary, "SECONDARY": secondary}
    _target_object, owner = _surface_contact_constraint_owner_from_guide(guide)
    constraints = getattr(owner, "constraints", None)
    changed = False
    for role, name, constraint_type, influence, mute in tuple(snapshot):
        constraint = by_role.get(str(role))
        if (
            constraint is None
            or (name and str(getattr(constraint, "name", "")) != str(name))
        ) and constraints is not None and name:
            try:
                constraint = constraints.get(str(name))
            except (AttributeError, ReferenceError, RuntimeError):
                constraint = None
        if constraint is None:
            continue
        if constraint_type and str(getattr(constraint, "type", "")) != str(constraint_type):
            continue
        if influence is not None and abs(
            float(getattr(constraint, "influence", 1.0)) - float(influence)
        ) > 1.0e-8:
            constraint.influence = float(influence)
            changed = True
        if mute is not None and hasattr(constraint, "mute") and bool(constraint.mute) != bool(mute):
            constraint.mute = bool(mute)
            changed = True
    return changed


def _surface_contact_set_constraint_attachment(guide, attached):
    """Enable existing-IK target constraints only while magnetically attached."""

    if (
        str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
        != SURFACE_CONTACT_KIND_CONTROL
    ):
        return False
    primary, secondary = _surface_contact_constraints(guide)
    desired = (
        (primary, 1.0 if attached else 0.0),
        (
            secondary,
            _surface_contact_guide_aim_influence(guide)
            if attached
            else 0.0,
        ),
    )
    changed = False
    for constraint, influence in desired:
        if (
            constraint is not None
            and abs(float(constraint.influence) - influence) > 1.0e-6
        ):
            constraint.influence = influence
            changed = True
    return changed
