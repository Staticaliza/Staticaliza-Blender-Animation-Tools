"""Shared attachment state for simulated and existing-IK contacts."""

from ..core.runtime import *  # noqa: F403


def _surface_contact_history_side_matches(entries, index):
    """Match selected or contact history entries against one paired side."""
    for entry in entries:
        armature_name, bone_name, before, after = entry[-4:]
        armature = bpy.data.objects.get(armature_name)
        pose_bone = (
            armature.pose.bones.get(bone_name)
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        expected = before if index == 0 else after
        if (
            pose_bone is None
            or _pin_keyboard_matrices_differ(
                pose_bone.matrix_basis,
                expected,
                epsilon=1.0e-5,
            )
        ):
            return False
    return True


def _surface_contact_snap_capable(guide):
    return str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, "")) in {
        SURFACE_CONTACT_KIND_SIMULATED,
        SURFACE_CONTACT_KIND_CONTROL,
    }


def _surface_contact_set_constraint_attachment(guide, attached):
    """Enable existing-IK target constraints only while magnetically attached."""

    if (
        str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
        != SURFACE_CONTACT_KIND_CONTROL
    ):
        return False
    primary, secondary = _surface_contact_constraints(guide)
    desired = (
        (primary, 1.0 if attached else 0.0),
        (
            secondary,
            _surface_contact_guide_aim_influence(guide)
            if attached
            else 0.0,
        ),
    )
    changed = False
    for constraint, influence in desired:
        if (
            constraint is not None
            and abs(float(constraint.influence) - influence) > 1.0e-6
        ):
            constraint.influence = influence
            changed = True
    return changed
