"""Exact evaluated contact poses paired with native transform history."""

from ..core.runtime import *  # noqa: F403


def _surface_contact_capture_history_visuals(
    context, contact_starts, live_poses
):
    visuals = []
    for guide in _surface_contact_active_simulated_guides(context.scene):
        armature, pose_bone = _surface_contact_pose_bone(guide)
        if armature is None or pose_bone is None:
            continue
        pose_key = (_armature_session_uid(armature), pose_bone.name)
        start = contact_starts.get(pose_key)
        if start is None:
            continue
        live_pose = live_poses.get(pose_key)
        visuals.append(
            (
                (_armature_session_uid(armature), guide.name),
                armature.name,
                pose_bone.name,
                (
                    start[3].copy()
                    if len(start) > 3
                    else pose_bone.matrix.copy()
                ),
                (
                    live_pose[3].copy()
                    if live_pose is not None and len(live_pose) > 3
                    else pose_bone.matrix.copy()
                ),
            )
        )
    return tuple(visuals)


def _surface_contact_restore_history_visuals(transition, restore_index):
    changed = False
    restored = set()
    for _key, armature_name, bone_name, before, after in transition.get(
        "visual_poses", ()
    ):
        owner = (armature_name, bone_name)
        if owner in restored:
            continue
        restored.add(owner)
        armature = bpy.data.objects.get(armature_name)
        pose_bone = (
            armature.pose.bones.get(bone_name)
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        expected = before if restore_index == 0 else after
        if (
            pose_bone is not None
            and _pin_keyboard_matrices_differ(
                pose_bone.matrix,
                expected,
                epsilon=1.0e-6,
            )
        ):
            pose_bone.matrix = expected.copy()
            changed = True
    return changed


def _surface_contact_set_history_pose_lock(transition, restore_index):
    """Hold one exact contact side through Blender's late history evaluation."""
    visual_by_owner = {
        (armature_name, bone_name): (
            before_visual if restore_index == 0 else after_visual
        ).copy()
        for (
            _key,
            armature_name,
            bone_name,
            before_visual,
            after_visual,
        ) in transition.get("visual_poses", ())
    }
    locked = []
    seen = set()
    for (
        _key,
        armature_name,
        bone_name,
        before_basis,
        after_basis,
    ) in transition.get("contacts", ()):
        owner = (armature_name, bone_name)
        if owner in seen:
            continue
        seen.add(owner)
        locked.append((
            armature_name,
            bone_name,
            (before_basis if restore_index == 0 else after_basis).copy(),
            visual_by_owner.get(owner),
        ))
    _state["pin_history_contact_pose_lock"] = tuple(locked)
    return bool(locked)


def _surface_contact_set_current_history_pose_lock(
    context, owner_keys, *, include_detached=False, append=False
):
    """Lock only contacts corrected from a changed selected ancestor."""
    owner_keys = set(owner_keys)
    locked = []
    for guide in _surface_contact_active_simulated_guides(context.scene):
        armature, pose_bone = _surface_contact_pose_bone(guide)
        owner_key = (_armature_session_uid(armature), guide.name)
        if (
            owner_key not in owner_keys
            or armature is None
            or pose_bone is None
            or (
                not include_detached
                and bool(guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False))
            )
        ):
            continue
        locked.append((
            armature.name,
            pose_bone.name,
            pose_bone.matrix_basis.copy(),
            pose_bone.matrix.copy(),
        ))
    if append:
        existing = tuple(_state.get("pin_history_contact_pose_lock", ()))
        existing_owners = {
            (str(item[0]), str(item[1])) for item in existing
        }
        locked = list(existing) + [
            item for item in locked
            if (str(item[0]), str(item[1])) not in existing_owners
        ]
    _state["pin_history_contact_pose_lock"] = tuple(locked)
    return bool(locked)


def _surface_contact_apply_history_pose_lock(
    context, update_view_layer=False
):
    """Reassert paired child poses without re-running contact solver math."""
    locked = tuple(_state.get("pin_history_contact_pose_lock", ()))
    if (
        not locked
        or _state.get("pin_history_pose_lock_syncing", False)
    ):
        return False
    _state["pin_history_pose_lock_syncing"] = True
    changed = False
    try:
        resolved = []
        for armature_name, bone_name, basis, visual in locked:
            armature = bpy.data.objects.get(str(armature_name))
            pose_bone = (
                armature.pose.bones.get(str(bone_name))
                if armature is not None and getattr(armature, "pose", None)
                else None
            )
            if pose_bone is None:
                continue
            resolved.append((pose_bone, basis, visual))
            if _pin_keyboard_matrices_differ(
                pose_bone.matrix_basis, basis, epsilon=1.0e-6
            ):
                pose_bone.matrix_basis = basis.copy()
                changed = True
        if update_view_layer and resolved:
            context.view_layer.update()
        # Apply the captured evaluated output after Blender has evaluated
        # Actions. Do not evaluate again here: that is the late pass which
        # used to replace the correct contact pose with the keyed straight one.
        for pose_bone, _basis, visual in resolved:
            if (
                visual is not None
                and _pin_keyboard_matrices_differ(
                    pose_bone.matrix, visual, epsilon=1.0e-6
                )
            ):
                pose_bone.matrix = visual.copy()
                changed = True
        return changed
    finally:
        _state["pin_history_pose_lock_syncing"] = False


def _surface_contact_history_lock_matches_frame(context):
    scene = getattr(context, "scene", None) if context is not None else None
    expected = _state.get("pin_history_pose_release_frame")
    return bool(
        scene is not None
        and expected
        and int(scene.as_pointer()) == int(expected[0])
        and int(scene.frame_current) == int(expected[1])
        and abs(float(scene.frame_subframe) - float(expected[2])) <= 1.0e-7
    )


def _surface_contact_history_lock_update_relevant(depsgraph):
    locked_names = {
        str(armature_name)
        for armature_name, _bone_name, _basis, _visual in tuple(
            _state.get("pin_history_contact_pose_lock", ())
        )
    }
    relevant_pointers = set()
    for armature_name in locked_names:
        armature = bpy.data.objects.get(armature_name)
        if armature is None:
            continue
        candidates = (
            armature,
            getattr(armature, "data", None),
            getattr(getattr(armature, "animation_data", None), "action", None),
        )
        for candidate in candidates:
            candidate = getattr(candidate, "original", candidate)
            try:
                relevant_pointers.add(int(candidate.as_pointer()))
            except (AttributeError, ReferenceError, RuntimeError, TypeError):
                pass
    for update in tuple(getattr(depsgraph, "updates", ())):
        updated = getattr(update, "id", None)
        updated = getattr(updated, "original", updated)
        try:
            if int(updated.as_pointer()) in relevant_pointers:
                return True
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            pass
    return False


def _surface_contact_history_pose_release_timeout():
    if not _state.get("pin_history_pose_release_pending", False):
        return None
    now = time.perf_counter()
    deadline = float(_state.get("pin_history_pose_release_deadline", 0.0))
    observed = bool(_state.get("pin_history_pose_release_observed", False))
    last_event = float(
        _state.get("pin_history_pose_release_last_event", 0.0)
    )
    if now < deadline and (not observed or now - last_event < 0.08):
        return 0.05
    _surface_contact_clear_history_pose_lock()
    return None


def _surface_contact_begin_history_pose_release(context):
    """Keep the exact Redo side through one queued same-frame Action pass."""
    if not _state.get("pin_history_contact_pose_lock", ()):
        _surface_contact_clear_history_pose_lock()
        return False
    scene = getattr(context, "scene", None) if context is not None else None
    if scene is None:
        _surface_contact_clear_history_pose_lock()
        return False
    _state["pin_history_pose_release_pending"] = True
    _state["pin_history_pose_release_frame"] = (
        int(scene.as_pointer()),
        int(scene.frame_current),
        float(scene.frame_subframe),
    )
    _state["pin_history_pose_release_deadline"] = time.perf_counter() + 0.75
    _state["pin_history_pose_release_last_event"] = time.perf_counter()
    _state["pin_history_pose_release_observed"] = False
    try:
        register_owned_timer(
            _surface_contact_history_pose_release_timeout,
            first_interval=0.05,
        )
    except (RuntimeError, ValueError):
        pass
    return True


def _surface_contact_finish_history_pose_release(context):
    if not _state.get("pin_history_pose_release_pending", False):
        return False
    if not _surface_contact_history_lock_matches_frame(context):
        _surface_contact_clear_history_pose_lock()
        return False
    changed = _surface_contact_apply_history_pose_lock(context)
    _state["pin_history_pose_release_observed"] = True
    _state["pin_history_pose_release_last_event"] = time.perf_counter()
    return changed


def _surface_contact_remove_history_pose_lock(armature_name, bone_name):
    locked = tuple(_state.get("pin_history_contact_pose_lock", ()))
    remaining = tuple(
        entry
        for entry in locked
        if (str(entry[0]), str(entry[1]))
        != (str(armature_name), str(bone_name))
    )
    if len(remaining) == len(locked):
        return False
    if remaining:
        _state["pin_history_contact_pose_lock"] = remaining
    else:
        _surface_contact_clear_history_pose_lock()
    return True


def _surface_contact_clear_history_pose_lock():
    _state["pin_history_contact_pose_lock"] = ()
    _state["pin_history_pose_lock_syncing"] = False
    _state["pin_history_pose_release_pending"] = False
    _state["pin_history_pose_release_frame"] = None
    _state["pin_history_pose_release_deadline"] = 0.0
    _state["pin_history_pose_release_last_event"] = 0.0
    _state["pin_history_pose_release_observed"] = False
