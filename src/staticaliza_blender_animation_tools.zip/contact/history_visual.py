"""Exact evaluated contact poses paired with native transform history."""

from ..core.runtime import *  # noqa: F403


def _surface_contact_history_owner_entry(entry):
    values = tuple(entry or ())
    if len(values) >= 6:
        owner_key, armature_name, bone_name, before, native_after, solved_after = values[-6:]
    elif len(values) >= 5:
        owner_key, armature_name, bone_name, before, native_after = values[-5:]
        solved_after = native_after
    else:
        raise ValueError("Invalid Contact owner history entry")
    return (
        owner_key,
        str(armature_name),
        str(bone_name),
        before,
        native_after,
        solved_after,
    )


def _surface_contact_capture_history_visuals(
    context,
    contact_starts,
    live_poses,
    native_after_poses=None,
):
    native_after_poses = native_after_poses or {}
    visuals = []
    for guide in _surface_contact_active_simulated_guides(context.scene):
        armature, pose_bone = _surface_contact_pose_bone(guide)
        if armature is None or pose_bone is None:
            continue
        pose_key = (_armature_session_uid(armature), pose_bone.name)
        start = contact_starts.get(pose_key)
        if start is None:
            continue
        native_pose = native_after_poses.get(pose_key)
        live_pose = live_poses.get(pose_key)
        visuals.append((
            (_armature_session_uid(armature), guide.name),
            armature.name,
            pose_bone.name,
            start[3].copy() if len(start) > 3 else pose_bone.matrix.copy(),
            (
                native_pose[3].copy()
                if native_pose is not None and len(native_pose) > 3
                else pose_bone.matrix.copy()
            ),
            (
                live_pose[3].copy()
                if live_pose is not None and len(live_pose) > 3
                else pose_bone.matrix.copy()
            ),
        ))
    return tuple(visuals)


def _surface_contact_restore_history_visuals(transition, restore_index):
    """Compatibility restore that keeps the authored local basis authoritative."""
    if not _surface_contact_set_history_pose_lock(transition, restore_index):
        return False
    context = bpy.context
    if context is None or getattr(context, "scene", None) is None:
        return False
    return _surface_contact_apply_history_pose_lock(
        context,
        update_view_layer=True,
    )


def _surface_contact_merge_history_pose_lock(entries, append=False):
    entries = tuple(entries)
    if append:
        merged = {
            (str(item[0]), str(item[1])): item
            for item in tuple(_state.get("pin_history_contact_pose_lock", ()))
        }
        for item in entries:
            merged[(str(item[0]), str(item[1]))] = item
        entries = tuple(merged.values())
    _state["pin_history_contact_pose_lock"] = entries
    _state["pin_history_pose_lock_relevant_pointers"] = None
    return bool(entries)


def _surface_contact_set_history_pose_lock(
    transition, restore_index, *, append=False
):
    restore_index = int(restore_index)
    visual_by_owner = {}
    for entry in transition.get("visual_poses", ()):
        _key, armature_name, bone_name, before, _native_after, solved_after = (
            _surface_contact_history_owner_entry(entry)
        )
        visual_by_owner[(armature_name, bone_name)] = (
            before if restore_index == 0 else solved_after
        ).copy()
    locked = []
    seen = set()
    for entry in transition.get("contacts", ()):
        _key, armature_name, bone_name, before, _native_after, solved_after = (
            _surface_contact_history_owner_entry(entry)
        )
        owner = (armature_name, bone_name)
        if owner in seen:
            continue
        seen.add(owner)
        locked.append((
            owner[0],
            owner[1],
            (before if restore_index == 0 else solved_after).copy(),
            visual_by_owner.get(owner),
        ))
    return _surface_contact_merge_history_pose_lock(locked, append=append)


def _surface_contact_current_history_pose_entries(
    context, owner_keys=None, *, include_detached=False
):
    owner_keys = None if owner_keys is None else set(owner_keys)
    locked = []
    for guide in _surface_contact_active_simulated_guides(context.scene):
        armature, pose_bone = _surface_contact_pose_bone(guide)
        if armature is None or pose_bone is None:
            continue
        owner_key = (_armature_session_uid(armature), guide.name)
        if owner_keys is not None and owner_key not in owner_keys:
            continue
        if (
            not include_detached
            and bool(guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False))
        ):
            continue
        locked.append((
            armature.name,
            pose_bone.name,
            pose_bone.matrix_basis.copy(),
            pose_bone.matrix.copy(),
        ))
    return tuple(locked)


def _surface_contact_set_current_history_pose_lock(
    context, owner_keys, *, include_detached=False, append=False
):
    return _surface_contact_merge_history_pose_lock(
        _surface_contact_current_history_pose_entries(
            context,
            owner_keys,
            include_detached=include_detached,
        ),
        append=append,
    )


def _surface_contact_apply_history_pose_lock(
    context, update_view_layer=False
):
    """Restore Contact's authored basis without deriving a second basis.

    ``PoseBone.matrix`` is evaluated output. Assigning it after ``matrix_basis``
    makes Blender solve a new local basis and was the source of the visible
    down-facing flicker and one-step rotation delay during Undo/Redo. The saved
    basis is authoritative; the saved visual matrix is verification only.
    """
    locked = tuple(_state.get("pin_history_contact_pose_lock", ()))
    if not locked or _state.get("pin_history_pose_lock_syncing", False):
        return False
    _state["pin_history_pose_lock_syncing"] = True
    changed = False
    try:
        resolved = []
        armatures = set()
        for armature_name, bone_name, basis, visual in locked:
            armature = bpy.data.objects.get(str(armature_name))
            pose_bone = (
                armature.pose.bones.get(str(bone_name))
                if armature is not None and getattr(armature, "pose", None)
                else None
            )
            if pose_bone is None:
                continue
            resolved.append((pose_bone, basis, visual))
            armatures.add(armature)
        if not resolved:
            return False

        for pose_bone, basis, _visual in resolved:
            if _pin_keyboard_matrices_differ(
                pose_bone.matrix_basis,
                basis,
                epsilon=1.0e-8,
            ):
                pose_bone.matrix_basis = basis.copy()
                changed = True

        if changed or update_view_layer:
            for armature in armatures:
                try:
                    armature.update_tag(refresh={"DATA"})
                except (AttributeError, ReferenceError, RuntimeError, TypeError):
                    pass
            if update_view_layer:
                context.view_layer.update()

        # One late evaluation can follow an undo handler. Reapply only the
        # authored basis; never assign the evaluated output matrix.
        late_changed = False
        for pose_bone, basis, _visual in resolved:
            if _pin_keyboard_matrices_differ(
                pose_bone.matrix_basis,
                basis,
                epsilon=1.0e-8,
            ):
                pose_bone.matrix_basis = basis.copy()
                late_changed = True
                changed = True
        if late_changed and update_view_layer:
            context.view_layer.update()
        return changed
    finally:
        _state["pin_history_pose_lock_syncing"] = False

def _surface_contact_history_lock_matches_frame(context):
    scene = getattr(context, "scene", None) if context is not None else None
    expected = _state.get("pin_history_pose_release_frame")
    return bool(
        scene is not None
        and expected
        and int(scene.as_pointer()) == int(expected[0])
        and int(scene.frame_current) == int(expected[1])
        and abs(float(scene.frame_subframe) - float(expected[2])) <= 1.0e-7
    )


def _surface_contact_history_lock_relevant_pointers():
    cached = _state.get("pin_history_pose_lock_relevant_pointers")
    if cached is not None:
        return set(cached)
    pointers = set()
    for armature_name, _bone_name, _basis, _visual in tuple(
        _state.get("pin_history_contact_pose_lock", ())
    ):
        armature = bpy.data.objects.get(str(armature_name))
        if armature is None:
            continue
        for candidate in (
            armature,
            getattr(armature, "data", None),
            getattr(getattr(armature, "animation_data", None), "action", None),
        ):
            candidate = getattr(candidate, "original", candidate)
            try:
                pointers.add(int(candidate.as_pointer()))
            except (AttributeError, ReferenceError, RuntimeError, TypeError):
                pass
    _state["pin_history_pose_lock_relevant_pointers"] = frozenset(pointers)
    return pointers


def _surface_contact_history_lock_update_relevant(depsgraph):
    relevant_pointers = _surface_contact_history_lock_relevant_pointers()
    if not relevant_pointers:
        return False
    for update in tuple(getattr(depsgraph, "updates", ())):
        updated = getattr(update, "id", None)
        updated = getattr(updated, "original", updated)
        try:
            if int(updated.as_pointer()) in relevant_pointers:
                return True
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            pass
    return False


def _surface_contact_history_pose_signature():
    signature = []
    for armature_name, bone_name, _basis, _visual in tuple(
        _state.get("pin_history_contact_pose_lock", ())
    ):
        armature = bpy.data.objects.get(str(armature_name))
        pose_bone = (
            armature.pose.bones.get(str(bone_name))
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is None:
            continue
        signature.append((
            str(armature_name),
            str(bone_name),
            tuple(
                round(float(value), 8)
                for matrix in (pose_bone.matrix_basis, pose_bone.matrix)
                for row in matrix
                for value in row
            ),
        ))
    return tuple(signature)


def _surface_contact_history_pose_release_timeout():
    if not _state.get("pin_history_pose_release_pending", False):
        return None
    context = bpy.context
    if not _surface_contact_history_lock_matches_frame(context):
        _surface_contact_clear_history_pose_lock()
        return None
    now = time.perf_counter()
    minimum_deadline = float(
        _state.get("pin_history_pose_release_minimum_deadline", 0.0)
    )
    deadline = float(_state.get("pin_history_pose_release_deadline", 0.0))
    before = _surface_contact_history_pose_signature()
    changed = _surface_contact_apply_history_pose_lock(context)
    after = _surface_contact_history_pose_signature()
    previous = _state.get("pin_history_pose_release_last_signature")
    if changed or before != after or previous != after:
        stable_ticks = 0
    else:
        stable_ticks = int(
            _state.get("pin_history_pose_release_stable_ticks", 0)
        ) + 1
    _state["pin_history_pose_release_last_signature"] = after
    _state["pin_history_pose_release_stable_ticks"] = stable_ticks
    observed = bool(_state.get("pin_history_pose_release_observed", False))
    require_update = bool(
        _state.get("pin_history_pose_release_require_update", False)
    )
    release_ready = bool(
        now >= minimum_deadline
        and stable_ticks >= 2
        and (observed or not require_update)
    )
    if now >= deadline or release_ready:
        _surface_contact_clear_history_pose_lock()
        return None
    return 0.025


def _surface_contact_begin_history_pose_release(
    context,
    *,
    minimum_duration=0.04,
    deadline_duration=0.60,
    require_update=False,
):
    if not _state.get("pin_history_contact_pose_lock", ()):
        _surface_contact_clear_history_pose_lock()
        return False
    scene = getattr(context, "scene", None) if context is not None else None
    if scene is None:
        _surface_contact_clear_history_pose_lock()
        return False
    now = time.perf_counter()
    minimum_duration = max(0.0, float(minimum_duration))
    deadline_duration = max(minimum_duration, float(deadline_duration))
    _state["pin_history_pose_release_pending"] = True
    _state["pin_history_pose_release_frame"] = (
        int(scene.as_pointer()),
        int(scene.frame_current),
        float(scene.frame_subframe),
    )
    _state["pin_history_pose_release_started"] = now
    _state["pin_history_pose_release_minimum_deadline"] = (
        now + minimum_duration
    )
    _state["pin_history_pose_release_deadline"] = now + deadline_duration
    _state["pin_history_pose_release_require_update"] = bool(require_update)
    _state["pin_history_pose_release_last_event"] = now
    _state["pin_history_pose_release_observed"] = False
    _state["pin_history_pose_release_stable_ticks"] = 0
    _state["pin_history_pose_release_last_signature"] = (
        _surface_contact_history_pose_signature()
    )
    try:
        if bpy.app.timers.is_registered(
            _surface_contact_history_pose_release_timeout
        ):
            bpy.app.timers.unregister(
                _surface_contact_history_pose_release_timeout
            )
        register_owned_timer(
            _surface_contact_history_pose_release_timeout,
            first_interval=0.025,
        )
    except (RuntimeError, ValueError):
        pass
    return True


def _surface_contact_finish_history_pose_release(context):
    if not _state.get("pin_history_pose_release_pending", False):
        return False
    if not _surface_contact_history_lock_matches_frame(context):
        _surface_contact_clear_history_pose_lock()
        return False
    changed = _surface_contact_apply_history_pose_lock(context)
    _state["pin_history_pose_release_observed"] = True
    _state["pin_history_pose_release_last_event"] = time.perf_counter()
    _state["pin_history_pose_release_stable_ticks"] = 0
    _state["pin_history_pose_release_last_signature"] = (
        _surface_contact_history_pose_signature()
    )
    return changed


def _surface_contact_remove_history_pose_lock(armature_name, bone_name):
    locked = tuple(_state.get("pin_history_contact_pose_lock", ()))
    remaining = tuple(
        entry
        for entry in locked
        if (str(entry[0]), str(entry[1]))
        != (str(armature_name), str(bone_name))
    )
    if len(remaining) == len(locked):
        return False
    if remaining:
        _surface_contact_merge_history_pose_lock(remaining)
    else:
        _surface_contact_clear_history_pose_lock()
    return True


def _surface_contact_clear_history_pose_lock():
    _state["pin_history_contact_pose_lock"] = ()
    _state["pin_history_pose_lock_syncing"] = False
    _state["pin_history_pose_lock_relevant_pointers"] = None
    _state["pin_history_pose_release_pending"] = False
    _state["pin_history_pose_release_frame"] = None
    _state["pin_history_pose_release_started"] = 0.0
    _state["pin_history_pose_release_minimum_deadline"] = 0.0
    _state["pin_history_pose_release_deadline"] = 0.0
    _state["pin_history_pose_release_require_update"] = False
    _state["pin_history_pose_release_last_event"] = 0.0
    _state["pin_history_pose_release_observed"] = False
    _state["pin_history_pose_release_stable_ticks"] = 0
    _state["pin_history_pose_release_last_signature"] = None
