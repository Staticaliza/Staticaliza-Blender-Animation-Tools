"""Surface-contact constraint synchronization and runtime handlers."""

from ..core.runtime import *  # noqa: F403

def _sync_surface_contact_constraints(
    scene,
    depsgraph = None,
    respect_selected = False,
    force_unselected = True,
    force_guide_names = (),
    solve_simulated = True,
    solve_guides = True,
    sync_dynamic_parent = True,
    solve_detached_target_motion = False,
):
    if _state.get("surface_contact_syncing", False):
        return False
    _state["surface_contact_syncing"] = True
    try:
        frame = int(getattr(scene, "frame_current", 0))
        forced_names = {str(name) for name in force_guide_names}
        changed = (
            _sync_dynamic_parent_constraints(frame)
            if sync_dynamic_parent
            else False
        )
        guides = tuple(_surface_contact_guides())
        if depsgraph is None:
            try:
                depsgraph = bpy.context.evaluated_depsgraph_get()
            except (AttributeError, RuntimeError):
                depsgraph = None
        changed = _surface_contact_sync_stretch_policy(guides, frame) or changed
        for guide in guides:
            changed = _surface_contact_update_guide_transform(guide) or changed
            target_moved = _surface_contact_target_motion_changed(
                bpy.context, guide, depsgraph
            )
            changed = (
                _surface_contact_migrate_legacy_ik_guide(bpy.context, guide)
                or changed
            )
            changed = (
                _surface_contact_ensure_control_rotation_constraint(
                    bpy.context,
                    guide,
                )
                or changed
            )
            active = _surface_contact_guide_active_at(guide, frame)
            primary, secondary = _surface_contact_constraints(guide)
            frame_snap_state = _state.setdefault(
                "pin_snap_frame_animated_states",
                {},
            ).get(_surface_contact_snap_key(guide))
            frame_snap_state_frame = _state.setdefault(
                "pin_snap_frame_animated_state_frames",
                {},
            ).get(_surface_contact_snap_key(guide))
            if (
                active
                and _surface_contact_snap_capable(guide)
                and frame_snap_state is not None
                and frame_snap_state_frame == frame
            ):
                # A keyed state is authoritative for this evaluated frame.
                # Do not let a transient anchor gap or stale runtime
                # departure detector disable Contact for one playback sample.
                detached_state = bool(frame_snap_state)
            else:
                detached_state = bool(
                    active
                    and _surface_contact_snap_capable(guide)
                    and (
                        _surface_contact_animated_detached_state(guide, frame)
                        or _surface_contact_snap_departure_active(
                            bpy.context,
                            guide,
                        )
                    )
                )
            snap_key = _surface_contact_snap_key(guide)
            pressure_supported = bool(
                active
                and not detached_state
                and _surface_contact_pressure_supported_pose(
                    bpy.context,
                    guide,
                )
            )
            pressure_states = _state.setdefault(
                "pin_snap_pressure_active", set()
            )
            if pressure_supported:
                pressure_states.add(snap_key)
            else:
                pressure_states.discard(snap_key)
            constraint_active = bool(
                active
                and not detached_state
                and not pressure_supported
            )
            desired_influences = (
                (primary, 1.0 if constraint_active else 0.0),
                (
                    secondary,
                    _surface_contact_guide_aim_influence(guide)
                    if constraint_active
                    else 0.0,
                ),
            )
            for constraint, desired in desired_influences:
                if (
                    constraint is not None
                    and abs(float(constraint.influence) - desired) > 1.0e-6
                ):
                    constraint.influence = desired
                    changed = True
            if active:
                if (
                    primary is not None
                    and primary.type == "IK"
                    and hasattr(primary, "use_stretch")
                    and bool(primary.use_stretch)
                ):
                    primary.use_stretch = False
                    changed = True
                contact_kind = str(
                    guide.get(SURFACE_CONTACT_KIND_PROPERTY, "")
                )
                detached = detached_state
                if (
                    detached
                    and solve_detached_target_motion
                    and target_moved
                    and contact_kind == SURFACE_CONTACT_KIND_SIMULATED
                    and not _surface_contact_guide_directly_selected(
                        bpy.context,
                        guide,
                    )
                ):
                    changed = (
                        _surface_contact_solve_detached_target_motion_rebased(
                            bpy.context,
                            guide,
                        )
                        or changed
                    )
                directly_selected = bool(
                    respect_selected
                    and _surface_contact_guide_directly_selected(
                        bpy.context,
                        guide,
                    )
                )
                force_contact = bool(
                    not pressure_supported
                    and (
                        guide.name in forced_names
                        or (
                            force_unselected
                            and not directly_selected
                            and not detached
                        )
                    )
                )
                if force_contact:
                    _surface_contact_clear_snap_departure(guide)
                if (
                    not detached
                    and not pressure_supported
                    and solve_guides
                    and (
                        solve_simulated
                        or contact_kind != SURFACE_CONTACT_KIND_SIMULATED
                    )
                ):
                    changed = _surface_contact_enforce_guide(
                        bpy.context,
                        guide,
                        force_contact = force_contact,
                        use_snap_hysteresis = directly_selected,
                        allow_snap = not detached,
                        rotate_detached = False,
                    ) or changed
                _target_object, owner = _surface_contact_constraint_owner_from_guide(
                    guide
                )
                changed = (
                    _surface_contact_order_constraints(owner, secondary, primary)
                    or changed
                )
        _surface_contact_seed_runtime_signatures(bpy.context, guides)
        if changed:
            _tag_redraw_all_view3d()
        return changed
    finally:
        _state["surface_contact_syncing"] = False


def _surface_contact_active_simulated_guides(scene):
    return _surface_contact_active_simulated_guides_cached(scene)


def _surface_contact_playback_batch_settle(context, guides):
    """Magnet attached contacts with cached guide resolution and one tag batch."""
    corrections = []
    inverse_by_armature = {}
    for guide in tuple(guides):
        resolved = _surface_contact_resolved_playback_guide(guide)
        if resolved is None:
            continue
        armature, pose_bone, geometry_bone, support = resolved
        target = guide.matrix_world.translation.copy()
        anchor = armature.matrix_world @ geometry_bone.matrix @ support
        delta = Vector(target) - Vector(anchor)
        tolerance = _surface_contact_settle_tolerance(guide)
        if delta.length_squared <= tolerance * tolerance:
            continue
        inverse = inverse_by_armature.get(armature)
        if inverse is None:
            inverse = armature.matrix_world.inverted_safe().to_3x3()
            inverse_by_armature[armature] = inverse
        corrections.append((armature, pose_bone, inverse @ delta))
    if not corrections:
        return False
    for _armature, pose_bone, armature_delta in corrections:
        matrix = pose_bone.matrix.copy()
        matrix.translation += armature_delta
        pose_bone.matrix = matrix
    _state["surface_contact_playback_settled_frame"] = int(
        context.scene.frame_current
    )
    for armature in inverse_by_armature:
        armature.update_tag(refresh={"DATA"})
    if not _animation_playback_active(context):
        _tag_redraw_all_view3d()
    return True



def _surface_contact_frame_settle_timer(snap_state_changed=False, guides=None):
    """Finish frame evaluation without replaying cached Contact poses."""
    context = bpy.context
    scene = getattr(context, "scene", None)
    if (
        context is None
        or scene is None
        or getattr(context, "mode", "") != "POSE"
        or _state.get("pin_history_syncing", False)
        or _state.get("pin_snap_transform_active", False)
        or _state.get("pin_target_dragging", False)
    ):
        return None
    playback_active = _animation_playback_active(context)
    try:
        # frame_change_post already runs after Blender evaluated the frame.
        # Starting another full view-layer evaluation here multiplied scrub
        # cost by every Contact before the solver had changed any data.
        # Blender's evaluated Action pose is authoritative while scrubbing
        # and playing. Only an explicitly keyed attached segment may receive
        # a contact settle; mixed attached/detached segments and unkeyed or
        # out-of-range frames must not replay cached poses or self-snap.
        _state.pop("surface_contact_frame_moved_guides", ())
        moved_guides = (
            tuple(guides)
            if guides is not None
            else _surface_contact_active_simulated_guides(scene)
        )
        if not snap_state_changed:
            attached_guides = tuple(
                guide
                for guide in moved_guides
                if _surface_contact_attached_at_frame(
                    guide,
                    int(scene.frame_current),
                )
            )
            if playback_active:
                _state["surface_contact_playback_settled_frame"] = int(
                    scene.frame_current
                )
            _surface_contact_playback_batch_settle(
                context,
                attached_guides,
            )
            if not playback_active:
                _surface_contact_seed_runtime_signatures(
                    context,
                    moved_guides,
                )
                _pin_cache_idle_transform_poses(context)
            return None
        changed = False
        for guide in moved_guides:
            attached = _surface_contact_attached_at_frame(
                guide,
                int(scene.frame_current),
            )
            if not attached:
                continue
            changed = _surface_contact_enforce_guide(
                context,
                guide,
                force_contact = True,
                allow_snap = True,
                rotate_detached = False,
                rotate_snap = False,
                # Simulated contacts need a live magnet pass during playback,
                # but one correction is enough for the already-evaluated
                # frame. The full iterative solve remains for manual edits.
                max_iterations = (
                    1
                    if playback_active and not snap_state_changed
                    else None
                ),
            ) or changed
        if changed:
            context.view_layer.update()
        if not playback_active:
            # The update above can reapply the Action's raw bone F-curves
            # after the iterative Contact solve. Finish manual scrubbing with
            # the same direct endpoint correction that keeps playback pinned,
            # and do not evaluate the view layer again afterward.
            attached_guides = tuple(
                guide
                for guide in moved_guides
                if _surface_contact_attached_at_frame(
                    guide,
                    int(scene.frame_current),
                )
            )
            changed = (
                _surface_contact_playback_batch_settle(
                    context,
                    attached_guides,
                )
                or changed
            )
            _surface_contact_seed_runtime_signatures(context, moved_guides)
            _pin_cache_idle_transform_poses(context)
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return None
    return None


def _surface_contact_target_motion_changed(context, guide, depsgraph=None):
    """Track only evaluated pink-target movement, not unrelated updates."""
    try:
        if depsgraph is None:
            depsgraph = context.evaluated_depsgraph_get()
        evaluated = guide.evaluated_get(depsgraph)
        matrix = evaluated.matrix_world
    except (AttributeError, ReferenceError, RuntimeError):
        matrix = guide.matrix_world
    signature = tuple(
        round(float(value), 7) for row in matrix for value in row
    )
    cache = _state.setdefault("surface_contact_target_signatures", {})
    key = _surface_contact_pose_cache_key(guide)
    previous = cache.get(key)
    cache[key] = signature
    return bool(previous is not None and previous != signature)


def _surface_contact_repair_attached_action_updates(context, guides):
    """Repair a keyed attached pose overwritten by a late Action evaluation."""
    if (
        context is None
        or getattr(context, "scene", None) is None
        or _state.get("surface_contact_solver_syncing", False)
    ):
        return False
    frame = int(context.scene.frame_current)
    repair = []
    for guide in tuple(guides):
        if not _surface_contact_attached_at_frame(guide, frame):
            continue
        target, _normal, anchor = _surface_contact_world_point_normal(
            context,
            guide,
        )
        if target is None or anchor is None:
            continue
        if (
            Vector(target) - Vector(anchor)
        ).length > _surface_contact_settle_tolerance(guide):
            repair.append(guide)
    if not repair:
        return False

    _state["surface_contact_solver_syncing"] = True
    try:
        # This callback exists specifically because Blender has already run a
        # late Action evaluation. The iterative solver performs another view-
        # layer evaluation and can reapply that same raw keyed pose. Correct
        # the endpoint matrices directly, as playback does, and leave them as
        # the final writes for this depsgraph pass.
        return _surface_contact_playback_batch_settle(context, repair)
    finally:
        _state["surface_contact_solver_syncing"] = False


def _surface_contact_apply_animated_snap_state(scene, guides=None):
    """Make keyed snap mode win over stale runtime state during scrubbing."""
    frame = int(getattr(scene, "frame_current", 0))
    detached = _state.setdefault("pin_snap_detached", set())
    latches = _state.setdefault("pin_snap_latches", set())
    departing = _state.setdefault("pin_snap_departing", set())
    seen = _state.setdefault("pin_snap_transform_seen", set())
    frame_states = _state.setdefault(
        "pin_snap_frame_animated_states",
        {},
    )
    frame_state_frames = _state.setdefault(
        "pin_snap_frame_animated_state_frames",
        {},
    )
    changed = False
    for guide in (
        tuple(guides)
        if guides is not None
        else _surface_contact_active_snap_guides(scene)
    ):
        animated = _surface_contact_animated_detached_state(guide, frame)
        if animated is None:
            # No animated Contact-state curve: manual edit state remains the
            # authority for this guide.
            continue
        key = _surface_contact_snap_key(guide)
        state_changed = bool(
            frame_states.get(key) != bool(animated)
            or (key in detached) != bool(animated)
            or (not animated and key not in latches)
            or (animated and key in latches)
            or key in departing
            or key in seen
            or bool(
                guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)
            ) != bool(animated)
        )
        frame_states[key] = bool(animated)
        frame_state_frames[key] = frame
        if not state_changed:
            continue
        changed = True
        departing.discard(key)
        seen.discard(key)
        _surface_contact_set_snap_detached(guide, bool(animated))
        if not animated:
            latches.add(key)
    return changed


def _surface_contact_begin_pressure_release(context, guide):
    """Make a pressure pull-out terminal and seed its immutable free pose."""
    snap_key = _surface_contact_snap_key(guide)
    try:
        armature, pose_bone = _surface_contact_pose_bone(guide)
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        # State-machine tests and partially torn-down files can retain a
        # lightweight guide without a live Blender RNA pointer. Releasing its
        # logical latch is still valid; only pose seeding is unavailable.
        armature, pose_bone = None, None
    _state.setdefault("pin_snap_pressure_active", set()).discard(snap_key)
    _state.setdefault("pin_snap_pressure_release_session", set()).add(
        snap_key
    )
    # Blender 5.2 may expose one non-zero TRANSFORM_OT_translate value and
    # then leave it unchanged for the rest of the modal drag.  Do not trust
    # that value for this release until it has actually moved away from the
    # origin captured below.
    _state.setdefault(
        "pin_snap_pressure_release_native_driven", set()
    ).discard(snap_key)
    _state.setdefault("pin_snap_collision_min_distances", {})[snap_key] = 0.0
    _state.setdefault("pin_snap_transform_releasing", set()).add(snap_key)
    _state.setdefault("pin_snap_transform_engaged", set()).discard(snap_key)
    if armature is not None and pose_bone is not None:
        _state.setdefault(
            "pin_snap_pressure_release_pose_matrices", {}
        )[snap_key] = pose_bone.matrix.copy()
        raw_pose = _state.setdefault("pin_snap_raw_pose_matrices", {}).get(
            snap_key
        )
        raw_world = armature.matrix_world @ (
            Matrix(raw_pose) if raw_pose is not None else pose_bone.matrix
        )
        _state.setdefault(
            "pin_snap_pressure_release_raw_translations", {}
        )[snap_key] = raw_world.translation.copy()
    native_translate = _pin_native_translate_vector(context)
    if native_translate is not None:
        _state.setdefault("pin_snap_pressure_release_origins", {})[
            snap_key
        ] = Vector(native_translate).copy()
    else:
        _state.setdefault("pin_snap_pressure_release_origins", {}).pop(
            snap_key,
            None,
        )
    _surface_contact_set_constraint_attachment(guide, False)
    _surface_contact_set_snap_detached(guide, True)
    _state.setdefault("pin_snap_latches", set()).discard(snap_key)
    _state.setdefault("pin_snap_swept_hits", set()).discard(snap_key)
    if pose_bone is not None:
        _surface_contact_store_valid_pose(guide)


def _surface_contact_solve_detached_target_motion(
    context,
    guide,
    *,
    resolve_collision=True,
    aim_pose=True,
):
    """One ordered detached rod/collision solve for target or bone motion."""
    changed = False
    snap_key = _surface_contact_snap_key(guide)
    hard_barrier = bool(
        snap_key
        in _state.get("pin_snap_hard_barrier_guides", set())
    )
    pressure_release = bool(
        snap_key in _state.setdefault(
            "pin_snap_pressure_release_session",
            set(),
        )
    )
    armature, pose_bone = _surface_contact_pose_bone(guide)
    target, normal, anchor = _surface_contact_world_point_normal(
        context, guide
    )
    effective_aim_pose = bool(aim_pose)
    if (
        effective_aim_pose
        and pressure_release
        and target is not None
        and normal is not None
        and anchor is not None
    ):
        pre_aim_opposite = _surface_contact_opposite_anchor_world(
            context, guide
        )
        if pre_aim_opposite is not None:
            plane_normal = Vector(normal)
            if plane_normal.length_squared > 1.0e-12:
                plane_normal.normalize()
                authored_pin_height = (
                    Vector(anchor) - Vector(target)
                ).dot(plane_normal)
                # The real pink endpoint owns magnetic intent; the opposite
                # rod endpoint owns only collision support. Suppressing aim
                # until *both* ends were clear disabled magnetism whenever a
                # released rolled limb still touched the floor/wall. Keep aim
                # off only while the authored pink pin itself is underneath.
                # The ordered two-ended collision pass below still prevents
                # the opposite endpoint from crossing the surface.
                if authored_pin_height < 0.0:
                    effective_aim_pose = False
    if (
        effective_aim_pose
        and target is not None
        and normal is not None
        and anchor is not None
    ):
        # Aim from Blender's requested pose first. Correcting collision before
        # this turn produced two visible poses per mouse/history sample and
        # made a torso-driven limb appear to stop at the side boundary. One
        # magnetic turn followed by one collision correction has one owner and
        # remains continuous through the complete rod arc.
        changed = (
            _surface_contact_aim_detached_simulated_pose(
                context,
                guide,
                preserve_current_roll=True,
            )
            or changed
        )
        aimed_anchor = _surface_contact_bone_anchor_world(
            context,
            guide,
            live_pose=True,
        )
        if aimed_anchor is not None:
            _state.setdefault(
                "pin_snap_magnetic_aim_anchor_samples",
                {},
            )[snap_key] = Vector(aimed_anchor).copy()
            if armature is not None and pose_bone is not None:
                _state.setdefault(
                    "pin_snap_magnetic_aim_pose_matrices",
                    {},
                )[snap_key] = pose_bone.matrix_basis.copy()
    target, normal, anchor = _surface_contact_world_point_normal(context, guide)
    armature, pose_bone = _surface_contact_pose_bone(guide)
    opposite = _surface_contact_opposite_anchor_world(context, guide)
    collision_needed = False
    escaping_preclipped = False
    if target is not None and normal is not None and anchor is not None:
        tolerance = (
            0.0
            if hard_barrier or pressure_release
            else _surface_contact_settle_tolerance(guide)
        )
        previous_min_distance = _state.setdefault(
            "pin_snap_collision_min_distances",
            {},
        ).get(snap_key)
        started_clipped = snap_key in _state.setdefault(
            "pin_snap_collision_started_clipped",
            set(),
        )
        # Only a limb that was already inside geometry when this transform
        # began may use an improving signed distance to escape.  Never infer
        # that privilege from a later raw cursor sample: doing so alternates
        # collision on/off after pressure roll and exposes multi-unit buried
        # poses for tiny mouse movements.  Surface-driven and pressure-release
        # paths remain strict two-ended barriers as before.
        if hard_barrier or pressure_release or not started_clipped:
            # A user-authored limb that genuinely began clipped may move
            # outward without being teleported. A pressure-roll release did
            # not begin clipped:
            # Contact put it exactly on the boundary. Letting reversal use the
            # escape exception makes both endpoints remain underneath until
            # the raw cursor pose is fully clear, producing the clip/unclip
            # teleport. Keep the released roll a strict barrier both ways.
            previous_min_distance = None
        plane_state = _surface_contact_rod_plane_state(
            target,
            normal,
            anchor,
            opposite,
            previous_min=previous_min_distance,
            tolerance=tolerance,
        )
        if plane_state is not None:
            (
                raw_min_distance,
                collision_needed,
                escaping_preclipped,
                _signed_distances,
            ) = plane_state
            _state["pin_snap_collision_min_distances"][snap_key] = (
                raw_min_distance
            )
    if (
        target is not None
        and normal is not None
        and anchor is not None
        and collision_needed
        and resolve_collision
        and not escaping_preclipped
        and opposite is not None
        and armature is not None
        and pose_bone is not None
    ):
        plane_normal = Vector(normal)
        if plane_normal.length_squared > 1.0e-12:
            plane_normal.normalize()
            # Use the earlier constant-time two-end rod solve in the drag hot
            # path. Projecting below the current limb prevents a distant pin
            # target from teleporting it, while the rod still blocks side and
            # far-end penetration and can roll bottom-up around either end.
            local_plane_target = Vector(anchor) - plane_normal * (
                (Vector(anchor) - Vector(target)).dot(plane_normal)
            )
            bone_world = armature.matrix_world @ pose_bone.matrix
            anchor_height = (
                Vector(anchor) - Vector(target)
            ).dot(plane_normal)
            opposite_height = (
                Vector(opposite) - Vector(target)
            ).dot(plane_normal)
            top_supported = bool(
                anchor_height > tolerance
                and opposite_height <= tolerance
            )
            pressure_pivot = snap_key in _state.setdefault(
                "pin_snap_pressure_pivot_active", set()
            )
            if top_supported and not pressure_release and not pressure_pivot:
                minimum_height = min(anchor_height, opposite_height)
                solved_world = Matrix(bone_world)
                if minimum_height < 0.0:
                    solved_world.translation += (
                        plane_normal * -minimum_height
                    )
            else:
                # GitHub 1.6.558 used one continuous two-ended rod projection
                # throughout released pressure. Do not alternate it with a
                # translation-only solve while dragging/reversing on the side.
                solved_world = _surface_contact_pressure_rod_world(
                    guide,
                    bone_world,
                    local_plane_target,
                    plane_normal,
                    anchor,
                    opposite,
                )
            if solved_world is not None:
                solved_changed = _set_pose_bone_constrained_output_matrix(
                    context,
                    armature,
                    pose_bone,
                    armature.matrix_world.inverted_safe() @ solved_world,
                )
                changed = solved_changed or changed
                if hard_barrier and solved_changed:
                    # The cached value is the starting condition for the next
                    # direct limb transform.  Do not leave the wall's raw
                    # penetration here after it has been resolved, otherwise a
                    # later inward limb move can be mistaken for an improving
                    # pre-clipped escape and pass through the surface.
                    _state["pin_snap_collision_min_distances"][snap_key] = 0.0
    _surface_contact_set_constraint_attachment(guide, False)
    # Publish the detached state, not only its transient runtime set entry.
    # A later depsgraph pass can otherwise see the magnetically aimed dots
    # close together and recreate a latch during the same ancestor transform.
    _surface_contact_set_snap_detached(guide, True)
    _state.setdefault("pin_snap_latches", set()).discard(snap_key)
    return changed


def _surface_contact_solve_detached_target_motion_rebased(context, guide):
    """Solve external surface motion from the authored detached limb pose."""
    # A moving contacted surface is external input. Always derive its result
    # from the user's authored pose, not the previous collision correction.
    changed = _surface_contact_restore_owner_pose_base(context, guide)
    snap_key = _surface_contact_snap_key(guide)
    hard_barriers = _state.setdefault(
        "pin_snap_hard_barrier_guides",
        set(),
    )
    hard_barriers.add(snap_key)
    try:
        return bool(
            _surface_contact_solve_detached_target_motion(context, guide)
            or changed
        )
    finally:
        hard_barriers.discard(snap_key)


def _surface_contact_pressure_rod_world(
    guide,
    bone_world,
    target,
    normal,
    anchor,
    opposite,
    *,
    allow_top_pivot=True,
):
    """Solve one continuous two-ended rod against the contact plane.

    Before the far/top endpoint reaches the plane, the pink endpoint is the
    planted pivot.  After the far endpoint crosses the plane, that endpoint
    becomes the pivot and the pink/bottom endpoint rolls upward.  This is the
    actual two-end rod rule; reflecting the far endpoint while permanently
    planting the pink endpoint produces the opposite motion.
    """
    target = Vector(target)
    normal = Vector(normal)
    anchor = Vector(anchor)
    opposite = Vector(opposite)
    if normal.length_squared <= 1.0e-12:
        return None
    normal.normalize()
    source_rod = opposite - anchor
    rod_length = source_rod.length
    if rod_length <= 1.0e-8:
        return None

    snap_key = _surface_contact_snap_key(guide)
    tangent_cache = _state.setdefault("pin_snap_pressure_tangents", {})
    raw_tangent_cache = _state.setdefault(
        "pin_snap_pressure_raw_tangents", {}
    )
    crossing_cache = _state.setdefault(
        "pin_snap_pressure_tangent_crossings", {}
    )
    pivot_active = _state.setdefault(
        "pin_snap_pressure_pivot_active", set()
    )
    # The oriented tangent cache is cleared at every transform/re-entry
    # boundary. Keep the two auxiliary caches self-synchronizing with it so
    # history/lifecycle cleanup cannot leave an old crossing candidate.
    if snap_key not in tangent_cache:
        raw_tangent_cache.pop(snap_key, None)
        crossing_cache.pop(snap_key, None)
        pivot_active.discard(snap_key)
    requested_top = opposite - target
    signed_top = requested_top.dot(normal)
    # Keep the fixed 1.6.558 pressure dead zone, with a small symmetric branch
    # epsilon so Blender 5.2 numerical noise cannot chatter at the boundary.
    pressure_threshold = (
        PIN_SNAP_WORLD_RADIUS
        * PIN_SNAP_RELEASE_PIXEL_RADIUS
        / max(1.0, PIN_SNAP_PIXEL_RADIUS)
    )
    branch_epsilon = max(
        1.0e-6,
        _surface_contact_settle_tolerance(guide) * 2.0,
    )
    pressure_was_active = bool(
        snap_key in pivot_active
        or snap_key in _state.setdefault("pin_snap_pressure_active", set())
    )
    top_pivot_active = bool(
        allow_top_pivot
        and (
            signed_top < -(pressure_threshold - branch_epsilon)
            if pressure_was_active
            else signed_top < -(pressure_threshold + branch_epsilon)
        )
    )
    tangent = requested_top - normal * signed_top
    if tangent.length_squared > 1.0e-12:
        tangent_direction = tangent.normalized()
        previous_tangent = tangent_cache.get(snap_key)
        previous_raw_tangent = raw_tangent_cache.get(snap_key)
        raw_tangent_cache[snap_key] = tangent.copy()
        crossing_committed = False
        if previous_raw_tangent is not None:
            previous_raw_tangent = Vector(previous_raw_tangent)
            if (
                previous_raw_tangent.length_squared > 1.0e-12
                and tangent_direction.dot(
                    previous_raw_tangent.normalized()
                ) < 0.0
            ):
                raw_segment = tangent - previous_raw_tangent
                crossing_factor = (
                    max(
                        0.0,
                        min(
                            1.0,
                            -previous_raw_tangent.dot(raw_segment)
                            / raw_segment.length_squared,
                        ),
                    )
                    if raw_segment.length_squared > 1.0e-12
                    else 0.0
                )
                closest_to_axis = (
                    previous_raw_tangent
                    + raw_segment * crossing_factor
                )
                if closest_to_axis.length <= branch_epsilon:
                    # Remember the new side while it is still inside the
                    # singularity dead zone. A 1e-4 numerical sign wobble
                    # must not mirror the limb, but a deliberate slow cross
                    # must be allowed to finish once it moves clear.
                    crossing_cache[snap_key] = tangent_direction.copy()
        crossing_direction = crossing_cache.get(snap_key)
        if crossing_direction is not None:
            crossing_direction = Vector(crossing_direction)
            if tangent_direction.dot(crossing_direction) < 0.0:
                crossing_cache.pop(snap_key, None)
            elif tangent.length >= pressure_threshold:
                crossing_committed = True
                crossing_cache.pop(snap_key, None)
        if previous_tangent is not None:
            previous_tangent = Vector(previous_tangent)
            previous_tangent -= normal * previous_tangent.dot(normal)
            if (
                previous_tangent.length_squared > 1.0e-12
                and tangent_direction.dot(previous_tangent) < 0.0
                and not crossing_committed
            ):
                tangent_direction.negate()
        tangent_cache[snap_key] = tangent_direction.copy()
    else:
        tangent_direction = tangent_cache.get(snap_key)
        if tangent_direction is None:
            tangent_direction = source_rod - normal * source_rod.dot(normal)
            if tangent_direction.length_squared <= 1.0e-12:
                tangent_direction = normal.orthogonal()
            tangent_direction.normalize()
            tangent_cache[snap_key] = tangent_direction.copy()
        else:
            tangent_direction = Vector(tangent_direction).normalized()

    if not top_pivot_active:
        pivot_active.discard(snap_key)
        _state.setdefault("pin_snap_pressure_active", set()).discard(snap_key)
        # Normal planted motion: the real pink endpoint stays at its pin.
        desired_bottom = target
        desired_direction = (
            tangent_direction
            if signed_top < 0.0
            else requested_top
        )
        if desired_direction.length_squared <= 1.0e-12:
            desired_direction = tangent_direction
        desired_direction.normalize()
        desired_top = desired_bottom + desired_direction * rod_length
    else:
        pivot_active.add(snap_key)
        _state.setdefault("pin_snap_pressure_active", set()).add(snap_key)
        # The imaginary top has reached the surface and is now the pivot.
        # Preserve continuity at the fixed dead-zone boundary while using the
        # same top-pivot rod geometry as 1.6.558.
        desired_top = target + tangent_direction * rod_length
        pressure_depth = max(0.0, -signed_top - pressure_threshold)
        bottom_direction = (
            -tangent_direction * tangent.length
            + normal * pressure_depth
        )
        if bottom_direction.length_squared <= 1.0e-12:
            bottom_direction = normal
        bottom_direction.normalize()
        desired_bottom = desired_top + bottom_direction * rod_length

    desired_rod = desired_top - desired_bottom
    if desired_rod.length_squared <= 1.0e-12:
        return None
    rotation = source_rod.normalized().rotation_difference(
        desired_rod.normalized()
    )
    solved_world = (
        Matrix.Translation(anchor)
        @ rotation.to_matrix().to_4x4()
        @ Matrix.Translation(-anchor)
        @ Matrix(bone_world)
    )
    solved_anchor = solved_world @ (Matrix(bone_world).inverted_safe() @ anchor)
    solved_world.translation += desired_bottom - solved_anchor
    return solved_world


def _surface_contact_solve_attached_rod_motion(
    context,
    guide,
    *,
    allow_top_pivot=True,
):
    """Keep attachment while either end of its collision rod pivots."""
    armature, pose_bone = _surface_contact_pose_bone(guide)
    target, normal, anchor = _surface_contact_world_point_normal(
        context, guide
    )
    opposite = _surface_contact_opposite_anchor_world(context, guide)
    if (
        armature is None
        or pose_bone is None
        or target is None
        or normal is None
        or anchor is None
        or opposite is None
    ):
        return None
    snap_key = _surface_contact_snap_key(guide)
    proximity_engaged = bool(
        snap_key in _state.setdefault("pin_snap_proximity_engaged", set())
    )
    newly_engaged = bool(
        snap_key in _state.setdefault("pin_snap_transform_engaged", set())
    )
    if newly_engaged and not proximity_engaged:
        # A normal steep approach can already put the far endpoint beyond the
        # plane when it snaps. Hold only that ordinary entry for one raw
        # sample. Pressure-release proximity has already passed collision and
        # approach-direction checks, so holding it only freezes rotation.
        engage_anchor = _state.setdefault(
            "pin_snap_engage_anchor_origins", {}
        ).get(snap_key)
        raw_anchor = _state.setdefault(
            "pin_snap_raw_anchor_samples", {}
        ).get(snap_key)
        if (
            engage_anchor is None
            or raw_anchor is None
            or (Vector(raw_anchor) - Vector(engage_anchor)).length
            <= max(
                1.0e-6,
                _surface_contact_settle_tolerance(guide),
            )
        ):
            allow_top_pivot = False
    _state.setdefault("pin_snap_proximity_engaged", set()).discard(snap_key)
    bone_world = armature.matrix_world @ pose_bone.matrix
    solved_world = _surface_contact_pressure_rod_world(
        guide,
        bone_world,
        target,
        normal,
        anchor,
        opposite,
        allow_top_pivot=allow_top_pivot,
    )
    if solved_world is None:
        return None
    # Contact pressure is a hard two-ended plane barrier. Remove even the
    # tiny numerical penetration that Blender's general settle tolerance
    # permits; otherwise deep rolls expose a narrow clipped pose and appear
    # to fight between the upper and lower solution.
    plane_normal = Vector(normal).normalized()
    bone_inverse = Matrix(bone_world).inverted_safe()
    solved_anchor = solved_world @ (bone_inverse @ Vector(anchor))
    solved_opposite = solved_world @ (bone_inverse @ Vector(opposite))
    minimum_height = min(
        (Vector(solved_anchor) - Vector(target)).dot(plane_normal),
        (Vector(solved_opposite) - Vector(target)).dot(plane_normal),
    )
    if minimum_height < 0.0:
        solved_world.translation += plane_normal * -minimum_height
    changed = _set_pose_bone_constrained_output_matrix(
        context,
        armature,
        pose_bone,
        armature.matrix_world.inverted_safe() @ solved_world,
    )
    # A pressure/top-pivot solve transfers surface support between the two rod
    # endpoints, but it does not express user intent to detach the socket.
    # Publishing a detach merely because the solved real endpoint moved away
    # caused a detach/aim/reattach loop and made reversal alternate above and
    # below the surface. Direct raw pull-out arbitration owns release instead.
    pressure_active = snap_key in _state.setdefault(
        "pin_snap_pressure_active", set()
    )
    solved_anchor = _surface_contact_bone_anchor_world(
        context,
        guide,
        live_pose=True,
    )
    pressure_release_world = (
        PIN_SNAP_WORLD_RADIUS
        * PIN_SNAP_RELEASE_PIXEL_RADIUS
        / max(1.0, PIN_SNAP_PIXEL_RADIUS)
    )
    if (
        pressure_active
        and solved_anchor is not None
        and (Vector(solved_anchor) - Vector(target)).length
        > pressure_release_world
    ):
        # Once the real pink dot has rolled outside the entry radius, the far
        # endpoint may remain a collision support but it is no longer a snap.
        # Make that release terminal for this drag so the magnetic pass cannot
        # recreate an illegal outer ring on the next dependency update.
        _state.setdefault(
            "pin_snap_pressure_terminal_departures", set()
        ).add(snap_key)
        _surface_contact_begin_pressure_release(context, guide)
        return changed
    _surface_contact_set_snap_detached(guide, False)
    # While the far endpoint supports the rod, this one-pass solver—not the
    # bottom-pin IK constraint—owns the pose. Keeping IK enabled here makes a
    # dependency update pull the bottom back to the socket between mouse
    # samples, producing the above/below flicker. The logical latch remains
    # attached and IK is restored as soon as reversal returns to bottom pivot.
    _surface_contact_set_constraint_attachment(
        guide,
        not pressure_active,
    )
    _state.setdefault("pin_snap_detached", set()).discard(snap_key)
    _state.setdefault("pin_snap_latches", set()).add(snap_key)
    _state.setdefault("pin_snap_transform_releasing", set()).discard(
        snap_key
    )
    _state.setdefault("pin_snap_pressure_release_session", set()).discard(
        snap_key
    )
    # Release direction follows the last planted rod pose. Keeping only the
    # direction captured at mouse-down makes a wide ball-joint roll look like
    # an outward pull once the rod has turned far enough.
    planted_axis = _surface_contact_bone_axis_world(
        context,
        guide,
        live_pose=True,
    )
    if planted_axis is not None:
        planted_direction = (
            Vector(planted_axis[0]) - Vector(planted_axis[1])
        )
        if planted_direction.length_squared > 1.0e-12:
            _state.setdefault(
                "pin_snap_grip_directions", {}
            )[snap_key] = planted_direction.normalized()
    _surface_contact_store_valid_pose(guide)
    return changed


def _surface_contact_active_snap_guides(scene):
    frame = int(getattr(scene, "frame_current", 0))
    return tuple(
        guide
        for guide in _surface_contact_guides()
        if (
            _surface_contact_snap_capable(guide)
            and _surface_contact_guide_active_at(guide, frame)
        )
    )


def _surface_contact_guide_directly_selected(context, guide):
    if (
        _state.get("pin_snap_transform_active", False)
        and guide.name in _state.get("pin_snap_direct_transform_guides", set())
    ):
        return True
    if context is None or getattr(context, "mode", "") != "POSE":
        return False
    armature = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
    )
    if _pin_selected_target_key() == (
        f"CONTACT:{_armature_session_uid(armature)}:"
        f"{getattr(guide, 'name', '')}"
    ):
        return True
    if (
        armature is None
        or armature.name
        != str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
    ):
        return False
    selected_names = {
        pose_bone.name
        for pose_bone in _selected_pose_bones_by_owner(context).get(
            armature,
            (),
        )
    }
    return bool(
        selected_names
        and _surface_contact_related_bone_names(guide) & selected_names
    )


def _surface_contact_transform_signature(context, guide, depsgraph = None):
    del context, depsgraph
    matrix_values = tuple(
        round(float(value), 7)
        for row in guide.matrix_world
        for value in row
    )
    armature, pose_bone = _surface_contact_pose_bone(guide)
    pose_values = ()
    if armature is not None and pose_bone is not None:
        pose_values = tuple(
            round(float(value), 7)
            for matrix in (
                armature.matrix_world,
                pose_bone.matrix_basis,
                pose_bone.matrix,
            )
            for row in matrix
            for value in row
        )
    property_values = []
    for property_name in (
        SURFACE_CONTACT_POINT_PROPERTY,
        SURFACE_CONTACT_NORMAL_PROPERTY,
        SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY,
    ):
        value = guide.get(property_name)
        if value is None:
            property_values.append(None)
            continue
        try:
            property_values.extend(
                round(float(component), 7) for component in value
            )
        except (TypeError, ValueError):
            property_values.append(str(value))
    return matrix_values + pose_values + tuple(property_values)


def _surface_contact_seed_runtime_signatures(context, guides = None):
    if context is None or getattr(context, "scene", None) is None:
        return False
    prune_all_caches = guides is None
    depsgraph = context.evaluated_depsgraph_get()
    signatures = _state.setdefault("surface_contact_transform_signatures", {})
    target_signatures = _state.setdefault(
        "surface_contact_target_signatures", {}
    )
    live_keys = set()
    for guide in tuple(guides if guides is not None else _surface_contact_guides()):
        key = _surface_contact_pose_cache_key(guide)
        live_keys.add(key)
        signatures[key] = _surface_contact_transform_signature(
            context,
            guide,
            depsgraph,
        )
        try:
            evaluated_guide = guide.evaluated_get(depsgraph)
            target_matrix = evaluated_guide.matrix_world
        except (AttributeError, ReferenceError, RuntimeError):
            target_matrix = guide.matrix_world
        target_signatures[key] = tuple(
            round(float(value), 7)
            for row in target_matrix
            for value in row
        )
    if prune_all_caches:
        for key in tuple(signatures):
            if key not in live_keys:
                signatures.pop(key, None)
        for key in tuple(target_signatures):
            if key not in live_keys:
                target_signatures.pop(key, None)
        for cache_name in (
            "surface_contact_valid_poses",
            "surface_contact_owner_pose_bases",
            "surface_contact_rotation_axes",
        ):
            cache = _state.setdefault(cache_name, {})
            for key in tuple(cache):
                if key not in live_keys:
                    cache.pop(key, None)
    return bool(live_keys)


def _surface_contact_runtime_signatures_changed(context, guides, depsgraph):
    signatures = _state.setdefault("surface_contact_transform_signatures", {})
    changed = []
    for guide in guides:
        key = _surface_contact_pose_cache_key(guide)
        current = _surface_contact_transform_signature(context, guide, depsgraph)
        previous = signatures.get(key)
        signatures[key] = current
        if previous is not None and previous != current:
            changed.append(guide)
    return tuple(changed)


def _surface_contact_depsgraph_update_is_relevant(guides, depsgraph):
    if not guides or depsgraph is None:
        return ()
    guides_by_owner_pointer = _surface_contact_depsgraph_guide_index_for(
        guides
    )
    try:
        updates = tuple(depsgraph.updates)
    except (AttributeError, ReferenceError, RuntimeError):
        return ()
    changed_candidates = []
    seen_guides = set()
    for update in updates:
        updated_id = getattr(update, "id", None)
        updated_id = getattr(updated_id, "original", updated_id)
        try:
            pointer = int(updated_id.as_pointer())
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            continue
        for guide in guides_by_owner_pointer.get(pointer, ()):
            try:
                guide_pointer = int(guide.as_pointer())
            except (ReferenceError, RuntimeError):
                continue
            if guide_pointer in seen_guides:
                continue
            seen_guides.add(guide_pointer)
            changed_candidates.append(guide)
    if not changed_candidates:
        return ()
    return _surface_contact_runtime_signatures_changed(
        bpy.context,
        tuple(changed_candidates),
        depsgraph,
    )



def _surface_contact_finalize_native_transform(context):
    """Commit or cancel contact-owned native-transform poses before redraw."""
    if not _state.get("pin_snap_transform_active", False):
        return False
    previous_guard = bool(_state.get("surface_contact_reconciling", False))
    _state["surface_contact_reconciling"] = True
    transform_changed = False
    try:
        # Blender restores the selected pose before removing a cancelled
        # native G/R/S operator. Preview dirtiness and a temporary release
        # flag therefore cannot decide confirmation: doing so recommits the
        # last pink preview after Right Click/Esc. The settled selected pose
        # is authoritative. A real release or ball-joint move leaves that pose
        # changed; a cancellation restores it exactly.
        transform_changed = bool(
            _pin_transform_pose_differs_from_start(context)
        )
        if transform_changed:
            # Blender can remove its G/R/S modal operator after applying one
            # last raw pose sample but before depsgraph observed that sample.
            # Solve that exact current pose now. Never restore the preceding
            # live cache: doing so is the apply-time teleport back to snap.
            current_signature = _pin_selected_pose_input_signature(context)
            if current_signature != _state.get(
                "pin_snap_last_solved_pose_signature"
            ):
                try:
                    _pin_process_native_transform_sample(
                        context,
                        _state.get(
                            "pin_snap_transform_operator",
                            "TRANSFORM_OT_translate",
                        ),
                    )
                except (
                    AttributeError,
                    ReferenceError,
                    RuntimeError,
                    TypeError,
                    ValueError,
                ) as exc:
                    print(
                        "[Roblox Animator Utils] Final Contact sample "
                        f"kept raw after solve failure: {exc}"
                    )
            _pin_native_group_finish(context)
        else:
            _pin_restore_transform_start_poses(context)
            _surface_contact_restore_transform_start_poses(context)
            _surface_contact_restore_transform_attachment_states(context)
            _pin_native_group_cancel(context)
        has_live_preview = bool(
            _state.get("pin_snap_live_pose_matrices", {})
        )
        if transform_changed and not has_live_preview:
            _state.pop("pin_snap_transform_dirty", False)
            _snap_selected_pin_endpoints(
                context,
                insert_keys=False,
                use_snap_hysteresis=True,
            )
        _pin_restore_contact_target_locks()
        if transform_changed:
            # Blender closes the armature G/R/S transaction by restoring
            # non-armature ID properties to their pre-modal values. Reassert
            # the snap result recorded by the last solved sample before
            # departure finalization/history capture; otherwise an endpoint
            # can be exactly on its pin while the guide property and ring
            # silently revert to detached a few milliseconds after Apply.
            _pin_reassert_live_contact_states()
            # Blender's Redo replays the raw native G/R/S result. The direct
            # sample capture retains that raw basis while the current pose is
            # already the one authoritative solved output.
            _surface_contact_capture_native_history_after(context)
            _surface_contact_finalize_snap_departures(context)
            # Capture Action keys after Auto Key and the final attachment state.
            # The resulting transition is still paired to Blender's one native
            # transform step and does not create a custom selection step.
            _surface_contact_record_native_transform_history(context)
        return transform_changed
    finally:
        final_contact_states = (
            _pin_current_contact_state_snapshot()
            if transform_changed
            else ()
        )
        _state["pin_snap_transform_dirty"] = False
        _pin_clear_transform_state()
        _state["surface_contact_reconciling"] = previous_guard
        # Seed from the fully committed pose. Otherwise the next Action
        # update for an unrelated bone sees the just-edited pink pose as a
        # new signature delta and wakes Contact one operation late.
        context.view_layer.update()
        # The final evaluation can restore non-armature guide properties from
        # Blender's pre-modal state after transform cleanup. Reapply the small
        # stable-name snapshot without another dependency-graph evaluation so
        # Apply has one visible/state result and the outer ring cannot flip a
        # few milliseconds later.
        _pin_reassert_live_contact_states(final_contact_states)
        if transform_changed:
            # History was paired while the modal operator still exposed its
            # raw result.  Store the authoritative after-side only now, after
            # Blender has completed the final parent/constraint evaluation.
            _surface_contact_refresh_recorded_history_after(context)
        _surface_contact_seed_runtime_signatures(context)
        _pin_cache_idle_transform_poses(context)


def _surface_contact_enforce_active_simulated(
    context,
    scene,
    guides = None,
    respect_selected = False,
):
    if (
        context is None
        or scene is None
        or _state.get("surface_contact_solver_syncing", False)
        or _state.get("surface_contact_syncing", False)
    ):
        return False
    guides = tuple(
        guides
        if guides is not None
        else _surface_contact_active_simulated_guides(scene)
    )
    if not guides:
        return False

    _state["surface_contact_solver_syncing"] = True
    changed = False
    try:
        for guide in guides:
            changed = _surface_contact_update_guide_transform(guide) or changed
            directly_selected = bool(
                respect_selected
                and _surface_contact_guide_directly_selected(context, guide)
            )
            detached = bool(
                _surface_contact_snap_departure_active(context, guide)
            )
            if detached:
                changed = (
                    _surface_contact_set_constraint_attachment(guide, False)
                    or changed
                )
                continue
            changed = _surface_contact_enforce_guide(
                context,
                guide,
                force_contact = not directly_selected and not detached,
                use_snap_hysteresis = directly_selected,
                allow_snap = not detached,
                rotate_detached = False,
                # Indirect parent/torso motion carries the contact's
                # authored orientation offset; only a direct pin edit
                # may re-aim the limb.
                rotate_snap = directly_selected,
            ) or changed
        _surface_contact_seed_runtime_signatures(context, guides)
        if changed:
            _tag_redraw_all_view3d()
        return changed
    finally:
        _state["surface_contact_solver_syncing"] = False


@persistent
def _surface_contact_frame_change_post(scene, _depsgraph = None):
    context = bpy.context
    if _state.get("pin_history_pose_release_pending", False):
        if _surface_contact_history_lock_matches_frame(context):
            _surface_contact_finish_history_pose_release(context)
            return None
        _surface_contact_clear_history_pose_lock()
    if (
        _state.get("surface_contact_load_restoring", False)
        or _state.get("surface_contact_creation_active", False)
        or _state.get("pin_history_active", False)
        or _state.get("pin_history_syncing", False)
    ):
        return None
    frame = int(getattr(scene, "frame_current", 0))
    scene_key = int(scene.as_pointer())
    last_frames = _state.setdefault("surface_contact_last_frames", {})
    previous_frame = last_frames.get(scene_key)
    last_frames[scene_key] = frame
    active_guides = _surface_contact_active_simulated_guides(scene)
    if not active_guides:
        return None
    pin_interaction_active = bool(
        _state.get("pin_snap_transform_active", False)
        or _state.get("pin_keyboard_transform_active", False)
        or _state.get("pin_target_dragging", False)
    )
    pin_modal_active = bool(_pin_active_transform_operator(context))
    if not pin_modal_active:
        window = getattr(context, "window", None)
        try:
            pin_modal_active = any(
                "transform_selected_pin"
                in str(getattr(operator, "bl_idname", "")).lower()
                for operator in tuple(getattr(window, "modal_operators", ()))
            )
        except (AttributeError, ReferenceError, RuntimeError):
            pin_modal_active = False
    if pin_interaction_active:
        if (
            previous_frame is None
            or int(previous_frame) == frame
            or pin_modal_active
        ):
            return None
        # A real timeline frame change supersedes custom/native pin ownership
        # after its modal operator has ended. Clear every interaction flag so
        # both keyed Contact state and its outer ring become authoritative.
        _state["pin_target_dragging"] = False
        _state["pin_keyboard_transform_active"] = False
        _state["pin_transform_from_gizmo"] = False
        _state.pop("pin_target_drag_references", None)
        _pin_clear_transform_state()
    if previous_frame is None:
        # A cold load can evaluate the Action after restoring Contact state.
        # Repair only an already-attached endpoint here; never run the full
        # solver or create a new snap during the synthetic first callback.
        attached_guides = tuple(
            guide
            for guide in active_guides
            if _surface_contact_attached_at_frame(guide, frame)
        )
        _surface_contact_playback_batch_settle(context, attached_guides)
        return None
    # Frame changes are the one place where keyed detach state supersedes the
    # current-frame runtime latch. Same-frame depsgraph and ancestor updates
    # must never clear a manual detach.
    playback_active = _animation_playback_active(context)
    if not playback_active:
        _surface_contact_restore_snap_detached(
            context,
            infer_missing=False,
            reset_runtime=True,
        )
    snap_state_changed = _surface_contact_apply_animated_snap_state(
        scene,
        guides=active_guides,
    )
    if int(previous_frame) == frame and not snap_state_changed:
        # Blender may evaluate the same scrubbed frame twice. The later pass
        # can restore raw Action matrices after the first Contact solve. Keep
        # this path translation-only and latch-gated so it repairs an existing
        # attachment without running collision/rotation work or self-snapping.
        same_frame_guides = active_guides
        attached_guides = tuple(
            guide
            for guide in same_frame_guides
            if _surface_contact_attached_at_frame(guide, frame)
        )
        _surface_contact_playback_batch_settle(context, attached_guides)
        return None
    _state["surface_contact_frame_settle_frame"] = frame
    # During playback the keyed state only needs a constraint sync when the
    # state changes. Re-running the complete guide walk on every frame creates
    # a startup hitch and steadily reduces playback FPS.
    if playback_active and not snap_state_changed:
        # The constraint state is unchanged, but the evaluated guide and limb
        # transforms are not. Run the focused attached-contact settle so two
        # attached keys remain magnetized throughout their interpolated span.
        _surface_contact_frame_settle_timer(
            snap_state_changed=False,
            guides=active_guides,
        )
        return None
    if playback_active:
        _state["surface_contact_frame_moved_guides"] = ()
    else:
        _state["surface_contact_frame_moved_guides"] = tuple(
            guide.name
            for guide in active_guides
            if _surface_contact_target_motion_changed(
                context, guide, _depsgraph
            )
        )
    _sync_surface_contact_constraints(
        scene,
        _depsgraph,
        sync_dynamic_parent = False,
        solve_guides = False,
        solve_detached_target_motion = False,
    )
    if playback_active and snap_state_changed:
        # Constraint influence changes made at a keyed boundary need one
        # immediate evaluated update. Without this, returning from a detached
        # key leaves the previous free pose visible until a later redraw.
        context.view_layer.update()
        attached_guides = tuple(
            guide
            for guide in active_guides
            if _surface_contact_attached_at_frame(guide, frame)
        )
        _surface_contact_playback_batch_settle(context, attached_guides)
        return None
    # Finish the keyed attached solve in this frame callback. Deferring it to
    # a timer exposed one stale evaluated sample while manually scrubbing.
    _surface_contact_frame_settle_timer(
        snap_state_changed = snap_state_changed,
        guides = active_guides,
    )


def _surface_contact_supersede_history_for_transform(transform_operator):
    """Release a completed history lock as soon as a new G/R/S owns input."""
    if (
        not transform_operator
        or _state.get("pin_history_syncing", False)
        or not (
            _state.get("pin_history_active", False)
            or _state.get("pin_history_pose_release_pending", False)
        )
    ):
        return False
    _state["pin_history_active"] = False
    _surface_contact_clear_history_pose_lock()
    try:
        if bpy.app.timers.is_registered(_clear_pin_history_visibility):
            bpy.app.timers.unregister(_clear_pin_history_visibility)
    except (ReferenceError, RuntimeError, ValueError):
        pass
    _state.setdefault("owned_timers", set()).discard(
        _clear_pin_history_visibility
    )
    return True


@persistent
def _surface_contact_depsgraph_update_post(scene, depsgraph):
    if _state.get("pin_selection_syncing", False):
        return None
    context = bpy.context
    if (
        context is not None
        and getattr(context, "scene", None) == scene
        and getattr(context, "mode", "") == "POSE"
        and not _state.get("pin_history_active", False)
        and _animation_playback_active(context)
        and int(_state.get("surface_contact_playback_settled_frame", -1))
        == int(scene.frame_current)
    ):
        return None
    transform_operator = (
        _pin_active_transform_operator(context)
        if (
            context is not None
            and getattr(context, "scene", None) == scene
            and getattr(context, "mode", "") == "POSE"
        )
        else None
    )
    # A new modal transform is newer authority than Undo's short-lived late
    # evaluation lock. Release it before either history branch can consume the
    # first parent-movement sample and leave the contacted child frozen.
    _surface_contact_supersede_history_for_transform(transform_operator)
    if (
        context is not None
        and getattr(context, "scene", None) == scene
        and _state.get("pin_history_pose_release_pending", False)
    ):
        if not _surface_contact_history_lock_matches_frame(context):
            _surface_contact_clear_history_pose_lock()
        elif _surface_contact_history_lock_update_relevant(depsgraph):
            _surface_contact_finish_history_pose_release(context)
            return None
    if (
        context is not None
        and getattr(context, "scene", None) == scene
        and getattr(context, "mode", "") == "POSE"
        and _state.get("pin_history_active", False)
    ):
        # Redo can evaluate the selected parent's Action once more after
        # redo_post. Keep its indirectly solved pink children on the exact
        # paired history side before that dependency pass reaches a redraw.
        _surface_contact_apply_history_pose_lock(context)
        return None
    if (
        context is None
        or getattr(context, "scene", None) != scene
        or getattr(context, "mode", "") != "POSE"
        or _state.get("pin_target_dragging", False)
        or _state.get("pin_snap_syncing", False)
        or _state.get("pin_history_syncing", False)
        or _state.get("surface_contact_creation_active", False)
        or _state.get("surface_contact_load_restoring", False)
        or time.perf_counter()
        < float(_state.get("surface_contact_registration_guard_until", 0.0))
        or _state.get("surface_contact_solver_syncing", False)
        or _state.get("surface_contact_reconciling", False)
        or _state.get("dynamic_space_reconciling", False)
    ):
        return None
    if transform_operator or _state.get("pin_snap_transform_active", False):
        if transform_operator:
            _pin_track_transform(transform_operator)
            if _state.get("pin_snap_transform_initializing", False):
                # A view-layer evaluation during capture recursively entered
                # this handler. The outer callback owns the first complete
                # sample once every baseline/attachment snapshot is ready.
                return None
            # Solve in the depsgraph callback that observed Blender's native
            # gizmo sample. Deferring this to the 60 Hz timer exposes the raw
            # unconstrained pose for a redraw, producing contact escape
            # flicker between otherwise-correct solver results.
            try:
                _pin_process_native_transform_sample(
                    context,
                    transform_operator,
                )
                _state["pin_snap_depsgraph_observed"] = True
                _state["pin_snap_transform_dirty"] = False
                _state["pin_snap_last_depsgraph_sync"] = time.perf_counter()
            except (
                AttributeError,
                ReferenceError,
                RuntimeError,
                TypeError,
                ValueError,
            ) as exc:
                _state["pin_snap_transform_dirty"] = True
                print(
                    "[Roblox Animator Utils] Immediate pin snap skipped: "
                    f"{exc}"
                )
        else:
            # The native operator has already left Blender's modal stack, so
            # this post-update is the last pre-redraw commit boundary. Finish
            # even when the timer, rather than this handler, observed the live
            # samples; deferring that case exposed the raw pose for a frame.
            _surface_contact_finalize_native_transform(context)
        return None

    selection_history_guard_until = float(_state.get(
        "surface_contact_selection_history_guard_until",
        0.0,
    ))
    if time.perf_counter() < selection_history_guard_until:
        # A selection-only undo/redo may dirty the owner's Action even though
        # Blender has restored no transform. Let that native history refresh
        # finish without treating it as a new Contact solve.
        _pin_cache_idle_transform_poses(context)
        return None
    _state.pop("surface_contact_selection_history_guard_until", None)

    guides = _surface_contact_active_simulated_guides(scene)
    changed_guides = _surface_contact_depsgraph_update_is_relevant(
        guides,
        depsgraph,
    )
    if changed_guides:
        # Action updates include key insertion/deletion and intermediate
        # interpolation refreshes. They are not a user Contact transform and
        # must never replay a cached/previous pink pose over Blender's newly
        # evaluated result. Frame changes are settled synchronously by the
        # frame-change handler; explicit G/R/S and pin drags own their solves.
        _surface_contact_repair_attached_action_updates(
            context,
            changed_guides,
        )
        _surface_contact_seed_runtime_signatures(context, changed_guides)
    _pin_cache_idle_transform_poses(context)
    return None
