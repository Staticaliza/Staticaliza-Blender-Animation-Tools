"""Surface-contact constraint synchronization and runtime handlers."""

from ..core.runtime import *  # noqa: F403

def _sync_surface_contact_constraints(
    scene,
    depsgraph = None,
    respect_selected = False,
    force_unselected = True,
    force_guide_names = (),
    solve_simulated = True,
    solve_guides = True,
    sync_dynamic_parent = True,
    solve_detached_target_motion = False,
):
    if _state.get("surface_contact_syncing", False):
        return False
    _state["surface_contact_syncing"] = True
    try:
        frame = int(getattr(scene, "frame_current", 0))
        forced_names = {str(name) for name in force_guide_names}
        changed = (
            _sync_dynamic_parent_constraints(frame)
            if sync_dynamic_parent
            else False
        )
        guides = tuple(_surface_contact_guides())
        changed = _surface_contact_sync_stretch_policy(guides, frame) or changed
        for guide in guides:
            changed = _surface_contact_update_guide_transform(guide) or changed
            target_moved = _surface_contact_target_motion_changed(
                bpy.context, guide
            )
            changed = (
                _surface_contact_migrate_legacy_ik_guide(bpy.context, guide)
                or changed
            )
            changed = (
                _surface_contact_ensure_control_rotation_constraint(
                    bpy.context,
                    guide,
                )
                or changed
            )
            active = _surface_contact_guide_active_at(guide, frame)
            primary, secondary = _surface_contact_constraints(guide)
            detached_state = bool(
                active
                and _surface_contact_snap_capable(guide)
                and (
                    _surface_contact_animated_detached_state(guide, frame)
                    or _surface_contact_snap_departure_active(
                        bpy.context,
                        guide,
                    )
                )
            )
            constraint_active = bool(active and not detached_state)
            desired_influences = (
                (primary, 1.0 if constraint_active else 0.0),
                (
                    secondary,
                    _surface_contact_guide_aim_influence(guide)
                    if constraint_active
                    else 0.0,
                ),
            )
            for constraint, desired in desired_influences:
                if (
                    constraint is not None
                    and abs(float(constraint.influence) - desired) > 1.0e-6
                ):
                    constraint.influence = desired
                    changed = True
            if active:
                if (
                    primary is not None
                    and primary.type == "IK"
                    and hasattr(primary, "use_stretch")
                    and bool(primary.use_stretch)
                ):
                    primary.use_stretch = False
                    changed = True
                contact_kind = str(
                    guide.get(SURFACE_CONTACT_KIND_PROPERTY, "")
                )
                detached = detached_state
                if (
                    detached
                    and solve_detached_target_motion
                    and target_moved
                    and contact_kind == SURFACE_CONTACT_KIND_SIMULATED
                ):
                    changed = (
                        _surface_contact_solve_detached_target_motion(
                            bpy.context, guide
                        )
                        or changed
                    )
                directly_selected = bool(
                    respect_selected
                    and _surface_contact_guide_directly_selected(
                        bpy.context,
                        guide,
                    )
                )
                force_contact = bool(
                    guide.name in forced_names
                    or (
                        force_unselected
                        and not directly_selected
                        and not detached
                    )
                )
                if force_contact:
                    _surface_contact_clear_snap_departure(guide)
                if (
                    not detached
                    and solve_guides
                    and (
                        solve_simulated
                        or contact_kind != SURFACE_CONTACT_KIND_SIMULATED
                    )
                ):
                    changed = _surface_contact_enforce_guide(
                        bpy.context,
                        guide,
                        force_contact = force_contact,
                        use_snap_hysteresis = directly_selected,
                        allow_snap = not detached,
                        rotate_detached = False,
                    ) or changed
                _target_object, owner = _surface_contact_constraint_owner_from_guide(
                    guide
                )
                changed = (
                    _surface_contact_order_constraints(owner, secondary, primary)
                    or changed
                )
        _surface_contact_seed_runtime_signatures(bpy.context, guides)
        if changed:
            _tag_redraw_all_view3d()
        return changed
    finally:
        _state["surface_contact_syncing"] = False


def _surface_contact_active_simulated_guides(scene):
    frame = int(getattr(scene, "frame_current", 0))
    return tuple(
        guide
        for guide in _surface_contact_guides()
        if (
            str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
            == SURFACE_CONTACT_KIND_SIMULATED
            and _surface_contact_guide_active_at(guide, frame)
        )
    )


def _surface_contact_target_motion_changed(context, guide):
    """Track only evaluated pink-target movement, not unrelated updates."""
    try:
        evaluated = guide.evaluated_get(context.evaluated_depsgraph_get())
        matrix = evaluated.matrix_world
    except (AttributeError, ReferenceError, RuntimeError):
        matrix = guide.matrix_world
    signature = tuple(
        round(float(value), 7) for row in matrix for value in row
    )
    cache = _state.setdefault("surface_contact_target_signatures", {})
    key = _surface_contact_pose_cache_key(guide)
    previous = cache.get(key)
    cache[key] = signature
    return bool(previous is not None and previous != signature)


def _surface_contact_solve_detached_target_motion(context, guide):
    """One ordered detached rod/collision solve for target or bone motion."""
    changed = False
    snap_key = _surface_contact_snap_key(guide)
    armature, pose_bone = _surface_contact_pose_bone(guide)
    target, normal, anchor = _surface_contact_world_point_normal(
        context, guide
    )
    if (
        target is not None
        and normal is not None
        and anchor is not None
    ):
        # Aim from Blender's requested pose first. Correcting collision before
        # this turn produced two visible poses per mouse/history sample and
        # made a torso-driven limb appear to stop at the side boundary. One
        # magnetic turn followed by one collision correction has one owner and
        # remains continuous through the complete rod arc.
        changed = (
            _surface_contact_aim_detached_simulated_pose(
                context,
                guide,
                preserve_current_roll=True,
            )
            or changed
        )
    target, normal, anchor = _surface_contact_world_point_normal(context, guide)
    armature, pose_bone = _surface_contact_pose_bone(guide)
    opposite = _surface_contact_opposite_anchor_world(context, guide)
    collision_needed = False
    if target is not None and normal is not None and anchor is not None:
        test_normal = Vector(normal)
        if test_normal.length_squared > 1.0e-12:
            test_normal.normalize()
            tolerance = _surface_contact_settle_tolerance(guide)
            collision_needed = bool(
                (Vector(anchor) - Vector(target)).dot(test_normal) < -tolerance
                or (
                    opposite is not None
                    and (Vector(opposite) - Vector(target)).dot(test_normal)
                    < -tolerance
                )
            )
    if (
        armature is not None
        and pose_bone is not None
        and target is not None
        and normal is not None
        and anchor is not None
        and opposite is not None
        and collision_needed
    ):
        plane_normal = Vector(normal)
        if plane_normal.length_squared > 1.0e-12:
            plane_normal.normalize()
            # A long pin line must not teleport the limb to the distant pink
            # target just to resolve collision. Use the point on the same
            # surface directly below this limb, then apply the identical
            # top-pivot/bottom-up rod rule used by attached motion.
            local_plane_target = Vector(anchor) - plane_normal * (
                (Vector(anchor) - Vector(target)).dot(plane_normal)
            )
            bone_world = armature.matrix_world @ pose_bone.matrix
            solved_world = _surface_contact_pressure_rod_world(
                guide,
                bone_world,
                local_plane_target,
                plane_normal,
                anchor,
                opposite,
            )
            if solved_world is not None:
                changed = _set_pose_bone_constrained_output_matrix(
                    context,
                    armature,
                    pose_bone,
                    armature.matrix_world.inverted_safe() @ solved_world,
                ) or changed
    _surface_contact_set_constraint_attachment(guide, False)
    # Publish the detached state, not only its transient runtime set entry.
    # A later depsgraph pass can otherwise see the magnetically aimed dots
    # close together and recreate a latch during the same ancestor transform.
    _surface_contact_set_snap_detached(guide, True)
    _state.setdefault("pin_snap_latches", set()).discard(snap_key)
    return changed


def _surface_contact_pressure_rod_world(
    guide,
    bone_world,
    target,
    normal,
    anchor,
    opposite,
    *,
    allow_top_pivot=True,
):
    """Solve one continuous two-ended rod against the contact plane.

    Before the far/top endpoint reaches the plane, the pink endpoint is the
    planted pivot.  After the far endpoint crosses the plane, that endpoint
    becomes the pivot and the pink/bottom endpoint rolls upward.  This is the
    actual two-end rod rule; reflecting the far endpoint while permanently
    planting the pink endpoint produces the opposite motion.
    """
    target = Vector(target)
    normal = Vector(normal)
    anchor = Vector(anchor)
    opposite = Vector(opposite)
    if normal.length_squared <= 1.0e-12:
        return None
    normal.normalize()
    source_rod = opposite - anchor
    rod_length = source_rod.length
    if rod_length <= 1.0e-8:
        return None

    snap_key = _surface_contact_snap_key(guide)
    tangent_cache = _state.setdefault("pin_snap_pressure_tangents", {})
    requested_top = opposite - target
    signed_top = requested_top.dot(normal)
    # Small numerical/interactive crossings are still ordinary planted
    # ball-socket motion. Switching pivots the instant the top is a fraction
    # below the plane makes every transform appear to slide off. Reserve the
    # top-pivot/bottom-up behavior for a deliberate, stronger push.
    pressure_threshold = (
        PIN_SNAP_WORLD_RADIUS
        * PIN_SNAP_RELEASE_PIXEL_RADIUS
        / max(1.0, PIN_SNAP_PIXEL_RADIUS)
    )
    top_pivot_active = bool(
        allow_top_pivot and signed_top < -pressure_threshold
    )
    tangent = requested_top - normal * signed_top
    if tangent.length_squared > 1.0e-12:
        tangent_direction = tangent.normalized()
        tangent_cache[snap_key] = tangent_direction.copy()
    else:
        tangent_direction = tangent_cache.get(snap_key)
        if tangent_direction is None:
            tangent_direction = source_rod - normal * source_rod.dot(normal)
            if tangent_direction.length_squared <= 1.0e-12:
                tangent_direction = normal.orthogonal()
            tangent_direction.normalize()
            tangent_cache[snap_key] = tangent_direction.copy()
        else:
            tangent_direction = Vector(tangent_direction).normalized()

    if not top_pivot_active:
        _state.setdefault("pin_snap_pressure_active", set()).discard(snap_key)
        # Normal planted motion: the real pink endpoint stays at its pin.
        desired_bottom = target
        desired_direction = (
            tangent_direction
            if signed_top < 0.0
            else requested_top
        )
        if desired_direction.length_squared <= 1.0e-12:
            desired_direction = tangent_direction
        desired_direction.normalize()
        desired_top = desired_bottom + desired_direction * rod_length
    else:
        _state.setdefault("pin_snap_pressure_active", set()).add(snap_key)
        # The imaginary top has reached the surface and is now the pivot.
        # At the crossing this starts at the exact side pose. More pressure
        # rotates the real bottom upward around that top pivot, continuously.
        desired_top = target + tangent_direction * rod_length
        bottom_direction = (
            -tangent_direction * tangent.length
            + normal * (-signed_top)
        )
        if bottom_direction.length_squared <= 1.0e-12:
            bottom_direction = normal
        bottom_direction.normalize()
        desired_bottom = desired_top + bottom_direction * rod_length

    desired_rod = desired_top - desired_bottom
    if desired_rod.length_squared <= 1.0e-12:
        return None
    rotation = source_rod.normalized().rotation_difference(
        desired_rod.normalized()
    )
    solved_world = (
        Matrix.Translation(anchor)
        @ rotation.to_matrix().to_4x4()
        @ Matrix.Translation(-anchor)
        @ Matrix(bone_world)
    )
    solved_anchor = solved_world @ (Matrix(bone_world).inverted_safe() @ anchor)
    solved_world.translation += desired_bottom - solved_anchor
    return solved_world


def _surface_contact_solve_attached_rod_motion(
    context,
    guide,
    *,
    allow_top_pivot=True,
):
    """Keep attachment while either end of its collision rod pivots."""
    armature, pose_bone = _surface_contact_pose_bone(guide)
    target, normal, anchor = _surface_contact_world_point_normal(
        context, guide
    )
    opposite = _surface_contact_opposite_anchor_world(context, guide)
    if (
        armature is None
        or pose_bone is None
        or target is None
        or normal is None
        or anchor is None
        or opposite is None
    ):
        return None
    bone_world = armature.matrix_world @ pose_bone.matrix
    solved_world = _surface_contact_pressure_rod_world(
        guide,
        bone_world,
        target,
        normal,
        anchor,
        opposite,
        allow_top_pivot=allow_top_pivot,
    )
    if solved_world is None:
        return None
    changed = _set_pose_bone_constrained_output_matrix(
        context,
        armature,
        pose_bone,
        armature.matrix_world.inverted_safe() @ solved_world,
    )
    snap_key = _surface_contact_snap_key(guide)
    _surface_contact_set_snap_detached(guide, False)
    _surface_contact_set_constraint_attachment(guide, True)
    _state.setdefault("pin_snap_detached", set()).discard(snap_key)
    _state.setdefault("pin_snap_latches", set()).add(snap_key)
    _surface_contact_store_valid_pose(guide)
    return changed


def _surface_contact_active_snap_guides(scene):
    frame = int(getattr(scene, "frame_current", 0))
    return tuple(
        guide
        for guide in _surface_contact_guides()
        if (
            _surface_contact_snap_capable(guide)
            and _surface_contact_guide_active_at(guide, frame)
        )
    )


def _surface_contact_guide_directly_selected(context, guide):
    if context is None or getattr(context, "mode", "") != "POSE":
        return False
    armature = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
    )
    if _pin_selected_target_key() == (
        f"CONTACT:{_armature_session_uid(armature)}:"
        f"{getattr(guide, 'name', '')}"
    ):
        return True
    if (
        armature is None
        or armature.name
        != str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
    ):
        return False
    selected_names = {
        pose_bone.name
        for pose_bone in _selected_pose_bones_by_owner(context).get(
            armature,
            (),
        )
    }
    return bool(
        selected_names
        and _surface_contact_related_bone_names(guide) & selected_names
    )


def _surface_contact_transform_signature(context, guide, depsgraph = None):
    del context, depsgraph
    matrix_values = tuple(
        round(float(value), 7)
        for row in guide.matrix_world
        for value in row
    )
    armature, pose_bone = _surface_contact_pose_bone(guide)
    pose_values = ()
    if armature is not None and pose_bone is not None:
        pose_values = tuple(
            round(float(value), 7)
            for matrix in (
                armature.matrix_world,
                pose_bone.matrix_basis,
                pose_bone.matrix,
            )
            for row in matrix
            for value in row
        )
    property_values = []
    for property_name in (
        SURFACE_CONTACT_POINT_PROPERTY,
        SURFACE_CONTACT_NORMAL_PROPERTY,
        SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY,
    ):
        value = guide.get(property_name)
        if value is None:
            property_values.append(None)
            continue
        try:
            property_values.extend(
                round(float(component), 7) for component in value
            )
        except (TypeError, ValueError):
            property_values.append(str(value))
    return matrix_values + pose_values + tuple(property_values)


def _surface_contact_seed_runtime_signatures(context, guides = None):
    if context is None or getattr(context, "scene", None) is None:
        return False
    prune_all_caches = guides is None
    depsgraph = context.evaluated_depsgraph_get()
    signatures = _state.setdefault("surface_contact_transform_signatures", {})
    target_signatures = _state.setdefault(
        "surface_contact_target_signatures", {}
    )
    live_keys = set()
    for guide in tuple(guides if guides is not None else _surface_contact_guides()):
        key = _surface_contact_pose_cache_key(guide)
        live_keys.add(key)
        signatures[key] = _surface_contact_transform_signature(
            context,
            guide,
            depsgraph,
        )
        try:
            evaluated_guide = guide.evaluated_get(depsgraph)
            target_matrix = evaluated_guide.matrix_world
        except (AttributeError, ReferenceError, RuntimeError):
            target_matrix = guide.matrix_world
        target_signatures[key] = tuple(
            round(float(value), 7)
            for row in target_matrix
            for value in row
        )
    if prune_all_caches:
        for key in tuple(signatures):
            if key not in live_keys:
                signatures.pop(key, None)
        for key in tuple(target_signatures):
            if key not in live_keys:
                target_signatures.pop(key, None)
        for cache_name in (
            "surface_contact_valid_poses",
            "surface_contact_owner_pose_bases",
            "surface_contact_rotation_axes",
        ):
            cache = _state.setdefault(cache_name, {})
            for key in tuple(cache):
                if key not in live_keys:
                    cache.pop(key, None)
    return bool(live_keys)


def _surface_contact_runtime_signatures_changed(context, guides, depsgraph):
    signatures = _state.setdefault("surface_contact_transform_signatures", {})
    changed = []
    for guide in guides:
        key = _surface_contact_pose_cache_key(guide)
        current = _surface_contact_transform_signature(context, guide, depsgraph)
        previous = signatures.get(key)
        signatures[key] = current
        if previous is not None and previous != current:
            changed.append(guide)
    return tuple(changed)


def _surface_contact_depsgraph_update_is_relevant(guides, depsgraph):
    if not guides or depsgraph is None:
        return ()
    guides_by_action_pointer = {}
    for guide in guides:
        armature, _pose_bone = _surface_contact_pose_bone(guide)
        for action in (
            _dynamic_parent_owner_action(guide),
            _dynamic_parent_owner_action(armature)
            if armature is not None
            else None,
        ):
            action = getattr(action, "original", action)
            if action is None:
                continue
            try:
                guides_by_action_pointer.setdefault(
                    int(action.as_pointer()),
                    [],
                ).append(guide)
            except (AttributeError, ReferenceError, RuntimeError, TypeError):
                pass

    try:
        updates = tuple(depsgraph.updates)
    except (AttributeError, ReferenceError, RuntimeError):
        return ()
    changed_candidates = []
    seen_guides = set()
    for update in updates:
        updated_id = getattr(update, "id", None)
        updated_id = getattr(updated_id, "original", updated_id)
        try:
            pointer = int(updated_id.as_pointer())
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            continue
        if not isinstance(updated_id, bpy.types.Action):
            continue
        for guide in guides_by_action_pointer.get(pointer, ()):
            if guide.name in seen_guides:
                continue
            seen_guides.add(guide.name)
            changed_candidates.append(guide)
    if not changed_candidates:
        return ()
    return _surface_contact_runtime_signatures_changed(
        bpy.context,
        tuple(changed_candidates),
        depsgraph,
    )


def _surface_contact_finalize_native_transform(context):
    """Commit or cancel contact-owned native-transform poses before redraw."""
    if not _state.get("pin_snap_transform_active", False):
        return False
    previous_guard = bool(_state.get("surface_contact_reconciling", False))
    _state["surface_contact_reconciling"] = True
    transform_changed = False
    try:
        # Blender restores the selected pose before removing a cancelled
        # native G/R/S operator. Preview dirtiness and a temporary release
        # flag therefore cannot decide confirmation: doing so recommits the
        # last pink preview after Right Click/Esc. The settled selected pose
        # is authoritative. A real release or ball-joint move leaves that pose
        # changed; a cancellation restores it exactly.
        transform_changed = bool(
            _pin_transform_pose_differs_from_start(context)
        )
        if transform_changed:
            _pin_native_group_finish(context)
        else:
            _pin_restore_transform_start_poses(context)
            _surface_contact_restore_transform_start_poses(context)
            _pin_native_group_cancel(context)
        has_live_preview = bool(
            _state.get("pin_snap_live_pose_matrices", {})
        )
        if transform_changed and not has_live_preview:
            _state.pop("pin_snap_transform_dirty", False)
            _snap_selected_pin_endpoints(
                context,
                insert_keys=False,
                use_snap_hysteresis=True,
            )
        _pin_restore_contact_target_locks()
        if transform_changed:
            _surface_contact_restore_live_poses(context)
            _surface_contact_finalize_snap_departures(context)
            _surface_contact_record_native_transform_history(context)
        if (
            transform_changed
            and context.scene.tool_settings.use_keyframe_insert_auto
        ):
            for guide_name in tuple(
                _state.get("pin_snap_contact_target_locks", {})
            ):
                guide = bpy.data.objects.get(str(guide_name))
                if guide is not None:
                    _surface_contact_keyframe_simulated_pose(
                        guide,
                        int(context.scene.frame_current),
                    )
        return transform_changed
    finally:
        _state["pin_snap_transform_dirty"] = False
        _pin_clear_transform_state()
        _state["surface_contact_reconciling"] = previous_guard
        # Seed from the fully committed pose. Otherwise the next Action
        # update for an unrelated bone sees the just-edited pink pose as a
        # new signature delta and wakes Contact one operation late.
        context.view_layer.update()
        _surface_contact_seed_runtime_signatures(context)
        _pin_cache_idle_transform_poses(context)


def _surface_contact_enforce_active_simulated(
    context,
    scene,
    guides = None,
    respect_selected = False,
):
    if (
        context is None
        or scene is None
        or _state.get("surface_contact_solver_syncing", False)
        or _state.get("surface_contact_syncing", False)
    ):
        return False
    guides = tuple(
        guides
        if guides is not None
        else _surface_contact_active_simulated_guides(scene)
    )
    if not guides:
        return False

    _state["surface_contact_solver_syncing"] = True
    changed = False
    try:
        for guide in guides:
            changed = _surface_contact_update_guide_transform(guide) or changed
            directly_selected = bool(
                respect_selected
                and _surface_contact_guide_directly_selected(context, guide)
            )
            detached = bool(
                _surface_contact_snap_departure_active(context, guide)
            )
            if detached:
                changed = (
                    _surface_contact_set_constraint_attachment(guide, False)
                    or changed
                )
                continue
            changed = _surface_contact_enforce_guide(
                context,
                guide,
                force_contact = not directly_selected and not detached,
                use_snap_hysteresis = directly_selected,
                allow_snap = not detached,
                rotate_detached = False,
            ) or changed
        _surface_contact_seed_runtime_signatures(context, guides)
        if changed:
            _tag_redraw_all_view3d()
        return changed
    finally:
        _state["surface_contact_solver_syncing"] = False


@persistent
def _surface_contact_frame_change_post(scene, _depsgraph = None):
    context = bpy.context
    if _state.get("pin_history_pose_release_pending", False):
        if _surface_contact_history_lock_matches_frame(context):
            _surface_contact_finish_history_pose_release(context)
            return None
        _surface_contact_clear_history_pose_lock()
    if (
        _state.get("surface_contact_load_restoring", False)
        or _state.get("surface_contact_creation_active", False)
        or _state.get("pin_history_active", False)
        or _state.get("pin_history_syncing", False)
        or _state.get("pin_target_dragging", False)
        or _state.get("pin_snap_transform_active", False)
    ):
        return None
    frame = int(getattr(scene, "frame_current", 0))
    scene_key = int(scene.as_pointer())
    last_frames = _state.setdefault("surface_contact_last_frames", {})
    previous_frame = last_frames.get(scene_key)
    last_frames[scene_key] = frame
    if previous_frame is None or int(previous_frame) == frame:
        # Blender emits a same-frame callback while restoring a file and while
        # re-registering an extension. The pose already stored in the blend is
        # authoritative; re-solving here caused the delayed "ghost" offset.
        return None
    # Frame changes are the one place where keyed detach state supersedes the
    # current-frame runtime latch. Same-frame depsgraph and ancestor updates
    # must never clear a manual detach.
    _surface_contact_restore_snap_detached(
        context,
        infer_missing=False,
        reset_runtime=True,
    )
    _sync_surface_contact_constraints(
        scene,
        _depsgraph,
        sync_dynamic_parent = False,
        solve_detached_target_motion = True,
    )


def _surface_contact_supersede_history_for_transform(transform_operator):
    """Release a completed history lock as soon as a new G/R/S owns input."""
    if (
        not transform_operator
        or _state.get("pin_history_syncing", False)
        or not (
            _state.get("pin_history_active", False)
            or _state.get("pin_history_pose_release_pending", False)
        )
    ):
        return False
    _state["pin_history_active"] = False
    _surface_contact_clear_history_pose_lock()
    try:
        if bpy.app.timers.is_registered(_clear_pin_history_visibility):
            bpy.app.timers.unregister(_clear_pin_history_visibility)
    except (ReferenceError, RuntimeError, ValueError):
        pass
    _state.setdefault("owned_timers", set()).discard(
        _clear_pin_history_visibility
    )
    return True


@persistent
def _surface_contact_depsgraph_update_post(scene, depsgraph):
    context = bpy.context
    transform_operator = (
        _pin_active_transform_operator(context)
        if (
            context is not None
            and getattr(context, "scene", None) == scene
            and getattr(context, "mode", "") == "POSE"
        )
        else None
    )
    # A new modal transform is newer authority than Undo's short-lived late
    # evaluation lock. Release it before either history branch can consume the
    # first parent-movement sample and leave the contacted child frozen.
    _surface_contact_supersede_history_for_transform(transform_operator)
    if (
        context is not None
        and getattr(context, "scene", None) == scene
        and _state.get("pin_history_pose_release_pending", False)
    ):
        if not _surface_contact_history_lock_matches_frame(context):
            _surface_contact_clear_history_pose_lock()
        elif _surface_contact_history_lock_update_relevant(depsgraph):
            _surface_contact_finish_history_pose_release(context)
            return None
    if (
        context is not None
        and getattr(context, "scene", None) == scene
        and getattr(context, "mode", "") == "POSE"
        and _state.get("pin_history_active", False)
    ):
        # Redo can evaluate the selected parent's Action once more after
        # redo_post. Keep its indirectly solved pink children on the exact
        # paired history side before that dependency pass reaches a redraw.
        _surface_contact_apply_history_pose_lock(context)
        return None
    if (
        context is None
        or getattr(context, "scene", None) != scene
        or getattr(context, "mode", "") != "POSE"
        or _state.get("pin_target_dragging", False)
        or _state.get("pin_snap_syncing", False)
        or _state.get("pin_history_syncing", False)
        or _state.get("surface_contact_creation_active", False)
        or _state.get("surface_contact_load_restoring", False)
        or time.perf_counter()
        < float(_state.get("surface_contact_registration_guard_until", 0.0))
        or _state.get("surface_contact_solver_syncing", False)
        or _state.get("surface_contact_reconciling", False)
        or _state.get("dynamic_space_reconciling", False)
    ):
        return None
    if transform_operator or _state.get("pin_snap_transform_active", False):
        if transform_operator:
            _pin_track_transform(transform_operator)
            if _state.get("pin_snap_transform_initializing", False):
                # A view-layer evaluation during capture recursively entered
                # this handler. The outer callback owns the first complete
                # sample once every baseline/attachment snapshot is ready.
                return None
            # Solve in the depsgraph callback that observed Blender's native
            # gizmo sample. Deferring this to the 60 Hz timer exposes the raw
            # unconstrained pose for a redraw, producing contact escape
            # flicker between otherwise-correct solver results.
            try:
                _pin_process_native_transform_sample(
                    context,
                    transform_operator,
                )
                _state["pin_snap_depsgraph_observed"] = True
                _state["pin_snap_transform_dirty"] = False
                _state["pin_snap_last_depsgraph_sync"] = time.perf_counter()
            except (
                AttributeError,
                ReferenceError,
                RuntimeError,
                TypeError,
                ValueError,
            ) as exc:
                _state["pin_snap_transform_dirty"] = True
                print(
                    "[Roblox Animator Utils] Immediate pin snap skipped: "
                    f"{exc}"
                )
        else:
            if _state.get("pin_snap_depsgraph_observed", False):
                _surface_contact_finalize_native_transform(context)
            else:
                _state["pin_snap_transform_dirty"] = True
        return None

    guides = _surface_contact_active_simulated_guides(scene)
    changed_guides = _surface_contact_depsgraph_update_is_relevant(
        guides,
        depsgraph,
    )
    if changed_guides:
        # Re-evaluate only when an Action update actually changed this
        # contact's guide, owner, or parent-driven pose. In particular, an
        # Action pass after Redo can put the child back on its keyed straight
        # basis; that change must reapply the engaged contact constraint.
        _surface_contact_enforce_active_simulated(
            context,
            scene,
            changed_guides,
            respect_selected = True,
        )
    _pin_cache_idle_transform_poses(context)
    return None
