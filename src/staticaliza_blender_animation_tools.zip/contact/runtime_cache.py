"""Hot-path caches for Surface Contact playback and depsgraph callbacks."""

from ..core.runtime import *  # noqa: F403


def _surface_contact_active_simulated_guides_cached(scene):
    if scene is None:
        return ()
    key = (
        int(_state.get("surface_contact_guide_cache_generation", 0)),
        len(bpy.data.objects),
        int(scene.as_pointer()),
        int(getattr(scene, "frame_current", 0)),
    )
    cache = _state.setdefault("surface_contact_active_guide_cache", {})
    cached = cache.get(key)
    if cached is not None:
        # Undo, file reload, and extension replacement can recreate Blender
        # objects with the same name and keep the global object count stable.
        # Never retain RNA object wrappers in this cache across those events;
        # stale wrappers make the pink overlay/pins disappear while their
        # surviving Action channels remain visible.
        return tuple(
            guide
            for name in cached
            if (guide := bpy.data.objects.get(str(name))) is not None
            and bool(guide.get(SURFACE_CONTACT_GUIDE_PROPERTY, False))
            and str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
            == SURFACE_CONTACT_KIND_SIMULATED
            and _surface_contact_guide_active_at(guide, key[3])
        )
    guides = tuple(
        guide
        for guide in _surface_contact_guides()
        if (
            str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
            == SURFACE_CONTACT_KIND_SIMULATED
            and _surface_contact_guide_active_at(guide, key[3])
        )
    )
    cache.clear()
    cache[key] = tuple(str(guide.name) for guide in guides)
    return guides


def _surface_contact_resolved_playback_guide(guide):
    if guide is None:
        return None
    support_data = guide.get(SURFACE_CONTACT_SUPPORT_PROPERTY)
    if support_data is None or len(support_data) < 3:
        return None
    support = tuple(float(value) for value in support_data[:3])
    armature_name = str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
    bone_name = str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
    geometry_name = str(
        guide.get(SURFACE_CONTACT_GEOMETRY_BONE_PROPERTY, bone_name)
    )
    try:
        key = (
            int(_state.get("surface_contact_guide_cache_generation", 0)),
            int(guide.as_pointer()),
            armature_name,
            bone_name,
            geometry_name,
            support,
        )
    except (ReferenceError, RuntimeError):
        return None
    cache = _state.setdefault("surface_contact_resolved_guide_cache", {})
    cached = cache.get(key)
    if cached is not None:
        armature, pose_bone, geometry_bone, cached_support = cached
        try:
            if (
                armature.name == armature_name
                and pose_bone.name == bone_name
                and geometry_bone.name == geometry_name
            ):
                return armature, pose_bone, geometry_bone, cached_support
        except (AttributeError, ReferenceError, RuntimeError):
            pass
    armature = bpy.data.objects.get(armature_name)
    pose_bone = (
        armature.pose.bones.get(bone_name)
        if armature is not None and getattr(armature, "pose", None)
        else None
    )
    geometry_bone = (
        armature.pose.bones.get(geometry_name)
        if armature is not None and getattr(armature, "pose", None)
        else None
    )
    if armature is None or pose_bone is None or geometry_bone is None:
        return None
    resolved = armature, pose_bone, geometry_bone, Vector(support)
    cache[key] = resolved
    if len(cache) > max(64, len(_surface_contact_guides()) * 4):
        live_generation = key[0]
        for cached_key in tuple(cache):
            if cached_key[0] != live_generation:
                cache.pop(cached_key, None)
    return resolved


def _surface_contact_depsgraph_guide_index_for(guides):
    guides = tuple(guides)
    generation = int(_state.get("surface_contact_guide_cache_generation", 0))
    try:
        guide_pointers = tuple(int(guide.as_pointer()) for guide in guides)
    except (ReferenceError, RuntimeError):
        guide_pointers = ()
    cache_key = generation, guide_pointers
    cached = _state.get("surface_contact_depsgraph_guide_index")
    if cached and cached[0] == cache_key:
        return cached[1]
    index = {}
    for guide in guides:
        armature, _pose_bone = _surface_contact_pose_bone(guide)
        surface = bpy.data.objects.get(str(
            guide.get(SURFACE_CONTACT_SURFACE_PROPERTY, "")
        ))
        follow = bpy.data.objects.get(str(
            guide.get(SURFACE_CONTACT_FOLLOW_OBJECT_PROPERTY, "")
        ))
        control = bpy.data.objects.get(str(
            guide.get(SURFACE_CONTACT_CONTROL_OBJECT_PROPERTY, "")
        ))
        owner_ids = (
            guide,
            surface,
            follow,
            control,
            armature,
            getattr(armature, "data", None),
            _dynamic_parent_owner_action(guide),
            _dynamic_parent_owner_action(armature)
            if armature is not None
            else None,
        )
        for owner_id in owner_ids:
            owner_id = getattr(owner_id, "original", owner_id)
            try:
                pointer = int(owner_id.as_pointer())
            except (AttributeError, ReferenceError, RuntimeError, TypeError):
                continue
            index.setdefault(pointer, []).append(guide)
    frozen = {pointer: tuple(items) for pointer, items in index.items()}
    _state["surface_contact_depsgraph_guide_index"] = cache_key, frozen
    return frozen
