"""Complete teardown for removed Surface Contact guides."""

from ..core.runtime import *  # noqa: F403


def _surface_contact_purge_removed_runtime(guide, armature, bone_name):
    guide_name = str(getattr(guide, "name", ""))
    snap_key = _surface_contact_snap_key(guide)
    cache_key = _surface_contact_pose_cache_key(guide)
    owner_key = (
        _owner_bone_key(armature, bone_name)
        if armature is not None and bone_name
        else None
    )
    history_key = (
        (_armature_session_uid(armature), guide_name)
        if armature is not None
        else None
    )
    aliases = {guide_name, snap_key, cache_key}
    for state_name in (
        "pin_snap_parent_transform_guides",
        "pin_snap_latches",
        "pin_snap_detached",
        "pin_snap_departing",
        "pin_snap_transform_seen",
        "pin_snap_swept_hits",
        "pin_snap_transform_engaged",
        "pin_snap_transform_releasing",
        "pin_snap_release_reentry_armed",
        "pin_snap_pressure_active",
    ):
        values = _state.setdefault(state_name, set())
        for alias in aliases:
            values.discard(alias)
    for state_name in (
        "pin_snap_contact_target_locks",
        "pin_snap_parent_attachment_states",
        "pin_snap_initial_detached",
        "pin_snap_previous_points",
        "pin_snap_pressure_tangents",
        "pin_snap_pressure_release_origins",
        "pin_snap_engage_translate_origins",
        "pin_snap_engage_anchor_origins",
        "pin_snap_grip_directions",
        "pin_snap_raw_anchor_samples",
        "pin_snap_magnetic_anchor_samples",
        "pin_snap_initial_attachment_states",
    ):
        values = _state.setdefault(state_name, {})
        for alias in aliases:
            values.pop(alias, None)
    _state.setdefault("pin_snap_live_pose_dirty_guides", set()).discard(
        guide_name
    )
    for state_name in (
        "surface_contact_valid_poses",
        "surface_contact_owner_pose_bases",
        "surface_contact_transform_signatures",
        "surface_contact_target_signatures",
        "surface_contact_rotation_axes",
        "surface_contact_smart_aim_branches",
        "surface_contact_roll_frames",
        "surface_contact_collision_tangents",
    ):
        _state.setdefault(state_name, {}).pop(cache_key, None)
    if owner_key is not None:
        _state.setdefault("pin_dual_snap_owners", {}).pop(
            owner_key,
            None,
        )
        _state.setdefault("pin_snap_live_pose_matrices", {}).pop(
            owner_key,
            None,
        )
        _state.setdefault(
            "pin_snap_contact_transform_start_poses", {}
        ).pop(owner_key, None)
    _state["pin_gizmo_deferred_finishes"] = [
        item
        for item in _state.get("pin_gizmo_deferred_finishes", ())
        if str(item.get("target_key", "")) != snap_key
    ]
    _state.setdefault("pin_gizmo_axes_visible", {}).pop(snap_key, None)
    pending_click = _state.get("pin_gizmo_pending_click")
    if pending_click and str(pending_click[0]) == snap_key:
        _state["pin_gizmo_pending_click"] = None
    selected_keys = set(_state.get("pin_gizmo_selected_keys", set()))
    selected_keys.discard(snap_key)
    _state["pin_gizmo_selected_keys"] = selected_keys
    if str(_state.get("pin_gizmo_selected_keys_active", "")) == snap_key:
        _state["pin_gizmo_selected_keys_active"] = next(
            iter(sorted(selected_keys)),
            "",
        )
    history_selection = _state.get("pin_history_selection_snapshot")
    if isinstance(history_selection, dict):
        history_selection = dict(history_selection)
        history_selected = set(history_selection.get("selected", set()))
        history_selected.discard(snap_key)
        history_selection["selected"] = history_selected
        if str(history_selection.get("active", "")) == snap_key:
            history_selection["active"] = next(
                iter(sorted(history_selected)),
                "",
            )
        _state["pin_history_selection_snapshot"] = history_selection
    history = _state.get("pin_history_contact_snapshot")
    if isinstance(history, dict) and history_key is not None:
        history = dict(history)
        for field in ("targets", "poses", "pose_matrices"):
            values = dict(history.get(field, {}))
            values.pop(history_key, None)
            history[field] = values
        for field in ("engaged", "selected"):
            values = set(history.get(field, set()))
            values.discard(history_key)
            history[field] = values
        _state["pin_history_contact_snapshot"] = history
    session = _state.get("pin_native_group_session")
    if session is not None and any(
        state.get("payload") == guide
        for state in getattr(session, "group_pin_states", ())
    ):
        _pin_native_group_clear()
    return snap_key


def _surface_contact_remove_solver_constraints(owner, guide, solver):
    if owner is None:
        return False
    stored_names = {
        str(guide.get(SURFACE_CONTACT_PRIMARY_PROPERTY, "")),
        str(guide.get(SURFACE_CONTACT_SECONDARY_PROPERTY, "")),
    }
    changed = False
    for constraint in tuple(getattr(owner, "constraints", ())):
        if not (
            constraint.name in stored_names
            or (
                solver is not None
                and getattr(constraint, "target", None) == solver
                and constraint.name.startswith(
                    SURFACE_CONTACT_CONSTRAINT_PREFIX
                )
            )
        ):
            continue
        changed = _surface_contact_remove_constraint(
            owner,
            constraint,
        ) or changed
    return changed
