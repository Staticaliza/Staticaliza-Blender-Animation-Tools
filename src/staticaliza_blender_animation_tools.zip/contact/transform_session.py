"""Authoritative live-pose snapshots for native contact transforms."""
from ..core.runtime import *  # noqa: F403

def _surface_contact_store_persistent_pose_snapshots(
    guides = None,
    only_missing = False,
):
    """Persist current simulated poses across file and extension reloads."""
    changed = False
    for guide in tuple(guides if guides is not None else _surface_contact_guides()):
        pose_bone = _surface_contact_simulated_pose_bone(guide)
        if pose_bone is None:
            continue
        if (
            only_missing
            and SURFACE_CONTACT_SAVED_POSE_PROPERTY in guide
        ):
            continue
        packed = tuple(
            float(value)
            for row in pose_bone.matrix_basis
            for value in row
        )
        if tuple(
            pose_bone.get(SURFACE_CONTACT_SAVED_POSE_PROPERTY, ())
        ) != packed:
            pose_bone[SURFACE_CONTACT_SAVED_POSE_PROPERTY] = packed
            changed = True
        if tuple(guide.get(SURFACE_CONTACT_SAVED_POSE_PROPERTY, ())) != packed:
            guide[SURFACE_CONTACT_SAVED_POSE_PROPERTY] = packed
            changed = True
    return changed


def _surface_contact_restore_persistent_pose_snapshots(
    context,
    guides = None,
    update_view_layer = True,
):
    """Restore the exact saved local pose without running a contact solve."""
    restored_bones = set()
    changed = False
    for guide in tuple(guides if guides is not None else _surface_contact_guides()):
        pose_bone = _surface_contact_simulated_pose_bone(guide)
        packed = (
            pose_bone.get(SURFACE_CONTACT_SAVED_POSE_PROPERTY)
            if pose_bone is not None
            else None
        ) or guide.get(SURFACE_CONTACT_SAVED_POSE_PROPERTY)
        if pose_bone is None or packed is None or len(packed) != 16:
            continue
        armature = bpy.data.objects.get(
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
        )
        key = (_armature_session_uid(armature), pose_bone.name)
        if key in restored_bones:
            continue
        restored_bones.add(key)
        matrix_basis = Matrix(
            tuple(
                tuple(float(packed[(row * 4) + column]) for column in range(4))
                for row in range(4)
            )
        )
        if _pin_keyboard_matrices_differ(
            pose_bone.matrix_basis,
            matrix_basis,
        ):
            pose_bone.matrix_basis = matrix_basis
            changed = True
    if changed and update_view_layer and context is not None:
        context.view_layer.update()
    return changed
def _surface_contact_restore_native_saved_history(context, transition):
    """Restore Blender-owned modal pose properties before runtime fallbacks."""
    changed = False
    restored = set()
    for entry in tuple((transition or {}).get("contacts", ())):
        armature = bpy.data.objects.get(str(entry[1]))
        pose_bone = (
            armature.pose.bones.get(str(entry[2]))
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is None:
            continue
        owner = (armature.name, pose_bone.name)
        if owner in restored:
            continue
        restored.add(owner)
        packed = pose_bone.get(SURFACE_CONTACT_SAVED_POSE_PROPERTY)
        if packed is None or len(packed) != 16:
            continue
        expected = Matrix(tuple(
            tuple(
                float(packed[(row * 4) + column])
                for column in range(4)
            )
            for row in range(4)
        ))
        if _pin_keyboard_matrices_differ(
            pose_bone.matrix_basis,
            expected,
        ):
            pose_bone.matrix_basis = expected
            changed = True
    if changed:
        context.view_layer.update()
    return changed


def _surface_contact_clear_live_pose_session():
    _state["pin_snap_live_pose_matrices"] = {}
def _pin_cache_idle_transform_poses(context):
    """Cache the pose before Blender emits the first native transform sample."""
    if (
        context is None
        or getattr(context, "mode", "") != "POSE"
        or _state.get("pin_snap_transform_active", False)
        or _state.get("pin_keyboard_transform_active", False)
    ):
        return False
    selected = {}
    for armature, pose_bones in _selected_pose_bones_by_owner(context).items():
        owner_uid = _armature_session_uid(armature)
        for pose_bone in pose_bones:
            selected[(owner_uid, pose_bone.name)] = (
                pose_bone.matrix_basis.copy()
            )
    contacts = {}
    for guide in _surface_contact_active_simulated_guides(context.scene):
        armature, pose_bone = _surface_contact_pose_bone(guide)
        if armature is None or pose_bone is None:
            continue
        key = (_armature_session_uid(armature), pose_bone.name)
        contacts[key] = (
            armature.name,
            pose_bone.name,
            pose_bone.matrix_basis.copy(),
            pose_bone.matrix.copy(),
        )
    _state["pin_snap_idle_transform_poses"] = {
        "signature": tuple(sorted(selected)),
        "selected": selected,
        "contacts": contacts,
    }
    return True
def _pin_prepare_transform_pose_baseline(grouped):
    """Use the last idle pose only when it matches the current selection."""
    keys = tuple(sorted(
        (_armature_session_uid(armature), pose_bone.name)
        for armature, pose_bones in grouped.items()
        for pose_bone in pose_bones
    ))
    cached = _state.get("pin_snap_idle_transform_poses", {})
    valid = bool(keys and tuple(cached.get("signature", ())) == keys)
    cached_selected = cached.get("selected", {}) if valid else {}
    # A changed selected basis means Blender's first native G/R/S sample
    # reached depsgraph before we noticed the modal operator. Only that case
    # needs the pre-sample idle contact pose; if the selected basis is still
    # unchanged, the live contact pose is the exact operation baseline.
    sample_already_applied = bool(
        valid
        and any(
            _pin_keyboard_matrices_differ(
                pose_bone.matrix_basis,
                cached_selected.get(
                    (_armature_session_uid(armature), pose_bone.name),
                    pose_bone.matrix_basis,
                ),
            )
            for armature, pose_bones in grouped.items()
            for pose_bone in pose_bones
        )
    )
    _state["pin_snap_transform_baseline_precedes_sample"] = (
        sample_already_applied
    )
    _state["pin_snap_transform_capture_baseline"] = (
        dict(cached.get("contacts", {})) if valid else {}
    )
    return dict(cached_selected)
def _surface_contact_capture_live_pose(guide):
    """Remember exactly what the user sees after the latest live solve."""

    armature, pose_bone = _surface_contact_pose_bone(guide)
    if armature is None or pose_bone is None:
        return False
    key = (_armature_session_uid(armature), pose_bone.name)
    _state.setdefault("pin_snap_live_pose_matrices", {})[key] = (
        armature.name,
        pose_bone.name,
        pose_bone.matrix_basis.copy(),
        pose_bone.matrix.copy(),
    )
    # This ID property is sampled by Blender's native undo snapshot while
    # G/R/S is still modal. Redo can therefore restore the solved child from
    # its own history state instead of a runtime-only delayed handler cache.
    _surface_contact_store_persistent_pose_snapshots((guide,))
    return True


def _surface_contact_restore_live_poses(context):
    """Restore the final preview atomically after Blender commits G/R/S."""

    snapshots = tuple(
        _state.get("pin_snap_live_pose_matrices", {}).values()
    )
    changed = False
    for snapshot in snapshots:
        armature_name, bone_name, matrix_basis = snapshot[:3]
        armature = bpy.data.objects.get(str(armature_name))
        pose_bone = (
            armature.pose.bones.get(str(bone_name))
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is None:
            continue
        # matrix_basis is the authored value and the value Blender stores in
        # native pose history. Assigning the captured evaluated pose matrix
        # here makes Blender derive a second local basis after the parent has
        # committed, so Redo briefly shows the preview and then evaluates back
        # to the stale/straight basis.
        if _pin_keyboard_matrices_differ(
            pose_bone.matrix_basis,
            matrix_basis,
        ):
            pose_bone.matrix_basis = matrix_basis.copy()
            changed = True
    if changed:
        context.view_layer.update()
    return changed


def _surface_contact_clear_transform_start_poses():
    _state["pin_snap_contact_transform_start_poses"] = {}
    _state["pin_snap_transform_capture_baseline"] = {}
    _state["pin_snap_transform_baseline_precedes_sample"] = False
    _state["surface_contact_smart_aim_branches"] = {}
    _state["surface_contact_roll_frames"] = {}
    _state["pin_snap_initial_latches"] = set()
    _state["pin_snap_transform_engaged"] = set()
    _state["pin_snap_engage_translate_origins"] = {}
    _state["pin_snap_engage_anchor_origins"] = {}
    _state["pin_snap_raw_anchor_samples"] = {}
    _state["pin_snap_transform_releasing"] = set()
    _state["pin_snap_release_reentry_armed"] = set()
    _state["pin_snap_pressure_tangents"] = {}
    _state["pin_snap_transform_finalize_pending"] = None


def _surface_contact_begin_native_transform(context):
    # A missing detach property is not proof that Contact is attached. Older
    # files and a just-finished modal bone transform can both have a free pink
    # endpoint before the property/action update has settled. Preserve only a
    # confirmed runtime latch, or recover attachment from endpoints that are
    # actually inside the entry radius. The previous unconditional add made
    # every active Contact attached at the start of a torso/unrelated G/R/S.
    latches = _state.setdefault("pin_snap_latches", set())
    initial = set(latches)
    for guide in _surface_contact_active_snap_guides(context.scene):
        key = _surface_contact_snap_key(guide)
        animated_detached = _surface_contact_animated_detached_state(
            guide,
            int(context.scene.frame_current),
        )
        has_current_state = SURFACE_CONTACT_DETACHED_PROPERTY in guide
        current_detached = bool(
            guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)
        )
        saved_detached = (
            current_detached
            if has_current_state
            else animated_detached
        )
        runtime_detached = key in _state.setdefault(
            "pin_snap_detached", set()
        )
        if runtime_detached:
            initial.discard(key)
            latches.discard(key)
            continue
        if key in initial:
            # The visible snap ring is driven by this live latch.  Keep it
            # authoritative even when a two-end pressure pose leaves the
            # displayed endpoint away from the target.  A saved False detach
            # property alone is not proof of attachment: old files and a
            # failed release can both contain that stale value.
            initial.add(key)
            latches.add(key)
            continue
        if saved_detached is True:
            initial.discard(key)
            latches.discard(key)
            continue
        target, _normal, anchor = _surface_contact_world_point_normal(
            context,
            guide,
        )
        if (
            target is not None
            and anchor is not None
            and _pin_points_within_snap_radius(context, target, anchor)
        ):
            initial.add(key)
            latches.add(key)
    _state["pin_snap_initial_latches"] = initial
    _state["pin_snap_transform_engaged"] = set()
    _state["pin_snap_engage_translate_origins"] = {}
    anchor_origins = {}
    for guide in _surface_contact_active_snap_guides(context.scene):
        key = _surface_contact_snap_key(guide)
        if key not in initial:
            continue
        target, _normal, anchor = _surface_contact_world_point_normal(
            context,
            guide,
        )
        if target is not None and anchor is not None:
            anchor_origins[key] = Vector(anchor).copy()
    _state["pin_snap_engage_anchor_origins"] = anchor_origins
    _state["pin_snap_raw_anchor_samples"] = {}
    _state["pin_snap_transform_releasing"] = set()
    _state["pin_snap_release_reentry_armed"] = set()
    _state["pin_snap_pressure_tangents"] = {}
    _state["pin_snap_transform_finalize_pending"] = None


def _surface_contact_native_transform_ready(context):
    """Wait one UI beat so Blender exposes the restored matrix after cancel."""
    now = time.perf_counter()
    pending = _state.get("pin_snap_transform_finalize_pending")
    if pending is None:
        _state["pin_snap_transform_finalize_pending"] = now
        return False
    if now - float(pending) < 0.02:
        return False
    context.view_layer.update()
    return True


def _pin_transform_pose_differs_from_start(context):
    """Test the settled pose, ignoring the dirty flag latched during preview."""
    snapshots = _state.get("pin_snap_transform_start_poses", {})
    for armature in tuple(context.scene.objects):
        if armature.type != "ARMATURE" or getattr(armature, "pose", None) is None:
            continue
        owner_uid = _armature_session_uid(armature)
        for pose_bone in armature.pose.bones:
            initial = snapshots.get((owner_uid, pose_bone.name))
            if initial is not None and _pin_keyboard_matrices_differ(
                pose_bone.matrix_basis, initial, epsilon=1.0e-6
            ):
                return True
    return False


def _pin_snap_should_engage(
    context, snap_key, target, current, use_hysteresis=False
):
    """Shared stable snap arbitration for yellow and pink endpoints."""
    latches = _state.setdefault("pin_snap_latches", set())
    snap_key = str(snap_key)
    was_latched = snap_key in latches
    operator_name = str(
        _state.get("pin_snap_transform_operator", "")
    ).lower()
    rotating = "rotate" in operator_name
    socket_locked_transform = bool(
        rotating or "resize" in operator_name or "scale" in operator_name
    )
    transform_locked = bool(
        socket_locked_transform
        and (
            snap_key in _state.setdefault("pin_snap_initial_latches", set())
            or snap_key in _state.setdefault("pin_snap_transform_engaged", set())
        )
    )
    if transform_locked:
        latches.add(snap_key)
        return True
    radius = (
        PIN_SNAP_RELEASE_PIXEL_RADIUS
        if use_hysteresis and was_latched
        else PIN_SNAP_PIXEL_RADIUS
    )
    within = _pin_points_within_snap_radius(
        context, target, current, pixel_radius=radius
    )
    engaged = within
    if not was_latched:
        engaged = bool(
            _pin_snap_sample_with_sweep(
                target,
                current,
                snap_key,
                world_radius=PIN_SNAP_WORLD_RADIUS,
            )
            or within
        )
    _state.setdefault("pin_snap_swept_hits", set()).discard(snap_key)
    if engaged:
        latches.add(snap_key)
        if rotating and _state.get("pin_snap_transform_active", False):
            _state.setdefault("pin_snap_transform_engaged", set()).add(
                snap_key
            )
    else:
        latches.discard(snap_key)
    return engaged


def _pin_native_translate_vector(context):
    """Return Blender's raw modal translation vector when it is available."""
    operator_name = str(
        _state.get("pin_snap_transform_operator", "")
    )
    if "translate" not in operator_name.lower():
        return None
    signature = _pin_transform_operator_delta_signature(
        context,
        operator_name,
    )
    if signature is None:
        return None
    values = tuple(float(component) for component in signature[1])
    while len(values) < 3:
        values += (0.0,)
    return Vector(values[:3])


def _surface_contact_direct_snap_close(
    context, guide, use_snap_hysteresis
):
    """Latch a newly reached Contact for the rest of its current transform."""
    target, _normal, anchor = _surface_contact_world_point_normal(
        context, guide
    )
    if target is None or anchor is None:
        return False
    key = _surface_contact_snap_key(guide)
    raw_anchor = Vector(
        _state.setdefault("pin_snap_raw_anchor_samples", {}).get(
            key,
            anchor,
        )
    )
    initial = _state.setdefault("pin_snap_initial_latches", set())
    engaged = _state.setdefault("pin_snap_transform_engaged", set())
    releasing = _state.setdefault("pin_snap_transform_releasing", set())
    if key in releasing:
        native_translate = _pin_native_translate_vector(context)
        translate_origin = (
            Vector((0.0, 0.0, 0.0))
            if key in initial
            else _state.setdefault(
                "pin_snap_engage_translate_origins", {}
            ).get(key)
        )
        native_distance = (
            (native_translate - Vector(translate_origin)).length
            if native_translate is not None and translate_origin is not None
            else None
        )
        anchor_origin = _state.setdefault(
            "pin_snap_engage_anchor_origins", {}
        ).get(key)
        anchor_distance = (raw_anchor - Vector(target)).length
        raw_distance = anchor_distance
        if key not in _state.get("pin_snap_raw_anchor_samples", {}):
            raw_distance = (
                native_distance
                if native_distance is not None
                else anchor_distance
            )
        if raw_distance is not None:
            if raw_distance > PIN_SNAP_WORLD_RADIUS:
                return False
            # The user's raw move really returned to the entry radius. No
            # extra outside event is required, and a solver-created visible
            # overlap cannot reach this branch while raw input is still out.
            _state.setdefault(
                "pin_snap_release_reentry_armed", set()
            ).discard(key)
            releasing.discard(key)
            _state.setdefault("pin_snap_departing", set()).discard(key)
            _surface_contact_set_snap_detached(guide, False)
        else:
            # Older/custom operators without a raw movement baseline retain
            # the guarded two-sample fallback.
            reentry_armed = _state.setdefault(
                "pin_snap_release_reentry_armed", set()
            )
            inside_entry = _pin_points_within_snap_radius(
                context,
                target,
                anchor,
                pixel_radius=PIN_SNAP_PIXEL_RADIUS,
            )
            if not inside_entry:
                reentry_armed.add(key)
                return False
            if key not in reentry_armed:
                return False
            reentry_armed.discard(key)
            releasing.discard(key)
            _state.setdefault("pin_snap_departing", set()).discard(key)
            _surface_contact_set_snap_detached(guide, False)
    operator_name = str(
        _state.get("pin_snap_transform_operator", "")
    ).lower()
    rotating = "rotate" in operator_name
    socket_locked_transform = bool(
        rotating or "resize" in operator_name or "scale" in operator_name
    )
    initial_hold = False
    transform_hold = bool(key in initial or key in engaged)
    if transform_hold and not socket_locked_transform:
        native_translate = _pin_native_translate_vector(context)
        translate_origin = (
            Vector((0.0, 0.0, 0.0))
            if key in initial
            else _state.setdefault(
                "pin_snap_engage_translate_origins", {}
            ).get(key)
        )
        native_translate_distance = (
            (native_translate - Vector(translate_origin)).length
            if native_translate is not None and translate_origin is not None
            else None
        )
        anchor_origin = _state.setdefault(
            "pin_snap_engage_anchor_origins", {}
        ).get(key)
        raw_anchor_delta = (
            raw_anchor - Vector(anchor_origin)
            if anchor_origin is not None
            else None
        )
        raw_anchor_distance = (
            raw_anchor_delta.length
            if raw_anchor_delta is not None
            else None
        )
        release_world = (
            PIN_SNAP_WORLD_RADIUS
            * PIN_SNAP_RELEASE_PIXEL_RADIUS
            / max(1.0, PIN_SNAP_PIXEL_RADIUS)
        )
        # Contact solving puts the visible endpoint back on its pin after
        # every modal sample. Measuring that corrected endpoint made release
        # random: one frame saw Blender's raw pull, the next saw the solved
        # dot overlap. Blender's own G/gizmo delta is the stable user intent.
        # Keep the geometric fallback for hosts/operators that do not expose
        # the native delta RNA.
        surface_normal = Vector(_normal)
        if surface_normal.length_squared > 1.0e-12:
            surface_normal.normalize()
        raw_sample_available = key in _state.get(
            "pin_snap_raw_anchor_samples", {}
        )
        if (
            raw_sample_available
            and raw_anchor_delta is not None
            and surface_normal.length_squared > 1.0e-12
        ):
            # A Contact is a ball joint while attached. Tangential movement
            # rolls around the dot; only a pull away from the contacted face
            # releases it. Measuring the corrected endpoint made upward
            # release look motionless and allowed sideways motion to leak
            # into the detached surface-sliding branch.
            outward_pull = raw_anchor_delta.dot(surface_normal)
            close = outward_pull <= release_world
        else:
            close = (
                native_translate_distance <= release_world
                if native_translate_distance is not None
                else (
                    raw_anchor_distance <= release_world
                    if raw_anchor_distance is not None
                    else _pin_points_within_snap_radius(
                        context,
                        target,
                        anchor,
                        pixel_radius=PIN_SNAP_RELEASE_PIXEL_RADIUS,
                    )
                )
            )
        if not close:
            if (
                not raw_sample_available
                and native_translate_distance is None
                and surface_normal.length_squared > 1.0e-12
            ):
                # Distance caused by pressure into the contacted plane is not
                # a pull-out, but pressure must not make every sideways pull
                # impossible. Keep the latch only while the raw endpoint is
                # still close to the target along the surface. Once the
                # sideways part crosses the same release band used elsewhere,
                # it is an intentional pull-out even if it is also slightly
                # below a floor/wall plane.
                offset = raw_anchor - Vector(target)
                signed_normal = offset.dot(surface_normal)
                tangent = offset - surface_normal * signed_normal
                if (
                    signed_normal < 0.0
                    and tangent.length <= release_world
                ):
                    close = True
        if not close:
            # A direct pull-out is a real attachment-state edit, not merely a
            # transient solver branch. Register it for mouse-up finalization
            # before setting the runtime latch so an existing attached
            # F-curve cannot restore Contact before the next ancestor G/R/S.
            _state.setdefault("pin_snap_initial_detached", {}).setdefault(
                key,
                bool(
                    _surface_contact_animated_detached_state(
                        guide,
                        int(context.scene.frame_current),
                    )
                    or guide.get(
                        SURFACE_CONTACT_DETACHED_PROPERTY,
                        False,
                    )
                ),
            )
            _state.setdefault("pin_snap_transform_seen", set()).add(key)
            releasing.add(key)
            _state.setdefault(
                "pin_snap_release_reentry_armed", set()
            ).discard(key)
            _surface_contact_set_snap_detached(guide, True)
            _state.setdefault("pin_snap_latches", set()).discard(key)
            _state.setdefault("pin_snap_swept_hits", set()).discard(key)
            _state.setdefault("pin_snap_previous_points", {})[key] = (
                raw_anchor.copy()
            )
            return False
        # Carry the wider release-band/pressure decision into the final snap
        # arbitration below. Previously `close` was recomputed from the small
        # entry radius, silently discarding this result. That is why a planted
        # limb could flicker free while being pushed into its pin and why the
        # first G behaved differently from the next one.
        initial_hold = True
    close = bool(
        initial_hold
        or (socket_locked_transform and key in initial)
        or (socket_locked_transform and key in engaged)
        or _pin_snap_should_engage(
            context,
            key,
            target,
            anchor,
            use_hysteresis=use_snap_hysteresis,
        )
    )
    if not close:
        return False
    if (
        _state.get("pin_snap_transform_active", False)
        and key not in initial
    ):
        if key not in engaged:
            native_translate = _pin_native_translate_vector(context)
            if native_translate is not None:
                _state.setdefault(
                    "pin_snap_engage_translate_origins", {}
                )[key] = native_translate.copy()
            _state.setdefault(
                "pin_snap_engage_anchor_origins", {}
            )[key] = raw_anchor.copy()
        engaged.add(key)
    _surface_contact_clear_snap_departure(guide)
    _state.setdefault("pin_snap_latches", set()).add(key)
    return True


def _surface_contact_capture_transform_start_pose(guide):
    """Capture every contact-owned pose that native G/R/S can influence."""
    armature, pose_bone = _surface_contact_pose_bone(guide)
    if armature is None or pose_bone is None:
        return False
    key = (_armature_session_uid(armature), pose_bone.name)
    snapshots = _state.setdefault(
        "pin_snap_contact_transform_start_poses", {}
    )
    baseline = _state.get("pin_snap_transform_capture_baseline", {}).get(key)
    snapshots.setdefault(
        key,
        baseline if baseline is not None else (
            armature.name, pose_bone.name,
            pose_bone.matrix_basis.copy(), pose_bone.matrix.copy(),
        ),
    )
    return True


def _surface_contact_capture_transform_scope(
    context, guide, armature, selected_names
):
    """Capture a direct/ancestor-driven guide and report both scope kinds."""
    direct = bool(
        selected_names
        and _surface_contact_direct_bone_names(guide) & selected_names
    )
    parent_driven = bool(
        selected_names
        and _surface_contact_selected_bones_drive_guide(
            armature, guide, selected_names
        )
    )
    if direct or parent_driven:
        _surface_contact_capture_transform_start_pose(guide)
    return direct, parent_driven


def _surface_contact_restore_transform_start_poses(context):
    """Atomically roll back contact corrections when native G/R/S cancels."""
    changed = False
    for snapshot in tuple(
        _state.get("pin_snap_contact_transform_start_poses", {}).values()
    ):
        armature_name, bone_name, matrix_basis = snapshot[:3]
        armature = bpy.data.objects.get(str(armature_name))
        pose_bone = (
            armature.pose.bones.get(str(bone_name))
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is None:
            continue
        if _pin_keyboard_matrices_differ(
            pose_bone.matrix_basis,
            matrix_basis,
        ):
            pose_bone.matrix_basis = matrix_basis.copy()
            changed = True
    if changed:
        context.view_layer.update()
    return changed


def _surface_contact_restore_transform_start_pose(context, guide):
    """Restore one contact owner to this modal transform's exact baseline."""
    armature, pose_bone = _surface_contact_pose_bone(guide)
    if armature is None or pose_bone is None:
        return False
    snapshot = _state.get(
        "pin_snap_contact_transform_start_poses",
        {},
    ).get((_armature_session_uid(armature), pose_bone.name))
    if (
        snapshot is None
        or not _pin_keyboard_matrices_differ(
            pose_bone.matrix_basis,
            snapshot[2],
        )
    ):
        return False
    pose_bone.matrix_basis = snapshot[2].copy()
    context.view_layer.update()
    return True


def _surface_contact_aim_detached_simulated_pose(
    context, guide, *, preserve_current_roll=False
):
    """Aim a detached Smart contact without translating its owner bone."""
    if not _surface_contact_preserves_rigid_orientation(guide):
        return False
    armature, pose_bone = _surface_contact_pose_bone(guide)
    target, _normal, anchor = _surface_contact_world_point_normal(
        context, guide
    )
    if (
        armature is None
        or pose_bone is None
        or target is None
        or anchor is None
    ):
        return False
    return _surface_contact_rotate_simulated_pose_toward(
        context,
        guide,
        armature,
        pose_bone,
        anchor,
        target,
        stabilize_smart_roll=not preserve_current_roll,
    )


def _surface_contact_settle_detached_smart(context, guide):
    """Return None for legacy pins, otherwise settle/store rotate-only aim."""
    if not _surface_contact_preserves_rigid_orientation(guide):
        return None
    changed = _surface_contact_aim_detached_simulated_pose(context, guide)
    _surface_contact_store_valid_pose(guide)
    return changed


def _surface_contact_stabilize_smart_roll(
    context, guide, rotation, target_direction
):
    """Remove Smart-object roll drift while preserving exact ray alignment."""
    smart_object = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_SMART_OBJECT_PROPERTY, ""))
    )
    if smart_object is None:
        return rotation
    try:
        evaluated = smart_object.evaluated_get(
            context.evaluated_depsgraph_get()
        )
        object_basis = evaluated.matrix_world.to_3x3()
        target_direction = Vector(target_direction).normalized()
        guide_basis = guide.matrix_world.to_3x3().normalized()
        saved_roll = guide.get(SURFACE_CONTACT_SMART_ROLL_PROPERTY)
        if saved_roll is not None and len(saved_roll) >= 6:
            local_roll = Vector(tuple(float(value) for value in saved_roll[:3]))
            guide_roll = Vector(tuple(float(value) for value in saved_roll[3:6]))
        else:
            cast_axis = _surface_contact_axis_vector(
                guide.get(SURFACE_CONTACT_CAST_AXIS_PROPERTY, "Y_NEG")
            )
            candidates = tuple(
                axis
                for axis in (
                    Vector((1.0, 0.0, 0.0)),
                    Vector((0.0, 1.0, 0.0)),
                    Vector((0.0, 0.0, 1.0)),
                )
                if abs(axis.dot(cast_axis)) < 0.5
            )
            # Guide X/Y are the contacted plane's tangents. Never pair the
            # welded box's roll axis with guide Z (the surface normal): after
            # projection that vector degenerates and leaves a visible tilt.
            guide_axes = (
                Vector((1.0, 0.0, 0.0)),
                Vector((0.0, 1.0, 0.0)),
            )
            local_roll, guide_roll = max(
                (
                    (object_axis, guide_axis)
                    for object_axis in candidates
                    for guide_axis in guide_axes
                ),
                key=lambda pair: abs(
                    (
                        object_basis @ pair[0]
                    ).normalized().dot(
                        (guide_basis @ pair[1]).normalized()
                    )
                )
            )
            if (object_basis @ local_roll).dot(
                guide_basis @ guide_roll
            ) < 0.0:
                guide_roll.negate()
            guide[SURFACE_CONTACT_SMART_ROLL_PROPERTY] = (
                *tuple(local_roll), *tuple(guide_roll)
            )
        swung_roll = rotation @ (object_basis @ local_roll)
        desired_roll = guide_basis @ guide_roll
        swung_roll -= target_direction * swung_roll.dot(target_direction)
        desired_roll -= target_direction * desired_roll.dot(target_direction)
        frame_key = _surface_contact_pose_cache_key(guide)
        frames = _state.setdefault("surface_contact_roll_frames", {})
        previous_frame = frames.get(frame_key)
        transported_roll = None
        if previous_frame is not None:
            previous_target = Vector(previous_frame["target"]).normalized()
            previous_roll = Vector(previous_frame["roll"]).normalized()
            dot = max(
                -1.0,
                min(1.0, previous_target.dot(target_direction)),
            )
            cross = previous_target.cross(target_direction)
            if cross.length_squared > 1.0e-12:
                transport = Quaternion(
                    cross.normalized(),
                    math.acos(dot),
                )
            elif dot < 0.0:
                transport_axis = previous_roll.copy()
                transport_axis -= (
                    previous_target
                    * transport_axis.dot(previous_target)
                )
                if transport_axis.length_squared <= 1.0e-12:
                    transport_axis = previous_target.orthogonal()
                transport = Quaternion(
                    transport_axis.normalized(),
                    math.pi,
                )
            else:
                transport = Quaternion()
            transported_roll = transport @ previous_roll
            transported_roll -= (
                target_direction
                * transported_roll.dot(target_direction)
            )
            if transported_roll.length_squared <= 1.0e-12:
                transported_roll = None
            else:
                transported_roll.normalize()
        if desired_roll.length_squared <= 1.0e-10:
            # The static surface tangent is parallel to the aim direction.
            # Its projection has no sign here and reverses after the crossing;
            # parallel transport supplies the unique continuous roll instead.
            desired_roll = (
                transported_roll.copy()
                if transported_roll is not None
                else (
                    swung_roll.normalized()
                    if swung_roll.length_squared > 1.0e-10
                    else target_direction.orthogonal().normalized()
                )
            )
        else:
            desired_roll.normalize()
            reference = (
                transported_roll
                if transported_roll is not None
                else (
                    swung_roll
                    if swung_roll.length_squared > 1.0e-10
                    else desired_roll
                )
            )
            if desired_roll.dot(reference) < 0.0:
                desired_roll.negate()
        frames[frame_key] = {
            "target": target_direction.copy(),
            "roll": desired_roll.copy(),
        }
        if swung_roll.length_squared <= 1.0e-10:
            # Roll is undefined for this exact sample. The shortest-arc aim is
            # already continuous; retaining the transported frame makes the
            # next non-degenerate sample resume without a sideways flip.
            return rotation
        swung_roll.normalize()
        twist_angle = math.atan2(
            target_direction.dot(swung_roll.cross(desired_roll)),
            max(-1.0, min(1.0, swung_roll.dot(desired_roll))),
        )
        interactive = bool(
            _state.get("pin_snap_transform_active", False)
            or _state.get("pin_keyboard_transform_active", False)
            or _state.get("pin_target_dragging", False)
        )
        if not interactive:
            remaining = max(
                0.0,
                SURFACE_CONTACT_MAX_AIM_STEP - min(
                    SURFACE_CONTACT_MAX_AIM_STEP, abs(float(rotation.angle))
                ),
            )
            twist_angle = max(-remaining, min(remaining, twist_angle))
        if abs(twist_angle) <= 1.0e-7:
            return rotation
        return Quaternion(target_direction, twist_angle) @ rotation
    except (
        AttributeError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ):
        return rotation


def _surface_contact_record_native_transform_history(context):
    """Pair native selected-bone history with its externally solved contacts."""
    # This record describes the most recently completed native pose transform,
    # not the most recent transform that happened to touch Contact.  Clearing
    # it up front is essential: otherwise an unrelated bone move leaves an old
    # parent/contact pair armed, and its next Undo/Redo evaluation can write
    # that stale pink pose again.
    _state["pin_snap_native_history_transition"] = None
    selected = []
    for (owner_uid, bone_name), before in _state.get(
        "pin_snap_transform_start_poses", {}
    ).items():
        armature = next(
            (
                obj
                for obj in tuple(context.scene.objects)
                if obj.type == "ARMATURE"
                and _armature_session_uid(obj) == owner_uid
            ),
            None,
        )
        pose_bone = (
            armature.pose.bones.get(bone_name)
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is not None:
            selected.append(
                (
                    armature.name,
                    bone_name,
                    before.copy(),
                    pose_bone.matrix_basis.copy(),
                )
            )
    contact_starts = _state.get(
        "pin_snap_contact_transform_start_poses", {}
    )
    live_poses = _state.get("pin_snap_live_pose_matrices", {})
    contacts = []
    attachments = []
    for guide in _surface_contact_active_simulated_guides(context.scene):
        armature, pose_bone = _surface_contact_pose_bone(guide)
        if armature is None or pose_bone is None:
            continue
        pose_key = (_armature_session_uid(armature), pose_bone.name)
        start = contact_starts.get(pose_key)
        if start is not None:
            # Finalization has already restored and evaluated the last live
            # preview. Capture that authoritative post-commit basis rather
            # than the earlier preview tuple, whose parent evaluation can be
            # one dependency-graph sample behind.
            after = pose_bone.matrix_basis.copy()
            if not _pin_keyboard_matrices_differ(
                start[2],
                after,
                epsilon=1.0e-6,
            ):
                # A detached child following an ancestor keeps the same local
                # basis and therefore owns no part of that history step.
                continue
            contacts.append(
                (
                    (_armature_session_uid(armature), guide.name),
                    armature.name,
                    pose_bone.name,
                    start[2].copy(),
                    after,
                )
            )
            snap_key = _surface_contact_snap_key(guide)
            attachments.append((
                (_armature_session_uid(armature), guide.name),
                bool(
                    snap_key in _state.setdefault(
                        "pin_snap_initial_latches", set()
                    )
                ),
                bool(
                    snap_key not in _state.setdefault(
                        "pin_snap_detached", set()
                    )
                    and snap_key not in _state.setdefault(
                        "pin_snap_transform_releasing", set()
                    )
                ),
            ))
    if selected and contacts:
        _state["pin_snap_native_history_transition"] = {
            "selected": tuple(selected),
            "contacts": tuple(contacts),
            "attachments": tuple(attachments),
            "visual_poses": _surface_contact_capture_history_visuals(
                context, contact_starts, live_poses,
            ),
        }

def _surface_contact_prepare_native_history_transition(context):
    """Remember Undo/Redo direction before other history handlers evaluate."""
    transition = _state.get("pin_snap_native_history_transition")
    _state["pin_snap_native_history_expected_index"] = None
    _state["pin_snap_native_history_pre_selected"] = {}
    if not transition:
        return False
    pre_selected = {}
    for armature_name, bone_name, _before, _after in transition["selected"]:
        armature = bpy.data.objects.get(armature_name)
        pose_bone = (
            armature.pose.bones.get(bone_name)
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is not None:
            pre_selected[(armature_name, bone_name)] = (
                pose_bone.matrix_basis.copy()
            )
    _state["pin_snap_native_history_pre_selected"] = pre_selected
    direction = str(_state.get("pin_history_direction", ""))
    if direction in {"UNDO", "REDO"}:
        _state["pin_snap_native_history_expected_index"] = 0 if direction == "UNDO" else 1
        return True
    selected_entries = tuple(transition["selected"])
    selected_sides = tuple(
        index
        for index in (0, 1)
        if _surface_contact_history_side_matches(selected_entries, index)
    )
    if len(selected_sides) == 1:
        current_index = selected_sides[0]
    else:
        matching_sides = tuple(
            index
            for index in selected_sides
            if _surface_contact_history_side_matches(
                transition["contacts"],
                index,
            )
        )
        current_index = matching_sides[0] if len(matching_sides) == 1 else None
    if current_index is None:
        return False
    _state["pin_snap_native_history_expected_index"] = 1 - current_index
    return True
def _surface_contact_restore_native_history_transition(
    context, previous_snapshot
):
    """Handle the matched side, restoring contact bones only when needed."""
    transition = _state.get("pin_snap_native_history_transition")
    if not transition:
        return False

    # A retained transition may outlive the next unrelated edit. Redo used to
    # restore its pink pose whenever the old driver merely still matched the
    # transition's "after" side, even if that driver did not participate in
    # this history step. Require an actual before/post change in at least one
    # transition-owned driver bone before this transition may write contacts.
    pre_selected = dict(
        _state.get("pin_snap_native_history_pre_selected", {})
    )
    if pre_selected:
        driver_changed = False
        for (armature_name, bone_name), previous in pre_selected.items():
            armature = bpy.data.objects.get(armature_name)
            pose_bone = (
                armature.pose.bones.get(bone_name)
                if armature is not None and getattr(armature, "pose", None)
                else None
            )
            if (
                pose_bone is not None
                and _pin_keyboard_matrices_differ(
                    pose_bone.matrix_basis,
                    previous,
                    epsilon=1.0e-6,
                )
            ):
                driver_changed = True
                break
        if not driver_changed:
            return False

    previous_poses = dict((previous_snapshot or {}).get("poses", {}))

    def matrix_matches(matrix, expected):
        return not _pin_keyboard_matrices_differ(
            matrix, expected, epsilon=1.0e-6
        )

    def selected_matches(index):
        for armature_name, bone_name, before, after in transition["selected"]:
            armature = bpy.data.objects.get(armature_name)
            pose_bone = (
                armature.pose.bones.get(bone_name)
                if armature is not None and getattr(armature, "pose", None)
                else None
            )
            expected = before if index == 0 else after
            if pose_bone is None or not matrix_matches(
                pose_bone.matrix_basis, expected
            ):
                return False
        return True

    def previous_contacts_match(index):
        for owner_key, _armature_name, _bone_name, before, after in (
            transition["contacts"]
        ):
            signature = previous_poses.get(owner_key)
            expected = before if index == 0 else after
            if signature is None or any(
                abs(float(signature[(row * 4) + column])
                    - float(expected[row][column])) > 1.0e-6
                for row in range(4)
                for column in range(4)
            ):
                return False
        return True

    restore_index = _state.get("pin_snap_native_history_expected_index")
    if restore_index not in (0, 1) or not selected_matches(restore_index):
        restore_index = None
    if restore_index is None and selected_matches(0) and previous_contacts_match(1):
        restore_index = 0
    elif selected_matches(1) and previous_contacts_match(0):
        restore_index = 1
    if restore_index is None:
        return False

    _surface_contact_set_history_pose_lock(transition, restore_index)
    _surface_contact_apply_history_pose_lock(
        context,
        update_view_layer=False,
    )
    # Runtime snap sets are intentionally outside Blender's ID history. Pair
    # them with the exact contact pose so Undo/Redo cannot briefly restore the
    # right limb matrix while leaving it in the opposite attach state.
    for owner_key, before_attached, after_attached in transition.get(
        "attachments", ()
    ):
        guide = bpy.data.objects.get(str(owner_key[1]))
        if guide is None:
            continue
        if bool(before_attached if restore_index == 0 else after_attached):
            _surface_contact_clear_snap_departure(guide)
        else:
            snap_key = _surface_contact_snap_key(guide)
            _surface_contact_set_snap_detached(guide, True)
            _state.setdefault("pin_snap_latches", set()).discard(snap_key)
    # This return reports that the transition side was recognized and fully
    # handled, not whether a matrix assignment happened. Blender can restore
    # the correct pink pose itself; treating that no-op as failure lets the
    # generic fallback overwrite the correct Redo pose one evaluation later.
    return True
