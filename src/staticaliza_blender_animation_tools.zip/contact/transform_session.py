"""Authoritative live-pose snapshots for native contact transforms."""
from ..core.runtime import *  # noqa: F403


def _surface_contact_capture_live_update_poses():
    """Hand exact visible Contact poses across a module replacement.

    Driver namespace data survives an extension module reload but is outside
    Blender's undoable ID graph. It therefore cannot be replaced by a stale
    saved custom property or create a hidden Undo checkpoint.
    """
    snapshots = {}
    for guide in tuple(_surface_contact_guides()):
        armature = bpy.data.objects.get(str(
            guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, "")
        ))
        pose_bone = _surface_contact_simulated_pose_bone(guide)
        if armature is None or pose_bone is None:
            continue
        snapshots[(armature.name, pose_bone.name)] = {
            "basis": tuple(
                float(value)
                for row in pose_bone.matrix_basis
                for value in row
            ),
            # matrix_basis alone is insufficient when Dynamic Parent or
            # another pose constraint contributes to the visible output.
            # Preserve that evaluated armature-space matrix too so package
            # replacement cannot recompose the limb to a different pose.
            "visual": tuple(
                float(value)
                for row in pose_bone.matrix
                for value in row
            ),
        }
    try:
        bpy.app.driver_namespace[
            SURFACE_CONTACT_LIVE_UPDATE_POSES_KEY
        ] = snapshots
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        return False
    return bool(snapshots)


def _surface_contact_restore_live_update_poses(context):
    """Consume the pre-unregister pose handoff without solving Contact."""
    try:
        snapshots = bpy.app.driver_namespace.pop(
            SURFACE_CONTACT_LIVE_UPDATE_POSES_KEY,
            {},
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        snapshots = {}
    changed = False
    visual_sides = []
    for (armature_name, bone_name), packed_state in dict(snapshots).items():
        armature = bpy.data.objects.get(str(armature_name))
        pose_bone = (
            armature.pose.bones.get(str(bone_name))
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        packed = (
            packed_state.get("basis", ())
            if isinstance(packed_state, dict)
            else packed_state
        )
        packed_visual = (
            packed_state.get("visual", ())
            if isinstance(packed_state, dict)
            else ()
        )
        if pose_bone is None or len(packed) != 16:
            continue
        matrix_basis = Matrix(tuple(
            tuple(
                float(packed[(row * 4) + column])
                for column in range(4)
            )
            for row in range(4)
        ))
        if _pin_keyboard_matrices_differ(
            pose_bone.matrix_basis,
            matrix_basis,
        ):
            pose_bone.matrix_basis = matrix_basis
            changed = True
        if len(packed_visual) == 16:
            visual_sides.append((
                str(armature_name),
                str(bone_name),
                Matrix(tuple(
                    tuple(
                        float(packed_visual[(row * 4) + column])
                        for column in range(4)
                    )
                    for row in range(4)
                )),
            ))
    if changed:
        context.view_layer.update()
    for armature_name, bone_name, visual_matrix in visual_sides:
        armature = bpy.data.objects.get(armature_name)
        pose_bone = (
            armature.pose.bones.get(bone_name)
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if (
            pose_bone is not None
            and _pin_keyboard_matrices_differ(
                pose_bone.matrix,
                visual_matrix,
            )
        ):
            _set_pose_bone_constrained_output_matrix(
                context,
                armature,
                pose_bone,
                visual_matrix,
                atomic=True,
            )
            changed = True
    return bool(snapshots)

def _surface_contact_store_persistent_pose_snapshots(
    guides = None,
    only_missing = False,
):
    """Persist current simulated poses across file and extension reloads."""
    changed = False
    for guide in tuple(guides if guides is not None else _surface_contact_guides()):
        pose_bone = _surface_contact_simulated_pose_bone(guide)
        if pose_bone is None:
            continue
        if (
            only_missing
            and SURFACE_CONTACT_SAVED_POSE_PROPERTY in guide
        ):
            continue
        packed = tuple(
            float(value)
            for row in pose_bone.matrix_basis
            for value in row
        )
        if tuple(
            pose_bone.get(SURFACE_CONTACT_SAVED_POSE_PROPERTY, ())
        ) != packed:
            pose_bone[SURFACE_CONTACT_SAVED_POSE_PROPERTY] = packed
            changed = True
        if tuple(guide.get(SURFACE_CONTACT_SAVED_POSE_PROPERTY, ())) != packed:
            guide[SURFACE_CONTACT_SAVED_POSE_PROPERTY] = packed
            changed = True
    return changed


def _surface_contact_clear_orphaned_pose_snapshots():
    """Remove saved Contact poses from bones that no Contact guide owns."""
    owned_pose_keys = set()
    for guide in _surface_contact_guides():
        armature = bpy.data.objects.get(
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
        )
        pose_bone = _surface_contact_simulated_pose_bone(guide)
        if armature is not None and pose_bone is not None:
            owned_pose_keys.add(
                (_armature_session_uid(armature), pose_bone.name)
            )
    changed = False
    for armature in tuple(bpy.data.objects):
        if (
            armature.type != "ARMATURE"
            or getattr(armature, "pose", None) is None
        ):
            continue
        owner_uid = _armature_session_uid(armature)
        for pose_bone in armature.pose.bones:
            if (
                SURFACE_CONTACT_SAVED_POSE_PROPERTY in pose_bone
                and (owner_uid, pose_bone.name) not in owned_pose_keys
            ):
                del pose_bone[SURFACE_CONTACT_SAVED_POSE_PROPERTY]
                changed = True
    return changed


def _surface_contact_restore_persistent_pose_snapshots(
    context,
    guides = None,
    update_view_layer = True,
):
    """Restore the exact saved local pose without running a contact solve."""
    restored_bones = set()
    changed = False
    for guide in tuple(guides if guides is not None else _surface_contact_guides()):
        pose_bone = _surface_contact_simulated_pose_bone(guide)
        packed = (
            pose_bone.get(SURFACE_CONTACT_SAVED_POSE_PROPERTY)
            if pose_bone is not None
            else None
        ) or guide.get(SURFACE_CONTACT_SAVED_POSE_PROPERTY)
        if pose_bone is None or packed is None or len(packed) != 16:
            continue
        armature = bpy.data.objects.get(
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
        )
        key = (_armature_session_uid(armature), pose_bone.name)
        if key in restored_bones:
            continue
        restored_bones.add(key)
        matrix_basis = Matrix(
            tuple(
                tuple(float(packed[(row * 4) + column]) for column in range(4))
                for row in range(4)
            )
        )
        if _pin_keyboard_matrices_differ(
            pose_bone.matrix_basis,
            matrix_basis,
        ):
            pose_bone.matrix_basis = matrix_basis
            changed = True
    if changed and update_view_layer and context is not None:
        context.view_layer.update()
    return changed
def _surface_contact_restore_native_saved_history(context, transition):
    """Restore Blender-owned modal pose properties before runtime fallbacks."""
    changed = False
    restored = set()
    for entry in tuple((transition or {}).get("contacts", ())):
        armature = bpy.data.objects.get(str(entry[1]))
        pose_bone = (
            armature.pose.bones.get(str(entry[2]))
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is None:
            continue
        owner = (armature.name, pose_bone.name)
        if owner in restored:
            continue
        restored.add(owner)
        packed = pose_bone.get(SURFACE_CONTACT_SAVED_POSE_PROPERTY)
        if packed is None or len(packed) != 16:
            continue
        expected = Matrix(tuple(
            tuple(
                float(packed[(row * 4) + column])
                for column in range(4)
            )
            for row in range(4)
        ))
        if _pin_keyboard_matrices_differ(
            pose_bone.matrix_basis,
            expected,
        ):
            pose_bone.matrix_basis = expected
            changed = True
    if changed:
        context.view_layer.update()
    return changed


def _surface_contact_clear_live_pose_session():
    _state["pin_snap_live_pose_matrices"] = {}
    _state["pin_snap_live_pose_dirty_guides"] = set()
    _state["pin_snap_raw_pose_matrices"] = {}
    _state["pin_snap_raw_basis_matrices"] = {}
    _state["pin_snap_native_after_poses"] = {}
def _pin_cache_idle_transform_poses(context):
    """Cache the pose before Blender emits the first native transform sample."""
    if (
        context is None
        or getattr(context, "mode", "") != "POSE"
        or _state.get("pin_snap_transform_active", False)
        or _state.get("pin_keyboard_transform_active", False)
    ):
        return False
    selected = {}
    for armature, pose_bones in _selected_pose_bones_by_owner(context).items():
        owner_uid = _armature_session_uid(armature)
        for pose_bone in pose_bones:
            selected[(owner_uid, pose_bone.name)] = (
                pose_bone.matrix_basis.copy()
            )
    contacts = {}
    for guide in _surface_contact_active_simulated_guides(context.scene):
        armature, pose_bone = _surface_contact_pose_bone(guide)
        if armature is None or pose_bone is None:
            continue
        key = (_armature_session_uid(armature), pose_bone.name)
        contacts[key] = (
            armature.name,
            pose_bone.name,
            pose_bone.matrix_basis.copy(),
            pose_bone.matrix.copy(),
        )
    _state["pin_snap_idle_transform_poses"] = {
        "signature": tuple(sorted(selected)),
        "selected": selected,
        "contacts": contacts,
    }
    return True
def _pin_prepare_transform_pose_baseline(grouped):
    """Use the last idle pose only when it matches the current selection."""
    keys = tuple(sorted(
        (_armature_session_uid(armature), pose_bone.name)
        for armature, pose_bones in grouped.items()
        for pose_bone in pose_bones
    ))
    cached = _state.get("pin_snap_idle_transform_poses", {})
    valid = bool(keys and tuple(cached.get("signature", ())) == keys)
    cached_selected = cached.get("selected", {}) if valid else {}
    # A changed selected basis means Blender's first native G/R/S sample
    # reached depsgraph before we noticed the modal operator. Only that case
    # needs the pre-sample idle contact pose; if the selected basis is still
    # unchanged, the live contact pose is the exact operation baseline.
    sample_already_applied = bool(
        valid
        and any(
            _pin_keyboard_matrices_differ(
                pose_bone.matrix_basis,
                cached_selected.get(
                    (_armature_session_uid(armature), pose_bone.name),
                    pose_bone.matrix_basis,
                ),
            )
            for armature, pose_bones in grouped.items()
            for pose_bone in pose_bones
        )
    )
    _state["pin_snap_transform_baseline_precedes_sample"] = (
        sample_already_applied
    )
    _state["pin_snap_transform_capture_baseline"] = (
        dict(cached.get("contacts", {}))
        if sample_already_applied
        else {}
    )
    # The idle snapshot is a rollback baseline only when Blender has already
    # advanced the selected pose before the modal watcher saw G/R/S.  Using it
    # for an untouched transform start reintroduces an older ancestor-driven
    # Contact pose and makes one Undo skip multiple visible operations.
    return dict(cached_selected) if sample_already_applied else {}
def _surface_contact_capture_live_pose(guide):
    """Remember exactly what the user sees after the latest live solve."""

    armature, pose_bone = _surface_contact_pose_bone(guide)
    if armature is None or pose_bone is None:
        return False
    key = (_armature_session_uid(armature), pose_bone.name)
    _state.setdefault("pin_snap_live_pose_matrices", {})[key] = (
        armature.name,
        pose_bone.name,
        pose_bone.matrix_basis.copy(),
        pose_bone.matrix.copy(),
    )
    # ID-property writes trigger dependency and undo bookkeeping. Never do
    # them inside interactive G/R/S or pin dragging; keep those previews in
    # runtime memory and persist once at commit. Non-modal dependency/history
    # reconciliation still writes immediately so Blender's Undo/Redo snapshot
    # owns the complete pose rather than a stale or missing saved value.
    interactive = bool(
        _state.get("pin_snap_transform_active", False)
        or _state.get("pin_keyboard_transform_active", False)
        or _state.get("pin_target_dragging", False)
    )
    history_restore = bool(
        _state.get("pin_history_active", False)
        or _state.get("pin_history_syncing", False)
    )
    if interactive:
        _state.setdefault("pin_snap_live_pose_dirty_guides", set()).add(
            guide.name
        )
    elif not history_restore:
        _surface_contact_store_persistent_pose_snapshots((guide,))
        _state.setdefault("pin_snap_live_pose_dirty_guides", set()).discard(
            guide.name
        )
    return True


def _surface_contact_flush_live_pose_snapshots():
    """Persist the final visible modal pose once, outside the mouse hot path."""
    dirty_names = set(
        _state.get("pin_snap_live_pose_dirty_guides", set())
    )
    if not dirty_names:
        return False
    guides = tuple(
        guide
        for guide in _surface_contact_guides()
        if guide.name in dirty_names
    )
    changed = _surface_contact_store_persistent_pose_snapshots(guides)
    _state["pin_snap_live_pose_dirty_guides"] = set()
    return changed


def _surface_contact_restore_live_poses(context):
    """Restore the final preview atomically after Blender commits G/R/S."""

    snapshots = tuple(
        _state.get("pin_snap_live_pose_matrices", {}).values()
    )
    changed = False
    for snapshot in snapshots:
        armature_name, bone_name, matrix_basis = snapshot[:3]
        armature = bpy.data.objects.get(str(armature_name))
        pose_bone = (
            armature.pose.bones.get(str(bone_name))
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is None:
            continue
        # matrix_basis is the authored value and the value Blender stores in
        # native pose history. Assigning the captured evaluated pose matrix
        # here makes Blender derive a second local basis after the parent has
        # committed, so Redo briefly shows the preview and then evaluates back
        # to the stale/straight basis.
        if _pin_keyboard_matrices_differ(
            pose_bone.matrix_basis,
            matrix_basis,
        ):
            pose_bone.matrix_basis = matrix_basis.copy()
            changed = True
    if changed:
        context.view_layer.update()
    return changed


def _surface_contact_clear_transform_start_poses():
    _state["pin_snap_contact_transform_start_poses"] = {}
    _state["pin_snap_frame_animated_states"] = {}
    _state["surface_contact_frame_settle_frame"] = None
    _state["pin_snap_transform_capture_baseline"] = {}
    _state["pin_snap_transform_baseline_precedes_sample"] = False
    _state["surface_contact_smart_aim_branches"] = {}
    _state["surface_contact_roll_frames"] = {}
    _state["pin_snap_initial_latches"] = set()
    _state["pin_snap_initial_attachment_states"] = {}
    _state["pin_snap_transform_engaged"] = set()
    _state["pin_snap_proximity_engaged"] = set()
    _state["pin_snap_engage_translate_origins"] = {}
    _state["pin_snap_engage_anchor_origins"] = {}
    _state["pin_snap_grip_directions"] = {}
    _state["pin_snap_raw_anchor_samples"] = {}
    _state["pin_snap_raw_pose_matrices"] = {}
    _state["pin_snap_raw_basis_matrices"] = {}
    _state["pin_snap_native_after_poses"] = {}
    _state["pin_snap_magnetic_anchor_samples"] = {}
    _state["pin_snap_magnetic_aim_anchor_samples"] = {}
    _state["pin_snap_magnetic_aim_pose_matrices"] = {}
    _state["pin_snap_pre_solve_anchor_samples"] = {}
    _state["pin_snap_transform_releasing"] = set()
    _state["pin_snap_release_reentry_armed"] = set()
    _state["pin_snap_release_anchor_origins"] = {}
    _state["pin_snap_pressure_tangents"] = {}
    _state["pin_snap_pressure_release_origins"] = {}
    _state["pin_snap_pressure_release_pose_matrices"] = {}
    _state["pin_snap_pressure_release_raw_translations"] = {}
    _state["pin_snap_transform_finalize_pending"] = None
    _state["pin_snap_contact_start_action_keys"] = {}
    _state["pin_snap_native_history_tokens"] = {}


def _surface_contact_pose_action_key_snapshot(armature, pose_bone, frame):
    """Capture the exact transform-key and FCurve state for one pose bone."""
    if armature is None or pose_bone is None:
        return None
    return _dynamic_parent_pose_key_snapshot(
        armature,
        pose_bone.name,
        float(frame),
    )


def _surface_contact_restore_action_key_snapshot(
    armature, pose_bone, frame, snapshot
):
    """Restore exact keys, handles, groups, and curve settings for one side."""
    del frame
    if armature is None or pose_bone is None or snapshot is None:
        return False
    return _dynamic_parent_restore_pose_key_snapshot(
        armature,
        pose_bone.name,
        snapshot,
    )



def _surface_contact_begin_native_transform(context):
    # A missing detach property is not proof that Contact is attached. Older
    # files still recover from the endpoints, while an explicit False value is
    # the persistent attached state represented by the outer ring. Runtime
    # detach remains newer authority during a just-finished direct pull-out,
    # before an older attached-state FCurve has finished evaluating.
    latches = _state.setdefault("pin_snap_latches", set())
    pressure_active = _state.setdefault("pin_snap_pressure_active", set())
    initial = set(latches)
    for guide in _surface_contact_active_snap_guides(context.scene):
        key = _surface_contact_snap_key(guide)
        target, _normal, anchor = _surface_contact_world_point_normal(
            context,
            guide,
        )
        pressure_supported = bool(
            key in pressure_active
            or _surface_contact_pressure_supported_pose(
                context,
                guide,
                target,
                _normal,
                anchor,
            )
        )
        if pressure_supported:
            pressure_active.add(key)
        geometrically_attached = bool(
            target is not None
            and anchor is not None
            and (
                (Vector(target) - Vector(anchor)).length
                <= PIN_SNAP_WORLD_RADIUS
                or pressure_supported
            )
        )
        animated_detached = _surface_contact_animated_detached_state(
            guide,
            int(context.scene.frame_current),
        )
        has_current_state = SURFACE_CONTACT_DETACHED_PROPERTY in guide
        current_detached = bool(
            guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)
        )
        runtime_detached = key in _state.setdefault(
            "pin_snap_detached", set()
        )
        if runtime_detached:
            pressure_active.discard(key)
            initial.discard(key)
            latches.discard(key)
            continue
        if key in initial:
            if geometrically_attached or key in pressure_active:
                initial.add(key)
                latches.add(key)
            else:
                initial.discard(key)
                latches.discard(key)
                _state.setdefault("pin_snap_detached", set()).add(key)
            continue
        if has_current_state:
            if current_detached or not geometrically_attached:
                initial.discard(key)
                latches.discard(key)
                if not geometrically_attached:
                    _state.setdefault("pin_snap_detached", set()).add(key)
            else:
                initial.add(key)
                latches.add(key)
            continue
        if animated_detached:
            initial.discard(key)
            latches.discard(key)
            continue
        if geometrically_attached:
            initial.add(key)
            latches.add(key)
    _state["pin_snap_initial_latches"] = initial
    frame = int(context.scene.frame_current)
    _state["pin_snap_initial_attachment_states"] = {
        _surface_contact_snap_key(guide): {
            "guide": guide.name,
            "latched": _surface_contact_snap_key(guide) in initial,
            "detached": _surface_contact_snap_key(guide) in _state.setdefault(
                "pin_snap_detached", set()
            ),
            "pressure_active": _surface_contact_snap_key(guide)
            in pressure_active,
            "had_property": SURFACE_CONTACT_DETACHED_PROPERTY in guide,
            "property": guide.get(SURFACE_CONTACT_DETACHED_PROPERTY),
            "detached_keys": _surface_contact_detached_key_snapshot(
                guide, frame
            ),
            "guide_matrix": guide.matrix_world.copy(),
            "guide_local_matrix": (
                tuple(float(value) for value in guide.get(
                    SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY,
                    (),
                ))
                if SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY in guide
                else None
            ),
            "constraints": _surface_contact_constraint_history_state(guide),
        }
        for guide in _surface_contact_active_snap_guides(context.scene)
    }
    start_action_keys = {}
    for guide in _surface_contact_active_simulated_guides(context.scene):
        armature, pose_bone = _surface_contact_pose_bone(guide)
        if armature is None or pose_bone is None:
            continue
        owner = (armature.name, pose_bone.name)
        start_action_keys.setdefault(
            owner,
            _surface_contact_pose_action_key_snapshot(
                armature,
                pose_bone,
                frame,
            ),
        )
    _state["pin_snap_contact_start_action_keys"] = start_action_keys
    # Do not mutate an armature ID property merely to identify this history
    # boundary. Blender can retain that mutation as a separate global Undo
    # entry, producing a pose-invisible blank step before the real transform.
    # The paired in-memory pose, attachment, Action-key and guide snapshots are
    # sufficient to recognize and restore both exact sides.
    _state["pin_snap_native_history_tokens"] = {}
    _state["pin_snap_transform_engaged"] = set()
    _state["pin_snap_proximity_engaged"] = set()
    _state["pin_snap_engage_translate_origins"] = {}
    anchor_origins = {}
    grip_directions = {}
    previous_points = _state.setdefault("pin_snap_previous_points", {})
    magnetic_points = _state.setdefault(
        "pin_snap_magnetic_anchor_samples", {}
    )
    aimed_points = _state.setdefault(
        "pin_snap_magnetic_aim_anchor_samples", {}
    )
    aimed_poses = _state.setdefault(
        "pin_snap_magnetic_aim_pose_matrices", {}
    )
    pre_solve_points = _state.setdefault(
        "pin_snap_pre_solve_anchor_samples", {}
    )
    for guide in _surface_contact_active_snap_guides(context.scene):
        key = _surface_contact_snap_key(guide)
        # Seed the sweep before Blender's first modal mouse sample. Without
        # this start point, a fast first move can jump from one side of the
        # target to the other while both sampled endpoints remain outside the
        # radius, so Contact misses the crossing and collision starts sliding.
        raw_start = _surface_contact_bone_anchor_world(
            context,
            guide,
            live_pose=True,
        )
        if raw_start is not None:
            previous_points[key] = Vector(raw_start).copy()
            magnetic_points[key] = Vector(raw_start).copy()
            aimed_points[key] = Vector(raw_start).copy()
            _armature, pose_bone = _surface_contact_pose_bone(guide)
            if pose_bone is not None:
                aimed_poses[key] = pose_bone.matrix_basis.copy()
            pre_solve_points[key] = Vector(raw_start).copy()
        if key not in initial:
            continue
        target, _normal, anchor = _surface_contact_world_point_normal(
            context,
            guide,
        )
        if target is not None and anchor is not None:
            anchor_origins[key] = Vector(anchor).copy()
            axis = _surface_contact_bone_axis_world(
                context,
                guide,
                live_pose=True,
            )
            if axis is not None:
                direction = Vector(axis[0]) - Vector(axis[1])
                if direction.length_squared > 1.0e-12:
                    grip_directions[key] = direction.normalized()
    _state["pin_snap_engage_anchor_origins"] = anchor_origins
    _state["pin_snap_grip_directions"] = grip_directions
    _state["pin_snap_raw_anchor_samples"] = {}
    _state["pin_snap_raw_pose_matrices"] = {}
    _state["pin_snap_raw_basis_matrices"] = {}
    _state["pin_snap_native_after_poses"] = {}
    _state["pin_snap_transform_releasing"] = set()
    _state["pin_snap_release_reentry_armed"] = set()
    _state["pin_snap_release_anchor_origins"] = {}
    _state["pin_snap_pressure_tangents"] = {}
    _state["pin_snap_pressure_release_origins"] = {}
    _state["pin_snap_pressure_release_pose_matrices"] = {}
    _state["pin_snap_pressure_release_raw_translations"] = {}
    _state["pin_snap_transform_finalize_pending"] = None


def _surface_contact_native_transform_ready(context):
    """Settle and commit on the first post-modal poll, before another redraw."""

    # Once Blender removes its native G/R/S operator the pose is authoritative.
    # The old fixed 20 ms delay exposed that raw post-operator pose for one or
    # more redraws before Contact restored the last solved preview, producing a
    # visible second movement after mouse-up/Enter. Force evaluation now and
    # finalize in this same timer callback instead of inventing another UI beat.
    _state["pin_snap_transform_finalize_pending"] = time.perf_counter()
    context.view_layer.update()
    return True


def _pin_transform_pose_differs_from_start(context):
    """Test the settled pose, ignoring the dirty flag latched during preview."""
    snapshots = _state.get("pin_snap_transform_start_poses", {})
    for armature in tuple(context.scene.objects):
        if armature.type != "ARMATURE" or getattr(armature, "pose", None) is None:
            continue
        owner_uid = _armature_session_uid(armature)
        for pose_bone in armature.pose.bones:
            initial = snapshots.get((owner_uid, pose_bone.name))
            if initial is not None and _pin_keyboard_matrices_differ(
                pose_bone.matrix_basis, initial, epsilon=1.0e-6
            ):
                return True
    return False


def _pin_snap_should_engage(
    context,
    snap_key,
    target,
    current,
    use_hysteresis=False,
    max_swept_endpoint_distance=None,
):
    """Shared stable snap arbitration for yellow and pink endpoints."""
    latches = _state.setdefault("pin_snap_latches", set())
    snap_key = str(snap_key)
    was_latched = snap_key in latches
    operator_name = str(
        _state.get("pin_snap_transform_operator", "")
    ).lower()
    rotating = "rotate" in operator_name
    socket_locked_transform = bool(
        rotating or "resize" in operator_name or "scale" in operator_name
    )
    transform_locked = bool(
        socket_locked_transform
        and (
            snap_key in _state.setdefault("pin_snap_initial_latches", set())
            or snap_key in _state.setdefault("pin_snap_transform_engaged", set())
        )
    )
    if transform_locked:
        latches.add(snap_key)
        return True
    radius = (
        PIN_SNAP_RELEASE_PIXEL_RADIUS
        if use_hysteresis and was_latched
        else PIN_SNAP_PIXEL_RADIUS
    )
    within = _pin_points_within_snap_radius(
        context, target, current, pixel_radius=radius
    )
    engaged = within
    if not was_latched:
        swept = _pin_snap_sample_with_sweep(
                target,
                current,
                snap_key,
                world_radius=PIN_SNAP_WORLD_RADIUS,
            )
        if (
            swept
            and max_swept_endpoint_distance is not None
            and (Vector(target) - Vector(current)).length
            > float(max_swept_endpoint_distance)
        ):
            swept = False
            _state.setdefault("pin_snap_swept_hits", set()).discard(
                snap_key
            )
        engaged = bool(
            swept or within
        )
    _state.setdefault("pin_snap_swept_hits", set()).discard(snap_key)
    if engaged:
        latches.add(snap_key)
        if rotating and _state.get("pin_snap_transform_active", False):
            _state.setdefault("pin_snap_transform_engaged", set()).add(
                snap_key
            )
    else:
        latches.discard(snap_key)
    return engaged


def _pin_native_translate_vector(context):
    """Return Blender's raw modal translation vector when it is available."""
    operator_name = str(
        _state.get("pin_snap_transform_operator", "")
    )
    if "translate" not in operator_name.lower():
        return None
    signature = _pin_transform_operator_delta_signature(
        context,
        operator_name,
    )
    if signature is None:
        return None
    values = tuple(float(component) for component in signature[1])
    while len(values) < 3:
        values += (0.0,)
    result = Vector(values[:3])
    if (
        result.length_squared <= 1.0e-14
        and not _state.get("pin_snap_transform_delta_observed", False)
    ):
        # Blender 5.2 can expose TRANSFORM_OT_translate.properties.value as a
        # permanent zero vector even while the selected pose and the visible
        # header delta continue changing. Treat that RNA field as unsupported
        # until it has produced one real non-zero sample. Pressure release can
        # then use the raw pose captured before Contact correction instead of
        # pinning every later mouse sample to a false zero origin.
        return None
    return result


def _surface_contact_direct_snap_close(
        context, guide, use_snap_hysteresis
):
    """Latch a newly reached Contact for the rest of its current transform."""
    # Custom pin drags and native bone transforms use different active flags,
    # but both are user-authored snap transitions and must be committed alike.
    if not _surface_contact_new_snap_allowed(context, guide):
        return False
    target, _normal, anchor = _surface_contact_world_point_normal(
        context, guide
    )
    if target is None or anchor is None:
        return False
    key = _surface_contact_snap_key(guide)
    if key in _state.setdefault(
        "pin_snap_pressure_release_session", set()
    ):
        # A top-roll release is terminal for this native transform. Re-entry
        # during the same drag made the limb alternate attached/detached and
        # stutter while its real endpoint remained outside the radius.
        return False
    raw_anchor = Vector(
        _state.setdefault("pin_snap_raw_anchor_samples", {}).get(
            key,
            anchor,
        )
    )
    initial = _state.setdefault("pin_snap_initial_latches", set())
    engaged = _state.setdefault("pin_snap_transform_engaged", set())
    releasing = _state.setdefault("pin_snap_transform_releasing", set())
    returned_from_release = False
    if key in releasing:
        # This function is called only for the directly edited pink bone. If
        # its real endpoint is already back inside the entry radius, accept
        # that deliberate placement immediately. Requiring an additional
        # release-band excursion made snap re-entry depend on the previous
        # transform history and caused the first snap attempt to be ignored.
        raw_reentry_close = bool(
            (Vector(target) - raw_anchor).length
            <= _surface_contact_settle_tolerance(guide)
            or _pin_points_within_snap_radius(
                context,
                target,
                raw_anchor,
                pixel_radius=PIN_SNAP_PIXEL_RADIUS,
            )
        )
        visible_reentry_close = bool(
            (Vector(target) - Vector(anchor)).length
            <= _surface_contact_settle_tolerance(guide)
            or _pin_points_within_snap_radius(
                context,
                target,
                anchor,
                pixel_radius=PIN_SNAP_PIXEL_RADIUS,
            )
        )
        native_translate = _pin_native_translate_vector(context)
        translate_origin = (
            Vector((0.0, 0.0, 0.0))
            if key in initial
            else _state.setdefault(
                "pin_snap_engage_translate_origins", {}
            ).get(key)
        )
        native_reentry_close = bool(
            native_translate is None
            or translate_origin is None
            or (
                native_translate - Vector(translate_origin)
            ).length <= PIN_SNAP_WORLD_RADIUS
        )
        direct_reentry_close = bool(
            raw_reentry_close
            and visible_reentry_close
            and native_reentry_close
        )
        if direct_reentry_close:
            releasing.discard(key)
            _state.setdefault(
                "pin_snap_release_reentry_armed", set()
            ).discard(key)
            _state.setdefault("pin_snap_departing", set()).discard(key)
            _surface_contact_set_snap_detached(guide, False)
            returned_from_release = True
        else:
            reentry_armed = _state.setdefault(
                "pin_snap_release_reentry_armed", set()
            )
            native_translate = _pin_native_translate_vector(context)
            translate_origin = (
                Vector((0.0, 0.0, 0.0))
                if key in initial
                else _state.setdefault(
                    "pin_snap_engage_translate_origins", {}
                ).get(key)
            )
            native_distance = (
                (native_translate - Vector(translate_origin)).length
                if native_translate is not None and translate_origin is not None
                else None
            )
            anchor_origin = _state.setdefault(
                "pin_snap_engage_anchor_origins", {}
            ).get(key)
            anchor_distance = (raw_anchor - Vector(target)).length
            raw_distance = anchor_distance
            if key not in _state.get("pin_snap_raw_anchor_samples", {}):
                raw_distance = (
                    native_distance
                    if native_distance is not None
                    else anchor_distance
                )
            if raw_distance is not None:
                if raw_distance > PIN_SNAP_WORLD_RADIUS:
                    reentry_armed.add(key)
                    # This is also the first real authored sample outside the
                    # socket. Seed magnetic sweep from it so a stale overlap
                    # left by the release solver cannot make the next distant
                    # aligned sample look like a pass through the pin.
                    _state.setdefault(
                        "pin_snap_magnetic_anchor_samples", {}
                    )[key] = raw_anchor.copy()
                return False
            inside_entry = _pin_points_within_snap_radius(
                context,
                target,
                anchor,
                pixel_radius=PIN_SNAP_PIXEL_RADIUS,
            )
            if not inside_entry or key not in reentry_armed:
                if not inside_entry:
                    reentry_armed.add(key)
                return False
            reentry_armed.discard(key)
            releasing.discard(key)
            _state.setdefault("pin_snap_departing", set()).discard(key)
            _surface_contact_set_snap_detached(guide, False)
            returned_from_release = True
    operator_name = str(
        _state.get("pin_snap_transform_operator", "")
    ).lower()
    rotating = "rotate" in operator_name
    socket_locked_transform = bool(
        rotating or "resize" in operator_name or "scale" in operator_name
    )
    if returned_from_release:
        # Re-entry is a new grip even when this G began attached. Reset its
        # movement origin before evaluating release resistance; otherwise the
        # old pre-release origin immediately tears the just-returned snap off
        # again, especially after crossing beyond the side angle.
        _state.setdefault("pin_snap_engage_anchor_origins", {})[key] = (
            raw_anchor.copy()
        )
        native_translate = _pin_native_translate_vector(context)
        if native_translate is not None:
            _state.setdefault(
                "pin_snap_engage_translate_origins", {}
            )[key] = native_translate.copy()
        engaged.add(key)
        axis = _surface_contact_bone_axis_world(
            context,
            guide,
            live_pose=True,
        )
        if axis is not None:
            direction = Vector(axis[0]) - Vector(axis[1])
            if direction.length_squared > 1.0e-12:
                _state.setdefault("pin_snap_grip_directions", {})[key] = (
                    direction.normalized()
                )
    initial_hold = False
    transform_hold = bool(key in initial or key in engaged)
    if transform_hold and not socket_locked_transform:
        native_translate = _pin_native_translate_vector(context)
        translate_origin = (
            Vector((0.0, 0.0, 0.0))
            if key in initial
            else _state.setdefault(
                "pin_snap_engage_translate_origins", {}
            ).get(key)
        )
        native_translate_distance = (
            (native_translate - Vector(translate_origin)).length
            if native_translate is not None and translate_origin is not None
            else None
        )
        anchor_origin = _state.setdefault(
            "pin_snap_engage_anchor_origins", {}
        ).get(key)
        raw_anchor_delta = (
            raw_anchor - Vector(anchor_origin)
            if anchor_origin is not None
            else None
        )
        raw_anchor_distance = (
            raw_anchor_delta.length
            if raw_anchor_delta is not None
            else None
        )
        # Direct outward movement releases at the same spatial boundary used
        # to enter Contact. Tangential movement is still filtered by the
        # surface/rod projections below, so ball-joint rolls remain planted
        # while a visibly separated dot cannot retain its outer ring.
        release_world = PIN_SNAP_WORLD_RADIUS
        # Contact solving puts the visible endpoint back on its pin after
        # every modal sample. Measuring that corrected endpoint made release
        # random: one frame saw Blender's raw pull, the next saw the solved
        # dot overlap. Blender's own G/gizmo delta is the stable user intent.
        # Keep the geometric fallback for hosts/operators that do not expose
        # the native delta RNA.
        surface_normal = Vector(_normal)
        if surface_normal.length_squared > 1.0e-12:
            surface_normal.normalize()
        release_direction = Vector(
            _state.setdefault("pin_snap_grip_directions", {}).get(
                key,
                surface_normal,
            )
        )
        if release_direction.length_squared > 1.0e-12:
            release_direction.normalize()
        raw_sample_available = key in _state.get(
            "pin_snap_raw_anchor_samples", {}
        )
        pressure_active = key in _state.setdefault(
            "pin_snap_pressure_active", set()
        )
        surface_offset = raw_anchor - Vector(target)
        signed_surface_offset = surface_offset.dot(surface_normal)
        tangent_surface_offset = (
            surface_offset
            - surface_normal * signed_surface_offset
        )
        inward_pressure = bool(
            surface_normal.length_squared > 1.0e-12
            and signed_surface_offset < 0.0
            and tangent_surface_offset.length <= release_world
        )
        if inward_pressure:
            # Crossing into the contacted half-space is pressure on the rod,
            # never a magnetic release. Keep the socket planted so the far
            # endpoint can hit the side and the real bottom can roll upward.
            # This signed-normal test is orientation-neutral.
            close = True
        elif pressure_active:
            # The pressure solver may leave the visible pink dot sitting on
            # its surface pin even after Blender's raw G/gizmo pose has moved
            # past it. Keeping every pressure sample latched therefore makes
            # the limb appear frozen. Establish one immutable raw origin, then
            # release as soon as authored motion crosses the normal socket
            # band on the allowed side of the surface. Below-plane motion is
            # still pressure and remains attached for the two-ended roll.
            if anchor_origin is None:
                _state.setdefault(
                    "pin_snap_engage_anchor_origins", {}
                )[key] = raw_anchor.copy()
                raw_anchor_delta = Vector((0.0, 0.0, 0.0))
                raw_anchor_distance = 0.0
            authored_distance = max(
                float(raw_anchor_distance or 0.0),
                float(native_translate_distance or 0.0),
            )
            close = bool(
                signed_surface_offset < 0.0
                or authored_distance <= release_world
            )
        elif (
            raw_sample_available
            and raw_anchor_delta is not None
            and release_direction.length_squared > 1.0e-12
        ):
            # Pull resistance follows the limb's current rod, not the fixed
            # surface normal. Moving across the rod remains a ball-joint arc;
            # pulling along the rod releases with the same short distance on
            # a floor, wall, or a limb already lying on its side. The former
            # surface-normal test made a sideways limb effectively impossible
            # to detach until Blender's raw move had grown enormous.
            surface_outward_pull = raw_anchor_delta.dot(surface_normal)
            rod_outward_pull = raw_anchor_delta.dot(release_direction)
            close = bool(
                surface_outward_pull <= release_world
                and rod_outward_pull <= release_world
            )
            if (
                close
                and native_translate_distance is not None
                and native_translate_distance > release_world
                and (raw_anchor - Vector(target)).length
                <= _surface_contact_settle_tolerance(guide)
            ):
                # A repeated depsgraph callback can expose Contact's corrected
                # endpoint instead of Blender's requested pose. In that one
                # case the native RNA magnitude proves that movement occurred.
                # Its vector is expressed in the current transform orientation,
                # so never dot it against world-space surface or rod axes.
                close = False
        else:
            close = (
                native_translate_distance <= release_world
                if native_translate_distance is not None
                else (
                    raw_anchor_distance <= release_world
                    if raw_anchor_distance is not None
                    else _pin_points_within_snap_radius(
                        context,
                        target,
                        anchor,
                        pixel_radius=PIN_SNAP_RELEASE_PIXEL_RADIUS,
                    )
                )
            )
        if not close:
            if (
                not raw_sample_available
                and native_translate_distance is None
                and surface_normal.length_squared > 1.0e-12
            ):
                # Distance caused by pressure into the contacted plane is not
                # a pull-out, but pressure must not make every sideways pull
                # impossible. Keep the latch only while the raw endpoint is
                # still close to the target along the surface. Once the
                # sideways part crosses the same release band used elsewhere,
                # it is an intentional pull-out even if it is also slightly
                # below a floor/wall plane.
                offset = raw_anchor - Vector(target)
                signed_normal = offset.dot(surface_normal)
                tangent = offset - surface_normal * signed_normal
                if (
                    signed_normal < 0.0
                    and tangent.length <= release_world
                ):
                    close = True
        if not close:
            # A direct pull-out is a real attachment-state edit, not merely a
            # transient solver branch. Register it for mouse-up finalization
            # before setting the runtime latch so an existing attached
            # F-curve cannot restore Contact before the next ancestor G/R/S.
            _state.setdefault("pin_snap_initial_detached", {}).setdefault(
                key,
                bool(
                    _surface_contact_animated_detached_state(
                        guide,
                        int(context.scene.frame_current),
                    )
                    or guide.get(
                        SURFACE_CONTACT_DETACHED_PROPERTY,
                        False,
                    )
                ),
            )
            _state.setdefault("pin_snap_transform_seen", set()).add(key)
            if pressure_active:
                # A raw pull-out from a rolled pose must use the detached
                # pressure barrier immediately. Without this terminal session
                # marker, the next depsgraph pass can magnetically relatch the
                # corrected dot and alternate attached/detached every sample.
                _surface_contact_begin_pressure_release(context, guide)
            releasing.add(key)
            engaged.discard(key)
            # A later outward sample must arm re-entry. Arming this same
            # release sample lets magnetic correction cancel the release.
            _state.setdefault(
                "pin_snap_release_reentry_armed", set()
            ).discard(key)
            _state.setdefault(
                "pin_snap_release_anchor_origins", {}
            )[key] = raw_anchor.copy()
            _surface_contact_set_snap_detached(guide, True)
            # Publish the constraint release before the detached rebase/aim
            # performs any view-layer update. Leaving influence enabled until
            # the end of that solve lets Blender pull the raw pink-bone pose
            # back onto the pin, so mouse-up looks unchanged and is treated
            # as a cancelled transform.
            _surface_contact_set_constraint_attachment(guide, False)
            _state.setdefault("pin_snap_latches", set()).discard(key)
            _state.setdefault("pin_snap_swept_hits", set()).discard(key)
            _state.setdefault("pin_snap_previous_points", {})[key] = (
                raw_anchor.copy()
            )
            return False
        # Carry the wider release-band/pressure decision into the final snap
        # arbitration below. Previously `close` was recomputed from the small
        # entry radius, silently discarding this result. That is why a planted
        # limb could flicker free while being pushed into its pin and why the
        # first G behaved differently from the next one.
        initial_hold = True
    close = bool(
        initial_hold
        or (socket_locked_transform and key in initial)
        or (socket_locked_transform and key in engaged)
        or _pin_snap_should_engage(
            context,
            key,
            target,
            raw_anchor,
            use_hysteresis=use_snap_hysteresis,
        )
    )
    if not close:
        return False
    if returned_from_release or key not in initial:
        if returned_from_release or key not in engaged:
            native_translate = _pin_native_translate_vector(context)
            if native_translate is not None:
                _state.setdefault(
                    "pin_snap_engage_translate_origins", {}
                )[key] = native_translate.copy()
            _state.setdefault(
                "pin_snap_engage_anchor_origins", {}
            )[key] = raw_anchor.copy()
            axis = _surface_contact_bone_axis_world(
                context,
                guide,
                live_pose=True,
            )
            if axis is not None:
                direction = Vector(axis[0]) - Vector(axis[1])
                if direction.length_squared > 1.0e-12:
                    _state.setdefault(
                        "pin_snap_grip_directions", {}
                    )[key] = direction.normalized()
        engaged.add(key)
    # Record first-entry transitions too.  Otherwise the modal solve can look
    # attached while mouse-up has no state to key for a previously detached
    # pin.
    initial_states = _state.setdefault("pin_snap_initial_detached", {})
    initial_states.setdefault(
        key,
        bool(
            _surface_contact_animated_detached_state(
                guide, int(context.scene.frame_current)
            )
            or guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)
        ),
    )
    _state.setdefault("pin_snap_transform_seen", set()).add(key)
    engaged.add(key)
    _state.setdefault(
        "pin_snap_parent_transform_guides", set()
    ).discard(guide.name)
    _state.setdefault(
        "pin_snap_parent_attachment_states", {}
    ).pop(guide.name, None)
    _surface_contact_clear_snap_departure(guide)
    _state.setdefault("pin_snap_latches", set()).add(key)
    return True


def _surface_contact_direct_magnetic_snap_close(context, guide):
    """Attach a directly moved limb once its aimed endpoint reaches the pin."""
    if not _surface_contact_new_snap_allowed(context, guide):
        return False
    key = _surface_contact_snap_key(guide)
    pressure_release = bool(key in _state.setdefault(
        "pin_snap_pressure_release_session", set()
    ))
    releasing = _state.setdefault("pin_snap_transform_releasing", set())
    reentering = bool(key in releasing and not pressure_release)
    if key in _state.setdefault("pin_snap_latches", set()):
        return True
    # The native-transform target is locked before G/R/S begins. Read that
    # lock and the just-authored live bone endpoint directly so this admission
    # check does not rebuild Blender's evaluated dependency graph on every
    # mouse event. Fall back to the regular query outside a native transform.
    target_lock = _state.get("pin_snap_contact_target_locks", {}).get(
        getattr(guide, "name", "")
    )
    target = (
        target_lock["matrix_world"].translation.copy()
        if target_lock is not None
        else None
    )
    solved_anchor = _surface_contact_bone_anchor_world(
        context,
        guide,
        live_pose=True,
    )
    if target is None or solved_anchor is None:
        target, _normal, solved_anchor = _surface_contact_world_point_normal(
            context,
            guide,
        )
    if target is None or solved_anchor is None:
        return False
    target = Vector(target)
    solved_anchor = Vector(solved_anchor)
    # Keep both real bottom-pin positions. A side approach can reach the dot
    # only after the one allowed magnetic turn, while a fast crossing can
    # reach it before collision correction. Either real bottom dot may admit
    # the snap; the imaginary opposite rod endpoint is never considered.
    pre_solve_anchor = Vector(
        _state.setdefault("pin_snap_pre_solve_anchor_samples", {}).get(
            key,
            solved_anchor,
        )
    )
    authored_anchor = Vector(
        _state.setdefault("pin_snap_raw_anchor_samples", {}).get(
            key,
            pre_solve_anchor,
        )
    )
    capture_radius = PIN_SNAP_WORLD_RADIUS
    within_authored = bool(
        (target - authored_anchor).length <= capture_radius
        or _pin_points_within_snap_radius(
            context,
            target,
            authored_anchor,
            pixel_radius=PIN_SNAP_PIXEL_RADIUS,
        )
    )
    within_pre_solve = bool(
        (target - pre_solve_anchor).length <= capture_radius
        or _pin_points_within_snap_radius(
            context,
            target,
            pre_solve_anchor,
            pixel_radius=PIN_SNAP_PIXEL_RADIUS,
        )
    )
    within_solved = bool(
        (target - solved_anchor).length <= capture_radius
        or _pin_points_within_snap_radius(
            context,
            target,
            solved_anchor,
            pixel_radius=PIN_SNAP_PIXEL_RADIUS,
        )
    )
    aimed_sample = _state.setdefault(
        "pin_snap_magnetic_aim_anchor_samples",
        {},
    ).get(key)
    aimed_anchor = (
        Vector(aimed_sample) if aimed_sample is not None else None
    )
    aimed_close = bool(
        aimed_anchor is not None
        and (
            (target - aimed_anchor).length <= capture_radius
            or _pin_points_within_snap_radius(
                context,
                target,
                aimed_anchor,
                pixel_radius=PIN_SNAP_PIXEL_RADIUS,
            )
        )
    )
    # A steep/side approach can require the one rotation-only magnetic aim to
    # reach the socket.  Admit that aim regardless of the approach angle.  Do
    # not use the final collision-corrected endpoint here: plane correction
    # can translate a vertically aligned, distant limb onto the target and
    # was the source of the false up/down snap.
    angled_magnetic_entry = bool(aimed_close)
    within = bool(
        within_authored
        or within_pre_solve
        or angled_magnetic_entry
    )
    magnetic_samples = _state.setdefault(
        "pin_snap_magnetic_anchor_samples", {}
    )
    previous = Vector(
        magnetic_samples.get(key, authored_anchor)
    ).copy()
    magnetic_samples[key] = authored_anchor.copy()
    swept = False
    segment = authored_anchor - previous
    pressure_active = key in _state.setdefault(
        "pin_snap_pressure_active", set()
    )
    if (
        not pressure_active
        and segment.length_squared > 1.0e-12
    ):
        factor = max(
            0.0,
            min(1.0, (target - previous).dot(segment) / segment.length_squared),
        )
        closest = previous + segment * factor
        swept = bool((closest - target).length <= capture_radius)
    reentry_armed = _state.setdefault(
        "pin_snap_release_reentry_armed", set()
    )
    if pressure_release:
        # Pressure suppresses magnetic capture while the limb rolls through
        # the socket.  Once the real authored pink endpoint has first cleared
        # the outer ring, however, returning to/crossing that ring is a new
        # deliberate approach in the same drag.  This is direction-neutral:
        # floor, wall, exterior, and interior pressure-roll bypasses all use
        # the real dot radius rather than a surface-facing angle test.
        was_armed = key in reentry_armed
        real_endpoint_within = bool(within_authored or within_pre_solve)
        if not real_endpoint_within:
            reentry_armed.add(key)
        if not was_armed or not (real_endpoint_within or swept):
            return False
    elif reentering and key not in reentry_armed:
        return False
    if not (within or swept):
        return False
    _state.setdefault(
        "pin_snap_parent_transform_guides", set()
    ).discard(guide.name)
    _state.setdefault(
        "pin_snap_parent_attachment_states", {}
    ).pop(guide.name, None)
    _surface_contact_clear_snap_departure(guide)
    _surface_contact_set_snap_detached(guide, False)
    raw_pose = _state.setdefault(
        "pin_snap_raw_pose_matrices",
        {},
    ).get(key)
    if raw_pose is not None:
        armature, pose_bone = _surface_contact_pose_bone(guide)
        if armature is not None and pose_bone is not None:
            # Magnetic aiming is only an admission probe for a steep/side
            # approach. Committing that probe rotates the limb a few degrees
            # upward at the instant of snap. Preserve Blender's authored pose
            # and translate its real dot onto the socket instead.
            authored_world = armature.matrix_world @ Matrix(raw_pose)
            authored_world.translation += target - authored_anchor
            _set_pose_bone_constrained_output_matrix(
                context,
                armature,
                pose_bone,
                armature.matrix_world.inverted_safe() @ authored_world,
            )
    _state.setdefault("pin_snap_latches", set()).add(key)
    _state.setdefault("pin_snap_transform_engaged", set()).add(key)
    proximity_engaged = _state.setdefault("pin_snap_proximity_engaged", set())
    proximity_engaged.discard(key)
    _state.setdefault("pin_snap_pressure_active", set()).discard(key)
    _state.setdefault("pin_snap_pressure_tangents", {}).pop(key, None)
    _state.setdefault("pin_snap_pressure_release_origins", {}).pop(key, None)
    _state.setdefault("pin_snap_pressure_release_session", set()).discard(key)
    _state.setdefault(
        "pin_snap_pressure_release_pose_matrices", {}
    ).pop(key, None)
    _state.setdefault(
        "pin_snap_pressure_release_raw_translations", {}
    ).pop(key, None)
    _state.setdefault(
        "pin_snap_pressure_release_native_driven", set()
    ).discard(key)
    _state.setdefault("pin_snap_collision_min_distances", {}).pop(key, None)
    releasing.discard(key)
    _state.setdefault("pin_snap_release_reentry_armed", set()).discard(key)
    _state.setdefault("pin_snap_release_anchor_origins", {}).pop(key, None)
    raw_anchor = _state.setdefault("pin_snap_raw_anchor_samples", {}).get(
        key,
        solved_anchor,
    )
    _state.setdefault("pin_snap_engage_anchor_origins", {})[key] = Vector(
        raw_anchor
    ).copy()
    axis = _surface_contact_bone_axis_world(
        context,
        guide,
        live_pose=True,
    )
    if axis is not None:
        direction = Vector(axis[0]) - Vector(axis[1])
        if direction.length_squared > 1.0e-12:
            _state.setdefault("pin_snap_grip_directions", {})[key] = (
                direction.normalized()
            )
    native_translate = _pin_native_translate_vector(context)
    if native_translate is not None:
        _state.setdefault("pin_snap_engage_translate_origins", {})[key] = (
            native_translate.copy()
        )
    return True


def _surface_contact_capture_transform_start_pose(guide):
    """Capture every contact-owned pose that native G/R/S can influence."""
    armature, pose_bone = _surface_contact_pose_bone(guide)
    if armature is None or pose_bone is None:
        return False
    key = (_armature_session_uid(armature), pose_bone.name)
    snapshots = _state.setdefault(
        "pin_snap_contact_transform_start_poses", {}
    )
    baseline = _state.get("pin_snap_transform_capture_baseline", {}).get(key)
    snapshots.setdefault(
        key,
        baseline if baseline is not None else (
            armature.name, pose_bone.name,
            pose_bone.matrix_basis.copy(), pose_bone.matrix.copy(),
        ),
    )
    return True


def _surface_contact_capture_transform_scope(
    context, guide, armature, selected_names
):
    """Capture a direct/ancestor-driven guide and report both scope kinds."""
    direct = bool(
        selected_names
        and _surface_contact_direct_bone_names(guide) & selected_names
    )
    parent_driven = bool(
        selected_names
        and _surface_contact_selected_bones_drive_guide(
            armature, guide, selected_names
        )
    )
    if direct or parent_driven:
        _surface_contact_capture_transform_start_pose(guide)
    return direct, parent_driven


def _surface_contact_restore_transform_start_poses(context):
    """Atomically roll back contact corrections when native G/R/S cancels."""
    changed = False
    for snapshot in tuple(
        _state.get("pin_snap_contact_transform_start_poses", {}).values()
    ):
        armature_name, bone_name, matrix_basis = snapshot[:3]
        armature = bpy.data.objects.get(str(armature_name))
        pose_bone = (
            armature.pose.bones.get(str(bone_name))
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is None:
            continue
        if _pin_keyboard_matrices_differ(
            pose_bone.matrix_basis,
            matrix_basis,
        ):
            pose_bone.matrix_basis = matrix_basis.copy()
            changed = True
    if changed:
        context.view_layer.update()
    return changed


def _surface_contact_restore_transform_attachment_states(context):
    """Restore the snap/detach meaning that existed before cancelled G/R/S."""
    states = dict(
        _state.get("pin_snap_initial_attachment_states", {})
    )
    if not states:
        return False
    changed = False
    latches = _state.setdefault("pin_snap_latches", set())
    detached_keys = _state.setdefault("pin_snap_detached", set())
    for snap_key, snapshot in states.items():
        guide = bpy.data.objects.get(str(snapshot.get("guide", "")))
        if guide is None:
            continue
        latched = bool(snapshot.get("latched", False))
        detached = bool(snapshot.get("detached", False))
        if latched:
            latches.add(snap_key)
        else:
            latches.discard(snap_key)
        if detached:
            detached_keys.add(snap_key)
        else:
            detached_keys.discard(snap_key)
        pressure_was_active = bool(
            snapshot.get("pressure_active", False)
        )
        _surface_contact_set_constraint_attachment(
            guide,
            latched and not pressure_was_active,
        )
        had_property = bool(snapshot.get("had_property", False))
        property_value = snapshot.get("property")
        if had_property:
            if guide.get(SURFACE_CONTACT_DETACHED_PROPERTY) != property_value:
                guide[SURFACE_CONTACT_DETACHED_PROPERTY] = property_value
                changed = True
        elif SURFACE_CONTACT_DETACHED_PROPERTY in guide:
            del guide[SURFACE_CONTACT_DETACHED_PROPERTY]
            changed = True
        for state_name in (
            "pin_snap_departing",
            "pin_snap_transform_engaged",
            "pin_snap_transform_releasing",
            "pin_snap_release_reentry_armed",
        ):
            _state.setdefault(state_name, set()).discard(snap_key)
        pressure_active = _state.setdefault(
            "pin_snap_pressure_active", set()
        )
        if pressure_was_active:
            pressure_active.add(snap_key)
        else:
            pressure_active.discard(snap_key)
        _state.setdefault("pin_snap_release_anchor_origins", {}).pop(
            snap_key,
            None,
        )
    if changed and context is not None:
        context.view_layer.update()
    return changed


def _surface_contact_restore_transform_start_pose(context, guide):
    """Restore one contact owner to this modal transform's exact baseline."""
    armature, pose_bone = _surface_contact_pose_bone(guide)
    if armature is None or pose_bone is None:
        return False
    snapshot = _state.get(
        "pin_snap_contact_transform_start_poses",
        {},
    ).get((_armature_session_uid(armature), pose_bone.name))
    if (
        snapshot is None
        or not _pin_keyboard_matrices_differ(
            pose_bone.matrix_basis,
            snapshot[2],
        )
    ):
        return False
    pose_bone.matrix_basis = snapshot[2].copy()
    context.view_layer.update()
    return True


def _surface_contact_aim_detached_simulated_pose(
    context, guide, *, preserve_current_roll=False
):
    """Aim a detached Smart contact without translating its owner bone."""
    if not _surface_contact_preserves_rigid_orientation(guide):
        return False
    armature, pose_bone = _surface_contact_pose_bone(guide)
    target, _normal, anchor = _surface_contact_world_point_normal(
        context, guide
    )
    if (
        armature is None
        or pose_bone is None
        or target is None
        or anchor is None
    ):
        return False
    return _surface_contact_rotate_simulated_pose_toward(
        context,
        guide,
        armature,
        pose_bone,
        anchor,
        target,
        stabilize_smart_roll=not preserve_current_roll,
    )


def _surface_contact_settle_detached_smart(context, guide):
    """Return None for legacy pins, otherwise settle/store rotate-only aim."""
    if not _surface_contact_preserves_rigid_orientation(guide):
        return None
    changed = _surface_contact_aim_detached_simulated_pose(context, guide)
    _surface_contact_store_valid_pose(guide)
    return changed


def _surface_contact_stabilize_smart_roll(
    context, guide, rotation, target_direction
):
    """Remove Smart-object roll drift while preserving exact ray alignment."""
    smart_object = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_SMART_OBJECT_PROPERTY, ""))
    )
    if smart_object is None:
        return rotation
    try:
        evaluated = smart_object.evaluated_get(
            context.evaluated_depsgraph_get()
        )
        object_basis = evaluated.matrix_world.to_3x3()
        target_direction = Vector(target_direction).normalized()
        guide_basis = guide.matrix_world.to_3x3().normalized()
        saved_roll = guide.get(SURFACE_CONTACT_SMART_ROLL_PROPERTY)
        if saved_roll is not None and len(saved_roll) >= 6:
            local_roll = Vector(tuple(float(value) for value in saved_roll[:3]))
            guide_roll = Vector(tuple(float(value) for value in saved_roll[3:6]))
        else:
            cast_axis = _surface_contact_axis_vector(
                guide.get(SURFACE_CONTACT_CAST_AXIS_PROPERTY, "Y_NEG")
            )
            candidates = tuple(
                axis
                for axis in (
                    Vector((1.0, 0.0, 0.0)),
                    Vector((0.0, 1.0, 0.0)),
                    Vector((0.0, 0.0, 1.0)),
                )
                if abs(axis.dot(cast_axis)) < 0.5
            )
            # Guide X/Y are the contacted plane's tangents. Never pair the
            # welded box's roll axis with guide Z (the surface normal): after
            # projection that vector degenerates and leaves a visible tilt.
            guide_axes = (
                Vector((1.0, 0.0, 0.0)),
                Vector((0.0, 1.0, 0.0)),
            )
            local_roll, guide_roll = max(
                (
                    (object_axis, guide_axis)
                    for object_axis in candidates
                    for guide_axis in guide_axes
                ),
                key=lambda pair: abs(
                    (
                        object_basis @ pair[0]
                    ).normalized().dot(
                        (guide_basis @ pair[1]).normalized()
                    )
                )
            )
            if (object_basis @ local_roll).dot(
                guide_basis @ guide_roll
            ) < 0.0:
                guide_roll.negate()
            guide[SURFACE_CONTACT_SMART_ROLL_PROPERTY] = (
                *tuple(local_roll), *tuple(guide_roll)
            )
        swung_roll = rotation @ (object_basis @ local_roll)
        desired_roll = guide_basis @ guide_roll
        swung_roll -= target_direction * swung_roll.dot(target_direction)
        desired_roll -= target_direction * desired_roll.dot(target_direction)
        frame_key = _surface_contact_pose_cache_key(guide)
        frames = _state.setdefault("surface_contact_roll_frames", {})
        previous_frame = frames.get(frame_key)
        transported_roll = None
        if previous_frame is not None:
            previous_target = Vector(previous_frame["target"]).normalized()
            previous_roll = Vector(previous_frame["roll"]).normalized()
            dot = max(
                -1.0,
                min(1.0, previous_target.dot(target_direction)),
            )
            cross = previous_target.cross(target_direction)
            if cross.length_squared > 1.0e-12:
                transport = Quaternion(
                    cross.normalized(),
                    math.acos(dot),
                )
            elif dot < 0.0:
                transport_axis = previous_roll.copy()
                transport_axis -= (
                    previous_target
                    * transport_axis.dot(previous_target)
                )
                if transport_axis.length_squared <= 1.0e-12:
                    transport_axis = previous_target.orthogonal()
                transport = Quaternion(
                    transport_axis.normalized(),
                    math.pi,
                )
            else:
                transport = Quaternion()
            transported_roll = transport @ previous_roll
            transported_roll -= (
                target_direction
                * transported_roll.dot(target_direction)
            )
            if transported_roll.length_squared <= 1.0e-12:
                transported_roll = None
            else:
                transported_roll.normalize()
        if desired_roll.length_squared <= 1.0e-10:
            # The static surface tangent is parallel to the aim direction.
            # Its projection has no sign here and reverses after the crossing;
            # parallel transport supplies the unique continuous roll instead.
            desired_roll = (
                transported_roll.copy()
                if transported_roll is not None
                else (
                    swung_roll.normalized()
                    if swung_roll.length_squared > 1.0e-10
                    else target_direction.orthogonal().normalized()
                )
            )
        else:
            desired_roll.normalize()
            reference = (
                transported_roll
                if transported_roll is not None
                else (
                    swung_roll
                    if swung_roll.length_squared > 1.0e-10
                    else desired_roll
                )
            )
            if desired_roll.dot(reference) < 0.0:
                desired_roll.negate()
        frames[frame_key] = {
            "target": target_direction.copy(),
            "roll": desired_roll.copy(),
        }
        if swung_roll.length_squared <= 1.0e-10:
            # Roll is undefined for this exact sample. The shortest-arc aim is
            # already continuous; retaining the transported frame makes the
            # next non-degenerate sample resume without a sideways flip.
            return rotation
        swung_roll.normalize()
        twist_angle = math.atan2(
            target_direction.dot(swung_roll.cross(desired_roll)),
            max(-1.0, min(1.0, swung_roll.dot(desired_roll))),
        )
        interactive = bool(
            _state.get("pin_snap_transform_active", False)
            or _state.get("pin_keyboard_transform_active", False)
            or _state.get("pin_target_dragging", False)
        )
        if not interactive:
            remaining = max(
                0.0,
                SURFACE_CONTACT_MAX_AIM_STEP - min(
                    SURFACE_CONTACT_MAX_AIM_STEP, abs(float(rotation.angle))
                ),
            )
            twist_angle = max(-remaining, min(remaining, twist_angle))
        if abs(twist_angle) <= 1.0e-7:
            return rotation
        return Quaternion(target_direction, twist_angle) @ rotation
    except (
        AttributeError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ):
        return rotation


def _surface_contact_capture_native_history_after(context):
    """Capture Blender's raw post-transform pose before Contact reapplies solve."""
    scene = getattr(context, "scene", None)
    if scene is None:
        _state["pin_snap_native_after_poses"] = {}
        return {}
    selected_keys = set(
        _state.get("pin_snap_transform_start_poses", {})
    )
    raw_bases = _state.get("pin_snap_raw_basis_matrices", {})
    raw_poses = _state.get("pin_snap_raw_pose_matrices", {})
    snapshots = {}
    armatures_by_uid = {
        _armature_session_uid(obj): obj
        for obj in tuple(scene.objects)
        if obj.type == "ARMATURE"
        and getattr(obj, "pose", None) is not None
    }
    for guide in _surface_contact_active_simulated_guides(scene):
        armature, pose_bone = _surface_contact_pose_bone(guide)
        if armature is None or pose_bone is None:
            continue
        pose_key = (_armature_session_uid(armature), pose_bone.name)
        snap_key = _surface_contact_snap_key(guide)
        direct = pose_key in selected_keys
        basis = raw_bases.get(snap_key) if direct else None
        visual = raw_poses.get(snap_key) if direct else None
        snapshots[pose_key] = (
            armature.name,
            pose_bone.name,
            (basis if basis is not None else pose_bone.matrix_basis).copy(),
            (visual if visual is not None else pose_bone.matrix).copy(),
        )
    for owner_uid, bone_name in selected_keys:
        pose_key = (owner_uid, bone_name)
        if pose_key in snapshots:
            continue
        armature = armatures_by_uid.get(owner_uid)
        pose_bone = (
            armature.pose.bones.get(bone_name)
            if armature is not None
            else None
        )
        if pose_bone is None:
            continue
        snapshots[pose_key] = (
            armature.name,
            pose_bone.name,
            pose_bone.matrix_basis.copy(),
            pose_bone.matrix.copy(),
        )
    _state["pin_snap_native_after_poses"] = snapshots
    return snapshots


def _surface_contact_record_native_transform_history(context):
    """Pair one native pose transform with exact raw and solved Contact sides."""
    _state["pin_snap_native_history_transition"] = None
    _state["pin_snap_native_history_transition_backup"] = None
    _state.setdefault("pin_snap_native_history_redo_stack", []).clear()

    scene = getattr(context, "scene", None)
    if scene is None:
        return None
    native_poses = _state.get("pin_snap_native_after_poses", {})
    live_poses = _state.get("pin_snap_live_pose_matrices", {})
    selected_starts = _state.get("pin_snap_transform_start_poses", {})
    contact_starts = _state.get(
        "pin_snap_contact_transform_start_poses", {}
    )
    armatures_by_uid = {
        _armature_session_uid(obj): obj
        for obj in tuple(scene.objects)
        if obj.type == "ARMATURE"
        and getattr(obj, "pose", None) is not None
    }

    selected = []
    for (owner_uid, bone_name), before in selected_starts.items():
        armature = armatures_by_uid.get(owner_uid)
        pose_bone = (
            armature.pose.bones.get(bone_name)
            if armature is not None
            else None
        )
        if pose_bone is None:
            continue
        pose_key = (owner_uid, bone_name)
        native = native_poses.get(pose_key)
        solved = live_poses.get(pose_key)
        native_after = (
            native[2].copy()
            if native is not None
            else pose_bone.matrix_basis.copy()
        )
        solved_after = (
            solved[2].copy()
            if solved is not None
            else pose_bone.matrix_basis.copy()
        )
        selected.append((
            armature.name,
            bone_name,
            before.copy(),
            native_after,
            solved_after,
        ))

    contacts = []
    attachments = []
    detached_key_states = []
    guide_matrices = []
    guide_local_matrices = []
    constraint_states = []
    included_owner_keys = set()
    initial_states = _state.get("pin_snap_initial_attachment_states", {})
    initial_latches = _state.setdefault("pin_snap_initial_latches", set())
    for guide in _surface_contact_active_simulated_guides(scene):
        armature, pose_bone = _surface_contact_pose_bone(guide)
        if armature is None or pose_bone is None:
            continue
        owner_uid = _armature_session_uid(armature)
        pose_key = (owner_uid, pose_bone.name)
        start_pose = contact_starts.get(pose_key)
        if start_pose is None:
            continue
        snap_key = _surface_contact_snap_key(guide)
        owner_key = (owner_uid, guide.name)
        native = native_poses.get(pose_key)
        solved = live_poses.get(pose_key)
        native_after = (
            native[2].copy()
            if native is not None
            else pose_bone.matrix_basis.copy()
        )
        solved_after = (
            solved[2].copy()
            if solved is not None
            else pose_bone.matrix_basis.copy()
        )
        native_visual = (
            native[3].copy()
            if native is not None and len(native) > 3
            else pose_bone.matrix.copy()
        )
        solved_visual = (
            solved[3].copy()
            if solved is not None and len(solved) > 3
            else pose_bone.matrix.copy()
        )
        initial_state = initial_states.get(snap_key, {})
        if initial_state.get("had_property", False):
            # The saved detach property is the authored/undoable snap side.
            # A transient evaluated endpoint offset must not rewrite the
            # operation's before-side as detached; that loses the outer ring
            # when Undo returns to an otherwise correctly snapped pose.
            before_attached = not bool(initial_state.get("property", False))
        else:
            before_attached = bool(
                initial_state.get("latched", snap_key in initial_latches)
                and not initial_state.get("detached", False)
            )
        after_attached = (
            not bool(guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False))
            if SURFACE_CONTACT_DETACHED_PROPERTY in guide
            else bool(_pin_contact_is_attached(context, guide))
        )
        basis_changed = _pin_keyboard_matrices_differ(
            start_pose[2], solved_after, epsilon=1.0e-7
        )
        visual_changed = bool(
            len(start_pose) > 3
            and _pin_keyboard_matrices_differ(
                start_pose[3], solved_visual, epsilon=1.0e-7
            )
        )
        attachment_changed = before_attached != after_attached
        if not (basis_changed or visual_changed or attachment_changed):
            continue
        contacts.append((
            owner_key,
            armature.name,
            pose_bone.name,
            start_pose[2].copy(),
            native_after,
            solved_after,
        ))
        attachments.append((
            owner_key,
            before_attached,
            after_attached,
        ))
        detached_key_states.append((
            owner_key,
            initial_state.get("detached_keys"),
            _surface_contact_detached_key_snapshot(
                guide, int(scene.frame_current)
            ),
        ))
        before_guide_matrix = initial_state.get("guide_matrix")
        if before_guide_matrix is None:
            before_guide_matrix = guide.matrix_world.copy()
        guide_matrices.append((
            owner_key,
            guide.name,
            before_guide_matrix.copy(),
            guide.matrix_world.copy(),
        ))
        guide_local_matrices.append((
            owner_key,
            guide.name,
            initial_state.get("guide_local_matrix"),
            (
                tuple(float(value) for value in guide.get(
                    SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY,
                    (),
                ))
                if SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY in guide
                else None
            ),
        ))
        constraint_states.append((
            owner_key,
            guide.name,
            tuple(initial_state.get(
                "constraints",
                _surface_contact_constraint_history_state(guide),
            )),
            _surface_contact_constraint_history_state(guide),
        ))
        included_owner_keys.add(owner_key)

    if not selected or not contacts:
        return None

    action_keys = []
    keyed_owners = set()
    for entry in contacts:
        _owner_key, armature_name, bone_name, _before, _native, _solved = (
            contact_history_contact_entry(entry)
        )
        owner = (armature_name, bone_name)
        if owner in keyed_owners:
            continue
        keyed_owners.add(owner)
        armature = bpy.data.objects.get(armature_name)
        pose_bone = (
            armature.pose.bones.get(bone_name)
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        action_keys.append((
            armature_name,
            bone_name,
            _state.get("pin_snap_contact_start_action_keys", {}).get(owner),
            _surface_contact_pose_action_key_snapshot(
                armature,
                pose_bone,
                int(scene.frame_current),
            ),
        ))

    visuals = tuple(
        entry
        for entry in _surface_contact_capture_history_visuals(
            context,
            contact_starts,
            live_poses,
            native_poses,
        )
        if _surface_contact_history_owner_entry(entry)[0]
        in included_owner_keys
    )
    transition = {
        "frame": int(scene.frame_current),
        "selected": tuple(selected),
        "contacts": tuple(contacts),
        "attachments": tuple(attachments),
        "detached_key_states": tuple(detached_key_states),
        "guide_matrices": tuple(guide_matrices),
        "guide_local_matrices": tuple(guide_local_matrices),
        "constraint_states": tuple(constraint_states),
        "visual_poses": visuals,
        "action_keys": tuple(action_keys),
        "history_tokens": tuple(
            (str(armature_name), int(values[0]), int(values[1]))
            for armature_name, values in sorted(
                _state.get("pin_snap_native_history_tokens", {}).items()
            )
        ),
    }
    history_stack = _state.setdefault(
        "pin_snap_native_history_transitions", []
    )
    history_stack.append(transition)
    try:
        undo_steps = int(context.preferences.edit.undo_steps)
    except (AttributeError, TypeError, ValueError):
        undo_steps = 32
    history_limit = max(32, undo_steps + 8)
    if len(history_stack) > history_limit:
        del history_stack[:-history_limit]
    _state["pin_snap_native_history_transition"] = transition
    _state["pin_snap_native_history_transition_backup"] = transition
    return transition


def _surface_contact_refresh_recorded_history_after(context):
    """Replace preview-era after matrices with the settled evaluated pose."""
    history_stack = _state.get("pin_snap_native_history_transitions", [])
    transition = history_stack[-1] if history_stack else None
    if not transition:
        return False

    changed = False
    selected = []
    for entry in tuple(transition.get("selected", ())):
        armature_name, bone_name, before, native_after, solved_after = (
            contact_history_selected_entry(entry)
        )
        armature = bpy.data.objects.get(armature_name)
        pose_bone = (
            armature.pose.bones.get(bone_name)
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        settled = (
            pose_bone.matrix_basis.copy()
            if pose_bone is not None
            else solved_after
        )
        changed = changed or pose_bone is not None
        selected.append((
            armature_name,
            bone_name,
            before,
            native_after,
            settled,
        ))

    contacts = []
    for entry in tuple(transition.get("contacts", ())):
        owner_key, armature_name, bone_name, before, native_after, solved_after = (
            contact_history_contact_entry(entry)
        )
        armature = bpy.data.objects.get(armature_name)
        pose_bone = (
            armature.pose.bones.get(bone_name)
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        settled = (
            pose_bone.matrix_basis.copy()
            if pose_bone is not None
            else solved_after
        )
        contacts.append((
            owner_key,
            armature_name,
            bone_name,
            before,
            native_after,
            settled,
        ))

    visuals = []
    for entry in tuple(transition.get("visual_poses", ())):
        owner_key, armature_name, bone_name, before, native_after, solved_after = (
            contact_history_visual_entry(entry)
        )
        armature = bpy.data.objects.get(armature_name)
        pose_bone = (
            armature.pose.bones.get(bone_name)
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        settled = (
            pose_bone.matrix.copy()
            if pose_bone is not None
            else solved_after
        )
        visuals.append((
            owner_key,
            armature_name,
            bone_name,
            before,
            native_after,
            settled,
        ))

    transition["selected"] = tuple(selected)
    transition["contacts"] = tuple(contacts)
    transition["visual_poses"] = tuple(visuals)
    return changed

def _surface_contact_prepare_native_history_transition(context):
    """Remember Undo/Redo direction before other history handlers evaluate."""
    transition = _state.get("pin_snap_native_history_transition")
    if not transition and (
        _state.get("pin_history_active", False)
        or _state.get("pin_history_syncing", False)
    ):
        transition = _state.get(
            "pin_snap_native_history_transition_backup"
        )
        if transition:
            _state["pin_snap_native_history_transition"] = transition
    _state["pin_snap_native_history_expected_index"] = None
    _state["pin_snap_native_history_pre_selected"] = {}
    _state["pin_snap_native_history_pre_tokens"] = {}
    if not transition:
        return False
    _state["pin_snap_native_history_pre_tokens"] = {
        armature_name: int(armature.get(
            SURFACE_CONTACT_HISTORY_TOKEN_PROPERTY,
            -1,
        ))
        for armature_name, _before_token, _after_token
        in tuple(transition.get("history_tokens", ()))
        if (armature := bpy.data.objects.get(armature_name)) is not None
    }
    pre_selected = {}
    for entry in transition["selected"]:
        armature_name, bone_name, _before, _native_after, _solved_after = (
            contact_history_selected_entry(entry)
        )
        armature = bpy.data.objects.get(armature_name)
        pose_bone = (
            armature.pose.bones.get(bone_name)
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is not None:
            pre_selected[(armature_name, bone_name)] = (
                pose_bone.matrix_basis.copy()
            )
    _state["pin_snap_native_history_pre_selected"] = pre_selected
    direction = str(_state.get("pin_history_direction", ""))
    if direction in {"UNDO", "REDO"}:
        _state["pin_snap_native_history_expected_index"] = 0 if direction == "UNDO" else 1
        return True
    selected_entries = tuple(transition["selected"])
    selected_sides = tuple(
        index
        for index in (0, 1)
        if _surface_contact_history_side_matches(selected_entries, index)
    )
    if len(selected_sides) == 1:
        current_index = selected_sides[0]
    else:
        matching_sides = tuple(
            index
            for index in selected_sides
            if _surface_contact_history_side_matches(
                transition["contacts"],
                index,
            )
        )
        current_index = matching_sides[0] if len(matching_sides) == 1 else None
    if current_index is None:
        return False
    _state["pin_snap_native_history_expected_index"] = 1 - current_index
    return True
def _surface_contact_apply_native_history_transition(
    context,
    transition,
    restore_index,
    *,
    append_lock=False,
):
    """Restore one verified Contact history side without creating a new step."""
    if not transition or int(restore_index) not in (0, 1):
        return False
    restore_index = int(restore_index)
    frame = int(transition.get("frame", context.scene.frame_current))

    for _owner_key, guide_name, before_local, after_local in transition.get(
        "guide_local_matrices", ()
    ):
        guide = bpy.data.objects.get(str(guide_name))
        if guide is None:
            continue
        expected = before_local if restore_index == 0 else after_local
        if expected is None:
            if SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY in guide:
                del guide[SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY]
        elif tuple(guide.get(
            SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY,
            (),
        )) != tuple(expected):
            guide[SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY] = tuple(expected)
        if expected is not None and len(expected) >= 16:
            try:
                local_matrix = Matrix(
                    tuple(
                        tuple(
                            float(expected[(row * 4) + column])
                            for column in range(4)
                        )
                        for row in range(4)
                    )
                )
                # GUIDE_LOCAL_MATRIX is the authoritative parent-local target
                # pose.  Restoring only the ID property is insufficient after
                # native Pose Undo: Blender may also have restored the child
                # object's matrix_basis from an older global undo snapshot.
                # Synchronize both representations before the view-layer
                # update so it cannot evaluate the stale basis over the
                # restored world target and turn this into a blank step.
                if _pin_keyboard_matrices_differ(
                    guide.matrix_basis,
                    local_matrix,
                    epsilon=1.0e-8,
                ):
                    guide.matrix_basis = local_matrix
            except (
                AttributeError,
                ReferenceError,
                RuntimeError,
                TypeError,
                ValueError,
            ):
                pass

    for _owner_key, guide_name, before_matrix, after_matrix in transition.get(
        "guide_matrices", ()
    ):
        guide = bpy.data.objects.get(str(guide_name))
        expected = before_matrix if restore_index == 0 else after_matrix
        if (
            guide is not None
            and expected is not None
            and _pin_keyboard_matrices_differ(
                guide.matrix_world,
                expected,
                epsilon=1.0e-8,
            )
        ):
            guide.matrix_world = expected.copy()

    for armature_name, bone_name, before_keys, after_keys in transition.get(
        "action_keys", ()
    ):
        armature = bpy.data.objects.get(str(armature_name))
        pose_bone = (
            armature.pose.bones.get(str(bone_name))
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is None:
            continue
        _surface_contact_restore_action_key_snapshot(
            armature,
            pose_bone,
            frame,
            before_keys if restore_index == 0 else after_keys,
        )

    for owner_key, before_keys, after_keys in transition.get(
        "detached_key_states", ()
    ):
        guide = bpy.data.objects.get(str(owner_key[1]))
        if guide is None:
            continue
        _surface_contact_restore_detached_key_snapshot(
            guide,
            before_keys if restore_index == 0 else after_keys,
        )
        # Blender may have restored the matching FCurve before this handler
        # ran. The viewport and solver caches still belong to the old side.
        _surface_contact_invalidate_detached_key_cache(guide)

    for owner_key, before_attached, after_attached in transition.get(
        "attachments", ()
    ):
        guide = bpy.data.objects.get(str(owner_key[1]))
        if guide is None:
            continue
        attached = bool(
            before_attached if restore_index == 0 else after_attached
        )
        if attached:
            _surface_contact_clear_snap_departure(guide)
            _state.setdefault("pin_snap_latches", set()).add(
                _surface_contact_snap_key(guide)
            )
        else:
            snap_key = _surface_contact_snap_key(guide)
            _surface_contact_set_snap_detached(guide, True)
            _state.setdefault("pin_snap_latches", set()).discard(snap_key)
        _surface_contact_invalidate_detached_key_cache(guide)

    for _owner_key, guide_name, before_state, after_state in transition.get(
        "constraint_states", ()
    ):
        guide = bpy.data.objects.get(str(guide_name))
        if guide is None:
            continue
        _surface_contact_restore_constraint_history_state(
            guide,
            before_state if restore_index == 0 else after_state,
        )

    _surface_contact_set_history_pose_lock(
        transition,
        restore_index,
        append=append_lock,
    )
    _surface_contact_apply_history_pose_lock(
        context,
        update_view_layer=True,
    )
    # History handlers must restore the captured Blender state only. Updating
    # the reload snapshot here dirties ID data after Undo/Redo changed its
    # cursor, producing an invisible next step and invalidating later Redo.
    # save_pre and add-on unregister persist the currently restored pose.
    return True



def _surface_contact_restore_native_history_transition(
    context, previous_snapshot
):
    """Handle the matched side, restoring contact bones only when needed."""
    transition = _state.get("pin_snap_native_history_transition")
    if not transition and (
        _state.get("pin_history_active", False)
        or _state.get("pin_history_syncing", False)
    ):
        transition = _state.get(
            "pin_snap_native_history_transition_backup"
        )
        if transition:
            _state["pin_snap_native_history_transition"] = transition
    if not transition:
        return False

    expected_index = _state.get("pin_snap_native_history_expected_index")
    token_entries = tuple(transition.get("history_tokens", ()))
    token_authoritative = bool(
        expected_index in (0, 1) and token_entries
    )
    pre_tokens = dict(
        _state.get("pin_snap_native_history_pre_tokens", {})
    )
    if token_entries and pre_tokens and not any(
        int(bpy.data.objects.get(armature_name).get(
            SURFACE_CONTACT_HISTORY_TOKEN_PROPERTY,
            -1,
        )) != int(previous_token)
        for armature_name, previous_token in pre_tokens.items()
        if bpy.data.objects.get(armature_name) is not None
    ):
        return False
    if token_authoritative:
        for armature_name, before_token, after_token in token_entries:
            armature = bpy.data.objects.get(armature_name)
            expected_token = before_token if expected_index == 0 else after_token
            if (
                armature is None
                or int(armature.get(
                    SURFACE_CONTACT_HISTORY_TOKEN_PROPERTY,
                    -1,
                )) != int(expected_token)
            ):
                return False

    # A retained transition may outlive the next unrelated edit. Redo used to
    # restore its pink pose whenever the old driver merely still matched the
    # transition's "after" side, even if that driver did not participate in
    # this history step. Require an actual before/post change in at least one
    # transition-owned driver bone before this transition may write contacts.
    pre_selected = dict(
        _state.get("pin_snap_native_history_pre_selected", {})
    )
    # A retained Contact transition is valid only when the native bones that
    # created it changed during this history step. Blender also calls these
    # handlers for selection changes and unrelated regular-bone edits; those
    # callbacks must never replay an older Contact matrix. Compare the full
    # basis so location, rotation, and scale stay one transaction.
    if pre_selected:
        selected_changed = False
        for (armature_name, bone_name), previous in pre_selected.items():
            armature = bpy.data.objects.get(armature_name)
            pose_bone = (
                armature.pose.bones.get(bone_name)
                if armature is not None and getattr(armature, "pose", None)
                else None
            )
            if (
                pose_bone is not None
                and _pin_keyboard_matrices_differ(
                    pose_bone.matrix_basis,
                    previous,
                    epsilon=1.0e-6,
                )
            ):
                selected_changed = True
                break
        if not selected_changed:
            return False
    if pre_selected and not token_authoritative:
        driver_changed = False
        for (armature_name, bone_name), previous in pre_selected.items():
            armature = bpy.data.objects.get(armature_name)
            pose_bone = (
                armature.pose.bones.get(bone_name)
                if armature is not None and getattr(armature, "pose", None)
                else None
            )
            if (
                pose_bone is not None
                and _pin_keyboard_matrices_differ(
                    pose_bone.matrix_basis,
                    previous,
                    epsilon=1.0e-6,
                )
            ):
                driver_changed = True
                break
        if not driver_changed:
            return False

    previous_poses = dict((previous_snapshot or {}).get("poses", {}))

    def matrix_matches(matrix, expected):
        return not _pin_keyboard_matrices_differ(
            matrix, expected, epsilon=1.0e-6
        )

    def selected_matches(index):
        for entry in transition["selected"]:
            armature_name, bone_name, _before, _native, _solved = (
                contact_history_selected_entry(entry)
            )
            armature = bpy.data.objects.get(armature_name)
            pose_bone = (
                armature.pose.bones.get(bone_name)
                if armature is not None and getattr(armature, "pose", None)
                else None
            )
            if pose_bone is None or not any(
                matrix_matches(pose_bone.matrix_basis, expected)
                for expected in contact_history_entry_candidates(entry, index)
            ):
                return False
        return True

    def previous_contacts_match(index):
        for entry in transition["contacts"]:
            owner_key, _armature_name, _bone_name, _before, _native, _solved = (
                contact_history_contact_entry(entry)
            )
            signature = previous_poses.get(owner_key)
            if signature is None:
                return False
            matches = False
            for expected in contact_history_entry_candidates(
                entry, index, owner=True
            ):
                if not any(
                    abs(float(signature[(row * 4) + column])
                        - float(expected[row][column])) > 1.0e-6
                    for row in range(4)
                    for column in range(4)
                ):
                    matches = True
                    break
            if not matches:
                return False
        return True

    restore_index = expected_index
    if token_authoritative:
        restore_index = expected_index
    elif restore_index not in (0, 1) or not selected_matches(restore_index):
        restore_index = None
    if restore_index is None and selected_matches(0) and previous_contacts_match(1):
        restore_index = 0
    elif selected_matches(1) and previous_contacts_match(0):
        restore_index = 1
    if restore_index is None:
        return False

    _surface_contact_set_history_pose_lock(transition, restore_index)
    # Native G/R/S creates its Blender undo step before Contact's final solved
    # pose is committed. Keep the Action key on the same recognized history
    # side so the evaluation immediately following Redo cannot replace the
    # magnetized rotation with the old straight key. Undo writes the before
    # side and Redo writes the after side; this remains one user history step.
    for armature_name, bone_name, before_keys, after_keys in transition.get(
        "action_keys", ()
    ):
        owner = (armature_name, bone_name)
        armature = bpy.data.objects.get(armature_name)
        pose_bone = (
            armature.pose.bones.get(bone_name)
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is None:
            continue
        _surface_contact_restore_action_key_snapshot(
            armature,
            pose_bone,
            int(transition.get("frame", context.scene.frame_current)),
            before_keys if restore_index == 0 else after_keys,
        )
    _surface_contact_apply_history_pose_lock(
        context,
        update_view_layer=False,
    )
    # Runtime snap sets are intentionally outside Blender's ID history. Pair
    # them with the exact contact pose so Undo/Redo cannot briefly restore the
    # right limb matrix while leaving it in the opposite attach state.
    for owner_key, before_attached, after_attached in transition.get(
        "attachments", ()
    ):
        guide = bpy.data.objects.get(str(owner_key[1]))
        if guide is None:
            continue
        if bool(before_attached if restore_index == 0 else after_attached):
            _surface_contact_clear_snap_departure(guide)
        else:
            snap_key = _surface_contact_snap_key(guide)
            _surface_contact_set_snap_detached(guide, True)
            _state.setdefault("pin_snap_latches", set()).discard(snap_key)
    # This return reports that the transition side was recognized and fully
    # handled, not whether a matrix assignment happened. Blender can restore
    # the correct pink pose itself; treating that no-op as failure lets the
    # generic fallback overwrite the correct Redo pose one evaluation later.
    return True
