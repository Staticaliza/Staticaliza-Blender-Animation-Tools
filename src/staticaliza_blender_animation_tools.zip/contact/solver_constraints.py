"""Surface-contact solver constraints and stretch policy."""

from ..core.runtime import *  # noqa: F403

def _surface_contact_remove_constraint(owner, constraint):
    if owner is None or constraint is None:
        return False
    action = _dynamic_parent_owner_action(owner)
    try:
        data_path = constraint.path_from_id("influence")
    except (AttributeError, TypeError, ValueError):
        data_path = ""
    if action is not None and data_path:
        for fcurve in tuple(
            _fcurves_find_all(
                action,
                data_path,
                getattr(owner, "id_data", None) or owner,
            )
        ):
            _action_remove_fcurve(action, fcurve)
    try:
        owner.constraints.remove(constraint)
    except (AttributeError, ReferenceError, RuntimeError):
        return False
    return True


def _surface_contact_create_solver(context, guide, world_matrix):
    digest = guide.name.rsplit("_", 1)[-1]
    solver = bpy.data.objects.new(f"_SurfaceContactSolver_{digest}", None)
    armature = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
    )
    _ensure_space_helper_collection(context, armature).objects.link(solver)
    solver[SURFACE_CONTACT_SOLVER_PROPERTY] = True
    solver.empty_display_type = "PLAIN_AXES"
    solver.empty_display_size = 0.01
    solver.hide_render = True
    solver.hide_select = True
    solver.parent = guide
    solver.matrix_world = world_matrix
    try:
        solver.hide_set(True)
    except RuntimeError:
        pass
    guide[SURFACE_CONTACT_SOLVER_OBJECT_PROPERTY] = solver.name
    context.view_layer.update()
    return solver


def _surface_contact_stretch_state(guide):
    encoded = guide.get(SURFACE_CONTACT_STRETCH_STATE_PROPERTY)
    if not encoded:
        return {}
    try:
        state = json.loads(str(encoded))
    except (TypeError, ValueError):
        return {}
    return state if isinstance(state, dict) else {}


def _surface_contact_disable_stretch(
    guide,
    armature,
    bones,
    existing_constraint = None,
    existing_constraint_bone = "",
):
    if guide is None or armature is None:
        return False
    other_states = tuple(
        _surface_contact_stretch_state(other)
        for other in _surface_contact_guides()
        if other != guide
    )
    bone_state = {}
    for pose_bone in bones:
        if pose_bone is None:
            continue
        baseline = float(getattr(pose_bone, "ik_stretch", 0.0))
        for state in other_states:
            if str(state.get("armature", "")) != armature.name:
                continue
            stored = state.get("bones", {}).get(pose_bone.name)
            if stored is not None:
                baseline = float(stored)
                break
        bone_state[pose_bone.name] = baseline
        try:
            pose_bone.ik_stretch = 0.0
        except (AttributeError, RuntimeError, TypeError, ValueError):
            pass

    state = {
        "armature": armature.name,
        "bones": bone_state,
    }
    if existing_constraint is not None and hasattr(
        existing_constraint,
        "use_stretch",
    ):
        baseline = bool(existing_constraint.use_stretch)
        for other_state in other_states:
            stored = other_state.get("constraint", {})
            if (
                str(other_state.get("armature", "")) == armature.name
                and str(stored.get("bone", "")) == existing_constraint_bone
                and str(stored.get("name", "")) == existing_constraint.name
            ):
                baseline = bool(stored.get("use_stretch", baseline))
                break
        state["constraint"] = {
            "bone": str(existing_constraint_bone),
            "name": existing_constraint.name,
            "use_stretch": baseline,
        }
        existing_constraint.use_stretch = False

    guide[SURFACE_CONTACT_STRETCH_STATE_PROPERTY] = json.dumps(
        state,
        separators = (",", ":"),
        sort_keys = True,
    )
    return True


def _surface_contact_restore_stretch(guide):
    state = _surface_contact_stretch_state(guide)
    armature = bpy.data.objects.get(str(state.get("armature", "")))
    if armature is None or getattr(armature, "pose", None) is None:
        return False
    other_states = tuple(
        _surface_contact_stretch_state(other)
        for other in _surface_contact_guides()
        if other != guide
    )
    changed = False
    for bone_name, baseline in state.get("bones", {}).items():
        still_needed = any(
            str(other.get("armature", "")) == armature.name
            and bone_name in other.get("bones", {})
            for other in other_states
        )
        if still_needed:
            continue
        pose_bone = armature.pose.bones.get(str(bone_name))
        if pose_bone is None:
            continue
        try:
            pose_bone.ik_stretch = float(baseline)
            changed = True
        except (AttributeError, RuntimeError, TypeError, ValueError):
            pass

    stored_constraint = state.get("constraint", {})
    constraint_bone = str(stored_constraint.get("bone", ""))
    constraint_name = str(stored_constraint.get("name", ""))
    if constraint_bone and constraint_name:
        still_needed = any(
            str(other.get("armature", "")) == armature.name
            and str(other.get("constraint", {}).get("bone", ""))
            == constraint_bone
            and str(other.get("constraint", {}).get("name", ""))
            == constraint_name
            for other in other_states
        )
        owner = armature.pose.bones.get(constraint_bone)
        constraint = (
            owner.constraints.get(constraint_name)
            if owner is not None
            else None
        )
        if not still_needed and constraint is not None and hasattr(
            constraint,
            "use_stretch",
        ):
            constraint.use_stretch = bool(
                stored_constraint.get("use_stretch", False)
            )
            changed = True
    return changed



def _surface_contact_sync_stretch_policy(guides, frame):
    bone_policy = {}
    constraint_policy = {}
    for guide in guides:
        state = _surface_contact_stretch_state(guide)
        armature_name = str(state.get("armature", ""))
        if not armature_name:
            continue
        active = _surface_contact_guide_active_at(guide, int(frame))
        for bone_name, baseline in state.get("bones", {}).items():
            key = (armature_name, str(bone_name))
            policy = bone_policy.setdefault(
                key,
                {"baseline": float(baseline), "active": False},
            )
            policy["active"] = bool(policy["active"] or active)
        stored = state.get("constraint", {})
        if stored:
            key = (
                armature_name,
                str(stored.get("bone", "")),
                str(stored.get("name", "")),
            )
            policy = constraint_policy.setdefault(
                key,
                {
                    "baseline": bool(stored.get("use_stretch", False)),
                    "active": False,
                },
            )
            policy["active"] = bool(policy["active"] or active)

    changed = False
    for (armature_name, bone_name), policy in bone_policy.items():
        armature = bpy.data.objects.get(armature_name)
        pose_bone = (
            armature.pose.bones.get(bone_name)
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is None:
            continue
        desired = 0.0 if policy["active"] else float(policy["baseline"])
        if abs(float(getattr(pose_bone, "ik_stretch", 0.0)) - desired) > 1.0e-8:
            pose_bone.ik_stretch = desired
            changed = True
    for (armature_name, bone_name, constraint_name), policy in constraint_policy.items():
        armature = bpy.data.objects.get(armature_name)
        owner = (
            armature.pose.bones.get(bone_name)
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        constraint = (
            owner.constraints.get(constraint_name)
            if owner is not None
            else None
        )
        if constraint is None or not hasattr(constraint, "use_stretch"):
            continue
        desired = False if policy["active"] else bool(policy["baseline"])
        if bool(constraint.use_stretch) != desired:
            constraint.use_stretch = desired
            changed = True
    return changed


def _surface_contact_add_dot_constraint(
    context,
    guide,
    armature,
    effector,
    relation,
):
    digest = guide.name.rsplit("_", 1)[-1]
    control_object, control_bone_name, uses_existing_ik = (
        _surface_contact_control_target(relation, armature, effector)
    )
    control_world = _surface_contact_target_world_matrix(
        context,
        control_object,
        control_bone_name,
    )
    if control_world is None:
        return None, None

    # Preserve the existing control orientation when Contact is enabled. The
    # guide-relative solver matrix will carry later surface-normal changes.
    solver_world = control_world.normalized()
    solver_world.translation = guide.matrix_world.translation.copy()
    solver = _surface_contact_create_solver(context, guide, solver_world)

    rotation_constraint = None
    if uses_existing_ik:
        owner = (
            control_object.pose.bones.get(control_bone_name)
            if control_bone_name and getattr(control_object, "pose", None)
            else control_object
        )
        if owner is None:
            bpy.data.objects.remove(solver, do_unlink = True)
            return None, None
        constraint = owner.constraints.new("COPY_LOCATION")
        constraint.name = f"{SURFACE_CONTACT_CONSTRAINT_PREFIX}{digest}_Target"
        constraint.target = solver
        constraint.owner_space = "WORLD"
        constraint.target_space = "WORLD"
        if hasattr(constraint, "use_offset"):
            constraint.use_offset = False
        rotation_constraint = _surface_contact_create_rotation_constraint(
            owner,
            solver,
            f"{SURFACE_CONTACT_CONSTRAINT_PREFIX}{digest}_Aim",
        )
        guide[SURFACE_CONTACT_KIND_PROPERTY] = SURFACE_CONTACT_KIND_CONTROL
        guide[SURFACE_CONTACT_CHAIN_PROPERTY] = int(
            getattr(relation.get("constraint"), "chain_count", 1)
        )
    else:
        owner = effector
        constraint = None
        control_object = armature
        control_bone_name = effector.name
        guide[SURFACE_CONTACT_KIND_PROPERTY] = SURFACE_CONTACT_KIND_SIMULATED
        guide[SURFACE_CONTACT_CHAIN_PROPERTY] = 1

    existing_ik = relation.get("constraint") if uses_existing_ik else None
    existing_ik_bone = (
        relation.get("effector").name
        if uses_existing_ik and relation.get("effector") is not None
        else ""
    )
    stretch_bones = (
        relation.get("chain", ())
        if uses_existing_ik
        else (effector,)
    )
    _surface_contact_disable_stretch(
        guide,
        armature,
        stretch_bones,
        existing_ik,
        existing_ik_bone,
    )

    if constraint is not None:
        constraint.influence = 0.0
    if rotation_constraint is not None:
        rotation_constraint.influence = 0.0
    guide[SURFACE_CONTACT_PRIMARY_PROPERTY] = (
        constraint.name if constraint is not None else ""
    )
    guide[SURFACE_CONTACT_SECONDARY_PROPERTY] = (
        rotation_constraint.name if rotation_constraint is not None else ""
    )
    guide[SURFACE_CONTACT_ROTATION_BINDING_PROPERTY] = (
        1 if rotation_constraint is not None else 0
    )
    guide[SURFACE_CONTACT_CONSTRAINT_OBJECT_PROPERTY] = control_object.name
    guide[SURFACE_CONTACT_CONSTRAINT_BONE_PROPERTY] = control_bone_name
    guide[SURFACE_CONTACT_RELEASE_OBJECT_PROPERTY] = control_object.name
    guide[SURFACE_CONTACT_RELEASE_BONE_PROPERTY] = control_bone_name
    return constraint, solver


def _surface_contact_migrate_legacy_ik_guide(context, guide):
    if (
        str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
        != SURFACE_CONTACT_KIND_IK
    ):
        return False
    _constraint_object, owner = _surface_contact_constraint_owner_from_guide(
        guide
    )
    primary, _secondary = _surface_contact_constraints(guide)
    if (
        owner is None
        or primary is None
        or primary.type != "IK"
        or not primary.name.startswith(SURFACE_CONTACT_CONSTRAINT_PREFIX)
    ):
        return False

    armature = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
    )
    bone_name = str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
    preserved_world = (
        _surface_contact_target_world_matrix(context, armature, bone_name)
        if armature is not None
        else None
    )
    _surface_contact_remove_constraint(owner, primary)
    guide[SURFACE_CONTACT_PRIMARY_PROPERTY] = ""
    guide[SURFACE_CONTACT_KIND_PROPERTY] = SURFACE_CONTACT_KIND_SIMULATED
    guide[SURFACE_CONTACT_CHAIN_PROPERTY] = 1
    context.view_layer.update()
    if preserved_world is not None and armature is not None:
        _surface_contact_set_target_world_matrix(
            context,
            armature,
            bone_name,
            preserved_world,
        )
    return True
