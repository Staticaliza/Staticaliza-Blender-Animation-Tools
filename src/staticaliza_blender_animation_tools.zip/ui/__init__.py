"""Sidebar panels and UI-facing operators."""
