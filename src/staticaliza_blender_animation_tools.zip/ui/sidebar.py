"""Roblox Animator Utils sidebar anchor and main panel classes."""

from ..core.runtime import *  # noqa: F403


def _draw_selection_hint(layout, text):
    hint = layout.row(align = True)
    hint.active = False
    hint.label(text = text)

class VIEW3D_PT_animator_utils_roblox_animator_anchor(bpy.types.Panel):
    bl_label = "Roblox Animator"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Roblox Animator"
    bl_options = {"HIDE_HEADER"}

    @classmethod
    def poll(cls, context):
        return False

    def draw(self, context):
        pass


class VIEW3D_PT_animator_utils_main(bpy.types.Panel):
    bl_label = f"Roblox Animator Utils (v{ADDON_VERSION_DISPLAY})"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Roblox Animator Utils"

    def draw(self, context):
        wm = context.window_manager
        layout = self.layout
        if _state.get("extension_update_running", False):
            update_box = layout.box()
            update_box.label(text = "Extension Update", icon = "FILE_REFRESH")
            update_box.label(
                text = _state.get("extension_update_status", "")
                or "Updating extensions..."
            )
            # Do not retain disabled operator buttons while this extension is
            # about to unregister and replace its own RNA classes. Blender can
            # request a delayed tooltip from those buttons after unregistration.
            return
        advanced_mode = getattr(wm, "roblox_compat_advanced_mode", False)
        hide_advanced = not advanced_mode

        pose_rigs = layout.box()
        pose_rigs.label(text = "Active Armatures")
        armatures = _pose_panel_armatures(context)
        try:
            pose_session = set(context.objects_in_mode or ())
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            pose_session = set()
        if not armatures:
            pose_rigs.label(text = "No rigs in this scene.")
        for armature in armatures:
            row = pose_rigs.row(align = True)
            try:
                available = (
                    armature.name in context.view_layer.objects
                    and (
                        not armature.hide_get()
                        or _pose_armature_managed_hidden(armature)
                    )
                    and not armature.hide_viewport
                    and not armature.hide_select
                )
            except (AttributeError, ReferenceError):
                available = False
            row.enabled = available
            operator = row.operator(
                "staticaliza.toggle_pose_rig",
                text = _rig_display_name(armature.name),
                icon = "ARMATURE_DATA",
                depress = armature in pose_session,
            )
            operator.armature_name = armature.name
            if _rig_delete_bundle(armature) is not None:
                delete_column = row.column(align = True)
                delete_column.operator_context = "INVOKE_DEFAULT"
                delete_operator = delete_column.operator(
                    "staticaliza.delete_rig",
                    text = "",
                    icon = "TRASH",
                )
                delete_operator.armature_name = armature.name

        onion_tools = layout.box()
        onion_tools.label(text = "Onion Tools")

        onion = onion_tools.column(align = True)
        onion.label(text = "Onion Skin (F)")

        pose_scope = _pose_scope_armatures(context)
        row = onion.row(align = True)
        row.operator(
            "onion_skin.ghost_toggle",
            text = "Toggle",
            depress = bool(pose_scope) and all(
                _onion_owner_enabled(armature)
                for armature in pose_scope
            ),
        )

        if advanced_mode:
            col = onion.column()
            col.prop(wm, "onion_skin_opacity", text = "Opacity")

            row2 = col.row(align = True)
            row2.prop(wm, "onion_skin_include_meshes", text = "Meshes")
            row2.prop(wm, "onion_skin_include_bones", text = "Bones")

            col.prop(wm, "onion_skin_raycast", text = "Raycast")
            col.prop(wm, "onion_skin_skip_hidden", text = "Skip Hidden")

        if _state["last_error"]:
            err = onion.box()
            err.label(text = "Last Error:")
            err.label(text = _state["last_error"])

        onion_tools.separator()
        yellow = onion_tools.column(align = True)
        yellow.label(text = "Onion Pin (Shift + F)")
        selected_yellow_keys = _selected_owner_bone_keys(
            context,
            include_virtual_pin=True,
        )
        selected_pose_bones = tuple(
            _selected_pose_bones_only(context)
            if context.mode == "POSE"
            else ()
        )
        pinned_yellow_keys = set(_state.get("yellow_modes", {}))
        has_selected_yellow = bool(
            selected_yellow_keys.intersection(pinned_yellow_keys)
        )
        selected_yellow_count = len(
            selected_yellow_keys.intersection(pinned_yellow_keys)
        )
        if not selected_pose_bones and not has_selected_yellow:
            _draw_selection_hint(yellow, "Select a bone.")
        elif has_selected_yellow:
            rowy = yellow.row(align = True)
            remove_yellow = rowy.operator(
                "staticaliza.yellow_clear_all",
                text = (
                    "Remove Pin" if selected_yellow_count == 1
                    else "Remove Pins"
                ),
                icon = "TRASH",
            )
            remove_yellow.clear_scope = "SELECTED"
        else:
            rowy = yellow.row(align = True)
            create_yellow = rowy.operator(
                "staticaliza.yellow_apply",
                text = "Create Pin",
                icon = "PINNED",
            )
            create_yellow.action = wm.yellow_pin_mode
            create_yellow.position_mode = wm.yellow_pin_mode
            create_yellow.pin_axis = wm.yellow_pin_axis
        if has_selected_yellow:
            yellow_pivot = yellow.column(align = True)
            yellow_pivot.operator_context = "INVOKE_DEFAULT"
            yellow_pivot.operator(
                "staticaliza.yellow_pivot",
                text = (
                    "Pivot Pin" if selected_yellow_count == 1
                    else "Pivot Pins"
                ),
                icon = "PIVOT_CURSOR",
            )
        if advanced_mode:
            pinned_count = sum(
                len(_yellow_owner_map("yellow_modes", armature))
                for armature in pose_scope
            )
            hidden_scope = any(
                _yellow_owner_hidden(armature)
                for armature in pose_scope
            )
            yellow.label(
                text = f"Pinned: {pinned_count} | Hidden: {hidden_scope}"
            )

        dynamic_tools = layout.box()
        dynamic_tools.label(text = "Animation Tools (Ctrl + F)")

        dp = dynamic_tools.column(align = True)
        dp.label(text = "Dynamic Parent")
        parent_target = _dynamic_parent_target(context)
        parent_can_create = _dynamic_parent_can_create(context)
        parent_can_end = _dynamic_parent_can_end(context)
        parent_has_active = _dynamic_parent_has_active_segment(parent_target)
        parent_has_data = _dynamic_parent_has_data(parent_target)
        if not (
            parent_can_create
            or parent_can_end
            or parent_has_active
            or parent_has_data
        ):
            _draw_selection_hint(dp, "Select child, then parent.")
        else:
            rowdp = dp.row(align = True)
            parent_start = rowdp.column(align = True)
            parent_start.enabled = parent_can_create
            parent_start.operator(
                "dynamic_parent.create",
                text = "Key Start",
                icon = "KEY_HLT",
            )
            parent_end = rowdp.column(align = True)
            parent_end.enabled = parent_can_end
            parent_end.operator(
                "dynamic_parent.disable",
                text = "Key End",
                icon = "KEY_DEHLT",
            )

        if hide_advanced and parent_has_active:
            parent_clear = dp.column(align = True)
            parent_clear.operator(
                "dynamic_parent.clear",
                text = "Clear",
                icon = "X",
            )
        elif not hide_advanced and (parent_has_active or parent_has_data):
            rowdp2 = dp.row(align = True)
            if parent_has_active:
                parent_clear = rowdp2.column(align = True)
                parent_clear.operator(
                    "dynamic_parent.clear",
                    text = "Clear",
                    icon = "X",
                )
            if parent_has_data:
                parent_bake = rowdp2.column(align = True)
                parent_bake.operator(
                    "dynamic_parent.bake",
                    text = "Bake",
                    icon = "REC",
                )

        dynamic_tools.separator()
        unparent = dynamic_tools.column(align = True)
        unparent.label(text = "Dynamic Unparent")
        can_unparent_start, can_unparent_end, can_unparent_clear, can_unparent_bake = (
            _dynamic_unparent_ui_state(context)
        )
        unparent_has_subject = bool(
            context.mode == "POSE" and _single_active_pose_bone(context)
        )
        if not unparent_has_subject:
            _draw_selection_hint(unparent, "Select a bone.")
        else:
            unparent_actions = unparent.row(align = True)
            unparent_start = unparent_actions.column(align = True)
            unparent_start.enabled = can_unparent_start
            start_operator = unparent_start.operator(
                "staticaliza.unparent_action",
                text = "Key Start",
                icon = "KEY_HLT",
            )
            start_operator.action = "START"
            unparent_end = unparent_actions.column(align = True)
            unparent_end.enabled = can_unparent_end
            end_operator = unparent_end.operator(
                "staticaliza.unparent_action",
                text = "Key End",
                icon = "KEY_DEHLT",
            )
            end_operator.action = "END"

            if hide_advanced and can_unparent_clear:
                unparent_clear = unparent.column(align = True)
                clear_operator = unparent_clear.operator(
                    "staticaliza.unparent_action",
                    text = "Clear",
                    icon = "X",
                )
                clear_operator.action = "CLEAR"
            elif not hide_advanced and (
                can_unparent_clear or can_unparent_bake
            ):
                unparent_tools = unparent.row(align = True)
                if can_unparent_clear:
                    unparent_clear = unparent_tools.column(align = True)
                    clear_operator = unparent_clear.operator(
                        "staticaliza.unparent_action",
                        text = "Clear",
                        icon = "X",
                    )
                    clear_operator.action = "CLEAR"
                if can_unparent_bake:
                    unparent_bake = unparent_tools.column(align = True)
                    bake_operator = unparent_bake.operator(
                        "staticaliza.unparent_action",
                        text = "Bake",
                        icon = "REC",
                    )
                    bake_operator.action = "BAKE_TO_ENDING"

        dynamic_tools.separator()
        contact_tools = dynamic_tools.column(align = True)
        contact_tools.label(text = "Surface Contact")
        can_contact_create, can_contact_release, can_contact_clear, contact_status = (
            _surface_contact_ui_state(context)
        )
        contact_has_subject = bool(
            selected_pose_bones
            or any(
                target_data[0] == "CONTACT"
                for _key, target_data in _pin_selected_targets_data(context)
            )
        )
        if not contact_has_subject:
            _draw_selection_hint(contact_tools, "Select a bone or Contact pin.")
        else:
            if advanced_mode and contact_status:
                contact_tools.label(text = contact_status)
            contact_action_row = contact_tools.row(align = True)
            contact_create = contact_action_row.column(align = True)
            contact_create.enabled = can_contact_create
            contact_create.operator(
                "staticaliza.surface_contact_create",
                text = "Key Start",
                icon = "KEY_HLT",
            )
            contact_release = contact_action_row.column(align = True)
            contact_release.enabled = can_contact_release
            contact_release.operator(
                "staticaliza.surface_contact_release",
                text = "Key End",
                icon = "KEY_DEHLT",
            )
            if can_contact_clear:
                selected_contact_count = len(
                    _surface_contact_selected_guides(
                        context,
                        active_only = True,
                    )
                )
                contact_pivot = contact_tools.column(align = True)
                contact_pivot.operator_context = "INVOKE_DEFAULT"
                contact_pivot.operator(
                    "staticaliza.surface_contact_pivot",
                    text = (
                        "Pivot Pin" if selected_contact_count == 1
                        else "Pivot Pins"
                    ),
                    icon = "PIVOT_CURSOR",
                )
                contact_clear = contact_tools.column(align = True)
                contact_clear.operator(
                    "staticaliza.surface_contact_clear",
                    text = "Clear",
                    icon = "X",
                )
            if advanced_mode:
                contact_tools.prop(
                    wm,
                    "staticaliza_surface_contact_mode",
                    text = "Surface",
                )

        dynamic_tools.separator()
        camera_tools = dynamic_tools.column(align = True)
        camera_tools.label(text = "Camera")
        selected_camera_bones = tuple(_selected_camera_bones(context))
        _camera_armature, _camera_bone, attached_camera = _selected_camera_bone(context)
        if not selected_camera_bones:
            _draw_selection_hint(camera_tools, "Select a bone.")
        elif attached_camera is None:
            camera_tools.prop(
                wm,
                "staticaliza_camera_fov_preset",
                text = "Preset",
            )
            if wm.staticaliza_camera_fov_preset == "CUSTOM":
                camera_tools.prop(wm, "staticaliza_camera_fov", text = "FOV")
            camera_tools.prop(
                wm,
                "staticaliza_camera_orientation",
                text = "Axis",
            )
            add_camera = camera_tools.column(align = True)
            add_camera.operator_context = "INVOKE_DEFAULT"
            add_camera.operator(
                "staticaliza.add_bone_camera",
                text = _selected_camera_button_text(context),
                icon = "CAMERA_DATA",
            )
        else:
            camera_tools.prop(
                attached_camera,
                "staticaliza_camera_fov_preset",
                text = "Preset",
            )
            if attached_camera.staticaliza_camera_fov_preset == "CUSTOM":
                camera_tools.prop(attached_camera.data, "angle", text = "FOV")
            camera_tools.prop(
                attached_camera,
                "staticaliza_camera_orientation",
                text = "Axis",
            )
            camera_tools.prop(
                attached_camera,
                "staticaliza_camera_hide_attached_object",
                text = "Hide Attached Object",
            )
            camera_tools.prop(
                attached_camera,
                "staticaliza_camera_opaque_frame",
                text = "Opaque Camera Frame",
            )
            remove_camera = camera_tools.column(align = True)
            remove_camera.operator_context = "INVOKE_DEFAULT"
            remove_camera.operator(
                "staticaliza.add_bone_camera",
                text = _selected_camera_button_text(context),
                icon = "TRASH",
            )
            keyframe_camera = camera_tools.column(align = True)
            keyframe_camera.operator(
                "staticaliza.keyframe_camera_view",
                text = "Keyframe View",
                icon = "KEY_HLT",
            )

        transform_tools = layout.box()
        transform_tools.label(text = "Transform Tools")
        transform_tools.label(text = "Orientation (Y)")
        orientation = context.scene.transform_orientation_slots[0].type
        pivot_mode = getattr(wm, "staticaliza_pivot_mode", "BONE")
        orientation_row = transform_tools.row(align = True)
        global_op = orientation_row.operator(
            "staticaliza.set_transform_orientation",
            text = "Global",
            depress = orientation == "GLOBAL",
        )
        global_op.orientation = "GLOBAL"
        local_op = orientation_row.operator(
            "staticaliza.set_transform_orientation",
            text = "Local",
            depress = orientation == ("CURSOR" if pivot_mode == "PART" else "LOCAL"),
        )
        local_op.orientation = "LOCAL"

        transform_tools.label(text = "Pivot (Shift + Y)")
        pivot_row = transform_tools.row(align = True)
        bone_pivot = pivot_row.operator(
            "staticaliza.set_pivot_mode",
            text = "Bone",
            depress = pivot_mode == "BONE",
        )
        bone_pivot.pivot_mode = "BONE"
        # The operator can resolve the active rig, retained bone, virtual pin,
        # or first connected rig object without a current bone selection. Keep
        # the panel path available just like the Shift+Y shortcut.
        part_pivot = pivot_row.operator(
            "staticaliza.set_pivot_mode",
            text = "Object",
            depress = pivot_mode == "PART",
        )
        part_pivot.pivot_mode = "PART"

        smart_draggers = transform_tools.box()
        smart_draggers.prop(
            wm,
            "smart_draggers_enabled",
            text = "Smart Draggers",
        )
        if wm.smart_draggers_enabled:
            position_split = smart_draggers.split(factor = 0.42)
            position_split.label(text = "Position")
            position_split.prop(wm, "smart_dragger_mode", text = "")
            if wm.smart_dragger_mode == "MODE_3":
                axis_split = smart_draggers.split(factor = 0.42)
                axis_split.label(text = "Axis")
                axis_split.prop(wm, "smart_dragger_axis", text = "")
            else:
                disabled_axis = smart_draggers.row()
                disabled_axis.enabled = False
                disabled_axis.label(text = "Axis: N/A")
            smart_draggers.prop(
                wm,
                "smart_dragger_collision",
                text = "Surface Collision",
            )

        scene_setup = layout.box()
        scene_setup.label(text = "Scene Setup")
        scene_setup.operator_context = "INVOKE_DEFAULT"
        scene_setup.operator("staticaliza.load_template", text = "Load Template")

        if advanced_mode:
            materials = layout.box()
            materials.label(text = "Materials")
            materials.prop(wm, "smart_material_import_enabled", text = "Smart Material Import")
            materials.prop(
                wm,
                "standardize_imported_material_display_enabled",
                text = "Standardize Viewport Display",
            )
            materials.prop(
                wm,
                "prevent_clothing_layer_clipping_enabled",
                text = "Prevent Clothing Clipping",
            )
            materials.operator(
                "dynamic_parent.clear_material_links",
                text = "Clear",
                icon = "X",
            )

            miscellaneous = layout.box()
            miscellaneous.label(text = "Miscellaneous")
            miscellaneous.prop(
                wm,
                "show_bone_names_enabled",
                text = "Show Bone Names",
            )
            miscellaneous.prop(
                wm,
                "auto_clear_object_transforms_enabled",
                text = "Auto-Clear Object Transforms",
            )

        roblox = layout.box()
        roblox.label(text = "Extension")
        roblox.operator("staticaliza.install_roblox_animations", text = "Install Latest Extension")
        roblox.operator("staticaliza.open_roblox_plugins", text = "Install Roblox Plugins")
        roblox.prop(wm, "roblox_compat_advanced_mode", text = "Advanced Mode")
