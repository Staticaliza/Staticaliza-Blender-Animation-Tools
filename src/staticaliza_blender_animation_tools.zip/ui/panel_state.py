"""Shared sidebar state for contacts, dynamic parenting, and unparenting."""

from ..core.runtime import *  # noqa: F403

def _surface_contact_ui_state(context):
    if context.mode != "POSE":
        return False, False, False, ""
    frame = int(context.scene.frame_current)
    action_guides = _surface_contact_selected_guides(
        context,
        active_only = True,
    )
    selected_contacts = tuple(
        target_data
        for _key, target_data in _pin_selected_targets_data(context)
        if target_data[0] == "CONTACT"
    )
    if selected_contacts:
        active_contacts = tuple(
            target_data
            for target_data in selected_contacts
            if _surface_contact_guide_active_at(target_data[3], frame)
        )
        can_release = bool(
            any(
                frame
                > int(
                    target_data[3].get(
                        SURFACE_CONTACT_START_PROPERTY,
                        frame,
                    )
                )
                for target_data in active_contacts
            )
        )
        active_target = selected_contacts[0]
        armature, selected_bone, active_guide = active_target[1:4]
        surface_name = _surface_contact_guide_surface_label(active_guide)
        status = (
            f"{len(action_guides)} Contact pins selected"
            if len(action_guides) > 1
            else f"{selected_bone.name}: Contact on {surface_name}"
        )
        return (
            armature is not None and selected_bone is not None,
            can_release,
            bool(action_guides),
            status,
        )
    selected_targets = tuple(
        (armature, pose_bone)
        for armature, pose_bones in _selected_pose_bones_by_owner(
            context
        ).items()
        for pose_bone in pose_bones
    )
    if len(selected_targets) > 1:
        status = (
            f"{len(action_guides)} Contact pins selected"
            if action_guides
            else f"{len(selected_targets)} endpoints selected"
        )
        return (
            True,
            False,
            bool(action_guides),
            status,
        )
    selected_bone = _single_active_pose_bone(context)
    armature = _pose_bone_owner(context, selected_bone)
    if armature is None or selected_bone is None:
        return False, False, False, ""
    relation = _surface_contact_ik_relation(armature, selected_bone)
    effector = relation["effector"] if relation is not None else selected_bone
    endpoint_guides = _surface_contact_guides_for_effector(armature, effector)
    active_guides = tuple(
        guide
        for guide in endpoint_guides
        if _surface_contact_guide_active_at(guide, frame)
    )
    active_guide = (
        max(
            active_guides,
            key = lambda guide: int(
                guide.get(SURFACE_CONTACT_START_PROPERTY, -1048574)
            ),
        )
        if active_guides
        else None
    )
    if active_guide is not None:
        surface_name = _surface_contact_guide_surface_label(active_guide)
        status = f"{selected_bone.name}: Contact on {surface_name}"
    else:
        status = f"{selected_bone.name}: Free"
    can_create = armature is not None and effector is not None
    can_release = bool(
        active_guide is not None
        and int(context.scene.frame_current)
        > int(active_guide.get(SURFACE_CONTACT_START_PROPERTY, context.scene.frame_current))
    )
    return can_create, can_release, bool(action_guides), status


def _dynamic_unparent_ui_state(context):
    if context.mode != "POSE":
        return (False, False, False, False)

    selected_bone = _single_active_pose_bone(context)
    arm = _pose_bone_owner(context, selected_bone)
    if not arm or selected_bone is None:
        return (False, False, False, False)

    action = arm.animation_data.action if arm.animation_data else None
    frame = int(context.scene.frame_current)
    can_start = False
    can_end = False
    can_clear = False
    can_bake = False

    for pose_bone in (selected_bone,):
        marker_at_frame = bool(
            action is not None
            and _dynamic_marker_value(
                action,
                _unparent_dp(pose_bone.name),
                frame,
            ) is not None
        )
        auto_starts = _dp_auto_unparent_start_frames(pose_bone)
        active_start = (
            _unparent_find_active_start_frame(
                action,
                pose_bone.name,
                frame,
            )
            if action
            else None
        )
        active = bool(
            action
            and _unparent_eval(
                action,
                pose_bone.name,
                frame,
                pb_default = 0.0,
            ) >= 0.5
        )
        active_is_manual = bool(
            active
            and active_start is not None
            and int(active_start) not in auto_starts
        )
        active_is_auto = bool(
            active
            and active_start is not None
            and int(active_start) in auto_starts
        )
        if active_is_auto:
            continue
        has_parent = bool(
            pose_bone.parent
            or str(pose_bone.bone.get(REL_K_PARENT, ""))
        )
        manual_start, _manual_end = _unparent_nearest_segment(
            action,
            pose_bone.name,
            frame,
            excluded_starts = auto_starts,
        )
        has_markers = manual_start is not None
        can_start = can_start or (
            has_parent
            and not active
            and not marker_at_frame
        )
        can_end = can_end or bool(
            active_is_manual
            and active_start is not None
            and frame > int(active_start)
            and not marker_at_frame
        )
        can_clear = can_clear or active_is_manual
        can_bake = can_bake or has_markers

    return (can_start, can_end, can_clear, can_bake)

def _dynamic_parent_target(context):
    if context.mode == "POSE":
        return context.active_pose_bone
    if context.mode == "OBJECT":
        return context.active_object
    return None


def _dynamic_parent_has_data(target):
    if target is None:
        return False
    return any(
        constraint.name.startswith("DP_")
        and _dynamic_parent_constraint_segment(target, constraint)[0] is not None
        for constraint in target.constraints
    )


def _dynamic_parent_has_active_segment(target, frame = None):
    return get_last_dynamic_parent_constraint(target, frame) is not None


def _dynamic_parent_has_marker_at(target, frame):
    if target is None:
        return False
    action = _dynamic_parent_owner_action(target)
    if action is None:
        return False
    for constraint in getattr(target, "constraints", ()):
        if not constraint.name.startswith("DP_"):
            continue
        data_path = _dynamic_parent_marker_data_path(constraint)
        if not data_path:
            continue
        if _dynamic_marker_value(action, data_path, int(frame)) is not None:
            return True
    return False


def _dynamic_parent_can_create(context):
    target = _dynamic_parent_target(context)
    if (
        target is None
        or _dynamic_parent_has_marker_at(
            target,
            int(context.scene.frame_current),
        )
        or get_last_dynamic_parent_constraint(target) is not None
    ):
        return False
    if context.mode == "OBJECT":
        selected_objects = tuple(context.selected_objects or ())
        return len(selected_objects) == 2 and context.active_object in selected_objects
    if context.mode == "POSE":
        armature = context.active_object
        if armature is None or armature.type != "ARMATURE":
            return False
        _target, _subtarget, error = _dynamic_parent_pose_target(
            context,
            armature,
            context.active_pose_bone,
        )
        return not error
    return False


def _dynamic_parent_can_end(context):
    target = _dynamic_parent_target(context)
    if _dynamic_parent_has_marker_at(
        target,
        int(context.scene.frame_current),
    ):
        return False
    constraint = get_last_dynamic_parent_constraint(target)
    if constraint is None:
        return False
    start_frame, _end_frame = _dynamic_parent_constraint_segment(
        target,
        constraint,
    )
    return start_frame is None or int(context.scene.frame_current) > int(start_frame)
