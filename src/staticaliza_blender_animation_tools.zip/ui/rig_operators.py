"""Sidebar operators for active rigs, deletion, and viewport hover tracking."""

from ..core.runtime import *  # noqa: F403

class ANIMATOR_UTILS_OT_toggle_pose_rig(bpy.types.Operator):
    bl_idname = "staticaliza.toggle_pose_rig"
    bl_label = "Toggle Rig Pose Access"
    bl_description = "Include or exclude this rig from the current multi-rig Pose Mode session"
    bl_options = {"REGISTER"}

    armature_name: bpy.props.StringProperty(options = {"HIDDEN"})

    @classmethod
    def poll(cls, context):
        return context.mode in {"OBJECT", "POSE"}

    def execute(self, context):
        target = context.scene.objects.get(self.armature_name)
        if (
            target is None
            or target.type != "ARMATURE"
            or target.name not in context.view_layer.objects
        ):
            self.report({"WARNING"}, "Rig is not available in this view layer.")
            return {"CANCELLED"}

        pose_armatures = [
            obj
            for obj in getattr(context, "objects_in_mode", ())
            if obj.type == "ARMATURE" and obj.mode == "POSE"
        ]
        if not pose_armatures and context.mode == "POSE":
            active = context.active_object
            if (
                active is not None
                and active.type == "ARMATURE"
                and active.mode == "POSE"
            ):
                pose_armatures = [active]

        original_pose_armatures = list(pose_armatures)
        original_active = context.view_layer.objects.active
        original_selected = [
            obj
            for obj in context.view_layer.objects
            if obj.select_get()
        ]

        enabling = target not in pose_armatures
        desired = list(pose_armatures)
        if enabling:
            desired.append(target)
        else:
            desired = [armature for armature in desired if armature != target]
            if not desired:
                try:
                    if context.mode != "OBJECT":
                        bpy.ops.object.mode_set(mode = "OBJECT")
                    _restore_pose_session_armature_visibility()
                    _tag_redraw_all_view3d()
                    return {"FINISHED"}
                except (AttributeError, ReferenceError, RuntimeError) as exc:
                    self.report(
                        {"WARNING"},
                        f"Could not leave Pose Mode: {exc}",
                    )
                    return {"CANCELLED"}

        active = context.active_object
        if active not in desired:
            active = desired[0]

        unavailable = []
        for armature in set(original_pose_armatures + desired):
            try:
                available = bool(
                    armature.name in context.view_layer.objects
                    and not armature.hide_viewport
                    and not armature.hide_select
                )
            except (AttributeError, ReferenceError):
                available = False
            if not available:
                unavailable.append(_rig_display_name(armature.name))
        if unavailable:
            self.report(
                {"WARNING"},
                "Rig is hidden or selection-locked: " + ", ".join(unavailable),
            )
            return {"CANCELLED"}

        def select_armatures(armatures, active_armature):
            for obj in context.view_layer.objects:
                try:
                    obj.select_set(False)
                except (AttributeError, RuntimeError):
                    pass
            selected = []
            for armature in armatures:
                armature.select_set(True)
                if not armature.select_get():
                    raise RuntimeError(
                        f"{_rig_display_name(armature.name)} is not selectable"
                    )
                selected.append(armature)
            if not selected:
                raise RuntimeError("No selectable rigs remain")
            if active_armature not in selected:
                active_armature = selected[0]
            context.view_layer.objects.active = active_armature
            return selected

        try:
            # A hidden imported rig is a valid Pose-isolation target even when
            # its runtime marker was lost during reload/update.
            target.hide_set(False)
            # Calling mode_set(OBJECT) while already in Object Mode requires
            # an active object and fails when the user has deselected all.
            # Establish the requested armature as active before the only mode
            # transition that is actually needed.
            if context.mode != "OBJECT":
                bpy.ops.object.mode_set(mode = "OBJECT")
            selected = select_armatures(desired, active)
            _set_selected_armatures_pose_mode(context, selected, active)
        except (AttributeError, ReferenceError, RuntimeError) as exc:
            try:
                if context.mode != "OBJECT":
                    bpy.ops.object.mode_set(mode = "OBJECT")
                selected = select_armatures(
                    original_pose_armatures,
                    original_active,
                )
                _set_selected_armatures_pose_mode(
                    context,
                    selected,
                    original_active,
                )
                for obj in original_selected:
                    if obj.mode == "POSE":
                        obj.select_set(True)
                if (
                    original_active is not None
                    and original_active.mode == "POSE"
                ):
                    context.view_layer.objects.active = original_active
            except (AttributeError, ReferenceError, RuntimeError):
                pass
            self.report({"WARNING"}, f"Could not update Active Armatures: {exc}")
            return {"CANCELLED"}

        _sync_pose_session_armature_visibility(context)
        _ensure_persistent_pose_runtime(context)
        _tag_redraw_all_view3d()

        return {"FINISHED"}


class ANIMATOR_UTILS_OT_delete_rig(bpy.types.Operator):
    bl_idname = "staticaliza.delete_rig"
    bl_label = "Delete Rig"
    bl_description = (
        "Permanently delete this imported rig and only its unshared owned data"
    )
    bl_options = {"UNDO", "INTERNAL"}

    armature_name: bpy.props.StringProperty(options = {"HIDDEN"})
    @classmethod
    def poll(cls, context):
        return getattr(context, "scene", None) is not None

    def draw(self, context):
        layout = self.layout
        armature = bpy.data.objects.get(self.armature_name)
        display_name = _rig_display_name(
            armature.name if armature is not None else self.armature_name
        )
        warning = layout.box()
        warning.label(
            text = f'Delete rig "{display_name}"?',
            icon = "ERROR",
        )
        warning.label(text = "Its collection, parts, armature, metadata, and helpers will be removed.")
        warning.label(text = "Materials, images, actions, and helper data shared by another rig are kept.")
        warning.label(text = "You can undo this deletion.", icon = "LOOP_BACK")

    def invoke(self, context, _event):
        armature = bpy.data.objects.get(self.armature_name)
        if _rig_delete_bundle(armature) is None:
            self.report(
                {"ERROR"},
                "This armature is not owned by one unambiguous imported RIG collection.",
            )
            return {"CANCELLED"}
        # Keep the destructive confirmation, while INTERNAL prevents this
        # operator from lingering as an Adjust Last Operation HUD afterward.
        return context.window_manager.invoke_props_dialog(self, width = 460)

    def execute(self, context):
        armature = bpy.data.objects.get(self.armature_name)
        bundle = _rig_delete_bundle(armature)
        if bundle is None:
            self.report(
                {"ERROR"},
                "The selected imported rig no longer exists or has ambiguous ownership.",
            )
            return {"CANCELLED"}
        pose_scope = _pose_scope_armatures(context)
        survivor_names = tuple(
            current.name for current in pose_scope if current != armature
        )
        active_before = _active_armature(context)
        active_name = (
            active_before.name
            if active_before is not None and active_before != armature
            else (survivor_names[0] if survivor_names else "")
        )
        resume_pose = bool(getattr(context, "mode", "") == "POSE")

        owned_collections = _rig_delete_owned_collections(bundle["master"])
        owned_objects = _rig_delete_owned_objects(bundle, owned_collections)
        external_helpers, heuristic_helpers = _rig_delete_external_helpers(
            armature,
            owned_objects,
        )
        weld_helpers = _rig_delete_weld_helpers(armature)
        delete_objects = set(owned_objects) | set(external_helpers)
        delete_object_names = {obj.name for obj in delete_objects}
        inventory = _rig_delete_resource_inventory()
        for obj in delete_objects:
            _rig_delete_collect_object_resources(
                obj,
                inventory,
                heuristic = obj in heuristic_helpers,
            )
        _rig_delete_collect_rebuild_orphans(armature, inventory)

        if getattr(context, "mode", "") != "OBJECT":
            try:
                bpy.ops.object.mode_set(mode = "OBJECT")
            except (AttributeError, RuntimeError):
                if resume_pose and getattr(context, "mode", "") != "POSE":
                    rollback_names = tuple(
                        current.name for current in pose_scope
                    )
                    rollback_active_name = (
                        active_before.name if active_before is not None else ""
                    )
                    _rig_delete_reenter_pose(
                        context,
                        rollback_names,
                        rollback_active_name,
                    )
                elif resume_pose:
                    _sync_pose_session_armature_visibility(context)
                self.report({"ERROR"}, "Could not leave Pose Mode to delete the rig.")
                return {"CANCELLED"}
        _restore_pose_session_armature_visibility()
        _rig_delete_clear_runtime(
            armature,
            bundle,
            delete_object_names,
        )

        for guide in tuple(_surface_contact_guides()):
            if not _rig_delete_guide_linked_to_objects(
                guide,
                delete_object_names,
            ):
                continue

            try:
                _surface_contact_remove_guide(context, guide)
            except (AttributeError, ReferenceError, RuntimeError, ValueError):
                try:
                    bpy.data.objects.remove(guide, do_unlink = True)
                except (ReferenceError, RuntimeError):
                    pass

        removed_objects = 0
        for obj in sorted(
            delete_objects,
            key = lambda candidate: candidate == armature,
        ):
            try:
                if obj.type == "CAMERA":
                    _set_attached_camera_object_visibility(
                        context.scene,
                        obj,
                        False,
                    )
                    for scene in bpy.data.scenes:
                        if scene.camera == obj:
                            scene.camera = None
                if bpy.data.objects.get(obj.name) == obj:
                    bpy.data.objects.remove(obj, do_unlink = True)
                    removed_objects += 1
            except (AttributeError, ReferenceError, RuntimeError, TypeError):
                continue

        for helper in tuple(weld_helpers):
            try:
                if (
                    bpy.data.objects.get(helper.name) == helper
                    and getattr(helper, "library", None) is None
                    and not bool(getattr(helper, "use_fake_user", False))
                    and _rig_delete_real_users(helper) == 0
                    and not _rig_delete_weld_helper_still_used(helper)
                ):
                    _rig_delete_collect_object_resources(
                        helper,
                        inventory,
                        heuristic = True,
                    )
                    bpy.data.objects.remove(helper, do_unlink = True)
                    removed_objects += 1
            except (AttributeError, ReferenceError, RuntimeError, TypeError):
                continue

        removed_collections = 0
        master = bundle["master"]
        for collection in sorted(
            owned_collections,
            key = lambda candidate: candidate == master,
        ):
            try:
                if bpy.data.collections.get(collection.name) == collection:
                    bpy.data.collections.remove(collection, do_unlink = True)
                    removed_collections += 1
            except (AttributeError, ReferenceError, RuntimeError, TypeError):
                continue

        for helper_collection in tuple(bpy.data.collections):
            if not (
                helper_collection.name.startswith(SPACE_HELPER_COLLECTION)
                or helper_collection.name.startswith(
                    LEGACY_SPACE_HELPER_COLLECTION
                )
                or SPACE_HELPER_OWNER_UID_PROPERTY in helper_collection
            ):
                continue
            if tuple(helper_collection.objects) or tuple(helper_collection.children):
                continue
            try:
                bpy.data.collections.remove(helper_collection, do_unlink = True)
                removed_collections += 1
            except (ReferenceError, RuntimeError):
                pass

        removed_data = _rig_delete_remove_orphans(inventory)
        if resume_pose:
            _rig_delete_reenter_pose(context, survivor_names, active_name)
        _refresh_roblox_armature_list(context, force = True)
        _yellow_refresh_runtime(context)
        _tag_redraw_all_view3d()
        self.report(
            {"INFO"},
            f"Deleted {_rig_display_name(self.armature_name)}: "
            f"{removed_objects} objects, {removed_collections} collections, "
            f"and {removed_data} orphan data-blocks.",
        )
        return {"FINISHED"}


class ANIMATOR_UTILS_OT_track_rig_hover(bpy.types.Operator):
    bl_idname = "staticaliza.track_rig_hover"
    bl_label = "Track Rig Hover"
    bl_description = "Track viewport hover for inactive rig labels"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        if not (
            getattr(context, "mode", "") == "POSE"
            and getattr(getattr(context, "area", None), "type", "")
            == "VIEW_3D"
            and getattr(getattr(context, "region", None), "type", "")
            == "WINDOW"
            and getattr(context, "window", None) is not None
        ):
            return False
        # The selection timer maintains this cheap flag. Never scan every rig
        # from Blender's per-pixel mouse event path.
        return bool(_state.get("rig_hover_available", False))

    def invoke(self, context, event):
        window = getattr(context, "window", None)
        if window is None:
            return {"PASS_THROUGH"}
        key = int(window.as_pointer())
        point = (
            int(getattr(event, "mouse_x", -2147483648)),
            int(getattr(event, "mouse_y", -2147483648)),
        )
        hover = dict(_state.get("rig_hover_mouse", {}))
        if hover.get(key) != point:
            hover[key] = point
            _state["rig_hover_mouse"] = hover
            # Redraw only the viewport that owns this mouse event.  Tagging
            # every viewport on every pixel of motion caused avoidable gizmo
            # highlight churn in multi-window workspaces.
            area = getattr(context, "area", None)
            if area is not None:
                now = time.perf_counter()
                area_key = int(area.as_pointer())
                redraw_times = _state.setdefault(
                    "rig_hover_redraw_times",
                    {},
                )
                if now - float(redraw_times.get(area_key, 0.0)) >= (1.0 / 60.0):
                    redraw_times[area_key] = now
                    area.tag_redraw()
        return {"PASS_THROUGH"}
