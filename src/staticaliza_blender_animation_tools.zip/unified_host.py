"""Register three private tool packages as one installed Blender extension."""

from __future__ import annotations

import addon_utils
import bpy
import importlib
import os
import sys
import tempfile
import time
import urllib.request


HOST_PACKAGE = __package__
CHILDREN = (
    ("Roblox Animator", "roblox_animations_importer_exporter"),
    ("Roblox Animator Utils", "staticaliza_blender_animation_tools"),
    ("Roblox Animator Impact", "staticaliza_blender_animation_tools_impact"),
)
LEGACY_IMPACT_ID = "impaction_impact_frames"
UNIFIED_PACKAGE_URL = (
    "https://raw.githubusercontent.com/Staticaliza/"
    "Staticaliza-Blender-Animation-Tools/main/src/"
    "staticaliza_blender_animation_tools.zip"
)

_modules = []
_cleanup_attempts = 0
_status = "One extension; three N-panels."


def _bundled_name(addon_id):
    return f"{HOST_PACKAGE}.bundled.{addon_id}"


def _disable_external(addon_id):
    """Disable an old separate package, never the bundled replacement."""
    for module in tuple(addon_utils.modules(refresh=True)):
        name = str(getattr(module, "__name__", ""))
        if name != addon_id and not name.endswith(f".{addon_id}"):
            continue
        if name.startswith(f"{HOST_PACKAGE}.bundled."):
            continue
        try:
            if addon_utils.check(name)[1]:
                addon_utils.disable(name, default_set=True)
        except (AttributeError, RuntimeError, TypeError):
            pass
        prefix = f"{name}."
        for cached_name in tuple(sys.modules):
            if cached_name == name or cached_name.startswith(prefix):
                sys.modules.pop(cached_name, None)


def _disable_legacy_impact():
    _disable_external(LEGACY_IMPACT_ID)
    try:
        callback = bpy.app.driver_namespace.pop(
            "impaction_impact_frames.self_update_timer",
            None,
        )
        if callback is not None and bpy.app.timers.is_registered(callback):
            bpy.app.timers.unregister(callback)
    except (AttributeError, RuntimeError, ValueError):
        pass


def _repository():
    repositories = getattr(
        getattr(bpy.context.preferences, "extensions", None),
        "repos",
        (),
    )
    return next(
        (repository for repository in repositories
         if repository.module == "user_default"),
        None,
    )


def _repository_locked():
    try:
        from bl_pkg import cookie_from_session
        from bl_pkg.bl_extension_utils import repo_lock_directory_query
    except ImportError:
        return False
    repository = _repository()
    return bool(
        repository is not None
        and repo_lock_directory_query(
            repository.directory,
            cookie_from_session(),
        ) is not None
    )


def _remove_old_package_rows():
    """Remove obsolete child entries after Blender releases the repo lock."""
    global _cleanup_attempts
    if _repository_locked():
        _cleanup_attempts += 1
        return 0.5 if _cleanup_attempts <= 40 else None
    repository = _repository()
    if repository is None:
        return None
    _cleanup_attempts = 0
    for _label, addon_id in CHILDREN:
        _disable_external(addon_id)
        try:
            bpy.ops.extensions.package_uninstall(
                "EXEC_DEFAULT",
                repo_directory=repository.directory,
                pkg_id=addon_id,
            )
        except (AttributeError, RuntimeError, TypeError):
            pass
    return None


def _register_children():
    registered = []
    try:
        for _label, addon_id in CHILDREN:
            module = importlib.import_module(_bundled_name(addon_id))
            callback = getattr(module, "register", None)
            if not callable(callback):
                raise RuntimeError(f"Bundled child has no register(): {addon_id}")
            callback()
            registered.append(module)
    except Exception:
        for module in reversed(registered):
            try:
                module.unregister()
            except Exception:
                pass
        raise
    _modules[:] = registered


def _version_text(module):
    version = getattr(module, "ADDON_VERSION", None)
    if version is None:
        version = getattr(module, "bl_info", {}).get("version")
    if isinstance(version, (tuple, list)):
        return ".".join(str(value) for value in version)
    return str(version or "bundled")


def _download_update():
    handle, destination = tempfile.mkstemp(
        prefix="staticaliza_unified_",
        suffix=".zip",
    )
    os.close(handle)
    separator = "&" if "?" in UNIFIED_PACKAGE_URL else "?"
    request = urllib.request.Request(
        f"{UNIFIED_PACKAGE_URL}{separator}_cache_bust={time.time_ns()}",
        headers={
            "Cache-Control": "no-cache, no-store, max-age=0",
            "Pragma": "no-cache",
            "User-Agent": "Staticaliza-Blender-Animation-Tools",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            with open(destination, "wb") as output:
                while chunk := response.read(1024 * 1024):
                    output.write(chunk)
        return destination
    except Exception:
        try:
            os.remove(destination)
        except OSError:
            pass
        raise


def install_or_update():
    """Update the host package; never install three child packages again."""
    global _status
    if not getattr(bpy.app, "online_access", True):
        raise RuntimeError("Blender online access is disabled in Preferences.")
    package = _download_update()
    try:
        result = bpy.ops.extensions.package_install_files(
            "EXEC_DEFAULT",
            filepath=package,
            repo="user_default",
            enable_on_install=True,
            overwrite=True,
        )
        if "FINISHED" not in result:
            raise RuntimeError("Blender did not finish updating the extension.")
    finally:
        try:
            os.remove(package)
        except OSError:
            pass
    _status = "Unified extension updated. Restart Blender if panels are open."
    return True


class STATICALIZA_SETUP_OT_update_unified(bpy.types.Operator):
    bl_idname = "staticaliza_setup.update_unified_extension"
    bl_label = "Update Unified Extension"
    bl_description = "Update the one extension containing all three N-panels"

    def execute(self, context):
        del context
        global _status
        try:
            install_or_update()
        except Exception as exc:
            _status = f"Update failed: {exc}"
            self.report({"ERROR"}, _status)
            return {"CANCELLED"}
        self.report({"INFO"}, _status)
        return {"FINISHED"}


class STATICALIZA_UNIFIED_preferences(bpy.types.AddonPreferences):
    bl_idname = HOST_PACKAGE

    def draw(self, context):
        del context
        layout = self.layout
        layout.label(text="One extension; three N-panels")
        for (label, _addon_id), module in zip(CHILDREN, _modules):
            layout.label(text=f"{label}: {_version_text(module)}")
        layout.label(text=_status)
        layout.operator(STATICALIZA_SETUP_OT_update_unified.bl_idname)


CLASSES = (
    STATICALIZA_SETUP_OT_update_unified,
    STATICALIZA_UNIFIED_preferences,
)


def register():
    for _label, addon_id in CHILDREN:
        _disable_external(addon_id)
    _disable_legacy_impact()
    _register_children()
    try:
        for cls in CLASSES:
            bpy.utils.register_class(cls)
    except Exception:
        for module in reversed(_modules):
            try:
                module.unregister()
            except Exception:
                pass
        _modules.clear()
        raise
    if not bpy.app.timers.is_registered(_remove_old_package_rows):
        bpy.app.timers.register(_remove_old_package_rows, first_interval=0.5)


def unregister():
    if bpy.app.timers.is_registered(_remove_old_package_rows):
        bpy.app.timers.unregister(_remove_old_package_rows)
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    for module in reversed(_modules):
        try:
            module.unregister()
        except Exception:
            pass
    _modules.clear()
