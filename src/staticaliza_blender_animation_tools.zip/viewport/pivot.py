"""Bone/object pivot selection and transform-orientation controls."""

from ..core.runtime import *  # noqa: F403
def _part_pivot_selected_bone(context):
    selected = _selected_pose_bones_only(context)
    active_bone = context.active_pose_bone
    if active_bone not in selected:
        active_bone = selected[0] if selected else None
    if active_bone is None and context.mode == "POSE":
        # Blender retains an active pose bone after its selection flag is
        # cleared.  Object pivot mode can still resolve that bone without
        # changing the user's visible selection.
        retained_active = getattr(context, "active_pose_bone", None)
        if _pose_bone_owner(context, retained_active) is not None:
            active_bone = retained_active
    if active_bone is None:
        # A virtual pin owns an active bone even though its normal-click
        # selection intentionally leaves every Pose selection flag clear.
        # Keep Object-pivot matching alive for that pin-only state.
        try:
            _pin_key, pin_target = _pin_selected_target_data(context)
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            pin_target = None
        if pin_target is not None:
            active_bone = pin_target[2]
    if active_bone is None:
        last_armature = _armature_from_session_uid(
            _state.get("part_pivot_last_armature", 0)
        )
        if last_armature is not None and getattr(last_armature, "pose", None):
            active_bone = last_armature.pose.bones.get(
                str(_state.get("part_pivot_last_bone", ""))
            )
    return active_bone


def _part_pivot_connected_object(
    context,
    armature,
    eval_armature,
    objects,
    pose_bone,
    include_hidden = False,
):
    canonical_name = _strip_blender_numeric_suffix(pose_bone.name)
    candidates = {}

    family_levels = list(
        _pose_bone_numeric_family_levels(eval_armature, pose_bone)
    )
    numbered_names = set().union(*family_levels)
    family_names = _surface_contact_bone_family_names(
        eval_armature,
        pose_bone,
    )
    weld_names = family_names - numbered_names
    if weld_names:
        family_levels.append(weld_names)

    target_objects = set(objects or ())
    target_objects.update(_surface_contact_rig_objects(armature))
    parts_collection = _find_roblox_parts_collection(armature)
    if parts_collection is not None:
        target_objects.update(parts_collection.all_objects)
    connected_objects = set(
        _surface_contact_connected_objects(
            context,
            armature,
            family_names,
        )
    )
    target_objects.update(connected_objects)
    search_objects = tuple(
        obj
        for obj in context.view_layer.objects
        if obj in target_objects and obj != armature
    )

    for level_index, level_names in enumerate(family_levels):
        for obj in search_objects:
            if (
                obj.type != "MESH"
                or (
                    not include_hidden
                    and not _is_object_visible(obj, context)
                )
            ):
                continue

            exact_name = obj.name == canonical_name
            matching_name = _strip_blender_numeric_suffix(obj.name) == canonical_name
            object_bone_names = _surface_contact_object_bone_names(
                obj,
                armature,
            )
            directly_connected = bool(object_bone_names & level_names)
            family_connected = bool(object_bone_names & family_names)
            belongs_to_family = (
                directly_connected
                or family_connected
                or obj in connected_objects
            )
            if not (exact_name or matching_name or directly_connected):
                continue
            if not belongs_to_family and obj not in target_objects:
                continue

            score = (
                0
                if directly_connected
                else 1
                if family_connected or obj in connected_objects
                else 2,
                0 if exact_name else 1 if matching_name else 2,
                level_index,
                1 if _object_has_linked_base_color(obj) else 0,
                obj.name.casefold(),
            )
            previous = candidates.get(obj.name)
            if previous is None or score < previous[0]:
                candidates[obj.name] = (score, obj)

    if not candidates:
        return None
    return min(candidates.values(), key = lambda item: item[0])[1]


def _part_pivot_object_local_center(evaluated_part):
    local_bounds = None
    for corner in evaluated_part.bound_box:
        point = Vector(corner)
        if local_bounds is None:
            local_bounds = _bounds_init(point)
        else:
            _bounds_add(local_bounds, point)
    if local_bounds is None:
        return None
    return Vector((
        (float(local_bounds[0]) + float(local_bounds[3])) * 0.5,
        (float(local_bounds[1]) + float(local_bounds[4])) * 0.5,
        (float(local_bounds[2]) + float(local_bounds[5])) * 0.5,
        1.0,
    ))


def _part_pivot_bone_object_target(context, armature, pose_bone):
    """Resolve only this bone's welded object, never another family fallback."""
    if armature is None or pose_bone is None:
        return None
    depsgraph = context.evaluated_depsgraph_get()
    eval_armature = armature.evaluated_get(depsgraph)
    eval_pose_bone = eval_armature.pose.bones.get(pose_bone.name)
    if eval_pose_bone is None:
        return None
    objects, _target_armature = _targets(context, armature)
    part = _part_pivot_connected_object(
        context,
        armature,
        eval_armature,
        objects,
        eval_pose_bone,
    )
    if part is None:
        return None
    local_center = _part_pivot_object_local_center(
        part.evaluated_get(depsgraph)
    )
    if local_center is None:
        return None
    return part, local_center


def _part_pivot_bone_object_world_center(context, armature, pose_bone):
    target = _part_pivot_bone_object_target(context, armature, pose_bone)
    if target is None:
        return None
    part, local_center = target
    evaluated_part = part.evaluated_get(context.evaluated_depsgraph_get())
    return Vector((evaluated_part.matrix_world @ _as_p4(local_center))[:3])


def _part_pivot_selection_targets(context):
    """Return every explicitly selected bone, including virtual pin owners."""
    candidates = []
    for armature, pose_bones in _selected_pose_bones_by_owner(context).items():
        candidates.extend((armature, pose_bone) for pose_bone in pose_bones)
    try:
        candidates.extend(
            (target_data[1], target_data[2])
            for _key, target_data in _pin_selected_targets_data(context)
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        pass
    active_bone = (
        _part_pivot_selected_bone(context)
        if context.mode == "POSE"
        else None
    )
    active_armature = _pose_bone_owner(context, active_bone)
    if active_armature is not None and active_bone is not None:
        candidates.insert(0, (active_armature, active_bone))
    seen = set()
    ordered = []
    for armature, pose_bone in candidates:
        if armature is None or pose_bone is None:
            continue
        key = _owner_bone_key(armature, pose_bone.name)
        if key in seen:
            continue
        seen.add(key)
        ordered.append((armature, pose_bone))
    return tuple(ordered)


def _part_pivot_selection_signature(context):
    return tuple(
        _owner_bone_key(armature, pose_bone.name)
        for armature, pose_bone in _part_pivot_selection_targets(context)
    )


def _part_pivot_target(context):
    if context.mode != "POSE":
        return None

    matches = []
    seen_objects = set()
    for armature, pose_bone in _part_pivot_selection_targets(context):
        target = _part_pivot_bone_object_target(
            context,
            armature,
            pose_bone,
        )
        if target is not None:
            part, local_center = target
            if part.name in seen_objects:
                continue
            seen_objects.add(part.name)
            matches.append(
                (armature, pose_bone, part, local_center.copy())
            )
    if not matches:
        return None
    armature, active_bone, part, local_center = matches[0]
    object_targets = tuple(
        (matched_part.name, matched_center.copy())
        for _owner, _bone, matched_part, matched_center in matches
    )
    return (
        int(armature.as_pointer()),
        active_bone.name,
        part.name,
        local_center,
        object_targets,
    )


def _view3d_spaces(context):
    window_manager = getattr(context, "window_manager", None)
    for window in getattr(window_manager, "windows", ()) if window_manager else ():
        screen = getattr(window, "screen", None)
        for area in getattr(screen, "areas", ()) if screen else ():
            if area.type != "VIEW_3D":
                continue
            for space in area.spaces:
                if space.type == "VIEW_3D":
                    yield space


def _hide_part_pivot_cursor(context):
    visibility = _state.setdefault("part_pivot_cursor_visibility", {})
    for space in _view3d_spaces(context):
        pointer = int(space.as_pointer())
        if pointer not in visibility:
            visibility[pointer] = bool(space.overlay.show_cursor)
        if space.overlay.show_cursor:
            space.overlay.show_cursor = False


def _restore_part_pivot_cursor(context):
    visibility = _state.get("part_pivot_cursor_visibility", {})
    for space in _view3d_spaces(context):
        pointer = int(space.as_pointer())
        if pointer in visibility:
            space.overlay.show_cursor = bool(visibility[pointer])
    _state["part_pivot_cursor_visibility"] = {}


def _sync_part_pivot(context, rematch = False):
    window_manager = getattr(context, "window_manager", None)
    if window_manager is None:
        return False
    if getattr(window_manager, "staticaliza_pivot_mode", "BONE") != "PART":
        return False
    if _state.get("part_pivot_syncing", False):
        return True

    _state["part_pivot_syncing"] = True
    try:
        active_bone = _part_pivot_selected_bone(context) if context.mode == "POSE" else None
        armature = (
            _pose_bone_owner(context, active_bone) or _active_armature(context)
            if active_bone is not None
            else _active_armature(context)
        )
        armature_pointer = int(armature.as_pointer()) if armature else 0
        bone_name = active_bone.name if active_bone else ""
        selection_signature = _part_pivot_selection_signature(context)
        if (
            rematch
            or armature_pointer != _state.get("part_pivot_armature", 0)
            or bone_name != _state.get("part_pivot_bone", "")
            or selection_signature
            != _state.get("part_pivot_selection_signature", ())
            or not _state.get("part_pivot_object", "")
        ):
            _state["part_pivot_armature"] = armature_pointer
            _state["part_pivot_bone"] = bone_name
            _state["part_pivot_object"] = ""
            _state["part_pivot_object_local"] = None
            _state["part_pivot_objects"] = ()
            _state["part_pivot_selection_signature"] = selection_signature
            _state["part_pivot_last_signature"] = None
            target = _part_pivot_target(context)
            if target is None:
                return False
            (
                armature_pointer,
                bone_name,
                object_name,
                local_center,
                object_targets,
            ) = target
            _state["part_pivot_armature"] = armature_pointer
            _state["part_pivot_bone"] = bone_name
            _state["part_pivot_object"] = object_name
            _state["part_pivot_object_local"] = local_center.copy()
            _state["part_pivot_objects"] = object_targets
            _state["part_pivot_last_signature"] = None
            _state["part_pivot_last_armature"] = armature_pointer
            _state["part_pivot_last_bone"] = bone_name

        object_targets = tuple(_state.get("part_pivot_objects", ()))
        if not object_targets:
            return False

        depsgraph = context.evaluated_depsgraph_get()
        evaluated_targets = []
        for object_name, target_center in object_targets:
            target_part = bpy.data.objects.get(str(object_name))
            if target_part is None:
                continue
            evaluated_targets.append(
                (target_part.evaluated_get(depsgraph), target_center)
            )
        if not evaluated_targets:
            return False
        part = evaluated_targets[0][0]
        eval_part = part.evaluated_get(depsgraph)
        matrix_signature = tuple(
            (
                evaluated_part.name,
                tuple(
                    float(value)
                    for row in evaluated_part.matrix_world
                    for value in row
                ),
            )
            for evaluated_part, _center in evaluated_targets
        )
        signature = (
            armature_pointer,
            bone_name,
            selection_signature,
            matrix_signature,
        )
        _hide_part_pivot_cursor(context)
        world_points = tuple(
            Vector((
                evaluated_part.matrix_world @ _as_p4(target_center)
            )[:3])
            for evaluated_part, target_center in evaluated_targets
        )
        world_location = (
            sum(world_points, Vector((0.0, 0.0, 0.0)))
            / len(world_points)
        )
        world_rotation = eval_part.matrix_world.to_quaternion().normalized()
        cursor = context.scene.cursor
        same_location = (cursor.location - world_location).length_squared <= 1.0e-16
        same_rotation = (
            cursor.rotation_mode == "QUATERNION"
            and abs(float(cursor.rotation_quaternion.dot(world_rotation)))
            >= 1.0 - 1.0e-10
        )
        if context.scene.tool_settings.transform_pivot_point != "CURSOR":
            context.scene.tool_settings.transform_pivot_point = "CURSOR"
        slot = context.scene.transform_orientation_slots[0]
        if slot.type == "LOCAL":
            slot.type = "CURSOR"
        if (
            signature == _state.get("part_pivot_last_signature")
            and same_location
            and same_rotation
        ):
            return True

        cursor.location = world_location
        context.scene.cursor.rotation_mode = "QUATERNION"
        cursor.rotation_quaternion = world_rotation
        _state["part_pivot_last_signature"] = signature
        return True
    finally:
        _state["part_pivot_syncing"] = False


def _disable_part_pivot(context):
    _restore_part_pivot_cursor(context)
    saved = _state.get("part_pivot_saved")
    if saved is not None:
        cursor = context.scene.cursor
        context.scene.tool_settings.transform_pivot_point = saved["pivot_point"]
        cursor.location = saved["cursor_location"]
        cursor.rotation_mode = "QUATERNION"
        cursor.rotation_quaternion = saved["cursor_rotation"]
        cursor.rotation_mode = saved["cursor_rotation_mode"]

    slot = context.scene.transform_orientation_slots[0]
    if slot.type == "CURSOR":
        slot.type = "LOCAL"

    window_manager = getattr(context, "window_manager", None)
    if window_manager is not None:
        window_manager.staticaliza_pivot_mode = "BONE"
    _state["part_pivot_bone"] = ""
    _state["part_pivot_armature"] = 0
    _state["part_pivot_object"] = ""
    _state["part_pivot_object_local"] = None
    _state["part_pivot_objects"] = ()
    _state["part_pivot_selection_signature"] = ()
    _state["part_pivot_saved"] = None
    _state["part_pivot_last_signature"] = None
    _tag_redraw_all_view3d()


@persistent
def _part_pivot_depsgraph_update(_scene, _depsgraph):
    context = bpy.context
    window_manager = getattr(context, "window_manager", None)
    if (
        window_manager is not None
        and not _pin_primary_mouse_pressed()
        and not _window_manager_has_modal_operator(context)
        and getattr(window_manager, "staticaliza_pivot_mode", "BONE") == "PART"
    ):
        _sync_part_pivot(context)


@persistent
def _part_pivot_frame_change_post(_scene, _depsgraph):
    _part_pivot_depsgraph_update(_scene, _depsgraph)


def _part_pivot_selection_timer():
    context = bpy.context
    window_manager = getattr(context, "window_manager", None)
    if (
        window_manager is None
        or getattr(window_manager, "staticaliza_pivot_mode", "BONE") != "PART"
    ):
        return 0.2
    if (
        _pin_primary_mouse_pressed()
        or _window_manager_has_modal_operator(context)
    ):
        return 0.05

    active_bone = _part_pivot_selected_bone(context) if context.mode == "POSE" else None
    armature = (
        _pose_bone_owner(context, active_bone) or _active_armature(context)
        if active_bone is not None
        else _active_armature(context)
    )
    armature_pointer = int(armature.as_pointer()) if armature else 0
    bone_name = active_bone.name if active_bone else ""
    selection_signature = _part_pivot_selection_signature(context)
    changed = (
        armature_pointer != _state.get("part_pivot_armature", 0)
        or bone_name != _state.get("part_pivot_bone", "")
        or selection_signature
        != _state.get("part_pivot_selection_signature", ())
    )
    if changed:
        if active_bone is None:
            _state["part_pivot_armature"] = armature_pointer
            _state["part_pivot_bone"] = ""
            _state["part_pivot_object"] = ""
            _state["part_pivot_object_local"] = None
            _state["part_pivot_objects"] = ()
            _state["part_pivot_selection_signature"] = ()
            _state["part_pivot_last_signature"] = None
        else:
            _sync_part_pivot(context, rematch = True)
        _tag_redraw_all_view3d()
    return 0.05


def _bone_label_selection_timer():
    context = bpy.context
    window_manager = getattr(context, "window_manager", None)
    if window_manager is None:
        return 0.1
    if _pin_primary_mouse_pressed():
        return 0.05
    if _window_manager_has_modal_operator(context):
        # Dynamic Parent's dual-selection lock is the only maintenance that
        # must follow an established transform modal. It does not run in the
        # physical press gap above.
        if _sync_dynamic_parent_dual_selection_locks(context):
            _tag_redraw_all_view3d()
        return 0.05

    _sync_animation_editors_pose_mode(context)

    panel_armatures = _pose_panel_armatures(context)
    if not panel_armatures:
        _state["rig_hover_available"] = False
        _state["pin_gizmo_available_kinds"] = frozenset()
        _poll_rig_hover_targets(context)
        _state["bone_label_selection_signature"] = (
            bool(getattr(window_manager, "show_bone_names_enabled", True)),
            str(getattr(context, "mode", "")),
            0,
            "",
            0,
            (),
        )
        if _state.get("enabled", False):
            _disable_runtime()
        return 0.25

    if getattr(context, "mode", "") == "POSE":
        active_uids = {
            _armature_session_uid(armature)
            for armature in _pose_scope_armatures(context)
        }
        _state["rig_hover_available"] = any(
            _armature_session_uid(armature) not in active_uids
            for armature in panel_armatures
        )
    else:
        _state["rig_hover_available"] = False
    # Keep timer-driven maintenance out of Blender's native modal event path.
    # Dynamic Parent's dual-selection lock is the sole transform-time task;
    # everything that can reorder channels, alter visibility, or refresh draw
    # state waits until the user's interaction is finished.
    _poll_rig_hover_targets(context)
    _pin_gizmo_refresh_availability(context)

    _ensure_persistent_pose_runtime(context)
    presentation_visibility_changed = _sync_presentation_viewport_overlays(
        context
    )
    if not _animation_playback_active(context):
        _maintain_armature_action_channels(context)
    visibility_changed = _sync_pose_session_armature_visibility(context)
    _sync_selected_camera_as_active(context)
    if _sync_dynamic_parent_dual_selection_locks(context):
        _tag_redraw_all_view3d()

    if _pin_gizmo_track_selection(context):
        _tag_redraw_all_view3d()

    armature, pose_bone = _selected_bone_label_target(context)
    active_object = getattr(context, "active_object", None)
    selected_keys = tuple(sorted(_selected_owner_bone_keys(context)))
    signature = (
        bool(getattr(window_manager, "show_bone_names_enabled", True)),
        str(getattr(context, "mode", "")),
        _armature_session_uid(armature),
        pose_bone.name if pose_bone is not None else "",
        int(active_object.as_pointer()) if active_object is not None else 0,
        selected_keys,
    )
    if signature == _state.get("bone_label_selection_signature"):
        if (
            not _state.get("enabled", False)
            and (
                _custom_bone_label_targets(context)[1]
                or _dynamic_parent_visible_relationships(context)
            )
        ):
            _yellow_refresh_runtime(context)
        if visibility_changed or presentation_visibility_changed:
            _yellow_refresh_runtime(context)
        return 0.1

    _state["bone_label_selection_signature"] = signature
    advanced_mode = bool(
        getattr(window_manager, "roblox_compat_advanced_mode", False)
    )
    _sync_armature_debug_overlays(advanced_mode, False)
    _yellow_refresh_runtime(context)
    return 0.1


class ANIMATOR_UTILS_OT_set_transform_orientation(bpy.types.Operator):
    bl_idname = "staticaliza.set_transform_orientation"
    bl_label = "Set Transform Orientation"
    bl_description = "Set or toggle the 3D View transform orientation between Global and Local"
    bl_options = {"REGISTER"}

    orientation: bpy.props.EnumProperty(
        items = (
            ("TOGGLE", "Toggle", "Toggle between Global and Local"),
            ("GLOBAL", "Global", "Use Global transform orientation"),
            ("LOCAL", "Local", "Use Local transform orientation"),
        ),
        default = "TOGGLE",
        options = {"SKIP_SAVE"},
    )

    def execute(self, context):
        pin_selection = _pin_selection_runtime_snapshot()
        slot = context.scene.transform_orientation_slots[0]
        target = self.orientation
        part_mode = (
            getattr(context.window_manager, "staticaliza_pivot_mode", "BONE")
            == "PART"
        )
        if target == "TOGGLE":
            local_types = {"CURSOR"} if part_mode else {"LOCAL"}
            target = "GLOBAL" if slot.type in local_types else "LOCAL"

        if target == "LOCAL" and part_mode:
            slot.type = "CURSOR" if _sync_part_pivot(context) else "LOCAL"
        else:
            slot.type = target
        _pin_selection_runtime_restore(context, pin_selection)
        self.report({"INFO"}, f"Transform orientation: {target.title()}")
        return {"FINISHED"}
class ANIMATOR_UTILS_OT_set_pivot_mode(bpy.types.Operator):
    bl_idname = "staticaliza.set_pivot_mode"
    bl_label = "Set Pivot Mode"
    bl_description = "Toggle between the normal bone pivot and the connected object pivot"
    bl_options = {"REGISTER"}

    pivot_mode: bpy.props.EnumProperty(
        items = (
            ("TOGGLE", "Toggle", "Toggle between Bone and Object pivot modes"),
            ("BONE", "Bone", "Use Blender's normal bone pivot"),
            ("PART", "Object", "Use the midpoint of all selected bones' and pins' connected rig objects"),
        ),
        default = "TOGGLE",
        options = {"SKIP_SAVE"},
    )

    def execute(self, context):
        pin_selection = _pin_selection_runtime_snapshot()
        window_manager = context.window_manager
        current = getattr(window_manager, "staticaliza_pivot_mode", "BONE")
        target = self.pivot_mode
        if target == "TOGGLE":
            target = "PART" if current == "BONE" else "BONE"

        if target == "BONE":
            _disable_part_pivot(context)
            _pin_selection_runtime_restore(context, pin_selection)
            self.report({"INFO"}, "Pivot mode: Bone")
            return {"FINISHED"}
        if current != "PART":
            cursor = context.scene.cursor
            original_rotation_mode = cursor.rotation_mode
            cursor.rotation_mode = "QUATERNION"
            original_rotation = cursor.rotation_quaternion.copy()
            cursor.rotation_mode = original_rotation_mode
            _state["part_pivot_saved"] = {
                "pivot_point": context.scene.tool_settings.transform_pivot_point,
                "cursor_location": cursor.location.copy(),
                "cursor_rotation": original_rotation,
                "cursor_rotation_mode": original_rotation_mode,
            }
        window_manager.staticaliza_pivot_mode = "PART"
        matched = _sync_part_pivot(context, rematch = True)

        slot = context.scene.transform_orientation_slots[0]
        if matched and slot.type == "LOCAL":
            slot.type = "CURSOR"
        _pin_selection_runtime_restore(context, pin_selection)
        self.report({"INFO"}, "Pivot mode: Object")
        _tag_redraw_all_view3d()
        return {"FINISHED"}
