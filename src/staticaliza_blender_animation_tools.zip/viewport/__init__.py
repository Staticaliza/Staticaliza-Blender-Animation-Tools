"""Viewport overlays, camera synchronization, and pivots."""
