"""Attached bone cameras, transforms, visibility, and camera state helpers."""

from ..core.runtime import *  # noqa: F403

CAMERA_ORIENTATION_ITEMS = (
    ("X_POS", "+X", "Point the camera along the bone's positive X axis"),
    ("X_NEG", "-X", "Point the camera along the bone's negative X axis"),
    ("Y_POS", "+Y", "Point the camera along the bone's positive Y axis"),
    ("Y_NEG", "-Y", "Point the camera along the bone's negative Y axis"),
    ("Z_POS", "+Z", "Point the camera along the bone's positive Z axis"),
    ("Z_NEG", "-Z", "Point the camera along the bone's negative Z axis"),
)

CAMERA_FOV_PRESET_ITEMS = (
    ("CINEMATIC", "Cinematic (35°)", "Use a 35-degree horizontal field of view"),
    ("CLASSIC", "Classic (70°)", "Use a 70-degree horizontal field of view"),
    ("CUSTOM", "Custom", "Use the manually selected field of view"),
)


def _camera_bone_binding(camera):
    if camera is None or camera.type != "CAMERA":
        return None, ""
    if (
        camera.parent is not None
        and camera.parent.type == "ARMATURE"
        and camera.parent_type == "BONE"
        and camera.parent_bone
    ):
        return camera.parent, camera.parent_bone
    # Undo/redo can transiently lose the live bone-parent fields while custom
    # ID properties are already restored. Recover the weld from those stable
    # identifiers instead of treating the camera as standalone.
    bone_name = str(camera.get(ATTACHED_CAMERA_BONE_PROPERTY, ""))
    if bone_name:
        try:
            owner_uid = int(
                camera.get(ATTACHED_CAMERA_OWNER_UID_PROPERTY, 0) or 0
            )
        except (TypeError, ValueError):
            owner_uid = 0
        armature = _armature_from_session_uid(owner_uid)
        if armature is None:
            armature = bpy.data.objects.get(str(
                camera.get(ATTACHED_CAMERA_OWNER_NAME_PROPERTY, "")
            ))
        if (
            armature is not None
            and getattr(armature, "type", "") == "ARMATURE"
            and getattr(armature, "pose", None) is not None
            and armature.pose.bones.get(bone_name) is not None
        ):
            return armature, bone_name
    for constraint in camera.constraints:
        target = getattr(constraint, "target", None)
        subtarget = getattr(constraint, "subtarget", "")
        if constraint.type == "CHILD_OF" and target and target.type == "ARMATURE" and subtarget:
            return target, subtarget
    return None, ""


def _select_attached_camera_bone(context, camera):
    """Make the bone driving the viewed camera the active pose selection."""
    armature, bone_name = _camera_bone_binding(camera)
    if armature is None or not bone_name or getattr(armature, "mode", "") != "POSE":
        return False
    bone = getattr(getattr(armature, "data", None), "bones", {}).get(bone_name)
    if bone is None:
        return False
    try:
        for candidate_armature in _pose_scope_armatures(context):
            for candidate_pose_bone in candidate_armature.pose.bones:
                if hasattr(candidate_pose_bone, "select"):
                    candidate_pose_bone.select = False
                else:
                    candidate_pose_bone.bone.select = False
        armature.select_set(True)
        context.view_layer.objects.active = armature
        pose_bone = armature.pose.bones.get(bone_name)
        if hasattr(pose_bone, "select"):
            pose_bone.select = True
        else:
            bone.select = True
        armature.data.bones.active = bone
        return True
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        return False


def _on_camera_fov_preset(window_manager, _context):
    if (
        _state.get("camera_fov_syncing", False)
        or _state.get("camera_panel_syncing", False)
    ):
        return
    preset_angles = {
        "CINEMATIC": math.radians(35.0),
        "CLASSIC": math.radians(70.0),
    }
    angle = preset_angles.get(window_manager.staticaliza_camera_fov_preset)
    if angle is None:
        angle = float(window_manager.staticaliza_camera_fov)
    _state["camera_fov_syncing"] = True
    try:
        window_manager.staticaliza_camera_fov = angle
    finally:
        _state["camera_fov_syncing"] = False
    _apply_selected_camera_fov(
        _context,
        window_manager.staticaliza_camera_fov_preset,
        angle,
    )


def _on_camera_fov_change(window_manager, _context):
    if (
        _state.get("camera_fov_syncing", False)
        or _state.get("camera_panel_syncing", False)
    ):
        return
    angle = float(window_manager.staticaliza_camera_fov)
    if abs(angle - math.radians(35.0)) <= math.radians(0.01):
        preset = "CINEMATIC"
    elif abs(angle - math.radians(70.0)) <= math.radians(0.01):
        preset = "CLASSIC"
    else:
        preset = "CUSTOM"
    if window_manager.staticaliza_camera_fov_preset != preset:
        _state["camera_fov_syncing"] = True
        try:
            window_manager.staticaliza_camera_fov_preset = preset
        finally:
            _state["camera_fov_syncing"] = False
    _apply_selected_camera_fov(_context, preset, angle)


def _on_camera_orientation_change(window_manager, context):
    if _state.get("camera_panel_syncing", False):
        return
    cameras = _selected_attached_camera_objects(context)
    if not cameras:
        return
    orientation = str(window_manager.staticaliza_camera_orientation)
    changed = False
    _state["camera_batch_property_syncing"] = True
    try:
        for camera in cameras:
            if camera.staticaliza_camera_orientation != orientation:
                camera.staticaliza_camera_orientation = orientation
                changed = True
            changed = (
                _apply_attached_camera_orientation(camera, context)
                or changed
            )
    finally:
        _state["camera_batch_property_syncing"] = False
    _push_camera_batch_history("Camera Axis", changed)


def _on_camera_hide_attached_change(window_manager, context):
    if _state.get("camera_panel_syncing", False):
        return
    hidden = bool(window_manager.staticaliza_camera_hide_attached_object)
    cameras = _selected_attached_camera_objects(context)
    changed = False
    _state["camera_batch_property_syncing"] = True
    try:
        for camera in cameras:
            if bool(camera.staticaliza_camera_hide_attached_object) != hidden:
                camera.staticaliza_camera_hide_attached_object = hidden
                changed = True
            _apply_camera_attached_object_visibility(camera, context)
    finally:
        _state["camera_batch_property_syncing"] = False
    _push_camera_batch_history("Camera Attached Object Visibility", changed)


def _on_camera_opaque_change(window_manager, context):
    if _state.get("camera_panel_syncing", False):
        return
    opaque = bool(window_manager.staticaliza_camera_opaque_frame)
    cameras = _selected_attached_camera_objects(context)
    changed = False
    _state["camera_batch_property_syncing"] = True
    try:
        for camera in cameras:
            if bool(camera.staticaliza_camera_opaque_frame) != opaque:
                camera.staticaliza_camera_opaque_frame = opaque
                changed = True
            _apply_camera_opaque_frame(camera, context)
    finally:
        _state["camera_batch_property_syncing"] = False
    _push_camera_batch_history("Camera Frame", changed)


def _on_camera_composition_thirds_change(window_manager, context):
    if _state.get("camera_panel_syncing", False):
        return
    visible = bool(
        window_manager.staticaliza_camera_composition_thirds
    )
    cameras = _selected_attached_camera_objects(context)
    changed = False
    for camera in cameras:
        if bool(camera.data.show_composition_thirds) != visible:
            camera.data.show_composition_thirds = visible
            changed = True
    if cameras:
        _remember_attached_camera(cameras[0])
    _push_camera_batch_history("Camera Composition Thirds", changed)


def _push_camera_batch_history(message, changed):
    if not changed:
        return False
    try:
        bpy.ops.ed.undo_push(message=message)
    except (AttributeError, RuntimeError):
        pass
    return True


def _apply_selected_camera_fov(context, preset, angle):
    cameras = _selected_attached_camera_objects(context)
    changed = False
    _state["camera_batch_property_syncing"] = True
    try:
        for camera in cameras:
            if camera.staticaliza_camera_fov_preset != str(preset):
                camera.staticaliza_camera_fov_preset = str(preset)
                changed = True
            if abs(float(camera.data.angle) - float(angle)) > 1.0e-8:
                camera.data.angle = float(angle)
                changed = True
    finally:
        _state["camera_batch_property_syncing"] = False
    return _push_camera_batch_history("Camera FOV", changed)



def _camera_angle_for_preset(preset, custom_angle):
    return {
        "CINEMATIC": math.radians(35.0),
        "CLASSIC": math.radians(70.0),
    }.get(str(preset), float(custom_angle))


def _on_create_camera_preset(operator, _context):
    if operator.preset == "CUSTOM":
        return
    operator.fov = _camera_angle_for_preset(operator.preset, operator.fov)


def _on_attached_camera_preset(camera, _context):
    if (
        _state.get("camera_fov_syncing", False)
        or _state.get("camera_batch_property_syncing", False)
        or camera.type != "CAMERA"
    ):
        return
    angle = {
        "CINEMATIC": math.radians(35.0),
        "CLASSIC": math.radians(70.0),
    }.get(camera.staticaliza_camera_fov_preset)
    if angle is not None:
        camera.data.angle = angle
        try:
            bpy.ops.ed.undo_push(message = "Camera FOV")
        except (AttributeError, RuntimeError):
            pass



def _camera_for_bone(scene, armature, bone_name):
    matches = []
    for camera in scene.objects:
        if camera.type != "CAMERA":
            continue
        target, subtarget = _camera_bone_binding(camera)
        if target == armature and subtarget == bone_name:
            matches.append(camera)
    if scene.camera in matches:
        return scene.camera
    return matches[0] if matches else None


def _selected_camera_bones(context):
    if context.mode != "POSE":
        return ()
    selected_by_owner = _selected_pose_bones_by_owner(context)
    active = getattr(context, "active_pose_bone", None)
    active_armature = _pose_bone_owner(context, active)
    ordered = []
    if active in selected_by_owner.get(active_armature, ()):
        ordered.append((active_armature, active))
    ordered.extend(
        (armature, pose_bone)
        for armature, pose_bones in selected_by_owner.items()
        for pose_bone in pose_bones
        if (armature, pose_bone) not in ordered
    )
    return tuple(
        (
            armature,
            pose_bone,
            _camera_for_bone(context.scene, armature, pose_bone.name),
        )
        for armature, pose_bone in ordered
    )


def _selected_camera_bone(context):
    for armature, pose_bone, camera in _selected_camera_bones(context):
        if camera is not None:
            return armature, pose_bone, camera
    return None, None, None


def _remember_attached_camera(camera):
    armature, bone_name = _camera_bone_binding(camera)
    if armature is None or not bone_name or camera is None:
        return False
    _state["attached_camera_last_name"] = str(camera.name)
    try:
        _state["attached_camera_last_pointer"] = int(camera.as_pointer())
    except (AttributeError, ReferenceError):
        _state["attached_camera_last_pointer"] = 0
    return True


def _selected_attached_camera_objects(context):
    if context is None or getattr(context, "scene", None) is None:
        return ()
    return tuple(
        camera
        for _armature, _pose_bone, camera in _selected_camera_bones(context)
        if camera is not None
    )


def _sync_selected_camera_panel_settings(context, window_manager, cameras=None):
    cameras = tuple(cameras or _selected_attached_camera_objects(context))
    if not cameras:
        return False
    active = cameras[0]
    _remember_attached_camera(active)
    _state["camera_panel_syncing"] = True
    try:
        preset = str(active.staticaliza_camera_fov_preset)
        if str(window_manager.staticaliza_camera_fov_preset) != preset:
            window_manager.staticaliza_camera_fov_preset = preset
        angle = float(active.data.angle)
        if abs(float(window_manager.staticaliza_camera_fov) - angle) > 1.0e-8:
            window_manager.staticaliza_camera_fov = angle
        orientation = str(active.staticaliza_camera_orientation)
        if str(window_manager.staticaliza_camera_orientation) != orientation:
            window_manager.staticaliza_camera_orientation = orientation
        hidden = bool(active.staticaliza_camera_hide_attached_object)
        if bool(window_manager.staticaliza_camera_hide_attached_object) != hidden:
            window_manager.staticaliza_camera_hide_attached_object = hidden
        opaque = bool(active.staticaliza_camera_opaque_frame)
        if bool(window_manager.staticaliza_camera_opaque_frame) != opaque:
            window_manager.staticaliza_camera_opaque_frame = opaque
        thirds = bool(active.data.show_composition_thirds)
        if (
            bool(window_manager.staticaliza_camera_composition_thirds)
            != thirds
        ):
            window_manager.staticaliza_camera_composition_thirds = thirds
    finally:
        _state["camera_panel_syncing"] = False
    return True


def _sync_selected_camera_as_active(context):
    _armature, _pose_bone, camera = _selected_camera_bone(context)
    # Selecting an ordinary bone/object must not clear the camera assigned to
    # an active camera viewport.  A missing selected-camera match means "keep
    # the current camera", not "remove the current camera".  We still switch
    # normally when the user explicitly selects a different camera bone.
    if camera is None:
        return False
    if context.scene.camera == camera:
        return False
    context.scene.camera = camera
    for area in getattr(getattr(context, "screen", None), "areas", ()):
        if area.type != "VIEW_3D":
            continue
        for space in area.spaces:
            if space.type == "VIEW_3D":
                space.camera = camera
        area.tag_redraw()
    return True


def _attached_bone_cameras(scene):
    """Return every valid bone-attached camera in the current scene."""
    attached = []
    for camera in scene.objects:
        if camera.type != "CAMERA":
            continue
        armature, bone_name = _camera_bone_binding(camera)
        if (
            armature is None
            or not bone_name
            or armature.pose is None
            or armature.pose.bones.get(bone_name) is None
        ):
            continue
        attached.append((armature, bone_name, camera))
    attached.sort(
        key = lambda entry: (
            entry[0].name.casefold(),
            entry[1].casefold(),
            entry[2].name.casefold(),
        )
    )
    return tuple(attached)


def _attached_camera_for_view(context):
    """Resolve a unique, selected, active, or most-recent bone camera."""
    attached = _attached_bone_cameras(context.scene)
    if not attached:
        return None

    cameras_by_pointer = {
        int(camera.as_pointer()): camera
        for _armature, _bone_name, camera in attached
    }
    for _armature, _pose_bone, camera in _selected_camera_bones(context):
        if (
            camera is not None
            and int(camera.as_pointer()) in cameras_by_pointer
        ):
            # _selected_camera_bones puts the active selected pose bone first,
            # so an active camera bone also disambiguates a multi-selection.
            _remember_attached_camera(camera)
            return camera

    active_camera = getattr(context.scene, "camera", None)
    if active_camera is not None:
        active_pointer = int(active_camera.as_pointer())
        if active_pointer in cameras_by_pointer:
            _remember_attached_camera(active_camera)
            return active_camera

    remembered_pointer = int(
        _state.get("attached_camera_last_pointer", 0) or 0
    )
    remembered = cameras_by_pointer.get(remembered_pointer)
    if remembered is None:
        remembered_name = str(
            _state.get("attached_camera_last_name", "")
        )
        remembered = next(
            (
                camera
                for _armature, _bone_name, camera in attached
                if camera.name == remembered_name
            ),
            None,
        )
    if remembered is not None:
        _remember_attached_camera(remembered)
        return remembered

    if len(attached) == 1:
        _remember_attached_camera(attached[0][2])
        return attached[0][2]
    return None


def _attached_camera_bone_for_keyframe(context):
    camera = _attached_camera_for_view(context)
    if camera is None:
        return None, None, None
    armature, bone_name = _camera_bone_binding(camera)
    pose_bone = (
        armature.pose.bones.get(bone_name)
        if armature is not None and getattr(armature, "pose", None)
        else None
    )
    if pose_bone is None:
        return None, None, None
    _remember_attached_camera(camera)
    return armature, pose_bone, camera


def _selected_camera_batch_removes(context):
    selected = _selected_camera_bones(context)
    return bool(selected) and all(camera is not None for _, _, camera in selected)


def _selected_camera_button_text(context):
    selected = _selected_camera_bones(context)
    multiple = len(selected) > 1
    if selected and all(camera is not None for _, _, camera in selected):
        return "Remove Cameras" if multiple else "Remove Camera"
    return "Create Cameras" if multiple else "Create Camera"


def _standalone_camera(context):
    candidates = []
    active = context.active_object
    if active is not None and active.type == "CAMERA":
        candidates.append(active)
    if context.scene.camera is not None:
        candidates.append(context.scene.camera)
    candidates.extend(obj for obj in context.scene.objects if obj.type == "CAMERA")
    seen = set()
    for camera in candidates:
        pointer = int(camera.as_pointer())
        if pointer in seen:
            continue
        seen.add(pointer)
        target, bone_name = _camera_bone_binding(camera)
        if target is None or not bone_name:
            return camera
    return None


def _view_camera_matrix(context):
    region_data = getattr(context, "region_data", None)
    if region_data is None:
        space = getattr(context, "space_data", None)
        if getattr(space, "type", "") != "VIEW_3D":
            area = getattr(context, "area", None)
            space = (
                getattr(getattr(area, "spaces", None), "active", None)
                if getattr(area, "type", "") == "VIEW_3D"
                else None
            )
        region_data = getattr(space, "region_3d", None)
    if region_data is None:
        return None
    try:
        matrix = region_data.view_matrix.inverted()
        location, rotation, _scale = matrix.decompose()
        result = rotation.to_matrix().to_4x4()
        result.translation = location
        return result
    except Exception:
        return None


def _camera_world_at_bone_tip(
    armature,
    pose_bone,
    orientation = "Z_NEG",
    context = None,
):
    bone_world = armature.matrix_world @ pose_bone.matrix
    axes = bone_world.to_3x3().normalized()
    anchor = bone_world @ Vector((0.0, pose_bone.length, 0.0))
    # A Roblox part can have a fixed rotation relative to its driving bone.
    # Use the evaluated part transform for both the attachment center and the
    # camera axes so that this offset is not mistaken for camera roll.
    if context is not None:
        try:
            depsgraph = context.evaluated_depsgraph_get()
            evaluated_armature = armature.evaluated_get(depsgraph)
            evaluated_bone = evaluated_armature.pose.bones.get(pose_bone.name)
            objects, _target_armature = _targets(context, armature)
            objects.extend(
                obj
                for obj in context.view_layer.objects
                if (
                    obj != armature
                    and (
                        obj.parent == armature
                        or any(
                            modifier.type == "ARMATURE"
                            and getattr(modifier, "object", None) == armature
                            for modifier in obj.modifiers
                        )
                    )
                )
            )
            objects = list(dict.fromkeys(objects))
            part = _part_pivot_connected_object(
                context,
                armature,
                evaluated_armature,
                objects,
                evaluated_bone,
                include_hidden = True,
            )
            evaluated_part = part.evaluated_get(depsgraph) if part else None
            if evaluated_part is not None:
                axes = evaluated_part.matrix_world.to_3x3().normalized()
            corners = tuple(
                Vector(corner)
                for corner in getattr(evaluated_part, "bound_box", ())
            )
            if corners:
                bounds = _bounds_init(corners[0])
                for corner in corners[1:]:
                    _bounds_add(bounds, corner)
                local_center = Vector((
                    (float(bounds[0]) + float(bounds[3])) * 0.5,
                    (float(bounds[1]) + float(bounds[4])) * 0.5,
                    (float(bounds[2]) + float(bounds[5])) * 0.5,
                ))
                anchor = evaluated_part.matrix_world @ local_center
        except (
            AttributeError,
            ReferenceError,
            RuntimeError,
            TypeError,
            ValueError,
        ):
            pass
    local_direction = {
        "X_POS": Vector((1.0, 0.0, 0.0)),
        "X_NEG": Vector((-1.0, 0.0, 0.0)),
        "Y_POS": Vector((0.0, 1.0, 0.0)),
        "Y_NEG": Vector((0.0, -1.0, 0.0)),
        "Z_POS": Vector((0.0, 0.0, 1.0)),
        "Z_NEG": Vector((0.0, 0.0, -1.0)),
    }.get(orientation, Vector((0.0, 0.0, -1.0)))
    forward = (axes @ local_direction).normalized()
    up_reference = axes.col[2].normalized()
    if abs(float(forward.dot(up_reference))) >= 0.999:
        up_reference = axes.col[1].normalized()
    x_axis = forward.cross(up_reference).normalized()
    up_axis = (-forward).cross(x_axis).normalized()
    matrix = Matrix((
        (x_axis.x, up_axis.x, -forward.x, 0.0),
        (x_axis.y, up_axis.y, -forward.y, 0.0),
        (x_axis.z, up_axis.z, -forward.z, 0.0),
        (0.0, 0.0, 0.0, 1.0),
    ))
    matrix.translation = anchor
    return matrix


def _apply_attached_camera_orientation(camera, context):
    if camera.type != "CAMERA":
        return False
    armature, bone_name = _camera_bone_binding(camera)
    if armature is None or not bone_name:
        return False
    pose_bone = armature.pose.bones.get(bone_name)
    if pose_bone is None:
        return False
    camera_world = _camera_world_at_bone_tip(
        armature,
        pose_bone,
        camera.staticaliza_camera_orientation,
        context = context,
    )
    camera.matrix_world = camera_world
    bone_world = armature.matrix_world @ pose_bone.matrix
    local_matrix = bone_world.inverted_safe() @ camera_world
    camera[ATTACHED_CAMERA_LOCAL_MATRIX_PROPERTY] = tuple(
        float(value) for row in local_matrix for value in row
    )
    try:
        context.view_layer.update()
    except Exception:
        pass
    return True


def _on_attached_camera_orientation(camera, context):
    if _state.get("camera_batch_property_syncing", False):
        return
    _push_camera_batch_history(
        "Camera Axis",
        _apply_attached_camera_orientation(camera, context),
    )


def _refresh_attached_camera_transforms(context):
    if context is None or getattr(context, "scene", None) is None:
        return False
    changed = False
    for camera in tuple(context.scene.objects):
        if camera.type != "CAMERA":
            continue
        armature, bone_name = _camera_bone_binding(camera)
        pose_bone = (
            armature.pose.bones.get(bone_name)
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is None:
            continue
        _stabilize_existing_camera_rotation_keys(pose_bone)
        camera[ATTACHED_CAMERA_OWNER_NAME_PROPERTY] = armature.name
        camera[ATTACHED_CAMERA_OWNER_UID_PROPERTY] = str(
            _armature_session_uid(armature)
        )
        camera[ATTACHED_CAMERA_BONE_PROPERTY] = bone_name
        # Undo/redo can restore the bone parent and its inverse in separate
        # dependency-graph stages. Reassert the rigid weld before assigning
        # the evaluated world matrix so no stale inverse offsets the camera.
        try:
            camera.parent = armature
            camera.parent_type = "BONE"
            camera.parent_bone = bone_name
            camera.matrix_parent_inverse = Matrix.Identity(4)
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            pass
        stored_local = camera.get(ATTACHED_CAMERA_LOCAL_MATRIX_PROPERTY)
        try:
            local_matrix = Matrix((
                stored_local[0:4],
                stored_local[4:8],
                stored_local[8:12],
                stored_local[12:16],
            )) if stored_local is not None and len(stored_local) == 16 else None
        except (IndexError, TypeError, ValueError):
            local_matrix = None
        if local_matrix is None:
            camera_world = _camera_world_at_bone_tip(
                armature,
                pose_bone,
                camera.staticaliza_camera_orientation,
                context = context,
            )
            bone_world = armature.matrix_world @ pose_bone.matrix
            local_matrix = bone_world.inverted_safe() @ camera_world
            camera[ATTACHED_CAMERA_LOCAL_MATRIX_PROPERTY] = tuple(
                float(value) for row in local_matrix for value in row
            )
        camera.matrix_world = (
            armature.matrix_world @ pose_bone.matrix @ local_matrix
        )
        changed = True
    if changed:
        try:
            context.view_layer.update()
        except (AttributeError, RuntimeError):
            pass
    return changed


def _stabilize_existing_camera_rotation_keys(pose_bone):
    """Repair older camera keys that interpolate through an upside-down flip."""
    armature = getattr(pose_bone, "id_data", None)
    animation_data = getattr(armature, "animation_data", None)
    action = getattr(animation_data, "action", None)
    if action is None:
        return False
    rotation_mode = str(getattr(pose_bone, "rotation_mode", "XYZ"))
    property_name = (
        "rotation_quaternion"
        if rotation_mode == "QUATERNION"
        else "rotation_axis_angle"
        if rotation_mode == "AXIS_ANGLE"
        else "rotation_euler"
    )
    data_path = pose_bone.path_from_id() + "." + property_name
    frames = sorted({
        int(round(float(key.co.x)))
        for curve in _action_fcurves(action, armature)
        if curve.data_path == data_path
        for key in curve.keyframe_points
    })
    changed = False
    for frame in frames:
        changed |= _stabilize_camera_rotation_keys(pose_bone, frame)
    return changed


def _refresh_attached_camera_transforms_timer():
    try:
        context = bpy.context
        if (
            _pin_primary_mouse_pressed()
            or _window_manager_has_modal_operator(context)
        ):
            # This is also queued by undo/redo. Updating the view layer and
            # redrawing during the next gizmo press can rebuild Blender's
            # native gizmo map underneath its pending hit.
            return 0.05
        if context is not None and getattr(context, "scene", None) is not None:
            if _refresh_attached_camera_transforms(context):
                _tag_redraw_all_view3d()
    except (
        AttributeError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ) as exc:
        print(f"[Roblox Animator Utils] Camera weld restore skipped: {exc}")
    return None


def _schedule_attached_camera_transform_restore(delay = 0.05):
    try:
        if bpy.app.timers.is_registered(_refresh_attached_camera_transforms_timer):
            bpy.app.timers.unregister(_refresh_attached_camera_transforms_timer)
        register_owned_timer(
            _refresh_attached_camera_transforms_timer,
            first_interval = max(0.0, float(delay)),
        )
    except (RuntimeError, ValueError):
        pass


def _insert_camera_bone_keys(armature, pose_bone, frame):
    frame = int(frame)
    group = pose_bone.name
    options = {"INSERTKEY_VISUAL"}
    base = f'pose.bones["{pose_bone.name}"]'
    armature.keyframe_insert(
        data_path = f"{base}.location",
        frame = frame,
        group = group,
        options = options,
    )
    if pose_bone.rotation_mode == "QUATERNION":
        rotation_path = "rotation_quaternion"
    elif pose_bone.rotation_mode == "AXIS_ANGLE":
        rotation_path = "rotation_axis_angle"
    else:
        rotation_path = "rotation_euler"
    armature.keyframe_insert(
        data_path = f"{base}.{rotation_path}",
        frame = frame,
        group = group,
        options = options,
    )
    armature.keyframe_insert(
        data_path = f"{base}.scale",
        frame = frame,
        group = group,
        options = options,
    )
    _set_keyframe_handles_auto(pose_bone, frame)
    _stabilize_camera_rotation_keys(pose_bone, frame)


def _stabilize_camera_rotation_keys(target, frame):
    """Keep camera rotation curves on one equivalent rotation path."""
    id_data = getattr(target, "id_data", None) or target
    animation_data = getattr(id_data, "animation_data", None)
    action = getattr(animation_data, "action", None)
    if action is None:
        return False
    target_path = ""
    if target is not id_data:
        try:
            target_path = target.path_from_id() + "."
        except (AttributeError, TypeError, ValueError):
            return False
    rotation_mode = str(getattr(target, "rotation_mode", "XYZ"))
    if rotation_mode == "QUATERNION":
        property_name = "rotation_quaternion"
        component_count = 4
    elif rotation_mode == "AXIS_ANGLE":
        property_name = "rotation_axis_angle"
        component_count = 4
    else:
        property_name = "rotation_euler"
        component_count = 3
    data_path = target_path + property_name
    curves = {
        int(curve.array_index): curve
        for curve in _action_fcurves(action, id_data)
        if curve.data_path == data_path
    }
    if any(index not in curves for index in range(component_count)):
        return False

    target_frame = float(frame)
    current_keys = []
    previous_keys = []
    for index in range(component_count):
        points = tuple(curves[index].keyframe_points)
        current = next(
            (
                key for key in points
                if abs(float(key.co.x) - target_frame) <= 1.0e-5
            ),
            None,
        )
        previous = max(
            (
                key for key in points
                if float(key.co.x) < target_frame - 1.0e-5
            ),
            key = lambda key: float(key.co.x),
            default = None,
        )
        if current is None:
            return False
        current_keys.append(current)
        previous_keys.append(previous)

    changed = False
    if all(key is not None for key in previous_keys):
        current_values = [float(key.co.y) for key in current_keys]
        previous_values = [float(key.co.y) for key in previous_keys]
        if rotation_mode == "QUATERNION":
            if sum(
                previous * current
                for previous, current in zip(previous_values, current_values)
            ) < 0.0:
                for key in current_keys:
                    key.co.y = -float(key.co.y)
                changed = True
        elif rotation_mode != "AXIS_ANGLE":
            for key, previous_value in zip(current_keys, previous_values):
                value = float(key.co.y)
                while value - previous_value > math.pi:
                    value -= math.tau
                while value - previous_value < -math.pi:
                    value += math.tau
                if abs(value - float(key.co.y)) > 1.0e-8:
                    key.co.y = value
                    changed = True

    for index, curve in curves.items():
        for key in (current_keys[index], previous_keys[index]):
            if key is not None:
                if key.handle_left_type != "AUTO_CLAMPED":
                    key.handle_left_type = "AUTO_CLAMPED"
                    changed = True
                if key.handle_right_type != "AUTO_CLAMPED":
                    key.handle_right_type = "AUTO_CLAMPED"
                    changed = True
        curve.update()
    return changed


def _keyframe_camera_bone(context, armature, pose_bone, camera, camera_world):
    action = armature.animation_data.action if armature.animation_data else None
    object_keys_before = _snapshot_object_keys_all(action)
    previous_autokey = _autokey_push(context)
    try:
        depsgraph = context.evaluated_depsgraph_get()
        evaluated_armature = armature.evaluated_get(depsgraph)
        evaluated_bone = evaluated_armature.pose.bones.get(pose_bone.name)
        if evaluated_bone is None:
            return False
        evaluated_camera = camera.evaluated_get(depsgraph)
        bone_world = evaluated_armature.matrix_world @ evaluated_bone.matrix
        relative_camera = bone_world.inverted() @ evaluated_camera.matrix_world
        desired_bone_world = camera_world @ relative_camera.inverted()
        pose_bone.matrix = armature.matrix_world.inverted() @ desired_bone_world
        context.view_layer.update()
        _insert_camera_bone_keys(
            armature,
            pose_bone,
            int(context.scene.frame_current),
        )
        context.view_layer.update()
        return True
    except Exception:
        return False
    finally:
        current_action = armature.animation_data.action if armature.animation_data else None
        _cleanup_new_object_keys_all(current_action, object_keys_before)
        _autokey_pop(context, previous_autokey)


def _keyframe_standalone_camera(camera, frame, camera_world):
    camera.matrix_world = camera_world
    camera.keyframe_insert(data_path = "location", frame = int(frame))
    if camera.rotation_mode == "QUATERNION":
        camera.keyframe_insert(data_path = "rotation_quaternion", frame = int(frame))
    elif camera.rotation_mode == "AXIS_ANGLE":
        camera.keyframe_insert(data_path = "rotation_axis_angle", frame = int(frame))
    else:
        camera.keyframe_insert(data_path = "rotation_euler", frame = int(frame))
    _set_keyframe_handles_auto(camera, frame)
    _stabilize_camera_rotation_keys(camera, frame)


def _objects_affiliated_with_camera_bone(scene, camera):
    armature, bone_name = _camera_bone_binding(camera)
    if armature is None or not bone_name:
        return []

    pose_bone = armature.pose.bones.get(bone_name)
    if pose_bone is None:
        return []
    family_names = _surface_contact_bone_family_names(armature, pose_bone)
    canonical_name = _strip_blender_numeric_suffix(bone_name)
    parts_collection = _find_roblox_parts_collection(armature)
    parts_objects = (
        set(parts_collection.all_objects)
        if parts_collection is not None
        else set()
    )
    connected = set()
    for obj in scene.objects:
        if obj == camera or obj.type != "MESH":
            continue
        matches = bool(
            _surface_contact_object_bone_names(obj, armature) & family_names
        )
        if (
            not matches
            and obj in parts_objects
            and _strip_blender_numeric_suffix(obj.name) == canonical_name
        ):
            matches = True
        if matches:
            connected.add(obj)

    for _depth in range(16):
        additions = {
            obj
            for obj in scene.objects
            if (
                obj.type == "MESH"
                and obj != camera
                and obj not in connected
                and (
                    obj.parent in connected
                    or any(
                        getattr(constraint, "target", None) in connected
                        for constraint in obj.constraints
                    )
                )
            )
        }
        if not additions:
            break
        connected.update(additions)
    return list(connected)


def _set_attached_camera_object_visibility(scene, camera, hidden):
    desired = bool(hidden)
    changed = False
    for obj in _objects_affiliated_with_camera_bone(scene, camera):
        # This helper also runs from an idle timer. Reassigning an unchanged
        # visibility property after the camera operator creates a separate
        # visibility-only native history boundary, so the first Ctrl+Z merely
        # unhides the part and a second Ctrl+Z is needed to remove the camera.
        if bool(obj.hide_get()) != desired:
            obj.hide_set(desired)
            changed = True
        if bool(obj.hide_render) != desired:
            obj.hide_render = desired
            changed = True
    return changed


def _apply_camera_passepartout(camera, space = None):
    """Apply one camera's saved opaque-frame choice in every camera view."""
    if camera is None or getattr(camera, "type", "") != "CAMERA":
        return False
    opaque = bool(getattr(camera, "staticaliza_camera_opaque_frame", True))
    changed = False
    camera_data = camera.data
    # Turning the custom opaque option off means Blender's factory camera
    # frame, not no frame. Blender 5.2 defaults to enabled passepartout at
    # 0.5 alpha.
    if not bool(camera_data.show_passepartout):
        camera_data.show_passepartout = True
        changed = True
    desired_alpha = 1.0 if opaque else 0.5
    if abs(float(camera_data.passepartout_alpha) - desired_alpha) > 1.0e-6:
        camera_data.passepartout_alpha = desired_alpha
        changed = True
    if space is not None:
        try:
            if not bool(space.overlay.show_camera_passepartout):
                space.overlay.show_camera_passepartout = True
                changed = True
        except (AttributeError, ReferenceError, RuntimeError):
            pass
    return changed


def _apply_camera_opaque_frame(camera, context):
    changed = _apply_camera_passepartout(camera)
    window_manager = getattr(context, "window_manager", None) if context else None
    for window in getattr(window_manager, "windows", ()):
        for area in window.screen.areas:
            if area.type != "VIEW_3D":
                continue
            for space in area.spaces:
                if (
                    space.type == "VIEW_3D"
                    and (getattr(space, "camera", None) or window.scene.camera)
                    == camera
                ):
                    changed = _apply_camera_passepartout(camera, space) or changed
                    area.tag_redraw()
    return changed


def _on_camera_opaque_frame_change(camera, context):
    if _state.get("camera_batch_property_syncing", False):
        return
    _apply_camera_opaque_frame(camera, context)


def _set_attached_camera_preview_visibility(scene, camera, previewing):
    """Hide the camera bone in preview and honor the object's saved choice."""
    if camera is None:
        return
    armature, bone_name = _camera_bone_binding(camera)
    preview_states = _state.setdefault("attached_camera_preview_visibility", {})
    try:
        camera_pointer = int(camera.as_pointer())
    except (AttributeError, ReferenceError):
        return

    if previewing:
        if camera_pointer not in preview_states:
            bone = (
                armature.data.bones.get(bone_name)
                if armature is not None and bone_name
                else None
            )
            preview_states[camera_pointer] = {
                "bone_hidden": bool(getattr(bone, "hide", False)),
            }
        if armature is not None and bone_name:
            bone = armature.data.bones.get(bone_name)
            if bone is not None:
                bone.hide = True
        # The camera controller bone must never clip into its own view, but
        # attached meshes may intentionally be custom foreground overlays.
        # Reapplying preview state on every timer tick must therefore respect
        # the checkbox instead of forcibly hiding those meshes again.
        _set_attached_camera_object_visibility(
            scene,
            camera,
            bool(getattr(
                camera,
                "staticaliza_camera_hide_attached_object",
                True,
            )),
        )
        return

    previous = preview_states.pop(camera_pointer, None)
    if armature is not None and bone_name:
        bone = armature.data.bones.get(bone_name)
        if bone is not None:
            bone.hide = bool((previous or {}).get("bone_hidden", False))
    _set_attached_camera_object_visibility(
        scene,
        camera,
        bool(getattr(camera, "staticaliza_camera_hide_attached_object", True)),
    )


def _sync_all_attached_camera_object_visibility():
    for scene in bpy.data.scenes:
        for camera in (obj for obj in scene.objects if obj.type == "CAMERA"):
            armature, bone_name = _camera_bone_binding(camera)
            if armature is None or not bone_name:
                continue
            hidden = getattr(
                camera,
                "staticaliza_camera_hide_attached_object",
                True,
            )
            _set_attached_camera_object_visibility(scene, camera, hidden)
            _apply_camera_passepartout(camera)
    # This function is also registered as a one-shot timer.  Blender treats a
    # numeric/boolean return as the next interval, so never return a change flag.
    return None


def _apply_camera_attached_object_visibility(camera, context):
    scenes = list(camera.users_scene)
    if context and context.scene and context.scene not in scenes:
        scenes.append(context.scene)
    for scene in scenes:
        _set_attached_camera_object_visibility(
            scene,
            camera,
            camera.staticaliza_camera_hide_attached_object,
        )
    return bool(scenes)


def _on_camera_attached_object_hide_change(camera, context):
    if _state.get("camera_batch_property_syncing", False):
        return
    _apply_camera_attached_object_visibility(camera, context)


def _level_free_view_rotation(region_data):
    rotation = region_data.view_rotation.copy()
    direction = (rotation @ Vector((0.0, 0.0, -1.0))).normalized()
    world_up = Vector((0.0, 0.0, 1.0))
    if abs(direction.dot(world_up)) >= 1.0 - 1.0e-10:
        return False
    region_data.view_rotation = direction.to_track_quat("-Z", "Y")
    return True


def _set_default_keyframe_handle_type():
    """Keep managed key styling local instead of changing user preferences."""
    return False


def _camera_view_state(previous = None):
    if isinstance(previous, dict):
        state = previous
    else:
        state = {"attached": bool(previous)}
    state.setdefault("attached", False)
    state.setdefault("pending_level", False)
    state.setdefault("last_rotation", None)
    state.setdefault("stable_ticks", 0)
    state.setdefault("return_view", None)
    state.setdefault("entering", False)
    state.setdefault("enter_started", 0.0)
    state.setdefault("camera_pointer", 0)
    state.setdefault("camera_name", "")
    return state
