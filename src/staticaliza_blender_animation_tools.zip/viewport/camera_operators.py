"""Operators for attached bone cameras and camera-view keyframing."""

from ..core.runtime import *  # noqa: F403
from .camera import (
    CAMERA_FOV_PRESET_ITEMS,
    CAMERA_ORIENTATION_ITEMS,
    _on_create_camera_preset,
)

class ANIMATOR_UTILS_OT_add_bone_camera(bpy.types.Operator):
    bl_idname = "staticaliza.add_bone_camera"
    bl_label = "Create Camera"
    bl_description = "Create or remove cameras rigidly attached to the selected pose bones"
    bl_options = {"REGISTER", "UNDO"}

    preset: bpy.props.EnumProperty(
        name = "Preset",
        description = "Choose the camera's horizontal field-of-view preset",
        items = CAMERA_FOV_PRESET_ITEMS,
        default = "CINEMATIC",
        update = _on_create_camera_preset,
    )
    fov: bpy.props.FloatProperty(
        name = "FOV",
        description = "Horizontal field of view for a custom camera preset",
        subtype = "ANGLE",
        default = math.radians(35.0),
        min = math.radians(1.0),
        max = math.radians(179.0),
    )
    orientation: bpy.props.EnumProperty(
        name = "Axis",
        description = "Choose the attached object's local axis the camera points along",
        items = CAMERA_ORIENTATION_ITEMS,
        default = "Z_NEG",
    )
    hide_attached_object: bpy.props.BoolProperty(
        name = "Hide Attached Object",
        description = "Hide mesh objects driven by the camera bone in the viewport and render",
        default = True,
    )
    opaque_frame: bpy.props.BoolProperty(
        name = "Opaque Camera Frame",
        description = "Fill every area outside the camera frame with pure black",
        default = True,
    )
    removed_existing: bpy.props.BoolProperty(
        default = False,
        options = {"HIDDEN", "SKIP_SAVE"},
    )

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE" and bool(_selected_pose_bones_only(context))

    def draw(self, _context):
        layout = self.layout
        if self.removed_existing:
            layout.label(text = "Selected cameras removed.")
            return
        layout.prop(self, "preset")
        if self.preset == "CUSTOM":
            layout.prop(self, "fov")
        layout.prop(self, "orientation")
        layout.prop(self, "hide_attached_object")
        layout.prop(self, "opaque_frame")

    def invoke(self, context, _event):
        self.removed_existing = _selected_camera_batch_removes(context)
        if not self.removed_existing:
            window_manager = context.window_manager
            self.preset = window_manager.staticaliza_camera_fov_preset
            self.fov = window_manager.staticaliza_camera_fov
            self.orientation = window_manager.staticaliza_camera_orientation
            self.hide_attached_object = True
            self.opaque_frame = True
        return self.execute(context)

    def execute(self, context):
        selected = _selected_camera_bones(context)
        if not selected:
            return {"CANCELLED"}

        remove_all = all(camera is not None for _, _, camera in selected)
        if remove_all:
            self.removed_existing = True
            removed = 0
            affected_armatures = set()
            for armature, _pose_bone, camera in selected:
                if camera is None:
                    continue
                affected_armatures.add(armature)
                _set_attached_camera_object_visibility(
                    context.scene,
                    camera,
                    False,
                )
                camera_data = camera.data
                if context.scene.camera == camera:
                    context.scene.camera = None
                bpy.data.objects.remove(camera, do_unlink = True)
                if camera_data.users == 0:
                    bpy.data.cameras.remove(camera_data)
                removed += 1
            context.view_layer.update()
            frame = int(context.scene.frame_current)
            for armature in affected_armatures:
                _sync_all_dynamic_pose_bone_colors(frame, armature)
            context.view_layer.update()
            _tag_redraw_all_view3d()
            noun = "camera" if removed == 1 else "cameras"
            self.report({"INFO"}, f"Removed {removed} selected {noun}.")
            return {"FINISHED"}

        self.removed_existing = False
        affected_armatures = {armature for armature, _bone, _camera in selected}
        camera_angle = _camera_angle_for_preset(self.preset, self.fov)
        _state["camera_fov_syncing"] = True
        try:
            context.window_manager.staticaliza_camera_fov_preset = self.preset
            context.window_manager.staticaliza_camera_fov = camera_angle
            context.window_manager.staticaliza_camera_orientation = self.orientation
        finally:
            _state["camera_fov_syncing"] = False

        created = 0
        preferred_camera = selected[0][2]
        for armature, pose_bone, existing_camera in selected:
            if existing_camera is not None:
                if preferred_camera is None:
                    preferred_camera = existing_camera
                continue

            camera_data = bpy.data.cameras.new(f"Camera - {pose_bone.name}")
            camera_data.type = "PERSP"
            camera_data.sensor_fit = "HORIZONTAL"
            camera_data.angle = camera_angle

            camera = bpy.data.objects.new(camera_data.name, camera_data)
            context.collection.objects.link(camera)
            camera[ATTACHED_CAMERA_OWNER_NAME_PROPERTY] = armature.name
            camera[ATTACHED_CAMERA_OWNER_UID_PROPERTY] = str(
                _armature_session_uid(armature)
            )
            camera[ATTACHED_CAMERA_BONE_PROPERTY] = pose_bone.name
            camera.staticaliza_camera_fov_preset = self.preset
            camera.staticaliza_camera_orientation = self.orientation
            camera_world = _camera_world_at_bone_tip(
                armature,
                pose_bone,
                camera.staticaliza_camera_orientation,
                context = context,
            )
            camera.parent = armature
            camera.parent_type = "BONE"
            camera.parent_bone = pose_bone.name
            camera.matrix_parent_inverse = Matrix.Identity(4)
            camera.matrix_world = camera_world
            bone_world = armature.matrix_world @ pose_bone.matrix
            local_matrix = bone_world.inverted_safe() @ camera_world
            camera[ATTACHED_CAMERA_LOCAL_MATRIX_PROPERTY] = tuple(
                float(value) for row in local_matrix for value in row
            )
            camera.staticaliza_camera_hide_attached_object = self.hide_attached_object
            camera.staticaliza_camera_opaque_frame = self.opaque_frame
            _apply_camera_passepartout(camera)
            _set_attached_camera_object_visibility(
                context.scene,
                camera,
                self.hide_attached_object,
            )
            if preferred_camera is None:
                preferred_camera = camera
            created += 1

        context.scene.render.resolution_x = 1920
        context.scene.render.resolution_y = 1080
        context.scene.render.resolution_percentage = 100
        if preferred_camera is not None:
            context.scene.camera = preferred_camera
        context.view_layer.update()
        frame = int(context.scene.frame_current)
        for armature in affected_armatures:
            _sync_all_dynamic_pose_bone_colors(frame, armature)
        context.view_layer.update()
        _tag_redraw_all_view3d()
        noun = "camera" if created == 1 else "cameras"
        self.report({"INFO"}, f"Added {created} selected {noun}.")
        return {"FINISHED"}


class ANIMATOR_UTILS_OT_toggle_attached_camera_view(bpy.types.Operator):
    bl_idname = "staticaliza.toggle_attached_camera_view"
    bl_label = "Toggle Attached Camera View"
    bl_description = "Enter the unambiguous selected bone camera, or leave camera view"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        return (
            getattr(getattr(context, "area", None), "type", "")
            == "VIEW_3D"
        )

    def execute(self, context):
        area = context.area
        space = context.space_data
        if getattr(space, "type", "") != "VIEW_3D":
            space = area.spaces.active
        region_data = getattr(space, "region_3d", None)
        if region_data is None:
            return {"FINISHED"}

        if _presentation_camera_navigation_locked(context):
            # Preview and Audio are presentation outputs, not free 3D
            # viewports. Numpad-0 must not toggle them out of their camera.
            return {"FINISHED"}

        if region_data.view_perspective == "CAMERA":
            _finish_attached_camera_exit(
                context,
                area,
                space,
                region_data,
            )
            _sync_free_viewports(
                context,
                source_region_data = region_data,
                source_space = space,
            )
            return {"FINISHED"}

        camera = _attached_camera_for_view(context)
        if camera is None:
            # Consume Numpad-0 so Blender cannot silently pick scene.camera
            # when no camera, or multiple unselected cameras, are attached.
            return {"FINISHED"}

        snapshot = _free_view_snapshot(region_data)
        try:
            space_pointer = int(space.as_pointer())
            region_pointer = int(region_data.as_pointer())
        except (AttributeError, ReferenceError):
            return {"FINISHED"}
        state = _camera_view_state(
            _state.setdefault("camera_view_spaces", {}).get(
                space_pointer
            )
        )
        state["return_view"] = snapshot
        state["pending_level"] = False
        state["last_rotation"] = None
        state["stable_ticks"] = 0
        state["entering"] = True
        state["enter_started"] = time.monotonic()
        state["camera_pointer"] = int(camera.as_pointer())
        state["camera_name"] = camera.name
        if snapshot is not None:
            _state["free_view_master"] = snapshot
            _state.setdefault("free_view_space_states", {})[
                region_pointer
            ] = snapshot

        context.scene.camera = camera
        try:
            space.camera = camera
        except (AttributeError, ReferenceError, TypeError):
            pass
        _select_attached_camera_bone(context, camera)
        _set_attached_camera_preview_visibility(context.scene, camera, True)
        window_region = next(
            (region for region in area.regions if region.type == "WINDOW"),
            None,
        )
        invoked_view_camera = False
        if window_region is not None:
            try:
                with context.temp_override(
                    area = area,
                    region = window_region,
                    space_data = space,
                ):
                    if bpy.ops.view3d.view_camera.poll():
                        bpy.ops.view3d.view_camera("INVOKE_DEFAULT")
                        invoked_view_camera = True
            except (AttributeError, ReferenceError, RuntimeError):
                pass
        # When Blender accepted view_camera it may be in smooth-view and
        # still report PERSP briefly. Do not force CAMERA here: that was the
        # instant snap that made Numpad-0 differ from the navigation button.
        if not invoked_view_camera and region_data.view_perspective != "CAMERA":
            try:
                region_data.view_perspective = "CAMERA"
            except (
                AttributeError,
                ReferenceError,
                RuntimeError,
                TypeError,
                ValueError,
            ):
                pass
        state["attached"] = region_data.view_perspective == "CAMERA"
        if state["attached"]:
            state["entering"] = False
            state["enter_started"] = 0.0
        _state["camera_view_spaces"][space_pointer] = state
        area.tag_redraw()
        return {"FINISHED"}


def _presentation_camera_navigation_locked(context):
    """True only for the dedicated Preview/Audio camera output area."""
    area = getattr(context, "area", None)
    space = getattr(context, "space_data", None)
    if getattr(area, "type", "") != "VIEW_3D":
        return False
    if getattr(space, "type", "") != "VIEW_3D":
        space = getattr(getattr(area, "spaces", None), "active", None)
    region_data = getattr(space, "region_3d", None)
    if (
        region_data is None
        or str(getattr(region_data, "view_perspective", "")) != "CAMERA"
    ):
        return False
    workspace = getattr(context, "workspace", None)
    if workspace is None:
        workspace = getattr(getattr(context, "window", None), "workspace", None)
    return str(getattr(workspace, "name", "")).strip().casefold() in {
        "preview",
        "audio",
    }


class ANIMATOR_UTILS_OT_attached_camera_wheel_exit(bpy.types.Operator):
    bl_idname = "staticaliza.attached_camera_wheel_exit"
    bl_label = "Exit Attached Camera View"
    bl_description = (
        "Leave an attached camera view while preserving normal free-view orbit controls"
    )
    bl_options = {"INTERNAL"}

    begin_orbit: bpy.props.BoolProperty(
        default = False,
        options = {"SKIP_SAVE"},
    )

    def _exit_camera(self, context):
        area = getattr(context, "area", None)
        space = getattr(context, "space_data", None)
        region_data = getattr(space, "region_3d", None)
        camera = getattr(space, "camera", None) or context.scene.camera
        armature, bone_name = _camera_bone_binding(camera)
        if (
            area is None
            or area.type != "VIEW_3D"
            or region_data is None
            or region_data.view_perspective != "CAMERA"
            or armature is None
            or not bone_name
        ):
            return None
        _finish_attached_camera_exit(context, area, space, region_data)
        _sync_free_viewports(
            context,
            source_region_data = region_data,
            source_space = space,
        )
        return region_data

    def execute(self, context):
        if _presentation_camera_navigation_locked(context):
            return {"FINISHED"}
        if self._exit_camera(context) is None:
            return {"PASS_THROUGH"}
        return {"FINISHED"}

    def invoke(self, context, event):
        if _presentation_camera_navigation_locked(context):
            return {"FINISHED"}
        if not self.begin_orbit:
            return self.execute(context)
        region_data = self._exit_camera(context)
        if region_data is None:
            return {"PASS_THROUGH"}
        self._region_data = region_data
        self._last_mouse_x = int(event.mouse_x)
        self._last_mouse_y = int(event.mouse_y)
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}
    def modal(self, context, event):
        if event.type == "MIDDLEMOUSE" and event.value == "RELEASE":
            return {"FINISHED"}
        if event.type == "ESC":
            return {"FINISHED"}
        if event.type != "MOUSEMOVE":
            return {"RUNNING_MODAL"}

        region_data = getattr(self, "_region_data", None)
        if region_data is None:
            return {"CANCELLED"}
        mouse_x = int(event.mouse_x)
        mouse_y = int(event.mouse_y)
        delta_x = mouse_x - int(self._last_mouse_x)
        delta_y = mouse_y - int(self._last_mouse_y)
        self._last_mouse_x = mouse_x
        self._last_mouse_y = mouse_y
        if not delta_x and not delta_y:
            return {"RUNNING_MODAL"}

        # Initialize this one transition gesture entirely from the restored
        # free-view quaternion. Blender's native camera-exit orbit caches the
        # upside-down camera basis before Python can replace RegionView3D,
        # reversing horizontal input until MMB is released.
        sensitivity = 0.005
        rotation = region_data.view_rotation.copy()
        world_up = Vector((0.0, 0.0, 1.0))
        yaw = Quaternion(world_up, -float(delta_x) * sensitivity)
        rotation = yaw @ rotation
        right = rotation @ Vector((1.0, 0.0, 0.0))
        if right.length_squared > 1.0e-12:
            pitch = Quaternion(
                right.normalized(),
                -float(delta_y) * sensitivity,
            )
            candidate = pitch @ rotation
            direction = candidate @ Vector((0.0, 0.0, -1.0))
            if abs(direction.dot(world_up)) < 1.0 - 1.0e-5:
                rotation = candidate
        rotation.normalize()
        region_data.view_rotation = rotation
        snapshot = _free_view_snapshot(region_data)
        if snapshot is not None:
            _state["free_view_master"] = snapshot
        _sync_free_viewports(
            context,
            source_region_data = region_data,
            source_space = context.space_data,
        )
        try:
            context.area.tag_redraw()
        except (AttributeError, ReferenceError):
            pass
        return {"RUNNING_MODAL"}


class ANIMATOR_UTILS_OT_keyframe_camera_view(bpy.types.Operator):
    bl_idname = "staticaliza.keyframe_camera_view"
    bl_label = "Keyframe View"
    bl_description = "Move the selected bone camera to the current view and insert a keyframe"
    bl_options = {"REGISTER", "UNDO"}

    @staticmethod
    def _enter_camera_view(context, camera):
        if camera is None:
            return False
        context.scene.camera = camera
        area = getattr(context, "area", None)
        if getattr(area, "type", "") != "VIEW_3D":
            return False
        space = getattr(context, "space_data", None)
        if getattr(space, "type", "") != "VIEW_3D":
            space = area.spaces.active
        try:
            space.camera = camera
        except (AttributeError, ReferenceError, TypeError):
            pass
        region_data = getattr(space, "region_3d", None)
        if (
            region_data is not None
            and region_data.view_perspective == "CAMERA"
        ):
            return True
        window_region = next(
            (region for region in area.regions if region.type == "WINDOW"),
            None,
        )
        if window_region is None:
            return False
        try:
            with context.temp_override(
                area = area,
                region = window_region,
                space_data = space,
            ):
                if bpy.ops.view3d.view_camera.poll():
                    bpy.ops.view3d.view_camera()
        except (AttributeError, RuntimeError):
            return False
        return bool(
            region_data is not None
            and region_data.view_perspective == "CAMERA"
        )

    def execute(self, context):
        camera_world = _view_camera_matrix(context)
        if camera_world is None:
            return {"FINISHED"}

        armature, pose_bone, camera = _selected_camera_bone(context)
        if camera is not None:
            if _keyframe_camera_bone(context, armature, pose_bone, camera, camera_world):
                context.scene.camera = camera
                context.view_layer.update()
                self._enter_camera_view(context, camera)
                self.report({"INFO"}, f"Keyframed camera bone {pose_bone.name}.")
            return {"FINISHED"}

        camera = _standalone_camera(context)
        if camera is None:
            return {"FINISHED"}
        _keyframe_standalone_camera(camera, context.scene.frame_current, camera_world)
        context.scene.camera = camera
        context.view_layer.update()
        self._enter_camera_view(context, camera)
        self.report({"INFO"}, f"Keyframed camera {camera.name}.")
        return {"FINISHED"}
