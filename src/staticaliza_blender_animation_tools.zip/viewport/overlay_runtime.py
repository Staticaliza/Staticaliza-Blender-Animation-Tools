"""Viewport overlay draw-handler lifecycle and projection geometry."""

from ..core.runtime import *  # noqa: F403

def _runtime_needed(context):
    wm = getattr(context, "window_manager", None)
    if not wm:
        return bool(
            _state["yellow_modes"]
            or _state.get("onion_enabled_owners", set())
        )
    label_runtime = bool(
        getattr(wm, "show_bone_names_enabled", True)
        and _pose_panel_armatures(context)
    )
    return (
        label_runtime
        or
        bool(_state.get("onion_enabled_owners", set()))
        or bool(_state["yellow_modes"])
        or bool(_pose_scope_armatures(context))
        or bool(_custom_bone_label_targets(context)[1])
        or bool(_surface_contact_guides())
        or bool(_dynamic_parent_visible_relationships(context))
    )

def _enable_runtime():
    if (
        _state["enabled"]
        and _state.get("handle_view") is not None
        and _state.get("handle_pixel") is not None
    ):
        return
    # Recover after extension reloads or workspace changes that invalidate one
    # draw handle without clearing the old enabled flag.
    unregister_owned_draw_handler("handle_view")
    unregister_owned_draw_handler("handle_pixel")
    _state["enabled"] = True
    register_owned_draw_handler(
        "handle_view",
        _draw_view,
        (),
        "WINDOW",
        "POST_VIEW",
    )
    register_owned_draw_handler(
        "handle_pixel",
        _draw_pixel,
        (),
        "WINDOW",
        "POST_PIXEL",
    )
    _tag_redraw_all_view3d()

def _disable_runtime():
    _state["enabled"] = False
    unregister_owned_draw_handler("handle_view")
    unregister_owned_draw_handler("handle_pixel")

    _state["mesh_batches"] = {}
    _state["raycast_fixed"] = {}
    _tag_redraw_all_view3d()

def _circle_tris_2d(center_xy, radius, segments = 18):
    if radius <= 0.0:
        return []

    cx, cy = center_xy
    verts = []

    for i in range(segments):
        a0 = (i / segments) * (math.pi * 2.0)
        a1 = ((i + 1) / segments) * (math.pi * 2.0)

        v0 = (cx, cy)
        v1 = (cx + math.cos(a0) * radius, cy + math.sin(a0) * radius)
        v2 = (cx + math.cos(a1) * radius, cy + math.sin(a1) * radius)

        verts.extend((v0, v1, v2))

    return verts


def _circle_lines_2d(center_xy, radius, segments = 24):
    if radius <= 0.0:
        return []

    cx, cy = center_xy
    verts = []
    for index in range(segments):
        angle_a = (index / segments) * math.tau
        angle_b = ((index + 1) / segments) * math.tau
        verts.extend((
            (cx + math.cos(angle_a) * radius, cy + math.sin(angle_a) * radius),
            (cx + math.cos(angle_b) * radius, cy + math.sin(angle_b) * radius),
        ))
    return verts

def _circle_scale_from_dist(distance_world):
    # A near endpoint must match the static target dot exactly for both pin
    # systems; only separation grows the moving endpoint.
    min_scale = 1.0
    max_scale = 3.0
    min_distance = PIN_SNAP_WORLD_RADIUS * 1.75
    max_distance = PIN_SNAP_WORLD_RADIUS * 24.0

    if distance_world <= min_distance:
        return min_scale
    if distance_world >= max_distance:
        return max_scale

    t = (distance_world - min_distance) / (
        max_distance - min_distance
    )
    t = t * t * (3.0 - (2.0 * t))
    return min_scale + (t * (max_scale - min_scale))


def _project_world_point_2d(region, region_data, world_point):
    from bpy_extras import view3d_utils

    try:
        projected = view3d_utils.location_3d_to_region_2d(
            region,
            region_data,
            Vector(world_point),
        )
        if projected is None:
            return None
        point = (float(projected.x), float(projected.y))
        if not all(
            math.isfinite(value) and abs(value) <= 1.0e12
            for value in point
        ):
            return None
        return point
    except (AttributeError, RuntimeError, TypeError, ValueError):
        return None


def _clip_line_to_region_2d(region, first, second, margin = 16.0):
    """Clip very long projected lines before sending them to the GPU."""
    x_min = -float(margin)
    y_min = -float(margin)
    x_max = float(region.width) + float(margin)
    y_max = float(region.height) + float(margin)
    x0, y0 = (float(first[0]), float(first[1]))
    x1, y1 = (float(second[0]), float(second[1]))
    dx = x1 - x0
    dy = y1 - y0
    t0 = 0.0
    t1 = 1.0
    for p, q in (
        (-dx, x0 - x_min),
        (dx, x_max - x0),
        (-dy, y0 - y_min),
        (dy, y_max - y0),
    ):
        if abs(p) <= 1.0e-12:
            if q < 0.0:
                return None
            continue
        ratio = q / p
        if p < 0.0:
            if ratio > t1:
                return None
            t0 = max(t0, ratio)
        else:
            if ratio < t0:
                return None
            t1 = min(t1, ratio)
    return (
        (x0 + (dx * t0), y0 + (dy * t0)),
        (x0 + (dx * t1), y0 + (dy * t1)),
    )


def _project_world_segment_2d(context, first_world, second_world):
    """Project a pin segment, clipping crossings of the viewer near plane."""
    region = getattr(context, "region", None)
    region_data = getattr(context, "region_data", None)
    if region is None or region_data is None:
        return None, None, None
    first_world = Vector(first_world)
    second_world = Vector(second_world)
    first = _project_world_point_2d(region, region_data, first_world)
    second = _project_world_point_2d(region, region_data, second_world)

    line_first = first
    line_second = second
    if (line_first is None) != (line_second is None):
        try:
            if bool(region_data.is_perspective):
                first_view = region_data.view_matrix @ first_world.to_4d()
                second_view = region_data.view_matrix @ second_world.to_4d()
                clip_start = max(
                    1.0e-5,
                    float(
                        getattr(
                            getattr(context, "space_data", None),
                            "clip_start",
                            0.01,
                        )
                    ),
                )
                near_z = -(clip_start * 1.001)
                denominator = float(second_view.z - first_view.z)
                if abs(denominator) > 1.0e-12:
                    factor = max(
                        0.0,
                        min(
                            1.0,
                            (near_z - float(first_view.z)) / denominator,
                        ),
                    )
                    clipped_world = first_world.lerp(second_world, factor)
                    clipped = _project_world_point_2d(
                        region,
                        region_data,
                        clipped_world,
                    )
                    if line_first is None:
                        line_first = clipped
                    else:
                        line_second = clipped
        except (AttributeError, RuntimeError, TypeError, ValueError):
            pass

    line = (
        _clip_line_to_region_2d(region, line_first, line_second)
        if line_first is not None and line_second is not None
        else None
    )
    margin = PIN_SNAP_RING_PIXEL_RADIUS + 2.0

    def visible_point(point):
        return point if point is not None and (
            -margin <= point[0] <= float(region.width) + margin
            and -margin <= point[1] <= float(region.height) + margin
        ) else None

    return line, visible_point(first), visible_point(second)

def _bounds_init(p):
    return [p.x, p.y, p.z, p.x, p.y, p.z]

def _bounds_add(b, p):
    if p.x < b[0]:
        b[0] = p.x
    if p.y < b[1]:
        b[1] = p.y
    if p.z < b[2]:
        b[2] = p.z
    if p.x > b[3]:
        b[3] = p.x
    if p.y > b[4]:
        b[4] = p.y
    if p.z > b[5]:
        b[5] = p.z

def _bounds_center(b):
    return Vector(((b[0] + b[3]) * 0.5, (b[1] + b[4]) * 0.5, (b[2] + b[5]) * 0.5))
