"""Viewport shading, overlay, and gizmo setting synchronization."""

from ..core.runtime import *  # noqa: F403

_VIEW3D_SPACE_SYNC_PROPERTIES = (
    "lens",
    "clip_start",
    "clip_end",
)

# Free-view synchronization belongs only to the four animator workspaces.  In
# particular, native gizmo visibility is intentionally *not* synchronized:
# writing any ``show_gizmo*`` property rebuilds viewport gizmo state and can
# invalidate hit testing while the user is pressing a handle.
_VIEW3D_SYNC_WORKSPACES = frozenset({
    "animate",
    "graph",
    "audio",
    "preview",
})

_VIEW3D_SHADING_SYNC_PROPERTIES = (
    "type",
    "light",
    "studio_light",
    "use_world_space_lighting",
    "show_object_outline",
    "show_backface_culling",
    "show_cavity",
    "cavity_type",
    "curvature_ridge_factor",
    "curvature_valley_factor",
    "cavity_ridge_factor",
    "cavity_valley_factor",
    "studiolight_rotate_z",
    "studiolight_intensity",
    "studiolight_background_alpha",
    "studiolight_background_blur",
    "use_studiolight_view_rotation",
    "color_type",
    "single_color",
    "background_type",
    "background_color",
    "show_shadows",
    "show_xray",
    "show_xray_wireframe",
    "xray_alpha",
    "xray_alpha_wireframe",
    "use_dof",
    "use_scene_lights",
    "use_scene_world",
    "use_scene_lights_render",
    "use_scene_world_render",
    "show_specular_highlight",
    "object_outline_color",
    "shadow_intensity",
    "render_pass",
    "aov_name",
    "use_compositor",
)

_VIEW3D_OVERLAY_SYNC_PROPERTIES = (
    "show_overlays",
    "show_ortho_grid",
    "show_floor",
    "show_axis_x",
    "show_axis_y",
    "show_axis_z",
    "grid_scale",
    "grid_lines",
    "grid_subdivisions",
    "show_outline_selected",
    "show_object_origins",
    "show_object_origins_all",
    "show_relationship_lines",
    "show_cursor",
    "show_text",
    "show_stats",
    "show_performance",
    "show_camera_guides",
    "show_camera_passepartout",
    "show_extras",
    "show_light_colors",
    "show_bones",
    "show_face_orientation",
    "show_fade_inactive",
    "fade_inactive_alpha",
    "show_xray_bone",
    "xray_alpha_bone",
    "bone_wire_alpha",
    "show_motion_paths",
    "show_onion_skins",
    "show_look_dev",
    "show_wireframes",
    "wireframe_threshold",
    "wireframe_opacity",
    "show_annotation",
)


_PRESENTATION_VIEW3D_SPACE_OVERRIDES = {
    "show_gizmo": False,
}

_PRESENTATION_VIEW3D_OVERLAY_OVERRIDES = {
    "show_overlays": False,
}


def _presentation_view3d_settings_snapshot(snapshot):
    if snapshot is None:
        return None
    return (
        tuple(
            item
            for item in snapshot[0]
            if item[0] not in _PRESENTATION_VIEW3D_SPACE_OVERRIDES
        ),
        snapshot[1],
        tuple(
            item
            for item in snapshot[2]
            if item[0] not in _PRESENTATION_VIEW3D_OVERLAY_OVERRIDES
        ),
    )


def _presentation_view3d_source_snapshot(snapshot, master):
    """Mask clean-workspace overrides from a source snapshot."""
    if snapshot is None:
        return None

    def masked_group(group, master_group, forced_names):
        master_values = dict(master_group or ())
        result = []
        seen = set()
        for name, value in group:
            if name not in forced_names:
                result.append((name, value))
                continue
            if name in master_values:
                result.append((name, master_values[name]))
                seen.add(name)
        for name, value in master_group or ():
            if name in forced_names and name not in seen:
                result.append((name, value))
        return tuple(result)

    master = master if master is not None else ((), (), ())
    return (
        masked_group(
            snapshot[0],
            master[0],
            _PRESENTATION_VIEW3D_SPACE_OVERRIDES,
        ),
        snapshot[1],
        masked_group(
            snapshot[2],
            master[2],
            _PRESENTATION_VIEW3D_OVERLAY_OVERRIDES,
        ),
    )


def _apply_presentation_viewport_overrides(space):
    if space is None or getattr(space, "type", "") != "VIEW_3D":
        return False
    changed = _apply_view3d_owner_settings(
        space,
        tuple(_PRESENTATION_VIEW3D_SPACE_OVERRIDES.items()),
    )
    try:
        changed |= _apply_view3d_owner_settings(
            space.overlay,
            tuple(_PRESENTATION_VIEW3D_OVERLAY_OVERRIDES.items()),
        )
    except (AttributeError, ReferenceError, RuntimeError):
        pass
    return bool(changed)


def _sync_presentation_viewport_overlays(context):
    changed = False
    for _pointer, screen, area, space in _view3d_setting_records(context):
        if not _screen_is_presentation(screen, context):
            continue
        if _apply_presentation_viewport_overrides(space):
            changed = True
            try:
                area.tag_redraw()
            except (AttributeError, ReferenceError):
                pass
    return changed


def _view3d_setting_value(owner, name):
    try:
        value = getattr(owner, name)
    except (AttributeError, ReferenceError, RuntimeError):
        return None
    if isinstance(value, (bool, int, float, str)):
        return value
    try:
        return tuple(value)
    except TypeError:
        return None


def _view3d_owner_settings(owner, property_names):
    return tuple(
        (name, value)
        for name in property_names
        if (value := _view3d_setting_value(owner, name)) is not None
    )


def _view3d_settings_snapshot(space):
    try:
        return (
            _view3d_owner_settings(
                space,
                _VIEW3D_SPACE_SYNC_PROPERTIES,
            ),
            _view3d_owner_settings(
                space.shading,
                _VIEW3D_SHADING_SYNC_PROPERTIES,
            ),
            _view3d_owner_settings(
                space.overlay,
                _VIEW3D_OVERLAY_SYNC_PROPERTIES,
            ),
        )
    except (AttributeError, ReferenceError, RuntimeError):
        return None


def _apply_view3d_owner_settings(owner, settings):
    changed = False
    for name, value in settings:
        if _view3d_setting_value(owner, name) == value:
            continue
        try:
            setattr(owner, name, value)
            changed = True
        except (
            AttributeError,
            ReferenceError,
            RuntimeError,
            TypeError,
            ValueError,
        ):
            pass
    return changed


def _apply_view3d_settings_snapshot(space, snapshot):
    if snapshot is None:
        return False
    try:
        return bool(
            _apply_view3d_owner_settings(space, snapshot[0])
            | _apply_view3d_owner_settings(space.shading, snapshot[1])
            | _apply_view3d_owner_settings(space.overlay, snapshot[2])
        )
    except (AttributeError, ReferenceError, RuntimeError):
        return False


def _view3d_sync_workspace_supported(workspace):
    if workspace is None:
        return False
    try:
        name = _strip_blender_numeric_suffix(workspace.name)
    except (AttributeError, ReferenceError, TypeError, ValueError):
        return False
    return str(name).strip().casefold() in _VIEW3D_SYNC_WORKSPACES


def _view3d_sync_screen_sources(context = None):
    """Return unique screens owned by the animator's four workspaces."""
    context = context or bpy.context
    sources = []
    seen = set()

    window_manager = getattr(context, "window_manager", None)
    for window in tuple(getattr(window_manager, "windows", ())):
        workspace = getattr(window, "workspace", None)
        screen = getattr(window, "screen", None)
        if screen is None or not _view3d_sync_workspace_supported(workspace):
            continue
        try:
            pointer = int(screen.as_pointer())
        except (AttributeError, ReferenceError, TypeError, ValueError):
            continue
        if pointer in seen:
            continue
        seen.add(pointer)
        sources.append((workspace, screen))

    for workspace in tuple(bpy.data.workspaces):
        if not _view3d_sync_workspace_supported(workspace):
            continue
        for screen in tuple(getattr(workspace, "screens", ())):
            try:
                pointer = int(screen.as_pointer())
            except (AttributeError, ReferenceError, TypeError, ValueError):
                continue
            if pointer in seen:
                continue
            seen.add(pointer)
            sources.append((workspace, screen))
    return tuple(sources)


def _view3d_setting_records(context = None):
    records = []
    seen = set()
    for _workspace, screen in _view3d_sync_screen_sources(context):
        try:
            areas = tuple(screen.areas)
        except (AttributeError, ReferenceError):
            continue
        for area in areas:
            if area.type != "VIEW_3D":
                continue
            for space in tuple(area.spaces):
                if space.type != "VIEW_3D":
                    continue
                try:
                    pointer = int(space.as_pointer())
                except (AttributeError, ReferenceError):
                    continue
                if pointer in seen:
                    continue
                seen.add(pointer)
                records.append((pointer, screen, area, space))
    return records
