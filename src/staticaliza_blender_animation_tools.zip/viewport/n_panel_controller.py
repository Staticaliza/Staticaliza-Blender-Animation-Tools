"""Animate/Graph viewport sidebar synchronization controller."""

from ..core.runtime import *  # noqa: F403

def _sync_view3d_n_panels(context, source_space = None):
    """Synchronize the paired sidebars without letting targets source writes."""
    now = time.monotonic()
    records = _view3d_n_panel_records(context)
    if not records:
        return

    states = _state.setdefault("view3d_n_panel_states", {})
    master = _state.get("view3d_n_panel_master")
    if master is not None and not isinstance(master, dict):
        master = None
    elif master is not None:
        master = dict(master)
        master.setdefault("revision", 1)
        master.setdefault("source", 0)
        master.setdefault("scroll_pending", False)

    window_manager = getattr(context, "window_manager", None)
    windows_by_screen = {}
    active_screen_pointers = set()
    activated_screen_pointers = set()
    window_screens = _state.setdefault(
        "view3d_n_panel_window_screens",
        {},
    )
    live_window_pointers = set()
    for window in tuple(getattr(window_manager, "windows", ())):
        screen = getattr(window, "screen", None)
        workspace = getattr(window, "workspace", None)
        if screen is None:
            continue
        try:
            window_pointer = int(window.as_pointer())
            screen_pointer = int(screen.as_pointer())
            workspace_pointer = (
                int(workspace.as_pointer()) if workspace is not None else 0
            )
        except (AttributeError, ReferenceError, TypeError, ValueError):
            continue
        live_window_pointers.add(window_pointer)
        current_binding = (screen_pointer, workspace_pointer)
        previous_binding = window_screens.get(window_pointer)
        window_screens[window_pointer] = current_binding
        if not _view3d_n_panel_workspace_supported(workspace):
            continue
        windows_by_screen.setdefault(screen_pointer, []).append(window)
        active_screen_pointers.add(screen_pointer)
        if (
            master is not None
            and previous_binding != current_binding
        ):
            activated_screen_pointers.add(screen_pointer)
    for window_pointer in tuple(window_screens):
        if window_pointer not in live_window_pointers:
            window_screens.pop(window_pointer, None)

    try:
        source_pointer = int(source_space.as_pointer()) if source_space else 0
    except (AttributeError, ReferenceError, TypeError, ValueError):
        source_pointer = 0
    context_workspace = getattr(context, "workspace", None)
    context_screen = getattr(context, "screen", None)

    current = []
    live_pointers = set()
    for record in records:
        pointer, workspace, screen, area, space, region = record
        live_pointers.add(pointer)
        snapshot = _view3d_n_panel_snapshot(space, region)
        try:
            screen_pointer = int(screen.as_pointer())
        except (AttributeError, ReferenceError, TypeError, ValueError):
            screen_pointer = 0
        active = screen_pointer in active_screen_pointers
        prior = states.get(pointer)
        new_state = not isinstance(prior, dict)
        if new_state:
            old_observed = (
                prior
                if isinstance(prior, tuple) and len(prior) == 3
                else snapshot
            )
            prior = _view3d_n_panel_state(old_observed, False)
            states[pointer] = prior
        was_active = bool(prior.get("active", False))
        just_activated = bool(
            active
            and (
                not was_active
                or new_state
                or screen_pointer in activated_screen_pointers
            )
        )
        prior["active"] = active
        current.append(
            (record, snapshot, prior, active, just_activated)
        )

    def source_priority(item):
        record = item[0]
        pointer, workspace, screen, area, _space, _region = record
        return (
            pointer == source_pointer,
            workspace == context_workspace,
            screen == context_screen,
            pointer == int((master or {}).get("source", 0)),
            int(getattr(area, "width", 0))
            * int(getattr(area, "height", 0)),
            -pointer,
        )

    if master is None:
        active_items = [item for item in current if item[3]]
        if not active_items:
            # Do not let an inactive workspace's never-drawn/default View2D
            # become authoritative while the user is in Preview or another
            # workspace.  The first actually visible paired viewport seeds
            # the master instead.
            for _record, snapshot, state, _active, _activated in current:
                state["observed"] = snapshot
            for pointer in tuple(states):
                if pointer not in live_pointers:
                    states.pop(pointer, None)
            return
        seed = max(active_items, key = source_priority)
        seed_record, seed_snapshot, seed_state = seed[:3]
        seed_pointer = seed_record[0]
        master = _view3d_n_panel_master_from_snapshot(
            seed_snapshot,
            seed_pointer,
        )
        _state["view3d_n_panel_master"] = master
        if master.get("scroll_pending", False):
            seed_state["capture_scroll_at"] = (
                now + _VIEW3D_N_PANEL_CATEGORY_SETTLE
            )
        elif master.get("visible", False) and not master.get("category", ""):
            seed_state["capture_category"] = True
        for record, _snapshot, state, _active, _activated in current:
            if record[0] != seed_pointer:
                _view3d_n_panel_mark_pending(
                    state,
                    master["revision"],
                    now,
                )
    else:
        for _record, _snapshot, state, active, just_activated in current:
            if active and just_activated:
                _view3d_n_panel_mark_pending(
                    state,
                    master["revision"],
                    now,
                )
                state["activation_fast_until"] = now + 0.25

    def can_source(state, active):
        return bool(
            active
            and not int(state.get("pending_revision", 0))
            and now >= float(state.get("block_until", 0.0))
        )

    # Finish an already-stable application before inspecting this poll.  If
    # the user changed the target between timer ticks, its last observed
    # (master-matching) baseline proves the pending write was complete, so we
    # must not overwrite that fresh interaction below.
    for _record, _snapshot, state, active, _activated in current:
        settle_since = float(state.get("settle_since", 0.0))
        if (
            active
            and int(state.get("pending_revision", 0))
            and settle_since
            and now - settle_since >= _VIEW3D_N_PANEL_TARGET_SETTLE
            and _view3d_n_panel_snapshot_matches_master(
                state.get("observed", (False, "", None)),
                master,
            )
        ):
            state["pending_revision"] = 0
            state["settle_since"] = 0.0
            state["block_until"] = (
                now + _VIEW3D_N_PANEL_SOURCE_GUARD
            )

    changed_items = []
    for item in current:
        record, snapshot, state, active = item[:4]
        if not can_source(state, active):
            continue
        fields = _view3d_n_panel_changed_fields(
            state.get("observed"),
            snapshot,
            master,
        )
        capture_at = float(state.get("capture_scroll_at", 0.0))
        if (
            capture_at
            and now >= capture_at
            and snapshot[0]
            and snapshot[1]
            and snapshot[1] == str(master.get("category", ""))
            and snapshot[2] is not None
        ):
            fields.add("scroll")
        if fields:
            changed_items.append((item, fields))

    source_change = (
        max(changed_items, key = lambda entry: source_priority(entry[0]))
        if changed_items
        else None
    )
    if source_change is not None:
        source_item, changed_fields = source_change
        source_record, source_snapshot, source_state = source_item[:3]
        source_pointer_value = source_record[0]
        updated_master, master_changed = _view3d_n_panel_update_master(
            master,
            source_snapshot,
            changed_fields,
            source_pointer_value,
        )
        source_state["capture_scroll_at"] = 0.0
        if master_changed:
            master = updated_master
            _state["view3d_n_panel_master"] = master
            if "category" in changed_fields:
                source_state["capture_category"] = False
                source_state["capture_category_value"] = ""
                source_state["capture_category_since"] = 0.0
                source_state["capture_scroll_at"] = (
                    now + _VIEW3D_N_PANEL_CATEGORY_SETTLE
                )
            for record, _snapshot, state, _active, _activated in current:
                if record[0] == source_pointer_value:
                    # A sidebar opened by the user still needs its preserved
                    # tab/scroll copied back after Blender initializes it.
                    if "visible" in changed_fields and source_snapshot[0]:
                        _view3d_n_panel_mark_pending(
                            state,
                            master["revision"],
                            now,
                        )
                        if not str(master.get("category", "")):
                            state["capture_category"] = True
                        elif master.get("scroll_pending", False):
                            state["capture_scroll_at"] = (
                                now + _VIEW3D_N_PANEL_CATEGORY_SETTLE
                            )
                    else:
                        state["pending_revision"] = 0
                    continue
                _view3d_n_panel_mark_pending(
                    state,
                    master["revision"],
                    now,
                )

    # A sidebar can be opened while its UI region still reports UNSUPPORTED.
    # Capture its first stable category explicitly; pending targets remain
    # barred from sourcing any other state throughout this initialization.
    category_seeds = []
    for item in current:
        _record, snapshot, state, active = item[:4]
        if not state.get("capture_category", False) or not active:
            continue
        category = str(snapshot[1] or "")
        if not snapshot[0] or not category:
            state["capture_category_value"] = ""
            state["capture_category_since"] = 0.0
            continue
        if state.get("capture_category_value") != category:
            state["capture_category_value"] = category
            state["capture_category_since"] = now
            continue
        if (
            now - float(state.get("capture_category_since", 0.0))
            >= _VIEW3D_N_PANEL_CATEGORY_SETTLE
        ):
            category_seeds.append(item)
    if not str(master.get("category", "")) and category_seeds:
        seed = max(category_seeds, key = source_priority)
        seed_record, seed_snapshot, seed_state = seed[:3]
        seeded_master, seeded = _view3d_n_panel_update_master(
            master,
            seed_snapshot,
            {"category"},
            seed_record[0],
        )
        if seeded:
            master = seeded_master
            _state["view3d_n_panel_master"] = master
            seed_state["capture_category"] = False
            seed_state["capture_category_value"] = ""
            seed_state["capture_category_since"] = 0.0
            seed_state["capture_scroll_at"] = (
                now + _VIEW3D_N_PANEL_CATEGORY_SETTLE
            )
            for record, _snapshot, state, _active, _activated in current:
                _view3d_n_panel_mark_pending(
                    state,
                    master["revision"],
                    now,
                )

    # If the source category was initialized after a redraw, finish its
    # deferred scroll capture before targets can become authoritative.
    if master.get("scroll_pending", False):
        scroll_seeds = []
        for item in current:
            record, snapshot, state, active = item[:4]
            if (
                active
                and snapshot[0]
                and snapshot[1]
                and snapshot[1] == str(master.get("category", ""))
                and snapshot[2] is not None
            ):
                capture_at = float(state.get("capture_scroll_at", 0.0))
                category_since = float(state.get("category_since", 0.0))
                if capture_at:
                    ready = now >= capture_at
                else:
                    ready = bool(
                        category_since
                        and now - category_since
                        >= _VIEW3D_N_PANEL_CATEGORY_SETTLE
                    )
                if ready:
                    scroll_seeds.append(item)
        if scroll_seeds:
            seed = max(scroll_seeds, key = source_priority)
            seed_record, seed_snapshot, seed_state = seed[:3]
            seeded_master, seeded = _view3d_n_panel_update_master(
                master,
                seed_snapshot,
                {"scroll"},
                seed_record[0],
            )
            if seeded:
                master = seeded_master
                _state["view3d_n_panel_master"] = master
                seed_state["capture_scroll_at"] = 0.0
                for record, _snapshot, state, _active, _activated in current:
                    if record[0] != seed_record[0]:
                        _view3d_n_panel_mark_pending(
                            state,
                            master["revision"],
                            now,
                        )

    desired_visible = bool(master.get("visible", False))
    desired_category = str(master.get("category", ""))
    desired_scroll = master.get("scroll")
    scroll_pending = bool(master.get("scroll_pending", False))
    revision = int(master.get("revision", 1))

    for record, _snapshot, state, active, just_activated in current:
        pointer, _workspace, screen, area, space, region = record
        pending_revision = int(state.get("pending_revision", 0))
        if not pending_revision:
            # Keep the pre-application baseline through the guard.  A real
            # user edit made during this short window is then detected as
            # soon as the guard expires instead of being silently absorbed.
            if now >= float(state.get("block_until", 0.0)):
                state["observed"] = _view3d_n_panel_snapshot(space, region)
            continue
        if pending_revision < revision:
            _view3d_n_panel_mark_pending(state, revision, now)

        redraw = False
        wrote = False
        current_snapshot = _view3d_n_panel_snapshot(space, region)
        activation_fast = bool(
            just_activated
            or now <= float(state.get("activation_fast_until", 0.0))
        )
        activation_scroll_ready = bool(
            activation_fast
            and active
            and desired_visible
            and bool(current_snapshot[0]) == desired_visible
            and desired_category
            and current_snapshot[1] == desired_category
            and desired_scroll is not None
            and current_snapshot[2] is not None
            and not scroll_pending
            and _view3d_n_panel_view2d_ready(region)
        )
        if bool(current_snapshot[0]) != desired_visible:
            try:
                space.show_region_ui = desired_visible
                redraw = True
                wrote = True
            except (AttributeError, ReferenceError, RuntimeError):
                pass
            state["category_since"] = 0.0
            state["category_match"] = ""
            state["settle_since"] = 0.0
            current_snapshot = _view3d_n_panel_snapshot(space, region)

        category_matches = bool(
            not desired_visible
            or not desired_category
            or current_snapshot[1] == desired_category
        )
        if active and desired_visible and desired_category:
            if current_snapshot[1] != desired_category:
                state["category_since"] = 0.0
                state["category_match"] = ""
                if (
                    now - float(state.get("last_category_attempt", 0.0))
                    >= _VIEW3D_N_PANEL_APPLY_INTERVAL
                ):
                    state["last_category_attempt"] = now
                    try:
                        region.active_panel_category = desired_category
                        wrote = True
                    except (
                        AttributeError,
                        ReferenceError,
                        RuntimeError,
                        TypeError,
                        ValueError,
                    ):
                        pass
                    redraw = True
                    current_snapshot = _view3d_n_panel_snapshot(
                        space,
                        region,
                    )
            if current_snapshot[1] == desired_category:
                # Setting active_panel_category can initialize View2D
                # synchronously during PRE_VIEW. Re-evaluate the activation
                # fast path so the first visible frame also gets its scroll.
                activation_scroll_ready = bool(
                    activation_fast
                    and active
                    and desired_visible
                    and bool(current_snapshot[0]) == desired_visible
                    and desired_scroll is not None
                    and current_snapshot[2] is not None
                    and not scroll_pending
                    and _view3d_n_panel_view2d_ready(region)
                )
                if activation_scroll_ready:
                    # This target's tab and View2D were already initialized
                    # before its first draw.  Pan now so a stale first frame
                    # is not rendered, while pending_revision still prevents
                    # the target from feeding state back into the master.
                    state["category_match"] = desired_category
                    state["category_since"] = now
                elif state.get("category_match") != desired_category:
                    state["category_match"] = desired_category
                    state["category_since"] = now
                elif not float(state.get("category_since", 0.0)):
                    state["category_since"] = now
                category_matches = True
            else:
                category_matches = False

        scroll_matches = bool(
            not desired_visible
            or not desired_category
            or desired_scroll is None
            or _view3d_n_panel_scrolls_match(
                current_snapshot[2],
                desired_scroll,
            )
        )
        category_since = float(state.get("category_since", 0.0))
        if (
            active
            and desired_visible
            and desired_category
            and category_matches
            and desired_scroll is not None
            and not scroll_matches
            and (
                activation_scroll_ready
                or (
                    category_since
                    and now - category_since
                    >= _VIEW3D_N_PANEL_CATEGORY_SETTLE
                )
            )
            and (
                activation_scroll_ready
                or now - float(state.get("last_pan_attempt", 0.0))
                >= _VIEW3D_N_PANEL_APPLY_INTERVAL
            )
        ):
            before_error = (
                abs(float(current_snapshot[2]) - float(desired_scroll))
                if current_snapshot[2] is not None
                else None
            )
            state["last_pan_attempt"] = now
            screen_pointer = int(screen.as_pointer())
            window = _view3d_n_panel_pick_window(
                context,
                screen_pointer,
                windows_by_screen,
            )
            if (
                window is not None
                and _view3d_n_panel_pan_to(
                    context,
                    window,
                    screen,
                    area,
                    space,
                    region,
                    desired_scroll,
                )
            ):
                redraw = True
                wrote = True
                current_snapshot = _view3d_n_panel_snapshot(space, region)
                after_error = (
                    abs(
                        float(current_snapshot[2])
                        - float(desired_scroll)
                    )
                    if current_snapshot[2] is not None
                    else None
                )
                prior_error = state.get("last_pan_error")
                if (
                    after_error is None
                    or (
                        prior_error is not None
                        and after_error
                        >= float(prior_error)
                        - _VIEW3D_N_PANEL_SCROLL_EPSILON
                    )
                    or (
                        before_error is not None
                        and after_error
                        >= before_error
                        - _VIEW3D_N_PANEL_SCROLL_EPSILON
                    )
                ):
                    state["pan_stalls"] = (
                        int(state.get("pan_stalls", 0)) + 1
                    )
                else:
                    state["pan_stalls"] = 0
                state["last_pan_error"] = after_error
            scroll_matches = _view3d_n_panel_scrolls_match(
                current_snapshot[2],
                desired_scroll,
            )

        # A narrower target can clamp its View2D range.  After three attempts
        # accept that target's closest stable value for this revision.  Its
        # observed baseline prevents the clamped value from feeding back into
        # the master unless the user actually scrolls it afterward.
        scroll_accepted = bool(
            scroll_matches or int(state.get("pan_stalls", 0)) >= 3
        )
        complete = bool(
            bool(current_snapshot[0]) == desired_visible
            and (
                not desired_visible
                or (
                    category_matches
                    and not scroll_pending
                    and scroll_accepted
                )
            )
        )
        if complete and active:
            if not float(state.get("settle_since", 0.0)):
                state["settle_since"] = now
            elif (
                now - float(state["settle_since"])
                >= _VIEW3D_N_PANEL_TARGET_SETTLE
            ):
                state["pending_revision"] = 0
                state["settle_since"] = 0.0
                state["activation_fast_until"] = 0.0
                state["block_until"] = (
                    now + _VIEW3D_N_PANEL_SOURCE_GUARD
                )
        elif complete and not active and not desired_visible:
            state["pending_revision"] = 0
            state["settle_since"] = 0.0
            state["activation_fast_until"] = 0.0
        else:
            state["settle_since"] = 0.0

        if redraw:
            try:
                area.tag_redraw()
            except (AttributeError, ReferenceError):
                pass
        state["observed"] = _view3d_n_panel_snapshot(space, region)
        if wrote:
            state["block_until"] = max(
                float(state.get("block_until", 0.0)),
                now + _VIEW3D_N_PANEL_SOURCE_GUARD,
            )

    for pointer in tuple(states):
        if pointer not in live_pointers:
            states.pop(pointer, None)
