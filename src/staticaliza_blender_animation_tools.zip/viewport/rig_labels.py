"""Rig-label geometry, placement, hover, and drawing helpers."""

from ..core.runtime import *  # noqa: F403
from .bone_labels import _camera_label_opacity

_RIG_LABEL_OBJECT_TYPES = frozenset({
    "MESH",
    "CURVE",
    "SURFACE",
    "META",
    "FONT",
})


def _object_screen_bounds(context, obj, depsgraph = None):
    if (
        obj is None
        or getattr(obj, "type", "") not in _RIG_LABEL_OBJECT_TYPES
        or not _is_object_visible(obj, context)
    ):
        return None
    try:
        depsgraph = depsgraph or context.evaluated_depsgraph_get()
        evaluated_object = obj.evaluated_get(depsgraph)
        matrix_world = evaluated_object.matrix_world
        corners = tuple(
            matrix_world @ Vector(corner)
            for corner in evaluated_object.bound_box
        )
    except (
        AttributeError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ):
        return None

    projected = []
    for first_index, second_index in (
        (0, 1), (1, 2), (2, 3), (3, 0),
        (4, 5), (5, 6), (6, 7), (7, 4),
        (0, 4), (1, 5), (2, 6), (3, 7),
    ):
        line, first, second = _project_world_segment_2d(
            context,
            corners[first_index],
            corners[second_index],
        )
        if line is not None:
            projected.extend(line)
        if first is not None:
            projected.append(first)
        if second is not None:
            projected.append(second)
    if not projected:
        return None
    return (
        min(point[0] for point in projected),
        min(point[1] for point in projected),
        max(point[0] for point in projected),
        max(point[1] for point in projected),
    )


def _rig_label_objects(context, armature):
    try:
        objects, _owner = _targets(context, armature)
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        return ()
    return tuple(
        obj
        for obj in objects
        if obj != armature
        and getattr(obj, "type", "") in _RIG_LABEL_OBJECT_TYPES
        and _is_object_visible(obj, context)
    )


def _rig_root_part_object(armature, objects):
    if armature is None or not objects:
        return None

    named_root_bones = []
    fallback_root_bones = []
    pose = getattr(armature, "pose", None)
    for pose_bone in getattr(pose, "bones", ()) if pose is not None else ():
        compact = "".join(
            character
            for character in _strip_blender_numeric_suffix(
                pose_bone.name
            ).casefold()
            if character.isalnum()
        )
        if compact == "humanoidrootpart":
            named_root_bones.insert(0, pose_bone.name)
        elif compact in {"rootpart", "root"}:
            named_root_bones.append(pose_bone.name)
        elif _pose_bone_is_label_root(pose_bone):
            fallback_root_bones.append(pose_bone.name)
    root_bone_names = named_root_bones or fallback_root_bones
    root_bone_names = tuple(dict.fromkeys(root_bone_names))
    root_names_casefold = {name.casefold() for name in root_bone_names}

    def score(obj):
        canonical_name = _strip_blender_numeric_suffix(obj.name)
        compact_name = "".join(
            character
            for character in canonical_name.casefold()
            if character.isalnum()
        )
        if compact_name == "humanoidrootpart":
            return (0, canonical_name.casefold())
        if compact_name == "rootpart":
            return (1, canonical_name.casefold())
        if compact_name == "root":
            return (2, canonical_name.casefold())

        parent_bone = str(getattr(obj, "parent_bone", "") or "")
        if (
            getattr(obj, "parent", None) == armature
            and parent_bone.casefold() in root_names_casefold
        ):
            return (3, canonical_name.casefold())
        for constraint in getattr(obj, "constraints", ()):
            try:
                if (
                    getattr(constraint, "target", None) == armature
                    and str(getattr(constraint, "subtarget", "") or "").casefold()
                    in root_names_casefold
                ):
                    return (4, canonical_name.casefold())
            except (AttributeError, ReferenceError):
                continue
        return (10, canonical_name.casefold())

    ordered = sorted(objects, key = score)
    return ordered[0] if ordered and score(ordered[0])[0] < 10 else None



def _object_world_bounds(obj, depsgraph):
    try:
        evaluated_object = obj.evaluated_get(depsgraph)
        corners = tuple(
            evaluated_object.matrix_world @ Vector(corner)
            for corner in evaluated_object.bound_box
        )
    except (
        AttributeError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ):
        return None
    if not corners:
        return None
    return (
        min(float(point.x) for point in corners),
        min(float(point.y) for point in corners),
        min(float(point.z) for point in corners),
        max(float(point.x) for point in corners),
        max(float(point.y) for point in corners),
        max(float(point.z) for point in corners),
    )


def _rig_label_world_anchor(context, armature, objects):
    """Place the title above the root column in global coordinates."""
    try:
        depsgraph = context.evaluated_depsgraph_get()
    except (AttributeError, ReferenceError, RuntimeError):
        return None

    world_bounds = tuple(
        (obj, bounds)
        for obj in objects
        if (bounds := _object_world_bounds(obj, depsgraph)) is not None
    )
    root_object = _rig_root_part_object(armature, objects)
    root_bounds = next(
        (bounds for obj, bounds in world_bounds if obj == root_object),
        None,
    )

    if root_bounds is not None:
        center_x = (root_bounds[0] + root_bounds[3]) * 0.5
        center_y = (root_bounds[1] + root_bounds[4]) * 0.5
        footprint = (
            root_bounds[0],
            root_bounds[1],
            root_bounds[3],
            root_bounds[4],
        )
        column_top = root_bounds[5]
    else:
        pose = getattr(armature, "pose", None)
        candidates = []
        for pose_bone in getattr(pose, "bones", ()) if pose is not None else ():
            compact = "".join(
                character
                for character in _strip_blender_numeric_suffix(
                    pose_bone.name
                ).casefold()
                if character.isalnum()
            )
            score = (
                0 if compact == "humanoidrootpart" else
                1 if compact == "rootpart" else
                2 if compact == "root" else
                3 if _pose_bone_is_label_root(pose_bone) else
                10
            )
            candidates.append((score, pose_bone.name.casefold(), pose_bone))
        candidates.sort(key = lambda item: item[:2])
        if not candidates or candidates[0][0] >= 10:
            return None
        try:
            evaluated_armature = armature.evaluated_get(depsgraph)
            evaluated_bone = evaluated_armature.pose.bones.get(
                candidates[0][2].name
            )
            if evaluated_bone is None:
                return None
            root_world = evaluated_armature.matrix_world @ (
                (evaluated_bone.head + evaluated_bone.tail) * 0.5
            )
        except (
            AttributeError,
            ReferenceError,
            RuntimeError,
            TypeError,
            ValueError,
        ):
            return None
        center_x = float(root_world.x)
        center_y = float(root_world.y)
        containing = tuple(
            bounds
            for _obj, bounds in world_bounds
            if bounds[0] <= center_x <= bounds[3]
            and bounds[1] <= center_y <= bounds[4]
        )
        if containing:
            footprint = (
                max(bounds[0] for bounds in containing),
                max(bounds[1] for bounds in containing),
                min(bounds[3] for bounds in containing),
                min(bounds[4] for bounds in containing),
            )
            column_top = max(bounds[5] for bounds in containing)
        else:
            footprint = (center_x, center_y, center_x, center_y)
            column_top = float(root_world.z)

    # Only geometry crossing the root's global vertical column can raise the
    # title. Detached limbs therefore cannot move it as the viewport turns.
    column_bounds = []
    for _obj, bounds in world_bounds:
        if (
            bounds[0] <= footprint[2]
            and bounds[3] >= footprint[0]
            and bounds[1] <= footprint[3]
            and bounds[4] >= footprint[1]
        ):
            column_bounds.append(bounds)
            column_top = max(column_top, bounds[5])

    if column_bounds:
        column_bottom = min(bounds[2] for bounds in column_bounds)
        padding = max(0.05, (column_top - column_bottom) * 0.035)
    else:
        padding = 0.1
    return Vector((center_x, center_y, column_top + padding))


def _rig_screen_object_bounds(context, armature):
    try:
        depsgraph = context.evaluated_depsgraph_get()
    except (AttributeError, ReferenceError, RuntimeError):
        return (), ()
    objects = _rig_label_objects(context, armature)
    object_bounds = tuple(
        (obj, bounds)
        for obj in objects
        if (bounds := _object_screen_bounds(context, obj, depsgraph)) is not None
    )
    return objects, object_bounds


def _rig_screen_bounds(context, armature, object_bounds = None):
    region = getattr(context, "region", None)
    region_data = getattr(context, "region_data", None)
    if region is None or region_data is None or armature is None:
        return None

    try:
        depsgraph = context.evaluated_depsgraph_get()
    except (AttributeError, ReferenceError, RuntimeError):
        return None
    if object_bounds is None:
        _objects, object_bounds = _rig_screen_object_bounds(context, armature)
    projected = [
        point
        for _obj, bounds in object_bounds
        for point in (
            (bounds[0], bounds[1]),
            (bounds[2], bounds[3]),
        )
    ]

    if not projected:
        try:
            evaluated_armature = armature.evaluated_get(depsgraph)
            for pose_bone in evaluated_armature.pose.bones:
                line, first, second = _project_world_segment_2d(
                    context,
                    evaluated_armature.matrix_world @ pose_bone.head,
                    evaluated_armature.matrix_world @ pose_bone.tail,
                )
                if line is not None:
                    projected.extend(line)
                if first is not None:
                    projected.append(first)
                if second is not None:
                    projected.append(second)
        except (
            AttributeError,
            ReferenceError,
            RuntimeError,
            TypeError,
            ValueError,
        ):
            return None
    if not projected:
        return None
    return (
        min(point[0] for point in projected),
        min(point[1] for point in projected),
        max(point[0] for point in projected),
        max(point[1] for point in projected),
    )


def _rig_hover_region_point(context):
    window = getattr(context, "window", None)
    region = getattr(context, "region", None)
    if window is None or region is None:
        return None
    mouse = _state.get("rig_hover_mouse", {}).get(int(window.as_pointer()))
    if mouse is None:
        return None
    point = (
        float(mouse[0]) - float(region.x),
        float(mouse[1]) - float(region.y),
    )
    if not (0.0 <= point[0] <= region.width and 0.0 <= point[1] <= region.height):
        return None
    return point


def _desktop_cursor_position():
    """Read the OS cursor without adding a Blender mouse-event handler."""
    if os.name != "nt":
        return None
    try:
        import ctypes

        class POINT(ctypes.Structure):
            _fields_ = (("x", ctypes.c_long), ("y", ctypes.c_long))

        point = POINT()
        if not ctypes.windll.user32.GetCursorPos(ctypes.byref(point)):
            return None
        return int(point.x), int(point.y)
    except (AttributeError, ImportError, OSError, TypeError, ValueError):
        return None


def _rig_hover_object_owners(context):
    owners = {}
    active_uids = {
        _armature_session_uid(armature)
        for armature in _pose_scope_armatures(context)
    }
    for armature in _pose_panel_armatures(context):
        uid = _armature_session_uid(armature)
        # Active rigs already show their title and own the native transform
        # gizmos. Never ray-cast them for the inactive-rig hover feature.
        if uid in active_uids:
            continue
        try:
            objects, _owner = _targets(context, armature)
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            objects = ()
        for obj in objects:
            try:
                owners[str(obj.name_full)] = uid
            except (AttributeError, ReferenceError):
                pass
    return owners


def _poll_rig_hover_targets(context):
    """Ray-cast rig hover at 12 Hz without entering Blender's event path."""
    previous = dict(_state.get("rig_hover_targets", {}))
    available = bool(
        getattr(context, "mode", "") == "POSE"
        and _state.get("rig_hover_available", False)
    )
    now = time.perf_counter()
    if available and (
        now - float(_state.get("rig_hover_poll_time", 0.0)) < (1.0 / 12.0)
    ):
        return False
    _state["rig_hover_poll_time"] = now

    cursor = _desktop_cursor_position() if available else None
    previous_cursor = _state.get("rig_hover_cursor_position")
    if cursor != previous_cursor:
        _state["rig_hover_cursor_position"] = cursor
        _state["rig_hover_cursor_changed_at"] = now
        # Wait until the pointer settles before ray-casting. This keeps hover
        # discovery off the native gizmo's approach/press event sequence.
        return False
    if cursor is not None and (
        now - float(_state.get("rig_hover_cursor_changed_at", 0.0)) < 0.15
    ):
        return False
    window_manager = getattr(context, "window_manager", None)
    owners = _rig_hover_object_owners(context) if cursor is not None else {}
    current = {}
    areas_by_key = {}
    for window in getattr(window_manager, "windows", ()) if window_manager else ():
        try:
            if _workspace_is_presentation(window.workspace):
                continue
            mouse_x = float(cursor[0]) - float(window.x)
            mouse_y = float(window.height) - (
                float(cursor[1]) - float(window.y)
            )
            if not (
                0.0 <= mouse_x < float(window.width)
                and 0.0 <= mouse_y < float(window.height)
            ):
                continue
        except (AttributeError, ReferenceError, TypeError, ValueError):
            continue
        for area in tuple(getattr(window.screen, "areas", ())):
            if area.type != "VIEW_3D":
                continue
            area_key = int(area.as_pointer())
            areas_by_key[area_key] = area
            region = next(
                (
                    candidate
                    for candidate in area.regions
                    if candidate.type == "WINDOW"
                ),
                None,
            )
            if region is None or not (
                float(region.x) <= mouse_x < float(region.x + region.width)
                and float(region.y) <= mouse_y < float(region.y + region.height)
            ):
                continue
            region_data = getattr(area.spaces.active, "region_3d", None)
            if region_data is None:
                continue
            region_point = Vector(
                (mouse_x - float(region.x), mouse_y - float(region.y))
            )
            try:
                from bpy_extras import view3d_utils

                with context.temp_override(
                    window = window,
                    area = area,
                    region = region,
                ):
                    depsgraph = bpy.context.evaluated_depsgraph_get()
                    origin = view3d_utils.region_2d_to_origin_3d(
                        region,
                        region_data,
                        region_point,
                    )
                    direction = view3d_utils.region_2d_to_vector_3d(
                        region,
                        region_data,
                        region_point,
                    )
                    hit = window.scene.ray_cast(
                        depsgraph,
                        origin,
                        direction,
                        distance = 1000000.0,
                    )
                hit_object = hit[4] if hit and hit[0] else None
                original = getattr(hit_object, "original", hit_object)
                uid = owners.get(str(getattr(original, "name_full", "")), 0)
                if uid:
                    current[area_key] = uid
            except (
                AttributeError,
                ReferenceError,
                RuntimeError,
                TypeError,
                ValueError,
            ):
                pass

    _state["rig_hover_targets"] = current
    changed_keys = {
        key for key in set(previous) | set(current)
        if previous.get(key) != current.get(key)
    }
    if not changed_keys:
        return False
    for window in getattr(window_manager, "windows", ()) if window_manager else ():
        for area in tuple(getattr(window.screen, "areas", ())):
            try:
                if int(area.as_pointer()) in changed_keys:
                    area.tag_redraw()
            except (AttributeError, ReferenceError, RuntimeError):
                pass
    return True


def _rig_hover_target_uid(context):
    area = getattr(context, "area", None)
    if area is None:
        return 0
    try:
        return int(
            _state.get("rig_hover_targets", {}).get(int(area.as_pointer()), 0)
        )
    except (AttributeError, ReferenceError, TypeError, ValueError):
        return 0


def _rig_label_screen_position(
    context,
    armature,
    rig_bounds,
    label,
    font_size,
    objects = None,
    object_bounds = None,
):
    if objects is None or object_bounds is None:
        objects, object_bounds = _rig_screen_object_bounds(context, armature)
    world_anchor = _rig_label_world_anchor(context, armature, objects)
    if world_anchor is not None:
        try:
            from bpy_extras import view3d_utils

            position = view3d_utils.location_3d_to_region_2d(
                context.region,
                context.region_data,
                world_anchor,
            )
        except (
            AttributeError,
            ReferenceError,
            RuntimeError,
            TypeError,
            ValueError,
        ):
            position = None
        if position is not None:
            return (
                float(position.x),
                float(position.y) + 14.0,
                0.0,
            )

    # Compatibility fallback for unusual hand-built armatures without a
    # recognizable root. It is used only when no global root anchor exists.
    if rig_bounds is None:
        return None
    return (
        (float(rig_bounds[0]) + float(rig_bounds[2])) * 0.5,
        float(rig_bounds[3]) + 14.0,
        0.0,
    )


def _draw_rig_labels(context, selected_armature, opacity_override = None):
    if _context_is_presentation_view(context):
        return
    pose_mode = getattr(context, "mode", "") == "POSE"
    scope = _pose_scope_armatures(context)
    scope_uids = {_armature_session_uid(armature) for armature in scope}
    hover_uid = _rig_hover_target_uid(context)
    try:
        base_size = float(context.preferences.ui_styles[0].widget.points) + 4.0
    except (AttributeError, IndexError, TypeError, ValueError):
        base_size = 13.0

    font_id = 0
    if not pose_mode:
        active_armature = _active_armature(context)
        try:
            selected_armature = (
                active_armature
                if active_armature is not None and active_armature.select_get()
                else None
            )
        except (AttributeError, ReferenceError, RuntimeError):
            selected_armature = None
    selected_uid = _armature_session_uid(selected_armature)
    for armature in _pose_panel_armatures(context):
        uid = _armature_session_uid(armature)
        enabled = (
            uid in scope_uids
            if pose_mode
            else _is_object_visible(armature, context)
        )
        # Hover tracking is intentionally not connected to a mouse keymap.
        # Skip inactive rigs before any geometry work in the normal path.
        if not enabled and uid != hover_uid:
            continue

        objects = _rig_label_objects(context, armature)
        object_bounds = ()
        bounds = None
        hovered = bool(uid == hover_uid)
        if not enabled and not hovered:
            continue
        # Match the selected-bone title exactly: widget points + 7 (16 px
        # with Blender's fallback UI font metrics).
        font_size = base_size + (3.0 if enabled and uid == selected_uid else 0.0)
        label = _rig_display_name(armature.name)
        center_x, text_y, text_rotation = _rig_label_screen_position(
            context,
            armature,
            bounds,
            label,
            font_size,
            objects = objects,
            object_bounds = object_bounds,
        ) or (None, None, None)
        if center_x is None:
            objects, object_bounds = _rig_screen_object_bounds(
                context,
                armature,
            )
            bounds = _rig_screen_bounds(
                context,
                armature,
                object_bounds = object_bounds,
            )
            if bounds is None:
                continue
            center_x, text_y, text_rotation = _rig_label_screen_position(
                context,
                armature,
                bounds,
                label,
                font_size,
                objects = objects,
                object_bounds = object_bounds,
            )
        _draw_outlined_bone_text(
            font_id,
            label,
            center_x,
            text_y,
            font_size,
            (1.0, 0.72, 0.03, 1.0 if enabled else 0.82),
            rotation = text_rotation,
            opacity = (
                _camera_label_opacity(
                    context,
                    Vector((float(center_x), float(text_y))),
                )
                if opacity_override is None
                else float(opacity_override)
            ),
        )
