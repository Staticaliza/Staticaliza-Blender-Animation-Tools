"""Shared viewport drawing, rig-scope, and pin-state context helpers."""

from ..core.runtime import *  # noqa: F403

def _tag_redraw_all_view3d():
    wm = bpy.context.window_manager
    for window in wm.windows:
        for area in window.screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


def _window_manager_has_modal_operator(context):
    """Return whether Blender currently owns an interactive modal action."""
    window_manager = getattr(context, "window_manager", None)
    for window in tuple(getattr(window_manager, "windows", ())):
        try:
            if tuple(window.modal_operators):
                return True
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            continue
    return False

def _ensure_shader_3d():
    if _state["shader_3d"] is not None:
        return _state["shader_3d"]

    _state["last_error"] = ""
    try:
        _state["shader_3d"] = gpu.shader.from_builtin("UNIFORM_COLOR")
        _state["shader_3d_mode"] = "UNIFORM"
    except Exception:
        _state["shader_3d"] = gpu.shader.from_builtin("FLAT_COLOR")
        _state["shader_3d_mode"] = "VERTEX"

    return _state["shader_3d"]

def _ensure_shader_2d():
    if _state["shader_2d"] is not None:
        return _state["shader_2d"]

    vertex_body = """
    void main()
    {
        vec2 ndc = (pos / u_viewport) * 2.0 - 1.0;
        gl_Position = vec4(ndc.xy, 0.0, 1.0);
    }
    """
    fragment_body = """
    void main()
    {
        FragColor = color;
    }
    """
    try:
        shader_info = gpu.types.GPUShaderCreateInfo()
        shader_info.vertex_in(0, "VEC2", "pos")
        shader_info.push_constant("VEC2", "u_viewport")
        shader_info.push_constant("VEC4", "color")
        shader_info.fragment_out(0, "VEC4", "FragColor")
        shader_info.vertex_source(vertex_body)
        shader_info.fragment_source(fragment_body)
        _state["shader_2d"] = gpu.shader.create_from_info(shader_info)
    except Exception:
        legacy_vertex_source = "in vec2 pos;\nuniform vec2 u_viewport;\n" + vertex_body
        legacy_fragment_source = (
            "uniform vec4 color;\nout vec4 FragColor;\n" + fragment_body
        )
        _state["shader_2d"] = gpu.types.GPUShader(
            legacy_vertex_source,
            legacy_fragment_source,
        )
    return _state["shader_2d"]

def _as_p4(v):
    try:
        if isinstance(v, Vector):
            if len(v) == 4:
                return Vector((float(v.x), float(v.y), float(v.z), float(v.w)))
            if len(v) == 3:
                return Vector((float(v.x), float(v.y), float(v.z), 1.0))
    except Exception:
        pass

    if isinstance(v, (list, tuple)) and len(v) >= 3:
        try:
            return Vector((float(v[0]), float(v[1]), float(v[2]), 1.0))
        except Exception:
            pass

    return Vector((0.0, 0.0, 0.0, 1.0))

def _world_to_bone_local_p4(eval_arm, pb, world_point):
    arm_mw = eval_arm.matrix_world
    try:
        arm_inv = arm_mw.inverted()
    except Exception:
        arm_inv = Matrix.Identity(4)

    try:
        pb_inv = pb.matrix.inverted()
    except Exception:
        pb_inv = Matrix.Identity(4)

    return pb_inv @ (arm_inv @ _as_p4(world_point))

def _bone_local_to_world(eval_arm, pb, local_p4):
    arm_mw = eval_arm.matrix_world
    try:
        out = arm_mw @ (pb.matrix @ _as_p4(local_p4))
    except Exception:
        out = arm_mw @ _as_p4((0.0, 0.0, 0.0))
    return Vector((float(out.x), float(out.y), float(out.z)))

def _is_object_visible(obj, context):
    wm = getattr(context, "window_manager", None)
    scn = getattr(context, "scene", None)
    if wm and not getattr(wm, "onion_skin_skip_hidden", True):
        return True
    if not scn:
        return True
    if obj.hide_viewport:
        return False
    if obj.hide_get():
        return False
    try:
        if hasattr(obj, "visible_get"):
            return obj.visible_get(view_layer=context.view_layer)
    except TypeError:
        try:
            return obj.visible_get()
        except Exception:
            return True
    return True

def _active_armature(context):
    active_pose_bone = getattr(context, "active_pose_bone", None)
    if getattr(context, "mode", "") == "POSE" and active_pose_bone is not None:
        try:
            active_pointer = int(active_pose_bone.as_pointer())
        except (AttributeError, ReferenceError, TypeError, ValueError):
            active_pointer = 0
        try:
            pose_armatures = tuple(context.objects_in_mode or ())
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            pose_armatures = ()
        for armature in pose_armatures:
            if getattr(armature, "type", "") != "ARMATURE":
                continue
            candidate = getattr(getattr(armature, "pose", None), "bones", {}).get(
                str(active_pose_bone.name)
            )
            if candidate is None:
                continue
            try:
                if candidate == active_pose_bone or (
                    active_pointer and int(candidate.as_pointer()) == active_pointer
                ):
                    return armature
            except (AttributeError, ReferenceError, TypeError, ValueError):
                continue
    ob = context.active_object
    if ob and ob.type == "ARMATURE":
        return ob
    for ob in context.selected_objects:
        if ob.type == "ARMATURE":
            return ob
    ob = context.active_object
    if ob and hasattr(ob, "find_armature"):
        arm = ob.find_armature()
        if arm and arm.type == "ARMATURE":
            return arm
    return None


def _armature_session_uid(armature):
    if armature is None:
        return 0
    try:
        uid = int(armature.session_uid)
    except (AttributeError, ReferenceError, TypeError, ValueError):
        uid = 0
    if uid:
        return uid
    try:
        return int(armature.as_pointer())
    except (AttributeError, ReferenceError, TypeError, ValueError):
        return 0


def _armature_from_session_uid(session_uid):
    session_uid = int(session_uid or 0)
    if not session_uid:
        return None
    for obj in bpy.data.objects:
        if obj.type == "ARMATURE" and _armature_session_uid(obj) == session_uid:
            return obj
    return None


def _pose_scope_armatures(context):
    if context is None or getattr(context, "mode", "") != "POSE":
        return ()
    candidates = []
    try:
        candidates.extend(tuple(context.objects_in_mode or ()))
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        pass
    if not candidates:
        try:
            candidates.extend(tuple(context.selected_objects or ()))
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            pass
    active = _active_armature(context)
    if active is not None:
        candidates.insert(0, active)
    result = []
    seen = set()
    for armature in candidates:
        if (
            armature is None
            or getattr(armature, "type", "") != "ARMATURE"
            or getattr(armature, "mode", "") != "POSE"
        ):
            continue
        uid = _armature_session_uid(armature)
        if not uid or uid in seen:
            continue
        seen.add(uid)
        result.append(armature)
    return tuple(result)


def _pose_bone_owner(context, pose_bone, armatures = None):
    if pose_bone is None:
        return None
    candidates = tuple(armatures or _pose_scope_armatures(context))
    if not candidates:
        active = _active_armature(context) if context is not None else None
        candidates = (active,) if active is not None else ()
    candidate_uids = {
        _armature_session_uid(armature)
        for armature in candidates
        if armature is not None
    }
    candidates = tuple(candidates) + tuple(
            obj
            for obj in bpy.data.objects
            if (
                obj.type == "ARMATURE"
                and getattr(obj, "pose", None)
                and _armature_session_uid(obj) not in candidate_uids
            )
        )
    pointer = 0
    try:
        pointer = int(pose_bone.as_pointer())
    except (AttributeError, ReferenceError, TypeError, ValueError):
        pass
    for armature in candidates:
        if armature is None or getattr(armature, "pose", None) is None:
            continue
        candidate = armature.pose.bones.get(str(pose_bone.name))
        if candidate is None:
            continue
        try:
            if candidate == pose_bone or (pointer and candidate.as_pointer() == pointer):
                return armature
        except (AttributeError, ReferenceError, TypeError, ValueError):
            continue
    return None


def _owner_bone_key(armature, bone_name):
    return (_armature_session_uid(armature), str(bone_name))


def _yellow_owner_map(state_name, armature):
    uid = _armature_session_uid(armature)
    return {
        bone_name: value
        for (owner_uid, bone_name), value in _state.get(state_name, {}).items()
        if int(owner_uid) == uid
    }


def _yellow_replace_owner_map(state_name, armature, values):
    uid = _armature_session_uid(armature)
    combined = {
        key: value
        for key, value in _state.get(state_name, {}).items()
        if int(key[0]) != uid
    }
    combined.update(
        (((uid, str(name)), value) for name, value in values.items())
    )
    _state[state_name] = combined


def _yellow_owner_hidden(armature):
    return _armature_session_uid(armature) in _state.get("yellow_hidden", set())


def _yellow_set_owner_hidden(armature, hidden):
    owners = set(_state.get("yellow_hidden", set()))
    uid = _armature_session_uid(armature)
    if hidden:
        owners.add(uid)
    else:
        owners.discard(uid)
    _state["yellow_hidden"] = owners
    try:
        armature[YELLOW_PIN_HIDDEN_PROPERTY] = bool(hidden)
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        pass


def _onion_owner_enabled(armature):
    return _armature_session_uid(armature) in _state.get(
        "onion_enabled_owners",
        set(),
    )


def _set_onion_property(window_manager, enabled):
    if window_manager is None or not hasattr(window_manager, "onion_skin_enabled"):
        return
    enabled = bool(enabled)
    if bool(window_manager.onion_skin_enabled) == enabled:
        return
    _state["onion_property_syncing"] = True
    try:
        window_manager.onion_skin_enabled = enabled
    finally:
        _state["onion_property_syncing"] = False


def _targets(context, armature = None):
    arm = armature or _active_armature(context)
    items = []

    if arm and _is_object_visible(arm, context):
        items.append(arm)

    if not arm:
        return items, None

    for obj in context.view_layer.objects:
        if obj == arm:
            continue
        if not _is_object_visible(obj, context):
            continue

        include = False

        if obj.parent == arm:
            include = True
        if obj.parent_type == "BONE" and obj.parent == arm:
            include = True

        if not include:
            for m in obj.modifiers:
                if m.type == "ARMATURE" and getattr(m, "object", None) == arm:
                    include = True
                    break

        if not include:
            for c in obj.constraints:
                t = getattr(c, "target", None)
                st = getattr(c, "subtarget", "")
                if t == arm and st:
                    include = True
                    break
                if c.type == "CHILD_OF" and t == arm:
                    include = True
                    break
                if c.type == "COPY_TRANSFORMS" and t == arm:
                    include = True
                    break
                if c.type == "COPY_LOCATION" and t == arm:
                    include = True
                    break
                if c.type == "COPY_ROTATION" and t == arm:
                    include = True
                    break
                if c.type == "COPY_SCALE" and t == arm:
                    include = True
                    break

        if include:
            items.append(obj)

    return list(dict.fromkeys(items)), arm

def _is_unmovable(pb):
    locked_loc = all(pb.lock_location)
    locked_scale = all(pb.lock_scale)
    locked_rot = all(pb.lock_rotation)
    if hasattr(pb, "lock_rotation_w"):
        locked_rot = locked_rot and bool(pb.lock_rotation_w)
    return locked_loc and locked_rot and locked_scale
