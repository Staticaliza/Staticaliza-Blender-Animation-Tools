"""Bone-label selection, status, and drawing helpers."""

from ..core.runtime import *  # noqa: F403

def _selected_bone_label_target(context):
    window_manager = getattr(context, "window_manager", None)
    if (
        window_manager is None
        or not getattr(window_manager, "show_bone_names_enabled", True)
        or getattr(context, "mode", "") != "POSE"
    ):
        return None, None

    armatures = _pose_scope_armatures(context)
    if not armatures:
        return None, None

    selected_by_owner = _selected_pose_bones_by_owner(context)
    active_bone = getattr(context, "active_pose_bone", None)
    active_armature = _pose_bone_owner(context, active_bone, armatures)
    if (
        active_armature is not None
        and active_bone in selected_by_owner.get(active_armature, ())
    ):
        return active_armature, active_bone

    selected = tuple(
        (armature, pose_bone)
        for armature, pose_bones in selected_by_owner.items()
        for pose_bone in pose_bones
    )
    return selected[0] if len(selected) == 1 else (None, None)


def _pose_bone_is_visible(pose_bone):
    bone = getattr(pose_bone, "bone", None)
    if bone is None or bool(getattr(bone, "hide", False)):
        return False

    collections = getattr(bone, "collections", ())
    if collections:
        visible_collections = (
            collection for collection in collections
            if bool(getattr(collection, "is_visible", True))
        )
        if not any(visible_collections):
            return False
    return True


def _pose_bone_is_label_root(pose_bone):
    return bool(
        pose_bone.parent is None
        and not str(pose_bone.bone.get(REL_K_PARENT, ""))
    )


def _bone_label_is_selected(context, armature, pose_bone):
    """Treat a pin-linked bone as selected for label presentation only."""
    target_key = _owner_bone_key(armature, pose_bone.name)
    if target_key in _selected_owner_bone_keys(context):
        return True
    return any(
        target_key
        == _owner_bone_key(target_data[1], target_data[2].name)
        for _pin_key, target_data in _pin_selected_targets_data(context)
    )


def _custom_bone_label_targets(context):
    window_manager = getattr(context, "window_manager", None)
    if (
        window_manager is None
        or not getattr(window_manager, "show_bone_names_enabled", True)
        or getattr(context, "mode", "") != "POSE"
    ):
        return None, ()
    selected_armature, _selected_bone = _selected_bone_label_target(context)
    selected_by_owner = _selected_pose_bones_by_owner(context)
    selected_targets = tuple(
        (armature, pose_bone)
        for armature, pose_bones in selected_by_owner.items()
        for pose_bone in pose_bones
        if _pose_bone_is_visible(pose_bone)
    )
    try:
        pin_targets = _pin_selected_targets_data(context)
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        pin_targets = ()
    if pin_targets:
        _active_key, active_target = pin_targets[0]
        _kind, linked_armature, _linked_bone, _payload = active_target
        combined_targets = []
        seen = set()
        pin_linked_targets = tuple(
            (target_data[1], target_data[2])
            for _target_key, target_data in pin_targets
        )
        for armature, pose_bone in pin_linked_targets + selected_targets:
            key = _owner_bone_key(armature, pose_bone.name)
            if key in seen or not _pose_bone_is_visible(pose_bone):
                continue
            seen.add(key)
            combined_targets.append((armature, pose_bone))
        return linked_armature, tuple(combined_targets)
    if selected_targets:
        if selected_armature is None:
            selected_armature = selected_targets[0][0]
        return selected_armature, selected_targets
    return selected_armature, tuple(
        (armature, pose_bone)
        for armature in _pose_scope_armatures(context)
        for pose_bone in armature.pose.bones
        if _pose_bone_is_visible(pose_bone)
        and not _pose_bone_is_label_root(pose_bone)
    )


def _dynamic_parent_visible_relationships(context):
    if getattr(context, "mode", "") != "POSE":
        return ()

    selected_by_owner = {
        _armature_session_uid(armature): {
            pose_bone.name for pose_bone in pose_bones
        }
        for armature, pose_bones in _selected_pose_bones_by_owner(
            context
        ).items()
    }
    if not selected_by_owner:
        return ()

    frame = int(context.scene.frame_current)
    relationships = []
    seen = set()
    for child_armature in tuple(bpy.data.objects):
        if (
            child_armature.type != "ARMATURE"
            or getattr(child_armature, "pose", None) is None
        ):
            continue
        for child_bone in child_armature.pose.bones:
            constraint = _active_dynamic_parent_constraint(
                child_bone,
                frame,
                _chosen_dynamic_parent_constraint(child_bone, frame),
            )
            if constraint is None:
                continue
            target = _dynamic_parent_constraint_target(
                child_bone,
                constraint,
            )
            if target is None:
                continue
            subtarget = _dynamic_parent_constraint_subtarget(
                child_bone,
                constraint,
            )
            child_selected = bool(
                child_bone.name
                in selected_by_owner.get(
                    _armature_session_uid(child_armature),
                    set(),
                )
            )
            target_selected = bool(
                subtarget
                in selected_by_owner.get(
                    _armature_session_uid(target),
                    set(),
                )
            )
            if not (child_selected or target_selected):
                continue
            key = (
                int(child_armature.as_pointer()),
                child_bone.name,
                int(target.as_pointer()),
                subtarget,
            )
            if key in seen:
                continue
            seen.add(key)
            relationships.append(
                (child_armature, child_bone.name, target, subtarget)
            )
    return tuple(
        sorted(
            relationships,
            key = lambda relationship: (
                relationship[0].name.casefold(),
                relationship[1].casefold(),
                relationship[2].name.casefold(),
                relationship[3].casefold(),
            ),
        )
    )


def _dynamic_parent_bone_pivot_world(
    context,
    armature,
    bone_name,
    draw_cache,
):
    pivot_mode = str(
        getattr(context.window_manager, "staticaliza_pivot_mode", "BONE")
    )
    key = (int(armature.as_pointer()), str(bone_name), pivot_mode)
    if key in draw_cache["points"]:
        return draw_cache["points"][key]

    depsgraph = draw_cache["depsgraph"]
    try:
        evaluated_armature = armature.evaluated_get(depsgraph)
        evaluated_bone = evaluated_armature.pose.bones.get(str(bone_name))
        if evaluated_bone is None:
            return None

        world_point = None
        if pivot_mode == "PART":
            part = _part_pivot_connected_object(
                context,
                armature,
                evaluated_armature,
                draw_cache["objects"],
                evaluated_bone,
            )
            if part is not None:
                evaluated_part = part.evaluated_get(depsgraph)
                corners = tuple(Vector(corner) for corner in evaluated_part.bound_box)
                if corners:
                    local_min = Vector((
                        min(corner.x for corner in corners),
                        min(corner.y for corner in corners),
                        min(corner.z for corner in corners),
                    ))
                    local_max = Vector((
                        max(corner.x for corner in corners),
                        max(corner.y for corner in corners),
                        max(corner.z for corner in corners),
                    ))
                    world_point = evaluated_part.matrix_world @ (
                        (local_min + local_max) * 0.5
                    )

        if world_point is None:
            world_point = (
                evaluated_armature.matrix_world @ evaluated_bone.head
            )
        world_point = Vector(world_point[:3])
        draw_cache["points"][key] = world_point
        return world_point
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return None


def _dynamic_parent_target_pivot_world(
    context,
    target,
    subtarget,
    draw_cache,
):
    if target.type == "ARMATURE" and subtarget:
        return _dynamic_parent_bone_pivot_world(
            context,
            target,
            subtarget,
            draw_cache,
        )
    try:
        evaluated_target = target.evaluated_get(draw_cache["depsgraph"])
        return evaluated_target.matrix_world.to_translation()
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return None


def _draw_outlined_bone_text(
    font_id,
    text,
    center_x,
    text_y,
    font_size,
    text_color,
    outline_color = None,
    left_x = None,
    rotation = 0.0,
    left_position = None,
    opacity = 1.0,
):
    blf.size(font_id, float(font_size))
    rgb = tuple(float(value) for value in text_color[:3])
    opacity = max(0.0, min(1.0, float(opacity)))
    alpha = (float(text_color[3]) if len(text_color) >= 4 else 1.0) * opacity
    if outline_color is None:
        outline_rgb = (0.0, 0.0, 0.0)
    else:
        outline_rgb = tuple(float(value) for value in outline_color[:3])
    text_width, text_height = blf.dimensions(font_id, text)
    angle = float(rotation)
    cos_angle = math.cos(angle)
    sin_angle = math.sin(angle)
    if left_position is not None:
        text_x, text_y = (float(value) for value in left_position[:2])
    elif left_x is not None:
        text_x = float(left_x)
    else:
        # BLF rotates around the pen position.  Offset the pen along the
        # rotated baseline so center_x remains the visual midpoint.
        text_x = float(center_x) - (float(text_width) * 0.5 * cos_angle)
        text_y = float(text_y) - (float(text_width) * 0.5 * sin_angle)
    rotation_enabled = False
    try:
        if abs(angle) > 1.0e-8:
            blf.enable(font_id, blf.ROTATION)
            blf.rotation(font_id, angle)
            rotation_enabled = True
        # Restore the original crisp eight-direction outline. A BLF shadow is
        # a drop/blur effect, not a true stroke, so it changes the established
        # appearance even with a zero-pixel offset.
        blf.color(font_id, *outline_rgb, opacity)
        for offset_x, offset_y in (
            (-1.5, 0.0),
            (1.5, 0.0),
            (0.0, -1.5),
            (0.0, 1.5),
            (-1.1, -1.1),
            (-1.1, 1.1),
            (1.1, -1.1),
            (1.1, 1.1),
        ):
            blf.position(font_id, text_x + offset_x, text_y + offset_y, 0.0)
            blf.draw(font_id, text)
        blf.color(font_id, *rgb, alpha)
        blf.position(font_id, text_x, text_y, 0.0)
        blf.draw(font_id, text)
    finally:
        if rotation_enabled:
            try:
                blf.disable(font_id, blf.ROTATION)
            except (AttributeError, RuntimeError, TypeError, ValueError):
                pass
    return float(text_height)


def _camera_label_opacity(context, position):
    """Match passepartout darkening for labels outside a transparent frame."""
    region = getattr(context, "region", None)
    region_data = getattr(context, "region_data", None)
    space = getattr(context, "space_data", None)
    if (
        region is None
        or region_data is None
        or str(getattr(region_data, "view_perspective", "")) != "CAMERA"
    ):
        return 1.0
    camera = getattr(space, "camera", None) or getattr(
        getattr(context, "scene", None),
        "camera",
        None,
    )
    if camera is None or getattr(camera, "type", "") != "CAMERA":
        return 1.0
    if bool(getattr(camera, "staticaliza_camera_opaque_frame", True)):
        return 1.0
    try:
        from bpy_extras import view3d_utils
        projected = tuple(
            view3d_utils.location_3d_to_region_2d(
                region,
                region_data,
                camera.matrix_world @ Vector(corner),
            )
            for corner in camera.data.view_frame(scene=context.scene)
        )
        if len(projected) != 4 or any(point is None for point in projected):
            return 1.0
        x = float(position.x)
        y = float(position.y)
        inside = (
            min(point.x for point in projected) <= x <= max(point.x for point in projected)
            and min(point.y for point in projected) <= y <= max(point.y for point in projected)
        )
        if inside:
            return 1.0
        passepartout_alpha = float(
            getattr(camera.data, "passepartout_alpha", 0.5)
        )
        return max(0.0, min(1.0, 1.0 - passepartout_alpha))
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return 1.0



def _bone_status_text_color(effect, color):
    if effect == "CAMERA":
        return (0.64, 0.64, 0.64)
    tint = 0.5
    return tuple(
        min(1.0, float(component) + ((1.0 - float(component)) * tint))
        for component in color[:3]
    )


_PRESENTATION_WORKSPACES = frozenset({"audio", "preview"})


def _workspace_is_presentation(workspace):
    if workspace is None:
        return False
    try:
        name = _strip_blender_numeric_suffix(workspace.name)
    except (AttributeError, ReferenceError, TypeError, ValueError):
        return False
    return str(name).strip().casefold() in _PRESENTATION_WORKSPACES


def _screen_is_presentation(screen, context = None):
    if screen is None:
        return False
    context = context or bpy.context
    window_manager = getattr(context, "window_manager", None)
    for window in getattr(window_manager, "windows", ()) if window_manager else ():
        try:
            if (
                window.screen == screen
                and _workspace_is_presentation(window.workspace)
            ):
                return True
        except (AttributeError, ReferenceError):
            continue
    for workspace in tuple(bpy.data.workspaces):
        if not _workspace_is_presentation(workspace):
            continue
        try:
            if any(candidate == screen for candidate in workspace.screens):
                return True
        except (AttributeError, ReferenceError, TypeError):
            continue
    return False


def _context_is_presentation_view(context):
    if context is None:
        return False
    if _workspace_is_presentation(getattr(context, "workspace", None)):
        return True
    return _screen_is_presentation(getattr(context, "screen", None), context)


def _draw_bone_label(context, armature, pose_bone, opacity_override = None):
    region = getattr(context, "region", None)
    region_data = getattr(context, "region_data", None)
    if region is None or region_data is None:
        return

    try:
        from bpy_extras import view3d_utils

        depsgraph = context.evaluated_depsgraph_get()
        evaluated_armature = armature.evaluated_get(depsgraph)
        evaluated_bone = evaluated_armature.pose.bones.get(pose_bone.name)
        if evaluated_bone is None:
            return
        label_world = evaluated_armature.matrix_world @ (
            (evaluated_bone.head + evaluated_bone.tail) * 0.5
        )
        label_position = view3d_utils.location_3d_to_region_2d(
            region,
            region_data,
            label_world,
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return
    if label_position is None:
        return
    label_opacity = (
        _camera_label_opacity(context, label_position)
        if opacity_override is None
        else float(opacity_override)
    )
    # Labels are a HUD overlay. Keep their baseline horizontal in screen
    # space so perspective near the viewport edges cannot skew the text.
    text_rotation = 0.0

    font_id = 0
    # Every selected bone is an active label target during multi-selection;
    # do not reserve enlarged text/properties for only Blender's active bone.
    is_selected = _bone_label_is_selected(context, armature, pose_bone)
    try:
        font_size = float(context.preferences.ui_styles[0].widget.points) + 2.0
    except (AttributeError, IndexError, TypeError, ValueError):
        font_size = 11.0
    base_font_size = font_size
    if is_selected:
        font_size += 5.0
    try:
        text_color = tuple(
            float(channel)
            for channel in context.preferences.themes[0].view_3d.space.text_hi
        )
    except (AttributeError, IndexError, TypeError, ValueError):
        text_color = (1.0, 1.0, 1.0)
    try:
        frame = int(context.scene.frame_current)
        chosen = (
            _chosen_dynamic_parent_constraint(pose_bone, frame)
            if is_selected
            else None
        )
        effects = tuple(
            _dynamic_pose_bone_label_effects(
                pose_bone,
                frame,
                chosen,
            )
        ) if is_selected else ()
        subtitle_size = max(10.0, float(base_font_size) + 1.0)
        center_x = float(label_position.x) + 10.0
        blf.size(font_id, font_size)
        text_width, text_height = blf.dimensions(font_id, pose_bone.name)
        text_y = float(label_position.y) - (float(text_height) * 0.5)
        cos_angle = math.cos(text_rotation)
        sin_angle = math.sin(text_rotation)
        name_left = (
            center_x - (float(text_width) * 0.5 * cos_angle),
            text_y - (float(text_width) * 0.5 * sin_angle),
        )
        _draw_outlined_bone_text(
            font_id,
            pose_bone.name,
            center_x,
            text_y,
            font_size,
            (*text_color, 1.0),
            rotation = text_rotation,
            opacity = label_opacity,
        )

        if is_selected:
            subtitle_offset = subtitle_size + 3.0
            subtitle_left = (
                name_left[0] + (sin_angle * subtitle_offset),
                name_left[1] - (cos_angle * subtitle_offset),
            )
            for effect, label, color in effects:
                status_color = _bone_status_text_color(effect, color)
                height = _draw_outlined_bone_text(
                    font_id,
                    label,
                    center_x,
                    subtitle_left[1],
                    subtitle_size,
                    (*status_color, 1.0),
                    outline_color = (0.0, 0.0, 0.0),
                    rotation = text_rotation,
                    left_position = subtitle_left,
                    opacity = label_opacity,
                )
                subtitle_offset = max(height, subtitle_size) + 2.0
                subtitle_left = (
                    subtitle_left[0] + (sin_angle * subtitle_offset),
                    subtitle_left[1] - (cos_angle * subtitle_offset),
                )
    except (AttributeError, RuntimeError, TypeError, ValueError):
        return
