"""Viewport sidebar discovery, snapshots, and synchronization state helpers."""

from ..core.runtime import *  # noqa: F403

_VIEW3D_N_PANEL_WORKSPACES = frozenset({"animate", "graph"})
_VIEW3D_N_PANEL_SCROLL_EPSILON = 1.0
_VIEW3D_N_PANEL_CATEGORY_SETTLE = 0.06
_VIEW3D_N_PANEL_APPLY_INTERVAL = 0.08
_VIEW3D_N_PANEL_TARGET_SETTLE = 0.09
_VIEW3D_N_PANEL_SOURCE_GUARD = 0.10


def _view3d_n_panel_workspace_supported(workspace):
    if workspace is None:
        return False
    try:
        workspace_name = _strip_blender_numeric_suffix(
            workspace.name
        ).casefold()
    except (AttributeError, ReferenceError):
        return False
    return workspace_name in _VIEW3D_N_PANEL_WORKSPACES


def _view3d_n_panel_records(context = None):
    """Return live and inactive N regions for the Animate/Graph pair."""
    records = []
    seen = set()

    # Live windows come first.  In particular, a workspace that has never
    # been visited may not occur in WorkSpace.screens until Blender creates
    # its first window/screen binding.
    screen_sources = []
    window_manager = getattr(
        context or bpy.context,
        "window_manager",
        None,
    )
    for window in tuple(getattr(window_manager, "windows", ())):
        workspace = getattr(window, "workspace", None)
        screen = getattr(window, "screen", None)
        if (
            screen is not None
            and _view3d_n_panel_workspace_supported(workspace)
        ):
            screen_sources.append((workspace, screen))

    for workspace in tuple(bpy.data.workspaces):
        if not _view3d_n_panel_workspace_supported(workspace):
            continue
        for screen in tuple(getattr(workspace, "screens", ())):
            screen_sources.append((workspace, screen))

    for workspace, screen in screen_sources:
        for area in tuple(getattr(screen, "areas", ())):
            if area.type != "VIEW_3D":
                continue
            space = area.spaces.active
            if space is None or space.type != "VIEW_3D":
                continue
            region = next(
                (
                    candidate
                    for candidate in area.regions
                    if candidate.type == "UI"
                ),
                None,
            )
            if region is None:
                continue
            try:
                pointer = int(space.as_pointer())
            except (AttributeError, ReferenceError, TypeError, ValueError):
                continue
            if pointer in seen:
                continue
            seen.add(pointer)
            records.append(
                (pointer, workspace, screen, area, space, region)
            )
    return records


def _view3d_n_panel_category(region):
    try:
        category = str(region.active_panel_category)
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        return ""
    return "" if category in {"", "UNSUPPORTED"} else category


def _view3d_n_panel_scroll(region):
    try:
        value = float(region.view2d.region_to_view(0.0, 0.0)[1])
    except (
        AttributeError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ):
        return None
    return value if math.isfinite(value) else None


def _view3d_n_panel_view2d_ready(region):
    """Return whether this UI region has a usable, finite View2D scale."""
    try:
        if int(region.width) <= 1 or int(region.height) <= 1:
            return False
        first = float(region.view2d.region_to_view(0.0, 0.0)[1])
        second = float(region.view2d.region_to_view(0.0, 1.0)[1])
    except (
        AttributeError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ):
        return False
    return bool(
        math.isfinite(first)
        and math.isfinite(second)
        and abs(second - first) > 1.0e-9
    )


def _view3d_n_panel_snapshot(space, region):
    return (
        bool(getattr(space, "show_region_ui", False)),
        _view3d_n_panel_category(region),
        _view3d_n_panel_scroll(region),
    )


def _view3d_n_panel_scrolls_match(first, second):
    if first is None or second is None:
        return first is None and second is None
    try:
        return abs(float(first) - float(second)) <= (
            _VIEW3D_N_PANEL_SCROLL_EPSILON
        )
    except (TypeError, ValueError):
        return False


def _view3d_n_panel_snapshot_matches_master(snapshot, master):
    visible, category, scroll = snapshot
    desired_visible = bool((master or {}).get("visible", False))
    if bool(visible) != desired_visible:
        return False
    if not desired_visible:
        return True
    desired_category = str((master or {}).get("category", ""))
    if desired_category and category != desired_category:
        return False
    if bool((master or {}).get("scroll_pending", False)):
        return False
    desired_scroll = (master or {}).get("scroll")
    return bool(
        desired_scroll is None
        or _view3d_n_panel_scrolls_match(scroll, desired_scroll)
    )


def _view3d_n_panel_changed_fields(old_snapshot, snapshot, master):
    """Return user-editable fields changed since the last observed poll."""
    if old_snapshot is None:
        return set()
    old_visible, old_category, old_scroll = old_snapshot
    visible, category, scroll = snapshot
    changed = set()
    if bool(visible) != bool(old_visible):
        changed.add("visible")

    master_category = str((master or {}).get("category", ""))
    if category and (
        (old_category and category != old_category)
        or (not old_category and not master_category)
    ):
        changed.add("category")

    # Opening a previously closed sidebar can expose a stale local category
    # and View2D offset in the same poll.  Visibility is the user's action;
    # category and scroll are copied from the master after the region draws.
    if "visible" in changed and visible:
        changed.discard("category")
        return changed

    if (
        "category" not in changed
        and visible
        and category
        and category == old_category
        and scroll is not None
        and old_scroll is not None
        and not _view3d_n_panel_scrolls_match(scroll, old_scroll)
    ):
        changed.add("scroll")
    return changed


def _view3d_n_panel_master_from_snapshot(
    snapshot,
    pointer,
    revision = 1,
):
    visible, category, scroll = snapshot
    return {
        "visible": bool(visible),
        "category": str(category or ""),
        "scroll": scroll if category else None,
        "scroll_pending": bool(visible and category and scroll is None),
        "revision": max(1, int(revision)),
        "source": int(pointer),
    }


def _view3d_n_panel_update_master(
    master,
    snapshot,
    changed_fields,
    pointer,
):
    """Merge one authoritative user edit and return (master, changed)."""
    visible, category, scroll = snapshot
    result = dict(master or {})
    result.setdefault("visible", bool(visible))
    result.setdefault("category", str(category or ""))
    result.setdefault("scroll", scroll if category else None)
    result.setdefault("scroll_pending", False)
    before = (
        bool(result.get("visible", False)),
        str(result.get("category", "")),
        result.get("scroll"),
        bool(result.get("scroll_pending", False)),
    )

    if "visible" in changed_fields:
        result["visible"] = bool(visible)
        if (
            visible
            and result.get("category", "")
            and result.get("scroll") is None
        ):
            result["scroll_pending"] = True
    if "category" in changed_fields and category:
        result["category"] = str(category)
        # The new category's View2D is finalized on a later redraw.  Do not
        # briefly push the previous category's scroll into every target.
        result["scroll"] = None
        result["scroll_pending"] = bool(visible)
    if "scroll" in changed_fields and scroll is not None:
        result["scroll"] = float(scroll)
        result["scroll_pending"] = False

    after = (
        bool(result.get("visible", False)),
        str(result.get("category", "")),
        result.get("scroll"),
        bool(result.get("scroll_pending", False)),
    )
    changed = before != after
    if changed:
        result["revision"] = int(result.get("revision", 0)) + 1
        result["source"] = int(pointer)
    return result, changed


def _view3d_n_panel_pan_to(
    context,
    window,
    screen,
    area,
    space,
    region,
    desired_scroll,
):
    current_scroll = _view3d_n_panel_scroll(region)
    if current_scroll is None or desired_scroll is None:
        return False
    try:
        desired_scroll = float(desired_scroll)
        next_scroll = float(region.view2d.region_to_view(0.0, 1.0)[1])
    except (
        AttributeError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ):
        return False
    units_per_pixel = next_scroll - current_scroll
    if (
        not math.isfinite(desired_scroll)
        or not math.isfinite(units_per_pixel)
        or abs(units_per_pixel) <= 1.0e-9
    ):
        return False
    difference = desired_scroll - current_scroll
    target_tolerance = max(
        _VIEW3D_N_PANEL_SCROLL_EPSILON,
        abs(units_per_pixel) * 0.5,
    )
    if abs(difference) <= target_tolerance:
        return False

    # View2D pan uses the measured view-units-per-pixel direction on current
    # Blender versions.  Some UI-region implementations have historically
    # inverted that response, so every attempt is verified below.
    predicted_delta = int(round(difference / units_per_pixel))
    if not predicted_delta:
        predicted_delta = 1 if difference > 0.0 else -1
    response_tolerance = max(abs(units_per_pixel) * 0.25, 1.0e-6)
    max_correction = max(abs(predicted_delta) * 4, 64)
    attempted = False

    try:
        with context.temp_override(
            window = window,
            screen = screen,
            area = area,
            region = region,
            space_data = space,
        ):
            if not bpy.ops.view2d.pan.poll():
                return False

            def apply_delta(delta):
                nonlocal attempted
                delta = int(delta)
                if not delta:
                    return _view3d_n_panel_scroll(region)
                bpy.ops.view2d.pan(deltax = 0, deltay = delta)
                attempted = True
                return _view3d_n_panel_scroll(region)

            first_scroll = apply_delta(predicted_delta)
            if first_scroll is None:
                return attempted
            if abs(first_scroll - desired_scroll) <= target_tolerance:
                return attempted

            response = first_scroll - current_scroll
            applied_delta = predicted_delta
            response_origin = current_scroll
            if abs(response) <= response_tolerance:
                # The predicted direction may have hit a clamp.  Probe the
                # opposite direction before declaring this target immovable.
                response_origin = first_scroll
                applied_delta = -predicted_delta
                opposite_scroll = apply_delta(applied_delta)
                if opposite_scroll is None:
                    return attempted
                if (
                    abs(opposite_scroll - desired_scroll)
                    <= target_tolerance
                ):
                    return attempted
                response = opposite_scroll - response_origin
                first_scroll = opposite_scroll

            if abs(response) <= response_tolerance or not applied_delta:
                return attempted

            # Calibrate the operator's actual signed response.  This both
            # corrects an inverted first move and restores a target moved away
            # during the clamp probe, without assuming a fixed Blender sign.
            response_per_delta = response / float(applied_delta)
            if (
                not math.isfinite(response_per_delta)
                or abs(response_per_delta) <= 1.0e-9
            ):
                return attempted
            correction = int(
                round(
                    (desired_scroll - first_scroll)
                    / response_per_delta
                )
            )
            correction = max(
                -max_correction,
                min(max_correction, correction),
            )
            if correction:
                apply_delta(correction)
    except (
        AttributeError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ):
        return attempted
    return attempted


def _view3d_n_panel_mark_pending(state, revision, now):
    state["pending_revision"] = max(1, int(revision))
    state["settle_since"] = 0.0
    state["category_since"] = 0.0
    state["category_match"] = ""
    state["pan_stalls"] = 0
    state["last_pan_error"] = None
    state["block_until"] = max(
        float(state.get("block_until", 0.0)),
        float(now) + _VIEW3D_N_PANEL_SOURCE_GUARD,
    )


def _view3d_n_panel_state(snapshot, active):
    return {
        "observed": snapshot,
        "active": bool(active),
        "pending_revision": 0,
        "settle_since": 0.0,
        "category_since": 0.0,
        "category_match": "",
        "last_category_attempt": 0.0,
        "last_pan_attempt": 0.0,
        "last_pan_error": None,
        "pan_stalls": 0,
        "block_until": 0.0,
        "capture_scroll_at": 0.0,
        "capture_category": False,
        "capture_category_value": "",
        "capture_category_since": 0.0,
    }


def _view3d_n_panel_pick_window(
    context,
    screen_pointer,
    windows_by_screen,
):
    windows = tuple(windows_by_screen.get(int(screen_pointer), ()))
    if not windows:
        return None
    context_window = getattr(context, "window", None)
    if context_window in windows:
        return context_window
    return windows[0]
