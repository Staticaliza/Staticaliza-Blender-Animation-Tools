"""Cross-window free-view state and attached-camera exit synchronization."""

from ..core.runtime import *  # noqa: F403

def _sync_view3d_settings(context, source_space = None):
    _sync_view3d_n_panels(context, source_space = source_space)
    records = _view3d_setting_records(context)
    live_pointers = {record[0] for record in records}
    previous = _state.setdefault("free_view_setting_states", {})
    window_manager = getattr(context, "window_manager", None)
    current_screens = {
        int(window.screen.as_pointer())
        for window in getattr(window_manager, "windows", ())
        if getattr(window, "screen", None) is not None
    }
    context_window = getattr(context, "window", None)
    context_screen = (
        getattr(context_window, "screen", None)
        if context_window is not None
        else None
    )
    context_screen_pointer = (
        int(context_screen.as_pointer())
        if context_screen is not None
        else 0
    )
    try:
        source_pointer = int(source_space.as_pointer()) if source_space else 0
    except (AttributeError, ReferenceError):
        source_pointer = 0
    source_is_presentation = any(
        pointer == source_pointer and _screen_is_presentation(screen, context)
        for pointer, screen, _area, _space in records
    )
    existing_master = _state.get("free_view_settings_master")
    forced_master = None
    if source_space is not None:
        forced_master = _view3d_settings_snapshot(source_space)
        if source_is_presentation:
            forced_master = _presentation_view3d_source_snapshot(
                forced_master,
                existing_master,
            )

    current_records = []
    changed_records = []
    for record in records:
        pointer, screen, _area, space = record
        snapshot = _view3d_settings_snapshot(space)
        if snapshot is None:
            continue
        if int(screen.as_pointer()) in current_screens:
            if _screen_is_presentation(screen, context):
                snapshot = _presentation_view3d_source_snapshot(
                    snapshot,
                    existing_master,
                )
            current_records.append((record, snapshot))
            old_snapshot = previous.get(pointer)
            if old_snapshot is not None and snapshot != old_snapshot:
                changed_records.append((record, snapshot))

    def source_priority(item):
        record, _snapshot = item
        pointer, screen, area, _space = record
        return (
            pointer == source_pointer,
            int(screen.as_pointer()) == context_screen_pointer,
            int(getattr(area, "width", 0)) * int(getattr(area, "height", 0)),
        )

    master = existing_master
    if forced_master is not None:
        master = forced_master
        _state["free_view_settings_master"] = master
    elif changed_records:
        _record, master = max(changed_records, key = source_priority)
        _state["free_view_settings_master"] = master
    elif master is None and current_records:
        _record, master = max(current_records, key = source_priority)
        _state["free_view_settings_master"] = master

    if master is not None:
        for _pointer, screen, area, space in records:
            is_presentation = _screen_is_presentation(screen, context)
            applied_snapshot = (
                _presentation_view3d_settings_snapshot(master)
                if is_presentation
                else master
            )
            changed = _apply_view3d_settings_snapshot(
                space,
                applied_snapshot,
            )
            if is_presentation:
                changed |= _apply_presentation_viewport_overrides(space)
            if changed:
                try:
                    area.tag_redraw()
                except (AttributeError, ReferenceError):
                    pass

    for pointer, screen, _area, space in records:
        snapshot = _view3d_settings_snapshot(space)
        if snapshot is not None:
            if _screen_is_presentation(screen, context):
                snapshot = _presentation_view3d_source_snapshot(
                    snapshot,
                    master,
                )
            previous[pointer] = snapshot
    for pointer in tuple(previous):
        if pointer not in live_pointers:
            previous.pop(pointer, None)


def _free_view_records(context = None):
    records = []
    seen = set()
    for _workspace, screen in _view3d_sync_screen_sources(context):
        try:
            areas = tuple(screen.areas)
        except (AttributeError, ReferenceError):
            continue
        for area in areas:
            if area.type != "VIEW_3D":
                continue
            for space in tuple(area.spaces):
                if space.type != "VIEW_3D":
                    continue
                region_data = getattr(space, "region_3d", None)
                if region_data is None:
                    continue
                try:
                    pointer = int(region_data.as_pointer())
                except (AttributeError, ReferenceError):
                    continue
                if pointer in seen:
                    continue
                seen.add(pointer)
                records.append((
                    pointer,
                    int(space.as_pointer()),
                    screen,
                    area,
                    region_data,
                ))
    return records


def _free_view_snapshot(region_data):
    try:
        if region_data.view_perspective == "CAMERA":
            return None
        return {
            "location": region_data.view_location.copy(),
            "rotation": region_data.view_rotation.copy(),
            "distance": float(region_data.view_distance),
            "perspective": str(region_data.view_perspective),
        }
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return None


def _free_view_snapshots_match(first, second):
    if first is None or second is None:
        return first is second
    try:
        return bool(
            first["perspective"] == second["perspective"]
            and abs(float(first["distance"]) - float(second["distance"]))
            <= 1.0e-8
            and (first["location"] - second["location"]).length_squared
            <= 1.0e-16
            and abs(first["rotation"].dot(second["rotation"]))
            >= 1.0 - 1.0e-12
        )
    except (KeyError, TypeError, ValueError):
        return False


def _apply_free_view_snapshot(region_data, snapshot):
    if snapshot is None:
        return False
    current = _free_view_snapshot(region_data)
    if current is None or _free_view_snapshots_match(current, snapshot):
        return False
    try:
        region_data.view_perspective = snapshot["perspective"]
        region_data.view_location = snapshot["location"].copy()
        region_data.view_rotation = snapshot["rotation"].copy()
        region_data.view_distance = float(snapshot["distance"])
        return True
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return False


def _force_free_view_snapshot(region_data, snapshot):
    """Leave camera view and restore a free view without a smooth-view frame."""
    if snapshot is None:
        return False
    try:
        perspective = str(snapshot.get("perspective", "PERSP"))
        if perspective == "CAMERA":
            perspective = "PERSP"
        region_data.view_perspective = perspective
        region_data.view_location = snapshot["location"].copy()
        region_data.view_rotation = snapshot["rotation"].copy()
        region_data.view_distance = float(snapshot["distance"])
        return True
    except (
        AttributeError,
        KeyError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ):
        return False


def _finish_attached_camera_exit(context, area, space, region_data):
    """Complete a bone-camera exit in the same event/draw that detects it."""
    try:
        space_pointer = int(space.as_pointer())
    except (AttributeError, ReferenceError):
        return False

    states = _state.setdefault("camera_view_spaces", {})
    state = _camera_view_state(states.get(space_pointer))
    camera = bpy.data.objects.get(str(state.get("camera_name", "")))
    if camera is None:
        camera = getattr(space, "camera", None) or getattr(context.scene, "camera", None)
    if camera is not None:
        _set_attached_camera_preview_visibility(context.scene, camera, False)
    # The viewport-local return view is authoritative.  A camera transition
    # must never replace it with a tilted/interpolated global master.
    snapshot = state.get("return_view") or _state.get("free_view_master")
    restored = _force_free_view_snapshot(region_data, snapshot)
    if not restored:
        try:
            region_data.view_perspective = "PERSP"
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            pass
        restored = _level_free_view_rotation(region_data)
    else:
        # Scroll-wheel camera exits can leave Blender's interpolated roll in
        # RegionView3D for one frame. Normalize it synchronously.
        _level_free_view_rotation(region_data)

    state["attached"] = False
    state["pending_level"] = False
    state["last_rotation"] = None
    state["stable_ticks"] = 0
    state["return_view"] = None
    state["entering"] = False
    state["enter_started"] = 0.0
    state["camera_pointer"] = 0
    state["camera_name"] = ""
    states[space_pointer] = state

    current = _free_view_snapshot(region_data)
    synced_space_pointers = {
        record[1] for record in _free_view_records(context)
    }
    if current is not None and space_pointer in synced_space_pointers:
        _state["free_view_master"] = current
        try:
            region_pointer = int(region_data.as_pointer())
            _state.setdefault("free_view_space_states", {})[
                region_pointer
            ] = current
        except (AttributeError, ReferenceError):
            pass
    try:
        area.tag_redraw()
    except (AttributeError, ReferenceError):
        pass
    return restored


def _free_view_record_protected(space_pointer, region_data):
    try:
        if region_data.view_perspective == "CAMERA":
            return True
    except (AttributeError, ReferenceError):
        return True
    state = _state.setdefault("camera_view_spaces", {}).get(
        int(space_pointer)
    )
    return bool(
        isinstance(state, dict)
        and (
            state.get("attached", False)
            or state.get("entering", False)
            or state.get("pending_level", False)
        )
    )


def _sync_free_viewports(
    context,
    source_region_data = None,
    source_space = None,
):
    if _state.get("free_view_syncing", False):
        return
    _state["free_view_syncing"] = True
    try:
        _sync_view3d_settings(context, source_space = source_space)
        records = _free_view_records(context)
        live_pointers = {record[0] for record in records}
        previous = _state.setdefault("free_view_space_states", {})
        window_manager = getattr(context, "window_manager", None)
        current_screens = {
            int(window.screen.as_pointer())
            for window in getattr(window_manager, "windows", ())
            if getattr(window, "screen", None) is not None
        }
        context_window = getattr(context, "window", None)
        context_screen = (
            getattr(context_window, "screen", None)
            if context_window is not None
            else None
        )
        context_screen_pointer = (
            int(context_screen.as_pointer())
            if context_screen is not None
            else 0
        )
        context_region = getattr(context, "region_data", None)
        context_region_pointer = (
            int(context_region.as_pointer())
            if context_region is not None
            else 0
        )

        forced_master = None
        if source_region_data is not None and source_space is not None:
            try:
                source_space_pointer = int(source_space.as_pointer())
            except (AttributeError, ReferenceError):
                source_space_pointer = 0
            synced_space_pointers = {record[1] for record in records}
            if (
                source_space_pointer in synced_space_pointers
                and not _free_view_record_protected(
                    source_space_pointer,
                    source_region_data,
                )
            ):
                forced_master = _free_view_snapshot(source_region_data)

        current_records = []
        changed_records = []
        for record in records:
            pointer, space_pointer, screen, area, region_data = record
            if _free_view_record_protected(space_pointer, region_data):
                continue
            snapshot = _free_view_snapshot(region_data)
            if snapshot is None:
                continue
            if int(screen.as_pointer()) in current_screens:
                current_records.append((record, snapshot))
                old_snapshot = previous.get(pointer)
                if (
                    old_snapshot is not None
                    and not _free_view_snapshots_match(snapshot, old_snapshot)
                ):
                    changed_records.append((record, snapshot))

        def source_priority(item):
            record, _snapshot = item
            pointer, _space_pointer, screen, area, _region_data = record
            return (
                pointer == context_region_pointer,
                int(screen.as_pointer()) == context_screen_pointer,
                int(getattr(area, "width", 0)) * int(getattr(area, "height", 0)),
            )

        master = _state.get("free_view_master")
        if forced_master is not None:
            master = forced_master
            _state["free_view_master"] = master
        elif changed_records:
            _record, master = max(changed_records, key = source_priority)
            _state["free_view_master"] = master
        elif master is None and current_records:
            _record, master = max(current_records, key = source_priority)
            _state["free_view_master"] = master

        if master is not None:
            for (
                _pointer,
                space_pointer,
                _screen,
                area,
                region_data,
            ) in records:
                if _free_view_record_protected(space_pointer, region_data):
                    continue
                if _apply_free_view_snapshot(region_data, master):
                    try:
                        area.tag_redraw()
                    except (AttributeError, ReferenceError):
                        pass

        for pointer, space_pointer, _screen, _area, region_data in records:
            if _free_view_record_protected(space_pointer, region_data):
                continue
            snapshot = _free_view_snapshot(region_data)
            if snapshot is not None:
                previous[pointer] = snapshot
        for pointer in tuple(previous):
            if pointer not in live_pointers:
                previous.pop(pointer, None)
    finally:
        _state["free_view_syncing"] = False


def _camera_view_exit_timer():
    context = bpy.context
    window_manager = getattr(context, "window_manager", None)
    states = _state.setdefault("camera_view_spaces", {})
    if window_manager is not None:
        _sync_presentation_camera_views(context)
    # The dedicated attached-camera exit operator performs its own immediate
    # repair. All other modal actions, especially native gizmo transforms,
    # must see an entirely read/write-idle viewport timer.
    if (
        _pin_primary_mouse_pressed()
        or _window_manager_has_modal_operator(context)
    ):
        return 0.05
    live_spaces = set()
    if window_manager is not None:
        for window in window_manager.windows:
            scene = window.scene
            for area in window.screen.areas:
                if area.type != "VIEW_3D":
                    continue
                for space in area.spaces:
                    if space.type != "VIEW_3D":
                        continue
                    region_data = getattr(space, "region_3d", None)
                    if region_data is None:
                        continue
                    pointer = int(space.as_pointer())
                    live_spaces.add(pointer)
                    state = _camera_view_state(states.get(pointer))
                    in_camera_view = region_data.view_perspective == "CAMERA"
                    if in_camera_view:
                        camera = getattr(space, "camera", None) or scene.camera
                        _apply_camera_passepartout(camera, space)
                        armature, bone_name = _camera_bone_binding(camera)
                        is_attached = bool(armature is not None and bone_name)
                        newly_attached = bool(
                            is_attached and not state["attached"]
                        )
                        if (
                            newly_attached
                            and state.get("return_view") is None
                        ):
                            state["return_view"] = _state.get(
                                "free_view_master"
                            )
                        state["attached"] = is_attached
                        state["entering"] = False
                        state["enter_started"] = 0.0
                        state["camera_pointer"] = (
                            int(camera.as_pointer()) if camera is not None else 0
                        )
                        state["camera_name"] = (
                            camera.name if camera is not None else ""
                        )
                        state["pending_level"] = False
                        state["last_rotation"] = None
                        state["stable_ticks"] = 0
                        if newly_attached:
                            _select_attached_camera_bone(context, camera)
                        if is_attached:
                            _set_attached_camera_preview_visibility(
                                scene,
                                camera,
                                True,
                            )
                    else:
                        if state["attached"]:
                            _finish_attached_camera_exit(
                                context,
                                area,
                                space,
                                region_data,
                            )
                            state = _camera_view_state(states.get(pointer))
                        elif state["pending_level"]:
                            # Migrate an older deferred state immediately.
                            if _level_free_view_rotation(region_data):
                                area.tag_redraw()
                            state["pending_level"] = False
                            state["last_rotation"] = None
                            state["stable_ticks"] = 0
                        elif state.get("entering", False):
                            # Smooth-view keeps perspective non-CAMERA while
                            # interpolating. Keep the saved free view isolated
                            # until Blender reaches its camera endpoint.
                            if (
                                time.monotonic()
                                - float(state.get("enter_started", 0.0))
                                > 2.0
                            ):
                                camera = bpy.data.objects.get(
                                    str(state.get("camera_name", ""))
                                )
                                if camera is not None:
                                    _set_attached_camera_preview_visibility(
                                        scene,
                                        camera,
                                        False,
                                    )
                                state["entering"] = False
                                state["enter_started"] = 0.0
                                state["camera_pointer"] = 0
                                state["camera_name"] = ""
                    states[pointer] = state

    for pointer in tuple(states):
        if pointer not in live_spaces:
            states.pop(pointer, None)
    # Never rewrite RegionView3D while Blender owns an interactive modal
    # operation (native gizmo transform, orbit, pan, box select, and so on).
    # Camera-exit repair above remains active, but cross-window propagation is
    # deferred until the operation releases the event stream.
    if _view3d_sync_screen_sources(context):
        _sync_free_viewports(context)
        return 0.05
    return 0.2
