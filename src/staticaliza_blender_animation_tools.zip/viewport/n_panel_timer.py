"""Timer callback for viewport sidebar synchronization."""

from ..core.runtime import *  # noqa: F403

def _view3d_n_panel_sync_timer():
    """Poll sidebar-only changes that do not trigger free-view syncing."""
    context = bpy.context
    if (
        _pin_primary_mouse_pressed()
        or _window_manager_has_modal_operator(context)
    ):
        return 0.08
    if not _view3d_n_panel_records(context):
        return 0.25
    try:
        _sync_view3d_n_panels(context)
    except (
        AttributeError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ):
        pass
    return 0.05
