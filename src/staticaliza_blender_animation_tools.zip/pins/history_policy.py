"""Pure policy helpers for pairing Contact transforms with Blender history."""

from __future__ import annotations


def contact_history_source_index(direction):
    return 1 if str(direction).upper() == "UNDO" else 0


def contact_history_target_index(direction):
    return 0 if str(direction).upper() == "UNDO" else 1


def contact_history_candidate(direction, undo_stack, redo_stack):
    stack = undo_stack if str(direction).upper() == "UNDO" else redo_stack
    return stack[-1] if stack else None


def _contact_history_entry(entry, owner=False):
    if isinstance(entry, dict):
        prefix = (entry.get("owner_key"),) if owner else ()
        return prefix + (
            str(entry.get("armature_name", "")),
            str(entry.get("bone_name", "")),
            entry.get("before"),
            entry.get("native_after", entry.get("after")),
            entry.get(
                "solved_after",
                entry.get("after", entry.get("native_after")),
            ),
        )
    values = tuple(entry or ())
    minimum = 5 if owner else 4
    if len(values) < minimum:
        raise ValueError("Invalid Contact history entry")
    offset = 1 if owner else 0
    prefix = (values[0],) if owner else ()
    armature_name = str(values[offset])
    bone_name = str(values[offset + 1])
    before = values[offset + 2]
    native_after = values[offset + 3]
    solved_after = values[offset + 4] if len(values) >= minimum + 1 else native_after
    return prefix + (
        armature_name,
        bone_name,
        before,
        native_after,
        solved_after,
    )


def contact_history_selected_entry(entry):
    return _contact_history_entry(entry, owner=False)


def contact_history_contact_entry(entry):
    return _contact_history_entry(entry, owner=True)


def contact_history_visual_entry(entry):
    return _contact_history_entry(entry, owner=True)


def contact_history_selected_entries(transition):
    if not transition:
        return ()
    return tuple(
        contact_history_selected_entry(entry)
        for entry in transition.get("selected", ())
    )


def contact_history_contact_entries(transition):
    if not transition:
        return ()
    return tuple(
        contact_history_contact_entry(entry)
        for entry in transition.get("contacts", ())
    )


def contact_history_visual_entries(transition):
    if not transition:
        return ()
    return tuple(
        contact_history_visual_entry(entry)
        for entry in transition.get("visual_poses", ())
    )


def contact_history_entry_candidates(entry, index, owner=False):
    values = _contact_history_entry(entry, owner=owner)
    before, native_after, solved_after = values[-3:]
    if int(index) == 0:
        return (before,)
    if int(index) != 1:
        return ()
    if solved_after is native_after:
        return (native_after,)
    return (native_after, solved_after)


def contact_history_entry_restore_value(entry, index, owner=False):
    values = _contact_history_entry(entry, owner=owner)
    return values[-3] if int(index) == 0 else values[-1]


def contact_history_selected_keys(transition):
    return frozenset(
        (armature_name, bone_name)
        for armature_name, bone_name, _before, _native_after, _solved_after
        in contact_history_selected_entries(transition)
    )


def contact_history_contact_owners(transition):
    return frozenset(
        (armature_name, bone_name)
        for _owner_key, armature_name, bone_name, _before, _native_after, _solved_after
        in contact_history_contact_entries(transition)
    )


def contact_history_owner_keys(transition):
    return frozenset(
        owner_key
        for owner_key, _armature_name, _bone_name, _before, _native_after, _solved_after
        in contact_history_contact_entries(transition)
    )


def contact_history_predict_transform(
    transition,
    selected_keys,
    active_key,
    source_side_matches,
):
    transition_keys = contact_history_selected_keys(transition)
    selected_keys = frozenset(selected_keys or ())
    return bool(
        transition_keys
        and selected_keys == transition_keys
        and (active_key is None or active_key in transition_keys)
        and source_side_matches
    )


def contact_history_transition_completed(
    predicted,
    selection_changed,
    transition_changed,
    target_side_matches,
):
    del selection_changed
    # A transform checkpoint may restore the selection from the preceding
    # transform at the same time. The exact target pose/state is the history
    # discriminator; treating any selection difference as a separate step
    # leaves the Contact transition pending and creates a blank Undo/Redo.
    return bool(predicted and transition_changed and target_side_matches)


def contact_history_advance(direction, transition, undo_stack, redo_stack):
    if transition is None:
        return False
    if str(direction).upper() == "UNDO":
        if not undo_stack or undo_stack[-1] is not transition:
            return False
        undo_stack.pop()
        redo_stack.append(transition)
        return True
    if not redo_stack or redo_stack[-1] is not transition:
        return False
    redo_stack.pop()
    undo_stack.append(transition)
    return True


def contact_history_should_restore(
    selection_changed,
    predicted_transform,
    selected_transform_changed,
    source_side_still_matches,
):
    return bool(
        not selection_changed
        and predicted_transform
        and selected_transform_changed
        and not source_side_still_matches
    )
