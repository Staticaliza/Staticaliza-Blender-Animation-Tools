"""Draw, redo, and Contact-bone helpers for the shared pin transform."""

from ..core.runtime import *  # noqa: F403


def _pin_contact_bone_transform_target(context):
    """Return the active pink bone's guide without selecting its target pin."""
    pose_bone = _single_active_pose_bone(context)
    armature = _pose_bone_owner(context, pose_bone)
    if armature is None or pose_bone is None:
        return "", None
    frame = int(context.scene.frame_current)
    guides = tuple(
        guide
        for guide in _surface_contact_guides_for_selected_bone(
            armature,
            pose_bone,
            frame,
        )
        if (
            str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
            == pose_bone.name
            and str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
            == SURFACE_CONTACT_KIND_SIMULATED
        )
    )
    if not guides:
        return "", None
    guide = max(
        guides,
        key = lambda item: int(
            item.get(SURFACE_CONTACT_START_PROPERTY, -1048574)
        ),
    )
    key = (
        f"CONTACT_BONE:{_armature_session_uid(armature)}:"
        f"{pose_bone.name}:{guide.name}"
    )
    return key, ("CONTACT", armature, pose_bone, guide)


def _pin_transform_operator_draw(operator, _context):
    if operator.transform_mode != "TRANSLATE":
        return
    column = operator.layout.column(align = True)
    column.prop(operator, "displacement", index = 0, text = "Move X")
    column.prop(operator, "displacement", index = 1, text = "Y")
    column.prop(operator, "displacement", index = 2, text = "Z")
    values = tuple(operator.orientation_basis_values)
    orientation = (
        Matrix((values[0:3], values[3:6], values[6:9]))
        if len(values) == 9
        else Matrix.Identity(3)
    )
    distance = (orientation @ Vector(operator.displacement)).length
    operator.layout.label(text = f"Distance: {distance:.6g} m")
    operator.layout.label(
        text = f"Orientation: {operator.orientation_name or 'Global'}"
    )
    operator.layout.label(text = f"Pivot: {operator.pivot_name or 'Bone'}")


def _pin_transform_apply_contact_bone(context, operator, target_data):
    """Apply magnetism to a bone pose authored by our own modal operator."""
    _kind, armature, pose_bone, guide = target_data
    saved_raw_world = getattr(operator, "contact_raw_world", None)
    raw_world = (
        Matrix(saved_raw_world)
        if saved_raw_world is not None
        else (armature.matrix_world @ pose_bone.matrix)
    )
    yellow_owned = _pin_apply_yellow_priority(
        context,
        armature,
        pose_bone,
    )
    if yellow_owned:
        operator.contact_keep_attached = False
    else:
        has_yellow = bool(
            _state.get("yellow_fixed", {}).get(
                _owner_bone_key(armature, pose_bone.name)
            )
        )
        target, _normal, anchor = _surface_contact_world_point_normal(
            context,
            guide,
        )
        snap_key = _surface_contact_snap_key(guide)
        _pin_contact_ball_joint_advance_release_state(operator)
        pulled_free = bool(
            operator.contact_keep_attached
            and operator.transform_mode == "TRANSLATE"
            and _pin_contact_ball_joint_pulled_free(
                operator,
                raw_world,
            )
        )
        if pulled_free:
            pressure_release = bool(getattr(
                operator,
                "contact_pressure_release_requested",
                False,
            ))
            operator.contact_detached_input_world = Matrix(
                getattr(
                    operator,
                    "contact_ball_previous_raw_world",
                    raw_world,
                )
            )
            operator.contact_detached_pose_world = Matrix(
                getattr(
                    operator,
                    "contact_ball_current_world",
                    raw_world,
                )
            )
            operator.contact_detached_continuity_active = True
            operator.contact_detached_magnetic_active = False
            operator.contact_reentry_armed = False
            operator.contact_keep_attached = False
            operator.contact_ball_active = False
            operator.contact_explicitly_released = True
            operator.contact_pressure_released = pressure_release
            if pressure_release:
                # Publish the same terminal release/barrier state used by
                # native G. The custom pink-pin operator previously skipped
                # it and re-entered magnetic snap on its very next event.
                _surface_contact_begin_pressure_release(context, guide)
            _state.setdefault("pin_snap_transform_releasing", set()).add(
                snap_key
            )
            _state.setdefault("pin_snap_latches", set()).discard(snap_key)
            _surface_contact_set_snap_detached(guide, True)
        pink_engaged = bool(operator.contact_keep_attached)
        raw_reentry_anchor, raw_reentry_within = (
            _pin_contact_ball_joint_reentry_probe(
                context,
                operator,
                raw_world,
                target,
                fallback=anchor,
            )
            if target is not None
            else (None, False)
        )
        terminal_pressure_release = bool(
            not pulled_free
            and getattr(operator, "contact_pressure_released", False)
            and getattr(operator, "contact_explicitly_released", False)
            and getattr(
                operator,
                "contact_detached_continuity_active",
                False,
            )
        )
        if (
            not pink_engaged
            and terminal_pressure_release
            and target is not None
            and raw_reentry_anchor is not None
        ):
            if not raw_reentry_within:
                operator.contact_reentry_armed = True
            elif getattr(operator, "contact_reentry_armed", False):
                pink_engaged = _pin_snap_should_engage(
                    context,
                    snap_key,
                    target,
                    raw_reentry_anchor,
                    use_hysteresis=True,
                )
        if (
            not pink_engaged
            and not pulled_free
            and not terminal_pressure_release
            and target is not None
            and anchor is not None
            and (
                not (
                    getattr(
                        operator,
                        "contact_detached_continuity_active",
                        False,
                    )
                    or getattr(
                        operator,
                        "contact_detached_magnetic_active",
                        False,
                    )
                )
                or getattr(operator, "contact_reentry_armed", False)
            )
        ):
            # Detached magnetic aiming is a presentation/guide solve.  Snap
            # re-entry must instead test the captured support point through
            # the raw modal pose, otherwise returning the mouse to the dot can
            # look aligned while the post-solve support remains outside the
            # inner ring forever.
            reentry_anchor = raw_reentry_anchor
            # A post-solve/magnetic endpoint may be exactly on the socket
            # while the authored pink pin is vertically far away. It is a
            # presentation result, not contact evidence. Require the current
            # raw endpoint to be inside the visible ring before arbitration.
            pink_engaged = bool(
                raw_reentry_within
                and _pin_snap_should_engage(
                    context,
                    snap_key,
                    target,
                    reentry_anchor,
                    use_hysteresis=True,
                )
            )
        if pink_engaged:
            ball_was_active = bool(
                getattr(operator, "contact_ball_active", False)
            )
            if not ball_was_active:
                # Capture while the persisted detach state is still active.
                # Clearing that ID property can synchronously run the old
                # simulated solver; capturing afterward would preserve its
                # stale/mirrored orientation instead of the raw modal pose.
                _pin_contact_ball_joint_capture(
                    context,
                    operator,
                    target_data,
                    raw_world,
                    pose_world=getattr(
                        operator,
                        "contact_ball_detached_world",
                        None,
                    ),
                )
                operator.contact_detached_input_world = None
                operator.contact_detached_pose_world = None
                operator.contact_detached_continuity_active = False
                operator.contact_detached_magnetic_active = False
                operator.contact_reentry_armed = False
            # This path already decided that the contact is engaged. Preserve
            # its latch continuously across the solve so viewport drawing and
            # depsgraph callbacks can never observe a transient detached
            # sample between clear and re-add.
            _surface_contact_clear_snap_departure(
                guide,
                preserve_latch=True,
            )
            _state.setdefault("pin_snap_transform_releasing", set()).discard(
                snap_key
            )
            _state.setdefault("pin_snap_latches", set()).add(snap_key)
            collision_start_world = Matrix(
                getattr(
                    operator,
                    "contact_ball_current_world",
                    raw_world,
                )
            )
            _surface_contact_set_constraint_attachment(guide, True)
            if (
                ball_was_active
                or (
                    bool(getattr(operator, "contact_ball_active", False))
                    and getattr(
                        operator,
                        "contact_ball_target",
                        None,
                    ) is not None
                    and getattr(
                        operator,
                        "contact_ball_initial_handle",
                        None,
                    ) is not None
                )
            ):
                # Enabling a persisted constraint can evaluate its old solver
                # orientation immediately. Reapply even on a zero-delta
                # capture so re-entry preserves the exact raw pose instead of
                # flashing or settling to that stale orientation.
                _pin_contact_ball_joint_apply(
                    context,
                    operator,
                    target_data,
                    raw_world,
                )
            operator.contact_keep_attached = bool(
                getattr(operator, "contact_ball_active", False)
            )
            if (
                operator.contact_keep_attached
                and getattr(
                    operator,
                    "contact_ball_handle_local",
                    None,
                ) is not None
            ):
                collision_target, collision_normal, collision_anchor = (
                    _surface_contact_world_point_normal(context, guide)
                )
                if (
                    collision_target is not None
                    and collision_normal is not None
                    and collision_anchor is not None
                ):
                    swept_collision = _pin_contact_ball_joint_sweep_collision(
                        context,
                        operator,
                        target_data,
                        collision_start_world,
                    )
                    if not swept_collision:
                        _surface_contact_resolve_pose_collision(
                            context,
                            guide,
                            collision_target,
                            collision_normal,
                            collision_anchor,
                            allow_planted_roll=True,
                            # This branch is a confirmed snap. The detached
                            # segment/plane roll pivots at an arbitrary
                            # intersection and can move the real endpoint off
                            # its pin while leaving the latch set. Attached
                            # pressure is owned solely by the planted rod
                            # solver above.
                            allow_detached_roll=False,
                        )
                    _pin_contact_ball_joint_sync_current(
                        operator,
                        armature,
                        pose_bone,
                    )
        elif has_yellow:
            _surface_contact_set_constraint_attachment(guide, False)
            _surface_contact_set_snap_detached(guide, True)
            operator.contact_keep_attached = False
        else:
            detached_input_world = getattr(
                operator,
                "contact_detached_input_world",
                None,
            )
            detached_pose_world = getattr(
                operator,
                "contact_detached_pose_world",
                None,
            )
            if (
                detached_input_world is not None
                and detached_pose_world is not None
            ):
                continuous_world = (
                    Matrix(raw_world)
                    @ Matrix(detached_input_world).inverted_safe()
                    @ Matrix(detached_pose_world)
                )
                _set_pose_bone_constrained_output_matrix(
                    context,
                    armature,
                    pose_bone,
                    armature.matrix_world.inverted_safe()
                    @ continuous_world,
                )
            continuous_detached = bool(
                getattr(
                    operator,
                    "contact_detached_continuity_active",
                    False,
                )
                and
                detached_input_world is not None
                and detached_pose_world is not None
            )
            detached_session = bool(
                detached_input_world is not None
                and detached_pose_world is not None
                and (
                    continuous_detached
                    or getattr(
                        operator,
                        "contact_detached_magnetic_active",
                        False,
                    )
                )
            )
            # Preserve the authored endpoint from before collision/magnetic
            # presentation. The magnetic solve below can rotate a far pin
            # exactly onto the socket, so its result cannot prove proximity.
            pre_aim_target = target
            pre_aim_probe = raw_reentry_anchor
            if bool(
                detached_session
                and getattr(
                    operator,
                    "contact_detached_magnetic_active",
                    False,
                )
            ):
                # Resolve wall/side compression before computing magnetic
                # orientation. Otherwise a hard push can move the target
                # through the opposite endpoint and expose the 180-degree
                # aim root for one modal sample.
                _surface_contact_enforce_guide(
                    context,
                    guide,
                    force_contact=False,
                    insert_keys=False,
                    use_snap_hysteresis=False,
                    allow_snap=False,
                    rotate_detached=False,
                    collision_only=True,
                    rotate_snap=False,
                    allow_collision_roll=True,
                )
                magnetic_target, _magnetic_normal, magnetic_anchor = (
                    _surface_contact_world_point_normal(context, guide)
                )
                if (
                    magnetic_target is not None
                    and magnetic_anchor is not None
                    and not _surface_contact_pose_is_invalid(
                        context,
                        guide,
                        magnetic_target,
                        _magnetic_normal,
                        magnetic_anchor,
                    )
                ):
                    _pin_contact_ball_joint_magnetic_aim(
                        context,
                        operator,
                        target_data,
                        magnetic_target,
                        magnetic_anchor,
                    )
            detached = _surface_contact_snap_departure_active(
                context,
                guide,
                start_if_close = True,
            )
            _surface_contact_enforce_guide(
                context,
                guide,
                force_contact = False,
                insert_keys = False,
                use_snap_hysteresis = True,
                allow_snap = bool(
                    not detached
                    and not getattr(
                        operator,
                        "contact_explicitly_released",
                        False,
                    )
                ),
                rotate_detached = bool(
                    operator.transform_mode == "TRANSLATE"
                    and not detached_session
                ),
                collision_only = detached_session,
                # Detached side contact may roll as a physical rod barrier;
                # it must not be confused with attachment/latch state.
                allow_collision_roll = bool(
                    not getattr(
                        operator,
                        "contact_pressure_released",
                        False,
                    )
                ),
                rotate_snap = bool(
                    operator.transform_mode == "TRANSLATE"
                    and not detached_session
                ),
            )
            solved_detached_world = armature.matrix_world @ pose_bone.matrix
            reattached_this_sample = False
            solved_target = solved_anchor = None
            solved_within_entry = False
            if (
                detached_session
                and not getattr(
                    operator,
                    "contact_explicitly_released",
                    False,
                )
            ):
                solved_target, _solved_normal, solved_anchor = (
                    _surface_contact_world_point_normal(context, guide)
                )
                solved_within_entry = bool(raw_reentry_within)
                if not solved_within_entry:
                    operator.contact_reentry_armed = True
                if (
                    pre_aim_target is not None
                    and pre_aim_probe is not None
                    and solved_within_entry
                    and getattr(
                        operator,
                        "contact_reentry_armed",
                        False,
                    )
                    and _pin_snap_should_engage(
                        context,
                        snap_key,
                        pre_aim_target,
                        pre_aim_probe,
                        use_hysteresis=True,
                    )
                    and _pin_contact_ball_joint_capture(
                        context,
                        operator,
                        target_data,
                        raw_world,
                        pose_world=solved_detached_world,
                    )
                ):
                    # The authored endpoint entered the ring during this
                    # sample. Preserve the magnetic presentation when forming
                    # the latch, but never let that presentation create the
                    # proximity fact by itself.
                    _surface_contact_clear_snap_departure(
                        guide,
                        preserve_latch=True,
                    )
                    _state.setdefault(
                        "pin_snap_transform_releasing",
                        set(),
                    ).discard(snap_key)
                    _state.setdefault("pin_snap_latches", set()).add(
                        snap_key
                    )
                    _surface_contact_set_constraint_attachment(guide, True)
                    _pin_contact_ball_joint_apply(
                        context,
                        operator,
                        target_data,
                        raw_world,
                    )
                    operator.contact_detached_input_world = None
                    operator.contact_detached_pose_world = None
                    operator.contact_detached_continuity_active = False
                    operator.contact_detached_magnetic_active = False
                    operator.contact_reentry_armed = False
                    operator.contact_keep_attached = True
                    reattached_this_sample = True
            if not reattached_this_sample:
                operator.contact_ball_detached_world = (
                    solved_detached_world.copy()
                )
                # Keep the release sample as the absolute modal baseline.
                # Rebasing this pair from the collision/magnetic result on
                # every mouse event feeds solver correction back into the
                # next input sample.  That creates apparent resistance when
                # far from the pin and leaves Blender's cursor progressively
                # offset after pushing into, then pulling out of, a surface.
                # A fixed baseline preserves Blender's 1:1 mouse pace while
                # collision remains a presentation constraint only.
                operator.contact_keep_attached = bool(
                    not _surface_contact_snap_departure_active(
                        context,
                        guide,
                    )
                    and _pin_contact_is_attached(context, guide)
                )
    bone_changed = any(
        (
            (current := armature.pose.bones.get(bone_name)) is not None
            and _pin_keyboard_matrices_differ(
                current.matrix_basis,
                operator.bone_states[bone_name]["matrix_basis"],
            )
        )
        for bone_name in operator.bone_order
    )
    operator.changed = bool(bone_changed)
    if operator.transform_mode == "TRANSLATE" and pose_bone is not None:
        initial_state = operator.bone_states.get(pose_bone.name)
        if initial_state is not None:
            initial_point = (
                armature.matrix_world @ initial_state["matrix"]
            ).translation
            current_point = (
                armature.matrix_world @ pose_bone.matrix
            ).translation
            operator.displacement = tuple(
                operator.orientation.inverted_safe()
                @ (current_point - initial_point)
            )
    _surface_contact_capture_live_pose(guide)
    _tag_redraw_all_view3d()
    return True


def _pin_transform_finish_contact_bone(context, operator, guide):
    """Commit bone-only attachment state without keying the fixed target."""
    _surface_contact_finalize_snap_departures(context)
    _surface_contact_store_owner_pose_base(guide)
    _surface_contact_store_persistent_pose_snapshots((guide,))
    _surface_contact_seed_runtime_signatures(context, (guide,))
    return True


def _pin_transform_redo_matrix(values):
    if not isinstance(values, (tuple, list)) or len(values) != 16:
        return None
    return Matrix(tuple(
        tuple(float(values[(row * 4) + column]) for column in range(4))
        for row in range(4)
    ))


def _pin_transform_redo_target(item):
    armature = bpy.data.objects.get(str(item.get("armature", "")))
    pose_bone = (
        armature.pose.bones.get(str(item.get("bone", "")))
        if armature is not None and getattr(armature, "pose", None)
        else None
    )
    if str(item.get("kind", "")) == "YELLOW":
        return (
            ("YELLOW", armature, pose_bone, None)
            if armature is not None and pose_bone is not None
            else None
        )
    guide = bpy.data.objects.get(str(item.get("guide", "")))
    if armature is None or pose_bone is None or guide is None:
        return None
    return "CONTACT", armature, pose_bone, guide


def _pin_transform_execute_pin_set(
    operator,
    context,
    world_displacement = None,
    include_active = True,
    orientation = None,
):
    try:
        items = json.loads(getattr(operator, "redo_pins_json", "") or "[]")
    except (TypeError, ValueError):
        items = []
    changed = False
    yellow_changed = False
    for item in items:
        if not include_active and bool(item.get("active", False)):
            continue
        target_data = _pin_transform_redo_target(item)
        if target_data is None:
            continue
        kind, armature, pose_bone, payload = target_data
        value_name = "result" if world_displacement is None else "initial"
        desired_matrix = _pin_transform_redo_matrix(item.get(value_name))
        if desired_matrix is None:
            continue
        if world_displacement is not None:
            desired_matrix.translation += world_displacement
            desired_matrix.translation = _pin_gizmo_apply_axis_locks(
                desired_matrix.translation,
                _pin_transform_redo_matrix(item.get("initial")).translation,
                _pin_target_locked_axes(target_data),
                orientation or Matrix.Identity(3),
            )
        if kind == "YELLOW":
            changed = _yellow_set_pin_target(
                armature,
                pose_bone.name,
                desired_matrix.translation,
            ) or changed
            _yellow_store_target_property(
                armature,
                pose_bone.name,
                desired_matrix.translation,
            )
            yellow_changed = True
            continue
        solver_name = (
            "result_solver"
            if world_displacement is None
            else "initial_solver"
        )
        solver_matrix = _pin_transform_redo_matrix(item.get(solver_name))
        if solver_matrix is not None and world_displacement is not None:
            solver_matrix.translation += world_displacement
        changed = _pin_keyboard_apply_contact_matrix(
            context,
            payload,
            desired_matrix,
            solver_matrix = solver_matrix,
            keep_attached = bool(item.get("keep_attached", False)),
            max_iterations = SURFACE_CONTACT_LIVE_SOLVER_ITERATIONS,
        ) or changed
        _pin_keyboard_commit_contact(
            context,
            payload,
            bool(item.get("keep_attached", False)),
        )
    if yellow_changed:
        _yellow_refresh_runtime(context)
    return changed


def _pin_transform_operator_execute_impl(operator, context):
    if operator.transform_mode != "TRANSLATE":
        _pin_transform_execute_pin_set(operator, context)
        return {"FINISHED"}
    values = tuple(operator.orientation_basis_values)
    orientation = (
        Matrix((values[0:3], values[3:6], values[6:9]))
        if len(values) == 9
        else Matrix.Identity(3)
    )
    world_displacement = orientation @ Vector(operator.displacement)
    armature = bpy.data.objects.get(operator.armature_name)
    if bool(operator.bone_only_contact):
        guide = bpy.data.objects.get(operator.contact_guide_name)
        if armature is None or guide is None:
            return {"CANCELLED"}
        try:
            matrices = json.loads(operator.redo_bones_json or "{}")
        except (TypeError, ValueError):
            matrices = {}
        for bone_name, packed in matrices.items():
            pose_bone = armature.pose.bones.get(bone_name)
            if pose_bone is None or len(packed) != 16:
                continue
            matrix = Matrix(tuple(
                tuple(float(packed[(row * 4) + column]) for column in range(4))
                for row in range(4)
            ))
            world_matrix = armature.matrix_world @ matrix
            world_matrix.translation += world_displacement
            pose_bone.matrix = armature.matrix_world.inverted_safe() @ world_matrix
        context.view_layer.update()
        detached = not _pin_contact_is_attached(context, guide)
        _surface_contact_enforce_guide(
            context,
            guide,
            force_contact = False,
            allow_snap = not detached,
            rotate_detached = True,
        )
        _surface_contact_store_persistent_pose_snapshots((guide,))
        return {"FINISHED"}

    candidate = Vector(operator.base_location) + world_displacement
    if operator.target_kind == "YELLOW":
        pose_bone = (
            armature.pose.bones.get(operator.target_bone_name)
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is None:
            return {"CANCELLED"}
        _yellow_set_pin_target(armature, pose_bone.name, candidate)
        _yellow_store_target_property(armature, pose_bone.name, candidate)
        _yellow_refresh_runtime(context)
        _pin_transform_execute_pin_set(
            operator,
            context,
            world_displacement,
            include_active = False,
            orientation = orientation,
        )
        return {"FINISHED"}

    guide = bpy.data.objects.get(operator.contact_guide_name)
    if guide is None:
        return {"CANCELLED"}
    surface = bpy.data.objects.get(operator.surface_name)
    if (
        surface is not None
        and str(guide.get(SURFACE_CONTACT_SURFACE_PROPERTY, "")) != surface.name
        and not _surface_contact_bind_guide_surface(
            context,
            guide,
            surface,
            candidate,
        )
    ):
        return {"CANCELLED"}
    if not _surface_contact_move_guide_world(
        context,
        guide,
        candidate,
        keep_attached = operator.contact_keep_attached,
    ):
        if (guide.matrix_world.translation - candidate).length > 1.0e-6:
            return {"CANCELLED"}
    _surface_contact_commit_target_key(
        context,
        guide,
        detached = not operator.contact_keep_attached,
    )
    _pin_transform_execute_pin_set(
        operator,
        context,
        world_displacement,
        include_active = False,
        orientation = orientation,
    )
    return {"FINISHED"}


def _pin_transform_operator_execute(operator, context):
    pin_selection = _pin_selection_runtime_snapshot()
    try:
        return _pin_transform_operator_execute_impl(operator, context)
    finally:
        _pin_selection_runtime_restore(context, pin_selection)
