"""Stable invocation snapshots for Pivot Direct/Inverse redo choices."""

from ..core.runtime import *  # noqa: F403


def _pin_pivot_matrix_values(matrix):
    return [float(value) for row in matrix for value in row]


def _pin_pivot_matrix(values):
    return Matrix(tuple(
        tuple(float(values[(row * 4) + column]) for column in range(4))
        for row in range(4)
    ))


def _pin_pivot_capture_bone_animation(armature, pose_bone, frame):
    animation_data = getattr(armature, "animation_data", None)
    action = getattr(animation_data, "action", None)
    path = pose_bone.path_from_id()
    curves = []
    keys = []
    for fcurve in _action_fcurves(action, armature):
        if not (
            fcurve.data_path == path
            or fcurve.data_path.startswith(path + ".")
            or fcurve.data_path.startswith(path + "[")
        ):
            continue
        curve_id = (str(fcurve.data_path), int(fcurve.array_index))
        curves.append(curve_id)
        for key in fcurve.keyframe_points:
            if abs(float(key.co.x) - float(frame)) > 1.0e-5:
                continue
            keys.append({
                "path": curve_id[0],
                "index": curve_id[1],
                "value": float(key.co.y),
                "interpolation": str(key.interpolation),
                "easing": str(key.easing),
                "handle_left_type": str(key.handle_left_type),
                "handle_right_type": str(key.handle_right_type),
                "handle_left": tuple(float(value) for value in key.handle_left),
                "handle_right": tuple(float(value) for value in key.handle_right),
            })
    return {
        "frame": float(frame),
        "curves": curves,
        "keys": keys,
    }


def _pin_pivot_restore_bone_animation(armature, pose_bone, snapshot):
    animation_data = getattr(armature, "animation_data", None)
    action = getattr(animation_data, "action", None)
    if action is None:
        return False
    frame = float(snapshot.get("frame", 0.0))
    path = pose_bone.path_from_id()
    original_curves = {
        (str(item[0]), int(item[1]))
        for item in snapshot.get("curves", ())
        if len(item) >= 2
    }
    changed = False
    current_curves = tuple(_action_fcurves(action, armature))
    for fcurve in current_curves:
        if not (
            fcurve.data_path == path
            or fcurve.data_path.startswith(path + ".")
            or fcurve.data_path.startswith(path + "[")
        ):
            continue
        for key in tuple(fcurve.keyframe_points):
            if abs(float(key.co.x) - frame) <= 1.0e-5:
                fcurve.keyframe_points.remove(key)
                changed = True
        curve_id = (str(fcurve.data_path), int(fcurve.array_index))
        if not fcurve.keyframe_points and curve_id not in original_curves:
            _action_remove_fcurve(action, fcurve)
        else:
            fcurve.update()
    for saved in snapshot.get("keys", ()):
        data_path = str(saved.get("path", ""))
        array_index = int(saved.get("index", 0))
        fcurve = next(
            (
                candidate
                for candidate in _action_fcurves(action, armature)
                if candidate.data_path == data_path
                and int(candidate.array_index) == array_index
            ),
            None,
        )
        if fcurve is None:
            fcurve = _action_new_fcurve(
                action,
                data_path,
                animated_id=armature,
                index=array_index,
            )
        key = fcurve.keyframe_points.insert(
            frame,
            float(saved.get("value", 0.0)),
        )
        for attribute in (
            "interpolation",
            "easing",
            "handle_left_type",
            "handle_right_type",
        ):
            value = saved.get(attribute)
            if value is not None:
                setattr(key, attribute, value)
        if len(saved.get("handle_left", ())) == 2:
            key.handle_left = saved["handle_left"]
        if len(saved.get("handle_right", ())) == 2:
            key.handle_right = saved["handle_right"]
        fcurve.update()
        changed = True
    return changed


def _pin_pivot_capture_initial(context, kind):
    bones = {}
    yellow_targets = {}
    animation = {}
    active_target = ""
    frame = float(context.scene.frame_current)
    if kind == "YELLOW":
        grouped = _selected_pose_bones_by_owner(
            context,
            include_active_fallback = True,
            include_virtual_pin = True,
        )
        for armature, pose_bones in grouped.items():
            fixed = _yellow_owner_map("yellow_fixed", armature)
            for pose_bone in pose_bones:
                key = f"{armature.name}\n{pose_bone.name}"
                bones[key] = _pin_pivot_matrix_values(
                    pose_bone.matrix_basis
                )
                animation[key] = _pin_pivot_capture_bone_animation(
                    armature,
                    pose_bone,
                    frame,
                )
                packed = fixed.get(pose_bone.name)
                if packed:
                    yellow_targets[key] = tuple(float(v) for v in packed[0])
        selected_target = _pin_virtual_selected_target_data(context)
        if selected_target is not None and selected_target[0] == "YELLOW":
            active_target = (
                f"{selected_target[1].name}\n{selected_target[2].name}"
            )
        else:
            active_bone = getattr(context, "active_pose_bone", None)
            for armature, pose_bones in grouped.items():
                if active_bone in pose_bones:
                    candidate = f"{armature.name}\n{active_bone.name}"
                    if candidate in yellow_targets:
                        active_target = candidate
                        break
            if not active_target and len(yellow_targets) == 1:
                active_target = next(iter(yellow_targets))
    else:
        guides = _surface_contact_selected_guides(
            context,
            active_only = True,
        )
        selected_target = _pin_virtual_selected_target_data(context)
        if selected_target is not None and selected_target[0] == "CONTACT":
            active_target = f"CONTACT\n{selected_target[3].name}"
        elif len(guides) == 1:
            active_target = f"CONTACT\n{guides[0].name}"
        for guide in guides:
            armature, pose_bone = _surface_contact_pose_bone(guide)
            if armature is None or pose_bone is None:
                continue
            key = f"{armature.name}\n{pose_bone.name}"
            bones[key] = _pin_pivot_matrix_values(
                pose_bone.matrix_basis
            )
            animation[key] = _pin_pivot_capture_bone_animation(
                armature,
                pose_bone,
                frame,
            )
    return json.dumps({
        "bones": bones,
        "yellow_targets": yellow_targets,
        "animation": animation,
        "active_target": active_target,
    })


def _pin_pivot_restore_initial(context, packed):
    if not packed:
        return False
    try:
        state = json.loads(packed)
    except (TypeError, ValueError):
        return False
    changed = False
    animation = dict(state.get("animation", {}))
    for key, snapshot in animation.items():
        armature_name, separator, bone_name = str(key).partition("\n")
        armature = bpy.data.objects.get(armature_name)
        pose_bone = (
            armature.pose.bones.get(bone_name)
            if separator
            and armature is not None
            and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is not None:
            changed = _pin_pivot_restore_bone_animation(
                armature,
                pose_bone,
                snapshot,
            ) or changed
    for key, values in dict(state.get("bones", {})).items():
        armature_name, separator, bone_name = str(key).partition("\n")
        armature = bpy.data.objects.get(armature_name)
        pose_bone = (
            armature.pose.bones.get(bone_name)
            if separator
            and armature is not None
            and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is None or len(values) != 16:
            continue
        matrix = _pin_pivot_matrix(values)
        if _pin_keyboard_matrices_differ(
            pose_bone.matrix_basis,
            matrix,
        ):
            pose_bone.matrix_basis = matrix
            changed = True
    if changed:
        context.view_layer.update()
    for key, point in dict(state.get("yellow_targets", {})).items():
        armature_name, separator, bone_name = str(key).partition("\n")
        armature = bpy.data.objects.get(armature_name)
        if not separator or armature is None or len(point) != 3:
            continue
        changed = _yellow_set_pin_target(
            armature,
            bone_name,
            Vector(point),
        ) or changed
        _yellow_store_target_property(
            armature,
            bone_name,
            Vector(point),
        )
    return changed


def _yellow_inverse_pivot_target(context, initial_state_json=""):
    target_data = _pin_virtual_selected_target_data(context)
    if target_data is not None and target_data[0] == "YELLOW":
        return target_data
    grouped = _selected_pose_bones_by_owner(
        context,
        include_active_fallback = True,
    )
    candidates = []
    active_bone = getattr(context, "active_pose_bone", None)
    for armature, pose_bones in grouped.items():
        fixed = _yellow_owner_map("yellow_fixed", armature)
        for pose_bone in pose_bones:
            packed = fixed.get(pose_bone.name)
            if packed:
                candidate = ("YELLOW", armature, pose_bone, packed)
                if pose_bone == active_bone:
                    return candidate
                candidates.append(candidate)
    if len(candidates) == 1:
        return candidates[0]
    try:
        active_target = str(
            json.loads(initial_state_json).get("active_target", "")
        )
    except (TypeError, ValueError):
        active_target = ""
    armature_name, separator, bone_name = active_target.partition("\n")
    armature = bpy.data.objects.get(armature_name) if separator else None
    pose_bone = (
        armature.pose.bones.get(bone_name)
        if armature is not None and getattr(armature, "pose", None)
        else None
    )
    packed = (
        _yellow_owner_map("yellow_fixed", armature).get(bone_name)
        if pose_bone is not None
        else None
    )
    return (
        ("YELLOW", armature, pose_bone, packed)
        if packed is not None
        else None
    )


def _yellow_inverse_pivot(context, target_data):
    _kind, armature, pose_bone, packed = target_data
    depsgraph = context.evaluated_depsgraph_get()
    evaluated_armature = armature.evaluated_get(depsgraph)
    evaluated_bone = evaluated_armature.pose.bones.get(pose_bone.name)
    if evaluated_bone is None:
        return False
    connected_point = _yellow_current_world_point(
        depsgraph,
        evaluated_armature,
        evaluated_bone,
        packed,
    )
    if connected_point is None:
        return False
    _yellow_set_pin_target(armature, pose_bone.name, connected_point)
    _yellow_store_target_property(
        armature,
        pose_bone.name,
        connected_point,
    )
    return True
