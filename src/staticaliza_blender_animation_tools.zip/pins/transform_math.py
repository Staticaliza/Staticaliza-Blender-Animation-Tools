"""Pin transform pivot, orientation, and pose-lock helpers."""

from ..core.runtime import *  # noqa: F403

def _pin_keyboard_target_matrix(target_data):
    if target_data is None:
        return None
    kind, armature, pose_bone, payload = target_data
    if kind == "CONTACT":
        return payload.matrix_world.copy()
    matrix = (
        (armature.matrix_world @ pose_bone.matrix).normalized()
        if armature is not None and pose_bone is not None
        else Matrix.Identity(4)
    )
    matrix.translation = Vector(payload[0])
    return matrix


def _pin_keyboard_orientation_matrix(context, target_data, pin_matrix):
    return _pin_transform_orientation_matrix(
        context,
        target_data,
        pin_matrix,
    )


def _pin_keyboard_view_axis(context):
    region_data = getattr(context, "region_data", None)
    if region_data is None:
        return Vector((0.0, 0.0, 1.0))
    axis = region_data.view_matrix.inverted_safe().to_3x3() @ Vector(
        (0.0, 0.0, 1.0)
    )
    return axis.normalized() if axis.length_squared > 1.0e-12 else Vector(
        (0.0, 0.0, 1.0)
    )


def _pin_keyboard_pivot(
    context,
    pin_matrix,
    armature,
    bone_states,
    pin_points = None,
    pin_targets = None,
    bone_targets = None,
):
    part_pivot_mode = bool(
        getattr(
            getattr(context, "window_manager", None),
            "staticaliza_pivot_mode",
            "BONE",
        ) == "PART"
    )
    if part_pivot_mode:
        # Resolve Object pivot independently for every selected pin/bone.
        # The generic sync path is active-element based and may legitimately
        # search the rest of the rig; using it for a group can therefore land
        # the handle on an unrelated parent bone's welded object.
        object_points = []
        seen_targets = set()
        explicit_pin_targets = tuple(pin_targets or ())
        if not explicit_pin_targets:
            explicit_pin_targets = tuple(
                target_data
                for _target_key, target_data
                in _pin_selected_targets_data(context)
            )
        for target_data in explicit_pin_targets:
            try:
                _kind, target_armature, pose_bone, _payload = target_data
                target_key = _owner_bone_key(
                    target_armature,
                    pose_bone.name,
                )
                if target_key in seen_targets:
                    continue
                point = _part_pivot_bone_object_world_center(
                    context,
                    target_armature,
                    pose_bone,
                )
            except (
                AttributeError,
                ReferenceError,
                RuntimeError,
                TypeError,
                ValueError,
            ):
                point = None
                target_key = None
            if point is None:
                matrix = _pin_keyboard_target_matrix(target_data)
                point = (
                    matrix.translation.copy()
                    if matrix is not None
                    else None
                )
            if point is None:
                continue
            object_points.append(point)
            if target_key is not None:
                seen_targets.add(target_key)
        for target_armature, pose_bone in tuple(bone_targets or ()):
            try:
                target_key = _owner_bone_key(
                    target_armature,
                    pose_bone.name,
                )
                if target_key in seen_targets:
                    continue
                point = _part_pivot_bone_object_world_center(
                    context,
                    target_armature,
                    pose_bone,
                )
            except (
                AttributeError,
                ReferenceError,
                RuntimeError,
                TypeError,
                ValueError,
            ):
                point = None
            if point is None:
                try:
                    point = (
                        target_armature.matrix_world @ pose_bone.matrix
                    ).translation
                except (
                    AttributeError,
                    ReferenceError,
                    RuntimeError,
                    TypeError,
                    ValueError,
                ):
                    point = None
            if point is None:
                continue
            object_points.append(point)
        if object_points:
            return (
                sum(object_points, Vector((0.0, 0.0, 0.0)))
                / len(object_points),
                False,
            )
        # No exact welded-object match: use the selected elements themselves,
        # never a different bone discovered by the rig-wide fallback search.
    pivot_mode = str(context.scene.tool_settings.transform_pivot_point)
    if part_pivot_mode:
        pivot_mode = "MEDIAN_POINT"
    pin_point = pin_matrix.translation.copy()
    if pivot_mode == "CURSOR":
        return context.scene.cursor.location.copy(), False
    if pivot_mode in {"ACTIVE_ELEMENT", "INDIVIDUAL_ORIGINS"}:
        return pin_point, pivot_mode == "INDIVIDUAL_ORIGINS"

    points = [
        Vector(point)
        for point in (pin_points or (pin_point,))
    ]
    for state in bone_states.values():
        points.append((armature.matrix_world @ state["matrix"]).translation)
    if pivot_mode == "BOUNDING_BOX_CENTER" and points:
        lower = Vector((
            min(point.x for point in points),
            min(point.y for point in points),
            min(point.z for point in points),
        ))
        upper = Vector((
            max(point.x for point in points),
            max(point.y for point in points),
            max(point.z for point in points),
        ))
        return (lower + upper) * 0.5, False
    return sum(points, Vector((0.0, 0.0, 0.0))) / len(points), False


def _pin_keyboard_around_origin(core_matrix, origin):
    return (
        Matrix.Translation(Vector(origin))
        @ core_matrix
        @ Matrix.Translation(-Vector(origin))
    )


def _pin_transform_sample_signature(operator, core_matrix):
    """Deduplicate Blender modal events that carry an identical transform."""
    return (
        str(getattr(operator, "transform_mode", "")),
        int(getattr(operator, "axis_index", -1)),
        int(getattr(operator, "plane_axis_index", -1)),
        *tuple(round(float(value), 9) for row in core_matrix for value in row),
    )


def _pin_transform_position_matrix(transform_mode, initial_matrix, delta):
    """Transform a pin's position without rotating/scaling its orientation."""
    if initial_matrix is None:
        return None
    transformed = delta @ initial_matrix
    if transform_mode not in {"ROTATE", "SCALE"}:
        return transformed
    position = transformed.translation.copy()
    transformed = initial_matrix.copy()
    transformed.translation = position
    return transformed



def _pin_keyboard_matrices_differ(first, second, epsilon = 1.0e-7):
    if first is None or second is None:
        return first is not second
    return any(
        abs(float(first[row][column]) - float(second[row][column])) > epsilon
        for row in range(4)
        for column in range(4)
    )


def _pin_restore_contact_detached_state(guide, existed, detached):
    _surface_contact_set_snap_detached(guide, bool(detached))
    if existed:
        guide[SURFACE_CONTACT_DETACHED_PROPERTY] = 1.0 if detached else 0.0
    elif SURFACE_CONTACT_DETACHED_PROPERTY in guide:
        del guide[SURFACE_CONTACT_DETACHED_PROPERTY]


def _pin_contact_is_attached(context, guide):
    # A pressure pivot can intentionally lift the real pink endpoint after
    # the imaginary top endpoint becomes the surface pivot.  Endpoint
    # distance is therefore not the attachment state.  An explicitly saved
    # attached value remains authoritative until the user actually pulls out.
    if (
        SURFACE_CONTACT_DETACHED_PROPERTY in guide
        and not bool(guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False))
    ):
        return True
    snap_key = _surface_contact_snap_key(guide)
    if (
        snap_key in _state.setdefault("pin_snap_latches", set())
        and snap_key not in _state.setdefault("pin_snap_detached", set())
        and snap_key not in _state.setdefault(
            "pin_snap_transform_releasing", set()
        )
        and (
            _state.get("pin_snap_transform_active", False)
            or snap_key in _state.setdefault(
                "pin_snap_pressure_active", set()
            )
        )
    ):
        # During the working top-pivot pressure phase the bottom dot may be
        # visibly separated, but the semantic snap remains active. Torso and
        # later transforms must not reinterpret that distance as an unsnap.
        return True
    target, _normal, anchor = _surface_contact_world_point_normal(
        context,
        guide,
    )
    return bool(
        target is not None
        and anchor is not None
        and _pin_points_within_snap_radius(context, target, anchor)
    )


def _pin_keyboard_apply_contact_matrix(
    context,
    guide,
    desired_matrix,
    solver_matrix = None,
    keep_attached = None,
    max_iterations = SURFACE_CONTACT_FINAL_SOLVER_ITERATIONS,
):
    rotate_pose = not _surface_contact_preserves_rigid_orientation(guide)
    projected = _surface_contact_bound_surface_point(
        context,
        guide,
        desired_matrix.translation,
    )
    if projected is None:
        return False
    point, normal = projected
    if (
        str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
        == SURFACE_CONTACT_KIND_SIMULATED
    ):
        point = _surface_contact_clamp_target_before_limb(
            context,
            guide,
            guide.matrix_world.translation,
            point,
        )
    if not _surface_contact_set_guide_surface_point(
        context,
        guide,
        point,
        normal,
        update_view_layer=False,
    ):
        return False
    if keep_attached:
        _surface_contact_clear_snap_departure(guide)
        _surface_contact_solve_target(
            context,
            guide,
            solver_matrix = solver_matrix,
            max_iterations = max_iterations,
            rotate_pose = rotate_pose,
        )
    else:
        _surface_contact_set_snap_detached(guide, True)
        if _surface_contact_settle_detached_smart(context, guide) is None:
            _surface_contact_enforce_guide(
                context,
                guide,
                force_contact = False,
                allow_snap = False,
                rotate_detached = rotate_pose,
                rotate_snap = rotate_pose,
            )
    return True


def _pin_keyboard_commit_contact(context, guide, keep_attached):
    if keep_attached:
        _surface_contact_solve_target(
            context,
            guide,
            max_iterations = SURFACE_CONTACT_FINAL_SOLVER_ITERATIONS,
            rotate_pose = not _surface_contact_preserves_rigid_orientation(
                guide
            ),
        )
    _surface_contact_commit_target_key(
        context,
        guide,
        detached = not keep_attached,
    )


def _pin_keyboard_apply_pose_locks(pose_bone, state, transform_mode):
    if transform_mode == "TRANSLATE":
        for index, locked in enumerate(tuple(pose_bone.lock_location[:3])):
            if locked:
                pose_bone.location[index] = state["location"][index]
    elif transform_mode == "SCALE":
        for index, locked in enumerate(tuple(pose_bone.lock_scale[:3])):
            if locked:
                pose_bone.scale[index] = state["scale"][index]
    elif transform_mode == "ROTATE":
        locked_axes = tuple(bool(value) for value in pose_bone.lock_rotation[:3])
        if pose_bone.rotation_mode == "QUATERNION":
            current = pose_bone.rotation_quaternion.copy()
            initial = state["rotation_quaternion"].copy()
            if bool(getattr(pose_bone, "lock_rotations_4d", False)):
                if bool(getattr(pose_bone, "lock_rotation_w", False)):
                    current.w = initial.w
                for index, locked in enumerate(locked_axes):
                    if locked:
                        current[index + 1] = initial[index + 1]
                if sum(float(value) * float(value) for value in current) > 1.0e-12:
                    current.normalize()
                pose_bone.rotation_quaternion = current
            elif any(locked_axes):
                initial_euler = initial.to_euler("XYZ")
                current_euler = current.to_euler("XYZ", initial_euler)
                for index, locked in enumerate(locked_axes):
                    if locked:
                        current_euler[index] = initial_euler[index]
                pose_bone.rotation_quaternion = current_euler.to_quaternion()
        elif pose_bone.rotation_mode == "AXIS_ANGLE":
            current_values = list(pose_bone.rotation_axis_angle)
            initial_values = state["rotation_axis_angle"]
            if bool(getattr(pose_bone, "lock_rotations_4d", False)):
                if bool(getattr(pose_bone, "lock_rotation_w", False)):
                    current_values[0] = initial_values[0]
                for index, locked in enumerate(locked_axes):
                    if locked:
                        current_values[index + 1] = initial_values[index + 1]
                pose_bone.rotation_axis_angle = current_values
            elif any(locked_axes):
                current_axis = Vector(current_values[1:4])
                initial_axis = Vector(initial_values[1:4])
                if current_axis.length_squared <= 1.0e-12:
                    current_axis = Vector((0.0, 1.0, 0.0))
                if initial_axis.length_squared <= 1.0e-12:
                    initial_axis = Vector((0.0, 1.0, 0.0))
                current = Quaternion(current_axis.normalized(), current_values[0])
                initial = Quaternion(initial_axis.normalized(), initial_values[0])
                initial_euler = initial.to_euler("XYZ")
                current_euler = current.to_euler("XYZ", initial_euler)
                for index, locked in enumerate(locked_axes):
                    if locked:
                        current_euler[index] = initial_euler[index]
                locked_quaternion = current_euler.to_quaternion()
                pose_bone.rotation_axis_angle = (
                    locked_quaternion.angle,
                    *locked_quaternion.axis,
                )
        else:
            for index, locked in enumerate(locked_axes):
                if locked:
                    pose_bone.rotation_euler[index] = state["rotation_euler"][index]
