"""Virtual pin selection and gizmo interaction state."""

from ..core.runtime import *  # noqa: F403

def _pin_gizmo_group(gizmo):
    try:
        return gizmo.group
    except (AttributeError, ReferenceError, RuntimeError):
        return None

def _pin_gizmo_set_if_changed(gizmo, property_name, value):
    """Avoid dirtying Blender's shared gizmo map with identical RNA writes."""
    try:
        current = getattr(gizmo, property_name)
        if isinstance(value, Matrix):
            unchanged = all(
                abs(float(current[row][column]) - float(value[row][column]))
                <= 1.0e-7
                for row in range(4)
                for column in range(4)
            )
        elif isinstance(value, float):
            unchanged = abs(float(current) - value) <= 1.0e-10
        else:
            unchanged = current == value
        if unchanged:
            return False
        setattr(gizmo, property_name, value)
        return True
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return False


def _pin_gizmo_update_hover_cursor(context, gizmo):
    """Use the move cursor while a visible pin diamond is highlighted."""
    now = time.perf_counter()
    hovered = bool(
        gizmo is not None
        and getattr(gizmo, "is_highlight", False)
        and not getattr(gizmo, "hide", True)
        and not getattr(gizmo, "hide_select", True)
    )
    hover_map = _state.setdefault("pin_gizmo_hover_cursor", {})
    key = id(gizmo) if gizmo is not None else 0
    if hovered:
        hover_map[key] = now + 0.12
    else:
        hover_map.pop(key, None)
    for stale_key, expires in tuple(hover_map.items()):
        if float(expires) < now:
            hover_map.pop(stale_key, None)
    active = bool(hover_map)
    if bool(_state.get("pin_gizmo_hover_cursor_active", False)) == active:
        return active
    window = getattr(context, "window", None)
    if window is None:
        return active
    try:
        window.cursor_set("SCROLL_XY" if active else "DEFAULT")
        _state["pin_gizmo_hover_cursor_active"] = active
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        pass
    return active

def _pin_gizmo_stable_target_mapping(group, target_keys):
    """Keep each live pin bound to the same pooled Gizmo across redraws."""
    target_keys = {str(key) for key in target_keys}
    pool = tuple(getattr(group, "target_gizmo_pool", ()))
    pool_ids = {id(gizmo) for gizmo in pool}
    retained = {
        str(key): gizmo
        for key, gizmo in dict(
            getattr(group, "target_gizmos", {})
        ).items()
        if str(key) in target_keys and id(gizmo) in pool_ids
    }
    used_ids = {id(gizmo) for gizmo in retained.values()}
    free_gizmos = [gizmo for gizmo in pool if id(gizmo) not in used_ids]
    for target_key in sorted(target_keys):
        if target_key in retained or not free_gizmos:
            continue
        retained[target_key] = free_gizmos.pop(0)
    group.target_gizmos = retained
    return retained

def _pin_gizmo_ensure_target_pool(
    group,
    required_count,
    gizmo_type,
    color,
    color_highlight,
):
    """Grow a center-gizmo pool on demand without rebinding live targets."""
    pool = group.target_gizmo_pool
    target_size = max(PIN_GIZMO_TARGET_POOL_SIZE, int(required_count))
    while len(pool) < target_size:
        gizmo = group.gizmos.new(gizmo_type)
        gizmo.axis_index = -1
        gizmo.color = color
        gizmo.color_highlight = color_highlight
        # Make the center visibly light up both while hovered and throughout
        # its modal drag; normal pin transparency remains unchanged.
        gizmo.alpha_highlight = 1.0
        # The diamond shares its origin with all three arrows. A small positive
        # depth bias makes an exact-center hit choose free drag while leaving
        # the surrounding arrow shafts fully selectable.
        gizmo.select_bias = PIN_GIZMO_CENTER_SELECT_BIAS
        gizmo.use_draw_modal = True
        # Passive centers must not retain stale ownership over native events.
        gizmo.use_event_handle_all = False
        gizmo.hide = True
        gizmo.hide_select = True
        pool.append(gizmo)
    return pool


def _pin_available_target_data(context):
    """Return every pin that can be selected in the current Pose viewport."""
    if context is None or getattr(context, "mode", "") != "POSE":
        return {}
    armatures = _pose_scope_armatures(context)
    if not armatures:
        return {}

    targets = {}
    frame = int(context.scene.frame_current)
    armatures_by_name = {armature.name: armature for armature in armatures}
    selected_owner_bones = _selected_owner_bone_keys(context)
    selected_pin_keys = _pin_selected_target_keys()
    for guide in _surface_contact_guides():
        armature = armatures_by_name.get(
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
        )
        if armature is None or not _surface_contact_guide_active_at(guide, frame):
            continue
        pose_bone = armature.pose.bones.get(
            str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
        )
        if pose_bone is None:
            continue
        key = _surface_contact_snap_key(guide)
        targets[key] = ("CONTACT", armature, pose_bone, guide)

    for armature in armatures:
        if _yellow_owner_hidden(armature):
            continue
        for bone_name, packed in _yellow_owner_map(
            "yellow_fixed",
            armature,
        ).items():
            pose_bone = armature.pose.bones.get(str(bone_name))
            if pose_bone is None or not packed:
                continue
            key = (
                f"YELLOW:{_armature_session_uid(armature)}:"
                f"{pose_bone.name}"
            )
            targets[key] = ("YELLOW", armature, pose_bone, packed)
    # One selected pin opens the complete cross-color pin selection scope.
    # The scope closes only when the selected-pin set becomes empty.
    if selected_pin_keys:
        return targets
    allowed_owner_bones = set(selected_owner_bones)
    return {
        key: data
        for key, data in targets.items()
        if _owner_bone_key(data[1], data[2].name) in allowed_owner_bones
    }


def _pin_gizmo_refresh_availability(context):
    try:
        kinds = frozenset(
            target_data[0]
            for target_data in _pin_available_target_data(context).values()
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        kinds = frozenset()
    _state["pin_gizmo_available_kinds"] = kinds
    return kinds


def _pin_deferred_contact_action_group_selection():
    _state["pin_contact_channel_selection_pending"] = False
    try:
        _pin_select_contact_action_groups(
            bpy.context,
            defer = False,
            exclusive = bool(
                _state.get("pin_contact_channel_selection_exclusive", False)
            ),
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        pass
    return None


def _pin_sync_contact_graph_filter(context, _wanted_by_armature):
    window_manager = getattr(context, "window_manager", None)
    for window in getattr(window_manager, "windows", ()):
        screen = getattr(window, "screen", None)
        for area in getattr(screen, "areas", ()):
            if area.type != "GRAPH_EDITOR":
                continue
            try:
                area.tag_redraw()
            except (
                AttributeError,
                ReferenceError,
                RuntimeError,
                TypeError,
                ValueError,
            ):
                pass


def _pin_select_contact_action_groups(
    context,
    defer = True,
    exclusive = False,
):
    previous_syncing = bool(_state.get("pin_selection_syncing", False))
    _state["pin_selection_syncing"] = True
    try:
        return _pin_select_contact_action_groups_impl(
            context,
            defer = defer,
            exclusive = exclusive,
        )
    finally:
        _state["pin_selection_syncing"] = previous_syncing


def _pin_select_contact_action_groups_impl(
    context,
    defer = True,
    exclusive = False,
):
    """Mirror selected pink pins into their Surface Contact channels."""
    wanted_by_armature = {}
    for _target_key, target_data in _pin_selected_targets_data(context):
        if target_data[0] != "CONTACT":
            continue
        armature = target_data[1]
        guide = target_data[3]
        bone_name = str(
            guide.get(
                SURFACE_CONTACT_BONE_PROPERTY,
                target_data[2].name,
            )
        )
        wanted_by_armature.setdefault(armature, set()).add(
            f"Surface Contact ({bone_name})"
        )
    changed = False
    armatures = list(_pose_scope_armatures(context))
    for armature in wanted_by_armature:
        if armature not in armatures:
            armatures.append(armature)
    for armature in armatures:
        wanted_names = wanted_by_armature.get(armature, set())
        action = getattr(
            getattr(armature, "animation_data", None),
            "action",
            None,
        )
        for groups in _action_group_owners(action, armature):
            for group in groups:
                is_contact_group = str(group.name).startswith("Surface Contact (")
                if not exclusive and not is_contact_group:
                    continue
                selected = str(group.name) in wanted_names
                if bool(group.select) != selected:
                    group.select = selected
                    changed = True
                if is_contact_group and selected:
                    try:
                        if bool(group.show_expanded):
                            group.show_expanded = False
                            changed = True
                        if not bool(group.show_expanded_graph):
                            group.show_expanded_graph = True
                            changed = True
                    except (
                        AttributeError,
                        ReferenceError,
                        RuntimeError,
                        TypeError,
                        ValueError,
                    ):
                        pass
                for fcurve in group.channels:
                    curve_selected = selected if (exclusive or is_contact_group) else bool(fcurve.select)
                    if is_contact_group and selected and bool(fcurve.hide):
                        fcurve.hide = False
                        changed = True
                    if bool(fcurve.select) != curve_selected:
                        fcurve.select = curve_selected
                        changed = True
    _pin_sync_contact_graph_filter(context, wanted_by_armature)
    if changed:
        window_manager = getattr(context, "window_manager", None)
        for window in getattr(window_manager, "windows", ()):
            for area in getattr(window.screen, "areas", ()):
                if area.type in {"DOPESHEET_EDITOR", "GRAPH_EDITOR"}:
                    area.tag_redraw()
    # The gizmo press is dispatched after this callback and Blender can apply
    # its own channel/key selection afterwards. Re-apply the channel selection
    # once the press has completed so the group row remains highlighted, just
    # like selecting a bone in the Dope Sheet.
    if defer and not _state.get("pin_contact_channel_selection_pending", False):
        _state["pin_contact_channel_selection_exclusive"] = bool(exclusive)
        _state["pin_contact_channel_selection_pending"] = True
        try:
            bpy.app.timers.register(
                _pin_deferred_contact_action_group_selection,
                first_interval = 0.02,
            )
        except (AttributeError, RuntimeError, TypeError, ValueError):
            _state["pin_contact_channel_selection_pending"] = False
    return changed


def _pin_selected_target_key(context = None, validate = False):
    key = str(_state.get("pin_gizmo_selected_key", ""))
    if key and validate and key not in _pin_available_target_data(context):
        return ""
    return key


def _pin_selected_target_keys():
    """Return the selected-pin set while honoring legacy active-key writes."""
    active_key = str(_state.get("pin_gizmo_selected_key", ""))
    recorded_active = str(
        _state.get("pin_gizmo_selected_keys_active", "")
    )
    selected_keys = {
        str(key)
        for key in _state.get("pin_gizmo_selected_keys", set())
        if str(key)
    }
    if active_key != recorded_active:
        # Tests, reload migration, and older runtime paths may still write the
        # singular key directly. Treat that as an intentional replacement.
        selected_keys = {active_key} if active_key else set()
        _state["pin_gizmo_selected_keys"] = selected_keys
        _state["pin_gizmo_selected_keys_active"] = active_key
    elif active_key:
        selected_keys.add(active_key)
    else:
        selected_keys.clear()
    _state["pin_gizmo_selected_keys"] = set(selected_keys)
    return frozenset(selected_keys)
def _pin_selected_target_data(context):
    key = _pin_selected_target_key()
    targets = _pin_available_target_data(context)
    cached = _state.setdefault("pin_selected_target_data", {})
    return key, targets.get(key) or cached.get(key)
def _pin_selected_targets_data(context):
    targets = _pin_available_target_data(context)
    cached = _state.setdefault("pin_selected_target_data", {})
    selected_keys = _pin_selected_target_keys()
    active_key = _pin_selected_target_key()
    ordered_keys = (
        ((active_key,) if active_key in selected_keys else ())
        + tuple(sorted(selected_keys - {active_key}))
    )
    return tuple(
        (key, targets.get(key) or cached.get(key))
        for key in ordered_keys
        if targets.get(key) is not None or cached.get(key) is not None
    )


def _pin_selection_runtime_snapshot():
    return {
        "active": _pin_selected_target_key(),
        "selected": set(_pin_selected_target_keys()),
    }


def _pin_selection_history_store(context = None, snapshot = None, push = False):
    context = context or bpy.context
    snapshot = snapshot or _pin_selection_runtime_snapshot()
    snapshot = {
        "active": str(snapshot.get("active", "")),
        "selected": {
            str(key) for key in snapshot.get("selected", set())
        },
    }
    previous = _state.get("pin_selection_runtime_history")
    _state["pin_selection_runtime_history"] = snapshot
    # Virtual pin selection is transient UI state. Writing it onto Scene
    # creates an undoable ID-property edit even without undo_push(), leaving a
    # phantom Ctrl+Z between ordinary pose transforms.
    del context, push
    return previous != snapshot


def _pin_selection_history_load(context):
    scene = getattr(context, "scene", None)
    packed = (
        scene.get(PIN_SELECTION_HISTORY_PROPERTY)
        if scene is not None
        else None
    )
    if packed is None:
        return None
    try:
        snapshot = json.loads(str(packed))
    except (TypeError, ValueError):
        return None
    return {
        "active": str(snapshot.get("active", "")),
        "selected": set(
            str(key) for key in snapshot.get("selected", ())
        ),
    }


def _pin_selection_runtime_restore(context, snapshot):
    """Restore virtual selection after a non-selection UI operation."""
    selected_keys = set((snapshot or {}).get("selected", set()))
    active_key = str((snapshot or {}).get("active", ""))
    if not selected_keys:
        _state["pin_gizmo_selected_key"] = ""
        _state["pin_gizmo_selected_keys"] = set()
        _state["pin_gizmo_selected_keys_active"] = ""
        _state["pin_gizmo_axes_visible"] = {}
        _state["pin_gizmo_selection_keys"] = ()
        _state["pin_gizmo_pending_click"] = None
        _state["pin_pointer_pending_click"] = None
        _pin_selection_history_store(
            context,
            {"active": "", "selected": set()},
        )
        _tag_redraw_all_view3d()
        return frozenset()
    _state["pin_gizmo_selected_key"] = active_key
    _state["pin_gizmo_selected_keys"] = selected_keys
    _state["pin_gizmo_selected_keys_active"] = active_key
    available_keys = set(_pin_available_target_data(context))
    selected_keys &= available_keys
    if active_key not in selected_keys:
        active_key = next(iter(sorted(selected_keys)), "")
    _state["pin_gizmo_selected_key"] = active_key
    _state["pin_gizmo_selected_keys"] = selected_keys
    _state["pin_gizmo_selected_keys_active"] = active_key
    _state["pin_gizmo_pending_click"] = None
    _state["pin_pointer_pending_click"] = None
    _state["pin_gizmo_selection_keys"] = (
        _pin_pose_selection_signature(context) if active_key else ()
    )
    _state["pin_gizmo_extend_selection_until"] = (
        time.perf_counter() + 0.25 if active_key else 0.0
    )
    _pin_selection_history_store(context)
    _tag_redraw_all_view3d()
    return frozenset(selected_keys)


def _pin_modal_target_data(operator, context):
    """Reuse stable pin references for one modal transform interaction."""
    cached = getattr(operator, "_target_data_cache", None)
    if cached is not None:
        try:
            kind, armature, pose_bone, payload = cached
            valid = bool(
                armature is not None
                and armature.name
                == str(getattr(operator, "armature_name", ""))
                and (
                    (
                        kind == "YELLOW"
                        and pose_bone is not None
                        and pose_bone.name
                        == str(getattr(operator, "target_bone_name", ""))
                    )
                    or (
                        kind == "CONTACT"
                        and payload is not None
                        and payload.name
                        == str(getattr(operator, "contact_guide_name", ""))
                    )
                )
            )
            if valid:
                return cached
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            pass

    target_data = _pin_available_target_data(context).get(operator.target_key)
    operator._target_data_cache = target_data
    return target_data


def _pin_target_locked_axes(target_data):
    pose_bone = target_data[2] if target_data else None
    if pose_bone is None:
        return (False, False, False)
    try:
        return tuple(bool(value) for value in pose_bone.lock_location[:3])
    except (AttributeError, ReferenceError, TypeError, ValueError):
        return (False, False, False)


def _pin_pose_selection_signature(context):
    armatures = _pose_scope_armatures(context)
    if not armatures:
        return ((), (), (0, ""))
    selected_names = tuple(sorted(_selected_owner_bone_keys(context)))
    active = getattr(context, "active_pose_bone", None)
    active_armature = _pose_bone_owner(context, active, armatures)
    active_key = (
        _owner_bone_key(active_armature, active.name)
        if active is not None and active_armature is not None
        else (0, "")
    )
    return (
        tuple(sorted(_armature_session_uid(armature) for armature in armatures)),
        selected_names,
        active_key,
    )


def _pin_shift_modifier_pressed():
    """Read Shift without putting a Python operator on Blender's mouse path.

    Blender does not expose the current modifier state outside an event
    callback. On Windows, GetAsyncKeyState also reports a Shift press that
    happened since the preceding call, so a quick Shift-click is still seen
    when the selection timer runs after Blender finishes selecting the bone.
    """
    if os.name != "nt":
        return False
    try:
        import ctypes

        state = int(ctypes.windll.user32.GetAsyncKeyState(0x10))
    except (AttributeError, OSError, TypeError, ValueError):
        return False
    return bool(state & 0x8001)


def _pin_primary_mouse_pressed():
    """Read LMB without adding a Python operator to Blender's press keymap."""
    if os.name != "nt":
        return False
    try:
        import ctypes

        return bool(int(ctypes.windll.user32.GetAsyncKeyState(0x01)) & 0x8000)
    except (AttributeError, OSError, TypeError, ValueError):
        return False


def _pin_preserve_extended_pose_selection(
    saved_signature,
    current_signature,
    shift_pressed,
):
    """Keep a virtual pin selected while Shift changes bone selection."""
    return bool(
        saved_signature
        and current_signature != saved_signature
        and shift_pressed
    )


def _pin_deselect_pose_bones(context):
    """Clear native pose selection and its active-bone hover/gizmo context."""
    changed = False
    for armature in _pose_scope_armatures(context):
        armature_data = getattr(armature, "data", None)
        pose = getattr(armature, "pose", None)
        for pose_bone in getattr(pose, "bones", ()):
            bone = getattr(pose_bone, "bone", None)
            try:
                if hasattr(pose_bone, "select"):
                    if pose_bone.select:
                        changed = True
                    pose_bone.select = False
                elif bone is not None:
                    if bone.select or bone.select_head or bone.select_tail:
                        changed = True
                    bone.select = False
                    bone.select_head = False
                    bone.select_tail = False
            except (AttributeError, ReferenceError, RuntimeError):
                pass
        try:
            if armature_data is not None and armature_data.bones.active is not None:
                armature_data.bones.active = None
                changed = True
        except (AttributeError, ReferenceError, RuntimeError):
            pass
    if changed:
        try:
            context.view_layer.update()
        except (AttributeError, ReferenceError, RuntimeError):
            pass
    return changed


def _pin_select_target(
    context,
    target_key,
    extend = False,
    defer_pose_selection = False,
    target_data_override = None,
):
    target_key = str(target_key)
    target_data = _pin_available_target_data(context).get(target_key)
    if target_data is None and target_data_override is not None:
        # The passive pixel-overlay picker snapshots its target before
        # Blender's underlying click selection runs. A background click can
        # deselect the owner bone before mouse release, but the pin click must
        # still win. The selected key immediately restores normal validation.
        target_data = target_data_override
    if target_data is None:
        return False
    if target_data[0] == "YELLOW":
        _state.setdefault("pin_yellow_history_fallbacks", {})[
            _owner_bone_key(target_data[1], target_data[2].name)
        ] = tuple(float(value) for value in Vector(target_data[3][0]))
        try:
            yellow_mode = int(
                target_data[2].get(YELLOW_PIN_MODE_PROPERTY, 3)
            )
        except (TypeError, ValueError):
            yellow_mode = 3
        yellow_mode = 3 if yellow_mode == 5 else max(1, min(4, yellow_mode))
        _state["yellow_pin_mode_syncing"] = True
        try:
            context.window_manager.yellow_pin_mode = f"MODE_{yellow_mode}"
        finally:
            _state["yellow_pin_mode_syncing"] = False
        _state["yellow_pin_axis_syncing"] = True
        try:
            context.window_manager.yellow_pin_axis = str(
                target_data[2].get(YELLOW_PIN_AXIS_PROPERTY, "Y_NEG")
            )
        finally:
            _state["yellow_pin_axis_syncing"] = False
    elif target_data[0] == "CONTACT":
        _state["surface_contact_axis_syncing"] = True
        try:
            context.window_manager.surface_contact_cast_axis = str(
                target_data[3].get(
                    SURFACE_CONTACT_CAST_AXIS_PROPERTY,
                    "Y_NEG",
                )
            )
        finally:
            _state["surface_contact_axis_syncing"] = False
    previous_active = str(_state.get("pin_gizmo_selected_key", ""))
    previous_keys = _pin_selected_target_keys()
    selected_keys = (
        set(previous_keys) | {target_key}
        if extend
        else {target_key}
    )
    changed = (
        target_key != previous_active
        or selected_keys != set(previous_keys)
    )
    _state["pin_gizmo_selected_key"] = target_key
    _state["pin_gizmo_selected_keys"] = selected_keys
    _state["pin_gizmo_selected_keys_active"] = target_key
    selected_cache = _state.setdefault("pin_selected_target_data", {})
    if not extend:
        selected_cache.clear()
    selected_cache[target_key] = target_data
    if changed:
        _state["pin_gizmo_selection_epoch"] = int(
            _state.get("pin_gizmo_selection_epoch", 0)
        ) + 1
    # Discard an older modifier transition when a new virtual-pin selection
    # begins. The next asynchronous Shift press then belongs unambiguously to
    # the bone-selection change that follows this pin click.
    _pin_shift_modifier_pressed()
    _state["pin_gizmo_pending_click"] = None
    _state["pin_gizmo_axes_visible"] = {target_key: True}
    if not extend and not defer_pose_selection:
        # A normal click selects the virtual pin exclusively. Set the pin key
        # first so contact reconciliation continues treating its guide as the
        # actively manipulated target while Blender clears the Pose selection.
        # The virtual pin key owns the linked-bone UI context. Blender's
        # native active-bone pointer must also be cleared or a bone behind the
        # diamond can flash and expose its transform gizmo during pin drags.
        _pin_deselect_pose_bones(context)
    _state["pin_gizmo_selection_keys"] = _pin_pose_selection_signature(context)
    _pin_selection_history_store(context, push = changed)
    _pin_select_contact_action_groups(
        context,
        defer = target_data[0] == "CONTACT",
        exclusive = target_data[0] == "CONTACT" and not extend,
    )
    if changed:
        _tag_redraw_all_view3d()
    return True


def _pin_deselect_target(push_history=True, store_history=True, redraw=True):
    if not _pin_selected_target_keys():
        _state["pin_gizmo_pending_click"] = None
        if store_history:
            _pin_selection_history_store(
                bpy.context, {"active": "", "selected": set()}
            )
        _pin_select_contact_action_groups(bpy.context, defer = False)
        return False
    _state["pin_gizmo_selected_key"] = ""
    _state["pin_gizmo_selected_keys"] = set()
    _state["pin_gizmo_selected_keys_active"] = ""
    _state["pin_selected_target_data"] = {}
    _pin_select_contact_action_groups(bpy.context, defer = False)
    _state["pin_gizmo_pending_click"] = None
    _state["pin_gizmo_selection_epoch"] = int(
        _state.get("pin_gizmo_selection_epoch", 0)
    ) + 1
    _state["pin_gizmo_axes_visible"] = {}
    _state["pin_gizmo_selection_keys"] = ()
    _state["pin_gizmo_extend_selection_until"] = 0.0
    if store_history:
        _pin_selection_history_store(bpy.context, push = push_history)
    if redraw:
        _tag_redraw_all_view3d()
    return True

def _pin_finish_exclusive_selection(context, target_key, exclusive):
    if not bool(exclusive):
        return
    target_data = _pin_available_target_data(context).get(str(target_key))
    if target_data is None:
        return
    _pin_deselect_pose_bones(context)
    _state["pin_gizmo_selection_keys"] = _pin_pose_selection_signature(context)


def _pin_gizmo_claim_pointer(event):
    _state["pin_gizmo_claim_serial"] = int(
        _state.get("pin_gizmo_claim_serial", 0)
    ) + 1
    _state["pin_gizmo_pending_click"] = None
    _state["pin_pointer_pending_click"] = None
    _state["pin_gizmo_last_claim"] = (
        int(getattr(getattr(bpy.context, "window", None), "as_pointer", lambda: 0)()),
        int(getattr(event, "mouse_x", -2147483648)),
        int(getattr(event, "mouse_y", -2147483648)),
        float(time.perf_counter()),
    )


def _pin_preserve_after_transform(context, target_key, event = None):
    """Keep a confirmed/cancelled pin transform from becoming click-away."""
    target_key = str(target_key)
    if (
        event is not None
        and str(getattr(event, "type", "")) == "LEFTMOUSE"
    ):
        _pin_gizmo_claim_pointer(event)
    _state["pin_gizmo_pending_click"] = None
    _state["pin_pointer_pending_click"] = None
    if target_key != _pin_selected_target_key():
        return False
    _state["pin_gizmo_axes_visible"] = {target_key: True}
    _state["pin_gizmo_selection_keys"] = _pin_pose_selection_signature(
        context
    )
    _state["pin_gizmo_extend_selection_until"] = (
        time.perf_counter() + 0.25
    )
    _tag_redraw_all_view3d()
    return True


def _pin_gizmo_saved_axes_visible(group, target_key = None):
    key = str(
        target_key
        if target_key is not None
        else getattr(group, "active_target_key", "")
    )
    if not key:
        return bool(getattr(group, "axes_visible", False))
    if key != _pin_selected_target_key():
        return False
    return bool(_state.setdefault("pin_gizmo_axes_visible", {}).get(key, True))


def _pin_gizmo_set_axes_visible(group, visible):
    if group is None:
        return
    visible = bool(visible)
    group.axes_visible = visible
    key = str(getattr(group, "active_target_key", ""))
    if key:
        _state.setdefault("pin_gizmo_axes_visible", {})[key] = visible



def _pin_gizmo_track_selection(context, preserve_visibility = False):
    if (
        preserve_visibility
        or _state.get("pin_history_active", False)
        or _state.get("pin_target_dragging", False)
        or _state.get("pin_keyboard_transform_active", False)
    ):
        # History evaluation and undoable gizmo commits can expose a transient
        # empty context. Do not consume the uninterrupted-selection baseline.
        return False
    selected = _pin_selected_target_key()
    if not selected:
        _state["pin_gizmo_selection_keys"] = ()
        return False
    if selected.startswith("CONTACT:"):
        # Blender completes Shift bone selection after the gizmo callback.
        # Reconcile the channel after that native selection pass as well.
        _pin_select_contact_action_groups(context, defer = False)
    extend_until = float(
        _state.get("pin_gizmo_extend_selection_until", 0.0)
    )
    if extend_until > 0.0:
        # Shift-click selection is completed by Blender after our pass-through
        # keymap item. Accept each intermediate signature until it settles.
        _state["pin_gizmo_selection_keys"] = _pin_pose_selection_signature(
            context
        )
        if time.perf_counter() < extend_until:
            return False
        _state["pin_gizmo_extend_selection_until"] = 0.0
    try:
        valid = bool(
            selected in _pin_available_target_data(context)
            or selected in _state.setdefault("pin_selected_target_data", {})
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        valid = False
    if valid:
        current_signature = _pin_pose_selection_signature(context)
        saved_signature = _state.get("pin_gizmo_selection_keys", ())
        if saved_signature and current_signature != saved_signature:
            if _pin_preserve_extended_pose_selection(
                saved_signature,
                current_signature,
                _pin_shift_modifier_pressed(),
            ):
                _state["pin_gizmo_selection_keys"] = current_signature
                _pin_select_contact_action_groups(context, defer = False)
                return False
            return _pin_deselect_target()
        _state["pin_gizmo_selection_keys"] = current_signature
        return False
    return _pin_deselect_target()


def _pin_gizmo_begin_interaction(
    gizmo,
    event,
    context=None,
    target_data_override=None,
):
    group = _pin_gizmo_group(gizmo)
    _pin_gizmo_claim_pointer(event)
    target_key = str(getattr(gizmo, "target_key", ""))
    gizmo.extend_selection = bool(getattr(event, "shift", False))
    axis_index = int(getattr(gizmo, "axis_index", -1))
    preserve_group = target_key in _pin_selected_target_keys()
    center_exclusive = bool(
        axis_index < 0
        and not gizmo.extend_selection
        and not preserve_group
    )
    pin_only_axis = bool(
        axis_index >= 0
        and not gizmo.extend_selection
        and context is not None
        and not _selected_owner_bone_keys(context)
    )
    if target_key and context is not None:
        # Blender may clear the pose-bone selection between Gizmo.invoke and
        # the zero-delay post-modal finalizer. Accept that transient signature
        # for both normal and Shift clicks so the just-selected virtual pin is
        # not mistaken for a click-away.
        _state["pin_gizmo_extend_selection_until"] = (
            time.perf_counter() + 0.75
        )
        _state["pin_gizmo_selection_keys"] = ()
        _pin_select_target(
            context,
            target_key,
            extend = gizmo.extend_selection or preserve_group,
            # A normal center press and a pin-only axis drag both clear stale
            # native active-bone state before the next redraw. Shift
            # multi-selection retains its actual pose-bone selection.
            defer_pose_selection = (
                bool(gizmo.extend_selection)
                or not target_key.startswith("CONTACT:")
            ),
            target_data_override=target_data_override,
        )
    if group is not None and target_key:
        group.active_target_key = target_key
        _pin_gizmo_set_axes_visible(group, True)
    gizmo.initial_mouse = (
        float(event.mouse_region_x),
        float(event.mouse_region_y),
    )
    gizmo.drag_started = False
    gizmo.axes_were_visible = _pin_gizmo_saved_axes_visible(group)
    if group is None:
        return
    _state["pin_gizmo_active_axis_index"] = axis_index
    group.center_dragging = False
    if axis_index >= 0:
        group.active_axis_index = axis_index
    else:
        group.active_axis_index = -1


def _pin_gizmo_drag_ready(gizmo, event):
    if bool(getattr(gizmo, "drag_started", False)):
        return True
    initial_mouse = Vector(getattr(gizmo, "initial_mouse", (0.0, 0.0)))
    current_mouse = Vector(
        (float(event.mouse_region_x), float(event.mouse_region_y))
    )
    if (current_mouse - initial_mouse).length < PIN_GIZMO_DRAG_PIXEL_THRESHOLD:
        return False
    gizmo.drag_started = True
    group = _pin_gizmo_group(gizmo)
    if group is not None:
        axis_index = int(getattr(gizmo, "axis_index", -1))
        if axis_index >= 0:
            group.active_axis_index = axis_index
        else:
            group.center_dragging = True
    _tag_redraw_all_view3d()
    return True


def _pin_gizmo_finish_interaction(gizmo, cancel):
    _state["pin_gizmo_active_axis_index"] = -1
    group = _pin_gizmo_group(gizmo)
    if group is None:
        return
    axis_index = int(getattr(gizmo, "axis_index", -1))
    group.active_axis_index = -1
    group.center_dragging = False
    if str(getattr(group, "active_target_key", "")) == _pin_selected_target_key():
        _pin_gizmo_set_axes_visible(group, True)

def _pin_gizmo_configure_undo(gizmo, enabled, legacy_message = ""):
    """Use native Gizmo undo when available, otherwise request safe fallback."""
    enabled = bool(enabled)
    try:
        gizmo.use_undo = enabled
        return ""
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        # Blender 4.2-4.3 do not expose Gizmo.use_undo to Python. Their undo
        # step is pushed by our zero-delay post-modal timer instead.
        return str(legacy_message) if enabled else ""
