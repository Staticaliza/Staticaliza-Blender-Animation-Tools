"""Shared pink/yellow pin selection, gizmos, transforms, history, and snapping."""

from ..core.runtime import *  # noqa: F403

_PIN_GIZMO_DIAMOND_VERTICES = (
    (0.0, 0.0, 1.0), (1.0, 0.0, 0.0), (0.0, 1.0, 0.0),
    (0.0, 0.0, 1.0), (0.0, 1.0, 0.0), (-1.0, 0.0, 0.0),
    (0.0, 0.0, 1.0), (-1.0, 0.0, 0.0), (0.0, -1.0, 0.0),
    (0.0, 0.0, 1.0), (0.0, -1.0, 0.0), (1.0, 0.0, 0.0),
    (0.0, 0.0, -1.0), (0.0, 1.0, 0.0), (1.0, 0.0, 0.0),
    (0.0, 0.0, -1.0), (-1.0, 0.0, 0.0), (0.0, 1.0, 0.0),
    (0.0, 0.0, -1.0), (0.0, -1.0, 0.0), (-1.0, 0.0, 0.0),
    (0.0, 0.0, -1.0), (1.0, 0.0, 0.0), (0.0, -1.0, 0.0),
)

def _pin_gizmo_axis_matrix(point, axis):
    axis = Vector(axis)
    if axis.length_squared <= 1.0e-12:
        axis = Vector((0.0, 0.0, 1.0))
    axis.normalize()
    matrix = Vector((0.0, 0.0, 1.0)).rotation_difference(axis).to_matrix().to_4x4()
    matrix.translation = Vector(point)
    return matrix


def _pin_gizmo_theme_axis_colors(context):
    try:
        interface = context.preferences.themes[0].user_interface
        return (
            tuple(interface.axis_x),
            tuple(interface.axis_y),
            tuple(interface.axis_z),
        )
    except (AttributeError, IndexError, ReferenceError, TypeError):
        return (
            (1.0, 0.20, 0.322),
            (0.545, 0.863, 0.0),
            (0.157, 0.565, 1.0),
        )


def _pin_gizmo_axis_offset_get():
    """Keep Blender's native arrow from adding its own modal displacement."""
    return 0.0


def _pin_gizmo_axis_offset_set(_value):
    """The pin transform operator is the sole owner of target displacement."""
    return None


def _pin_rest_orientation_world(target_data):
    if target_data is None:
        return Matrix.Identity(3)
    try:
        _kind, armature, pose_bone, _payload = target_data
        if armature is None or pose_bone is None or pose_bone.bone is None:
            return Matrix.Identity(3)
        armature_rotation = armature.matrix_world.to_quaternion().normalized()
        rest_rotation = (
            pose_bone.bone.matrix_local.to_quaternion().normalized()
        )
        return (armature_rotation @ rest_rotation).normalized().to_matrix()
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return Matrix.Identity(3)


def _pin_transform_orientation_matrix(
    context,
    target_data,
    pin_matrix = None,
):
    try:
        orientation_type = str(
            context.scene.transform_orientation_slots[0].type
        )
    except (AttributeError, IndexError, ReferenceError):
        orientation_type = "GLOBAL"
    part_mode = bool(
        getattr(
            getattr(context, "window_manager", None),
            "staticaliza_pivot_mode",
            "BONE",
        ) == "PART"
    )
    if orientation_type == "GLOBAL":
        return Matrix.Identity(3)
    if part_mode and orientation_type in {"LOCAL", "CURSOR"}:
        # Object pivot mode stores the connected object's world axes on the
        # cursor. Refresh them for pin-only selection before drawing/using the
        # pin handles so they cannot fall back to the bone's rest axes.
        try:
            _sync_part_pivot(context)
            return context.scene.cursor.matrix.to_3x3().normalized()
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            pass
    if orientation_type == "LOCAL":
        # Bone.matrix_local already includes the original parent rest chain.
        return _pin_rest_orientation_world(target_data)
    if orientation_type == "VIEW":
        region_data = getattr(context, "region_data", None)
        if region_data is not None:
            try:
                return (
                    region_data.view_matrix.inverted_safe()
                    .to_3x3()
                    .normalized()
                )
            except (AttributeError, RuntimeError, TypeError, ValueError):
                pass
    if orientation_type == "CURSOR":
        try:
            return context.scene.cursor.matrix.to_3x3().normalized()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            pass
    if pin_matrix is None and target_data is not None:
        try:
            kind, armature, pose_bone, payload = target_data
            pin_matrix = (
                payload.matrix_world.copy()
                if kind == "CONTACT"
                else (armature.matrix_world @ pose_bone.matrix).normalized()
            )
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            pin_matrix = None
    try:
        return pin_matrix.to_3x3().normalized()
    except (AttributeError, RuntimeError, TypeError, ValueError):
        return Matrix.Identity(3)


def _pin_gizmo_center_matrix(point):
    return Matrix.Translation(Vector(point))


def _pin_gizmo_view_depth(context, point):
    region_data = getattr(context, "region_data", None)
    if region_data is None:
        return None
    try:
        return float(
            (region_data.view_matrix @ Vector((*Vector(point), 1.0))).z
        )
    except (AttributeError, RuntimeError, TypeError, ValueError):
        return None


def _pin_gizmo_center_in_front(context, point):
    depth = _pin_gizmo_view_depth(context, point)
    if depth is None:
        return False
    near = max(
        1.0e-5,
        float(getattr(getattr(context, "space_data", None), "clip_start", 0.01)),
    )
    return depth < -(near + PIN_GIZMO_DIAMOND_SCALE)


def _pin_gizmo_center_visible(context, point, target_data = None):
    """Hide a complete pin control when scene geometry is in front of it."""
    point = Vector(point)
    if not _pin_gizmo_center_in_front(context, point):
        return False
    region = getattr(context, "region", None)
    region_data = getattr(context, "region_data", None)
    if region is None or region_data is None:
        return False
    try:
        from bpy_extras import view3d_utils

        projected = view3d_utils.location_3d_to_region_2d(
            region,
            region_data,
            point,
        )
        if projected is None:
            return False
        origin = view3d_utils.region_2d_to_origin_3d(
            region,
            region_data,
            projected,
        )
        direction = view3d_utils.region_2d_to_vector_3d(
            region,
            region_data,
            projected,
        )
        distance = float((point - origin).length)
        if distance <= 1.0e-5:
            return True

        excluded = set()
        if target_data is not None:
            _kind, armature, pose_bone, _payload = target_data
            if armature is not None:
                excluded.add(armature)
                evaluated_armature = armature.evaluated_get(
                    context.evaluated_depsgraph_get()
                )
                evaluated_bone = evaluated_armature.pose.bones.get(
                    pose_bone.name
                )
                if evaluated_bone is not None:
                    family_names = _surface_contact_bone_family_names(
                        evaluated_armature,
                        evaluated_bone,
                    )
                    excluded.update(
                        _surface_contact_connected_objects(
                            context,
                            armature,
                            family_names,
                        )
                    )
        # Stop slightly before the control center so the surface carrying a
        # contact pin is not mistaken for geometry in front of that pin.
        cast_distance = max(0.0, distance - 0.002)
        return (
            _surface_contact_ray_cast(
                context,
                origin,
                direction,
                cast_distance,
                excluded,
            )
            is None
        )
    except (
        AttributeError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ):
        return True


def _pin_gizmo_axis_in_front(context, point, axis):
    point = Vector(point)
    axis = Vector(axis)
    start_depth = _pin_gizmo_view_depth(context, point)
    end_depth = _pin_gizmo_view_depth(
        context,
        point + (axis * PIN_GIZMO_AXIS_SCALE),
    )
    if start_depth is None or end_depth is None:
        return False
    near = max(
        1.0e-5,
        float(getattr(getattr(context, "space_data", None), "clip_start", 0.01)),
    )
    return start_depth < -near and end_depth < -near



def _pin_gizmo_apply_axis_locks(
    candidate,
    origin,
    locked_axes,
    orientation = None,
):
    result = Vector(candidate)
    origin = Vector(origin)
    if orientation is None:
        orientation = Matrix.Identity(3)
    try:
        orientation = orientation.to_3x3().normalized()
    except (AttributeError, RuntimeError, TypeError, ValueError):
        orientation = Matrix.Identity(3)
    local_delta = orientation.inverted_safe() @ (result - origin)
    for axis_index, locked in enumerate(tuple(locked_axes or ())[:3]):
        if locked:
            local_delta[axis_index] = 0.0
    return origin + (orientation @ local_delta)


def _pin_gizmo_mouse_plane_point(context, point, mouse_position):
    region = getattr(context, "region", None)
    region_data = getattr(context, "region_data", None)
    if region is None or region_data is None:
        return None
    from bpy_extras import view3d_utils

    try:
        return view3d_utils.region_2d_to_location_3d(
            region,
            region_data,
            Vector(mouse_position),
            Vector(point),
        )
    except (AttributeError, RuntimeError, TypeError, ValueError):
        return None


def _pin_gizmo_oriented_plane_point(
    context,
    point,
    normal,
    mouse_position,
):
    region = getattr(context, "region", None)
    region_data = getattr(context, "region_data", None)
    if region is None or region_data is None:
        return None
    from bpy_extras import view3d_utils
    from mathutils.geometry import intersect_line_plane

    mouse = Vector(mouse_position)
    origin = view3d_utils.region_2d_to_origin_3d(region, region_data, mouse)
    direction = view3d_utils.region_2d_to_vector_3d(
        region,
        region_data,
        mouse,
    )
    normal = Vector(normal)
    if normal.length_squared <= 1.0e-12:
        return None
    return intersect_line_plane(
        origin,
        origin + direction,
        Vector(point),
        normal.normalized(),
        False,
    )


def _pin_gizmo_mouse_surface_hit(context, mouse_position, guide = None):
    """Return the first visible scene mesh under the pointer.

    A Contact target ignores the linked bone's complete welded object family;
    otherwise its center drag can stick to the limb it is meant to position.
    Yellow pins retain the general any-visible-surface behavior.
    """
    region = getattr(context, "region", None)
    region_data = getattr(context, "region_data", None)
    if region is None or region_data is None:
        return None
    from bpy_extras import view3d_utils

    mouse = Vector(mouse_position)
    origin = view3d_utils.region_2d_to_origin_3d(region, region_data, mouse)
    direction = view3d_utils.region_2d_to_vector_3d(region, region_data, mouse)
    excluded = (
        _surface_contact_linked_collision_objects(context, guide)
        if guide is not None
        else set()
    )
    hit = _surface_contact_ray_cast(
        context,
        origin,
        direction,
        1000000.0,
        excluded,
    )
    if hit is not None or guide is None:
        return hit

    # Thin/open meshes and a ray passing exactly over a triangle edge can
    # produce a one-sample miss. Continue on the already bound surface by
    # intersecting the view ray with its local tangent plane and projecting
    # that point back to the evaluated mesh. This prevents a flat drag from
    # freezing while preserving direct ray hits as the authority for changing
    # from a floor to a wall.
    surface = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_SURFACE_PROPERTY, ""))
    )
    if surface is None or surface in excluded:
        return None
    direction = Vector(direction)
    if direction.length_squared <= 1.0e-12:
        return None
    direction.normalize()
    point = guide.matrix_world.translation.copy()
    normal = _surface_contact_reference_normal(guide)
    denominator = direction.dot(normal)
    if abs(denominator) <= 1.0e-8:
        return None
    distance = (point - origin).dot(normal) / denominator
    if distance < 0.0:
        return None
    plane_point = origin + (direction * distance)
    projected = _surface_contact_closest_point(
        surface,
        plane_point,
        context.evaluated_depsgraph_get(),
        max(
            1.0,
            (plane_point - point).length * 2.0,
            float(guide.get(SURFACE_CONTACT_SIZE_PROPERTY, 0.05)) * 8.0,
        ),
    )
    if projected is None:
        return None
    projected_point, projected_normal = projected
    projected_normal = _surface_contact_align_surface_normal(
        guide,
        projected_normal,
        normal,
    )
    return surface, projected_point, projected_normal, float(distance)


def _pin_gizmo_mouse_surface_point(context, mouse_position):
    hit = _pin_gizmo_mouse_surface_hit(context, mouse_position)
    return hit[1].copy() if hit is not None else None


def _pin_gizmo_axis_mouse_point(context, point, axis, mouse_position):
    region = getattr(context, "region", None)
    region_data = getattr(context, "region_data", None)
    if region is None or region_data is None:
        return None
    from bpy_extras import view3d_utils
    from mathutils.geometry import intersect_line_line

    mouse = Vector(mouse_position)
    ray_origin = view3d_utils.region_2d_to_origin_3d(region, region_data, mouse)
    ray_direction = view3d_utils.region_2d_to_vector_3d(region, region_data, mouse)
    axis = Vector(axis)
    if axis.length_squared <= 1.0e-12 or ray_direction.length_squared <= 1.0e-12:
        return None
    axis.normalize()
    pair = intersect_line_line(
        Vector(point) - axis,
        Vector(point) + axis,
        ray_origin,
        ray_origin + ray_direction,
    )
    return pair[0] if pair is not None else None


def _surface_contact_axis_surface_point(context, guide, candidate):
    return _surface_contact_bound_surface_point(context, guide, candidate)
