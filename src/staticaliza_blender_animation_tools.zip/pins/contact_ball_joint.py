"""Continuous planted-point math for direct pink-bone transforms."""

from ..core.runtime import *  # noqa: F403


def _pin_contact_ball_joint_reset(operator):
    operator.contact_ball_active = False
    operator.contact_explicitly_released = False
    operator.contact_pressure_released = False
    operator.contact_pressure_release_requested = False
    operator.contact_pressure_ever_active = False
    operator.contact_ball_detached_world = None
    operator.contact_ball_previous_raw_world = None
    operator.contact_detached_input_world = None
    operator.contact_detached_pose_world = None
    operator.contact_detached_continuity_active = False
    operator.contact_detached_magnetic_active = False
    operator.contact_reentry_armed = False
    operator.contact_ball_initial_mouse = None
    operator.contact_ball_previous_mouse = None
    operator.contact_ball_left_return_zone = False
    operator.contact_ball_world_left_return_zone = False
    operator.contact_ball_view_azimuth = 0.0
    operator.contact_ball_view_initial_elevation = 0.0
    operator.contact_ball_tilt_reference_local = None
    operator.contact_ball_tilt_view_axis = None
    operator.contact_ball_tilt_view_fallback = None
    operator.contact_ball_tilt_offset = 0.0
    operator.contact_ball_tilt_previous_base = None
    operator.contact_ball_opposite_local = None
    operator.contact_ball_surface_normal_screen = None


def _pin_contact_project_reference(reference, direction):
    reference = Vector(reference)
    direction = Vector(direction).normalized()
    projected = reference - direction * reference.dot(direction)
    return projected.normalized() if projected.length_squared > 1.0e-12 else None


def _pin_contact_signed_angle(first, second, axis):
    first = Vector(first).normalized()
    second = Vector(second).normalized()
    axis = Vector(axis).normalized()
    return math.atan2(
        axis.dot(first.cross(second)),
        max(-1.0, min(1.0, first.dot(second))),
    )


def _pin_contact_ball_joint_capture_tilt(
    context,
    operator,
    guide,
    corrected_world,
    radial,
):
    """Capture one screen-stable welded-object face as the roll reference."""
    view_axis = _pin_keyboard_view_axis(context).normalized()
    reference_world = None
    smart_object = bpy.data.objects.get(str(
        guide.get(SURFACE_CONTACT_SMART_OBJECT_PROPERTY, "")
    ))
    if smart_object is not None:
        basis = smart_object.matrix_world.to_3x3().normalized()
        candidates = tuple(Vector(basis.col[index]) for index in range(3))
        radial_direction = Vector(radial).normalized()
        usable = tuple(
            axis for axis in candidates
            if _pin_contact_project_reference(
                axis,
                radial_direction,
            ) is not None
        )
        if usable:
            reference_world = max(
                usable,
                key=lambda axis: (
                    abs(axis.dot(view_axis))
                    + 0.01 * _pin_contact_project_reference(
                        axis,
                        radial_direction,
                    ).length
                ),
            )
        if reference_world is not None and reference_world.dot(view_axis) < 0.0:
            reference_world.negate()
    if reference_world is None:
        corrected_basis = corrected_world.to_3x3().normalized()
        reference_world = next(
            (
                Vector(corrected_basis.col[index])
                for index in range(3)
                if _pin_contact_project_reference(
                    corrected_basis.col[index],
                    radial,
                ) is not None
            ),
            view_axis.orthogonal().normalized(),
        )
    radial = Vector(radial).normalized()
    fallback = view_axis.orthogonal().normalized()
    base = _pin_contact_project_reference(view_axis, radial)
    if base is None:
        base = _pin_contact_project_reference(fallback, radial)
    reference = _pin_contact_project_reference(reference_world, radial)
    if base is None or reference is None:
        return False
    operator.contact_ball_tilt_reference_local = (
        corrected_world.to_3x3().inverted_safe() @ reference_world
    )
    operator.contact_ball_tilt_view_axis = view_axis.copy()
    operator.contact_ball_tilt_view_fallback = fallback.copy()
    operator.contact_ball_tilt_offset = _pin_contact_signed_angle(
        base,
        reference,
        radial,
    )
    operator.contact_ball_tilt_previous_base = base.copy()
    return True


def _pin_contact_ball_joint_lock_tilt(operator, target, desired_world):
    """Keep the captured welded-object face at one screen tilt."""
    reference_local = getattr(
        operator,
        "contact_ball_tilt_reference_local",
        None,
    )
    view_axis = getattr(operator, "contact_ball_tilt_view_axis", None)
    if reference_local is None or view_axis is None:
        return Matrix(desired_world).copy()
    desired_world = Matrix(desired_world)
    target = Vector(target)
    handle = desired_world @ Vector(operator.contact_ball_handle_local)
    radial = handle - target
    if radial.length_squared <= 1.0e-12:
        return desired_world.copy()
    radial.normalize()
    view_axis = Vector(view_axis)
    fixed_raw = view_axis - radial * view_axis.dot(radial)
    fixed_strength = fixed_raw.length
    fixed_base = (
        fixed_raw / fixed_strength
        if fixed_strength > 1.0e-12
        else None
    )
    previous_base = _pin_contact_project_reference(
        getattr(
            operator,
            "contact_ball_tilt_previous_base",
            getattr(operator, "contact_ball_tilt_view_fallback", view_axis),
        ),
        radial,
    )
    if fixed_base is None:
        base = previous_base
    elif previous_base is None or fixed_strength >= 0.25:
        base = fixed_base
    else:
        if previous_base.dot(fixed_base) < 0.0:
            fixed_base.negate()
        blend = max(0.0, min(1.0, fixed_strength / 0.25))
        blend = blend * blend * (3.0 - (2.0 * blend))
        base = (
            previous_base.lerp(fixed_base, blend).normalized()
        )
    current = _pin_contact_project_reference(
        desired_world.to_3x3() @ Vector(reference_local),
        radial,
    )
    if base is None or current is None:
        return desired_world.copy()
    operator.contact_ball_tilt_previous_base = base.copy()
    target_reference = Quaternion(
        radial,
        float(getattr(operator, "contact_ball_tilt_offset", 0.0)),
    ) @ base
    twist = _pin_contact_signed_angle(current, target_reference, radial)
    # Screen tilt is undefined while the rod points into the camera. Fade the
    # lock out around that pole and bound its recovery so equivalent projected
    # frames cannot make a visible half-turn in one mouse sample.
    tilt_weight = max(0.0, min(1.0, (fixed_strength - 0.35) / 0.65))
    tilt_weight = tilt_weight * tilt_weight * (3.0 - (2.0 * tilt_weight))
    twist *= tilt_weight
    twist_limit = math.radians(10.0)
    twist = max(-twist_limit, min(twist_limit, twist))
    return (
        Matrix.Translation(target)
        @ Quaternion(radial, twist).to_matrix().to_4x4()
        @ Matrix.Translation(-target)
        @ desired_world
    )


def _pin_contact_ball_joint_pivot(operator, armature, pose_bone):
    if (
        bool(getattr(operator, "contact_keep_attached", False))
        and bool(getattr(operator, "contact_ball_active", False))
    ):
        return Vector(operator.contact_ball_target)
    return (armature.matrix_world @ pose_bone.matrix).translation


def _pin_contact_ball_joint_raw_anchor(operator, raw_world, fallback=None):
    """Return the support point before detached magnetic aiming is applied.

    A released contact keeps the local support captured by the planted
    ball-joint session.  Mapping that point through the raw modal matrix makes
    re-entry follow the endpoint the user actually moved.  Reading the live
    pose here is incorrect because detached aiming may already have rotated it
    toward the target, producing a different support coordinate and preventing
    an apparent dot-on-dot return from entering the inner snap radius.
    """
    local_anchor = getattr(operator, "contact_ball_anchor_local", None)
    if local_anchor is None:
        return Vector(fallback) if fallback is not None else None
    try:
        return Matrix(raw_world) @ Vector(local_anchor)
    except (TypeError, ValueError):
        return Vector(fallback) if fallback is not None else None


def _pin_contact_ball_joint_reentry_probe(
    context,
    operator,
    raw_world,
    target,
    fallback=None,
):
    """Return the authored endpoint and whether it is currently in the ring."""
    anchor = _pin_contact_ball_joint_raw_anchor(
        operator,
        raw_world,
        fallback=fallback,
    )
    within = bool(
        anchor is not None
        and target is not None
        and _pin_points_within_snap_radius(
            context,
            target,
            anchor,
            pixel_radius=PIN_SNAP_PIXEL_RADIUS,
        )
    )
    return anchor, within


def _pin_contact_ball_joint_capture(
    context,
    operator,
    target_data,
    raw_world=None,
    pose_world=None,
):
    _kind, armature, pose_bone, guide = target_data
    target, normal, anchor = _surface_contact_world_point_normal(
        context,
        guide,
    )
    if target is None or normal is None or anchor is None:
        return False
    raw_world = (
        raw_world.copy()
        if raw_world is not None
        else (armature.matrix_world @ pose_bone.matrix)
    )
    preserve_pose_world = pose_world is not None
    pose_world = (
        Matrix(pose_world).copy()
        if preserve_pose_world
        else raw_world.copy()
    )
    target = Vector(target)
    anchor = Vector(anchor)
    operator.contact_pressure_released = False
    operator.contact_pressure_release_requested = False
    preserve_local_frame = bool(
        preserve_pose_world
        and getattr(operator, "contact_ball_anchor_local", None) is not None
        and getattr(operator, "contact_ball_handle_local", None) is not None
    )
    local_anchor = (
        Vector(operator.contact_ball_anchor_local)
        if preserve_local_frame
        else (raw_world.inverted_safe() @ anchor)
    )
    head_local = Vector((0.0, 0.0, 0.0))
    tail_local = Vector(
        (0.0, max(1.0e-8, float(pose_bone.length)), 0.0)
    )
    handle_local = (
        Vector(operator.contact_ball_handle_local)
        if preserve_local_frame
        else max(
            (head_local, tail_local),
            key=lambda point: ((raw_world @ point) - anchor).length_squared,
        )
    )
    opposite_world = _surface_contact_opposite_anchor_world(context, guide)
    opposite_local = (
        Vector(operator.contact_ball_opposite_local)
        if preserve_local_frame
        and getattr(operator, "contact_ball_opposite_local", None) is not None
        else (
            raw_world.inverted_safe() @ Vector(opposite_world)
            if opposite_world is not None
            else handle_local.copy()
        )
    )
    corrected_world = pose_world.copy()
    corrected_world.translation += (
        target - (pose_world @ local_anchor)
    )
    operator.contact_ball_target = target.copy()
    operator.contact_ball_anchor_local = local_anchor.copy()
    normal = Vector(normal)
    if normal.length_squared <= 1.0e-12:
        normal = Vector((0.0, 0.0, 1.0))
    else:
        normal.normalize()
    operator.contact_ball_surface_normal = normal.copy()
    operator.contact_ball_raw_anchor = raw_world @ local_anchor
    operator.contact_ball_handle_local = handle_local.copy()
    operator.contact_ball_opposite_local = opposite_local.copy()
    operator.contact_ball_initial_world = corrected_world.copy()
    operator.contact_ball_frame_initial_world = corrected_world.copy()
    operator.contact_ball_raw_world = raw_world.copy()
    operator.contact_ball_previous_raw_world = raw_world.copy()
    target_screen = None
    try:
        from bpy_extras import view3d_utils
        target_screen = view3d_utils.location_3d_to_region_2d(
            context.region,
            context.region_data,
            target,
        )
    except (AttributeError, RuntimeError, TypeError, ValueError):
        target_screen = None
    operator.contact_ball_target_screen = (
        tuple(float(value) for value in target_screen)
        if target_screen is not None
        else None
    )
    normal_screen = None
    if target_screen is not None:
        try:
            from bpy_extras import view3d_utils
            normal_tip_screen = view3d_utils.location_3d_to_region_2d(
                context.region,
                context.region_data,
                target + normal,
            )
            if normal_tip_screen is not None:
                normal_screen = Vector(normal_tip_screen) - Vector(target_screen)
                if normal_screen.length_squared > 1.0e-8:
                    normal_screen.normalize()
                else:
                    normal_screen = None
        except (AttributeError, RuntimeError, TypeError, ValueError):
            normal_screen = None
    operator.contact_ball_surface_normal_screen = (
        tuple(float(value) for value in normal_screen)
        if normal_screen is not None
        else None
    )
    current_mouse = getattr(operator, "contact_current_mouse", None)
    operator.contact_ball_initial_mouse = (
        tuple(float(value) for value in current_mouse)
        if current_mouse is not None
        else None
    )
    operator.contact_ball_previous_mouse = (
        tuple(float(value) for value in current_mouse)
        if current_mouse is not None
        else None
    )
    operator.contact_ball_initial_handle = (
        corrected_world @ handle_local
    )
    operator.contact_ball_raw_handle = raw_world @ handle_local
    operator.contact_ball_previous_requested = (
        operator.contact_ball_initial_handle.copy()
    )
    operator.contact_ball_current_world = corrected_world.copy()
    operator.contact_ball_current_handle = (
        operator.contact_ball_initial_handle.copy()
    )
    radial = operator.contact_ball_initial_handle - target
    if radial.length_squared <= 1.0e-12:
        return False
    operator.contact_ball_radial = radial.normalized()
    _pin_contact_ball_joint_capture_tilt(
        context,
        operator,
        guide,
        corrected_world,
        radial,
    )
    operator.contact_ball_previous_axis = None
    view_axis = _pin_keyboard_view_axis(context).normalized()
    view_radial = radial - view_axis * radial.dot(view_axis)
    view_depth = radial.dot(view_axis)
    operator.contact_ball_view_depth_sign = (
        -1.0 if view_depth < -1.0e-10 else 1.0
    )
    operator.contact_ball_view_radius = max(
        1.0e-8,
        float(
            view_radial.length
            if view_radial.length > 1.0e-8
            else radial.length
        ),
    )
    (
        _capture_axis,
        capture_direction,
        capture_radius,
        capture_depth,
    ) = _pin_contact_ball_joint_trackball_components(
        context,
        operator,
        target,
        operator.contact_ball_initial_handle,
    )
    operator.contact_ball_view_screen_direction = capture_direction.copy()
    operator.contact_ball_initial_screen_direction = capture_direction.copy()
    operator.contact_ball_view_elevation = math.atan2(
        capture_depth,
        capture_radius,
    )
    operator.contact_ball_view_initial_elevation = (
        operator.contact_ball_view_elevation
    )
    operator.contact_ball_view_azimuth = 0.0
    operator.contact_ball_view_vector = (
        capture_direction * capture_radius
        + _capture_axis * capture_depth
    ).normalized()
    operator.contact_ball_trackball_to_world = (
        operator.contact_ball_view_vector.rotation_difference(
            radial.normalized()
        )
    )
    operator.contact_ball_initial_trackball_to_world = Quaternion(
        operator.contact_ball_trackball_to_world
    )
    operator.contact_ball_frame_initial_view_vector = Vector(
        operator.contact_ball_view_vector
    ).copy()
    operator.contact_ball_active = True
    # Always reassert the full intended pose. At exact dot-to-dot re-entry the
    # translation delta is zero, but a dependency update may already have
    # evaluated the stale detached solver orientation. A translation-only
    # difference test would therefore preserve a 180-degree pose flip.
    desired_output = (
        armature.matrix_world.inverted_safe() @ corrected_world
    )
    _set_pose_bone_constrained_output_matrix(
        context,
        armature,
        pose_bone,
        desired_output,
    )
    return True


def _pin_contact_ball_joint_requested_handle(operator, raw_world):
    handle_local = Vector(operator.contact_ball_handle_local)
    return (
        Vector(operator.contact_ball_initial_handle)
        + (raw_world @ handle_local)
        - Vector(operator.contact_ball_raw_handle)
    )


def _pin_contact_ball_joint_pulled_free(operator, raw_world):
    operator.contact_pressure_release_requested = False
    if not bool(getattr(operator, "contact_ball_active", False)):
        return False
    local_anchor = getattr(operator, "contact_ball_anchor_local", None)
    raw_anchor = getattr(operator, "contact_ball_raw_anchor", None)
    surface_normal = getattr(
        operator,
        "contact_ball_surface_normal",
        None,
    )
    if (
        local_anchor is None
        or raw_anchor is None
        or surface_normal is None
    ):
        return False
    surface_normal = Vector(surface_normal)
    if surface_normal.length_squared <= 1.0e-12:
        return False
    surface_normal.normalize()
    release_distance = (
        PIN_SNAP_WORLD_RADIUS
        * PIN_SNAP_RELEASE_PIXEL_RADIUS
        / PIN_SNAP_PIXEL_RADIUS
    )
    requested = _pin_contact_ball_joint_requested_handle(
        operator, raw_world
    )
    requested_anchor = raw_world @ Vector(local_anchor)
    target = Vector(
        getattr(
            operator,
            "contact_ball_target",
            Vector(operator.contact_ball_initial_handle)
            - Vector(operator.contact_ball_radial),
        )
    )
    # Pushing into the contacted plane is pressure, never release. This uses
    # the stored surface normal, so the rule is identical on floors and walls.
    if (Vector(requested_anchor) - target).dot(surface_normal) < -1.0e-6:
        return False
    current_world = getattr(operator, "contact_ball_current_world", None)
    if current_world is not None:
        current_anchor = Matrix(current_world) @ Vector(local_anchor)
        if (Vector(current_anchor) - target).length > PIN_SNAP_WORLD_RADIUS:
            # Pressure can transfer support to the rod's far endpoint, moving
            # the real pink endpoint outside its physical socket while the
            # corrected viewport pose no longer follows additional mouse
            # input. Screen-space arc intent is not authoritative after that
            # transfer: keeping it latched is the visible permanent freeze.
            operator.contact_pressure_release_requested = True
            return True
    screen_state = _pin_contact_ball_joint_screen_release_state(operator)
    if screen_state is not None:
        # Screen-space radial motion distinguishes a deliberate pull from a
        # wide ball-joint arc. A large world chord during that arc must not
        # release the socket.
        released = bool(screen_state[0])
        if released and bool(getattr(
            operator,
            "contact_pressure_ever_active",
            False,
        )):
            operator.contact_pressure_release_requested = True
        return released
    current_handle = Vector(
        getattr(
            operator,
            "contact_ball_current_handle",
            operator.contact_ball_initial_handle,
        )
    )
    current_radial = current_handle - target
    radial = (
        current_radial.normalized()
        if current_radial.length_squared > 1.0e-12
        else Vector(operator.contact_ball_radial).normalized()
    )
    # Measure excess input from the currently solved socket position. This
    # follows the limb as it rolls, so pulling along a tilted/sideways limb can
    # leave the socket instead of being rejected by the initial screen cone.
    handle_displacement = requested - current_handle
    radial_outward = handle_displacement.dot(radial)
    # Projection can be unavailable end-on or outside the region. Keep one
    # direction-independent world fallback for those cases only.
    released = bool(radial_outward > release_distance)
    if released and bool(getattr(
        operator,
        "contact_pressure_ever_active",
        False,
    )):
        operator.contact_pressure_release_requested = True
    return released


def _pin_contact_ball_joint_advance_release_state(operator):
    """Keep pressure pull-out terminal; advance ordinary pull-out normally."""
    if not (
        getattr(operator, "contact_explicitly_released", False)
        and not getattr(operator, "contact_keep_attached", False)
        and not getattr(operator, "contact_ball_active", False)
    ):
        return False
    if getattr(operator, "contact_pressure_released", False):
        # A rolled support transfer already put the real pin outside its
        # socket. Preserve one immutable detached baseline for the rest of the
        # drag; magnetic aiming/re-entry here caused the recorded alternating
        # teleports and could feed collision output back into mouse input.
        operator.contact_detached_continuity_active = True
        operator.contact_detached_magnetic_active = False
        return True
    operator.contact_explicitly_released = False
    operator.contact_detached_continuity_active = False
    operator.contact_detached_magnetic_active = True
    return False


def _pin_contact_ball_joint_screen_release_state(operator):
    """Resolve one direction-independent screen-space pull boundary."""
    current = getattr(operator, "contact_current_mouse", None)
    initial = getattr(operator, "contact_ball_initial_mouse", None)
    previous = getattr(operator, "contact_ball_previous_mouse", None)
    target = getattr(operator, "contact_ball_target_screen", None)
    if (
        current is None
        or initial is None
        or previous is None
        or target is None
    ):
        return None
    current = Vector(current)
    initial = Vector(initial)
    previous = Vector(previous)
    target = Vector(target)
    initial_radial = initial - target
    current_radial = current - target
    if initial_radial.length_squared <= 1.0e-12:
        return None
    step = current - previous
    current_direction = (
        current_radial.normalized()
        if current_radial.length_squared > 1.0e-12
        else initial_radial.normalized()
    )
    radial_excess = current_radial.length - initial_radial.length
    radial_step = step.dot(current_direction)
    tangent_step = (
        step - current_direction * radial_step
    ).length
    outward_sample = bool(
        radial_excess > 0.0
        and radial_step > 0.0
        and radial_step
        >= tangent_step * PIN_SNAP_RELEASE_RADIAL_INTENT_RATIO
    )
    release = bool(
        outward_sample
        and radial_excess > PIN_SNAP_RELEASE_PIXEL_RADIUS
    )
    return (
        release,
        float(radial_excess),
        outward_sample,
        False,
        current,
    )


def _pin_contact_ball_joint_swing(operator, initial, input_delta):
    initial = Vector(initial)
    radius = initial.length
    if radius <= 1.0e-8:
        return Quaternion()
    radial = initial / radius
    tangent = (
        Vector(input_delta)
        - radial * Vector(input_delta).dot(radial)
    )
    tangent_distance = tangent.length
    if tangent_distance <= 1.0e-10:
        return Quaternion()
    axis = radial.cross(tangent / tangent_distance)
    if axis.length_squared <= 1.0e-12:
        return Quaternion()
    axis.normalize()
    operator.contact_ball_previous_axis = axis.copy()
    return Quaternion(axis, tangent_distance / radius)


def _pin_contact_ball_joint_view_swing(context, initial, input_delta):
    """Map free G to one exact screen-plane arc without perspective roll."""
    initial = Vector(initial)
    view_axis = _pin_keyboard_view_axis(context).normalized()
    screen_radial = initial - view_axis * initial.dot(view_axis)
    screen_radius = screen_radial.length
    if screen_radius <= 1.0e-8:
        return None
    tangent = view_axis.cross(screen_radial / screen_radius)
    signed_distance = Vector(input_delta).dot(tangent)
    return Quaternion(view_axis, signed_distance / screen_radius)


def _pin_contact_ball_joint_view_step(
    context,
    operator,
    target,
    requested,
):
    """Return an absolute, continuous two-angle virtual-trackball swing."""
    (
        view_axis,
        candidate_direction,
        planar_radius,
        depth,
    ) = _pin_contact_ball_joint_trackball_components(
        context,
        operator,
        target,
        requested,
    )
    previous_direction = getattr(
        operator,
        "contact_ball_view_screen_direction",
        None,
    )
    previous_vector = getattr(operator, "contact_ball_view_vector", None)
    if previous_direction is None or previous_vector is None:
        operator.contact_ball_view_screen_direction = (
            candidate_direction.copy()
        )
        operator.contact_ball_view_elevation = math.atan2(
            depth,
            planar_radius,
        )
        operator.contact_ball_view_initial_elevation = (
            operator.contact_ball_view_elevation
        )
        operator.contact_ball_view_azimuth = 0.0
        operator.contact_ball_view_vector = (
            candidate_direction * planar_radius
            + view_axis * depth
        ).normalized()
        return Quaternion()
    previous_direction = Vector(previous_direction).normalized()
    previous_vector = Vector(previous_vector).normalized()
    signed_radius = planar_radius
    # Polar direction is undefined at the exact trackball pole. Keep the
    # previous meridian only for numerical zero; non-zero screen noise is safe
    # because it is weighted by planar_radius in the 3D vector below.
    if planar_radius <= 1.0e-6:
        current_direction = previous_direction.copy()
        signed_radius = 0.0
    else:
        current_direction = candidate_direction.copy()
        # Crossing the pointer through the pin center reverses its raw screen
        # direction. Keep the same meridian and make radius signed so this is
        # represented as elevation continuing past 90 degrees, not an
        # instantaneous 180-degree azimuth flip.
        if current_direction.dot(previous_direction) < 0.0:
            current_direction.negate()
            signed_radius = -planar_radius
    raw_elevation = math.atan2(depth, signed_radius)
    previous_elevation = float(getattr(
        operator,
        "contact_ball_view_elevation",
        raw_elevation,
    ))
    elevation = raw_elevation
    while elevation - previous_elevation > math.pi:
        elevation -= 2.0 * math.pi
    while elevation - previous_elevation < -math.pi:
        elevation += 2.0 * math.pi
    current = (
        current_direction * signed_radius
        + view_axis * depth
    ).normalized()
    trackball_to_world = Quaternion(
        getattr(
            operator,
            "contact_ball_initial_trackball_to_world",
            getattr(
                operator,
                "contact_ball_trackball_to_world",
                Quaternion(),
            ),
        )
    )
    view_axis = Vector(view_axis).normalized()
    azimuth_step = math.atan2(
        view_axis.dot(previous_direction.cross(current_direction)),
        max(-1.0, min(1.0, previous_direction.dot(current_direction))),
    )
    azimuth = float(getattr(
        operator,
        "contact_ball_view_azimuth",
        0.0,
    )) + azimuth_step
    initial_direction = Vector(getattr(
        operator,
        "contact_ball_initial_screen_direction",
        previous_direction,
    )).normalized()
    initial_elevation = float(getattr(
        operator,
        "contact_ball_view_initial_elevation",
        previous_elevation,
    ))
    elevation_axis = initial_direction.cross(view_axis)
    if elevation_axis.length_squared <= 1.0e-12:
        elevation_axis = view_axis.orthogonal().normalized()
    else:
        elevation_axis.normalize()
    view_rotation = (
        Quaternion(view_axis, azimuth)
        @ Quaternion(elevation_axis, elevation - initial_elevation)
    )
    swing = (
        trackball_to_world
        @ view_rotation
        @ trackball_to_world.inverted()
    )
    operator.contact_ball_view_screen_direction = current_direction.copy()
    operator.contact_ball_view_elevation = elevation
    operator.contact_ball_view_azimuth = azimuth
    operator.contact_ball_view_vector = current.copy()
    return swing


def _pin_contact_ball_joint_trackball_components(
    context,
    operator,
    target,
    requested,
):
    """Map a pointer-plane point onto a smooth virtual trackball.

    A direct orthographic sphere projection has an infinite derivative at its
    rim. A side-on limb starts exactly on that rim, so even a tiny inward
    mouse sample used to create a large rotation and visible teleport. Use
    the conventional sphere/hyperbolic-sheet blend instead: the inner region
    retains spherical ball-joint motion while the outer region has a finite,
    continuous slope.
    """
    region_data = getattr(context, "region_data", None)
    if region_data is not None:
        view_basis = (
            region_data.view_matrix.inverted_safe().to_3x3().normalized()
        )
        view_right = (view_basis @ Vector((1.0, 0.0, 0.0))).normalized()
        view_up = (view_basis @ Vector((0.0, 1.0, 0.0))).normalized()
        view_axis = (view_basis @ Vector((0.0, 0.0, 1.0))).normalized()
    else:
        view_axis = _pin_keyboard_view_axis(context).normalized()
        view_right = view_axis.orthogonal().normalized()
        view_up = view_axis.cross(view_right).normalized()
    radial = Vector(requested) - Vector(target)
    reference_radius = max(
        1.0e-8,
        float(getattr(operator, "contact_ball_view_radius", radial.length)),
    )
    horizontal = radial.dot(view_right) / reference_radius
    vertical = radial.dot(view_up) / reference_radius
    planar_squared = (horizontal * horizontal) + (vertical * vertical)
    planar_length = math.sqrt(max(0.0, planar_squared))
    if planar_squared <= 0.5:
        depth = (
            float(
                getattr(operator, "contact_ball_view_depth_sign", 1.0)
            )
            * math.sqrt(max(0.0, 1.0 - planar_squared))
        )
    else:
        depth = (
            float(
                getattr(operator, "contact_ball_view_depth_sign", 1.0)
            )
            * 0.5
            / max(1.0e-8, planar_length)
        )
    planar = view_right * horizontal + view_up * vertical
    direction = (
        planar / planar_length
        if planar_length > 1.0e-10
        else view_up.copy()
    )
    return view_axis, direction, planar_length, depth


def _pin_contact_ball_joint_sync_current(operator, armature, pose_bone):
    """Refresh displayed endpoints without changing the modal input frame."""
    handle_local = getattr(operator, "contact_ball_handle_local", None)
    if (
        not bool(getattr(operator, "contact_ball_active", False))
        or handle_local is None
    ):
        return False
    current_world = armature.matrix_world @ pose_bone.matrix
    operator.contact_ball_current_world = current_world.copy()
    operator.contact_ball_current_handle = (
        current_world @ Vector(handle_local)
    )
    # Every modal event restores Blender's transform-start pose before this
    # solver runs. Rebasing the ball frame to the previous corrected pose made
    # odd and even events use different baselines, causing pressure flicker.
    return True


def _pin_contact_ball_joint_magnetic_aim(
    context,
    operator,
    target_data,
    target,
    anchor,
):
    """Aim a released endpoint at its pin without replacing its roll frame."""
    _kind, armature, pose_bone, _guide = target_data
    handle_local = getattr(operator, "contact_ball_handle_local", None)
    if handle_local is None:
        return False
    current_world = armature.matrix_world @ pose_bone.matrix
    pivot = current_world @ Vector(handle_local)
    current_vector = Vector(anchor) - pivot
    target_vector = Vector(target) - pivot
    if (
        current_vector.length_squared <= 1.0e-12
        or target_vector.length_squared <= 1.0e-12
    ):
        return False
    swing = current_vector.normalized().rotation_difference(
        target_vector.normalized()
    )
    if abs(float(swing.angle)) <= 1.0e-8:
        return False
    desired_world = (
        Matrix.Translation(pivot)
        @ swing.to_matrix().to_4x4()
        @ Matrix.Translation(-pivot)
        @ current_world
    )
    return _set_pose_bone_constrained_output_matrix(
        context,
        armature,
        pose_bone,
        armature.matrix_world.inverted_safe() @ desired_world,
    )


def _pin_contact_ball_joint_sweep_collision(
    context,
    operator,
    target_data,
    start_world,
):
    """Apply the same two-end pressure pivot used by indirect transforms."""
    _kind, armature, pose_bone, guide = target_data
    end_world = armature.matrix_world @ pose_bone.matrix
    target, normal, anchor = _surface_contact_world_point_normal(
        context,
        guide,
    )
    if (
        target is None
        or normal is None
        or anchor is None
        or not _surface_contact_pose_is_invalid(
            context,
            guide,
            target,
            normal,
            anchor,
        )
    ):
        return False

    opposite = _surface_contact_opposite_anchor_world(context, guide)
    if opposite is None:
        return False
    solved_world = _surface_contact_pressure_rod_world(
        guide,
        end_world,
        target,
        normal,
        anchor,
        opposite,
    )
    if solved_world is None:
        return False
    # The normal ball-joint solve already locked screen tilt. Do not run that
    # lock again after changing which rod endpoint is the pivot: its radial is
    # based on the bottom target and would bend the newly planted top endpoint
    # back through the surface, alternating between two poses.
    end_world = solved_world
    _set_pose_bone_constrained_output_matrix(
        context,
        armature,
        pose_bone,
        armature.matrix_world.inverted_safe() @ end_world,
    )
    operator.contact_ball_current_world = (
        armature.matrix_world @ pose_bone.matrix
    )
    operator.contact_ball_current_handle = (
        operator.contact_ball_current_world
        @ Vector(operator.contact_ball_handle_local)
    )
    return True


def _pin_contact_ball_joint_apply(
    context,
    operator,
    target_data,
    raw_world,
):
    _kind, armature, pose_bone, guide = target_data
    if not bool(getattr(operator, "contact_ball_active", False)):
        if not _pin_contact_ball_joint_capture(
            context,
            operator,
            target_data,
            raw_world,
        ):
            return False
    target = Vector(operator.contact_ball_target)
    if operator.transform_mode == "TRANSLATE":
        requested = _pin_contact_ball_joint_requested_handle(
            operator,
            raw_world,
        )
        initial_handle = Vector(operator.contact_ball_initial_handle)
        free_view_arc = bool(
            int(getattr(operator, "axis_index", -1)) < 0
            and int(getattr(operator, "plane_axis_index", -1)) < 0
        )
        if free_view_arc:
            swing = _pin_contact_ball_joint_view_step(
                context,
                operator,
                target,
                requested,
            )
            baseline_world = Matrix(getattr(
                operator,
                "contact_ball_frame_initial_world",
                operator.contact_ball_initial_world,
            ))
        else:
            swing = _pin_contact_ball_joint_swing(
                operator,
                initial_handle - target,
                requested - initial_handle,
            )
            baseline_world = Matrix(operator.contact_ball_initial_world)
        desired_world = (
            Matrix.Translation(target)
            @ swing.to_matrix().to_4x4()
            @ Matrix.Translation(-target)
            @ baseline_world
        )
        if free_view_arc:
            desired_world = _pin_contact_ball_joint_lock_tilt(
                operator,
                target,
                desired_world,
            )
        current_mouse = getattr(operator, "contact_current_mouse", None)
        initial_mouse = getattr(
            operator,
            "contact_ball_initial_mouse",
            None,
        )
        return_radius = max(1.0, PIN_SNAP_PIXEL_RADIUS)
        mouse_return_distance = (
            (Vector(current_mouse) - Vector(initial_mouse)).length
            if current_mouse is not None and initial_mouse is not None
            else None
        )
        if (
            mouse_return_distance is not None
            and mouse_return_distance > return_radius
        ):
            operator.contact_ball_left_return_zone = True
        if (
            mouse_return_distance is not None
            and bool(getattr(
                operator,
                "contact_ball_left_return_zone",
                False,
            ))
            and mouse_return_distance <= return_radius
        ):
            # A closed pointer loop has one authoritative answer: the exact
            # captured pose. Use half the visible entry radius instead of a
            # single hardware pixel: normal hand/mouse input rarely returns
            # to the identical integer coordinate, and retaining incremental
            # spherical holonomy there is the visible pinwheel drift.
            desired_world = Matrix(
                operator.contact_ball_initial_world
            ).copy()
        operator.contact_ball_previous_requested = requested.copy()
    else:
        desired_world = raw_world.copy()
        anchor = (
            desired_world @ Vector(operator.contact_ball_anchor_local)
        )
        desired_world.translation += target - anchor
    # Produce the planted and pressure-corrected result before publishing any
    # pose. The previous raw-arc + correction loop exposed several different
    # matrices to the viewport during one mouse sample and visibly flickered.
    desired_anchor = desired_world @ Vector(operator.contact_ball_anchor_local)
    desired_world.translation += target - desired_anchor
    desired_anchor = desired_world @ Vector(operator.contact_ball_anchor_local)
    desired_opposite = desired_world @ Vector(
        getattr(
            operator,
            "contact_ball_opposite_local",
            operator.contact_ball_handle_local,
        )
    )
    pressure_normal = Vector(operator.contact_ball_surface_normal)
    if pressure_normal.length_squared > 1.0e-12:
        pressure_normal.normalize()
        if (desired_opposite - target).dot(pressure_normal) < -1.0e-7:
            pressure_world = _surface_contact_pressure_rod_world(
                guide,
                desired_world,
                target,
                pressure_normal,
                desired_anchor,
                desired_opposite,
            )
            if pressure_world is not None:
                desired_world = pressure_world
                operator.contact_pressure_ever_active = True
    changed = _set_pose_bone_constrained_output_matrix(
        context,
        armature,
        pose_bone,
        armature.matrix_world.inverted_safe() @ desired_world,
    )
    current_world = armature.matrix_world @ pose_bone.matrix
    operator.contact_ball_current_world = current_world.copy()
    operator.contact_ball_current_handle = (
        current_world @ Vector(operator.contact_ball_handle_local)
    )
    operator.contact_ball_previous_raw_world = Matrix(raw_world).copy()
    current_mouse = getattr(operator, "contact_current_mouse", None)
    if current_mouse is not None:
        operator.contact_ball_previous_mouse = tuple(
            float(value) for value in current_mouse
        )
    return changed
