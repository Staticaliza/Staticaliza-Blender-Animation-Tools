"""Exclusive dot-to-dot snap arbitration for bones carrying both pin types."""

from ..core.runtime import *  # noqa: F403


def _pin_reset_dual_snap_owners():
    _state["pin_dual_snap_owners"] = {}


def _pin_snap_ring_visible(snap_key, target, current):
    """Show a ring only for an authoritative attachment latch.

    Geometric dot overlap is also produced by detached magnetic aiming and
    collision correction during an ancestor transform. Treating coincidence
    as attachment made the ring flicker even though no true snap occurred.
    """
    return str(snap_key) in _state.setdefault("pin_snap_latches", set())


def _pin_snap_sample_with_sweep(
    target,
    current,
    snap_key,
    world_radius = PIN_SNAP_WORLD_RADIUS,
):
    """Catch fast outside-to-outside crossings without trapping a snap."""
    target = Vector(target)
    current = Vector(current)
    snap_key = str(snap_key)
    previous_points = _state.setdefault("pin_snap_previous_points", {})
    previous = previous_points.get(snap_key)
    previous_points[snap_key] = current.copy()
    direct = (target - current).length <= world_radius
    swept = False
    if previous is not None:
        previous = Vector(previous)
        # Starting inside means the user is pulling away from a snap, not
        # entering a new one.
        previous_outside = (target - previous).length > world_radius
        segment = current - previous
        if previous_outside and segment.length_squared > 1.0e-12:
            factor = max(
                0.0,
                min(
                    1.0,
                    (target - previous).dot(segment)
                    / segment.length_squared,
                ),
            )
            closest = previous + (segment * factor)
            swept = (target - closest).length <= world_radius
    swept_hits = _state.setdefault("pin_snap_swept_hits", set())
    if swept:
        swept_hits.add(snap_key)
    return bool(direct or snap_key in swept_hits)


def _pin_yellow_takeover_contact(context, guide):
    """Detach Contact without letting its solver alter a yellow snap sample."""
    changed = _surface_contact_set_constraint_attachment(guide, False)
    _surface_contact_set_snap_detached(guide, True)
    _state.setdefault("pin_snap_latches", set()).discard(
        _surface_contact_snap_key(guide)
    )
    armature, pose_bone = _surface_contact_pose_bone(guide)
    if armature is not None and pose_bone is not None:
        _state.setdefault("pin_snap_live_pose_matrices", {}).pop(
            (_armature_session_uid(armature), pose_bone.name),
            None,
        )
    if changed:
        context.view_layer.update()
    return changed


def _pin_unsolved_world_point(armature, pose_bone, local_point):
    """Resolve a bone-local point before Contact constraints alter evaluation."""
    try:
        pose_matrix = armature.convert_space(
            pose_bone = pose_bone,
            matrix = pose_bone.matrix_basis,
            from_space = "LOCAL",
            to_space = "POSE",
        )
        world = armature.matrix_world @ pose_matrix @ Vector(local_point)
        return Vector((world.x, world.y, world.z))
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return None


def _pin_yellow_endpoint_source(context, armature, pose_bone):
    """Use original pose data during modal transforms, evaluated data otherwise."""
    depsgraph = context.evaluated_depsgraph_get()
    endpoint_armature = (
        armature
        if (
            _state.get("pin_snap_transform_active")
            or _state.get("pin_keyboard_transform_active")
        )
        else armature.evaluated_get(depsgraph)
    )
    return (
        depsgraph,
        endpoint_armature,
        endpoint_armature.pose.bones.get(pose_bone.name),
    )


def _yellow_snap_pose_bone(
    context,
    armature,
    pose_bone,
    packed,
    insert_keys = True,
    update_view_layer = True,
    use_snap_hysteresis = False,
):
    target = Vector(packed[0])
    depsgraph, endpoint_armature, endpoint_bone = (
        _pin_yellow_endpoint_source(context, armature, pose_bone)
    )
    current = (
        _yellow_current_world_point(
            depsgraph, endpoint_armature, endpoint_bone, packed
        )
        if endpoint_bone is not None
        else None
    )
    if current is None:
        return False
    snap_key = f"YELLOW:{_armature_session_uid(armature)}:{pose_bone.name}"
    snap_close = _pin_snap_should_engage(
        context,
        snap_key,
        target,
        current,
        use_hysteresis = use_snap_hysteresis,
    )
    if not snap_close or (target - current).length <= 1.0e-7:
        if (target - current).length <= 1.0e-7:
            _state.setdefault("pin_snap_swept_hits", set()).discard(snap_key)
        return False
    _state.setdefault("pin_snap_latches", set()).add(snap_key)

    locked_axes = tuple(bool(value) for value in pose_bone.lock_location[:3])
    changed = False
    previous_error = float("inf")
    for _iteration in range(4):
        depsgraph, endpoint_armature, endpoint_bone = (
            _pin_yellow_endpoint_source(context, armature, pose_bone)
        )
        if endpoint_bone is None:
            break
        current = _yellow_current_world_point(
            depsgraph, endpoint_armature, endpoint_bone, packed
        )
        if current is None:
            break
        delta = target - current
        error = delta.length
        if error <= 1.0e-7 or error >= previous_error - 1.0e-9:
            break
        previous_error = error
        try:
            armature_delta = (
                armature.matrix_world.inverted_safe().to_3x3() @ delta
            )
        except (
            AttributeError,
            ReferenceError,
            RuntimeError,
            TypeError,
            ValueError,
        ):
            break
        for axis_index, locked in enumerate(locked_axes):
            if locked:
                armature_delta[axis_index] = 0.0
        if armature_delta.length_squared <= 1.0e-12:
            break
        matrix = pose_bone.matrix.copy()
        matrix.translation += armature_delta
        pose_bone.matrix = matrix
        context.view_layer.update()
        changed = True
    if (
        changed
        and insert_keys
        and bool(
            getattr(context.scene.tool_settings, "use_keyframe_insert_auto", False)
        )
    ):
        _insert_bone_keys(pose_bone, int(context.scene.frame_current))
    if changed and update_view_layer:
        context.view_layer.update()
    if changed:
        _state.setdefault("pin_snap_swept_hits", set()).discard(snap_key)
        _state.setdefault("pin_snap_previous_points", {})[snap_key] = target.copy()
    return changed


def _pin_yellow_snap_active_for_contact(
    context,
    guide = None,
    armature = None,
    pose_bone = None,
):
    """Return whether this contact's owner currently sits in its yellow ring."""
    if guide is not None:
        armature = bpy.data.objects.get(
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
        )
        pose_bone = (
            armature.pose.bones.get(
                str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
            )
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
    if pose_bone is None:
        return False
    packed = _state.get("yellow_fixed", {}).get(
        _owner_bone_key(armature, pose_bone.name)
    )
    if not packed:
        return False
    try:
        depsgraph, endpoint_armature, endpoint_bone = (
            _pin_yellow_endpoint_source(context, armature, pose_bone)
        )
        current = (
            _yellow_current_world_point(
                depsgraph,
                endpoint_armature,
                endpoint_bone,
                packed,
            )
            if endpoint_bone is not None
            else None
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        current = None
    if current is None:
        return False
    snap_key = f"YELLOW:{_armature_session_uid(armature)}:{pose_bone.name}"
    return _pin_snap_should_engage(
        context,
        snap_key,
        packed[0],
        current,
        use_hysteresis = True,
    )


def _pin_apply_yellow_priority(context, armature, pose_bone):
    """Apply yellow immediately from a linked-bone transform path."""
    if (
        armature is None
        or pose_bone is None
        or not _pin_yellow_snap_active_for_contact(
            context,
            armature = armature,
            pose_bone = pose_bone,
        )
    ):
        return False
    frame = int(context.scene.frame_current)
    changed = False
    for guide in _surface_contact_guides():
        if (
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
            == armature.name
            and str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
            == pose_bone.name
            and _surface_contact_guide_active_at(guide, frame)
        ):
            changed = _pin_yellow_takeover_contact(context, guide) or changed
    packed = _state.get("yellow_fixed", {}).get(
        _owner_bone_key(armature, pose_bone.name)
    )
    return _yellow_snap_pose_bone(
        context,
        armature,
        pose_bone,
        packed,
        insert_keys = False,
        use_snap_hysteresis = False,
    ) or changed


def _pin_snap_scope_bones(context):
    """Include the linked bone when a pin owns the visible selection."""
    grouped = _selected_pose_bones_by_owner(context)
    try:
        _key, target_data = _pin_selected_target_data(context)
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        target_data = None
    if not target_data:
        return grouped
    _kind, armature, pose_bone, _payload = target_data
    if armature is None or pose_bone is None:
        return grouped
    scoped = grouped.setdefault(armature, [])
    if pose_bone not in scoped:
        scoped.append(pose_bone)
    return grouped


def _surface_contact_direct_bone_names(guide):
    """Bones that represent the edited pink limb, excluding its ancestors."""
    return {
        str(guide.get(property_name, ""))
        for property_name in (
            SURFACE_CONTACT_BONE_PROPERTY,
            SURFACE_CONTACT_CONTROL_BONE_PROPERTY,
            SURFACE_CONTACT_GEOMETRY_BONE_PROPERTY,
        )
        if str(guide.get(property_name, ""))
    }


def _pin_dual_snap_owner(
    context,
    guide = None,
    armature = None,
    pose_bone = None,
):
    """Choose one in-range snap system from the unsolved pose sample."""
    if guide is not None:
        armature = bpy.data.objects.get(
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
        )
        pose_bone = (
            armature.pose.bones.get(
                str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
            )
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
    if armature is None or pose_bone is None:
        return ""
    key = _owner_bone_key(armature, pose_bone.name)
    owners = _state.setdefault("pin_dual_snap_owners", {})
    if guide is None:
        return str(owners.get(key, ""))

    packed = _state.get("yellow_fixed", {}).get(key)
    if not packed:
        owners[key] = ""
        return ""
    if _pin_yellow_snap_active_for_contact(
        context,
        guide,
        armature,
        pose_bone,
    ):
        owners[key] = "YELLOW"
        return "YELLOW"

    frame = int(context.scene.frame_current)
    for contact in _surface_contact_guides():
        if (
            str(contact.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
            != armature.name
            or str(contact.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
            != pose_bone.name
            or not _surface_contact_guide_active_at(contact, frame)
        ):
            continue
        target, _normal, anchor = _surface_contact_world_point_normal(
            context,
            contact,
        )
        if (
            target is not None
            and anchor is not None
            and _pin_points_within_snap_radius(context, target, anchor)
        ):
            owners[key] = "CONTACT"
            return "CONTACT"
    owners[key] = ""
    return ""
