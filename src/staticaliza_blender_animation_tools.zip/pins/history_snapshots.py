"""Compatibility snapshots and non-history state used around Undo/Redo."""

from ..core.runtime import *  # noqa: F403


def _surface_contact_history_driver_signature(
    context, armature, pose_bone
):
    selected = {
        selected_bone.name
        for selected_bone in _selected_pose_bones_by_owner(context).get(
            armature, ()
        )
    }
    signature = []
    current = getattr(pose_bone, "parent", None)
    while current is not None:
        if current.name in selected:
            world = armature.matrix_world @ current.matrix
            signature.append((
                current.name,
                tuple(
                    round(float(value), 8)
                    for row in world
                    for value in row
                ),
            ))
        current = current.parent
    return tuple(signature)


def _surface_contact_history_snapshot(context):
    scene = getattr(context, "scene", None) if context is not None else None
    if scene is None:
        return {
            "targets": {},
            "poses": {},
            "pose_matrices": {},
            "drivers": {},
            "engaged": set(),
            "selected": set(),
        }
    targets = {}
    poses = {}
    pose_matrices = {}
    drivers = {}
    engaged = set()
    selected = set()
    detached_keys = _state.setdefault("pin_snap_detached", set())
    departing_keys = _state.setdefault("pin_snap_departing", set())
    for guide in _surface_contact_active_simulated_guides(scene):
        armature = bpy.data.objects.get(
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
        )
        owner_key = (_armature_session_uid(armature), guide.name)
        matrix = guide.matrix_world.copy()
        targets[owner_key] = tuple(
            round(float(value), 8)
            for row in matrix
            for value in row
        )
        pose_bone = (
            armature.pose.bones.get(
                str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
            )
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is not None:
            poses[owner_key] = tuple(
                round(float(value), 8)
                for row in pose_bone.matrix_basis
                for value in row
            )
            pose_matrices[owner_key] = pose_bone.matrix_basis.copy()
            drivers[owner_key] = _surface_contact_history_driver_signature(
                context,
                armature,
                pose_bone,
            )
        if _surface_contact_guide_directly_selected(context, guide):
            selected.add(owner_key)
        snap_key = _surface_contact_snap_key(guide)
        if (
            snap_key not in departing_keys
            and snap_key not in detached_keys
            and not bool(
                guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)
            )
        ):
            engaged.add(owner_key)
    return {
        "targets": targets,
        "poses": poses,
        "pose_matrices": pose_matrices,
        "drivers": drivers,
        "engaged": engaged,
        "selected": selected,
    }


def _surface_contact_restore_history_poses(
    context,
    snapshot,
    *,
    update_view_layer=True,
    owner_keys=None,
):
    """Keep unrelated Undo/Redo from re-evaluating contact-owned limbs."""
    changed = False
    matrices = dict((snapshot or {}).get("pose_matrices", {}))
    owner_keys = None if owner_keys is None else set(owner_keys)
    for guide in _surface_contact_active_simulated_guides(context.scene):
        armature = bpy.data.objects.get(
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
        )
        owner_key = (_armature_session_uid(armature), guide.name)
        if owner_keys is not None and owner_key not in owner_keys:
            continue
        matrix_basis = matrices.get(owner_key)
        pose_bone = _surface_contact_simulated_pose_bone(guide)
        if (
            matrix_basis is not None
            and pose_bone is not None
            and _pin_keyboard_matrices_differ(
                pose_bone.matrix_basis,
                matrix_basis,
            )
        ):
            pose_bone.matrix_basis = matrix_basis.copy()
            changed = True
    if changed and update_view_layer:
        context.view_layer.update()
    return changed


def _pin_history_regular_pose_snapshot(context):
    """Capture non-contact pose owners to recognize selection-only history."""
    scene = getattr(context, "scene", None) if context is not None else None
    if scene is None:
        return {}
    contact_bones = set()
    for guide in _surface_contact_active_simulated_guides(scene):
        armature, pose_bone = _surface_contact_pose_bone(guide)
        if armature is not None and pose_bone is not None:
            contact_bones.add((armature.name, pose_bone.name))
    snapshot = {}
    for armature in tuple(scene.objects):
        if armature.type != "ARMATURE" or getattr(armature, "pose", None) is None:
            continue
        for pose_bone in armature.pose.bones:
            key = (armature.name, pose_bone.name)
            if key not in contact_bones:
                snapshot[key] = pose_bone.matrix_basis.copy()
    return snapshot


def _pin_history_regular_pose_changed(context):
    previous = _state.get("pin_history_pre_regular_pose_matrices", {})
    for (armature_name, bone_name), basis in previous.items():
        armature = bpy.data.objects.get(armature_name)
        pose_bone = (
            armature.pose.bones.get(bone_name)
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if (
            pose_bone is not None
            and _pin_keyboard_matrices_differ(
                pose_bone.matrix_basis,
                basis,
                epsilon=1.0e-6,
            )
        ):
            return True
    return False


def _pin_nonhistory_snapshot(context):
    """Capture pin membership/onion visibility, which are UI state, not edits."""
    scene = getattr(context, "scene", None) if context is not None else None
    if scene is None:
        return {"owners": {}, "pins": {}}
    enabled = set(_state.get("onion_enabled_owners", set()))
    owners = {}
    armature_access = {}
    pins = {}
    for armature in tuple(getattr(scene, "objects", ())):
        if armature.type != "ARMATURE" or getattr(armature, "pose", None) is None:
            continue
        owner_key = (_armature_session_uid(armature), armature.name)
        owners[owner_key] = bool(
            owner_key[0] in enabled
            or armature.get(ONION_SKIN_ENABLED_PROPERTY, False)
        )
        try:
            armature_access[owner_key] = {
                "hide_viewport": bool(armature.hide_viewport),
                "hide_select": bool(armature.hide_select),
                "hidden": bool(armature.hide_get()),
            }
        except (AttributeError, ReferenceError, RuntimeError):
            pass
        runtime_modes = _yellow_owner_map("yellow_modes", armature)
        runtime_fixed = _yellow_owner_map("yellow_fixed", armature)
        for pose_bone in armature.pose.bones:
            runtime = runtime_fixed.get(pose_bone.name)
            stored_target = pose_bone.get(YELLOW_PIN_TARGET_PROPERTY)
            exists = bool(
                pose_bone.name in runtime_modes
                or runtime is not None
                or stored_target is not None
            )
            if not exists:
                continue
            try:
                mode = int(pose_bone.get(
                    YELLOW_PIN_MODE_PROPERTY,
                    runtime_modes.get(pose_bone.name, 1),
                ))
            except (TypeError, ValueError):
                mode = 1
            target = stored_target
            if target is None and runtime is not None:
                target = runtime[0]
            try:
                target = tuple(float(value) for value in target[:3])
            except (IndexError, TypeError, ValueError):
                target = None
            initial_target = pose_bone.get(
                YELLOW_PIN_INITIAL_TARGET_PROPERTY,
                target,
            )
            try:
                initial_target = tuple(
                    float(value) for value in initial_target[:3]
                )
            except (IndexError, TypeError, ValueError):
                initial_target = target
            pins[(owner_key[0], owner_key[1], pose_bone.name)] = {
                "mode": max(1, min(5, mode)),
                "axis": str(
                    pose_bone.get(YELLOW_PIN_AXIS_PROPERTY, "Y_NEG")
                ),
                "target": target,
                "initial_target": initial_target,
            }
    return {
        "owners": owners,
        "pins": pins,
        "armature_access": armature_access,
    }


def _restore_pin_nonhistory_snapshot(context, snapshot):
    """Keep pin add/remove and onion enable state outside undo/redo history."""
    if not snapshot or context is None or getattr(context, "scene", None) is None:
        return False
    owners = dict(snapshot.get("owners", {}))
    pins = dict(snapshot.get("pins", {}))
    armature_access = dict(snapshot.get("armature_access", {}))
    armatures_by_uid = {}
    armatures_by_name = {}
    for armature in tuple(context.scene.objects):
        if armature.type != "ARMATURE" or getattr(armature, "pose", None) is None:
            continue
        armatures_by_uid[_armature_session_uid(armature)] = armature
        armatures_by_name[armature.name] = armature

    changed = False
    runtime_rebuild_needed = set(owners) != {
        (_armature_session_uid(armature), armature.name)
        for armature in armatures_by_uid.values()
    }
    for owner_key, onion_enabled in owners.items():
        owner_uid, owner_name = owner_key
        armature = armatures_by_uid.get(int(owner_uid))
        if armature is None:
            armature = armatures_by_name.get(str(owner_name))
        if armature is None:
            continue
        access = armature_access.get(owner_key)
        if access is not None:
            try:
                armature.hide_viewport = bool(access.get("hide_viewport", False))
                armature.hide_select = bool(access.get("hide_select", False))
                armature.hide_set(bool(access.get("hidden", False)))
            except (AttributeError, ReferenceError, RuntimeError):
                pass
        for pose_bone in armature.pose.bones:
            pin_key = (int(owner_uid), str(owner_name), pose_bone.name)
            desired = pins.get(pin_key)
            if desired is None:
                for property_name in (
                    YELLOW_PIN_TARGET_PROPERTY,
                    YELLOW_PIN_MODE_PROPERTY,
                    YELLOW_PIN_AXIS_PROPERTY,
                    YELLOW_PIN_INITIAL_TARGET_PROPERTY,
                ):
                    if property_name in pose_bone:
                        del pose_bone[property_name]
                        changed = True
                        runtime_rebuild_needed = True
                continue
            desired_mode = int(desired.get("mode", 1))
            if int(pose_bone.get(YELLOW_PIN_MODE_PROPERTY, 0)) != desired_mode:
                pose_bone[YELLOW_PIN_MODE_PROPERTY] = desired_mode
                changed = True
                runtime_rebuild_needed = True
            desired_axis = str(desired.get("axis", "Y_NEG"))
            if str(
                pose_bone.get(YELLOW_PIN_AXIS_PROPERTY, "Y_NEG")
            ) != desired_axis:
                pose_bone[YELLOW_PIN_AXIS_PROPERTY] = desired_axis
                changed = True
                runtime_rebuild_needed = True
            initial_target = desired.get("initial_target")
            if (
                initial_target is not None
                and tuple(pose_bone.get(
                    YELLOW_PIN_INITIAL_TARGET_PROPERTY,
                    (),
                )) != tuple(initial_target)
            ):
                pose_bone[YELLOW_PIN_INITIAL_TARGET_PROPERTY] = tuple(
                    initial_target
                )
                changed = True
                runtime_rebuild_needed = True
            # When history removed the pin itself, put back its last target.
            # The first movement undo must land at the spawn point, never at
            # the moved snapshot that happened to exist before undo started.
            # When it exists on both sides, retain Blender's restored target so
            # later pin movements remain normally undoable and redoable.
            if YELLOW_PIN_TARGET_PROPERTY not in pose_bone:
                target = desired.get("initial_target") or desired.get("target")
                if target is not None:
                    pose_bone[YELLOW_PIN_TARGET_PROPERTY] = tuple(target)
                    changed = True
                    runtime_rebuild_needed = True
        desired_onion = bool(onion_enabled)
        if bool(armature.get(ONION_SKIN_ENABLED_PROPERTY, False)) != desired_onion:
            armature[ONION_SKIN_ENABLED_PROPERTY] = desired_onion
            changed = True
            runtime_rebuild_needed = True

    # Rebuild all runtime maps from the restored data. This also revives a
    # fully deleted rig after Ctrl+Z and prunes it again after Ctrl+Shift+Z.
    if not runtime_rebuild_needed:
        return changed
    alive_uids = set(armatures_by_uid)
    _state["yellow_fixed"] = {}
    _state["yellow_modes"] = {}
    _state["yellow_hidden"] = set()
    _state["onion_enabled_owners"] = {
        uid
        for uid, armature in armatures_by_uid.items()
        if bool(armature.get(ONION_SKIN_ENABLED_PROPERTY, False))
    }
    for state_name in ("mesh_batches", "raycast_fixed"):
        _state[state_name] = {
            key: value
            for key, value in _state.get(state_name, {}).items()
            if int(key) in alive_uids
        }
    _restore_persistent_runtime_state(context)
    return changed


def _pin_history_capture_selection():
    snapshot = _pin_selection_runtime_snapshot()
    _state["pin_history_selection_snapshot"] = snapshot
    return snapshot


def _pin_history_restore_selection(context):
    available = set(_pin_available_target_data(context))
    selected = set(_pin_selected_target_keys()) & available
    active = _pin_selected_target_key()
    if active not in selected:
        active = next(iter(sorted(selected)), "")
    return _pin_selection_runtime_restore(
        context,
        {"active": active, "selected": selected},
    )


def _surface_contact_reconcile_history_magnetism(
    context, owner_keys=None
):
    """Repair only contacts indirectly driven by the restored selection."""
    owner_keys = None if owner_keys is None else set(owner_keys)
    grouped = _selected_pose_bones_by_owner(context)
    selected_by_name = {
        armature.name: {pose_bone.name for pose_bone in selected}
        for armature, selected in grouped.items()
    }
    changed = False
    detached_keys = _state.setdefault("pin_snap_detached", set())
    for guide in _surface_contact_active_simulated_guides(context.scene):
        armature = bpy.data.objects.get(str(
            guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, "")
        ))
        owner_key = (_armature_session_uid(armature), guide.name)
        if owner_keys is not None and owner_key not in owner_keys:
            continue
        armature_name = str(
            guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, "")
        )
        selected_names = selected_by_name.get(armature_name)
        if not selected_names:
            continue
        if (
            _surface_contact_direct_bone_names(guide) & selected_names
            or not _surface_contact_selected_bones_drive_guide(
                armature,
                guide,
                selected_names,
            )
        ):
            continue
        snap_key = _surface_contact_snap_key(guide)
        detached = bool(
            guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)
            or snap_key in detached_keys
        )
        if detached:
            # Ancestor Undo/Redo must reproduce the same detached magnetic
            # preview as live G/R/S, but it must remain detached (no ring and
            # no true snap). Use the one-pass rod solve rather than the
            # attached constraint solver.
            changed = bool(
                _surface_contact_solve_detached_target_motion(context, guide)
            ) or changed
            continue
        target, _normal, anchor = _surface_contact_world_point_normal(
            context,
            guide,
        )
        if (
            target is None
            or anchor is None
            or (Vector(target) - Vector(anchor)).length
            <= _surface_contact_settle_tolerance(guide)
        ):
            continue
        changed = bool(
            _surface_contact_enforce_guide(
                context,
                guide,
                force_contact=True,
                insert_keys=False,
                use_snap_hysteresis=False,
                allow_snap=True,
            )
        ) or changed
    return changed


@persistent
def _pin_history_pre(*_):
    direction = str(_state.get("pin_history_direction", "")).upper()
    transition = (
        _state.get("pin_snap_native_history_transition")
        or _state.get("pin_snap_native_history_transition_backup")
    )
    if direction not in {"UNDO", "REDO"}:
        before = bool(
            transition
            and _pin_history_transition_side_matches(transition, 0)
        )
        after = bool(
            transition
            and _pin_history_transition_side_matches(transition, 1)
        )
        direction = "REDO" if before and not after else "UNDO"
    return _pin_history_prepare(direction)
