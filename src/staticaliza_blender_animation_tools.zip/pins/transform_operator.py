"""Modal operator for transforming selected pins."""
from ..core.runtime import *  # noqa: F403
class ANIMATOR_UTILS_OT_transform_selected_pin(bpy.types.Operator):
    bl_idname = "staticaliza.transform_selected_pin"
    bl_label = "Move Selected Pin"
    bl_description = "Transform the selected pin without moving pose bones"
    bl_options = {"REGISTER", "UNDO", "BLOCKING"}

    transform_mode: bpy.props.EnumProperty(
        items = (
            ("TRANSLATE", "Move", "Move the selected pin"),
            ("ROTATE", "Rotate", "Rotate the selected pin"),
            ("SCALE", "Scale", "Scale the selected pin around the current pivot"),
        ),
        options = {"HIDDEN", "SKIP_SAVE"},
    )
    initial_axis: bpy.props.IntProperty(
        default = -1,
        min = -1,
        max = 2,
        options = {"HIDDEN", "SKIP_SAVE"},
    )
    finish_on_release: bpy.props.BoolProperty(
        default = False, options = {"HIDDEN", "SKIP_SAVE"}
    )
    exclusive_pin_selection: bpy.props.BoolProperty(
        default = False, options = {"HIDDEN", "SKIP_SAVE"}
    )
    bone_only_contact: bpy.props.BoolProperty(
        default = False, options = {"HIDDEN", "SKIP_SAVE"}
    )
    contact_keep_attached: bpy.props.BoolProperty(
        default = False, options = {"HIDDEN"}
    )
    target_kind: bpy.props.StringProperty(options = {"HIDDEN"})
    armature_name: bpy.props.StringProperty(options = {"HIDDEN"})
    contact_guide_name: bpy.props.StringProperty(options = {"HIDDEN"})
    surface_name: bpy.props.StringProperty(options = {"HIDDEN"})
    target_bone_name: bpy.props.StringProperty(options = {"HIDDEN"})
    redo_bones_json: bpy.props.StringProperty(options = {"HIDDEN"})
    redo_pins_json: bpy.props.StringProperty(options = {"HIDDEN"})
    orientation_basis_values: bpy.props.FloatVectorProperty(
        size = 9,
        options = {"HIDDEN"},
    )
    orientation_name: bpy.props.StringProperty(options = {"HIDDEN"})
    pivot_name: bpy.props.StringProperty(options = {"HIDDEN"})
    base_location: bpy.props.FloatVectorProperty(
        size = 3,
        subtype = "TRANSLATION",
        options = {"HIDDEN"},
    )
    displacement: bpy.props.FloatVectorProperty(
        name = "Move",
        size = 3,
        subtype = "TRANSLATION",
        unit = "LENGTH",
    )
    def draw(self, _context):
        _pin_transform_operator_draw(self, _context)
    def execute(self, context):
        return _pin_transform_operator_execute(self, context)
    @classmethod
    def poll(cls, context):
        return (
            getattr(context, "mode", "") == "POSE"
            and getattr(getattr(context, "area", None), "type", "") == "VIEW_3D"
            and bool(
                _pin_selected_target_key()
                or _state.get("pin_target_dragging", False)
            )
        )
    def _header_text(self, context):
        label = {
            "TRANSLATE": "Move",
            "ROTATE": "Rotate",
            "SCALE": "Scale",
        }[self.transform_mode]
        constraint = (
            f" Shift+{('X', 'Y', 'Z')[self.plane_axis_index]}"
            if int(getattr(self, "plane_axis_index", -1)) >= 0
            else (
                ""
                if self.axis_index < 0
                else f" {('X', 'Y', 'Z')[self.axis_index]}"
            )
        )
        _pin_transform_update_constraint_overlay(self)
        try:
            subject = (
                "Contact Bone"
                if bool(self.bone_only_contact)
                else "Pin"
            )
            context.area.header_text_set(
                f"{label} {subject}{constraint}: move mouse, X/Y/Z constrain, "
                "Left Click/Enter confirm, Right Click/Esc cancel"
            )
        except (AttributeError, RuntimeError):
            pass
    def _clear_header(self, context):
        try:
            context.area.header_text_set(None)
        except (AttributeError, RuntimeError):
            pass
    def _release_modal_state(self, context):
        _pin_transform_end_keyboard_presentation(self, context)
        self._clear_header(context)
        _state["pin_gizmo_active_axis_index"] = -1
        _state["pin_transform_constraint"] = None
        _state["pin_keyboard_transform_active"] = False
        _state["pin_target_dragging"] = False
        _state.pop("pin_target_drag_references", None)
        _state["pin_transform_from_gizmo"] = False
        _pin_clear_transform_state()
        _tag_redraw_all_view3d()
    def _finish_exclusive_pin_selection(self, context):
        snapshot = _state.pop("pin_transform_selection_snapshot", None)
        if snapshot is not None and not bool(self.exclusive_pin_selection):
            _pin_selection_runtime_restore(context, snapshot)
        _pin_finish_exclusive_selection(
            context,
            self.target_key,
            self.exclusive_pin_selection,
        )
    def _restore_initial(self, context):
        target_data = _pin_modal_target_data(self, context)
        armature = (
            target_data[1]
            if target_data is not None
            else bpy.data.objects.get(str(getattr(self, "armature_name", "")))
        )
        kind = str(getattr(self, "target_kind", ""))
        payload = (
            target_data[3]
            if target_data is not None and target_data[0] == "CONTACT"
            else bpy.data.objects.get(
                str(getattr(self, "contact_guide_name", ""))
            )
        )
        if kind == "YELLOW":
            fixed = dict(_state.get("yellow_fixed", {}))
            fixed[_owner_bone_key(armature, self.target_bone_name)] = tuple(
                value.copy() if hasattr(value, "copy") else value
                for value in self.initial_yellow_packed
            )
            _state["yellow_fixed"] = fixed
            pose_bone = (
                armature.pose.bones.get(self.target_bone_name)
                if armature is not None and getattr(armature, "pose", None)
                else None
            )
            if pose_bone is not None:
                if self.initial_yellow_property_exists:
                    pose_bone[YELLOW_PIN_TARGET_PROPERTY] = (
                        self.initial_yellow_property
                    )
                elif YELLOW_PIN_TARGET_PROPERTY in pose_bone:
                    del pose_bone[YELLOW_PIN_TARGET_PROPERTY]
        elif payload is not None:
            guide = payload
            initial_surface = bpy.data.objects.get(
                str(getattr(self, "initial_contact_surface_name", ""))
            )
            if (
                initial_surface is not None
                and str(guide.get(SURFACE_CONTACT_SURFACE_PROPERTY, ""))
                != initial_surface.name
            ):
                _surface_contact_bind_guide_surface(
                    context,
                    guide,
                    initial_surface,
                    self.initial_pin_matrix.translation,
                )
            guide.matrix_world = self.initial_pin_matrix.copy()
            if self.initial_contact_point_exists:
                guide[SURFACE_CONTACT_POINT_PROPERTY] = self.initial_contact_point
            elif SURFACE_CONTACT_POINT_PROPERTY in guide:
                del guide[SURFACE_CONTACT_POINT_PROPERTY]
            if self.initial_contact_normal_exists:
                guide[SURFACE_CONTACT_NORMAL_PROPERTY] = self.initial_contact_normal
            elif SURFACE_CONTACT_NORMAL_PROPERTY in guide:
                del guide[SURFACE_CONTACT_NORMAL_PROPERTY]
            if self.initial_contact_local_matrix_exists:
                guide[SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY] = (
                    self.initial_contact_local_matrix
                )
            elif SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY in guide:
                del guide[SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY]
            _pin_restore_contact_detached_state(
                guide,
                self.initial_contact_detached_exists,
                self.initial_contact_detached,
            )
            solver = _surface_contact_solver_from_guide(guide)
            if solver is not None and self.initial_solver_matrix is not None:
                solver.matrix_world = self.initial_solver_matrix.copy()
            _surface_contact_restore_simulated_pose(
                context,
                guide,
                self.initial_simulated_pose_matrix,
                update_view_layer = False,
            )
        _pin_transform_group_restore(context, self)
        if armature is not None and getattr(armature, "pose", None):
            for bone_name in self.bone_order:
                state = self.bone_states[bone_name]
                pose_bone = armature.pose.bones.get(bone_name)
                if pose_bone is not None:
                    pose_bone.matrix_basis = state["matrix_basis"].copy()
        try:
            context.view_layer.update()
        except (AttributeError, RuntimeError):
            pass
        return bool(armature is not None or payload is not None)
    def _mouse_transform(self, context, event):
        return _pin_transform_mouse_matrix(self, context, event)
    def _apply(self, context, event):
        self.contact_current_mouse = (
            float(event.mouse_region_x),
            float(event.mouse_region_y),
        )
        core_matrix = self._mouse_transform(context, event)
        sample_signature = _pin_transform_sample_signature(self, core_matrix)
        if sample_signature == getattr(self, "last_apply_signature", None):
            return True
        if not self._restore_initial(context):
            return False
        target_data = _pin_modal_target_data(self, context)
        if target_data is None:
            return False
        kind, armature, connected_bone, payload = target_data
        shared_delta = _pin_keyboard_around_origin(core_matrix, self.pivot)
        for bone_name in self.bone_order:
            state = self.bone_states[bone_name]
            pose_bone = armature.pose.bones.get(bone_name)
            if pose_bone is None:
                continue
            origin = (
                (armature.matrix_world @ state["matrix"]).translation
                if self.individual_origins and self.transform_mode != "TRANSLATE"
                else self.pivot
            )
            delta = (
                _pin_keyboard_around_origin(core_matrix, origin)
                if self.individual_origins and self.transform_mode != "TRANSLATE"
                else shared_delta
            )
            world_matrix = armature.matrix_world @ state["matrix"]
            requested_world = delta @ world_matrix
            pose_bone.matrix = (
                armature.matrix_world.inverted_safe() @ requested_world
            )
            if (
                bool(self.bone_only_contact)
                and bone_name == self.target_bone_name
            ):
                # Preserve user intent before view_layer.update() gives the
                # existing contact solver a chance to rewrite evaluation.
                self.contact_raw_world = requested_world.copy()
            _pin_keyboard_apply_pose_locks(
                pose_bone,
                state,
                self.transform_mode,
            )
        if self.bone_order:
            context.view_layer.update()
        if bool(self.bone_only_contact):
            return _pin_transform_apply_contact_bone(
                context,
                self,
                target_data,
            )

        pin_origin = (
            self.initial_pin_matrix.translation
            if self.individual_origins and self.transform_mode != "TRANSLATE"
            else self.pivot
        )
        pin_delta = (
            _pin_keyboard_around_origin(core_matrix, pin_origin)
            if self.individual_origins and self.transform_mode != "TRANSLATE"
            else shared_delta
        )
        desired_matrix = _pin_transform_position_matrix(
            self.transform_mode, self.initial_pin_matrix, pin_delta
        )
        locked_axes = _pin_target_locked_axes(target_data)
        if self.transform_mode == "TRANSLATE":
            desired_matrix.translation = _pin_gizmo_apply_axis_locks(
                desired_matrix.translation,
                self.initial_pin_matrix.translation,
                locked_axes,
                self.orientation,
            )

        if kind == "YELLOW":
            changed = _yellow_set_pin_target(
                armature,
                self.target_bone_name,
                desired_matrix.translation,
            )
            _yellow_store_target_property(
                armature,
                self.target_bone_name,
                desired_matrix.translation,
            )
        else:
            dragged_surface = (
                bpy.data.objects.get(str(getattr(self, "drag_surface_name", "")))
                if self.transform_mode == "TRANSLATE"
                and self.finish_on_release
                and self.axis_index < 0
                else None
            )
            if dragged_surface is not None:
                if str(payload.get(SURFACE_CONTACT_SURFACE_PROPERTY, "")) != dragged_surface.name:
                    if not _surface_contact_bind_guide_surface(
                        context,
                        payload,
                        dragged_surface,
                        desired_matrix.translation,
                    ):
                        return False
                normal = getattr(self, "drag_surface_normal", None)
                if normal is None:
                    normal = desired_matrix.to_3x3().col[2]
                changed = _surface_contact_move_guide_to_surface(
                    context,
                    payload,
                    desired_matrix.translation,
                    normal,
                    keep_attached = self.contact_keep_attached,
                    max_iterations = SURFACE_CONTACT_LIVE_SOLVER_ITERATIONS,
                    sweep_collision = False,
                )
                self.surface_name = dragged_surface.name
            else:
                solver_matrix = _pin_transform_position_matrix(
                    self.transform_mode,
                    self.initial_solver_matrix,
                    pin_delta,
                )
                changed = _pin_keyboard_apply_contact_matrix(
                    context,
                    payload,
                    desired_matrix,
                    solver_matrix = solver_matrix,
                    keep_attached = self.contact_keep_attached,
                    max_iterations = SURFACE_CONTACT_LIVE_SOLVER_ITERATIONS,
                )
            if not changed:
                changed = (
                    desired_matrix.translation
                    - self.initial_pin_matrix.translation
                ).length <= 1.0e-7
        if kind == "YELLOW":
            context.view_layer.update()
        if (
            connected_bone is not None
            and connected_bone.name in self.bone_order
        ):
            changed = _pin_apply_yellow_priority(
                context,
                armature,
                connected_bone,
            ) or changed
        group_changed = _pin_transform_group_apply(
            context, self, core_matrix, shared_delta
        )
        self.redo_pins_json = _pin_transform_group_redo_json(self, target_data)
        if kind == "YELLOW":
            current = _state.get("yellow_fixed", {}).get(
                _owner_bone_key(armature, self.target_bone_name)
            )
            pin_changed = bool(
                current
                and (
                    Vector(current[0]) - self.initial_pin_matrix.translation
                ).length > 1.0e-7
            )
        else:
            pin_changed = _pin_keyboard_matrices_differ(
                payload.matrix_world,
                self.initial_pin_matrix,
            )
            solver = _surface_contact_solver_from_guide(payload)
            if solver is not None and self.initial_solver_matrix is not None:
                pin_changed = pin_changed or _pin_keyboard_matrices_differ(
                    solver.matrix_world,
                    self.initial_solver_matrix,
                )
            simulated_pose = _surface_contact_simulated_pose_matrix(payload)
            if (
                simulated_pose is not None
                and self.initial_simulated_pose_matrix is not None
            ):
                pin_changed = pin_changed or _pin_keyboard_matrices_differ(
                    simulated_pose,
                    self.initial_simulated_pose_matrix,
                )
        bone_changed = any(
            (
                (pose_bone := armature.pose.bones.get(bone_name)) is not None
                and _pin_keyboard_matrices_differ(
                    pose_bone.matrix_basis,
                    self.bone_states[bone_name]["matrix_basis"],
                )
            )
            for bone_name in self.bone_order
        )
        self.changed = bool(pin_changed or bone_changed or group_changed)
        self.last_apply_signature = sample_signature
        if self.transform_mode == "TRANSLATE":
            # desired_matrix is the settled, lock-aware pin target for this
            # mouse position. Recording its delta directly avoids a transient
            # evaluated contact guide reporting its previous location as zero.
            settled_location = (
                payload.matrix_world.translation
                if kind == "CONTACT"
                else desired_matrix.translation
            )
            self.displacement = tuple(
                self.orientation.inverted_safe() @ (
                    settled_location
                    - self.initial_pin_matrix.translation
                )
            )
        _tag_redraw_all_view3d()
        return True
    def invoke(self, context, event):
        self.bone_only_contact = False
        _state["pin_transform_selection_snapshot"] = (
            _pin_selection_runtime_snapshot()
        )
        self.target_key, target_data = _pin_selected_target_data(context)
        if not self.target_key or target_data is None:
            _state.pop("pin_transform_selection_snapshot", None)
            # Pink contact owners remain ordinary Blender pose bones. Native
            # G/R/S owns their modal UI, constraints, numeric entry, and redo
            # panel; Contact observes those samples via the existing native
            # transform callback. This operator owns only selected pin handles.
            _schedule_transform_gizmo_refresh()
            return {"PASS_THROUGH"}
        if not self.bone_only_contact and self.transform_mode == "ROTATE" and not _pin_transform_group_can_rotate(context):
            _state.pop("pin_transform_selection_snapshot", None)
            return {"PASS_THROUGH"}
        if self.finish_on_release:
            _pin_gizmo_claim_pointer(event)
        kind, armature, pose_bone, payload = target_data
        if kind == "CONTACT":
            continuity_key = _surface_contact_pose_cache_key(payload)
            for cache_name in (
                "surface_contact_rotation_axes",
                "surface_contact_smart_aim_branches",
                "surface_contact_roll_frames",
                "surface_contact_collision_tangents",
            ):
                _state.setdefault(cache_name, {}).pop(
                    continuity_key,
                    None,
                )
        self.initial_pin_matrix = _pin_keyboard_target_matrix(target_data)
        if self.initial_pin_matrix is None:
            return {"PASS_THROUGH"}
        self.target_kind = kind
        self.armature_name = armature.name
        self.contact_guide_name = payload.name if kind == "CONTACT" else ""
        self.target_bone_name = pose_bone.name if pose_bone is not None else ""
        self._target_data_cache = target_data
        self.base_location = tuple(self.initial_pin_matrix.translation)
        self.displacement = (0.0, 0.0, 0.0)
        self.initial_yellow_packed = None
        self.initial_yellow_property_exists = False
        self.initial_yellow_property = ()
        self.initial_contact_point = ()
        self.initial_contact_point_exists = False
        self.initial_contact_normal = ()
        self.initial_contact_normal_exists = False
        self.initial_contact_local_matrix = ()
        self.initial_contact_local_matrix_exists = False
        self.initial_contact_surface_name = ""
        self.contact_keep_attached = False
        self.contact_raw_world = None
        _pin_contact_ball_joint_reset(self)
        self.initial_contact_detached_exists = self.initial_contact_detached = False
        self.initial_solver_matrix = None
        self.initial_simulated_pose_matrix = None
        if kind == "YELLOW":
            self.initial_yellow_packed = tuple(
                value.copy() if hasattr(value, "copy") else value
                for value in payload
            )
            self.initial_yellow_property_exists = bool(
                pose_bone is not None
                and YELLOW_PIN_TARGET_PROPERTY in pose_bone
            )
            if self.initial_yellow_property_exists:
                self.initial_yellow_property = tuple(
                    pose_bone[YELLOW_PIN_TARGET_PROPERTY]
                )
        else:
            self.initial_contact_surface_name = str(
                payload.get(SURFACE_CONTACT_SURFACE_PROPERTY, "")
            )
            self.initial_contact_detached_exists = bool(
                SURFACE_CONTACT_DETACHED_PROPERTY in payload
            )
            self.initial_contact_detached = bool(
                payload.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)
            )
            self.surface_name = self.initial_contact_surface_name
            self.initial_contact_point_exists = (
                SURFACE_CONTACT_POINT_PROPERTY in payload
            )
            self.initial_contact_point = tuple(
                payload.get(SURFACE_CONTACT_POINT_PROPERTY, ())
            )
            self.initial_contact_normal_exists = (
                SURFACE_CONTACT_NORMAL_PROPERTY in payload
            )
            self.initial_contact_normal = tuple(
                payload.get(SURFACE_CONTACT_NORMAL_PROPERTY, ())
            )
            self.initial_contact_local_matrix_exists = (
                SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY in payload
            )
            self.initial_contact_local_matrix = tuple(
                payload.get(SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY, ())
            )
            solver = _surface_contact_solver_from_guide(payload)
            self.initial_solver_matrix = (
                solver.matrix_world.copy() if solver is not None else None
            )
            self.initial_simulated_pose_matrix = (
                _surface_contact_simulated_pose_matrix(payload)
            )
            # A target drag on an already snapped Contact must carry the limb
            # with the moved surface pin. Bone-only G/R uses the same planted
            # attachment rule; detached contacts remain magnetic-only.
            self.contact_keep_attached = bool(
                _pin_contact_is_attached(context, payload)
            )
            if self.contact_keep_attached:
                opposite = _surface_contact_opposite_anchor_world(
                    context,
                    payload,
                )
                pose_world = (
                    armature.matrix_world @ self.initial_simulated_pose_matrix
                    if self.initial_simulated_pose_matrix is not None
                    else None
                )
                if opposite is not None and pose_world is not None:
                    _state.setdefault(
                        "pin_target_drag_references",
                        {},
                    )[payload.name] = {
                        "target": payload.matrix_world.translation.copy(),
                        "opposite": Vector(opposite).copy(),
                        "pose_world": pose_world.copy(),
                    }
        _pin_transform_group_capture(self, context, self.target_key)
        self.redo_pins_json = _pin_transform_group_redo_json(self, target_data)
        selected_bones = (
            []
            if bool(self.exclusive_pin_selection)
            else list(_selected_pose_bones_by_owner(context).get(armature, ()))
        )
        def hierarchy_depth(selected_bone):
            depth = 0
            parent = selected_bone.parent
            while parent is not None:
                depth += 1
                parent = parent.parent
            return depth

        selected_bones.sort(key = hierarchy_depth)
        self.bone_states = {}
        self.bone_order = []
        for selected_bone in selected_bones:
            self.bone_order.append(selected_bone.name)
            self.bone_states[selected_bone.name] = {
                "matrix": selected_bone.matrix.copy(),
                "matrix_basis": selected_bone.matrix_basis.copy(),
                "location": selected_bone.location.copy(),
                "rotation_euler": selected_bone.rotation_euler.copy(),
                "rotation_quaternion": selected_bone.rotation_quaternion.copy(),
                "rotation_axis_angle": tuple(selected_bone.rotation_axis_angle),
                "scale": selected_bone.scale.copy(),
            }
        self.redo_bones_json = json.dumps({
            bone_name: [
                float(value)
                for row in state["matrix"]
                for value in row
            ]
            for bone_name, state in self.bone_states.items()
        })
        if self.contact_keep_attached:
            # Capture against the same uncorrected matrix baseline that every
            # modal sample restores. Ball-joint capture can reassert the
            # planted endpoint and therefore change the evaluated pose; doing
            # that before bone_states were saved made raw mouse matrices and
            # contact_ball_raw_* belong to two different reference frames.
            self.contact_current_mouse = (
                float(event.mouse_region_x),
                float(event.mouse_region_y),
            )
            _pin_contact_ball_joint_capture(context, self, target_data)
        pivot_matrix = self.initial_pin_matrix
        if bool(self.bone_only_contact) and pose_bone is not None:
            pivot_matrix = self.initial_pin_matrix.copy()
            pivot_matrix.translation = _pin_contact_ball_joint_pivot(self, armature, pose_bone)
        self.pivot, self.individual_origins = _pin_keyboard_pivot(
            context,
            pivot_matrix,
            armature,
            self.bone_states,
            **_pin_transform_group_pivot_options(self, target_data, armature, selected_bones),
        )
        self.group_handle_origin = self.pivot.copy()
        self.orientation = _pin_keyboard_orientation_matrix(
            context,
            target_data,
            self.initial_pin_matrix,
        )
        self.orientation_basis_values = tuple(
            float(value) for row in self.orientation for value in row
        )
        slot_type = str(context.scene.transform_orientation_slots[0].type)
        self.orientation_name = (
            "Local" if slot_type in {"LOCAL", "CURSOR"} else "Global"
        )
        self.pivot_name = (
            "Object"
            if getattr(
                context.window_manager,
                "staticaliza_pivot_mode",
                "BONE",
            ) == "PART"
            else "Bone"
        )
        self.initial_mouse = (
            float(event.mouse_region_x),
            float(event.mouse_region_y),
        )
        self.mouse_started_at_pivot = False
        try:
            from bpy_extras import view3d_utils

            pivot_2d = view3d_utils.location_3d_to_region_2d(
                context.region,
                context.region_data,
                self.pivot,
            )
            self.mouse_started_at_pivot = bool(
                pivot_2d is not None
                and (Vector(self.initial_mouse) - pivot_2d).length <= 4.0
            )
        except (AttributeError, RuntimeError, TypeError, ValueError):
            pass
        self.axis_index = int(self.initial_axis)
        _state["pin_gizmo_active_axis_index"] = self.axis_index
        self.plane_axis_index = -1
        self.drag_surface_name = ""
        self.drag_surface_normal = None
        self.drag_surface_point = None
        self.changed = False
        self.last_apply_signature = None
        self.drag_started = False
        _state.setdefault("pin_snap_previous_points", {}).clear()
        _state.setdefault("pin_snap_swept_hits", set()).clear()
        if bool(self.bone_only_contact):
            # The target pin is not part of a pink-bone transform. Freeze its
            # world-space surface point before modal evaluation can inherit a
            # changing armature/constraint transform.
            _pin_capture_contact_target_locks(context)
        _state["pin_keyboard_transform_active"] = True
        _state["pin_target_dragging"] = True
        _state["pin_transform_from_gizmo"] = bool(self.finish_on_release)
        _state["pin_gizmo_pending_click"] = None
        _pin_transform_begin_keyboard_presentation(self, context)
        context.window_manager.modal_handler_add(self)
        self._header_text(context)
        return {"RUNNING_MODAL"}
    def modal(self, context, event):
        # Navigation belongs to the viewport even when the pointer overlaps a
        # pin handle. Never interpret MMB/wheel input as pin movement.
        if event.type == "MIDDLEMOUSE":
            if event.value == "PRESS":
                _pin_preserve_after_transform(context, self.target_key, event)
                try:
                    self._restore_initial(context)
                finally:
                    _state["pin_shared_transform_resync_pending"] = True
                    self._release_modal_state(context)
                    self._finish_exclusive_pin_selection(context)
                return {"CANCELLED"}
            return {"RUNNING_MODAL"}
        if event.type in {
            "WHEELUPMOUSE", "WHEELDOWNMOUSE",
            "WHEELINMOUSE", "WHEELOUTMOUSE",
        }:
            return {"RUNNING_MODAL"}
        if event.type in {"ESC", "RIGHTMOUSE"} and event.value == "PRESS":
            _pin_preserve_after_transform(context, self.target_key, event)
            try:
                self._restore_initial(context)
            finally:
                self._release_modal_state(context)
                self._finish_exclusive_pin_selection(context)
            return {"CANCELLED"}
        release_confirm = bool(self.finish_on_release) and (
            event.type == "LEFTMOUSE" and event.value == "RELEASE"
        )
        keyboard_confirm = not bool(self.finish_on_release) and (
            event.type in {"LEFTMOUSE", "RET", "NUMPAD_ENTER", "SPACE"}
            and event.value == "PRESS"
        )
        if release_confirm or keyboard_confirm:
            _pin_preserve_after_transform(context, self.target_key, event)
            target_data = _pin_modal_target_data(self, context)
            if target_data is None:
                try:
                    self._restore_initial(context)
                finally:
                    self._release_modal_state(context)
                    self._finish_exclusive_pin_selection(context)
                return {"CANCELLED"}
            if not self.changed:
                try:
                    self._restore_initial(context)
                finally:
                    self._release_modal_state(context)
                    self._finish_exclusive_pin_selection(context)
                return {"CANCELLED"}
            kind, armature, _pose_bone, payload = target_data
            try:
                if kind == "YELLOW":
                    current = _state.get("yellow_fixed", {}).get(
                        _owner_bone_key(armature, self.target_bone_name)
                    )
                    if current:
                        _yellow_store_target_property(
                            armature,
                            self.target_bone_name,
                            current[0],
                        )
                        _yellow_refresh_runtime(context)
                elif bool(self.bone_only_contact):
                    _pin_transform_finish_contact_bone(context, self, payload)
                _pin_transform_group_commit(
                    context, self,
                    (payload, self.contact_keep_attached)
                    if kind == "CONTACT" and not self.bone_only_contact
                    else None,
                )
                if bool(
                    getattr(context.scene.tool_settings, "use_keyframe_insert_auto", False)
                ):
                    frame = int(context.scene.frame_current)
                    for bone_name in self.bone_order:
                        pose_bone = armature.pose.bones.get(bone_name)
                        if pose_bone is not None:
                            _insert_bone_keys(pose_bone, frame)
            except Exception as exc:
                print(f"[Roblox Animator Utils] Pin transform commit failed: {exc}")
                try:
                    self._restore_initial(context)
                finally:
                    self._release_modal_state(context)
                    self._finish_exclusive_pin_selection(context)
                return {"CANCELLED"}
            self._release_modal_state(context)
            self._finish_exclusive_pin_selection(context)
            return {"FINISHED" if self.changed else "CANCELLED"}
        if event.value == "PRESS" and event.type in {"X", "Y", "Z"}:
            axis_index = {"X": 0, "Y": 1, "Z": 2}[event.type]
            if event.shift:
                self.plane_axis_index = (
                    -1
                    if self.plane_axis_index == axis_index
                    else axis_index
                )
                self.axis_index = -1
            else:
                self.axis_index = (
                    -1 if self.axis_index == axis_index else axis_index
                )
                self.plane_axis_index = -1
            _state["pin_gizmo_active_axis_index"] = self.axis_index
            self._header_text(context)
            try:
                if not self._apply(context, event):
                    raise RuntimeError("The selected pin is no longer available")
            except Exception as exc:
                print(f"[Roblox Animator Utils] Pin transform cancelled: {exc}")
                try:
                    self._restore_initial(context)
                finally:
                    self._release_modal_state(context)
                    self._finish_exclusive_pin_selection(context)
                return {"CANCELLED"}
            return {"RUNNING_MODAL"}
        if event.type == "MOUSEMOVE":
            if self.finish_on_release and not self.drag_started:
                current_mouse = Vector((
                    float(event.mouse_region_x),
                    float(event.mouse_region_y),
                ))
                if (
                    current_mouse - Vector(self.initial_mouse)
                ).length < PIN_GIZMO_DRAG_PIXEL_THRESHOLD:
                    return {"RUNNING_MODAL"}
                self.drag_started = True
            try:
                if not self._apply(context, event):
                    raise RuntimeError("The selected pin is no longer available")
            except Exception as exc:
                print(f"[Roblox Animator Utils] Pin transform cancelled: {exc}")
                try:
                    self._restore_initial(context)
                finally:
                    self._release_modal_state(context)
                    self._finish_exclusive_pin_selection(context)
                return {"CANCELLED"}
            return {"RUNNING_MODAL"}
        return {"RUNNING_MODAL"}
    def cancel(self, context):
        _pin_preserve_after_transform(context, self.target_key)
        try:
            self._restore_initial(context)
        finally:
            self._release_modal_state(context)
            self._finish_exclusive_pin_selection(context)
