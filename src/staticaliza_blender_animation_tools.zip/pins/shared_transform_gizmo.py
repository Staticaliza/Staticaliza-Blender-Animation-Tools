"""One Blender-style transform gizmo for the active virtual pin handle."""

from ..core.runtime import *  # noqa: F403


def _pin_shared_transform_subject(context):
    smart_side = int(_state.get("smart_dragger_selected_side", -1))
    if smart_side in (0, 1):
        data = _smart_dragger_data(context)
        if data is not None:
            target_data = (
                "YELLOW",
                data["armature"],
                data["pose_bone"],
                data["packed"][smart_side],
            )
            return {
                "kind": "SMART",
                "point": data["points"][smart_side],
                "orientation": _pin_transform_orientation_matrix(
                    context,
                    target_data,
                ),
                "rotate": True,
            }
    target_key, target_data = _pin_selected_target_data(context)
    if not target_key or target_data is None:
        return None
    if _pin_transform_group_has_selected_bones(context):
        # Blender's native bone gizmo owns mixed bone/pin transforms.
        return None
    return {
        "kind": "PIN",
        "point": _pin_transform_group_handle_point(context, target_data),
        "orientation": _pin_transform_orientation_matrix(
            context,
            target_data,
            target_data[3].matrix_world
            if target_data[0] == "CONTACT"
            else None,
        ),
        "rotate": _pin_transform_group_can_rotate(context),
    }


def _pin_shared_transform_tool_modes(context):
    tool_id = _pin_workspace_tool_id(context)
    return (
        tool_id in {"builtin.move", "builtin.transform"},
        tool_id in {"builtin.rotate", "builtin.transform"},
    )


class ANIMATOR_UTILS_GGT_pin_shared_transform(bpy.types.GizmoGroup):
    bl_idname = "ANIMATOR_UTILS_GGT_pin_shared_transform"
    bl_label = "Active Pin Transform"
    bl_space_type = "VIEW_3D"
    bl_region_type = "WINDOW"
    bl_options = {"3D", "SELECT", "PERSISTENT"}

    @classmethod
    def poll(cls, context):
        return getattr(context, "mode", "") == "POSE"

    def setup(self, context):
        self.handles = {"PIN": ([], []), "SMART": ([], [])}
        colors = _pin_gizmo_theme_axis_colors(context)
        for kind, operator_id in (
            ("PIN", "staticaliza.transform_selected_pin"),
            ("SMART", "staticaliza.smart_dragger_transform"),
        ):
            moves, rotations = self.handles[kind]
            for axis_index, color in enumerate(colors):
                move = self.gizmos.new("GIZMO_GT_arrow_3d")
                move.draw_style = "NORMAL"
                move.color = move.color_highlight = color
                move.alpha, move.alpha_highlight = 0.55, 0.8
                move.scale_basis = PIN_GIZMO_AXIS_SCALE
                move.line_width = 2.5
                move.select_bias = 1.0
                move.use_draw_modal = True
                move.use_event_handle_all = True
                move.hide = move.hide_select = True
                move.target_set_handler(
                    "offset",
                    get=_pin_gizmo_axis_offset_get,
                    set=_pin_gizmo_axis_offset_set,
                )
                move_operator = move.target_set_operator(operator_id)
                move_operator.transform_mode = "TRANSLATE"
                move_operator.initial_axis = axis_index
                move_operator.finish_on_release = True
                moves.append(move)

                rotation = self.gizmos.new("GIZMO_GT_dial_3d")
                rotation.color = rotation.color_highlight = color
                rotation.alpha, rotation.alpha_highlight = 0.45, 0.8
                rotation.scale_basis = PIN_GIZMO_AXIS_SCALE * 0.78
                rotation.line_width = 2.5
                rotation.select_bias = 1.0
                rotation.use_draw_modal = True
                rotation.use_event_handle_all = True
                rotation.hide = rotation.hide_select = True
                rotate_operator = rotation.target_set_operator(operator_id)
                rotate_operator.transform_mode = "ROTATE"
                rotate_operator.initial_axis = axis_index
                rotate_operator.finish_on_release = True
                rotations.append(rotation)

    def draw_prepare(self, context):
        hide_for_keyboard = bool(
            (
                _state.get("pin_keyboard_transform_active", False)
                and not _state.get("pin_transform_from_gizmo", False)
            )
            or _state.get("pin_snap_transform_active", False)
        )
        if hide_for_keyboard:
            for moves, rotations in self.handles.values():
                for gizmo in (*moves, *rotations):
                    _pin_gizmo_set_if_changed(gizmo, "hide", True)
                    _pin_gizmo_set_if_changed(gizmo, "hide_select", True)
                    _pin_gizmo_set_if_changed(gizmo, "select", False)
            return
        transform_active = bool(
            _state.get("pin_keyboard_transform_active", False)
            or _state.get("smart_dragger_transform_active", False)
        )
        if transform_active:
            # Hiding a dial while it owns the custom modal transform cancels
            # its event stream. Preserve it until that operator finishes.
            return
        if (
            _pin_primary_mouse_pressed()
            or _window_manager_has_modal_operator(context)
        ):
            return
        subject = _pin_shared_transform_subject(context)
        if subject is None:
            for moves, rotations in self.handles.values():
                for gizmo in (*moves, *rotations):
                    _pin_gizmo_set_if_changed(gizmo, "hide", True)
                    _pin_gizmo_set_if_changed(gizmo, "hide_select", True)
                    _pin_gizmo_set_if_changed(gizmo, "select", False)
            return
        show_move, show_rotate = _pin_shared_transform_tool_modes(context)
        active_kind = subject["kind"]
        point = Vector(subject["point"])
        orientation = Matrix(subject["orientation"])
        for kind, (moves, rotations) in self.handles.items():
            active = kind == active_kind
            for axis_index, gizmo in enumerate(moves):
                show = active and show_move
                _pin_gizmo_set_if_changed(gizmo, "select", False)
                _pin_gizmo_set_if_changed(gizmo, "hide", not show)
                _pin_gizmo_set_if_changed(gizmo, "hide_select", not show)
                if show:
                    _pin_gizmo_set_if_changed(
                        gizmo,
                        "matrix_basis",
                        _pin_gizmo_axis_matrix(
                            point,
                            orientation.col[axis_index],
                        ),
                    )
            for axis_index, gizmo in enumerate(rotations):
                show = bool(
                    active
                    and show_rotate
                    and subject["rotate"]
                )
                _pin_gizmo_set_if_changed(gizmo, "select", False)
                _pin_gizmo_set_if_changed(gizmo, "hide", not show)
                _pin_gizmo_set_if_changed(gizmo, "hide_select", not show)
                if show:
                    _pin_gizmo_set_if_changed(
                        gizmo,
                        "matrix_basis",
                        _pin_gizmo_axis_matrix(
                            point,
                            orientation.col[axis_index],
                        ),
                    )
