"""Pink surface-contact pin gizmos."""

from ..core.runtime import *  # noqa: F403

class ANIMATOR_UTILS_GT_surface_contact_target(bpy.types.Gizmo):
    bl_idname = "ANIMATOR_UTILS_GT_surface_contact_target"

    __slots__ = (
        "diamond_shape",
        "target_key",
        "guide_name",
        "axis_index",
        "axis_world",
        "axis_locked",
        "locked_axes",
        "orientation_basis",
        "axis_offset",
        "initial_matrix",
        "initial_solver_matrix",
        "initial_simulated_pose_matrix",
        "initial_point",
        "initial_normal",
        "initial_local_matrix",
        "initial_surface_name",
        "initial_mouse",
        "extend_selection",
        "axes_were_visible",
        "drag_started",
        "interaction_valid",
        "moved",
    )

    def setup(self):
        if not hasattr(self, "diamond_shape"):
            self.diamond_shape = self.new_custom_shape(
                "TRIS",
                _PIN_GIZMO_DIAMOND_VERTICES,
            )

    def draw(self, context):
        _pin_gizmo_update_hover_cursor(context, self)
        if getattr(self, "axis_index", -1) >= 0:
            return
        self.draw_custom_shape(self.diamond_shape)

    def draw_select(self, _context, select_id):
        if getattr(self, "axis_index", -1) < 0:
            self.draw_custom_shape(self.diamond_shape, select_id=select_id)

    def invoke(self, context, event):
        self.interaction_valid = False
        _pin_gizmo_configure_undo(self, False)
        if bool(getattr(self, "axis_locked", False)):
            return {"CANCELLED"}
        target_key = str(getattr(self, "target_key", ""))
        was_selected = target_key in _pin_selected_target_keys()
        target_data = _pin_available_target_data(context).get(target_key)
        guide = bpy.data.objects.get(str(getattr(self, "guide_name", "")))
        if (
            guide is None
            or target_data is None
            or target_data[0] != "CONTACT"
            or target_data[3] != guide
            or (
                getattr(self, "axis_index", -1) >= 0
                and target_key != _pin_selected_target_key()
            )
        ):
            return {"CANCELLED"}
        _pin_gizmo_begin_interaction(
            self,
            event,
            context,
            target_data_override=target_data,
        )
        axis_index = int(getattr(self, "axis_index", -1))
        shift_pressed = bool(getattr(event, "shift", False))
        if axis_index < 0 and shift_pressed:
            # Shift-click adds the pin to the existing bone selection. It is
            # selection-only; movement starts only from an unmodified drag.
            _pin_gizmo_finish_interaction(self, False)
            _tag_redraw_all_view3d()
            return {"FINISHED"}
        _state["pin_target_dragging"] = True
        try:
            result = bpy.ops.staticaliza.transform_selected_pin(
                "INVOKE_DEFAULT",
                transform_mode = "TRANSLATE",
                initial_axis = axis_index,
                finish_on_release = True,
                exclusive_pin_selection = bool(
                    not shift_pressed and (axis_index < 0 or not was_selected)
                ),
            )
        except (AttributeError, RuntimeError, TypeError, ValueError):
            result = {"CANCELLED"}
        if "RUNNING_MODAL" in result:
            # The registered operator owns this press through release, making
            # every drag an independent Blender undo/redo and HUD operation.
            return {"FINISHED"}
        # Never fall back to the old incremental gizmo modal. It restored the
        # starting pose after release and replayed a displacement later, so an
        # iterative Contact could visibly snap to a second result. Preserve
        # the pin click, but leave the contact exactly where it was.
        _state["pin_target_dragging"] = False
        _pin_gizmo_finish_interaction(self, True)
        _pin_gizmo_defer_finish(self, target_data)
        _tag_redraw_all_view3d()
        return {"CANCELLED"}

    def modal(self, context, event, tweak):
        if not bool(getattr(self, "interaction_valid", False)):
            return {"CANCELLED"}
        guide = bpy.data.objects.get(str(getattr(self, "guide_name", "")))
        if guide is None:
            return {"CANCELLED"}
        if not _pin_gizmo_drag_ready(self, event):
            return {"RUNNING_MODAL"}
        if getattr(self, "axis_index", -1) >= 0:
            axis_point = _pin_gizmo_axis_mouse_point(
                context,
                self.initial_matrix.translation,
                self.axis_world,
                (event.mouse_region_x, event.mouse_region_y),
            )
            candidate = axis_point + self.axis_offset if axis_point is not None else None
            if candidate is not None:
                candidate = _pin_gizmo_apply_axis_locks(
                    candidate,
                    self.initial_matrix.translation,
                    getattr(self, "locked_axes", (False, False, False)),
                    getattr(self, "orientation_basis", Matrix.Identity(3)),
                )
            if (
                candidate is not None
                and (Vector(candidate) - guide.matrix_world.translation).length > 1.0e-6
                and _surface_contact_move_guide_world(
                    context,
                    guide,
                    candidate,
                    keep_attached = _pin_contact_is_attached(context, guide),
                    max_iterations = SURFACE_CONTACT_LIVE_SOLVER_ITERATIONS,
                )
            ):
                self.moved = True
            return {"RUNNING_MODAL"}
        result = _surface_contact_mouse_surface_point(
            context,
            guide,
            (event.mouse_region_x, event.mouse_region_y),
        )
        if result is not None:
            surface, surface_point, _surface_normal = result
            locked_point = _pin_gizmo_apply_axis_locks(
                surface_point,
                self.initial_matrix.translation,
                getattr(self, "locked_axes", (False, False, False)),
                getattr(self, "orientation_basis", Matrix.Identity(3)),
            )
            result = _surface_contact_closest_point(
                surface,
                locked_point,
                context.evaluated_depsgraph_get(),
                max(1.0, (Vector(locked_point) - surface_point).length * 4.0),
            )
            if result is not None:
                rebound = False
                if str(
                    guide.get(SURFACE_CONTACT_SURFACE_PROPERTY, "")
                ) != surface.name:
                    rebound = _surface_contact_bind_guide_surface(
                        context,
                        guide,
                        surface,
                        result[0],
                    )
                    if not rebound:
                        return {"RUNNING_MODAL"}
                if _surface_contact_move_guide_to_surface(
                    context,
                    guide,
                    result[0],
                    result[1],
                    keep_attached = _pin_contact_is_attached(context, guide),
                    max_iterations = SURFACE_CONTACT_LIVE_SOLVER_ITERATIONS,
                    sweep_collision = False,
                ) or rebound:
                    self.moved = True
        return {"RUNNING_MODAL"}

    def exit(self, context, cancel):
        if not bool(getattr(self, "interaction_valid", False)):
            _tag_redraw_all_view3d()
            return
        _pin_gizmo_finish_interaction(self, cancel)
        guide = bpy.data.objects.get(str(getattr(self, "guide_name", "")))
        if guide is None:
            _state["pin_target_dragging"] = False
            return
        target_data = _pin_available_target_data(context).get(
            str(getattr(self, "target_key", ""))
        )
        try:
            move_operation = None
            restore_data = None
            if self.moved and not cancel:
                final_location = guide.matrix_world.translation.copy()
                move_operation = {
                    "pin_kind": "CONTACT",
                    "armature_name": (
                        target_data[1].name if target_data else ""
                    ),
                    "target_name": guide.name,
                    "surface_name": str(
                        guide.get(SURFACE_CONTACT_SURFACE_PROPERTY, "")
                    ),
                    "surface_constrained": bool(
                        int(getattr(self, "axis_index", -1)) < 0
                    ),
                    "base_location": tuple(self.initial_matrix.translation),
                    "displacement": tuple(
                        final_location - self.initial_matrix.translation
                    ),
                }
                restore_data = {
                    "kind": "CONTACT",
                    "target_name": guide.name,
                    "surface_name": self.initial_surface_name,
                    "matrix": self.initial_matrix.copy(),
                    "point": tuple(self.initial_point),
                    "point_exists": bool(self.initial_point),
                    "normal": tuple(self.initial_normal),
                    "normal_exists": bool(self.initial_normal),
                    "local_matrix": tuple(self.initial_local_matrix),
                    "local_matrix_exists": bool(self.initial_local_matrix),
                    "solver_matrix": (
                        self.initial_solver_matrix.copy()
                        if self.initial_solver_matrix is not None else None
                    ),
                    "simulated_pose_matrix": (
                        self.initial_simulated_pose_matrix.copy()
                        if self.initial_simulated_pose_matrix is not None else None
                    ),
                }
            if cancel:
                initial_surface = bpy.data.objects.get(self.initial_surface_name)
                if initial_surface is not None:
                    _surface_contact_bind_guide_surface(
                        context,
                        guide,
                        initial_surface,
                        self.initial_matrix.translation,
                    )
                guide.matrix_world = self.initial_matrix
                if self.initial_point:
                    guide[SURFACE_CONTACT_POINT_PROPERTY] = self.initial_point
                if self.initial_normal:
                    guide[SURFACE_CONTACT_NORMAL_PROPERTY] = self.initial_normal
                if self.initial_local_matrix:
                    guide[SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY] = (
                        self.initial_local_matrix
                    )
                solver = _surface_contact_solver_from_guide(guide)
                if solver is not None and self.initial_solver_matrix is not None:
                    solver.matrix_world = self.initial_solver_matrix
                _surface_contact_restore_simulated_pose(
                    context,
                    guide,
                    self.initial_simulated_pose_matrix,
                    update_view_layer = False,
                )
                context.view_layer.update()
            # Apply the settled displacement through a real REGISTER+UNDO
            # operator after Blender releases the C-side gizmo. This creates
            # one meaningful history entry and exposes editable XYZ values in
            # Adjust Last Operation instead of appending empty undo states.
            _pin_gizmo_defer_finish(
                self,
                target_data,
                move_operation = move_operation,
                restore_data = restore_data,
            )
        finally:
            _state["pin_target_dragging"] = False
            _tag_redraw_all_view3d()


class ANIMATOR_UTILS_GGT_surface_contact_target(bpy.types.GizmoGroup):
    bl_idname = "ANIMATOR_UTILS_GGT_surface_contact_target"
    bl_label = "Surface Contact Target"
    bl_space_type = "VIEW_3D"
    bl_region_type = "WINDOW"
    bl_options = {"3D", "SELECT", "PERSISTENT"}

    @classmethod
    def poll(cls, context):
        return getattr(context, "mode", "") == "POSE"

    def setup(self, context):
        self.target_gizmos = {}
        self.target_gizmo = None
        self.target_gizmo_pool = []
        self.axis_gizmos = []
        for axis_index, color in enumerate(
            _pin_gizmo_theme_axis_colors(context)
        ):
            axis_gizmo = self.gizmos.new("GIZMO_GT_arrow_3d")
            axis_gizmo.draw_style = "NORMAL"
            axis_gizmo.color = color
            axis_gizmo.alpha = 0.55
            axis_gizmo.color_highlight = color
            axis_gizmo.alpha_highlight = 0.75
            axis_gizmo.use_draw_modal = True
            axis_gizmo.use_event_handle_all = True
            axis_gizmo.hide = True
            axis_gizmo.hide_select = True
            axis_gizmo.select = False
            axis_gizmo.scale_basis = PIN_GIZMO_AXIS_SCALE
            axis_gizmo.line_width = 2.5
            axis_gizmo.select_bias = 1.0
            axis_gizmo.target_set_handler(
                "offset",
                get = _pin_gizmo_axis_offset_get,
                set = _pin_gizmo_axis_offset_set,
            )
            operator = axis_gizmo.target_set_operator(
                "staticaliza.transform_selected_pin"
            )
            operator.transform_mode = "TRANSLATE"
            operator.initial_axis = axis_index
            operator.finish_on_release = True
            operator.exclusive_pin_selection = False
            self.axis_gizmos.append(axis_gizmo)
        # The diamond shares Blender's native gizmo layer and draws after the
        # arrows, masking their bases while every guide circle stays below.
        _pin_gizmo_ensure_target_pool(
            self,
            PIN_GIZMO_TARGET_POOL_SIZE,
            ANIMATOR_UTILS_GT_surface_contact_target.bl_idname,
            SURFACE_CONTACT_HOT_PINK[:3],
            (1.0, 0.45, 1.0),
        )
        self.active_target_key = ""
        self.axes_visible = False
        self.active_axis_index = -1
        self.center_dragging = False

    def draw_prepare(self, context):
        hide_for_keyboard = bool(
            (
                _state.get("pin_keyboard_transform_active", False)
                and not _state.get("pin_transform_from_gizmo", False)
            )
            or _state.get("pin_snap_transform_active", False)
        )
        if hide_for_keyboard:
            for gizmo in (*self.target_gizmo_pool, *self.axis_gizmos):
                _pin_gizmo_set_if_changed(gizmo, "hide", True)
                _pin_gizmo_set_if_changed(gizmo, "hide_select", True)
                _pin_gizmo_set_if_changed(gizmo, "select", False)
            return
        if (
            _pin_primary_mouse_pressed()
            and not _state.get("pin_target_dragging", False)
            and not _state.get("pin_keyboard_transform_active", False)
        ):
            return
        if _animation_playback_active(context):
            for gizmo in (*self.target_gizmo_pool, *self.axis_gizmos):
                _pin_gizmo_set_if_changed(gizmo, "hide", True)
                _pin_gizmo_set_if_changed(gizmo, "hide_select", True)
                _pin_gizmo_set_if_changed(gizmo, "select", False)
            return
        if (
            _window_manager_has_modal_operator(context)
            and not _state.get("pin_target_dragging", False)
            and not _state.get("pin_keyboard_transform_active", False)
        ):
            # Do not rebuild this custom map under Blender's active native
            # gizmo; doing so can invalidate native highlight/press ownership.
            return
        targets = {
            key: data
            for key, data in _pin_available_target_data(context).items()
            if data[0] == "CONTACT"
        }
        selected_key = _pin_selected_target_key()
        selected_keys = _pin_selected_target_keys()
        modal_active = bool(
            _state.get("pin_target_dragging", False)
            and selected_key
            and str(getattr(self, "active_target_key", "")) == selected_key
        )
        if not modal_active:
            self.active_axis_index = -1
            self.center_dragging = False
        if modal_active and selected_key not in targets:
            # Let the gizmo's next modal callback cancel cleanly. Rebinding or
            # hiding it here would invalidate Blender's active C gizmo pointer.
            return
        history_selection_locked = bool(
            _state.get("pin_history_active", False)
            and selected_key.startswith("CONTACT:")
            and selected_key in self.target_gizmos
        )
        if history_selection_locked:
            # Keep the target non-interactive during history reconciliation,
            # but do not freeze its old matrix until the delayed clear timer.
            for gizmo in self.target_gizmos.values():
                _pin_gizmo_set_if_changed(gizmo, "hide_select", True)
            for axis_gizmo in self.axis_gizmos:
                _pin_gizmo_set_if_changed(axis_gizmo, "hide_select", True)
        _pin_gizmo_ensure_target_pool(
            self,
            len(targets),
            ANIMATOR_UTILS_GT_surface_contact_target.bl_idname,
            SURFACE_CONTACT_HOT_PINK[:3],
            (1.0, 0.45, 1.0),
        )
        _pin_gizmo_stable_target_mapping(self, targets)
        modal_center = (
            self.target_gizmos.get(selected_key)
            if modal_active and int(self.active_axis_index) < 0
            else None
        )
        live_gizmo_ids = {
            id(gizmo) for gizmo in self.target_gizmos.values()
        }
        for pooled_gizmo in self.target_gizmo_pool:
            if id(pooled_gizmo) in live_gizmo_ids:
                continue
            _pin_gizmo_set_if_changed(pooled_gizmo, "hide", True)
            _pin_gizmo_set_if_changed(pooled_gizmo, "hide_select", True)
            if pooled_gizmo != modal_center:
                _pin_gizmo_set_if_changed(pooled_gizmo, "select", False)
        for target_key in sorted(targets):
            gizmo = self.target_gizmos.get(target_key)
            if gizmo is None:
                continue
            target_data = targets[target_key]
            guide = target_data[3]
            center_in_front = _pin_gizmo_center_in_front(
                context,
                guide.matrix_world.translation,
            )
            gizmo.target_key = target_key
            gizmo.guide_name = guide.name
            gizmo.locked_axes = _pin_target_locked_axes(target_data)
            if gizmo != modal_center:
                _pin_gizmo_set_if_changed(
                    gizmo,
                    "hide",
                    not center_in_front,
                )
                _pin_gizmo_set_if_changed(
                    gizmo,
                    "hide_select",
                    history_selection_locked or not center_in_front,
                )
                # Logical pin selection lives in runtime state and alpha.
                # Leaving Blender's C-side gizmo selected after release makes
                # it a fallback event target even when it is hidden/occluded.
                _pin_gizmo_set_if_changed(gizmo, "select", False)
            _pin_gizmo_set_if_changed(
                gizmo,
                "alpha",
                1.0 if target_key in selected_keys else 0.36,
            )
            _pin_gizmo_set_if_changed(
                gizmo,
                "matrix_basis",
                _pin_gizmo_center_matrix(guide.matrix_world.translation),
            )
            _pin_gizmo_set_if_changed(
                gizmo,
                "scale_basis",
                PIN_GIZMO_DIAMOND_SCALE,
            )
        target_data = targets.get(selected_key)
        next_active_target_key = selected_key if target_data else ""
        if self.active_target_key != next_active_target_key:
            previous_gizmo = self.target_gizmos.get(self.active_target_key)
            if previous_gizmo is not None and previous_gizmo != modal_center:
                _pin_gizmo_set_if_changed(previous_gizmo, "select", False)
            self.active_target_key = next_active_target_key
            self.active_axis_index = -1
            self.center_dragging = False
            for axis_gizmo in self.axis_gizmos:
                _pin_gizmo_set_if_changed(axis_gizmo, "select", False)
        self.target_gizmo = self.target_gizmos.get(selected_key)
        self.axes_visible = bool(target_data)
        guide = target_data[3] if target_data else None
        point = (
            guide.matrix_world.translation.copy()
            if guide
            else Vector((0.0, 0.0, 0.0))
        )
        handle_point = (
            _pin_transform_group_handle_point(context, target_data)
            if target_data
            else point
        )
        handle_scale = PIN_GIZMO_AXIS_SCALE
        show_axes = False
        locked_axes = _pin_target_locked_axes(target_data)
        orientation_basis = _pin_transform_orientation_matrix(
            context,
            target_data,
            guide.matrix_world if guide is not None else None,
        )
        for axis_index, axis_gizmo in enumerate(self.axis_gizmos):
            modal_axis = bool(
                modal_active and int(self.active_axis_index) == axis_index
            )
            axis = orientation_basis.col[axis_index].copy()
            if axis.length_squared <= 1.0e-12:
                axis = Vector((0.0, 0.0, 1.0))
            axis.normalize()
            show_axis = bool(
                show_axes
                and _pin_gizmo_axis_in_front(context, handle_point, axis)
            )
            if not modal_axis:
                _pin_gizmo_set_if_changed(
                    axis_gizmo,
                    "hide",
                    not show_axis,
                )
                _pin_gizmo_set_if_changed(axis_gizmo, "select", False)
            if not modal_axis:
                _pin_gizmo_set_if_changed(
                    axis_gizmo,
                    "hide_select",
                    bool(
                        history_selection_locked
                        or not show_axis
                        or locked_axes[axis_index]
                    ),
                )
            _pin_gizmo_set_if_changed(
                axis_gizmo,
                "alpha",
                PIN_GIZMO_LOCKED_ALPHA if locked_axes[axis_index] else 0.55,
            )
            _pin_gizmo_set_if_changed(
                axis_gizmo,
                "alpha_highlight",
                PIN_GIZMO_LOCKED_ALPHA if locked_axes[axis_index] else 0.75,
            )
            _pin_gizmo_set_if_changed(
                axis_gizmo,
                "matrix_basis",
                _pin_gizmo_axis_matrix(handle_point, axis),
            )
            _pin_gizmo_set_if_changed(
                axis_gizmo,
                "scale_basis",
                handle_scale,
            )
