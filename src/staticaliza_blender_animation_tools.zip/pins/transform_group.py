"""Multi-pin transform snapshots, group pivots, and shared application."""

from ..core.runtime import *  # noqa: F403


_GROUP_CONTACT_PROPERTIES = (
    SURFACE_CONTACT_POINT_PROPERTY,
    SURFACE_CONTACT_NORMAL_PROPERTY,
    SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY,
    SURFACE_CONTACT_DETACHED_PROPERTY,
)


def _pin_transform_group_capture(operator, context, active_key):
    states = []
    for target_key, target_data in _pin_selected_targets_data(context):
        if target_key == active_key:
            continue
        kind, armature, pose_bone, payload = target_data
        initial_matrix = _pin_keyboard_target_matrix(target_data)
        if initial_matrix is None:
            continue
        state = {
            "target_key": target_key,
            "target_data": target_data,
            "kind": kind,
            "armature": armature,
            "pose_bone": pose_bone,
            "payload": payload,
            "initial_matrix": initial_matrix,
        }
        if kind == "YELLOW":
            state["packed"] = tuple(
                value.copy() if hasattr(value, "copy") else value
                for value in payload
            )
            state["property_exists"] = bool(
                YELLOW_PIN_TARGET_PROPERTY in pose_bone
            )
            state["property_value"] = tuple(
                pose_bone.get(YELLOW_PIN_TARGET_PROPERTY, ())
            )
        else:
            state["properties"] = {
                name: (
                    name in payload,
                    (
                        value.copy()
                        if hasattr(
                            value := payload.get(name),
                            "copy",
                        )
                        else value
                    ),
                )
                for name in _GROUP_CONTACT_PROPERTIES
            }
            solver = _surface_contact_solver_from_guide(payload)
            state["solver_matrix"] = (
                solver.matrix_world.copy() if solver is not None else None
            )
            state["simulated_pose"] = (
                _surface_contact_simulated_pose_matrix(payload)
            )
            state["keep_attached"] = _pin_contact_is_attached(
                context,
                payload,
            )
        states.append(state)
    operator.group_pin_states = states
    return states


def _pin_transform_redo_matrix_values(matrix):
    if matrix is None:
        return []
    return [float(value) for row in matrix for value in row]


def _pin_transform_group_redo_json(operator, active_target_data):
    """Serialize every selected pin's initial and settled transform."""
    items = []
    active_key = str(getattr(operator, "target_key", ""))
    states = [{
        "target_key": active_key,
        "target_data": active_target_data,
        "initial_matrix": getattr(operator, "initial_pin_matrix", None),
        "solver_matrix": getattr(operator, "initial_solver_matrix", None),
        "keep_attached": bool(
            getattr(operator, "contact_keep_attached", False)
        ),
        "active": True,
    }]
    states.extend(
        {
            **state,
            "active": False,
            "solver_matrix": state.get("solver_matrix"),
        }
        for state in getattr(operator, "group_pin_states", ())
    )
    for state in states:
        target_data = state.get("target_data")
        initial_matrix = state.get("initial_matrix")
        if target_data is None or initial_matrix is None:
            continue
        kind, armature, pose_bone, payload = target_data
        result_matrix = _pin_keyboard_target_matrix(target_data)
        if kind == "YELLOW":
            current = _state.get("yellow_fixed", {}).get(
                _owner_bone_key(armature, pose_bone.name)
            )
            if current:
                result_matrix = initial_matrix.copy()
                result_matrix.translation = Vector(current[0])
        solver = (
            _surface_contact_solver_from_guide(payload)
            if kind == "CONTACT"
            else None
        )
        items.append({
            "active": bool(state.get("active", False)),
            "target_key": str(state.get("target_key", active_key)),
            "kind": kind,
            "armature": armature.name,
            "bone": pose_bone.name if pose_bone is not None else "",
            "guide": payload.name if kind == "CONTACT" else "",
            "initial": _pin_transform_redo_matrix_values(initial_matrix),
            "result": _pin_transform_redo_matrix_values(result_matrix),
            "initial_solver": _pin_transform_redo_matrix_values(
                state.get("solver_matrix")
            ),
            "result_solver": _pin_transform_redo_matrix_values(
                solver.matrix_world if solver is not None else None
            ),
            "keep_attached": bool(state.get("keep_attached", False)),
        })
    return json.dumps(items)


def _pin_transform_group_initial_points(operator):
    return (
        operator.initial_pin_matrix.translation.copy(),
        *tuple(
            state["initial_matrix"].translation.copy()
            for state in getattr(operator, "group_pin_states", ())
        ),
    )


def _pin_transform_group_pivot_options(
    operator,
    active_target_data,
    armature,
    selected_bones,
):
    return {
        "pin_points": _pin_transform_group_initial_points(operator),
        "pin_targets": (
            active_target_data,
            *tuple(
                state["target_data"]
                for state in getattr(operator, "group_pin_states", ())
            ),
        ),
        "bone_targets": tuple(
            (armature, selected_bone)
            for selected_bone in selected_bones
        ),
    }


def _pin_transform_group_can_rotate(context):
    pin_count = len(_pin_selected_targets_data(context))
    bone_count = sum(
        len(pose_bones)
        for pose_bones in _selected_pose_bones_by_owner(context).values()
    )
    return pin_count + bone_count >= 2


def _pin_transform_group_restore(context, operator):
    changed = False
    for state in getattr(operator, "group_pin_states", ()):
        kind = state["kind"]
        armature = state["armature"]
        pose_bone = state["pose_bone"]
        payload = state["payload"]
        if kind == "YELLOW":
            fixed = dict(_state.get("yellow_fixed", {}))
            fixed[_owner_bone_key(armature, pose_bone.name)] = state["packed"]
            _state["yellow_fixed"] = fixed
            if state["property_exists"]:
                pose_bone[YELLOW_PIN_TARGET_PROPERTY] = state["property_value"]
            elif YELLOW_PIN_TARGET_PROPERTY in pose_bone:
                del pose_bone[YELLOW_PIN_TARGET_PROPERTY]
            changed = True
            continue
        payload.matrix_world = state["initial_matrix"].copy()
        for name, (existed, value) in state["properties"].items():
            if name == SURFACE_CONTACT_DETACHED_PROPERTY:
                continue
            if existed:
                payload[name] = value
            elif name in payload:
                del payload[name]
        detached_existed, detached = state["properties"][
            SURFACE_CONTACT_DETACHED_PROPERTY
        ]
        _pin_restore_contact_detached_state(
            payload,
            detached_existed,
            detached,
        )
        solver = _surface_contact_solver_from_guide(payload)
        if solver is not None and state["solver_matrix"] is not None:
            solver.matrix_world = state["solver_matrix"].copy()
        _surface_contact_restore_simulated_pose(
            context,
            payload,
            state["simulated_pose"],
            update_view_layer = False,
        )
        changed = True
    return changed


def _pin_transform_group_apply(context, operator, core_matrix, shared_delta):
    changed = False
    yellow_changed = False
    for state in getattr(operator, "group_pin_states", ()):
        target_data = state["target_data"]
        kind = state["kind"]
        armature = state["armature"]
        pose_bone = state["pose_bone"]
        payload = state["payload"]
        initial_matrix = state["initial_matrix"]
        origin = (
            initial_matrix.translation
            if operator.individual_origins
            and operator.transform_mode != "TRANSLATE"
            else operator.pivot
        )
        pin_delta = (
            _pin_keyboard_around_origin(core_matrix, origin)
            if operator.individual_origins
            and operator.transform_mode != "TRANSLATE"
            else shared_delta
        )
        desired_matrix = _pin_transform_position_matrix(
            operator.transform_mode,
            initial_matrix,
            pin_delta,
        )
        if operator.transform_mode == "TRANSLATE":
            desired_matrix.translation = _pin_gizmo_apply_axis_locks(
                desired_matrix.translation,
                initial_matrix.translation,
                _pin_target_locked_axes(target_data),
                operator.orientation,
            )
        if kind == "YELLOW":
            pin_changed = _yellow_set_pin_target(
                armature,
                pose_bone.name,
                desired_matrix.translation,
            )
            _yellow_store_target_property(
                armature,
                pose_bone.name,
                desired_matrix.translation,
            )
            yellow_changed = True
        else:
            solver_matrix = _pin_transform_position_matrix(
                operator.transform_mode,
                state["solver_matrix"],
                pin_delta,
            )
            pin_changed = _pin_keyboard_apply_contact_matrix(
                context,
                payload,
                desired_matrix,
                solver_matrix = solver_matrix,
                keep_attached = state["keep_attached"],
                max_iterations = SURFACE_CONTACT_LIVE_SOLVER_ITERATIONS,
            )
        if (
            armature.name == str(operator.armature_name)
            and pose_bone.name in operator.bone_order
        ):
            pin_changed = _pin_apply_yellow_priority(
                context,
                armature,
                pose_bone,
            ) or pin_changed
        changed = bool(pin_changed or changed)
    if yellow_changed:
        context.view_layer.update()
    return changed


def _pin_transform_contact_commit_snapshot(guide, keep_attached):
    solver = _surface_contact_solver_from_guide(guide)
    return {
        "guide": guide,
        "keep_attached": bool(keep_attached),
        "matrix": guide.matrix_world.copy(),
        "properties": {
            name: (
                name in guide,
                (
                    value.copy()
                    if hasattr(value := guide.get(name), "copy")
                    else value
                ),
            )
            for name in _GROUP_CONTACT_PROPERTIES
        },
        "solver_matrix": (
            solver.matrix_world.copy() if solver is not None else None
        ),
        "pose_matrix": _surface_contact_simulated_pose_matrix(guide),
    }


def _pin_transform_restore_contact_commit_snapshot(context, snapshot):
    guide = snapshot["guide"]
    guide.matrix_world = snapshot["matrix"].copy()
    for name, (existed, value) in snapshot["properties"].items():
        if existed:
            guide[name] = value
        elif name in guide:
            del guide[name]
    solver = _surface_contact_solver_from_guide(guide)
    if solver is not None and snapshot["solver_matrix"] is not None:
        solver.matrix_world = snapshot["solver_matrix"].copy()
    _surface_contact_restore_simulated_pose(
        context,
        guide,
        snapshot["pose_matrix"],
        update_view_layer = False,
    )


def _pin_transform_commit_contacts(context, entries):
    unique = {}
    for guide, keep_attached in entries:
        if guide is not None:
            unique[guide.name] = (guide, keep_attached)
    if not unique:
        return False
    if len(unique) == 1:
        guide, keep_attached = next(iter(unique.values()))
        _pin_keyboard_commit_contact(context, guide, keep_attached)
        return True
    snapshots = tuple(
        _pin_transform_contact_commit_snapshot(guide, keep_attached)
        for guide, keep_attached in unique.values()
    )
    for snapshot in snapshots:
        _pin_transform_restore_contact_commit_snapshot(context, snapshot)
        _surface_contact_commit_target_key(
            context,
            snapshot["guide"],
            detached = not snapshot["keep_attached"],
        )
    for snapshot in snapshots:
        _pin_transform_restore_contact_commit_snapshot(context, snapshot)
    context.view_layer.update()
    guides = tuple(snapshot["guide"] for snapshot in snapshots)
    for guide in guides:
        _surface_contact_store_valid_pose(guide)
        _surface_contact_store_owner_pose_base(guide)
        _surface_contact_capture_live_pose(guide)
    _surface_contact_store_persistent_pose_snapshots(guides)
    _surface_contact_seed_runtime_signatures(context, guides)
    _tag_redraw_all_view3d()
    return True


def _pin_transform_group_commit(context, operator, active_contact = None):
    entries = [active_contact] if active_contact is not None else []
    entries.extend(
        (state["payload"], state["keep_attached"])
        for state in getattr(operator, "group_pin_states", ())
        if state["kind"] == "CONTACT"
    )
    return _pin_transform_commit_contacts(context, entries)


def _pin_transform_group_handle_point(context, active_target_data):
    active_matrix = _pin_keyboard_target_matrix(active_target_data)
    if active_matrix is None:
        return Vector((0.0, 0.0, 0.0))
    selected_targets = tuple(_pin_selected_targets_data(context))
    points = [
        matrix.translation.copy()
        for _target_key, target_data in selected_targets
        if (matrix := _pin_keyboard_target_matrix(target_data)) is not None
    ]
    selected_bones = tuple(
        (armature, pose_bone)
        for armature, pose_bones
        in _selected_pose_bones_by_owner(context).items()
        for pose_bone in pose_bones
    )
    for armature, pose_bone in selected_bones:
        points.append((armature.matrix_world @ pose_bone.matrix).translation)
    if len(points) <= 1:
        return active_matrix.translation.copy()
    pivot, _individual = _pin_keyboard_pivot(
        context,
        active_matrix,
        active_target_data[1],
        {},
        pin_points = points,
        pin_targets = tuple(
            target_data for _target_key, target_data in selected_targets
        ),
        bone_targets = selected_bones,
    )
    return pivot


def _pin_transform_group_has_selected_bones(context):
    return any(
        pose_bones
        for pose_bones in _selected_pose_bones_by_owner(context).values()
    )


def _pin_transform_use_custom_axes(context):
    """Pin arrows yield to Blender's native gizmo for real bone selection."""
    return not _pin_transform_group_has_selected_bones(context)
