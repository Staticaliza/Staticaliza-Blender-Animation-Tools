"""Carry virtual pin selection through Blender's native bone transforms."""

from ..core.runtime import *  # noqa: F403


class _PinNativeGroupSession:
    pass


def _pin_native_group_mode(identifier):
    identifier = str(identifier).lower()
    if "rotate" in identifier:
        return "ROTATE"
    if "resize" in identifier or "scale" in identifier:
        return "SCALE"
    return "TRANSLATE"


def _pin_native_group_capture(context):
    if (
        not _pin_selected_target_keys()
        or not _pin_transform_group_has_selected_bones(context)
    ):
        _state["pin_native_group_session"] = None
        return False
    session = _PinNativeGroupSession()
    _pin_transform_group_capture(session, context, "")
    if not session.group_pin_states:
        _state["pin_native_group_session"] = None
        return False
    selected_bones = []
    for armature, pose_bones in _selected_pose_bones_by_owner(context).items():
        for pose_bone in pose_bones:
            depth = 0
            parent = pose_bone.parent
            while parent is not None:
                depth += 1
                parent = parent.parent
            selected_bones.append((
                depth,
                armature.name,
                pose_bone.name,
                armature.matrix_world @ pose_bone.matrix,
            ))
    selected_bones.sort(key = lambda item: (item[0], item[1], item[2]))
    if not selected_bones:
        _state["pin_native_group_session"] = None
        return False
    session.bones = tuple(selected_bones)
    session.individual_origins = False
    session.transform_mode = "TRANSLATE"
    session.orientation = Matrix.Identity(3)
    session.pivot = _pin_transform_group_handle_point(
        context,
        session.group_pin_states[0]["target_data"],
    )
    session.bone_order = []
    session.armature_name = ""
    session.selected_keys = _pin_selected_target_keys()
    session.active_key = _pin_selected_target_key()
    session.last_delta = None
    _state["pin_native_group_session"] = session
    return True


def _pin_native_group_delta(context, session):
    for _depth, armature_name, bone_name, initial_world in session.bones:
        armature = bpy.data.objects.get(str(armature_name))
        pose_bone = (
            armature.pose.bones.get(str(bone_name))
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is None:
            continue
        current_world = armature.matrix_world @ pose_bone.matrix
        return current_world @ initial_world.inverted_safe()
    return Matrix.Identity(4)


def _pin_native_group_apply_targets(context, session, delta):
    """Batch virtual targets without recursively solving inside depsgraph."""
    changed = False
    for state in session.group_pin_states:
        target_data = state["target_data"]
        initial_matrix = state["initial_matrix"]
        desired_matrix = _pin_transform_position_matrix(
            session.transform_mode,
            initial_matrix,
            delta,
        )
        if session.transform_mode == "TRANSLATE":
            desired_matrix.translation = _pin_gizmo_apply_axis_locks(
                desired_matrix.translation,
                initial_matrix.translation,
                _pin_target_locked_axes(target_data),
                session.orientation,
            )
        if state["kind"] == "YELLOW":
            changed = _yellow_set_pin_target(
                state["armature"],
                state["pose_bone"].name,
                desired_matrix.translation,
            ) or changed
            _yellow_store_target_property(
                state["armature"],
                state["pose_bone"].name,
                desired_matrix.translation,
            )
            continue
        guide = state["payload"]
        projected = _surface_contact_bound_surface_point(
            context,
            guide,
            desired_matrix.translation,
        )
        if projected is None:
            continue
        point, normal = projected
        if str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, "")) == (
            SURFACE_CONTACT_KIND_SIMULATED
        ):
            point = _surface_contact_clamp_target_before_limb(
                context,
                guide,
                guide.matrix_world.translation,
                point,
            )
        changed = _surface_contact_set_guide_surface_point(
            context,
            guide,
            point,
            normal,
            update_view_layer=False,
        ) or changed
        if state["keep_attached"]:
            _surface_contact_clear_snap_departure(guide)
        else:
            _surface_contact_set_snap_detached(guide, True)
    return changed


def _pin_native_group_apply(context, transform_operator = ""):
    session = _state.get("pin_native_group_session")
    if session is None or _state.get("pin_native_group_applying", False):
        return False
    session.transform_mode = _pin_native_group_mode(
        transform_operator
        or _state.get("pin_snap_transform_operator", "")
    )
    delta = _pin_native_group_delta(context, session)
    previous_delta = getattr(session, "last_delta", None)
    if previous_delta is not None and not _pin_keyboard_matrices_differ(
        delta,
        previous_delta,
    ):
        return False
    _state["pin_native_group_applying"] = True
    try:
        changed = _pin_native_group_apply_targets(context, session, delta)
        session.last_delta = delta.copy()
    finally:
        _state["pin_native_group_applying"] = False
    _state["pin_gizmo_selected_key"] = session.active_key
    _state["pin_gizmo_selected_keys"] = set(session.selected_keys)
    _state["pin_gizmo_selected_keys_active"] = session.active_key
    return changed


def _pin_native_group_changed(session):
    for state in session.group_pin_states:
        current = _pin_keyboard_target_matrix(state["target_data"])
        if current is not None and _pin_keyboard_matrices_differ(
            current,
            state["initial_matrix"],
        ):
            return True
    return False


def _pin_native_group_finish(context):
    session = _state.get("pin_native_group_session")
    if session is None:
        return False
    _pin_native_group_apply(context)
    changed = _pin_native_group_changed(session)
    if changed:
        _pin_transform_group_commit(context, session)
    else:
        _pin_transform_group_restore(context, session)
    _state["pin_gizmo_selected_key"] = session.active_key
    _state["pin_gizmo_selected_keys"] = set(session.selected_keys)
    _state["pin_gizmo_selected_keys_active"] = session.active_key
    _state["pin_gizmo_selection_keys"] = _pin_pose_selection_signature(
        context
    )
    _state["pin_native_group_session"] = None
    _tag_redraw_all_view3d()
    return changed


def _pin_native_group_clear():
    _state["pin_native_group_session"] = None
    _state["pin_native_group_applying"] = False


def _pin_native_group_cancel(context):
    """Restore virtual group members before clearing a cancelled native edit."""
    session = _state.get("pin_native_group_session")
    if session is None:
        return False
    changed = _pin_transform_group_restore(context, session)
    _state["pin_native_group_session"] = None
    return changed
