"""Paired, keyframe-free surface draggers for quick limb posing."""

from ..core.runtime import *  # noqa: F403

def _on_smart_dragger_setting_change(_owner, context):
    _state["smart_dragger_cache"] = {}
    if not getattr(context.window_manager, "smart_draggers_enabled", False):
        _state["smart_dragger_selected_side"] = -1
        _state["smart_dragger_owner"] = None
    _tag_redraw_all_view3d()

def _register_smart_dragger_properties():
    bpy.types.WindowManager.smart_draggers_enabled = bpy.props.BoolProperty(
        name = "Smart Draggers",
        description = "Show paired surface handles for quick limb posing",
        default = False,
        update = _on_smart_dragger_setting_change,
    )
    bpy.types.WindowManager.smart_dragger_mode = bpy.props.EnumProperty(
        name = "Position",
        description = "Choose where the primary Smart Dragger is placed",
        items = (
            ("MODE_3", "Smart", "Use the selected welded-object face"),
            ("MODE_4", "Bone Start", "Use the active bone head"),
            ("MODE_2", "Bone Center", "Use the weighted geometry center"),
            ("MODE_1", "Bone End", "Use the active bone tail"),
        ),
        default = "MODE_3",
        update = _on_smart_dragger_setting_change,
    )
    bpy.types.WindowManager.smart_dragger_axis = bpy.props.EnumProperty(
        name = "Axis",
        description = "Choose the red handle's welded-object face",
        items = PIN_AXIS_ITEMS,
        default = "Y_NEG",
        update = _on_smart_dragger_setting_change,
    )
    bpy.types.WindowManager.smart_dragger_collision = bpy.props.BoolProperty(
        name = "Surface Collision",
        description = "Clamp both handles against scene surfaces while posing",
        default = True,
        update = _on_smart_dragger_setting_change,
    )

def _unregister_smart_dragger_properties():
    for name in (
        "smart_draggers_enabled",
        "smart_dragger_mode",
        "smart_dragger_axis",
        "smart_dragger_collision",
    ):
        if hasattr(bpy.types.WindowManager, name):
            delattr(bpy.types.WindowManager, name)

def _reset_smart_dragger_runtime():
    _state["smart_dragger_selected_side"] = -1
    _state["smart_dragger_owner"] = None
    _state["smart_dragger_transform_active"] = False
    _state["smart_dragger_cache"] = {}

def _smart_dragger_active_pose(context):
    if (
        context is None
        or getattr(context, "mode", "") != "POSE"
        or not getattr(
            getattr(context, "window_manager", None),
            "smart_draggers_enabled",
            False,
        )
    ):
        return None, None
    pose_bone = getattr(context, "active_pose_bone", None)
    armature = _pose_bone_owner(
        context,
        pose_bone,
        _pose_scope_armatures(context),
    )
    selected_side = int(_state.get("smart_dragger_selected_side", -1))
    owner = _state.get("smart_dragger_owner")
    if selected_side in (0, 1) and owner:
        # Any new native bone selection takes ownership back immediately.
        if armature is not None and pose_bone is not None and _pose_bone_selected(pose_bone):
            _state["smart_dragger_selected_side"] = -1
            _state["smart_dragger_owner"] = None
        else:
            armature = bpy.data.objects.get(str(owner[0]))
            pose_bone = (
                armature.pose.bones.get(str(owner[1]))
                if armature is not None and getattr(armature, "pose", None)
                else None
            )
            return armature, pose_bone
    if armature is None or pose_bone is None or not _pose_bone_selected(pose_bone):
        return None, None
    return armature, pose_bone


def _smart_dragger_capture_pair(context, armature, pose_bone, mode, axis):
    if SMART_DRAGGER_INITIAL_BASIS_PROPERTY not in pose_bone:
        pose_bone[SMART_DRAGGER_INITIAL_BASIS_PROPERTY] = tuple(
            float(value)
            for row in pose_bone.matrix_basis
            for value in row
        )
    depsgraph = context.evaluated_depsgraph_get()
    evaluated_armature = armature.evaluated_get(depsgraph)
    objects, _active = _targets(context, armature)
    bounds = {}
    if int(mode) == 2:
        bounds = _collect_world_shape_from_largest_components(
            context,
            depsgraph,
            armature,
            evaluated_armature,
            {pose_bone.name},
            objs = objects,
        )
    primary = _yellow_capture(
        context,
        depsgraph,
        armature,
        evaluated_armature,
        objects,
        pose_bone.name,
        int(mode),
        bounds,
        axis = axis,
    )
    opposite_axis = _smart_dragger_opposite_axis(axis)
    opposite_mode = {
        1: 4,
        4: 1,
        2: 3,
    }.get(int(mode), 3)
    secondary = _yellow_capture(
        context,
        depsgraph,
        armature,
        evaluated_armature,
        objects,
        pose_bone.name,
        opposite_mode,
        bounds,
        axis = opposite_axis,
    )
    return primary, secondary


def _smart_dragger_data(context):
    armature, pose_bone = _smart_dragger_active_pose(context)
    if armature is None or pose_bone is None:
        return None
    wm = context.window_manager
    mode_name = str(getattr(wm, "smart_dragger_mode", "MODE_3"))
    mode = {
        "MODE_1": 1,
        "MODE_2": 2,
        "MODE_3": 3,
        "MODE_4": 4,
    }.get(mode_name, 3)
    axis = str(getattr(wm, "smart_dragger_axis", "Y_NEG"))
    cache_key = (
        _armature_session_uid(armature),
        pose_bone.name,
        mode,
        axis,
    )
    cache = _state.setdefault("smart_dragger_cache", {})
    packed_pair = cache.get(cache_key)
    if packed_pair is None:
        packed_pair = _smart_dragger_capture_pair(
            context,
            armature,
            pose_bone,
            mode,
            axis,
        )
        if not all(packed_pair):
            return None
        cache.clear()
        cache[cache_key] = packed_pair
    depsgraph = context.evaluated_depsgraph_get()
    evaluated_armature = armature.evaluated_get(depsgraph)
    evaluated_bone = evaluated_armature.pose.bones.get(pose_bone.name)
    if evaluated_bone is None:
        return None
    points = tuple(
        Vector(
            _yellow_current_world_point(
                depsgraph,
                evaluated_armature,
                evaluated_bone,
                packed,
            )
        )
        for packed in packed_pair
    )
    bone_axes = (
        evaluated_armature.matrix_world.to_3x3()
        @ evaluated_bone.matrix.to_3x3()
    )
    surface_axes = (axis, _smart_dragger_opposite_axis(axis))
    matrices = tuple(
        _smart_dragger_surface_matrix(
            context,
            point,
            packed,
            surface_axis,
            bone_axes,
        )
        for point, packed, surface_axis in zip(
            points,
            packed_pair,
            surface_axes,
        )
    )
    normals = tuple(matrix.to_3x3().col[2].normalized() for matrix in matrices)
    return {
        "armature": armature,
        "pose_bone": pose_bone,
        "points": points,
        "normals": normals,
        "matrices": matrices,
        "packed": packed_pair,
        "cache_key": cache_key,
    }


def _smart_dragger_collision_fraction(context, starts, ends, excluded):
    fraction = 1.0
    for start, end in zip(starts, ends):
        delta = Vector(end) - Vector(start)
        distance = delta.length
        if distance <= 1.0e-8:
            continue
        direction = delta / distance
        epsilon = min(1.0e-4, distance * 0.05)
        hit = _surface_contact_ray_cast(
            context,
            Vector(start) + (direction * epsilon),
            direction,
            max(0.0, distance - epsilon),
            excluded,
        )
        if hit is None:
            continue
        hit_fraction = max(
            0.0,
            min(1.0, (float(hit[3]) + epsilon - 1.0e-4) / distance),
        )
        fraction = min(fraction, hit_fraction)
    return fraction


def _smart_dragger_apply_world_delta(context, data, world_delta):
    armature = data["armature"]
    pose_bone = data["pose_bone"]
    initial_world = data["initial_world"]
    desired_world = world_delta @ initial_world
    desired_output = armature.matrix_world.inverted_safe() @ desired_world
    return _set_pose_bone_constrained_output_matrix(
        context,
        armature,
        pose_bone,
        desired_output,
    )


def _smart_dragger_project_2d(context, point):
    try:
        from bpy_extras import view3d_utils

        return view3d_utils.location_3d_to_region_2d(
            context.region,
            context.region_data,
            point,
        )
    except (AttributeError, RuntimeError, TypeError, ValueError):
        return None


def _smart_dragger_red_contact_visible(context, data):
    if not getattr(context.window_manager, "smart_dragger_collision", True):
        return False
    objects, _active = _targets(context, data["armature"])
    planes = _smart_dragger_collision_planes(
        context,
        data["points"][:1],
        data["normals"][:1],
        set(objects) | {data["armature"]},
        PIN_SNAP_WORLD_RADIUS * 1.05,
    )
    return bool(
        planes
        and _smart_dragger_plane_touching(data["points"][0], planes[0])
    )


class ANIMATOR_UTILS_OT_smart_dragger_transform(bpy.types.Operator):
    bl_idname = "staticaliza.smart_dragger_transform"
    bl_label = "Transform Smart Dragger"
    bl_description = "Pose the active limb from its selected Smart Dragger"
    bl_options = {"REGISTER", "UNDO", "BLOCKING"}

    transform_mode: bpy.props.EnumProperty(
        items = (
            ("TRANSLATE", "Move", ""),
            ("ROTATE", "Rotate", ""),
        ),
        options = {"HIDDEN", "SKIP_SAVE"},
    )
    initial_axis: bpy.props.IntProperty(
        default = -1,
        min = -1,
        max = 2,
        options = {"HIDDEN", "SKIP_SAVE"},
    )
    dragger_side: bpy.props.IntProperty(
        default = -1,
        min = -1,
        max = 1,
        options = {"HIDDEN", "SKIP_SAVE"},
    )
    finish_on_release: bpy.props.BoolProperty(
        default = False,
        options = {"HIDDEN", "SKIP_SAVE"},
    )

    @classmethod
    def poll(cls, context):
        return getattr(context, "mode", "") == "POSE" and getattr(
            getattr(context, "area", None), "type", ""
        ) == "VIEW_3D"

    def invoke(self, context, event):
        side = int(self.dragger_side)
        if side not in (0, 1):
            side = int(_state.get("smart_dragger_selected_side", -1))
        if side not in (0, 1):
            return {"PASS_THROUGH"}
        dragger = _smart_dragger_data(context)
        if dragger is None:
            return {"PASS_THROUGH"}
        if int(self.dragger_side) in (0, 1):
            _pin_gizmo_claim_pointer(event)
            _pin_deselect_target(push_history = False)
            _state["smart_dragger_selected_side"] = side
            _state["smart_dragger_owner"] = (
                dragger["armature"].name,
                dragger["pose_bone"].name,
            )
        armature = dragger["armature"]
        pose_bone = dragger["pose_bone"]
        evaluated = armature.evaluated_get(
            context.evaluated_depsgraph_get()
        ).pose.bones.get(pose_bone.name)
        if evaluated is None:
            return {"PASS_THROUGH"}
        self.armature_name = armature.name
        self.bone_name = pose_bone.name
        self.side = side
        self.axis_index = int(self.initial_axis)
        self.initial_basis = pose_bone.matrix_basis.copy()
        self.initial_world = armature.matrix_world @ evaluated.matrix
        self.initial_points = tuple(point.copy() for point in dragger["points"])
        self.initial_normals = tuple(
            normal.copy() for normal in dragger["normals"]
        )
        self.initial_point = self.initial_points[side].copy()
        self.initial_mouse = Vector((
            float(event.mouse_region_x),
            float(event.mouse_region_y),
        ))
        self.orientation = _pin_transform_orientation_matrix(
            context,
            ("YELLOW", armature, pose_bone, dragger["packed"][side]),
        )
        self.plane_axis_index = -1
        self.axis_offset = Vector((0.0, 0.0, 0.0))
        if self.axis_index >= 0:
            axis = self.orientation.col[self.axis_index]
            axis_point = _pin_gizmo_axis_mouse_point(
                context,
                self.initial_point,
                axis,
                self.initial_mouse,
            )
            if axis_point is not None:
                self.axis_offset = self.initial_point - axis_point
        else:
            plane_point = _pin_gizmo_mouse_plane_point(
                context,
                self.initial_point,
                self.initial_mouse,
            )
            if plane_point is not None:
                self.axis_offset = self.initial_point - plane_point
        objects, _active = _targets(context, armature)
        self.excluded = set(objects)
        self.excluded.add(armature)
        self.collision_planes = _smart_dragger_collision_planes(
            context,
            self.initial_points,
            dragger["normals"],
            self.excluded,
            max(
                1.0,
                float(pose_bone.length) * 20.0,
                (self.initial_points[0] - self.initial_points[1]).length
                * 10.0,
            ),
        )
        self.collision_support_points = (
            _smart_dragger_welded_support_points(
                context,
                dragger["packed"],
            )
        )
        collision_enabled = bool(
            getattr(context.window_manager, "smart_dragger_collision", True)
        )
        self.red_contact_active = bool(
            collision_enabled
            and self.collision_planes
            and _smart_dragger_plane_touching(
                self.initial_points[0],
                self.collision_planes[0],
            )
        )
        self.pivot_world = self.initial_points[
            0 if side == 1 or self.red_contact_active else 1
        ].copy()
        self.pivot_2d = _smart_dragger_project_2d(context, self.pivot_world)
        if int(self.dragger_side) in (0, 1):
            _pin_deselect_pose_bones(context)
        self.moved = False
        _state["smart_dragger_transform_active"] = True
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def _translation_delta(self, context, event):
        mouse = (event.mouse_region_x, event.mouse_region_y)
        if self.plane_axis_index >= 0:
            normal = self.orientation.col[self.plane_axis_index].normalized()
            start = _pin_gizmo_oriented_plane_point(
                context,
                self.initial_point,
                normal,
                self.initial_mouse,
            )
            point = _pin_gizmo_oriented_plane_point(
                context,
                self.initial_point,
                normal,
                mouse,
            )
            if start is None or point is None:
                return None
            return point - start
        if self.axis_index >= 0:
            axis = self.orientation.col[self.axis_index]
            point = _pin_gizmo_axis_mouse_point(
                context,
                self.initial_point,
                axis,
                mouse,
            )
        else:
            point = _pin_gizmo_mouse_plane_point(
                context,
                self.initial_point,
                mouse,
            )
        return (
            (point + self.axis_offset - self.initial_point)
            if point is not None
            else None
        )

    def _rotation_angle(self, event):
        if self.pivot_2d is None:
            return 0.0
        before = self.initial_mouse - Vector(self.pivot_2d)
        after = Vector((
            float(event.mouse_region_x),
            float(event.mouse_region_y),
        )) - Vector(self.pivot_2d)
        if before.length_squared <= 1.0e-8 or after.length_squared <= 1.0e-8:
            return 0.0
        before.normalize()
        after.normalize()
        return math.atan2(
            (before.x * after.y) - (before.y * after.x),
            before.dot(after),
        )

    def _apply_event(self, context, event):
        collision_enabled = bool(
            getattr(
                context.window_manager,
                "smart_dragger_collision",
                True,
            )
        )
        red_plane = (
            self.collision_planes[0]
            if collision_enabled and self.collision_planes
            else None
        )
        if self.transform_mode == "ROTATE":
            angle = self._rotation_angle(event)
            axis = (
                self.orientation.col[self.axis_index].normalized()
                if self.axis_index >= 0
                else _pin_keyboard_view_axis(context)
            )
            world_delta = (
                Matrix.Translation(self.pivot_world)
                @ Matrix.Rotation(angle, 4, axis)
                @ Matrix.Translation(-self.pivot_world)
            )
            if collision_enabled:
                world_delta = _smart_dragger_green_rod_delta(
                    self.initial_points,
                    world_delta @ self.initial_points[1],
                    red_plane,
                )
        else:
            delta = self._translation_delta(context, event)
            if delta is None:
                return False
            desired_point = self.initial_point + delta
            if self.side == 0:
                if collision_enabled and self.red_contact_active:
                    desired_point = _smart_dragger_red_contact_point(
                        context,
                        self.initial_point,
                        desired_point,
                        red_plane,
                        self.excluded,
                    )
                world_delta = (
                    _smart_dragger_grounded_red_delta(
                        self.initial_points, desired_point)
                    if collision_enabled and self.red_contact_active
                    else _smart_dragger_free_rod_delta(
                        self.initial_points,
                        0,
                        desired_point,
                    )
                )
            else:
                world_delta = _smart_dragger_green_rod_delta(
                    self.initial_points,
                    desired_point,
                    red_plane,
                )
        if collision_enabled:
            active_planes = _smart_dragger_active_collision_planes(
                self.red_contact_active,
                red_plane,
                self.collision_planes,
            )
            world_delta = _smart_dragger_collision_clamped_delta(
                self.initial_points,
                world_delta,
                active_planes,
                self.collision_support_points,
            )
        data = {
            "armature": bpy.data.objects.get(self.armature_name),
            "pose_bone": None,
            "initial_world": self.initial_world,
        }
        armature = data["armature"]
        if armature is None:
            return False
        data["pose_bone"] = armature.pose.bones.get(self.bone_name)
        if data["pose_bone"] is None:
            return False
        changed = _smart_dragger_apply_world_delta(
            context,
            data,
            world_delta,
        )
        self.moved = bool(changed) or self.moved
        _tag_redraw_all_view3d()
        return bool(changed)

    def _finish(self, context, cancel):
        armature = bpy.data.objects.get(str(getattr(self, "armature_name", "")))
        pose_bone = (
            armature.pose.bones.get(str(getattr(self, "bone_name", "")))
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        try:
            if cancel and pose_bone is not None:
                pose_bone.matrix_basis = self.initial_basis.copy()
                context.view_layer.update()
            elif self.moved and pose_bone is not None:
                _insert_bone_keys(
                    pose_bone,
                    int(context.scene.frame_current),
                )
        finally:
            _state["smart_dragger_transform_active"] = False
            _state["smart_dragger_cache"] = {}
            _tag_redraw_all_view3d()

    def modal(self, context, event):
        if event.type in {"ESC", "RIGHTMOUSE"} and event.value == "PRESS":
            self._finish(context, True)
            return {"CANCELLED"}
        release_confirm = bool(self.finish_on_release) and (
            event.type == "LEFTMOUSE" and event.value == "RELEASE"
        )
        keyboard_confirm = not bool(self.finish_on_release) and (
            event.type in {"LEFTMOUSE", "RET", "NUMPAD_ENTER"}
            and event.value == "PRESS"
        )
        if release_confirm or keyboard_confirm:
            if release_confirm:
                _pin_gizmo_claim_pointer(event)
            self._finish(context, False)
            return {"FINISHED"}
        if event.value == "PRESS" and event.type in {"X", "Y", "Z"}:
            axis_index = {"X": 0, "Y": 1, "Z": 2}[event.type]
            if event.shift and self.transform_mode == "TRANSLATE":
                self.plane_axis_index = (
                    -1
                    if self.plane_axis_index == axis_index
                    else axis_index
                )
                self.axis_index = -1
            else:
                self.axis_index = (
                    -1 if self.axis_index == axis_index else axis_index
                )
                self.plane_axis_index = -1
            self._apply_event(context, event)
            return {"RUNNING_MODAL"}
        if event.type == "MOUSEMOVE":
            self._apply_event(context, event)
        return {"RUNNING_MODAL"}

class ANIMATOR_UTILS_GT_smart_dragger(bpy.types.Gizmo):
    bl_idname = "ANIMATOR_UTILS_GT_smart_dragger"

    __slots__ = (
        "diamond_shape",
        "ring_shape",
        "side",
        "contact_active",
    )

    def setup(self):
        if not hasattr(self, "diamond_shape"):
            self.diamond_shape = self.new_custom_shape(
                "TRIS",
                _PIN_GIZMO_DIAMOND_VERTICES,
            )
            self.ring_shape = self.new_custom_shape(
                "TRIS",
                SMART_DRAGGER_RING_VERTICES,
            )

    def draw(self, _context):
        if self.side == 0 and bool(getattr(self, "contact_active", False)):
            self.draw_custom_shape(self.ring_shape)
        self.draw_custom_shape(self.diamond_shape)

    def draw_select(self, _context, select_id):
        self.draw_custom_shape(self.diamond_shape, select_id=select_id)
class ANIMATOR_UTILS_GGT_smart_draggers(bpy.types.GizmoGroup):
    bl_idname = "ANIMATOR_UTILS_GGT_smart_draggers"
    bl_label = "Smart Draggers"
    bl_space_type = "VIEW_3D"
    bl_region_type = "WINDOW"
    bl_options = {"3D", "SELECT", "PERSISTENT"}

    @classmethod
    def poll(cls, context):
        return getattr(context, "mode", "") == "POSE"

    def setup(self, context):
        self.draggers = []
        for side, color in enumerate((SMART_DRAGGER_RED, SMART_DRAGGER_GREEN)):
            gizmo = self.gizmos.new(ANIMATOR_UTILS_GT_smart_dragger.bl_idname)
            gizmo.side = side
            gizmo.color = color
            gizmo.color_highlight = tuple(
                min(1.0, value + 0.25) for value in color
            )
            gizmo.alpha = 0.82
            gizmo.alpha_highlight = 1.0
            gizmo.scale_basis = PIN_GIZMO_DIAMOND_SCALE
            gizmo.line_width = 2.5
            gizmo.select_bias = PIN_GIZMO_CENTER_SELECT_BIAS
            gizmo.use_draw_modal = True
            gizmo.use_event_handle_all = False
            operator = gizmo.target_set_operator(
                "staticaliza.smart_dragger_transform"
            )
            operator.transform_mode = "TRANSLATE"
            operator.initial_axis = -1
            operator.dragger_side = side
            operator.finish_on_release = True
            self.draggers.append(gizmo)

    def draw_prepare(self, context):
        if not getattr(
            getattr(context, "window_manager", None),
            "smart_draggers_enabled",
            False,
        ):
            # A native G/R/S press can arrive before this persistent gizmo
            # group receives its normal disabled draw pass. Hide first so a
            # stale/default red or green diamond cannot flash at the moving
            # bone endpoint for the duration of Blender's modal interaction.
            for gizmo in self.draggers:
                _pin_gizmo_set_if_changed(gizmo, "hide", True)
                _pin_gizmo_set_if_changed(gizmo, "hide_select", True)
                _pin_gizmo_set_if_changed(gizmo, "select", False)
            return
        if not _state.get("smart_dragger_transform_active", False):
            transform_operator = _pin_active_transform_operator(context)
            if transform_operator:
                # Keep drawing state and hit-test flags untouched while
                # Blender owns the native modal interaction, but refresh the
                # evaluated matrices on every draw so the diamonds follow
                # their moving welded owner instead of jumping on confirm.
                _smart_dragger_refresh_live_gizmos(context, self.draggers)
                return
            if _pin_primary_mouse_pressed() or _window_manager_has_modal_operator(context):
                return
        data = _smart_dragger_data(context)
        if data is None:
            for gizmo in self.draggers:
                gizmo.hide = gizmo.hide_select = True
                gizmo.select = False
            return
        selected_side = int(_state.get("smart_dragger_selected_side", -1))
        transform_active = bool(_state.get("smart_dragger_transform_active", False))
        red_contact_visible = _smart_dragger_red_contact_visible(context, data)
        for side, gizmo in enumerate(self.draggers):
            matrix = data["matrices"][side]
            _pin_gizmo_set_if_changed(gizmo, "matrix_basis", matrix)
            _pin_gizmo_set_if_changed(
                gizmo,
                "alpha",
                1.0 if side == selected_side else 0.36,
            )
            _pin_gizmo_set_if_changed(gizmo, "hide", False)
            _pin_gizmo_set_if_changed(
                gizmo,
                "hide_select",
                transform_active and side != selected_side,
            )
            _pin_gizmo_set_if_changed(
                gizmo,
                "select",
                False,
            )
            _pin_gizmo_set_if_changed(
                gizmo,
                "scale_basis",
                PIN_GIZMO_DIAMOND_SCALE,
            )
            gizmo.contact_active = bool(side == 0 and red_contact_visible)
