"""Yellow onion-pin gizmos."""

from ..core.runtime import *  # noqa: F403

class ANIMATOR_UTILS_GT_yellow_pin_target(bpy.types.Gizmo):
    bl_idname = "ANIMATOR_UTILS_GT_yellow_pin_target"

    __slots__ = (
        "diamond_shape",
        "target_key",
        "armature_name",
        "bone_name",
        "axis_index",
        "axis_world",
        "axis_locked",
        "locked_axes",
        "orientation_basis",
        "axis_offset",
        "initial_packed",
        "initial_point",
        "initial_mouse",
        "extend_selection",
        "axes_were_visible",
        "drag_started",
        "interaction_valid",
        "moved",
    )

    def setup(self):
        if not hasattr(self, "diamond_shape"):
            self.diamond_shape = self.new_custom_shape(
                "TRIS",
                _PIN_GIZMO_DIAMOND_VERTICES,
            )

    def draw(self, context):
        if getattr(self, "axis_index", -1) >= 0:
            return
        self.draw_custom_shape(self.diamond_shape)

    def draw_select(self, _context, select_id):
        if getattr(self, "axis_index", -1) < 0:
            self.draw_custom_shape(self.diamond_shape, select_id=select_id)

    def invoke(self, context, event):
        self.interaction_valid = False
        _pin_gizmo_configure_undo(self, False)
        if bool(getattr(self, "axis_locked", False)):
            return {"CANCELLED"}
        group = _pin_gizmo_group(self)
        target_key = str(getattr(self, "target_key", ""))
        was_selected = target_key in _pin_selected_target_keys()
        target_data = _pin_available_target_data(context).get(target_key)
        if target_data is None or target_data[0] != "YELLOW":
            return {"CANCELLED"}
        _kind, armature, pose_bone, packed = target_data
        if (
            armature is None
            or pose_bone is None
            or pose_bone.name != str(getattr(self, "bone_name", ""))
            or (
                getattr(self, "axis_index", -1) >= 0
                and (
                    (
                        group is not None
                        and str(getattr(group, "active_target_key", ""))
                        != target_key
                    )
                    or target_key != _pin_selected_target_key()
                )
            )
        ):
            return {"CANCELLED"}
        _pin_gizmo_begin_interaction(self, event, context)
        axis_index = int(getattr(self, "axis_index", -1))
        shift_pressed = bool(getattr(event, "shift", False))
        if axis_index < 0 and shift_pressed:
            # Shift-click adds the pin to the existing bone selection. It is
            # selection-only; movement starts only from an unmodified drag.
            _pin_gizmo_finish_interaction(self, False)
            _tag_redraw_all_view3d()
            return {"FINISHED"}
        _state["pin_target_dragging"] = True
        try:
            result = bpy.ops.staticaliza.transform_selected_pin(
                "INVOKE_DEFAULT",
                transform_mode = "TRANSLATE",
                initial_axis = axis_index,
                finish_on_release = True,
                exclusive_pin_selection = bool(
                    not shift_pressed and (axis_index < 0 or not was_selected)
                ),
            )
        except (AttributeError, RuntimeError, TypeError, ValueError):
            result = {"CANCELLED"}
        if "RUNNING_MODAL" in result:
            return {"FINISHED"}
        _state["pin_target_dragging"] = True
        self.armature_name = armature.name
        self.initial_packed = tuple(
            value.copy() if hasattr(value, "copy") else value
            for value in packed
        )
        self.initial_point = Vector(packed[0]).copy()
        pin_matrix = (armature.matrix_world @ pose_bone.matrix).normalized()
        pin_matrix.translation = self.initial_point
        self.orientation_basis = _pin_transform_orientation_matrix(
            context,
            target_data,
            pin_matrix,
        )
        _yellow_store_target_property(
            armature,
            pose_bone.name,
            self.initial_point,
        )
        self.axis_offset = Vector((0.0, 0.0, 0.0))
        if getattr(self, "axis_index", -1) >= 0:
            axis_point = _pin_gizmo_axis_mouse_point(
                context,
                self.initial_point,
                self.axis_world,
                (event.mouse_region_x, event.mouse_region_y),
            )
            if axis_point is not None:
                self.axis_offset = self.initial_point - axis_point
        else:
            plane_point = _pin_gizmo_mouse_plane_point(
                context,
                self.initial_point,
                (event.mouse_region_x, event.mouse_region_y),
            )
            if plane_point is not None:
                self.axis_offset = self.initial_point - plane_point
        self.moved = False
        self.interaction_valid = True
        return {"RUNNING_MODAL"}

    def modal(self, context, event, tweak):
        if not bool(getattr(self, "interaction_valid", False)):
            return {"CANCELLED"}
        armature = bpy.data.objects.get(str(getattr(self, "armature_name", "")))
        packed = _state.get("yellow_fixed", {}).get(
            _owner_bone_key(armature, getattr(self, "bone_name", ""))
        )
        if not packed:
            return {"CANCELLED"}
        if not _pin_gizmo_drag_ready(self, event):
            return {"RUNNING_MODAL"}
        current = Vector(packed[0])
        if getattr(self, "axis_index", -1) >= 0:
            axis_point = _pin_gizmo_axis_mouse_point(
                context,
                self.initial_point,
                self.axis_world,
                (event.mouse_region_x, event.mouse_region_y),
            )
            candidate = axis_point + self.axis_offset if axis_point is not None else None
        else:
            candidate = _pin_gizmo_mouse_surface_point(
                context,
                (event.mouse_region_x, event.mouse_region_y),
            )
            if candidate is None:
                plane_point = _pin_gizmo_mouse_plane_point(
                    context,
                    self.initial_point,
                    (event.mouse_region_x, event.mouse_region_y),
                )
                candidate = (
                    plane_point + self.axis_offset
                    if plane_point is not None
                    else None
                )
        if candidate is not None:
            candidate = _pin_gizmo_apply_axis_locks(
                candidate,
                self.initial_point,
                getattr(self, "locked_axes", (False, False, False)),
                getattr(self, "orientation_basis", Matrix.Identity(3)),
            )
        if candidate is not None and (Vector(candidate) - current).length > 1.0e-6:
            self.moved = _yellow_set_pin_target(
                armature,
                self.bone_name,
                candidate,
            ) or self.moved
            _tag_redraw_all_view3d()
        return {"RUNNING_MODAL"}

    def exit(self, context, cancel):
        if not bool(getattr(self, "interaction_valid", False)):
            _tag_redraw_all_view3d()
            return
        _pin_gizmo_finish_interaction(self, cancel)
        target_data = _pin_available_target_data(context).get(
            str(getattr(self, "target_key", ""))
        )
        committed = False
        try:
            armature = bpy.data.objects.get(str(self.armature_name))
            key = _owner_bone_key(armature, self.bone_name)
            packed = _state.get("yellow_fixed", {}).get(key)
            final_location = (
                Vector(packed[0]) if packed else self.initial_point.copy()
            )
            move_operation = None
            restore_data = None
            if self.moved and not cancel:
                move_operation = {
                    "pin_kind": "YELLOW",
                    "armature_name": str(self.armature_name),
                    "target_name": str(self.bone_name),
                    "surface_name": "",
                    "surface_constrained": False,
                    "base_location": tuple(self.initial_point),
                    "displacement": tuple(
                        final_location - self.initial_point
                    ),
                }
                restore_data = {
                    "kind": "YELLOW",
                    "armature_name": str(self.armature_name),
                    "bone_name": str(self.bone_name),
                    "packed": self.initial_packed,
                    "point": self.initial_point.copy(),
                }
            if cancel:
                fixed = dict(_state.get("yellow_fixed", {}))
                fixed[key] = self.initial_packed
                _state["yellow_fixed"] = fixed
                committed = _yellow_store_target_property(
                    armature,
                    str(self.bone_name),
                    self.initial_point,
                )
                if not committed:
                    move_operation = None
            _pin_gizmo_defer_finish(
                self,
                target_data,
                move_operation = move_operation,
                restore_data = restore_data,
            )
        finally:
            _state["pin_target_dragging"] = False
            _tag_redraw_all_view3d()


class ANIMATOR_UTILS_GGT_yellow_pin_target(bpy.types.GizmoGroup):
    bl_idname = "ANIMATOR_UTILS_GGT_yellow_pin_target"
    bl_label = "Onion Pin Target"
    bl_space_type = "VIEW_3D"
    bl_region_type = "WINDOW"
    bl_options = {"3D", "SELECT", "PERSISTENT"}

    @classmethod
    def poll(cls, context):
        return getattr(context, "mode", "") == "POSE"

    def setup(self, context):
        self.target_gizmos = {}
        self.target_gizmo = None
        self.target_gizmo_pool = []
        self.axis_gizmos = []
        for axis_index, color in enumerate(
            _pin_gizmo_theme_axis_colors(context)
        ):
            axis_gizmo = self.gizmos.new("GIZMO_GT_arrow_3d")
            axis_gizmo.draw_style = "NORMAL"
            axis_gizmo.color = color
            axis_gizmo.alpha = 0.55
            axis_gizmo.color_highlight = color
            axis_gizmo.alpha_highlight = 0.75
            axis_gizmo.use_draw_modal = True
            axis_gizmo.use_event_handle_all = True
            axis_gizmo.hide = True
            axis_gizmo.hide_select = True
            axis_gizmo.select = False
            axis_gizmo.scale_basis = PIN_GIZMO_AXIS_SCALE
            axis_gizmo.line_width = 2.5
            axis_gizmo.select_bias = 1.0
            axis_gizmo.target_set_handler(
                "offset",
                get = _pin_gizmo_axis_offset_get,
                set = _pin_gizmo_axis_offset_set,
            )
            operator = axis_gizmo.target_set_operator(
                "staticaliza.transform_selected_pin"
            )
            operator.transform_mode = "TRANSLATE"
            operator.initial_axis = axis_index
            operator.finish_on_release = True
            operator.exclusive_pin_selection = False
            self.axis_gizmos.append(axis_gizmo)
        # The diamond shares Blender's native gizmo layer and draws after the
        # arrows, masking their bases while every guide circle stays below.
        _pin_gizmo_ensure_target_pool(
            self,
            PIN_GIZMO_TARGET_POOL_SIZE,
            ANIMATOR_UTILS_GT_yellow_pin_target.bl_idname,
            ONION_PIN_COLOR[:3],
            (1.0, 1.0, 0.45),
        )
        self.active_target_key = ""
        self.axes_visible = False
        self.active_axis_index = -1
        self.center_dragging = False

    def draw_prepare(self, context):
        if (
            _pin_primary_mouse_pressed()
            and not _state.get("pin_target_dragging", False)
            and not _state.get("pin_keyboard_transform_active", False)
        ):
            return
        if _animation_playback_active(context):
            for gizmo in (*self.target_gizmo_pool, *self.axis_gizmos):
                _pin_gizmo_set_if_changed(gizmo, "hide", True)
                _pin_gizmo_set_if_changed(gizmo, "hide_select", True)
                _pin_gizmo_set_if_changed(gizmo, "select", False)
            return
        if (
            _window_manager_has_modal_operator(context)
            and not _state.get("pin_target_dragging", False)
            and not _state.get("pin_keyboard_transform_active", False)
        ):
            # Keep the pin map stable while a native Blender gizmo owns the
            # interaction. Its last prepared matrices remain drawable.
            return
        targets = {
            key: data
            for key, data in _pin_available_target_data(context).items()
            if data[0] == "YELLOW"
        }
        selected_key = _pin_selected_target_key()
        selected_keys = _pin_selected_target_keys()
        modal_active = bool(
            _state.get("pin_target_dragging", False)
            and selected_key
            and str(getattr(self, "active_target_key", "")) == selected_key
        )
        if not modal_active:
            self.active_axis_index = -1
            self.center_dragging = False
        if modal_active and selected_key not in targets:
            # Let the gizmo's next modal callback cancel cleanly. Rebinding or
            # hiding it here would invalidate Blender's active C gizmo pointer.
            return
        history_selection_locked = bool(
            _state.get("pin_history_active", False)
            and selected_key.startswith("YELLOW:")
            and selected_key in self.target_gizmos
        )
        if history_selection_locked:
            # Undo/redo may redraw before the history visibility timer clears.
            # Lock interaction, but continue below so the pin and every handle
            # receive the restored target matrix in this same redraw.
            for gizmo in self.target_gizmos.values():
                _pin_gizmo_set_if_changed(gizmo, "hide_select", True)
            for axis_gizmo in self.axis_gizmos:
                _pin_gizmo_set_if_changed(axis_gizmo, "hide_select", True)
        _pin_gizmo_ensure_target_pool(
            self,
            len(targets),
            ANIMATOR_UTILS_GT_yellow_pin_target.bl_idname,
            ONION_PIN_COLOR[:3],
            (1.0, 1.0, 0.45),
        )
        _pin_gizmo_stable_target_mapping(self, targets)
        modal_center = (
            self.target_gizmos.get(selected_key)
            if modal_active and int(self.active_axis_index) < 0
            else None
        )
        live_gizmo_ids = {
            id(gizmo) for gizmo in self.target_gizmos.values()
        }
        for pooled_gizmo in self.target_gizmo_pool:
            if id(pooled_gizmo) in live_gizmo_ids:
                continue
            _pin_gizmo_set_if_changed(pooled_gizmo, "hide", True)
            _pin_gizmo_set_if_changed(pooled_gizmo, "hide_select", True)
            if pooled_gizmo != modal_center:
                _pin_gizmo_set_if_changed(pooled_gizmo, "select", False)
        for target_key in sorted(targets):
            gizmo = self.target_gizmos.get(target_key)
            if gizmo is None:
                continue
            target_data = targets[target_key]
            _kind, armature, pose_bone, packed = target_data
            center_in_front = _pin_gizmo_center_in_front(context, packed[0])
            gizmo.target_key = target_key
            gizmo.armature_name = armature.name
            gizmo.bone_name = pose_bone.name
            gizmo.locked_axes = _pin_target_locked_axes(target_data)
            if gizmo != modal_center:
                _pin_gizmo_set_if_changed(
                    gizmo,
                    "hide",
                    not center_in_front,
                )
                _pin_gizmo_set_if_changed(
                    gizmo,
                    "hide_select",
                    history_selection_locked or not center_in_front,
                )
                # Runtime state owns logical selection. A stale C-side
                # selection remains in Blender's fallback gizmo event path,
                # including after this target becomes hidden behind geometry.
                _pin_gizmo_set_if_changed(gizmo, "select", False)
            _pin_gizmo_set_if_changed(
                gizmo,
                "alpha",
                1.0 if target_key in selected_keys else 0.36,
            )
            _pin_gizmo_set_if_changed(
                gizmo,
                "matrix_basis",
                _pin_gizmo_center_matrix(Vector(packed[0])),
            )
            _pin_gizmo_set_if_changed(
                gizmo,
                "scale_basis",
                PIN_GIZMO_DIAMOND_SCALE,
            )
        target_data = targets.get(selected_key)
        next_active_target_key = selected_key if target_data else ""
        if self.active_target_key != next_active_target_key:
            previous_gizmo = self.target_gizmos.get(self.active_target_key)
            if previous_gizmo is not None and previous_gizmo != modal_center:
                _pin_gizmo_set_if_changed(previous_gizmo, "select", False)
            self.active_target_key = next_active_target_key
            self.active_axis_index = -1
            self.center_dragging = False
            for axis_gizmo in self.axis_gizmos:
                _pin_gizmo_set_if_changed(axis_gizmo, "select", False)
        self.target_gizmo = self.target_gizmos.get(selected_key)
        self.axes_visible = bool(target_data)
        armature = target_data[1] if target_data else None
        pose_bone = target_data[2] if target_data else None
        packed = target_data[3] if target_data else None
        point = (
            Vector(packed[0])
            if packed
            else Vector((0.0, 0.0, 0.0))
        )
        handle_point = (
            _pin_transform_group_handle_point(context, target_data)
            if target_data
            else point
        )
        handle_scale = (
            PIN_GIZMO_AXIS_SCALE * 1.5
            if _pin_transform_group_has_selected_bones(context)
            else PIN_GIZMO_AXIS_SCALE
        )
        show_axes = False
        locked_axes = _pin_target_locked_axes(target_data)
        orientation_basis = _pin_transform_orientation_matrix(
            context,
            target_data,
        )
        for axis_index, axis_gizmo in enumerate(self.axis_gizmos):
            modal_axis = bool(
                modal_active and int(self.active_axis_index) == axis_index
            )
            axis = orientation_basis.col[axis_index].copy()
            if axis.length_squared <= 1.0e-12:
                axis = Vector((0.0, 0.0, 1.0))
            axis.normalize()
            show_axis = bool(
                show_axes
                and _pin_gizmo_axis_in_front(context, handle_point, axis)
            )
            if not modal_axis:
                _pin_gizmo_set_if_changed(
                    axis_gizmo,
                    "hide",
                    not show_axis,
                )
                _pin_gizmo_set_if_changed(axis_gizmo, "select", False)
            if not modal_axis:
                _pin_gizmo_set_if_changed(
                    axis_gizmo,
                    "hide_select",
                    bool(
                        history_selection_locked
                        or not show_axis
                        or locked_axes[axis_index]
                    ),
                )
            _pin_gizmo_set_if_changed(
                axis_gizmo,
                "alpha",
                PIN_GIZMO_LOCKED_ALPHA if locked_axes[axis_index] else 0.55,
            )
            _pin_gizmo_set_if_changed(
                axis_gizmo,
                "alpha_highlight",
                PIN_GIZMO_LOCKED_ALPHA if locked_axes[axis_index] else 0.75,
            )
            _pin_gizmo_set_if_changed(
                axis_gizmo,
                "matrix_basis",
                _pin_gizmo_axis_matrix(handle_point, axis),
            )
            _pin_gizmo_set_if_changed(
                axis_gizmo,
                "scale_basis",
                handle_scale,
            )
