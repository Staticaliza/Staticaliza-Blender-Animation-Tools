"""Deferred pin gizmo commits and hit testing."""

from ..core.runtime import *  # noqa: F403

def _pin_gizmo_restore_for_commit(context, restore_data):
    if not restore_data:
        return False
    kind = str(restore_data.get("kind", ""))
    if kind == "CONTACT":
        guide = bpy.data.objects.get(str(restore_data.get("target_name", "")))
        if guide is None:
            return False
        surface = bpy.data.objects.get(str(restore_data.get("surface_name", "")))
        if surface is not None:
            _surface_contact_bind_guide_surface(
                context,
                guide,
                surface,
                restore_data["matrix"].translation,
            )
        guide.matrix_world = restore_data["matrix"].copy()
        for property_name, value, existed in (
            (
                SURFACE_CONTACT_POINT_PROPERTY,
                restore_data.get("point", ()),
                restore_data.get("point_exists", False),
            ),
            (
                SURFACE_CONTACT_NORMAL_PROPERTY,
                restore_data.get("normal", ()),
                restore_data.get("normal_exists", False),
            ),
            (
                SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY,
                restore_data.get("local_matrix", ()),
                restore_data.get("local_matrix_exists", False),
            ),
        ):
            if existed:
                guide[property_name] = value
            elif property_name in guide:
                del guide[property_name]
        solver = _surface_contact_solver_from_guide(guide)
        solver_matrix = restore_data.get("solver_matrix")
        if solver is not None and solver_matrix is not None:
            solver.matrix_world = solver_matrix.copy()
        _surface_contact_restore_simulated_pose(
            context,
            guide,
            restore_data.get("simulated_pose_matrix"),
            update_view_layer = False,
        )
        context.view_layer.update()
        return True
    if kind == "YELLOW":
        armature = bpy.data.objects.get(str(restore_data.get("armature_name", "")))
        bone_name = str(restore_data.get("bone_name", ""))
        packed = restore_data.get("packed")
        if armature is None or packed is None:
            return False
        fixed = dict(_state.get("yellow_fixed", {}))
        fixed[_owner_bone_key(armature, bone_name)] = packed
        _state["yellow_fixed"] = fixed
        _yellow_store_target_property(
            armature,
            bone_name,
            restore_data.get("point", packed[0]),
        )
        context.view_layer.update()
        return True
    return False


def _pin_gizmo_run_deferred_finishes():
    """Finish pin clicks after Blender releases its native tweak handler."""
    context = bpy.context
    if (
        _pin_primary_mouse_pressed()
        or _window_manager_has_modal_operator(context)
    ):
        # A second native gizmo interaction may start during this one-shot
        # timer's delay. Keep the queued operation intact and avoid selection,
        # dependency-graph, or redraw work until Blender releases that press.
        return 0.05
    pending = list(_state.get("pin_gizmo_deferred_finishes", ()))
    _state["pin_gizmo_deferred_finishes"] = []
    for item in pending:
        move_operation = item.get("move_operation")
        if move_operation:
            try:
                window = item.get("window")
                area = item.get("area")
                region = item.get("region")
                space = item.get("space")
                if (
                    window is not None
                    and area is not None
                    and region is not None
                    and space is not None
                ):
                    with context.temp_override(
                        window = window,
                        screen = window.screen,
                        area = area,
                        region = region,
                        space_data = space,
                    ):
                        _pin_gizmo_restore_for_commit(
                            context,
                            item.get("restore_data"),
                        )
                        bpy.ops.staticaliza.move_pin_target(
                            "EXEC_DEFAULT",
                            **move_operation,
                        )
                else:
                    _pin_gizmo_restore_for_commit(
                        context,
                        item.get("restore_data"),
                    )
                    bpy.ops.staticaliza.move_pin_target(
                        "EXEC_DEFAULT",
                        **move_operation,
                    )
            except (AttributeError, RuntimeError, TypeError, ValueError) as exc:
                print(
                    "[Roblox Animator Utils] Pin move commit failed: "
                    f"{exc}"
                )

        target_key = str(item.get("target_key", ""))
        if (
            bool(item.get("extend_selection", False))
            or not target_key
            or target_key != _pin_selected_target_key()
            or context is None
            or getattr(context, "mode", "") != "POSE"
        ):
            continue
        armature = _armature_from_session_uid(
            int(item.get("armature_uid", 0))
        )
        if armature is None:
            armature = bpy.data.objects.get(str(item.get("armature_name", "")))
        pose_bone = (
            armature.pose.bones.get(str(item.get("bone_name", "")))
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is None or armature not in _pose_scope_armatures(context):
            continue
        _pin_deselect_pose_bones(context)
        # This selection change belongs to the pin click itself, so it must
        # become the new baseline instead of looking like a later click-away.
        _state["pin_gizmo_selection_keys"] = _pin_pose_selection_signature(
            context
        )
    _tag_redraw_all_view3d()
    return None


def _pin_gizmo_defer_finish(
    gizmo,
    target_data,
    undo_message = "",
    move_operation = None,
    restore_data = None,
):
    """Queue work that must not run from Gizmo.exit's C modal stack."""
    armature = target_data[1] if target_data else None
    pose_bone = target_data[2] if target_data else None
    _state.setdefault("pin_gizmo_deferred_finishes", []).append({
        "target_key": str(getattr(gizmo, "target_key", "")),
        "armature_uid": _armature_session_uid(armature),
        "armature_name": armature.name if armature is not None else "",
        "bone_name": pose_bone.name if pose_bone is not None else "",
        "extend_selection": bool(
            getattr(gizmo, "extend_selection", False)
        ),
        "undo_message": str(undo_message),
        "move_operation": dict(move_operation) if move_operation else None,
        "restore_data": dict(restore_data) if restore_data else None,
        "window": getattr(bpy.context, "window", None),
        "area": getattr(bpy.context, "area", None),
        "region": getattr(bpy.context, "region", None),
        "space": getattr(bpy.context, "space_data", None),
    })
    try:
        if not bpy.app.timers.is_registered(_pin_gizmo_run_deferred_finishes):
            register_owned_timer(
                _pin_gizmo_run_deferred_finishes,
                # Let Blender finish and unregister gizmo_tweak first. The
                # Move operator must be the final registered operation so its
                # HUD and undo step are retained.
                first_interval = 0.05,
            )
    except (AttributeError, ReferenceError, RuntimeError, ValueError) as exc:
        # Never let timer setup unwind through Blender's native
        # gizmo_tweak_modal stack. Stale finalizers are more dangerous than a
        # skipped selection/legacy-undo finish because they could affect a
        # later, unrelated pin interaction.
        discarded = len(_state.get("pin_gizmo_deferred_finishes", ()))
        _state["pin_gizmo_deferred_finishes"] = []
        print(
            "[Roblox Animator Utils] Pin post-modal finalization could not "
            f"be scheduled; discarded {discarded} pending action(s): {exc}"
        )
