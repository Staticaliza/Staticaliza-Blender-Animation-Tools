"""Mouse projection for virtual-pin transform operations."""

from ..core.runtime import *  # noqa: F403


_PIN_CONSTRAINT_COLORS = (
    (1.0, 0.18, 0.14, 0.9),
    (0.35, 0.9, 0.18, 0.9),
    (0.2, 0.48, 1.0, 0.9),
)


def _pin_transform_view_unit_pixels(region, region_data, pivot):
    """Return the largest screen projection of one view-plane world unit."""
    from bpy_extras import view3d_utils

    pivot = Vector(pivot)
    pivot_2d = view3d_utils.location_3d_to_region_2d(
        region, region_data, pivot
    )
    if pivot_2d is None:
        return 0.0
    view_basis = region_data.view_matrix.inverted_safe().to_3x3().normalized()
    unit_pixels = 0.0
    for tangent in (view_basis.col[0], view_basis.col[1]):
        projected = view3d_utils.location_3d_to_region_2d(
            region, region_data, pivot + Vector(tangent)
        )
        if projected is not None:
            unit_pixels = max(
                unit_pixels,
                (Vector(projected) - Vector(pivot_2d)).length,
            )
    return unit_pixels


def _pin_transform_begin_keyboard_presentation(operator, context):
    """Match Blender's native hotkey transform presentation."""
    operator._keyboard_gizmo_space = None
    operator._keyboard_gizmo_tool_visible = None
    operator._keyboard_cursor_modal = False
    if bool(operator.finish_on_release):
        window = getattr(context, "window", None)
        if window is not None:
            try:
                window.cursor_modal_set("SCROLL_XY")
                operator._keyboard_cursor_modal = True
            except (AttributeError, ReferenceError, RuntimeError, TypeError):
                pass
        return
    space = getattr(context, "space_data", None)
    if space is not None and hasattr(space, "show_gizmo_tool"):
        try:
            operator._keyboard_gizmo_space = space
            operator._keyboard_gizmo_tool_visible = bool(
                space.show_gizmo_tool
            )
            space.show_gizmo_tool = False
        except (AttributeError, ReferenceError, RuntimeError):
            operator._keyboard_gizmo_space = None
            operator._keyboard_gizmo_tool_visible = None
    window = getattr(context, "window", None)
    if window is not None:
        try:
            window.cursor_modal_set(
                "CROSSHAIR"
                if operator.transform_mode == "ROTATE"
                else "SCROLL_XY"
            )
            operator._keyboard_cursor_modal = True
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            operator._keyboard_cursor_modal = False


def _pin_transform_end_keyboard_presentation(operator, context):
    space = getattr(operator, "_keyboard_gizmo_space", None)
    visible = getattr(operator, "_keyboard_gizmo_tool_visible", None)
    if space is not None and visible is not None:
        try:
            space.show_gizmo_tool = bool(visible)
        except (AttributeError, ReferenceError, RuntimeError):
            pass
    operator._keyboard_gizmo_space = None
    operator._keyboard_gizmo_tool_visible = None
    if bool(getattr(operator, "_keyboard_cursor_modal", False)):
        window = getattr(context, "window", None)
        if window is not None:
            try:
                window.cursor_modal_restore()
            except (AttributeError, ReferenceError, RuntimeError):
                pass
    operator._keyboard_cursor_modal = False


def _pin_transform_move_origin(operator):
    """Anchor pin translation to its handle instead of a rotation pivot."""
    group_origin = getattr(operator, "group_handle_origin", None)
    if group_origin is not None:
        return Vector(group_origin)
    initial_matrix = getattr(operator, "initial_pin_matrix", None)
    if (
        not bool(getattr(operator, "bone_only_contact", False))
        and initial_matrix is not None
    ):
        return initial_matrix.translation.copy()
    return Vector(operator.pivot)


def _pin_transform_update_constraint_overlay(operator):
    axis_index = int(getattr(operator, "axis_index", -1))
    plane_axis = int(getattr(operator, "plane_axis_index", -1))
    if operator.transform_mode == "ROTATE":
        axis = (
            Vector(operator.orientation.col[axis_index]).normalized()
            if axis_index >= 0
            else Vector((0.0, 0.0, 1.0))
        )
        _state["pin_transform_constraint"] = {
            "mode": "ROTATE",
            "pivot": Vector(operator.pivot),
            "directions": (axis,),
            "colors": (
                _PIN_CONSTRAINT_COLORS[axis_index]
                if axis_index >= 0
                else (0.8, 0.8, 0.8, 0.8),
            ),
            "angle": 0.0,
            "start_direction": Vector((1.0, 0.0)),
        }
        return True
    if operator.transform_mode != "TRANSLATE" or (
        axis_index < 0 and plane_axis < 0
    ):
        _state["pin_transform_constraint"] = None
        return False
    indices = (
        (axis_index,)
        if axis_index >= 0
        else tuple(index for index in range(3) if index != plane_axis)
    )
    _state["pin_transform_constraint"] = {
        "mode": "TRANSLATE",
        "pivot": _pin_transform_move_origin(operator),
        "directions": tuple(
            Vector(operator.orientation.col[index]).normalized()
            for index in indices
        ),
        "colors": tuple(_PIN_CONSTRAINT_COLORS[index] for index in indices),
    }
    return True


def _draw_pin_transform_constraint(context):
    data = _state.get("pin_transform_constraint")
    region = getattr(context, "region", None)
    region_data = getattr(context, "region_data", None)
    if not data or region is None or region_data is None:
        return
    from bpy_extras import view3d_utils

    pivot_2d = view3d_utils.location_3d_to_region_2d(
        region,
        region_data,
        data["pivot"],
    )
    if pivot_2d is None:
        return
    extent = float(max(region.width, region.height) * 2)
    shader = _ensure_shader_2d()
    previous = _capture_gpu_draw_state()
    try:
        gpu.state.blend_set("ALPHA")
        gpu.state.line_width_set(1.5)
        for direction, color in zip(data["directions"], data["colors"]):
            projected = view3d_utils.location_3d_to_region_2d(
                region,
                region_data,
                data["pivot"] + direction,
            )
            if projected is None:
                projected = view3d_utils.location_3d_to_region_2d(
                    region,
                    region_data,
                    data["pivot"] - direction,
                )
            if projected is None:
                continue
            screen_direction = Vector(projected) - Vector(pivot_2d)
            if screen_direction.length_squared <= 1.0e-8:
                continue
            screen_direction.normalize()
            vertices = (
                Vector(pivot_2d) - (screen_direction * extent),
                Vector(pivot_2d) + (screen_direction * extent),
            )
            shader.bind()
            shader.uniform_float("color", color)
            batch_for_shader(
                shader,
                "LINES",
                {"pos": vertices},
            ).draw(shader)
        if data.get("mode") == "ROTATE":
            angle = float(data.get("angle", 0.0))
            axis = Vector(data.get("rotation_axis", (0.0, 0.0, 1.0)))
            start = Vector(data.get("start_world", (1.0, 0.0, 0.0)))
            radius_pixels = float(data.get("radius_pixels", 0.0))
            if (
                axis.length_squared <= 1.0e-8
                or start.length_squared <= 1.0e-8
                or radius_pixels <= 1.0e-8
            ):
                return
            axis.normalize()
            start.normalize()
            # The dial is screen-scaled by Blender. Re-evaluate the matching
            # world radius from the current view on every draw so viewport
            # panning/zooming cannot leave the 3D fill at a stale size.
            unit_pixels = _pin_transform_view_unit_pixels(
                region, region_data, data["pivot"]
            )
            radius = (
                radius_pixels / unit_pixels
                if unit_pixels > 1.0e-8
                else float(data.get("radius_world", 1.0))
            )
            tangent = axis.cross(start)
            if tangent.length_squared <= 1.0e-8:
                return
            tangent.normalize()
            start_2d = view3d_utils.location_3d_to_region_2d(
                region,
                region_data,
                Vector(data["pivot"]) + (start * radius),
            )
            tangent_2d = view3d_utils.location_3d_to_region_2d(
                region,
                region_data,
                Vector(data["pivot"]) + (tangent * radius),
            )
            if start_2d is None or tangent_2d is None:
                return
            start_basis = Vector(start_2d) - Vector(pivot_2d)
            tangent_basis = Vector(tangent_2d) - Vector(pivot_2d)
            steps = max(2, int(abs(angle) / math.tau * 64.0) + 2)
            arc = []
            for index in range(steps + 1):
                current = angle * (index / steps)
                arc.append(
                    Vector(pivot_2d)
                    + (start_basis * math.cos(current))
                    + (tangent_basis * math.sin(current))
                )
            if len(arc) < 2:
                return
            fill_vertices = []
            for index in range(len(arc) - 1):
                fill_vertices.extend((Vector(pivot_2d), arc[index], arc[index + 1]))
            color = tuple(data["colors"][0])
            shader.bind()
            shader.uniform_float("color", (*color[:3], 0.18))
            batch_for_shader(
                shader,
                "TRIS",
                {"pos": fill_vertices},
            ).draw(shader)
    finally:
        _restore_gpu_draw_state(previous)


def _pin_transform_mouse_matrix(operator, context, event):
    mouse = (float(event.mouse_region_x), float(event.mouse_region_y))
    if operator.transform_mode == "TRANSLATE":
        move_origin = _pin_transform_move_origin(operator)
        surface_constrained = False
        plane_axis = int(getattr(operator, "plane_axis_index", -1))
        if plane_axis >= 0:
            normal = operator.orientation.col[plane_axis].normalized()
            start = _pin_gizmo_oriented_plane_point(
                context,
                move_origin,
                normal,
                operator.initial_mouse,
            )
            current = _pin_gizmo_oriented_plane_point(
                context,
                move_origin,
                normal,
                mouse,
            )
            if start is not None and current is not None:
                delta = current - start
            else:
                start = _pin_gizmo_mouse_plane_point(
                    context,
                    move_origin,
                    operator.initial_mouse,
                )
                current = _pin_gizmo_mouse_plane_point(
                    context,
                    move_origin,
                    mouse,
                )
                delta = (
                    current - start
                    if start is not None and current is not None
                    else Vector((0.0, 0.0, 0.0))
                )
                delta -= normal * delta.dot(normal)
        elif operator.axis_index >= 0:
            axis = operator.orientation.col[operator.axis_index].normalized()
            start = _pin_gizmo_axis_mouse_point(
                context, move_origin, axis, operator.initial_mouse
            )
            current = _pin_gizmo_axis_mouse_point(
                context, move_origin, axis, mouse
            )
            delta = (
                axis * (current - start).dot(axis)
                if start is not None and current is not None
                else Vector((0.0, 0.0, 0.0))
            )
        else:
            guide = (
                bpy.data.objects.get(operator.contact_guide_name)
                if operator.target_kind == "CONTACT"
                else None
            )
            surface_hit = (
                _pin_gizmo_mouse_surface_hit(context, mouse, guide)
                if operator.finish_on_release
                else None
            )
            if surface_hit is not None:
                surface, point, normal, _distance = surface_hit
                operator.drag_surface_name = surface.name
                operator.drag_surface_normal = normal.copy()
                operator.drag_surface_point = point.copy()
                surface_constrained = True
                delta = point - operator.initial_pin_matrix.translation
            elif (
                operator.target_kind == "CONTACT"
                and getattr(operator, "drag_surface_point", None) is not None
            ):
                # Preserve the last acquired contact while crossing empty
                # screen space; center-gizmo drags never fall off a surface.
                surface_constrained = True
                delta = (
                    operator.drag_surface_point
                    - operator.initial_pin_matrix.translation
                )
            else:
                operator.drag_surface_name = ""
                operator.drag_surface_normal = None
                start = _pin_gizmo_mouse_plane_point(
                    context, move_origin, operator.initial_mouse
                )
                current = _pin_gizmo_mouse_plane_point(
                    context, move_origin, mouse
                )
                delta = (
                    current - start
                    if start is not None and current is not None
                    else Vector((0.0, 0.0, 0.0))
                )
        if event.shift and not surface_constrained and plane_axis < 0:
            delta *= 0.1
        if event.ctrl and not surface_constrained:
            for index in range(3):
                delta[index] = round(float(delta[index]) * 10.0) / 10.0
        return Matrix.Translation(delta)

    from bpy_extras import view3d_utils

    center = view3d_utils.location_3d_to_region_2d(
        context.region, context.region_data, operator.pivot
    )
    if center is None:
        return Matrix.Identity(4)
    start_vector = Vector(operator.initial_mouse) - center
    current_vector = Vector(mouse) - center
    if operator.transform_mode == "ROTATE":
        if operator.mouse_started_at_pivot:
            mouse_delta = Vector(mouse) - Vector(operator.initial_mouse)
            angle = (mouse_delta.x + mouse_delta.y) * 0.01
        elif (
            start_vector.length_squared <= 1.0e-8
            or current_vector.length_squared <= 1.0e-8
        ):
            angle = 0.0
        else:
            angle = math.atan2(
                (start_vector.x * current_vector.y)
                - (start_vector.y * current_vector.x),
                start_vector.dot(current_vector),
            )
        if event.shift:
            angle *= 0.1
        if event.ctrl:
            increment = math.radians(5.0)
            angle = round(angle / increment) * increment
        axis = (
            operator.orientation.col[operator.axis_index].normalized()
            if operator.axis_index >= 0
            else _pin_keyboard_view_axis(context)
        )
        start_world_point = _pin_gizmo_oriented_plane_point(
            context,
            Vector(operator.pivot),
            Vector(axis).normalized(),
            operator.initial_mouse,
        )
        start_world = (
            Vector(start_world_point) - Vector(operator.pivot)
            if start_world_point is not None
            else Vector(axis).orthogonal()
        )
        if start_world.length_squared <= 1.0e-8:
            start_world = Vector(axis).orthogonal()
        initial_radius_world = max(1.0e-4, start_world.length)
        start_world.normalize()
        start_screen = start_vector.copy()
        if start_screen.length_squared <= 1.0e-8:
            start_screen = Vector((1.0, 0.0))
        unit_pixels = _pin_transform_view_unit_pixels(
            context.region,
            context.region_data,
            operator.pivot,
        )
        radius_pixels = max(1.0, initial_radius_world * unit_pixels)
        start_screen.normalize()
        _state["pin_transform_constraint"] = {
            "mode": "ROTATE",
            "pivot": Vector(operator.pivot),
            "directions": (Vector(axis).normalized(),),
            "colors": (
                _PIN_CONSTRAINT_COLORS[operator.axis_index]
                if operator.axis_index >= 0
                else (0.8, 0.8, 0.8, 0.8),
            ),
            "angle": angle,
            "rotation_axis": Vector(axis).normalized(),
            "start_world": start_world,
            "radius_world": initial_radius_world,
            "start_screen": start_screen,
            "radius_pixels": radius_pixels,
        }
        return Matrix.Rotation(angle, 4, axis)

    if operator.mouse_started_at_pivot:
        mouse_delta = Vector(mouse) - Vector(operator.initial_mouse)
        factor = 1.0 + ((mouse_delta.x + mouse_delta.y) * 0.01)
    else:
        start_distance = max(1.0e-6, start_vector.length)
        factor = current_vector.length / start_distance
        if start_vector.dot(current_vector) < 0.0:
            factor = -factor
    if event.shift:
        factor = 1.0 + ((factor - 1.0) * 0.1)
    if event.ctrl:
        factor = round(factor * 10.0) / 10.0
    factors = [factor, factor, factor]
    if operator.axis_index >= 0:
        factors = [1.0, 1.0, 1.0]
        factors[operator.axis_index] = factor
    return (
        operator.orientation.to_4x4()
        @ Matrix.Diagonal((*factors, 1.0))
        @ operator.orientation.inverted_safe().to_4x4()
    )
