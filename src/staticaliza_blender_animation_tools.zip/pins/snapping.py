"""Pin transform observation and endpoint snapping."""

from ..core.runtime import *  # noqa: F403

def _pin_active_transform_operator(context):
    window = getattr(context, "window", None)
    if window is None:
        return ""
    try:
        for operator in window.modal_operators:
            identifier = str(getattr(operator, "bl_idname", ""))
            if (
                identifier.upper().startswith("TRANSFORM_OT_")
                or identifier.lower().startswith("transform.")
            ):
                return identifier
    except (AttributeError, ReferenceError, RuntimeError):
        pass
    return ""
def _pin_transform_operator_delta_signature(context, identifier):
    """Return a stable signature for the current native G/R/S input delta."""
    window = getattr(context, "window", None)
    if window is None:
        return None
    try:
        for operator in window.modal_operators:
            current_identifier = str(getattr(operator, "bl_idname", ""))
            if current_identifier != identifier:
                continue
            properties = getattr(operator, "properties", operator)
            value = getattr(properties, "value", None)
            if value is None:
                return None
            values = (
                tuple(float(component) for component in value)
                if hasattr(value, "__len__")
                else (float(value),)
            )
            return (
                identifier,
                tuple(round(component, 9) for component in values),
            )
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return None
    return None
def _pin_transform_operator_delta_state(context, identifier):
    """Return whether a native G/R/S operator has a non-default input delta."""
    signature = _pin_transform_operator_delta_signature(context, identifier)
    if signature is None:
        return None
    values = signature[1]
    if "resize" in identifier.lower():
        return any(abs(component - 1.0) > 1.0e-7 for component in values)
    return any(abs(component) > 1.0e-7 for component in values)


_PIN_CONTACT_TARGET_LOCK_PROPERTIES = (
    SURFACE_CONTACT_SURFACE_PROPERTY,
    SURFACE_CONTACT_POINT_PROPERTY,
    SURFACE_CONTACT_NORMAL_PROPERTY,
    SURFACE_CONTACT_FOLLOW_OBJECT_PROPERTY,
    SURFACE_CONTACT_FOLLOW_BONE_PROPERTY,
    SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY,
)


def _pin_selected_pose_drives_contact_target(guide, selected_by_name):
    """Return whether this native pose transform owns the surface target."""
    follow_object = bpy.data.objects.get(str(
        guide.get(SURFACE_CONTACT_FOLLOW_OBJECT_PROPERTY, "")
    ))
    follow_bone_name = str(
        guide.get(SURFACE_CONTACT_FOLLOW_BONE_PROPERTY, "")
    )
    if (
        follow_object is None
        or follow_object.type != "ARMATURE"
        or not follow_bone_name
        or getattr(follow_object, "pose", None) is None
    ):
        return False
    selected_names = selected_by_name.get(follow_object.name, set())
    follow_bone = follow_object.pose.bones.get(follow_bone_name)
    current = follow_bone
    while current is not None:
        if current.name in selected_names:
            return True
        current = current.parent
    return False


def _pin_capture_contact_target_locks(context):
    """Freeze pink surface targets for one native pose-bone transform."""
    existing = _state.setdefault("pin_snap_contact_target_locks", {})
    if existing or context is None or getattr(context, "mode", "") != "POSE":
        return bool(existing)
    grouped = _pin_snap_scope_bones(context)
    selected_by_name = {
        armature.name: {pose_bone.name for pose_bone in selected}
        for armature, selected in grouped.items()
    }
    for guide in _surface_contact_active_snap_guides(context.scene):
        if _pin_selected_pose_drives_contact_target(
            guide, selected_by_name
        ):
            # The contacted surface is part of this transform. Freezing and
            # restoring its guide leaves the pink target behind while the
            # animated/manual surface bone moves.
            continue
        selected_names = selected_by_name.get(
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
        )
        armature = bpy.data.objects.get(
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
        )
        if not selected_names or not (
            _surface_contact_direct_bone_names(guide) & selected_names
            or _surface_contact_selected_bones_drive_guide(
                armature,
                guide,
                selected_names,
            )
        ):
            continue
        properties = {}
        for property_name in _PIN_CONTACT_TARGET_LOCK_PROPERTIES:
            if property_name in guide:
                value = guide[property_name]
                if not isinstance(value, str):
                    try:
                        value = tuple(value)
                    except TypeError:
                        pass
                properties[property_name] = value
            else:
                properties[property_name] = None
        existing[guide.name] = {
            "matrix_world": guide.matrix_world.copy(),
            "properties": properties,
        }
    return bool(existing)


def _pin_restore_contact_target_locks():
    """Restore targets without evaluating or moving their linked pose bones."""
    changed = False
    for guide_name, target_lock in tuple(
        _state.get("pin_snap_contact_target_locks", {}).items()
    ):
        guide = bpy.data.objects.get(str(guide_name))
        if guide is None:
            continue
        matrix_world = target_lock["matrix_world"]
        if _pin_keyboard_matrices_differ(guide.matrix_world, matrix_world):
            guide.matrix_world = matrix_world.copy()
            changed = True
        for property_name, value in target_lock["properties"].items():
            if value is None:
                if property_name in guide:
                    del guide[property_name]
                    changed = True
            elif guide.get(property_name) != value:
                guide[property_name] = value
                changed = True
    return changed


def _pin_capture_transform_intent(context):
    """Snapshot native pose-transform intent before contact solving begins."""
    pose_snapshots = {}
    parent_attachment_states = {}
    _surface_contact_clear_transform_start_poses()
    if context is None or getattr(context, "mode", "") != "POSE":
        _state["pin_snap_transform_start_poses"] = pose_snapshots
        _state["pin_snap_parent_attachment_states"] = parent_attachment_states
        return False
    # Rebuild the confirmed attachment set after clearing the previous
    # transform session and before classifying ancestor-driven contacts.
    _surface_contact_begin_native_transform(context)

    grouped = _selected_pose_bones_by_owner(context)
    idle_poses = _pin_prepare_transform_pose_baseline(grouped)
    selected_by_name = {}
    for armature, selected in grouped.items():
        owner_uid = _armature_session_uid(armature)
        selected_names = {pose_bone.name for pose_bone in selected}
        selected_by_name[armature.name] = selected_names
        for pose_bone in selected:
            key = (owner_uid, pose_bone.name)
            pose_snapshots[key] = idle_poses.get(
                key, pose_bone.matrix_basis
            ).copy()

    for guide in _surface_contact_active_snap_guides(context.scene):
        armature = bpy.data.objects.get(
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
        )
        selected_names = selected_by_name.get(getattr(armature, "name", ""))
        direct, parent_driven = _surface_contact_capture_transform_scope(
            context, guide, armature, selected_names
        )
        target_driven = _pin_selected_pose_drives_contact_target(
            guide, selected_by_name
        )
        if target_driven and not direct and not parent_driven:
            _surface_contact_capture_transform_start_pose(guide)
        if not direct and not parent_driven and not target_driven:
            continue
        if direct:
            # Native G/R/S must expose the unconstrained raw endpoint before
            # release distance is measured. Keeping the constraint evaluated
            # here made horizontal/wall contacts appear motionless and forced
            # users to reproduce the ground-oriented mouse direction.
            if _surface_contact_set_constraint_attachment(guide, False):
                # Existing-constraint contacts otherwise expose their old
                # endpoint for the first G sample and only release on the
                # second operation.
                context.view_layer.update()
            continue
        snap_key = _surface_contact_snap_key(guide)
        # An indirect transform does not *create* a snap, but it must preserve
        # a real snap that already existed when G/R/S began.  Collapsing both
        # cases into detached guidance made an outer-ring contact float away
        # as soon as its torso or contacted surface moved.  Detached contacts
        # remain detached and only aim at the target; attached contacts retain
        # their fixed endpoint without changing ownership semantics.
        parent_attached = bool(
            snap_key in _state.setdefault("pin_snap_initial_latches", set())
            and snap_key not in _state.setdefault("pin_snap_detached", set())
        )
        if not parent_attached:
            _surface_contact_set_snap_detached(guide, True)
            _state.setdefault("pin_snap_latches", set()).discard(snap_key)
            _state.setdefault("pin_snap_initial_latches", set()).discard(
                snap_key
            )
        # A detached child has no Contact correction to unwind: its local
        # basis is unchanged by an ancestor transform. Capture the live local
        # basis instead of an idle/cache baseline from an older operation.
        pose_bone = _surface_contact_simulated_pose_bone(guide)
        if (
            pose_bone is not None
            and not _state.get(
                "pin_snap_transform_baseline_precedes_sample",
                False,
            )
        ):
            pose_key = (
                _armature_session_uid(armature),
                pose_bone.name,
            )
            _state.setdefault(
                "pin_snap_contact_transform_start_poses",
                {},
            )[pose_key] = (
                armature.name,
                pose_bone.name,
                pose_bone.matrix_basis.copy(),
                pose_bone.matrix.copy(),
            )
        parent_attachment_states[guide.name] = parent_attached

    _state["pin_snap_transform_start_poses"] = pose_snapshots
    _state["pin_snap_transform_changed"] = False
    _state["pin_snap_transform_delta_supported"] = False
    _state["pin_snap_transform_delta_observed"] = False
    _state["pin_snap_transform_last_delta_signature"] = None
    _state["pin_snap_last_solved_pose_signature"] = None
    _state["pin_snap_parent_attachment_states"] = parent_attachment_states
    return bool(pose_snapshots)


def _pin_restore_transform_start_poses(context):
    """Undo constraint-only pose changes emitted when native G/R/S starts."""
    snapshots = _state.get("pin_snap_transform_start_poses", {})
    changed = False
    for armature, selected in _selected_pose_bones_by_owner(context).items():
        owner_uid = _armature_session_uid(armature)
        for pose_bone in selected:
            initial = snapshots.get((owner_uid, pose_bone.name))
            if initial is None or not _pin_keyboard_matrices_differ(
                pose_bone.matrix_basis,
                initial,
            ):
                continue
            pose_bone.matrix_basis = initial.copy()
            changed = True
    if changed:
        context.view_layer.update()
    return changed


def _pin_selected_transform_changed(context):
    """Return true only after Blender actually changes a selected pose."""
    if _state.get("pin_snap_transform_changed", False):
        return True
    delta_state = _pin_transform_operator_delta_state(
        context,
        str(_state.get("pin_snap_transform_operator", "")),
    )
    if delta_state is not None:
        _state["pin_snap_transform_delta_supported"] = True
        if delta_state:
            _state["pin_snap_transform_delta_observed"] = True
            _state["pin_snap_transform_changed"] = True
            return True
        # Gizmo RNA can trail Blender's changed pose by one event. Treating a
        # still-zero operator value as "unchanged" restores the
        # captured matrix and makes an unsnapped Onion Pin fight the drag.
    snapshots = _state.get("pin_snap_transform_start_poses", {})
    if not snapshots:
        return False
    for armature, selected in _selected_pose_bones_by_owner(context).items():
        owner_uid = _armature_session_uid(armature)
        for pose_bone in selected:
            initial = snapshots.get((owner_uid, pose_bone.name))
            if (
                initial is not None
                and _pin_keyboard_matrices_differ(
                    pose_bone.matrix_basis,
                    initial,
                    epsilon = 1.0e-6,
                )
            ):
                _state["pin_snap_transform_changed"] = True
                return True
    return False


def _pin_track_transform(transform_operator):
    if _state.get("pin_history_pose_release_pending", False):
        _surface_contact_clear_history_pose_lock()
    if not _state.get("pin_snap_transform_active", False):
        # Publish ownership before any capture calls. Several capture helpers
        # evaluate the view layer/mesh and can synchronously recurse through
        # depsgraph_update_post. Previously that nested callback saw an
        # inactive transform and initialized the same G/R/S a second time.
        _state["pin_snap_transform_active"] = True
        _state["pin_snap_transform_initializing"] = True
        _state["pin_snap_transform_operator"] = str(transform_operator)
        # Pin interactions keep a short selection grace period so their own
        # mouse-up is not mistaken for click-away. A rapid click on another
        # bone followed by G/R/S can begin inside that period. Validate the
        # native pose selection synchronously here; otherwise the stale
        # virtual pink pin is captured as a group member and moves/re-solves
        # with the torso or unrelated bone.
        if _pin_selected_target_keys():
            saved_selection = _state.get("pin_gizmo_selection_keys", ())
            current_selection = _pin_pose_selection_signature(bpy.context)
            if (
                (saved_selection and current_selection != saved_selection)
                or (
                    not saved_selection
                    and bool(current_selection[1])
                )
            ):
                _state["pin_gizmo_extend_selection_until"] = 0.0
                _pin_deselect_target(
                    push_history=False,
                    store_history=False,
                    redraw=False,
                )
        try:
            _state["pin_snap_depsgraph_observed"] = False
            _state.setdefault("pin_snap_transform_seen", set()).clear()
            _state.setdefault("pin_snap_previous_points", {}).clear()
            _state.setdefault("pin_snap_swept_hits", set()).clear()
            _surface_contact_clear_live_pose_session()
            _pin_capture_transform_intent(bpy.context)
            _pin_capture_contact_target_locks(bpy.context)
            _pin_native_group_capture(bpy.context)
            # The first modal event may be consumed by the view-layer update
            # that disables Contact's constraint. Make the timer process that
            # first Blender pose even if no second depsgraph event arrives;
            # otherwise the first G pull appears ignored and only a second G
            # can leave the snap.
            _state["pin_snap_transform_dirty"] = True
        except Exception:
            _pin_clear_transform_state()
            raise
        finally:
            _state["pin_snap_transform_initializing"] = False
    _state["pin_snap_transform_active"] = True
    _state["pin_snap_transform_operator"] = str(transform_operator)


def _pin_clear_transform_state():
    _pin_restore_contact_target_locks()
    directly_owned_guides = []
    parent_driven_guides = set(
        _state.get("pin_snap_parent_transform_guides", set())
    )
    if _state.get("pin_snap_transform_active", False):
        for guide_name in tuple(
            _state.get("pin_snap_contact_target_locks", {})
        ):
            if guide_name in parent_driven_guides:
                continue
            guide = bpy.data.objects.get(str(guide_name))
            if guide is not None:
                _surface_contact_store_owner_pose_base(guide)
                directly_owned_guides.append(guide)
    _state["pin_snap_transform_active"] = False
    _state["pin_snap_transform_initializing"] = False
    _state["pin_snap_depsgraph_observed"] = False
    _state["pin_snap_transform_operator"] = ""
    _state["pin_snap_transform_start_poses"] = {}
    _state["pin_snap_transform_changed"] = False
    _state["pin_snap_transform_delta_supported"] = False
    _state["pin_snap_transform_delta_observed"] = False
    _state["pin_snap_transform_last_delta_signature"] = None
    _state["pin_snap_last_solved_pose_signature"] = None
    _state["pin_snap_contact_target_locks"] = {}
    _state["pin_snap_parent_transform_guides"] = set()
    _state["pin_snap_parent_attachment_states"] = {}
    _state.setdefault("pin_snap_transform_seen", set()).clear()
    _state.setdefault("pin_snap_initial_detached", {}).clear()
    _state.setdefault("pin_snap_previous_points", {}).clear()
    _state.setdefault("pin_snap_swept_hits", set()).clear()
    _state["pin_snap_last_depsgraph_sync"] = 0.0
    _pin_native_group_clear()
    _surface_contact_clear_live_pose_session()
    _surface_contact_clear_transform_start_poses()
    # Persist only contacts directly owned by this transform. Parent-driven
    # attached contacts persist their solved preview when it is captured;
    # detached and unrelated contacts must not receive any ID-property write
    # that could make Blender include them in this undo step.
    if (
        directly_owned_guides
        and not _state.get("pin_history_syncing", False)
    ):
        _surface_contact_store_persistent_pose_snapshots(
            tuple(directly_owned_guides)
        )


def _surface_contact_guides_for_selected_bone(armature, pose_bone, frame):
    if armature is None or pose_bone is None:
        return ()
    property_names = (
        SURFACE_CONTACT_BONE_PROPERTY,
        SURFACE_CONTACT_CONTROL_BONE_PROPERTY,
        SURFACE_CONTACT_GEOMETRY_BONE_PROPERTY,
        SURFACE_CONTACT_CONSTRAINT_BONE_PROPERTY,
        SURFACE_CONTACT_RELEASE_BONE_PROPERTY,
    )
    return tuple(
        guide
        for guide in _surface_contact_guides()
        if (
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
            == armature.name
            and pose_bone.name
            in {str(guide.get(name, "")) for name in property_names}
            and _surface_contact_guide_active_at(guide, int(frame))
        )
    )


def _surface_contact_related_bone_names(guide):
    return {
        str(guide.get(property_name, ""))
        for property_name in (
            SURFACE_CONTACT_BONE_PROPERTY,
            SURFACE_CONTACT_CONTROL_BONE_PROPERTY,
            SURFACE_CONTACT_GEOMETRY_BONE_PROPERTY,
            SURFACE_CONTACT_CONSTRAINT_BONE_PROPERTY,
            SURFACE_CONTACT_RELEASE_BONE_PROPERTY,
        )
        if str(guide.get(property_name, ""))
    }


def _surface_contact_selected_bones_drive_guide(
    armature,
    guide,
    selected_names,
):
    """Return whether selected ancestors move this guide's linked pose bone."""
    if (
        armature is None
        or getattr(armature, "pose", None) is None
        or not selected_names
    ):
        return False
    pose_bone = armature.pose.bones.get(
        str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
    )
    while pose_bone is not None:
        if pose_bone.name in selected_names:
            return True
        pose_bone = pose_bone.parent
    return False


def _snap_selected_pin_endpoints(
    context,
    insert_keys = True,
    update_view_layer = True,
    use_snap_hysteresis = False,
):
    if (
        _state.get("pin_snap_syncing", False)
        or _state.get("pin_target_dragging", False)
        or context is None
        or getattr(context, "mode", "") != "POSE"
    ):
        return False
    screen = getattr(context, "screen", None)
    if screen is not None and bool(getattr(screen, "is_animation_playing", False)):
        return False
    grouped = _selected_pose_bones_by_owner(context)
    if not grouped:
        return False
    if _pin_selected_target_keys():
        return True

    _state["pin_snap_syncing"] = True
    changed = False
    try:
        _pin_reset_dual_snap_owners()
        changed = _pin_restore_contact_target_locks() or changed
        frame = int(context.scene.frame_current)
        selected_by_name = {
            armature.name: {pose_bone.name for pose_bone in selected}
            for armature, selected in grouped.items()
        }
        for guide in _surface_contact_guides():
            guide_armature_name = str(
                guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, "")
            )
            selected_names = selected_by_name.get(guide_armature_name)
            target_driven = _pin_selected_pose_drives_contact_target(
                guide, selected_by_name
            )
            if (
                not _surface_contact_guide_active_at(guide, frame)
                or (selected_names is None and not target_driven)
            ):
                continue
            directly_selected = bool(
                selected_names
                and _surface_contact_direct_bone_names(guide) & selected_names
            )
            armature = bpy.data.objects.get(guide_armature_name)
            parent_driven = bool(
                not directly_selected
                and _surface_contact_selected_bones_drive_guide(
                    armature,
                    guide,
                    selected_names,
                )
            )
            indirectly_driven = bool(
                not directly_selected and (parent_driven or target_driven)
            )
            if not directly_selected and not indirectly_driven:
                # Editing one limb must not wake every other contact in the
                # armature. Besides wasting several evaluated-mesh queries per
                # mouse sample, that fan-out allowed untouched pink bones to
                # accumulate tiny solver corrections.
                continue
            contact_kind = str(
                guide.get(SURFACE_CONTACT_KIND_PROPERTY, "")
            )
            simulated = contact_kind == SURFACE_CONTACT_KIND_SIMULATED
            snap_capable = _surface_contact_snap_capable(guide)
            contact_pose_bone = (
                armature.pose.bones.get(
                    str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
                )
                if armature is not None
                else None
            )
            has_yellow = bool(
                contact_pose_bone is not None
                and _state.get("yellow_fixed", {}).get(
                    _owner_bone_key(armature, contact_pose_bone.name)
                )
            )
            parent_transform = bool(
                simulated
                and indirectly_driven
                and _state.get("pin_snap_transform_active", False)
            )
            parent_attached = bool(
                _state.get("pin_snap_parent_attachment_states", {}).get(
                    guide.name,
                    False,
                )
            )
            if parent_transform:
                _state.setdefault(
                    "pin_snap_parent_transform_guides",
                    set(),
                ).add(guide.name)
                # Contact corrections change the child's matrix_basis. Restore
                # its user-authored local pose before every ancestor sample so
                # collision cannot accumulate or fight Blender's native modal
                # transform.
                if parent_attached:
                    _surface_contact_restore_transform_start_pose(
                        context,
                        guide,
                    )
                    _surface_contact_clear_snap_departure(guide)
                    attached_result = _surface_contact_solve_attached_rod_motion(
                        context, guide
                    )
                    if attached_result is None:
                        changed = _surface_contact_enforce_guide(
                            context,
                            guide,
                            force_contact=True,
                            insert_keys=False,
                            allow_snap=True,
                            rotate_detached=False,
                        ) or changed
                    else:
                        changed = attached_result or changed
                    _surface_contact_capture_live_pose(guide)
                    changed = _pin_restore_contact_target_locks() or changed
                    continue
                else:
                    # A detached child starts from Blender's normal inherited
                    # parent pose. The shared direct-pink solver below owns
                    # magnetic aiming and collision, but never attachment.
                    snap_key = _surface_contact_snap_key(guide)
                    _state.setdefault("pin_snap_detached", set()).add(snap_key)
                    _state.setdefault("pin_snap_latches", set()).discard(
                        snap_key
                    )
                    _surface_contact_restore_transform_start_pose(
                        context,
                        guide,
                    )
                    # One ordered solve gives collision authority for this
                    # sample. A rod arc is never immediately aimed back toward
                    # the pin, which was the indirect angle limiter.
                    changed = (
                        _surface_contact_solve_detached_target_motion(
                            context, guide
                        )
                        or changed
                    )
                    _surface_contact_set_constraint_attachment(guide, False)
                    _state.setdefault("pin_snap_detached", set()).add(
                        snap_key
                    )
                    _state.setdefault("pin_snap_latches", set()).discard(
                        snap_key
                    )
                    _surface_contact_capture_live_pose(guide)
                    changed = _pin_restore_contact_target_locks() or changed
                    continue
            pink_snap_close = False
            if directly_selected and snap_capable:
                pink_snap_close = _surface_contact_direct_snap_close(
                    context, guide, use_snap_hysteresis
                )
            yellow_owns_snap = bool(
                directly_selected
                and not pink_snap_close
                and _pin_dual_snap_owner(context, guide = guide) == "YELLOW"
            )
            if yellow_owns_snap:
                changed = _pin_yellow_takeover_contact(context, guide) or changed
                changed |= _pin_restore_contact_target_locks()
                continue
            if directly_selected and pink_snap_close and simulated:
                if "translate" in str(
                    _state.get("pin_snap_transform_operator", "")
                ).lower():
                    # Blender's native G can evaluate from the contact-corrected
                    # pose of the previous sample. Rebase only its orientation
                    # to the captured transform-start pose while preserving the
                    # current raw translation. A closed cursor path therefore
                    # returns to the exact initial tilt instead of accumulating
                    # a small roll on every ball-joint sample.
                    current_world = (
                        armature.matrix_world @ contact_pose_bone.matrix
                    )
                    current_translation = current_world.translation.copy()
                    if _surface_contact_restore_transform_start_pose(
                        context,
                        guide,
                    ):
                        rebased_world = (
                            armature.matrix_world @ contact_pose_bone.matrix
                        )
                        rebased_world.translation = current_translation
                        _set_pose_bone_constrained_output_matrix(
                            context,
                            armature,
                            contact_pose_bone,
                            armature.matrix_world.inverted_safe()
                            @ rebased_world,
                        )
                attached_result = _surface_contact_solve_attached_rod_motion(
                    context,
                    guide,
                    # R is a ball-socket rotation around the real pink pin.
                    # It must never switch to the pressure-only imaginary top
                    # pivot, which visibly slides the two dots apart.
                    allow_top_pivot=(
                        "translate" in str(
                            _state.get(
                                "pin_snap_transform_operator",
                                "",
                            )
                        ).lower()
                    ),
                )
                if attached_result is None:
                    changed = _surface_contact_enforce_guide(
                        context,
                        guide,
                        force_contact=True,
                        insert_keys=False,
                        allow_snap=True,
                        rotate_detached=False,
                    ) or changed
                else:
                    changed = attached_result or changed
                _surface_contact_capture_live_pose(guide)
                changed = _pin_restore_contact_target_locks() or changed
                continue
            detached = bool(
                snap_capable
                and not pink_snap_close
                and (
                    (indirectly_driven and not parent_attached)
                    or _surface_contact_snap_departure_active(
                        context,
                        guide,
                        start_if_close = bool(
                            directly_selected
                            and _state.get("pin_snap_transform_active", False)
                        ),
                    )
                )
            )
            if (
                directly_selected
                and detached
                and simulated
                and not yellow_owns_snap
            ):
                # Native Blender G/R/S supplies the raw bone pose. Use the
                # same single-pass rod/collision solve as target/ancestor
                # motion instead of the older rotate/collide settle loop,
                # which alternated two poses and flickered in the viewport.
                if "translate" in str(
                    _state.get("pin_snap_transform_operator", "")
                ).lower():
                    # Begin every detached mouse sample from the orientation
                    # captured when G started. Starting from the previous
                    # magnetic correction feeds twist back into the next
                    # sample, so a closed circular move drifts permanently.
                    current_world = (
                        armature.matrix_world @ contact_pose_bone.matrix
                    )
                    current_translation = current_world.translation.copy()
                    if _surface_contact_restore_transform_start_pose(
                        context,
                        guide,
                    ):
                        rebased_world = (
                            armature.matrix_world @ contact_pose_bone.matrix
                        )
                        rebased_world.translation = current_translation
                        _set_pose_bone_constrained_output_matrix(
                            context,
                            armature,
                            contact_pose_bone,
                            armature.matrix_world.inverted_safe()
                            @ rebased_world,
                        )
                changed = (
                    _surface_contact_solve_detached_target_motion(
                        context, guide
                    )
                    or changed
                )
                _surface_contact_capture_live_pose(guide)
                changed = _pin_restore_contact_target_locks() or changed
                continue
            changed = _surface_contact_enforce_guide(
                context,
                guide,
                force_contact = bool(
                    pink_snap_close
                    or (parent_transform and parent_attached)
                ),
                insert_keys = bool(insert_keys and directly_selected),
                use_snap_hysteresis = use_snap_hysteresis,
                allow_snap = bool(
                    (directly_selected and not detached and not yellow_owns_snap)
                    or (parent_transform and parent_attached)
                ),
                rotate_detached = bool(
                    directly_selected
                    and not yellow_owns_snap
                    and not has_yellow
                    and "rotate" not in str(
                        _state.get(
                            "pin_snap_transform_operator",
                            "",
                        )
                    ).lower()
                ),
                collision_only = False,
                rotate_snap = bool(
                    not pink_snap_close
                    and (not has_yellow or parent_transform)
                ),
            ) or changed
            if directly_selected or indirectly_driven:
                _surface_contact_capture_live_pose(guide)
            changed = _pin_restore_contact_target_locks() or changed
        for armature, selected in grouped.items():
            for pose_bone in selected:
                packed = _state.get("yellow_fixed", {}).get(
                    _owner_bone_key(armature, pose_bone.name)
                )
                dual_owner = _pin_dual_snap_owner(
                    context, armature = armature, pose_bone = pose_bone,
                )
                if packed and dual_owner != "CONTACT":
                    changed = _yellow_snap_pose_bone(
                        context,
                        armature,
                        pose_bone,
                        packed,
                        insert_keys = insert_keys,
                        update_view_layer = update_view_layer,
                        use_snap_hysteresis = use_snap_hysteresis,
                    ) or changed
        if changed:
            if update_view_layer:
                context.view_layer.update()
            _tag_redraw_all_view3d()
        return changed
    finally:
        _pin_reset_dual_snap_owners()
        _state["pin_snap_syncing"] = False


def _pin_native_transform_has_snap_scope(context):
    """Avoid contact work for unrelated Pose transforms."""
    grouped = _selected_pose_bones_by_owner(context)
    if not grouped:
        return False
    selected_by_name = {
        armature.name: {pose_bone.name for pose_bone in selected}
        for armature, selected in grouped.items()
    }
    frame = int(context.scene.frame_current)
    guides = tuple(_surface_contact_guides())
    if any(
        _pin_selected_pose_drives_contact_target(guide, selected_by_name)
        for guide in guides
    ):
        # The moved bone may belong to another rig. Its transform still owns
        # the contacted surface, so the linked pink limb needs every live
        # transform sample rather than only the final mouse-up update.
        return True
    for armature, selected in grouped.items():
        selected_names = {pose_bone.name for pose_bone in selected}
        if any(
            _state.get("yellow_fixed", {}).get(
                _owner_bone_key(armature, pose_bone.name)
            )
            for pose_bone in selected
        ):
            return True
        for guide in guides:
            if (
                str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
                != armature.name
                or not _surface_contact_guide_active_at(guide, frame)
            ):
                continue
            if (
                _surface_contact_related_bone_names(guide) & selected_names
                or _surface_contact_selected_bones_drive_guide(
                    armature,
                    guide,
                    selected_names,
                )
            ):
                return True
    return False


def _pin_process_native_transform_sample(context, transform_operator):
    """Correct one native G/R/S sample before Blender redraws the viewport."""
    if not _pin_native_transform_has_snap_scope(context):
        return False
    _pin_track_transform(transform_operator)
    delta_signature = _pin_transform_operator_delta_signature(
        context,
        transform_operator,
    )
    pose_signature = _pin_selected_pose_input_signature(context)
    if (
        delta_signature is not None
        and delta_signature
        == _state.get("pin_snap_transform_last_delta_signature")
        and pose_signature
        == _state.get("pin_snap_last_solved_pose_signature")
    ):
        # Solver-owned dependency updates can re-enter this callback with the
        # same Blender mouse delta and the exact solver-produced pose. Only
        # that complete pair is a duplicate; Blender may legally reuse an
        # operator value for a genuinely different pose sample.
        return False
    _pin_native_group_apply(context, transform_operator)
    _pin_capture_direct_contact_raw_anchors(context)
    if not _pin_selected_transform_changed(context):
        _pin_restore_transform_start_poses(context)
        return False

    _state["pin_snap_transform_last_delta_signature"] = delta_signature
    changed = _snap_selected_pin_endpoints(
        context,
        insert_keys = False,
        use_snap_hysteresis = True,
    )
    _state["pin_snap_last_solved_pose_signature"] = (
        _pin_selected_pose_input_signature(context)
    )
    return changed


def _pin_selected_pose_input_signature(context):
    """Small signature separating raw Blender input from our solved pose."""
    values = []
    for armature, selected in _selected_pose_bones_by_owner(context).items():
        owner_uid = _armature_session_uid(armature)
        for pose_bone in selected:
            values.append((
                owner_uid,
                pose_bone.name,
                tuple(
                    round(float(component), 9)
                    for row in pose_bone.matrix_basis
                    for component in row
                ),
            ))
    values.sort(key=lambda item: (item[0], item[1]))
    return tuple(values)


def _pin_capture_direct_contact_raw_anchors(context):
    """Capture direct pink-bone input before Contact corrects the pose."""
    grouped = _selected_pose_bones_by_owner(context)
    selected_by_name = {
        armature.name: {pose_bone.name for pose_bone in selected}
        for armature, selected in grouped.items()
    }
    samples = _state.setdefault("pin_snap_raw_anchor_samples", {})
    for guide in _surface_contact_active_snap_guides(context.scene):
        selected_names = selected_by_name.get(
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, "")),
            set(),
        )
        if not (
            _surface_contact_direct_bone_names(guide) & selected_names
        ):
            continue
        # This runs for every mouse event. Read the saved support point from
        # the live pose matrix directly; asking Blender for an evaluated
        # dependency graph here rebuilds contacted mesh geometry per pixel
        # and makes pink-bone dragging stall badly on real rigs.
        anchor = _surface_contact_bone_anchor_world(
            context,
            guide,
            live_pose=True,
        )
        if anchor is not None:
            samples[_surface_contact_snap_key(guide)] = Vector(anchor).copy()


def _pin_snap_runtime_needed(context):
    if context is None or getattr(context, "mode", "") != "POSE":
        return False
    if (
        _pin_selected_target_key()
        or _state.get("pin_target_dragging", False)
        or _state.get("pin_keyboard_transform_active", False)
        or _state.get("pin_snap_transform_active", False)
    ):
        return True
    try:
        return bool(_pin_available_target_data(context))
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return False


def _pin_snap_timer():
    context = bpy.context
    if context is None:
        return 0.2
    if not _pin_snap_runtime_needed(context):
        if _state.get("pin_snap_transform_active", False):
            _pin_clear_transform_state()
        return 0.2
    transform_operator = _pin_active_transform_operator(context)
    if _pin_primary_mouse_pressed() and not transform_operator:
        # Do no scene, selection, or gizmo-map maintenance between Blender's
        # native gizmo press and its modal transform ownership.
        return 0.03
    if transform_operator:
        if (
            _pin_selected_target_key()
            and not _state.get("pin_keyboard_transform_active", False)
            and not _state.get("pin_target_dragging", False)
            and not _pin_transform_group_has_selected_bones(context)
        ):
            # A native transform gizmo belongs to Blender's bone/object
            # selection, so it is the same as clicking away from the pin.
            _state["pin_native_selection_cleanup_pending"] = bool(
                _pin_deselect_target(
                    push_history=False,
                    store_history=False,
                    redraw=False,
                )
            )
        if not _state.get("pin_snap_transform_active", False):
            _pin_track_transform(transform_operator)
        if not _state.pop("pin_snap_transform_dirty", False):
            return 0.016
        try:
            _pin_process_native_transform_sample(
                context,
                transform_operator,
            )
        except (
            AttributeError,
            ReferenceError,
            RuntimeError,
            TypeError,
            ValueError,
        ) as exc:
            print(f"[Roblox Animator Utils] Live pin snap skipped: {exc}")
        _state["pin_snap_last_depsgraph_sync"] = time.perf_counter()
        return 0.016

    if _state.get("pin_snap_transform_active", False):
        if not _surface_contact_native_transform_ready(context):
            return 0.016
        try:
            _surface_contact_finalize_native_transform(context)
        except (
            AttributeError,
            ReferenceError,
            RuntimeError,
            TypeError,
            ValueError,
        ) as exc:
            print(f"[Roblox Animator Utils] Pin snap skipped: {exc}")
    if _state.pop("pin_native_selection_cleanup_pending", False):
        _pin_selection_history_store(context)
        _tag_redraw_all_view3d()
    _pin_cache_idle_transform_poses(context)
    return 0.1
