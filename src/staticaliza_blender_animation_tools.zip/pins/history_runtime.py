"""Exact Contact runtime snapshots used around Blender Undo/Redo."""

from ..core.runtime import *  # noqa: F403


_CONTACT_HISTORY_SET_STATES = (
    "pin_snap_latches",
    "pin_snap_detached",
    "pin_snap_departing",
    "pin_snap_transform_seen",
    "pin_snap_swept_hits",
    "pin_snap_transform_engaged",
    "pin_snap_transform_releasing",
    "pin_snap_release_reentry_armed",
    "pin_snap_pressure_active",
    "pin_snap_pressure_release_session",
)

_CONTACT_HISTORY_MAP_STATES = (
    "pin_snap_previous_points",
    "pin_snap_pressure_tangents",
    "pin_snap_pressure_release_origins",
    "pin_snap_pressure_release_pose_matrices",
    "pin_snap_pressure_release_raw_translations",
    "pin_snap_pressure_release_authored_translations",
    "pin_snap_engage_translate_origins",
    "pin_snap_engage_anchor_origins",
    "pin_snap_grip_directions",
    "pin_snap_raw_anchor_samples",
    "pin_snap_magnetic_anchor_samples",
    "pin_snap_pre_solve_anchor_samples",
    "pin_snap_release_anchor_origins",
)


def _pin_history_runtime_value_copy(value):
    if isinstance(value, dict):
        return {
            key: _pin_history_runtime_value_copy(item)
            for key, item in value.items()
        }
    if isinstance(value, list):
        return [_pin_history_runtime_value_copy(item) for item in value]
    if isinstance(value, tuple):
        return tuple(_pin_history_runtime_value_copy(item) for item in value)
    if isinstance(value, set):
        return {_pin_history_runtime_value_copy(item) for item in value}
    try:
        return value.copy()
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        return value


def _surface_contact_detached_key_snapshot(guide, frame):
    if guide is None:
        return None
    action = _dynamic_parent_owner_action(guide)
    animated_id = getattr(guide, "id_data", None) or guide
    data_path = f'["{SURFACE_CONTACT_DETACHED_PROPERTY}"]'
    frame = float(frame)
    curves = []
    keys = []
    for fcurve in _fcurves_find_all(action, data_path, animated_id):
        group = getattr(fcurve, "group", None)
        curves.append({
            "path": data_path,
            "index": int(fcurve.array_index),
            "group": str(getattr(group, "name", "")) if group else "",
            "extrapolation": str(getattr(fcurve, "extrapolation", "")),
            "color_mode": str(getattr(fcurve, "color_mode", "")),
            "auto_smoothing": str(getattr(fcurve, "auto_smoothing", "")),
        })
        for key in fcurve.keyframe_points:
            if abs(float(key.co.x) - frame) > 1.0e-5:
                continue
            keys.append({
                "path": data_path,
                "index": int(fcurve.array_index),
                "frame": float(key.co.x),
                "value": float(key.co.y),
                "interpolation": str(getattr(key, "interpolation", "")),
                "easing": str(getattr(key, "easing", "")),
                "type": str(getattr(key, "type", "")),
                "handle_left_type": str(getattr(key, "handle_left_type", "")),
                "handle_right_type": str(getattr(key, "handle_right_type", "")),
                "handle_left": tuple(float(value) for value in key.handle_left),
                "handle_right": tuple(float(value) for value in key.handle_right),
                "amplitude": float(getattr(key, "amplitude", 0.0)),
                "back": float(getattr(key, "back", 0.0)),
                "period": float(getattr(key, "period", 0.0)),
            })
    curves.sort(key=lambda item: (item["path"], item["index"]))
    keys.sort(key=lambda item: (item["path"], item["index"]))
    return {"frame": frame, "curves": tuple(curves), "keys": tuple(keys)}


def _surface_contact_restore_detached_key_snapshot(guide, snapshot):
    if guide is None or snapshot is None:
        return False
    frame = float(snapshot.get("frame", 0.0))
    if _dynamic_parent_pose_key_snapshot_signature(
        _surface_contact_detached_key_snapshot(guide, frame)
    ) == _dynamic_parent_pose_key_snapshot_signature(snapshot):
        return False
    animated_id = getattr(guide, "id_data", None) or guide
    expected_curves = {
        (str(item.get("path", "")), int(item.get("index", 0))): item
        for item in snapshot.get("curves", ())
    }
    expected_keys = tuple(snapshot.get("keys", ()))
    action = _dynamic_parent_owner_action(guide)
    if action is None:
        if not expected_curves and not expected_keys:
            return False
        action = _ensure_object_action(guide)
    data_path = f'["{SURFACE_CONTACT_DETACHED_PROPERTY}"]'
    changed = False
    for fcurve in tuple(_fcurves_find_all(action, data_path, animated_id)):
        for key in tuple(fcurve.keyframe_points):
            if abs(float(key.co.x) - frame) <= 1.0e-5:
                fcurve.keyframe_points.remove(key)
                changed = True
        curve_id = (str(fcurve.data_path), int(fcurve.array_index))
        if not fcurve.keyframe_points and curve_id not in expected_curves:
            changed = _action_remove_fcurve(action, fcurve) or changed
        else:
            fcurve.update()

    def find_curve(path, index):
        return next((
            candidate
            for candidate in _fcurves_find_all(action, path, animated_id)
            if int(candidate.array_index) == int(index)
        ), None)

    for curve_id, saved_curve in expected_curves.items():
        fcurve = find_curve(*curve_id)
        if fcurve is None:
            fcurve = _action_new_fcurve(
                action,
                curve_id[0],
                animated_id=animated_id,
                index=curve_id[1],
                group_name=saved_curve.get("group", ""),
            )
            changed = True
        changed = _dynamic_parent_apply_history_curve_state(
            action, fcurve, saved_curve
        ) or changed
    for saved in expected_keys:
        path = str(saved.get("path", data_path))
        index = int(saved.get("index", 0))
        fcurve = find_curve(path, index)
        if fcurve is None:
            curve_state = expected_curves.get((path, index), {})
            fcurve = _action_new_fcurve(
                action,
                path,
                animated_id=animated_id,
                index=index,
                group_name=curve_state.get("group", ""),
            )
            _dynamic_parent_apply_history_curve_state(
                action, fcurve, curve_state
            )
        key = fcurve.keyframe_points.insert(
            float(saved.get("frame", frame)),
            float(saved.get("value", 0.0)),
        )
        for attribute in (
            "interpolation",
            "easing",
            "type",
            "handle_left_type",
            "handle_right_type",
            "amplitude",
            "back",
            "period",
        ):
            value = saved.get(attribute)
            if value in (None, ""):
                continue
            try:
                setattr(key, attribute, value)
            except (AttributeError, RuntimeError, TypeError, ValueError):
                pass
        if len(saved.get("handle_left", ())) == 2:
            key.handle_left = saved["handle_left"]
        if len(saved.get("handle_right", ())) == 2:
            key.handle_right = saved["handle_right"]
        fcurve.update()
        changed = True
    return changed


def _pin_contact_runtime_snapshot(context):
    scene = getattr(context, "scene", None) if context is not None else None
    if scene is None:
        return {"frame": 0, "entries": ()}
    frame = int(scene.frame_current)
    entries = []
    for guide in _surface_contact_active_simulated_guides(scene):
        armature, pose_bone = _surface_contact_pose_bone(guide)
        if armature is None or pose_bone is None:
            continue
        snap_key = _surface_contact_snap_key(guide)
        entries.append({
            "guide": str(guide.name),
            "armature": str(armature.name),
            "bone": str(pose_bone.name),
            "basis": pose_bone.matrix_basis.copy(),
            "visual": pose_bone.matrix.copy(),
            "guide_matrix": guide.matrix_world.copy(),
            "constraints": _surface_contact_constraint_history_state(guide),
            "action_keys": _surface_contact_pose_action_key_snapshot(
                armature, pose_bone, frame
            ),
            "detached_keys": _surface_contact_detached_key_snapshot(
                guide, frame
            ),
            "detached_property_exists": (
                SURFACE_CONTACT_DETACHED_PROPERTY in guide
            ),
            "detached_property": _pin_history_runtime_value_copy(
                guide.get(SURFACE_CONTACT_DETACHED_PROPERTY)
            ),
            "set_states": {
                name: snap_key in _state.setdefault(name, set())
                for name in _CONTACT_HISTORY_SET_STATES
            },
            "map_states": {
                name: (
                    snap_key in _state.setdefault(name, {}),
                    _pin_history_runtime_value_copy(
                        _state.setdefault(name, {}).get(snap_key)
                    ),
                )
                for name in _CONTACT_HISTORY_MAP_STATES
            },
        })
    return {"frame": frame, "entries": tuple(entries)}


def _pin_contact_runtime_restore(context, snapshot, update_view_layer=True):
    if not snapshot or context is None or getattr(context, "scene", None) is None:
        return False
    frame = int(snapshot.get("frame", context.scene.frame_current))
    changed = False
    lock_entries = []
    for entry in tuple(snapshot.get("entries", ())):
        guide = bpy.data.objects.get(str(entry.get("guide", "")))
        armature = bpy.data.objects.get(str(entry.get("armature", "")))
        pose_bone = (
            armature.pose.bones.get(str(entry.get("bone", "")))
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if guide is None or pose_bone is None:
            continue
        guide_matrix = entry.get("guide_matrix")
        if guide_matrix is not None and _pin_keyboard_matrices_differ(
            guide.matrix_world,
            guide_matrix,
            epsilon=1.0e-8,
        ):
            guide.matrix_world = guide_matrix.copy()
            changed = True
        current_keys = _surface_contact_pose_action_key_snapshot(
            armature, pose_bone, frame
        )
        expected_keys = entry.get("action_keys")
        if _dynamic_parent_pose_key_snapshot_signature(
            current_keys
        ) != _dynamic_parent_pose_key_snapshot_signature(expected_keys):
            changed = _surface_contact_restore_action_key_snapshot(
                armature, pose_bone, frame, expected_keys
            ) or changed
        detached_changed = _surface_contact_restore_detached_key_snapshot(
            guide, entry.get("detached_keys")
        )
        changed = detached_changed or changed
        property_exists = bool(entry.get("detached_property_exists", False))
        property_value = entry.get("detached_property")
        if property_exists:
            if (
                SURFACE_CONTACT_DETACHED_PROPERTY not in guide
                or guide.get(SURFACE_CONTACT_DETACHED_PROPERTY) != property_value
            ):
                guide[SURFACE_CONTACT_DETACHED_PROPERTY] = property_value
                changed = True
                detached_changed = True
        elif SURFACE_CONTACT_DETACHED_PROPERTY in guide:
            del guide[SURFACE_CONTACT_DETACHED_PROPERTY]
            changed = True
            detached_changed = True
        snap_key = _surface_contact_snap_key(guide)
        for name, present in dict(entry.get("set_states", {})).items():
            values = _state.setdefault(str(name), set())
            before = snap_key in values
            if present:
                values.add(snap_key)
            else:
                values.discard(snap_key)
            changed = changed or before != bool(present)
        for name, saved in dict(entry.get("map_states", {})).items():
            values = _state.setdefault(str(name), {})
            present, value = saved
            before_present = snap_key in values
            if present:
                values[snap_key] = _pin_history_runtime_value_copy(value)
            else:
                values.pop(snap_key, None)
            changed = changed or before_present != bool(present)
        attached = bool(
            snap_key in _state.setdefault("pin_snap_latches", set())
            and snap_key not in _state.setdefault("pin_snap_detached", set())
            and snap_key not in _state.setdefault(
                "pin_snap_transform_releasing", set()
            )
            and not bool(
                guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)
            )
        )
        changed = _surface_contact_set_constraint_attachment(
            guide, attached
        ) or changed
        changed = _surface_contact_restore_constraint_history_state(
            guide,
            entry.get("constraints", ()),
        ) or changed
        if detached_changed:
            _surface_contact_invalidate_detached_key_cache(guide)
        basis = entry.get("basis")
        visual = entry.get("visual")
        if basis is not None:
            lock_entries.append((
                str(armature.name),
                str(pose_bone.name),
                basis.copy(),
                visual.copy() if visual is not None else None,
            ))
    _surface_contact_merge_history_pose_lock(lock_entries)
    if lock_entries:
        changed = _surface_contact_apply_history_pose_lock(
            context, update_view_layer=bool(update_view_layer)
        ) or changed
    elif changed and update_view_layer:
        context.view_layer.update()
    return changed

def _pin_history_matrix_signature(matrix):
    if matrix is None:
        return None
    return tuple(
        round(float(value), 8)
        for row in matrix
        for value in row
    )


def _pin_history_attachment_signature(guide):
    if guide is None:
        return None
    snap_key = _surface_contact_snap_key(guide)
    return (
        bool(guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)),
        snap_key in _state.setdefault("pin_snap_latches", set()),
        snap_key in _state.setdefault("pin_snap_detached", set()),
        snap_key in _state.setdefault("pin_snap_departing", set()),
        snap_key in _state.setdefault("pin_snap_transform_releasing", set()),
    )


def _pin_history_transition_attachment_property_side_matches(
    transition, index
):
    if not transition or int(index) not in (0, 1):
        return False
    for owner_key, before_attached, after_attached in transition.get(
        "attachments", ()
    ):
        if bool(before_attached) == bool(after_attached):
            continue
        guide = bpy.data.objects.get(str(owner_key[1]))
        expected_attached = bool(
            before_attached if int(index) == 0 else after_attached
        )
        if (
            guide is None
            or bool(
                guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)
            ) == expected_attached
        ):
            return False
    return True


def _pin_history_transition_native_state_side_matches(transition, index):
    token_entries = tuple(transition.get("history_tokens", ()))
    if token_entries:
        # The token lives on the armature ID that Blender's native G/R/S owns.
        # Once it matches a side, this is the exact Contact transform step.
        # Guide properties, constraint influences, and solved contact poses
        # are intentionally restored by the post handler because Blender may
        # leave those external/derived values on the opposite side.
        return all(
            (
                (armature := bpy.data.objects.get(str(armature_name)))
                is not None
                and int(armature.get(
                    SURFACE_CONTACT_HISTORY_TOKEN_PROPERTY,
                    -1,
                ))
                == int(before_token if int(index) == 0 else after_token)
            )
            for armature_name, before_token, after_token in token_entries
        )
    checks = []
    if any(
        _pin_history_matrix_signature(before_matrix)
        != _pin_history_matrix_signature(after_matrix)
        for _owner_key, _guide_name, before_matrix, after_matrix
        in transition.get("guide_matrices", ())
    ):
        checks.append(_pin_history_transition_guide_side_matches(
            transition, index
        ))
    if any(
        _dynamic_parent_pose_key_snapshot_signature(before_keys)
        != _dynamic_parent_pose_key_snapshot_signature(after_keys)
        for _armature_name, _bone_name, before_keys, after_keys
        in transition.get("action_keys", ())
    ):
        checks.append(_pin_history_transition_action_side_matches(
            transition, index
        ))
    if any(
        _pin_history_constraint_signature(before_state)
        != _pin_history_constraint_signature(after_state)
        for _owner_key, _guide_name, before_state, after_state
        in transition.get("constraint_states", ())
    ):
        checks.append(_pin_history_transition_constraint_side_matches(
            transition, index
        ))
    if any(
        bool(before_attached) != bool(after_attached)
        for _owner_key, before_attached, after_attached
        in transition.get("attachments", ())
    ):
        checks.append(
            _pin_history_transition_attachment_property_side_matches(
                transition, index
            )
        )
    return bool(checks and all(checks))


def _pin_history_constraint_signature(snapshot):
    return tuple(
        (
            str(role),
            str(name),
            str(constraint_type),
            None if influence is None else round(float(influence), 8),
            None if mute is None else bool(mute),
        )
        for role, name, constraint_type, influence, mute in tuple(
            snapshot or ()
        )
    )


def _pin_history_transition_guide_side_matches(transition, index):
    if not transition or int(index) not in (0, 1):
        return False
    for _owner_key, guide_name, before_matrix, after_matrix in transition.get(
        "guide_matrices", ()
    ):
        guide = bpy.data.objects.get(str(guide_name))
        expected = before_matrix if int(index) == 0 else after_matrix
        if (
            guide is None
            or expected is None
            or not _pin_history_matrix_matches(
                guide.matrix_world,
                expected,
                epsilon=1.0e-6,
            )
        ):
            return False
    for _owner_key, guide_name, before_local, after_local in transition.get(
        "guide_local_matrices", ()
    ):
        guide = bpy.data.objects.get(str(guide_name))
        expected = before_local if int(index) == 0 else after_local
        current = (
            tuple(guide.get(SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY, ()))
            if guide is not None
            and SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY in guide
            else None
        )
        if current != (None if expected is None else tuple(expected)):
            return False
    return True


def _pin_history_transition_constraint_side_matches(transition, index):
    if not transition or int(index) not in (0, 1):
        return False
    for _owner_key, guide_name, before_state, after_state in transition.get(
        "constraint_states", ()
    ):
        guide = bpy.data.objects.get(str(guide_name))
        expected = before_state if int(index) == 0 else after_state
        if guide is None or _pin_history_constraint_signature(
            _surface_contact_constraint_history_state(guide)
        ) != _pin_history_constraint_signature(expected):
            return False
    return True
