"""Contact pose reconciliation around Blender's native undo and redo stack."""

from ..core.runtime import *  # noqa: F403


def _pin_history_selected_name_state(context):
    grouped = _selected_pose_bones_by_owner(context)
    selected = {
        (str(armature.name), str(pose_bone.name))
        for armature, pose_bones in grouped.items()
        for pose_bone in pose_bones
    }
    active_bone = getattr(context, "active_pose_bone", None)
    active_owner = _pose_bone_owner(
        context,
        active_bone,
        tuple(grouped) or _pose_scope_armatures(context),
    )
    active = (
        (str(active_owner.name), str(active_bone.name))
        if active_owner is not None and active_bone is not None
        else None
    )
    return selected, active


def _pin_attached_camera_history_signature(context):
    """Identify camera add/remove history without touching Contact poses."""
    scene = getattr(context, "scene", None) if context is not None else None
    if scene is None:
        return ()
    signature = []
    for camera in tuple(getattr(scene, "objects", ())):
        if getattr(camera, "type", "") != "CAMERA":
            continue
        armature, bone_name = _camera_bone_binding(camera)
        signature.append((
            str(camera.name),
            str(getattr(armature, "name", "")),
            str(bone_name),
        ))
    return tuple(sorted(signature))


_CONTACT_HISTORY_MATRIX_ELEMENT_TOLERANCE = 2.0e-4
_CONTACT_HISTORY_TRANSLATION_TOLERANCE = 2.0e-4
_CONTACT_HISTORY_ROTATION_TOLERANCE = 2.0e-4
_CONTACT_HISTORY_SCALE_TOLERANCE = 2.0e-4


def _pin_history_matrix_matches(current, expected, epsilon=1.0e-6):
    """Recognize a native history side despite harmless pose recomposition."""
    if current is None or expected is None:
        return current is expected
    tolerance = max(float(epsilon), _CONTACT_HISTORY_MATRIX_ELEMENT_TOLERANCE)
    if not _pin_keyboard_matrices_differ(current, expected, epsilon=tolerance):
        return True
    try:
        current_location, current_rotation, current_scale = current.decompose()
        expected_location, expected_rotation, expected_scale = expected.decompose()
        translation_error = (current_location - expected_location).length
        rotation_error = current_rotation.rotation_difference(
            expected_rotation
        ).angle
        rotation_error = min(
            float(rotation_error),
            abs(math.tau - float(rotation_error)),
        )
        scale_error = max(
            abs(float(current_scale[index]) - float(expected_scale[index]))
            for index in range(3)
        )
    except (
        AttributeError,
        IndexError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ):
        return False
    return bool(
        translation_error
        <= max(float(epsilon), _CONTACT_HISTORY_TRANSLATION_TOLERANCE)
        and rotation_error
        <= max(float(epsilon), _CONTACT_HISTORY_ROTATION_TOLERANCE)
        and scale_error
        <= max(float(epsilon), _CONTACT_HISTORY_SCALE_TOLERANCE)
    )


def _pin_history_transition_side_matches(transition, index, epsilon=1.0e-6):
    if not transition or int(index) not in (0, 1):
        return False
    for entry in transition.get("selected", ()):
        armature_name, bone_name, _before, _native_after, _solved_after = (
            contact_history_selected_entry(entry)
        )
        armature = bpy.data.objects.get(armature_name)
        pose_bone = (
            armature.pose.bones.get(bone_name)
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is None or not any(
            _pin_history_matrix_matches(
                pose_bone.matrix_basis,
                expected,
                epsilon=epsilon,
            )
            for expected in contact_history_entry_candidates(entry, index)
        ):
            return False
    return True


def _pin_history_transition_selected_snapshot(transition):
    snapshot = {}
    if not transition:
        return snapshot
    for entry in transition.get("selected", ()):
        armature_name, bone_name, _before, _native_after, _solved_after = (
            contact_history_selected_entry(entry)
        )
        armature = bpy.data.objects.get(armature_name)
        pose_bone = (
            armature.pose.bones.get(bone_name)
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is not None:
            snapshot[(armature_name, bone_name)] = pose_bone.matrix_basis.copy()
    return snapshot


def _pin_history_transition_selected_changed(snapshot, epsilon=1.0e-7):
    for (armature_name, bone_name), before in dict(snapshot).items():
        armature = bpy.data.objects.get(str(armature_name))
        pose_bone = (
            armature.pose.bones.get(str(bone_name))
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if (
            pose_bone is not None
            and _pin_keyboard_matrices_differ(
                pose_bone.matrix_basis,
                before,
                epsilon=epsilon,
            )
        ):
            return True
    return False


def _pin_history_transition_runtime_snapshot(transition):
    if not transition:
        return ()
    snapshot = []
    for entry in transition.get("selected", ()):
        armature_name, bone_name, _before, _native_after, _solved_after = (
            contact_history_selected_entry(entry)
        )
        armature = bpy.data.objects.get(str(armature_name))
        pose_bone = (
            armature.pose.bones.get(str(bone_name))
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        snapshot.append((
            "SELECTED",
            str(armature_name),
            str(bone_name),
            _pin_history_matrix_signature(
                pose_bone.matrix_basis if pose_bone is not None else None
            ),
        ))
    for entry in transition.get("contacts", ()):
        owner_key, armature_name, bone_name, _before, _native_after, _solved_after = (
            contact_history_contact_entry(entry)
        )
        armature = bpy.data.objects.get(str(armature_name))
        pose_bone = (
            armature.pose.bones.get(str(bone_name))
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        snapshot.append((
            "CONTACT",
            str(owner_key[0]),
            str(owner_key[1]),
            _pin_history_matrix_signature(
                pose_bone.matrix_basis if pose_bone is not None else None
            ),
            _pin_history_matrix_signature(
                pose_bone.matrix if pose_bone is not None else None
            ),
        ))
    frame = int(transition.get("frame", 0))
    for armature_name, bone_name, _before_keys, _after_keys in transition.get(
        "action_keys", ()
    ):
        armature = bpy.data.objects.get(str(armature_name))
        pose_bone = (
            armature.pose.bones.get(str(bone_name))
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        snapshot.append((
            "KEYS",
            str(armature_name),
            str(bone_name),
            _surface_contact_pose_action_key_snapshot(
                armature,
                pose_bone,
                frame,
            ),
        ))
    for owner_key, guide_name, _before_matrix, _after_matrix in transition.get(
        "guide_matrices", ()
    ):
        guide = bpy.data.objects.get(str(guide_name))
        snapshot.append((
            "GUIDE",
            str(owner_key[0]),
            str(owner_key[1]),
            _pin_history_matrix_signature(
                guide.matrix_world if guide is not None else None
            ),
        ))
    for owner_key, guide_name, _before_state, _after_state in transition.get(
        "constraint_states", ()
    ):
        guide = bpy.data.objects.get(str(guide_name))
        snapshot.append((
            "CONSTRAINT",
            str(owner_key[0]),
            str(owner_key[1]),
            _pin_history_constraint_signature(
                _surface_contact_constraint_history_state(guide)
                if guide is not None
                else ()
            ),
        ))
    for owner_key, _before_attached, _after_attached in transition.get(
        "attachments", ()
    ):
        guide = bpy.data.objects.get(str(owner_key[1]))
        snapshot.append((
            "ATTACHMENT",
            str(owner_key[0]),
            str(owner_key[1]),
            _pin_history_attachment_signature(guide),
        ))
    for armature_name, _before_token, _after_token in transition.get(
        "history_tokens", ()
    ):
        armature = bpy.data.objects.get(str(armature_name))
        snapshot.append((
            "TOKEN",
            str(armature_name),
            int(armature.get(
                SURFACE_CONTACT_HISTORY_TOKEN_PROPERTY,
                -1,
            )) if armature is not None else -1,
        ))
    return tuple(snapshot)


def _pin_history_transition_contact_side_matches(
    transition, index, epsilon=1.0e-6
):
    if not transition or int(index) not in (0, 1):
        return False
    for entry in transition.get("contacts", ()):
        _owner_key, armature_name, bone_name, _before, _native, _solved = (
            contact_history_contact_entry(entry)
        )
        armature = bpy.data.objects.get(armature_name)
        pose_bone = (
            armature.pose.bones.get(bone_name)
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is None or not any(
            _pin_history_matrix_matches(
                pose_bone.matrix_basis,
                expected,
                epsilon=epsilon,
            )
            for expected in contact_history_entry_candidates(
                entry, index, owner=True
            )
        ):
            return False
    return True


def _pin_history_transition_visual_side_matches(
    transition, index, epsilon=1.0e-6
):
    if not transition or int(index) not in (0, 1):
        return False
    for entry in transition.get("visual_poses", ()):
        _owner_key, armature_name, bone_name, before, _native, solved = (
            _surface_contact_history_owner_entry(entry)
        )
        armature = bpy.data.objects.get(armature_name)
        pose_bone = (
            armature.pose.bones.get(bone_name)
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        expected = before if int(index) == 0 else solved
        if (
            pose_bone is None
            or not _pin_history_matrix_matches(
                pose_bone.matrix,
                expected,
                epsilon=epsilon,
            )
        ):
            return False
    return True


def _pin_history_transition_action_side_matches(transition, index):
    if not transition or int(index) not in (0, 1):
        return False
    frame = int(transition.get("frame", 0))
    for armature_name, bone_name, before_keys, after_keys in transition.get(
        "action_keys", ()
    ):
        armature = bpy.data.objects.get(str(armature_name))
        pose_bone = (
            armature.pose.bones.get(str(bone_name))
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        expected = before_keys if int(index) == 0 else after_keys
        current = _surface_contact_pose_action_key_snapshot(
            armature, pose_bone, frame
        )
        if _dynamic_parent_pose_key_snapshot_signature(
            current
        ) != _dynamic_parent_pose_key_snapshot_signature(expected):
            return False
    return True


def _pin_history_transition_attachment_side_matches(transition, index):
    if not transition or int(index) not in (0, 1):
        return False
    for owner_key, before_attached, after_attached in transition.get(
        "attachments", ()
    ):
        guide = bpy.data.objects.get(str(owner_key[1]))
        if guide is None:
            return False
        snap_key = _surface_contact_snap_key(guide)
        expected = bool(before_attached if int(index) == 0 else after_attached)
        attached = bool(
            snap_key in _state.setdefault("pin_snap_latches", set())
            and snap_key not in _state.setdefault("pin_snap_detached", set())
            and snap_key not in _state.setdefault(
                "pin_snap_transform_releasing", set()
            )
            and not bool(
                guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)
            )
        )
        if attached != expected:
            return False
    return True


def _pin_history_transition_restored_matches(transition, index):
    return bool(
        _pin_history_transition_side_matches(
            transition, index, epsilon=1.0e-6
        )
        and _pin_history_transition_contact_side_matches(
            transition, index, epsilon=1.0e-6
        )
        and _pin_history_transition_visual_side_matches(
            transition, index, epsilon=1.0e-6
        )
        and _pin_history_transition_action_side_matches(transition, index)
        and _pin_history_transition_attachment_side_matches(transition, index)
        and _pin_history_transition_guide_side_matches(transition, index)
        and _pin_history_transition_constraint_side_matches(transition, index)
    )


def _pin_history_filter_lock_entries(entries, excluded_owners):
    excluded_owners = {
        (str(owner[0]), str(owner[1])) for owner in excluded_owners
    }
    return tuple(
        entry
        for entry in entries
        if (str(entry[0]), str(entry[1])) not in excluded_owners
    )


def _pin_history_settle_previous_lock(context):
    """Commit the preceding history side before another rapid Ctrl+Z/Y."""
    if not _state.get("pin_history_contact_pose_lock", ()):
        return False
    try:
        return _surface_contact_apply_history_pose_lock(
            context,
            update_view_layer=True,
        )
    except (
        AttributeError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ):
        return False


def _pin_history_prepare(direction):
    context = bpy.context
    # Blender rebuilds ID/RNA storage at every native history boundary. Never
    # let playback caches hand pre-Undo guide or PoseBone wrappers to a new
    # snapshot.
    _surface_contact_invalidate_guide_cache()
    _pin_history_settle_previous_lock(context)
    _surface_contact_clear_history_pose_lock()
    _dynamic_parent_stage_pending_history_transition(context)
    _state["pin_history_direction"] = str(direction).upper()
    _state["pin_history_active"] = True
    _state["pin_history_syncing"] = True
    _state["pin_history_selection_only_step"] = False
    _state["pin_history_selection_only"] = False
    _state["pin_history_pre_pose_selection_signature"] = (
        _pin_pose_selection_signature(context)
    )
    _state["pin_history_selection_snapshot"] = (
        _pin_selection_runtime_snapshot()
    )
    _state["pin_history_pre_contact_runtime_snapshot"] = (
        _pin_contact_runtime_snapshot(context)
    )
    _state["pin_history_pre_attached_camera_signature"] = (
        _pin_attached_camera_history_signature(context)
    )
    # Structural marker identity is the only Dynamic Parent/Unparent state
    # needed before native history moves its cursor. Capturing this small,
    # order-independent signature lets undo_post rebuild an added/removed
    # relationship without snapshotting or replaying follower poses.
    _state["dynamic_space_history_pre_marker_signature"] = (
        _dynamic_space_marker_signature()
    )

    undo_stack = _state.setdefault(
        "pin_snap_native_history_transitions", []
    )
    redo_stack = _state.setdefault(
        "pin_snap_native_history_redo_stack", []
    )
    transition = contact_history_candidate(
        direction,
        undo_stack,
        redo_stack,
    )
    source_index = contact_history_source_index(direction)
    target_index = contact_history_target_index(direction)
    selected, active = _pin_history_selected_name_state(context)
    source_matches = _pin_history_transition_side_matches(
        transition,
        source_index,
        epsilon=_CONTACT_HISTORY_MATRIX_ELEMENT_TOLERANCE,
    )
    transition_kind = str((transition or {}).get("kind", "BONE"))
    if transition_kind == "TARGET":
        # The constrained limb may receive a late dependency evaluation after
        # a target move. The guide's persisted local/world side remains the
        # stable identity of that undoable operator.
        source_matches = _pin_history_transition_guide_side_matches(
            transition,
            source_index,
        )
    elif transition:
        # Blender may recompose a constrained pink bone's raw matrix between
        # mouse-up and undo_pre. Recognize the exact evaluated Contact pose or
        # persistent attachment side too, so the movement checkpoint is not
        # skipped merely because matrix_basis no longer equals its modal copy.
        source_matches = bool(
            source_matches
            or _pin_history_transition_contact_side_matches(
                transition,
                source_index,
                epsilon=_CONTACT_HISTORY_MATRIX_ELEMENT_TOLERANCE,
            )
            or _pin_history_transition_visual_side_matches(
                transition,
                source_index,
                epsilon=_CONTACT_HISTORY_MATRIX_ELEMENT_TOLERANCE,
            )
            or _pin_history_transition_native_state_side_matches(
                transition,
                source_index,
            )
        )
    predicted = contact_history_predict_transform(
        transition,
        selected,
        active,
        source_matches,
    )

    full_lock = _surface_contact_current_history_pose_entries(
        context,
        include_detached=True,
    )
    direct_contact_owners = (
        contact_history_contact_owners(transition)
        & contact_history_selected_keys(transition)
        if predicted
        else frozenset()
    )
    active_lock = (
        _pin_history_filter_lock_entries(
            full_lock,
            direct_contact_owners,
        )
        if predicted
        else ()
    )
    _state["pin_history_pre_contact_pose_lock"] = full_lock
    _state["pin_history_pre_active_contact_pose_lock"] = active_lock
    _state["pin_history_contact_transition"] = transition
    _state["pin_history_contact_transition_predicted"] = predicted
    _state["pin_history_contact_transition_source_index"] = source_index
    _state["pin_history_contact_transition_target_index"] = target_index
    selected_snapshot = _pin_history_transition_selected_snapshot(transition)
    _state["pin_history_contact_transition_selected"] = selected_snapshot
    _state["pin_history_contact_transition_runtime_before"] = (
        _pin_history_transition_runtime_snapshot(transition)
    )
    _state["pin_snap_native_history_transition"] = transition
    _state["pin_snap_native_history_transition_backup"] = transition
    _state["pin_snap_native_history_expected_index"] = target_index
    _state["pin_snap_native_history_pre_selected"] = selected_snapshot
    _state["pin_snap_native_history_pre_tokens"] = {
        str(armature_name): int(armature.get(
            SURFACE_CONTACT_HISTORY_TOKEN_PROPERTY,
            -1,
        ))
        for armature_name, _before_token, _after_token
        in tuple((transition or {}).get("history_tokens", ()))
        if (armature := bpy.data.objects.get(str(armature_name))) is not None
    }
    _surface_contact_merge_history_pose_lock(active_lock)

    # A jointly transformed Dynamic Parent child is compensated and keyed in
    # the same native G/R/S transaction.  Blender restores the raw selected
    # bones, but not the final compensated follower evaluation, so prepare the
    # already-recorded exact sides while every pre-history RNA wrapper is
    # still valid.  The post handler only consumes this one paired transition;
    # it never creates an additional native history checkpoint.
    _state["dynamic_parent_history_snapshot"] = ()
    _dynamic_parent_prepare_native_history_transition(context)
    return transition


def _pin_history_compatibility_symbols():
    return (
        _surface_contact_history_snapshot,
        _surface_contact_restore_history_poses,
        _pin_nonhistory_snapshot,
        _restore_pin_nonhistory_snapshot,
        _pin_history_capture_selection,
        _pin_history_restore_selection,
        _surface_contact_reconcile_history_magnetism,
        _surface_contact_set_current_history_pose_lock,
        _pin_contact_runtime_snapshot,
        _pin_contact_runtime_restore,
    )


@persistent
def _pin_undo_pre(*_):
    _pin_history_prepare("UNDO")


@persistent
def _pin_redo_pre(*_):
    _pin_history_prepare("REDO")


def _pin_history_transition_completed(
    context,
    transition,
    target_index,
    selection_changed,
):
    del context
    predicted = bool(
        transition
        and int(target_index) in (0, 1)
        and _state.get("pin_history_contact_transition_predicted", False)
    )
    selected_changed = bool(
        predicted
        and _pin_history_transition_selected_changed(
            _state.get("pin_history_contact_transition_selected", {})
        )
    )
    runtime_changed = bool(
        predicted
        and _pin_history_transition_runtime_snapshot(transition)
        != _state.get("pin_history_contact_transition_runtime_before", ())
    )
    state_target_matches = bool(
        runtime_changed
        and _pin_history_transition_native_state_side_matches(
            transition, target_index
        )
    )
    transition_kind = str((transition or {}).get("kind", "BONE"))
    # Target operations can move their constrained limb as a dependency, so
    # their guide/key/attachment side is the authoritative discriminator.
    # A pure pink-bone rotation with Auto Key disabled has no persistent side
    # change beyond its pose, however, and must remain undoable. Target moves
    # now own first-class transitions, keeping the older bone transition below
    # them instead of forcing this bone-only fallback to guess across steps.
    transition_changed = bool(
        state_target_matches
        or (transition_kind != "TARGET" and selected_changed)
    )
    target_matches = bool(
        predicted
        and (
            (
                transition_kind == "TARGET"
                and state_target_matches
            )
            or _pin_history_transition_side_matches(
                transition,
                target_index,
                epsilon=_CONTACT_HISTORY_MATRIX_ELEMENT_TOLERANCE,
            )
            # Complex rigs can recompose a constrained Contact bone before
            # undo_post runs, so its raw matrix may match neither captured
            # side. A changed exact guide/key/constraint/attachment side is
            # still an unambiguous native checkpoint and can restore the
            # paired authored pose.
            or state_target_matches
        )
    )
    return contact_history_transition_completed(
        predicted,
        selection_changed,
        transition_changed,
        target_matches,
    )


def _pin_history_restore_pre_contact_lock(context, *, restore_data=True):
    if restore_data:
        snapshot = _state.get("pin_history_pre_contact_runtime_snapshot")
        if snapshot and _pin_contact_runtime_restore(
            context, snapshot, update_view_layer=True
        ):
            return True
    entries = tuple(_state.get("pin_history_pre_contact_pose_lock", ()))
    if not restore_data:
        changed_pose_owners = set()
        snapshot = _state.get("pin_history_pre_contact_runtime_snapshot") or {}
        for entry in tuple(snapshot.get("entries", ())):
            guide = bpy.data.objects.get(str(entry.get("guide", "")))
            expected = entry.get("guide_matrix")
            if (
                guide is not None
                and expected is not None
                and _pin_keyboard_matrices_differ(
                    guide.matrix_world,
                    expected,
                    epsilon=1.0e-8,
                )
            ):
                changed_pose_owners.add((
                    str(entry.get("armature", "")),
                    str(entry.get("bone", "")),
                ))
        entries = tuple(
            entry
            for entry in entries
            if (str(entry[0]), str(entry[1])) not in changed_pose_owners
        )
    _surface_contact_merge_history_pose_lock(entries)
    if entries:
        _surface_contact_apply_history_pose_lock(
            context, update_view_layer=True
        )
    return bool(entries)


def _pin_history_restore_transition(context, transition, target_index):
    contact_owners = contact_history_contact_owners(transition)
    pre_entries = tuple(_state.get("pin_history_pre_contact_pose_lock", ()))
    unrelated = _pin_history_filter_lock_entries(
        pre_entries,
        contact_owners,
    )
    _surface_contact_merge_history_pose_lock(unrelated)
    if not _surface_contact_apply_native_history_transition(
        context,
        transition,
        target_index,
        append_lock=True,
    ):
        _pin_history_restore_pre_contact_lock(context)
        return False
    token_authoritative = bool(
        tuple((transition or {}).get("history_tokens", ()))
        and _pin_history_transition_native_state_side_matches(
            transition,
            target_index,
        )
    )
    if (
        not token_authoritative
        and not _pin_history_transition_restored_matches(
            transition, target_index
        )
    ):
        _pin_history_restore_pre_contact_lock(context)
        return False
    return True


def _pin_history_deferred_runtime_sync():
    context = bpy.context
    if (
        context is None
        or getattr(context, "scene", None) is None
    ):
        return None
    if (
        _state.get("pin_history_active", False)
        or _state.get("pin_history_syncing", False)
    ):
        return 0.02
    try:
        guides = tuple(
            _surface_contact_active_simulated_guides(context.scene)
        )
        _surface_contact_seed_runtime_signatures(context, guides)
        _pin_cache_idle_transform_poses(context)
        if _refresh_attached_camera_transforms(context):
            _schedule_attached_camera_transform_restore(0.05)
    except (
        AttributeError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ):
        pass
    return None


def _pin_history_finish_runtime(context):
    # Never author keys or persistent ID properties from undo_post/redo_post.
    # The transition restore above already applies its captured matrices,
    # attachment state, and exact Action-key snapshots. Additional writes here
    # create a pose-invisible history mutation and can destroy the next Redo.
    _pin_clear_transform_state()
    _pin_cache_idle_transform_poses(context)
    _schedule_pin_history_visibility_clear()
    try:
        if bpy.app.timers.is_registered(_pin_history_deferred_runtime_sync):
            bpy.app.timers.unregister(_pin_history_deferred_runtime_sync)
        register_owned_timer(
            _pin_history_deferred_runtime_sync,
            first_interval=0.02,
        )
    except (RuntimeError, ValueError):
        pass
    _tag_redraw_all_view3d()


def _pin_history_clear_prepared_state():
    _state["pin_history_contact_snapshot"] = None
    _state["pin_history_nonhistory_snapshot"] = None
    _state["pin_history_selection_snapshot"] = None
    _state["pin_history_direction"] = ""
    _state["pin_history_pre_pose_selection_signature"] = ()
    _state["pin_history_pre_contact_pose_lock"] = ()
    _state["pin_history_pre_active_contact_pose_lock"] = ()
    _state["pin_history_pre_contact_runtime_snapshot"] = None
    _state["pin_history_pre_attached_camera_signature"] = ()
    _state["pin_history_contact_transition"] = None
    _state["pin_history_contact_transition_predicted"] = False
    _state["pin_history_contact_transition_source_index"] = None
    _state["pin_history_contact_transition_target_index"] = None
    _state["pin_history_contact_transition_selected"] = {}
    _state["pin_history_contact_transition_runtime_before"] = ()
    _state["pin_snap_native_history_expected_index"] = None
    _state["pin_snap_native_history_pre_selected"] = {}
    _state["pin_snap_native_history_pre_tokens"] = {}
    _state["pin_history_syncing"] = False


@persistent
def _pin_undo_post(*_):
    context = bpy.context
    if context is None or getattr(context, "scene", None) is None:
        _state["pin_history_active"] = False
        _pin_history_clear_prepared_state()
        return
    # The wrappers captured before native Undo/Redo are invalid now. Rebuild
    # all Contact indexes from stable names before reading the restored side.
    _surface_contact_invalidate_guide_cache()
    direction = str(_state.get("pin_history_direction", "UNDO")).upper()
    transition = _state.get("pin_history_contact_transition")
    target_index = _state.get(
        "pin_history_contact_transition_target_index"
    )
    previous_selection = _state.get(
        "pin_history_pre_pose_selection_signature", ()
    )
    selection_changed = bool(
        previous_selection != _pin_pose_selection_signature(context)
    )
    attached_camera_changed = bool(
        tuple(_state.get(
            "pin_history_pre_attached_camera_signature", ()
        ))
        != _pin_attached_camera_history_signature(context)
    )
    transition_restored = False
    try:
        transition_completed = _pin_history_transition_completed(
            context,
            transition,
            target_index,
            selection_changed,
        )
        native_transition_completed = bool(
            transition
            and target_index in (0, 1)
            and _pin_history_transition_restored_matches(
                transition,
                target_index,
            )
        )
        source_index = _state.get(
            "pin_history_contact_transition_source_index"
        )
        source_side_still_matches = bool(
            transition
            and source_index in (0, 1)
            and (
                _pin_history_transition_side_matches(
                    transition,
                    source_index,
                    epsilon=_CONTACT_HISTORY_MATRIX_ELEMENT_TOLERANCE,
                )
                or _pin_history_transition_contact_side_matches(
                    transition,
                    source_index,
                    epsilon=_CONTACT_HISTORY_MATRIX_ELEMENT_TOLERANCE,
                )
                or _pin_history_transition_visual_side_matches(
                    transition,
                    source_index,
                    epsilon=_CONTACT_HISTORY_MATRIX_ELEMENT_TOLERANCE,
                )
                or _pin_history_transition_native_state_side_matches(
                    transition,
                    source_index,
                )
            )
        )
        # Blender can restore an unconstrained intermediate matrix rather than
        # either captured Contact side.  The operation is still unambiguous
        # when its exact source matched in undo_pre/redo_pre and that source
        # changed across the native boundary.  A selection-only checkpoint
        # leaves the source pose untouched, so it remains unconsumed.
        transition_completed = bool(
            transition_completed
            or (
                _state.get(
                    "pin_history_contact_transition_predicted", False
                )
                and not source_side_still_matches
            )
        )
        if transition_completed:
            transition_restored = _pin_history_restore_transition(
                context,
                transition,
                target_index,
            )
            if transition_restored:
                contact_history_advance(
                    direction,
                    transition,
                    _state.setdefault(
                        "pin_snap_native_history_transitions", []
                    ),
                    _state.setdefault(
                        "pin_snap_native_history_redo_stack", []
                    ),
                )
                _state["pin_history_native_transition_restored"] = True
            else:
                # A failed custom restore must not overwrite Blender's native
                # history result. That made one pink limb appear permanently
                # frozen across every later Undo and Redo operation.
                _surface_contact_clear_history_pose_lock()
                _state["pin_history_native_transition_restored"] = False
            _state["pin_history_selection_only"] = False
            _state["pin_history_selection_only_step"] = False
            _state.pop(
                "surface_contact_selection_history_guard_until", None
            )
        elif native_transition_completed:
            # Blender already restored this exact Contact side. Advance only
            # the in-memory pairing cursor; do not write a pose lock over the
            # native result. This keeps mixed-bone Undo/Redo stacks aligned
            # even when selection changes in the same checkpoint.
            contact_history_advance(
                direction,
                transition,
                _state.setdefault(
                    "pin_snap_native_history_transitions", []
                ),
                _state.setdefault(
                    "pin_snap_native_history_redo_stack", []
                ),
            )
            _surface_contact_clear_history_pose_lock()
            _state["pin_history_native_transition_restored"] = False
            _state["pin_history_selection_only"] = False
            _state["pin_history_selection_only_step"] = False
            _state.pop(
                "surface_contact_selection_history_guard_until", None
            )
        elif selection_changed and not attached_camera_changed:
            # A native selection checkpoint can sit between two Contact
            # transforms. Blender can re-evaluate an indirectly driven pink
            # limb from its unconstrained basis when the active bone changes
            # (for example Contact leg -> Torso), leaving the endpoint at a
            # small angle from its attached target. Re-run only the evaluated
            # magnet solve for contacts driven by the newly selected ancestor.
            # This deliberately does not restore Action keys, detach
            # properties, guide matrices, constraints, or a broad pose lock;
            # those writes would invalidate the movement waiting in Redo.
            _surface_contact_clear_history_pose_lock()
            _state["pin_history_native_transition_restored"] = False
            _state["pin_history_selection_only"] = True
            _state["pin_history_selection_only_step"] = True
            _state["surface_contact_selection_history_guard_until"] = (
                time.perf_counter() + 0.35
            )
        else:
            # Blender has moved its native history cursor through a step that
            # is not the pending pink-bone transition (target-pin movement,
            # regular bone movement, or another add-on operator). Restoring the
            # full pre-Undo runtime snapshot here writes the old ID state back
            # over Blender's result: the step looks blank while Redo is already
            # advanced or discarded. Preserve native data and lock only truly
            # unaffected contact poses.
            _surface_contact_clear_history_pose_lock()
            _state["pin_history_native_transition_restored"] = False
            _state["pin_history_selection_only"] = False
            _state["pin_history_selection_only_step"] = False
            _state.pop(
                "surface_contact_selection_history_guard_until", None
            )
        if (
            selection_changed
            and not attached_camera_changed
            and not transition_restored
            and not native_transition_completed
        ):
            # A Contact transform checkpoint can restore selection along with
            # its pose. Reconcile only when no exact paired/native Contact side
            # was restored; those sides already contain their authoritative
            # solved matrix and another solve would rotate them a second time.
            if _surface_contact_reconcile_history_magnetism(context):
                context.view_layer.update()
        _pin_history_finish_runtime(context)
    except (
        AttributeError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ) as exc:
        print(f"[Roblox Animator Utils] Pin history sync failed: {exc}")
        try:
            _surface_contact_clear_history_pose_lock()
        except (
            AttributeError,
            ReferenceError,
            RuntimeError,
            TypeError,
            ValueError,
        ):
            _surface_contact_clear_history_pose_lock()
        _state["pin_history_active"] = False
    finally:
        _pin_history_clear_prepared_state()
