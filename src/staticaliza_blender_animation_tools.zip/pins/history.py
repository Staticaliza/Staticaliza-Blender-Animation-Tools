"""Pin undo and redo state reconciliation."""

from ..core.runtime import *  # noqa: F403


def _surface_contact_history_driver_signature(
    context, armature, pose_bone
):
    selected = {
        selected_bone.name
        for selected_bone in _selected_pose_bones_by_owner(context).get(
            armature, ()
        )
    }
    signature = []
    current = getattr(pose_bone, "parent", None)
    while current is not None:
        if current.name in selected:
            world = armature.matrix_world @ current.matrix
            signature.append((
                current.name,
                tuple(
                    round(float(value), 8)
                    for row in world
                    for value in row
                ),
            ))
        current = current.parent
    return tuple(signature)


def _surface_contact_history_snapshot(context):
    scene = getattr(context, "scene", None) if context is not None else None
    if scene is None:
        return {
            "targets": {},
            "poses": {},
            "pose_matrices": {},
            "drivers": {},
            "engaged": set(),
            "selected": set(),
        }
    targets = {}
    poses = {}
    pose_matrices = {}
    drivers = {}
    engaged = set()
    selected = set()
    detached_keys = _state.setdefault("pin_snap_detached", set())
    departing_keys = _state.setdefault("pin_snap_departing", set())
    for guide in _surface_contact_active_simulated_guides(scene):
        armature = bpy.data.objects.get(
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
        )
        owner_key = (_armature_session_uid(armature), guide.name)
        matrix = guide.matrix_world.copy()
        targets[owner_key] = tuple(
            round(float(value), 8)
            for row in matrix
            for value in row
        )
        pose_bone = (
            armature.pose.bones.get(
                str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
            )
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if pose_bone is not None:
            poses[owner_key] = tuple(
                round(float(value), 8)
                for row in pose_bone.matrix_basis
                for value in row
            )
            pose_matrices[owner_key] = pose_bone.matrix_basis.copy()
            drivers[owner_key] = _surface_contact_history_driver_signature(
                context,
                armature,
                pose_bone,
            )
        if _surface_contact_guide_directly_selected(context, guide):
            selected.add(owner_key)
        snap_key = _surface_contact_snap_key(guide)
        if (
            snap_key not in departing_keys
            and snap_key not in detached_keys
            and not bool(
                guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)
            )
        ):
            engaged.add(owner_key)
    return {
        "targets": targets,
        "poses": poses,
        "pose_matrices": pose_matrices,
        "drivers": drivers,
        "engaged": engaged,
        "selected": selected,
    }


def _surface_contact_restore_history_poses(
    context,
    snapshot,
    *,
    update_view_layer=True,
    owner_keys=None,
):
    """Keep unrelated Undo/Redo from re-evaluating contact-owned limbs."""
    changed = False
    matrices = dict((snapshot or {}).get("pose_matrices", {}))
    owner_keys = None if owner_keys is None else set(owner_keys)
    for guide in _surface_contact_active_simulated_guides(context.scene):
        armature = bpy.data.objects.get(
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
        )
        owner_key = (_armature_session_uid(armature), guide.name)
        if owner_keys is not None and owner_key not in owner_keys:
            continue
        matrix_basis = matrices.get(owner_key)
        pose_bone = _surface_contact_simulated_pose_bone(guide)
        if (
            matrix_basis is not None
            and pose_bone is not None
            and _pin_keyboard_matrices_differ(
                pose_bone.matrix_basis,
                matrix_basis,
            )
        ):
            pose_bone.matrix_basis = matrix_basis.copy()
            changed = True
    if changed and update_view_layer:
        context.view_layer.update()
    return changed


def _pin_nonhistory_snapshot(context):
    """Capture pin membership/onion visibility, which are UI state, not edits."""
    scene = getattr(context, "scene", None) if context is not None else None
    if scene is None:
        return {"owners": {}, "pins": {}}
    enabled = set(_state.get("onion_enabled_owners", set()))
    owners = {}
    armature_access = {}
    pins = {}
    for armature in tuple(getattr(scene, "objects", ())):
        if armature.type != "ARMATURE" or getattr(armature, "pose", None) is None:
            continue
        owner_key = (_armature_session_uid(armature), armature.name)
        owners[owner_key] = bool(
            owner_key[0] in enabled
            or armature.get(ONION_SKIN_ENABLED_PROPERTY, False)
        )
        try:
            armature_access[owner_key] = {
                "hide_viewport": bool(armature.hide_viewport),
                "hide_select": bool(armature.hide_select),
                "hidden": bool(armature.hide_get()),
            }
        except (AttributeError, ReferenceError, RuntimeError):
            pass
        runtime_modes = _yellow_owner_map("yellow_modes", armature)
        runtime_fixed = _yellow_owner_map("yellow_fixed", armature)
        for pose_bone in armature.pose.bones:
            runtime = runtime_fixed.get(pose_bone.name)
            stored_target = pose_bone.get(YELLOW_PIN_TARGET_PROPERTY)
            exists = bool(
                pose_bone.name in runtime_modes
                or runtime is not None
                or stored_target is not None
            )
            if not exists:
                continue
            try:
                mode = int(pose_bone.get(
                    YELLOW_PIN_MODE_PROPERTY,
                    runtime_modes.get(pose_bone.name, 1),
                ))
            except (TypeError, ValueError):
                mode = 1
            target = stored_target
            if target is None and runtime is not None:
                target = runtime[0]
            try:
                target = tuple(float(value) for value in target[:3])
            except (IndexError, TypeError, ValueError):
                target = None
            initial_target = pose_bone.get(
                YELLOW_PIN_INITIAL_TARGET_PROPERTY,
                target,
            )
            try:
                initial_target = tuple(
                    float(value) for value in initial_target[:3]
                )
            except (IndexError, TypeError, ValueError):
                initial_target = target
            pins[(owner_key[0], owner_key[1], pose_bone.name)] = {
                "mode": max(1, min(5, mode)),
                "axis": str(
                    pose_bone.get(YELLOW_PIN_AXIS_PROPERTY, "Y_NEG")
                ),
                "target": target,
                "initial_target": initial_target,
            }
    return {
        "owners": owners,
        "pins": pins,
        "armature_access": armature_access,
    }


def _restore_pin_nonhistory_snapshot(context, snapshot):
    """Keep pin add/remove and onion enable state outside undo/redo history."""
    if not snapshot or context is None or getattr(context, "scene", None) is None:
        return False
    owners = dict(snapshot.get("owners", {}))
    pins = dict(snapshot.get("pins", {}))
    armature_access = dict(snapshot.get("armature_access", {}))
    armatures_by_uid = {}
    armatures_by_name = {}
    for armature in tuple(context.scene.objects):
        if armature.type != "ARMATURE" or getattr(armature, "pose", None) is None:
            continue
        armatures_by_uid[_armature_session_uid(armature)] = armature
        armatures_by_name[armature.name] = armature

    changed = False
    runtime_rebuild_needed = set(owners) != {
        (_armature_session_uid(armature), armature.name)
        for armature in armatures_by_uid.values()
    }
    for owner_key, onion_enabled in owners.items():
        owner_uid, owner_name = owner_key
        armature = armatures_by_uid.get(int(owner_uid))
        if armature is None:
            armature = armatures_by_name.get(str(owner_name))
        if armature is None:
            continue
        access = armature_access.get(owner_key)
        if access is not None:
            try:
                armature.hide_viewport = bool(access.get("hide_viewport", False))
                armature.hide_select = bool(access.get("hide_select", False))
                armature.hide_set(bool(access.get("hidden", False)))
            except (AttributeError, ReferenceError, RuntimeError):
                pass
        for pose_bone in armature.pose.bones:
            pin_key = (int(owner_uid), str(owner_name), pose_bone.name)
            desired = pins.get(pin_key)
            if desired is None:
                for property_name in (
                    YELLOW_PIN_TARGET_PROPERTY,
                    YELLOW_PIN_MODE_PROPERTY,
                    YELLOW_PIN_AXIS_PROPERTY,
                    YELLOW_PIN_INITIAL_TARGET_PROPERTY,
                ):
                    if property_name in pose_bone:
                        del pose_bone[property_name]
                        changed = True
                        runtime_rebuild_needed = True
                continue
            desired_mode = int(desired.get("mode", 1))
            if int(pose_bone.get(YELLOW_PIN_MODE_PROPERTY, 0)) != desired_mode:
                pose_bone[YELLOW_PIN_MODE_PROPERTY] = desired_mode
                changed = True
                runtime_rebuild_needed = True
            desired_axis = str(desired.get("axis", "Y_NEG"))
            if str(
                pose_bone.get(YELLOW_PIN_AXIS_PROPERTY, "Y_NEG")
            ) != desired_axis:
                pose_bone[YELLOW_PIN_AXIS_PROPERTY] = desired_axis
                changed = True
                runtime_rebuild_needed = True
            initial_target = desired.get("initial_target")
            if (
                initial_target is not None
                and tuple(pose_bone.get(
                    YELLOW_PIN_INITIAL_TARGET_PROPERTY,
                    (),
                )) != tuple(initial_target)
            ):
                pose_bone[YELLOW_PIN_INITIAL_TARGET_PROPERTY] = tuple(
                    initial_target
                )
                changed = True
                runtime_rebuild_needed = True
            # When history removed the pin itself, put back its last target.
            # The first movement undo must land at the spawn point, never at
            # the moved snapshot that happened to exist before undo started.
            # When it exists on both sides, retain Blender's restored target so
            # later pin movements remain normally undoable and redoable.
            if YELLOW_PIN_TARGET_PROPERTY not in pose_bone:
                target = desired.get("initial_target") or desired.get("target")
                if target is not None:
                    pose_bone[YELLOW_PIN_TARGET_PROPERTY] = tuple(target)
                    changed = True
                    runtime_rebuild_needed = True
        desired_onion = bool(onion_enabled)
        if bool(armature.get(ONION_SKIN_ENABLED_PROPERTY, False)) != desired_onion:
            armature[ONION_SKIN_ENABLED_PROPERTY] = desired_onion
            changed = True
            runtime_rebuild_needed = True

    # Rebuild all runtime maps from the restored data. This also revives a
    # fully deleted rig after Ctrl+Z and prunes it again after Ctrl+Shift+Z.
    if not runtime_rebuild_needed:
        return changed
    alive_uids = set(armatures_by_uid)
    _state["yellow_fixed"] = {}
    _state["yellow_modes"] = {}
    _state["yellow_hidden"] = set()
    _state["onion_enabled_owners"] = {
        uid
        for uid, armature in armatures_by_uid.items()
        if bool(armature.get(ONION_SKIN_ENABLED_PROPERTY, False))
    }
    for state_name in ("mesh_batches", "raycast_fixed"):
        _state[state_name] = {
            key: value
            for key, value in _state.get(state_name, {}).items()
            if int(key) in alive_uids
        }
    _restore_persistent_runtime_state(context)
    return changed


def _pin_history_capture_selection():
    snapshot = _pin_selection_runtime_snapshot()
    _state["pin_history_selection_snapshot"] = snapshot
    return snapshot


def _pin_history_restore_selection(context):
    historical = _pin_selection_history_load(context)
    return _pin_selection_runtime_restore(
        context,
        historical
        if historical is not None
        else _state.get("pin_history_selection_snapshot"),
    )


def _surface_contact_reconcile_history_magnetism(
    context, owner_keys=None
):
    """Repair only contacts indirectly driven by the restored selection."""
    owner_keys = None if owner_keys is None else set(owner_keys)
    grouped = _selected_pose_bones_by_owner(context)
    selected_by_name = {
        armature.name: {pose_bone.name for pose_bone in selected}
        for armature, selected in grouped.items()
    }
    changed = False
    detached_keys = _state.setdefault("pin_snap_detached", set())
    for guide in _surface_contact_active_simulated_guides(context.scene):
        armature = bpy.data.objects.get(str(
            guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, "")
        ))
        owner_key = (_armature_session_uid(armature), guide.name)
        if owner_keys is not None and owner_key not in owner_keys:
            continue
        armature_name = str(
            guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, "")
        )
        selected_names = selected_by_name.get(armature_name)
        if not selected_names:
            continue
        if (
            _surface_contact_direct_bone_names(guide) & selected_names
            or not _surface_contact_selected_bones_drive_guide(
                armature,
                guide,
                selected_names,
            )
        ):
            continue
        snap_key = _surface_contact_snap_key(guide)
        detached = bool(
            guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)
            or snap_key in detached_keys
        )
        if detached:
            # Ancestor Undo/Redo must reproduce the same detached magnetic
            # preview as live G/R/S, but it must remain detached (no ring and
            # no true snap). Use the one-pass rod solve rather than the
            # attached constraint solver.
            changed = bool(
                _surface_contact_solve_detached_target_motion(context, guide)
            ) or changed
            continue
        target, _normal, anchor = _surface_contact_world_point_normal(
            context,
            guide,
        )
        if (
            target is None
            or anchor is None
            or (Vector(target) - Vector(anchor)).length
            <= _surface_contact_settle_tolerance(guide)
        ):
            continue
        changed = bool(
            _surface_contact_enforce_guide(
                context,
                guide,
                force_contact=True,
                insert_keys=False,
                use_snap_hysteresis=False,
                allow_snap=True,
            )
        ) or changed
    return changed


@persistent
def _pin_history_pre(*_):
    # Gizmo groups can be rebuilt before undo_post/redo_post. Mark history up
    # front so that rebuilds preserve runtime-only handle visibility.
    _state["pin_history_active"] = True
    _state["pin_history_syncing"] = True
    _surface_contact_clear_history_pose_lock()
    _pin_history_capture_selection()
    _dynamic_parent_capture_history_snapshot(bpy.context)
    _dynamic_parent_prepare_native_history_transition()
    _surface_contact_prepare_native_history_transition(bpy.context)
    if bpy.app.timers.is_registered(_clear_pin_history_visibility):
        bpy.app.timers.unregister(_clear_pin_history_visibility)
    try:
        _state["pin_history_contact_snapshot"] = (
            _surface_contact_history_snapshot(bpy.context)
        )
        # Undo/Redo evaluates Actions before its post handler.  Lock contacts
        # that the selected history owner cannot drive during that interval,
        # including detached pink limbs.  Otherwise an unrelated limb edit
        # can expose one keyed/stale pink pose for a viewport frame and only
        # then be corrected by undo_post/redo_post.
        context = bpy.context
        grouped = _selected_pose_bones_by_owner(context)
        selected_by_name = {
            armature.name: {bone.name for bone in bones}
            for armature, bones in grouped.items()
        }
        untouched_contact_keys = set()
        for guide in _surface_contact_active_simulated_guides(context.scene):
            armature = bpy.data.objects.get(str(
                guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, "")
            ))
            selected_names = selected_by_name.get(
                getattr(armature, "name", ""), set()
            )
            if (
                _surface_contact_direct_bone_names(guide) & selected_names
                or _surface_contact_selected_bones_drive_guide(
                    armature, guide, selected_names
                )
                or _pin_selected_pose_drives_contact_target(
                    guide, selected_by_name
                )
            ):
                continue
            untouched_contact_keys.add((
                _armature_session_uid(armature), guide.name,
            ))
        _surface_contact_set_current_history_pose_lock(
            context,
            untouched_contact_keys,
            include_detached=True,
            append=True,
        )
        _state["pin_history_nonhistory_snapshot"] = (
            _pin_nonhistory_snapshot(bpy.context)
        )
    except (
        AttributeError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ) as exc:
        print(f"[Roblox Animator Utils] Pin history snapshot skipped: {exc}")
        _state["pin_history_contact_snapshot"] = {
            "targets": {},
            "poses": {},
            "engaged": set(),
            "selected": set(),
        }
        _state["pin_history_nonhistory_snapshot"] = None


@persistent
def _pin_undo_pre(*args):
    _state["pin_history_direction"] = "UNDO"
    _pin_history_pre(*args)


@persistent
def _pin_redo_pre(*args):
    _state["pin_history_direction"] = "REDO"
    _pin_history_pre(*args)


@persistent
def _pin_undo_post(*_):
    _state["pin_history_active"] = True
    _state["pin_history_syncing"] = True
    try:
        context = bpy.context
        _state["pin_target_dragging"] = False
        _pin_clear_transform_state()
        _restore_pose_session_armature_visibility()
        _restore_pin_nonhistory_snapshot(
            context,
            _state.get("pin_history_nonhistory_snapshot"),
        )
        if getattr(context, "mode", "") == "POSE":
            _sync_pose_session_armature_visibility(context)
        _yellow_sync_targets_from_properties(context)
        _pin_history_restore_selection(context)
        # Blender's restored pose is the history authority. Persistent saved
        # poses exist only for file/reload recovery and may describe the
        # opposite history side, so never apply them inside Undo or Redo.
        previous_snapshot = (
            _state.get("pin_history_contact_snapshot")
            or {
                "targets": {},
                "poses": {},
                "pose_matrices": {},
                "drivers": {},
                "engaged": set(),
                "selected": set(),
            }
        )
        current_snapshot = _surface_contact_history_snapshot(context)
        transition_history_restored = (
            _surface_contact_restore_native_history_transition(
                context,
                previous_snapshot,
            )
        )
        native_history_restored = bool(transition_history_restored)
        if native_history_restored:
            # The paired transition writes the exact contact pose that was
            # visible when native G/R/S finished. Settle that write before
            # sampling matrix_basis; constrained parent chains may otherwise
            # still expose the undo-side basis until the next evaluation.
            context.view_layer.update()
            current_snapshot = _surface_contact_history_snapshot(context)
        previous_targets = previous_snapshot.get("targets", {})
        current_targets = current_snapshot.get("targets", {})
        previous_poses = previous_snapshot.get("poses", {})
        current_poses = current_snapshot.get("poses", {})
        previous_drivers = previous_snapshot.get("drivers", {})
        current_drivers = current_snapshot.get("drivers", {})
        changed_pose_keys = {
            key
            for key, signature in current_poses.items()
            if previous_poses.get(key) != signature
        }
        changed_target_keys = {
            key
            for key, signature in current_targets.items()
            if previous_targets.get(key) != signature
        }
        changed_driver_keys = {
            key
            for key, signature in current_drivers.items()
            if (
                key in previous_drivers
                and previous_drivers.get(key) != signature
            )
        }
        driver_candidate_keys = set()
        for guide in _surface_contact_active_simulated_guides(context.scene):
            if (
                not str(
                    guide.get(SURFACE_CONTACT_SURFACE_PROPERTY, "")
                )
            ):
                continue
            armature = bpy.data.objects.get(
                str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
            )
            driver_candidate_keys.add(
                (_armature_session_uid(armature), guide.name)
            )
        changed_driver_keys &= driver_candidate_keys
        history_selected_keys = (
            set(previous_snapshot.get("selected", set()))
            | set(current_snapshot.get("selected", set()))
        )
        if not native_history_restored:
            # Undo can invalidate/evaluate an unrelated dependency and expose
            # a different contact-owned matrix_basis even though the history
            # step did not edit that contact. Accept a pink pose delta only
            # when the pink owner was directly selected, its target changed,
            # or a selected ancestor driver changed. Restore every other
            # contact from the pre-history snapshot before any solver/cache
            # reconciliation can turn that transient evaluation into state.
            unowned_pose_keys = changed_pose_keys - (
                history_selected_keys
                | changed_target_keys
                | changed_driver_keys
            )
            if unowned_pose_keys:
                _surface_contact_restore_history_poses(
                    context,
                    previous_snapshot,
                    update_view_layer=False,
                    owner_keys=unowned_pose_keys,
                )
                context.view_layer.update()
                changed_pose_keys -= unowned_pose_keys
        driver_lock_keys = changed_driver_keys
        repair_driver_keys = driver_lock_keys - changed_pose_keys
        driver_history_locked = False
        if (
            not changed_target_keys
            and not changed_pose_keys
            and not changed_driver_keys
        ):
            _surface_contact_restore_history_poses(
                context,
                previous_snapshot,
            )
            history_guides = tuple(
                _surface_contact_active_simulated_guides(context.scene)
            )
            # The only detected pink delta was an unowned depsgraph/history
            # evaluation and has just been rolled back. Persist that
            # authoritative rollback before returning; otherwise the older
            # saved-pose property can replay the leaked pose when the short
            # history visibility lock is released.
            for guide in history_guides:
                _surface_contact_store_owner_pose_base(guide)
            _surface_contact_store_persistent_pose_snapshots(history_guides)
            _surface_contact_seed_runtime_signatures(context, history_guides)
            _pin_cache_idle_transform_poses(context)
            _schedule_pin_history_visibility_clear()
            _tag_redraw_all_view3d()
            return
        # Blender restores guide ID properties as part of undo/redo, while the
        # runtime latch is intentionally not in history. Rebuild saved latches
        # before deciding whether a changed target should be force-solved.
        _surface_contact_restore_snap_detached(
            context,
            infer_missing = False,
            reset_runtime = True,
        )
        # Preserve the semantic state of a manual endpoint move across
        # history. Undoing back onto an unchanged target re-engages it; redoing
        # the same move away records a detach instead of force-solving it back.
        history_departure_changed = False
        previous_engaged = set(previous_snapshot.get("engaged", set()))
        for guide in _surface_contact_active_simulated_guides(context.scene):
            armature = bpy.data.objects.get(
                str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
            )
            owner_key = (_armature_session_uid(armature), guide.name)
            if (
                owner_key in driver_lock_keys
                or owner_key not in changed_pose_keys
                or previous_targets.get(owner_key)
                != current_targets.get(owner_key)
            ):
                continue
            target, _normal, anchor = _surface_contact_world_point_normal(
                context,
                guide,
            )
            if target is None or anchor is None:
                continue
            tolerance = _surface_contact_settle_tolerance(guide)
            if (Vector(target) - Vector(anchor)).length <= tolerance:
                _surface_contact_clear_snap_departure(guide)
                history_departure_changed = True
            elif owner_key in previous_engaged:
                snap_key = _surface_contact_snap_key(guide)
                _state.setdefault("pin_snap_departing", set()).discard(
                    snap_key
                )
                _state.setdefault("pin_snap_transform_seen", set()).discard(
                    snap_key
                )
                _state.setdefault("pin_snap_latches", set()).discard(snap_key)
                _surface_contact_set_snap_detached(guide, True)
                history_departure_changed = True
        detached_owner_keys = set()
        detached_snap_keys = _state.setdefault("pin_snap_detached", set())
        for guide in _surface_contact_active_simulated_guides(context.scene):
            if _surface_contact_snap_key(guide) not in detached_snap_keys:
                continue
            armature = bpy.data.objects.get(
                str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
            )
            detached_owner_keys.add(
                (_armature_session_uid(armature), guide.name)
            )
        # Blender's undo step has already restored the complete guide and pose
        # matrices. Do not run the contact solver here: it necessarily updates
        # the dependency graph between its rotation and translation phases,
        # which exposes a visible two-step limb movement. Rebuild only the
        # runtime bookkeeping, then reapply the exact post-history pose below
        # and evaluate it once.
        if changed_target_keys:
            for guide in _surface_contact_active_simulated_guides(context.scene):
                armature = bpy.data.objects.get(
                    str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
                )
                owner_key = (_armature_session_uid(armature), guide.name)
                if owner_key not in changed_target_keys:
                    continue
                _surface_contact_store_owner_pose_base(guide)
        directly_changed_pose_keys = changed_pose_keys & (
            set(previous_snapshot.get("selected", set()))
            | set(current_snapshot.get("selected", set()))
        )
        if directly_changed_pose_keys:
            for guide in _surface_contact_active_simulated_guides(context.scene):
                armature = bpy.data.objects.get(
                    str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
                )
                owner_key = (_armature_session_uid(armature), guide.name)
                if owner_key in directly_changed_pose_keys:
                    _surface_contact_store_owner_pose_base(guide)
        if not native_history_restored:
            _surface_contact_restore_history_poses(
                context,
                current_snapshot,
                update_view_layer=False,
                # Only a directly edited pink bone owns a local pose restored
                # by Blender history. Target/parent/unrelated history must
                # start from the pre-history lock and receive exactly one
                # magnetic result below. Restoring every current pink matrix
                # here caused the visible move-back-move twitch.
                owner_keys=directly_changed_pose_keys,
            )
        # Contact/dynamic-parent history reconciliation can settle the pose
        # after the general runtime restore. Weld attached cameras once more
        # against that final evaluated pose.
        context.view_layer.update()
        if not native_history_restored:
            if driver_lock_keys:
                # Redo's late Action evaluation has already put indirectly
                # driven contact limbs back on their keyed straight basis at
                # this point. Reconcile first, then lock that corrected pose.
                # Capturing before reconciliation faithfully preserved the
                # wrong straight state and skipped magnetism altogether.
                if repair_driver_keys:
                    _surface_contact_reconcile_history_magnetism(
                        context,
                        repair_driver_keys,
                    )
                    context.view_layer.update()
                driver_history_locked = (
                    _surface_contact_set_current_history_pose_lock(
                        context,
                        driver_lock_keys,
                        include_detached=True,
                    )
                )
            else:
                _surface_contact_reconcile_history_magnetism(context)
                context.view_layer.update()
            if driver_history_locked:
                _surface_contact_apply_history_pose_lock(
                    context,
                    update_view_layer=True,
                )
        history_guides = tuple(
            _surface_contact_active_simulated_guides(context.scene)
        )
        for guide in history_guides:
            armature = bpy.data.objects.get(
                str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
            )
            owner_key = (_armature_session_uid(armature), guide.name)
            if owner_key in driver_lock_keys:
                # An ancestor history step owns only the parent transform.
                # Its magnetic child pose is a transient solution, not a new
                # user-authored local base for the next parent drag.
                continue
            _surface_contact_store_owner_pose_base(guide)
        _surface_contact_store_persistent_pose_snapshots(history_guides)
        _surface_contact_seed_runtime_signatures(context, history_guides)
        _surface_contact_seed_valid_poses()
        # A rapid second G/R/S can begin before the normal idle timer runs.
        # Seed its intent baseline from the just-restored history side now;
        # retaining the first move's committed pose makes repeating that move
        # look unchanged and skips the pink Contact solve.
        _pin_cache_idle_transform_poses(context)
        if _refresh_attached_camera_transforms(context):
            _schedule_attached_camera_transform_restore(0.05)
        _schedule_pin_history_visibility_clear()
        _refresh_roblox_armature_list(context, force = True)
        _tag_redraw_all_view3d()
    except (
        AttributeError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ) as exc:
        print(f"[Roblox Animator Utils] Pin history sync failed: {exc}")
        _state["pin_history_active"] = False
    finally:
        _state["pin_history_contact_snapshot"] = None
        _state["pin_history_nonhistory_snapshot"] = None
        _state["pin_history_selection_snapshot"] = None
        _state["pin_history_direction"] = ""
        _state["pin_snap_native_history_expected_index"] = None
        _state["pin_snap_native_history_pre_selected"] = {}
        _state["pin_history_syncing"] = False
