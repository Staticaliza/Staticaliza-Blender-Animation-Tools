"""Registered undoable pin movement operator."""

from ..core.runtime import *  # noqa: F403


def _pin_target_history_snapshot(context, guide):
    armature, pose_bone = _surface_contact_pose_bone(guide)
    if armature is None or pose_bone is None:
        return None
    local_values = guide.get(SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY)
    return {
        "frame": int(context.scene.frame_current),
        "owner_key": (_armature_session_uid(armature), guide.name),
        "armature": armature.name,
        "bone": pose_bone.name,
        "basis": pose_bone.matrix_basis.copy(),
        "visual": pose_bone.matrix.copy(),
        "guide_matrix": guide.matrix_world.copy(),
        "guide_local": (
            tuple(float(value) for value in local_values)
            if local_values is not None and len(local_values) >= 16
            else None
        ),
        "attached": bool(_pin_contact_is_attached(context, guide)),
        "detached_keys": _surface_contact_detached_key_snapshot(
            guide,
            int(context.scene.frame_current),
        ),
        "constraints": _surface_contact_constraint_history_state(guide),
        "action_keys": _surface_contact_pose_action_key_snapshot(
            armature,
            pose_bone,
            int(context.scene.frame_current),
        ),
    }


def _pin_record_target_history_transition(context, guide, before):
    """Pair a pink target operator with the same exact Contact history model."""
    after = _pin_target_history_snapshot(context, guide)
    if before is None or after is None:
        return None
    if (
        not _pin_keyboard_matrices_differ(
            before["guide_matrix"], after["guide_matrix"], epsilon=1.0e-8
        )
        and not _pin_keyboard_matrices_differ(
            before["basis"], after["basis"], epsilon=1.0e-8
        )
        and before["attached"] == after["attached"]
        and _dynamic_parent_pose_key_snapshot_signature(before["action_keys"])
        == _dynamic_parent_pose_key_snapshot_signature(after["action_keys"])
        and _dynamic_parent_pose_key_snapshot_signature(before["detached_keys"])
        == _dynamic_parent_pose_key_snapshot_signature(after["detached_keys"])
    ):
        return None

    owner_key = before["owner_key"]
    armature_name = before["armature"]
    bone_name = before["bone"]
    transition = {
        "kind": "TARGET",
        "frame": int(before["frame"]),
        # The owner pose is a dependency of the target operation, not proof of
        # its identity. The guide/key/attachment side checks below distinguish
        # this transition from an adjacent pink-bone transform.
        "selected": ((
            armature_name,
            bone_name,
            before["basis"].copy(),
            after["basis"].copy(),
            after["basis"].copy(),
        ),),
        "contacts": ((
            owner_key,
            armature_name,
            bone_name,
            before["basis"].copy(),
            after["basis"].copy(),
            after["basis"].copy(),
        ),),
        "attachments": ((
            owner_key,
            bool(before["attached"]),
            bool(after["attached"]),
        ),),
        "detached_key_states": ((
            owner_key,
            before["detached_keys"],
            after["detached_keys"],
        ),),
        "guide_matrices": ((
            owner_key,
            guide.name,
            before["guide_matrix"].copy(),
            after["guide_matrix"].copy(),
        ),),
        "guide_local_matrices": ((
            owner_key,
            guide.name,
            before["guide_local"],
            after["guide_local"],
        ),),
        "constraint_states": ((
            owner_key,
            guide.name,
            before["constraints"],
            after["constraints"],
        ),),
        "visual_poses": ((
            owner_key,
            armature_name,
            bone_name,
            before["visual"].copy(),
            after["visual"].copy(),
            after["visual"].copy(),
        ),),
        "action_keys": ((
            armature_name,
            bone_name,
            before["action_keys"],
            after["action_keys"],
        ),),
        "history_tokens": (),
    }
    history_stack = _state.setdefault(
        "pin_snap_native_history_transitions", []
    )
    history_stack.append(transition)
    _state.setdefault("pin_snap_native_history_redo_stack", []).clear()
    try:
        undo_steps = int(context.preferences.edit.undo_steps)
    except (AttributeError, TypeError, ValueError):
        undo_steps = 32
    history_limit = max(32, undo_steps + 8)
    if len(history_stack) > history_limit:
        del history_stack[:-history_limit]
    _state["pin_snap_native_history_transition"] = transition
    _state["pin_snap_native_history_transition_backup"] = transition
    return transition


class ANIMATOR_UTILS_OT_move_pin_target(bpy.types.Operator):
    bl_idname = "staticaliza.move_pin_target"
    bl_label = "Move"
    bl_description = "Move the selected pin target with an undoable displacement"
    bl_options = {"REGISTER", "UNDO"}

    pin_kind: bpy.props.EnumProperty(
        items = (
            ("CONTACT", "Contact", ""),
            ("YELLOW", "Onion Pin", ""),
        ),
        options = {"HIDDEN"},
    )
    armature_name: bpy.props.StringProperty(
        options = {"HIDDEN"},
    )
    target_name: bpy.props.StringProperty(
        options = {"HIDDEN"},
    )
    surface_name: bpy.props.StringProperty(
        options = {"HIDDEN"},
    )
    surface_constrained: bpy.props.BoolProperty(
        default = True,
        options = {"HIDDEN"},
    )
    base_location: bpy.props.FloatVectorProperty(
        size = 3,
        subtype = "TRANSLATION",
        options = {"HIDDEN"},
    )
    displacement: bpy.props.FloatVectorProperty(
        name = "Move",
        description = "World-space offset from the pin's position before this move",
        size = 3,
        subtype = "TRANSLATION",
        unit = "LENGTH",
    )

    def draw(self, context):
        column = self.layout.column(align = True)
        column.prop(self, "displacement", index = 0, text = "Move X")
        column.prop(self, "displacement", index = 1, text = "Y")
        column.prop(self, "displacement", index = 2, text = "Z")
        column.label(text = f"Distance: {Vector(self.displacement).length:.6g} m")

    def execute(self, context):
        candidate = Vector(self.base_location) + Vector(self.displacement)
        if self.pin_kind == "CONTACT":
            guide = bpy.data.objects.get(str(self.target_name))
            if guide is None:
                self.report({"ERROR"}, "The Contact target no longer exists.")
                return {"CANCELLED"}
            history_before = _pin_target_history_snapshot(context, guide)
            current = guide.matrix_world.translation.copy()
            if self.surface_constrained:
                surface = bpy.data.objects.get(str(self.surface_name))
                if (
                    surface is not None
                    and str(guide.get(SURFACE_CONTACT_SURFACE_PROPERTY, ""))
                    != surface.name
                    and not _surface_contact_bind_guide_surface(
                        context,
                        guide,
                        surface,
                        candidate,
                    )
                ):
                    self.report({"ERROR"}, "Unable to bind the Contact surface.")
                    return {"CANCELLED"}
                result = _surface_contact_axis_surface_point(
                    context,
                    guide,
                    candidate,
                )
                if result is None:
                    self.report({"ERROR"}, "No point was found on the Contact surface.")
                    return {"CANCELLED"}
                candidate = Vector(result[0])
                moved = (
                    _surface_contact_move_guide_to_surface(
                        context,
                        guide,
                        candidate,
                        result[1],
                        keep_attached = False,
                    )
                    or (candidate - current).length <= 1.0e-6
                )
            else:
                moved = (
                    _surface_contact_move_guide_world(
                        context,
                        guide,
                        candidate,
                        keep_attached = False,
                    )
                    or (candidate - current).length <= 1.0e-6
                )
            if not moved:
                self.report({"ERROR"}, "Unable to move the Contact target.")
                return {"CANCELLED"}
            # Keep Adjust Last Operation tied to this drag's original point,
            # including the final surface-projected pink target.
            self.displacement = tuple(
                candidate - Vector(self.base_location)
            )
            _surface_contact_commit_target_key(context, guide)
            _pin_record_target_history_transition(
                context,
                guide,
                history_before,
            )
            return {"FINISHED"}

        armature = bpy.data.objects.get(str(self.armature_name))
        pose_bone = (
            armature.pose.bones.get(str(self.target_name))
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        packed = _state.get("yellow_fixed", {}).get(
            _owner_bone_key(armature, self.target_name)
        )
        if armature is None or pose_bone is None or not packed:
            self.report({"ERROR"}, "The Onion Pin target no longer exists.")
            return {"CANCELLED"}
        current = Vector(packed[0])
        moved = (
            _yellow_set_pin_target(armature, pose_bone.name, candidate)
            or (candidate - current).length <= 1.0e-6
        )
        if not moved:
            return {"CANCELLED"}
        self.displacement = tuple(
            candidate - Vector(self.base_location)
        )
        _yellow_store_target_property(armature, pose_bone.name, candidate)
        _yellow_refresh_runtime(context)
        return {"FINISHED"}
