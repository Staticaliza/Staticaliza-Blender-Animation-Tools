"""Registered undoable pin movement operator."""

from ..core.runtime import *  # noqa: F403

class ANIMATOR_UTILS_OT_move_pin_target(bpy.types.Operator):
    bl_idname = "staticaliza.move_pin_target"
    bl_label = "Move"
    bl_description = "Move the selected pin target with an undoable displacement"
    bl_options = {"REGISTER", "UNDO"}

    pin_kind: bpy.props.EnumProperty(
        items = (
            ("CONTACT", "Contact", ""),
            ("YELLOW", "Onion Pin", ""),
        ),
        options = {"HIDDEN"},
    )
    armature_name: bpy.props.StringProperty(
        options = {"HIDDEN"},
    )
    target_name: bpy.props.StringProperty(
        options = {"HIDDEN"},
    )
    surface_name: bpy.props.StringProperty(
        options = {"HIDDEN"},
    )
    surface_constrained: bpy.props.BoolProperty(
        default = True,
        options = {"HIDDEN"},
    )
    base_location: bpy.props.FloatVectorProperty(
        size = 3,
        subtype = "TRANSLATION",
        options = {"HIDDEN"},
    )
    displacement: bpy.props.FloatVectorProperty(
        name = "Move",
        description = "World-space offset from the pin's position before this move",
        size = 3,
        subtype = "TRANSLATION",
        unit = "LENGTH",
    )

    def draw(self, context):
        column = self.layout.column(align = True)
        column.prop(self, "displacement", index = 0, text = "Move X")
        column.prop(self, "displacement", index = 1, text = "Y")
        column.prop(self, "displacement", index = 2, text = "Z")
        column.label(text = f"Distance: {Vector(self.displacement).length:.6g} m")

    def execute(self, context):
        candidate = Vector(self.base_location) + Vector(self.displacement)
        if self.pin_kind == "CONTACT":
            guide = bpy.data.objects.get(str(self.target_name))
            if guide is None:
                self.report({"ERROR"}, "The Contact target no longer exists.")
                return {"CANCELLED"}
            current = guide.matrix_world.translation.copy()
            if self.surface_constrained:
                surface = bpy.data.objects.get(str(self.surface_name))
                if (
                    surface is not None
                    and str(guide.get(SURFACE_CONTACT_SURFACE_PROPERTY, ""))
                    != surface.name
                    and not _surface_contact_bind_guide_surface(
                        context,
                        guide,
                        surface,
                        candidate,
                    )
                ):
                    self.report({"ERROR"}, "Unable to bind the Contact surface.")
                    return {"CANCELLED"}
                result = _surface_contact_axis_surface_point(
                    context,
                    guide,
                    candidate,
                )
                if result is None:
                    self.report({"ERROR"}, "No point was found on the Contact surface.")
                    return {"CANCELLED"}
                candidate = Vector(result[0])
                moved = (
                    _surface_contact_move_guide_to_surface(
                        context,
                        guide,
                        candidate,
                        result[1],
                        keep_attached = False,
                    )
                    or (candidate - current).length <= 1.0e-6
                )
            else:
                moved = (
                    _surface_contact_move_guide_world(
                        context,
                        guide,
                        candidate,
                        keep_attached = False,
                    )
                    or (candidate - current).length <= 1.0e-6
                )
            if not moved:
                self.report({"ERROR"}, "Unable to move the Contact target.")
                return {"CANCELLED"}
            # Keep Adjust Last Operation tied to this drag's original point,
            # including the final surface-projected pink target.
            self.displacement = tuple(
                candidate - Vector(self.base_location)
            )
            _surface_contact_commit_target_key(context, guide)
            return {"FINISHED"}

        armature = bpy.data.objects.get(str(self.armature_name))
        pose_bone = (
            armature.pose.bones.get(str(self.target_name))
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        packed = _state.get("yellow_fixed", {}).get(
            _owner_bone_key(armature, self.target_name)
        )
        if armature is None or pose_bone is None or not packed:
            self.report({"ERROR"}, "The Onion Pin target no longer exists.")
            return {"CANCELLED"}
        current = Vector(packed[0])
        moved = (
            _yellow_set_pin_target(armature, pose_bone.name, candidate)
            or (candidate - current).length <= 1.0e-6
        )
        if not moved:
            return {"CANCELLED"}
        self.displacement = tuple(
            candidate - Vector(self.base_location)
        )
        _yellow_store_target_property(armature, pose_bone.name, candidate)
        _yellow_refresh_runtime(context)
        return {"FINISHED"}
