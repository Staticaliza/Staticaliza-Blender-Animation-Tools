"""Pose and pin clipboard and mirrored paste support."""

from ..core.runtime import *  # noqa: F403

def _pin_parent_world_matrix(armature, pose_bone):
    if armature is None:
        return Matrix.Identity(4)
    if pose_bone is not None and pose_bone.parent is not None:
        return armature.matrix_world @ pose_bone.parent.matrix
    return armature.matrix_world.copy()


def _pin_mirror_world_matrix(
    armature,
    source_pose_bone = None,
    target_pose_bone = None,
):
    """Use the posed rig-root frame as the moving symmetry plane."""
    frame = armature.matrix_world.copy()
    pose = getattr(armature, "pose", None)
    candidates = []
    for pose_bone in getattr(pose, "bones", ()) if pose is not None else ():
        compact = "".join(
            character
            for character in _strip_blender_numeric_suffix(
                pose_bone.name
            ).casefold()
            if character.isalnum()
        )
        score = (
            0 if compact == "humanoidrootpart" else
            1 if compact == "rootpart" else
            2 if compact == "root" else
            3 if _pose_bone_is_label_root(pose_bone) else
            10
        )
        candidates.append((score, pose_bone.name.casefold(), pose_bone))
    candidates.sort(key = lambda item: item[:2])
    if candidates and candidates[0][0] < 10:
        try:
            root_world = armature.matrix_world @ candidates[0][2].matrix
            frame = root_world.normalized()
            frame.translation = root_world.translation
        except (
            AttributeError,
            ReferenceError,
            RuntimeError,
            TypeError,
            ValueError,
        ):
            pass
    return frame


def _pin_clipboard_capture(context):
    pose_grouped = _selected_pose_bones_by_owner(context)
    grouped = {
        armature: list(pose_bones)
        for armature, pose_bones in pose_grouped.items()
    }

    # A pin is a virtual selection and deliberately may be selected without
    # its pose bone. Include its associated bone for pin capture without
    # pretending that Blender's pose itself was selected for copying.
    _selected_key, selected_target = _pin_selected_target_data(context)
    if selected_target is not None:
        _kind, armature, pose_bone, _payload = selected_target
        if armature is not None and pose_bone is not None:
            owner_bones = grouped.setdefault(armature, [])
            if all(item.name != pose_bone.name for item in owner_bones):
                owner_bones.append(pose_bone)
    if not grouped:
        return None
    frame = int(context.scene.frame_current)
    owners = []
    for armature, pose_bones in grouped.items():
        entries = []
        for pose_bone in pose_bones:
            opposite_bone = armature.pose.bones.get(
                _pin_flipped_name(pose_bone.name)
            )
            mirror_inverse = _pin_mirror_world_matrix(
                armature,
                pose_bone,
                opposite_bone,
            ).inverted_safe()
            parent_world = _pin_parent_world_matrix(armature, pose_bone)
            parent_inverse = parent_world.inverted_safe()
            packed = _state.get("yellow_fixed", {}).get(
                _owner_bone_key(armature, pose_bone.name)
            )
            if packed:
                target_world = Vector(packed[0])
                entries.append({
                    "kind": "YELLOW",
                    "bone_name": pose_bone.name,
                    "parent_name": (
                        pose_bone.parent.name if pose_bone.parent else ""
                    ),
                    "local_offset": tuple(parent_inverse @ target_world),
                    "armature_offset": tuple(
                        armature.matrix_world.inverted_safe() @ target_world
                    ),
                    "mirror_offset": tuple(mirror_inverse @ target_world),
                })
            contact_guides = _surface_contact_guides_for_selected_bone(
                armature,
                pose_bone,
                frame,
            )
            if contact_guides:
                guide = max(
                    contact_guides,
                    key = lambda item: int(
                        item.get(
                            SURFACE_CONTACT_START_PROPERTY,
                            SPACE_MIN_FRAME,
                        )
                    ),
                )
                target_world = guide.matrix_world.translation.copy()
                entries.append({
                    "kind": "CONTACT",
                    "bone_name": pose_bone.name,
                    "parent_name": (
                        pose_bone.parent.name if pose_bone.parent else ""
                    ),
                    "local_offset": tuple(
                        parent_inverse @ target_world
                    ),
                    "armature_offset": tuple(
                        armature.matrix_world.inverted_safe() @ target_world
                    ),
                    "mirror_offset": tuple(mirror_inverse @ target_world),
                })
        owners.append({
            "session_uid": _armature_session_uid(armature),
            "armature_name": armature.name,
            "entries": entries,
        })
    return {
        "owners": owners,
        "has_pose": bool(pose_grouped),
    }


def _pin_flipped_name(name):
    name = str(name)
    try:
        flipped = bpy.utils.flip_name(name, strip_digits = False)
    except (AttributeError, TypeError):
        flipped = name
    if flipped != name:
        return flipped

    # Roblox rigs commonly use full-word side names. Keep these working even
    # if Blender changes which naming conventions flip_name recognizes.
    for left, right in (
        ("Left", "Right"),
        ("left", "right"),
        ("LEFT", "RIGHT"),
    ):
        if left in name:
            return name.replace(left, right, 1)
        if right in name:
            return name.replace(right, left, 1)
    return name


def _pin_clipboard_apply(context, flipped = False):
    clipboard = _state.get("pin_clipboard")
    scope = _pose_scope_armatures(context)
    if not clipboard or not scope:
        return 0
    frame = int(context.scene.frame_current)
    changed = 0
    owner_entries = tuple(clipboard.get("owners", ()))
    if not owner_entries and "entries" in clipboard:
        owner_entries = ({
            "session_uid": 0,
            "armature_name": str(clipboard.get("armature_name", "")),
            "entries": tuple(clipboard.get("entries", ())),
        },)
    scope_by_uid = {
        _armature_session_uid(armature): armature for armature in scope
    }
    scope_by_name = {armature.name: armature for armature in scope}
    for owner_entry in owner_entries:
        armature = scope_by_uid.get(int(owner_entry.get("session_uid", 0)))
        if armature is None:
            armature = scope_by_name.get(str(owner_entry.get("armature_name", "")))
        if armature is None and len(owner_entries) == 1 and len(scope) == 1:
            armature = scope[0]
        if armature is None:
            continue
        for entry in owner_entry.get("entries", ()):
            source_name = str(entry.get("bone_name", ""))
            target_name = _pin_flipped_name(source_name) if flipped else source_name
            pose_bone = armature.pose.bones.get(target_name)
            if pose_bone is None:
                continue
            if flipped:
                source_pose_bone = armature.pose.bones.get(source_name)
                mirror_world = _pin_mirror_world_matrix(
                    armature,
                    source_pose_bone,
                    pose_bone,
                )
                mirror_offset_data = entry.get("mirror_offset")
                if mirror_offset_data is not None:
                    mirror_offset = Vector(tuple(mirror_offset_data))
                    mirror_offset.x = -mirror_offset.x
                    target = mirror_world @ mirror_offset
                else:
                    # Compatibility with clipboards captured before v1.6.55.
                    armature_offset = Vector(tuple(entry.get(
                        "armature_offset",
                        entry.get("local_offset", (0.0, 0.0, 0.0)),
                    )))
                    armature_offset.x = -armature_offset.x
                    target = armature.matrix_world @ armature_offset
            else:
                local_offset = Vector(tuple(
                    entry.get("local_offset", (0.0, 0.0, 0.0))
                ))
                target = (
                    _pin_parent_world_matrix(armature, pose_bone)
                    @ local_offset
                )

            if str(entry.get("kind", "")) == "YELLOW":
                packed = _state.get("yellow_fixed", {}).get(
                    _owner_bone_key(armature, target_name)
                )
                if not packed:
                    continue
                if _yellow_set_pin_target(armature, target_name, target):
                    _yellow_store_target_property(armature, target_name, target)
                    changed += 1
                continue

            guides = _surface_contact_guides_for_selected_bone(
                armature,
                pose_bone,
                frame,
            )
            if not guides:
                continue
            guide = max(
                guides,
                key = lambda item: int(
                    item.get(SURFACE_CONTACT_START_PROPERTY, SPACE_MIN_FRAME)
                ),
            )
            result = _surface_contact_axis_surface_point(context, guide, target)
            if result is None:
                continue
            current = guide.matrix_world.translation.copy()
            if (
                (Vector(result[0]) - current).length <= 1.0e-6
                or _surface_contact_move_guide_to_surface(
                    context,
                    guide,
                    result[0],
                    result[1],
                )
            ):
                _surface_contact_commit_target_key(context, guide)
                changed += 1
    if changed:
        _yellow_refresh_runtime(context)
        context.view_layer.update()
        _tag_redraw_all_view3d()
    return changed


class ANIMATOR_UTILS_OT_pose_pin_clipboard(bpy.types.Operator):
    bl_idname = "staticaliza.pose_pin_clipboard"
    bl_label = "Pose and Pin Clipboard"
    bl_description = "Copy or paste the pose and its pin targets"
    bl_options = {"REGISTER", "UNDO"}

    action: bpy.props.EnumProperty(
        items = (
            ("COPY", "Copy", ""),
            ("PASTE", "Paste", ""),
            ("PASTE_FLIPPED", "Paste Flipped", ""),
        ),
        options = {"HIDDEN", "SKIP_SAVE"},
    )

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE" and _active_armature(context) is not None

    def execute(self, context):
        if self.action == "COPY":
            clipboard = _pin_clipboard_capture(context)
            if clipboard is not None and clipboard.get("has_pose", False):
                try:
                    bpy.ops.pose.copy()
                except RuntimeError:
                    pass
            _state["pin_clipboard"] = clipboard
            return {"FINISHED"}

        flipped = self.action == "PASTE_FLIPPED"
        clipboard = _state.get("pin_clipboard")
        scope = tuple(_pose_scope_armatures(context))
        object_key_snapshots = {
            _armature_session_uid(armature): (
                armature.animation_data.action
                if armature.animation_data else None,
                _snapshot_object_keys_all(
                    armature.animation_data.action
                    if armature.animation_data else None
                ),
            )
            for armature in scope
        }
        if clipboard is None or clipboard.get("has_pose", True):
            try:
                bpy.ops.pose.paste(flipped = flipped, selected_mask = False)
            except RuntimeError:
                pass
        context.view_layer.update()
        _pin_clipboard_apply(context, flipped = flipped)
        for armature in scope:
            _previous_action, snapshot = object_key_snapshots.get(
                _armature_session_uid(armature),
                (None, {}),
            )
            current_action = (
                armature.animation_data.action
                if armature.animation_data else None
            )
            _cleanup_new_object_keys_all(current_action, snapshot)
        return {"FINISHED"}
