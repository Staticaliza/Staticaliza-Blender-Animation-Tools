"""Rig discovery, lifecycle, materials, and import normalization."""
