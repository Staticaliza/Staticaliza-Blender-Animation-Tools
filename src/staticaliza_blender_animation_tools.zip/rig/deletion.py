"""Rig deletion ownership discovery, runtime cleanup, orphan removal, and pose recovery."""

from ..core.runtime import *  # noqa: F403

def _rig_delete_bundle(armature):
    if armature is None or getattr(armature, "type", "") != "ARMATURE":
        return None
    candidates = []
    for collection in bpy.data.collections:
        if not collection.name.startswith("RIG: "):
            continue
        try:
            if collection.all_objects.get(armature.name) != armature:
                continue
        except (AttributeError, ReferenceError, RuntimeError):
            continue
        parts = tuple(
            child
            for child in collection.children
            if _strip_blender_numeric_suffix(child.name).casefold() == "parts"
        )
        metas = tuple(obj for obj in collection.all_objects if "RigMeta" in obj)
        if len(parts) == 1 and len(metas) == 1:
            candidates.append((collection, parts[0], metas[0]))
    if len(candidates) != 1:
        return None
    master, parts, meta = candidates[0]
    return {
        "armature": armature,
        "master": master,
        "parts": parts,
        "meta": meta,
    }


def _rig_delete_collection_parents(collection):
    return {
        parent
        for parent in bpy.data.collections
        if parent.children.get(collection.name) == collection
    }


def _rig_delete_collection_scene_links(collection):
    return {
        scene
        for scene in bpy.data.scenes
        if scene.collection.children.get(collection.name) == collection
    }


def _rig_delete_owned_collections(master):
    descendants = set()
    pending = [master]
    while pending:
        collection = pending.pop()
        if collection in descendants:
            continue
        descendants.add(collection)
        pending.extend(tuple(collection.children))

    owned = {master}
    changed = True
    while changed:
        changed = False
        for collection in descendants - owned:
            parents = _rig_delete_collection_parents(collection)
            if (
                parents
                and parents.issubset(owned)
                and not _rig_delete_collection_scene_links(collection)
            ):
                owned.add(collection)
                changed = True
    return owned


def _rig_delete_owned_objects(bundle, owned_collections):
    armature = bundle["armature"]
    meta = bundle["meta"]
    objects = set()
    for collection in owned_collections:
        for obj in collection.objects:
            try:
                external_links = {
                    linked
                    for linked in obj.users_collection
                    if linked not in owned_collections
                }
            except (AttributeError, ReferenceError, RuntimeError):
                external_links = {None}
            if not external_links or obj in {armature, meta}:
                objects.add(obj)
    objects.update((armature, meta))
    return objects


def _rig_delete_resource_inventory():
    return {
        "actions": set(),
        "armatures": set(),
        "cameras": set(),
        "curves": set(),
        "images": set(),
        "lights": set(),
        "materials": set(),
        "meshes": set(),
        "node_groups": set(),
        "textures": set(),
        # IDs found only through a global/name-based search are deliberately
        # more conservative than data reached from an owned rig object.
        "direct": set(),
        "heuristic": set(),
    }


def _rig_delete_inventory_add(
    inventory,
    resource_name,
    datablock,
    heuristic = False,
):
    if datablock is None:
        return
    inventory[resource_name].add(datablock)
    if heuristic:
        inventory["heuristic"].add(datablock)
    else:
        inventory["direct"].add(datablock)


def _rig_delete_collect_actions(id_block, inventory, heuristic = False):

    if id_block is None:
        return
    animation_data = getattr(id_block, "animation_data", None)
    if animation_data is None:
        return
    action = getattr(animation_data, "action", None)
    if action is not None:
        _rig_delete_inventory_add(
            inventory,
            "actions",
            action,
            heuristic,
        )
    for track in getattr(animation_data, "nla_tracks", ()):
        for strip in getattr(track, "strips", ()):
            action = getattr(strip, "action", None)
            if action is not None:
                _rig_delete_inventory_add(
                    inventory,
                    "actions",
                    action,
                    heuristic,
                )


def _rig_delete_collect_node_tree(
    node_tree,
    inventory,
    visited = None,
    heuristic = False,
):
    if node_tree is None:
        return
    visited = visited if visited is not None else set()
    try:
        pointer = int(node_tree.as_pointer())
    except (AttributeError, ReferenceError, TypeError, ValueError):
        pointer = id(node_tree)
    if pointer in visited:
        return
    visited.add(pointer)
    _rig_delete_collect_actions(node_tree, inventory, heuristic)
    for node in getattr(node_tree, "nodes", ()):
        image = getattr(node, "image", None)
        if image is not None:
            _rig_delete_inventory_add(
                inventory,
                "images",
                image,
                heuristic,
            )
        texture = getattr(node, "texture", None)
        if texture is not None:
            _rig_delete_inventory_add(
                inventory,
                "textures",
                texture,
                heuristic,
            )
            texture_image = getattr(texture, "image", None)
            if texture_image is not None:
                _rig_delete_inventory_add(
                    inventory,
                    "images",
                    texture_image,
                    heuristic,
                )
        child_tree = getattr(node, "node_tree", None)
        if child_tree is None or child_tree == node_tree:
            continue
        try:
            if bpy.data.node_groups.get(child_tree.name) == child_tree:
                _rig_delete_inventory_add(
                    inventory,
                    "node_groups",
                    child_tree,
                    heuristic,
                )
        except (AttributeError, ReferenceError, TypeError):
            pass
        _rig_delete_collect_node_tree(
            child_tree,
            inventory,
            visited,
            heuristic,
        )


def _rig_delete_collect_object_resources(
    obj,
    inventory,
    heuristic = False,
):
    if obj is None:
        return
    _rig_delete_collect_actions(obj, inventory, heuristic)
    data = getattr(obj, "data", None)
    if data is not None:
        _rig_delete_collect_actions(data, inventory, heuristic)
        if isinstance(data, bpy.types.Armature):
            resource_name = "armatures"
        elif isinstance(data, bpy.types.Camera):
            resource_name = "cameras"
        elif isinstance(data, bpy.types.Curve):
            resource_name = "curves"
        elif isinstance(data, bpy.types.Light):
            resource_name = "lights"
        elif isinstance(data, bpy.types.Mesh):
            resource_name = "meshes"
            shape_keys = getattr(data, "shape_keys", None)
            _rig_delete_collect_actions(shape_keys, inventory, heuristic)
        else:
            resource_name = ""
        if resource_name:
            _rig_delete_inventory_add(
                inventory,
                resource_name,
                data,
                heuristic,
            )

    materials = set()
    for slot in getattr(obj, "material_slots", ()):
        material = getattr(slot, "material", None)
        if material is not None:
            materials.add(material)
    for material in getattr(data, "materials", ()) if data is not None else ():
        if material is not None:
            materials.add(material)
    for material in materials:
        _rig_delete_inventory_add(
            inventory,
            "materials",
            material,
            heuristic,
        )
        _rig_delete_collect_actions(material, inventory, heuristic)
        _rig_delete_collect_node_tree(
            getattr(material, "node_tree", None),
            inventory,
            heuristic = heuristic,
        )


def _rig_delete_real_users(datablock):
    try:
        users = max(0, int(datablock.users))
        if bool(getattr(datablock, "use_fake_user", False)):
            users = max(0, users - 1)
        return users

    except (AttributeError, ReferenceError, TypeError, ValueError):
        return 1


def _rig_delete_collect_rebuild_orphans(armature, inventory):
    armature_data = getattr(armature, "data", None)
    if armature_data is None:
        return
    canonical_name = _strip_blender_numeric_suffix(armature_data.name)
    for datablock in bpy.data.armatures:
        if (
            _strip_blender_numeric_suffix(datablock.name) == canonical_name
            and _rig_delete_real_users(datablock) == 0
        ):
            _rig_delete_inventory_add(
                inventory,
                "armatures",
                datablock,
                heuristic = True,
            )


def _rig_delete_guide_linked_to_objects(guide, object_names):
    for property_name in (
        SURFACE_CONTACT_ARMATURE_PROPERTY,
        SURFACE_CONTACT_CONTROL_OBJECT_PROPERTY,
        SURFACE_CONTACT_OBJECT_PROPERTY,
        SURFACE_CONTACT_SURFACE_PROPERTY,
        SURFACE_CONTACT_SMART_OBJECT_PROPERTY,
        SURFACE_CONTACT_RELEASE_OBJECT_PROPERTY,
        SURFACE_CONTACT_FOLLOW_OBJECT_PROPERTY,
        SURFACE_CONTACT_CONSTRAINT_OBJECT_PROPERTY,
        SURFACE_CONTACT_SOLVER_OBJECT_PROPERTY,
    ):
        if str(guide.get(property_name, "")) in object_names:
            return True
    return False


def _attached_camera_owner_marker(camera):
    try:
        owner_name = str(camera.get(ATTACHED_CAMERA_OWNER_NAME_PROPERTY, ""))
        owner_uid = int(camera.get(ATTACHED_CAMERA_OWNER_UID_PROPERTY, 0) or 0)
    except (AttributeError, ReferenceError, TypeError, ValueError):
        return False, "", 0
    return bool(owner_name or owner_uid), owner_name, owner_uid


def _attached_camera_marker_matches(camera, armature):
    marked, owner_name, owner_uid = _attached_camera_owner_marker(camera)
    if not marked or armature is None:
        return False
    try:
        parent = getattr(camera, "parent", None)
        has_live_bone_parent = bool(
            parent is not None
            and getattr(parent, "type", "") == "ARMATURE"
            and getattr(camera, "parent_type", "") == "BONE"
            and bool(getattr(camera, "parent_bone", ""))
            and bpy.data.objects.get(parent.name) == parent
        )
    except (AttributeError, ReferenceError, TypeError):
        parent = None
        has_live_bone_parent = False
    if has_live_bone_parent:
        return parent == armature
    return bool(
        (owner_uid and owner_uid == _armature_session_uid(armature))
        or (owner_name and owner_name == armature.name)
    )


def _rig_delete_external_helpers(armature, owned_objects):
    helpers = set()
    heuristic_helpers = set()
    for obj in tuple(bpy.data.objects):
        if obj in owned_objects:
            continue
        if (
            bool(obj.get(SPACE_HELPER_PROPERTY, False))
            and getattr(obj, "parent", None) == armature
        ):
            helpers.add(obj)
            continue
        if obj.type != "CAMERA":
            continue
        marked, _owner_name, _owner_uid = _attached_camera_owner_marker(obj)
        if marked:
            if _attached_camera_marker_matches(obj, armature):
                helpers.add(obj)
            continue
        if (
            obj.name.startswith("Camera - ")
            and getattr(obj, "parent", None) == armature
            and getattr(obj, "parent_type", "") == "BONE"
        ):
            helpers.add(obj)
            heuristic_helpers.add(obj)
    return helpers, heuristic_helpers


def _rig_delete_weld_helpers(armature):
    helpers = set()
    pose = getattr(armature, "pose", None)
    for pose_bone in getattr(pose, "bones", ()):
        helper = getattr(pose_bone, "custom_shape", None)
        if (
            helper is not None
            and helper.name.startswith("__WeldBoneShape")
            and helper.type == "CURVE"
            and not tuple(helper.users_collection)
        ):
            helpers.add(helper)
    return helpers


def _rig_delete_weld_helper_still_used(helper):
    for obj in bpy.data.objects:
        if obj.type != "ARMATURE" or getattr(obj, "pose", None) is None:
            continue
        for pose_bone in obj.pose.bones:
            if getattr(pose_bone, "custom_shape", None) == helper:
                return True
    return False


def _rig_delete_clear_runtime(
    armature,
    bundle = None,
    delete_object_names = (),
):
    owner_uid = _armature_session_uid(armature)
    armature_name = str(getattr(armature, "name", ""))
    armature_pointer = 0
    armature_data_pointer = 0
    try:
        armature_pointer = int(armature.as_pointer())
        armature_data_pointer = int(armature.data.as_pointer())
    except (AttributeError, ReferenceError, TypeError, ValueError):
        pass
    for state_name in ("yellow_fixed", "yellow_modes"):
        _state[state_name] = {
            key: value
            for key, value in _state.get(state_name, {}).items()
            if int(key[0]) != owner_uid
        }
    for state_name in ("yellow_hidden", "onion_enabled_owners"):
        owners = set(_state.get(state_name, set()))
        owners.discard(owner_uid)
        _state[state_name] = owners

    for state_name in ("mesh_batches", "raycast_fixed"):
        values = dict(_state.get(state_name, {}))
        values.pop(owner_uid, None)
        _state[state_name] = values

    managed_hidden = dict(_state.get("pose_hidden_armatures", {}))
    managed_hidden.pop(owner_uid, None)
    _state["pose_hidden_armatures"] = managed_hidden

    overlay_saved = dict(_state.get("armature_overlay_saved", {}))
    overlay_saved.pop(armature_data_pointer, None)
    _state["armature_overlay_saved"] = overlay_saved
    for state_name in (
        "roblox_constraints_normalized",
        "roblox_constraints_new_rigs",
    ):
        values = set(_state.get(state_name, set()))
        values.discard(armature_pointer)
        _state[state_name] = values
    if bundle is not None:
        try:
            master_pointer = int(bundle["master"].as_pointer())
        except (AttributeError, KeyError, ReferenceError, TypeError, ValueError):
            master_pointer = 0
        processed = set(_state.get("smart_material_processed_rigs", set()))
        processed.discard(master_pointer)
        _state["smart_material_processed_rigs"] = processed

    pending_rigs = set(_state.get("pose_mode_pending_rigs", set()))
    pending_rigs.discard(armature_name)
    _state["pose_mode_pending_rigs"] = pending_rigs
    _state["unparent_rel_cache"] = {
        key: value
        for key, value in _state.get("unparent_rel_cache", {}).items()
        if not str(key).startswith(f"{armature_name}::")
    }
    if _state.get("unparent_export_armature") == armature:
        _state["unparent_export_armature"] = None
    _state["bone_label_selection_signature"] = None

    delete_object_names = {str(name) for name in delete_object_names}
    if (
        int(_state.get("part_pivot_armature", 0) or 0) == armature_pointer
        or str(_state.get("part_pivot_object", "")) in delete_object_names
    ):
        try:
            _disable_part_pivot(bpy.context)
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            _state["part_pivot_armature"] = 0
            _state["part_pivot_bone"] = ""
            _state["part_pivot_object"] = ""
            _state["part_pivot_object_local"] = None
            _state["part_pivot_objects"] = ()
            _state["part_pivot_selection_signature"] = ()
            _state["part_pivot_saved"] = None
            _state["part_pivot_last_signature"] = None

    for state_name in (
        "pin_snap_latches",
        "pin_snap_departing",
        "pin_snap_detached",
        "pin_snap_transform_seen",
    ):
        _state[state_name] = set(_state.get(state_name, set()))
    contact_keys = {
        _surface_contact_snap_key(guide)
        for guide in _surface_contact_guides()
        if str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, "")) == armature_name
    }
    target_prefixes = (
        f"YELLOW:{owner_uid}:",
        f"CONTACT:{owner_uid}:",
    )

    def is_target_key(key):
        key = str(key)
        return key in contact_keys or key.startswith(target_prefixes)

    for state_name in (
        "pin_snap_latches",
        "pin_snap_departing",
        "pin_snap_detached",
        "pin_snap_transform_seen",
    ):
        _state[state_name] = {
            key
            for key in _state.get(state_name, set())
            if not is_target_key(key)
        }
    _state["pin_snap_initial_detached"] = {
        key: value
        for key, value in _state.get("pin_snap_initial_detached", {}).items()
        if not is_target_key(key)
    }

    selected_key = _pin_selected_target_key()
    if selected_key and is_target_key(selected_key):
        _pin_deselect_target(push_history = False)
    else:
        _state["pin_gizmo_axes_visible"] = {
            key: value
            for key, value in _state.get(
                "pin_gizmo_axes_visible",
                {},
            ).items()
            if not is_target_key(key)
        }

    signature = _state.get("pin_gizmo_selection_keys", ())
    if isinstance(signature, (tuple, list)) and len(signature) >= 3:
        scope = tuple(
            uid for uid in signature[0] if int(uid) != owner_uid
        )
        selected = tuple(
            key for key in signature[1] if int(key[0]) != owner_uid
        )
        active = signature[2]
        if active and int(active[0]) == owner_uid:
            active = (0, "")
        _state["pin_gizmo_selection_keys"] = (scope, selected, active)

    pending_click = _state.get("pin_gizmo_pending_click")
    if pending_click and is_target_key(pending_click[0]):
        _state["pin_gizmo_pending_click"] = None
    _state["pin_gizmo_deferred_finishes"] = [
        item
        for item in _state.get("pin_gizmo_deferred_finishes", ())
        if (
            int(item.get("armature_uid", 0) or 0) != owner_uid
            and str(item.get("armature_name", "")) != armature_name
            and not is_target_key(item.get("target_key", ""))
        )
    ]
    _state["pin_yellow_history_fallbacks"] = {
        key: value
        for key, value in _state.get(
            "pin_yellow_history_fallbacks",
            {},
        ).items()
        if int(key[0]) != owner_uid
    }

    snapshot = _state.get("pin_history_contact_snapshot")
    if isinstance(snapshot, dict):
        filtered_snapshot = dict(snapshot)
        for field in ("targets", "engaged", "selected"):
            values = snapshot.get(field, {})
            if isinstance(values, dict):
                filtered_snapshot[field] = {
                    key: value
                    for key, value in values.items()
                    if int(key[0]) != owner_uid
                }
            else:
                filtered_snapshot[field] = {
                    key for key in values if int(key[0]) != owner_uid
                }

        _state["pin_history_contact_snapshot"] = filtered_snapshot

    clipboard = _state.get("pin_clipboard")
    if isinstance(clipboard, dict):
        owners = tuple(clipboard.get("owners", ()))
        if owners:
            remaining_owners = [
                entry
                for entry in owners
                if (
                    int(entry.get("session_uid", 0) or 0) != owner_uid
                    and str(entry.get("armature_name", "")) != armature_name
                )
            ]
            if remaining_owners:
                clipboard = dict(clipboard)
                clipboard["owners"] = remaining_owners
                _state["pin_clipboard"] = clipboard
            else:
                _state["pin_clipboard"] = None
    _set_onion_property(
        getattr(bpy.context, "window_manager", None),
        bool(_state.get("onion_enabled_owners", set())),
    )


def _rig_delete_purge_datablock_runtime(resource_name, datablock):
    try:
        pointer = int(datablock.as_pointer())
    except (AttributeError, ReferenceError, TypeError, ValueError):
        return
    if resource_name == "armatures":
        saved = dict(_state.get("armature_overlay_saved", {}))
        saved.pop(pointer, None)
        _state["armature_overlay_saved"] = saved
    elif resource_name == "materials":
        baseline = _state.get("material_import_baseline")
        if baseline is not None:
            baseline = set(baseline)
            baseline.discard(pointer)
            _state["material_import_baseline"] = baseline
    elif resource_name == "actions":
        pointers = {pointer}
        for slot in getattr(datablock, "slots", ()):
            try:
                pointers.add(int(slot.as_pointer()))
            except (AttributeError, ReferenceError, TypeError, ValueError):
                pass
        for groups in _action_group_owners(datablock):
            for group in groups:
                try:
                    pointers.add(int(group.as_pointer()))
                except (AttributeError, ReferenceError, TypeError, ValueError):
                    pass
        _state["expanded_animation_channels"] = {
            key
            for key in _state.get("expanded_animation_channels", set())
            if int(key[1]) not in pointers
        }
        _state["animation_channel_content"] = {
            key: value
            for key, value in _state.get(
                "animation_channel_content",
                {},
            ).items()
            if int(key[1]) not in pointers
        }


def _rig_delete_remove_orphans(inventory):
    removed = 0
    direct = set(inventory.get("direct", set()))
    heuristic = set(inventory.get("heuristic", set()))
    collections = (
        ("armatures", bpy.data.armatures),
        ("cameras", bpy.data.cameras),
        ("curves", bpy.data.curves),
        ("lights", bpy.data.lights),
        ("meshes", bpy.data.meshes),
        ("materials", bpy.data.materials),
        ("node_groups", bpy.data.node_groups),
        ("textures", bpy.data.textures),
        ("images", bpy.data.images),
        ("actions", bpy.data.actions),
    )
    for resource_name, data_collection in collections:
        for datablock in tuple(inventory.get(resource_name, ())):
            try:
                if data_collection.get(datablock.name) != datablock:
                    continue
                if getattr(datablock, "library", None) is not None:
                    continue
                if _rig_delete_real_users(datablock) != 0:
                    continue
                fake_user = bool(getattr(datablock, "use_fake_user", False))
                if (
                    fake_user
                    and datablock in heuristic
                    and datablock not in direct
                ):
                    continue
                if fake_user:
                    datablock.use_fake_user = False
                if _rig_delete_real_users(datablock) != 0:
                    continue
                _rig_delete_purge_datablock_runtime(
                    resource_name,
                    datablock,
                )
                data_collection.remove(datablock)
                removed += 1
            except (AttributeError, ReferenceError, RuntimeError, TypeError):
                continue
    return removed


def _rig_delete_reenter_pose(context, survivor_names, active_name):
    survivors = tuple(
        obj
        for name in survivor_names
        if (
            (obj := bpy.data.objects.get(name)) is not None
            and obj.type == "ARMATURE"
        )
    )
    if not survivors:
        return False
    for obj in context.view_layer.objects:
        try:
            obj.select_set(False)
        except (AttributeError, ReferenceError, RuntimeError):
            pass
    selected = []
    for armature in survivors:
        try:
            armature.hide_set(False)
            armature.select_set(True)
            if armature.select_get():
                selected.append(armature)
        except (AttributeError, ReferenceError, RuntimeError):
            continue
    if not selected:
        return False
    active = bpy.data.objects.get(active_name) if active_name else None
    if active not in selected:
        active = selected[0]
    try:
        _set_selected_armatures_pose_mode(context, selected, active)
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return False
    _sync_pose_session_armature_visibility(context)
    return True
