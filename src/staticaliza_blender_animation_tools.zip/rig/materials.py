"""Imported rig material, texture, and clothing compatibility helpers."""

from ..core.runtime import *  # noqa: F403

def _clear_material_input_links(node_tree, socket_names, visited = None):
    if node_tree is None:
        return 0
    if getattr(node_tree, "library", None) is not None:
        return 0

    if visited is None:
        visited = set()

    tree_id = node_tree.as_pointer()
    if tree_id in visited:
        return 0
    visited.add(tree_id)

    removed = 0

    for node in node_tree.nodes:
        for socket_name in socket_names:
            socket = node.inputs.get(socket_name)
            if not socket or not socket.is_linked:
                continue

            for link in tuple(socket.links):
                node_tree.links.remove(link)
                removed += 1

        if node.type == "GROUP" and getattr(node, "node_tree", None):
            removed += _clear_material_input_links(node.node_tree, socket_names, visited)

    return removed

def dp_clear_material_links():
    removed = 0
    visited = set()

    for material in bpy.data.materials:
        if getattr(material, "library", None) is not None:
            continue
        if _is_bundled_template_baseplate_material(material):
            continue
        node_tree = getattr(material, "node_tree", None)
        if node_tree is None:
            continue
        removed += _clear_material_input_links(node_tree, {"Base Color", "Alpha"}, visited)

    return removed


def _is_bundled_template_baseplate_material(material):
    if material is None or material.name != "Baseplate":
        return False
    node_tree = getattr(material, "node_tree", None)
    if node_tree is None or not any(
        node.type == "TEX_IMAGE"
        and getattr(getattr(node, "image", None), "name", "") == "Baseplate.png"
        for node in node_tree.nodes
    ):
        return False

    baseplate = bpy.data.objects.get("Baseplate")
    if baseplate is None or baseplate.type != "MESH":
        return False
    return any(slot.material == material for slot in baseplate.material_slots)

def _strip_blender_numeric_suffix(name):
    base, separator, suffix = str(name).rpartition(".")
    if separator and suffix.isdigit():
        return base
    return name


def _find_child_collection_by_base_name(collection, base_name):
    if collection is None:
        return None
    for child in collection.children:
        if _strip_blender_numeric_suffix(child.name) == base_name:
            return child
    return None


def _object_world_bounds_center(obj):
    if not getattr(obj, "bound_box", None):
        return obj.matrix_world.to_translation()
    center = Vector((0.0, 0.0, 0.0))
    for corner in obj.bound_box:
        center += Vector(corner)
    return obj.matrix_world @ (center / 8.0)


def _is_matching_clothing_layer(base_obj, candidate):
    base_dimensions = tuple(abs(float(axis)) for axis in base_obj.dimensions)
    candidate_dimensions = tuple(abs(float(axis)) for axis in candidate.dimensions)
    if min(base_dimensions) <= 1.0e-6 or min(candidate_dimensions) <= 1.0e-6:
        return False

    for base_axis, candidate_axis in zip(base_dimensions, candidate_dimensions):
        if abs(base_axis - candidate_axis) / max(base_axis, candidate_axis) > 0.08:
            return False

    largest_dimension = max(max(base_dimensions), max(candidate_dimensions))
    center_distance = (
        _object_world_bounds_center(base_obj)
        - _object_world_bounds_center(candidate)
    ).length
    return center_distance <= largest_dimension * 0.03


def _set_imported_clothing_layer_offsets(parts_collection, enabled):
    mesh_objects = [
        obj for obj in parts_collection.all_objects if obj.type == "MESH"
    ]
    if not enabled:
        removed = 0
        for obj in mesh_objects:
            modifier = obj.modifiers.get(CLOTHING_LAYER_OFFSET_MODIFIER)
            if modifier is not None:
                obj.modifiers.remove(modifier)
                removed += 1
        return -removed

    families = {}
    for obj in mesh_objects:
        families.setdefault(_strip_blender_numeric_suffix(obj.name), []).append(obj)

    adjusted = 0
    for canonical_name, family in families.items():
        if len(family) < 2:
            continue

        linked_candidates = [
            obj for obj in family if _object_has_linked_base_color(obj)
        ]
        unlinked_candidates = [
            obj for obj in family if not _object_has_linked_base_color(obj)
        ]
        has_material_signal = bool(linked_candidates and unlinked_candidates)
        body_candidates = unlinked_candidates if has_material_signal else family
        body_candidates.sort(
            key = lambda obj: (
                float(obj.dimensions.x * obj.dimensions.y * obj.dimensions.z),
                obj.name != canonical_name,
                obj.name,
            )
        )
        body_obj = body_candidates[0]
        body_volume = abs(float(
            body_obj.dimensions.x
            * body_obj.dimensions.y
            * body_obj.dimensions.z
        ))

        for obj in family:
            if (
                obj == body_obj
                or (
                    has_material_signal
                    and not _object_has_linked_base_color(obj)
                )
                or not _is_matching_clothing_layer(body_obj, obj)
            ):
                continue
            if not has_material_signal:
                candidate_volume = abs(float(
                    obj.dimensions.x * obj.dimensions.y * obj.dimensions.z
                ))
                if candidate_volume <= body_volume * 1.0001:
                    continue

            modifier = obj.modifiers.get(CLOTHING_LAYER_OFFSET_MODIFIER)
            if modifier is None:
                modifier = obj.modifiers.new(
                    name = CLOTHING_LAYER_OFFSET_MODIFIER,
                    type = "DISPLACE",
                )
                adjusted += 1
            positive_dimensions = [
                abs(float(axis)) for axis in body_obj.dimensions if abs(float(axis)) > 1.0e-6
            ]
            reference_dimension = min(positive_dimensions, default = 1.0)
            modifier.direction = "NORMAL"
            modifier.mid_level = 0.0
            modifier.strength = max(0.001, min(0.02, reference_dimension * 0.005))

    return adjusted

def _get_smart_material_rig(collection):
    if not collection.name.startswith("RIG: "):
        return None

    rig_name = _strip_blender_numeric_suffix(collection.name[5:].strip())
    parts_collection = _find_child_collection_by_base_name(collection, "Parts")
    if not rig_name or parts_collection is None:
        return None

    armature_name = f"__{rig_name}_Armature"
    meta_name = f"__{rig_name}Meta"
    armature = None
    meta = None

    for obj in collection.all_objects:
        obj_name = _strip_blender_numeric_suffix(obj.name)
        if obj.type == "ARMATURE" and obj_name == armature_name:
            armature = obj
        elif obj.type == "EMPTY" and obj_name == meta_name:
            meta = obj

    if armature is None or meta is None:
        return None

    return rig_name, parts_collection


def _image_source_path(image):
    stored_path = str(image.get(RIG_TEXTURE_SOURCE_KEY, "")).strip()
    if stored_path and os.path.isfile(stored_path):
        return os.path.normcase(os.path.realpath(stored_path))

    raw_path = str(getattr(image, "filepath_raw", "") or image.filepath).strip()
    if not raw_path:
        return ""
    try:
        absolute_path = bpy.path.abspath(raw_path, library=image.library)
    except (AttributeError, RuntimeError, TypeError, ValueError):
        absolute_path = bpy.path.abspath(raw_path)
    return os.path.normcase(os.path.realpath(absolute_path))


def _safe_rig_texture_name(name):
    safe_name = "".join(
        character if character.isalnum() or character in {"-", "_", "."} else "_"
        for character in str(name)
    ).strip("._")
    return safe_name or "texture"


def _copy_image_color_settings(source, destination):
    for attribute in ("alpha_mode", "use_view_as_render"):
        try:
            setattr(destination, attribute, getattr(source, attribute))
        except (AttributeError, TypeError, ValueError):
            pass
    try:
        destination.colorspace_settings.name = source.colorspace_settings.name
    except (AttributeError, TypeError, ValueError):
        pass


def _isolated_rig_image(source_image, rig_name, rig_token, image_cache):
    source_path = _image_source_path(source_image)
    cache_key = source_path or f"IMAGE:{source_image.as_pointer()}"
    cached = image_cache.get(cache_key)
    if cached is not None:
        return cached

    isolated = None
    if source_path and os.path.isfile(source_path):
        try:
            isolated = bpy.data.images.load(source_path, check_existing=False)
        except (RuntimeError, OSError):
            isolated = None
    if isolated is None:
        isolated = source_image.copy()

    _copy_image_color_settings(source_image, isolated)
    source_filename = os.path.basename(source_path) if source_path else source_image.name
    source_filename = _safe_rig_texture_name(source_filename)
    isolated.name = f"{rig_name}::{source_filename}"
    isolated[RIG_TEXTURE_SOURCE_KEY] = source_path
    isolated[RIG_TEXTURE_OWNER_KEY] = rig_name
    if isolated.packed_file is None:
        try:
            isolated.pack()
        except (RuntimeError, OSError):
            pass
    if isolated.packed_file is not None:
        isolated.filepath = (
            f"//.staticaliza_rig_textures/{rig_token}/{source_filename}"
        )
    image_cache[cache_key] = isolated
    return isolated


def _isolate_node_tree_images(
    node_tree,
    rig_name,
    rig_token,
    image_cache,
    group_cache,
    visited=None,
):
    if node_tree is None:
        return 0
    if visited is None:
        visited = set()
    pointer = node_tree.as_pointer()
    if pointer in visited:
        return 0
    visited.add(pointer)

    replaced = 0
    for node in node_tree.nodes:
        if node.type == "TEX_IMAGE" and node.image is not None:
            isolated = _isolated_rig_image(
                node.image,
                rig_name,
                rig_token,
                image_cache,
            )
            if isolated is not node.image:
                node.image = isolated
                replaced += 1
            continue

        if node.type != "GROUP" or getattr(node, "node_tree", None) is None:
            continue
        original_group = node.node_tree
        group_pointer = original_group.as_pointer()
        isolated_group = group_cache.get(group_pointer)
        if isolated_group is None:
            isolated_group = original_group.copy()
            isolated_group.name = f"{rig_name}::{original_group.name}"
            group_cache[group_pointer] = isolated_group
        node.node_tree = isolated_group
        replaced += _isolate_node_tree_images(
            isolated_group,
            rig_name,
            rig_token,
            image_cache,
            group_cache,
            visited,
        )
    return replaced


def _isolate_imported_rig_textures(rig_collection, parts_collection):
    rig_name = _strip_blender_numeric_suffix(rig_collection.name[5:].strip())
    token_source = (
        f"{rig_collection.name}|{rig_collection.as_pointer()}|{time.time_ns()}"
    )
    rig_token = hashlib.sha1(token_source.encode("utf-8")).hexdigest()[:12]
    material_cache = {}
    image_cache = {}
    group_cache = {}
    original_materials = set()
    original_images = set()
    replaced_images = 0

    for obj in parts_collection.all_objects:
        if obj.type != "MESH":
            continue
        for slot in obj.material_slots:
            source_material = slot.material
            if source_material is None:
                continue
            material_pointer = source_material.as_pointer()
            isolated_material = material_cache.get(material_pointer)
            if isolated_material is None:
                isolated_material = source_material.copy()
                isolated_material.name = f"{rig_name}::{source_material.name}"
                original_materials.add(source_material)
                for node in getattr(
                    getattr(source_material, "node_tree", None),
                    "nodes",
                    (),
                ):
                    if node.type == "TEX_IMAGE" and node.image is not None:
                        original_images.add(node.image)
                replaced_images += _isolate_node_tree_images(
                    isolated_material.node_tree,
                    rig_name,
                    rig_token,
                    image_cache,
                    group_cache,
                )
                material_cache[material_pointer] = isolated_material
            slot.material = isolated_material

    for material in original_materials:
        if material.users == 0:
            bpy.data.materials.remove(material)
    for image in original_images:
        if image.users == 0 and image.name != "Baseplate.png":
            bpy.data.images.remove(image)

    return replaced_images, len(material_cache)


def _isolate_newly_imported_rig_textures(previous_collection_pointers):
    isolated_images = 0
    isolated_materials = 0
    for collection in bpy.data.collections:
        if collection.as_pointer() in previous_collection_pointers:
            continue
        if not collection.name.startswith("RIG: "):
            continue
        parts_collection = _find_child_collection_by_base_name(
            collection,
            "Parts",
        )
        if parts_collection is None:
            continue
        image_count, material_count = _isolate_imported_rig_textures(
            collection,
            parts_collection,
        )
        isolated_images += image_count
        isolated_materials += material_count
    return isolated_images, isolated_materials

def _smart_disconnect_base_color_links(node_tree, visited = None):
    if node_tree is None or getattr(node_tree, "library", None) is not None:
        return 0

    if visited is None:
        visited = set()

    tree_id = node_tree.as_pointer()
    if tree_id in visited:
        return 0
    visited.add(tree_id)

    removed = 0
    for node in node_tree.nodes:
        if node.type == "BSDF_PRINCIPLED":
            base_color = node.inputs.get("Base Color")
            normal = node.inputs.get("Normal")
            if base_color and base_color.is_linked and normal and normal.is_linked:
                for link in tuple(base_color.links):
                    node_tree.links.remove(link)
                    removed += 1

        if node.type == "GROUP" and getattr(node, "node_tree", None):
            removed += _smart_disconnect_base_color_links(node.node_tree, visited)

    return removed


def _capture_material_import_baseline():
    try:
        materials = bpy.data.materials
    except AttributeError:
        return False
    _state["material_import_baseline"] = {
        int(material.as_pointer()) for material in materials
    }
    return True


def _initialize_material_import_tracking():
    return None if _capture_material_import_baseline() else 0.1


def _standardize_imported_material_display(material):
    material.diffuse_color = IMPORTED_MATERIAL_DISPLAY_COLOR
    material.metallic = 0.0
    material.roughness = 0.5

def _smart_material_import_scan(scene):
    context = bpy.context
    wm = getattr(context, "window_manager", None)
    if wm is None:
        return

    smart_enabled = getattr(wm, "smart_material_import_enabled", True)
    display_enabled = getattr(
        wm,
        "standardize_imported_material_display_enabled",
        True,
    )
    clothing_offset_enabled = getattr(
        wm,
        "prevent_clothing_layer_clipping_enabled",
        False,
    )

    processed = _state.setdefault("smart_material_processed_rigs", set())
    material_baseline = _state.get("material_import_baseline")
    if material_baseline is None:
        if not _capture_material_import_baseline():
            return
        material_baseline = _state["material_import_baseline"]
    current_rigs = set()

    for collection in bpy.data.collections:
        rig = _get_smart_material_rig(collection)
        if rig is None:
            continue

        rig_name, parts_collection = rig
        rig_id = collection.as_pointer()
        current_rigs.add(rig_id)
        if rig_id in processed:
            continue

        removed = 0
        standardized = 0
        adjusted_layers = 0
        material_ids = set()
        visited_trees = set()

        for obj in parts_collection.all_objects:
            if obj.type != "MESH":
                continue
            for slot in obj.material_slots:
                material = slot.material
                if material is None or getattr(material, "library", None) is not None:
                    continue
                material_id = material.as_pointer()
                if material_id in material_ids:
                    continue
                material_ids.add(material_id)
                if smart_enabled:
                    removed += _smart_disconnect_base_color_links(
                        material.node_tree,
                        visited_trees,
                    )
                if display_enabled and material_id not in material_baseline:
                    _standardize_imported_material_display(material)
                    standardized += 1

        adjusted_layers = _set_imported_clothing_layer_offsets(
            parts_collection,
            clothing_offset_enabled,
        )

        processed.add(rig_id)
        if removed:
            print(f"[Smart Material Import] Removed {removed} Base Color link(s) from '{rig_name}'.")
        if standardized:
            print(
                f"[Smart Material Import] Standardized {standardized} viewport "
                f"material(s) on '{rig_name}'."
            )
        if adjusted_layers > 0:
            print(
                f"[Smart Material Import] Offset {adjusted_layers} clothing "
                f"layer(s) on '{rig_name}' to prevent clipping."
            )
        elif adjusted_layers < 0:
            print(
                f"[Smart Material Import] Removed {-adjusted_layers} clothing "
                f"layer offset(s) from '{rig_name}'."
            )

    processed.intersection_update(current_rigs)

def _on_smart_material_import_toggle(self, context):
    _state["smart_material_processed_rigs"] = set()
    _smart_material_import_scan(context.scene)

@persistent
def _smart_material_import_depsgraph_update(scene, depsgraph):
    if (
        _state.get("pin_history_active", False)
        or _state.get("pin_history_syncing", False)
        or _state.get("pin_history_direction", "")
    ):
        return
    for update in depsgraph.updates:
        datablock = getattr(update, "id", None)
        if not isinstance(datablock, bpy.types.Object):
            continue
        if datablock.type == "ARMATURE" or (
            datablock.type == "EMPTY"
            and datablock.name.startswith("__")
            and "Meta" in datablock.name
        ):
            _schedule_smart_material_import_scan()
            return


def _run_smart_material_import_scan():
    context = bpy.context
    if (
        _state.get("pin_history_active", False)
        or _state.get("pin_history_syncing", False)
        or _state.get("pin_history_direction", "")
        or _pin_primary_mouse_pressed()
        or _window_manager_has_modal_operator(context)
    ):
        # Undo/Redo can invalidate every RNA wrapper while its handlers run.
        # Keep this timer pending and reacquire collections on a later tick.
        return 0.1
    _state["smart_material_scan_pending"] = False
    if context and context.scene:
        _smart_material_import_scan(context.scene)
    return None


def _schedule_smart_material_import_scan(delay = 0.15):
    if _state.get("smart_material_scan_pending", False):
        return
    _state["smart_material_scan_pending"] = True
    try:
        register_owned_timer(
            _run_smart_material_import_scan,
            first_interval = delay,
        )
    except Exception:
        _state["smart_material_scan_pending"] = False
