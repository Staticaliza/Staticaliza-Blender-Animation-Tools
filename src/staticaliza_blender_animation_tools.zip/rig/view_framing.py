"""Smoothly frame a newly imported rig from its object-space front."""

from ..core.runtime import *  # noqa: F403


_RIG_FRONT_DIRECTION = Vector((0.0, -1.0, 0.0))


def _import_view_area(context, requested_window, requested_area):
    window_manager = getattr(context, "window_manager", None)
    if window_manager is None:
        return None

    fallback = None
    for window in tuple(window_manager.windows):
        screen = getattr(window, "screen", None)
        if screen is None:
            continue
        for area in tuple(screen.areas):
            if area.type != "VIEW_3D":
                continue
            record = (window, screen, area)
            if fallback is None or area.width * area.height > fallback[2].width * fallback[2].height:
                fallback = record
            try:
                if (
                    int(window.as_pointer()) == requested_window
                    and int(area.as_pointer()) == requested_area
                ):
                    return record
            except (AttributeError, ReferenceError):
                continue
    return fallback


def _rig_framing_objects(armatures):
    objects = []
    seen = set()
    for armature in armatures:
        parts = _find_roblox_parts_collection(armature)
        candidates = tuple(parts.all_objects) if parts is not None else (armature,)
        for obj in candidates:
            try:
                pointer = int(obj.as_pointer())
                usable = obj.type in {"MESH", "CURVE", "SURFACE", "META", "FONT"}
            except (AttributeError, ReferenceError):
                continue
            if usable and pointer not in seen:
                seen.add(pointer)
                objects.append(obj)
    return tuple(objects)


def _evaluated_world_matrix(obj, depsgraph):
    try:
        return obj.evaluated_get(depsgraph).matrix_world.copy()
    except (AttributeError, ReferenceError, RuntimeError):
        return obj.matrix_world.copy()


def _rig_framing_points(objects, depsgraph):
    points = []
    for obj in objects:
        try:
            evaluated = obj.evaluated_get(depsgraph)
            matrix = evaluated.matrix_world
            bounds = tuple(evaluated.bound_box)
        except (AttributeError, ReferenceError, RuntimeError):
            try:
                matrix = obj.matrix_world
                bounds = tuple(obj.bound_box)
            except (AttributeError, ReferenceError, RuntimeError):
                continue
        points.extend(matrix @ Vector(corner) for corner in bounds)
    return tuple(points)


def _rig_front_rotation(armatures, depsgraph):
    armature = armatures[0] if armatures else None
    if armature is None:
        return _RIG_FRONT_DIRECTION.to_track_quat("-Z", "Y")
    try:
        armature_rotation = _evaluated_world_matrix(
            armature,
            depsgraph,
        ).to_quaternion()
        armature_rotation.normalize()
        direction = armature_rotation @ _RIG_FRONT_DIRECTION
        # Imported rigs can carry conversion roll on their object transform.
        # Preserve the armature-derived facing direction while keeping the
        # resulting viewport upright relative to Blender's world Z axis.
        level_direction = Vector((direction.x, direction.y, 0.0))
        if level_direction.length_squared > 1.0e-8:
            direction = level_direction.normalized()
        else:
            direction.normalize()
        return direction.to_track_quat("-Z", "Y")
    except (AttributeError, ReferenceError, RuntimeError, ValueError):
        return _RIG_FRONT_DIRECTION.to_track_quat("-Z", "Y")


def _rig_view_distance(space, region, points, center, rotation):
    local_points = tuple(rotation.inverted() @ (point - center) for point in points)
    half_width = max(abs(point.x) for point in local_points)
    half_height = max(abs(point.y) for point in local_points)
    half_depth = max(abs(point.z) for point in local_points)
    aspect = max(0.25, float(region.width) / max(1.0, float(region.height)))
    lens = max(1.0, float(getattr(space, "lens", 50.0)))
    horizontal_fov = 2.0 * math.atan(36.0 / (2.0 * lens))
    vertical_fov = 2.0 * math.atan(math.tan(horizontal_fov * 0.5) / aspect)
    distance = max(
        half_width / max(0.01, math.tan(horizontal_fov * 0.5)),
        half_height / max(0.01, math.tan(vertical_fov * 0.5)),
    ) + half_depth
    return max(0.25, distance * 1.18)


def _smooth_frame_imported_rig(request):
    context = bpy.context
    scene = getattr(context, "scene", None)
    if scene is None:
        return None
    armatures = tuple(
        armature
        for name in request["armatures"]
        if (armature := scene.objects.get(name)) is not None
        and armature.type == "ARMATURE"
    )
    if not armatures:
        return None
    area_record = _import_view_area(
        context,
        request["window"],
        request["area"],
    )
    if area_record is None:
        return None
    _window, _screen, area = area_record
    space = area.spaces.active
    region_data = getattr(space, "region_3d", None)
    region = next((item for item in area.regions if item.type == "WINDOW"), None)
    if region_data is None or region is None:
        return None

    objects = _rig_framing_objects(armatures)
    if not objects:
        return None
    depsgraph = context.evaluated_depsgraph_get()
    points = _rig_framing_points(objects, depsgraph)
    if not points:
        return None
    center = sum(points, Vector()) / len(points)
    rotation = _rig_front_rotation(armatures, depsgraph)
    distance = _rig_view_distance(space, region, points, center, rotation)

    try:
        start_location = region_data.view_location.copy()
        start_rotation = region_data.view_rotation.copy()
        start_distance = max(1.0e-6, float(region_data.view_distance))
        region_data.view_perspective = "PERSP"
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return None

    serial = request["serial"]
    started = time.monotonic()
    smooth_view_ms = float(
        getattr(getattr(context.preferences, "view", None), "smooth_view", 200)
    )
    duration = max(0.001, smooth_view_ms / 1000.0)

    def animate_view():
        if serial != _state.get("rig_view_frame_serial"):
            return None
        try:
            factor = min(1.0, max(0.0, (time.monotonic() - started) / duration))
            eased = factor * factor * (3.0 - 2.0 * factor)
            region_data.view_location = start_location.lerp(center, eased)
            region_data.view_rotation = start_rotation.slerp(rotation, eased)
            region_data.view_distance = math.exp(
                math.log(start_distance) * (1.0 - eased)
                + math.log(distance) * eased
            )
            area.tag_redraw()
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            return None
        if factor >= 1.0:
            snapshot = _free_view_snapshot(region_data)
            if snapshot is not None:
                _state["free_view_master"] = snapshot
            return None
        return 1.0 / 120.0

    register_owned_timer(animate_view, first_interval = 0.0)
    return None


def _run_scheduled_imported_rig_framing():
    request = _state.get("rig_view_frame_request")
    _state["rig_view_frame_request"] = None
    if request is not None:
        _smooth_frame_imported_rig(request)
    return None


def _schedule_imported_rig_framing(armatures, context, delay = 0.08):
    names = tuple(
        armature.name
        for armature in armatures
        if armature is not None and armature.type == "ARMATURE"
    )
    if not names:
        return
    _state["rig_view_frame_serial"] = int(_state.get("rig_view_frame_serial", 0)) + 1
    try:
        window_pointer = int(context.window.as_pointer())
        area_pointer = int(context.area.as_pointer()) if context.area else 0
    except (AttributeError, ReferenceError):
        window_pointer = 0
        area_pointer = 0
    _state["rig_view_frame_request"] = {
        "armatures": names,
        "window": window_pointer,
        "area": area_pointer,
        "serial": _state["rig_view_frame_serial"],
    }
    if not bpy.app.timers.is_registered(_run_scheduled_imported_rig_framing):
        register_owned_timer(
            _run_scheduled_imported_rig_framing,
            first_interval = max(0.01, float(delay)),
        )
