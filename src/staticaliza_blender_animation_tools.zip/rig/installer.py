"""Combined extension updater execution and user-facing installer operators."""

from ..core.runtime import *  # noqa: F403

def _show_extension_update_result(message, icon):
    window_manager = getattr(bpy.context, "window_manager", None)
    if window_manager is None:
        print(f"[Roblox Animator Utils] {message}")
        return

    def draw(self, context):
        self.layout.label(text = message)

    window_manager.popup_menu(draw, title = "Extension Update", icon = icon)


def _perform_combined_extension_update():
    roblox_filepath = None
    utils_filepath = None

    _persist_runtime_session_state(bpy.context)

    if _extension_repository_is_locked():
        _state["extension_update_lock_waits"] += 1
        if _state["extension_update_lock_waits"] <= 20:
            _state["extension_update_status"] = "Waiting for Blender's extension repository..."
            _tag_redraw_all_view3d()
            return 0.5

        _show_extension_update_result(
            "Update paused because the User Default repository is still locked. "
            "Wait for the current install to finish or use Force Unlock Repository.",
            "ERROR",
        )
        _state["extension_update_running"] = False
        _state["extension_update_status"] = ""
        _state["extension_update_lock_waits"] = 0
        _tag_redraw_all_view3d()
        return None

    _state["extension_update_lock_waits"] = 0

    try:
        _state["extension_update_status"] = "Downloading Roblox Animator and Utils..."
        _tag_redraw_all_view3d()
        tag, asset_name, asset_url = _get_roblox_release_asset()
        roblox_filepath = _download_release_asset(asset_name, asset_url)
        utils_filepath, utils_version = _download_utils_package()

        # Keep Roblox Animator above Utils in the N-panel category order.
        _state["extension_update_status"] = "Installing the downloaded extensions..."
        _tag_redraw_all_view3d()
        _install_roblox_addon(roblox_filepath)
        _install_utils_addon(utils_filepath)
        _show_extension_update_result(
            f"Installed Roblox Animator {tag} and Roblox Animator Utils v{utils_version}.",
            "CHECKMARK",
        )
    except Exception as exc:
        _show_extension_update_result(f"Update failed: {exc}", "ERROR")
    finally:
        for filepath in (roblox_filepath, utils_filepath):
            if filepath and os.path.exists(filepath):
                try:
                    os.remove(filepath)
                except OSError:
                    pass
        _state["extension_update_running"] = False
        _state["extension_update_status"] = ""
        _state["extension_update_lock_waits"] = 0
        _tag_redraw_all_view3d()

    return None


class ANIMATOR_UTILS_OT_install_roblox_animations(bpy.types.Operator):
    bl_idname = "staticaliza.install_roblox_animations"
    bl_label = "Install Latest Extension"
    bl_description = "Install or update Roblox Animator first, then Roblox Animator Utils"
    # This operator replaces and reloads the extension that owns its RNA type.
    # Keeping it in Blender's redo/undo history leaves a freed OperatorType
    # pointer behind after that reload; hovering UI can then dereference it
    # while constructing a tooltip. Installation itself is not undoable.
    bl_options = {"INTERNAL"}

    def execute(self, context):
        if not getattr(bpy.app, "online_access", True):
            self.report({"ERROR"}, "Blender online access is disabled in Preferences.")
            return {"CANCELLED"}

        if _state["extension_update_running"]:
            self.report({"WARNING"}, "An extension update is already running.")
            return {"CANCELLED"}

        _state["extension_update_running"] = True
        _state["extension_update_status"] = "Preparing the extension update..."
        _state["extension_update_lock_waits"] = 0
        _tag_redraw_all_view3d()
        try:
            register_owned_timer(_perform_combined_extension_update, first_interval = 0.35)
        except Exception as exc:
            _state["extension_update_running"] = False
            _state["extension_update_status"] = ""
            _tag_redraw_all_view3d()
            self.report({"ERROR"}, f"Could not start extension update: {exc}")
            return {"CANCELLED"}

        self.report({"INFO"}, "Downloading the latest Roblox Animator and Utils releases.")
        return {"FINISHED"}


class ANIMATOR_UTILS_OT_open_roblox_plugins(bpy.types.Operator):
    bl_idname = "staticaliza.open_roblox_plugins"
    bl_label = "Install Roblox Plugins"
    bl_description = "Open both recommended Roblox animation plugins in the Creator Store"

    def execute(self, context):
        for url in (
            "https://create.roblox.com/store/asset/118148792788940",
            "https://create.roblox.com/store/asset/16708835782",
        ):
            bpy.ops.wm.url_open(url = url)
        return {"FINISHED"}
