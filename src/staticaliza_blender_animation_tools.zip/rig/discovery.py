"""Roblox rig discovery, armature enumeration, and display identity."""

from ..core.runtime import *  # noqa: F403

def _iter_roblox_rigs():
    seen = set()

    for collection in bpy.data.collections:
        if not collection.name.startswith("RIG: "):
            continue

        rig_name = _strip_blender_numeric_suffix(collection.name[5:].strip())
        if (
            not rig_name
            or _find_child_collection_by_base_name(collection, "Parts") is None
        ):
            continue

        armature_name = f"__{rig_name}_Armature"
        meta_name = f"__{rig_name}Meta"
        armature = None
        meta = None

        for obj in collection.all_objects:
            obj_name = _strip_blender_numeric_suffix(obj.name)
            if obj.type == "ARMATURE" and obj_name == armature_name:
                armature = obj
            elif obj.type == "EMPTY" and obj_name == meta_name:
                meta = obj

        if armature is not None and meta is not None and armature.as_pointer() not in seen:
            seen.add(armature.as_pointer())
            yield collection, armature, meta


def _iter_roblox_rig_armatures():
    for _collection, armature, _meta in _iter_roblox_rigs():
        yield armature


def _rig_display_name(armature_name):
    name = str(armature_name or "")
    if name.startswith("__"):
        name = name[2:]
    marker = "_Armature"
    marker_index = name.rfind(marker)
    if marker_index >= 0:
        suffix = name[marker_index + len(marker):]
        if not suffix or (
            suffix.startswith(".") and suffix[1:].isdigit()
        ):
            name = name[:marker_index] + suffix
    return name or str(armature_name or "Armature")

