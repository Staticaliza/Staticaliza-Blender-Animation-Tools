"""Roblox rig discovery, armature enumeration, and display identity."""

from ..core.runtime import *  # noqa: F403

def _iter_roblox_rigs():
    if extension_update_guard_active():
        return
    seen = set()

    try:
        collections = tuple(bpy.data.collections)
    except (ReferenceError, RuntimeError, UnicodeDecodeError):
        return

    for collection in collections:
        try:
            collection_name = str(collection.name)
        except (
            AttributeError,
            ReferenceError,
            RuntimeError,
            UnicodeDecodeError,
        ):
            continue
        if not collection_name.startswith("RIG: "):
            continue

        rig_name = _strip_blender_numeric_suffix(collection_name[5:].strip())
        try:
            parts = _find_child_collection_by_base_name(collection, "Parts")
        except (
            AttributeError,
            ReferenceError,
            RuntimeError,
            UnicodeDecodeError,
        ):
            continue
        if not rig_name or parts is None:
            continue

        armature_name = f"__{rig_name}_Armature"
        meta_name = f"__{rig_name}Meta"
        armature = None
        meta = None

        collection_suffix = collection_name[len(
            _strip_blender_numeric_suffix(collection_name)
        ):]
        for obj_type, base_name in (
            ("ARMATURE", armature_name),
            ("EMPTY", meta_name),
        ):
            try:
                objects = collection.all_objects
                obj = objects.get(base_name + collection_suffix)
                if obj is None and collection_suffix:
                    obj = objects.get(base_name)
                if obj is None:
                    continue
                obj_name = _strip_blender_numeric_suffix(str(obj.name))
                current_type = str(obj.type)
            except (
                AttributeError,
                ReferenceError,
                RuntimeError,
                UnicodeDecodeError,
            ):
                continue
            if current_type == "ARMATURE" and obj_name == armature_name:
                armature = obj
            elif current_type == "EMPTY" and obj_name == meta_name:
                meta = obj

        if armature is None or meta is None:
            continue
        try:
            pointer = int(armature.as_pointer())
        except (AttributeError, ReferenceError, RuntimeError, UnicodeDecodeError):
            continue
        if pointer not in seen:
            seen.add(pointer)
            yield collection, armature, meta


def _iter_roblox_rig_armatures():
    for _collection, armature, _meta in _iter_roblox_rigs():
        yield armature


def _rig_display_name(armature_name):
    name = str(armature_name or "")
    if name.startswith("__"):
        name = name[2:]
    marker = "_Armature"
    marker_index = name.rfind(marker)
    if marker_index >= 0:
        suffix = name[marker_index + len(marker):]
        if not suffix or (
            suffix.startswith(".") and suffix[1:].isdigit()
        ):
            name = name[:marker_index] + suffix
    return name or str(armature_name or "Armature")
