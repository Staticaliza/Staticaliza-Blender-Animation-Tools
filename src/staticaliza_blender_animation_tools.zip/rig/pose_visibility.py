"""Pose-rig panel scope, visibility isolation, and save restoration."""

from ..core.runtime import *  # noqa: F403

def _pose_panel_armatures(context):
    scene = getattr(context, "scene", None)
    if scene is None:
        return ()

    preferred = []
    seen = set()
    for armature in _iter_roblox_rig_armatures():
        try:
            if armature.name not in scene.objects:
                continue
            pointer = int(armature.as_pointer())
        except (AttributeError, ReferenceError):
            continue
        if pointer in seen:
            continue
        seen.add(pointer)
        preferred.append(armature)

    for armature in scene.objects:
        if armature.type != "ARMATURE":
            continue
        pointer = int(armature.as_pointer())
        if pointer in seen:
            continue
        seen.add(pointer)
        preferred.append(armature)

    return tuple(sorted(
        preferred,
        key = lambda armature: (
            _rig_display_name(armature.name).casefold(),
            armature.name.casefold(),
        ),
    ))


def _set_selected_armatures_pose_mode(context, armatures, active):
    """Enter Pose Mode with an explicit active-object context override."""
    selected = tuple(
        armature
        for armature in armatures
        if (
            armature is not None
            and armature.type == "ARMATURE"
            and armature.name in context.view_layer.objects
        )
    )
    if not selected:
        raise RuntimeError("No selectable rigs remain")
    if active not in selected:
        active = selected[0]

    context.view_layer.objects.active = active
    try:
        context.view_layer.update()
    except (AttributeError, ReferenceError, RuntimeError):
        pass

    override = {
        "active_object": active,
        "object": active,
        "selected_objects": list(selected),
        "selected_editable_objects": list(selected),
    }
    with context.temp_override(**override):
        if not bpy.ops.object.mode_set.poll():
            raise RuntimeError("Pose Mode requires an active armature")
        bpy.ops.object.mode_set(mode = "POSE")
    return selected


def _pose_armature_managed_hidden(armature):
    return _armature_session_uid(armature) in _state.get(
        "pose_hidden_armatures",
        {},
    )


def _restore_pose_session_armature_visibility():
    managed = dict(_state.get("pose_hidden_armatures", {}))
    _state["pose_hidden_armatures"] = {}
    changed = False
    for owner_uid, saved_hidden in managed.items():
        armature = _armature_from_session_uid(owner_uid)
        if armature is None:
            continue
        try:
            desired = bool(saved_hidden)
            if bool(armature.hide_get()) != desired:
                armature.hide_set(desired)
                changed = True
        except (AttributeError, ReferenceError, RuntimeError):
            continue
    # Pose isolation is strictly temporary. If Blender/add-on reload discarded
    # the runtime map while a rig was isolated, never leave that rig unusable
    # after returning to Object Mode.
    context = bpy.context
    if context is not None and getattr(context, "mode", "") != "POSE":
        for armature in _pose_panel_armatures(context):
            try:
                if armature.hide_viewport:
                    armature.hide_viewport = False
                    changed = True
                if armature.hide_select:
                    armature.hide_select = False
                    changed = True
                if armature.hide_get():
                    armature.hide_set(False)
                    changed = True
            except (AttributeError, ReferenceError, RuntimeError):
                pass
    if changed:
        _tag_redraw_all_view3d()
    return changed

def _sync_pose_session_armature_visibility(context):
    if context is None or getattr(context, "mode", "") != "POSE":
        return _restore_pose_session_armature_visibility()

    scope_uids = {
        _armature_session_uid(armature)
        for armature in _pose_scope_armatures(context)
    }
    managed = dict(_state.get("pose_hidden_armatures", {}))
    changed = False
    candidates = _pose_panel_armatures(context)
    candidate_uids = {_armature_session_uid(armature) for armature in candidates}

    for owner_uid in tuple(managed):
        if owner_uid in candidate_uids:
            continue
        armature = _armature_from_session_uid(owner_uid)
        if armature is not None:
            try:
                armature.hide_set(bool(managed[owner_uid]))
                changed = True
            except (AttributeError, ReferenceError, RuntimeError):
                pass
        managed.pop(owner_uid, None)

    for armature in candidates:
        owner_uid = _armature_session_uid(armature)
        if not owner_uid:
            continue
        if owner_uid in scope_uids:
            if owner_uid in managed:
                try:
                    if armature.hide_get():
                        armature.hide_set(False)
                        changed = True
                except (AttributeError, ReferenceError, RuntimeError):
                    pass
            continue

        if owner_uid not in managed:
            try:
                if armature.hide_viewport:
                    continue
                # After an extension/Blender reload the runtime isolation map
                # is empty, but inactive imported rigs can still carry their
                # Pose-mode hide_set state. Adopt that state as temporary
                # isolation so Active Armatures can reveal/activate the rig.
                managed[owner_uid] = False
            except (AttributeError, ReferenceError, RuntimeError):
                continue
        try:
            if not armature.hide_get():
                armature.hide_set(True)
                changed = True
        except (AttributeError, ReferenceError, RuntimeError):
            continue

    _state["pose_hidden_armatures"] = managed
    if changed:
        _tag_redraw_all_view3d()
    return changed


@persistent
def _pose_visibility_save_pre(*_):
    _persist_runtime_session_state(bpy.context)
    # Save the user's real Dope Sheet/Graph filters, never Object Mode's
    # temporary native Selected + Errors content lock.
    _restore_animation_editor_pose_states()
    _state["dynamic_parent_dual_selection_save_paused"] = True
    _restore_dynamic_parent_dual_selection_locks()
    _state["pose_visibility_resume_after_save"] = bool(
        getattr(bpy.context, "mode", "") == "POSE"
        and _state.get("pose_hidden_armatures", {})
    )
    _restore_pose_session_armature_visibility()


@persistent
def _pose_visibility_save_post(*_):
    resume = bool(_state.get("pose_visibility_resume_after_save", False))
    _state["pose_visibility_resume_after_save"] = False
    _state["dynamic_parent_dual_selection_save_paused"] = False
    _sync_dynamic_parent_dual_selection_locks(bpy.context)
    _sync_animation_editors_pose_mode(bpy.context)
    if resume:
        _sync_pose_session_armature_visibility(bpy.context)
