"""Single source of truth for the Utils extension version."""

ADDON_VERSION = (1, 7, 0)
