"""Ordered Blender class registry for the Utils extension."""

from __future__ import annotations

from typing import Any, Mapping

import bpy


UTILS_CLASS_NAMES = (
    "ANIMATOR_UTILS_OT_import_rigs_obj",
    "ANIMATOR_UTILS_OT_toggle_loop_tab",
    "ANIMATOR_UTILS_OT_set_selected_keyframe_type",
    "ANIMATOR_UTILS_OT_pin_click_away",
    "ANIMATOR_UTILS_OT_transform_selected_pin",
    "ANIMATOR_UTILS_OT_move_pin_target",
    "ANIMATOR_UTILS_OT_pose_pin_clipboard",
    "ANIMATOR_UTILS_GT_surface_contact_target",
    "ANIMATOR_UTILS_GGT_surface_contact_target",
    "ANIMATOR_UTILS_GT_yellow_pin_target",
    "ANIMATOR_UTILS_GGT_yellow_pin_target",
    "ANIMATOR_UTILS_OT_smart_dragger_transform",
    "ANIMATOR_UTILS_GT_smart_dragger",
    "ANIMATOR_UTILS_GGT_smart_draggers",
    "ANIMATOR_UTILS_GGT_pin_shared_transform",
    "ONION_SKIN_OT_ghost_toggle",
    "ANIMATOR_UTILS_OT_yellow_resync_all",
    "ANIMATOR_UTILS_OT_yellow_clear_all",
    "ANIMATOR_UTILS_OT_yellow_hide_all",
    "ANIMATOR_UTILS_OT_yellow_show",
    "ANIMATOR_UTILS_OT_yellow_apply",
    "ANIMATOR_UTILS_OT_yellow_remove",
    "ANIMATOR_UTILS_OT_yellow_pivot",
    "ANIMATOR_UTILS_MT_yellow_pin_menu",
    "ANIMATOR_UTILS_OT_yellow_menu",
    "ANIMATOR_UTILS_OT_unparent_action",
    "ANIMATOR_UTILS_MT_unparent_menu_inactive",
    "ANIMATOR_UTILS_MT_unparent_menu_active",
    "ANIMATOR_UTILS_OT_unparent_menu",
    "ANIMATOR_UTILS_OT_surface_contact_create",
    "ANIMATOR_UTILS_OT_surface_contact_release",
    "ANIMATOR_UTILS_OT_surface_contact_pivot",
    "ANIMATOR_UTILS_OT_surface_contact_clear",
    "ANIMATOR_UTILS_OT_clear_contact_pose_transform",
    "ANIMATOR_UTILS_OT_ragdoll_action",
    "ANIMATOR_UTILS_OT_install_roblox_animations",
    "ANIMATOR_UTILS_OT_open_roblox_plugins",
    "ANIMATOR_UTILS_OT_set_transform_orientation",
    "ANIMATOR_UTILS_OT_set_pivot_mode",
    "ANIMATOR_UTILS_OT_add_bone_camera",
    "ANIMATOR_UTILS_OT_toggle_attached_camera_view",
    "ANIMATOR_UTILS_OT_attached_camera_wheel_exit",
    "ANIMATOR_UTILS_OT_keyframe_camera_view",
    "ANIMATOR_UTILS_OT_load_template",
    "ANIMATOR_UTILS_OT_toggle_pose_rig",
    "ANIMATOR_UTILS_OT_delete_rig",
    "ANIMATOR_UTILS_OT_track_rig_hover",
    "ROBLOX_ANIMATOR_UTILS_OT_edit_animation_length",
    "ROBLOX_ANIMATOR_UTILS_OT_import_animation_clipboard",
    "VIEW3D_PT_animator_utils_roblox_animator_anchor",
    "VIEW3D_PT_animator_utils_main",
)

DYNAMIC_PARENT_CLASS_NAMES = (
    "DYNAMIC_PARENT_OT_menu",
    "DYNAMIC_PARENT_MT_hotkey_menu",
    "DYNAMIC_PARENT_OT_create",
    "DYNAMIC_PARENT_OT_disable",
    "DYNAMIC_PARENT_OT_clear",
    "DYNAMIC_PARENT_OT_bake",
    "DYNAMIC_PARENT_OT_clear_material_links",
    "DYNAMIC_PARENT_MT_clear_menu",
)

REGISTER_CLASS_NAMES = UTILS_CLASS_NAMES + DYNAMIC_PARENT_CLASS_NAMES

if len(REGISTER_CLASS_NAMES) != len(set(REGISTER_CLASS_NAMES)):
    raise RuntimeError("Utils class registry contains a duplicate")


def resolve_classes(namespace: Mapping[str, Any]) -> tuple[type, ...]:
    """Resolve the registry and reject missing or accidentally unlisted UI."""

    missing = tuple(name for name in REGISTER_CLASS_NAMES if name not in namespace)
    if missing:
        raise RuntimeError(
            "Missing Utils registration classes: " + ", ".join(missing)
        )
    registerable_bases = tuple(
        base
        for base_name in (
            "Operator",
            "Menu",
            "Panel",
            "Gizmo",
            "GizmoGroup",
        )
        if (base := getattr(bpy.types, base_name, None)) is not None
    )
    package_prefix = (
        str(namespace[REGISTER_CLASS_NAMES[0]].__module__).rsplit(".", 2)[0]
        + "."
    )
    discovered = {
        name
        for name, value in namespace.items()
        if isinstance(value, type)
        and issubclass(value, registerable_bases)
        and value not in registerable_bases
        and str(getattr(value, "__module__", "")).startswith(package_prefix)
    }
    unlisted = tuple(sorted(discovered.difference(REGISTER_CLASS_NAMES)))
    if unlisted:
        raise RuntimeError(
            "Unlisted Utils registration classes: " + ", ".join(unlisted)
        )
    return tuple(namespace[name] for name in REGISTER_CLASS_NAMES)
