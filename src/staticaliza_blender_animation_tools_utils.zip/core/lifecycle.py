"""Blender property, handler, timer, draw, and class lifecycle."""
from .runtime import *  # noqa: F403
def _initialize_registered_scene_state():
    """Finish data-dependent setup after Blender releases register restrictions."""
    scenes = tuple(getattr(bpy.data, "scenes", ()))
    for scene in scenes:
        _sync_roblox_animation_loop_mode(scene)
    context = getattr(bpy, "context", None)
    _animator_utils_apply_file_defaults(context)
    _ragdoll_migrate_legacy_start_keys()
    view_layer = getattr(context, "view_layer", None)
    if view_layer is not None:
        _state["surface_contact_solver_syncing"] = True
        try:
            # Registration/update is metadata-only. Blender's currently
            # visible pose must not be re-solved because a package changed.
            _surface_contact_clear_orphaned_pose_snapshots()
            # unregister() captured the exact visible local pose before any
            # classes, constraints, or handlers were retired. Restore that
            # authoritative side before Blender evaluates the newly loaded
            # package; otherwise the first update can publish a teardown-time
            # dependency pose and make a pink limb jump without user input.
            _surface_contact_restore_live_update_poses(context)
            view_layer.update()
            # Rebuild attachment only after the exact pose is back. This lets
            # the real world-space pink-dot gap reject a stale False detach
            # property instead of manufacturing a vertical ghost ring.
            _surface_contact_restore_snap_detached(
                context,
                infer_missing=False,
            )
            _surface_contact_restore_loaded_snap_latches(context)
            _surface_contact_store_persistent_pose_snapshots()
            _surface_contact_seed_valid_poses()
            _surface_contact_seed_owner_pose_bases()
            _surface_contact_seed_runtime_signatures(context)
        except (AttributeError, RuntimeError):
            pass
        finally:
            _state["surface_contact_solver_syncing"] = False
    # Registration dirties every linked ID. Ignore that synthetic depsgraph
    # burst so updating Utils cannot re-solve and offset saved contact poses.
    try:
        # This namespace survives replacement of the add-on module itself.
        # Keep stale panels and discovery code inert until the new module's
        # registration settles, then let the deadline expire naturally.
        bpy.app.driver_namespace[EXTENSION_UPDATE_GUARD_KEY] = (
            time.perf_counter() + 1.0
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        pass
    _state["surface_contact_registration_guard_until"] = (
        time.perf_counter() + 0.75
    )
    _pin_cache_idle_transform_poses(context)
    return None
def _register_impl():
    _unsubscribe_animation_range_redraw()
    unregister_owned_timers()
    unregister_owned_handlers()
    unregister_owned_draw_handlers()
    if not _migrate_dynamic_keyframe_names():
        register_owned_timer(
            _run_dynamic_keyframe_name_migration,
            first_interval = 0.1,
        )
    _capture_animation_channel_baseline()
    for name in (
        "onion_skin_enabled",
        "onion_skin_mode",
        "onion_skin_opacity",
        "onion_skin_include_meshes",
        "onion_skin_include_bones",
        "onion_skin_raycast",
        "onion_skin_skip_hidden"
    ):
        if hasattr(bpy.types.Scene, name):
            delattr(bpy.types.Scene, name)
    if hasattr(bpy.types.Scene, ROBLOX_ANIMATION_LOOP_PROPERTY):
        delattr(bpy.types.Scene, ROBLOX_ANIMATION_LOOP_PROPERTY)
    if hasattr(bpy.types.Scene, ROBLOX_ANIMATION_PRIORITY_PROPERTY):
        delattr(bpy.types.Scene, ROBLOX_ANIMATION_PRIORITY_PROPERTY)
    if hasattr(bpy.types.Scene, ROBLOX_ANIMATION_LENGTH_PROPERTY):
        delattr(bpy.types.Scene, ROBLOX_ANIMATION_LENGTH_PROPERTY)
    if hasattr(bpy.types.WindowManager, "smart_material_import_enabled"):
        delattr(bpy.types.WindowManager, "smart_material_import_enabled")
    if hasattr(
        bpy.types.WindowManager,
        "standardize_imported_material_display_enabled",
    ):
        delattr(
            bpy.types.WindowManager,
            "standardize_imported_material_display_enabled",
        )
    if hasattr(
        bpy.types.WindowManager,
        "prevent_clothing_layer_clipping_enabled",
    ):
        delattr(
            bpy.types.WindowManager,
            "prevent_clothing_layer_clipping_enabled",
        )
    if hasattr(bpy.types.WindowManager, "yellow_pin_mode"):
        delattr(bpy.types.WindowManager, "yellow_pin_mode")
    for name in (
        "roblox_compat_hide_weld_bones",
        "roblox_compat_hide_face_bones",
        "roblox_compat_hide_advanced_panels",
        "roblox_compat_advanced_mode",
        "roblox_import_rigging_type",
        "show_bone_names_enabled",
        "auto_clear_object_transforms_enabled",
        KEYFRAME_HANDLE_MODE_PROPERTY,
        "staticaliza_pivot_mode",
        "staticaliza_camera_fov_mode",
        "staticaliza_camera_custom_fov",
        "staticaliza_camera_fov",
        "staticaliza_camera_orientation",
        "staticaliza_camera_hide_attached_object",
        "staticaliza_camera_opaque_frame",
        "staticaliza_camera_composition_thirds",
        "staticaliza_surface_contact_mode",
        "surface_contact_pin_mode",
        "surface_contact_cast_axis",
        "yellow_pin_axis",
    ):
        if hasattr(bpy.types.WindowManager, name):
            delattr(bpy.types.WindowManager, name)
    for name in (
        "staticaliza_camera_orientation",
        "staticaliza_camera_hide_attached_preview",
        "staticaliza_camera_hide_attached_object",
        "staticaliza_camera_opaque_frame",
    ):
        if hasattr(bpy.types.Object, name):
            delattr(bpy.types.Object, name)
    for name in (RAGDOLL_GRAVITY_AXIS_RNA, RAGDOLL_ACCELERATION_RNA):
        if hasattr(bpy.types.PoseBone, name):
            delattr(bpy.types.PoseBone, name)

    setattr(
        bpy.types.PoseBone,
        RAGDOLL_GRAVITY_AXIS_RNA,
        bpy.props.EnumProperty(
            name="Gravity Axis",
            description="World-space direction used by orange-pin gravity",
            items=(
                ("X_POS", "+X", "Gravity toward world +X"),
                ("X_NEG", "-X", "Gravity toward world -X"),
                ("Y_POS", "+Y", "Gravity toward world +Y"),
                ("Y_NEG", "-Y", "Gravity toward world -Y"),
                ("Z_POS", "+Z", "Gravity toward world +Z"),
                ("Z_NEG", "-Z", "Gravity toward world -Z (down)"),
            ),
            default="Z_NEG",
            update=_ragdoll_gravity_axis_update,
        ),
    )
    setattr(
        bpy.types.PoseBone,
        RAGDOLL_ACCELERATION_RNA,
        bpy.props.FloatProperty(
            name="Weight",
            description=(
                "Gravity strength: 100 is normal, 50 is half, 200 is double; "
                "negative values reverse the chosen axis"
            ),
            default=_RAGDOLL_DEFAULT_WEIGHT,
            soft_min=-500.0,
            soft_max=500.0,
            precision=2,
            update=_ragdoll_weight_update,
        ),
    )

    bpy.types.WindowManager.onion_skin_enabled = bpy.props.BoolProperty(
        name = "Ghost",
        default = False,
        options = {"SKIP_SAVE"},
        update = _on_enabled_toggle
    )
    bpy.types.WindowManager.onion_skin_mode = bpy.props.EnumProperty(
        name="Onion Skin Mode",
        description="Choose a captured pose or nearest keyed poses around the playhead",
        items=(
            ("SINGLE", "Single", "Show the captured current pose"),
            ("MULTIPLE", "Multiple", "Show only the nearest previous and next keyed poses"),
        ),
        default="SINGLE",
        options={"SKIP_SAVE"},
        update=_on_onion_mode_change,
    )
    setattr(
        bpy.types.Scene,
        ROBLOX_ANIMATION_LOOP_PROPERTY,
        bpy.props.BoolProperty(
            name = "Loop",
            description = (
                "Repeat animation playback and mark Roblox exports as looped"
            ),
            default = False,
            update = _on_roblox_animation_loop_change,
        ),
    )
    setattr(
        bpy.types.Scene,
        ROBLOX_ANIMATION_PRIORITY_PROPERTY,
        bpy.props.EnumProperty(
            name = "Priority",
            description = "Roblox animation playback priority",
            items = ROBLOX_ANIMATION_PRIORITY_ITEMS,
            default = "Action",
        ),
    )
    setattr(
        bpy.types.Scene,
        ROBLOX_ANIMATION_LENGTH_PROPERTY,
        bpy.props.StringProperty(
            name = "Animation Length",
            description = (
                "Enter frames, or frame-accurate time as SS:FF, MM:SS:FF, "
                "or HH:MM:SS:FF"
            ),
            get = _get_roblox_animation_length,
            set = _set_roblox_animation_length,
        ),
    )
    _subscribe_animation_range_redraw()
    bpy.types.WindowManager.onion_skin_opacity = bpy.props.FloatProperty(
        name = "Opacity",
        default = 0.10,
        min = 0.001,
        max = 1.0,
        update = _on_setting_change
    )
    bpy.types.WindowManager.onion_skin_include_meshes = bpy.props.BoolProperty(
        name = "Meshes",
        default = True,
        update = _on_setting_change
    )
    bpy.types.WindowManager.onion_skin_include_bones = bpy.props.BoolProperty(
        name = "Bones",
        default = False,
        update = _on_setting_change
    )
    bpy.types.WindowManager.onion_skin_raycast = bpy.props.BoolProperty(
        name = "Raycast",
        default = True,
        update = _on_setting_change
    )
    bpy.types.WindowManager.onion_skin_skip_hidden = bpy.props.BoolProperty(
        name = "Skip Hidden",
        default = True,
        update = _on_setting_change
    )
    bpy.types.WindowManager.smart_material_import_enabled = bpy.props.BoolProperty(
        name = "Smart Material Import",
        description = "Preserve imported textures and use smooth blending for transparent rig materials",
        default = True,
        update = _on_smart_material_import_toggle
    )
    bpy.types.WindowManager.standardize_imported_material_display_enabled = bpy.props.BoolProperty(
        name = "Standardize Viewport Display",
        description = "Replace the imported viewport swatch with a neutral color",
        default = False,
        update = _on_smart_material_import_toggle,
    )
    bpy.types.WindowManager.prevent_clothing_layer_clipping_enabled = bpy.props.BoolProperty(
        name = "Prevent Clothing Clipping",
        description = "Offset imported clothing overlay meshes slightly so the underlying body does not clip through",
        default = False,
        update = _on_smart_material_import_toggle,
    )
    bpy.types.WindowManager.yellow_pin_mode = bpy.props.EnumProperty(
        name = "Pin Position",
        description = "Choose where new and updated pins are placed",
        items = (
            ("MODE_3", "Smart", "Use the selected welded-object face"),
            ("MODE_4", "Bone Start", "Use the bone head"),
            ("MODE_2", "Bone Center", "Use the center of the weighted geometry"),
            ("MODE_1", "Bone End", "Use the bone tail"),
        ),
        default = "MODE_3",
        update = _on_yellow_pin_mode_change,
    )
    bpy.types.WindowManager.yellow_pin_axis = bpy.props.EnumProperty(
        name = "Pin Axis",
        description = "Choose the welded-object face used by Smart Onion Pins",
        items = PIN_AXIS_ITEMS,
        default = "Y_NEG",
        update = _on_yellow_pin_axis_change,
    )
    bpy.types.WindowManager.roblox_compat_advanced_mode = bpy.props.BoolProperty(
        name = "Advanced Mode",
        description = "Show advanced panels, weld and face bones, bone axes, and detailed Utils controls",
        default = False,
        update = _on_advanced_mode_change
    )
    bpy.types.WindowManager.roblox_import_rigging_type = bpy.props.EnumProperty(
        name = "Rigging Type",
        description = "Choose how Roblox Animator generates imported armature bones",
        items = (
            ("RAW", "Nodes only", "Generate nodes without aligned bones"),
            ("LOCAL_AXIS_EXTEND", "Local axis aligned bones", "Align bones to each local part axis"),
            ("LOCAL_YAXIS_EXTEND", "Local Y-axis aligned bones", "Align bones to each part's local Y axis"),
            ("CONNECT", "Connect", "Connect generated bones"),
        ),
        default = "LOCAL_YAXIS_EXTEND",
    )
    bpy.types.WindowManager.show_bone_names_enabled = bpy.props.BoolProperty(
        name = "Show Bone Names",
        description = "Show bone name text in the 3D Viewport",
        default = True,
        update = _on_roblox_compatibility_setting_change,
    )
    bpy.types.WindowManager.auto_clear_object_transforms_enabled = bpy.props.BoolProperty(
        name = "Auto-Clear Object Transforms",
        description = (
            "Automatically remove accidental object transform keyframes from "
            "imported rig parts and armatures"
        ),
        default = True,
    )
    setattr(
        bpy.types.WindowManager,
        KEYFRAME_HANDLE_MODE_PROPERTY,
        bpy.props.EnumProperty(
            name = "Keyframe Type",
            description = "Choose the handles Blender gives newly inserted transform keys",
            items = KEYFRAME_HANDLE_MODE_ITEMS,
            default = "DEFAULT",
            update = _on_keyframe_handle_mode_change,
            options = {"SKIP_SAVE"},
        ),
    )
    _activate_keyframe_handle_policy()
    bpy.types.WindowManager.staticaliza_pivot_mode = bpy.props.EnumProperty(
        name = "Pivot Mode",
        description = "Use Blender's bone pivot or the midpoint of selected connected objects",
        items = (
            ("BONE", "Bone", "Use Blender's normal bone pivot"),
            ("PART", "Object", "Use the midpoint of all selected bones' and pins' connected rig objects"),
        ),
        default = "BONE",
        options = {"SKIP_SAVE"},
    )
    _register_smart_dragger_properties()
    bpy.types.WindowManager.staticaliza_surface_contact_mode = bpy.props.EnumProperty(
        name = "Surface Detection",
        description = "Choose which nearby mesh surfaces Surface Contact may detect",
        items = (
            ("AUTO", "Automatic", "Detect nearby floors, walls, slopes, and custom meshes"),
            ("FLOOR", "Floor", "Only detect upward-facing floor and slope surfaces"),
            ("WALL", "Wall", "Only detect mostly vertical surfaces"),
        ),
        default = "AUTO",
    )
    bpy.types.WindowManager.surface_contact_pin_mode = bpy.props.EnumProperty(
        name = "Pin Position",
        description = "Choose the linked-limb point used by new contacts",
        items = (
            ("MODE_3", "Smart", "Use the selected welded-object face"),
            ("MODE_4", "Bone Start", "Use the selected contact bone's head"),
            ("MODE_2", "Bone Center", "Use the center of the linked weighted geometry"),
            ("MODE_1", "Bone End", "Use the selected contact bone's tail"),
        ),
        default = "MODE_3",
        update = _on_surface_contact_pin_mode_change,
    )
    bpy.types.WindowManager.surface_contact_cast_axis = bpy.props.EnumProperty(
        name = "Cast Axis",
        description = "Choose the axis used to find the contact surface",
        items = PIN_AXIS_ITEMS,
        default = "Y_NEG",
        update = _on_surface_contact_cast_axis_change,
    )
    bpy.types.WindowManager.staticaliza_camera_fov = bpy.props.FloatProperty(
        name = "FOV",
        description = "Horizontal field of view used for newly attached cameras",
        default = 35.0,
        min = 1.0,
        max = 120.0,
        precision = 2,
        update = _on_camera_fov_change,
    )
    bpy.types.WindowManager.staticaliza_camera_orientation = bpy.props.EnumProperty(
        name = "Camera Orientation",
        description = "Choose the attached object's local axis the camera points along",
        items = CAMERA_ORIENTATION_ITEMS,
        default = "Z_NEG",
        update = _on_camera_orientation_change,
    )
    bpy.types.WindowManager.staticaliza_camera_hide_attached_object = bpy.props.BoolProperty(
        name = "Hide Object",
        description = "Hide objects driven by every selected camera bone",
        default = True,
        update = _on_camera_hide_attached_change,
    )
    bpy.types.WindowManager.staticaliza_camera_opaque_frame = bpy.props.BoolProperty(
        name = "Opaque Frame",
        description = "Use an opaque frame for every selected camera bone",
        default = True,
        update = _on_camera_opaque_change,
    )
    bpy.types.WindowManager.staticaliza_camera_composition_thirds = bpy.props.BoolProperty(
        name = "Composition Thirds",
        description = "Show the rule-of-thirds guide for every selected camera bone",
        default = False,
        update = _on_camera_composition_thirds_change,
    )
    bpy.types.Object.staticaliza_camera_orientation = bpy.props.EnumProperty(
        name = "Camera Orientation",
        description = "Choose the attached object's local axis this camera points along",
        items = CAMERA_ORIENTATION_ITEMS,
        default = "Z_NEG",
        update = _on_attached_camera_orientation,
    )
    bpy.types.Object.staticaliza_camera_hide_attached_object = bpy.props.BoolProperty(
        name = "Hide Object",
        description = "Hide mesh objects driven by this camera bone in the viewport and final render",
        default = True,
        update = _on_camera_attached_object_hide_change,
    )
    bpy.types.Object.staticaliza_camera_opaque_frame = bpy.props.BoolProperty(
        name = "Opaque Frame",
        description = "Fill every area outside this camera's frame with pure black",
        default = True,
        update = _on_camera_opaque_frame_change,
    )
    # Normalize the upstream panel before registering the Utils sidebar.
    # Blender orders sidebar tabs when their panels register; doing this only
    # at the end moves Roblox Animator below Roblox Animator Utils.
    _configure_roblox_sidebar_tabs()
    register_owned_classes(classes)
    _state["yellow_fixed"] = {}
    _state["yellow_modes"] = {}
    _state["yellow_hidden"] = set()
    _state["onion_enabled_owners"] = set()
    _state["onion_property_syncing"] = False
    _state["onion_multiple_updating"] = False
    _state["onion_multiple_refresh_after_playback"] = False
    _state["onion_multiple_pose_dirty"] = False
    _state["onion_multiple_signatures"] = {}
    _state["onion_multiple_side_signatures"] = {}
    _state["onion_multiple_pending_refresh"] = False
    _state["onion_multiple_mesh_batches"] = {}
    _state["onion_multiple_raycast_fixed"] = {}
    _state["persistent_runtime_restored"] = False
    _state["persistent_pose_scope_signature"] = ()
    _state["mesh_batches"] = {}
    _state["raycast_fixed"] = {}
    _state["unparent_rel_cache"] = {}
    _state["unparent_handler_mute"] = False
    _state["dynamic_space_export_sampling"] = False
    _state["last_error"] = ""
    _state["smart_material_processed_rigs"] = set()
    _state["material_import_baseline"] = None
    if not _capture_material_import_baseline():
        register_owned_timer(
            _initialize_material_import_tracking,
            first_interval = 0.05,
        )
    _state["extension_update_lock_waits"] = 0
    _state["extension_update_running"] = False
    _state["extension_update_status"] = ""
    _state["roblox_constraints_normalized"] = set()
    _state["roblox_constraints_new_rigs"] = set()
    _state["unparent_export_armature"] = None
    _state["smart_material_scan_pending"] = False
    _state["smart_material_scan_not_before"] = 0.0
    _state["roblox_compatibility_scan_pending"] = False
    _state["roblox_armature_list_signature"] = None
    _state["armature_overlay_saved"] = {}
    _state["part_pivot_syncing"] = False
    _state["transform_gizmo_refresh_pending"] = False
    _state["part_pivot_armature"] = 0
    _state["part_pivot_bone"] = ""
    _state["part_pivot_last_armature"] = 0
    _state["part_pivot_last_bone"] = ""
    _state["part_pivot_object"] = ""
    _state["part_pivot_object_local"] = None
    _state["part_pivot_objects"] = ()
    _state["part_pivot_selection_signature"] = ()
    _state["part_pivot_saved"] = None
    _state["part_pivot_last_signature"] = None
    _state["part_pivot_cursor_visibility"] = {}
    _state["camera_view_spaces"] = {}
    _state["animation_camera_view_master"] = None
    _state["animation_camera_view_states"] = {}
    _state["animation_camera_view_syncing"] = False
    _state["attached_camera_last_name"] = ""
    _state["attached_camera_last_pointer"] = 0
    _state["free_view_master"] = None
    _state["free_view_space_states"] = {}
    _state["free_view_settings_master"] = None
    _state["free_view_setting_states"] = {}
    _state["view3d_n_panel_master"] = None
    _state["view3d_n_panel_states"] = {}
    _state["view3d_n_panel_window_screens"] = {}
    _state["animation_editor_pose_states"] = {}
    _state["animation_editor_sync_signature"] = None
    _state["animation_editor_sync_time"] = 0.0
    _state["animation_channel_maintenance_last_time"] = 0.0
    _state["animation_channel_maintenance_syncing"] = False
    _state["animation_channel_structure_signatures"] = {}
    _state["special_action_order_attempts"] = {}
    _state["free_view_syncing"] = False
    _state["pose_mode_pending_rigs"] = set()
    _state["pose_mode_pending_attempts"] = 0
    _state["rig_view_frame_request"] = None
    _state["rig_view_frame_serial"] = 0
    _state["bone_label_selection_signature"] = None
    _state["pose_hidden_armatures"] = {}
    _state["pose_visibility_resume_after_save"] = False
    _state["rig_hover_mouse"] = {}
    _state["rig_hover_redraw_times"] = {}
    _state["rig_hover_targets"] = {}
    _state["rig_hover_poll_time"] = 0.0
    _state["rig_hover_cursor_position"] = None
    _state["rig_hover_cursor_changed_at"] = 0.0
    _state["rig_hover_available"] = False
    _state["surface_contact_syncing"] = False
    _state["surface_contact_reconciling"] = False
    _state["surface_contact_solver_syncing"] = False
    _state["surface_contact_creation_active"] = False
    _state["surface_contact_load_restoring"] = False
    _state["surface_contact_valid_poses"] = {}
    _state["surface_contact_owner_pose_bases"] = {}
    _state["surface_contact_transform_signatures"] = {}
    _state["surface_contact_guide_cache"] = ()
    _state["surface_contact_guide_cache_object_count"] = -1
    _state["surface_contact_guide_cache_identity"] = ()
    _state["surface_contact_guide_cache_validation_deadline"] = 0.0
    _state["surface_contact_guide_cache_generation"] = int(
        _state.get("surface_contact_guide_cache_generation", 0)
    ) + 1
    _state["surface_contact_detached_cache_revision"] = int(
        _state.get("surface_contact_detached_cache_revision", 0)
    ) + 1
    _state["surface_contact_active_guide_cache"] = {}
    _state["surface_contact_effector_guide_cache"] = {}
    _state["surface_contact_pose_bone_cache"] = {}
    _state["surface_contact_resolved_guide_cache"] = {}
    _state["surface_contact_attached_frame_cache"] = {}
    _state["surface_contact_attached_frame_cache_scope"] = None
    _state["surface_contact_detached_fcurve_cache"] = {}
    _state["surface_contact_detached_key_cache"] = {}
    _state["surface_contact_depsgraph_guide_index"] = None
    _state["surface_contact_playback_settle_signature"] = None
    _state["surface_contact_rotation_axes"] = {}
    _state["surface_contact_smart_aim_branches"] = {}
    _state["surface_contact_roll_frames"] = {}
    _state["surface_contact_collision_tangents"] = {}
    _state["surface_contact_last_frames"] = {
        int(scene.as_pointer()): int(scene.frame_current)
        for scene in tuple(getattr(bpy.data, "scenes", ()))
    }
    _state["pin_target_dragging"] = False
    _state["pin_snap_transform_active"] = False
    _state["pin_snap_sample_syncing"] = False
    _state["pin_snap_transform_initializing"] = False
    _state["pin_snap_transform_operator"] = ""
    _state["pin_snap_transform_start_poses"] = {}
    _state["pin_snap_transform_changed"] = False
    _state["pin_snap_transform_delta_supported"] = False
    _state["pin_snap_transform_delta_observed"] = False
    _state["pin_snap_transform_last_delta_signature"] = None
    _state["pin_snap_last_solved_pose_signature"] = None
    _state["pin_snap_contact_target_locks"] = {}
    _state["pin_snap_direct_transform_guides"] = set()
    _state["pin_snap_parent_transform_guides"] = set()
    _state["pin_snap_target_transform_guides"] = set()
    _state["pin_snap_parent_attachment_states"] = {}
    _state["pin_snap_collision_min_distances"] = {}
    _state["pin_snap_collision_started_clipped"] = set()
    _state["pin_snap_live_detached_keyed"] = {}
    _state["pin_snap_syncing"] = False
    _state["pin_pose_selection_checkpoint_active"] = False
    _state["pin_pose_selection_checkpoint_pair"] = None
    _state["pin_pose_selection_checkpoint_guard_until"] = 0.0
    _state["pin_snap_latches"] = set()
    _state["pin_snap_departing"] = set()
    _state["pin_snap_detached"] = set()
    _state["pin_snap_transform_seen"] = set()
    _state["pin_snap_initial_detached"] = {}
    _state["pin_snap_last_depsgraph_sync"] = 0.0
    _state["pin_snap_transform_dirty"] = False
    _state["pin_snap_live_pose_matrices"] = {}
    _state["pin_snap_live_pose_dirty_guides"] = set()
    _state["pin_snap_contact_transform_start_poses"] = {}
    _state["pin_snap_contact_start_action_keys"] = {}
    _state["pin_snap_native_history_tokens"] = {}
    _state["pin_snap_native_history_token_serial"] = -1
    _state["pin_snap_native_history_transition"] = None
    _state["pin_snap_native_history_transition_backup"] = None
    _state["pin_snap_native_history_transitions"] = []
    _state["pin_snap_native_history_redo_stack"] = []
    _state["pin_snap_native_history_pre_selected"] = {}
    _state["pin_snap_initial_latches"] = set()
    _state["pin_snap_transform_start_anchor_samples"] = {}
    _state["pin_snap_initial_attachment_states"] = {}
    _state["pin_snap_transform_engaged"] = set()
    _state["pin_snap_proximity_engaged"] = set()
    _state["pin_snap_engage_translate_origins"] = {}
    _state["pin_snap_engage_anchor_origins"] = {}
    _state["pin_snap_grip_directions"] = {}
    _state["pin_snap_swept_entry_directions"] = {}
    _state["pin_snap_raw_anchor_samples"] = {}
    _state["pin_snap_raw_pose_matrices"] = {}
    _state["pin_snap_raw_basis_matrices"] = {}
    _state["pin_snap_native_after_poses"] = {}
    _state["pin_snap_magnetic_anchor_samples"] = {}
    _state["pin_snap_magnetic_aim_anchor_samples"] = {}
    _state["pin_snap_magnetic_aim_pose_matrices"] = {}
    _state["pin_snap_pre_solve_anchor_samples"] = {}
    _state["pin_snap_transform_releasing"] = set()
    _state["pin_snap_release_reentry_armed"] = set()
    _state["pin_snap_release_anchor_origins"] = {}
    _state["pin_snap_pressure_release_origins"] = {}
    _state["pin_snap_pressure_return_samples"] = {}
    _state["pin_snap_engage_pose_origins"] = {}
    _state["pin_snap_pressure_tangents"] = {}
    _state["pin_snap_pressure_pivot_active"] = set()
    _state["pin_snap_pressure_active"] = set()
    _state["pin_snap_pressure_release_session"] = set()
    _state["pin_snap_pressure_terminal_departures"] = set()
    _state["pin_snap_pressure_release_pose_matrices"] = {}
    _state["pin_snap_pressure_release_raw_translations"] = {}
    _state["pin_snap_transform_finalize_pending"] = None
    _state["pin_gizmo_axes_visible"] = {}
    _state["pin_gizmo_active_axis_index"] = -1
    _state["pin_gizmo_available_kinds"] = frozenset()
    _state["pin_gizmo_selection_keys"] = ()
    _state["pin_gizmo_selected_key"] = ""
    _state["pin_gizmo_selected_keys"] = set()
    _state["pin_gizmo_selected_keys_active"] = ""
    _state["pin_gizmo_pending_click"] = None
    _state["pin_gizmo_selection_epoch"] = 0
    _state["pin_gizmo_claim_serial"] = 0
    _state["pin_gizmo_last_claim"] = None
    _state["pin_pointer_pending_click"] = None
    _pin_reset_pointer_tool_state()
    _state["pin_cpu_pick_targets"] = {}
    _state["pin_gizmo_extend_selection_until"] = 0.0
    _state["pin_gizmo_deferred_finishes"] = []
    _state["pin_keyboard_transform_active"] = False
    _state["pin_transform_from_gizmo"] = False
    _state["pin_native_selection_cleanup_pending"] = False
    _reset_smart_dragger_runtime()
    _state["pin_transform_constraint"] = None
    _state["pin_yellow_history_fallbacks"] = {}
    _state["pin_history_active"] = False
    _surface_contact_clear_history_pose_lock()
    _state["pin_history_contact_snapshot"] = None
    _state["pin_history_nonhistory_snapshot"] = None
    _state["pin_history_selection_snapshot"] = None
    _state["pin_history_pre_contact_pose_lock"] = ()
    _state["pin_history_pre_active_contact_pose_lock"] = ()
    _state["pin_history_pre_contact_runtime_snapshot"] = None
    _state["pin_history_contact_transition"] = None
    _state["pin_history_contact_transition_predicted"] = False
    _state["pin_history_contact_transition_source_index"] = None
    _state["pin_history_contact_transition_target_index"] = None
    _state["pin_history_contact_transition_selected"] = {}
    _state["pin_history_contact_transition_runtime_before"] = ()
    _state["pin_history_syncing"] = False
    _state["animator_utils_file_defaults_syncing"] = False
    _state["ragdoll_states"] = {}
    _state["ragdoll_frame_cache"] = {}
    _state["ragdoll_collision_shapes"] = {}
    _state["ragdoll_boundary_pose_samples"] = {}
    _state["ragdoll_last_live_update"] = 0.0
    _state["ragdoll_syncing"] = False
    _state["ragdoll_history_restoring"] = False
    _state["ragdoll_baking"] = False
    _state["ragdoll_frame_handler_calls"] = 0
    _state["ragdoll_frame_handler_last_frame"] = None
    _state["ragdoll_frame_handler_blocked"] = ""
    _state["ragdoll_frame_poll_repairs"] = 0
    _state["ragdoll_frame_handler_restores"] = 0
    _state["ragdoll_marker_signatures"] = {}
    _state["pin_native_group_session"] = None
    _state["pin_clipboard"] = None
    _state["roblox_animation_loop_modes"] = {}
    _state["roblox_animation_playback_frame"] = 0
    _state["roblox_animation_statusbars"] = {}
    if getattr(bpy.data, "scenes", None) is None:
        register_owned_timer(
            _initialize_registered_scene_state,
            first_interval = 0.01,
        )
    else:
        _initialize_registered_scene_state()
    if not _register_addon_keymaps():
        register_owned_timer(
            _register_addon_keymaps_timer,
            first_interval = 0.05,
        )
    register_owned_timer(
        _onion_multiple_frame_poll,
        first_interval=0.03,
    )
    register_owned_timer(
        _ragdoll_frame_poll,
        first_interval=0.03,
        persistent=True,
    )
    unregister_owned_handlers()
    for handler_list, handler_function in (
        (bpy.app.handlers.load_pre, _load_pre),
        (bpy.app.handlers.animation_playback_pre, _dynamic_parent_playback_pre),
        (bpy.app.handlers.animation_playback_pre, _camera_timeline_playback_pre),
        (bpy.app.handlers.animation_playback_pre, _ragdoll_playback_pre),
        (bpy.app.handlers.animation_playback_post, _ragdoll_playback_post),
        (bpy.app.handlers.animation_playback_post, _onion_multiple_playback_post),
        (bpy.app.handlers.animation_playback_post, _camera_timeline_playback_post),
        *_roblox_preview_playback_handlers(),
        (bpy.app.handlers.frame_change_pre, _dynamic_space_frame_change_pre),
        (bpy.app.handlers.frame_change_post, _unparent_frame_change_post),
        (bpy.app.handlers.frame_change_post, _part_pivot_frame_change_post),
        (bpy.app.handlers.frame_change_post, _camera_fov_frame_change_post),
        (bpy.app.handlers.frame_change_post, _camera_timeline_frame_change_post),
        (bpy.app.handlers.frame_change_post, _surface_contact_frame_change_post),
        (bpy.app.handlers.frame_change_post, _ragdoll_frame_change_post),
        (bpy.app.handlers.frame_change_post, _onion_multiple_frame_change_post),
        (bpy.app.handlers.load_post, _load_post),
        (bpy.app.handlers.save_pre, _animator_utils_store_file_defaults),
        (bpy.app.handlers.save_pre, _ragdoll_native_cancel_job),
        (bpy.app.handlers.save_pre, _surface_contact_save_pre),
        (bpy.app.handlers.save_pre, _pose_visibility_save_pre),
        (bpy.app.handlers.save_post, _pose_visibility_save_post),
        (bpy.app.handlers.undo_pre, _pin_undo_pre),
        (bpy.app.handlers.redo_pre, _pin_redo_pre),
        (bpy.app.handlers.undo_pre, _ragdoll_history_pre),
        (bpy.app.handlers.redo_pre, _ragdoll_history_pre),
        (bpy.app.handlers.undo_post, _dynamic_space_undo_post),
        (bpy.app.handlers.redo_post, _dynamic_space_undo_post),
        (bpy.app.handlers.undo_post, _pin_undo_post),
        (bpy.app.handlers.redo_post, _pin_undo_post),
        (bpy.app.handlers.undo_post, _ragdoll_history_post),
        (bpy.app.handlers.redo_post, _ragdoll_history_post),
        (
            bpy.app.handlers.depsgraph_update_post,
            _smart_material_import_depsgraph_update,
        ),
        (
            bpy.app.handlers.depsgraph_update_post,
            _roblox_compatibility_depsgraph_update,
        ),
        (bpy.app.handlers.depsgraph_update_post, _part_pivot_depsgraph_update),
        (
            bpy.app.handlers.depsgraph_update_post,
            _animation_camera_view_depsgraph_update,
        ),
        (bpy.app.handlers.depsgraph_update_post, _dynamic_space_depsgraph_update),
        (
            bpy.app.handlers.depsgraph_update_post,
            _surface_contact_depsgraph_update_post,
        ),
        (
            bpy.app.handlers.depsgraph_update_post,
            _ragdoll_depsgraph_update_post,
        ),
        (
            bpy.app.handlers.depsgraph_update_post,
            _onion_multiple_depsgraph_update_post,
        ),
    ):
        register_owned_handler(handler_list, handler_function)
    if bpy.app.timers.is_registered(_run_scheduled_dynamic_space_reconcile):
        bpy.app.timers.unregister(_run_scheduled_dynamic_space_reconcile)
    if bpy.app.timers.is_registered(_run_dynamic_parent_boundary_refresh):
        bpy.app.timers.unregister(_run_dynamic_parent_boundary_refresh)
    _state["dynamic_space_reconciling"] = False
    _state["dynamic_space_reconcile_pending"] = False
    _state["dynamic_space_calibrating"] = False
    _state["dynamic_space_export_sampling"] = False
    _state["dynamic_space_last_action_update"] = 0.0
    _state["dynamic_space_marker_signature"] = None
    _state["dynamic_space_frame_evaluation_until"] = 0.0
    _dynamic_space_invalidate_runtime_cache()
    _state["dynamic_parent_boundary_refresh_pending"] = False
    _state["dynamic_parent_boundary_refresh_last_update"] = 0.0
    _state["dynamic_parent_animation_signature"] = None
    _state["dynamic_parent_playback_session_active"] = False
    _state["dynamic_parent_cleanup_pending"] = False
    _state["dynamic_parent_dual_selection_locks"] = {}
    _state["dynamic_parent_dual_selection_translate_sessions"] = {}
    _state["dynamic_parent_indirect_parent_baselines"] = {}
    _state["dynamic_parent_indirect_visual_commits"] = {}
    _reset_dynamic_parent_history_state()
    _state["dynamic_parent_dual_selection_save_paused"] = False
    if bpy.app.timers.is_registered(_dynamic_space_marker_watch_timer):
        bpy.app.timers.unregister(_dynamic_space_marker_watch_timer)
    register_owned_timer(
        _dynamic_space_marker_watch_timer,
        first_interval = 0.25,
        persistent = True,
    )

    _schedule_persistent_runtime_restore(0.1)
    register_owned_timer(lambda: (_sync_view3d_relationship_lines(bpy.context), None)[1], first_interval = 0.1)
    if bpy.app.timers.is_registered(_view3d_n_panel_sync_timer):
        bpy.app.timers.unregister(_view3d_n_panel_sync_timer)
    register_owned_timer(
        _view3d_n_panel_sync_timer,
        first_interval = 0.05,
        persistent = True,
    )
    register_owned_timer(
        _camera_view_exit_timer,
        first_interval = 0.05,
        persistent = True,
    )
    register_owned_timer(
        _roblox_animation_loop_timer,
        first_interval = 0.1,
        persistent = True,
    )
    register_owned_timer(_sync_all_attached_camera_object_visibility, first_interval = 0.2)
    register_owned_timer(
        _part_pivot_selection_timer,
        first_interval = 0.05,
        persistent = True,
    )
    register_owned_timer(
        _bone_label_selection_timer,
        first_interval = 0.05,
        persistent = True,
    )
    if bpy.app.timers.is_registered(_pin_snap_timer):
        bpy.app.timers.unregister(_pin_snap_timer)
    register_owned_timer(
        _pin_snap_timer,
        first_interval = 0.04,
        persistent = True,
    )
    register_owned_timer(
        _pin_pointer_click_away_timer,
        first_interval = 0.1,
        persistent = True,
    )
    register_owned_timer(lambda: (_smart_material_import_scan(bpy.context.scene), None)[1], first_interval = 0.2)
    register_owned_timer(lambda: (_apply_roblox_compatibility(bpy.context.scene), None)[1], first_interval = 0.3)
    # The unified host registers Roblox Animator before Utils, so apply the
    # panel relocation immediately. Keep the timer as a retry for standalone
    # installs where Roblox Animator may register later in the session.
    _configure_roblox_sidebar_tabs()
    register_owned_timer(_configure_roblox_sidebar_tabs, first_interval = 0.5)
    register_owned_timer(
        _expand_new_animation_channels,
        first_interval = 0.15,
        persistent = True,
    )
def register():
    """Register atomically and roll back partial lifecycle failures."""

    if _state.get("extension_registered", False):
        return
    try:
        _register_impl()
    except Exception:
        try:
            unregister()
        finally:
            _state["extension_registered"] = False
        raise
    _state["extension_registered"] = True
def unregister():
    _ragdoll_native_cancel_job()
    _ragdoll_restore_playback_sync()
    _state["extension_registered"] = False
    context = getattr(bpy, "context", None)
    _state["surface_contact_solver_syncing"] = True
    try:
        # Capture outside Blender's undoable ID graph before teardown touches
        # constraints, handlers, classes, or dependency evaluation.
        _surface_contact_capture_live_update_poses()
        _persist_runtime_session_state(context)
    except Exception:
        pass
    _unsubscribe_animation_range_redraw()
    unregister_owned_timers()
    unregister_owned_handlers()
    unregister_owned_draw_handlers()
    # Remove event bindings before retiring their OperatorType classes. This
    # ordering matters during a live package replacement in the UI thread.
    _unregister_addon_keymaps()
    unregister_owned_classes()
    _restore_dynamic_parent_dual_selection_locks()
    _restore_pose_session_armature_visibility()
    _restore_animation_editor_pose_states()
    scene = getattr(context, "scene", None)
    if scene is not None:
        _sync_dynamic_parent_constraints(int(scene.frame_current))
    _restore_roblox_bone_color_patch()
    _restore_all_dynamic_pose_bone_colors()
    _restore_roblox_nodes_only_default()
    _restore_roblox_import_patch()
    _restore_roblox_unparent_patch()
    _restore_roblox_advanced_panel_filter()
    _restore_roblox_clipboard_endpoint_patch()
    _restore_roblox_preview_state()
    _restore_roblox_metadata_patches()
    _restore_roblox_serializer_patch()
    _restore_roblox_export_patch()
    _sync_armature_debug_overlays(True)

    for timer_function in (
        _run_smart_material_import_scan,
        _run_roblox_compatibility_scan,
        _camera_view_exit_timer,
        _enter_pending_roblox_rigs_pose_mode,
        _part_pivot_selection_timer,
        _bone_label_selection_timer,
        _initialize_material_import_tracking,
        _register_addon_keymaps_timer,
        _run_dynamic_keyframe_name_migration,
        _expand_new_animation_channels,
        _dynamic_space_marker_watch_timer,
        _view3d_n_panel_sync_timer,
        _clear_pin_history_visibility,
        _pin_history_deferred_runtime_sync,
        _pin_gizmo_run_deferred_finishes,
        _pin_click_away_timer,
        _pin_pointer_click_away_timer,
        _pin_snap_timer,
        _restore_persistent_runtime_timer,
        _refresh_attached_camera_transforms_timer,
        _roblox_animation_loop_timer,
    ):
        try:
            if bpy.app.timers.is_registered(timer_function):
                bpy.app.timers.unregister(timer_function)
        except Exception:
            pass

    try:
        if bpy.context and bpy.context.window_manager:
            if getattr(
                bpy.context.window_manager,
                "staticaliza_pivot_mode",
                "BONE",
            ) == "PART":
                _disable_part_pivot(bpy.context)
            _set_onion_property(bpy.context.window_manager, False)
    except Exception:
        pass

    try:
        if bpy.app.timers.is_registered(_run_scheduled_dynamic_space_reconcile):
            bpy.app.timers.unregister(_run_scheduled_dynamic_space_reconcile)
        if bpy.app.timers.is_registered(_run_dynamic_parent_boundary_refresh):
            bpy.app.timers.unregister(_run_dynamic_parent_boundary_refresh)
        _state["dynamic_space_reconciling"] = False
        _state["dynamic_space_reconcile_pending"] = False
        _state["dynamic_space_calibrating"] = False
        _state["dynamic_space_export_sampling"] = False
        _state["dynamic_space_last_action_update"] = 0.0
        _state["dynamic_space_marker_signature"] = None
        _state["dynamic_parent_boundary_refresh_pending"] = False
        _state["dynamic_parent_boundary_refresh_last_update"] = 0.0
        _state["dynamic_parent_animation_signature"] = None
        _state["dynamic_parent_playback_session_active"] = False
        _state["dynamic_parent_cleanup_pending"] = False
        _reset_dynamic_parent_history_state()
        _state["surface_contact_syncing"] = False
        _state["surface_contact_solver_syncing"] = True
        _state["pin_snap_departing"] = set()
        _state["pin_snap_detached"] = set()
        _state["pin_snap_transform_seen"] = set()
        _state["pin_snap_initial_detached"] = {}
        _state["pin_gizmo_selection_keys"] = ()
        _state["pin_gizmo_selected_key"] = ""
        _state["pin_gizmo_selected_keys"] = set()
        _state["pin_gizmo_selected_keys_active"] = ""
        _state["pin_gizmo_active_axis_index"] = -1
        _state["pin_gizmo_pending_click"] = None
        _state["pin_pointer_pending_click"] = None
        _pin_reset_pointer_tool_state()
        _state["pin_cpu_pick_targets"] = {}
        _state["pin_gizmo_last_claim"] = None
        _state["pin_gizmo_extend_selection_until"] = 0.0
        _state["pin_gizmo_deferred_finishes"] = []
        _state["pin_keyboard_transform_active"] = False
        _state["pin_transform_from_gizmo"] = False
        _reset_smart_dragger_runtime()
        _state["pin_yellow_history_fallbacks"] = {}
        _state["pin_history_active"] = False
        _state["pin_history_contact_snapshot"] = None
        _state["pin_history_syncing"] = False
    except Exception:
        pass

    _disable_runtime()
    _restore_keyframe_handle_preference()

    for name in (
        "onion_skin_enabled",
        "onion_skin_mode",
        "onion_skin_opacity",
        "onion_skin_include_meshes",
        "onion_skin_include_bones",
        "onion_skin_raycast",
        "onion_skin_skip_hidden",
        "smart_material_import_enabled",
        "standardize_imported_material_display_enabled",
        "prevent_clothing_layer_clipping_enabled",
        "yellow_pin_mode",
        "yellow_pin_axis",
        "roblox_compat_advanced_mode",
        "roblox_import_rigging_type",
        "show_bone_names_enabled",
        "auto_clear_object_transforms_enabled",
        KEYFRAME_HANDLE_MODE_PROPERTY,
        "staticaliza_pivot_mode",
        "staticaliza_camera_fov",
        "staticaliza_camera_orientation",
        "staticaliza_camera_hide_attached_object",
        "staticaliza_camera_opaque_frame",
        "staticaliza_camera_composition_thirds",
        "staticaliza_surface_contact_mode",
        "surface_contact_pin_mode",
        "surface_contact_cast_axis",
    ):
        if hasattr(bpy.types.WindowManager, name):
            delattr(bpy.types.WindowManager, name)
    if hasattr(bpy.types.Scene, ROBLOX_ANIMATION_LOOP_PROPERTY):
        delattr(bpy.types.Scene, ROBLOX_ANIMATION_LOOP_PROPERTY)
    if hasattr(bpy.types.Scene, ROBLOX_ANIMATION_PRIORITY_PROPERTY):
        delattr(bpy.types.Scene, ROBLOX_ANIMATION_PRIORITY_PROPERTY)
    if hasattr(bpy.types.Scene, ROBLOX_ANIMATION_LENGTH_PROPERTY):
        delattr(bpy.types.Scene, ROBLOX_ANIMATION_LENGTH_PROPERTY)
    _unregister_smart_dragger_properties()
    for name in (
        "staticaliza_camera_orientation",
        "staticaliza_camera_hide_attached_preview",
        "staticaliza_camera_hide_attached_object",
        "staticaliza_camera_opaque_frame",
    ):
        if hasattr(bpy.types.Object, name):
            delattr(bpy.types.Object, name)
    for name in (RAGDOLL_GRAVITY_AXIS_RNA, RAGDOLL_ACCELERATION_RNA):
        if hasattr(bpy.types.PoseBone, name):
            delattr(bpy.types.PoseBone, name)
    # _persist_runtime_session_state() captured Contact poses before teardown.
    # Do not overwrite them here: constraint/class removal above may have
    # produced a temporary dependency pose that was never authored by the user.
