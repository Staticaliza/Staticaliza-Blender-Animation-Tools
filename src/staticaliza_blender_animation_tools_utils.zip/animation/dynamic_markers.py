"""Dynamic Parent and unparent marker storage, pruning, and reconciliation."""

from ..core.runtime import *  # noqa: F403


def _safe_constraint_name(constraint):
    try:
        return str(constraint.name)
    except (ReferenceError, UnicodeDecodeError):
        return ""

def _dynamic_marker_value(action, data_path, frame):
    values = []
    for fcurve in _fcurves_find_all(action, data_path):
        key = _fcurve_key_at(fcurve, int(frame))
        if key is not None:
            values.append(float(key.co.y))
    return max(values) if values else None


def _normalize_dynamic_marker_fcurve(fcurve):
    if fcurve is None:
        return False
    changed = False
    for key in fcurve.keyframe_points:
        if key.interpolation != "CONSTANT":
            key.interpolation = "CONSTANT"
            changed = True
        # Handle choices are user-editable.  Insertion sites initialize new
        # marker keys to AUTO; reconciliation must not undo a later manual
        # AUTO_CLAMPED (or other) choice.
    if changed:
        fcurve.update()
    return changed


def _set_dynamic_marker_value(action, data_path, frame, value):
    changed = False
    for fcurve in _fcurves_find_all(action, data_path):
        key = _fcurve_key_at(fcurve, int(frame))
        if key is None:
            continue
        value_changed = False
        if abs(float(key.co.y) - float(value)) > 1.0e-6:
            key.co.y = float(value)
            changed = True
            value_changed = True
        if value_changed:
            fcurve.update()
    return changed


def _managed_unparent_segments(pose_bone):
    segments = []
    for constraint in _internal_space_constraints(pose_bone):
        source = _dynamic_space_source(pose_bone, constraint)
        if not source.startswith(SPACE_SOURCE_UNPARENT_PREFIX):
            continue
        if _dynamic_space_role(pose_bone, constraint) != SPACE_ROLE_UNPARENT:
            continue
        start, end = _stored_dynamic_parent_constraint_segment(
            pose_bone,
            constraint,
        )
        try:
            source_start = int(source.split(":", 1)[1])
        except (IndexError, TypeError, ValueError):
            source_start = start
        if source_start is None:
            continue
        segments.append(
            {
                "source": source,
                "start": int(source_start),
                "end": int(end) if end is not None else None,
            }
        )
    segments.sort(key = lambda segment: segment["start"])
    return segments


def _unparent_marker_segments(action, bone_name):
    segments = []
    active_start = None
    for frame, value in _unparent_points(action, bone_name):
        active = float(value) >= 0.5
        split = float(value) >= UNP_SPLIT_VALUE - 0.5
        if active and (active_start is None or split):
            if active_start is not None:
                segments.append({"start": active_start, "end": int(frame)})
            active_start = int(frame)
        elif not active and active_start is not None:
            segments.append({"start": active_start, "end": int(frame)})
            active_start = None
    if active_start is not None:
        segments.append({"start": active_start, "end": None})
    return segments


def _retime_managed_unparent_segment(pose_bone, stored, marker):
    old_source = stored["source"]
    new_source = _space_constraint_source_for_unparent(marker["start"])
    changed = False
    for constraint in tuple(_space_constraints_with_source(pose_bone, old_source)):
        role = _dynamic_space_role(pose_bone, constraint)
        if role != SPACE_ROLE_UNPARENT and marker["end"] is None:
            changed = _remove_space_constraint(pose_bone, constraint) or changed
            continue
        start = marker["start"] if role == SPACE_ROLE_UNPARENT else marker["end"]
        end = marker["end"] if role == SPACE_ROLE_UNPARENT else None
        _store_dynamic_parent_constraint_segment(pose_bone, constraint, start, end)
        _store_dynamic_space_source(pose_bone, constraint, new_source)
        changed = True
    return changed


def _remove_dynamic_marker_pair(action, data_path, start, end = None):
    frames = {int(start)}
    if end is not None:
        frames.add(int(end))
    removed = False
    for fcurve in list(_fcurves_find_all(action, data_path)):
        for key in list(fcurve.keyframe_points):
            if int(round(float(key.co.x))) not in frames:
                continue
            fcurve.keyframe_points.remove(key)
            removed = True
        if not fcurve.keyframe_points:
            _action_remove_fcurve(action, fcurve)
        else:
            fcurve.update()
    return removed


def _prune_orphan_unparent_markers(action, bone_name):
    if action is None:
        return False

    data_path = _unparent_dp(bone_name)
    points = _unparent_points(action, bone_name)
    active = False
    orphan_frames = set()
    for frame, value in points:
        next_active = float(value) >= 0.5
        if next_active:
            active = True
        elif active:
            active = False
        else:
            orphan_frames.add(int(frame))

    if not orphan_frames:
        return False

    changed = False
    for fcurve in list(_fcurves_find_all(action, data_path)):
        for key in list(fcurve.keyframe_points):
            if int(round(float(key.co.x))) not in orphan_frames:
                continue
            fcurve.keyframe_points.remove(key)
            changed = True
        if not fcurve.keyframe_points:
            _action_remove_fcurve(action, fcurve)
        else:
            fcurve.update()
    return changed



def _prune_orphan_dynamic_parent_markers(action, owner):
    if action is None or owner is None:
        return False

    changed = False
    for constraint in getattr(owner, "constraints", ()):
        if not _safe_constraint_name(constraint).startswith("DP_"):
            continue
        data_path = _dynamic_parent_marker_data_path(constraint)
        if not data_path:
            continue
        fcurve = _fcurve_find(action, data_path)
        if fcurve is None or any(
            float(key.co.y) > 0.5 for key in fcurve.keyframe_points
        ):
            continue
        changed = _action_remove_fcurve(action, fcurve) or changed
    return changed


def _prune_orphan_dynamic_markers():
    changed = False
    for armature in tuple(bpy.data.objects):
        action = armature.animation_data.action if armature.animation_data else None
        if action is None:
            continue
        changed = _prune_orphan_dynamic_parent_markers(
            action,
            armature,
        ) or changed
        if armature.type != "ARMATURE" or getattr(armature, "pose", None) is None:
            continue
        for pose_bone in armature.pose.bones:
            changed = _prune_orphan_unparent_markers(
                action,
                pose_bone.name,
            ) or changed
            changed = _prune_orphan_dynamic_parent_markers(
                action,
                pose_bone,
            ) or changed
    return changed


def _remove_pose_dynamic_parent_segment(
    context,
    armature,
    pose_bone,
    constraint,
):
    start, _end = _stored_dynamic_parent_constraint_segment(
        pose_bone,
        constraint,
    )
    action = armature.animation_data.action if armature.animation_data else None
    influence_path = _dynamic_parent_marker_data_path(constraint)
    if action is not None and influence_path:
        for fcurve in list(_fcurves_find_all(action, influence_path)):
            _action_remove_fcurve(action, fcurve)

    if start is not None:
        _remove_pose_space_source(
            pose_bone,
            _space_constraint_source_for_dynamic_parent(constraint, start),
        )
    for property_name in _dp_auto_unparent_property_names(constraint):
        if property_name in pose_bone:
            del pose_bone[property_name]
    _remove_dynamic_parent_constraint_metadata(pose_bone, constraint)
    try:
        pose_bone.constraints.remove(constraint)
    except (ReferenceError, RuntimeError, ValueError):
        return False
    _dynamic_space_invalidate_runtime_cache()
    context.view_layer.update()
    return True


def _reconcile_dynamic_parent_space_source(
    pose_bone,
    constraint,
    stored_start,
    curve_start,
    curve_end,
):
    sources = {
        _space_constraint_source_for_dynamic_parent(constraint, int(start))
        for start in (stored_start, curve_start)
        if start is not None
    }
    if not sources:
        return False

    if curve_end is None:
        changed = False
        for source in sources:
            changed = _remove_pose_space_source(pose_bone, source) or changed
        return changed

    new_source = _space_constraint_source_for_dynamic_parent(
        constraint,
        int(curve_start),
    )
    changed = False
    for space_constraint in _internal_space_constraints(pose_bone):
        if _dynamic_space_source(pose_bone, space_constraint) not in sources:
            continue
        if _dynamic_space_source(pose_bone, space_constraint) != new_source:
            _store_dynamic_space_source(
                pose_bone,
                space_constraint,
                new_source,
            )
            changed = True
        current_start, current_end = _stored_dynamic_parent_constraint_segment(
            pose_bone,
            space_constraint,
        )
        adjusted_end = current_end
        if adjusted_end is not None and int(adjusted_end) <= int(curve_end):
            adjusted_end = None
        if (
            current_start is None
            or int(current_start) != int(curve_end)
            or adjusted_end != current_end

        ):
            _store_dynamic_parent_constraint_segment(
                pose_bone,
                space_constraint,
                int(curve_end),
                adjusted_end,
            )
            changed = True
    return changed


def _reconcile_pose_bone_dynamic_markers(context, armature, bone_name):
    pose_bone = armature.pose.bones.get(bone_name)
    if pose_bone is None:
        return False
    action = armature.animation_data.action if armature.animation_data else None
    changed = False

    for constraint in list(pose_bone.constraints):
        if not _safe_constraint_name(constraint).startswith("DP_"):
            continue
        stored_start, stored_end = _stored_dynamic_parent_constraint_segment(
            pose_bone,
            constraint,
        )
        influence_path = _dynamic_parent_marker_data_path(constraint)
        curve_start, curve_end = _dynamic_parent_constraint_segment(
            pose_bone,
            constraint,
        )
        if curve_start is not None:
            changed = _reconcile_dynamic_parent_space_source(
                pose_bone,
                constraint,
                stored_start,
                curve_start,
                curve_end,
            ) or changed
            if (stored_start, stored_end) != (curve_start, curve_end):
                _store_dynamic_parent_constraint_segment(
                    pose_bone,
                    constraint,
                    int(curve_start),
                    int(curve_end) if curve_end is not None else None,
                )
                changed = True
            continue
        changed = _remove_pose_dynamic_parent_segment(
            context,
            armature,
            pose_bone,
            constraint,
        ) or changed
        pose_bone = armature.pose.bones.get(bone_name)
        if pose_bone is None:
            return changed

    valid_dp_sources = set()
    valid_dp_paths = set()
    for constraint in pose_bone.constraints:
        if not _safe_constraint_name(constraint).startswith("DP_"):
            continue
        start, _end = _stored_dynamic_parent_constraint_segment(
            pose_bone,
            constraint,
        )
        if start is not None:
            valid_dp_sources.add(
                _space_constraint_source_for_dynamic_parent(constraint, start)
            )
        marker_path = _dynamic_parent_marker_data_path(constraint)
        if marker_path:
            valid_dp_paths.add(marker_path)

    for source in {
        _dynamic_space_source(pose_bone, constraint)
        for constraint in _internal_space_constraints(pose_bone)
        if _dynamic_space_source(pose_bone, constraint).startswith(
            SPACE_SOURCE_DYNAMIC_PARENT_PREFIX
        )
    } - valid_dp_sources:
        changed = _remove_pose_space_source(pose_bone, source) or changed

    if action is not None:
        try:
            bone_prefix = pose_bone.path_from_id()
            constraint_prefix = bone_prefix + '.constraints["DP_'
            marker_prefix = bone_prefix + f'["{DP_MARKER_PROPERTY_PREFIX}'
        except (AttributeError, TypeError, ValueError):
            constraint_prefix = ""
            marker_prefix = ""
        if constraint_prefix:
            for fcurve in list(_action_fcurves(action, armature)):
                if (
                    (
                        (
                            fcurve.data_path.startswith(constraint_prefix)
                            and fcurve.data_path.endswith(".influence")
                        )
                        or fcurve.data_path.startswith(marker_prefix)
                    )
                    and fcurve.data_path not in valid_dp_paths
                ):
                    changed = _action_remove_fcurve(action, fcurve) or changed

    data_path = _unparent_dp(bone_name)
    segments = _managed_unparent_segments(pose_bone)
    marker_segments = _unparent_marker_segments(action, bone_name)
    for stored, marker in zip(segments, marker_segments):
        if (stored["start"], stored["end"]) != (marker["start"], marker["end"]):
            changed = _retime_managed_unparent_segment(
                pose_bone,
                stored,
                marker,
            ) or changed
    for segment in segments[len(marker_segments):]:
        changed = _remove_pose_space_source(
            pose_bone,
            segment["source"],
        ) or changed

    segments = _managed_unparent_segments(pose_bone)
    unparent_structure_matched = len(segments) == len(marker_segments)
    valid_unparent_sources = {segment["source"] for segment in segments}
    for source in {
        _dynamic_space_source(pose_bone, constraint)
        for constraint in _internal_space_constraints(pose_bone)
        if _dynamic_space_source(pose_bone, constraint).startswith(
            SPACE_SOURCE_UNPARENT_PREFIX
        )
    } - valid_unparent_sources:
        changed = _remove_pose_space_source(pose_bone, source) or changed

    if action is not None and unparent_structure_matched:
        starts = {segment["start"] for segment in segments}
        shared_boundaries = {
            segment["end"]
            for segment in segments
            if segment["end"] is not None and segment["end"] in starts
        }
        for frame in shared_boundaries:
            changed = _set_dynamic_marker_value(
                action,
                data_path,
                frame,
                UNP_SPLIT_VALUE,
            ) or changed
        for frame in starts - shared_boundaries:
            value = _dynamic_marker_value(action, data_path, frame)
            if value is not None and value >= UNP_SPLIT_VALUE - 0.5:
                changed = _set_dynamic_marker_value(
                    action,
                    data_path,
                    frame,
                    1.0,
                ) or changed

        expected_frames = starts | {
            segment["end"]
            for segment in segments
            if segment["end"] is not None
        }
        for fcurve in list(_fcurves_find_all(action, data_path)):
            for key in list(fcurve.keyframe_points):
                if int(round(float(key.co.x))) in expected_frames:
                    continue
                fcurve.keyframe_points.remove(key)
                changed = True
            if not fcurve.keyframe_points:
                changed = _action_remove_fcurve(action, fcurve) or changed
            else:
                fcurve.update()

    has_dynamic_parent = any(
        _safe_constraint_name(constraint).startswith("DP_")
        for constraint in pose_bone.constraints
    )
    has_unparent = bool(_managed_unparent_segments(pose_bone))
    if not has_unparent and action is not None:
        for fcurve in list(_fcurves_find_all(action, data_path)):
            changed = _action_remove_fcurve(action, fcurve) or changed
    if not has_dynamic_parent and not has_unparent:
        changed = _teardown_pose_space_system(
            context,
            armature,
            pose_bone,
        ) or changed
    return changed


def _reconcile_dynamic_space_markers(context, armature = None):
    if _state.get("dynamic_space_reconciling", False):
        return False
    _state["dynamic_space_reconciling"] = True
    try:
        marker_changed = _prune_orphan_dynamic_markers()
        marker_changed = (
            _reconcile_surface_contact_markers(context, armature)
            or marker_changed
        )
        armatures = (
            (armature,)
            if armature is not None
            else tuple(
                obj
                for obj in bpy.data.objects
                if obj.type == "ARMATURE" and getattr(obj, "pose", None) is not None
            )
        )
        for current_armature in armatures:
            if current_armature is None or getattr(current_armature, "pose", None) is None:
                continue
            bone_names = tuple(
                pose_bone.name
                for pose_bone in current_armature.pose.bones
                if any(
                    _is_dynamic_state_constraint(constraint)
                    for constraint in pose_bone.constraints
                )
            )
            for bone_name in bone_names:
                marker_changed = _reconcile_pose_bone_dynamic_markers(
                    context,
                    current_armature,
                    bone_name,
                ) or marker_changed
        frame = int(context.scene.frame_current)
        calibrated = _recalibrate_all_dynamic_space_boundaries(
            context,
            armature,
        )
        changed = _sync_dynamic_parent_constraints(frame, armature)
        changed = bool(marker_changed or calibrated or changed)
        _store_dynamic_parent_animation_signature()
        if changed:
            context.view_layer.update()
            _tag_redraw_all_view3d()
        return changed
    finally:
        _state["dynamic_space_reconciling"] = False

def _dp_auto_unparent_property_name(constraint):
    name = str(getattr(constraint, "name", ""))
    digest = hashlib.sha1(name.encode("utf-8")).hexdigest()[:16]
    return f"{DP_AUTO_UNPARENT_PROPERTY_PREFIX}{digest}"


def _dp_auto_unparent_property_names(constraint):
    if constraint is None:
        return ()
    return (
        _dp_auto_unparent_property_name(constraint),
        f"{DP_AUTO_UNPARENT_START_KEY}::{constraint.name}",
    )


def _dp_auto_unparent_start(owner, constraint):
    if not isinstance(owner, bpy.types.PoseBone) or constraint is None:
        return None
    for property_name in _dp_auto_unparent_property_names(constraint):
        try:
            value = owner.get(property_name, None)
            if value is not None:
                segment_start, _segment_end = (
                    _dynamic_parent_constraint_segment(owner, constraint)
                )
                return int(segment_start) if segment_start is not None else int(value)
        except (AttributeError, KeyError, TypeError, ValueError):
            continue
    return None


def _dp_auto_unparent_start_frames(owner):
    if not isinstance(owner, bpy.types.PoseBone):
        return set()

    prefixes = (
        DP_AUTO_UNPARENT_PROPERTY_PREFIX,
        f"{DP_AUTO_UNPARENT_START_KEY}::",
    )
    frames = set()
    matched_properties = set()
    for constraint in getattr(owner, "constraints", ()):
        if not _safe_constraint_name(constraint).startswith("DP_"):
            continue
        property_names = _dp_auto_unparent_property_names(constraint)
        if not any(property_name in owner for property_name in property_names):
            continue
        matched_properties.update(property_names)
        start_frame, _end_frame = _dynamic_parent_constraint_segment(
            owner,
            constraint,
        )
        if start_frame is not None:
            frames.add(int(start_frame))

    try:
        property_names = tuple(owner.keys())
    except (AttributeError, TypeError):
        return frames

    for property_name in property_names:
        if not str(property_name).startswith(prefixes):
            continue
        if property_name in matched_properties:
            continue
        try:
            frames.add(int(owner[property_name]))
        except (KeyError, TypeError, ValueError):
            continue
    return frames
