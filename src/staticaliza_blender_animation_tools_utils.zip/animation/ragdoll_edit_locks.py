"""Native transform ownership while a ragdoll interval owns the pose."""
from ..core.runtime import *  # noqa: F403

_RAGDOLL_EDIT_LOCKS = '_staticaliza_ragdoll_edit_locks'
_RAGDOLL_AUTOKEY_LOCK = '_staticaliza_ragdoll_autokey_lock'


def _ragdoll_sync_autokey_lock(context, *, restore=False, scene=None):
    """Native Auto Key otherwise keys even a fully locked, unchanged bone.

    Suspend it only while every selected bone is simulated. Explicit key
    insertion remains available; the user's Auto Key setting returns as soon
    as an editable selection, Object mode, Start or End owns input again.
    """
    scene = scene or context.scene
    locked = not restore and context.scene == scene and _ragdoll_selection_simulated(context)
    saved = scene.get(_RAGDOLL_AUTOKEY_LOCK)
    settings = scene.tool_settings
    if locked:
        if settings.use_keyframe_insert_auto:
            if saved is None:scene[_RAGDOLL_AUTOKEY_LOCK] = True
            settings.use_keyframe_insert_auto = False
    elif saved is not None:
        if settings.use_keyframe_insert_auto != bool(saved):
            settings.use_keyframe_insert_auto = bool(saved)
        del scene[_RAGDOLL_AUTOKEY_LOCK]


def _ragdoll_selection_simulated(context):
    if context.mode!='POSE':return False
    bones=tuple(context.selected_pose_bones or ())
    frame=context.scene.frame_current_final
    return bool(bones) and all(_ragdoll_active(bone,int(frame))
        and (start:=_ragdoll_active_start_frame(bone.id_data,bone,int(frame))) is not None
        and frame>start+1.e-5 for bone in bones)


def _ragdoll_sync_transform_locks(scene, *, restore=False):
    changed=False
    for owner in scene.objects:
        if owner.type!='ARMATURE' or owner.pose is None or (owner.mode=='EDIT' and not restore):continue
        for bone in owner.pose.bones:
            start=_ragdoll_active_start_frame(owner,bone,scene.frame_current)
            locked=(not restore and _ragdoll_active(bone,scene.frame_current)
                    and start is not None and scene.frame_current_final>start+1.e-5)
            saved=bone.get(_RAGDOLL_EDIT_LOCKS)
            if not locked and saved is None:continue
            if locked and saved is None:
                saved=json.dumps([list(bone.lock_location),list(bone.lock_rotation),
                                  list(bone.lock_scale),bone.lock_rotation_w,bone.lock_rotations_4d])
                bone[_RAGDOLL_EDIT_LOCKS]=saved
            values=([True]*3,[True]*3,[True]*3,True,True) if locked else json.loads(saved)
            for name,value in zip(('lock_location','lock_rotation','lock_scale','lock_rotation_w','lock_rotations_4d'),values):
                current=getattr(bone,name)
                if (tuple(current)!=tuple(value) if isinstance(value,(tuple,list)) else current!=value):
                    setattr(bone,name,value);changed=True
            if not locked:
                del bone[_RAGDOLL_EDIT_LOCKS]
    _ragdoll_sync_autokey_lock(bpy.context, restore=restore, scene=scene)
    return changed
