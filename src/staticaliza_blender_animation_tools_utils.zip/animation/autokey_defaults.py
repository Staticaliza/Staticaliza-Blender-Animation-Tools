"""Preserve the pre-transform value when native Auto Key creates a channel."""

from ..core.runtime import *  # noqa: F403


_AUTOKEY_DEFAULTS_TOKEN = '_staticaliza_autokey_transaction'


def _autokey_defaults_clear(*_args, defer_scene=False):
    pending = _state.pop('autokey_transform_defaults', None)
    if pending:
        if defer_scene:
            try:
                if pending['scene'].get(_AUTOKEY_DEFAULTS_TOKEN) != pending['token']:
                    return
            except ReferenceError:
                return
            retired = _state.setdefault('autokey_defaults_retired_tokens', [])
            retired.append((pending['scene'], pending['token']))
            del retired[:-32]
            if not bpy.app.timers.is_registered(_autokey_defaults_retire_tokens):
                register_owned_timer(_autokey_defaults_retire_tokens, first_interval=0.01)
            return
        try:
            scene = pending['scene']
            if scene.get(_AUTOKEY_DEFAULTS_TOKEN) == pending['token']:
                del scene[_AUTOKEY_DEFAULTS_TOKEN]
        except ReferenceError:
            pass


def _autokey_defaults_retire_tokens():
    # Never dirty the Scene in a press handler before native gizmo picking.
    if _pin_primary_mouse_pressed() and not _pin_active_transform_operator(bpy.context):
        return 0.01
    for scene, token in _state.pop('autokey_defaults_retired_tokens', ()):
        try:
            if scene.get(_AUTOKEY_DEFAULTS_TOKEN) == token:
                del scene[_AUTOKEY_DEFAULTS_TOKEN]
        except ReferenceError:
            pass
    return None


def _autokey_defaults_capture(context):
    """Capture plain values before native input; never insert keys on a press."""
    _autokey_defaults_clear(defer_scene=True)
    scene = context.scene
    screen = context.screen
    if (not scene.tool_settings.use_keyframe_insert_auto
            or screen.is_animation_playing or screen.is_scrubbing
            or context.mode not in {'POSE', 'OBJECT'}):
        return
    if context.mode == 'POSE':
        targets = tuple(context.selected_pose_bones or ())
    else:
        targets = tuple(context.selected_objects)
    records = {}
    owners = {}
    frame = float(scene.frame_current_final)
    for target in targets:
        owner = target.id_data
        if context.mode == 'POSE' and target.get('_staticaliza_ragdoll_edit_locks'):
            continue
        animation = owner.animation_data
        # Layered NLA values are not an Action's original channel defaults.
        # Let native keying own those values rather than baking the blend.
        if animation and (animation.use_tweak_mode or any(
                not track.mute for track in animation.nla_tracks)):
            continue
        action = animation.action if animation else None
        owner_uid = owner.session_uid
        if owner_uid not in owners:
            curves = _action_fcurves(action, owner)
            keyed = {(curve.data_path, curve.array_index)
                     for curve in curves if len(curve.keyframe_points)}
            anchor = min((float(curve.keyframe_points[0].co.x)
                          for curve in curves if len(curve.keyframe_points)),
                         default=float(scene.frame_start))
            owners[owner_uid] = (keyed, anchor)
        keyed, anchor = owners[owner_uid]
        rotation = ('rotation_quaternion' if target.rotation_mode == 'QUATERNION'
                    else 'rotation_axis_angle' if target.rotation_mode == 'AXIS_ANGLE'
                    else 'rotation_euler')
        defaults = {}
        for property_name in ('location', rotation, 'scale'):
            path = target.path_from_id(property_name)
            for index, value in enumerate(getattr(target, property_name)):
                key = (path, index)
                if key not in keyed:
                    defaults[key] = float(value)
        if defaults:
            if frame <= anchor + 1.e-5:
                continue
            if owner_uid not in records:
                records[owner_uid] = (owner, action.session_uid if action else None,
                                      anchor, {})
            records[owner_uid][3].update(defaults)
    if not records:
        return
    token = str(time.time_ns())
    _state['autokey_transform_defaults'] = {
        'token': token,
        'scene': scene, 'frame': frame, 'records': tuple(records.values()),
        'captured': time.monotonic(),
        'operator': (context.window_manager.operators[-1].as_pointer()
                     if context.window_manager.operators else None),
    }
    # Arm the history token only after the native transform has acquired
    # input. A Scene write here can invalidate the gizmo pick on this press.
    register_owned_timer(_autokey_defaults_finish, first_interval=0.0)


def _autokey_defaults_commit(scene):
    pending = _state.get('autokey_transform_defaults')
    if not pending or pending.get('writing'):
        return 0
    if pending['scene'] != scene:
        return 0
    if (abs(scene.frame_current_final - pending['frame']) > 1.e-5
            or not scene.tool_settings.use_keyframe_insert_auto):
        _autokey_defaults_clear()
        return 0
    operators = bpy.context.window_manager.operators
    last = operators[-1] if operators else None
    active = _pin_active_transform_operator(bpy.context)
    confirmed = (last is not None and last.as_pointer() != pending['operator']
                 and last.bl_idname in {'TRANSFORM_OT_translate',
                                        'TRANSFORM_OT_rotate',
                                        'TRANSFORM_OT_resize', 'TRANSFORM_OT_trackball',
                                        'TRANSFORM_OT_transform',
                                        'POSE_OT_loc_clear', 'POSE_OT_rot_clear',
                                        'POSE_OT_scale_clear', 'POSE_OT_transforms_clear'})
    if not active and not confirmed:
        return 0
    operator_id = active or (last.bl_idname if confirmed else '')
    properties = {
        'TRANSFORM_OT_translate': ('.location',),
        'TRANSFORM_OT_rotate': ('.rotation_quaternion', '.rotation_euler', '.rotation_axis_angle'),
        'TRANSFORM_OT_trackball': ('.rotation_quaternion', '.rotation_euler', '.rotation_axis_angle'),
        'TRANSFORM_OT_resize': ('.scale',),
    }.get(operator_id)
    if properties and not any(
        path.endswith(properties)
        for _owner, _action, _anchor, defaults in pending['records']
        for path, _index in defaults
    ):
        # Existing keyed channels can move while the only missing defaults
        # belong to another transform (for example Scale during Rotate).
        # No baseline can be added: avoid a Scene write and dependency refresh.
        if confirmed:
            _autokey_defaults_clear(defer_scene=True)
        return 0
    pending['writing'] = True
    count = 0
    inserted = []
    try:
        if scene.get(_AUTOKEY_DEFAULTS_TOKEN) != pending['token']:
            scene[_AUTOKEY_DEFAULTS_TOKEN] = pending['token']
        prefs = bpy.context.preferences.edit
        for owner, original_action, anchor, defaults in pending['records']:
            try:
                animation = owner.animation_data
                action = animation.action if animation else None
                if action is None or (original_action is not None
                                      and action.session_uid != original_action):
                    continue
                for curve in _action_fcurves(action, owner):
                    key = (curve.data_path, curve.array_index)
                    if key not in defaults:
                        continue
                    points = curve.keyframe_points
                    # A confirmed native edit creates its first key here.
                    # Existing/future keys, cancellation and explicit special
                    # interval keys must never gain another baseline.
                    if (len(points) != 1
                            or abs(points[0].co.x - pending['frame']) > 1.e-5):
                        continue
                    inserted.append((owner.session_uid, action.session_uid, key,
                                     anchor, defaults[key], float(points[0].co.y)))
                    point = points.insert(anchor, defaults[key], options={'FAST'})
                    point.interpolation = prefs.keyframe_new_interpolation_type
                    point.handle_left_type = point.handle_right_type = prefs.keyframe_new_handle_type
                    curve.update()
                    defaults.pop(key)
                    count += 1
            except (ReferenceError, RuntimeError):
                continue
    finally:
        pending['writing'] = False
    if inserted:
        history = _state.setdefault('autokey_defaults_history', {})
        previous = history.get(pending['token'])
        rows = (previous[1] if previous else ()) + tuple(inserted)
        history[pending['token']] = (pending['frame'], rows,
                                     prefs.keyframe_new_interpolation_type,
                                     prefs.keyframe_new_handle_type)
        limit = max(8, min(264, prefs.undo_steps + 8))
        while len(history) > limit:
            history.pop(next(iter(history)))
    if confirmed:
        _autokey_defaults_clear()
    return count


def _autokey_defaults_finish():
    pending = _state.get('autokey_transform_defaults')
    if not pending:
        return None
    context = bpy.context
    if _pin_active_transform_operator(context):
        _autokey_defaults_commit(context.scene)
        return 0.1
    # LMB can precede Blender's drag threshold. Leave a short window for the
    # native operator to start without owning input or changing its hit map.
    if time.monotonic() - pending['captured'] < 0.4:
        _autokey_defaults_commit(context.scene)
        return 0.1
    _autokey_defaults_commit(context.scene)
    _autokey_defaults_clear()
    return None


@persistent
def _autokey_defaults_depsgraph_post(scene, _depsgraph=None):
    if _state.get('autokey_transform_defaults'):
        _autokey_defaults_commit(scene)


@persistent
def _autokey_defaults_frame_pre(scene, _depsgraph=None):
    pending = _state.get('autokey_transform_defaults')
    if pending and pending['scene'] == scene:
        _autokey_defaults_clear()


@persistent
def _autokey_defaults_redo_post(_scene=None):
    """Restore explicit starting keys in the native transform's redo step.

    Native Auto Key pushes its undo snapshot before our idle completion can
    insert a missing baseline. Keep only math plus a temporary native snapshot token;
    replay it exclusively for that snapshot, never on ordinary evaluation.
    """
    scene = bpy.context.scene
    token = scene.get(_AUTOKEY_DEFAULTS_TOKEN)
    if token is None:
        return
    del scene[_AUTOKEY_DEFAULTS_TOKEN]
    record = _state.get('autokey_defaults_history', {}).get(token)
    if not record:
        return
    frame, rows, interpolation, handle_type = record
    owners = {obj.session_uid: obj for obj in bpy.data.objects}
    for owner_uid, action_uid, key, anchor, value, edited_value in rows:
        owner = owners.get(owner_uid)
        animation = owner.animation_data if owner else None
        action = animation.action if animation else None
        if action is None or action.session_uid != action_uid:
            continue
        curve = next((curve for curve in _action_fcurves(action, owner)
                      if (curve.data_path, curve.array_index) == key), None)
        if curve is None or len(curve.keyframe_points) != 1:
            continue
        edited = curve.keyframe_points[0]
        if abs(edited.co.x-frame) > 1.e-5 or abs(edited.co.y-edited_value) > 1.e-6:
            continue
        point = curve.keyframe_points.insert(anchor, value, options={'FAST'})
        point.interpolation = interpolation
        point.handle_left_type = point.handle_right_type = handle_type
        curve.update()
        action.update_tag()


@persistent
def _autokey_defaults_reset(*_args):
    _autokey_defaults_clear()
    _state.pop('autokey_defaults_history', None)
