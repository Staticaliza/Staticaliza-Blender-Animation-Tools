"""Free-body ragdoll integration and contact resolution."""

from ..core.runtime import *  # noqa: F403


def _ragdoll_integrate_free_impl(
    context, armature, pose_bone, state, *, collision_setup=None
):
    """Translate an unparented limb as one rigid body under gravity."""
    fps = max(
        1.0,
        float(context.scene.render.fps)
        / max(1.0e-6, float(context.scene.render.fps_base)),
    )
    dt = 1.0 / fps
    solver_substeps = max(1, min(8, math.ceil(120.0 / fps)))
    sub_dt = dt / float(solver_substeps)
    damping = min(
        0.999,
        max(0.0, float(pose_bone.get(RAGDOLL_DAMPING_PROPERTY, 0.94))),
    ) ** (24.0 / (fps * float(solver_substeps)))
    bounce = min(
        1.0,
        max(0.0, float(pose_bone.get(RAGDOLL_BOUNCE_PROPERTY, 0.0))),
    )
    friction = min(
        1.0,
        max(0.0, float(pose_bone.get(RAGDOLL_FRICTION_PROPERTY, 0.35))),
    )
    fallback_radius = max(
        0.001,
        float(pose_bone.get(RAGDOLL_RADIUS_PROPERTY, max(0.02, pose_bone.bone.length * 0.08))),
    )
    if collision_setup is None:
        collision_setup = _ragdoll_collision_setup(
            context, armature, pose_bone, fallback_radius
        )
    (
        shape_radius,
        excluded,
        collision_samples,
        _collision_normals,
        collision_surfaces,
    ) = collision_setup
    self_collision_scale = 1.0
    anchor = Vector(state["anchor"])
    tail = Vector(state["position"])
    previous_anchor = Vector(state.get("anchor_previous", anchor))
    previous_tail = Vector(state.get("previous", tail))
    velocity = Vector(
        state.get(
            "velocity",
            ((anchor - previous_anchor) + (tail - previous_tail))
            * (0.5 * fps),
        )
    )
    angular_velocity = Vector(
        state.get("angular_velocity", (0.0, 0.0, 0.0))
    )
    body_length = max(1.0e-4, (tail - anchor).length)
    predicted_anchor = anchor.copy()
    predicted_tail = tail.copy()
    gravity = _ragdoll_gravity(pose_bone)
    reference_world, _authored_scale = _ragdoll_rigid_reference(armature, pose_bone)

    reference_scale = reference_world.to_scale()
    orientation = (
        Quaternion(state["orientation"]).normalized()
        if state.get("orientation") is not None
        else _ragdoll_tail_world_matrix(
            reference_world, anchor, tail
        ).to_quaternion().normalized()
    )
    local_body_direction = Vector((0.0, body_length, 0.0))
    # Unit-mass box inertia from the welded support hull, in body space.
    # Impulses use the world inverse tensor rather than one scalar rod inertia.
    scaled_samples = tuple(Vector((point.x * reference_scale.x,
                                   point.y * reference_scale.y,
                                   point.z * reference_scale.z)) for point in collision_samples)
    extents = [max((p[i] for p in scaled_samples), default=0.1)
               - min((p[i] for p in scaled_samples), default=-0.1) for i in range(3)]
    inverse_inertia = Vector(tuple(12.0 / max(1.0e-4, extents[(i+1)%3]**2 + extents[(i+2)%3]**2)
                                   for i in range(3)))
    # The welded mesh, not the pose bone, defines the rigid body's centre of
    # mass.  Using the bone midpoint can put the mathematical COM below a
    # visible corner, making gravity hold the part *on* that corner.  The
    # symmetric support samples provide a cheap, stable welded-volume centre.
    local_center = (
        sum(collision_samples, Vector((0.0, 0.0, 0.0)))
        / float(len(collision_samples))
        if collision_samples
        else Vector((0.0, float(pose_bone.bone.length) * 0.5, 0.0))
    )
    oriented_y = orientation @ Vector((0.0, 1.0, 0.0))
    if oriented_y.length > 1.0e-8:
        orientation = (
            oriented_y.normalized().rotation_difference(
                (tail - anchor).normalized()
            )
            @ orientation
        ).normalized()
    contact_normal = (
        Vector(state["contact_normal"])
        if state.get("contact_normal") is not None
        else None
    )
    contact_point = (
        Vector(state["contact_point"])
        if state.get("contact_point") is not None
        else None
    )
    contact_self = bool(state.get("contact_self", False))
    contact_surface = str(state.get("contact_surface", ""))
    contact_point_local = state.get("contact_point_local")
    contact_normal_local = state.get("contact_normal_local")
    if contact_self:
        moving_contact = _ragdoll_contact_surface_world_frame(context, state)
        if moving_contact is not None:
            contact_point, contact_normal, _surface = moving_contact
        else:
            contact_normal = None
            contact_point = None
            contact_self = False
            contact_surface = ""
            contact_point_local = None
            contact_normal_local = None
    sleeping = bool(state.get("sleeping", False))
    sleep_steps = int(state.get("sleep_steps", 0))
    contact_steps = int(state.get("contact_steps", 0))
    final_support_count = 0
    for _substep in range(solver_substeps):
        if sleeping:
            velocity.zero()
            angular_velocity.zero()
        else:
            velocity *= damping
            angular_velocity *= damping
            velocity += gravity * sub_dt
        old_orientation = orientation.copy()
        old_matrix = Matrix.LocRotScale(
            anchor,
            old_orientation,
            reference_scale,
        )
        center = old_matrix @ local_center
        direction = tail - anchor
        # Gravity is integrated into COM velocity above. The contact impulse
        # below converts that motion into the correct off-centre torque. An
        # additional explicit gravity torque double-counts the same force and
        # was the source of perpetual rocking and renewed launches.
        angular_speed = angular_velocity.length
        if angular_speed > 12.0:
            angular_velocity *= 12.0 / angular_speed
            angular_speed = 12.0
        if angular_speed > 1.0e-8:
            rotation = Quaternion(
                angular_velocity / angular_speed,
                angular_speed * sub_dt,
            )
            orientation = (rotation @ orientation).normalized()
            direction = orientation @ local_body_direction
        predicted_center = center + velocity * sub_dt
        rotated_offset = (
            Matrix.LocRotScale(
                Vector((0.0, 0.0, 0.0)),
                orientation,
                reference_scale,
            )
            @ local_center
        )
        predicted_anchor = predicted_center - rotated_offset
        predicted_tail = predicted_anchor + direction
        collision_normal = None
        collision_velocity = None
        support_count = 0
        contact_planes = []
        if collision_samples:
            new_matrix = Matrix.LocRotScale(
                predicted_anchor,
                orientation,
                reference_scale,
            )
            # A free limb translates as one rigid welded body. Sweeping the
            # actual support points avoids the old endpoint spheres whose
            # radius could be almost a full Blender unit and catch surfaces
            # the visible mesh had not reached.
            persistent_contact = False
            if contact_normal is not None and contact_point is not None:
                active_contact_samples = collision_samples
                sample_world = tuple(
                    new_matrix @ sample for sample in active_contact_samples
                )
                signed = tuple(
                    (point - contact_point).dot(contact_normal)
                    for point in sample_world
                )
                minimum_index = min(
                    range(len(signed)), key=signed.__getitem__, default=0
                )
                minimum_distance = signed[minimum_index] if signed else 0.0
                penetration = max(0.0, -minimum_distance)
                contact_slop = max(
                    0.002, min(0.01, shape_radius * 0.02)
                )
                if (
                    minimum_distance <= contact_slop
                    and penetration <= max(0.02, shape_radius * 2.0)
                ):
                    persistent_contact = True
                    collision_normal = contact_normal.copy()
                    contact_planes.append((contact_normal.copy(), Vector(contact_point)))
                    # Include support points crossed during this angular
                    # substep. A fast corner-to-edge rotation can otherwise
                    # step over the instant where two corners are exactly
                    # coplanar and remain classified as a single corner.
                    support_band = max(
                        1.0e-4,
                        min(
                            0.12,
                            shape_radius * 0.02
                            + shape_radius * angular_speed * sub_dt,
                        ),
                    )
                    support_points = tuple(
                        point - collision_normal * distance
                        for point, distance in zip(sample_world, signed)
                        if distance <= minimum_distance + support_band
                    )
                    support_count = len(support_points)
                    if not contact_self:
                        contact_point = sum(
                            support_points, Vector((0.0, 0.0, 0.0))
                        ) / float(len(support_points))
                    if penetration > 0.0:
                        correction = collision_normal * min(
                            penetration + 1.0e-5, max(0.001, body_length * 0.04 / solver_substeps)
                        )
                        predicted_anchor += correction
                        predicted_tail += correction
                    angular_velocity *= max(0.0, 1.0 - friction * 0.5)
                elif minimum_distance > contact_slop:
                    contact_normal = None
                    contact_point = None
                    contact_self = False
                    contact_surface = ""
                    contact_point_local = None
                    contact_normal_local = None
            # A held side contact must not disable floor/other-body CCD.
            # Exclude only its own surface, whose plane was handled above.
            sweep_surfaces = tuple(surface for surface in collision_surfaces
                if not persistent_contact or surface.name != contact_surface)
            hit = _ragdoll_welded_sweep(
                context,
                sweep_surfaces,
                collision_samples,
                old_matrix,
                new_matrix,
                armature=armature,
                pose_bone=pose_bone,
                compact_samples=(),
                self_collision_scale=self_collision_scale,
            )
            if hit is not None:
                fraction, collision_normal, contact_point, hit_surface = hit
                contact_planes.append((Vector(collision_normal), Vector(contact_point)))
                contact_self = _ragdoll_self_collision_surface(
                    hit_surface, armature
                )
                support_count = 1
                impact_center = center.lerp(predicted_center, fraction)
                orientation = old_orientation.slerp(orientation, fraction).normalized()
                offset = Matrix.LocRotScale(Vector((0.0, 0.0, 0.0)), orientation, reference_scale) @ local_center
                predicted_anchor = impact_center - offset
                predicted_tail = predicted_anchor + orientation @ local_body_direction
                contact_normal = collision_normal.copy()
                if contact_self:
                    local_frame = _ragdoll_contact_surface_local_frame(
                        context, hit_surface, contact_point, collision_normal
                    )
                    if local_frame is not None:
                        (
                            contact_surface,
                            contact_point_local,
                            contact_normal_local,
                        ) = local_frame
                    else:
                        contact_surface = ""
                        contact_point_local = None
                        contact_normal_local = None
                else:
                    contact_surface = hit_surface.name
                    contact_point_local = None
                    contact_normal_local = None
                sleeping = False
            if collision_normal is not None:
                contacts = []
                for plane_normal, plane_point in contact_planes:
                    matrix = Matrix.LocRotScale(predicted_anchor, orientation, reference_scale)
                    points = tuple(matrix @ point for point in collision_samples)
                    distances = tuple((point - plane_point).dot(plane_normal) for point in points)
                    lowest = min(distances, default=0.0)
                    correction = plane_normal * min(max(0.0, -lowest + 1.0e-5), max(0.001, body_length * 0.04 / solver_substeps))
                    predicted_anchor += correction
                    predicted_tail += correction
                    margin = max(0.002, min(0.015, shape_radius * 0.03))
                    support = tuple(point + correction for point, distance in zip(points, distances)
                                    if distance <= lowest + margin)
                    support_count = max(support_count, len(support))
                    contacts.extend((point, plane_normal) for point in support)
                impact_center = Matrix.LocRotScale(predicted_anchor, orientation, reference_scale) @ local_center
                rotation_matrix = orientation.to_matrix()
                inverse_tensor = rotation_matrix @ Matrix.Diagonal(inverse_inertia) @ rotation_matrix.transposed()
                impulses = [0.0] * len(contacts)
                tangent_impulses = [Vector((0.0, 0.0, 0.0)) for _ in contacts]
                rows = []
                for point, normal in contacts:
                    lever = point - impact_center
                    torque = lever.cross(normal)
                    denominator = max(1.0e-6, 1.0 + torque.dot(inverse_tensor @ torque))
                    incoming = (velocity + angular_velocity.cross(lever)).dot(normal)
                    rebound = -bounce * incoming if incoming < -0.5 else 0.0
                    rows.append((lever, normal, denominator, rebound))
                # Solve all held/new contact planes together: alternating a
                # side plane with the floor manufactures rocking and drift.
                for iteration in range(8):
                    for index, (lever, normal, denominator, rebound) in enumerate(rows):
                        point_velocity = velocity + angular_velocity.cross(lever)
                        normal_speed = point_velocity.dot(normal)
                        delta = (rebound - normal_speed) / denominator
                        accumulated = max(0.0, impulses[index] + delta)
                        delta = accumulated - impulses[index]
                        impulses[index] = accumulated
                        impulse = normal * delta
                        velocity += impulse
                        angular_velocity += (inverse_tensor @ lever.cross(impulse))
                        tangent = velocity + angular_velocity.cross(lever)
                        tangent -= normal * tangent.dot(normal)
                        speed = tangent.length
                        if speed > 1.0e-8:
                            direction = tangent / speed
                            torque = lever.cross(direction)
                            denominator = 1.0 + torque.dot(inverse_tensor @ torque)
                            proposed = tangent_impulses[index] - direction * (speed / max(1.0e-6, denominator))
                            limit = friction * accumulated
                            if proposed.length > limit:
                                proposed = proposed.normalized() * limit
                            impulse = proposed - tangent_impulses[index]
                            tangent_impulses[index] = proposed
                            velocity += impulse
                            angular_velocity += (inverse_tensor @ lever.cross(impulse))
                if hit is not None:
                    # Complete the remaining time after impact with the solved
                    # velocities. Discarding it traps zero-TOI contacts while
                    # angular velocity keeps accumulating behind a frozen pose.
                    remaining = sub_dt * max(0.0, 1.0 - float(hit[0]))
                    angular_speed = angular_velocity.length
                    if angular_speed > 1.0e-8:
                        orientation = (Quaternion(angular_velocity / angular_speed,
                                                  angular_speed * remaining) @ orientation).normalized()
                    impact_center += velocity * remaining
                    offset = Matrix.LocRotScale(Vector((0.0, 0.0, 0.0)), orientation, reference_scale) @ local_center
                    predicted_anchor = impact_center - offset
                    predicted_tail = predicted_anchor + orientation @ local_body_direction
                    for normal, point in contact_planes:
                        matrix = Matrix.LocRotScale(predicted_anchor, orientation, reference_scale)
                        distance = min(((matrix @ sample) - point).dot(normal) for sample in collision_samples)
                        correction = normal * min(max(0.0, -distance + 1.0e-5), max(0.001, body_length * 0.04 / solver_substeps))
                        predicted_anchor += correction
                        predicted_tail += correction
                collision_velocity = velocity.copy()
        # No welded visible-object samples means no collision body. Never
        # substitute the pose bone as geometry: it does not represent the
        # visible part boundary and can balance the object in midair.
        if collision_normal is not None and collision_velocity is not None:
            # Positional depenetration is not momentum. Keep only the
            # reflected/tangential incoming velocity so contact correction
            # cannot manufacture a second impact or trap the limb.
            velocity = Vector(collision_velocity)
        if collision_normal is not None:
            contact_steps += 1
        else:
            contact_steps = 0
        # A face manifold may sleep at low linear and angular speed.
        # A corner or edge must continue rotating under contact torque.
        stable_support = support_count >= 3
        if (
            collision_normal is not None
            and stable_support
            and velocity.length < 0.1
            and angular_velocity.length < 0.2
        ):
            sleep_steps += 1
            # Require a slow face manifold throughout one frame's substeps.
            # Sleeping never supplies an orientation target or extra impulse.
            required_sleep_steps = solver_substeps
            if sleep_steps >= required_sleep_steps:
                sleeping = True
                velocity.zero()
                angular_velocity.zero()
        else:
            sleep_steps = max(0, sleep_steps - 1)
            sleeping = False
        # Otherwise keep the centre-of-mass velocity integrated above.
        # Deriving it from one endpoint's displacement incorrectly converts
        # angular rotation into linear momentum. That positive feedback was
        # the recorded 0.9 -> 11.9 -> 25.6 -> 78.7 unparent launch.
        anchor = predicted_anchor.copy()
        tail = predicted_tail.copy()
        final_support_count = support_count
    next_previous_anchor = predicted_anchor - velocity * dt
    next_previous_tail = predicted_tail - velocity * dt
    return {
        "position": predicted_tail.copy(),
        "previous": next_previous_tail.copy(),
        "anchor": predicted_anchor.copy(),
        "anchor_previous": next_previous_anchor.copy(),
        "velocity": velocity.copy(),
        "angular_velocity": angular_velocity.copy(),
        "orientation": orientation.copy(),
        "sleeping": sleeping,
        "sleep_steps": sleep_steps,
        "contact_steps": contact_steps,
        "support_count": final_support_count,
        "contact_normal": (
            contact_normal.copy() if contact_normal is not None else None
        ),
        "contact_point": (
            contact_point.copy() if contact_point is not None else None
        ),
        "contact_self": contact_self,
        "contact_surface": contact_surface,
        "contact_point_local": (
            Vector(contact_point_local).copy()
            if contact_point_local is not None else None
        ),
        "contact_normal_local": (
            Vector(contact_normal_local).copy()
            if contact_normal_local is not None else None
        ),
        "free": True,
        "seeded": True,
    }


