"""Free-body ragdoll integration and contact resolution."""

from ..core.runtime import *  # noqa: F403


def _ragdoll_integrate_free_impl(
    context, armature, pose_bone, state, *, collision_setup=None
):
    """Translate an unparented limb as one rigid body under gravity."""
    fps = max(
        1.0,
        float(context.scene.render.fps)
        / max(1.0e-6, float(context.scene.render.fps_base)),
    )
    dt = 1.0 / fps
    sub_dt = dt / float(_RAGDOLL_SOLVER_SUBSTEPS)
    damping = min(
        0.999,
        max(0.0, float(pose_bone.get(RAGDOLL_DAMPING_PROPERTY, 0.94))),
    ) ** (24.0 / (fps * float(_RAGDOLL_SOLVER_SUBSTEPS)))
    bounce = min(
        1.0,
        max(0.0, float(pose_bone.get(RAGDOLL_BOUNCE_PROPERTY, 0.0))),
    )
    friction = min(
        1.0,
        max(0.0, float(pose_bone.get(RAGDOLL_FRICTION_PROPERTY, 0.35))),
    )
    fallback_radius = max(
        0.001,
        float(pose_bone.get(RAGDOLL_RADIUS_PROPERTY, max(0.02, pose_bone.length * 0.08))),
    )
    if collision_setup is None:
        collision_setup = _ragdoll_collision_setup(
            context, armature, pose_bone, fallback_radius
        )
    (
        shape_radius,
        excluded,
        collision_samples,
        collision_normals,
        collision_surfaces,
    ) = collision_setup
    collision_stretch = min(
        1.0,
        max(
            0.01,
            float(pose_bone.get(RAGDOLL_COLLISION_STRETCH_PROPERTY, 0.2)),
        ),
    )
    compact_collision_samples = _ragdoll_compact_collision_samples(
        collision_samples, collision_stretch
    )
    self_collision_scale = 0.94
    compact_self_collision_samples = _ragdoll_scaled_collision_samples(
        compact_collision_samples or collision_samples,
        self_collision_scale,
    )
    anchor = Vector(state["anchor"])
    tail = Vector(state["position"])
    previous_anchor = Vector(state.get("anchor_previous", anchor))
    previous_tail = Vector(state.get("previous", tail))
    velocity = Vector(
        state.get(
            "velocity",
            ((anchor - previous_anchor) + (tail - previous_tail))
            * (0.5 * fps),
        )
    )
    angular_velocity = Vector(
        state.get("angular_velocity", (0.0, 0.0, 0.0))
    )
    body_length = max(1.0e-4, (tail - anchor).length)
    inertia_per_mass = max(
        1.0e-4,
        (body_length * body_length + 4.0 * fallback_radius * fallback_radius)
        / 12.0,
    )
    predicted_anchor = anchor.copy()
    predicted_tail = tail.copy()
    gravity = _ragdoll_gravity(pose_bone)
    reference_world = armature.matrix_world @ pose_bone.matrix
    collision_surfaces = _ragdoll_filter_initial_overlap_surfaces(
        context,
        armature,
        pose_bone,
        int(context.scene.frame_current),
        state,
        compact_collision_samples or collision_samples,
        reference_world,
        collision_surfaces,
    )
    reference_scale = reference_world.to_scale()
    orientation = (
        Quaternion(state["orientation"]).normalized()
        if state.get("orientation") is not None
        else _ragdoll_tail_world_matrix(
            reference_world, anchor, tail
        ).to_quaternion().normalized()
    )
    local_body_direction = Vector((0.0, body_length, 0.0))
    # The welded mesh, not the pose bone, defines the rigid body's centre of
    # mass.  Using the bone midpoint can put the mathematical COM below a
    # visible corner, making gravity hold the part *on* that corner.  The
    # symmetric support samples provide a cheap, stable welded-volume centre.
    local_center = (
        sum(collision_samples, Vector((0.0, 0.0, 0.0)))
        / float(len(collision_samples))
        if collision_samples
        else Vector((0.0, float(pose_bone.length) * 0.5, 0.0))
    )
    oriented_y = orientation @ Vector((0.0, 1.0, 0.0))
    if oriented_y.length > 1.0e-8:
        orientation = (
            oriented_y.normalized().rotation_difference(
                (tail - anchor).normalized()
            )
            @ orientation
        ).normalized()
    contact_normal = (
        Vector(state["contact_normal"])
        if state.get("contact_normal") is not None
        else None
    )
    contact_point = (
        Vector(state["contact_point"])
        if state.get("contact_point") is not None
        else None
    )
    contact_self = bool(state.get("contact_self", False))
    contact_surface = str(state.get("contact_surface", ""))
    contact_point_local = state.get("contact_point_local")
    contact_normal_local = state.get("contact_normal_local")
    if contact_self:
        moving_contact = _ragdoll_contact_surface_world_frame(context, state)
        if moving_contact is not None:
            contact_point, contact_normal, _surface = moving_contact
        else:
            contact_normal = None
            contact_point = None
            contact_self = False
            contact_surface = ""
            contact_point_local = None
            contact_normal_local = None
    sleeping = bool(state.get("sleeping", False))
    sleep_steps = int(state.get("sleep_steps", 0))
    contact_steps = int(state.get("contact_steps", 0))
    final_support_count = 0
    for _substep in range(_RAGDOLL_SOLVER_SUBSTEPS):
        if sleeping:
            velocity.zero()
            angular_velocity.zero()
        else:
            velocity *= damping
            angular_velocity *= damping
            velocity += gravity * sub_dt
        old_orientation = orientation.copy()
        old_matrix = Matrix.LocRotScale(
            anchor,
            old_orientation,
            reference_scale,
        )
        center = old_matrix @ local_center
        direction = tail - anchor
        # Gravity is integrated into COM velocity above. The contact impulse
        # below converts that motion into the correct off-centre torque. An
        # additional explicit gravity torque double-counts the same force and
        # was the source of perpetual rocking and renewed launches.
        angular_speed = angular_velocity.length
        if angular_speed > 12.0:
            angular_velocity *= 12.0 / angular_speed
            angular_speed = 12.0
        if angular_speed > 1.0e-8:
            rotation = Quaternion(
                angular_velocity / angular_speed,
                angular_speed * sub_dt,
            )
            orientation = (rotation @ orientation).normalized()
            direction = orientation @ local_body_direction
        predicted_center = center + velocity * sub_dt
        rotated_offset = (
            Matrix.LocRotScale(
                Vector((0.0, 0.0, 0.0)),
                orientation,
                reference_scale,
            )
            @ local_center
        )
        predicted_anchor = predicted_center - rotated_offset
        predicted_tail = predicted_anchor + direction
        collision_normal = None
        collision_velocity = None
        support_count = 0
        if collision_samples:
            new_matrix = Matrix.LocRotScale(
                predicted_anchor,
                orientation,
                reference_scale,
            )
            # A free limb translates as one rigid welded body. Sweeping the
            # actual support points avoids the old endpoint spheres whose
            # radius could be almost a full Blender unit and catch surfaces
            # the visible mesh had not reached.
            persistent_contact = False
            if contact_normal is not None and contact_point is not None:
                active_contact_samples = (
                    compact_self_collision_samples
                    if contact_self else collision_samples
                )
                sample_world = tuple(
                    new_matrix @ sample for sample in active_contact_samples
                )
                signed = tuple(
                    (point - contact_point).dot(contact_normal)
                    for point in sample_world
                )
                minimum_index = min(
                    range(len(signed)), key=signed.__getitem__, default=0
                )
                minimum_distance = signed[minimum_index] if signed else 0.0
                penetration = max(0.0, -minimum_distance)
                contact_slop = max(
                    0.002, min(0.01, shape_radius * 0.02)
                )
                if (
                    minimum_distance <= contact_slop
                    and penetration <= max(0.02, shape_radius * 2.0)
                ):
                    persistent_contact = True
                    collision_normal = contact_normal.copy()
                    # Include support points crossed during this angular
                    # substep. A fast corner-to-edge rotation can otherwise
                    # step over the instant where two corners are exactly
                    # coplanar and remain classified as a single corner.
                    support_band = max(
                        1.0e-4,
                        min(
                            0.12,
                            shape_radius * 0.02
                            + shape_radius * angular_speed * sub_dt,
                        ),
                    )
                    support_points = tuple(
                        point - collision_normal * distance
                        for point, distance in zip(sample_world, signed)
                        if distance <= minimum_distance + support_band
                    )
                    support_count = len(support_points)
                    if not contact_self:
                        contact_point = sum(
                            support_points, Vector((0.0, 0.0, 0.0))
                        ) / float(len(support_points))
                    if penetration > 0.0:
                        correction = collision_normal * (
                            penetration + 1.0e-5
                        )
                        predicted_anchor += correction
                        predicted_tail += correction
                    angular_velocity *= max(0.0, 1.0 - friction * 0.5)
                elif minimum_distance > contact_slop:
                    contact_normal = None
                    contact_point = None
                    contact_self = False
                    contact_surface = ""
                    contact_point_local = None
                    contact_normal_local = None
            hit = None if persistent_contact else _ragdoll_welded_sweep(
                context,
                collision_surfaces,
                collision_samples,
                old_matrix,
                new_matrix,
                armature=armature,
                pose_bone=pose_bone,
                compact_samples=compact_collision_samples,
                self_collision_scale=self_collision_scale,
            )
            if hit is not None:
                fraction, collision_normal, contact_point, hit_surface = hit
                contact_self = _ragdoll_self_collision_surface(
                    hit_surface, armature
                )
                support_count = 1
                predicted_anchor = anchor.lerp(predicted_anchor, fraction)
                predicted_tail = tail.lerp(predicted_tail, fraction)
                predicted_anchor += collision_normal * 1.0e-5
                predicted_tail += collision_normal * 1.0e-5
                contact_normal = collision_normal.copy()
                if contact_self:
                    local_frame = _ragdoll_contact_surface_local_frame(
                        context, hit_surface, contact_point, collision_normal
                    )
                    if local_frame is not None:
                        (
                            contact_surface,
                            contact_point_local,
                            contact_normal_local,
                        ) = local_frame
                    else:
                        contact_surface = ""
                        contact_point_local = None
                        contact_normal_local = None
                else:
                    contact_surface = ""
                    contact_point_local = None
                    contact_normal_local = None
                sleeping = False
            if collision_normal is not None:
                energy_before = (
                    velocity.length_squared
                    + inertia_per_mass * angular_velocity.length_squared
                )
                impact_center = (
                    Matrix.LocRotScale(
                        predicted_anchor,
                        orientation,
                        reference_scale,
                    )
                    @ local_center
                )
                lever = Vector(contact_point) - impact_center
                point_velocity = velocity + angular_velocity.cross(lever)
                normal_speed = point_velocity.dot(collision_normal)
                impulse = Vector((0.0, 0.0, 0.0))
                if normal_speed < 0.0:
                    rotational_term = (
                        lever.cross(collision_normal).length_squared
                        / inertia_per_mass
                    )
                    impulse = collision_normal * (
                        -(1.0 + bounce) * normal_speed
                        / max(1.0e-5, 1.0 + rotational_term)
                    )
                    velocity += impulse
                    angular_velocity += (
                        lever.cross(impulse) / inertia_per_mass
                    )
                center_normal_speed = velocity.dot(collision_normal)
                inward_velocity = collision_normal * min(
                    0.0, center_normal_speed
                )
                tangent_velocity = velocity - (
                    collision_normal * center_normal_speed
                )
                collision_velocity = (
                    tangent_velocity * max(0.0, 1.0 - friction)
                )
                if bounce > 0.0:
                    collision_velocity -= inward_velocity * bounce
                energy_after = (
                    collision_velocity.length_squared
                    + inertia_per_mass * angular_velocity.length_squared
                )
                energy_limit = energy_before * (1.0 + bounce) + 1.0e-8
                if energy_after > energy_limit:
                    scale = math.sqrt(energy_limit / energy_after)
                    collision_velocity *= scale
                    angular_velocity *= scale
                angular_speed = angular_velocity.length
                if angular_speed > 12.0:
                    angular_velocity *= 12.0 / angular_speed
                if contact_self:
                    # Self-contact may redirect existing motion but may not
                    # inject energy into the articulated island. Sequential
                    # one-body solves otherwise let two moving limbs correct
                    # the same overlap twice and fling the whole rig.
                    self_energy_after = (
                        collision_velocity.length_squared
                        + inertia_per_mass
                        * angular_velocity.length_squared
                    )
                    self_energy_limit = energy_before + 1.0e-8
                    if self_energy_after > self_energy_limit:
                        self_scale = math.sqrt(
                            self_energy_limit / self_energy_after
                        )
                        collision_velocity *= self_scale
                        angular_velocity *= self_scale
        # No welded visible-object samples means no collision body. Never
        # substitute the pose bone as geometry: it does not represent the
        # visible part boundary and can balance the object in midair.
        if collision_normal is not None and collision_velocity is not None:
            # Positional depenetration is not momentum. Keep only the
            # reflected/tangential incoming velocity so contact correction
            # cannot manufacture a second impact or trap the limb.
            velocity = Vector(collision_velocity)
        if collision_normal is not None:
            contact_steps += 1
        else:
            contact_steps = 0
        if (
            collision_normal is not None
            and collision_normals
            and contact_steps >= _RAGDOLL_SOLVER_SUBSTEPS * 2
            and velocity.length < 3.0
        ):
            # Sequential-impulse engines use contact stabilization because a
            # finite timestep rarely lands on the exact instant when a second
            # corner joins the manifold. Pick the welded face already nearest
            # the surface plane and converge toward it gradually. This is
            # based on the visible part's face normals, never the pose bone.
            target_surface_normal = -collision_normal
            local_face_normal = min(
                collision_normals,
                key=lambda normal: (
                    (orientation @ normal).normalized()
                ).angle(target_surface_normal),
            )
            world_face_normal = (orientation @ local_face_normal).normalized()
            alignment_angle = world_face_normal.angle(target_surface_normal)
            if alignment_angle > 1.0e-4 and alignment_angle < 1.1:
                stabilization_center = (
                    Matrix.LocRotScale(
                        predicted_anchor,
                        orientation,
                        reference_scale,
                    )
                    @ local_center
                )
                correction = world_face_normal.rotation_difference(
                    target_surface_normal
                )
                target_orientation = (correction @ orientation).normalized()
                orientation = orientation.slerp(
                    target_orientation,
                    min(1.0, 12.0 * sub_dt),
                ).normalized()
                rotated_offset = (
                    Matrix.LocRotScale(
                        Vector((0.0, 0.0, 0.0)),
                        orientation,
                        reference_scale,
                    )
                    @ local_center
                )
                predicted_anchor = stabilization_center - rotated_offset
                predicted_tail = predicted_anchor + (
                    orientation @ local_body_direction
                )
                stabilized_matrix = Matrix.LocRotScale(
                    predicted_anchor,
                    orientation,
                    reference_scale,
                )
                minimum_distance = min(
                    (
                        (stabilized_matrix @ sample) - contact_point
                    ).dot(collision_normal)
                    for sample in collision_samples
                )
                if minimum_distance < 0.0:
                    correction_offset = collision_normal * (
                        -minimum_distance + 1.0e-5
                    )
                    predicted_anchor += correction_offset
                    predicted_tail += correction_offset
                angular_velocity *= max(0.0, 1.0 - 8.0 * sub_dt)
        # One welded sample is only a corner pivot and must keep rotating.
        # Two or more simultaneous samples form an edge/support manifold that
        # can legitimately settle without the recorded corner freeze.
        stable_support = support_count >= 2
        if (
            collision_normal is not None
            and stable_support
            and velocity.length < 0.35
            and angular_velocity.length < 3.0
        ):
            sleep_steps += 1
            # Once a real edge/face manifold remains slow for three solver
            # samples, settle it. Requiring a fourth let alternating corners
            # repeatedly reset the counter and produced the visible "dance".
            required_sleep_steps = _RAGDOLL_SOLVER_SUBSTEPS
            if sleep_steps >= required_sleep_steps:
                sleeping = True
                velocity.zero()
                angular_velocity.zero()
        else:
            sleep_steps = max(0, sleep_steps - 1)
            sleeping = False
        # Otherwise keep the centre-of-mass velocity integrated above.
        # Deriving it from one endpoint's displacement incorrectly converts
        # angular rotation into linear momentum. That positive feedback was
        # the recorded 0.9 -> 11.9 -> 25.6 -> 78.7 unparent launch.
        anchor = predicted_anchor.copy()
        tail = predicted_tail.copy()
        final_support_count = support_count
    next_previous_anchor = predicted_anchor - velocity * dt
    next_previous_tail = predicted_tail - velocity * dt
    return {
        "position": predicted_tail.copy(),
        "previous": next_previous_tail.copy(),
        "anchor": predicted_anchor.copy(),
        "anchor_previous": next_previous_anchor.copy(),
        "velocity": velocity.copy(),
        "angular_velocity": angular_velocity.copy(),
        "orientation": orientation.copy(),
        "sleeping": sleeping,
        "sleep_steps": sleep_steps,
        "contact_steps": contact_steps,
        "support_count": final_support_count,
        "contact_normal": (
            contact_normal.copy() if contact_normal is not None else None
        ),
        "contact_point": (
            contact_point.copy() if contact_point is not None else None
        ),
        "contact_self": contact_self,
        "contact_surface": contact_surface,
        "contact_point_local": (
            Vector(contact_point_local).copy()
            if contact_point_local is not None else None
        ),
        "contact_normal_local": (
            Vector(contact_normal_local).copy()
            if contact_normal_local is not None else None
        ),
        "free": True,
        "seeded": True,
    }


