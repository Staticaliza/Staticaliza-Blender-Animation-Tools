"""Component selection and native per-Graph-Editor curve isolation."""

from ..core.runtime import *  # noqa: F403


def _animation_selected_channel_groups(context):
    wanted = {
        owner: {bone.name for bone in owner.pose.bones if _pose_bone_selected(bone)}
        for owner in _pose_scope_armatures(context)
    }
    for _key, data in _pin_selected_targets_data(context):
        kind, owner, bone, _payload = data
        if kind in {"CONTACT", "GYRO"}:
            wanted.setdefault(owner, set()).add(f"Constraint ({bone.name})")
    return wanted


def _animation_component_fcurves(owner, names):
    """Resolve ordinary bones from RNA paths, independently of group labels."""
    prefixes = tuple(bone.path_from_id() for bone in owner.pose.bones if bone.name in names)
    result = []
    for curve in _action_fcurves(_dynamic_parent_owner_action(owner), owner):
        group = curve.group
        pin_group = group is not None and group.name.startswith('Constraint (')
        if pin_group:
            selected = group.name in names
        else:
            selected = any(curve.data_path.startswith(prefix + '.')
                           or curve.data_path.startswith(prefix + '[') for prefix in prefixes)
        if selected:
            result.append(curve)
    return tuple(result)


def _animation_graph_has_local_view():
    return 'local_view' in dir(bpy.ops.graph)


def _animation_graph_legacy_visibility(curves, target=None):
    """Graph-only visibility fallback for Blender before native Local View."""
    previous = _state.pop('animation_graph_legacy_visibility', {})
    _state.pop('animation_graph_legacy_active', None)
    identities = {}
    actions = {curve.id_data for curve in curves}
    for action in actions:
        uid = int(getattr(action, 'session_uid', action.as_pointer()))
        for bag in _action_channelbags(action):
            for curve in bag.fcurves:
                identities[int(curve.as_pointer())] = (uid, int(bag.slot_handle), curve.data_path, int(curve.array_index))
    for curve in curves:
        identities.setdefault(int(curve.as_pointer()), (
            int(getattr(curve.id_data, 'session_uid', curve.id_data.as_pointer())), 0, curve.data_path, int(curve.array_index)))
    for curve in curves:
        identity = identities[int(curve.as_pointer())]
        if identity in previous:
            curve.hide = previous[identity]
    if target is not None:
        wanted = {int(curve.as_pointer()) for curve in target}
        original = {}
        for curve in curves:
            hide = int(curve.as_pointer()) not in wanted
            if bool(curve.hide) != hide:
                identity = identities[int(curve.as_pointer())]
                original[identity] = bool(curve.hide)
                curve.hide = hide
        _state['animation_graph_legacy_visibility'] = original
        _state['animation_graph_legacy_active'] = True


def _animation_graph_selection_reset(context):
    """Exit native isolation without needing private SpaceGraph memory.

    With all FCurves deselected, Local View can only exit an existing scope;
    entering a new empty scope is cancelled by Blender. Do not push Undo or
    frame/zoom the view. All native curve/key selection is retained.
    """
    curves = tuple(curve for action in bpy.data.actions
                   if not action.get('_staticaliza_pin_curve_eval', False)
                   for curve in _action_fcurves(action))
    if _state.get('animation_graph_legacy_active'):
        _animation_graph_legacy_visibility(curves)
    if _animation_graph_has_local_view():
        return bpy.ops.graph.local_view('EXEC_DEFAULT', False, frame_selected=False)
    return {'CANCELLED'}


def _animation_graph_restore_parked_scope(context, window, screen, area, space, state, curves):
    original_type = area.type
    selected = tuple((curve, bool(curve.select)) for curve in curves)
    try:
        area.type = 'GRAPH_EDITOR'
        region = next((r for r in area.regions if r.type == 'WINDOW'), None)
        if region is not None:
            for curve, was_selected in selected:
                if was_selected:
                    curve.select = False
            space.dopesheet.show_only_selected = False
            space.dopesheet.filter_fcurve_name = state['filters'][1]
            with context.temp_override(window=window, screen=screen, area=area, region=region):
                _animation_graph_selection_reset(context)
    finally:
        for curve, was_selected in selected:
            if curve.select != was_selected:
                curve.select = was_selected
        space.dopesheet.show_only_selected, space.dopesheet.filter_fcurve_name = state['filters']
        area.type = original_type


def _animation_finish_graph_selection():
    _animation_sync_graph_selection(bpy.context)
    return None


def _animation_sync_graph_selection(context, *, restore=False, force=False):
    if context is None or _state.get("animation_graph_selection_syncing"):
        return False
    if not restore and (_state.get('pin_selection_syncing')
                        or _window_manager_has_modal_operator(context)):
        # Pin selection can run inside Gizmo.invoke. Native operators flush
        # dependencies, which may retire that live gizmo group. Finish on the
        # next event tick instead; the existing idle sync also covers drags.
        if not bpy.app.timers.is_registered(_animation_finish_graph_selection):
            register_owned_timer(_animation_finish_graph_selection, first_interval=0.)
        return False
    if not restore and any(_state.get(key) for key in (
        "pin_history_active", "pin_history_syncing", "pin_target_dragging",
        "pin_keyboard_transform_active", "pin_channel_selection_pending",
    )):
        return False
    scopes = _state.setdefault("animation_graph_selection_scopes", {})
    # Retire the previous broad selected-only exception, including parked
    # Dope Sheet spaces. It must not coexist with component isolation.
    legacy = _state.pop("pin_editor_selection_filters", {})
    windows = tuple(getattr(context.window_manager, "windows", ()))
    for window in windows:
        for area in window.screen.areas:
            for space in area.spaces:
                original = legacy.get(int(space.as_pointer()))
                if original is not None and hasattr(space, "dopesheet"):
                    space.dopesheet.show_only_selected = original
    enabled = not restore and getattr(context, "mode", "") == "POSE"
    wanted = _animation_selected_channel_groups(context) if enabled else {}
    structure = tuple(
        (_armature_session_uid(owner), int(action.as_pointer()),
         len(_action_fcurves(action, owner)),
         tuple((group.name, len(group.channels)) for groups in _action_group_owners(action, owner)
               for group in groups))
        for owner in wanted
        if (action := _dynamic_parent_owner_action(owner)) is not None
    )
    selection = tuple(sorted((_armature_session_uid(owner), tuple(sorted(names)))
                             for owner, names in wanted.items()))
    changed = False
    live = set()
    frame = context.scene.frame_current_final
    poses = None
    targets = ()
    _state["animation_graph_selection_syncing"] = True
    previous_syncing = _state.get("pin_selection_syncing", False)
    previous_maintenance = _state.get("animation_channel_maintenance_syncing", False)
    _state["pin_selection_syncing"] = True
    _state["animation_channel_maintenance_syncing"] = True
    try:
        curves = None
        for window in windows:
            for area in window.screen.areas:
                for space in area.spaces:
                    pointer = int(space.as_pointer())
                    if pointer not in scopes and space.type != "GRAPH_EDITOR":
                        continue
                    if space.type != "GRAPH_EDITOR":
                        continue
                    live.add(pointer)
                    state = scopes.get(pointer)
                    active = space == area.spaces.active and space.mode == 'FCURVES'
                    relevant = enabled and any(window.scene.objects.get(owner.name) == owner for owner in wanted)
                    if not active:
                        continue
                    ds = space.dopesheet
                    # Older builds wrote an empty-result label into Blender's
                    # real search field (filter_text and filter_fcurve_name are
                    # aliases). Retire that derived search even in cached views.
                    if ds.filter_fcurve_name == "— No keyed selection —":
                        ds.filter_fcurve_name = ''
                        if state is not None:
                            state.pop('signature', None)
                    if state is None:
                        if not relevant:
                            continue
                        state = scopes[pointer] = {
                            "filters": (bool(ds.show_only_selected), str(ds.filter_fcurve_name)),
                        }
                        if state['filters'][1] == "— No keyed selection —":
                            # A saved empty native view is derived UI state,
                            # never a permanent user search on a later load.
                            state['filters'] = (state['filters'][0], '')
                    signature = (selection, structure, int(getattr(window.scene, 'session_uid', window.scene.as_pointer())),
                                 ds.filter_text, bool(ds.use_filter_invert), bool(ds.show_only_errors))
                    if relevant and not force and state.get("signature") == signature:
                        continue
                    if curves is None:
                        poses = tuple((bone, bone.matrix_basis.copy()) for owner in _pose_scope_armatures(context)
                                      for bone in owner.pose.bones)
                        targets = tuple((guide, guide.matrix_basis.copy()) for guide in _surface_contact_guides()
                                        if guide.name in context.scene.objects)
                        curves = tuple(curve for action in bpy.data.actions
                                       if not action.get('_staticaliza_pin_curve_eval', False)
                                       for curve in _action_fcurves(action))
                    selected = tuple((curve, bool(curve.select)) for curve in curves)
                    region = next((r for r in area.regions if r.type == 'WINDOW'), None)
                    if region is None:
                        continue
                    try:
                        for curve, was_selected in selected:
                            if was_selected:
                                curve.select = False
                        ds.show_only_selected = False
                        ds.filter_fcurve_name = state["filters"][1]
                        with context.temp_override(window=window, area=area, region=region):
                            _animation_graph_selection_reset(context)
                            if relevant:
                                target = tuple(
                                    curve for owner, names in wanted.items()
                                    if window.scene.objects.get(owner.name) == owner
                                    for curve in _animation_component_fcurves(owner, names)
                                )
                                if target:
                                    for curve in target:
                                        curve.select = True
                                    if _animation_graph_has_local_view():
                                        bpy.ops.graph.local_view('EXEC_DEFAULT', False, frame_selected=False)
                                    else:
                                        _animation_graph_legacy_visibility(curves, target)
                                else:
                                    # Native Local View cannot enter an empty
                                    # set. Use reversible Graph visibility and
                                    # native bone filtering, never a fake search.
                                    ds.show_only_selected = True
                                    _animation_graph_legacy_visibility(curves, ())
                                state["signature"] = signature
                            else:
                                ds.show_only_selected, ds.filter_fcurve_name = state["filters"]
                                scopes.pop(pointer, None)
                    finally:
                        for curve, was_selected in selected:
                            if curve.select != was_selected:
                                curve.select = was_selected
                    area.tag_redraw()
                    changed = True
        if not changed and enabled:
            return False
        # Stored workspaces and parked Graph spaces still own their native
        # local-view bit. Keep their plain-data bookkeeping until they reopen;
        # on teardown restore them synchronously with the screen/area intact.
        stored = {}
        for screen in bpy.data.screens:
            for area in screen.areas:
                for space in area.spaces:
                    pointer = int(space.as_pointer())
                    if space.type == 'GRAPH_EDITOR' and pointer in scopes:
                        stored[pointer] = (screen, area, space)
        for pointer in tuple(scopes):
            if pointer not in stored:
                scopes.pop(pointer, None)
            elif not enabled and windows:
                screen, area, space = stored[pointer]
                if curves is None:
                    poses = tuple((bone, bone.matrix_basis.copy()) for owner in _pose_scope_armatures(context)
                                  for bone in owner.pose.bones)
                    targets = tuple((guide, guide.matrix_basis.copy()) for guide in _surface_contact_guides()
                                    if guide.name in context.scene.objects)
                    curves = tuple(curve for action in bpy.data.actions
                                   if not action.get('_staticaliza_pin_curve_eval', False)
                                   for curve in _action_fcurves(action))
                _animation_graph_restore_parked_scope(
                    context, windows[0], screen, area, space, scopes.pop(pointer), curves)
                changed = True
    finally:
        # A native UI operator's pre-flush can replay raw Action LRS. Curve
        # isolation owns no pose edit: publish the unchanged evaluated pose
        # and target sample last, without another recursive dependency flush.
        if poses is not None and context.scene.frame_current_final == frame:
            for item, basis in (*targets, *poses):
                if _pin_keyboard_matrices_differ(item.matrix_basis, basis, epsilon=1.e-7):
                    item.matrix_basis = basis
        _state["pin_selection_syncing"] = previous_syncing
        _state["animation_channel_maintenance_syncing"] = previous_maintenance
        _state["animation_graph_selection_syncing"] = False
    return changed
