"""Dope Sheet channel discovery and automatic hierarchy expansion."""

from ..core.runtime import *  # noqa: F403


_ANIMATION_EDITOR_POSE_WORKSPACES = frozenset({
    "animate",
    "graph",
    "audio",
    "preview",
})


def _capture_animation_editor_filters(area):
    filters = []
    for space in tuple(getattr(area, "spaces", ())):
        dopesheet = getattr(space, "dopesheet", None)
        if dopesheet is None:
            continue
        try:
            filters.append(
                (
                    space,
                    str(dopesheet.filter_text),
                    bool(dopesheet.use_filter_invert),
                    bool(dopesheet.show_only_selected),
                    bool(dopesheet.show_only_errors),
                )
            )
        except (AttributeError, ReferenceError, TypeError, ValueError):
            pass
    return tuple(filters)


def _hide_animation_editor_keys(area):
    """Blank an animation editor using Blender's native filter toggles."""
    changed = False
    for space in tuple(getattr(area, "spaces", ())):
        dopesheet = getattr(space, "dopesheet", None)
        if dopesheet is None:
            continue
        try:
            if str(dopesheet.filter_text):
                dopesheet.filter_text = ""
                changed = True
            if dopesheet.use_filter_invert:
                dopesheet.use_filter_invert = False
                changed = True
            if not dopesheet.show_only_selected:
                dopesheet.show_only_selected = True
                changed = True
            if not dopesheet.show_only_errors:
                dopesheet.show_only_errors = True
                changed = True
            if dopesheet.show_summary:
                dopesheet.show_summary = False
                changed = True
            if dopesheet.show_expanded_summary:
                dopesheet.show_expanded_summary = False
                changed = True
        except (AttributeError, ReferenceError, TypeError, ValueError):
            pass
    return changed


def _disable_animation_editor_summary(area):
    """Keep Blender's redundant Summary channel out of animator editors."""
    changed = False
    for space in tuple(getattr(area, "spaces", ())):
        dopesheet = getattr(space, "dopesheet", None)
        if dopesheet is None:
            continue
        try:
            if dopesheet.show_summary:
                dopesheet.show_summary = False
                changed = True
            if dopesheet.show_expanded_summary:
                dopesheet.show_expanded_summary = False
                changed = True
        except (AttributeError, ReferenceError, TypeError, ValueError):
            pass
    return changed


def _animation_editor_workspace_supported(workspace):
    if not _template_layout_workspace(workspace):
        return False
    try:
        name = _strip_blender_numeric_suffix(workspace.name)
    except (AttributeError, ReferenceError, TypeError, ValueError):
        return False
    return str(name).strip().casefold() in _ANIMATION_EDITOR_POSE_WORKSPACES


def _animation_editor_screen_sources(context = None):
    """Return live and stored animator screens, with active windows first."""
    context = context or bpy.context
    sources = []
    seen = set()
    window_manager = getattr(context, "window_manager", None)
    for window in tuple(getattr(window_manager, "windows", ())):
        workspace = getattr(window, "workspace", None)
        screen = getattr(window, "screen", None)
        if screen is None or not _animation_editor_workspace_supported(workspace):
            continue
        try:
            pointer = int(screen.as_pointer())
        except (AttributeError, ReferenceError, TypeError, ValueError):
            continue
        if pointer in seen:
            continue
        seen.add(pointer)
        sources.append((workspace, screen))
    for workspace in tuple(bpy.data.workspaces):
        if not _animation_editor_workspace_supported(workspace):
            continue
        for screen in tuple(getattr(workspace, "screens", ())):
            try:
                pointer = int(screen.as_pointer())
            except (AttributeError, ReferenceError, TypeError, ValueError):
                continue
            if pointer in seen:
                continue
            seen.add(pointer)
            sources.append((workspace, screen))
    return tuple(sources)


def _canonical_animation_editor_area(workspace, screen):
    """Keep the bundled template's lower editor in its named type."""
    if not _template_layout_workspace(workspace):return None,False
    try:
        workspace_name = str(
            _strip_blender_numeric_suffix(workspace.name)
        ).strip().casefold()
    except (AttributeError, ReferenceError, TypeError, ValueError):
        return None, False
    desired = {
        "animate": ("DOPESHEET_EDITOR", "DOPESHEET"),
        "graph": ("GRAPH_EDITOR", "FCURVES"),
    }.get(workspace_name)
    if desired is None:
        return None, False
    candidates = [
        area
        for area in tuple(getattr(screen, "areas", ()))
        if area.type in {"DOPESHEET_EDITOR", "GRAPH_EDITOR"}
    ]
    if not candidates:
        return None, False
    area = max(
        candidates,
        key = lambda candidate: int(candidate.width) * int(candidate.height),
    )
    desired_type, desired_mode = desired
    changed = False
    try:
        if area.type != desired_type:
            area.type = desired_type
            changed = True
        current_mode = str(
            getattr(area, "ui_type", "")
            or getattr(area.spaces.active, "mode", "")
        )
        if current_mode != desired_mode:
            area.ui_type = desired_mode
            changed = True
        if _disable_animation_editor_summary(area):
            changed = True
        if changed:
            area.tag_redraw()
    except (
        AttributeError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ):
        return area, changed
    return area, changed


def _canonicalize_animation_editor_layouts(context = None):
    changed = False
    for workspace, screen in _animation_editor_screen_sources(context):
        _area, area_changed = _canonical_animation_editor_area(
            workspace,
            screen,
        )
        changed = area_changed or changed
        for area in tuple(getattr(screen, "areas", ())):
            if area.type not in {"DOPESHEET_EDITOR", "GRAPH_EDITOR"}:
                continue
            if _disable_animation_editor_summary(area):
                changed = True
                try:
                    area.tag_redraw()
                except (AttributeError, ReferenceError, RuntimeError):
                    pass
    return changed


def _restore_animation_editor_pose_states():
    """Restore editor filters saved before the Object Mode content lock."""
    states = _state.setdefault("animation_editor_pose_states", {})
    changed = False
    for key, state in tuple(states.items()):
        area, original_type, original_mode, original_filters = state
        area_changed = False
        try:
            if area.type != original_type:
                area.type = original_type
                changed = True
                area_changed = True
            if original_mode:
                current_mode = str(
                    getattr(area, "ui_type", "")
                    or getattr(area.spaces.active, "mode", "")
                )
                if current_mode != original_mode:
                    area.ui_type = original_mode
                    changed = True
                    area_changed = True
                for space in tuple(area.spaces):
                    if (
                        getattr(space, "type", "") == original_type
                        and hasattr(space, "mode")
                        and str(space.mode) != original_mode
                    ):
                        space.mode = original_mode
                        changed = True
                        area_changed = True
            for filter_state in original_filters:
                try:
                    space, filter_text, use_filter_invert = filter_state[:3]
                    show_only_selected = (
                        bool(filter_state[3])
                        if len(filter_state) >= 4
                        else False
                    )
                    show_only_errors = (
                        bool(filter_state[4])
                        if len(filter_state) >= 5
                        else False
                    )
                    dopesheet = space.dopesheet
                    if str(dopesheet.filter_text) != filter_text:
                        dopesheet.filter_text = filter_text
                        changed = True
                        area_changed = True
                    if bool(dopesheet.use_filter_invert) != use_filter_invert:
                        dopesheet.use_filter_invert = use_filter_invert
                        changed = True
                        area_changed = True
                    if (
                        bool(dopesheet.show_only_selected)
                        != show_only_selected
                    ):
                        dopesheet.show_only_selected = show_only_selected
                        changed = True
                        area_changed = True
                    if bool(dopesheet.show_only_errors) != show_only_errors:
                        dopesheet.show_only_errors = show_only_errors
                        changed = True
                        area_changed = True
                    if dopesheet.show_summary:
                        dopesheet.show_summary = False
                        changed = True
                        area_changed = True
                    if dopesheet.show_expanded_summary:
                        dopesheet.show_expanded_summary = False
                        changed = True
                        area_changed = True
                except (AttributeError, ReferenceError, TypeError, ValueError):
                    pass
            if area_changed:
                area.tag_redraw()
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            pass
        states.pop(key, None)
    return changed


def _sync_animation_editors_pose_mode(context):
    """Expose animation channels only while the animator is in Pose Mode."""
    if context is None or _window_manager_has_modal_operator(context):
        return False
    # Restore pin-only selection's filter exception before Object Mode's
    # content lock captures user filters. This also follows editor/workspace
    # changes through the existing sync, without another polling timer.
    _pin_sync_contact_graph_filter(context)
    active = context.view_layer.objects.active
    if (active is not None and active.get('impaction_marker_host', False)
            and any(obj.type == 'ARMATURE' and obj.mode == 'POSE'
                    for obj in context.view_layer.objects)):
        return _restore_animation_editor_pose_states()
    now = time.perf_counter()
    topology = tuple(
        (
            int(screen.as_pointer()),
            tuple(
                (
                    int(area.as_pointer()),
                    str(area.type),
                    str(getattr(area, "ui_type", "")),
                )
                for area in tuple(getattr(screen, "areas", ()))
            ),
        )
        for _workspace, screen in _animation_editor_screen_sources(context)
    )
    signature = (str(getattr(context, "mode", "")), topology)
    if (
        signature == _state.get("animation_editor_sync_signature")
        and now - float(_state.get("animation_editor_sync_time", 0.0)) < 0.5
    ):
        return False
    _state["animation_editor_sync_signature"] = signature
    _state["animation_editor_sync_time"] = now
    if getattr(context, "mode", "") != "OBJECT":
        changed = _restore_animation_editor_pose_states()
        return _canonicalize_animation_editor_layouts(context) or changed

    states = _state.setdefault("animation_editor_pose_states", {})
    changed = _canonicalize_animation_editor_layouts(context)
    for _workspace, screen in _animation_editor_screen_sources(context):
        for area in tuple(getattr(screen, "areas", ())):
            if area.type not in {
                "DOPESHEET_EDITOR",
                "GRAPH_EDITOR",
                "NLA_EDITOR",
            }:
                continue
            key = int(area.as_pointer())
            current_mode = str(
                getattr(area, "ui_type", "")
                or getattr(area.spaces.active, "mode", "")
            )
            if key not in states:
                if (
                    area.type == "DOPESHEET_EDITOR"
                    and current_mode == "TIMELINE"
                ):
                    continue
                states[key] = (
                    area,
                    str(area.type),
                    current_mode,
                    _capture_animation_editor_filters(area),
                )
            area_changed = False
            try:
                if _hide_animation_editor_keys(area):
                    changed = True
                    area_changed = True
                if area_changed:
                    area.tag_redraw()
            except (
                AttributeError,
                ReferenceError,
                RuntimeError,
                TypeError,
                ValueError,
            ):
                continue
    return changed


def _animation_channel_entries():
    try:
        actions = tuple(bpy.data.actions)
    except AttributeError:
        return ()

    entries = []
    for action in actions:
        # Undo keeps the logical Action/slot but can replace their RNA storage.
        # Pointer identities turn every history step into a newly discovered
        # hierarchy and invoke channels_expand, which replays raw pose Actions.
        identity = int(action.session_uid) if hasattr(action, 'session_uid') else (
            action.name_full, action.library.filepath if action.library else '')
        try:
            action_has_content = bool(_action_fcurves(action))
            entries.append(
                (("ACTION", identity), action, action_has_content)
            )
        except (AttributeError, ReferenceError):
            action_has_content = False
        for slot in getattr(action, "slots", ()):
            try:
                slot_handle = int(getattr(slot, "handle", 0))
                has_content = any(
                    int(getattr(channelbag, "slot_handle", 0)) == slot_handle
                    and bool(tuple(channelbag.fcurves))
                    for channelbag in _action_channelbags(action)
                )
                entries.append(
                    (("SLOT", identity, slot_handle), slot, has_content)
                )
            except (AttributeError, ReferenceError):
                pass
        # Group objects are deliberately rebuilt when their final display
        # order changes.  Pointer-based identities therefore made the
        # expansion timer treat every reorder as a brand-new set of channels
        # and invoke ``channels_expand`` repeatedly after unrelated edits.
        # The Action/owner/name tuple is stable across that internal rebuild.
        for owner_index, groups in enumerate(_action_group_owners(action)):
            for group in groups:
                try:
                    entries.append(
                        (
                            (
                                "GROUP",
                                identity,
                                int(owner_index),
                                str(group.name),
                            ),
                            group,
                            True,
                        )
                    )
                except (AttributeError, ReferenceError):
                    pass
    return tuple(entries)


def _capture_animation_channel_baseline():
    entries = _animation_channel_entries()
    _state["expanded_animation_channels"] = {
        key for key, _channel, _has_content in entries
    }
    _state["animation_channel_content"] = {
        key: bool(has_content)
        for key, _channel, has_content in entries
    }
    expansion_requested = any(
        key[0] == "ACTION" and bool(has_content)
        for key, _channel, has_content in entries
    )
    _state["animation_channel_expand_pending"] = expansion_requested
    _state["animation_channel_expand_attempts"] = (
        1 if expansion_requested else 0
    )


def _expand_dopesheet_hierarchy():
    window_manager = getattr(bpy.context, "window_manager", None)
    if window_manager is None:
        return False

    impact_actions = {obj.animation_data.action for obj in bpy.data.objects
                      if obj.get('impaction_marker_host', False) and obj.animation_data
                      and obj.animation_data.action is not None}
    attempted = False
    for window in window_manager.windows:
        for area in window.screen.areas:
            if area.type != "DOPESHEET_EDITOR":
                continue
            space = area.spaces.active
            if (
                str(getattr(area, "ui_type", "")) == "TIMELINE"
                or str(getattr(space, "mode", "")) == "TIMELINE"
            ):
                continue
            channel_region = next(
                (region for region in area.regions if region.type == "CHANNELS"),
                None,
            )
            if channel_region is None:
                continue
            dopesheet = getattr(space, "dopesheet", None)
            if dopesheet is not None:
                dopesheet.show_summary = False
                dopesheet.show_expanded_summary = False
            marker_host = next((obj for obj in window.scene.objects
                                if obj.get('impaction_marker_host', False)), None)
            saved_filter = {}
            scope = None
            if marker_host is not None and dopesheet is not None:
                # Impact owns its one-time reveal. A later ordinary bone key
                # must not reopen an Impact hierarchy the animator collapsed.
                for name in ('filter_text', 'use_filter_invert', 'use_multi_word_filter', 'filter_fcurve_name', 'filter_collection'):
                    saved_filter[name] = getattr(dopesheet, name)
                scope = bpy.data.collections.new('_AnimationChannelExpandScope')
                for obj in window.scene.objects:
                    if not obj.get('impaction_marker_host', False):
                        scope.objects.link(obj)
                dopesheet.filter_collection = scope
                dopesheet.filter_text = ""
                dopesheet.use_filter_invert = False
                dopesheet.use_multi_word_filter = False
                dopesheet.filter_fcurve_name = ""
            try:
                with bpy.context.temp_override(
                    window = window,
                    area = area,
                    region = channel_region,
                    space_data = space,
                ):
                    if bpy.ops.anim.channels_expand.poll():
                        result = bpy.ops.anim.channels_expand(all = True)
                        attempted = "FINISHED" in result or attempted
            except (AttributeError, RuntimeError, TypeError):
                continue
            finally:
                for name, value in saved_filter.items():
                    setattr(dopesheet, name, value)
                if scope is not None:
                    bpy.data.collections.remove(scope)

    # The operator opens Blender's private object/action hierarchy state. Keep
    # pose-bone transform channels folded so only the useful first level shows.
    for action in tuple(bpy.data.actions):
        if action in impact_actions:
            continue
        for slot in getattr(action, "slots", ()):
            try:
                slot.show_expanded = True
            except (AttributeError, ReferenceError, TypeError):
                pass
        for groups in _action_group_owners(action):
            for group in groups:
                try:
                    group.show_expanded = False
                except (AttributeError, ReferenceError, TypeError):
                    pass

    if attempted:
        for window in window_manager.windows:
            for area in window.screen.areas:
                if (
                    area.type == "DOPESHEET_EDITOR"
                    and str(getattr(area, "ui_type", "")) != "TIMELINE"
                ):
                    area.tag_redraw()
    return attempted


def _expand_new_animation_channels():
    if (
        _pin_primary_mouse_pressed()
        or _window_manager_has_modal_operator(bpy.context)
        or _animation_playback_active()
    ):
        return 0.25
    _apply_keyframe_handle_mode_to_new_pose_keys()
    entries = _animation_channel_entries()
    if not entries:
        return 0.15

    seen = _state.setdefault("expanded_animation_channels", set())
    content_state = _state.setdefault("animation_channel_content", {})
    live = {key for key, _channel, _has_content in entries}
    impact_ids = {int(obj.animation_data.action.session_uid) for obj in bpy.data.objects
                  if obj.get('impaction_marker_host', False) and obj.animation_data
                  and obj.animation_data.action is not None}
    expansion_requested = False
    for key, channel, has_content in entries:
        if key[1] in impact_ids:
            seen.add(key)
            content_state[key] = bool(has_content)
            continue
        is_new = key not in seen
        gained_content = bool(has_content) and not bool(
            content_state.get(key, False)
        )
        try:
            # Reveal the action hierarchy, but keep each bone's transform
            # F-curves collapsed until the user explicitly expands that bone.
            if key[0] == "ACTION" and (
                gained_content or (is_new and has_content)
            ):
                expansion_requested = True
            elif key[0] == "SLOT" and (
                gained_content or (is_new and has_content)
            ):
                channel.show_expanded = True
                expansion_requested = True
            elif key[0] == "GROUP" and is_new:
                channel.show_expanded = False
                expansion_requested = True
        except (AttributeError, ReferenceError, TypeError):
            pass
        seen.add(key)
        content_state[key] = bool(has_content)
    seen.intersection_update(live)
    for key in tuple(content_state):
        if key not in live:
            content_state.pop(key, None)

    if expansion_requested:
        _state["animation_channel_expand_pending"] = True
        # ``all=True`` expands the complete hierarchy in one operation.  A
        # three-tick retry loop made each newly sorted group visibly settle
        # over ~0.45 s and needlessly dirtied animation-editor state.
        _state["animation_channel_expand_attempts"] = 1
    if _state.get("animation_channel_expand_pending", False):
        if _expand_dopesheet_hierarchy():
            attempts = max(
                0,
                int(_state.get("animation_channel_expand_attempts", 0)) - 1,
            )
            _state["animation_channel_expand_attempts"] = attempts
            _state["animation_channel_expand_pending"] = attempts > 0
    return 0.15


def _animation_reveal_selected_bone_channels(context):
    """Follow a viewport bone selection without selecting keys or changing time."""
    owners = _pose_scope_armatures(context)
    active = getattr(context, 'active_pose_bone', None)
    wanted_by_owner = _animation_selected_channel_groups(context)
    changed = False
    for owner in owners:
        action = _dynamic_parent_owner_action(owner)
        wanted = wanted_by_owner.get(owner, set())
        selected_curves = {int(curve.as_pointer()) for curve in _animation_component_fcurves(owner, wanted)}
        for groups in _action_group_owners(action, owner):
            for group in groups:
                selected = any(int(curve.as_pointer()) in selected_curves for curve in group.channels)
                if group.select != selected:
                    group.select = selected
                for curve in group.channels:
                    curve_selected = int(curve.as_pointer()) in selected_curves
                    if curve.select != curve_selected:
                        curve.select = curve_selected
                if selected:
                    changed = True
        for curve in _action_fcurves(action, owner):
            if curve.group is None:
                selected = int(curve.as_pointer()) in selected_curves
                if curve.select != selected:
                    curve.select = selected
        if action is not None:
            for slot in getattr(action, 'slots', ()):
                if slot.handle == getattr(owner.animation_data, 'action_slot_handle', -1):
                    slot.show_expanded = True
    changed = _animation_sync_graph_selection(context) or changed
    if not changed:
        return False
    for obj in context.scene.objects:
        if not obj.get('impaction_marker_host', False):
            continue
        if obj != context.active_object and obj.select_get():
            obj.select_set(False)
        action = getattr(getattr(obj, 'animation_data', None), 'action', None)
        for groups in _action_group_owners(action, obj):
            for group in groups:
                group.select = False
                for curve in group.channels:
                    curve.select = False
    for area in context.window.screen.areas:
        if area.type not in {'DOPESHEET_EDITOR', 'GRAPH_EDITOR'} or getattr(area.spaces.active, 'mode', '') == 'TIMELINE':
            continue
        region = next((r for r in area.regions if r.type == 'CHANNELS'), None)
        if region is not None and active is not None:
            _animation_scroll_bone_channel(context, area, region, active.id_data, active.name)
            area.tag_redraw()
    return True


def _animation_queue_bone_channel_follow():
    context = bpy.context
    if (context.mode != 'POSE' or _animation_playback_active(context)
            or _state.get('pin_history_active') or _pin_selected_target_key()):
        return
    if not bpy.app.timers.is_registered(_animation_finish_bone_channel_follow):
        register_owned_timer(_animation_finish_bone_channel_follow, first_interval=0.0)


def _animation_finish_bone_channel_follow():
    context = bpy.context
    if context.mode == 'POSE' and not _state.get('pin_history_active'):
        _animation_reveal_selected_bone_channels(context)
    return None


def _animation_scroll_bone_channel(context, area, region, owner, bone_name):
    """Pan the channel list only; never frame keys or zoom the curve view."""
    if bpy.app.background or region.width < 2 or region.height < 2:
        return False
    ds = area.spaces.active.dopesheet
    if ds.filter_text or ds.filter_fcurve_name or ds.show_only_errors:
        return False
    objects = tuple(context.scene.objects)
    if ds.use_datablock_sort:
        objects = tuple(sorted(objects, key=lambda obj: obj.name.casefold()))
    allowed = set(ds.filter_collection.all_objects) if ds.filter_collection else None
    row = int(ds.show_summary)
    graph = area.type == 'GRAPH_EDITOR'
    isolated = (graph and int(area.spaces.active.as_pointer())
                in _state.get('animation_graph_selection_scopes', {}))
    components = _animation_selected_channel_groups(context) if isolated else {}
    for obj in objects:
        if allowed is not None and obj not in allowed:
            continue
        if not ds.show_hidden and obj.hide_get():
            continue
        if ds.show_only_selected and not obj.select_get() and obj.mode != 'POSE':
            continue
        action = _dynamic_parent_owner_action(obj)
        curves = _action_fcurves(action, obj)
        if not curves:
            continue
        if isolated and not any(curve.group is not None
                                and curve.group.name in components.get(obj, ()) for curve in curves):
            continue
        # Object and owning Action/slot are native blue hierarchy rows.
        row += 2
        for groups in _action_group_owners(action, obj):
            for group in groups:
                if isolated and group.name not in components.get(obj, ()):
                    continue
                bone = obj.pose.bones.get(group.name) if obj.type == 'ARMATURE' else None
                if ds.show_only_selected and bone is not None and not _pose_bone_selected(bone):
                    continue
                if obj == owner and group.name == bone_name:
                    scale = max(float(context.preferences.system.ui_scale),
                                float(context.preferences.system.dpi) / 72.0)
                    factor = context.preferences.themes[0].dopesheet_editor.keyframe_scale_factor
                    step = (16.0 * max(.1, factor) + 2.0) * scale
                    target = -(row + .5) * step - 30.0 * scale
                    y = region.view2d.view_to_region(0, target, clip=False)[1]
                    if abs(float(y)) >= 2**30:
                        # Native View2D can return an integer-limit sentinel
                        # before a freshly changed editor has laid out rows.
                        return False
                    margin = 2 * step
                    if margin <= y <= region.height - margin:
                        return True
                    with context.temp_override(area=area, region=region):
                        bpy.ops.view2d.pan(deltax=0, deltay=round(y - region.height * .5))
                    return True
                row += 1
                if (group.show_expanded_graph if graph else group.show_expanded):
                    row += len(group.channels)
        row += sum(curve.group is None for curve in curves)
    return False


def _animation_observe_channel_delete(context):
    _state['animation_channel_delete_pending'] = time.perf_counter() + 3.0
    if not bpy.app.timers.is_registered(_animation_finish_channel_delete):
        register_owned_timer(_animation_finish_channel_delete, first_interval=0.0)


def _animation_finish_channel_delete():
    deadline = _state.get('animation_channel_delete_pending')
    if deadline is None:
        return None
    context = bpy.context
    if _window_manager_has_modal_operator(context):
        if time.perf_counter() < deadline:
            return 0.02
        _state.pop('animation_channel_delete_pending', None)
        return None
    _state.pop('animation_channel_delete_pending', None)
    if _state.get('pin_history_active'):
        return None
    _reconcile_dynamic_space_markers(context)
    _constraint_reconcile_gyro(context)
    if _ragdoll_reconcile_marker_edits(context.scene):
        _ragdoll_frame_change_post(context.scene)
    _surface_contact_frame_change_post(context.scene)
    _sync_all_dynamic_pose_bone_colors(context.scene.frame_current)
    _tag_redraw_all_view3d()
    return None
