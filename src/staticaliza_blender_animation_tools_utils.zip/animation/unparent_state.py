"""Dynamic-unparent marker state, relation switching, and pose preservation."""

from ..core.runtime import *  # noqa: F403

def _fcurve_remove_key_all(action, data_path, frame):
    if not action:
        return

    frame = int(frame)

    for fc in list(_fcurves_find_all(action, data_path)):
        removed = False

        for kp in list(fc.keyframe_points):
            try:
                fr = int(round(float(kp.co.x)))
            except Exception:
                continue

            if int(fr) != int(frame):
                continue

            try:
                fc.keyframe_points.remove(kp)
                removed = True
            except Exception:
                pass

        if removed:
            if not fc.keyframe_points:
                try:
                    _action_remove_fcurve(action, fc)
                except Exception:
                    pass
            else:
                try:
                    fc.update()
                except Exception:
                    pass

def _unparent_next_transform_keyframe(action, bone_name, after_frame):
    if not action:
        return None

    after_frame = int(after_frame)
    prefix = f'pose.bones["{bone_name}"].'
    best = None

    for prop in (
        "location",
        "scale",
        "rotation_euler",
        "rotation_quaternion",
        "rotation_axis_angle"
    ):
        for fc in _fcurves_find_all(action, prefix + prop):
            for kp in fc.keyframe_points:
                try:
                    fr = int(round(float(kp.co.x)))
                except Exception:
                    continue

                if fr <= after_frame:
                    continue

                if best is None or fr < best:
                    best = fr

    return int(best) if best is not None else None

def _unparent_next_start_after(action, bone_name, start_frame):
    if not action:
        return None

    s = int(start_frame)
    pts = _unparent_points(action, bone_name)
    if not pts:
        return None

    state = False
    inside = False

    for fr, v in pts:
        fr = int(fr)
        new_state = float(v) >= 0.5

        if fr <= s:
            state = new_state
            continue

        if inside:
            if new_state and not state:
                return int(fr)
        else:
            if state:
                inside = True

        state = new_state

    return None

def _unparent_allow_settle(action, bone_name, frame):
    nxt = _unparent_next_start_after(action, bone_name, int(frame))
    if nxt is None:
        return True
    return int(frame + 1) < int(nxt)

def _unparent_insert_hold_keys(context, arm, action, bone_name, frame, world_m, snap_pose, allow_next = True):
    scn = context.scene

    try:
        arm_inv = arm.matrix_world.inverted()
    except Exception:
        arm_inv = Matrix.Identity(4)

    f0 = int(frame)
    f1 = int(f0 + 1)

    do_f1 = bool(allow_next)
    if do_f1 and action:
        do_f1 = _unparent_allow_settle(action, bone_name, int(f0))
    if int(f1) > int(scn.frame_end):
        do_f1 = False

    scn.frame_set(int(f0))
    context.view_layer.update()

    pb0 = arm.pose.bones.get(bone_name)
    if pb0 and world_m is not None:
        try:
            pb0.matrix = arm_inv @ world_m
        except Exception:
            pass
        context.view_layer.update()
        _insert_bone_keys(pb0, int(f0))

        _set_pose_keys_vector_handles_new_only(action, bone_name, int(f0), snap_pose)

    if do_f1:
        scn.frame_set(int(f1))
        context.view_layer.update()

        pb1 = arm.pose.bones.get(bone_name)
        if pb1 and world_m is not None:
            try:
                pb1.matrix = arm_inv @ world_m
            except Exception:
                pass
            context.view_layer.update()
            _insert_bone_keys(pb1, int(f1))
            _set_pose_keys_vector_handles_new_only(action, bone_name, int(f1), snap_pose)

    lock_frames = {int(f0)}
    if do_f1:
        lock_frames.add(int(f1))

    for lf in sorted(lock_frames):
        _lock_pose_key_handles(action, bone_name, int(lf))

def _unparent_bake_to_end_target(context, action, bone_name, current_frame):
    scn = context.scene
    f_end = int(scn.frame_end)

    nxt_t = _unparent_next_transform_keyframe(action, bone_name, int(current_frame))
    nxt_s = _unparent_find_next_start_frame_from_points(action, bone_name, int(current_frame))

    targets = [f_end]
    if nxt_t is not None:
        targets.append(int(nxt_t))

    if nxt_s is not None:
        targets.append(int(nxt_s) - 1)

    return min(targets)

def _unparent_dp(bone_name):
    return f'pose.bones["{bone_name}"]["{UNP_PROP}"]'

def _pose_dp(bone_name, prop):
    return f'pose.bones["{bone_name}"].{prop}'

def _pb_prop_get(pb, key, default_value = 0.0):
    try:
        return float(pb.get(key, default_value))
    except Exception:
        return float(default_value)

def _pb_prop_set(pb, key, value):
    try:
        pb[key] = float(value)
    except Exception:
        pass

def _unparent_eval(action, bone_name, frame, pb_default = 0.0):
    if not action:
        return float(pb_default)

    dp = _unparent_dp(bone_name)
    fcs = _fcurves_find_all(action, dp)
    if not fcs:
        return float(pb_default)

    f = int(frame)
    v_best = None

    for fc in fcs:
        last_x = None
        last_v = None

        for kp in fc.keyframe_points:
            try:
                x = int(round(float(kp.co.x)))
                y = float(kp.co.y)
            except Exception:
                continue

            if x > f:
                continue

            if last_x is None or x > int(last_x):
                last_x = int(x)
                last_v = float(y)

        v = 0.0 if last_v is None else float(last_v)

        if v_best is None or float(v) > float(v_best):
            v_best = float(v)

    if v_best is None:
        return float(pb_default)
    return 1.0 if float(v_best) >= 0.5 else 0.0

def _unparent_remove_pose_keys_at(action, bone_name, frame):
    if not action:
        return

    for dp in (
        _pose_dp(bone_name, "location"),
        _pose_dp(bone_name, "scale"),
        _pose_dp(bone_name, "rotation_euler"),
        _pose_dp(bone_name, "rotation_quaternion"),
        _pose_dp(bone_name, "rotation_axis_angle")
    ):
        _fcurve_remove_key_all(action, dp, int(frame))

def _arm_pose_mtx_eval(context, arm, bone_name):
    depsgraph = context.evaluated_depsgraph_get()
    eval_arm = arm.evaluated_get(depsgraph)
    pb_eval = eval_arm.pose.bones.get(bone_name)
    if not pb_eval:
        return None
    try:
        return pb_eval.matrix.copy()
    except Exception:
        return None

def _insert_bone_keys(pb, frame, visual = True):
    frame = int(frame)
    opts = {"INSERTKEY_VISUAL"} if visual else set()

    pb.keyframe_insert(data_path = "location", frame = frame, options = opts)

    if pb.rotation_mode == "QUATERNION":
        pb.keyframe_insert(data_path = "rotation_quaternion", frame = frame, options = opts)
    elif pb.rotation_mode == "AXIS_ANGLE":
        pb.keyframe_insert(data_path = "rotation_axis_angle", frame = frame, options = opts)
    else:
        pb.keyframe_insert(data_path = "rotation_euler", frame = frame, options = opts)

    pb.keyframe_insert(data_path = "scale", frame = frame, options = opts)
    _set_keyframe_handles_auto(pb, frame)


def _rel_saved_parent(pb):
    b = pb.bone
    if REL_K_PARENT not in b:
        b[REL_K_PARENT] = pb.parent.name if pb.parent else ""
        try:
            b[REL_K_CONNECT] = 1 if bool(b.use_connect) else 0
        except Exception:
            b[REL_K_CONNECT] = 0
    return str(b.get(REL_K_PARENT, ""))

def _unparent_ensure_visual_constraint(arm, pb):
    c = pb.constraints.get(UNP_VIS_CONSTRAINT)
    if c and c.type != "LIMIT_LOCATION":
        try:
            pb.constraints.remove(c)
        except Exception:
            pass
        c = None

    if not c:
        c = pb.constraints.new("LIMIT_LOCATION")
        c.name = UNP_VIS_CONSTRAINT

    try:
        c.owner_space = "WORLD"
    except Exception:
        pass

    try:
        c.use_min_x = False
        c.use_min_y = False
        c.use_min_z = False
        c.use_max_x = False
        c.use_max_y = False
        c.use_max_z = False
    except Exception:
        pass

    try:
        c.mute = False
    except Exception:
        pass

    try:
        c.influence = 1.0
    except Exception:
        pass

    return c

def _unparent_remove_visual_constraint(pb):
    c = pb.constraints.get(UNP_VIS_CONSTRAINT)
    if not c:
        return
    try:
        pb.constraints.remove(c)
    except Exception:
        pass

def _safe_mode_set(mode):
    try:
        bpy.ops.object.mode_set(mode = mode)
        return True
    except Exception:
        return False


def _capture_relation_selection_state(arm):
    selected_names = tuple(
        pose_bone.name
        for pose_bone in arm.pose.bones
        if _pose_bone_selected(pose_bone)
    )
    active = getattr(arm.data.bones, "active", None)
    visibility = {}
    for bone_name in selected_names:
        data_bone = arm.data.bones.get(bone_name)
        if data_bone is None:
            continue
        visibility[bone_name] = (
            bool(getattr(data_bone, "hide", False)),
            bool(getattr(data_bone, "hide_select", False)),
            bool(getattr(arm.pose.bones.get(bone_name), "hide", False)),
            tuple(
                (collection, bool(getattr(collection, "is_visible", True)))
                for collection in getattr(data_bone, "collections", ())
            ),
        )
    return {
        "selected": selected_names,
        "active": active.name if active is not None else "",
        "visibility": visibility,
    }


def _restore_relation_selection_state(arm, state):
    selected_names = tuple(state.get("selected", ()))
    selected_set = set(selected_names)
    for pose_bone in arm.pose.bones:
        selected = pose_bone.name in selected_set
        data_bone = pose_bone.bone
        for owner in (pose_bone, data_bone):
            if hasattr(owner, "select"):
                try:
                    owner.select = selected
                except (AttributeError, ReferenceError, RuntimeError):
                    pass
        for attribute in ("select_head", "select_tail"):
            if hasattr(data_bone, attribute):
                try:
                    setattr(data_bone, attribute, selected)
                except (AttributeError, ReferenceError, RuntimeError):
                    pass

    for bone_name, (hidden, hide_select, pose_hidden, collections) in state.get(
        "visibility", {}
    ).items():
        data_bone = arm.data.bones.get(bone_name)
        if data_bone is None:
            continue
        if hasattr(data_bone, "hide"):
            data_bone.hide = hidden
        if hasattr(data_bone, "hide_select"):
            data_bone.hide_select = hide_select
        pose_bone = arm.pose.bones.get(bone_name)
        if pose_bone is not None and hasattr(pose_bone, "hide"):
            pose_bone.hide = pose_hidden
        for collection, was_visible in collections:
            if hasattr(collection, "is_visible"):
                collection.is_visible = was_visible

    active_name = str(state.get("active", ""))
    active_bone = arm.data.bones.get(active_name) if active_name else None
    if active_bone is None and selected_names:
        active_bone = arm.data.bones.get(selected_names[0])
    if active_bone is not None:
        arm.data.bones.active = active_bone

def _unparent_apply_relation(context, arm, bone_name, detach):
    if not arm or arm.type != "ARMATURE":
        return False

    saved_active = context.view_layer.objects.active
    saved_mode = bpy.context.mode
    selection_state = _capture_relation_selection_state(arm)

    try:
        try:
            context.view_layer.objects.active = arm
        except Exception:
            pass

        if not _safe_mode_set("EDIT"):
            return False

        eb = arm.data.edit_bones.get(bone_name)
        if not eb:
            return False

        b = arm.data.bones.get(bone_name)
        if not b:
            return False

        if detach:
            eb.parent = None
            try:
                eb.use_connect = False
            except Exception:
                pass
            return True

        parent_name = str(b.get(REL_K_PARENT, ""))
        try:
            connect_val = bool(int(b.get(REL_K_CONNECT, 0)))
        except Exception:
            connect_val = False

        if parent_name:
            eb.parent = arm.data.edit_bones.get(parent_name)
        else:
            eb.parent = None

        try:
            eb.use_connect = bool(connect_val)
        except Exception:
            pass

        return True

    except Exception:
        return False

    finally:
        try:
            if saved_mode.startswith("POSE"):
                _safe_mode_set("POSE")
                _restore_relation_selection_state(arm, selection_state)
            else:
                _safe_mode_set("OBJECT")
        except Exception:
            pass

        try:
            if saved_active:
                context.view_layer.objects.active = saved_active
        except Exception:
            pass


def _unparent_rel_set_cached(arm_name, bone_name, detached):
    _state["unparent_rel_cache"][f"{arm_name}::{bone_name}"] = bool(detached)

def _unparent_relation_is_detached(pb):
    if pb is None:
        return False
    saved_parent_name = str(pb.bone.get(REL_K_PARENT, ""))
    return bool(saved_parent_name and pb.parent is None)

def _unparent_switch_preserve_pose(context, arm, pb, detach):
    action = arm.animation_data.action if arm.animation_data else None
    object_keys_before = _snapshot_object_keys_all(action)
    previous_autokey = _autokey_push(context)
    try:
        bone_name = pb.name
        pose_m = _arm_pose_mtx_eval(context, arm, bone_name)
        if pose_m is None:
            return False

        _rel_saved_parent(pb)
        _unparent_ensure_visual_constraint(arm, pb)

        if not _unparent_apply_relation(context, arm, bone_name, detach):
            return False

        context.view_layer.update()

        current_pb = arm.pose.bones.get(bone_name)
        if current_pb is None:
            return False
        try:
            current_pb.matrix = pose_m
        except Exception:
            return False

        context.view_layer.update()
        return _unparent_relation_is_detached(current_pb) == bool(detach)
    finally:
        current_action = arm.animation_data.action if arm.animation_data else None
        _cleanup_new_object_keys_all(current_action, object_keys_before)
        _autokey_pop(context, previous_autokey)

def _capture_pose_matrices(context, arm, bone_name, frames):
    scn = context.scene
    saved_frame = int(scn.frame_current)
    mats = {}

    try:
        for f in sorted({int(x) for x in frames}):
            scn.frame_set(int(f))
            context.view_layer.update()

            depsgraph = context.evaluated_depsgraph_get()
            eval_arm = arm.evaluated_get(depsgraph)
            pb_eval = eval_arm.pose.bones.get(bone_name)
            if not pb_eval:
                continue

            mats[int(f)] = (eval_arm.matrix_world @ pb_eval.matrix).copy()

    finally:
        scn.frame_set(saved_frame)
        context.view_layer.update()

    return mats

def _unparent_start_frame(pb):
    try:
        v = pb.bone.get(UNP_STATE_KEY, None)
    except Exception:
        v = None
    if v is None:
        return None
    try:
        return int(v)
    except Exception:
        return None

def _unparent_clear_start_frame(pb):
    try:
        if UNP_STATE_KEY in pb.bone:
            del pb.bone[UNP_STATE_KEY]
    except Exception:
        pass

def _unparent_is_active_at(context, arm, pb, frame):
    action = arm.animation_data.action if arm.animation_data else None
    if not action:
        return False
    v = _unparent_eval(action, pb.name, int(frame), pb_default = 0.0)
    return float(v) >= 0.5

def _unparent_points(action, bone_name):
    if not action:
        return []

    dp = _unparent_dp(bone_name)
    merged = {}

    for fc in _fcurves_find_all(action, dp):
        for kp in fc.keyframe_points:
            try:
                fr = int(round(float(kp.co.x)))
                v = float(kp.co.y)
            except Exception:
                continue

            merged.setdefault(fr, []).append(float(v))

    out = []
    for fr, values in merged.items():
        has_end = any(value < 0.5 for value in values)
        has_start = any(value >= 0.5 for value in values)
        value = (
            UNP_SPLIT_VALUE
            if has_end and has_start
            else max(values)
        )
        out.append((int(fr), float(value)))
    out.sort(key = lambda x: int(x[0]))
    return out


def _unparent_run_curve_at(action, bone_name, frame):
    for curve in _fcurves_find_all(action, _unparent_dp(bone_name)):
        points = sorted(
            (float(point.co[0]), float(point.co[1]))
            for point in curve.keyframe_points
        )
        previous = next(
            (point for point in reversed(points) if point[0] <= float(frame) + 1.0e-4),
            None,
        )
        if previous is not None and previous[1] >= 0.5:
            return curve
    return None

def _unparent_find_active_start_frame(action, bone_name, frame):
    if not action:
        return None

    f = int(frame)
    pts = _unparent_points(action, bone_name)
    if not pts:
        return None

    state = False
    last_start = None

    for fr, v in pts:
        if fr > f:
            break


        new_state = float(v) >= 0.5
        if new_state and (not state or float(v) >= UNP_SPLIT_VALUE - 0.5):
            last_start = int(fr)

        state = new_state

    return int(last_start) if state and last_start is not None else None

def _unparent_find_end_frame(action, bone_name, start_frame):
    if not action:
        return None

    s = int(start_frame)
    pts = _unparent_points(action, bone_name)
    if not pts:
        return None

    for fr, v in pts:
        if int(fr) <= s:
            continue
        if float(v) < 0.5 or float(v) >= UNP_SPLIT_VALUE - 0.5:
            return int(fr)

    return None

def _unparent_find_start_frame_fallback(action, bone_name):
    if not action:
        return None

    pts = _unparent_points(action, bone_name)
    if not pts:
        return None

    for fr, v in pts:
        if float(v) >= 0.5:
            return int(fr)

    return None

def _unparent_find_next_start_frame_from_points(action, bone_name, frame):
    if not action:
        return None

    f = int(frame)
    pts = _unparent_points(action, bone_name)
    if not pts:
        return None

    state = False

    for fr, v in pts:
        if int(fr) <= f:
            state = float(v) >= 0.5
            continue

        new_state = float(v) >= 0.5
        if new_state and (not state or float(v) >= UNP_SPLIT_VALUE - 0.5):
            return int(fr)

        state = new_state

    return None

def _unparent_remove_window_keys_only(action, bone_name, start_f, end_f):
    if not action:
        return

    s = int(start_f)
    e = int(end_f)

    if e < s:
        s, e = e, s

    dp = _unparent_dp(bone_name)

    for fc in list(_fcurves_find_all(action, dp)):
        idxs = []

        try:
            kps = fc.keyframe_points
        except Exception:
            continue

        for i in range(len(kps)):
            try:
                fr = int(round(float(kps[i].co.x)))
            except Exception:
                continue

            if fr < s or fr > e:
                continue

            idxs.append(i)

        if not idxs:
            continue

        for i in reversed(idxs):
            try:
                fc.keyframe_points.remove(fc.keyframe_points[i])
            except RuntimeError:
                pass
            except Exception:
                pass

        try:
            if not fc.keyframe_points:
                try:
                    _action_remove_fcurve(action, fc)
                except Exception:
                    pass
            else:
                try:
                    fc.update()
                except Exception:
                    pass
        except Exception:
            pass
