"""Keep native poses independent from Ragdoll channel lifetime."""

from ..core.runtime import *  # noqa: F403


def _ragdoll_separate_pose_channels(armature, bone):
    action = _dynamic_parent_owner_action(armature)
    paths = {bone.path_from_id(path) for path in (
        "location", "scale", "rotation_quaternion", "rotation_euler", "rotation_axis_angle")}
    changed = False
    curves = [curve for groups in _action_group_owners(action, armature)
              if (group := groups.get(f"Ragdoll ({bone.name})")) is not None
              for curve in tuple(group.channels)]
    for curve in curves:
        if (curve.data_path in paths and curve.group is not None
                and curve.group.name == f"Ragdoll ({bone.name})"):
            changed = _set_fcurve_group(curve, action, bone.name) or changed
    return changed


def _ragdoll_rebase_deleted_spaces(context, armature, bone, first_frame, defaults):
    """Recapture generated Unparent starts without the deleted simulation.

    Only the boundary is sampled. The resulting world anchor remains fixed;
    scrubbing and subsequent parent edits never recalibrate it. No pose keys
    are inserted, and independently animated/edited helpers are preserved.
    """
    candidates=[]
    for constraint in _internal_space_constraints(bone):
        start,_end=_dynamic_parent_constraint_segment(bone,constraint)
        helper=_dynamic_parent_constraint_target(bone,constraint)
        if (start is None or start<first_frame or _dynamic_space_role(bone,constraint)!=SPACE_ROLE_UNPARENT
                or helper is None or not helper.get(SPACE_HELPER_PROPERTY) or helper.animation_data
                or helper.constraints or helper.parent!=armature
                or not _matrices_nearly_equal(constraint.inverse_matrix,Matrix.Identity(4))):continue
        captured=helper.get('_staticaliza_ragdoll_capture')
        if captured is not None and (len(captured)!=16 or not _matrices_nearly_equal(
                helper.matrix_basis,_ragdoll_native_matrix(captured),1.e-5)):continue
        candidates.append((int(start),constraint,helper))
    if not candidates:return False
    previous_native=_state.get('ragdoll_native_evaluating',False)
    previous_control=_state.get('ragdoll_native_control_sampling',False)
    previous_capture=_state.get('ragdoll_native_capture_before')
    _state['ragdoll_native_evaluating']=True
    _state['ragdoll_native_control_sampling']=True
    changed=False
    try:
        for frame,constraint,helper in sorted(candidates,key=lambda entry:entry[0]):
            _state['ragdoll_native_capture_before']={(armature.name_full,bone.name):frame}
            active=tuple(_ragdoll_active_bones_hierarchy_order(armature,frame))
            driver=(active[0] if any(_ragdoll_parent(armature,b)==active[0] for b in active[1:])
                    else _ragdoll_parent(armature,active[0])) if active else None
            plan=_ragdoll_native_plan(armature,driver,frame,False) if driver is not None else None
            if plan is not None:
                fps=context.scene.render.fps/max(1.e-6,context.scene.render.fps_base)
                output=_ragdoll_native_replay(plan,fps)
                state=output.get(bone.name,{}).get(frame)
                if state is None:continue
                world=Matrix.LocRotScale(Vector(state['anchor']),Quaternion(state['orientation']),Vector((1,1,1)))
            else:
                motion=_ragdoll_native_authored_motion(armature,bone.name,(frame,))
                if motion is None:continue
                world=motion[frame]
            channels=_surface_contact_release_channels(bone,frame,tuple(_action_fcurves(_ragdoll_action(armature),armature)),
                                                       bone.path_from_id()+'.',defaults=defaults)
            input_matrix=bone.bone.matrix_local@channels
            factor=armature.matrix_world.inverted_safe()@world@input_matrix.inverted_safe()
            helper.matrix_basis=factor@constraint.inverse_matrix.inverted_safe()
            helper['_staticaliza_ragdoll_capture']=[v for row in helper.matrix_basis for v in row]
            changed=True
        return changed
    finally:
        _state['ragdoll_native_evaluating']=previous_native
        _state['ragdoll_native_control_sampling']=previous_control
        if previous_capture is None:_state.pop('ragdoll_native_capture_before',None)
        else:_state['ragdoll_native_capture_before']=previous_capture


def _ragdoll_release_deleted_marker(context, armature, bone):
    """Remove simulation state without authoring an ordinary transform key."""
    frame = context.scene.frame_current_final
    key = _ragdoll_state_key(armature, bone)
    # Physics writes unkeyed channels too. Replaying only the Action leaves
    # those components at the last simulated output after the marker is gone.
    # The first Start owns the original defaults; later Split snapshots can
    # contain simulated channels and must not become ordinary pose defaults.
    starts=_ragdoll_start_poses(bone)
    first=min(starts,key=lambda at:float(at)) if starts else None
    source=dict(starts[first].get('channel_source',{})) if first is not None else {}
    previous = _state.get("ragdoll_syncing", False)
    _state["ragdoll_syncing"] = True
    try:
        _ragdoll_native_cancel_job()
        for name in ('ragdoll_marker_curve_indexes','ragdoll_evaluation_curves',
                     'ragdoll_native_channel_indexes','special_event_reads'):
            if (read_scope:=_state.get(name)) is not None:read_scope.clear()
        if not source and first is not None:
            _ragdoll_apply_stored_start_pose(bone,float(first),connected=True)
            source={name:tuple(getattr(bone,name)) for name in _RAGDOLL_TRANSFORM_SUFFIXES}
        # A delayed transform confirmation must not author a pose after its
        # Ragdoll feature has been deleted in the meantime.
        for name in ('ragdoll_driver_modal_sessions','ragdoll_modal_preview_inputs','ragdoll_driver_preview_signatures'):
            values=_state.get(name,{})
            for identity in tuple(values):
                if identity[:2]==key:values.pop(identity,None)
        previews=_state.get('ragdoll_live_preview_states',{})
        for identity,entry in tuple(previews.items()):
            if identity==key or entry[0][:2]==key:previews.pop(identity,None)
        active=tuple(b for b in _ragdoll_active_bones_hierarchy_order(armature,int(frame)) if b!=bone)
        held={_ragdoll_state_key(armature,b):dict(state) for b in active
              if (state:=_state.get('ragdoll_states',{}).get(_ragdoll_state_key(armature,b))) is not None
              and int(state.get('frame',-1))==int(frame)}
        published={identity:value for identity,value in _state.get('ragdoll_published_poses',{}).items() if identity in held}
        # Removing one collider changes every coupled body, including siblings
        # of an unparented limb. Retain only the current display snapshot while
        # a new native generation is prepared, never its old frame history.
        _ragdoll_invalidate_bones((bone,*active))
        _state.setdefault('ragdoll_states',{}).update(held)
        _state.setdefault('ragdoll_published_poses',{}).update(published)
        _state.setdefault("ragdoll_marker_signatures", {}).pop(key, None)
        pending = _state.get("ragdoll_pending_resimulation")
        if pending and pending.get("armature") in (armature.name, armature.name_full):
            _state["ragdoll_pending_resimulation"] = None
        for prop in (RAGDOLL_ENABLED_PROPERTY, _RAGDOLL_BASELINE_KEYS_PROPERTY,
                     _RAGDOLL_AUTHORED_FRAMES_PROPERTY, _RAGDOLL_START_POSES_PROPERTY,
                     CONSTRAINT_END_KEYS_PROPERTY, "_constraint_release_inputs",
                     "_staticaliza_handoff_sources"):
            if prop in bone:
                del bone[prop]
        # Deletion/Clear relinquishes the simulated output immediately. Restore
        # captured defaults, then evaluate remaining ordinary channels at this
        # exact time. Parent/Unparent and pin constraints keep their own inputs.
        # Explicit End alone requests an editable release key.
        for name,values in source.items():
            if name in _RAGDOLL_TRANSFORM_SUFFIXES:setattr(bone,name,values)
        prefix=bone.path_from_id()+'.'
        for curve in _action_fcurves(_ragdoll_action(armature),armature):
            name=curve.data_path.removeprefix(prefix)
            if (curve.data_path!=prefix+name or name not in _RAGDOLL_TRANSFORM_SUFFIXES
                    or curve.mute or not (curve.keyframe_points or curve.modifiers)):continue
            values=getattr(bone,name)
            if 0<=curve.array_index<len(values):values[curve.array_index]=float(curve.evaluate(frame))
        if first is not None:
            _ragdoll_rebase_deleted_spaces(context,armature,bone,float(first),source)
        armature.update_tag(refresh={'DATA'})
    finally:
        _state["ragdoll_syncing"] = previous
    _ragdoll_sync_transform_locks(context.scene)

