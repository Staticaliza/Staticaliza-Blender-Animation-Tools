"""Dynamic Parent operators, menus, and class registration."""

from ..core.runtime import *  # noqa: F403


def _shortcut_camera_keyframe_target(context, attached_camera):
    """Return a camera only when Keyframe View belongs in the shortcut menu."""
    selected_pose_bones = (
        tuple(_selected_pose_bones_only(context))
        if context.mode == "POSE"
        else ()
    )
    if selected_pose_bones:
        return attached_camera
    return _standalone_camera(context)


def _shortcut_has_actions(context):
    """Keep Ctrl+F completely silent when no listed action is available."""
    advanced_mode = bool(getattr(
        context.window_manager, "roblox_compat_advanced_mode", False,
    ))
    parent_target = _dynamic_parent_target(context)
    parent_visible = bool(
        _dynamic_parent_can_create(context)
        or _dynamic_parent_can_end(context)
        or _dynamic_parent_active_selection(context)
        or (advanced_mode and _dynamic_parent_has_data(parent_target))
    )
    unparent_state = _dynamic_unparent_ui_state(context)
    unparent_visible = bool(
        _dynamic_unparent_can_split(context)
        or any(unparent_state[:3])
        or (advanced_mode and unparent_state[3])
    )
    contact_state = _surface_contact_ui_state(context)
    contact_visible = bool(
        _surface_contact_can_split(context) or any(contact_state[:3])
    )
    ragdoll_selected, ragdoll_active, ragdoll_has_data = (
        _ragdoll_ui_state(context)
    )
    ragdoll_visible = bool(
        _ragdoll_can_split(context)
        or ragdoll_selected
        or ragdoll_active
        or ragdoll_has_data
    )
    camera_bones = _camera_panel_bones(context)
    _armature, _bone, attached_camera = _selected_camera_bone(context)
    camera_visible = bool(
        camera_bones
        or (
            _selected_pose_bones_only(context)
            and _shortcut_camera_keyframe_target(context, attached_camera)
            is not None
        )
    )
    return bool(
        parent_visible or unparent_visible or contact_visible
        or ragdoll_visible or camera_visible
    )


class DYNAMIC_PARENT_OT_menu(bpy.types.Operator):
    bl_idname = "dynamic_parent.menu"
    bl_label = "Animation Tools"
    bl_description = (
        "Open Animation Tools for Dynamic Parent, Dynamic Unparent, "
        "Surface Contact, and cameras"
    )
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def execute(self, context):
        if not _shortcut_has_actions(context):
            return {"CANCELLED"}
        bpy.ops.wm.call_menu(name = "DYNAMIC_PARENT_MT_hotkey_menu")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)

class DYNAMIC_PARENT_MT_hotkey_menu(bpy.types.Menu):
    bl_label = "Animation Tools"
    bl_idname = "DYNAMIC_PARENT_MT_hotkey_menu"

    def draw(self, context):
        layout = self.layout
        advanced_mode = getattr(
            context.window_manager,
            "roblox_compat_advanced_mode",
            False,
        )

        parent_target = _dynamic_parent_target(context)
        parent_can_create = _dynamic_parent_can_create(context)
        parent_can_end = _dynamic_parent_can_end(context)
        parent_can_split = _dynamic_parent_can_split(context)
        parent_has_active = bool(_dynamic_parent_active_selection(context))
        parent_has_data = _dynamic_parent_has_data(parent_target)
        parent_visible = bool(
            parent_can_create
            or parent_can_end
            or parent_has_active
            or parent_has_data
        )
        if parent_visible:
            layout.label(text = "Dynamic Parent")
            if parent_can_split:
                layout.operator(
                    "dynamic_parent.disable",
                    text = "Keyframe Split",
                    icon = "DUPLICATE",
                )
            elif parent_can_create:
                layout.operator(
                    "dynamic_parent.create",
                    text = "Key Start",
                    icon = "KEY_HLT",
                )
            if parent_can_end and not parent_can_split:
                layout.operator(
                    "dynamic_parent.disable",
                    text = "Key End",
                    icon = "KEY_DEHLT",
                )
            if parent_has_active:
                layout.operator(
                    "dynamic_parent.clear",
                    text = "Clear",
                    icon = "X",
                )
            if advanced_mode and parent_has_data:
                layout.operator(
                    "dynamic_parent.bake",
                    text = "Bake",
                    icon = "REC",
                )
            layout.separator()

        can_start, can_end, can_clear, can_bake = _dynamic_unparent_ui_state(context)
        can_split = _dynamic_unparent_can_split(context)
        unparent_visible = bool(
            can_split or can_start or can_end or can_clear
            or (advanced_mode and can_bake)
        )

        if unparent_visible:
            layout.label(text = "Dynamic Unparent")
        if can_split:
            split_operator = layout.operator(
                "staticaliza.unparent_action",
                text = "Keyframe Split",
                icon = "DUPLICATE",
            )
            split_operator.action = "END"
        else:
            if can_start:
                start_operator = layout.operator(
                    "staticaliza.unparent_action",
                    text = "Key Start",
                    icon = "KEY_HLT",
                )
                start_operator.action = "START"
            if can_end:
                end_operator = layout.operator(
                    "staticaliza.unparent_action",
                    text = "Key End",
                    icon = "KEY_DEHLT",
                )
                end_operator.action = "END"

        if can_clear:
            clear_row = layout.row()
            clear_operator = clear_row.operator(
                "staticaliza.unparent_action",
                text = "Clear",
                icon = "X",
            )
            clear_operator.action = "CLEAR"

        if advanced_mode and can_bake:
            bake_row = layout.row()
            bake_operator = bake_row.operator(
                "staticaliza.unparent_action",
                text = "Bake",
                icon = "REC",
            )
            bake_operator.action = "BAKE_TO_ENDING"

        can_contact, can_release, can_contact_clear, _contact_status = (
            _surface_contact_ui_state(context)
        )
        can_contact_split = _surface_contact_can_split(context)
        contact_visible = bool(
            can_contact_split or can_contact or can_release or can_contact_clear
        )
        if contact_visible:
            layout.separator()
            layout.label(text = "Surface Contact")
        if can_contact_split:
            layout.operator(
                "staticaliza.surface_contact_create",
                text = "Keyframe Split",
                icon = "DUPLICATE",
            )
        else:
            if can_contact:
                layout.operator(
                    "staticaliza.surface_contact_create",
                    text = "Key Start",
                    icon = "KEY_HLT",
                )
            if can_release:
                layout.operator(
                    "staticaliza.surface_contact_release",
                    text = "Key End",
                    icon = "KEY_DEHLT",
                )
        if can_contact_clear:
            selected_contact_count = len(
                _surface_contact_selected_guides(
                    context,
                    active_only = True,
                )
            )
            contact_pivot = layout.row()
            contact_pivot.operator_context = "INVOKE_DEFAULT"
            contact_pivot.operator(
                "staticaliza.surface_contact_pivot",
                text = (
                    "Pivot Pin" if selected_contact_count == 1
                    else "Pivot Pins"
                ),
                icon = "PIVOT_CURSOR",
            )
            contact_clear = layout.row()
            contact_clear.operator(
                "staticaliza.surface_contact_clear",
                text = "Clear",
                icon = "X",
            )
        if advanced_mode and contact_visible:
            layout.prop(
                context.window_manager,
                "staticaliza_surface_contact_mode",
                text = "Surface",
            )

        ragdoll_selected, ragdoll_active, ragdoll_has_data = (
            _ragdoll_ui_state(context)
        )
        ragdoll_can_split = _ragdoll_can_split(context)
        ragdoll_visible = bool(
            ragdoll_can_split or ragdoll_selected
            or ragdoll_active or ragdoll_has_data
        )
        if ragdoll_visible:
            layout.separator()
            layout.label(text="Ragdoll")
        if ragdoll_can_split:
            ragdoll_split = layout.operator(
                "staticaliza.ragdoll_action",
                text="Keyframe Split",
                icon="DUPLICATE",
            )
            ragdoll_split.action = "SPLIT"
        else:
            if ragdoll_selected and not ragdoll_active:
                ragdoll_start = layout.operator(
                    "staticaliza.ragdoll_action",
                    text="Key Start",
                    icon="KEY_HLT",
                )
                ragdoll_start.action = "START"
            if ragdoll_active:
                ragdoll_end = layout.operator(
                    "staticaliza.ragdoll_action",
                    text="Key End",
                    icon="KEY_DEHLT",
                )
                ragdoll_end.action = "END"
        if ragdoll_has_data:
            ragdoll_clear = layout.operator(
                "staticaliza.ragdoll_action",
                text="Clear",
                icon="X",
            )
            ragdoll_clear.action = "CLEAR"

        _camera_armature, _camera_bone, attached_camera = _selected_camera_bone(
            context
        )
        camera_bones = _camera_panel_bones(context)
        keyframe_target = _shortcut_camera_keyframe_target(
            context,
            attached_camera,
        )
        camera_visible = bool(
            camera_bones
            or (_selected_pose_bones_only(context) and keyframe_target is not None)
        )
        if camera_visible:
            layout.separator()
            layout.label(text = "Camera")
        if camera_bones:
            camera_toggle = layout.column(align = True)
            camera_toggle.operator_context = "INVOKE_DEFAULT"
            camera_toggle.operator(
                "staticaliza.add_bone_camera",
                text = _selected_camera_button_text(context),
                icon = (
                    "TRASH"
                    if _selected_camera_batch_removes(context)
                    else "CAMERA_DATA"
                ),
            )
        if (
            camera_visible
            and
            getattr(context.area, "type", "") == "VIEW_3D"
            and keyframe_target is not None
        ):
            camera_keyframe = layout.column(align = True)
            camera_keyframe.operator(
                "staticaliza.keyframe_camera_view",
                text = "Keyframe View",
                icon = "KEY_HLT",
            )

def _dynamic_parent_pose_operation_begin(context, armature):
    action = armature.animation_data.action if armature.animation_data else None
    state = {
        "frame": int(context.scene.frame_current),
        "handler_mute": bool(_state.get("unparent_handler_mute", False)),
        "autokey": _autokey_push(context),
        "object_keys": _snapshot_object_keys_all(action),
    }
    if not state["handler_mute"]:
        _unparent_frame_change_post(context.scene, None)
    _state["unparent_handler_mute"] = True
    return state


def _dynamic_parent_pose_operation_end(context, armature, state):
    try:
        if int(context.scene.frame_current) != int(state["frame"]):
            context.scene.frame_set(int(state["frame"]))
        context.view_layer.update()
    finally:
        _state["unparent_handler_mute"] = bool(state["handler_mute"])
        if not state["handler_mute"]:
            _unparent_frame_change_post(context.scene, None)
        action = armature.animation_data.action if armature.animation_data else None
        _cleanup_new_object_keys_all(action, state["object_keys"])
        _autokey_pop(context, state["autokey"])
        _yellow_refresh_runtime(context)




class DYNAMIC_PARENT_OT_create(bpy.types.Operator):
    bl_idname = "dynamic_parent.create"
    bl_label = "Keyframe Start"
    bl_description = (
        "Parent the later-selected child bones to the first-selected bone "
        "at the current frame"
    )
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _dynamic_parent_can_create(context)

    def execute(self, context):
        obj = context.active_object
        frame = context.scene.frame_current
        operation_state = None
        pose_plan = ()
        pose_parent_bone = None

        if obj.type == "ARMATURE":
            if obj.mode != "POSE":
                self.report({"ERROR"}, "Armature objects must be in Pose mode.")
                return {"CANCELLED"}
            pose_plan, target_error = _dynamic_parent_pose_create_plan(
                context,
                obj,
            )
            if target_error:
                self.report({"ERROR"}, target_error)
                return {"CANCELLED"}
            if pose_plan and pose_plan[0][1] == obj:
                pose_parent_bone = obj.pose.bones.get(pose_plan[0][2])
            operation_state = _dynamic_parent_pose_operation_begin(context, obj)

        created_count = 0
        skipped_count = 0
        try:
            if obj.type == "ARMATURE":
                for pose_bone, pose_parent_target, pose_parent_subtarget in pose_plan:
                    if not _dynamic_parent_child_can_create(pose_bone, int(frame)):
                        skipped_count += 1
                        continue
                    created_constraint = _create_pose_dynamic_parent(
                        context,
                        obj,
                        pose_bone,
                        pose_parent_target,
                        pose_parent_subtarget,
                        int(frame),
                    )
                    if created_constraint is None:
                        skipped_count += 1
                        continue
                    created_count += 1
                if not created_count:
                    self.report(
                        {"ERROR"},
                        "Selected children already have Dynamic Parent segments.",
                    )
                    return {"CANCELLED"}
            else:
                dynamic_target = _dynamic_parent_target(context)
                if _dynamic_parent_has_marker_at(dynamic_target, int(frame)):
                    self.report(
                        {"ERROR"},
                        "A Dynamic Parent marker already exists on this frame.",
                    )
                    return {"CANCELLED"}
                const = get_last_dynamic_parent_constraint(obj)
                if const:
                    disable_constraint(obj, const, frame)
                dp_create_dynamic_parent_obj(self)
        finally:
            if operation_state is not None:
                _dynamic_parent_pose_operation_end(context, obj, operation_state)

        # Keep the complete authored selection visible in the viewport and in
        # Dope Sheet editors using Only Show Selected. The dual-selection
        # transform synchronizer already prevents children from receiving the
        # parent's motion twice.
        if obj.type == "ARMATURE" and pose_parent_bone is not None:
            parent_bone = obj.pose.bones.get(pose_parent_bone.name)
            parent_data_bone = obj.data.bones.get(pose_parent_bone.name)
            if parent_bone is not None and parent_data_bone is not None:
                obj.data.bones.active = parent_data_bone
                _tag_redraw_all_view3d()

        if skipped_count:
            self.report(
                {"WARNING"},
                f"Created {created_count}; skipped {skipped_count} already-parented child bone(s).",
            )

        return {"FINISHED"}

class DYNAMIC_PARENT_OT_disable(bpy.types.Operator):
    bl_idname = "dynamic_parent.disable"
    bl_label = "Keyframe End"
    bl_description = "End the active Dynamic Parent segment at the current frame"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _dynamic_parent_can_end(context)

    def execute(self, context):
        frame = context.scene.frame_current
        dynamic_target = _dynamic_parent_target(context)
        if _dynamic_parent_has_marker_at(dynamic_target, int(frame)):
            self.report(
                {"ERROR"},
                "A Dynamic Parent marker already exists on this frame.",
            )
            return {"CANCELLED"}
        armature = context.active_object if context.mode == "POSE" else None
        operation_state = (
            _dynamic_parent_pose_operation_begin(context, armature)
            if armature is not None and armature.type == "ARMATURE"
            else None
        )
        objects = get_selected_objects(context)
        counter = 0

        try:
            if not objects:
                self.report({"ERROR"}, "Nothing selected.")
                return {"CANCELLED"}

            for obj in objects:
                const = get_last_dynamic_parent_constraint(obj)
                if const is None:
                    continue
                if armature is not None and isinstance(obj, bpy.types.PoseBone):
                    if not _end_pose_dynamic_parent(
                        context,
                        armature,
                        obj,
                        const,
                        int(frame),
                    ):
                        continue
                else:
                    disable_constraint(obj, const, frame)
                counter += 1
        finally:
            if operation_state is not None:
                _dynamic_parent_pose_operation_end(context, armature, operation_state)

        self.report({"INFO"}, f"{counter} constraints were disabled.")
        return {"FINISHED"}

class DYNAMIC_PARENT_OT_clear(bpy.types.Operator):
    bl_idname = "dynamic_parent.clear"
    bl_label = "Clear Dynamic Parent"
    bl_description = "Remove the active Dynamic Parent segment without baking it"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return bool(_dynamic_parent_active_clear_targets(context))

    def execute(self, context):
        obj = context.active_object
        if obj is None:
            return {"CANCELLED"}
        if obj.type != "ARMATURE" or context.mode != "POSE":
            return {"FINISHED"} if dp_clear(obj, None) else {"CANCELLED"}

        clear_targets = _dynamic_parent_active_clear_targets(context)
        if not clear_targets:
            return {"CANCELLED"}
        cleared = 0
        by_owner = {}
        for owner, pose_bone in clear_targets:
            by_owner.setdefault(owner, []).append(pose_bone.name)
        for owner, bone_names in by_owner.items():
            operation_state = _dynamic_parent_pose_operation_begin(
                context, owner
            )
            try:
                for bone_name in bone_names:
                    pose_bone = owner.pose.bones.get(bone_name)
                    if pose_bone is not None and dp_clear(owner, pose_bone):
                        cleared += 1
            finally:
                _dynamic_parent_pose_operation_end(
                    context, owner, operation_state
                )
        _yellow_refresh_runtime(context)
        self.report({"INFO"}, f"Cleared {cleared} Dynamic Parent segment(s).")
        return {"FINISHED"} if cleared else {"CANCELLED"}

class DYNAMIC_PARENT_OT_bake(bpy.types.Operator):
    bl_idname = "dynamic_parent.bake"
    bl_label = "Bake Dynamic Parent"
    bl_description = (
        "Bake Dynamic Parent motion to keyframes and remove its constraints"
    )
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return _dynamic_parent_has_data(_dynamic_parent_target(context))

    def execute(self, context):
        obj = bpy.context.active_object
        scn = bpy.context.scene

        if obj.type == "ARMATURE":
            obj = bpy.context.active_pose_bone
            bpy.ops.nla.bake(
                frame_start = scn.frame_start,
                frame_end = scn.frame_end,
                step = 1,
                only_selected = True,
                visual_keying = True,
                clear_constraints = False,
                clear_parents = False,
                bake_types = {"POSE"},
            )
            for const in obj.constraints[:]:
                if const.name.startswith("DP_"):
                    _remove_dynamic_parent_constraint_metadata(obj, const)
                    obj.constraints.remove(const)
        else:
            bpy.ops.nla.bake(
                frame_start = scn.frame_start,
                frame_end = scn.frame_end,
                step = 1,
                only_selected = True,
                visual_keying = True,
                clear_constraints = False,
                clear_parents = False,
                bake_types = {"OBJECT"},
            )
            for const in obj.constraints[:]:
                if const.name.startswith("DP_"):
                    _remove_dynamic_parent_constraint_metadata(obj, const)
                    obj.constraints.remove(const)

        return {"FINISHED"}

class DYNAMIC_PARENT_OT_clear_material_links(bpy.types.Operator):
    bl_idname = "dynamic_parent.clear_material_links"
    bl_label = "Clear Material Links"
    bl_description = "Disconnect Base Color and Alpha links for all materials in the current file"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        removed = dp_clear_material_links()

        if removed:
            self.report({"INFO"}, f"Removed {removed} Base Color/Alpha link(s).")
        else:
            self.report({"INFO"}, "No Base Color or Alpha links were connected.")

        return {"FINISHED"}

class DYNAMIC_PARENT_MT_clear_menu(bpy.types.Menu):
    bl_label = "Clear Dynamic Parent?"
    bl_idname = "DYNAMIC_PARENT_MT_clear_menu"

    def draw(self, context):
        layout = self.layout
        layout.operator("dynamic_parent.clear", text = "Clear", icon = "X")
        layout.operator("dynamic_parent.bake", text = "Bake and clear", icon = "REC")
