"""Native joint replay for connected limbs driven by one animated parent.

The disposable physics scene never becomes the visible scene. Preview and
confirmed playback use identical collision bodies, joints and time samples.
Completed caches contain only math values. During playback, one owned generator
keeps its private scene between timer slices; save/history/load/teardown close it.
"""
from ..core.runtime import *  # noqa: F403


def _ragdoll_native_socket_damping(retention, gravity, length, points=None, center=None):
    """Damp a geometry-derived physical pendulum, independent of bone names.

    Approximate COM inertia with the collision bounds, then apply the
    parallel-axis theorem about the socket. Compact parts must not inherit
    the fourfold end-pivot compensation of a thin rod.
    """
    retention = min(1.0, max(1e-6, float(retention)))
    strength = math.log(retention) / math.log(.97)
    radius = max(1e-5, length * .5)
    inertia = max(1e-10, length * length / 12.0)
    if points and center is not None:
        dims = [max(p[i] for p in points)-min(p[i] for p in points) for i in range(3)]
        diagonal = Vector(((dims[1]**2+dims[2]**2)/12.0,
                           (dims[0]**2+dims[2]**2)/12.0,
                           (dims[0]**2+dims[1]**2)/12.0))
        radius = center.length
        radial = center.normalized() if radius > 1e-8 else Vector((0,1,0))
        # Mean inertia of the two swing axes perpendicular to the COM lever.
        inertia = max(1e-10, .5 * sum(diagonal[i]*(1-radial[i]**2) for i in range(3)))
    socket_inertia = inertia + radius*radius
    frequency = math.sqrt(gravity.length * radius / socket_inertia)
    rate = strength * (-24.0 * math.log(.97) + .15 * frequency)
    return 1.0 - math.exp(-min(14.0, socket_inertia/inertia * rate))


def _ragdoll_native_matrix(values):
    return Matrix(tuple(tuple(values[r * 4 + c] for c in range(4)) for r in range(4)))


def _ragdoll_native_authored_motion(owner, bone_name, frames):
    preview = _state.get('ragdoll_native_controller_preview')
    action = _ragdoll_action(owner)
    trial = None
    try:
        curves = None
        if preview and preview[0] == owner.name_full and action is not None:
            trial = action.copy()
            curves = {(c.data_path, c.array_index): c for c in _action_fcurves(trial, owner)}
            slot = int(owner.animation_data.action_slot_handle)
            bags = [b for b in _action_channelbags(trial) if b.slot_handle == slot]
            collection = bags[0].fcurves if bags else trial.fcurves
            edited = owner.pose.bones[preview[1]]
            rotation = 'rotation_quaternion' if edited.rotation_mode == 'QUATERNION' else 'rotation_axis_angle' if edited.rotation_mode == 'AXIS_ANGLE' else 'rotation_euler'
            for channel in ('location', rotation, 'scale'):
                path = edited.path_from_id() + '.' + channel
                for index, value in enumerate(getattr(edited, channel)):
                    curve = curves.get((path, index))
                    if curve is None:
                        curve = collection.new(path, index=index)
                        curves[(path, index)] = curve
                    exists = any(abs(p.co.x-preview[2]) < 1e-5 for p in curve.keyframe_points)
                    point = curve.keyframe_points.insert(preview[2], value, options={'FAST'})
                    if not exists:
                        point.handle_left_type = point.handle_right_type = 'AUTO_CLAMPED'
                    curve.update()
        return _ragdoll_native_authored_motion_impl(owner, bone_name, frames, curves)
    finally:
        if trial is not None:
            bpy.data.actions.remove(trial)


def _ragdoll_native_authored_motion_impl(owner, bone_name, frames, curves=None):
    """Sample an ordinary controller chain without changing the visible frame.

    Constraints/drivers/NLA require evaluated-scene sampling and are deliberately
    not guessed here. Blender's conversion preserves inherit-scale semantics.
    """
    from mathutils import Euler
    animation = owner.animation_data
    if owner.parent or owner.constraints or (animation and
            (animation.drivers or any(t.strips for t in animation.nla_tracks))):
        return None
    bone = owner.pose.bones.get(bone_name) if owner.type == 'ARMATURE' else None
    if bone_name and bone is None:
        return None
    chain = list(reversed(bone.parent_recursive)) + [bone] if bone else []
    if any(b.constraints or _ragdoll_curves(owner, b) for b in chain):
        return None
    if curves is None:
        curves = {(c.data_path, c.array_index): c for c in
                  _action_fcurves(animation.action, owner)} if animation and animation.action else {}
    def basis(item, prefix, frame):
        mode = item.rotation_mode
        rotation = 'rotation_quaternion' if mode == 'QUATERNION' else 'rotation_axis_angle' if mode == 'AXIS_ANGLE' else 'rotation_euler'
        values = {}
        for channel in ('location', rotation, 'scale'):
            values[channel] = [float(curves[(prefix+channel, i)].evaluate(frame))
                if (prefix+channel, i) in curves else float(v)
                for i, v in enumerate(getattr(item, channel))]
        angles = values[rotation]
        q = (Quaternion(angles) if mode == 'QUATERNION' else
             Quaternion(Vector(angles[1:]), angles[0]) if mode == 'AXIS_ANGLE' else
             Euler(angles, mode).to_quaternion())
        q.normalize()
        return Matrix.LocRotScale(Vector(values['location']), q, Vector(values['scale']))
    # Static object delta transforms are retained. Animated deltas are outside
    # this sampler's contract; accepting them would silently lose motion.
    if any(path.startswith('delta_') for path, _ in curves):
        return None
    factor = owner.matrix_world @ basis(owner, '', bpy.context.scene.frame_current).inverted_safe()
    output = {}
    for frame in frames:
        world = factor @ basis(owner, '', frame)
        pose = None
        for item in chain:
            kwargs = dict(parent_matrix=pose, parent_matrix_local=item.parent.bone.matrix_local) if pose is not None else {}
            pose = item.bone.convert_local_to_pose(basis(item, item.path_from_id()+'.', frame),
                                                   item.bone.matrix_local, **kwargs)
        output[frame] = world @ pose if pose is not None else world
    return output


def _ragdoll_native_grabs(armature, bones, frames):
    result = {}
    for bone in bones:
        grabs = [c for c in bone.constraints if c.name.startswith('DP_')]
        if not grabs:
            continue
        offsets = json.loads(bone.get('_staticaliza_ragdoll_grab_offsets', '{}'))
        rows = {f: (False, ()) for f in frames}
        for constraint in grabs:
            target = _dynamic_parent_constraint_target(bone, constraint)
            subtarget = _dynamic_parent_constraint_subtarget(bone, constraint)
            start, end = _dynamic_parent_constraint_segment(bone, constraint)
            if start is None:
                continue  # A deleted marker is not a persistent grab.
            packed = offsets.get(constraint.name)
            if target is None or target == armature or not packed or len(packed) != 16:
                return None
            motion = _ragdoll_native_authored_motion(target, subtarget, frames)
            if motion is None:
                return None
            offset = _ragdoll_native_matrix(packed)
            for frame in frames:
                if frame >= start and (end is None or frame < end):
                    if rows[frame][0]:
                        return None  # Ambiguous overlapping parents.
                    matrix = motion[frame] @ offset
                    rows[frame] = (True, tuple(v for row in matrix for v in row))
        result['_grab:' + bone.name] = tuple((f, *rows[f]) for f in frames)
    return result


def _ragdoll_native_samples(plan):
    frames, worlds, _specs, statics, _gravity, _release, data = plan
    motions = [dict((f, (on, packed)) for f, on, packed in rows)
               for name, rows in data.items() if name.startswith('_grab:')]
    obstacles = [relative for _, _, relative, _ in statics if isinstance(relative, dict)]
    return tuple((tuple(v for row in worlds[f] for v in row),
                  tuple(m[f] for m in motions),
                  tuple(tuple(v for row in m[f] for v in row) for m in obstacles))
                 for f in frames)


def _ragdoll_native_plan(armature, driver, target, preview):
    scene = bpy.context.scene
    bones = tuple(b for b in _ragdoll_active_bones_hierarchy_order(armature, target) if b != driver)
    if not bones or any(_ragdoll_parent(armature, b) != driver
            or any(not c.name.startswith(('_DynamicSpace_', 'DP_')) for c in b.constraints) for b in bones):
        return None
    animation = armature.animation_data
    if animation is None or animation.action is None or animation.drivers or any(t.strips for t in animation.nla_tracks):
        return None
    # Parent/space constraints and animated ancestors require the general
    # evaluated-scene solver. Do not silently omit their trajectories.
    ancestors = []
    parent = driver
    while parent:
        if parent.constraints:
            return None
        ancestors.append(parent)
        parent = parent.parent
    ancestor_paths = tuple('pose.bones[' + json.dumps(b.name) + '].' for b in ancestors[1:])
    if any((c.data_path.startswith(ancestor_paths) or not c.data_path.startswith('pose.bones[')) and len(c.keyframe_points) > 1
           for c in _action_fcurves(animation.action, armature)):
        return None
    starts = [_ragdoll_active_start_frame(armature, b, target) for b in bones]
    if any(s is None for s in starts) or len(set(starts)) != 1:
        return None
    start = int(round(starts[0]))
    # Retained Pink guides do not disable native replay while Orange owns
    # them. Inspect the whole sampled interval, not only the target frame.
    if any(_surface_contact_guide_active_at(guide, frame)
           and not _surface_contact_ragdoll_override(guide, frame, include_start=True)
           for guide in _surface_contact_guides()
           for frame in range(start, int(target) + 1)):
        return None
    if start < 0:
        return None
    if target <= start:
        return None  # Native G/R/S at Start still owns the initial pose.
    # A root-nearest torso can release after its children have already been
    # simulating. Keep the same joint island and switch only its body mode.
    root_curves = _ragdoll_curves(armature, driver)
    root_keys = sorted({int(round(p.co.x)) for c in root_curves for p in c.keyframe_points})
    releases = [f for f in root_keys if _ragdoll_active(driver, f, curves=root_curves)]
    release = releases[0] if releases else None
    if release is not None:
        if (release < start or not _ragdoll_free(armature, driver, release)
                or any(not _ragdoll_active(driver, f, curves=root_curves) for f in root_keys if f > release)):
            return None
    frames = tuple(range(start, int(target) + 1))
    # A blue key changes joint topology inside the same native replay.
    # Switching solvers at that boundary discarded sibling history.
    joint_schedules = {}
    for bone in bones:
        boundaries = {start}
        boundaries.update(int(round(p.co.x)) for c in _fcurves_find_all(
            animation.action, _unparent_dp(bone.name)) for p in c.keyframe_points
            if p.co.x >= start)
        schedule = tuple((f, not _ragdoll_unparented(armature, bone, f))
                         for f in sorted(boundaries))
        if any(not enabled for _, enabled in schedule):
            joint_schedules['_joint:' + bone.name] = schedule
    accelerations = {b.name: _ragdoll_hinge_gravity(b) for b in (driver, *bones)}
    accelerations.update(joint_schedules)
    grabs = _ragdoll_native_grabs(armature, (driver, *bones), (start-1, *frames))
    if grabs is None:
        return None
    accelerations.update(grabs)
    # Let Bullet apply the common acceleration directly. Only differing
    # weights need residual force constraints; ordinary gravity is not a joint.
    frequencies = {}
    for bone in bones:
        value = tuple(accelerations[bone.name])
        frequencies[value] = frequencies.get(value, 0) + 1
    gravity = Vector(max(frequencies, key=frequencies.get))
    deltas, worlds = _ragdoll_preview_driver_deltas(armature, driver, (start-1, *frames), target, preview=preview and not _state.get('ragdoll_native_controller_preview'), native=True)
    if not worlds:
        return None
    if release is not None and release <= target:
        # Ordinary keys up to release define the incoming trajectory. A saved
        # world matrix must not resurrect a deleted driving key or its velocity.
        released_pose = worlds[release].copy()
        for f in frames:
            if f >= release:
                worlds[f] = released_pose
    initial_scale = worlds[start].to_scale()
    if any((matrix.to_scale() - initial_scale).length > 1e-5 for matrix in worlds.values()):
        return None
    inverse_driver = (armature.matrix_world @ driver.matrix).inverted_safe()
    # Each shape is expressed in its rigid frame. Convex hulls preserve the
    # welded part extents, unlike a point pendulum or an oversized capsule.
    specs = []
    owned_parts = {armature}
    for bone in (driver, *bones):
        _radius, excluded, samples, _normals = _ragdoll_collision_shape(bpy.context, armature, bone, 0.02)
        if len(samples) < 4:
            return None
        owned_parts.update(excluded)
        if bone == driver:
            relative = Matrix.Identity(4)
        else:
            saved = _ragdoll_start_poses(bone).get(str(start), {})
            packed = saved.get('parent_relative_matrix', ())
            if len(packed) == 16:
                relative = _ragdoll_native_matrix(packed)
            elif len(saved.get('matrix', ())) == 16:
                # Managed unparenting removes the edit-bone parent, but the
                # saved Start pose and logical parent still define this socket.
                relative = worlds[start].inverted_safe() @ armature.matrix_world @ _ragdoll_native_matrix(saved['matrix'])
            else:
                return None
        initial = worlds[start] @ relative
        location, rotation, scale = initial.decompose()
        points = tuple(Vector((p.x * scale.x, p.y * scale.y, p.z * scale.z)) for p in samples)
        center = sum(points, Vector()) / len(points)
        rigid = Matrix.LocRotScale(location, rotation, Vector((1, 1, 1)))
        specs.append((bone.name, relative, points, center, rigid,
                      float(bone.get(RAGDOLL_DAMPING_PROPERTY, 0.94)),
                      float(bone.get(RAGDOLL_FRICTION_PROPERTY, 0.35)),
                      float(bone.get(RAGDOLL_BOUNCE_PROPERTY, 0.0)),
                      float(bone.bone.length) * abs(scale.y)))
    statics = []
    depsgraph = bpy.context.evaluated_depsgraph_get()
    for surface in _ragdoll_collision_surfaces(bpy.context, owned_parts):
        attachment = None
        if _ragdoll_self_collision_surface(surface, armature):
            bone_name = surface.parent_bone if surface.parent == armature else ''
            if not bone_name:
                bone_name = next((c.subtarget for c in surface.constraints
                                  if getattr(c, 'target', None) == armature and getattr(c, 'subtarget', '')), '')
            attached = armature.pose.bones.get(bone_name)
            if attached is None:
                return None
            paths = tuple('pose.bones[' + json.dumps(b.name) + '].'
                          for b in (attached, *attached.parent_recursive) if b != driver)
            if any(c.data_path.startswith(paths) and len(c.keyframe_points) > 1
                   for c in _action_fcurves(animation.action, armature)):
                return None
            if attached == driver or _ragdoll_is_ancestor(armature, driver, attached):
                attachment = inverse_driver
        elif surface.animation_data or surface.constraints or surface.parent:
            owner = surface.parent if surface.parent_type == 'BONE' else None
            bone_name = surface.parent_bone if owner else ''
            if owner is None:
                link = next((c for c in surface.constraints if c.type == 'CHILD_OF' and c.target and c.target.type == 'ARMATURE' and c.subtarget), None)
                if link is not None:
                    owner, bone_name = link.target, link.subtarget
            if owner is None or owner == armature:
                return None
            trajectory = _ragdoll_native_authored_motion(owner, bone_name, (start-1, *frames, scene.frame_current))
            if trajectory is None:
                return None
            attachment = trajectory
        evaluated = surface.evaluated_get(depsgraph)
        if len(evaluated.data.vertices) > 4096:
            return None
        matrix = evaluated.matrix_world.copy()
        geometry = (tuple(tuple(v.co) for v in evaluated.data.vertices),
                    tuple(tuple(p.vertices) for p in evaluated.data.polygons))
        if isinstance(attachment, dict):
            offset = attachment[scene.frame_current].inverted_safe() @ matrix
            relative = {f: m @ offset for f, m in attachment.items()}
        else:
            relative = attachment @ matrix if attachment is not None else None
        statics.append((surface, matrix, relative, geometry))
    return frames, worlds, specs, statics, gravity, release, accelerations


def _ragdoll_native_buffered_hull(points, socket=None):
    """Round sharp collision corners, retaining broad blocking faces.

    A bounded plain-data cache avoids rebuilding identical convex proxies on
    every scrub. No Blender IDs or BMesh references survive this function.
    """
    coordinates = tuple(tuple(float(v) for v in p) for p in points)
    key = (coordinates, tuple(socket) if socket is not None else None)
    if len(coordinates) < 8:
        return coordinates
    cache = _state.setdefault("ragdoll_rounded_hulls", {})
    if key in cache:
        return cache[key]
    import bmesh
    bm = bmesh.new()
    try:
        for point in coordinates:
            bm.verts.new(point)
        bmesh.ops.convex_hull(bm, input=list(bm.verts), use_existing_faces=False)
        unused = [v for v in bm.verts if not v.link_faces]
        if unused:
            bmesh.ops.delete(bm, geom=unused, context='VERTS')
        bm.normal_update()
        bmesh.ops.dissolve_limit(bm, angle_limit=.001,
            verts=list(bm.verts), edges=list(bm.edges), use_dissolve_boundaries=False)
        bm.normal_update()
        edges = [e for e in bm.edges if e.is_manifold and e.calc_face_angle() > math.radians(35)]
        width = min(max(p[i] for p in coordinates)-min(p[i] for p in coordinates) for i in range(3))
        if edges and width > 1e-6:
            bmesh.ops.bevel(bm, geom=edges, offset=.3*width,
                segments=3, profile=.5, affect='EDGES', clamp_overlap=True)
        result = tuple(tuple(v.co) for v in bm.verts)
        if socket is not None:
            pivot = Vector(socket)
            lever = -pivot
            radius = lever.length
            extents = [max(p[i] for p in coordinates)-min(p[i] for p in coordinates) for i in range(3)]
            compactness = max(0.0, min(1.0, (2.0 - max(extents)/max(1e-6, width)) / .5))
            band = min(radius, .75 * width)
            if band > 1e-6:
                axis = lever / radius
                buffered = []
                for values in result:
                    point = Vector(values)
                    relative = point - pivot
                    axial = relative.dot(axis)
                    # A local collar provides rotational clearance around
                    # the attachment, while leaving the distal core intact.
                    fraction = max(0.0, min(1.0, axial / band))
                    radial = relative - axis * axial
                    point = pivot + axis * axial + radial * (1.0 - .75*compactness*(1.0-fraction))
                    buffered.append(tuple(point))
                result = tuple(buffered)
    finally:
        bm.free()
    if len(cache) >= 64:
        cache.pop(next(iter(cache)))
    cache[key] = result
    return result


def _ragdoll_native_body(scene, name, points, matrix, dynamic, objects, meshes, socket=None):
    mesh = bpy.data.meshes.new('_UtilsJointShape')
    meshes.append(mesh)
    mesh.from_pydata(_ragdoll_native_buffered_hull(points, socket), [], [])
    prototype = next((o for o in objects if o.rigid_body
                      and o.rigid_body.type == ('ACTIVE' if dynamic else 'PASSIVE')), None)
    if prototype is None:
        obj = bpy.data.objects.new(name, mesh)
    else:
        # Copy configured native body data within this disposable solve.
        # Avoid one operator/depsgraph rebuild per limb; retain no RNA pool
        # across user events or undo transactions.
        obj = prototype.copy()
        obj.name = name
        obj.data = mesh
        obj.animation_data_clear()
    objects.append(obj)
    scene.collection.objects.link(obj)
    obj.matrix_world = matrix
    if prototype is None:
        with bpy.context.temp_override(scene=scene, view_layer=scene.view_layers[0],
                                       object=obj, active_object=obj,
                                       selected_objects=[obj], selected_editable_objects=[obj]):
            bpy.ops.rigidbody.object_add('EXEC_DEFAULT', False, type='ACTIVE' if dynamic else 'PASSIVE')
    else:
        if obj.name not in scene.rigidbody_world.collection.objects:
            scene.rigidbody_world.collection.objects.link(obj)
        obj.rigid_body.kinematic = False
    obj.rigid_body.mesh_source = 'BASE'
    obj.rigid_body.collision_shape = 'CONVEX_HULL'
    obj.rigid_body.use_margin = True
    obj.rigid_body.collision_margin = 0.001
    obj.rigid_body.use_deactivation = False
    return obj


def _ragdoll_native_motion(obj, frames, matrices, actions):
    # Collapse only exactly constant spans; changing samples retain their
    # original interpolation. Long holds need two keys, not seven per frame.
    if len(frames) > 2:
        keep = [0]
        for index in range(1, len(frames)-1):
            if matrices[index] != matrices[index-1] or matrices[index] != matrices[index+1]:
                keep.append(index)
        keep.append(len(frames)-1)
        frames = tuple(frames[i] for i in keep)
        matrices = tuple(matrices[i] for i in keep)
    obj.rotation_mode = 'QUATERNION'
    obj.keyframe_insert('location', frame=frames[0])
    obj.keyframe_insert('rotation_quaternion', frame=frames[0])
    action = obj.animation_data.action
    actions.append(action)
    positions, rotations = [], []
    previous = None
    for matrix in matrices:
        positions.append(tuple(matrix.translation))
        rotation = matrix.to_quaternion()
        if previous is not None and rotation.dot(previous) < 0:
            rotation.negate()
        rotations.append(tuple(rotation))
        previous = rotation
    for curve in _action_fcurves(action, obj):
        values = positions if curve.data_path == 'location' else rotations
        curve.keyframe_points.add(len(frames) - 1)
        curve.keyframe_points.foreach_set('co', [v for f, row in zip(frames, values) for v in (f, row[curve.array_index])])
        linear = bpy.types.Keyframe.bl_rna.properties['interpolation'].enum_items['LINEAR'].value
        curve.keyframe_points.foreach_set('interpolation', [linear] * len(frames))
        curve.update()


def _ragdoll_native_gravity_motor(scene, anchor, body, acceleration, objects):
    """Constant COM force using Bullet's unlocked linear motor row.

    Blender names the cap max_impulse, but its Bullet adapter supplies a
    force; Bullet multiplies by the substep dt. A saturated target velocity
    therefore supplies F=m*a without changing mass or constraining rotation.
    The static first body keeps the force axis fixed in world coordinates.
    """
    prototype = next((obj for obj in objects if obj.rigid_body_constraint
                      and obj.rigid_body_constraint.type == 'MOTOR'), None)
    motor = prototype.copy() if prototype else bpy.data.objects.new('_UtilsGravityForce', None)
    objects.append(motor)
    scene.collection.objects.link(motor)
    axis = acceleration.normalized() if acceleration.length > 1e-12 else Vector((0, 0, -1))
    rotation = Vector((1, 0, 0)).rotation_difference(axis)
    motor.matrix_world = Matrix.LocRotScale(body.matrix_world.translation,
                                          rotation, Vector((1, 1, 1)))
    if prototype is None:
        with bpy.context.temp_override(scene=scene, view_layer=scene.view_layers[0],
                                       object=motor, active_object=motor,
                                       selected_objects=[motor], selected_editable_objects=[motor]):
            bpy.ops.rigidbody.constraint_add('EXEC_DEFAULT', False)
    elif motor.name not in scene.rigidbody_world.constraints.objects:
        scene.rigidbody_world.constraints.objects.link(motor)
    constraint = motor.rigid_body_constraint
    constraint.type = 'MOTOR'
    constraint.object1, constraint.object2 = anchor, body
    constraint.use_motor_lin = True
    constraint.use_motor_ang = False
    constraint.motor_lin_target_velocity = -1000000.0
    constraint.motor_lin_max_impulse = 0.0  # Start priming has no acceleration.
    return constraint, body.rigid_body.mass * acceleration.length


def _ragdoll_native_replay(plan, fps, *, endpoints_only=False):
    steps = _ragdoll_native_replay_steps(plan, fps, endpoints_only=endpoints_only)
    while True:
        try:
            next(steps)
        except StopIteration as finished:
            return finished.value


def _ragdoll_native_replay_steps(plan, fps, *, endpoints_only=False):
    frames, worlds, specs, statics, gravity, release, accelerations = plan
    scene = bpy.data.scenes.new('_UtilsJointReplay')
    scene['_staticaliza_physics_scratch'] = True
    # Blender clamps the rigid-body cache start to frame 1 and initializes
    # joints on the following step. Private frame 2 primes the incoming pose;
    # authored Start is frame 3, still kinematic, to establish its velocity.
    # Dynamic simulation begins on the next interval.
    frame_offset = 3 - frames[0]
    motion_frames = (frames[0]-1, *frames)
    grabs = {name[6:]: {f: (on, packed) for f, on, packed in rows}
             for name, rows in accelerations.items() if name.startswith('_grab:')}
    substeps = max(2, math.ceil(240.0/fps))

    def private_frame(frame):
        return frame + frame_offset

    scene.frame_current = 1
    objects, meshes, actions = [], [], []
    collections = []
    output = {spec[0]: {} for spec in (specs if release is not None else specs[1:])}
    try:
        scene.render.fps = max(1, round(fps))
        scene.render.fps_base = scene.render.fps / fps
        scene.gravity = (0.0, 0.0, 0.0)
        parent_spec = specs[0]
        center = parent_spec[3]
        driver = _ragdoll_native_body(scene, '_UtilsDriver',
            [p - center for p in parent_spec[2]],
            Matrix.LocRotScale(worlds[frames[0]-1].translation, worlds[frames[0]-1].to_quaternion(), Vector((1,1,1))) @ Matrix.Translation(center), True, objects, meshes)
        driver.rigid_body.mass = 2.0
        driver.rigid_body.friction = max(0.0, min(1.0, parent_spec[6]))
        driver.rigid_body.restitution = max(0.0, min(1.0, parent_spec[7]))
        driver.rigid_body.linear_damping = driver.rigid_body.angular_damping = 1.0-min(.999,max(0.0,parent_spec[5]))**24.0
        driver.rigid_body.kinematic = True
        _ragdoll_native_motion(driver, tuple(private_frame(f) for f in motion_frames),
            [Matrix.LocRotScale(worlds[f].translation, worlds[f].to_quaternion(), Vector((1,1,1))) @ Matrix.Translation(center) for f in motion_frames], actions)
        bodies = []
        if release is not None:
            # Preserve the authored Start pose through its exact frame. The
            # following interval is dynamic, with all limb joints still live.
            driver.rigid_body.kinematic = True
            driver.keyframe_insert('rigid_body.kinematic', frame=frames[0]+frame_offset)
            driver.keyframe_insert('rigid_body.kinematic', frame=release+frame_offset)
            driver.rigid_body.kinematic = False
            driver.keyframe_insert('rigid_body.kinematic', frame=release+frame_offset+1)
            for curve in _action_fcurves(driver.animation_data.action, driver):
                if curve.data_path == 'rigid_body.kinematic':
                    for point in curve.keyframe_points:point.interpolation = 'CONSTANT'
            bodies.append((parent_spec[0], driver, center, Matrix.Identity(4), parent_spec[8]))
        joint_prototype = None
        for name, relative, points, center, rigid, damping, friction, bounce, length in specs[1:]:
            incoming = worlds[frames[0]-1] @ relative
            incoming = Matrix.LocRotScale(incoming.translation, incoming.to_quaternion(), Vector((1,1,1)))
            body = _ragdoll_native_body(scene, '_UtilsLimb', [p-center for p in points],
                                      incoming @ Matrix.Translation(center), True, objects, meshes, socket=-center)
            grab_rows = accelerations.get('_grab:' + name, ())
            grab_map = grabs.get(name, {})
            body_frames = (frames[0]-1, frames[0]) if not grab_rows else motion_frames
            body_matrices = []
            for f in body_frames:
                on, packed = grab_map.get(f, (False, ()))
                pose = _ragdoll_native_matrix(packed) if on else (incoming if f < frames[0] else rigid)
                body_matrices.append(pose @ Matrix.Translation(center))
            _ragdoll_native_motion(body, tuple(private_frame(f) for f in body_frames), body_matrices, actions)
            body.rigid_body.kinematic = True
            body.keyframe_insert('rigid_body.kinematic', frame=2)
            body.keyframe_insert('rigid_body.kinematic', frame=3)
            body.rigid_body.kinematic = False
            body.keyframe_insert('rigid_body.kinematic', frame=4)
            for f, on, _packed in grab_rows:
                if f > frames[0]:
                    body.rigid_body.kinematic = on
                    body.keyframe_insert('rigid_body.kinematic', frame=private_frame(f))
            for curve in _action_fcurves(body.animation_data.action, body):
                if curve.data_path == 'rigid_body.kinematic':
                    for point in curve.keyframe_points:
                        point.interpolation = 'CONSTANT'
            body.rigid_body.mass = 1.0
            body.rigid_body.friction = max(0.0, min(1.0, friction))
            body.rigid_body.restitution = max(0.0, min(1.0, bounce))
            # A connected limb damps its swing, not its absolute world travel.
            # Linear drag on every child created socket torque proportional to
            # torso speed even at constant velocity, and braked released rigs.
            # The free driver owns translational drag for the connected island.
            body.rigid_body.linear_damping = 0.0
            body.rigid_body.angular_damping = _ragdoll_native_socket_damping(
                damping, accelerations[name], length, points, center)
            joint = joint_prototype.copy() if joint_prototype else bpy.data.objects.new('_UtilsSocket', None)
            joint.animation_data_clear()
            objects.append(joint)
            scene.collection.objects.link(joint)
            joint.matrix_world = incoming
            if joint_prototype is None:
                with bpy.context.temp_override(scene=scene, view_layer=scene.view_layers[0],
                                               object=joint, active_object=joint,
                                               selected_objects=[joint], selected_editable_objects=[joint]):
                    bpy.ops.rigidbody.constraint_add('EXEC_DEFAULT', False)
                joint_prototype = joint
            else:
                if joint.name not in scene.rigidbody_world.constraints.objects:
                    scene.rigidbody_world.constraints.objects.link(joint)
            constraint = joint.rigid_body_constraint
            # Socket anchoring must not suppress physical contact between
            # connected shapes. All parts use the same free ball joint and
            # convex-hull contact solve, without anatomical name exceptions.
            constraint.enabled = True
            constraint.type = 'POINT'
            constraint.object1, constraint.object2 = driver, body
            constraint.disable_collisions = False
            constraint.use_override_solver_iterations = True
            constraint.solver_iterations = 8
            schedule = accelerations.get('_joint:' + name, ())
            previous_enabled = None
            for f, enabled in schedule:
                if enabled != previous_enabled:
                    constraint.enabled = enabled
                    joint.keyframe_insert('rigid_body_constraint.enabled', frame=private_frame(f))
                    previous_enabled = enabled
            if schedule:
                joint_action = joint.animation_data.action
                actions.append(joint_action)
                for curve in _action_fcurves(joint_action, joint):
                    for point in curve.keyframe_points:
                        point.interpolation = 'CONSTANT'
            bodies.append((name, body, center, relative, length))
        gravity_motors = []
        gravity_anchor = None
        for name, body, _center, _relative, _length in bodies:
            residual = accelerations[name] - gravity
            if residual.length_squared < 1e-16:
                continue
            if gravity_anchor is None:
                gravity_anchor = _ragdoll_native_body(scene, '_UtilsGravityAnchor',
                    (Vector((0, 0, 0)), Vector((.01, 0, 0)),
                     Vector((0, .01, 0)), Vector((0, 0, .01))),
                    Matrix.Identity(4), False, objects, meshes)
                gravity_anchor.rigid_body.collision_collections = (False,) * 20
            gravity_motors.append(_ragdoll_native_gravity_motor(
                scene, gravity_anchor, body, residual, objects))
        depsgraph = bpy.context.evaluated_depsgraph_get()
        for surface, matrix, relative, _geometry in statics:
            evaluated = surface.evaluated_get(depsgraph)
            mesh = bpy.data.meshes.new_from_object(evaluated, depsgraph=depsgraph)
            meshes.append(mesh)
            obj = bpy.data.objects.new('_UtilsObstacle', mesh)
            objects.append(obj)
            scene.collection.objects.link(obj)
            obj.matrix_world = matrix
            with bpy.context.temp_override(scene=scene, view_layer=scene.view_layers[0],
                                           object=obj, active_object=obj,
                                           selected_objects=[obj], selected_editable_objects=[obj]):
                bpy.ops.rigidbody.object_add('EXEC_DEFAULT', False, type='ACTIVE' if relative is not None else 'PASSIVE')
            if relative is not None:
                obj.rigid_body.kinematic = True
                _ragdoll_native_motion(obj, tuple(private_frame(f) for f in motion_frames), [relative[f] if isinstance(relative, dict) else worlds[f] @ relative for f in motion_frames], actions)
            obj.rigid_body.collision_shape = 'MESH'
            # An ordinary scene mesh has no authored physics material. Use a
            # neutral friction multiplier, so a limb's .35 means .35 against
            # the floor, not .175 after Bullet multiplies it by Blender's .5.
            # Respect materials on surfaces that do have rigid-body settings.
            material = surface.rigid_body
            obj.rigid_body.friction = material.friction if material else 1.0
            obj.rigid_body.restitution = material.restitution if material else 0.0
            obj.rigid_body.use_margin = True
            obj.rigid_body.collision_margin = .001
        world = scene.rigidbody_world
        collections = [world.collection, world.constraints]
        world.substeps_per_frame = substeps
        # Keep the 240 Hz integration/contact steps; eight sequential-impulse
        # iterations passed socket, contact, high-weight and release checks.
        # See Catto, Solver2D (2024): prioritize small steps over extra passes.
        world.solver_iterations = 8
        world.point_cache.frame_start = 1
        world.point_cache.frame_end = private_frame(frames[-1])
        layer = scene.view_layers[0]
        capture_frames = {frames[0], *frames[-3:]} if endpoints_only else None
        # Private pre-roll gives Bullet the authored incoming linear/angular
        # velocity before kinematic bodies become dynamic at Start + 1.
        scene.frame_set(2)
        yield None
        deadline = time.perf_counter() + .004
        for frame in frames:
            if time.perf_counter() >= deadline:
                yield None
                deadline = time.perf_counter() + .004
            scene.frame_set(private_frame(frame))
            if frame == frames[0]:
                scene.gravity = gravity
                for motor, force in gravity_motors:
                    motor.motor_lin_max_impulse = force
            depsgraph = layer.depsgraph
            # Bullet still solves every timestep/contact. A drag only needs
            # its requested pose and adjacent velocity samples read into RNA.
            if capture_frames is not None and frame not in capture_frames:
                continue
            driver_transform = (driver.evaluated_get(depsgraph).matrix_world
                                @ Matrix.Translation(-parent_spec[3]))
            driver_scale = worlds[frame].to_scale()
            driver_world = Matrix.LocRotScale(driver_transform.translation,
                driver_transform.to_quaternion(), driver_scale)
            # Project residual socket error toward the prescribed grip. The
            # free island moves; the animated hand must not drift off target.
            grip_shift = Vector()
            for name, body, center, relative, length in bodies:
                row = grabs.get(name, {}).get(frame)
                schedule = accelerations.get('_joint:' + name, ())
                attached = not schedule or next(on for f, on in reversed(schedule) if f <= frame)
                if row and row[0] and attached and release is not None and frame >= release:
                    grip_shift = _ragdoll_native_matrix(row[1]).translation - (driver_world @ relative).translation
                    driver_world.translation += grip_shift
                    break
            for name, body, center, relative, length in bodies:
                transform = body.evaluated_get(depsgraph).matrix_world @ Matrix.Translation(-center)
                if body == driver:
                    transform.translation += grip_shift
                if frame == frames[0]:
                    transform = next(spec[4] for spec in specs if spec[0] == name)
                orientation = transform.to_quaternion()
                schedule = accelerations.get('_joint:' + name, ())
                detached = bool(schedule and not next(enabled for f, enabled in reversed(schedule) if f <= frame))
                free = body == driver or detached
                anchor = transform.translation if free else (driver_world @ relative).translation
                position = anchor + orientation @ Vector((0, length, 0))
                previous = output[name].get(frame-1)
                velocity = (position - previous['position']) * fps if previous else Vector()
                output[name][frame] = dict(frame=frame, anchor=anchor.copy(), position=position,
                    previous=previous['position'].copy() if previous else position.copy(),
                    anchor_previous=previous['anchor'].copy() if previous else anchor.copy(),
                    velocity=velocity, orientation=orientation, free=free, seeded=True,
                    anchor_velocity=(anchor-previous['anchor'])*fps if previous else Vector(),
                    contact_normal=None, contact_point=None, native_joint=True,
                    start_authoritative=(frame == frames[0] or (body == driver and frame == release)),
                    joint_error=(transform.translation-anchor).length)
        return output
    finally:
        # Remove all disposable IDs before returning to Blender's undo system.
        if scene.rigidbody_world:
            collections = [scene.rigidbody_world.collection, scene.rigidbody_world.constraints]
        # This scene and every ID below were created locally in this call;
        # none is ever assigned to a window or linked to the user's scene.
        # scenes.remove() invokes editor scene replacement even for a private
        # scene, and crashes when a frame callback has no UI context. Batch
        # deletion releases these owned IDs without that editor operation.
        if any(window.scene == scene for manager in bpy.data.window_managers
               for window in manager.windows):
            raise RuntimeError("Private physics scene unexpectedly attached to a window")
        owned_ids = (scene, *objects, *meshes, *actions,
                     *(collection for collection in collections if collection is not None))
        bpy.data.batch_remove(ids=owned_ids)


@persistent
def _ragdoll_native_cancel_job(*_args):
    _state.pop('ragdoll_native_finishing', None)
    job = _state.pop('ragdoll_native_job', None)
    if job is not None:
        previous = bool(_state.get('ragdoll_syncing'))
        _state['ragdoll_syncing'] = True
        try:
            job['steps'].close()
        finally:
            _state['ragdoll_syncing'] = previous


def _ragdoll_native_should_defer():
    # Editing must publish the current trajectory before returning. Holding an
    # old orientation until a queued replay matches constantly changing input
    # starves live previews and produces a large release pop.
    if (_state.get('ragdoll_driver_modal_sessions')
            or _state.get('ragdoll_key_transform_active')):
        return False
    return (_ragdoll_interactive_replay() and not _state.get('dynamic_space_export_sampling')
            and (_animation_playback_active(bpy.context)
                 or _state.get('ragdoll_native_finishing', False)))


def _ragdoll_native_job_timer():
    job = _state.get('ragdoll_native_job')
    if job is None:
        return None
    if not _ragdoll_native_should_defer():
        if _ragdoll_interactive_replay() and not _state.get('dynamic_space_export_sampling'):
            _state['ragdoll_native_finishing'] = True
        else:
            _ragdoll_native_cancel_job()
            return None
    previous = bool(_state.get('ragdoll_syncing'))
    _state['ragdoll_syncing'] = True
    completed = None
    try:
        next(job['steps'])
    except StopIteration as finished:
        completed = finished.value
        _state.pop('ragdoll_native_job', None)
    except Exception:
        _ragdoll_native_cancel_job()
        raise
    finally:
        _state['ragdoll_syncing'] = previous
    if completed is None:
        return .001  # Return to Blender so Space/Escape and other input can run.
    cached = dict(signature=job['signature'], samples=job['samples'], output=completed)
    solutions = _state.setdefault('ragdoll_native_solutions', {})
    solutions[job['key'] + (job['preview'],)] = cached
    history = solutions.setdefault(job['key'] + ('history',), [])
    history.insert(0, cached)
    del history[4:]
    # Revalidate authored input before publishing; user edits can occur at any yield.
    scene = bpy.context.scene
    if scene.name_full == job['scene']:
        _ragdoll_native_scene(scene)
    if _state.get('ragdoll_native_job') is not None:
        return .001
    _state.pop('ragdoll_native_finishing', None)
    return None


def _ragdoll_native_queue_job(plan, fps, key, signature, samples, *, preview=False):
    existing = _state.get('ragdoll_native_job')
    if existing is not None:
        # Coalesce mouse input. Restarting on every event would starve a solve;
        # completed results are revalidated against the latest authored input.
        return
    _state['ragdoll_native_job'] = dict(key=key, scene=bpy.context.scene.name_full,
        signature=signature, samples=samples, preview=preview,
        steps=_ragdoll_native_replay_steps(plan, fps, endpoints_only=(preview
            or bool(_state.get('ragdoll_native_sparse_replay'))
            or bool(_state.get('ragdoll_key_transform_active'))
            or bool(_state.get('ragdoll_native_finishing')))))
    if not bpy.app.timers.is_registered(_ragdoll_native_job_timer):
        register_owned_timer(_ragdoll_native_job_timer, first_interval=.001)


def _ragdoll_native_equal(left, right):
    """Ignore only matrix-evaluation roundoff, not meaningful input changes."""
    if left == right:
        return True
    stack = [(left, right)]
    while stack:
        a, b = stack.pop()
        if isinstance(a, (tuple, list)):
            if not isinstance(b, (tuple, list)) or len(a) != len(b):
                return False
            stack.extend(zip(a, b))
        elif isinstance(a, float) and isinstance(b, (float, int)):
            if abs(a - b) > 1e-5:
                return False
        elif a != b:
            return False
    return True


def _ragdoll_native_grab_islands(owner, driver, frame):
    if driver is None:
        return ()
    targets = {}
    for rig in bpy.context.scene.objects:
        if rig == owner or rig.type != 'ARMATURE':
            continue
        for bone in _ragdoll_active_bones_hierarchy_order(rig, frame):
            for constraint in bone.constraints:
                if not constraint.name.startswith('DP_') or _dynamic_parent_constraint_target(bone, constraint) != owner:
                    continue
                start, _end = _dynamic_parent_constraint_segment(bone, constraint)
                target = owner.pose.bones.get(_dynamic_parent_constraint_subtarget(bone, constraint))
                if start is None or start > frame or target is None:
                    continue
                if target != driver and driver not in target.parent_recursive:
                    continue
                root = _ragdoll_parent(rig, bone)
                if root is not None:
                    targets[(rig.name_full, root.name)] = (rig, root)
    return tuple(targets.values())


def _ragdoll_native_branch(armature, driver, target, *, preview=False):
    # Input geometry/Action sampling can flush the depsgraph too. Guard the
    # entire transaction, not only Bullet replay and final pose publication.
    # Otherwise an active G transform re-enters preview while planning it.
    previous_syncing = bool(_state.get('ragdoll_syncing'))
    previous_native = bool(_state.get('ragdoll_native_evaluating'))
    _state['ragdoll_native_evaluating'] = True
    _state['ragdoll_syncing'] = True
    own_indexes = 'ragdoll_native_channel_indexes' not in _state
    if own_indexes:
        _state['ragdoll_native_channel_indexes'] = {}
    previous = _state.get('ragdoll_evaluation_curves')
    if previous is None:
        _state['ragdoll_evaluation_curves'] = {}
    previous_controller = _state.get('ragdoll_native_controller_preview')
    try:
        islands = _ragdoll_native_grab_islands(armature, driver, target)
        if islands:
            if preview:
                _state['ragdoll_native_controller_preview'] = (armature.name_full, driver.name, int(target))
            return all(_ragdoll_native_branch_impl(rig, root, target, preview=preview) for rig, root in islands)
        return _ragdoll_native_branch_impl(armature, driver, target, preview=preview)
    finally:
        if previous_controller is None:
            _state.pop('ragdoll_native_controller_preview', None)
        else:
            _state['ragdoll_native_controller_preview'] = previous_controller
        if own_indexes:
            _state.pop('ragdoll_native_channel_indexes', None)
        if previous is None:
            _state.pop('ragdoll_evaluation_curves', None)
        _state['ragdoll_syncing'] = previous_syncing
        _state['ragdoll_native_evaluating'] = previous_native


def _ragdoll_native_branch_impl(armature, driver, target, *, preview=False):
    # There may be a suspended playback/stop replay when an ordinary RNA
    # edit requests an immediate solve (no modal session or key-drag flag).
    # Creating/removing a second scratch world can invalidate the suspended
    # Bullet world's collision state during graph rebuilds. Never keep
    # that world alive across a synchronous replay, including cache hits.
    if (_state.get('ragdoll_native_job')
            and (preview or _state.get('ragdoll_key_transform_active')
                 or not _ragdoll_native_should_defer())):
        _ragdoll_native_cancel_job()
    plan = _ragdoll_native_plan(armature, driver, int(target), preview)
    if plan is None:
        return False
    frames, worlds, specs, statics, gravity, release, accelerations = plan
    fps = bpy.context.scene.render.fps / max(1e-6, bpy.context.scene.render.fps_base)
    endpoints_only = (preview or bool(_state.get('ragdoll_native_sparse_replay'))
                      or bool(_state.get('ragdoll_key_transform_active'))
                      or bool(_state.get('ragdoll_native_finishing')))
    signature = (fps, frames[0], tuple(gravity), release,
        tuple(v for row in worlds[frames[0]-1] for v in row),
        tuple((name, tuple(value)) for name, value in accelerations.items() if not name.startswith('_grab:')),
        tuple((name, tuple(v for row in relative for v in row), tuple(tuple(p) for p in points), damping, friction, bounce, length)
              for name, relative, points, center, rigid, damping, friction, bounce, length in specs),
        tuple((o.name_full, geometry,
               (o.rigid_body.friction, o.rigid_body.restitution) if o.rigid_body else (1.0, 0.0),
               ('animated',) if isinstance(relative, dict) else tuple(v for row in (relative if relative is not None else m) for v in row))
              for o,m,relative,geometry in statics))
    samples = _ragdoll_native_samples(plan)
    key = (armature.name_full, driver.name)
    solutions = _state.setdefault('ragdoll_native_solutions', {})
    history = solutions.setdefault(key + ('history',), [])
    candidates = [solutions.get(key + (preview,)), solutions.get(key + (not preview,)), *history]
    cached = next((candidate for candidate in candidates if candidate
        and len(candidate['samples']) >= len(samples)
        and _ragdoll_native_equal(candidate['samples'][len(samples)-1], samples[-1])
        and _ragdoll_native_equal(candidate['signature'], signature)
        and _ragdoll_native_equal(candidate['samples'][:len(samples)], samples)
        and all(int(target) in states for states in candidate['output'].values())), None)
    if cached is not None:
        output = cached['output']
    else:
        if not endpoints_only:
            horizon = min(int(bpy.context.scene.frame_end), int(target) + max(8, int(fps / 2)))
            if horizon > int(target):
                extended = _ragdoll_native_plan(armature, driver, horizon, False)
                if (extended is not None and extended[0][0] == frames[0]
                        and tuple(spec[0] for spec in extended[2]) == tuple(spec[0] for spec in specs)):
                    plan = extended
                    frames, worlds = plan[:2]
                    samples = _ragdoll_native_samples(plan)
        if _ragdoll_native_should_defer():
            _ragdoll_native_queue_job(plan, fps, key, signature, samples, preview=preview)
            # Keep one coherent completed pose until the exact solve is ready.
            states = _state.get('ragdoll_states', {})
            bones = tuple(b for b in _ragdoll_active_bones_hierarchy_order(armature, target)
                          if _ragdoll_state_key(armature, b) in states)
            if bones:
                if preview:
                    origin = _state.get('ragdoll_native_controller_preview') or (armature.name_full, driver.name, int(target))
                    for bone in bones:
                        state_key = _ragdoll_state_key(armature, bone)
                        held = dict(states[state_key])
                        if not held.get('free'):
                            anchor = _ragdoll_connected_anchor(armature, bone)
                            if anchor is not None:
                                held['position'] = Vector(held['position']) + anchor - Vector(held['anchor'])
                                held['anchor'] = anchor.copy()
                        held['frame'] = int(target)
                        states[state_key] = held
                        _state.setdefault('ragdoll_live_preview_states', {})[state_key] = (origin, held)
                held_frame = states[_ragdoll_state_key(armature, bones[0])]['frame']
                _ragdoll_restore_applied_states(armature, bones, held_frame)
            return True
        syncing = bool(_state.get('ragdoll_syncing'))
        _state['ragdoll_syncing'] = True
        try:
            output = (_ragdoll_native_replay(plan, fps, endpoints_only=True) if endpoints_only
                      else _ragdoll_native_replay(plan, fps))
        finally:
            _state['ragdoll_syncing'] = syncing
        cached = dict(signature=signature, samples=samples, output=output)
        solutions[key + (preview,)] = cached
        if not preview:
            # Bounded plain-math generations survive native undo. Inputs are
            # verified above; no RNA or stale transform preview is retained.
            history.insert(0, cached)
            del history[4:]
    bones = tuple(armature.pose.bones[name] for name in output
                  if _ragdoll_active(armature.pose.bones[name], int(target)))
    for bone in bones:
        state_key = _ragdoll_state_key(armature, bone)
        _state.setdefault('ragdoll_states', {})[state_key] = {k: v.copy() if hasattr(v, 'copy') else v for k,v in output[bone.name][int(target)].items()}
        if preview:
            origin = _state.get('ragdoll_native_controller_preview') or (armature.name_full, driver.name, int(target))
            _state.setdefault('ragdoll_live_preview_states', {})[state_key] = (origin, output[bone.name][int(target)])
        if not preview:
            caches = _state.setdefault('ragdoll_frame_cache', {})
            published = cached.setdefault('published', {})
            # Copy once per generation. Runtime states own their vectors;
            # cached playback must not clone every historical body each tick.
            if caches.get(state_key) is not published.get(bone.name) or int(target) not in caches.get(state_key, {}):
                caches[state_key] = {f: {k: v.copy() if hasattr(v, 'copy') else v for k,v in st.items()} for f,st in output[bone.name].items()}
                published[bone.name] = caches[state_key]
    syncing = bool(_state.get('ragdoll_syncing'))
    _state['ragdoll_syncing'] = True
    try:
        if (_state.get('ragdoll_key_transform_active')
                and not _ragdoll_active(driver, int(target))):
            # Display the same finalized driver trajectory used by Bullet.
            # Otherwise its native temporary-handle pose disagrees with the
            # simulated sockets until the Dope Sheet confirms the transform.
            desired = armature.matrix_world.inverted_safe() @ worlds[int(target)]
            if max(abs(driver.matrix[r][c] - desired[r][c])
                   for r in range(4) for c in range(4)) > 1.e-6:
                driver.matrix = desired
                bpy.context.view_layer.update()
        _ragdoll_restore_applied_states(armature, bones, int(target))
    finally:
        _state['ragdoll_syncing'] = syncing
    if not preview:
        _state.pop('ragdoll_scrub_job', None)
        _state['ragdoll_pending_resimulation'] = None
        _state.setdefault('ragdoll_driver_curve_signatures', {})[(armature.name_full, driver.name)] = _ragdoll_driver_curve_signature(armature, driver)
        _state.setdefault('ragdoll_driver_preview_signatures', {})[
            (armature.name_full, driver.name, int(target))] = _ragdoll_driver_pose_signature(driver, target)
    return True


def _ragdoll_native_scene(scene):
    own_indexes = 'ragdoll_native_channel_indexes' not in _state
    if own_indexes:
        _state['ragdoll_native_channel_indexes'] = {}
    previous = _state.get('ragdoll_evaluation_curves')
    if previous is None:
        _state['ragdoll_evaluation_curves'] = {}
    try:
        return _ragdoll_native_scene_impl(scene)
    finally:
        if own_indexes:
            _state.pop('ragdoll_native_channel_indexes', None)
        if previous is None:
            _state.pop('ragdoll_evaluation_curves', None)


def _ragdoll_native_scene_impl(scene):
    """Handle compatible connected branches before scheduling historical RNA work."""
    targets = []
    frame = int(scene.frame_current)
    for owner in scene.objects:
        if owner.type != 'ARMATURE' or not owner.pose:
            continue
        bones = tuple(_ragdoll_active_bones_hierarchy_order(owner, frame))
        if not bones:
            continue
        parent = bones[0] if any(_ragdoll_parent(owner, b) == bones[0] for b in bones[1:]) else _ragdoll_parent(owner, bones[0])
        if parent is None or any(b != parent and _ragdoll_parent(owner, b) != parent for b in bones):
            return False
        targets.append((owner, parent))
    if not targets:
        return False
    # A pending native transform owns its island through confirmation/cancel.
    # Action/depsgraph echoes must not publish the pre-drag trajectory over it.
    sessions = tuple(session for session in (() if _state.get('ragdoll_baking') else _state.get('ragdoll_driver_modal_sessions', {}).values())
                     if int(session.get('frame', -1)) == frame)
    preview_drivers = {}
    for session in sessions:
        edited_owner = scene.objects.get(session.get('armature', ''))
        if edited_owner is None or edited_owner.type != 'ARMATURE':
            continue
        edited = edited_owner.pose.bones.get(session.get('bone', ''))
        if edited is None:
            continue
        islands = _ragdoll_native_grab_islands(edited_owner, edited, frame)
        for owner, driver in targets:
            if (owner == edited_owner and driver == edited) or (owner, driver) in islands:
                preview_drivers[(owner.name_full, driver.name)] = (edited_owner, edited)
    for owner, driver in targets:
        edited = preview_drivers.get((owner.name_full, driver.name))
        if edited is not None:
            if not _ragdoll_native_branch(*edited, frame, preview=True):
                return False
        elif not _ragdoll_native_branch(owner, driver, frame):
            return False
    _sync_all_dynamic_pose_bone_colors(frame)
    return True
