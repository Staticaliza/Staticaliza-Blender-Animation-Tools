"""Native joint replay for connected limbs driven by one animated parent.

The disposable physics scene never becomes the visible scene. Preview and
confirmed playback use identical collision bodies, joints and time samples.
Completed caches contain only math values. During playback, one owned generator
keeps its private scene between timer slices; save/history/load/teardown close it.
"""
from ..core.runtime import *  # noqa: F403

# Scheduling changes do not invalidate poses made by the identical solver.
_RAGDOLL_NATIVE_REVISION = 389


def _ragdoll_private_scene_evaluation():
    """Let sibling extensions avoid observing a private physics transaction."""
    return bool(_state.get('ragdoll_syncing') or _state.get('ragdoll_native_evaluating'))


def _ragdoll_native_socket_damping(retention, gravity, length, points=None, center=None):
    """Apply spin retention to the total rotational energy about a socket."""
    factor=1.
    if points and center is not None:
        extents=Vector(tuple(max(p[i] for p in points)-min(p[i] for p in points) for i in range(3)))
        # A joint carries both COM spin and orbital COM travel. Bullet damps
        # only the former; the socket transfers the undamped linear component
        # back into swing. The parallel-axis ratio supplies the missing loss,
        # without braking the island's linear momentum through world drag.
        mean_radius_squared=extents.length_squared/12.
        factor+=Vector(center).length_squared/max(mean_radius_squared,1.e-10)
    return 1.0-min(1.0,max(0.0,float(retention)))**(24.*factor)


def _ragdoll_native_matrix(values):
    return Matrix(tuple(tuple(values[r * 4 + c] for c in range(4)) for r in range(4)))


def _ragdoll_native_unhandled_drivers(owner):
    """Managed influence gates do not animate the controller's channels."""
    animation = owner.animation_data
    drivers = tuple(animation.drivers) if animation else ()
    if not drivers:
        return False
    allowed = set()
    for guide in _gyro_guides(bpy.context.scene):
        armature, bone = _gyro_owner(guide)
        if armature != owner or bone is None:
            continue
        for key, target in (("gyro_stable_constraint", "gyro_reference"),
                            ("gyro_aim_constraint", "gyro_aim_output")):
            constraint = bone.constraints.get(str(guide.get(key, "")))
            if (constraint is not None and constraint.type == 'COPY_ROTATION'
                    and constraint.target == guide.get(target)
                    and constraint.owner_space == constraint.target_space == 'WORLD'):
                allowed.add(constraint.path_from_id('influence'))
    return any(curve.data_path not in allowed for curve in drivers)


def _ragdoll_native_contact_motion(owner, bone, motion, frames):
    """Sample direct pink limbs using the same rigid solve as frame playback."""
    guides = tuple(_surface_contact_guides_for_effector(owner, bone))
    if not guides:return motion
    def packed(value):
        if isinstance(value, bpy.types.ID):return (value.name_full,value.as_pointer())
        if hasattr(value,'to_list'):return tuple(value.to_list())
        return str(value)
    sources = []
    for guide in guides:
        part = bpy.data.objects.get(str(guide.get(SURFACE_CONTACT_SMART_OBJECT_PROPERTY,'')))
        if part is not None:
            sources.append(('part',part.name_full,tuple(tuple(row) for row in part.matrix_basis),
                tuple(tuple(c) for c in part.bound_box),tuple((co.name,co.type,
                    tuple(tuple(row) for row in co.inverse_matrix),co.subtarget)
                    for co in part.constraints if co.type=='CHILD_OF')))
        item = guide
        while item is not None:
            if item.parent_type=='BONE' or item.constraints or (item.animation_data and item.animation_data.drivers):
                return None
            curves = _action_fcurves(_ragdoll_action(item),item)
            paths = {(fc.data_path,fc.array_index) for fc in curves}
            sources.append((item.name_full,item.rotation_mode,tuple(v for row in item.matrix_parent_inverse for v in row),
                tuple((p,tuple(None if (p,i) in paths else float(v) for i,v in enumerate(getattr(item,p))))
                      for p in ('location','rotation_quaternion','rotation_euler','rotation_axis_angle','scale')),
                tuple((fc.data_path,fc.array_index,fc.mute,fc.extrapolation,_ragdoll_modifier_signature(fc),
                    tuple((tuple(p.co),tuple(p.handle_left),tuple(p.handle_right),p.interpolation,p.easing,
                           p.back,p.amplitude,p.period) for p in fc.keyframe_points)) for fc in curves)))
            item = item.parent
    signature = (tuple(sources),tuple((g.name,tuple(sorted((k,packed(v)) for k,v in g.items()))) for g in guides),
                 _state.get('ragdoll_native_kinematic_samples',{}).get((owner.name_full,bone.name),(None,))[0],
                 tuple((b.name,tuple(tuple(row) for row in b.bone.matrix_local)) for b in owner.pose.bones),
                 tuple((fc.data_path,fc.array_index,tuple((tuple(p.co),tuple(p.handle_left),tuple(p.handle_right),
                     p.interpolation,p.easing) for p in fc.keyframe_points)) for fc in _action_fcurves(_ragdoll_action(owner),owner)))
    bank = _state.setdefault('ragdoll_native_contact_samples',{})
    key = (owner.name_full,bone.name)
    entry = bank.get(key)
    if entry is None or entry[0]!=signature:
        entry=(signature,{})
        bank[key]=entry
        while len(bank)>32:bank.pop(next(iter(bank)))
    cached = entry[1]
    prepared = {}
    for frame in frames:
        if (_state.get('ragdoll_native_controller_preview')
                and frame == bpy.context.scene.frame_current_final
                and any(g.name in _state.get('pin_snap_parent_transform_guides',set()) for g in guides)):
            # Contact has already solved this native parent-drag sample. Its
            # magnetic/pressure state is newer than the saved detached key.
            # Feed Bullet that exact visible obstacle, without publishing the
            # transient pose into the authored-trajectory cache.
            motion[frame] = owner.matrix_world @ bone.matrix
            continue
        if frame in cached:
            motion[frame] = cached[frame]
            continue
        active = [g for g in guides if _surface_contact_guide_active_at(g, frame)]
        if not active:
            cached[frame] = motion[frame]
            continue
        if len(active) != 1:
            return None
        guide = active[0]
        resolved = _surface_contact_resolved_playback_guide(guide)
        gyro=_gyro_find(bpy.context,owner,bone)
        gyro_names={str(gyro.get(k,'')) for k in ('gyro_stable_constraint','gyro_aim_constraint')} if gyro else set()
        if resolved is None or resolved[2] != bone or any(co.name not in gyro_names for co in bone.constraints):
            return None
        if guide.name not in prepared:
            part = bpy.data.objects.get(str(guide.get(SURFACE_CONTACT_SMART_OBJECT_PROPERTY, '')))
            local = guide.get(SURFACE_CONTACT_SMART_LOCAL_PROPERTY)
            welds = [co for co in part.constraints if co.type == 'CHILD_OF' and co.target == owner
                     and co.subtarget in owner.pose.bones] if part else []
            if local is None or len(welds) != 1 or abs(welds[0].influence-1.) > 1.e-6:
                return None
            weld = welds[0]
            part_motion = _ragdoll_native_authored_motion(owner, weld.subtarget, frames)
            if part_motion is None:
                return None
            opposite = Vector(tuple(float(v) for v in local[:3]))
            axis = {'X':0,'Y':1,'Z':2}.get(str(guide.get(SURFACE_CONTACT_CAST_AXIS_PROPERTY,'Y_NEG'))[0],1)
            bounds = [float(c[axis]) for c in part.bound_box]
            opposite[axis] = max((min(bounds),max(bounds)),key=lambda v:abs(v-opposite[axis]))
            prepared[guide.name] = (part_motion, weld.inverse_matrix @ part.matrix_basis, opposite)
        part_motion, weld_matrix, opposite = prepared[guide.name]
        raw = motion[frame]
        binding = raw.inverted_safe() @ part_motion[frame] @ weld_matrix
        target = _surface_contact_release_object_matrix(guide, frame, {})
        anchor = raw @ resolved[3]
        if _surface_contact_animated_detached_state(guide, frame) is True:
            motion[frame] = _surface_contact_detached_rod_world(
                raw, anchor, raw @ binding @ opposite, target.translation, target.to_3x3().col[2].normalized())
        else:
            # Attached playback translates the authored support onto its key.
            motion[frame] = raw.copy()
            motion[frame].translation += target.translation-anchor
        cached[frame] = motion[frame]
    if len(cached)>8192:bank.pop(key,None)
    return motion


def _ragdoll_native_authored_motion(owner, bone_name, frames):
    stack=_state.setdefault('ragdoll_native_motion_stack',set())
    stack_key=(int(owner.as_pointer()),bone_name)
    if stack_key in stack:return None
    stack.add(stack_key)
    preview = _state.get('ragdoll_native_controller_preview')
    action = _ragdoll_action(owner)
    trial = None
    trials = _state.get('ragdoll_native_preview_actions')
    try:
        curves = None
        if preview and preview[0] == owner.name_full and action is not None:
            if trials is not None and owner.name_full in trials:
                return _ragdoll_native_authored_motion_impl(owner,bone_name,frames,trials[owner.name_full][1])
            trial = action.copy()
            curves = {(c.data_path, c.array_index): c for c in _action_fcurves(trial, owner)}
            slot = int(owner.animation_data.action_slot_handle)
            bags = [b for b in _action_channelbags(trial) if b.slot_handle == slot]
            collection = bags[0].fcurves if bags else trial.fcurves
            edited = owner.pose.bones[preview[1]]
            rotation = 'rotation_quaternion' if edited.rotation_mode == 'QUATERNION' else 'rotation_axis_angle' if edited.rotation_mode == 'AXIS_ANGLE' else 'rotation_euler'
            for channel in ('location', rotation, 'scale'):
                path = edited.path_from_id() + '.' + channel
                for index, value in enumerate(getattr(edited, channel)):
                    curve = curves.get((path, index))
                    if curve is None:
                        curve = collection.new(path, index=index)
                        curves[(path, index)] = curve
                    exists = any(abs(p.co.x-preview[2]) < 1e-5 for p in curve.keyframe_points)
                    point = curve.keyframe_points.insert(preview[2], value, options={'FAST'})
                    if not exists:
                        _apply_new_motion_key_style(point)
                    curve.update()
            if trials is not None:
                trials[owner.name_full]=(trial,curves)
        return _ragdoll_native_authored_motion_impl(owner, bone_name, frames, curves)
    finally:
        stack.discard(stack_key)
        if trial is not None and (trials is None or trials.get(owner.name_full,(None,))[0] is not trial):
            bpy.data.actions.remove(trial)


def _ragdoll_native_control_relation(owner, bone, frame):
    """Sample the incoming space while recapturing a removed body's anchor."""
    before = _state.get('ragdoll_native_capture_before', {}).get((owner.name_full, bone.name))
    return _chosen_dynamic_parent_constraint(bone, min(frame, before - 1) if before is not None else frame)


def _ragdoll_native_authored_motion_impl(owner, bone_name, frames, curves=None):
    """Sample an ordinary controller chain without changing the visible frame.

    Constraints/drivers/NLA require evaluated-scene sampling and are deliberately
    not guessed here. Blender's conversion preserves inherit-scale semantics.
    """
    from mathutils import Euler
    animation = owner.animation_data
    if owner.parent or owner.constraints or (animation and
            (_ragdoll_native_unhandled_drivers(owner) or any(t.strips for t in animation.nla_tracks))):
        return None
    bone = owner.pose.bones.get(bone_name) if owner.type == 'ARMATURE' else None
    if bone_name and bone is None:
        return None
    control_sampling = bool(_state.get('ragdoll_native_control_sampling'))
    managed_sampling=control_sampling or bool(bone and any(_dynamic_carrier(b) is not None for b in (bone,*bone.parent_recursive)))
    chain = []
    item = bone
    while item is not None:
        if item in chain:return None
        chain.append(item)
        item = _ragdoll_parent(owner,item) if managed_sampling else item.parent
    chain.reverse()
    gyros = {b.name: _gyro_find(bpy.context, owner, b) for b in chain}
    if any(any(
            co.name not in {str(gyros[b.name].get(k, '')) for k in ('gyro_stable_constraint','gyro_aim_constraint')}
            if gyros[b.name] is not None else True for co in b.constraints) for b in chain):
        return None
    if curves is None:
        curves = {(c.data_path, c.array_index): c for c in
                  _action_fcurves(animation.action, owner)} if animation and animation.action else {}
    if any(curve.mute for curve in curves.values()):
        return None
    def basis(item, prefix, frame):
        sampled_curves=curves;defaults=None
        if isinstance(item,bpy.types.PoseBone) and _SPECIAL_END_INPUTS in item:
            filtered=_special_end_simulation_inputs(bpy.context,owner,item,frame,evaluate_only=True)
            if isinstance(filtered,bpy.types.Action):
                sampled_curves={k:v for k,v in curves.items() if not k[0].startswith(prefix)}
                sampled_curves.update({(c.data_path,c.array_index):c for c in _action_fcurves(filtered,owner)})
                records=[r for r in json.loads(item.get(_SPECIAL_END_INPUTS,'[]')) if r['frame']>frame]
                if records:defaults=min(records,key=lambda r:r['frame'])['defaults']
        mode = item.rotation_mode
        rotation = 'rotation_quaternion' if mode == 'QUATERNION' else 'rotation_axis_angle' if mode == 'AXIS_ANGLE' else 'rotation_euler'
        values = {}
        for channel in ('location', rotation, 'scale'):
            values[channel] = [float(sampled_curves[(prefix+channel, i)].evaluate(frame))
                if (prefix+channel, i) in sampled_curves else float(v)
                for i, v in enumerate(defaults[channel] if defaults else getattr(item, channel))]
        angles = values[rotation]
        q = (Quaternion(angles) if mode == 'QUATERNION' else
             Quaternion(Vector(angles[1:]), angles[0]) if mode == 'AXIS_ANGLE' else
             Euler(angles, mode).to_quaternion())
        q.normalize()
        return Matrix.LocRotScale(Vector(values['location']), q, Vector(values['scale']))
    # Static object delta transforms are retained. Animated deltas are outside
    # this sampler's contract; accepting them would silently lose motion.
    if any(path.startswith('delta_') for path, _ in curves):
        return None
    factor = owner.matrix_world @ basis(owner, '', bpy.context.scene.frame_current).inverted_safe()
    prefixes = tuple(item.path_from_id() for item in chain)
    relevant = tuple((key,curve) for key,curve in curves.items()
                     if not key[0].startswith('pose.bones[') or key[0].startswith(prefixes))
    spaces=tuple((item.name,tuple((co.name,tuple(v for row in co.inverse_matrix for v in row),
                  _dynamic_parent_constraint_segment(item,co)) for co in _dynamic_constraints(item)
                  if _is_dynamic_state_constraint(co)),
                  tuple((co.name,tuple(tuple(row) for row in target.matrix_basis)) for co in _dynamic_constraints(item)
                    if (target:=_dynamic_parent_constraint_target(item,co)) is not None and target.get(SPACE_HELPER_PROPERTY)))
                 for item in chain) if managed_sampling else ()
    signature = (spaces,tuple(v for row in factor for v in row),owner.rotation_mode,
        tuple((prop,tuple(None if (prop,i) in curves else float(v) for i,v in enumerate(getattr(owner,prop))))
              for prop in ('location','scale','rotation_quaternion','rotation_euler','rotation_axis_angle')),
        tuple((key,curve.extrapolation,tuple((tuple(p.co),tuple(p.handle_left),tuple(p.handle_right),
                p.interpolation,p.easing,p.back,p.amplitude,p.period) for p in curve.keyframe_points))
              for key,curve in relevant),
        tuple((item.name,str(item.get(_SPECIAL_END_INPUTS,'')),tuple(v for row in item.bone.matrix_local for v in row),item.rotation_mode,
               item.bone.inherit_scale,item.bone.use_inherit_rotation,item.bone.use_local_location,
               tuple((prop,tuple(None if (item.path_from_id()+'.'+prop,i) in curves else float(v)
                    for i,v in enumerate(getattr(item,prop))))
                    for prop in ('location','scale','rotation_quaternion','rotation_euler','rotation_axis_angle')),
               (tuple(gyros[item.name].get('gyro_anchor',())),
                tuple(gyros[item.name].get('gyro_local_axis',())),str(gyros[item.name].get('gyro_axis','')),
                tuple((prop,tuple(None if (item.path_from_id(f'["{prop}"]'),i) in curves else float(v)
                         for i,v in enumerate(item.get(prop,())))) for prop in (GYRO_TARGET_PROPERTY,GYRO_TILT_PROPERTY)))
                    if gyros[item.name] is not None else ()) for item in chain))
    bank = _state.setdefault('ragdoll_native_kinematic_samples', {})
    capture=tuple(sorted(_state.get('ragdoll_native_capture_before',{}).items()))
    key = (owner.name_full,bone_name,'control',capture) if control_sampling else (owner.name_full,bone_name,capture)
    entry = bank.get(key)
    if entry is None or entry[0] != signature or any(curve.modifiers for _,curve in relevant):
        entry = (signature,{})
        bank[key] = entry
        while len(bank)>32:bank.pop(next(iter(bank)))
    sampled = entry[1]
    output = {}
    for frame in frames:
        if frame in sampled:
            output[frame] = sampled[frame]
            continue
        world = factor @ basis(owner, '', frame)
        pose = None
        poses={}
        for index,item in enumerate(chain):
            if not control_sampling and _ragdoll_active(item,frame):
                disconnected=any((co:=_chosen_dynamic_parent_constraint(later,frame)) is not None
                    and _dynamic_space_role(later,co)==SPACE_ROLE_UNPARENT for later in chain[index+1:])
                if not disconnected:return None
            kwargs = dict(parent_matrix=pose, parent_matrix_local=chain[index-1].bone.matrix_local) if pose is not None else {}
            parent_pose=pose
            pose = item.bone.convert_local_to_pose(basis(item, item.path_from_id()+'.', frame),
                                                   item.bone.matrix_local, **kwargs)
            if managed_sampling and _dynamic_carrier(item) is not None:
                constraint=_ragdoll_native_control_relation(owner,item,frame)
                if constraint is not None:
                    target=_dynamic_parent_constraint_target(item,constraint);subtarget=_dynamic_parent_constraint_subtarget(item,constraint)
                    if target==owner and subtarget in poses:target_world=world@poses[subtarget]
                    elif target is not None and target.get(SPACE_HELPER_PROPERTY):
                        target_world=_surface_contact_release_object_matrix(target,frame,{})
                    elif target is not None:
                        sampled_target=_ragdoll_native_authored_motion(target,subtarget,(frame,))
                        if sampled_target is None:return None
                        target_world=sampled_target[frame]
                    else:return None
                    pose=world.inverted_safe()@target_world@constraint.inverse_matrix@item.bone.matrix_local@basis(item,item.path_from_id()+'.',frame)
            guide = gyros[item.name]
            if not control_sampling and guide is not None and _gyro_bone_active_at(owner, item, frame):
                def keyed(prop, default):
                    path = item.path_from_id(f'["{prop}"]')
                    return tuple(float(curves[(path, i)].evaluate(frame)) if (path,i) in curves else float(v)
                                 for i,v in enumerate(item.get(prop, default)))
                rotation = Quaternion(keyed(GYRO_TILT_PROPERTY, (1,0,0,0))).normalized()
                target = Vector(keyed(GYRO_TARGET_PROPERTY, guide.location))
                matrix = world @ pose
                desired = _gyro_aim_rotation(guide, matrix.translation, rotation, target)
                pose = world.inverted_safe() @ Matrix.LocRotScale(matrix.translation, desired, matrix.to_scale())
            poses[item.name]=pose
        output[frame] = world @ pose if pose is not None else world
        sampled[frame] = output[frame]
    if len(sampled)>8192:bank.pop(key,None)
    return output


def _ragdoll_native_grabs(armature, bones, frames):
    result = {}
    for bone in bones:
        grabs = [c for c in _dynamic_constraints(bone) if c.name.startswith('DP_')]
        if not grabs:
            continue
        offsets = json.loads(bone.get('_staticaliza_ragdoll_grab_offsets', '{}'))
        rows = {f: (False, ()) for f in frames}
        for constraint in grabs:
            target = _dynamic_parent_constraint_target(bone, constraint)
            subtarget = _dynamic_parent_constraint_subtarget(bone, constraint)
            start, end = _dynamic_parent_constraint_segment(bone, constraint)
            if start is None:
                continue  # A deleted marker is not a persistent grab.
            packed = offsets.get(constraint.name)
            if target is None or not packed or len(packed) != 16:
                return None
            if target == armature and subtarget in {b.name for b in bones}:
                # A simulated target is a physical body, never an authored
                # kinematic trajectory. Keep the connection inside Bullet.
                result['_link:'+bone.name+':'+constraint.name] = (
                    subtarget, int(start), None if end is None else int(end), tuple(packed))
                continue
            needed=tuple(f for f in frames if f>=start and (end is None or f<end))
            if not needed:continue
            motion = _ragdoll_native_authored_motion(target, subtarget, needed)
            if motion is None:
                return None
            if target.type=='ARMATURE' and subtarget in target.pose.bones:
                motion=_ragdoll_native_contact_motion(target,target.pose.bones[subtarget],motion,needed)
                if motion is None:return None
            offset = _ragdoll_native_matrix(packed)
            for frame in frames:
                if frame >= start and (end is None or frame < end):
                    if rows[frame][0]:
                        return None  # Ambiguous overlapping parents.
                    matrix = motion[frame] @ offset
                    rows[frame] = (True, tuple(v for row in matrix for v in row))
        result['_grab:' + bone.name] = tuple((f, *rows[f]) for f in frames)
    return result


def _ragdoll_native_controls(armature, driver, bones, frames):
    """Math-only handoffs for bodies whose Orange interval ends mid-island."""
    result={};previous=_state.get('ragdoll_native_control_sampling',False)
    island_names={driver.name,*(b.name for b in bones)}
    contact_attachments={};motions={}
    def authored_motion(name):
        if name not in motions:
            motions[name]=_ragdoll_native_authored_motion(armature,name,frames)
        return motions[name]
    _state['ragdoll_native_control_sampling']=True
    try:
        firsts={b.name:min((int(round(p.co.x)) for fc in _ragdoll_curves(armature,b) for p in fc.keyframe_points
                           if p.co.y>=.5),default=frames[0]) for b in bones}
        pending=[b for b in bones if any(f>=firsts[b.name] and not _ragdoll_active(b,f) for f in frames)]
        if not pending:return result
        parent_motion=authored_motion(driver.name)
        if parent_motion is None:return None
        curves={(fc.data_path,fc.array_index):fc for fc in _action_fcurves(_ragdoll_action(armature),armature)}
        for bone in pending:
            motion=authored_motion(bone.name)
            if motion is None:return None
            rows=[];gyro=_gyro_find(bpy.context,armature,bone)
            bone_guides=tuple(_surface_contact_guides_for_effector(armature,bone))
            for f in frames:
                if f<firsts[bone.name] or _ragdoll_active(bone,f):continue
                relation=_ragdoll_native_control_relation(armature,bone,f)
                reference=driver.name
                reference_motion=parent_motion
                if bone==driver or (relation is not None and _dynamic_space_role(bone,relation)==SPACE_ROLE_UNPARENT):
                    reference='';reference_motion=None
                elif relation is not None and relation.name.startswith('DP_'):
                    target=_dynamic_parent_constraint_target(bone,relation)
                    subtarget=_dynamic_parent_constraint_subtarget(bone,relation)
                    if target==armature and subtarget in {b.name for b in bones}:
                        reference=subtarget
                        reference_motion=authored_motion(subtarget)
                        if reference_motion is None:return None
                    else:reference='';reference_motion=None
                local=motion[f] if reference_motion is None else reference_motion[f].inverted_safe()@motion[f]
                gyro_data=()
                if gyro is not None and _gyro_bone_active_at(armature,bone,f):
                    def keyed(prop,default):
                        path=bone.path_from_id(f'["{prop}"]')
                        return tuple(float(curves[(path,i)].evaluate(f)) if (path,i) in curves else float(v)
                                     for i,v in enumerate(bone.get(prop,default)))
                    gyro_data=(tuple(gyro.get('gyro_anchor',(0,0,0))),tuple(gyro.get('gyro_local_axis',(0,0,-1))),
                               keyed(GYRO_TILT_PROPERTY,(1,0,0,0)),keyed(GYRO_TARGET_PROPERTY,gyro.location))
                contact=()
                guides=[g for g in bone_guides if _surface_contact_guide_active_at(g,f)]
                if len(guides)>1:return None
                if guides:
                    guide=guides[0];resolved=_surface_contact_resolved_playback_guide(guide)
                    part=bpy.data.objects.get(str(guide.get(SURFACE_CONTACT_SMART_OBJECT_PROPERTY,'')))
                    support=guide.get(SURFACE_CONTACT_SMART_LOCAL_PROPERTY)
                    welds=[co for co in part.constraints if co.type=='CHILD_OF' and co.target==armature and co.subtarget in armature.pose.bones] if part else []
                    if resolved is None or resolved[2]!=bone or support is None or len(welds)!=1:return None
                    opposite=Vector(tuple(float(v) for v in support[:3]));axis={'X':0,'Y':1,'Z':2}.get(str(guide.get(SURFACE_CONTACT_CAST_AXIS_PROPERTY,'Y_NEG'))[0],1)
                    bounds=[float(p[axis]) for p in part.bound_box]
                    opposite[axis]=max((min(bounds),max(bounds)),key=lambda v:abs(v-opposite[axis]))
                    part_motion=authored_motion(welds[0].subtarget)
                    if part_motion is None:return None
                    binding=motion[f].inverted_safe()@part_motion[f]@welds[0].inverse_matrix@part.matrix_basis
                    target_bone=''
                    follow=(armature.pose.bones.get(guide.parent_bone)
                            if guide.parent==armature and guide.parent_type=='BONE' else None)
                    physical=follow
                    while physical is not None and physical.name not in island_names:
                        physical=_ragdoll_parent(armature,physical)
                    if physical is not None:
                        # This surface belongs to the same physical island.
                        # Sampling its cached world pose feeds an old solve
                        # back into the next one. Keep the attachment local
                        # and resolve it from this replay's causal body state.
                        target_bone=physical.name
                        if guide.name not in contact_attachments:
                            physical_motion=authored_motion(target_bone)
                            follow_motion=authored_motion(follow.name)
                            if physical_motion is None or follow_motion is None:return None
                            contact_attachments[guide.name]={
                                t:physical_motion[t].inverted_safe()@follow_motion[t] for t in frames}
                        guide_curves=_action_fcurves(_ragdoll_action(guide),guide)
                        target=(contact_attachments[guide.name][f]
                                @Matrix.Translation((0,follow.length,0))
                                @guide.matrix_parent_inverse
                                @_surface_contact_release_channels(guide,f,guide_curves))
                    else:
                        target=_surface_contact_release_object_matrix(guide,f,{})
                    contact=(tuple(resolved[3]),tuple(binding@opposite),tuple(target.translation),
                             tuple(target.to_3x3().col[2].normalized()),_surface_contact_animated_detached_state(guide,f) is True,
                             target_bone)
                rows.append((f,tuple(v for row in local for v in row),gyro_data,contact,reference))
            result['_control:'+bone.name]=tuple(rows)
        return result
    finally:_state['ragdoll_native_control_sampling']=previous


def _ragdoll_native_control_matrix(row,parent,targets=None):
    _frame,packed,gyro,contact=row[:4]
    matrix=parent@_ragdoll_native_matrix(packed)
    if gyro:
        anchor,axis,rotation,target=gyro
        orientation=_gyro_aim_rotation({'gyro_anchor':anchor,'gyro_local_axis':axis},matrix.translation,
                                      Quaternion(rotation),Vector(target))
        matrix=Matrix.LocRotScale(matrix.translation,orientation,matrix.to_scale())
    if contact:
        support,opposite,target,normal,detached=contact[:5]
        if len(contact)>5 and contact[5]:
            reference=targets[contact[5]]
            target=reference@Vector(target)
            normal=(reference.to_3x3()@Vector(normal)).normalized()
        anchor=matrix@Vector(support)
        if detached:matrix=_surface_contact_detached_rod_world(matrix,anchor,matrix@Vector(opposite),Vector(target),Vector(normal))
        else:matrix=_surface_contact_attached_rod_world(matrix,Vector(support),Vector(opposite),Vector(target))
    return matrix


def _ragdoll_native_samples(plan):
    frames, worlds, _specs, statics, _gravity, _release, data = plan
    motions = [dict((f, (on, packed)) for f, on, packed in rows)
               for name, rows in data.items() if name.startswith('_grab:')]
    controls=[{row[0]:row[1:] for row in rows} for name,rows in data.items() if name.startswith('_control:')]
    obstacles = [relative for _, _, relative, _ in statics if isinstance(relative, dict)]
    return tuple((tuple(v for row in worlds[f] for v in row),
                  tuple(m[f] for m in motions),
                  tuple(m.get(f,()) for m in controls),
                  tuple(tuple(v for row in m[f] for v in row) for m in obstacles))
                 for f in frames)


def _ragdoll_native_body_geometry(armature, bone, samples, scale):
    """Reuse an unchanged local convex hull during cached playback."""
    cache=_state.setdefault('ragdoll_native_geometry',{})
    key=_ragdoll_state_key(armature,bone)
    scale_key=tuple(float(v) for v in scale)
    cached=cache.get(key)
    if cached is not None and cached[0] is samples and cached[1]==scale_key:
        return cached[2],cached[3]
    points=tuple(Vector((p.x*scale.x,p.y*scale.y,p.z*scale.z)) for p in samples)
    center=Vector(tuple((min(p[i] for p in points)+max(p[i] for p in points))*.5 for i in range(3)))
    cache[key]=(samples,scale_key,points,center)
    return points,center


def _ragdoll_native_packed_points(points):
    cache=_state.setdefault('ragdoll_native_packed_geometry',{})
    key=id(points)
    cached=cache.get(key)
    if cached is not None and cached[0] is points:return cached[1]
    packed=tuple(tuple(p) for p in points)
    if len(cache)>=128:cache.pop(next(iter(cache)))
    cache[key]=(points,packed)
    return packed


def _ragdoll_native_plan(armature, driver, target, preview):
    scene = bpy.context.scene
    active = tuple(b for b in _ragdoll_active_bones_hierarchy_order(armature, target) if b != driver)
    firsts=[min((int(round(p.co.x)) for fc in _ragdoll_curves(armature,b) for p in fc.keyframe_points
                 if p.co.y>=.5 and p.co.x<=target),default=int(target)) for b in active]
    start=min(firsts,default=int(target))
    # An End changes body ownership, not the history of every other body.
    # Retain the island's incoming bodies and schedule their handoffs below.
    bones=tuple(sorted((b for b in armature.pose.bones if b!=driver and _ragdoll_active(b,start)
                        and _ragdoll_parent(armature,b)==driver),key=lambda b:b.name.casefold()))
    # Ordinary same-rig targets are kinematic members of the same island.
    # Their Unparent intervals can then stop following the physical driver.
    targets=set()
    # Ordinary welded siblings still belong to this physical scene. Sampling
    # them as independent world obstacles reads a simulated ancestor (or forces
    # a different solver) after their Orange channel is deleted. Kinematic
    # members instead follow the solved parent until their own space releases.
    for surface in _ragdoll_collision_surfaces(bpy.context,{armature}):
        if not _ragdoll_self_collision_surface(surface,armature):continue
        other=_ragdoll_surface_pose_bone(surface,armature)
        if other is not None and other!=driver and _ragdoll_parent(armature,other)==driver:
            targets.add(other.name)
    for b in bones:
        for co in _dynamic_constraints(b):
            relation_target=_dynamic_parent_constraint_target(b,co)
            subtarget=_dynamic_parent_constraint_subtarget(b,co)
            other=armature.pose.bones.get(subtarget) if relation_target==armature else None
            if co.name.startswith('DP_') and other is not None and other!=driver:
                if _ragdoll_parent(armature,other)!=driver:return None
                targets.add(other.name)
    bones=tuple(sorted({b.name:b for b in (*bones,*(armature.pose.bones[n] for n in targets))}.values(),key=lambda b:b.name.casefold()))
    def unsupported(b):
        guide=_gyro_find(bpy.context,armature,b)
        allowed={str(guide.get(k,'')) for k in ('gyro_stable_constraint','gyro_aim_constraint')} if guide else set()
        return any(not _is_dynamic_state_constraint(co) and co.name not in allowed for co in b.constraints)
    if not bones or any(_ragdoll_parent(armature, b) != driver or unsupported(b) for b in bones):
        return None
    animation = armature.animation_data
    if animation is None or animation.action is None or _ragdoll_native_unhandled_drivers(armature) or any(t.strips for t in animation.nla_tracks):
        return None
    # Parent/space constraints and animated ancestors require the general
    # evaluated-scene solver. Do not silently omit their trajectories.
    ancestors = []
    parent = driver
    while parent:
        if parent.constraints:
            return None
        ancestors.append(parent)
        parent = parent.parent
    ancestor_paths = tuple('pose.bones[' + json.dumps(b.name) + '].' for b in ancestors[1:])
    if any((c.data_path.startswith(ancestor_paths) or not c.data_path.startswith('pose.bones[')) and len(c.keyframe_points) > 1
           for c in _action_fcurves(animation.action, armature)):
        return None
    if any(b not in bones for b in active):
        return None
    # Retained Pink guides do not disable native replay while Orange owns
    # them. Inspect the whole sampled interval, not only the target frame.
    if any(_surface_contact_pose_bone(guide)[1] == driver and not _ragdoll_curves(armature,driver)
           and _surface_contact_guide_active_at(guide, frame)
           and not _surface_contact_ragdoll_override(guide, frame, include_start=True)
           for guide in _surface_contact_guides()
           for frame in range(start, int(target) + 1)):
        return None
    if start < 0:
        return None
    if target <= start:
        return None  # Native G/R/S at Start still owns the initial pose.
    # A root-nearest torso can release after its children have already been
    # simulating. Keep the same joint island and switch only its body mode.
    root_curves = _ragdoll_curves(armature, driver)
    root_keys = sorted({int(round(p.co.x)) for c in root_curves for p in c.keyframe_points})
    releases = [f for f in root_keys if f >= start and _ragdoll_active(driver, f, curves=root_curves)]
    release = releases[0] if releases else None
    if release is None and _ragdoll_active(driver,target,curves=root_curves):
        return None  # A parent released before this island needs its earlier history.
    if release is not None:
        if (release < start or not _ragdoll_free(armature, driver, release)
                ):
            return None
    frames = tuple(range(start, int(target) + 1))
    # A blue key changes joint topology inside the same native replay.
    # Switching solvers at that boundary discarded sibling history.
    joint_schedules = {}
    for bone in bones:
        boundaries = {start}
        boundaries.update(int(round(p.co.x)) for c in _fcurves_find_all(
            animation.action, _unparent_dp(bone.name)) for p in c.keyframe_points
            if p.co.x >= start)
        boundaries.update(int(round(p.co.x)) for c in _ragdoll_curves(armature,bone) for p in c.keyframe_points
                          if p.co.x>=start)
        for constraint in _dynamic_constraints(bone):
            if not constraint.name.startswith('DP_'):continue
            a,z=_dynamic_parent_constraint_segment(bone,constraint)
            boundaries.update(f for f in (a,z) if f is not None and start<=f<=target)
        schedule = tuple((f, _ragdoll_active(bone,f) and not _ragdoll_unparented(armature, bone, f)
                          and not any(co.name.startswith('DP_') and _dynamic_parent_constraint_active_at(bone,co,f)
                                      for co in _dynamic_constraints(bone)))
                         for f in sorted(boundaries))
        if any(not enabled for _, enabled in schedule):
            joint_schedules['_joint:' + bone.name] = schedule
    accelerations = {b.name: _ragdoll_hinge_gravity(b) for b in (driver, *bones)}
    accelerations.update(joint_schedules)
    grabs = _ragdoll_native_grabs(armature, (driver, *bones), (start-1, *frames))
    if grabs is None:
        return None
    accelerations.update(grabs)
    controls=_ragdoll_native_controls(armature,driver,(driver,*bones),frames)
    if controls is None:return None
    accelerations.update(controls)
    # Let Bullet apply the common acceleration directly. Only differing
    # weights need residual force constraints; ordinary gravity is not a joint.
    frequencies = {}
    for bone in bones:
        if not _ragdoll_curves(armature,bone):continue
        value = tuple(accelerations[bone.name])
        frequencies[value] = frequencies.get(value, 0) + 1
    gravity = Vector(max(frequencies, key=frequencies.get)) if frequencies else _ragdoll_hinge_gravity(driver)
    controller = _state.get('ragdoll_native_controller_preview')
    direct_preview = not controller or controller[:2] == (armature.name_full,driver.name)
    source_frame=target if preview or release is None else min(target,release)
    deltas, worlds = _ragdoll_preview_driver_deltas(armature, driver, (start-1, *frames), source_frame,
        preview=preview and direct_preview, native=True)
    if not worlds:
        return None
    if release is not None and release <= target:
        # Ordinary keys up to release define the incoming trajectory. A saved
        # world matrix must not resurrect a deleted driving key or its velocity.
        released_pose = worlds[release].copy()
        for f in frames:
            if f >= release:
                worlds[f] = released_pose
    initial_scale = worlds[start].to_scale()
    if any((matrix.to_scale() - initial_scale).length > 1e-5 for matrix in worlds.values()):
        return None
    inverse_driver = (armature.matrix_world @ driver.matrix).inverted_safe()
    # Each shape is expressed in its rigid frame. Convex hulls preserve the
    # welded part extents, unlike a point pendulum or an oversized capsule.
    specs = []
    owned_parts = {armature}
    for bone in (driver, *bones):
        _radius, excluded, samples, _normals = _ragdoll_collision_shape(bpy.context, armature, bone, 0.02, borrow=True)
        if len(samples) < 4:
            return None
        owned_parts.update(excluded)
        if bone == driver:
            relative = Matrix.Identity(4)
        else:
            saved = _ragdoll_start_poses(bone).get(str(start), {})
            packed = saved.get('parent_relative_matrix', ())
            rebound = _ragdoll_managed_start_reference(armature, bone, start)
            if rebound is not None:
                relative = worlds[start].inverted_safe() @ armature.matrix_world @ rebound['matrix']
            elif len(packed) == 16:
                relative = _ragdoll_resolved_start_relative(bone,start,saved)
            elif len(saved.get('matrix', ())) == 16:
                # Managed unparenting removes the edit-bone parent, but the
                # saved Start pose and logical parent still define this socket.
                relative = worlds[start].inverted_safe() @ armature.matrix_world @ _ragdoll_native_matrix(saved['matrix'])
            else:
                previous_control=_state.get('ragdoll_native_control_sampling',False)
                _state['ragdoll_native_control_sampling']=True
                try:ordinary=_ragdoll_native_authored_motion(armature,bone.name,(start,))
                finally:_state['ragdoll_native_control_sampling']=previous_control
                if ordinary is None:return None
                relative=worlds[start].inverted_safe()@ordinary[start]
                initial_control=next((row for row in controls.get('_control:'+bone.name,()) if row[0]==start),None)
                if initial_control is not None and initial_control[4]==driver.name:
                    relative=_ragdoll_native_matrix(initial_control[1])
        initial = worlds[start] @ relative
        location, rotation, scale = initial.decompose()
        points, center = _ragdoll_native_body_geometry(armature,bone,samples,scale)
        rigid = Matrix.LocRotScale(location, rotation, Vector((1, 1, 1)))
        specs.append((bone.name, relative, points, center, rigid,
                      float(bone.get(RAGDOLL_DAMPING_PROPERTY, 0.94)),
                      float(bone.get(RAGDOLL_FRICTION_PROPERTY, 0.35)),
                      float(bone.get(RAGDOLL_BOUNCE_PROPERTY, 0.0)),
                      float(bone.bone.length) * abs(scale.y)))
    statics = []
    depsgraph = bpy.context.evaluated_depsgraph_get()
    for surface in _ragdoll_collision_surfaces(bpy.context, owned_parts):
        attachment = None
        if _ragdoll_self_collision_surface(surface, armature):
            bone_name = surface.parent_bone if surface.parent == armature else ''
            if not bone_name:
                bone_name = next((c.subtarget for c in surface.constraints
                                  if getattr(c, 'target', None) == armature and getattr(c, 'subtarget', '')), '')
            attached = armature.pose.bones.get(bone_name)
            if attached is None:
                return None
            paths = tuple('pose.bones[' + json.dumps(b.name) + '].'
                          for b in (attached, *attached.parent_recursive) if b != driver)
            chain = tuple(b for b in (attached, *attached.parent_recursive) if b != driver)
            contact_owner = next((b for b in chain if any(
                _surface_contact_pose_bone(g)[1] == b for g in _surface_contact_guides_for_effector(armature,b))), None)
            articulated = any(b.constraints for b in chain) or contact_owner is not None or any(
                c.data_path.startswith(paths) and len(c.keyframe_points) > 1
                for c in _action_fcurves(animation.action, armature))
            if articulated:
                attachment = _ragdoll_native_authored_motion(armature, attached.name, (start-1, *frames, scene.frame_current))
                if attachment is None:
                    return None
                if contact_owner is not None:
                    raw = _ragdoll_native_authored_motion(armature, contact_owner.name, (start-1, *frames, scene.frame_current))
                    if raw is None:
                        return None
                    solved = _ragdoll_native_contact_motion(armature, contact_owner, dict(raw), (start-1, *frames, scene.frame_current))
                    if solved is None:
                        return None
                    attachment = {f: solved[f] @ raw[f].inverted_safe() @ matrix for f,matrix in attachment.items()}
            elif attached == driver or _ragdoll_is_ancestor(armature, driver, attached):
                attachment = inverse_driver
        elif surface.animation_data or surface.constraints or surface.parent:
            if surface.parent is None and not surface.constraints:
                # Ordinary keyed scene objects are kinematic obstacles too.
                # Requiring an armature attachment here sent even a simple
                # animated cube through the general Python contact solver.
                trajectory = _ragdoll_native_authored_motion(surface, '', (start-1, *frames, scene.frame_current))
                if trajectory is None:
                    return None
                attachment = trajectory
            else:
                owner = surface.parent if surface.parent_type == 'BONE' else None
                bone_name = surface.parent_bone if owner else ''
                if owner is None:
                    link = next((c for c in surface.constraints if c.type == 'CHILD_OF' and c.target and c.target.type == 'ARMATURE' and c.subtarget), None)
                    if link is not None:
                        owner, bone_name = link.target, link.subtarget
                if owner is None or owner == armature:
                    return None
                trajectory = _ragdoll_native_authored_motion(owner, bone_name, (start-1, *frames, scene.frame_current))
                if trajectory is None:
                    return None
                attachment = trajectory
        evaluated = surface.evaluated_get(depsgraph)
        if len(evaluated.data.vertices) > 4096:
            return None
        matrix = evaluated.matrix_world.copy()
        geometry = (tuple(tuple(v.co) for v in evaluated.data.vertices),
                    tuple(tuple(p.vertices) for p in evaluated.data.polygons))
        if isinstance(attachment, dict):
            welds = [co for co in surface.constraints if co.type == 'CHILD_OF'
                     and co.target == armature and co.subtarget == attached.name
                     and abs(co.influence-1.) < 1.e-6] if _ragdoll_self_collision_surface(surface,armature) else []
            # A rigid weld is authored data. Factoring it from two separately
            # evaluated poses leaks incoming-frame error into every collider
            # sample and can change an otherwise identical collision replay.
            offset = (welds[0].inverse_matrix @ surface.matrix_basis
                      if len(welds)==1 and len(surface.constraints)==1 and surface.parent is None
                      else attachment[scene.frame_current].inverted_safe() @ matrix)
            relative = {f: m @ offset for f, m in attachment.items()}
        else:
            relative = attachment @ matrix if attachment is not None else None
        statics.append((surface, matrix, relative, geometry))
    return frames, worlds, specs, statics, gravity, release, accelerations


def _ragdoll_native_buffered_hull(points, socket=None):
    """Use the full visible convex envelope, without contracted corners."""
    # Contact must cover the visible shape. Bevels and a contracted socket
    # collar let render-mesh corners pass through other bodies and the floor.
    return tuple(tuple(float(v) for v in p) for p in points)


def _ragdoll_native_initial_overlap(plan):
    """Use split recovery only for a Start pose intersecting scene geometry."""
    from mathutils.bvhtree import BVHTree
    import bmesh
    frames,worlds,specs,statics,_gravity,_release,_accelerations=plan
    bodies=[tuple(spec[4]@point for point in spec[2]) for spec in specs]
    bounds=lambda points: tuple((min(p[i] for p in points),max(p[i] for p in points)) for i in range(3))
    body_bounds=[bounds(points) for points in bodies]
    for surface,matrix,relative,geometry in statics:
        if isinstance(relative,dict):matrix=relative[frames[0]]
        elif relative is not None:matrix=worlds[frames[0]]@relative
        if geometry is None:
            evaluated=surface.evaluated_get(bpy.context.evaluated_depsgraph_get())
            vertices=[matrix@v.co for v in evaluated.data.vertices]
            polygons=[tuple(p.vertices) for p in evaluated.data.polygons]
        else:
            vertices=[matrix@Vector(p) for p in geometry[0]];polygons=geometry[1]
        if not vertices or not polygons:continue
        obstacle_bounds=bounds(vertices);tree=None
        for points,box in zip(bodies,body_bounds):
            if any(box[i][1]<obstacle_bounds[i][0] or box[i][0]>obstacle_bounds[i][1] for i in range(3)):continue
            if tree is None:tree=BVHTree.FromPolygons(vertices,polygons)
            for point in points:
                location,normal,_index,distance=tree.find_nearest(point)
                if location is not None and distance>.002 and (point-location).dot(normal)<-.002:return True
            # Edge/face crossings can exist without a vertex inside either body.
            bm=bmesh.new()
            try:
                for point in points:bm.verts.new(point)
                if len(bm.verts)<4:continue
                bmesh.ops.convex_hull(bm,input=list(bm.verts),use_existing_faces=False)
                if BVHTree.FromBMesh(bm).overlap(tree):return True
            finally:bm.free()
    return False


def _ragdoll_native_joint_guard(points,parent_points,parent_in_child):
    """Keep distal contact while excluding the authored socket overlap volume."""
    import bmesh
    from mathutils.bvhtree import BVHTree
    cache=_state.setdefault('ragdoll_native_guard_geometry',{})
    key=(id(points),id(parent_points),tuple(round(float(v),6) for row in parent_in_child for v in row))
    cached=cache.get(key)
    if cached is not None and cached[0] is points and cached[1] is parent_points:return cached[2]
    center=Vector(tuple((min(p[i] for p in points)+max(p[i] for p in points))*.5 for i in range(3)))
    if center.length<1.e-6:return ()
    direction=center.normalized()
    def convex(values):
        bm=bmesh.new()
        for point in values:bm.verts.new(point)
        bmesh.ops.convex_hull(bm,input=list(bm.verts),use_existing_faces=False)
        bm.normal_update()
        return bm
    parent=convex(tuple(parent_in_child@p for p in parent_points))
    try:parent_tree=BVHTree.FromBMesh(parent)
    finally:parent.free()
    def clipped(distance,check=False):
        bm=convex(points)
        try:
            bmesh.ops.bisect_plane(bm,geom=list(bm.verts)+list(bm.edges)+list(bm.faces),dist=1.e-7,
                plane_co=direction*distance,plane_no=direction,clear_inner=True,clear_outer=False)
            result=tuple(v.co.copy() for v in bm.verts)
            if len(result)<4:return (),False
            if not check:return result,False
            crossing=bool(BVHTree.FromBMesh(bm).overlap(parent_tree))
            if not crossing:
                for point in result:
                    location,normal,_index,_distance=parent_tree.find_nearest(point)
                    if location is not None and (point-location).dot(normal)<-.001:crossing=True;break
            return result,crossing
        finally:bm.free()
    low=max(0.,min(p.dot(direction) for p in points));high=max(p.dot(direction) for p in points)
    result,crossing=clipped(low,True)
    if crossing:
        for _ in range(9):
            middle=(low+high)*.5;_,crossing=clipped(middle,True)
            if crossing:low=middle
            else:high=middle
        width=min(max(p[i] for p in points)-min(p[i] for p in points) for i in range(3))
        result,_=clipped(high+width*.025)
    if len(cache)>=128:cache.pop(next(iter(cache)))
    cache[key]=(points,parent_points,result)
    return result


def _ragdoll_native_release_projection(plan):
    """Repair embedded limbs about their sockets before initializing velocity.

    An authored intersecting Start remains visible at Start. The private solve
    needs a nonintersecting initial configuration; moving the entire island to
    clear one foot would visibly lift an otherwise clear torso.
    """
    import bmesh
    from mathutils.bvhtree import BVHTree
    frames,worlds,specs,statics,gravity,release,accelerations=plan
    if release!=frames[0]:return plan
    up=-gravity.normalized() if gravity.length>1.e-8 else Vector((0,0,1))
    bounds=lambda values: tuple((min(p[i] for p in values),max(p[i] for p in values)) for i in range(3))
    obstacles=[]
    for surface,matrix,relative,geometry in statics:
        if relative is not None and not isinstance(relative,dict):continue
        if isinstance(relative,dict):matrix=relative[frames[0]]
        if geometry is None:
            evaluated=surface.evaluated_get(bpy.context.evaluated_depsgraph_get())
            vertices=[matrix@v.co for v in evaluated.data.vertices]
            polygons=[tuple(p.vertices) for p in evaluated.data.polygons]
        else:vertices=[matrix@Vector(p) for p in geometry[0]];polygons=geometry[1]
        if vertices and polygons:obstacles.append((bounds(vertices),BVHTree.FromPolygons(vertices,polygons)))
    if not obstacles:return plan
    def facets(points):
        bm=bmesh.new()
        try:
            for point in points:bm.verts.new(point)
            bmesh.ops.convex_hull(bm,input=list(bm.verts),use_existing_faces=False)
            bm.verts.index_update()
            return tuple(v.co.copy() for v in bm.verts),tuple(tuple(v.index for v in f.verts) for f in bm.faces)
        finally:bm.free()
    def intersects(points,faces,targets,margin=.006):
        box=bounds(points)
        for other,tree in targets:
            if any(box[i][1]<other[i][0]-margin or box[i][0]>other[i][1]+margin for i in range(3)):continue
            for point in points:
                location,normal,_index,_distance=tree.find_nearest(point)
                if location is not None and (point-location).dot(normal)<margin:return True
            if BVHTree.FromPolygons(points,faces).overlap(tree):return True
        return False
    hulls={sp[0]:facets(sp[2]) for sp in specs}
    root=specs[0];root_points,root_faces=hulls[root[0]]
    root_world=tuple(root[4]@p for p in root_points)
    # A torso embedded in the scene has no fixed-root articulated solution.
    if intersects(root_world,root_faces,obstacles):return plan
    parent_tree=(bounds(root_world),BVHTree.FromPolygons(root_world,root_faces))
    projected=list(specs);placed=[]
    for index,sp in enumerate(specs[1:],1):
        name,relative,points,center,rigid,*properties=sp
        local,faces=hulls[name];world_points=tuple(rigid@p for p in local)
        if not intersects(world_points,faces,obstacles):
            placed.append((bounds(world_points),BVHTree.FromPolygons(world_points,faces)));continue
        guard=_ragdoll_native_joint_guard(points,root[2],relative.inverted_safe())
        guard_local,guard_faces=facets(guard) if len(guard)>=4 else ((),())
        outward=rigid@center-root[4]@root[3];outward-=up*outward.dot(up)
        travel=worlds[frames[0]].translation-worlds[frames[0]-1].translation
        travel-=up*travel.dot(up)
        axes=[]
        for direction in (outward,travel,rigid.to_quaternion()@center,Vector((1,0,0)),Vector((0,1,0))):
            direction=direction-up*direction.dot(up)
            if direction.length<1.e-6:continue
            axis=direction.normalized().cross(up)
            for signed in (axis,-axis):
                if not any(signed.dot(old)>.999 for old in axes):axes.append(signed)
        def candidate(axis,angle):
            rotation=Quaternion(axis,angle)@rigid.to_quaternion()
            result=Matrix.LocRotScale(rigid.translation,rotation,Vector((1,1,1)))
            values=tuple(result@p for p in local)
            if intersects(values,faces,obstacles) or intersects(values,faces,placed,0.):return None
            if guard_local and intersects(tuple(result@p for p in guard_local),guard_faces,(parent_tree,),0.):return None
            return result
        best=None;best_angle=math.radians(101)
        for axis in axes:
            for degrees in range(5,101,5):
                angle=math.radians(degrees)
                if angle>=best_angle:break
                result=candidate(axis,angle)
                if result is None:continue
                low=angle-math.radians(5);high=angle
                for _ in range(8):
                    middle=(low+high)*.5;trial=candidate(axis,middle)
                    if trial is None:low=middle
                    else:high=middle;result=trial
                best=result;best_angle=high;break
        if best is not None:
            relative=worlds[frames[0]].inverted_safe()@best
            projected[index]=(name,relative,points,center,best,*properties)
            world_points=tuple(best@p for p in local)
        placed.append((bounds(world_points),BVHTree.FromPolygons(world_points,faces)))
    return frames,worlds,projected,statics,gravity,release,accelerations


def _ragdoll_native_release_clearance(plan):
    """Separate an initially intersecting free island without adding velocity."""
    from mathutils.bvhtree import BVHTree
    frames,worlds,specs,statics,gravity,release,_accelerations=plan
    if release!=frames[0]:return Vector()
    points=[tuple(spec[4]@point for point in spec[2]) for spec in specs]
    all_points=[point for body in points for point in body]
    reach=max(max(p[i] for p in all_points)-min(p[i] for p in all_points) for i in range(3))
    up=-gravity.normalized() if gravity.length>1.e-8 else Vector((0,0,1))
    bounds=lambda values: tuple((min(p[i] for p in values),max(p[i] for p in values)) for i in range(3))
    obstacles=[]
    for surface,matrix,relative,geometry in statics:
        # Rigid attachments move with this island; they cannot separate it.
        if relative is not None and not isinstance(relative,dict):continue
        if isinstance(relative,dict):matrix=relative[frames[0]]
        if geometry is None:
            evaluated=surface.evaluated_get(bpy.context.evaluated_depsgraph_get())
            vertices=[matrix@v.co for v in evaluated.data.vertices]
            polygons=[tuple(p.vertices) for p in evaluated.data.polygons]
        else:vertices=[matrix@Vector(p) for p in geometry[0]];polygons=geometry[1]
        if vertices and polygons:obstacles.append((bounds(vertices),BVHTree.FromPolygons(vertices,polygons)))
    shift=Vector()
    for _ in range(8):
        deepest=0.;direction=None
        for body in points:
            moved=[p+shift for p in body];box=bounds(moved)
            for obstacle,tree in obstacles:
                if any(box[i][1]<obstacle[i][0] or box[i][0]>obstacle[i][1] for i in range(3)):continue
                for point in moved:
                    location,normal,_index,_distance=tree.find_nearest(point)
                    if location is None:continue
                    distance=-(point-location).dot(normal)
                    # An embedded foot must leave through the support surface,
                    # rather than being pushed through the bottom of a slab.
                    if distance>.002 and normal.dot(up)<-.5:
                        hit,n,_face,_length=tree.ray_cast(point+up*reach,-up,reach*2)
                        if hit is not None and n.dot(up)>.5:
                            location,normal=hit,n;distance=-(point-location).dot(normal)
                    if distance>deepest+.002:deepest=distance;direction=normal
        if direction is None:break
        step=direction*(deepest+.009)
        if (shift+step).length>reach:break
        shift+=step
    return shift


def _ragdoll_native_substeps(plan,fps):
    frames,worlds,specs,_statics,gravity,_release,_accelerations=plan
    widths=[min(max(p[i] for p in spec[2])-min(p[i] for p in spec[2]) for i in range(3)) for spec in specs]
    width=max(1.e-4,min(widths))
    start=frames[0]
    speed=(worlds[start].translation-worlds[start-1].translation).length*fps
    # Bound travel relative to collider thickness, including gravity acquired
    # over this solve. Fast launches need more contact samples than idle poses.
    # A fixed one-second gravity budget keeps the chosen integration rate
    # independent of the requested cursor frame and cache lookahead horizon.
    speed+=gravity.length
    return max(2,math.ceil(480./fps),min(64,math.ceil(speed/(fps*width*.2))))


def _ragdoll_native_masses(specs):
    volumes={spec[0]:max(1.e-8,math.prod(max(p[i] for p in spec[2])-min(p[i] for p in spec[2]) for i in range(3))) for spec in specs}
    reference=sorted(volumes.values())[len(volumes)//2]
    return {name:min(4.,max(.25,volume/reference)) for name,volume in volumes.items()}


def _ragdoll_native_body(scene, name, points, matrix, dynamic, objects, meshes, socket=None):
    mesh = bpy.data.meshes.new('_UtilsJointShape')
    meshes.append(mesh)
    mesh.from_pydata(_ragdoll_native_buffered_hull(points, socket), [], [])
    prototype = next((o for o in objects if o.rigid_body
                      and o.rigid_body.type == ('ACTIVE' if dynamic else 'PASSIVE')), None)
    if prototype is None:
        obj = bpy.data.objects.new(name, mesh)
    else:
        # Copy configured native body data within this disposable solve.
        # Avoid one operator/depsgraph rebuild per limb; retain no RNA pool
        # across user events or undo transactions.
        obj = prototype.copy()
        obj.name = name
        obj.data = mesh
        obj.animation_data_clear()
    objects.append(obj)
    scene.collection.objects.link(obj)
    obj.matrix_world = matrix
    if prototype is None:
        with bpy.context.temp_override(scene=scene, view_layer=scene.view_layers[0],
                                       object=obj, active_object=obj,
                                       selected_objects=[obj], selected_editable_objects=[obj]):
            bpy.ops.rigidbody.object_add('EXEC_DEFAULT', False, type='ACTIVE' if dynamic else 'PASSIVE')
    else:
        if obj.name not in scene.rigidbody_world.collection.objects:
            scene.rigidbody_world.collection.objects.link(obj)
        obj.rigid_body.kinematic = False
    obj.rigid_body.collision_collections = (True,)+(False,)*19
    obj.rigid_body.mesh_source = 'BASE'
    obj.rigid_body.collision_shape = 'CONVEX_HULL'
    obj.rigid_body.use_margin = True
    # Scale the numerical skin with the part. A fixed skin adds overlapping
    # support to touching sibling hulls and creates a kick at release.
    width=max(1.e-4,min(max(p[i] for p in points)-min(p[i] for p in points) for i in range(3)))
    obj.rigid_body.collision_margin = min(.004,width*.0001)
    obj.rigid_body.use_deactivation = True
    obj.rigid_body.deactivate_linear_velocity = width*.1
    obj.rigid_body.deactivate_angular_velocity = .2
    return obj


def _ragdoll_native_motion(obj, frames, matrices, actions, *, dense=False):
    # Collapse only exactly constant spans; changing samples retain their
    # original interpolation. Long holds need two keys, not seven per frame.
    if len(frames) > 2 and not dense:
        keep = [0]
        for index in range(1, len(frames)-1):
            if matrices[index] != matrices[index-1] or matrices[index] != matrices[index+1]:
                keep.append(index)
        keep.append(len(frames)-1)
        frames = tuple(frames[i] for i in keep)
        matrices = tuple(matrices[i] for i in keep)
    obj.rotation_mode = 'QUATERNION'
    obj.keyframe_insert('location', frame=frames[0])
    obj.keyframe_insert('rotation_quaternion', frame=frames[0])
    action = obj.animation_data.action
    actions.append(action)
    positions, rotations = [], []
    previous = None
    for matrix in matrices:
        positions.append(tuple(matrix.translation))
        rotation = matrix.to_quaternion()
        if previous is not None and rotation.dot(previous) < 0:
            rotation.negate()
        rotations.append(tuple(rotation))
        previous = rotation
    for curve in _action_fcurves(action, obj):
        values = positions if curve.data_path == 'location' else rotations
        curve.keyframe_points.add(len(frames) - 1)
        curve.keyframe_points.foreach_set('co', [v for f, row in zip(frames, values) for v in (f, row[curve.array_index])])
        linear = bpy.types.Keyframe.bl_rna.properties['interpolation'].enum_items['LINEAR'].value
        curve.keyframe_points.foreach_set('interpolation', [linear] * len(frames))
        curve.update()


def _ragdoll_native_gravity_motor(scene, anchor, body, acceleration, objects):
    """Constant COM force using Bullet's unlocked linear motor row.

    Blender names the cap max_impulse, but its Bullet adapter supplies a
    force; Bullet multiplies by the substep dt. A saturated target velocity
    therefore supplies F=m*a without changing mass or constraining rotation.
    The static first body keeps the force axis fixed in world coordinates.
    """
    prototype = next((obj for obj in objects if obj.rigid_body_constraint
                      and obj.rigid_body_constraint.type == 'MOTOR'), None)
    motor = prototype.copy() if prototype else bpy.data.objects.new('_UtilsGravityForce', None)
    objects.append(motor)
    scene.collection.objects.link(motor)
    axis = acceleration.normalized() if acceleration.length > 1e-12 else Vector((0, 0, -1))
    rotation = Vector((1, 0, 0)).rotation_difference(axis)
    motor.matrix_world = Matrix.LocRotScale(body.matrix_world.translation,
                                          rotation, Vector((1, 1, 1)))
    if prototype is None:
        with bpy.context.temp_override(scene=scene, view_layer=scene.view_layers[0],
                                       object=motor, active_object=motor,
                                       selected_objects=[motor], selected_editable_objects=[motor]):
            bpy.ops.rigidbody.constraint_add('EXEC_DEFAULT', False)
    elif motor.name not in scene.rigidbody_world.constraints.objects:
        scene.rigidbody_world.constraints.objects.link(motor)
    constraint = motor.rigid_body_constraint
    constraint.type = 'MOTOR'
    constraint.object1, constraint.object2 = anchor, body
    constraint.use_motor_lin = True
    constraint.use_motor_ang = False
    constraint.motor_lin_target_velocity = -1000000.0
    constraint.motor_lin_max_impulse = 0.0  # Start priming has no acceleration.
    return constraint, body.rigid_body.mass * acceleration.length


def _ragdoll_native_replay(plan, fps, *, endpoints_only=False):
    steps = _ragdoll_native_replay_steps(plan, fps, endpoints_only=endpoints_only)
    while True:
        try:
            next(steps)
        except StopIteration as finished:
            return finished.value


def _ragdoll_native_replay_steps(plan, fps, *, endpoints_only=False):
    """Replay topology intervals causally; future joints cannot change history."""
    frames,worlds,specs,statics,gravity,release,data=plan
    events=set()
    for name,rows in data.items():
        if name.startswith('_joint:'):
            events.update(f for i,(f,on) in enumerate(rows) if i and on!=rows[i-1][1])
        elif name.startswith('_link:'):
            events.update(f for f in rows[1:3] if f is not None)
        elif name.startswith('_control:'):
            on={row[0] for row in rows}
            events.update(f for f in frames[1:] if (f in on)!=(f-1 in on))
            events.update(row[0] for previous,row in zip(rows,rows[1:]) if row[4]!=previous[4])
    events=sorted(f for f in events if frames[0]<f<=frames[-1])
    merged={};begin=frames[0]
    def matrix(name,f):
        state=merged[name][f]
        return Matrix.LocRotScale(Vector(state['anchor']),Quaternion(state['orientation']),Vector((1,1,1)))
    for finish in (*[f-1 for f in events],frames[-1]):
        if finish<=begin:continue
        chunk_frames=tuple(range(begin,finish+1));chunk_worlds={f:worlds[f] for f in (begin-1,*chunk_frames)}
        chunk_specs=specs;chunk_release=release;chunk_data={}
        if begin>frames[0]:
            chunk_data['_checkpoint']=(True,)
            if release is not None and release<=begin:
                chunk_release=begin
                chunk_worlds[begin-1]=matrix(specs[0][0],begin-1)
                chunk_worlds[begin]=matrix(specs[0][0],begin)
                for f in chunk_frames:chunk_worlds[f]=chunk_worlds[begin]
            chunk_specs=[]
            for spec in specs:
                name=spec[0]
                rigid=matrix(name,begin) if name in merged else chunk_worlds[begin]@spec[1]
                relative=chunk_worlds[begin].inverted_safe()@rigid
                chunk_specs.append((name,relative,spec[2],spec[3],rigid,*spec[5:]))
                if name in merged:
                    chunk_data['_incoming:'+name]=tuple(v for row in matrix(name,begin-1) for v in row)
        mode_frame=begin+1
        for name,rows in data.items():
            if name.startswith('_joint:'):
                enabled=next(on for f,on in reversed(rows) if f<=mode_frame)
                if not enabled:chunk_data[name]=((begin,False),)
                before=next((on for f,on in reversed(rows) if f<=begin),enabled)
                if enabled and not before:chunk_data['_reattach:'+name[7:]]=(True,)
            elif name.startswith('_link:'):
                target,start,end,packed=rows
                if start<=mode_frame and (end is None or mode_frame<end):chunk_data[name]=rows
            elif name.startswith(('_control:','_grab:')):
                selected=tuple(row for row in rows if begin-1<=row[0]<=finish)
                if selected:chunk_data[name]=selected
            else:chunk_data[name]=rows
        # A space switch is a collider teleport, not a swept high-speed move.
        # Rebind both private priming poses in the new frame while retaining
        # the already-published old-frame pose in merged history.
        for label,rows in data.items():
            if not label.startswith('_control:') or begin==frames[0]:continue
            old=next((row for row in rows if row[0]==begin),None)
            new=next((row for row in rows if row[0]==mode_frame),None)
            if old is None or new is None or old[4]==new[4]:continue
            name=label[9:];reference=new[4];local=_ragdoll_native_matrix(new[1])
            def rebound(f):
                parent=(matrix(reference,f) if reference in merged else chunk_worlds[f]) if reference else Matrix.Identity(4)
                return parent@local
            rigid=rebound(begin)
            chunk_specs=[(spec[0],chunk_worlds[begin].inverted_safe()@rigid,spec[2],spec[3],rigid,*spec[5:])
                         if spec[0]==name else spec for spec in chunk_specs]
            chunk_data['_incoming:'+name]=tuple(v for row in rebound(begin-1) for v in row)
        chunk=(chunk_frames,chunk_worlds,chunk_specs,statics,gravity,chunk_release,chunk_data)
        if not events:return (yield from _ragdoll_native_replay_segment_steps(chunk,fps,endpoints_only=endpoints_only))
        generator=_ragdoll_native_replay_segment_steps(chunk,fps,endpoints_only=endpoints_only)
        try:
            while True:
                item=next(generator)
                if item is None:yield None;continue
                f,output=item
                for name,states in output.items():
                    dest=merged.setdefault(name,{})
                    if f not in dest and f in states:dest[f]=states[f]
                yield f,merged
        except StopIteration:pass
        finally:generator.close()
        begin=finish
    return merged


def _ragdoll_native_replay_segment_steps(plan, fps, *, endpoints_only=False):
    """Reuse completed causal intervals without keeping a private Blender ID."""
    frames,worlds,specs,statics,gravity,release,data=plan
    packed=lambda matrix:tuple(v for row in matrix for v in row)
    signature=(_RAGDOLL_NATIVE_REVISION,float(fps),frames[0],tuple(gravity),release,packed(worlds[frames[0]-1]),
        tuple((s[0],packed(s[1]),_ragdoll_native_packed_points(s[2]),tuple(s[3]),packed(s[4]),*s[5:]) for s in specs),
        tuple((o.name_full,geometry,('animated',) if isinstance(relative,dict) else packed(relative if relative is not None else matrix),
               (o.rigid_body.friction,o.rigid_body.restitution) if o.rigid_body else (1.,0.)) for o,matrix,relative,geometry in statics),
        tuple((name,tuple(value)) for name,value in data.items() if not name.startswith(('_control:','_grab:'))))
    samples=_ragdoll_native_samples(plan)
    required={frames[0],*frames[-3:]} if endpoints_only else set(frames)
    bank=_state.setdefault('ragdoll_native_segment_cache',[])
    for saved_signature,saved_samples,output in bank:
        if (len(saved_samples)>=len(samples) and _ragdoll_native_equal(signature,saved_signature)
                and _ragdoll_native_equal(samples,saved_samples[:len(samples)])
                and all(required.issubset(states) for states in output.values())):
            _state['ragdoll_native_segment_hits']=_state.get('ragdoll_native_segment_hits',0)+1
            prefix={name:{f:states[f] for f in sorted(required)} for name,states in output.items()}
            for f in sorted(required):yield f,prefix
            return prefix
    output=yield from _ragdoll_native_replay_segment_build_steps(plan,fps,endpoints_only=endpoints_only)
    bank.insert(0,(signature,samples,output))
    count=0;keep=0
    for _signature,_samples,states in bank:
        size=sum(len(rows) for rows in states.values())
        if keep and (count+size>20000 or keep>=16):break
        count+=size;keep+=1
    del bank[keep:]
    return output


def _ragdoll_native_replay_segment_build_steps(plan, fps, *, endpoints_only=False):
    authored_starts={sp[0]:sp[4] for sp in plan[2]}
    checkpoint=bool(plan[6].get('_checkpoint'))
    if not checkpoint:plan=_ragdoll_native_release_projection(plan)
    frames, worlds, specs, statics, gravity, release, accelerations = plan
    scene = bpy.data.scenes.new('_UtilsJointReplay')
    scene['_staticaliza_physics_scratch'] = True
    # Blender clamps the rigid-body cache start to frame 1 and initializes
    # joints on the following step. Private frame 2 primes the incoming pose;
    # authored Start is frame 3, still kinematic, to establish its velocity.
    # Dynamic simulation begins on the next interval.
    frame_offset = 3 - frames[0]
    motion_frames = (frames[0]-1, *frames)
    grabs = {name[6:]: {f: (on, packed) for f, on, packed in rows}
             for name, rows in accelerations.items() if name.startswith('_grab:')}
    controls={name[9:]:{row[0]:row for row in rows} for name,rows in accelerations.items() if name.startswith('_control:')}
    links={name:value for name,value in accelerations.items() if name.startswith('_link:')}
    if links:
        # Bind both priming poses into the authored rigid grip frame. A fixed
        # joint then has zero positional/angular error at activation, instead
        # of converting a changed Euler limit into a correction impulse.
        accelerations=dict(accelerations);specs=list(specs)
        by_name={sp[0]:i for i,sp in enumerate(specs)}
        for label,(target,start,end,packed) in links.items():
            name=label.split(':',2)[1]
            if not (start<=frames[0]+1 and (end is None or frames[0]+1<end)):continue
            parent=specs[by_name[target]];child=specs[by_name[name]];offset=_ragdoll_native_matrix(packed)
            rigid=parent[4]@offset
            relative=worlds[frames[0]].inverted_safe()@rigid
            specs[by_name[name]]=(name,relative,child[2],child[3],rigid,*child[5:])
            incoming=(_ragdoll_native_matrix(accelerations['_incoming:'+target]) if '_incoming:'+target in accelerations else worlds[frames[0]-1]@parent[1])@offset
            accelerations['_incoming:'+name]=tuple(v for row in incoming for v in row)
    for label in tuple(accelerations):
        if not label.startswith('_reattach:'):continue
        name=label[10:];spec=next(sp for sp in specs if sp[0]==name)
        incoming=_ragdoll_native_matrix(accelerations['_incoming:'+name])
        incoming.translation=worlds[frames[0]-1]@spec[1].translation
        accelerations['_incoming:'+name]=tuple(v for row in incoming for v in row)
    substeps = _ragdoll_native_substeps(plan,fps)
    clearance = Vector() if checkpoint else _ragdoll_native_release_clearance(plan)
    if clearance.length_squared>1.e-12:
        worlds={f:matrix.copy() for f,matrix in worlds.items()}
        for matrix in worlds.values():matrix.translation+=clearance
    masses = _ragdoll_native_masses(specs)

    def private_frame(frame):
        return frame + frame_offset

    scene.frame_current = 1
    objects, meshes, actions = [], [], []
    collections = []
    output = {spec[0]: {} for spec in (specs if release is not None else specs[1:])}
    try:
        scene.render.fps = max(1, round(fps))
        scene.render.fps_base = scene.render.fps / fps
        scene.gravity = (0.0, 0.0, 0.0)
        parent_spec = specs[0]
        center = parent_spec[3]
        driver = _ragdoll_native_body(scene, '_UtilsDriver',
            [p - center for p in parent_spec[2]],
            Matrix.LocRotScale(worlds[frames[0]-1].translation, worlds[frames[0]-1].to_quaternion(), Vector((1,1,1))) @ Matrix.Translation(center), True, objects, meshes)
        driver.rigid_body.mass = masses[parent_spec[0]]
        driver.rigid_body.friction = max(0.0, min(1.0, parent_spec[6]))
        driver.rigid_body.restitution = max(0.0, min(1.0, parent_spec[7]))
        driver.rigid_body.linear_damping = 0.0
        driver.rigid_body.angular_damping = _ragdoll_native_socket_damping(parent_spec[5],gravity,parent_spec[8])
        driver.rigid_body.kinematic = True
        yield None
        _ragdoll_native_motion(driver, tuple(private_frame(f) for f in motion_frames),
            [Matrix.LocRotScale(worlds[f].translation, worlds[f].to_quaternion(), Vector((1,1,1))) @ Matrix.Translation(center) for f in motion_frames], actions, dense=parent_spec[0] in controls)
        bodies = []
        if release is not None:
            # Preserve the authored Start pose through its exact frame. The
            # following interval is dynamic, with all limb joints still live.
            driver.rigid_body.kinematic = True
            driver.keyframe_insert('rigid_body.kinematic', frame=frames[0]+frame_offset)
            driver.keyframe_insert('rigid_body.kinematic', frame=release+frame_offset)
            driver.rigid_body.kinematic = False
            driver.keyframe_insert('rigid_body.kinematic', frame=release+frame_offset+1)
            for curve in _action_fcurves(driver.animation_data.action, driver):
                if curve.data_path == 'rigid_body.kinematic':
                    for point in curve.keyframe_points:point.interpolation = 'CONSTANT'
            bodies.append((parent_spec[0], driver, center, Matrix.Identity(4), parent_spec[8]))
        joint_prototype = None
        guard_forces = []
        body_objects={parent_spec[0]:driver}
        body_centers={parent_spec[0]:parent_spec[3]}
        controlled_guards={}
        for name, relative, points, center, rigid, damping, friction, bounce, length in specs[1:]:
            rigid=rigid.copy();rigid.translation+=clearance
            controlled=frames[0]+1 in controls.get(name,{})
            guard_points = _ragdoll_native_joint_guard(points,parent_spec[2],relative.inverted_safe()) if len(specs)<=20 and not controlled else ()
            full_center=center
            guard_center=(Vector(tuple((min(p[i] for p in guard_points)+max(p[i] for p in guard_points))*.5 for i in range(3))) if guard_points else None)
            if guard_points:center=(full_center-guard_center*.1)/.9
            incoming = (_ragdoll_native_matrix(accelerations['_incoming:'+name]) if '_incoming:'+name in accelerations
                        else worlds[frames[0]-1] @ relative)
            incoming = Matrix.LocRotScale(incoming.translation, incoming.to_quaternion(), Vector((1,1,1)))
            body = _ragdoll_native_body(scene, '_UtilsLimb', [p-center for p in points],
                                      incoming @ Matrix.Translation(center), True, objects, meshes, socket=-center)
            grab_rows = accelerations.get('_grab:' + name, ())
            grab_map = grabs.get(name, {})
            body_frames = (frames[0]-1, frames[0]) if not grab_rows and name not in controls else motion_frames
            body_matrices = []
            for f in body_frames:
                on, packed = grab_map.get(f, (False, ()))
                pose = _ragdoll_native_matrix(packed) if on else (incoming if f < frames[0] else rigid)
                body_matrices.append(pose @ Matrix.Translation(center))
            _ragdoll_native_motion(body, tuple(private_frame(f) for f in body_frames), body_matrices, actions,dense=name in controls)
            body.rigid_body.kinematic = True
            body.keyframe_insert('rigid_body.kinematic', frame=2)
            body.keyframe_insert('rigid_body.kinematic', frame=3)
            body.rigid_body.kinematic = False
            body.keyframe_insert('rigid_body.kinematic', frame=4)
            for f, on, _packed in grab_rows:
                if f > frames[0]:
                    body.rigid_body.kinematic = on
                    body.keyframe_insert('rigid_body.kinematic', frame=private_frame(f))
            if name in controls:
                for f in frames:
                    if f<=frames[0]:continue
                    body.rigid_body.kinematic=f in controls[name] or grabs.get(name,{}).get(f,(False,()))[0]
                    body.keyframe_insert('rigid_body.kinematic',frame=private_frame(f))
            for curve in _action_fcurves(body.animation_data.action, body):
                if curve.data_path == 'rigid_body.kinematic':
                    for point in curve.keyframe_points:
                        point.interpolation = 'CONSTANT'
            body.rigid_body.mass = masses[name]*(.9 if guard_points else 1.)
            body.rigid_body.friction = max(0.0, min(1.0, friction))
            body.rigid_body.restitution = max(0.0, min(1.0, bounce))
            # A connected limb damps its swing, not its absolute world travel.
            # Linear drag on every child created socket torque proportional to
            # torso speed even at constant velocity, and braked released rigs.
            # The whole free island retains its incoming linear momentum.
            body.rigid_body.linear_damping = 0.0
            body.rigid_body.angular_damping = _ragdoll_native_socket_damping(
                damping, accelerations[name], length, points, center)
            joint = joint_prototype.copy() if joint_prototype else bpy.data.objects.new('_UtilsSocket', None)
            joint.animation_data_clear()
            objects.append(joint)
            scene.collection.objects.link(joint)
            joint.matrix_world = incoming
            if joint_prototype is None:
                with bpy.context.temp_override(scene=scene, view_layer=scene.view_layers[0],
                                               object=joint, active_object=joint,
                                               selected_objects=[joint], selected_editable_objects=[joint]):
                    bpy.ops.rigidbody.constraint_add('EXEC_DEFAULT', False)
                joint_prototype = joint
            else:
                if joint.name not in scene.rigidbody_world.constraints.objects:
                    scene.rigidbody_world.constraints.objects.link(joint)
            constraint = joint.rigid_body_constraint
            # Socket anchoring must not suppress physical contact between
            # connected shapes. All parts use the same free ball joint and
            # convex-hull contact solve, without anatomical name exceptions.
            constraint.enabled = True
            constraint.type = 'GENERIC'
            for axis in ('x','y','z'):
                setattr(constraint,'use_limit_lin_'+axis,True)
                setattr(constraint,'limit_lin_'+axis+'_lower',0.)
                setattr(constraint,'limit_lin_'+axis+'_upper',0.)
                setattr(constraint,'use_limit_ang_'+axis,True)
                angle=math.radians(55 if axis=='y' else 100)
                setattr(constraint,'limit_ang_'+axis+'_lower',-angle)
                setattr(constraint,'limit_ang_'+axis+'_upper',angle)
            constraint.object1, constraint.object2 = driver, body
            constraint.disable_collisions = bool(guard_points)
            constraint.use_override_solver_iterations = True
            constraint.solver_iterations = 128
            schedule = accelerations.get('_joint:' + name, ())
            previous_enabled = None
            disconnected=False
            for f, enabled in schedule:
                disconnected=disconnected or not enabled
                enabled=enabled and not disconnected
                if enabled != previous_enabled:
                    constraint.enabled = enabled
                    joint.keyframe_insert('rigid_body_constraint.enabled', frame=private_frame(f))
                    previous_enabled = enabled
            if schedule:
                joint_action = joint.animation_data.action
                actions.append(joint_action)
                for curve in _action_fcurves(joint_action, joint):
                    for point in curve.keyframe_points:
                        point.interpolation = 'CONSTANT'
            if guard_points:
                layer_index=len(guard_forces)+1
                driver.rigid_body.collision_collections=tuple(v or i==layer_index for i,v in enumerate(driver.rigid_body.collision_collections))
                guard=_ragdoll_native_body(scene,'_UtilsSocketGuard',[p-guard_center for p in guard_points],
                    incoming@Matrix.Translation(guard_center),True,objects,meshes)
                guard.rigid_body.collision_collections=tuple(i==layer_index for i in range(20))
                guard.rigid_body.mass=masses[name]*.1
                guard.rigid_body.friction=body.rigid_body.friction
                guard.rigid_body.restitution=body.rigid_body.restitution
                guard.rigid_body.linear_damping=0.
                guard.rigid_body.angular_damping=body.rigid_body.angular_damping
                _ragdoll_native_motion(guard,tuple(private_frame(f) for f in body_frames),
                    [matrix@Matrix.Translation(guard_center-center) for matrix in body_matrices],actions,dense=name in controls)
                for f,on in ((frames[0]-1,True),(frames[0],True),(frames[0]+1,False),*((f,on) for f,on,_ in grab_rows if f>frames[0])):
                    guard.rigid_body.kinematic=on
                    guard.keyframe_insert('rigid_body.kinematic',frame=private_frame(f))
                if name in controls:
                    controlled_guards[name]=(guard,guard_center)
                    for f in frames:
                        if f<=frames[0]:continue
                        guard.rigid_body.kinematic=f in controls[name] or grabs.get(name,{}).get(f,(False,()))[0]
                        guard.keyframe_insert('rigid_body.kinematic',frame=private_frame(f))
                for curve in _action_fcurves(guard.animation_data.action,guard):
                    if curve.data_path=='rigid_body.kinematic':
                        for point in curve.keyframe_points:point.interpolation='CONSTANT'
                weld=joint_prototype.copy();weld.name='_UtilsGuardWeld';weld.animation_data_clear()
                objects.append(weld);scene.collection.objects.link(weld)
                if weld.name not in scene.rigidbody_world.constraints.objects:scene.rigidbody_world.constraints.objects.link(weld)
                weld.matrix_world=incoming
                weld.rigid_body_constraint.type='FIXED'
                weld.rigid_body_constraint.object1=body;weld.rigid_body_constraint.object2=guard
                weld.rigid_body_constraint.enabled=True;weld.rigid_body_constraint.disable_collisions=True
                guard_forces.append((name,guard))
            bodies.append((name, body, center, relative, length))
            body_objects[name]=body
            body_centers[name]=center
            # Building another articulated body can rebuild dependencies. Give
            # Blender an input/redraw turn between bodies during preparation.
            yield None
        if parent_spec[0] in controls:
            for f in frames:
                driver.rigid_body.kinematic=(release is None or f<=release or f in controls[parent_spec[0]])
                driver.keyframe_insert('rigid_body.kinematic',frame=private_frame(f))
            for fc in _action_fcurves(driver.animation_data.action,driver):
                if fc.data_path=='rigid_body.kinematic':
                    for p in fc.keyframe_points:p.interpolation='CONSTANT'
        # Filter only feedback into bodies supplying a kinematic member's own
        # motion. A world-held Unparent member has no such driver and remains
        # a solid collider for the rest of the island.
        controlled_names=[name for name in body_objects if name!=parent_spec[0] and frames[0]+1 in controls.get(name,{})]
        edges=[]
        for name in body_objects:
            if name==parent_spec[0]:continue
            schedule=accelerations.get('_joint:'+name,())
            if not schedule or next(on for f,on in reversed(schedule) if f<=frames[0]+1):edges.append((parent_spec[0],name))
        for label,(target,start,end,_offset) in links.items():
            if start<=frames[0]+1 and (end is None or frames[0]+1<end):edges.append((target,label.split(':',2)[1]))
        available=[i for i,v in reversed(tuple(enumerate(driver.rigid_body.collision_collections))) if i and not v]
        for index,name in enumerate(controlled_names):
            reference=controls[name][frames[0]+1][4]
            seen={name}
            while reference in controls and reference not in seen:
                seen.add(reference)
                row=controls[reference].get(frames[0]+1)
                if row is None:break
                reference=row[4]
            connected={reference} if reference else set()
            for _ in body_objects:
                previous=len(connected)
                for a,b in edges:
                    if a in connected or b in connected:connected.update((a,b))
                if len(connected)==previous:break
            layer=available[index]
            body_objects[name].rigid_body.collision_collections=tuple(i==layer for i in range(20))
            for other,body in body_objects.items():
                if other==name or other in connected or other in controlled_names:continue
                body.rigid_body.collision_collections=tuple(v or i==layer for i,v in enumerate(body.rigid_body.collision_collections))
        for label,(target,start,end,packed) in links.items():
            name=label.split(':',2)[1]
            if name==target:return None
            link=joint_prototype.copy();link.name='_UtilsParentLink';link.animation_data_clear()
            objects.append(link);scene.collection.objects.link(link)
            if link.name not in scene.rigidbody_world.constraints.objects:scene.rigidbody_world.constraints.objects.link(link)
            link.matrix_world=next(sp[4] for sp in specs if sp[0]==name)
            co=link.rigid_body_constraint;co.type='FIXED'
            co.object1=body_objects[target];co.object2=body_objects[name]
            co.disable_collisions=True
            # The fixed link uses the authored grip offset, rather than the
            # unrelated original shoulder/hip socket.
            target_spec=next(sp for sp in specs if sp[0]==target)
            target_incoming=target_spec[4] if checkpoint else worlds[frames[0]-1]@target_spec[1]
            initial_target=target_incoming@Matrix.Translation(body_centers[target])
            link.matrix_world=initial_target
            for f in frames:
                controlled=name in controls and f in controls[name]
                co.enabled=f>=start and (end is None or f<end) and not controlled
                link.keyframe_insert('rigid_body_constraint.enabled',frame=private_frame(f))
            actions.append(link.animation_data.action)
            for fc in _action_fcurves(link.animation_data.action,link):
                for p in fc.keyframe_points:p.interpolation='CONSTANT'
            yield None
        gravity_motors = []
        gravity_anchor = None
        for name, body in [(name,body) for name,body,*_rest in bodies]+guard_forces:
            residual = accelerations[name] - gravity
            if residual.length_squared < 1e-16:
                continue
            if gravity_anchor is None:
                gravity_anchor = _ragdoll_native_body(scene, '_UtilsGravityAnchor',
                    (Vector((0, 0, 0)), Vector((.01, 0, 0)),
                     Vector((0, .01, 0)), Vector((0, 0, .01))),
                    Matrix.Identity(4), False, objects, meshes)
                gravity_anchor.rigid_body.collision_collections = (False,) * 20
            gravity_motors.append(_ragdoll_native_gravity_motor(
                scene, gravity_anchor, body, residual, objects))
        depsgraph = bpy.context.evaluated_depsgraph_get()
        for surface, matrix, relative, _geometry in statics:
            evaluated = surface.evaluated_get(depsgraph)
            mesh = bpy.data.meshes.new_from_object(evaluated, depsgraph=depsgraph)
            meshes.append(mesh)
            obj = bpy.data.objects.new('_UtilsObstacle', mesh)
            objects.append(obj)
            scene.collection.objects.link(obj)
            obj.matrix_world = matrix
            with bpy.context.temp_override(scene=scene, view_layer=scene.view_layers[0],
                                           object=obj, active_object=obj,
                                           selected_objects=[obj], selected_editable_objects=[obj]):
                bpy.ops.rigidbody.object_add('EXEC_DEFAULT', False, type='ACTIVE' if relative is not None else 'PASSIVE')
            if relative is not None:
                obj.rigid_body.kinematic = True
                _ragdoll_native_motion(obj, tuple(private_frame(f) for f in motion_frames), [relative[f] if isinstance(relative, dict) else worlds[f] @ relative for f in motion_frames], actions)
            obj.rigid_body.collision_collections=(True,)+(False,)*19
            obj.rigid_body.collision_shape = 'MESH'
            # An ordinary scene mesh has no authored physics material. Use a
            # neutral friction multiplier, so a limb's .35 means .35 against
            # the floor, not .175 after Bullet multiplies it by Blender's .5.
            # Respect materials on surfaces that do have rigid-body settings.
            material = surface.rigid_body
            obj.rigid_body.friction = material.friction if material else 1.0
            obj.rigid_body.restitution = material.restitution if material else 0.0
            obj.rigid_body.use_margin = True
            obj.rigid_body.collision_margin = .004
            yield None
        world = scene.rigidbody_world
        # Resolve initial overlap without turning positional recovery into
        # an upward launch impulse when a Start pose touches the ground.
        world.use_split_impulse = False if clearance.length_squared>1.e-12 else _ragdoll_native_initial_overlap(plan)
        collections = [world.collection, world.constraints]
        world.substeps_per_frame = substeps
        # Resolve articulated contacts with a bounded solver budget.
        # See Catto, Solver2D (2024): prioritize small steps over extra passes.
        world.solver_iterations = 128
        world.point_cache.frame_start = 1
        world.point_cache.frame_end = private_frame(frames[-1])
        layer = scene.view_layers[0]
        capture_frames = {frames[0], *frames[-3:]} if endpoints_only else None
        # Private pre-roll gives Bullet the authored incoming linear/angular
        # velocity before kinematic bodies become dynamic at Start + 1.
        scene.frame_set(2)
        yield None
        control_curves={name:{(fc.data_path,fc.array_index):fc for fc in _action_fcurves(body_objects[name].animation_data.action,body_objects[name])}
                        for name in controls}
        guard_curves={name:{(fc.data_path,fc.array_index):fc for fc in _action_fcurves(guard.animation_data.action,guard)}
                      for name,(guard,_center) in controlled_guards.items()}
        previous_bodies={spec[0]:[(_ragdoll_native_matrix(accelerations['_incoming:'+spec[0]])
                            if '_incoming:'+spec[0] in accelerations else worlds[frames[0]-1]@spec[1])]
                         for spec in specs}
        deadline = time.perf_counter() + .004
        for frame in frames:
            if time.perf_counter() >= deadline:
                yield None
                deadline = time.perf_counter() + .004
            if controls and frame>frames[0]:
                # Advance kinematic handoffs causally from the solved parent.
                # Never feed a previously cached future back into Bullet.
                predicted={name:(history[-1]@history[-2].inverted_safe()@history[-1]
                                 if len(history)>1 else history[-1])
                           for name,history in previous_bodies.items() if history}
                for name,rows in controls.items():
                    if frame not in rows:continue
                    reference=rows[frame][4]
                    parent=predicted.get(reference)
                    if parent is None:parent=worlds[frame] if reference else Matrix.Identity(4)
                    target=_ragdoll_native_control_matrix(rows[frame],parent,predicted)
                    center=next(sp[3] for sp in specs if sp[0]==name)
                    targets=[(control_curves[name],center)]
                    if name in guard_curves:targets.append((guard_curves[name],controlled_guards[name][1]))
                    for channels,center in targets:
                        location,rotation,_scale=(target@Matrix.Translation(center)).decompose()
                        for prop,values in (('location',location),('rotation_quaternion',rotation)):
                            for i,value in enumerate(values):
                                fc=channels.get((prop,i))
                                if fc is not None:
                                    point=_fcurve_key_at(fc,private_frame(frame))
                                    if point is not None:point.co.y=value;fc.update()
            scene.frame_set(private_frame(frame))
            if frame == frames[0]:
                scene.gravity = gravity
                for motor, force in gravity_motors:
                    motor.motor_lin_max_impulse = force
            depsgraph = layer.depsgraph
            # Bullet still solves every timestep/contact. A drag only needs
            # its requested pose and adjacent velocity samples read into RNA.
            if controls:
                for name,body in body_objects.items():
                    history=previous_bodies[name]
                    history.append(body.evaluated_get(depsgraph).matrix_world@Matrix.Translation(-body_centers[name]))
                    del history[:-2]
            if capture_frames is not None and frame not in capture_frames:continue
            driver_transform = (driver.evaluated_get(depsgraph).matrix_world
                                @ Matrix.Translation(-parent_spec[3]))
            driver_scale = worlds[frame].to_scale()
            driver_world = Matrix.LocRotScale(driver_transform.translation,
                driver_transform.to_quaternion(), driver_scale)
            # Project residual socket error toward the prescribed grip. The
            # free island moves; the animated hand must not drift off target.
            grip_shift = Vector()
            for name, body, center, relative, length in bodies:
                row = grabs.get(name, {}).get(frame)
                schedule = accelerations.get('_joint:' + name, ())
                attached = not schedule or next(on for f, on in reversed(schedule) if f <= frame)
                if row and row[0] and attached and release is not None and frame >= release:
                    grip_shift = _ragdoll_native_matrix(row[1]).translation - (driver_world @ relative).translation
                    driver_world.translation += grip_shift
                    break
            for name, body, center, relative, length in bodies:
                transform = body.evaluated_get(depsgraph).matrix_world @ Matrix.Translation(-center)
                if body == driver:
                    transform.translation += grip_shift
                if frame == frames[0]:
                    transform = authored_starts[name]
                orientation = transform.to_quaternion()
                schedule = accelerations.get('_joint:' + name, ())
                detached = bool(schedule and not next(enabled for f, enabled in reversed(schedule) if f <= frame))
                free = body == driver or detached
                # Publish the contact-solved body pose. Projecting its origin
                # back to a perfect socket after solving undid collision work.
                anchor = transform.translation.copy()
                position = anchor + orientation @ Vector((0, length, 0))
                previous = output[name].get(frame-1)
                previous_position=previous['position'].copy() if previous else position.copy()
                previous_anchor=previous['anchor'].copy() if previous else anchor.copy()
                if previous and frame==frames[0]+1:
                    shadow=next(sp[4] for sp in specs if sp[0]==name)
                    previous_anchor=shadow.translation+clearance
                    previous_position=previous_anchor+shadow.to_quaternion()@Vector((0,length,0))
                velocity = (position - previous_position) * fps if previous else Vector()
                output[name][frame] = dict(frame=frame, anchor=anchor.copy(), position=position,
                    previous=previous_position,
                    anchor_previous=previous_anchor,
                    velocity=velocity, orientation=orientation, free=free, seeded=True,
                    anchor_velocity=(anchor-previous_anchor)*fps if previous else Vector(),
                    initial_clearance=clearance.copy() if frame==frames[0]+1 else Vector(),
                    contact_normal=None, contact_point=None, native_joint=True,
                    start_authoritative=(frame == frames[0] or (body == driver and frame == release)),
                    joint_error=(transform.translation-(driver_world@relative).translation).length if not free else 0.)
            yield frame,output
        return output
    finally:
        # Remove all disposable IDs before returning to Blender's undo system.
        if scene.rigidbody_world:
            collections = [scene.rigidbody_world.collection, scene.rigidbody_world.constraints]
        # This scene and every ID below were created locally in this call;
        # none is ever assigned to a window or linked to the user's scene.
        # scenes.remove() invokes editor scene replacement even for a private
        # scene, and crashes when a frame callback has no UI context. Batch
        # deletion releases these owned IDs without that editor operation.
        if any(window.scene == scene for manager in bpy.data.window_managers
               for window in manager.windows):
            raise RuntimeError("Private physics scene unexpectedly attached to a window")
        owned_ids = (scene, *objects, *meshes, *actions,
                     *(collection for collection in collections if collection is not None))
        bpy.data.batch_remove(ids=owned_ids)


@persistent
def _ragdoll_native_cancel_job(*_args):
    _state.pop('ragdoll_native_finishing', None)
    _state.pop('ragdoll_native_prepare_request', None)
    _state.pop('ragdoll_native_collider_pending',None)
    job = _state.pop('ragdoll_native_job', None)
    if job is not None:
        previous = bool(_state.get('ragdoll_syncing'))
        _state['ragdoll_syncing'] = True
        try:
            job['steps'].close()
        finally:
            _state['ragdoll_syncing'] = previous








def _ragdoll_native_should_defer():
    if _state.get('ragdoll_baking') or _state.get('dynamic_space_export_sampling') or bpy.app.background:
        return False
    # Editing must publish the current trajectory before returning. Holding an
    # old orientation until a queued replay matches constantly changing input
    # starves live previews and produces a large release pop.
    if _ragdoll_native_collider_edit() or _state.get('ragdoll_native_collider_pending'):
        return True
    if (_state.get('ragdoll_driver_modal_sessions')
            or _state.get('ragdoll_key_transform_active')):
        return False
    return (_ragdoll_interactive_replay() and not _state.get('dynamic_space_export_sampling')
            and (_animation_playback_active(bpy.context)
                 or _state.get('ragdoll_native_finishing', False)
                 or _state.get('ragdoll_native_preparing', False)
                 or _state.get('ragdoll_config_syncing', False)
                 or _state.get('ragdoll_native_job', {}).get('interactive_edit', False)))


def _ragdoll_native_horizon(armature, driver, target):
    """Keep one world through the current run, instead of restarting every 10s."""
    if _ragdoll_native_collider_edit() or _state.get('ragdoll_native_collider_pending'):
        if _animation_playback_active(bpy.context):
            fps=bpy.context.scene.render.fps/max(1.e-6,bpy.context.scene.render.fps_base)
            return min(int(bpy.context.scene.frame_end),int(target)+max(2,int(fps/2)))
        return int(target)
    end = max(int(target), int(bpy.context.scene.frame_end))
    # A changed active set starts a different island. Do not plan past it.
    for bone in (driver, *(b for b in armature.pose.bones if _ragdoll_parent(armature, b) == driver)):
        for curve in _ragdoll_curves(armature, bone):
            for point in curve.keyframe_points:
                boundary = int(round(point.co.x))
                if boundary > target and _special_event_value(curve, point) < .5:
                    end = min(end, boundary - 1)
    return end


def _ragdoll_native_prepare_playback(scene):
    """Extend simulation only while playback is inside its physical interval."""
    if (_state.get('ragdoll_native_job') or _state.get('ragdoll_native_prepare_request')
            or _state.get('ragdoll_syncing')
            or not _ragdoll_interactive_replay() or not _animation_playback_active(bpy.context)):
        return
    now = time.perf_counter()
    if now - _state.get('ragdoll_native_prepare_checked', 0.) < .2:
        return
    _state['ragdoll_native_prepare_checked'] = now
    frame = int(scene.frame_current)
    for owner in scene.objects:
        if owner.type != 'ARMATURE' or not owner.pose:
            continue
        active = tuple(b for b in _ragdoll_active_bones_hierarchy_order(owner, frame)
                       if (start := _ragdoll_active_start_frame(owner, b, frame)) is not None
                       and frame > start)
        target = frame
        if not active:
            # Building a private world can exceed a display frame even when
            # its later integration yields. Never charge that cold work to
            # ordinary animation ahead of a future Start.
            continue
        driver = active[0] if any(_ragdoll_parent(owner, b) == active[0] for b in active[1:]) else _ragdoll_parent(owner, active[0])
        if driver is None:
            continue
        start = _ragdoll_active_start_frame(owner, active[-1], target)
        target = max(target, int(round(start)) + 1) if start is not None else target
        _state['ragdoll_native_prepare_request'] = (scene.name_full, owner.name_full, driver.name, target)
        if not bpy.app.timers.is_registered(_ragdoll_native_prepare_timer):
            register_owned_timer(_ragdoll_native_prepare_timer, first_interval=.001)
        return


def _ragdoll_native_prepare_timer():
    request = _state.get('ragdoll_native_prepare_request')
    if request is None:
        return None
    if not _animation_playback_active(bpy.context):
        _state.pop('ragdoll_native_prepare_request', None)
        return None
    if _pin_primary_mouse_pressed() or _pin_active_transform_operator(bpy.context):
        return .02
    _state.pop('ragdoll_native_prepare_request', None)
    scene = bpy.context.scene
    owner = scene.objects.get(request[1]) if scene.name_full == request[0] else None
    driver = owner.pose.bones.get(request[2]) if owner and owner.pose else None
    if driver is None:
        return None
    if not any((start := _ragdoll_active_start_frame(owner, bone, int(scene.frame_current)))
               is not None and scene.frame_current > start
               for bone in _ragdoll_active_bones_hierarchy_order(owner, int(scene.frame_current))):
        return None
    # A private world has native dependency costs even while its timer yields.
    # Start it near the available boundary, not on every cached playback just
    # because the distant end of the timeline has not been simulated yet.
    fps=scene.render.fps/max(1.e-6,scene.render.fps_base)
    ahead=min(_ragdoll_native_horizon(owner,driver,request[3]),
              max(int(scene.frame_current),request[3])+max(2,int(fps/2)))
    inputs = _ragdoll_native_fast_inputs(owner, driver, frame=request[3])
    if inputs is not None and _ragdoll_native_fast_restore(owner, driver,
            ahead, inputs, publish=False):
        _state['ragdoll_native_prepare_cache_hits'] = _state.get('ragdoll_native_prepare_cache_hits', 0) + 1
        return None
    _state['ragdoll_native_preparing'] = True
    try:
        _ragdoll_native_branch(owner, driver, request[3])
    finally:
        _state.pop('ragdoll_native_preparing', None)
    return None


def _ragdoll_native_job_cache(job,output,frame):
    cached=job.get('cached')
    if cached is None:
        cached=dict(signature=job['signature'],samples=(),output=output,streaming=True)
        job['cached']=cached
    cached['through'] = int(frame)
    cached['samples']=job['samples'][:int(frame)-job['start']+1]
    _state.setdefault('ragdoll_native_solutions',{})[job['key']+(job['preview'],)]=cached
    return cached


def _ragdoll_native_remember_cache(job,cached):
    cached['streaming']=False
    history=_state.setdefault('ragdoll_native_solutions',{}).setdefault(job['key']+('history',),[])
    history[:]=[candidate for candidate in history if candidate is not cached]
    history.insert(0,cached);del history[4:]


def _ragdoll_native_advance_job(job,target):
    """Advance the live native world only through the requested display frame.

    Blender's no-drop clock already slows when its frame callback takes longer.
    Rewinding scene.frame_current from inside that callback fights the playback
    timer and can leave it marked playing while the cursor stops advancing.
    """
    cached=job.get('cached')
    if cached and all(target in rows for rows in cached['output'].values()):return cached
    while True:
        try:sample=next(job['steps'])
        except StopIteration as finished:
            if _state.get('ragdoll_native_job') is job:_state.pop('ragdoll_native_job',None)
            cached=_ragdoll_native_job_cache(job,finished.value,job['end'])
            _ragdoll_native_remember_cache(job,cached)
            return cached
        except Exception:
            _ragdoll_native_cancel_job()
            raise
        if sample is not None:
            frame,output=sample
            cached=_ragdoll_native_job_cache(job,output,frame)
            if frame>=target:
                if frame>=job['end']:
                    _ragdoll_native_remember_cache(job,cached)
                    _ragdoll_native_cancel_job()
                return cached


def _ragdoll_native_job_timer():
    job=_state.get('ragdoll_native_job')
    if job is None:return None
    owner=bpy.context.scene.objects.get(job['key'][0])
    if owner is None or owner.mode=='EDIT':
        _ragdoll_native_cancel_job();return None
    if _animation_playback_active(bpy.context):
        if bpy.context.scene.frame_current <= job['start']:
            # A rewind/loop can leave an in-flight job. Do not spend its
            # cooperative slices on frames before physics owns the pose.
            return .05
        # Rebuild a closed cached prefix while it is still being displayed,
        # then retain the very same Bullet world for new frames. Each slice
        # yields to native input. No cached pose seeds a fresh physics state.
        if not job.get('collider_edit') and (_pin_primary_mouse_pressed() or _pin_active_transform_operator(bpy.context)):
            return .02
        cached = job.get('cached')
        ahead = int(bpy.context.scene.frame_current) + max(2, int(bpy.context.scene.render.fps / bpy.context.scene.render.fps_base))
        if cached and all(max(rows) >= min(job['end'], ahead) for rows in cached['output'].values()):
            return .01
        previous = bool(_state.get('ragdoll_syncing'))
        _state['ragdoll_syncing'] = True
        try:
            # Cached playback shares this thread with native drawing/input.
            # Use one short cooperative slice; the frame handler still solves
            # every required step if playback reaches an uncached pose.
            deadline = time.perf_counter() + .002
            while True:
                try:
                    sample = next(job['steps'])
                except StopIteration as finished:
                    cached = _ragdoll_native_job_cache(job, finished.value, job['end'])
                    if _ragdoll_native_collider_completed(job,cached):return None
                    _ragdoll_native_remember_cache(job, cached)
                    _state.pop('ragdoll_native_job', None)
                    return None
                if sample is not None:
                    solved, output = sample
                    _ragdoll_native_job_cache(job, output, solved)
                    if solved >= job['end']:
                        if _ragdoll_native_collider_completed(job,job['cached']):return None
                        _ragdoll_native_remember_cache(job, job['cached'])
                        _ragdoll_native_cancel_job()
                        return None
                if time.perf_counter() >= deadline:
                    break
        except Exception:
            _ragdoll_native_cancel_job()
            raise
        finally:
            _state['ragdoll_syncing'] = previous
        return .001
    scene=bpy.context.scene
    cached=job.get('cached')
    if (scene.name_full==job['scene'] and cached
            and (scene.frame_current<=job['start'] or all(scene.frame_current in rows for rows in cached['output'].values()))):
        if _ragdoll_native_collider_completed(job,cached):return None
        _ragdoll_native_remember_cache(job,cached)
        _ragdoll_native_cancel_job()
        return None
    if not job.get('collider_edit') and (_pin_primary_mouse_pressed() or _pin_active_transform_operator(bpy.context)):
        # A slider press or a new handle click owns input until release. It
        # must not discard a partial property replay and force it to restart.
        return .02
    if not _ragdoll_native_should_defer():
        if _ragdoll_interactive_replay() and not _state.get('dynamic_space_export_sampling'):
            _state['ragdoll_native_finishing']=True
        else:_ragdoll_native_cancel_job();return None
    previous=bool(_state.get('ragdoll_syncing'));_state['ragdoll_syncing']=True
    completed=None;sample=None
    try:
        deadline = time.perf_counter() + .008
        while True:
            sample=next(job['steps'])
            if sample is not None:
                frame, output = sample
                _ragdoll_native_job_cache(job, output, frame)
                if all(scene.frame_current in rows for rows in output.values()):
                    break
            if time.perf_counter() >= deadline:
                break
    except StopIteration as finished:
        completed=finished.value;_state.pop('ragdoll_native_job',None)
    except Exception:
        _ragdoll_native_cancel_job();raise
    finally:_state['ragdoll_syncing']=previous
    if sample is not None:
        frame,output=sample;cached=_ragdoll_native_job_cache(job,output,frame)
        # Stop and scrub finish only the requested pose. Do not simulate the
        # rest of the timeline while the user resumes editing a stopped rig.
        scene=bpy.context.scene
        if (not _animation_playback_active(bpy.context) and scene.name_full==job['scene']
                and (scene.frame_current<=job['start'] or all(scene.frame_current in rows for rows in output.values()))):
            if _ragdoll_native_collider_completed(job,cached):return None
            _ragdoll_native_scene(scene)
            _ragdoll_native_remember_cache(job,cached)
            _ragdoll_native_cancel_job()
            return None
    if completed is None:return .001
    cached=_ragdoll_native_job_cache(job,completed,job['end'])
    if _ragdoll_native_collider_completed(job,cached):return None
    _ragdoll_native_remember_cache(job,cached)
    scene=bpy.context.scene
    if scene.name_full==job['scene']:_ragdoll_native_scene(scene)
    if _state.get('ragdoll_native_job') is not None:return .001
    _state.pop('ragdoll_native_finishing',None)
    return None


def _ragdoll_native_plan_signature(plan, fps):
    frames, worlds, specs, statics, gravity, release, accelerations = plan
    return (_RAGDOLL_NATIVE_REVISION,fps, frames[0], tuple(gravity), release,
        tuple(v for row in worlds[frames[0]-1] for v in row),
        tuple((name, tuple(value)) for name, value in accelerations.items() if not name.startswith(('_grab:','_control:'))),
        tuple((name, tuple(v for row in relative for v in row), _ragdoll_native_packed_points(points), damping, friction, bounce, length)
              for name, relative, points, center, rigid, damping, friction, bounce, length in specs),
        tuple((o.name_full, geometry,
               (o.rigid_body.friction, o.rigid_body.restitution) if o.rigid_body else (1.0, 0.0),
               ('animated',) if isinstance(relative, dict) else tuple(v for row in (relative if relative is not None else m) for v in row))
              for o,m,relative,geometry in statics))


def _ragdoll_native_queue_job(plan, fps, key, signature, samples, *, preview=False):
    collider_edit=bool(_ragdoll_native_collider_edit() or _state.get('ragdoll_native_collider_pending'))
    existing = _state.get('ragdoll_native_job')
    if existing is not None:
        common=min(len(existing['samples']),len(samples))
        same_inputs=(existing['key']==key and _ragdoll_native_equal(existing['signature'],signature)
            and _ragdoll_native_equal(existing['samples'][:common],samples[:common]))
        held_collider=_ragdoll_native_collider_edit()
        if collider_edit and existing.get('collider_edit') and existing['key']==key and (
                same_inputs or (held_collider and (existing['end']==plan[0][-1] or (
                    _animation_playback_active(bpy.context) and bpy.context.scene.frame_current<=existing['end'])))):
            # Finish one bounded generation instead of restarting it on every
            # mouse move. Reconcile immediately against the newest input after
            # publication; native Undo/cancel still closes the owned worker.
            return
        if (existing['key']==key and _ragdoll_native_equal(existing['signature'],signature)
                and len(existing['samples'])>=len(samples)
                and _ragdoll_native_equal(existing['samples'][:len(samples)],samples)):return
        # A topology/input change cannot wait behind a stale ten-second job.
        _ragdoll_native_cancel_job()
    sparse=bool(preview or (collider_edit and not _animation_playback_active(bpy.context))
        or _state.get('ragdoll_native_sparse_replay') or _state.get('ragdoll_key_transform_active')
        or _state.get('ragdoll_config_syncing') or _state.get('ragdoll_native_finishing'))
    _state['ragdoll_native_job'] = dict(key=key, scene=bpy.context.scene.name_full,start=plan[0][0],end=plan[0][-1],
        sparse=sparse,
        collider_edit=collider_edit,
        signature=signature, samples=samples, preview=preview,
        plan_signature=_ragdoll_native_plan_signature(plan, fps),
        frozen_inputs=(_ragdoll_native_fast_inputs(owner,driver)
            if not preview and (owner:=bpy.context.scene.objects.get(key[0])) is not None
            and (driver:=owner.pose.bones.get(key[1])) is not None else None),
        interactive_edit=bool(_state.get('ragdoll_config_syncing') or _state.get('ragdoll_native_finishing')),
        steps=_ragdoll_native_replay_steps(plan, fps, endpoints_only=sparse))
    if collider_edit:_state['ragdoll_native_collider_pending']=(bpy.context.scene.name_full,*key,plan[0][-1])
    if not bpy.app.timers.is_registered(_ragdoll_native_job_timer):
        register_owned_timer(_ragdoll_native_job_timer, first_interval=.001)


def _ragdoll_native_equal(left, right):
    """Ignore only matrix-evaluation roundoff, not meaningful input changes."""
    if left == right:
        return True
    stack = [(left, right)]
    while stack:
        a, b = stack.pop()
        if isinstance(a, (tuple, list)):
            if not isinstance(b, (tuple, list)) or len(a) != len(b):
                return False
            stack.extend(zip(a, b))
        elif isinstance(a, float) and isinstance(b, (float, int)):
            if abs(a - b) > 1e-5:
                return False
        elif a != b:
            return False
    return True


def _ragdoll_native_grab_islands(owner, driver, frame):
    if driver is None:
        return ()
    targets = {}
    for rig in bpy.context.scene.objects:
        if rig == owner or rig.type != 'ARMATURE':
            continue
        for bone in _ragdoll_active_bones_hierarchy_order(rig, frame):
            for constraint in _dynamic_constraints(bone):
                if not constraint.name.startswith('DP_') or _dynamic_parent_constraint_target(bone, constraint) != owner:
                    continue
                start, _end = _dynamic_parent_constraint_segment(bone, constraint)
                target = owner.pose.bones.get(_dynamic_parent_constraint_subtarget(bone, constraint))
                if start is None or start > frame or target is None:
                    continue
                if target != driver and driver not in target.parent_recursive:
                    continue
                root = _ragdoll_parent(rig, bone)
                if root is not None:
                    targets[(rig.name_full, root.name)] = (rig, root)
    return tuple(targets.values())


def _ragdoll_native_branch(armature, driver, target, *, preview=False):
    # Input geometry/Action sampling can flush the depsgraph too. Guard the
    # entire transaction, not only Bullet replay and final pose publication.
    # Otherwise an active G transform re-enters preview while planning it.
    previous_syncing = bool(_state.get('ragdoll_syncing'))
    previous_native = bool(_state.get('ragdoll_native_evaluating'))
    _state['ragdoll_native_evaluating'] = True
    _state['ragdoll_syncing'] = True
    own_indexes = 'ragdoll_native_channel_indexes' not in _state
    if own_indexes:
        _state['ragdoll_native_channel_indexes'] = {}
    previous = _state.get('ragdoll_evaluation_curves')
    if previous is None:
        _state['ragdoll_evaluation_curves'] = {}
    previous_controller = _state.get('ragdoll_native_controller_preview')
    own_preview_actions = preview and 'ragdoll_native_preview_actions' not in _state
    if own_preview_actions:
        _state['ragdoll_native_preview_actions']={}
    try:
        if preview:
            _state['ragdoll_native_controller_preview'] = (armature.name_full, driver.name, int(target))
        islands = _ragdoll_native_grab_islands(armature, driver, target)
        if islands:
            return all(_ragdoll_native_branch_impl(rig, root, target, preview=preview) for rig, root in islands)
        return _ragdoll_native_branch_impl(armature, driver, target, preview=preview)
    finally:
        if own_preview_actions:
            for action,curves in _state.pop('ragdoll_native_preview_actions').values():
                bpy.data.actions.remove(action)
        if previous_controller is None:
            _state.pop('ragdoll_native_controller_preview', None)
        else:
            _state['ragdoll_native_controller_preview'] = previous_controller
        if own_indexes:
            _state.pop('ragdoll_native_channel_indexes', None)
        if previous is None:
            _state.pop('ragdoll_evaluation_curves', None)
        _state['ragdoll_syncing'] = previous_syncing
        _state['ragdoll_native_evaluating'] = previous_native








def _ragdoll_native_branch_impl(armature, driver, target, *, preview=False):
    # The evaluated planner rejects constrained ancestors too. Check this
    # before rebuilding its whole-scene fast-input signature every frame.
    if any(bone.constraints for bone in (driver, *driver.parent_recursive)):
        return False
    if not _state.get('ragdoll_native_job'):
        # A finished/cancelled worker cannot own a later edit or playback.
        _state.pop('ragdoll_native_finishing', None)
    # There may be a suspended playback/stop replay when an ordinary RNA
    # edit requests an immediate solve (no modal session or key-drag flag).
    # Creating/removing a second scratch world can invalidate the suspended
    # Bullet world's collision state during graph rebuilds. Never keep
    # that world alive across a synchronous replay, including cache hits.
    if (_state.get('ragdoll_native_job')
            and (preview or _state.get('ragdoll_key_transform_active')
                 or not _ragdoll_native_should_defer())):
        _ragdoll_native_cancel_job()
    fast_inputs=None
    if (not preview and not _pin_active_transform_operator(bpy.context)
            and not _state.get('ragdoll_key_transform_active') and not _state.get('ragdoll_config_syncing')
            and not _state.get('ragdoll_native_preparing') and not _state.get('ragdoll_native_finishing')
            and not _state.get('ragdoll_native_collider_pending')):
        fast_inputs=_ragdoll_native_fast_inputs(armature,driver)
        if fast_inputs is not None:
            if _ragdoll_native_fast_restore(armature,driver,int(target),fast_inputs):return True
            if _ragdoll_native_fast_resume(armature,driver,int(target),fast_inputs):return True
    plan = _ragdoll_native_plan(armature, driver, int(target), preview)
    if plan is None:
        return False
    frames, worlds, specs, statics, gravity, release, accelerations = plan
    fps = bpy.context.scene.render.fps / max(1e-6, bpy.context.scene.render.fps_base)
    endpoints_only = (preview or bool(_state.get('ragdoll_native_sparse_replay'))
                      or bool(_state.get('ragdoll_key_transform_active'))
                      or bool(_state.get('ragdoll_config_syncing'))
                      or bool(_state.get('ragdoll_native_finishing')) or (
                          (_ragdoll_native_collider_edit() or _state.get('ragdoll_native_collider_pending'))
                          and not _animation_playback_active(bpy.context)))
    signature = _ragdoll_native_plan_signature(plan, fps)
    samples = _ragdoll_native_samples(plan)
    key = (armature.name_full, driver.name)
    solutions = _state.setdefault('ragdoll_native_solutions', {})
    history = solutions.setdefault(key + ('history',), [])
    candidates = [solutions.get(key + (preview,)), solutions.get(key + (not preview,)), *history]
    cached = next((candidate for candidate in candidates if candidate
        and len(candidate['samples']) >= len(samples)
        and _ragdoll_native_equal(candidate['samples'][len(samples)-1], samples[-1])
        and _ragdoll_native_equal(candidate['signature'], signature)
        and _ragdoll_native_equal(candidate['samples'][:len(samples)], samples)
        and all(int(target) in states for states in candidate['output'].values())), None)
    preparing = bool(_state.get('ragdoll_native_preparing'))
    if preparing and cached is not None and all(
            max(rows) >= _ragdoll_native_horizon(armature, driver, target)
            for rows in cached['output'].values()):
        return True
    if cached is not None and not preparing:
        output = cached['output']
    else:
        job=_state.get('ragdoll_native_job')
        reuse_job=bool(job and job['key']==key and job['end']>=int(target)
            and _ragdoll_native_equal(job['signature'],signature)
            and len(job['samples'])>=len(samples)
            and _ragdoll_native_equal(job['samples'][:len(samples)],samples))
        if not endpoints_only and not reuse_job:
            horizon = min(int(bpy.context.scene.frame_end), int(target) + max(8, int(fps / 2)))
            if _ragdoll_native_should_defer() or _state.get('dynamic_space_export_sampling'):
                horizon = _ragdoll_native_horizon(armature, driver, target)
            if horizon > int(target):
                extended = _ragdoll_native_plan(armature, driver, horizon, False)
                if extended is None and _ragdoll_native_should_defer():
                    horizon=min(int(bpy.context.scene.frame_end),int(target)+max(8,int(fps/2)))
                    extended=_ragdoll_native_plan(armature,driver,horizon,False)
                if (extended is not None and extended[0][0] == frames[0]
                        and tuple(spec[0] for spec in extended[2]) == tuple(spec[0] for spec in specs)):
                    plan = extended
                    frames, worlds = plan[:2]
                    samples = _ragdoll_native_samples(plan)
        if _ragdoll_native_should_defer():
            _ragdoll_native_queue_job(plan, fps, key, signature, samples, preview=preview)
            if preparing:
                return True
            if _animation_playback_active(bpy.context):
                job=_state['ragdoll_native_job']
                if job.get('collider_edit'):
                    # Keep the animation clock and every displayed pose on the
                    # same frame while a changed obstacle generation catches
                    # up. Never drain Start->cursor inside a mouse event.
                    candidate=job.get('cached')
                    if not candidate or not all(int(target) in states for states in candidate['output'].values()):
                        candidate=next((entry for entry in candidates if entry and
                            all(int(target) in states for states in entry['output'].values())),None)
                    if candidate is None:return _ragdoll_restore_cached_frame(bpy.context.scene)
                    cached=candidate
                else:
                    cached=_ragdoll_native_advance_job(job,int(target))
                output=cached['output']
            else:
            # Keep one coherent completed pose until the exact solve is ready.
                states = _state.get('ragdoll_states', {})
                bones = tuple(b for b in _ragdoll_active_bones_hierarchy_order(armature, target)
                              if _ragdoll_state_key(armature, b) in states)
                if bones:
                    held_frame = min(int(states[_ragdoll_state_key(armature,b)]['frame']) for b in bones)
                    _ragdoll_restore_applied_states(armature, bones, held_frame)
                return True
        else:
            syncing = bool(_state.get('ragdoll_syncing'))
            _state['ragdoll_syncing'] = True
            try:
                output = (_ragdoll_native_replay(plan, fps, endpoints_only=True) if endpoints_only
                          else _ragdoll_native_replay(plan, fps))
            finally:
                _state['ragdoll_syncing'] = syncing
            cached = dict(signature=signature, samples=samples, output=output, through=frames[-1])
            solutions[key + (preview,)] = cached
            if not preview:
                # Bounded plain-math generations survive native undo.
                history.insert(0, cached)
                del history[4:]
    bones = tuple(armature.pose.bones[name] for name in output
                  if _ragdoll_active(armature.pose.bones[name], int(target)))
    for bone in bones:
        state_key = _ragdoll_state_key(armature, bone)
        _state.setdefault('ragdoll_states', {})[state_key] = {k: v.copy() if hasattr(v, 'copy') else v for k,v in output[bone.name][int(target)].items()}
        if preview:
            origin = _state.get('ragdoll_native_controller_preview') or (armature.name_full, driver.name, int(target))
            _state.setdefault('ragdoll_live_preview_states', {})[state_key] = (origin, output[bone.name][int(target)])
        if not preview:
            caches = _state.setdefault('ragdoll_frame_cache', {})
            published = cached.setdefault('published', {})
            # Copy once per generation. Runtime states own their vectors;
            # cached playback must not clone every historical body each tick.
            until=cached.setdefault('published_until',{})
            if state_key not in caches or caches[state_key] is not published.get(bone.name):
                caches[state_key]={};published[bone.name]=caches[state_key];until[bone.name]=frames[0]-1
            latest=max(output[bone.name])
            for frame in range(until.get(bone.name,frames[0]-1)+1,latest+1):
                state=output[bone.name].get(frame)
                if state is not None:caches[state_key][frame]={k:v.copy() if hasattr(v,'copy') else v for k,v in state.items()}
            until[bone.name]=latest
    syncing = bool(_state.get('ragdoll_syncing'))
    _state['ragdoll_syncing'] = True
    try:
        if (_state.get('ragdoll_key_transform_active')
                and not _ragdoll_active(driver, int(target))):
            # Display the same finalized driver trajectory used by Bullet.
            # Otherwise its native temporary-handle pose disagrees with the
            # simulated sockets until the Dope Sheet confirms the transform.
            desired = armature.matrix_world.inverted_safe() @ worlds[int(target)]
            if max(abs(driver.matrix[r][c] - desired[r][c])
                   for r in range(4) for c in range(4)) > 1.e-6:
                driver.matrix = desired
                bpy.context.view_layer.update()
        _ragdoll_restore_applied_states(armature, bones, int(target))
    finally:
        _state['ragdoll_syncing'] = syncing
    if not preview:
        _state.pop('ragdoll_scrub_job', None)
        _state['ragdoll_pending_resimulation'] = None
        _state.setdefault('ragdoll_driver_curve_signatures', {})[(armature.name_full, driver.name)] = _ragdoll_driver_curve_signature(armature, driver)
        _state.setdefault('ragdoll_driver_preview_signatures', {})[
            (armature.name_full, driver.name, int(target))] = _ragdoll_driver_pose_signature(driver, target)
        if fast_inputs is not None:
            _ragdoll_native_fast_store(armature,driver,fast_inputs,cached,validated_samples=samples,
                validated_signature=_ragdoll_native_plan_signature(plan,fps))
    return True


def _ragdoll_native_scene(scene):
    read_scope = _special_read_begin()
    own_indexes = 'ragdoll_native_channel_indexes' not in _state
    if own_indexes:
        _state['ragdoll_native_channel_indexes'] = {}
    previous = _state.get('ragdoll_evaluation_curves')
    if previous is None:
        _state['ragdoll_evaluation_curves'] = {}
    try:
        return _ragdoll_native_scene_impl(scene)
    finally:
        _special_read_end(read_scope)
        if own_indexes:
            _state.pop('ragdoll_native_channel_indexes', None)
        if previous is None:
            _state.pop('ragdoll_evaluation_curves', None)


def _ragdoll_native_scene_impl(scene):
    """Handle compatible connected branches before scheduling historical RNA work."""
    if bpy.context.mode!='EDIT_ARMATURE':
        for guide in _gyro_guides(scene):_gyro_sync_constraint_mask(bpy.context,guide)
    targets = []
    frame = int(scene.frame_current)
    for owner in scene.objects:
        if owner.type != 'ARMATURE' or not owner.pose:
            continue
        bones = tuple(_ragdoll_active_bones_hierarchy_order(owner, frame))
        if not bones:
            continue
        parent = bones[0] if any(_ragdoll_parent(owner, b) == bones[0] for b in bones[1:]) else _ragdoll_parent(owner, bones[0])
        if parent is None or any(b != parent and _ragdoll_parent(owner, b) != parent for b in bones):
            return False
        targets.append((owner, parent))
    if not targets:
        return False
    # A pending native transform owns its island through confirmation/cancel.
    # Action/depsgraph echoes must not publish the pre-drag trajectory over it.
    sessions = tuple(session for session in (() if _state.get('ragdoll_baking') else _state.get('ragdoll_driver_modal_sessions', {}).values())
                     if int(session.get('frame', -1)) == frame)
    preview_drivers = {}
    for session in sessions:
        edited_owner = scene.objects.get(session.get('armature', ''))
        if edited_owner is None or edited_owner.type != 'ARMATURE':
            continue
        edited = edited_owner.pose.bones.get(session.get('bone', ''))
        if edited is None:
            continue
        islands = _ragdoll_native_grab_islands(edited_owner, edited, frame)
        for owner, driver in targets:
            if (owner == edited_owner and driver == edited) or (owner, driver) in islands:
                preview_drivers[(owner.name_full, driver.name)] = (edited_owner, edited)
    for owner, driver in targets:
        edited = preview_drivers.get((owner.name_full, driver.name))
        if edited is not None:
            if not _ragdoll_native_branch(*edited, frame, preview=True):
                return False
        elif not _ragdoll_native_branch(owner, driver, frame):
            return False
    _sync_all_dynamic_pose_bone_colors(frame)
    return True
