"""Deterministic keyed pose-bone ragdoll simulation."""

from ..core.runtime import *  # noqa: F403


_RAGDOLL_TRANSFORM_SUFFIXES = (
    "location",
    "rotation_euler",
    "rotation_quaternion",
    "rotation_axis_angle",
    "scale",
)
_RAGDOLL_BASELINE_KEYS_PROPERTY = "_staticaliza_ragdoll_baseline_keys"
_RAGDOLL_AUTHORED_FRAMES_PROPERTY = "_staticaliza_ragdoll_authored_frames"
_RAGDOLL_START_POSES_PROPERTY = "_staticaliza_ragdoll_start_poses"
_RAGDOLL_CHAIN_DAMPING = 0.97
_RAGDOLL_LEGACY_CHAIN_DAMPINGS = (0.985, 0.992, 0.995, 0.999)
_RAGDOLL_UNIFORM_ROD_GRAVITY_FACTOR = 1.5
_RAGDOLL_LEGACY_DEFAULT_WEIGHT = 9.80665
_RAGDOLL_DEFAULT_WEIGHT = 100.0
_RAGDOLL_WEIGHT_ACCELERATION_SCALE = 2.5
_RAGDOLL_EARTH_GRAVITY = 9.80665

_RAGDOLL_AXIS_VECTORS = {
    "X_POS": Vector((1.0, 0.0, 0.0)),
    "X_NEG": Vector((-1.0, 0.0, 0.0)),
    "Y_POS": Vector((0.0, 1.0, 0.0)),
    "Y_NEG": Vector((0.0, -1.0, 0.0)),
    "Z_POS": Vector((0.0, 0.0, 1.0)),
    "Z_NEG": Vector((0.0, 0.0, -1.0)),
}


def _ragdoll_debug_event(event, **fields):
    if not bool(_state.get("ragdoll_debug_enabled", False)):
        return
    # Runtime probes already capture every body's frame/state/cache summary.
    # Per-body before/after events multiplied Python allocation and JSON
    # pressure by active_bones * playback_frames without adding diagnostic
    # information. Keep transition/collision/ownership events only.
    if event in {"depsgraph_blocked", "frame_step_before", "frame_step_after"}:
        return
    now = time.monotonic()
    sequence = int(_state.get("ragdoll_debug_sequence", 0)) + 1
    _state["ragdoll_debug_sequence"] = sequence
    record = {
        "sequence": sequence,
        "event": str(event),
        "time": now,
    }
    record.update(fields)
    events = _state.setdefault("ragdoll_debug_events", [])
    events.append(record)
    del events[:-256]


def _ragdoll_gravity(pose_bone):
    axis = str(getattr(pose_bone, RAGDOLL_GRAVITY_AXIS_RNA, "Z_NEG"))
    acceleration = float(
        getattr(pose_bone, RAGDOLL_ACCELERATION_RNA, _RAGDOLL_DEFAULT_WEIGHT)
    )
    return _RAGDOLL_AXIS_VECTORS.get(axis, _RAGDOLL_AXIS_VECTORS["Z_NEG"]) * (acceleration * _RAGDOLL_WEIGHT_ACCELERATION_SCALE)


def _ragdoll_hinge_gravity(pose_bone):
    """Use the artist-facing Weight as signed hinge acceleration."""
    return _ragdoll_gravity(pose_bone)


def _ragdoll_unparented(armature, pose_bone, frame):
    evaluation = _state.get("ragdoll_evaluation_curves")
    if evaluation is None:
        return _ragdoll_unparented_uncached(armature, pose_bone, frame)
    key = ("unparented", armature.as_pointer(), pose_bone.name, int(frame))
    if key not in evaluation:
        evaluation[key] = _ragdoll_unparented_uncached(armature, pose_bone, frame)
    return evaluation[key]


def _ragdoll_unparented_uncached(armature, pose_bone, frame):
    return _unparent_eval(
        _ragdoll_action(armature),
        pose_bone.name,
        int(frame),
        pb_default=float(pose_bone.get(UNP_PROP, 0.0)),
    ) >= 0.5


def _ragdoll_parent(armature, pose_bone):
    parent = getattr(pose_bone, "parent", None)
    if parent is not None:
        return parent
    parent_name = str(pose_bone.bone.get(REL_K_PARENT, ""))
    return armature.pose.bones.get(parent_name) if parent_name else None


def _ragdoll_hierarchy_depth(armature, pose_bone):
    depth = 0
    visited = {pose_bone.name}
    parent = _ragdoll_parent(armature, pose_bone)
    while parent is not None and parent.name not in visited:
        visited.add(parent.name)
        depth += 1
        parent = _ragdoll_parent(armature, parent)
    return depth


def _ragdoll_has_active_descendant(armature, pose_bone, frame):
    for candidate in armature.pose.bones:
        if candidate == pose_bone or not _ragdoll_active(candidate, frame):
            continue
        visited = {candidate.name}
        parent = _ragdoll_parent(armature, candidate)
        while parent is not None and parent.name not in visited:
            if parent == pose_bone:
                return True
            visited.add(parent.name)
            parent = _ragdoll_parent(armature, parent)
    return False


def _ragdoll_is_ancestor(armature, ancestor, descendant):
    visited = {descendant.name}
    parent = _ragdoll_parent(armature, descendant)
    while parent is not None and parent.name not in visited:
        if parent == ancestor:
            return True
        visited.add(parent.name)
        parent = _ragdoll_parent(armature, parent)
    return False


def _ragdoll_free(armature, pose_bone, frame):
    evaluation = _state.get("ragdoll_evaluation_curves")
    if evaluation is None:
        return _ragdoll_free_uncached(armature, pose_bone, frame)
    key = ("free", armature.as_pointer(), pose_bone.name, int(frame))
    if key not in evaluation:
        evaluation[key] = _ragdoll_free_uncached(armature, pose_bone, frame)
    return evaluation[key]


def _ragdoll_free_uncached(armature, pose_bone, frame):
    """Release explicit blue bones and the body directly below the locked root."""
    if _ragdoll_unparented(armature, pose_bone, frame):
        return True
    parent = _ragdoll_parent(armature, pose_bone)
    return bool(
        parent is not None
        and (
            _strip_blender_numeric_suffix(parent.name).casefold() == "humanoidrootpart"
            or _is_roblox_structural_root_bone(armature, parent.bone)
        )
        and not _is_roblox_weld_bone(armature, pose_bone.bone)
    )


def _ragdoll_active_bones_hierarchy_order(armature, frame):
    return tuple(sorted(
        (
            pose_bone for pose_bone in armature.pose.bones
            if _ragdoll_active(pose_bone, int(frame))
        ),
        key=lambda pose_bone: (
            _ragdoll_hierarchy_depth(armature, pose_bone),
            pose_bone.name.casefold(),
        ),
    ))


def _ragdoll_active_island_root(armature, pose_bone, frame):
    root = pose_bone
    parent = _ragdoll_parent(armature, root)
    while parent is not None and _ragdoll_active(parent, frame):
        root = parent
        parent = _ragdoll_parent(armature, root)
    return root


def _ragdoll_surface_pose_bone(surface, armature):
    evaluation = _state.get("ragdoll_evaluation_curves")
    if evaluation is None:
        return _ragdoll_surface_pose_bone_uncached(surface, armature)
    key = ("surface_owner", armature.as_pointer(), surface.as_pointer())
    if key not in evaluation:
        evaluation[key] = _ragdoll_surface_pose_bone_uncached(surface, armature)
    return evaluation[key]


def _ragdoll_surface_pose_bone_uncached(surface, armature):
    def physical_owner(candidate):
        visited = set()
        while candidate is not None and candidate.name not in visited:
            visited.add(candidate.name)
            try:
                is_weld_helper = _is_roblox_weld_bone(
                    armature, candidate.bone
                )
            except (AttributeError, ReferenceError, RuntimeError, TypeError):
                is_weld_helper = False
            if not is_weld_helper:
                return candidate
            parent = _ragdoll_parent(armature, candidate)
            if parent is None:
                return candidate
            candidate = parent
        return candidate

    try:
        bound_armature, bound_name = _surface_contact_explicit_bone_binding(
            surface
        )
        if bound_armature == armature and bound_name:
            candidate = armature.pose.bones.get(str(bound_name))
            if candidate is not None:
                return physical_owner(candidate)
        bound_armature, bound_name = _surface_contact_rig_meta_bone_binding(
            surface
        )
        if bound_armature == armature and bound_name:
            candidate = armature.pose.bones.get(str(bound_name))
            if candidate is not None:
                return physical_owner(candidate)
        for constraint in surface.constraints:
            if getattr(constraint, "target", None) != armature:
                continue
            name = str(getattr(constraint, "subtarget", ""))
            candidate = armature.pose.bones.get(name) if name else None
            if candidate is not None:
                return physical_owner(candidate)
        if surface.parent == armature and surface.parent_type == "BONE":
            return physical_owner(
                armature.pose.bones.get(str(surface.parent_bone))
            )
    except (AttributeError, ReferenceError, RuntimeError):
        pass
    return None


def _ragdoll_filter_articulation_surfaces(
    armature, pose_bone, frame, surfaces
):
    """Disable collisions inside one fully active ragdoll island."""
    source_root = _ragdoll_active_island_root(
        armature, pose_bone, frame
    )
    filtered = []
    for surface in surfaces:
        target_bone = _ragdoll_surface_pose_bone(surface, armature)
        if (
            target_bone is not None
            and (
                _ragdoll_is_ancestor(armature, pose_bone, target_bone)
                or _ragdoll_is_ancestor(armature, target_bone, pose_bone)
                or (
                    _ragdoll_active(target_bone, frame)
                    and _ragdoll_active_island_root(
                        armature, target_bone, frame
                    ) == source_root
                )
            )
        ):
            continue
        filtered.append(surface)
    return tuple(filtered)


def _ragdoll_filter_joint_neighbor_surfaces(
    armature, pose_bone, frame, surfaces
):
    """Keep self-contact but give every active pair one deterministic owner."""
    parent = _ragdoll_parent(armature, pose_bone)
    filtered = []
    for surface in surfaces:
        target = _ragdoll_surface_pose_bone(surface, armature)
        rigid_attached_descendant = bool(
            target is not None
            and _ragdoll_is_ancestor(armature, pose_bone, target)
            and not _ragdoll_active(target, frame)
            and not _ragdoll_unparented(armature, target, frame)
        )
        if rigid_attached_descendant:
            # A non-ragdolled descendant follows this orange body rigidly.
            # Its welded mesh belongs to the same collision body; treating it
            # as an external surface makes a torso collide with its own
            # attached head/arms/legs and appear suspended by hidden geometry.
            continue
        same_active_island = bool(
            target is not None
            and target != pose_bone
            and _ragdoll_active(target, frame)
            and _ragdoll_active_island_root(armature, target, frame)
            == _ragdoll_active_island_root(armature, pose_bone, frame)
        )
        if (
            same_active_island
            and not _ragdoll_unparented(armature, pose_bone, frame)
            and not _ragdoll_unparented(armature, target, frame)
            and (
                _ragdoll_hierarchy_depth(armature, pose_bone),
                pose_bone.name.casefold(),
            )
            < (
                _ragdoll_hierarchy_depth(armature, target),
                target.name.casefold(),
            )
        ):
            # The later body owns this pair, avoiding reciprocal correction.
            # Only direct shared sockets use proximal articulation clearance.
            continue
        filtered.append(surface)
    return tuple(filtered)


def _ragdoll_contact_start_transaction(armature, bone, frame):
    """Keep Contact's live/history boundary pose under its existing owner."""
    return bool(
        (_state.get("pin_history_active") or _state.get("ragdoll_history_restoring")
         or _state.get("pin_snap_transform_active") or _state.get("pin_target_dragging")
         or _state.get("pin_keyboard_transform_active"))
        and _ragdoll_active_start_frame(armature, bone, int(frame)) == int(frame)
        and _surface_contact_guides_for_pose_bone(bone, int(frame))
    )


def _ragdoll_restore_applied_states(armature, pose_bones, frame):
    """Publish cached hierarchy before returning, without deferred pose repair."""
    states = _state.setdefault("ragdoll_states", {})
    caches = _state.setdefault("ragdoll_frame_cache", {})
    restored = False
    previous_syncing = bool(_state.get("ragdoll_syncing", False))
    _state["ragdoll_syncing"] = True
    last_depth = None
    depth_changed = False
    previous_publication_matrices = _state.get("ragdoll_publication_matrices")
    if _state.get("ragdoll_frame_publication"):
        _state["ragdoll_publication_matrices"] = {}
    try:
        for pose_bone in sorted(
            pose_bones, key=lambda bone: _ragdoll_hierarchy_depth(armature, bone)
        ):
            if _ragdoll_contact_start_transaction(armature, pose_bone, frame):
                # Contact owns the editable boundary during its transaction.
                # A cached Orange pose belongs to the preceding edit/history side.
                continue
            key = _ragdoll_state_key(armature, pose_bone)
            state = states.get(key)
            if state is None or int(state.get("frame", -1)) != int(frame):
                state = caches.get(key, {}).get(int(frame))
            if state is None:
                continue
            depth = _ragdoll_hierarchy_depth(armature, pose_bone)
            if (last_depth is not None and depth != last_depth and depth_changed
                    and not _state.get("ragdoll_frame_publication")):
                bpy.context.view_layer.update()
                depth_changed = False
            last_depth = depth
            changed = _ragdoll_apply_tail(
                armature, pose_bone, Vector(state["anchor"]),
                Vector(state["position"]), free=bool(state.get("free", False)),
                orientation=state.get("orientation"), report_change=True,
            )
            depth_changed = depth_changed or changed
            restored = restored or changed
        # Frame-change callbacks run inside Blender's dependency evaluation.
        # A nested update here consumes its pending pose tags without reliably
        # publishing them. Let the outer refresh evaluate all native siblings
        # together; live edits outside that callback still flush immediately.
        if depth_changed and not _state.get("ragdoll_frame_publication"):
            bpy.context.view_layer.update()
    finally:
        if previous_publication_matrices is None:
            _state.pop("ragdoll_publication_matrices", None)
        else:
            _state["ragdoll_publication_matrices"] = previous_publication_matrices
        _state["ragdoll_syncing"] = previous_syncing
    return restored


def _ragdoll_remap_armature_world_states(armature, previous_world):
    """Apply an actual armature-object edit without confusing it with a scrub."""
    current_world = armature.matrix_world.copy()
    delta = current_world @ Matrix(previous_world).inverted_safe()
    if max(
        abs(float(delta[row][column]) - float(Matrix.Identity(4)[row][column]))
        for row in range(4) for column in range(4)
    ) <= 1.0e-8:
        return False
    states = _state.setdefault("ragdoll_states", {})
    caches = _state.setdefault("ragdoll_frame_cache", {})
    for pose_bone in armature.pose.bones:
        key = _ragdoll_state_key(armature, pose_bone)
        state = states.get(key)
        if state is None:
            continue
        for name in ("position", "previous", "anchor", "anchor_previous"):
            if state.get(name) is not None:
                state[name] = delta @ Vector(state[name])
        rotation = delta.to_quaternion()
        for name in ("velocity", "anchor_velocity", "angular_velocity"):
            if state.get(name) is not None:
                state[name] = rotation @ Vector(state[name])
        frame = int(state.get("frame", 0))
        cache = caches.setdefault(key, {})
        for cached_frame in tuple(cache):
            if int(cached_frame) >= frame:
                cache.pop(cached_frame, None)
        cache[frame] = {
            name: value.copy() if hasattr(value, "copy") else value
            for name, value in state.items()
        }
    _state.setdefault("ragdoll_collision_bounds", {}).clear()
    return True


def _ragdoll_restore_cached_frame(scene):
    """Replay the exact stored hierarchy for the current history frame."""
    frame = int(scene.frame_current)
    restored = False
    previous_syncing = bool(_state.get("ragdoll_syncing", False))
    _state["ragdoll_syncing"] = True
    try:
        for armature in tuple(scene.objects):
            if armature.type != "ARMATURE" or getattr(armature, "pose", None) is None:
                continue
            ordered = _ragdoll_active_bones_hierarchy_order(armature, frame)
            applied = []
            for pose_bone in ordered:
                key = _ragdoll_state_key(armature, pose_bone)
                cached = _state.setdefault("ragdoll_frame_cache", {}).get(
                    key, {}
                ).get(frame)
                live = _state.get('ragdoll_live_preview_states', {}).get(key)
                if live is not None and not _state.get('ragdoll_history_restoring'):
                    origin, pose = live
                    if (int(pose.get('frame', -1)) == frame and any(
                            (session.get('armature'), session.get('bone'), session.get('frame')) == origin
                            for session in _state.get('ragdoll_driver_modal_sessions', {}).values())):
                        cached = pose
                if cached is None:
                    continue
                _state.setdefault("ragdoll_states", {})[key] = {
                    name: value.copy() if hasattr(value, "copy") else value
                    for name, value in cached.items()
                }
                applied.append(pose_bone)
            if applied:
                _ragdoll_restore_applied_states(armature, applied, frame)
                # Callers use this result to detect an available cached pose,
                # including a pose that was already displayed correctly.
                restored = True
    finally:
        _state["ragdoll_syncing"] = previous_syncing
    return restored


def _ragdoll_refresh_descendants(context, armature, parent, frame):
    descendants = tuple(
        pose_bone
        for pose_bone in _ragdoll_active_bones_hierarchy_order(armature, frame)
        if _ragdoll_is_ancestor(armature, parent, pose_bone)
    )
    if not descendants:
        return False
    changed = False
    _state["ragdoll_syncing"] = True
    try:
        # Evaluate the user's parent edit once, then restore any active parent
        # state that native Action evaluation overwrote before sampling child
        # sockets.
        context.view_layer.update()
        active_ancestors = tuple(
            candidate
            for candidate in _ragdoll_active_bones_hierarchy_order(armature, frame)
            if candidate == parent
            or _ragdoll_is_ancestor(armature, candidate, parent)
        )
        _ragdoll_restore_applied_states(
            armature, active_ancestors, int(frame)
        )
        applied = []
        last_depth = None
        for pose_bone in descendants:
            depth = _ragdoll_hierarchy_depth(armature, pose_bone)
            if last_depth is not None and depth != last_depth:
                context.view_layer.update()
                _ragdoll_restore_applied_states(
                    armature, (*active_ancestors, *applied), int(frame)
                )
            last_depth = depth
            changed = bool(
                _ragdoll_step(context, armature, pose_bone, int(frame))
            ) or changed
            applied.append(pose_bone)
        if applied:
            context.view_layer.update()
            _ragdoll_restore_applied_states(
                armature, (*active_ancestors, *applied), int(frame)
            )
    finally:
        _state["ragdoll_syncing"] = False
    return changed


def _ragdoll_remap_connected_branch(armature, driver, target_frame, targets):
    """Remap an existing connected simulation after one hierarchy pose edit.

    The cached endpoint response is the local discrete response Jacobian used
    by the modal preview. Applying that same mapping to every cached sample
    makes confirm exactly match preview without evaluating Blender once per
    historical frame. This path is valid only while the driver itself is not
    ragdolled and every affected body remains connected.
    """
    target_frame = int(target_frame)
    caches = _state.setdefault("ragdoll_frame_cache", {})
    states = _state.setdefault("ragdoll_states", {})
    responses = _state.setdefault("ragdoll_measured_preview_responses", {})
    fps = max(
        1.0,
        float(bpy.context.scene.render.fps)
        / max(1.0e-6, float(bpy.context.scene.render.fps_base)),
    )
    plans = []
    for pose_bone in targets:
        key = _ragdoll_state_key(armature, pose_bone)
        cache = caches.get(key, {})
        target_state = cache.get(target_frame)
        current_anchor = _ragdoll_connected_anchor(armature, pose_bone)
        start = _ragdoll_active_start_frame(
            armature, pose_bone, target_frame
        )
        if (
            target_state is None
            or current_anchor is None
            or start is None
            or bool(target_state.get("free", False))
        ):
            return False
        start_frame = int(round(float(start)))
        frames = tuple(
            frame
            for frame in sorted(cache)
            if start_frame <= int(frame) <= target_frame
        )
        if not frames or int(frames[-1]) != target_frame:
            return False
        old_target_anchor = Vector(target_state["anchor"])
        plans.append((
            pose_bone,
            key,
            cache,
            frames,
            start_frame,
            current_anchor - old_target_anchor,
            max(-1.25, min(0.5, float(responses.get(key, -0.35)))),
        ))
    if not plans:
        return False
    for (
        pose_bone,
        key,
        cache,
        frames,
        start_frame,
        endpoint_delta,
        response,
    ) in plans:
        span = max(1, target_frame - start_frame)
        remapped = {}
        for frame in frames:
            old = cache[int(frame)]
            fraction = max(
                0.0,
                min(1.0, float(int(frame) - start_frame) / float(span)),
            )
            eased = fraction * fraction * (3.0 - 2.0 * fraction)
            delta = endpoint_delta * eased
            old_anchor = Vector(old["anchor"])
            radial = Vector(old["position"]) - old_anchor
            length = max(1.0e-5, radial.length)
            if radial.length <= 1.0e-8:
                radial = Vector((0.0, -1.0, 0.0))
            radial_direction = radial.normalized()
            tangent = delta - radial_direction * delta.dot(radial_direction)
            new_radial = radial + tangent * response
            if new_radial.length <= 1.0e-8:
                new_radial = radial
            new_anchor = old_anchor + delta
            new_position = new_anchor + new_radial.normalized() * length
            state = {
                name: value.copy() if hasattr(value, "copy") else value
                for name, value in old.items()
            }
            state.update({
                "anchor": new_anchor.copy(),
                "position": new_position.copy(),
                "contact_normal": None,
                "contact_point": None,
                "contact_self": False,
                "contact_surface": "",
                "contact_point_local": None,
                "contact_normal_local": None,
            })
            remapped[int(frame)] = state
        previous_state = None
        for frame in frames:
            state = remapped[int(frame)]
            if previous_state is None:
                state["previous"] = Vector(state["position"]).copy()
                state["anchor_previous"] = Vector(state["anchor"]).copy()
                state["velocity"] = Vector((0.0, 0.0, 0.0))
                state["anchor_velocity"] = Vector((0.0, 0.0, 0.0))
            else:
                state["previous"] = Vector(previous_state["position"]).copy()
                state["anchor_previous"] = Vector(
                    previous_state["anchor"]
                ).copy()
                state["velocity"] = (
                    Vector(state["position"])
                    - Vector(previous_state["position"])
                ) * fps
                state["anchor_velocity"] = (
                    Vector(state["anchor"])
                    - Vector(previous_state["anchor"])
                ) * fps
            cache[int(frame)] = state
            previous_state = state
        states[key] = {
            name: value.copy() if hasattr(value, "copy") else value
            for name, value in cache[target_frame].items()
        }
    ordered = tuple(
        pose_bone
        for pose_bone in _ragdoll_active_bones_hierarchy_order(
            armature, target_frame
        )
        if pose_bone in targets
    )
    _ragdoll_restore_applied_states(armature, ordered, target_frame)
    _state.setdefault("ragdoll_driver_preview_signatures", {})[
        (armature.name_full, driver.name, target_frame)
    ] = _ragdoll_driver_pose_signature(driver, target_frame)
    _ragdoll_debug_event(
        "connected_branch_cache_remap",
        driver=driver.name,
        target=target_frame,
        bones=tuple(pose_bone.name for pose_bone in targets),
        cache_frames=sum(len(frames) for _pb, _key, _cache, frames, *_ in plans),
    )
    return True


def _ragdoll_resimulate_branch(
    armature, driver, target_frame, *, allow_cached_remap=False, defer=False
):
    """Rebuild the affected branch exactly as a Start-to-target play-through."""
    if _ragdoll_native_branch(armature, driver, int(target_frame)):
        return True
    scene = bpy.context.scene
    targets = tuple(
        pose_bone
        for pose_bone in armature.pose.bones
        if _ragdoll_active(pose_bone, target_frame)
        and (
            pose_bone == driver
            or _ragdoll_is_ancestor(armature, driver, pose_bone)
        )
    )
    if not targets:
        return False
    if (
        allow_cached_remap
        and not _ragdoll_active(driver, int(target_frame))
        and all(
            not _ragdoll_free(armature, pose_bone, int(target_frame))
            for pose_bone in targets
        )
        and _ragdoll_remap_connected_branch(
            armature, driver, int(target_frame), targets
        )
    ):
        return True
    starts = tuple(
        int(round(start))
        for pose_bone in targets
        if (start := _ragdoll_active_start_frame(
            armature, pose_bone, target_frame
        )) is not None
    )
    if not starts:
        return False
    start_frame = min(starts)
    if defer:
        # Preserve the displayed generation before invalidating its caches.
        # The event-loop worker performs the same canonical solve a frame at
        # a time. Neither confirmation nor a cursor callback may drain it.
        _state.pop("ragdoll_scrub_job", None)
        _ragdoll_queue_scrub(scene, int(scene.frame_current))
    # A new driver generation moves every collider even on cached frame numbers.
    _state.setdefault("ragdoll_collision_bounds", {}).clear()
    states = _state.setdefault("ragdoll_states", {})
    caches = _state.setdefault("ragdoll_frame_cache", {})
    samples = _state.setdefault("ragdoll_boundary_pose_samples", {})
    for pose_bone in targets:
        key = _ragdoll_state_key(armature, pose_bone)
        states.pop(key, None)
        caches.pop(key, None)
        samples.pop(key, None)
    if defer:
        _state.setdefault("ragdoll_driver_preview_signatures", {})[
            (armature.name_full, driver.name, int(target_frame))
        ] = _ragdoll_driver_pose_signature(driver, target_frame)
        return True
    saved_frame = int(scene.frame_current)
    saved_subframe = float(getattr(scene, "frame_subframe", 0.0))
    saved_bases = {
        pose_bone.name: pose_bone.matrix_basis.copy()
        for pose_bone in armature.pose.bones
        if pose_bone != driver
    }
    previous_syncing = bool(_state.get("ragdoll_syncing", False))
    _state["ragdoll_syncing"] = True
    _state["ragdoll_resimulating"] = True
    _ragdoll_debug_event(
        "resimulation_begin",
        driver=driver.name,
        start=int(start_frame),
        target=int(target_frame),
        bones=tuple(pose_bone.name for pose_bone in targets),
    )
    try:
        for replay_frame in range(start_frame, int(target_frame) + 1):
            scene.frame_set(replay_frame)
            bpy.context.view_layer.update()
            # Use the playback algorithm, including Start restoration and
            # final self-contact settling, for the edited trajectory too.
            _state["ragdoll_syncing"] = False
            _state["ragdoll_evaluation_curves"] = {}
            try:
                _ragdoll_frame_change_impl(scene)
            finally:
                _state.pop("ragdoll_evaluation_curves", None)
                _state["ragdoll_syncing"] = True
    finally:
        scene.frame_set(saved_frame, subframe=saved_subframe)
        # The Action is authoritative for the edited/deleted driver key.
        # Restoring its pre-replay basis resurrected deleted torso poses and
        # injected impossible socket velocity into the next scrub.
        bpy.context.view_layer.update()
        for bone_name, matrix_basis in saved_bases.items():
            pose_bone = armature.pose.bones.get(bone_name)
            if pose_bone is not None:
                pose_bone.matrix_basis = matrix_basis
        bpy.context.view_layer.update()
        final_bones = tuple(
            pose_bone
            for pose_bone in _ragdoll_active_bones_hierarchy_order(
                armature, saved_frame
            )
            if pose_bone in targets
        )
        applied = []
        last_depth = None
        for pose_bone in final_bones:
            depth = _ragdoll_hierarchy_depth(armature, pose_bone)
            if last_depth is not None and depth != last_depth:
                bpy.context.view_layer.update()
                _ragdoll_restore_applied_states(
                    armature, applied, saved_frame
                )
            last_depth = depth
            applied.append(pose_bone)
        _ragdoll_restore_applied_states(armature, applied, saved_frame)
        bpy.context.view_layer.update()
        _state["ragdoll_resimulating"] = False
        _state["ragdoll_syncing"] = previous_syncing
    signature_key = (
        armature.name_full,
        driver.name,
        int(target_frame),
    )
    _state.setdefault("ragdoll_driver_preview_signatures", {})[
        signature_key
    ] = _ragdoll_driver_pose_signature(driver, target_frame)
    _ragdoll_debug_event(
        "resimulation_end",
        driver=driver.name,
        start=int(start_frame),
        target=int(target_frame),
        bones=tuple(pose_bone.name for pose_bone in targets),
    )
    return True


def _ragdoll_preview_driver_deltas(armature, driver, frames, target_frame, *, preview=True, native=False):
    """Sample a hypothetical endpoint key without editing the user's Action."""
    from mathutils import Euler
    original = _ragdoll_action(armature)
    if original is None:
        return {}, {}
    finalize_handles = bool(native and _state.get("ragdoll_key_transform_active"))
    trial = original.copy() if preview or finalize_handles else original
    try:
        rotation_path = ("rotation_quaternion" if driver.rotation_mode == "QUATERNION"
                         else "rotation_axis_angle" if driver.rotation_mode == "AXIS_ANGLE"
                         else "rotation_euler")
        names = ("location", rotation_path, "scale")
        prefix = f"pose.bones[{json.dumps(driver.name)}]."
        original_curves = {(c.data_path, int(c.array_index)): c
                           for c in _action_fcurves(original, armature)}
        slot_handle = int(getattr(armature.animation_data, "action_slot_handle", 0) or 0)
        trial_bags = tuple(bag for bag in _action_channelbags(trial)
                           if not slot_handle or int(bag.slot_handle) == slot_handle)
        copied_curves = (tuple(c for bag in trial_bags for c in bag.fcurves)
                         if trial_bags else _action_fcurves(trial, armature))
        trial_curves = {(c.data_path, int(c.array_index)): c for c in copied_curves}
        if finalize_handles:
            # Dope Sheet motion translates handles in place; Blender refreshes
            # automatic handles only on confirmation. Predict that final curve
            # on a disposable copy, never sort/reallocate the modal's live keys.
            for curve in copied_curves:
                curve.update()
        for name in names if preview else ():
            for index, value in enumerate(getattr(driver, name)):
                path = prefix + name
                curve = trial_curves.get((path, index))
                if curve is None:
                    collection = trial_bags[0].fcurves if trial_bags else trial.fcurves
                    curve = collection.new(path, index=index)
                    trial_curves[(path, index)] = curve
                existing = any(abs(point.co.x - target_frame) < 1e-5
                               for point in curve.keyframe_points)
                point = curve.keyframe_points.insert(float(target_frame), float(value), options={'FAST'})
                if not existing:
                    point.handle_left_type = point.handle_right_type = 'AUTO_CLAMPED'
                    point.interpolation = getattr(bpy.context.preferences.edit, 'keyframe_new_interpolation_type', 'BEZIER')
                curve.update()
        signature = _state.get("ragdoll_driver_preview_signatures", {}).get(
            (armature.name_full, driver.name, int(target_frame)))
        basis = (Matrix(tuple(tuple(signature[1][r * 4 + c] for c in range(4)) for r in range(4)))
                 if signature else driver.matrix_basis.copy())
        saved_start = {}
        release = _ragdoll_active_start_frame(armature, driver, target_frame)
        if release is not None and _ragdoll_free(armature, driver, target_frame):
            saved_start = _ragdoll_start_poses(driver).get(str(int(round(release))), {})
            packed = saved_start.get('matrix', ())
            if len(packed) == 16:
                saved_pose = Matrix(tuple(tuple(packed[r*4+c] for c in range(4)) for r in range(4)))
                parent = driver.parent
                parent_args = (dict(parent_matrix=parent.matrix, parent_matrix_local=parent.bone.matrix_local)
                               if parent is not None else {})
                basis = driver.bone.convert_local_to_pose(saved_pose, driver.bone.matrix_local,
                                                         invert=True, **parent_args)
        location, rotation, scale = basis.decompose()
        defaults = {'location': tuple(location), 'scale': tuple(scale),
                    'rotation_quaternion': tuple(rotation),
                    'rotation_axis_angle': (rotation.angle, *rotation.axis),
                    'rotation_euler': tuple(rotation.to_euler(driver.rotation_mode if rotation_path == 'rotation_euler' else 'XYZ'))}
        defaults.update(saved_start.get("channel_source", {}))
        start_offset = saved_start.get("channel_offset", {})
        def sampled(curves, frame):
            values = {}
            for name in names:
                values[name] = tuple(float(curves[(prefix + name, index)].evaluate(frame))
                                     if (prefix + name, index) in curves else value
                                     for index, value in enumerate(defaults[name]))
            angles = values[rotation_path]
            q = (Quaternion(angles) if rotation_path == 'rotation_quaternion'
                 else Quaternion(Vector(angles[1:]), angles[0]) if rotation_path == 'rotation_axis_angle'
                 else Euler(angles, driver.rotation_mode).to_quaternion())
            # Blender normalizes quaternion pose channels during evaluation.
            # FCurve component interpolation is not unit length; passing it
            # directly to LocRotScale invents scale and rejects native R/gizmos.
            if q.magnitude <= 1.0e-12:
                q = Quaternion((1, 0, 0, 0))
            else:
                q.normalize()
            location = Vector(values['location'])
            scale = Vector(values['scale'])
            if start_offset:
                location += Vector(start_offset["location"])
                q = Quaternion(start_offset["rotation"]) @ q
                scale = Vector(tuple(v * factor for v, factor in zip(scale, start_offset["scale"])))
            return Matrix.LocRotScale(location, q, scale)
        # Factor out the native/Dynamic Space input once. Ancestor motion is
        # already present in the cached socket samples and is not integrated twice.
        factor = armature.matrix_world @ driver.matrix @ _pose_space_input_matrix(driver).inverted_safe()
        rest = driver.bone.matrix_local
        parent = driver.parent
        parent_args = (dict(parent_matrix=parent.matrix,
                           parent_matrix_local=parent.bone.matrix_local)
                       if parent is not None else {})
        def world(curves, frame):
            basis = sampled(curves, frame)
            if native:
                # The native planner already verifies static, unconstrained
                # ancestry. Build from authored channels directly; factoring
                # a simulated/evaluated pose introduces history-dependent
                # roundoff that can diverge at a collision after undo/redo.
                return armature.matrix_world @ driver.bone.convert_local_to_pose(
                    basis, rest, **parent_args)
            return factor @ rest @ basis
        if native:
            curves = trial_curves if preview or finalize_handles else original_curves
            # Reuse authored sampling, not simulated state. The fingerprint
            # includes Bezier handles/easing and unkeyed defaults, so moving a
            # group of keys, undo or a tangent edit invalidates it immediately.
            relevant = {key: curve for key, curve in curves.items()
                        if key[0] in tuple(prefix + name for name in names)}
            cacheable = not preview and not any(curve.modifiers for curve in relevant.values())
            if cacheable:
                signature = (
                    tuple(tuple(row) for row in armature.matrix_world),
                    tuple(tuple(row) for row in rest),
                    tuple(tuple(row) for row in parent.matrix) if parent else (),
                    tuple(tuple(row) for row in parent.bone.matrix_local) if parent else (),
                    (driver.bone.inherit_scale, driver.bone.use_inherit_rotation, driver.bone.use_local_location),
                    tuple((name, tuple(value if (prefix+name,index) not in relevant else None
                        for index,value in enumerate(defaults[name]))) for name in names),
                    json.dumps(start_offset, sort_keys=True),
                    tuple((key, curve.extrapolation, tuple((tuple(p.co), tuple(p.handle_left),
                        tuple(p.handle_right), p.interpolation, p.easing, p.back, p.amplitude, p.period)
                        for p in curve.keyframe_points)) for key,curve in relevant.items()))
                bank = _state.setdefault('ragdoll_native_authored_samples', {})
                key = (armature.name_full, driver.name)
                entry = bank.get(key)
                if entry is None or entry[0] != signature:
                    entry = (signature, {})
                    bank[key] = entry
                    while len(bank) > 16:
                        bank.pop(next(iter(bank)))
                sampled_worlds = entry[1]
                for frame in frames:
                    if frame not in sampled_worlds:
                        sampled_worlds[frame] = world(curves, frame)
                result = {frame: sampled_worlds[frame] for frame in frames}
                # Bound long-session memory without retaining any RNA.
                if len(sampled_worlds) > 8192:
                    bank.pop(key, None)
                return {}, result
            return {}, {frame: world(curves, frame) for frame in frames}
        worlds = {frame: world(original_curves, frame) for frame in frames}
        deltas = ({frame: world(trial_curves, frame) @ worlds[frame].inverted_safe()
                   for frame in frames} if preview else {})
        return deltas, worlds
    finally:
        if trial is not original:
            bpy.data.actions.remove(trial)


def _ragdoll_preview_rod(state, anchors, length, gravity, damping, fps):
    """Prescribed-socket pendulum, using the solver's timestep and damping."""
    position = Vector(state["position"])
    velocity = Vector(state.get("velocity", (0, 0, 0)))
    old_anchor = Vector(state["anchor"])
    steps = max(1, min(8, math.ceil(120.0 / fps)))
    dt = 1.0 / (fps * steps)
    acceleration = gravity * _RAGDOLL_UNIFORM_ROD_GRAVITY_FACTOR
    retention = min(0.999, max(0.0, damping)) ** (24.0 / (fps * steps))
    retention *= math.exp(-0.35 * math.sqrt(acceleration.length / max(length, 1e-5)) * dt)
    for anchor in anchors:
        anchor_velocity = (anchor - old_anchor) * fps
        for substep in range(1, steps + 1):
            socket = old_anchor.lerp(anchor, substep / steps)
            velocity = velocity * retention + acceleration * dt
            predicted = position + velocity * dt
            radial = predicted - socket
            if radial.length <= 1e-8:
                radial = position - old_anchor
            radial.normalize()
            predicted = socket + radial * length
            velocity = (predicted - position) / dt
            relative = velocity - anchor_velocity
            velocity = relative - radial * relative.dot(radial) + anchor_velocity
            position = predicted
        old_anchor = anchor
    return position, velocity


def _ragdoll_preview_branch(armature, driver, target_frame):
    """Use the canonical solver for both held input and confirmation."""
    frame = int(target_frame)
    descendants = tuple(bone for bone in _ragdoll_active_bones_hierarchy_order(armature, frame)
                        if bone == driver or _ragdoll_is_ancestor(armature, driver, bone))
    if descendants and all(_ragdoll_active_start_frame(armature, bone, frame) == frame
                           for bone in descendants):
        if driver in descendants:
            # Direct limb edits own the initial pose too. A leaf has no
            # descendants; excluding the driver fell through to Action replay
            # and repeatedly replaced the mouse input with the stored pose.
            _ragdoll_capture_start_edits(bpy.context, contact_bone=driver)
        else:
            _ragdoll_rebase_start_branch(armature, driver, frame)
        # No elapsed physics time at Start. In particular, the modal watcher
        # must not sample an Action over Contact's live solved channels.
        return True
    if _ragdoll_native_branch(armature, driver, int(target_frame), preview=True):
        return True
    return _ragdoll_exact_edit_preview(armature, driver, int(target_frame))


def _ragdoll_exact_edit_preview(armature, driver, frame, *, key_edit=False):
    """Replay a disposable Action; never edit native modal-owned FCurves.

    Unsupported native hierarchies used to preview a pendulum approximation
    and switch to collision replay on release. A private Action now supplies
    the same final keys/handles to the normal fallback solver while its math
    caches remain separate from the user's confirmed generation.
    """
    animation = armature.animation_data
    if animation is None or animation.action is None:
        return False
    _ragdoll_native_cancel_job()
    original = animation.action
    slot = animation.action_slot
    trial = original.copy()
    saved_basis = driver.matrix_basis.copy()
    snapshot = {key: value for key, value in _state.items() if key.startswith('ragdoll_')}
    derived = ('ragdoll_states', 'ragdoll_frame_cache', 'ragdoll_boundary_pose_samples',
               'ragdoll_native_solutions', 'ragdoll_native_authored_samples',
               'ragdoll_collision_bounds', 'ragdoll_driver_preview_signatures',
               'ragdoll_driver_curve_signatures', 'ragdoll_evaluation_curves')
    output = {}
    authored_bases = {}
    driver_basis = saved_basis
    success = False
    _state['ragdoll_syncing'] = True
    _state['ragdoll_exact_preview_active'] = True
    for key in derived:
        _state[key] = {}
    try:
        animation.action = trial
        if slot is not None:
            animation.action_slot = next(candidate for candidate in trial.slots if candidate.handle == slot.handle)
        if key_edit:
            for curve in _action_fcurves(trial, armature):
                curve.update()
        else:
            driver.matrix_basis = saved_basis
            _insert_bone_keys(driver, frame, visual=False)
        success = _ragdoll_resimulate_branch(armature, driver, frame, defer=False)
        driver_basis = driver.matrix_basis.copy() if key_edit else saved_basis
        if key_edit:
            # The replay restores non-driver bases for pose gestures. A key
            # gesture instead needs every authored driver at its trial keys.
            bpy.context.scene.frame_set(frame)
            bpy.context.view_layer.update()
            authored_bases = {bone.name: bone.matrix_basis.copy() for bone in armature.pose.bones
                              if not _ragdoll_active(bone, frame)}
        output = {key: dict(value) for key, value in _state.get('ragdoll_states', {}).items()
                  if key[0] == armature.name_full and int(value.get('frame', -1)) == frame}
    finally:
        _state['ragdoll_syncing'] = True
        animation.action = original
        if slot is not None:
            animation.action_slot = slot
        bpy.data.actions.remove(trial)
        driver.matrix_basis = driver_basis
        bpy.context.view_layer.update()
        for key in tuple(_state):
            if key.startswith('ragdoll_'):
                _state.pop(key, None)
        _state.update(snapshot)
    if success:
        origin = (armature.name_full, driver.name, frame)
        _state.setdefault('ragdoll_states', {}).update(output)
        for key, value in output.items():
            _state.setdefault('ragdoll_live_preview_states', {})[key] = (origin, value)
        previous = bool(_state.get('ragdoll_syncing'))
        _state['ragdoll_syncing'] = True
        try:
            driver.matrix_basis = driver_basis
            for name, basis in authored_bases.items():
                armature.pose.bones[name].matrix_basis = basis
            bpy.context.view_layer.update()
            _ragdoll_restore_applied_states(armature, tuple(
                armature.pose.bones[key[1]] for key in output), frame)
        finally:
            _state['ragdoll_syncing'] = previous
    return success


def _ragdoll_preview_key_edit(scene):
    handled = False
    frame = int(scene.frame_current)
    for owner in scene.objects:
        if owner.type != 'ARMATURE' or not owner.pose:
            continue
        active_bones = _ragdoll_active_bones_hierarchy_order(owner, frame)
        roots = {}
        for bone in active_bones:
            root = bone
            while root.parent is not None:
                root = root.parent
            roots[root.name] = root
        if active_bones and all(
                _ragdoll_active_start_frame(owner, bone, frame) == frame
                for bone in active_bones):
            # Zero elapsed physics time: copying/sampling an Action here
            # replaces Blender's live initial-pose edit with its old keys.
            # This path is also reached by redraws during native bone input.
            selected = _selected_pose_bones_by_owner(bpy.context).get(owner, ())
            direct = tuple(bone for bone in selected if bone in active_bones)
            for bone in direct:
                _ragdoll_capture_start_edits(bpy.context, contact_bone=bone)
            if not direct:
                for root in roots.values():
                    _ragdoll_rebase_start_branch(owner, root, frame)
            owners = _state.get('ragdoll_key_preview_owners', set())
            for root in roots.values():
                owners.discard((owner.name_full, root.name))
            handled = True
            continue
        for root in roots.values():
            if _ragdoll_exact_edit_preview(owner, root, frame, key_edit=True):
                _state.setdefault('ragdoll_key_preview_owners', set()).add((owner.name_full, root.name))
                handled = True
    return handled


def _ragdoll_commit_key_preview(scene):
    owners = _state.pop('ragdoll_key_preview_owners', ())
    _state.pop('ragdoll_live_preview_states', None)
    for owner_name, root_name in owners:
        owner = scene.objects.get(owner_name)
        root = owner.pose.bones.get(root_name) if owner and owner.pose else None
        if root is not None:
            _ragdoll_resimulate_branch(owner, root, int(scene.frame_current), defer=False)
    return bool(owners)


def _ragdoll_resimulation_timer():
    pending = _state.get("ragdoll_pending_resimulation")
    if not pending:
        return None
    context = getattr(bpy, "context", None)
    if context is not None and _animation_playback_active(context):
        # A pending edit belongs to its captured target frame. Running it as
        # playback advances remaps the cache against a different socket and
        # produces the recorded wild limbs. Confirmation normally consumes
        # connected remaps atomically; exceptional full replays wait for idle.
        return 0.08
    if (
        context is not None
        and (
            _pin_active_transform_operator(context)
            or _pin_primary_mouse_pressed()
        )
    ):
        # Never change frames while Blender is still committing the user's
        # transform/key insertion. The existing request runs once afterward.
        return 0.08
    quiet_for = time.monotonic() - float(pending.get("updated", 0.0))
    if quiet_for < 0.12:
        return max(0.02, 0.12 - quiet_for)
    _state["ragdoll_pending_resimulation"] = None
    armature = bpy.data.objects.get(str(pending.get("armature", "")))
    driver = (
        armature.pose.bones.get(str(pending.get("bone", "")))
        if armature is not None and getattr(armature, "pose", None) is not None
        else None
    )
    if armature is not None and driver is not None:
        _ragdoll_resimulate_branch(
            armature,
            driver,
            int(pending.get("frame", 0)),
            allow_cached_remap=False,
            defer=_ragdoll_interactive_replay(),
        )
    return None


def _ragdoll_driver_modal_commit_timer():
    """Finalize confirmed transforms; discard cancelled drag previews."""
    sessions = _state.get("ragdoll_driver_modal_sessions") or {}
    if not sessions:
        return None
    context = getattr(bpy, "context", None)
    if context is None:
        return 0.01
    if _pin_active_transform_operator(context) or _pin_primary_mouse_pressed():
        # Native modal transforms need not re-enter our depsgraph callback on
        # every mouse event. Sample final RNA channels from this existing timer
        # so the live solver does not remain at the first preview until release.
        for session in tuple(sessions.values()):
            owner = bpy.data.objects.get(session.get("armature", ""))
            bone = owner.pose.bones.get(session.get("bone", "")) if owner and owner.pose else None
            if bone is None or int(context.scene.frame_current) != int(session["frame"]):
                continue
            current = bone.matrix_basis.copy()
            previous = session["matrix_basis"]
            if max(abs(current[r][c] - previous[r][c]) for r in range(4) for c in range(4)) <= 1.e-6:
                continue
            session["matrix_basis"] = current
            _ragdoll_preview_branch(owner, bone, int(session["frame"]))
        return 0.01
    if _state.get('ragdoll_native_job'):
        _state['ragdoll_native_finishing'] = True
    _state["ragdoll_driver_modal_sessions"] = {}
    _state.pop("ragdoll_live_preview_states", None)
    _state.pop("ragdoll_modal_preview_inputs", None)
    scene = getattr(context, "scene", None)
    current_frame = int(getattr(scene, "frame_current", 0)) if scene else 0
    for signature_key, session in tuple(sessions.items()):
        armature = bpy.data.objects.get(str(session.get("armature", "")))
        pose_bone = (
            armature.pose.bones.get(str(session.get("bone", "")))
            if armature is not None and getattr(armature, "pose", None) is not None
            else None
        )
        if armature is None or pose_bone is None:
            continue
        target_frame = int(session.get("frame", current_frame))
        saved_basis = pose_bone.matrix_basis.copy()
        previous_syncing = bool(_state.get("ragdoll_syncing", False))
        _state["ragdoll_syncing"] = True
        _state["ragdoll_driver_autokeying"] = True
        try:
            native_finished = _pin_transform_operator_finished(context, session.get("operator_token"))
            # Gizmo transforms may not retain the modal operator identity in
            # redo history. Blender's final channels remain authoritative:
            # cancellation restores the initial basis before removing the modal.
            start_basis = session.get("start_basis")
            final_basis = tuple(float(v) for row in saved_basis for v in row)
            kept_native_result = (start_basis is not None
                and max(abs(x-y) for x,y in zip(final_basis, start_basis)) > 1e-6)
            if ("operator_token" in session and not native_finished and not kept_native_result):
                # Blender has already restored G/R/S channels. Never replace
                # those channels with the last preview or insert an Auto Key.
                _ragdoll_finish_modal_start_poses(armature, cancel=True)
                for name, stored in session.get("start_poses", {}).items():
                    child = armature.pose.bones.get(name)
                    if child is not None:
                        if stored is None:
                            child.pop(_RAGDOLL_START_POSES_PROPERTY, None)
                        else:
                            child[_RAGDOLL_START_POSES_PROPERTY] = stored
                _state["ragdoll_pending_resimulation"] = None
                if current_frame == target_frame:
                    _ragdoll_resimulate_branch(
                        armature, pose_bone, target_frame,
                        allow_cached_remap=False,
                        defer=False,
                    )
                _state.setdefault("ragdoll_driver_preview_signatures", {})[
                    signature_key
                ] = _ragdoll_driver_pose_signature(pose_bone, target_frame)
                _state.setdefault("ragdoll_driver_curve_signatures", {})[
                    (armature.name_full, pose_bone.name)
                ] = _ragdoll_driver_curve_signature(armature, pose_bone)
                continue
            # Native confirmation owns the final channels. A modal depsgraph
            # snapshot can lag behind the last mouse event (or contain only
            # the initial pose); assigning it here undoes the confirmed drag.
            _ragdoll_finish_modal_start_poses(armature)
            if bool(session.get("autokey", False)):
                _insert_bone_keys(pose_bone, target_frame, visual=False)
            _state.setdefault("ragdoll_driver_preview_signatures", {})[
                signature_key
            ] = _ragdoll_driver_pose_signature(pose_bone, target_frame)
            # Own the curve mutation in this same confirmation transaction.
            # Without publishing its new signature here, the next depsgraph
            # callback interpreted our Auto Key as a second external edit and
            # scheduled another remap. That exposed the ordinary frame-Start
            # pose for one draw between LMB release and the duplicate repair.
            _state.setdefault("ragdoll_driver_curve_signatures", {})[
                (armature.name_full, pose_bone.name)
            ] = _ragdoll_driver_curve_signature(armature, pose_bone)
            _ragdoll_debug_event(
                "driver_pose_autokey",
                driver=pose_bone.name,
                frame=target_frame,
                once_after_modal=True,
                current_frame=current_frame,
            )
            if current_frame == target_frame:
                # Key insertion temporarily restores ordinary descendant pose
                # channels. Consume the connected cache remap inside this same
                # transaction so no draw/depsgraph callback can expose that
                # initial pose between confirmation and simulated output.
                _state["ragdoll_pending_resimulation"] = None
                if session.get("autokey", False):
                    _ragdoll_resimulate_branch(
                        armature, pose_bone, target_frame,
                        allow_cached_remap=False, defer=False,
                    )
                else:
                    # An unkeyed native pose remains an edit at this frame.
                    # Replaying the old Action here would undo its preview.
                    _ragdoll_preview_branch(armature, pose_bone, target_frame)
        finally:
            if current_frame != target_frame:
                pose_bone.matrix_basis = saved_basis
            _state["ragdoll_driver_autokeying"] = False
            _state["ragdoll_syncing"] = previous_syncing
    return None


def _ragdoll_schedule_resimulation(
    armature,
    driver,
    frame,
    *,
    refresh_deadline=True,
    force_full=False,
):
    pending = _state.get("ragdoll_pending_resimulation")
    identity = (
        armature.name_full,
        driver.name,
        int(frame),
    )
    pending_identity = (
        str((pending or {}).get("armature", "")),
        str((pending or {}).get("bone", "")),
        int((pending or {}).get("frame", -1048576)),
    )
    if pending_identity == identity and not refresh_deadline:
        return False
    _state["ragdoll_pending_resimulation"] = {
        "armature": armature.name_full,
        "bone": driver.name,
        "frame": int(frame),
        "updated": (
            float(pending.get("updated", time.monotonic()))
            if pending_identity == identity and not refresh_deadline
            else time.monotonic()
        ),
        "force_full": bool(
            force_full or (pending or {}).get("force_full", False)
        ),
    }
    _ragdoll_debug_event(
        "resimulation_scheduled",
        driver=driver.name,
        frame=int(frame),
    )
    if not bpy.app.timers.is_registered(_ragdoll_resimulation_timer):
        register_owned_timer(
            _ragdoll_resimulation_timer, first_interval=0.12
        )
    return True


def _ragdoll_driver_pose_signature(driver, frame):
    """Stable authored-driver signature; simulated descendants are excluded."""
    return (
        int(frame),
        tuple(
            round(float(driver.matrix_basis[row][column]), 7)
            for row in range(4)
            for column in range(4)
        ),
    )


def _ragdoll_modifier_signature(curve):
    """Fingerprint modifier parameters without retaining any Blender RNA."""
    def properties(value):
        result = []
        for prop in value.bl_rna.properties:
            if prop.identifier in {'rna_type', 'name'}:
                continue
            if prop.type not in {'BOOLEAN', 'INT', 'FLOAT', 'STRING', 'ENUM'}:
                continue
            item = getattr(value, prop.identifier)
            result.append((prop.identifier, tuple(item) if getattr(prop, 'is_array', False) else item))
        return tuple(result)
    return tuple((properties(modifier), tuple(properties(point) for point in
        getattr(modifier, 'control_points', ()))) for modifier in curve.modifiers)


def _ragdoll_driver_curve_signature(armature, driver):
    """Fingerprint transform keys that define a hierarchy driver's path."""
    prefix = f"pose.bones[{json.dumps(driver.name)}]."
    valid_paths = {prefix + suffix for suffix in _RAGDOLL_TRANSFORM_SUFFIXES}
    curves = []
    for curve in _action_fcurves(_ragdoll_action(armature), armature):
        if str(curve.data_path) not in valid_paths:
            continue
        curves.append((
            str(curve.data_path),
            int(curve.array_index),
            tuple(
                (
                    round(float(point.co.x), 5),
                    round(float(point.co.y), 7),
                    str(point.interpolation), tuple(point.handle_left), tuple(point.handle_right),
                    point.easing, point.back, point.amplitude, point.period,
                )
                for point in curve.keyframe_points
            ),
            curve.extrapolation, _ragdoll_modifier_signature(curve),
        ))
    return tuple(sorted(curves))


def _ragdoll_publish_frame_driver_signatures(scene, frame):
    """Mark the evaluated ancestor poses owned by one completed frame solve."""
    published = _state.setdefault("ragdoll_driver_preview_signatures", {})
    seen = set()
    for armature in tuple(scene.objects):
        if armature.type != "ARMATURE" or getattr(armature, "pose", None) is None:
            continue
        for pose_bone in armature.pose.bones:
            if not _ragdoll_active(pose_bone, int(frame)):
                continue
            driver = _ragdoll_parent(armature, pose_bone)
            while driver is not None:
                key = (armature.name_full, driver.name, int(frame))
                if key not in seen:
                    published[key] = _ragdoll_driver_pose_signature(
                        driver, frame
                    )
                    seen.add(key)
                driver = _ragdoll_parent(armature, driver)


def _ragdoll_curve_signature_point_count(signature):
    return sum(len(curve[2]) for curve in tuple(signature or ()))


def _ragdoll_label(pose_bone):
    axis = str(getattr(pose_bone, RAGDOLL_GRAVITY_AXIS_RNA, "Z_NEG"))
    axis_label = {
        "X_POS": "+X", "X_NEG": "-X", "Y_POS": "+Y",
        "Y_NEG": "-Y", "Z_POS": "+Z", "Z_NEG": "-Z",
    }.get(axis, "-Z")
    acceleration = float(
        getattr(pose_bone, RAGDOLL_ACCELERATION_RNA, _RAGDOLL_DEFAULT_WEIGHT)
    )
    return f"Ragdoll · {axis_label} · {acceleration:.2f}"


def _ragdoll_path(pose_bone, property_name=RAGDOLL_ENABLED_PROPERTY):
    return f"pose.bones[{json.dumps(pose_bone.name)}][{json.dumps(property_name)}]"


def _ragdoll_action(armature):
    animation_data = getattr(armature, "animation_data", None)
    return getattr(animation_data, "action", None)


def _ragdoll_curve(armature, pose_bone):
    return next(iter(_ragdoll_curves(armature, pose_bone)), None)


def _ragdoll_curves(armature, pose_bone):
    path = _ragdoll_path(pose_bone)
    evaluation = _state.get("ragdoll_evaluation_curves")
    if evaluation is not None:
        key = armature.as_pointer()
        if key not in evaluation:
            evaluation[key] = _ragdoll_curve_index(armature)
        return evaluation[key].get(path, ())
    return tuple(
        curve
        for curve in _action_fcurves(_ragdoll_action(armature), armature)
        if str(getattr(curve, "data_path", "")) == path
    )


def _ragdoll_curve_index(armature):
    """Index marker curves once instead of rescanning an Action per bone."""
    suffix = f"[{json.dumps(RAGDOLL_ENABLED_PROPERTY)}]"
    indexed = {}
    for curve in _action_fcurves(_ragdoll_action(armature), armature):
        path = str(getattr(curve, "data_path", ""))
        if not path.startswith('pose.bones[') or not path.endswith(suffix):
            continue
        indexed.setdefault(path, []).append(curve)
    return {
        path: tuple(curves)
        for path, curves in indexed.items()
    }


def _ragdoll_scene_has_data(scene):
    """Cheaply reject scenes with no ragdoll markers or legacy state."""
    if (
        _state.get("ragdoll_marker_signatures")
        or _state.get("ragdoll_states")
        or _state.get("ragdoll_frame_cache")
    ):
        return True
    for armature in tuple(getattr(scene, "objects", ())):
        if armature.type != "ARMATURE" or getattr(armature, "pose", None) is None:
            continue
        if _ragdoll_curve_index(armature):
            return True
        if any(
            RAGDOLL_ENABLED_PROPERTY in pose_bone
            for pose_bone in armature.pose.bones
        ):
            return True
    return False


def _depsgraph_has_action_update(depsgraph):
    """Return whether a depsgraph pass contains an Action update."""
    if depsgraph is None:
        return True
    try:
        return any(
            isinstance(update.id, bpy.types.Action)
            for update in depsgraph.updates
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        return True


def _ragdoll_curve_active_at(curve, frame):
    points = sorted(
        (float(point.co[0]), float(point.co[1]))
        for point in curve.keyframe_points
    )
    previous = next(
        (point for point in reversed(points) if point[0] <= float(frame) + 1.0e-4),
        None,
    )
    return previous is not None and previous[1] >= 0.5


def _ragdoll_migrate_legacy_start_keys():
    """Remove the 1.6.641/642 synthetic zero one frame before first Start."""
    changed = False
    for armature in tuple(getattr(bpy.data, "objects", ())):
        if armature.type != "ARMATURE" or getattr(armature, "pose", None) is None:
            continue
        for pose_bone in armature.pose.bones:
            legacy_weight = float(
                getattr(
                    pose_bone,
                    RAGDOLL_ACCELERATION_RNA,
                    _RAGDOLL_DEFAULT_WEIGHT,
                )
            )
            if (
                _ragdoll_curve(armature, pose_bone) is not None
                and abs(legacy_weight - _RAGDOLL_LEGACY_DEFAULT_WEIGHT)
                <= 1.0e-5
            ):
                setattr(
                    pose_bone,
                    RAGDOLL_ACCELERATION_RNA,
                    _RAGDOLL_DEFAULT_WEIGHT,
                )
                changed = True
            stored_damping = float(
                pose_bone.get(RAGDOLL_DAMPING_PROPERTY, 0.94)
            )
            if any(
                abs(stored_damping - legacy) <= 1.0e-6
                for legacy in (0.94, *_RAGDOLL_LEGACY_CHAIN_DAMPINGS)
            ):
                pose_bone[RAGDOLL_DAMPING_PROPERTY] = _RAGDOLL_CHAIN_DAMPING
                changed = True
            if abs(float(pose_bone.get(RAGDOLL_BOUNCE_PROPERTY, 0.15)) - 0.15) <= 1.0e-6:
                pose_bone[RAGDOLL_BOUNCE_PROPERTY] = 0.0
                changed = True
            curve = _ragdoll_curve(armature, pose_bone)
            if curve is None:
                continue
            if _RAGDOLL_BASELINE_KEYS_PROPERTY not in pose_bone:
                _ragdoll_store_transform_baseline(armature, pose_bone)
                changed = True
            if _RAGDOLL_AUTHORED_FRAMES_PROPERTY not in pose_bone:
                pose_bone[_RAGDOLL_AUTHORED_FRAMES_PROPERTY] = "[]"
                changed = True
            points = sorted(curve.keyframe_points, key=lambda point: float(point.co[0]))
            for point in tuple(points):
                if float(point.co[1]) < 0.5:
                    changed = (
                        _ragdoll_remove_generated_pose_keys(
                            armature, pose_bone, float(point.co[0])
                        )
                        or changed
                    )
            if len(points) < 2:
                continue
            first, second = points[0], points[1]
            if (
                float(first.co[1]) < 0.5
                and float(second.co[1]) >= 0.5
                and abs(float(second.co[0]) - float(first.co[0]) - 1.0) <= 1.0e-4
            ):
                try:
                    curve.keyframe_points.remove(first)
                    curve.update()
                    changed = True
                except (ReferenceError, RuntimeError, TypeError, ValueError):
                    pass
    return changed


def _ragdoll_active(pose_bone, frame, curves=None):
    armature = getattr(pose_bone, "id_data", None)
    if curves is None:
        curves = _ragdoll_curves(armature, pose_bone) if armature is not None else ()
    if curves:
        try:
            return any(_ragdoll_curve_active_at(curve, frame) for curve in curves)
        except (ReferenceError, RuntimeError, TypeError, ValueError):
            pass
    return float(pose_bone.get(RAGDOLL_ENABLED_PROPERTY, 0.0)) >= 0.5


def _ragdoll_transform_key_samples(armature, pose_bone):
    prefix = f"pose.bones[{json.dumps(pose_bone.name)}]."
    samples = []
    for curve in _action_fcurves(_ragdoll_action(armature), armature):
        path = str(getattr(curve, "data_path", ""))
        if not any(path == prefix + suffix for suffix in _RAGDOLL_TRANSFORM_SUFFIXES):
            continue
        for point in getattr(curve, "keyframe_points", ()):
            try:
                samples.append((
                    path,
                    int(getattr(curve, "array_index", 0)),
                    float(point.co[0]),
                    float(point.co[1]),
                ))
            except (AttributeError, IndexError, TypeError, ValueError):
                continue
    return tuple(samples)


def _ragdoll_store_transform_baseline(armature, pose_bone):
    pose_bone[_RAGDOLL_BASELINE_KEYS_PROPERTY] = json.dumps(
        _ragdoll_transform_key_samples(armature, pose_bone),
        separators=(",", ":"),
    )


def _ragdoll_start_poses(pose_bone):
    try:
        packed = _state.get("ragdoll_modal_start_poses", {}).get(
            _ragdoll_state_key(pose_bone.id_data, pose_bone),
            pose_bone.get(_RAGDOLL_START_POSES_PROPERTY, "{}"),
        )
        data = json.loads(str(packed))
        return data if isinstance(data, dict) else {}
    except (TypeError, ValueError):
        return {}


def _ragdoll_write_start_poses(pose_bone, poses):
    packed = json.dumps(poses, separators=(",", ":"))
    owner = pose_bone.id_data
    key = _ragdoll_state_key(owner, pose_bone)
    if (_pin_active_transform_operator(bpy.context)
            and not _ragdoll_transform_edits_keys(bpy.context)):
        # ID-property writes invalidate Action evaluation while Blender's
        # transform owns the driver channels. Keep boundary edits as plain
        # data until that native transform confirms or cancels.
        _state.setdefault("ragdoll_modal_start_poses", {})[key] = packed
    else:
        _state.get("ragdoll_modal_start_poses", {}).pop(key, None)
        if pose_bone.get(_RAGDOLL_START_POSES_PROPERTY) != packed:
            pose_bone[_RAGDOLL_START_POSES_PROPERTY] = packed


def _ragdoll_finish_modal_start_poses(armature, *, cancel=False):
    pending = _state.get("ragdoll_modal_start_poses", {})
    for key in tuple(pending):
        if key[0] != armature.name_full:
            continue
        packed = pending.pop(key)
        bone = armature.pose.bones.get(key[1])
        if not cancel and bone is not None and bone.get(_RAGDOLL_START_POSES_PROPERTY) != packed:
            bone[_RAGDOLL_START_POSES_PROPERTY] = packed


def _ragdoll_store_start_pose(pose_bone, frame):
    """Persist the exact visible pose and its connected-parent relationship."""
    from mathutils import Euler
    pose_matrix = pose_bone.matrix.copy()
    parent = _ragdoll_parent(pose_bone.id_data, pose_bone)
    rotation_path = ("rotation_quaternion" if pose_bone.rotation_mode == "QUATERNION"
                     else "rotation_axis_angle" if pose_bone.rotation_mode == "AXIS_ANGLE"
                     else "rotation_euler")
    # Preserve an unkeyed Start adjustment as an offset, while ordinary
    # driving keys (including deletions) remain authoritative for motion.
    source = {name: list(getattr(pose_bone, name))
              for name in ("location", rotation_path, "scale")}
    prefix = pose_bone.path_from_id() + "."
    for curve in _action_fcurves(_ragdoll_action(pose_bone.id_data), pose_bone.id_data):
        suffix = curve.data_path[len(prefix):] if curve.data_path.startswith(prefix) else ""
        if suffix in source and curve.keyframe_points:
            source[suffix][curve.array_index] = float(curve.evaluate(frame))
    values = source[rotation_path]
    source_rotation = (Quaternion(values) if rotation_path == "rotation_quaternion"
        else Quaternion(Vector(values[1:]), values[0]) if rotation_path == "rotation_axis_angle"
        else Euler(values, pose_bone.rotation_mode).to_quaternion())
    source_rotation.normalize()
    offset = {
        "location": list(pose_bone.location - Vector(source["location"])),
        "rotation": list(pose_bone.matrix_basis.to_quaternion() @ source_rotation.inverted()),
        "scale": [float(value) / original if abs(original) > 1e-8 else 1.0
                  for value, original in zip(pose_bone.scale, source["scale"])],
    }
    poses = _ragdoll_start_poses(pose_bone)
    poses[str(int(round(float(frame))))] = {
        "space": "POSE",
        "channel_source": source,
        "channel_offset": offset,
        "local_scale": list(pose_bone.scale),
        "matrix": [
            float(pose_matrix[row][column])
            for row in range(4)
            for column in range(4)
        ],
        "parent": parent.name if parent is not None else "",
        "parent_relative_matrix": (
            [
                float(value)
                for row in (
                    parent.matrix.inverted_safe() @ pose_matrix
                )
                for value in row
            ]
            if parent is not None
            else []
        ),
    }
    _ragdoll_write_start_poses(pose_bone, poses)


def _ragdoll_apply_stored_start_pose(pose_bone, frame, *, connected=False):
    values = _ragdoll_start_poses(pose_bone).get(
        str(int(round(float(frame))))
    )
    pose_space = isinstance(values, dict) and values.get("space") == "POSE"
    if not pose_space:
        return False
    matrix_values = values.get("matrix")
    if not isinstance(matrix_values, list) or len(matrix_values) != 16:
        return False
    try:
        restored = Matrix(
            tuple(
                tuple(
                    float(matrix_values[(row * 4) + column])
                    for column in range(4)
                )
                for row in range(4)
            )
        )
        parent = pose_bone.parent
        relative_values = values.get("parent_relative_matrix")
        if (
            connected
            and parent is not None
            and str(values.get("parent", "")) == parent.name
            and isinstance(relative_values, list)
            and len(relative_values) == 16
        ):
            relative = Matrix(
                tuple(
                    tuple(
                        float(relative_values[(row * 4) + column])
                        for column in range(4)
                    )
                    for row in range(4)
                )
            )
            restored = parent.matrix @ relative
            restore_space = "PARENT_RELATIVE"
        else:
            restore_space = "POSE"
        pose_bone.matrix = restored
        _ragdoll_debug_event(
            "start_pose_restore",
            bone=pose_bone.name,
            frame=int(round(float(frame))),
            connected=bool(connected),
            restore_space=restore_space,
            has_relative=bool(
                isinstance(relative_values, list)
                and len(relative_values) == 16
            ),
            parent=(parent.name if parent is not None else ""),
            restored_translation=tuple(float(value) for value in restored.translation),
        )
    except (ReferenceError, RuntimeError, TypeError, ValueError):
        return False
    return True


def _ragdoll_authored_frames(pose_bone):
    try:
        return tuple(sorted({
            float(frame)
            for frame in json.loads(
                str(pose_bone.get(_RAGDOLL_AUTHORED_FRAMES_PROPERTY, "[]"))
            )
        }))
    except (TypeError, ValueError):
        return ()


def _ragdoll_add_authored_frame(pose_bone, frame):
    frames = set(_ragdoll_authored_frames(pose_bone))
    frames.add(float(frame))
    pose_bone[_RAGDOLL_AUTHORED_FRAMES_PROPERTY] = json.dumps(
        sorted(frames), separators=(",", ":")
    )


def _ragdoll_transform_keyframes(armature, pose_bone):
    del armature
    # Only a pose the orange bone actually authored may suspend gravity.
    # Inferring intent from newly appearing F-curve points is unsafe: auto-key,
    # keying-set spillover, copy/paste, and action reconciliation can all add a
    # transform point without the user moving this ragdoll.  Treating those
    # points as an override clears the simulation state on every playback
    # frame, leaving the limb completely frozen.  The depsgraph edit detector
    # records real orange-bone edits in this explicit list instead.
    return _ragdoll_authored_frames(pose_bone)


def _ragdoll_marker_signature(armature, pose_bone, curves=None):
    if curves is None:
        curves = _ragdoll_curves(armature, pose_bone)
    if not curves:
        return ()
    return tuple(
        sorted(
            (
                round(float(point.co[0]), 4),
                round(float(point.co[1]), 4),
            )
            for curve in curves
            for point in curve.keyframe_points
        )
    )


def _ragdoll_remove_generated_pose_keys(armature, pose_bone, frame):
    prefix = f"pose.bones[{json.dumps(pose_bone.name)}]."
    valid_paths = {prefix + suffix for suffix in _RAGDOLL_TRANSFORM_SUFFIXES}
    changed = False
    for curve in _action_fcurves(_ragdoll_action(armature), armature):
        if str(getattr(curve, "data_path", "")) not in valid_paths:
            continue
        curve_changed = False
        for point in tuple(curve.keyframe_points):
            if (
                str(getattr(point, "type", "")) != "GENERATED"
                or abs(float(point.co[0]) - float(frame)) > 1.0e-4
            ):
                continue
            curve.keyframe_points.remove(point)
            curve_changed = True
            changed = True
        if curve_changed:
            curve.update()
    return changed


def _ragdoll_active_start_frame(armature, pose_bone, frame):
    signature = _ragdoll_marker_signature(armature, pose_bone)
    starts = [point_frame for point_frame, value in signature if value >= 0.5 and point_frame <= float(frame) + 1.0e-4]
    return max(starts) if starts else None


def _ragdoll_last_pose_key_frame(armature, pose_bone, start_frame):
    prefix = f"pose.bones[{json.dumps(pose_bone.name)}]."
    valid_paths = {prefix + suffix for suffix in _RAGDOLL_TRANSFORM_SUFFIXES}
    frames = []
    for curve in _action_fcurves(_ragdoll_action(armature), armature):
        if str(getattr(curve, "data_path", "")) not in valid_paths:
            continue
        for point in curve.keyframe_points:
            if (
                str(getattr(point, "type", "")) != "GENERATED"
                and float(point.co[0]) <= float(start_frame) + 1.0e-4
            ):
                frames.append(float(point.co[0]))
    return max(frames) if frames else None


def _ragdoll_previous_pose_key_frame(armature, pose_bone, frame):
    """Return the last regular pose key strictly before ``frame``."""
    return _ragdoll_last_pose_key_frame(
        armature, pose_bone, float(frame) - 1.0e-3
    )


def _ragdoll_apply_start_pose_source(armature, pose_bone, frame):
    start_frame = _ragdoll_active_start_frame(
        armature, pose_bone, frame
    )
    if start_frame is None:
        return False
    connected = not _ragdoll_free(
        armature, pose_bone, int(round(float(start_frame)))
    )
    if _ragdoll_apply_stored_start_pose(
        pose_bone, start_frame, connected=connected
    ):
        return True
    source_frame = _ragdoll_last_pose_key_frame(
        armature, pose_bone, start_frame
    )
    if source_frame is None:
        # Legacy files predate persisted Start poses. Freeze their first
        # ordinary evaluated boundary once so later playback cannot morph it.
        _ragdoll_store_start_pose(pose_bone, start_frame)
        return True
    changed = _unparent_apply_action_pose_channels(
        _ragdoll_action(armature), pose_bone, source_frame
    )
    _ragdoll_store_start_pose(pose_bone, start_frame)
    if changed:
        try:
            bpy.context.view_layer.update()
        except (AttributeError, RuntimeError):
            pass
    return changed


def _ragdoll_reconcile_marker_edits(scene):
    if _state.get("ragdoll_marker_reconciling", False):
        return False
    _state["ragdoll_marker_reconciling"] = True
    signatures = _state.setdefault("ragdoll_marker_signatures", {})
    current_keys = set()
    changed = False
    frame = int(scene.frame_current)
    try:
        for armature in tuple(scene.objects):
            if armature.type != "ARMATURE" or getattr(armature, "pose", None) is None:
                continue
            curve_index = _ragdoll_curve_index(armature)
            for pose_bone in armature.pose.bones:
                # Blender's native X deletion may remove only the selected
                # authored Start and leave its generated End behind.  Such a
                # curve is not a legal segment and must not keep orange state
                # alive.  A lone authored Start remains legal/open-ended.
                action = _ragdoll_action(armature)
                curves = curve_index.get(_ragdoll_path(pose_bone), ())
                remaining_curves = []
                for curve in curves:
                    if curve.keyframe_points and not any(
                        float(point.co[1]) >= 0.5
                        for point in curve.keyframe_points
                    ):
                        _action_remove_fcurve(action, curve)
                        changed = True
                        continue
                    remaining_curves.append(curve)
                signature = _ragdoll_marker_signature(
                    armature,
                    pose_bone,
                    curves=remaining_curves,
                )
                key = _ragdoll_state_key(armature, pose_bone)
                if not signature:
                # Match Dynamic Parent/Unparent orphan cleanup: deleting all
                # marker keys or the whole channel removes the feature state,
                # runtime simulation, and orange status instead of falling
                # back to the stale ID property forever.
                    if (
                        key in signatures
                        or RAGDOLL_ENABLED_PROPERTY in pose_bone
                    ):
                        signatures.pop(key, None)
                        _ragdoll_invalidate_bones((pose_bone,))
                        for property_name in (
                            RAGDOLL_ENABLED_PROPERTY,
                            _RAGDOLL_BASELINE_KEYS_PROPERTY,
                            _RAGDOLL_AUTHORED_FRAMES_PROPERTY,
                            _RAGDOLL_START_POSES_PROPERTY,
                        ):
                            if property_name in pose_bone:
                                del pose_bone[property_name]
                        _unparent_apply_action_pose_channels(
                            action, pose_bone, frame
                        )
                        changed = True
                    continue
                current_keys.add(key)
                previous = signatures.get(key)
                signatures[key] = signature
                if previous is None or previous == signature:
                    continue
                old_starts = sorted(f for f, value in previous if value >= .5)
                new_starts = sorted(f for f, value in signature if value >= .5)
                if len(old_starts) == len(new_starts) and old_starts != new_starts:
                    # A dragged marker carries its authored Start pose. Leaving
                    # that pose indexed at its old frame rejects native replay
                    # and exposes a slow fallback until another edit repairs it.
                    poses = _ragdoll_start_poses(pose_bone)
                    moved = {str(int(round(new))): poses[str(int(round(old)))]
                             for old, new in zip(old_starts, new_starts)
                             if str(int(round(old))) in poses}
                    for old in old_starts:
                        poses.pop(str(int(round(old))), None)
                    poses.update(moved)
                    _ragdoll_write_start_poses(pose_bone, poses)
                for old_frame, value in previous:
                    if value < 0.5:
                        _ragdoll_remove_generated_pose_keys(
                            armature, pose_bone, old_frame
                        )
                _state.setdefault("ragdoll_states", {}).pop(key, None)
                _state.setdefault("ragdoll_frame_cache", {}).pop(key, None)
                if not _ragdoll_active(pose_bone, frame):
                    _unparent_apply_action_pose_channels(
                        action, pose_bone, frame
                    )
                changed = True
        for key in tuple(signatures):
            if key not in current_keys:
                signatures.pop(key, None)
        if changed:
            _sync_all_dynamic_pose_bone_colors(frame)
            try:
                bpy.context.view_layer.update()
            except (AttributeError, RuntimeError):
                pass
        return changed
    finally:
        _state["ragdoll_marker_reconciling"] = False


def _ragdoll_animation_owns_frame(armature, pose_bone, frame):
    """Let a bounded pair of authored pose keys own its interpolation window."""
    if _state.get("ragdoll_baking", False) or _ragdoll_active(pose_bone, frame):
        return False
    frames = _ragdoll_transform_keyframes(armature, pose_bone)
    if any(abs(key - frame) <= 1.0e-4 for key in frames):
        return True
    previous = next((key for key in reversed(frames) if key < frame), None)
    following = next((key for key in frames if key > frame), None)
    return previous is not None and following is not None


def _ragdoll_state_key(armature, pose_bone):
    # Blender can replace an Object datablock during unrelated Undo/Redo,
    # changing session_uid even though the rig and bone are semantically the
    # same. Names are unique inside bpy.data and remain stable across history.
    return (str(getattr(armature, "name_full", armature.name)), pose_bone.name)


def _ragdoll_invalidate_bones(pose_bones):
    states = _state.setdefault("ragdoll_states", {})
    caches = _state.setdefault("ragdoll_frame_cache", {})
    samples = _state.setdefault("ragdoll_boundary_pose_samples", {})
    targets = list(pose_bones)
    frame = int(getattr(getattr(bpy.context, "scene", None), "frame_current", 0))
    seen = {
        _ragdoll_state_key(pose_bone.id_data, pose_bone)
        for pose_bone in targets
    }
    # Changing one marker can change which node is the highest active
    # ragdoll root. Invalidate only its connected active hierarchy, not
    # unrelated orange bones elsewhere in the rig.
    for pose_bone in tuple(targets):
        armature = pose_bone.id_data
        # End/Clear/deleted markers also change descendant sockets, even
        # though this selected parent is no longer orange at the edit frame.
        for candidate in armature.pose.bones:
            key = _ragdoll_state_key(armature, candidate)
            if key in seen or not _ragdoll_active(candidate, frame):
                continue
            if (
                _ragdoll_is_ancestor(armature, pose_bone, candidate)
                or _ragdoll_is_ancestor(armature, candidate, pose_bone)
            ):
                seen.add(key)
                targets.append(candidate)
    for pose_bone in targets:
        key = _ragdoll_state_key(pose_bone.id_data, pose_bone)
        states.pop(key, None)
        caches.pop(key, None)
        samples.pop(key, None)
    # Evaluated mesh bounds may have moved with an edited/keyed bone. They
    # are cheap to rebuild and unsafe to retain after simulation invalidation.
    _state.setdefault("ragdoll_collision_bounds", {}).clear()


def _ragdoll_store_boundary_cache(cache, frame, state, tolerance):
    previous = cache.get(int(frame))
    changed = bool(
        previous is None
        or bool(previous.get("free", False)) != bool(state.get("free", False))
        or (
            Vector(previous.get("anchor", state["anchor"]))
            - Vector(state["anchor"])
        ).length > tolerance
        or (
            Vector(previous.get("position", state["position"]))
            - Vector(state["position"])
        ).length > tolerance
    )
    if changed:
        cache.clear()
    cache[int(frame)] = {
        name: value.copy() if hasattr(value, "copy") else value
        for name, value in state.items()
    }
    return changed


def _ragdoll_world_points(armature, pose_bone):
    return (
        armature.matrix_world @ pose_bone.head,
        armature.matrix_world @ pose_bone.tail,
    )


def _ragdoll_connected_anchor(armature, pose_bone):
    """Return the real parent socket, independent of the simulated limb."""
    parent = pose_bone.parent
    if parent is None:
        parent_name = str(pose_bone.bone.get(REL_K_PARENT, ""))
        parent = armature.pose.bones.get(parent_name) if parent_name else None
    if parent is None:
        # Orange alone anchors a root at its captured start in object space.
        return _ragdoll_rigid_reference(armature, pose_bone)[0].translation.copy()
    start = _ragdoll_active_start_frame(armature, pose_bone, bpy.context.scene.frame_current)
    values = _ragdoll_start_poses(pose_bone).get(str(int(round(start)))) if start is not None else None
    if isinstance(values, dict) and values.get("editable_socket"):
        relative = values.get("parent_relative_matrix", ())
        if len(relative) == 16:
            return armature.matrix_world @ parent.matrix @ Vector((relative[3], relative[7], relative[11]))
    socket_matrix = (
        parent.matrix
        @ parent.bone.matrix_local.inverted_safe()
        @ pose_bone.bone.matrix_local
    )
    return (armature.matrix_world @ socket_matrix).translation.copy()


def _ragdoll_connected_rotation(armature, pose_bone):
    """Return the current world rotation of the limb's connected parent."""
    parent = pose_bone.parent
    if parent is None:
        parent_name = str(pose_bone.bone.get(REL_K_PARENT, ""))
        parent = armature.pose.bones.get(parent_name) if parent_name else None
    if parent is None:
        return armature.matrix_world.to_quaternion()
    return (armature.matrix_world @ parent.matrix).to_quaternion()


def _ragdoll_rebase_start_branch(armature, driver, frame):
    """Make a same-Start-frame hierarchy edit a zero-velocity initial pose."""
    states = _state.setdefault("ragdoll_states", {})
    caches = _state.setdefault("ragdoll_frame_cache", {})
    changed = False
    for pose_bone in armature.pose.bones:
        if (
            not _ragdoll_active(pose_bone, frame)
            or not _ragdoll_is_ancestor(armature, driver, pose_bone)
            or _ragdoll_free(armature, pose_bone, frame)
        ):
            continue
        start = _ragdoll_active_start_frame(armature, pose_bone, frame)
        if start is None or int(round(float(start))) != int(frame):
            continue
        key = _ragdoll_state_key(armature, pose_bone)
        state = states.get(key)
        if state is None or int(state.get("frame", -1)) != int(frame):
            state = caches.get(key, {}).get(int(frame))
        if state is None:
            continue
        if _surface_contact_guides_for_pose_bone(pose_bone, int(frame)):
            # Contact owns the editable Start pose. Re-anchoring it to the
            # socket after its magnet solve makes the two solvers fight.
            # Capture the solved result; integration begins on the next frame.
            head, tail = _ragdoll_matrix_world_points(armature, pose_bone)
            orientation = (armature.matrix_world @ pose_bone.matrix).to_quaternion()
            previous_orientation = state.get("orientation")
            if (previous_orientation is not None
                    and (head - Vector(state["anchor"])).length_squared < 1.e-12
                    and (tail - Vector(state["position"])).length_squared < 1.e-12
                    and abs(orientation.dot(Quaternion(previous_orientation))) > 1.0 - 1.e-7):
                # Dependency echoes are not another edit. Writing identical
                # custom properties dirties the rig and perpetuates redraws.
                changed = True
                continue
            initial = {
                "frame": int(frame), "anchor": head.copy(), "position": tail.copy(),
                "anchor_previous": head.copy(), "previous": tail.copy(),
                "velocity": Vector((0.0, 0.0, 0.0)),
                "orientation": orientation,
                "socket_rotation": _ragdoll_connected_rotation(armature, pose_bone),
                "free": False, "seeded": True, "start_authoritative": True,
            }
            states[key] = initial
            caches[key] = {int(frame): dict(initial)}
            _ragdoll_store_start_pose(pose_bone, frame)
            poses = _ragdoll_start_poses(pose_bone)
            poses[str(int(frame))]["editable_socket"] = True
            _ragdoll_write_start_poses(pose_bone, poses)
            changed = True
            continue
        old_anchor = Vector(state.get("anchor", (0.0, 0.0, 0.0)))
        old_position = Vector(state.get("position", old_anchor))
        new_anchor = _ragdoll_connected_anchor(armature, pose_bone)
        if new_anchor is None:
            continue
        new_rotation = _ragdoll_connected_rotation(armature, pose_bone)
        old_rotation = state.get("socket_rotation")
        radial = old_position - old_anchor
        if old_rotation is not None:
            radial = new_rotation @ old_rotation.inverted() @ radial
        length = _ragdoll_world_length(armature, pose_bone)
        if radial.length <= 1.0e-8:
            _anchor, visible_tail = _ragdoll_matrix_world_points(
                armature, pose_bone, connected=True
            )
            radial = visible_tail - new_anchor
        if radial.length <= 1.0e-8:
            radial = Vector((0.0, -1.0, 0.0))
        new_position = new_anchor + radial.normalized() * length
        if (old_rotation is not None
                and (new_anchor - old_anchor).length_squared < 1.e-12
                and (new_position - old_position).length_squared < 1.e-12
                and abs(new_rotation.dot(old_rotation)) > 1.0 - 1.e-7):
            changed = True
            continue
        rebased = {
            name: value.copy() if hasattr(value, "copy") else value
            for name, value in state.items()
        }
        rebased.update({
            "frame": int(frame),
            "position": new_position.copy(),
            "previous": new_position.copy(),
            "velocity": Vector((0.0, 0.0, 0.0)),
            "anchor": new_anchor.copy(),
            "anchor_previous": new_anchor.copy(),
            "anchor_velocity": Vector((0.0, 0.0, 0.0)),
            "socket_rotation": new_rotation.copy(),
            "free": False,
            "seeded": True,
            "start_authoritative": True,
        })
        states[key] = rebased
        cache = caches.setdefault(key, {})
        for cached_frame in tuple(cache):
            if int(cached_frame) >= int(frame):
                cache.pop(cached_frame, None)
        cache[int(frame)] = {
            name: value.copy() if hasattr(value, "copy") else value
            for name, value in rebased.items()
        }
        _ragdoll_apply_tail(
            armature, pose_bone, new_anchor, new_position, free=False
        )
        _ragdoll_store_start_pose(pose_bone, frame)
        _ragdoll_debug_event(
            "start_hierarchy_rebase",
            driver=driver.name,
            bone=pose_bone.name,
            frame=int(frame),
            anchor_delta=tuple(
                float(value) for value in (new_anchor - old_anchor)
            ),
            old_position=tuple(float(value) for value in old_position),
            new_position=tuple(float(value) for value in new_position),
            rotated=bool(old_rotation is not None),
            velocity=(0.0, 0.0, 0.0),
        )
        changed = True
    return changed


def _ragdoll_matrix_world_points(armature, pose_bone, *, connected=False, authored=False):
    matrix_world = (
        _ragdoll_rigid_reference(armature, pose_bone)[0] if authored
        else armature.matrix_world @ pose_bone.matrix
    )
    anchor = (
        _ragdoll_connected_anchor(armature, pose_bone)
        if connected
        else None
    )
    head = anchor if anchor is not None else matrix_world.translation.copy()
    # Moving the head onto its socket must translate the whole rigid limb.
    # Aiming at the old world-space tail incorrectly rotates translated poses.
    offset = matrix_world.to_3x3() @ Vector((0.0, float(pose_bone.bone.length), 0.0))
    return head, head + offset


def _ragdoll_world_length(armature, pose_bone):
    matrix_world, _scale = _ragdoll_rigid_reference(armature, pose_bone)
    return max(
        1.0e-5,
        (matrix_world.to_3x3() @ Vector((0.0, float(pose_bone.bone.length), 0.0))).length,
    )


def _ragdoll_seed_tail(anchor, tail, length, free):
    if free:
        return Vector(tail).copy()
    direction = Vector(tail) - Vector(anchor)
    if direction.length <= 1.0e-8:
        direction = Vector((0.0, -1.0, 0.0))
    return Vector(anchor) + direction.normalized() * float(length)


def _ragdoll_collision(context, excluded, start, end, radius, bounce, friction):
    movement = end - start
    distance = movement.length
    if distance <= 1.0e-8:
        return end, None, None
    hit = _surface_contact_ray_cast(
        context,
        Vector(start),
        movement / distance,
        distance + radius,
        excluded,
    )
    if hit is None:
        return end, None, None
    _obj, location, normal, _travelled = hit
    normal = Vector(normal).normalized()
    corrected = Vector(location) + normal * radius
    velocity = movement
    normal_velocity = normal * velocity.dot(normal)
    tangent_velocity = velocity - normal_velocity
    reflected = tangent_velocity * max(0.0, 1.0 - friction) - normal_velocity * bounce
    return corrected, reflected, normal


def _ragdoll_collision_shape(context, armature, pose_bone, fallback_radius):
    """Return a welded-family capsule radius and its self-collision exclusions."""
    key = _ragdoll_state_key(armature, pose_bone)
    cache = _state.setdefault("ragdoll_collision_shapes", {})
    cached = cache.get(key)
    if cached is None:
        radius = float(fallback_radius)
        object_names = set()
        support_samples = ()
        support_normals = ()
        try:
            evaluated_armature, evaluated_bone, _part, points, parts = (
                _surface_contact_part_geometry(context, armature, pose_bone)
            )
            if evaluated_bone is not None and points:
                bone_world = (
                    evaluated_armature.matrix_world @ evaluated_bone.matrix
                )
                inverse_bone_world = bone_world.inverted_safe()
                local_points = tuple(
                    inverse_bone_world @ Vector(point) for point in points
                )
                head = evaluated_armature.matrix_world @ evaluated_bone.head
                tail = evaluated_armature.matrix_world @ evaluated_bone.tail
                axis = tail - head
                if axis.length > 1.0e-8:
                    axis.normalize()
                    radius = max(
                        radius,
                        max(
                            (
                                Vector(point)
                                - head
                                - axis * (Vector(point) - head).dot(axis)
                            ).length
                            for point in points
                        ),
                    )
                directions = tuple(
                    Vector((x, y, z)).normalized()
                    for x in (-1.0, 1.0)
                    for y in (-1.0, 1.0)
                    for z in (-1.0, 1.0)
                )
                selected = {}
                for direction in directions:
                    point = max(
                        local_points,
                        key=lambda candidate: candidate.dot(direction),
                    )
                    selected[tuple(round(float(value), 7) for value in point)] = (
                        point.copy()
                    )
                support_samples = tuple(selected.values())
                bone_rotation_inverse = bone_world.to_quaternion().inverted()
                normals = {}
                for part in parts:
                    part_rotation = part.matrix_world.to_quaternion()
                    for axis in (
                        Vector((1.0, 0.0, 0.0)),
                        Vector((0.0, 1.0, 0.0)),
                        Vector((0.0, 0.0, 1.0)),
                    ):
                        local_normal = (
                            bone_rotation_inverse @ (part_rotation @ axis)
                        ).normalized()
                        for normal in (local_normal, -local_normal):
                            normals[
                                tuple(round(float(value), 6) for value in normal)
                            ] = normal.copy()
                support_normals = tuple(normals.values())
            object_names.update(part.name for part in parts)
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            pass
        cached = {
            "radius": radius,
            "objects": tuple(sorted(object_names)),
            "samples": support_samples,
            "normals": support_normals,
        }
        cache[key] = cached
    excluded = {armature}
    excluded.update(
        obj
        for name in cached.get("objects", ())
        if (obj := bpy.data.objects.get(str(name))) is not None
    )
    # Keep the current bone's own welded parts excluded, but allow the other
    # visible parts driven by this armature to participate as self-collision.
    # Only the proximal shared socket receives articulation clearance.
    # Cross-body contacts retain the complete visible support hull.
    return (
        max(float(fallback_radius), float(cached.get("radius", fallback_radius))),
        excluded,
        tuple(Vector(point) for point in cached.get("samples", ())),
        tuple(Vector(normal) for normal in cached.get("normals", ())),
    )


def _ragdoll_tail_world_matrix(reference_world, anchor, tail):
    direction = Vector(tail) - Vector(anchor)
    current_y = reference_world.to_3x3().col[1]
    if direction.length <= 1.0e-8 or current_y.length <= 1.0e-8:
        return reference_world.copy()
    swing = current_y.normalized().rotation_difference(direction.normalized())
    return Matrix.LocRotScale(
        Vector(anchor),
        (swing @ reference_world.to_quaternion()).normalized(),
        reference_world.to_scale(),
    )


def _ragdoll_collision_surfaces(context, excluded):
    """Cache visible evaluated collision candidates once per target frame."""
    key = (
        str(context.scene.name_full),
        int(context.scene.frame_current),
    )
    cache = _state.setdefault("ragdoll_collision_surfaces", {})
    names = cache.get(key)
    if names is None:
        names = tuple(
            obj.name_full
            for obj in context.scene.objects
            if obj.type == "MESH"
            and _surface_contact_object_visible(context, obj)
            and not bool(obj.get(SURFACE_CONTACT_GUIDE_PROPERTY, False))
        )
        cache[key] = names
        if len(cache) > 8:
            for old_key in tuple(cache)[:-8]:
                cache.pop(old_key, None)
    return tuple(
        obj
        for name in names
        if (obj := bpy.data.objects.get(name)) is not None
        and obj not in excluded
        and _surface_contact_object_visible(context, obj)
    )


def _ragdoll_collision_setup(
    context, armature, pose_bone, fallback_radius
):
    """Build the immutable collision inputs once for one bone/frame step."""
    evaluation = _state.get("ragdoll_evaluation_curves")
    key = ("collision_setup", armature.as_pointer(), pose_bone.name,
           int(context.scene.frame_current), float(fallback_radius))
    if evaluation is not None and key in evaluation:
        return evaluation[key]
    radius, excluded, samples, normals = _ragdoll_collision_shape(
        context, armature, pose_bone, fallback_radius
    )
    surfaces = _ragdoll_collision_surfaces(context, excluded)
    surfaces = _ragdoll_filter_joint_neighbor_surfaces(
        armature,
        pose_bone,
        int(context.scene.frame_current),
        surfaces,
    )
    result = radius, excluded, samples, normals, surfaces
    if evaluation is not None:
        evaluation[key] = result
    return result


def _ragdoll_surface_world_bounds(context, surface, depsgraph):
    """Return one evaluated world AABB per object/frame for collision broad phase."""
    key = (
        str(context.scene.name_full),
        int(context.scene.frame_current),
        str(surface.name_full),
    )
    cache = _state.setdefault("ragdoll_collision_bounds", {})
    cached = cache.get(key)
    if cached is not None:
        return Vector(cached[0]), Vector(cached[1])
    evaluated = surface.evaluated_get(depsgraph)
    points = tuple(
        evaluated.matrix_world @ Vector(corner)
        for corner in evaluated.bound_box
    )
    minimum = Vector(tuple(
        min(point[axis] for point in points) for axis in range(3)
    ))
    maximum = Vector(tuple(
        max(point[axis] for point in points) for axis in range(3)
    ))
    cache[key] = (tuple(minimum), tuple(maximum))
    if len(cache) > 512:
        current_frame = int(context.scene.frame_current)
        for old_key in tuple(cache):
            if int(old_key[1]) != current_frame:
                cache.pop(old_key, None)
    return minimum, maximum


def _ragdoll_self_collision_surface(surface, armature):
    try:
        return bool(
            surface.parent == armature
            or surface.find_armature() == armature
            or any(
                getattr(constraint, "target", None) == armature
                for constraint in surface.constraints
            )
        )
    except (AttributeError, ReferenceError, RuntimeError):
        return False


def _ragdoll_contact_surface_local_frame(context, surface, point, normal):
    """Store a contact plane in the collider's local coordinates."""
    try:
        evaluated = surface.evaluated_get(context.evaluated_depsgraph_get())
        matrix = evaluated.matrix_world.copy()
        local_point = matrix.inverted_safe() @ Vector(point)
        # world_normal = M^-T local_normal, therefore local_normal = M^T world.
        local_normal = matrix.to_3x3().transposed() @ Vector(normal)
        if local_normal.length <= 1.0e-8:
            return None
        return (
            str(surface.name_full),
            local_point.copy(),
            local_normal.normalized(),
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return None


def _ragdoll_contact_surface_world_frame(context, state):
    """Resolve a stored collider-local plane at its current evaluated pose."""
    name = str(state.get("contact_surface", ""))
    local_point = state.get("contact_point_local")
    local_normal = state.get("contact_normal_local")
    if not name or local_point is None or local_normal is None:
        return None
    try:
        surface = bpy.data.objects.get(name)
        if surface is None:
            return None
        evaluated = surface.evaluated_get(context.evaluated_depsgraph_get())
        matrix = evaluated.matrix_world.copy()
        normal = matrix.to_3x3().inverted_safe().transposed() @ Vector(
            local_normal
        )
        if normal.length <= 1.0e-8:
            return None
        return matrix @ Vector(local_point), normal.normalized(), surface
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return None


def _ragdoll_compact_collision_samples(samples, stretch):
    if not samples:
        return ()
    local_samples = tuple(Vector(sample) for sample in samples)
    minimum_y = min(sample.y for sample in local_samples)
    maximum_y = max(sample.y for sample in local_samples)
    span = maximum_y - minimum_y
    if span <= 1.0e-6:
        return local_samples
    # A direct parent/child shares the proximal socket, so samples inside a
    # short head band would permanently collide at a valid joint. Preserve
    # the *actual* width/depth and distal boundary instead of shrinking the
    # whole welded hull: global contraction allowed visible limbs to travel
    # far into the torso before CCD noticed them.
    socket_fraction = max(0.08, min(0.3, 0.12 + float(stretch) * 0.18))
    threshold = minimum_y + span * socket_fraction
    distal = tuple(sample.copy() for sample in local_samples if sample.y >= threshold)
    return distal or local_samples


def _ragdoll_scaled_collision_samples(samples, scale):
    """Contract a welded hull around its centre for same-rig contacts only."""
    local_samples = tuple(Vector(sample) for sample in samples)
    if not local_samples:
        return ()
    scale = min(1.0, max(0.8, float(scale)))
    center = sum(local_samples, Vector((0.0, 0.0, 0.0))) / float(
        len(local_samples)
    )
    return tuple(center + (sample - center) * scale for sample in local_samples)


def _ragdoll_unstable_equilibrium_impulse(
    armature, pose_bone, position, anchor, acceleration, length
):
    """Release a perfectly inverted hinge without adding random simulation."""
    radial = Vector(position) - Vector(anchor)
    acceleration = Vector(acceleration)
    if radial.length <= 1.0e-8 or acceleration.length <= 1.0e-8:
        return Vector((0.0, 0.0, 0.0))
    radial.normalize()
    gravity_direction = acceleration.normalized()
    tangent = acceleration - radial * acceleration.dot(radial)
    if radial.dot(-gravity_direction) < 0.9995 or tangent.length > 1.0e-4:
        return Vector((0.0, 0.0, 0.0))
    world_basis = armature.matrix_world.to_3x3()
    lateral = world_basis @ Vector((1.0, 0.0, 0.0))
    lateral -= radial * lateral.dot(radial)
    if lateral.length <= 1.0e-8:
        lateral = world_basis @ Vector((0.0, 1.0, 0.0))
        lateral -= radial * lateral.dot(radial)
    if lateral.length <= 1.0e-8:
        return Vector((0.0, 0.0, 0.0))
    # A stable name-derived sign makes replay/scrub results identical while
    # preventing mirrored upright bones from all falling onto the same side.
    sign = -1.0 if sum(
        (index + 1) * ord(character)
        for index, character in enumerate(str(pose_bone.name))
    ) & 1 else 1.0
    speed = min(
        0.25,
        max(0.04, math.sqrt(acceleration.length * max(1.0e-5, length)) * 0.015),
    )
    return lateral.normalized() * (sign * speed)


def _ragdoll_joint_clearance_pair(old_point, new_point, socket, radius):
    """Trim a swept sample to the part outside a shared-joint sphere."""
    old_point = Vector(old_point)
    new_point = Vector(new_point)
    socket = Vector(socket)
    radius = max(0.0, float(radius))
    old_offset = old_point - socket
    new_offset = new_point - socket
    old_inside = old_offset.length <= radius
    new_inside = new_offset.length <= radius
    if new_inside:
        # Motion wholly into the articulated socket volume is intentionally
        # collision-free. It cannot tunnel into the rest of the parent because
        # distal samples remain outside and retain the full visible hull.
        return None
    if not old_inside:
        return old_point, new_point
    movement = new_point - old_point
    a = movement.length_squared
    if a <= 1.0e-12:
        return None
    b = 2.0 * old_offset.dot(movement)
    c = old_offset.length_squared - radius * radius
    discriminant = max(0.0, b * b - 4.0 * a * c)
    exit_fraction = (-b + math.sqrt(discriminant)) / (2.0 * a)
    exit_fraction = min(1.0, max(0.0, exit_fraction + 1.0e-5))
    return old_point.lerp(new_point, exit_fraction), new_point


def _ragdoll_joint_slot_contains(direction, rest_direction, cosine_limit):
    """Return whether a limb points inside its parent-relative socket cone."""
    direction = Vector(direction)
    rest_direction = Vector(rest_direction)
    if direction.length <= 1.0e-8 or rest_direction.length <= 1.0e-8:
        return False
    return direction.normalized().dot(rest_direction.normalized()) >= float(
        cosine_limit
    )


def _ragdoll_joint_motion_direction(direction, fallback_matrix):
    """Return the solver's real anchor-to-tail direction for socket tests."""
    direction = Vector(direction) if direction is not None else Vector()
    if direction.length > 1.0e-8:
        return direction.normalized()
    fallback = fallback_matrix.to_3x3() @ Vector((0.0, 1.0, 0.0))
    return fallback.normalized() if fallback.length > 1.0e-8 else fallback


def _ragdoll_joint_rest_direction(armature, pose_bone):
    """Natural limb direction following its parent's current pose."""
    parent = _ragdoll_parent(armature, pose_bone)
    if parent is None:
        return None
    socket_matrix = (
        parent.matrix
        @ parent.bone.matrix_local.inverted_safe()
        @ pose_bone.bone.matrix_local
    )
    world_matrix = armature.matrix_world @ socket_matrix
    direction = world_matrix.to_3x3() @ Vector(
        (0.0, float(pose_bone.bone.length), 0.0)
    )
    return direction.normalized() if direction.length > 1.0e-8 else None


def _ragdoll_state_joint_rest_direction(
    state, armature, pose_bone, anchor, evaluated_tail
):
    """Return the socket rest slot in the parent's current moving frame."""
    # The articulation slot belongs to the physical parent, not world space.
    # Recompute it from the current parent matrix so a falling/turning torso
    # carries shoulder, hip, and neck sockets without making their limbs clip
    # into the body or get pushed toward a stale world-space direction.
    moving_rest_direction = _ragdoll_joint_rest_direction(
        armature, pose_bone
    )
    if (
        moving_rest_direction is not None
        and moving_rest_direction.length > 1.0e-8
    ):
        return moving_rest_direction.normalized()
    stored = state.get("joint_rest_direction")
    if stored is not None and Vector(stored).length > 1.0e-8:
        return Vector(stored).normalized()
    # Imported rigs can have a bind/rest bone axis opposite their evaluated
    # pose direction. The confirmed start pose is the user-visible truth for
    # a ball socket, so seed the cone from that pose instead of bind metadata.
    direction = Vector(state.get("position", evaluated_tail)) - Vector(anchor)
    if direction.length <= 1.0e-8:
        direction = Vector(evaluated_tail) - Vector(anchor)
    if direction.length > 1.0e-8:
        return direction.normalized()
    return _ragdoll_joint_rest_direction(armature, pose_bone)


def _ragdoll_direct_joint_surface(surface, armature, pose_bone):
    target_bone = _ragdoll_surface_pose_bone(surface, armature)
    return bool(
        target_bone is not None
        and (
            target_bone == _ragdoll_parent(armature, pose_bone)
            or _ragdoll_parent(armature, target_bone) == pose_bone
        )
    )


def _ragdoll_welded_sweep(
    context,
    surfaces,
    samples,
    old_matrix,
    new_matrix,
    *,
    armature=None,
    pose_bone=None,
    compact_samples=(),
    joint_clearance_radius=0.0,
    joint_rest_direction=None,
    joint_slot_cosine=-1.0,
    joint_direction=None,
    self_collision_scale=1.0,
):
    """Return the earliest exact welded-boundary contact in this substep."""
    earliest = None
    if not surfaces or not samples:
        return earliest
    depsgraph = context.evaluated_depsgraph_get()
    sample_sets = {
        (False, False): tuple(samples),
        (False, True): _ragdoll_scaled_collision_samples(
            samples, self_collision_scale
        ),
    }
    if compact_samples:
        sample_sets[(True, False)] = tuple(compact_samples)
        sample_sets[(True, True)] = _ragdoll_scaled_collision_samples(
            compact_samples, self_collision_scale
        )
    sweeps = {}
    for surface in surfaces:
        is_self_surface = bool(
            armature is not None
            and _ragdoll_self_collision_surface(surface, armature)
        )
        target_bone = (
            _ragdoll_surface_pose_bone(surface, armature)
            if is_self_surface and pose_bone is not None
            else None
        )
        direct_joint_neighbor = bool(
            target_bone is not None
            and _ragdoll_direct_joint_surface(surface, armature, pose_bone)
        )
        # Never skip the complete parent surface. A direct joint only exempts
        # its proximal ball-socket volume below; distal support samples must
        # still collide with the torso even while the bone direction remains
        # inside its natural articulation cone.
        # Only a shared socket needs an articulation margin. Sibling and
        # cross-body contacts use the complete welded support hull; otherwise
        # their visible meshes can overlap deeply before compact CCD reports
        # the recorded zero-fraction recovery.
        # A direct joint uses the distal support samples plus the spherical
        # clearance below. Keeping the proximal socket band out of CCD avoids
        # treating a valid connected rest pose as permanent self-penetration;
        # distal width/depth still prevents entry into the parent's body.
        compact = bool(
            is_self_surface and direct_joint_neighbor and compact_samples
        )
        sample_key = (compact, is_self_surface and float(self_collision_scale) != 1.0)
        if sample_key not in sweeps:
            pairs = tuple((old_matrix @ point, new_matrix @ point)
                          for point in sample_sets[sample_key])
            points = tuple(point for pair in pairs for point in pair)
            sweeps[sample_key] = (
                pairs,
                Vector(tuple(min(point[axis] for point in points) for axis in range(3))),
                Vector(tuple(max(point[axis] for point in points) for axis in range(3))),
            )
        pairs, sweep_min, sweep_max = sweeps[sample_key]
        if direct_joint_neighbor and float(joint_clearance_radius) > 0.0:
            if target_bone == _ragdoll_parent(armature, pose_bone):
                socket = _ragdoll_connected_anchor(armature, pose_bone)
            else:
                socket = _ragdoll_connected_anchor(armature, target_bone)
            if socket is not None:
                pairs = tuple(
                    trimmed
                    for old_point, new_point in pairs
                    if (trimmed := _ragdoll_joint_clearance_pair(
                        old_point,
                        new_point,
                        socket,
                        joint_clearance_radius,
                    )) is not None
                )
                if not pairs:
                    continue
                points = tuple(point for pair in pairs for point in pair)
                sweep_min = Vector(tuple(
                    min(point[axis] for point in points) for axis in range(3)
                ))
                sweep_max = Vector(tuple(
                    max(point[axis] for point in points) for axis in range(3)
                ))
        # Broad phase: Blender's Object.ray_cast expects object-space rays and
        # evaluates mesh geometry for every call. Reject non-overlapping world
        # AABBs before any of those expensive narrow-phase casts.
        try:
            surface_min, surface_max = _ragdoll_surface_world_bounds(
                context, surface, depsgraph
            )
            margin = 1.0e-4
            if any(
                sweep_max[axis] < surface_min[axis] - margin
                or sweep_min[axis] > surface_max[axis] + margin
                for axis in range(3)
            ):
                continue
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            pass
        surface_ray_hit = False
        for old_point, new_point in pairs:
            movement = new_point - old_point
            distance = movement.length
            if distance <= 1.0e-8:
                continue
            direction = movement / distance
            hit = _surface_contact_object_ray_cast(
                surface,
                old_point,
                direction,
                distance + 1.0e-5,
                depsgraph,
            )
            if hit is None:
                continue
            surface_ray_hit = True
            location, normal = hit
            travelled = max(
                0.0, float((Vector(location) - old_point).dot(direction))
            )
            fraction = min(1.0, max(0.0, travelled / distance))
            if earliest is None or fraction < earliest[0]:
                earliest = (
                    fraction,
                    Vector(normal).normalized(),
                    Vector(location).copy(),
                    surface,
                )
        if surface_ray_hit:
            continue
        # A ray only reports a boundary crossing. If the frame begins with a
        # shallow overlap it can start inside and miss the entry face. Run the
        # more expensive closest-point recovery only after every sweep ray for
        # this overlapping AABB missed; normal contacts stay on the fast path.
        deepest_overlap = None
        recovery_distance = max(
            0.02,
            max(
                ((new_point - old_point).length for old_point, new_point in pairs),
                default=0.0,
            ) * 2.0,
        )
        # Self-collision must test the complete welded support hull.  Sampling
        # only four of eight corners could miss a leg already inside a torso
        # or arm; the AABB gate above keeps this full recovery off the normal
        # fast path for non-overlapping objects.
        recovery_stride = (
            1 if is_self_surface else max(1, len(pairs) // 4)
        )
        for _old_point, new_point in pairs[::recovery_stride]:
            closest = _surface_contact_closest_point(
                surface, new_point, depsgraph, recovery_distance
            )
            if closest is None:
                continue
            location, normal = closest
            signed_distance = (new_point - Vector(location)).dot(Vector(normal))
            if signed_distance >= -1.0e-5:
                continue
            if deepest_overlap is None or signed_distance < deepest_overlap[0]:
                deepest_overlap = (
                    signed_distance,
                    Vector(normal).normalized(),
                    Vector(location).copy(),
                )
        if deepest_overlap is not None:
            _distance, normal, location = deepest_overlap
            return (0.0, normal, location, surface)
    return earliest


def _ragdoll_project_contact(anchor, candidate, length, contact_center, normal):
    """Solve the rigid length and non-penetration constraints together."""
    result = Vector(candidate)
    contact_center = Vector(contact_center)
    normal = Vector(normal).normalized()
    for _iteration in range(6):
        radial = result - anchor
        if radial.length > 1.0e-8:
            result = anchor + radial.normalized() * length
        penetration = (result - contact_center).dot(normal)
        if penetration < 0.0:
            result -= normal * penetration
    radial = result - anchor
    if radial.length > 1.0e-8:
        result = anchor + radial.normalized() * length
    return result


def _ragdoll_project_welded_contact(
    reference_world, anchor, candidate, length, samples, contact_point, normal,
):
    """Project contact on the socket's rotation manifold; never stretch the rod."""
    normal = Vector(normal).normalized()
    contact_point = Vector(contact_point)
    direction = Vector(candidate) - anchor
    if direction.length <= 1.0e-8 or not samples:
        return Vector(candidate)
    direction.normalize()
    epsilon = 1.0e-3
    for _iteration in range(24):
        matrix = _ragdoll_tail_world_matrix(reference_world, anchor, anchor + direction * length)
        point = min(samples, key=lambda sample: (matrix @ sample).dot(normal))
        distance = ((matrix @ point) - contact_point).dot(normal)
        if distance >= -1.0e-5:
            break
        first_axis = direction.orthogonal().normalized()
        second_axis = direction.cross(first_axis).normalized()
        derivatives = []
        for axis in (first_axis, second_axis):
            perturbed = Quaternion(axis, epsilon) @ direction
            perturbed_matrix = _ragdoll_tail_world_matrix(
                reference_world, anchor, anchor + perturbed * length
            )
            derivatives.append(((perturbed_matrix @ point) - (matrix @ point)).dot(normal) / epsilon)
        gradient = first_axis * derivatives[0] + second_axis * derivatives[1]
        magnitude = gradient.length
        if magnitude < 1.0e-7:
            break
        # A bounded angular Newton step solves the visible support constraint
        # directly. Translating and renormalizing the tail left deep overlaps.
        angle = min(0.25, (-distance + 1.0e-5) / magnitude)
        direction = (Quaternion(gradient / magnitude, angle) @ direction).normalized()
    return Vector(anchor) + direction * length


def _ragdoll_resolve_self_contacts(
    context, armature, pose_bone, reference, anchor, tail, length, samples, surfaces, velocity
):
    """Project simultaneous inter-limb contacts without adding correction momentum."""
    candidates = tuple(
        surface for surface in surfaces
        if _ragdoll_self_collision_surface(surface, armature)
        and not _ragdoll_direct_joint_surface(surface, armature, pose_bone)
    )
    if not samples or not candidates:
        return tail, velocity
    depsgraph = context.evaluated_depsgraph_get()
    result = Vector(tail)
    for _iteration in range(6):
        changed = False
        for surface in candidates:
            matrix = _ragdoll_tail_world_matrix(reference, anchor, result)
            points = tuple(matrix @ sample for sample in samples)
            minimum, maximum = _ragdoll_surface_world_bounds(context, surface, depsgraph)
            if any(
                max(point[axis] for point in points) < minimum[axis] - 1.0e-4
                or min(point[axis] for point in points) > maximum[axis] + 1.0e-4
                for axis in range(3)
            ):
                continue
            deepest = None
            for point in points:
                hit = _surface_contact_closest_point(surface, point, depsgraph, length)
                if hit is None:
                    continue
                location, normal = hit
                distance = (point - location).dot(normal)
                if distance < -1.0e-4 and (deepest is None or distance < deepest[0]):
                    deepest = (distance, location, normal)
            if deepest is None:
                continue
            _distance, point, normal = deepest
            projected = _ragdoll_project_welded_contact(
                reference, anchor, result, length, samples, point, normal
            )
            changed |= (projected - result).length > 1.0e-5
            result = projected
            inward = velocity.dot(normal)
            if inward < 0.0:
                velocity -= normal * inward
        if not changed:
            break
    # Finite faces can make successive tangent planes conflict at a corner.
    # Search a small angular neighborhood only when projection still overlaps;
    # choose the nearest clear orientation instead of accepting penetration.
    def penetration(candidate):
        matrix = _ragdoll_tail_world_matrix(reference, anchor, candidate)
        points = tuple(matrix @ sample for sample in samples)
        worst = 0.0
        for surface in candidates:
            minimum, maximum = _ragdoll_surface_world_bounds(context, surface, depsgraph)
            if any(
                max(point[axis] for point in points) < minimum[axis] - 1.0e-4
                or min(point[axis] for point in points) > maximum[axis] + 1.0e-4
                for axis in range(3)
            ):
                continue
            for point in points:
                hit = _surface_contact_closest_point(surface, point, depsgraph, length)
                if hit is not None:
                    worst = max(worst, -(point - hit[0]).dot(hit[1]))
        return worst

    residual = penetration(result)
    if residual > 1.0e-3:
        direction = (Vector(tail) - anchor).normalized()
        first = direction.orthogonal().normalized()
        second = direction.cross(first).normalized()
        for angle in (0.15, 0.3, 0.6, 1.0):
            for index in range(8):
                azimuth = index * math.tau / 8.0
                axis = first * math.cos(azimuth) + second * math.sin(azimuth)
                candidate = Vector(anchor) + (Quaternion(axis, angle) @ direction) * length
                depth = penetration(candidate)
                if depth < residual:
                    result, residual = candidate, depth
                    # Recovery chooses a pose, not an extra impact impulse.
                    velocity.zero()
                if residual <= 1.0e-3:
                    return result, velocity
    return result, velocity


def _ragdoll_rigid_reference(armature, pose_bone):
    """Use authored shape/twist; simulated output is never a new input."""
    frame = bpy.context.scene.frame_current
    start = _ragdoll_active_start_frame(armature, pose_bone, frame)
    values = (
        _ragdoll_start_poses(pose_bone).get(str(int(round(start))))
        if start is not None else None
    )
    if not isinstance(values, dict) or len(values.get("matrix", ())) != 16:
        return armature.matrix_world @ pose_bone.matrix, pose_bone.scale.copy()
    packed = values["matrix"]
    reference = Matrix(tuple(
        tuple(packed[row * 4 + column] for column in range(4))
        for row in range(4)
    ))
    relative_values = values.get("parent_relative_matrix", ())
    parent = _ragdoll_parent(armature, pose_bone)
    if parent is not None and len(relative_values) == 16:
        relative = Matrix(tuple(
            tuple(relative_values[row * 4 + column] for column in range(4))
            for row in range(4)
        ))
        basis = (
            pose_bone.bone.matrix_local.inverted_safe()
            @ parent.bone.matrix_local @ relative
        )
        if not _ragdoll_free(armature, pose_bone, frame):
            reference = parent.matrix @ relative
    else:
        basis = pose_bone.bone.matrix_local.inverted_safe() @ reference
    scale = Vector(values.get("local_scale", basis.to_scale()))
    return armature.matrix_world @ reference, scale


def _ragdoll_apply_tail(
    armature,
    pose_bone,
    anchor,
    tail,
    *,
    free=False,
    orientation=None,
    report_change=False,
):
    """Publish a pose; optionally report RNA writes instead of valid application."""
    if _ragdoll_contact_start_transaction(armature, pose_bone, bpy.context.scene.frame_current):
        return False
    direction = tail - anchor
    if direction.length <= 1.0e-8:
        return False
    current_world, authored_scale = _ragdoll_rigid_reference(armature, pose_bone)
    current_y = current_world.to_3x3().col[1]
    if current_y.length <= 1.0e-8:
        return False
    if orientation is not None:
        # A detached welded object is a full rigid body. Its orientation has
        # a roll degree of freedom which cannot be reconstructed from only
        # the head-to-tail direction; discarding it is what allowed a box to
        # freeze forever on one corner instead of rotating onto a face.
        rotation = Quaternion(orientation).normalized()
    else:
        # Rotate the current bone by the shortest swing that aligns its Y axis
        # with the simulated limb.  Unlike to_track_quat(Y, Z), this preserves
        # authored twist/roll and has no vertical up-axis singularity.
        swing = current_y.normalized().rotation_difference(direction.normalized())
        rotation = (swing @ current_world.to_quaternion()).normalized()
    world_matrix = Matrix.LocRotScale(
        Vector(anchor),
        rotation,
        current_world.to_scale(),
    )
    pose_matrix = armature.matrix_world.inverted_safe() @ world_matrix
    # Even assigning the same RNA value dirties the dependency graph. Idle
    # holds and playback-stop callbacks must not repeatedly publish an already
    # correct pose (and trigger viewport/gizmo refreshes as a side effect).
    # During held timeline scrubbing Blender can reset the authored channels
    # before refreshing pose_bone.matrix. An equal evaluated matrix alone is
    # therefore not proof that the next evaluation will retain this pose.
    # Check the local input as well for ordinary, unconstrained bones, using
    # Blender's parent/inherit-scale conversion instead of hand-built TRS math.
    input_matches = True
    publication = _state.get("ragdoll_publication_matrices")
    if publication is not None:
        publication[pose_bone.name] = pose_matrix
    if not pose_bone.constraints:
        parent = pose_bone.parent
        parent_matrix = ((publication or {}).get(parent.name, parent.matrix)
                         if parent is not None else None)
        parent_args = (
            dict(parent_matrix=parent_matrix,
                 parent_matrix_local=parent.bone.matrix_local)
            if parent is not None else {}
        )
        desired_basis = pose_bone.bone.convert_local_to_pose(
            pose_matrix, pose_bone.bone.matrix_local,
            invert=True, **parent_args,
        )
        input_matches = max(
            abs(pose_bone.matrix_basis[row][column] - desired_basis[row][column])
            for row in range(4) for column in range(4)
        ) <= 2.0e-6
    if (
        input_matches
        and max(abs(pose_bone.matrix[row][column] - pose_matrix[row][column])
            for row in range(4) for column in range(4)) <= 2.0e-6
        and (pose_bone.scale - authored_scale).length <= 2.0e-6
    ):
        return not report_change
    if (pose_bone.scale - authored_scale).length > 2.0e-6:
        pose_bone.scale = authored_scale
    drove_unparent_helper = False
    if free:
        # Dynamic Unparent owns the evaluated pose through a Child Of helper.
        # Writing only pose_bone.matrix is therefore overwritten on the next
        # dependency-graph evaluation. Drive the active unparent helper with
        # the same desired pose-space factor so the simulated translation and
        # rotation remain authoritative and visible.
        input_matrix = _pose_space_input_matrix(pose_bone)
        desired_factor = pose_matrix @ input_matrix.inverted_safe()
        for constraint in pose_bone.constraints:
            source = _dynamic_space_source(pose_bone, constraint)
            role = _dynamic_space_role(pose_bone, constraint)
            target = getattr(constraint, "target", None)
            if (
                role == SPACE_ROLE_UNPARENT
                and source.startswith(SPACE_SOURCE_UNPARENT_PREFIX)
                and target is not None
                and bool(target.get(SPACE_HELPER_PROPERTY, False))
            ):
                target.matrix_basis = desired_factor
                drove_unparent_helper = True
    if not drove_unparent_helper:
        # A connected bone can still be owned by the NORMAL Dynamic Space
        # Child Of constraint which preserves its original rig parent.  In
        # that case pose_bone.matrix is the evaluated output, while assigning
        # pose_bone.matrix changes the constraint input.  Feeding the desired
        # output back as input applies the torso factor a second time (the
        # recorded pre-Unparent overshoot).  Remove the currently evaluated
        # factor once so the visible output is exactly the simulated pose.
        managed_constraint = next(
            (
                constraint
                for constraint in pose_bone.constraints
                if constraint.name.startswith((SPACE_CONSTRAINT_PREFIX, 'DP_'))
                and not bool(getattr(constraint, "mute", False))
                and float(getattr(constraint, "influence", 0.0)) > 0.0
            ),
            None,
        )
        if managed_constraint is not None:
            input_matrix = _pose_space_input_matrix(pose_bone)
            evaluated_factor = pose_bone.matrix @ input_matrix.inverted_safe()
            desired_input = evaluated_factor.inverted_safe() @ pose_matrix
            pose_bone.matrix_basis = (
                pose_bone.bone.matrix_local.inverted_safe() @ desired_input
            )
        else:
            if publication is not None and not pose_bone.constraints:
                # Publish parent and child channels atomically. Reading the
                # parent's old evaluated matrix here would detach the limbs
                # until a later dependency refresh during timeline scrubbing.
                pose_bone.matrix_basis = desired_basis
            else:
                pose_bone.matrix = pose_matrix
    if not drove_unparent_helper:
        pose_bone.scale = authored_scale
    return True


def _ragdoll_integrate(
    context, armature, pose_bone, state, anchor, evaluated_tail, length,
    *, collision_enabled=True, collision_setup=None,
):
    return _ragdoll_integrate_impl(
        context, armature, pose_bone, state, anchor, evaluated_tail, length,
        collision_enabled=collision_enabled, collision_setup=collision_setup,
    )


def _ragdoll_integrate_free(
    context, armature, pose_bone, state, *, collision_setup=None,
):
    return _ragdoll_integrate_free_impl(
        context, armature, pose_bone, state, collision_setup=collision_setup,
    )


def _ragdoll_detach_state(context, state):
    """Convert a connected pendulum state into one continuous rigid body."""
    fps = max(
        1.0,
        float(context.scene.render.fps)
        / max(1.0e-6, float(context.scene.render.fps_base)),
    )
    dt = 1.0 / fps
    detached = {
        name: value.copy() if hasattr(value, "copy") else value
        for name, value in state.items()
    }
    anchor = Vector(detached["anchor"])
    tail = Vector(detached["position"])
    radial = tail - anchor
    socket_velocity = Vector(
        detached.get("anchor_velocity", (0.0, 0.0, 0.0))
    )
    relative_tail_velocity = Vector(
        detached.get("velocity", (0.0, 0.0, 0.0))
    )
    angular_velocity = Vector((0.0, 0.0, 0.0))
    if radial.length_squared > 1.0e-8:
        angular_velocity = radial.cross(relative_tail_velocity) / radial.length_squared
    anchor_velocity = socket_velocity
    tail_velocity = socket_velocity + relative_tail_velocity
    detached.update({
        "free": True,
        # Parent socket speed owns free-body translation. Relative tail
        # motion is rotation, not additional COM velocity; adding half of it
        # caused the recorded 21.6 -> 23.9 units/s disconnect overshoot.
        "velocity": socket_velocity.copy(),
        "angular_velocity": angular_velocity,
        "anchor_previous": anchor - anchor_velocity * dt,
        "previous": tail - tail_velocity * dt,
        "contact_normal": None,
        "contact_point": None,
        "sleeping": False,
        "sleep_steps": 0,
    })
    return detached


def _ragdoll_reapply_same_frame(
    armature,
    pose_bone,
    state,
    anchor,
    evaluated_tail,
    length,
):
    if bool(state.get("free", False)):
        return _ragdoll_apply_tail(
            armature,
            pose_bone,
            Vector(state["anchor"]),
            Vector(state["position"]),
            free=True,
            orientation=state.get("orientation"),
        )
    position = Vector(state["position"])
    previous = Vector(state["previous"])
    old_anchor = Vector(state.get("anchor", anchor))
    anchor_delta = anchor - old_anchor
    if anchor_delta.length_squared > 1.0e-16:
        # A same-frame torso edit is an authoritative kinematic move.  Shift
        # both Verlet samples atomically so the leg follows immediately and
        # does not appear to float until the playhead advances.
        position += anchor_delta
        previous += anchor_delta
        state["previous"] = previous.copy()
        state["anchor_delta"] = (
            Vector(state.get("anchor_delta", Vector((0.0, 0.0, 0.0))))
            + anchor_delta
        )
    offset = position - anchor
    if offset.length <= 1.0e-8:
        offset = evaluated_tail - anchor
    if offset.length <= 1.0e-8:
        return False
    position = anchor + offset.normalized() * length
    state["position"] = position.copy()
    state["anchor"] = anchor.copy()
    return _ragdoll_apply_tail(armature, pose_bone, anchor, position)


def _ragdoll_step(context, armature, pose_bone, frame):
    # This index lives for exactly one solve. Never retain FCurve wrappers
    # across native deletion/undo or cache an evaluated marker value.
    previous = _state.get("ragdoll_evaluation_curves")
    if previous is None:
        _state["ragdoll_evaluation_curves"] = {}
    try:
        return _ragdoll_step_impl(context, armature, pose_bone, frame)
    finally:
        if previous is None:
            _state.pop("ragdoll_evaluation_curves", None)


def _ragdoll_step_impl(context, armature, pose_bone, frame):
    if _ragdoll_contact_start_transaction(armature, pose_bone, frame):
        return False
    key = _ragdoll_state_key(armature, pose_bone)
    states = _state.setdefault("ragdoll_states", {})
    cache = _state.setdefault("ragdoll_frame_cache", {}).setdefault(key, {})
    active_start = _ragdoll_active_start_frame(
        armature, pose_bone, int(frame)
    )
    if (
        active_start is not None
        and int(frame) == int(round(float(active_start)))
    ):
        cached_start = cache.get(int(frame))
        if cached_start is not None and bool(
            cached_start.get("start_authoritative", False)
        ):
            # Start is immutable once published. Same-frame hierarchy edits
            # explicitly rebase this cache in _ragdoll_rebase_start_branch;
            # ordinary scrubs/playback must replay it, never derive a new
            # Start from matrices that can still contain the previous frame's
            # simulation override.
            state = {
                name: value.copy() if hasattr(value, "copy") else value
                for name, value in cached_start.items()
            }
            states[key] = state
            return _ragdoll_apply_tail(
                armature,
                pose_bone,
                Vector(state["anchor"]),
                Vector(state["position"]),
                free=bool(state.get("free", False)),
                orientation=state.get("orientation"),
            )
        # Start is a boundary, never a continuation.  Re-evaluate the authored
        # pose after its parent/torso keys and discard every stale simulated
        # sample so changing the starting pose cannot manufacture velocity.
        start_unparented = _ragdoll_free(
            armature, pose_bone, int(frame)
        )
        _ragdoll_apply_start_pose_source(armature, pose_bone, int(frame))
        anchor, evaluated_tail = _ragdoll_matrix_world_points(
            armature, pose_bone, connected=not start_unparented, authored=True
        )
        evaluated_tail = _ragdoll_seed_tail(
            anchor,
            evaluated_tail,
            _ragdoll_world_length(armature, pose_bone),
            start_unparented,
        )
        state = {
            "frame": int(frame),
            "position": evaluated_tail.copy(),
            "previous": evaluated_tail.copy(),
            "velocity": Vector((0.0, 0.0, 0.0)),
            "anchor": anchor.copy(),
            "anchor_previous": anchor.copy(),
            "socket_rotation": _ragdoll_connected_rotation(
                armature, pose_bone
            ),
            "free": start_unparented,
            "seeded": True,
            "start_authoritative": True,
        }
        states[key] = state
        cached_start = cache.get(int(frame))
        tolerance = max(1.0e-5, float(pose_bone.bone.length) * 1.0e-4)
        start_changed = bool(
            cached_start is None
            or bool(cached_start.get("free", False)) != start_unparented
            or (
                Vector(cached_start.get("anchor", anchor)) - anchor
            ).length > tolerance
            or (
                Vector(cached_start.get("position", evaluated_tail))
                - evaluated_tail
            ).length > tolerance
        )
        if start_changed:
            cache.clear()
        cache[int(frame)] = {
            name: value.copy() if hasattr(value, "copy") else value
            for name, value in state.items()
        }
        _ragdoll_debug_event(
            "start_boundary_seed",
            bone=pose_bone.name,
            frame=int(frame),
            free=bool(start_unparented),
            cache_existed=bool(cached_start is not None),
            cache_cleared=bool(start_changed),
            anchor=tuple(float(value) for value in anchor),
            position=tuple(float(value) for value in evaluated_tail),
            velocity=(0.0, 0.0, 0.0),
        )
        return _ragdoll_apply_tail(
            armature,
            pose_bone,
            anchor,
            evaluated_tail,
            free=start_unparented,
        )
    if _surface_contact_guides_for_pose_bone(pose_bone, int(frame)):
        _state.setdefault("ragdoll_states", {}).pop(
            _ragdoll_state_key(armature, pose_bone), None
        )
        return False
    unparented = _ragdoll_free(armature, pose_bone, int(frame))
    anchor, evaluated_tail = _ragdoll_matrix_world_points(
        armature, pose_bone, connected=not unparented
    )
    length = _ragdoll_world_length(armature, pose_bone)
    collision_setup = None
    state = states.get(key)
    if state is None and not cache:
        current_unparented = _ragdoll_free(
            armature, pose_bone, int(frame)
        )
        _ragdoll_apply_start_pose_source(
            armature, pose_bone, int(frame)
        )
        anchor, evaluated_tail = _ragdoll_matrix_world_points(
            armature, pose_bone, connected=not current_unparented, authored=True
        )
        length = _ragdoll_world_length(armature, pose_bone)
        evaluated_tail = _ragdoll_seed_tail(
            anchor, evaluated_tail, length, current_unparented
        )
        active_start = _ragdoll_active_start_frame(
            armature, pose_bone, int(frame)
        )
        if active_start is not None:
            start_frame = int(round(float(active_start)))
            state = {
                "frame": start_frame,
                "position": evaluated_tail.copy(),
                "previous": evaluated_tail.copy(),
                "velocity": Vector((0.0, 0.0, 0.0)),
                "anchor": anchor.copy(),
                "anchor_previous": anchor.copy(),
                "free": _ragdoll_free(
                    armature, pose_bone, start_frame
                ),
                "seeded": True,
            }
            states[key] = state
            cache[start_frame] = {
                name: value.copy() if hasattr(value, "copy") else value
                for name, value in state.items()
            }
            if int(frame) == start_frame:
                return _ragdoll_apply_tail(
                    armature,
                    pose_bone,
                    anchor,
                    evaluated_tail,
                    free=bool(state.get("free", False)),
                )
    unparented = _ragdoll_free(armature, pose_bone, int(frame))
    boundary_sample = _state.setdefault(
        "ragdoll_boundary_pose_samples", {}
    ).get(key)
    if (
        state is not None
        and boundary_sample is not None
        and int(frame) > int(boundary_sample.get("frame", frame))
        and int(state.get("frame", frame))
        == int(boundary_sample.get("frame", frame))
    ):
        # A torso edit at Start is a new initial condition, not parent
        # acceleration.  The depsgraph boundary sample can still contain our
        # previous simulation override, so use it only as a dirty signal.
        # Rebuild the ordinary keyed leg pose under the newly evaluated torso
        # exactly as a frame-zero scrub does before integrating a later frame.
        sample_frame = int(boundary_sample["frame"])
        boundary_free = bool(boundary_sample.get("free", unparented))
        _ragdoll_apply_start_pose_source(
            armature, pose_bone, sample_frame
        )
        seed_anchor, seed_tail = _ragdoll_matrix_world_points(
            armature, pose_bone, connected=not boundary_free, authored=True
        )
        seed_tail = _ragdoll_seed_tail(
            seed_anchor,
            seed_tail,
            _ragdoll_world_length(armature, pose_bone),
            boundary_free,
        )
        state = {
            "frame": sample_frame,
            "position": seed_tail.copy(),
            "previous": seed_tail.copy(),
            "velocity": Vector((0.0, 0.0, 0.0)),
            "anchor": seed_anchor.copy(),
            "anchor_previous": seed_anchor.copy(),
            "free": boundary_free,
            "seeded": True,
        }
        states[key] = state
        cache.clear()
        cache[sample_frame] = {
            name: value.copy() if hasattr(value, "copy") else value
            for name, value in state.items()
        }
        _state["ragdoll_boundary_pose_samples"].pop(key, None)
    if (
        state is not None
        and int(state.get("frame", frame)) == int(frame)
        and not bool(state.get("seeded", True))
    ):
        # Until the first simulated frame, the evaluated ordinary leg key is
        # authoritative. Parent/torso edits at the Start frame therefore
        # update the physics seed instead of leaving a stale world-space tail.
        state.update({
            "position": evaluated_tail.copy(),
            "previous": evaluated_tail.copy(),
            "velocity": Vector((0.0, 0.0, 0.0)),
            "anchor": anchor.copy(),
            "anchor_previous": anchor.copy(),
            "free": unparented,
        })
        cache[int(frame)] = {
            name: value.copy() if hasattr(value, "copy") else value
            for name, value in state.items()
        }
        return _ragdoll_apply_tail(
            armature,
            pose_bone,
            anchor,
            evaluated_tail,
            free=unparented,
        )
    cached = cache.get(int(frame))
    if (
        cached is not None
        and unparented
        and not bool(cached.get("free", False))
    ):
        # A Dynamic Unparent key may be inserted on a frame already cached by
        # connected ragdoll playback. Preserve that exact swing pose and
        # velocity, but change ownership to the free-body solver immediately;
        # never replay the stale connected cache entry over the new key.
        state = _ragdoll_detach_state(context, cached)
        states[key] = state
        for cached_frame in tuple(cache):
            if int(cached_frame) > int(frame):
                cache.pop(cached_frame, None)
        cache[int(frame)] = {
            name: value.copy() if hasattr(value, "copy") else value
            for name, value in state.items()
        }
        return _ragdoll_apply_tail(
            armature,
            pose_bone,
            Vector(state["anchor"]),
            Vector(state["position"]),
            free=True,
        )
    if cached is not None:
        # An exact cached frame is authoritative in either playback direction.
        # Reintegrating a forward cache hit wastes collision work and bypasses
        # the frame handler's final contact pass (which runs only on misses).
        # Authored edits invalidate the affected cache explicitly.
        state = {
            name: value.copy() if hasattr(value, "copy") else value
            for name, value in cached.items()
        }
        states[key] = state
        applied = _ragdoll_apply_tail(
            armature,
            pose_bone,
            Vector(state["anchor"]),
            Vector(state["position"]),
            free=bool(state.get("free", False)),
            orientation=state.get("orientation"),
        )
        return applied
    # For an uncached scrub target, continue from the nearest authoritative
    # predecessor produced by the latest simulation. This makes access order
    # irrelevant and avoids replaying the whole range from a transient pose.
    prior_frames = [
        int(cached_frame)
        for cached_frame in cache
        if int(cached_frame) < int(frame)
    ]
    if prior_frames:
        prior_frame = max(prior_frames)
        if (
            state is None
            or int(state.get("frame", prior_frame)) > int(frame)
            or prior_frame > int(state.get("frame", -1048574))
        ):
            state = {
                name: value.copy() if hasattr(value, "copy") else value
                for name, value in cache[prior_frame].items()
            }
            states[key] = state
    if state is None:
        state = {
            "frame": int(frame) - 1,
            "position": evaluated_tail.copy(),
            "previous": evaluated_tail.copy(),
            "velocity": Vector((0.0, 0.0, 0.0)),
            "anchor": anchor.copy(),
            "anchor_previous": anchor.copy(),
            "free": unparented,
            "seeded": True,
        }
    elif bool(state.get("free", False)) != unparented:
        # Dynamic Unparent changes constraint ownership, not the visible
        # rigid-body pose. Preserve the exact simulated transform and its
        # velocity at the boundary instead of reseeding from a dependency-
        # graph result that may already contain the helper-space jump.
        state = {
            name: value.copy() if hasattr(value, "copy") else value
            for name, value in state.items()
        }
        if unparented:
            # Blender may skip the frame immediately before the marker during
            # playback. Advance the still-connected pendulum to the exact
            # socket pose on this boundary, then transfer socket translation
            # plus angular tail motion into free rigid-body momentum.
            state_frame = int(state.get("frame", int(frame) - 1))
            boundary_anchor = _ragdoll_connected_anchor(armature, pose_bone)
            if boundary_anchor is None:
                boundary_anchor = Vector(state.get("anchor", anchor))
            start_anchor = Vector(state.get("anchor", boundary_anchor))
            transition_steps = max(0, int(frame) - state_frame)
            if transition_steps > 0:
                fallback_radius = max(
                    0.001,
                    float(
                        pose_bone.get(
                            RAGDOLL_RADIUS_PROPERTY,
                            max(0.02, pose_bone.bone.length * 0.08),
                        )
                    ),
                )
                collision_setup = _ragdoll_collision_setup(
                    context,
                    armature,
                    pose_bone,
                    fallback_radius,
                )
            for index in range(1, transition_steps + 1):
                factor = float(index) / float(transition_steps)
                step_anchor = start_anchor.lerp(boundary_anchor, factor)
                radial = Vector(state["position"]) - Vector(state["anchor"])
                if radial.length <= 1.0e-8:
                    radial = evaluated_tail - anchor
                fallback_tail = step_anchor + radial.normalized() * length
                state = _ragdoll_integrate(
                    context,
                    armature,
                    pose_bone,
                    state,
                    step_anchor,
                    fallback_tail,
                    length,
                    collision_setup=collision_setup,
                )
                state["frame"] = state_frame + index
            state = _ragdoll_detach_state(context, state)
        else:
            state["free"] = False
            state["velocity"] = Vector((0.0, 0.0, 0.0))
            state["previous"] = Vector(state["position"]).copy()
            state["anchor_previous"] = Vector(state["anchor"]).copy()
            state["contact_normal"] = None
            state["contact_point"] = None
        # The Unparent marker frame is the exact handoff pose. Gravity begins
        # on the following frame; integrating here would create the one-frame
        # drop/teleport the user sees at the boundary.
        state["frame"] = int(frame)
        for cached_frame in tuple(cache):
            if int(cached_frame) >= int(frame):
                cache.pop(cached_frame, None)
        cache[int(frame)] = {
            name: value.copy() if hasattr(value, "copy") else value
            for name, value in state.items()
        }
    state_frame = int(state.get("frame", int(frame) - 1))
    if state_frame > int(frame):
        state = {
            "frame": int(frame) - 1,
            "position": evaluated_tail.copy(),
            "previous": evaluated_tail.copy(),
            "velocity": Vector((0.0, 0.0, 0.0)),
            "anchor": anchor.copy(),
            "anchor_previous": anchor.copy(),
            "free": unparented,
            "seeded": True,
        }
        state_frame = int(frame) - 1
    if state_frame == int(frame):
        states[key] = state
        return _ragdoll_reapply_same_frame(
            armature,
            pose_bone,
            state,
            anchor,
            evaluated_tail,
            length,
        )
    steps = max(1, min(1200, int(frame) - state_frame))
    start_anchor = Vector(state.get("anchor", anchor))
    if collision_setup is None:
        fallback_radius = max(
            0.001,
            float(
                pose_bone.get(
                    RAGDOLL_RADIUS_PROPERTY,
                    max(0.02, pose_bone.bone.length * 0.08),
                )
            ),
        )
        collision_setup = _ragdoll_collision_setup(
            context,
            armature,
            pose_bone,
            fallback_radius,
        )
    for index in range(1, steps + 1):
        factor = float(index) / float(steps)
        step_anchor = start_anchor.lerp(anchor, factor)
        if unparented:
            state = _ragdoll_integrate_free(
                context,
                armature,
                pose_bone,
                state,
                collision_setup=collision_setup,
            )
        else:
            state = _ragdoll_integrate(
                context,
                armature,
                pose_bone,
                state,
                step_anchor,
                evaluated_tail,
                length,
                collision_setup=collision_setup,
            )
        state["frame"] = state_frame + index
        cache[int(state["frame"])] = {
            name: value.copy() if hasattr(value, "copy") else value
            for name, value in state.items()
        }
    state["frame"] = int(frame)
    if not _ragdoll_apply_tail(
        armature,
        pose_bone,
        Vector(state["anchor"]) if unparented else anchor,
        Vector(state["position"]),
        free=unparented,
        orientation=(state.get("orientation") if unparented else None),
    ):
        return False
    states[key] = state
    if len(cache) > 600:
        for cached_frame in sorted(cache)[:-600]:
            cache.pop(cached_frame, None)
    return True


def _ragdoll_settle_frame_contacts(context, armature, pose_bones):
    """Publish the same final contact correction for playback and history replay."""
    scene = context.scene
    # Resolve against the final published sibling meshes. The
    # integration pass may see a sibling's earlier evaluated pose.
    context.view_layer.update()
    _state.pop("ragdoll_collision_bounds", None)
    for pose_bone in pose_bones:
        key = _ragdoll_state_key(armature, pose_bone)
        state = _state.get("ragdoll_states", {}).get(key)
        if not state or state.get("free") or state.get("start_authoritative"):
            continue
        setup = _ragdoll_collision_setup(context, armature, pose_bone, 0.02)
        reference, _scale = _ragdoll_rigid_reference(armature, pose_bone)
        position, velocity = _ragdoll_resolve_self_contacts(
            context, armature, pose_bone, reference,
            Vector(state["anchor"]), Vector(state["position"]),
            _ragdoll_world_length(armature, pose_bone), setup[2], setup[4],
            Vector(state["velocity"]),
        )
        if (position - Vector(state["position"])).length <= 1.0e-5:
            continue
        state["position"] = position.copy()
        state["velocity"] = velocity.copy()
        fps = max(1.0, scene.render.fps / max(1.0e-6, scene.render.fps_base))
        state["previous"] = position - velocity / fps
        _state["ragdoll_frame_cache"][key][int(scene.frame_current)] = {
            name: value.copy() if hasattr(value, "copy") else value
            for name, value in state.items()
        }
        _ragdoll_apply_tail(armature, pose_bone, Vector(state["anchor"]), position)
        context.view_layer.update()
        _state.pop("ragdoll_collision_bounds", None)


def _ragdoll_uncached_predecessor(scene, target):
    predecessors = []
    for owner in scene.objects:
        if owner.type != "ARMATURE" or owner.pose is None:
            continue
        for bone in _ragdoll_active_bones_hierarchy_order(owner, target):
            cache = _state.get("ragdoll_frame_cache", {}).get(_ragdoll_state_key(owner, bone), {})
            if target in cache:
                continue
            prior = [int(frame) for frame in cache if int(frame) < target]
            start = _ragdoll_active_start_frame(owner, bone, target)
            if prior:
                predecessors.append(max(prior))
            elif start is not None:
                predecessors.append(int(round(start)) - 1)
    return min(predecessors) if predecessors else None


def _ragdoll_hold_scrub_pose(scene):
    """Keep the last published physics pose visible, never transient Action RNA."""
    held = _state.get("ragdoll_scrub_hold", {})
    previous = bool(_state.get("ragdoll_syncing"))
    _state["ragdoll_syncing"] = True
    try:
        for owner in scene.objects:
            if owner.type != "ARMATURE" or owner.pose is None:
                continue
            last_depth = None
            changed = False
            for bone in _ragdoll_active_bones_hierarchy_order(owner, scene.frame_current):
                state = held.get(_ragdoll_state_key(owner, bone))
                if state is None:
                    continue
                depth = _ragdoll_hierarchy_depth(owner, bone)
                if last_depth is not None and depth != last_depth and changed:
                    bpy.context.view_layer.update()
                    changed = False
                last_depth = depth
                changed = _ragdoll_apply_tail(
                    owner, bone, Vector(state["anchor"]), Vector(state["position"]),
                    free=bool(state.get("free")), orientation=state.get("orientation"),
                    report_change=True,
                ) or changed
            if changed:
                bpy.context.view_layer.update()
    finally:
        _state["ragdoll_syncing"] = previous


def _ragdoll_queue_scrub(scene, target):
    _sync_all_dynamic_pose_bone_colors(int(target))
    if not _state.get("ragdoll_scrub_job"):
        _state["ragdoll_scrub_hold"] = {
            key: {name: value.copy() if hasattr(value, "copy") else value
                  for name, value in state.items()}
            for key, state in _state.get("ragdoll_states", {}).items()
        }
    # Replace the destination, retaining exact samples already computed.
    _state["ragdoll_scrub_job"] = scene.name
    _state["ragdoll_scrub_target"] = int(target)
    _ragdoll_hold_scrub_pose(scene)
    if not bpy.app.timers.is_registered(_ragdoll_scrub_timer):
        register_owned_timer(_ragdoll_scrub_timer, first_interval=0.0)


def _ragdoll_scrub_timer():
    """Compute one missing frame per event-loop turn, without a long UI stall."""
    name = _state.get("ragdoll_scrub_job")
    if not name:
        return None
    scene = bpy.data.scenes.get(name)
    if (scene is None or bpy.context.scene != scene
            or _state.get("ragdoll_history_restoring")
            or _pin_active_transform_operator(bpy.context)):
        _state.pop("ragdoll_scrub_job", None)
        return None
    target = int(scene.frame_current)
    prior = _ragdoll_uncached_predecessor(scene, target)
    if prior is None:
        _state.pop("ragdoll_scrub_job", None)
        _ragdoll_restore_cached_frame(scene)
        return None
    step = min(target, prior + 1)
    subframe = float(scene.frame_subframe)
    # Internal frames never escape to a viewport draw. Retain the displayed
    # inputs and blue helpers until the requested exact pose is available.
    bases = [(owner, {bone.name: bone.matrix_basis.copy() for bone in owner.pose.bones})
             for owner in scene.objects if owner.type == "ARMATURE" and owner.pose]
    helpers = [(obj, obj.matrix_basis.copy()) for obj in scene.objects
               if bool(obj.get(SPACE_HELPER_PROPERTY, False))]
    syncing = bool(_state.get("ragdoll_syncing"))
    filling = bool(_state.get("ragdoll_filling_frames"))
    _state["ragdoll_filling_frames"] = True
    try:
        _state["ragdoll_syncing"] = True
        scene.frame_set(step)
        bpy.context.view_layer.update()
        _state["ragdoll_syncing"] = False
        _state["ragdoll_evaluation_curves"] = {}
        _ragdoll_frame_change_impl(scene)
    except Exception:
        _state.pop("ragdoll_scrub_job", None)
        raise
    finally:
        _state.pop("ragdoll_evaluation_curves", None)
        _state["ragdoll_syncing"] = True
        scene.frame_set(target, subframe=subframe)
        if step != target:
            for owner, saved in bases:
                for name, basis in saved.items():
                    bone = owner.pose.bones.get(name)
                    if bone is not None:
                        bone.matrix_basis = basis
            for obj, basis in helpers:
                obj.matrix_basis = basis
        bpy.context.view_layer.update()
        _state["ragdoll_syncing"] = syncing
        _state["ragdoll_filling_frames"] = filling
    if step == target:
        _state.pop("ragdoll_scrub_job", None)
        _state.pop("ragdoll_scrub_hold", None)
        _ragdoll_restore_cached_frame(scene)
        return None
    _ragdoll_hold_scrub_pose(scene)
    # Yield to the next event-loop turn without adding 8 ms to every
    # historical frame of a changed-weight generation.
    return 0.0


def _ragdoll_interactive_replay():
    """Display callbacks yield; export/bake and background evaluation finish."""
    return (not bpy.app.background and not _state.get("ragdoll_baking")
            and not bpy.app.is_job_running("RENDER"))


def _ragdoll_frame_change_post(scene, _depsgraph=None):
    try:
        return _ragdoll_frame_change_evaluate(scene, _depsgraph)
    finally:
        # Orange publication can flush the Action after Pink's earlier frame
        # callback. Finish active Contact on this same frame, especially End,
        # rather than leaving its raw pose visible until the next callback.
        if (bpy.context.scene == scene and not _state.get("ragdoll_syncing")
                and not _state.get("ragdoll_history_restoring")
                and not extension_update_guard_active()):
            guides = _surface_contact_active_simulated_guides(scene)
            if guides:
                _surface_contact_playback_batch_settle(bpy.context, tuple(
                    guide for guide in guides
                    if _surface_contact_attached_at_frame(guide, scene.frame_current)))


def _ragdoll_frame_change_evaluate(scene, _depsgraph=None):
    # Share Action indexes across the complete hierarchy, then drop all RNA
    # references before another edit, frame, or native history operation.
    if not (
        _state.get("ragdoll_syncing") or _state.get("ragdoll_history_restoring")
        or _state.get("ragdoll_filling_frames") or extension_update_guard_active()
    ):
        previous_publication = _state.get("ragdoll_frame_publication", False)
        _state["ragdoll_frame_publication"] = _depsgraph is not None
        try:
            native_handled = _ragdoll_native_scene(scene)
        finally:
            _state["ragdoll_frame_publication"] = previous_publication
        if native_handled:
            return
        if (_state.get('ragdoll_key_transform_active')
                and not _state.get('ragdoll_exact_preview_active')
                and _ragdoll_preview_key_edit(scene)):
            return
        target = int(scene.frame_current)
        screen = getattr(bpy.context, "screen", None)
        waiting = _state.get("ragdoll_scrub_target")
        if (_state.get("ragdoll_scrub_job") and waiting is not None
                and bool(getattr(screen, "is_animation_playing", False))
                and not bool(getattr(screen, "is_scrubbing", False))
                and target == int(waiting) + 1):
            # Keep the playback clock at its requested sample while it is
            # computed. Advancing the destination faster than the worker can
            # solve made the held rig remain frozen throughout playback.
            _state["ragdoll_syncing"] = True
            try:
                scene.frame_set(int(waiting))
                _ragdoll_hold_scrub_pose(scene)
            finally:
                _state["ragdoll_syncing"] = False
            return
        predecessor = _ragdoll_uncached_predecessor(scene, target)
        if (predecessor is not None and _ragdoll_interactive_replay()
                and (predecessor < target - 1 or _state.get("ragdoll_scrub_job"))):
            _ragdoll_queue_scrub(scene, target)
            return
        if predecessor is None:
            _state.pop("ragdoll_scrub_job", None)
        if predecessor is not None and predecessor < target - 1:
            # Missing display frames still need a complete articulated solve:
            # parent, siblings, animated colliders, and contact settling at
            # each time sample. Per-bone catch-up freezes those inputs.
            _state["ragdoll_filling_frames"] = True
            subframe = float(scene.frame_subframe)
            try:
                for frame in range(predecessor + 1, target):
                    _state["ragdoll_syncing"] = True
                    scene.frame_set(frame)
                    bpy.context.view_layer.update()
                    _state["ragdoll_syncing"] = False
                    _ragdoll_frame_change_post(scene, _depsgraph)
            finally:
                _state["ragdoll_syncing"] = True
                scene.frame_set(target, subframe=subframe)
                bpy.context.view_layer.update()
                _state["ragdoll_syncing"] = False
                _state["ragdoll_filling_frames"] = False
    previous = _state.get("ragdoll_evaluation_curves")
    if previous is None:
        _state["ragdoll_evaluation_curves"] = {}
    try:
        return _ragdoll_frame_change_impl(scene, _depsgraph)
    finally:
        if previous is None:
            _state.pop("ragdoll_evaluation_curves", None)


def _ragdoll_frame_change_impl(scene, _depsgraph=None):
    _state["ragdoll_frame_handler_calls"] = int(
        _state.get("ragdoll_frame_handler_calls", 0)
    ) + 1
    _state["ragdoll_frame_handler_last_frame"] = int(scene.frame_current)
    if (
        _state.get("ragdoll_syncing", False)
        or (_state.get("ragdoll_history_restoring", False)
            and not _state.get("ragdoll_resimulating", False))
        or extension_update_guard_active()
    ):
        _state["ragdoll_frame_handler_blocked"] = (
            "syncing"
            if _state.get("ragdoll_syncing", False)
            else (
                "history"
                if _state.get("ragdoll_history_restoring", False)
                else "update_guard"
            )
        )
        return
    context = bpy.context
    if getattr(context, "scene", None) != scene:
        _state["ragdoll_frame_handler_blocked"] = "scene_mismatch"
        return
    if not _ragdoll_scene_has_data(scene):
        _state["ragdoll_frame_handler_blocked"] = "no_data"
        return
    if _ragdoll_native_scene(scene):
        return
    pending = _state.get("ragdoll_pending_resimulation") or {}
    if (pending and not _state.get("ragdoll_resimulating")
            and int(pending.get("frame", -1)) >= int(scene.frame_current)):
        # A complete Start-to-target generation is already queued. Do not let
        # incidental scrubs or playback extend the stale generation while it
        # is being replaced; that made repeated scrubs progressively change
        # the answer. Keep only an exact cached sample, if one exists.
        if _ragdoll_restore_cached_frame(scene):
            _ragdoll_debug_event(
                "pending_generation_hold",
                frame=int(scene.frame_current),
                target=int(pending.get("frame", -1)),
            )
            return
    _state["ragdoll_frame_handler_blocked"] = ""
    _state["ragdoll_syncing"] = True
    try:
        if not (_state.get("ragdoll_resimulating") or _state.get("ragdoll_filling_frames")):
            _sync_all_dynamic_pose_bone_colors(int(scene.frame_current))
        active_keys = set()
        for armature in tuple(scene.objects):
            if armature.type != "ARMATURE" or getattr(armature, "pose", None) is None:
                continue
            ordered_bones = _ragdoll_active_bones_hierarchy_order(
                armature, int(scene.frame_current)
            )
            # Restore every authored Start basis as one hierarchy transaction.
            # Applying parent physics before a child has restored its basis
            # lets the child capture a mixed old/new skeleton as its boundary.
            restored_start_basis = False
            for pose_bone in ordered_bones:
                start = _ragdoll_active_start_frame(
                    armature, pose_bone, int(scene.frame_current)
                )
                if (
                    start is not None
                    and int(round(float(start))) == int(scene.frame_current)
                    and int(scene.frame_current) not in _state.setdefault(
                        "ragdoll_frame_cache", {}
                    ).get(_ragdoll_state_key(armature, pose_bone), {})
                ):
                    start_connected = not _ragdoll_free(
                        armature, pose_bone, int(scene.frame_current)
                    )
                    restored_start_basis = (
                        _ragdoll_apply_stored_start_pose(
                            pose_bone,
                            start,
                            connected=start_connected,
                        )
                        or restored_start_basis
                    )
            if restored_start_basis:
                context.view_layer.update()
            uncached = any(
                int(scene.frame_current) not in _state.get("ragdoll_frame_cache", {}).get(
                    _ragdoll_state_key(armature, bone), {}
                ) for bone in ordered_bones
            )
            applied_bones = []
            last_depth = None
            for pose_bone in ordered_bones:
                depth = _ragdoll_hierarchy_depth(armature, pose_bone)
                if last_depth is not None and depth != last_depth:
                    # Commit the previous hierarchy depth so bone-parented
                    # welded meshes expose their new evaluated transforms to
                    # descendant/self collision queries.
                    context.view_layer.update()
                    _ragdoll_restore_applied_states(
                        armature,
                        applied_bones,
                        int(scene.frame_current),
                    )
                last_depth = depth
                key = _ragdoll_state_key(armature, pose_bone)
                active_keys.add(key)
                if _state.get("ragdoll_debug_enabled", False):
                    state_before = _state.setdefault("ragdoll_states", {}).get(key)
                    visible_anchor, visible_tail = _ragdoll_matrix_world_points(
                        armature,
                        pose_bone,
                        connected=not _ragdoll_free(
                            armature, pose_bone, int(scene.frame_current)
                        ),
                    )
                    _ragdoll_debug_event(
                        "frame_step_before",
                        frame=int(scene.frame_current),
                        key=str(key),
                        visible_anchor=tuple(float(value) for value in visible_anchor),
                        visible_position=tuple(float(value) for value in visible_tail),
                        state_frame=(state_before or {}).get("frame"),
                        cache_hit=int(scene.frame_current) in _state.setdefault(
                            "ragdoll_frame_cache", {}
                        ).get(key, {}),
                    )
                applied = _ragdoll_step(
                    context, armature, pose_bone, int(scene.frame_current)
                )
                if _state.get("ragdoll_debug_enabled", False):
                    state_after = _state.setdefault("ragdoll_states", {}).get(key)
                    _ragdoll_debug_event(
                        "frame_step_after",
                        frame=int(scene.frame_current),
                        key=str(key),
                        applied=bool(applied),
                        state_frame=(state_after or {}).get("frame"),
                        contact=bool(
                            state_after is not None
                            and state_after.get("contact_normal") is not None
                        ),
                    )
                applied_bones.append(pose_bone)
            if applied_bones and uncached:
                _ragdoll_settle_frame_contacts(context, armature, applied_bones)
            for pose_bone in armature.pose.bones:
                key = _ragdoll_state_key(armature, pose_bone)
                if key in active_keys:
                    continue
                if key in _state.setdefault("ragdoll_states", {}):
                    _unparent_apply_action_pose_channels(
                        _ragdoll_action(armature),
                        pose_bone,
                        int(scene.frame_current),
                    )
        states = _state.setdefault("ragdoll_states", {})
        for key in tuple(states):
            if key not in active_keys:
                states.pop(key, None)
        _ragdoll_publish_frame_driver_signatures(
            scene, int(scene.frame_current)
        )
        snapshots = _state.setdefault("ragdoll_armature_world_matrices", {})
        for armature in tuple(scene.objects):
            if armature.type == "ARMATURE":
                snapshots[str(armature.name_full)] = armature.matrix_world.copy()
    finally:
        _state["ragdoll_syncing"] = False


def _ragdoll_reseed_start_boundaries(scene):
    """Rebase all current Start markers before Blender can skip frame zero."""
    if _state.get("ragdoll_syncing", False) or extension_update_guard_active():
        return False
    context = bpy.context
    if getattr(context, "scene", None) != scene:
        return False
    frame = int(scene.frame_current)
    targets = []
    for armature in tuple(scene.objects):
        if armature.type != "ARMATURE" or getattr(armature, "pose", None) is None:
            continue
        for pose_bone in armature.pose.bones:
            key = _ragdoll_state_key(armature, pose_bone)
            start = _ragdoll_active_start_frame(armature, pose_bone, frame)
            cache = _state.setdefault("ragdoll_frame_cache", {}).get(key, {})
            cached_boundary = min(cache, default=None)
            if (
                _ragdoll_active(pose_bone, frame)
                and (
                    (start is not None and frame == int(round(float(start))))
                    or (
                        cached_boundary is not None
                        and frame == int(cached_boundary)
                    )
                )
            ):
                targets.append((armature, pose_bone))
    if not targets:
        return False
    _state["ragdoll_syncing"] = True
    try:
        for armature, pose_bone in targets:
            key = _ragdoll_state_key(armature, pose_bone)
            unparented = _ragdoll_free(armature, pose_bone, frame)
            _ragdoll_apply_start_pose_source(armature, pose_bone, frame)
            anchor, tail = _ragdoll_matrix_world_points(
                armature, pose_bone, connected=not unparented
            )
            tail = _ragdoll_seed_tail(
                anchor,
                tail,
                _ragdoll_world_length(armature, pose_bone),
                unparented,
            )
            state = {
                "frame": frame,
                "position": tail.copy(),
                "previous": tail.copy(),
                "velocity": Vector((0.0, 0.0, 0.0)),
                "anchor": anchor.copy(),
                "anchor_previous": anchor.copy(),
                "free": unparented,
                "seeded": True,
                "start_authoritative": True,
            }
            _state.setdefault("ragdoll_states", {})[key] = state
            cache = _state.setdefault("ragdoll_frame_cache", {}).setdefault(
                key, {}
            )
            _ragdoll_store_boundary_cache(
                cache,
                frame,
                state,
                max(1.0e-5, float(pose_bone.bone.length) * 1.0e-4),
            )
            _ragdoll_apply_tail(
                armature,
                pose_bone,
                anchor,
                tail,
                free=unparented,
            )
    finally:
        _state["ragdoll_syncing"] = False
    return True


def _ragdoll_seed_visible_playback_pose(scene):
    """Use the pose visible when Play is pressed as the simulation boundary."""
    if _state.get("ragdoll_syncing", False) or extension_update_guard_active():
        _ragdoll_debug_event("playback_seed_blocked", frame=int(scene.frame_current))
        return False
    context = bpy.context
    if getattr(context, "scene", None) != scene:
        _ragdoll_debug_event("playback_seed_scene_mismatch")
        return False
    frame = int(scene.frame_current)
    changed = False
    restored = False
    _state["ragdoll_syncing"] = True
    try:
        for armature in tuple(scene.objects):
            if armature.type != "ARMATURE" or getattr(armature, "pose", None) is None:
                continue
            ordered_bones = _ragdoll_active_bones_hierarchy_order(
                armature, frame
            )
            for pose_bone in ordered_bones:
                key = _ragdoll_state_key(armature, pose_bone)
                unparented = _ragdoll_free(
                    armature, pose_bone, frame
                )
                anchor, tail = _ragdoll_matrix_world_points(
                    armature, pose_bone, connected=not unparented
                )
                tail = _ragdoll_seed_tail(
                    anchor,
                    tail,
                    _ragdoll_world_length(armature, pose_bone),
                    unparented,
                )
                state = _state.setdefault("ragdoll_states", {}).get(key)
                active_start = _ragdoll_active_start_frame(
                    armature, pose_bone, frame
                )
                at_start_boundary = bool(
                    active_start is not None
                    and int(round(float(active_start))) == frame
                )
                if at_start_boundary:
                    # Never promote the currently displayed simulation back
                    # into frame zero. The persisted authored basis is the
                    # deterministic boundary for every play and scrub.
                    if _ragdoll_step(context, armature, pose_bone, frame):
                        restored = True
                        continue
                cached = _state.setdefault("ragdoll_frame_cache", {}).get(
                    key, {}
                ).get(frame)
                if (
                    state is None
                    or int(state.get("frame", -1)) != frame
                ) and cached is not None:
                    state = {
                        name: value.copy() if hasattr(value, "copy") else value
                        for name, value in cached.items()
                    }
                    _state["ragdoll_states"][key] = state
                if (
                    not at_start_boundary
                    and cached is None
                    and state is not None
                ):
                    # Starting playback inside an active interval must replay
                    # stored simulation, never promote Blender's temporarily
                    # restored authored pose to a new boundary. Step from the
                    # nearest cache predecessor exactly as scrubbing does.
                    if _ragdoll_step(
                        context, armature, pose_bone, frame
                    ):
                        restored = True
                        continue
                position_gap = (
                    (tail - Vector(state["position"])).length
                    if state is not None and state.get("position") is not None
                    else float("inf")
                )
                anchor_gap = (
                    (anchor - Vector(state["anchor"])).length
                    if state is not None and state.get("anchor") is not None
                    else float("inf")
                )
                tolerance = max(1.0e-5, float(pose_bone.bone.length) * 1.0e-4)
                if (
                    not at_start_boundary
                    and state is not None
                    and int(state.get("frame", -1)) == frame
                ):
                    # Stored simulation is authoritative on replay. Blender
                    # may briefly evaluate ordinary pose channels just before
                    # animation_playback_pre; reseeding from that transient
                    # matrix erased velocity/cache and made repeated plays
                    # inconsistently freeze.
                    _ragdoll_apply_tail(
                        armature,
                        pose_bone,
                        Vector(state["anchor"]),
                        Vector(state["position"]),
                        free=bool(state.get("free", False)),
                        orientation=state.get("orientation"),
                    )
                    restored = True
                    cache = _state.setdefault("ragdoll_frame_cache", {}).setdefault(
                        key, {}
                    )
                    cache[frame] = {
                        name: value.copy() if hasattr(value, "copy") else value
                        for name, value in state.items()
                    }
                    _ragdoll_debug_event(
                        "playback_restore_authoritative_state",
                        frame=frame,
                        key=str(key),
                        position_gap=float(position_gap),
                        anchor_gap=float(anchor_gap),
                    )
                    continue
                state = {
                    "frame": frame,
                    "position": tail.copy(),
                    "previous": tail.copy(),
                    "velocity": Vector((0.0, 0.0, 0.0)),
                    "anchor": anchor.copy(),
                    "anchor_previous": anchor.copy(),
                    "free": unparented,
                    "seeded": True,
                }
                _state["ragdoll_states"][key] = state
                cache = _state.setdefault("ragdoll_frame_cache", {}).setdefault(
                    key, {}
                )
                _ragdoll_store_boundary_cache(
                    cache,
                    frame,
                    state,
                    max(1.0e-5, float(pose_bone.bone.length) * 1.0e-4),
                )
                _state.setdefault("ragdoll_boundary_pose_samples", {}).pop(
                    key, None
                )
                _ragdoll_debug_event(
                    "playback_seed_visible_pose",
                    frame=frame,
                    key=str(key),
                    anchor=tuple(float(value) for value in anchor),
                    position=tuple(float(value) for value in tail),
                    old_position_gap=float(position_gap),
                    old_anchor_gap=float(anchor_gap),
                )
                changed = True
        if restored:
            context.view_layer.update()
    finally:
        _state["ragdoll_syncing"] = False
    return changed


def _ragdoll_playback_needs_simulation(scene):
    """Whether this playback range contains an uncached physics sample."""
    first = int(scene.frame_preview_start if scene.use_preview_range else scene.frame_start)
    last = int(scene.frame_preview_end if scene.use_preview_range else scene.frame_end)
    first = min(first, int(scene.frame_current))
    last = max(last, int(scene.frame_current))
    caches = _state.get("ragdoll_frame_cache", {})
    for owner in scene.objects:
        if owner.type != "ARMATURE" or owner.pose is None:
            continue
        index = _ragdoll_curve_index(owner)
        for bone in owner.pose.bones:
            curves = index.get(_ragdoll_path(bone), ())
            if not curves and not _ragdoll_active(bone, first, curves=()):
                continue
            cache = caches.get(_ragdoll_state_key(owner, bone), {})
            for frame in range(first, last + 1):
                if frame not in cache and _ragdoll_active(bone, frame, curves=curves):
                    return True
    return False


def _ragdoll_restore_playback_sync(scene=None):
    """Release the temporary cold-playback clock, preserving user edits."""
    saved = _state.pop("ragdoll_playback_sync", None)
    if saved is None:
        return
    owner = bpy.data.scenes.get(saved[0])
    if owner is not None and owner.sync_mode == "NONE":
        owner.sync_mode = saved[1]


def _ragdoll_playback_pre(scene, _depsgraph=None):
    # A cursor replay remains owned by the bounded event-loop worker. Draining
    # it here turned a Space press after a jump into a multi-second UI stall.
    pending = _state.get("ragdoll_pending_resimulation")
    if pending:
        pending["updated"] = 0.0
        _ragdoll_resimulation_timer()
    _ragdoll_debug_event("playback_pre", frame=int(scene.frame_current))
    if not _state.get("ragdoll_scrub_job"):
        _ragdoll_seed_visible_playback_pose(scene)
    _ragdoll_restore_playback_sync()
    if scene.sync_mode != "NONE" and _ragdoll_playback_needs_simulation(scene):
        # Wall-clock frame dropping creates unbounded catch-up: every skipped
        # frame still needs a physics solve, which makes the next skip larger.
        # Cold physics advances one frame per display tick. Cached playback
        # keeps the user's normal clock, and Stop restores it after a cold run.
        _state["ragdoll_playback_sync"] = (scene.name, scene.sync_mode)
        scene.sync_mode = "NONE"


def _ragdoll_playback_post(scene, _depsgraph=None):
    """Keep the final simulated pose visible when animation playback stops."""
    if not _animation_playback_active(bpy.context) and _state.get('ragdoll_native_job'):
        # Space stops immediately; finish the exact stopped pose in timer slices.
        _state['ragdoll_native_finishing'] = True
    if not bool(getattr(getattr(bpy.context, "screen", None), "is_animation_playing", False)):
        _ragdoll_restore_playback_sync()
    if _state.get("ragdoll_syncing", False) or extension_update_guard_active():
        return
    context = bpy.context
    if getattr(context, "scene", None) != scene:
        return
    if _state.get("ragdoll_scrub_job"):
        _ragdoll_hold_scrub_pose(scene)
        return
    frame = int(scene.frame_current)
    applied = []
    _state["ragdoll_syncing"] = True
    try:
        for armature in tuple(scene.objects):
            if armature.type != "ARMATURE" or getattr(armature, "pose", None) is None:
                continue
            ordered_bones = _ragdoll_active_bones_hierarchy_order(
                armature, frame
            )
            if _ragdoll_restore_applied_states(armature, ordered_bones, frame):
                applied.append(armature.name)
    finally:
        _state["ragdoll_syncing"] = False
    _ragdoll_debug_event(
        "playback_post_hold",
        frame=frame,
        applied=tuple(applied),
    )


def _ragdoll_history_inputs(scene):
    """Snapshot authored inputs, never simulated matrices or RNA references."""
    result = {}
    frame = int(scene.frame_current)
    for armature in scene.objects:
        if armature.type != "ARMATURE" or armature.pose is None:
            continue
        if not any(_ragdoll_curves(armature, bone) for bone in armature.pose.bones):
            continue
        curves = tuple(sorted(
            (curve.data_path, int(curve.array_index), tuple(
                (tuple(point.co), tuple(point.handle_left), tuple(point.handle_right),
                 str(point.interpolation))
                for point in curve.keyframe_points
            ))
            for curve in _action_fcurves(_ragdoll_action(armature), armature)
        ))
        bones = tuple(
            (bone.name, bone.parent.name if bone.parent else "",
             str(bone.get(_RAGDOLL_START_POSES_PROPERTY, "")),
             str(getattr(bone, RAGDOLL_GRAVITY_AXIS_RNA, "Z_NEG")),
             float(getattr(bone, RAGDOLL_ACCELERATION_RNA, _RAGDOLL_DEFAULT_WEIGHT)),
             tuple(float(bone.get(prop, default)) for prop, default in (
                 (RAGDOLL_DAMPING_PROPERTY, _RAGDOLL_CHAIN_DAMPING),
                 (RAGDOLL_BOUNCE_PROPERTY, 0.0),
                 (RAGDOLL_FRICTION_PROPERTY, 0.35),
                 (RAGDOLL_RADIUS_PROPERTY, 0.02),
                 (RAGDOLL_COLLISION_STRETCH_PROPERTY, 0.2),
             )),
             # Active limb channels are outputs. Non-orange parents are inputs.
             () if _ragdoll_active(bone, frame) else tuple(
                 round(float(value), 6) for row in bone.matrix_basis for value in row
             ))
            for bone in armature.pose.bones
        )
        result[armature.name_full] = (
            curves, bones, tuple(float(value) for row in armature.matrix_world for value in row)
        )
    return result


def _ragdoll_history_rebuild_changed(scene):
    previous = _state.pop("ragdoll_history_inputs", None)
    if previous is None:
        return
    current = _ragdoll_history_inputs(scene)
    for name, signature in current.items():
        if previous.get(name) == signature:
            continue
        armature = bpy.data.objects.get(name)
        active = tuple(_ragdoll_active_bones_hierarchy_order(armature, scene.frame_current))
        if active:
            driver = active[0] if any(b.parent == active[0] for b in active[1:]) else active[0].parent
            if driver is not None and _ragdoll_native_branch(armature, driver, int(scene.frame_current)):
                continue
        roots = {}
        for bone in active:
            root = bone
            visited = {root.name}
            while (parent := _ragdoll_parent(armature, root)) is not None:
                if parent.name in visited:
                    break
                visited.add(parent.name)
                root = parent
            roots[root.name] = root
        # World bounds belong to the undone generation; local shape is rigid.
        _state.setdefault("ragdoll_collision_bounds", {}).clear()
        for root in roots.values():
            _ragdoll_resimulate_branch(armature, root, int(scene.frame_current))


@persistent
def _ragdoll_history_pre(*_args):
    _state.pop("ragdoll_modal_start_poses", None)
    _state.pop("surface_contact_pending_modal_keys", None)
    _ragdoll_native_cancel_job()
    _state.pop("ragdoll_scrub_job", None)
    _state.pop("ragdoll_start_edit_frame", None)
    _state["ragdoll_history_restoring"] = True
    scene = getattr(bpy.context, "scene", None)
    if scene is not None:
        _state["ragdoll_history_inputs"] = _ragdoll_history_inputs(scene)
    _ragdoll_debug_event("history_pre")


def _ragdoll_history_finalize():
    """Reapply cached state after Blender's deferred undo evaluation settles."""
    scene = getattr(getattr(bpy, "context", None), "scene", None)
    try:
        if scene is not None:
            # Contact's undo handler restores its visible pose separately.
            # Keep that restored boundary in derived caches after the history
            # lock expires; never write authored properties during undo_post.
            frame = int(scene.frame_current)
            for guide in _surface_contact_active_simulated_guides(scene):
                owner, bone = _surface_contact_pose_bone(guide)
                if (owner is None or bone is None
                        or _ragdoll_active_start_frame(owner, bone, frame) != frame):
                    continue
                head, tail = _ragdoll_matrix_world_points(owner, bone)
                initial = {
                    "frame": frame, "anchor": head.copy(), "position": tail.copy(),
                    "anchor_previous": head.copy(), "previous": tail.copy(),
                    "velocity": Vector((0.0, 0.0, 0.0)),
                    "orientation": (owner.matrix_world @ bone.matrix).to_quaternion(),
                    "socket_rotation": _ragdoll_connected_rotation(owner, bone),
                    "free": _ragdoll_free(owner, bone, frame),
                    "seeded": True, "start_authoritative": True,
                }
                key = _ragdoll_state_key(owner, bone)
                _state.setdefault("ragdoll_states", {})[key] = initial
                _state.setdefault("ragdoll_frame_cache", {})[key] = {frame: dict(initial)}
            _ragdoll_restore_cached_frame(scene)
            _ragdoll_debug_event(
                "history_deferred_hold", frame=int(scene.frame_current)
            )
    finally:
        _state["ragdoll_history_restoring"] = False
    return None


@persistent
def _ragdoll_history_post(*_args):
    """Reapply unaffected simulation state after Blender restores history."""
    scene = getattr(getattr(bpy, "context", None), "scene", None)
    if scene is None:
        _state["ragdoll_history_restoring"] = False
        return
    try:
        _ragdoll_reconcile_marker_edits(scene)
        _ragdoll_history_rebuild_changed(scene)
        _ragdoll_restore_cached_frame(scene)
        _ragdoll_debug_event("history_post_hold", frame=int(scene.frame_current))
        try:
            if bpy.app.timers.is_registered(_ragdoll_history_finalize):
                bpy.app.timers.unregister(_ragdoll_history_finalize)
            register_owned_timer(
                _ragdoll_history_finalize,
                # Run at the next Blender event-loop boundary.  A fixed
                # 20 ms hold made every undo/redo visibly pause and caused
                # repeated full hierarchy restores in depsgraph callbacks.
                first_interval=0.0,
            )
        except (ReferenceError, RuntimeError, ValueError):
            _state["ragdoll_history_restoring"] = False
    except Exception:
        _state["ragdoll_history_restoring"] = False
        raise


def _ragdoll_frame_poll():
    """Restore a lost frame hook and repair only the frame missed before it."""
    if _state.get("ragdoll_scrub_job"):
        return 0.02
    context = getattr(bpy, "context", None)
    scene = getattr(context, "scene", None)
    if scene is None:
        return 0.05
    for handler_list, handler_function, state_name in (
        (
            bpy.app.handlers.animation_playback_pre,
            _ragdoll_playback_pre,
            "ragdoll_playback_pre_handler_restores",
        ),
        (
            bpy.app.handlers.animation_playback_post,
            _ragdoll_playback_post,
            "ragdoll_playback_post_handler_restores",
        ),
        (
            bpy.app.handlers.undo_pre,
            _ragdoll_history_pre,
            "ragdoll_history_handler_restores",
        ),
        (
            bpy.app.handlers.redo_pre,
            _ragdoll_history_pre,
            "ragdoll_history_handler_restores",
        ),
        (
            bpy.app.handlers.undo_post,
            _ragdoll_history_post,
            "ragdoll_history_handler_restores",
        ),
        (
            bpy.app.handlers.redo_post,
            _ragdoll_history_post,
            "ragdoll_history_handler_restores",
        ),
    ):
        handler_key = _owned_handler_key(handler_function)
        handler_present = any(
            handler is handler_function
            or getattr(handler, _HANDLER_OWNER_ATTRIBUTE, None) == handler_key
            for handler in tuple(handler_list)
        )
        if not handler_present:
            register_owned_handler(handler_list, handler_function)
            _state[state_name] = int(_state.get(state_name, 0)) + 1
    handler_list = bpy.app.handlers.frame_change_post
    handler_key = _owned_handler_key(_ragdoll_frame_change_post)
    handler_present = any(
        handler is _ragdoll_frame_change_post
        or getattr(handler, _HANDLER_OWNER_ATTRIBUTE, None) == handler_key
        for handler in tuple(handler_list)
    )
    restored_handler = False
    if not handler_present:
        register_owned_handler(handler_list, _ragdoll_frame_change_post)
        restored_handler = True
        _state["ragdoll_frame_handler_restores"] = int(
            _state.get("ragdoll_frame_handler_restores", 0)
        ) + 1
    if not _ragdoll_scene_has_data(scene):
        return 0.5
    fps = max(
        1.0,
        float(scene.render.fps) / max(1.0e-6, float(scene.render.fps_base)),
    )
    _ragdoll_reconcile_marker_edits(scene)
    if (_state.get("ragdoll_key_transform_active")
            and _pin_active_transform_operator(context)
            and not _ragdoll_transform_edits_keys(context)):
        # A previous key gesture must not own the next viewport transform.
        _state.pop("ragdoll_key_transform_active", None)
        _state.pop("ragdoll_key_preview_owners", None)
        _state.pop("ragdoll_live_preview_states", None)
    if _state.get("ragdoll_key_transform_active"):
        # Graph/Dope Sheet transforms can also stop issuing depsgraph callbacks
        # while held. Revalidate current curve data, including Start/End moves.
        if not _pin_active_transform_operator(context):
            _state.pop("ragdoll_key_transform_active", None)
            if _ragdoll_commit_key_preview(scene):
                return max(0.01, 1.0 / fps)
            if _state.get("ragdoll_native_job"):
                _state["ragdoll_native_finishing"] = True
        previous_sparse = _state.get("ragdoll_native_sparse_replay", False)
        _state["ragdoll_native_sparse_replay"] = True
        try:
            if _ragdoll_native_scene(scene):
                return max(0.01, 1.0 / fps)
            if _state.get('ragdoll_key_transform_active') and _ragdoll_preview_key_edit(scene):
                return max(0.01, 1.0 / fps)
        finally:
            _state["ragdoll_native_sparse_replay"] = previous_sparse
    # The registered frame-change handler owns playback. Scanning and
    # measuring every active limb again from this 60 Hz safety timer was a
    # duplicate O(rigs*bones) pass and could re-enter between physics frames.
    if _animation_playback_active(context):
        return max(0.05, 3.0 / fps)
    frame = int(scene.frame_current)
    if _state.get("ragdoll_start_edit_frame") == frame and _ragdoll_capture_start_edits(context):
        return max(0.01, 1.0 / fps)
    active = []
    for armature in tuple(scene.objects):
        if armature.type != "ARMATURE" or getattr(armature, "pose", None) is None:
            continue
        curve_index = _ragdoll_curve_index(armature)
        for pose_bone in armature.pose.bones:
            if _ragdoll_active(
                pose_bone,
                frame,
                curves=curve_index.get(_ragdoll_path(pose_bone), ()),
            ):
                active.append((armature, pose_bone))
    if not active:
        return min(0.1, 2.0 / fps)
    states = _state.setdefault("ragdoll_states", {})
    behind = any(
        int(states.get(_ragdoll_state_key(armature, pose_bone), {}).get("frame", frame - 1))
        != frame
        for armature, pose_bone in active
    )
    active_pose_bone = getattr(context, "active_pose_bone", None)
    visible_mismatch = False
    if not (
        active_pose_bone is not None
        and _ragdoll_active(active_pose_bone, frame)
    ):
        for armature, pose_bone in active:
            key = _ragdoll_state_key(armature, pose_bone)
            state = states.get(key)
            if state is None or int(state.get("frame", -1)) != frame:
                continue
            _anchor, visible_tail = _ragdoll_matrix_world_points(
                armature,
                pose_bone,
                connected=not bool(state.get("free", False)),
            )
            if (
                visible_tail - Vector(state["position"])
            ).length > max(1.0e-4, float(pose_bone.bone.length) * 1.0e-3):
                visible_mismatch = True
                break
    if (
        visible_mismatch
        and active_pose_bone is not None
        and getattr(active_pose_bone, "id_data", None) is not None
    ):
        driver_armature = active_pose_bone.id_data
        if _ragdoll_rebase_start_branch(
            driver_armature, active_pose_bone, frame
        ):
            _state["ragdoll_frame_poll_repairs"] = int(
                _state.get("ragdoll_frame_poll_repairs", 0)
            ) + 1
            _ragdoll_debug_event(
                "poll_start_rebase",
                driver=active_pose_bone.name,
                frame=int(frame),
            )
            try:
                context.view_layer.update()
            except (AttributeError, RuntimeError):
                pass
            return max(0.01, 1.0 / fps)
        if any(
            _ragdoll_active(candidate, frame)
            and _ragdoll_is_ancestor(
                driver_armature, active_pose_bone, candidate
            )
            for candidate in driver_armature.pose.bones
        ):
            if (
                _pin_active_transform_operator(context)
                or _pin_primary_mouse_pressed()
            ):
                # The depsgraph callback owns the inexpensive modal preview;
                # this safety timer must not replace it with the old cache.
                return max(0.01, 1.0 / fps)
            # A non-boundary torso/parent edit invalidates every later socket
            # sample in its ragdoll descendants. The depsgraph callback can
            # be pre-empted by other pose handlers during a modal transform,
            # but this mismatch is direct proof that the cached simulation no
            # longer matches the evaluated hierarchy. Debounce one exact
            # Start-to-current replay after the edit settles.
            signature_key = (
                driver_armature.name_full,
                active_pose_bone.name,
                int(frame),
            )
            current_signature = _ragdoll_driver_pose_signature(
                active_pose_bone, frame
            )
            published_signature = _state.setdefault(
                "ragdoll_driver_preview_signatures", {}
            ).get(signature_key)
            pending = _state.get("ragdoll_pending_resimulation") or {}
            pending_identity = (
                str(pending.get("armature", "")),
                str(pending.get("bone", "")),
                int(pending.get("frame", -1048576)),
            )
            if (
                current_signature != published_signature
                and pending_identity != signature_key
                and not _pin_active_transform_operator(context)
                and not _pin_primary_mouse_pressed()
            ):
                _ragdoll_schedule_resimulation(
                    driver_armature,
                    active_pose_bone,
                    frame,
                    refresh_deadline=False,
                )
                _ragdoll_debug_event(
                    "poll_driver_resimulation",
                    driver=active_pose_bone.name,
                    frame=int(frame),
                )
                return max(0.01, 1.0 / fps)
            if pending_identity == signature_key:
                # Preserve the current viewport until the single atomic cache
                # generation is ready. Replaying the stale frame here caused
                # the recorded alternating right-leg pose and extra work.
                return max(0.01, 1.0 / fps)
    if behind or visible_mismatch or restored_handler:
        _state["ragdoll_frame_poll_repairs"] = int(
            _state.get("ragdoll_frame_poll_repairs", 0)
        ) + 1
        _ragdoll_frame_change_post(scene, None)
    return max(0.01, 1.0 / fps)


def _ragdoll_capture_start_edits(context, contact_bone=None):
    """Let the native transform transaction author the exact Start pose."""
    previous_curves = _state.get("ragdoll_evaluation_curves")
    if previous_curves is None:
        _state["ragdoll_evaluation_curves"] = {}
    try:
        return _ragdoll_capture_start_edits_indexed(context, contact_bone)
    finally:
        if previous_curves is None:
            _state.pop("ragdoll_evaluation_curves", None)


def _ragdoll_capture_start_edits_indexed(context, contact_bone=None):
    frame = int(context.scene.frame_current)
    transforming = bool(_pin_active_transform_operator(context))
    session_frame = _state.get("ragdoll_start_edit_frame")
    if contact_bone is None and not transforming and session_frame != frame:
        _state.pop("ragdoll_start_edit_frame", None)
        return False
    owners = {}
    selected_owners = ({contact_bone.id_data: (contact_bone,)} if contact_bone is not None
                       else _selected_pose_bones_by_owner(context))
    for owner, selected in selected_owners.items():
        starts = tuple(bone for bone in selected
            if _ragdoll_active(bone, frame)
            and _ragdoll_active_start_frame(owner, bone, frame) == frame)
        if starts:
            owners[owner] = starts
    if not owners:
        _state.pop("ragdoll_start_edit_frame", None)
        return False
    if transforming:
        _state["ragdoll_start_edit_frame"] = frame
    else:
        # Native confirm/cancel has now published the final matrix. Capture
        # it before any cache hold can undo an Escape cancellation.
        _state.pop("ragdoll_start_edit_frame", None)
    previous = bool(_state.get("ragdoll_syncing"))
    _state["ragdoll_syncing"] = True
    try:
        for owner, selected in owners.items():
            bones = tuple(bone for bone in _ragdoll_active_bones_hierarchy_order(owner, frame)
                if _ragdoll_active_start_frame(owner, bone, frame) == frame)
            changed_bones = []
            for bone in bones:
                head, tail = _ragdoll_matrix_world_points(owner, bone)
                orientation = (owner.matrix_world @ bone.matrix).to_quaternion()
                cached = _state.get("ragdoll_states", {}).get(_ragdoll_state_key(owner, bone))
                if (cached and cached.get("frame") == frame and cached.get("start_authoritative")
                        and "orientation" in cached
                        and (head - cached["anchor"]).length_squared < 1.e-12
                        and (tail - cached["position"]).length_squared < 1.e-12
                        and abs(orientation.dot(cached["orientation"])) > 1.0 - 1.e-7):
                    continue
                changed_bones.append(bone)
                editable_socket = bone in selected or bool(
                    _ragdoll_start_poses(bone).get(str(frame), {}).get("editable_socket")
                )
                _ragdoll_store_start_pose(bone, frame)
                if editable_socket:
                    poses = _ragdoll_start_poses(bone)
                    poses[str(frame)]["editable_socket"] = True
                    _ragdoll_write_start_poses(bone, poses)
            if not changed_bones:
                if not transforming:
                    _ragdoll_finish_modal_start_poses(owner)
                continue
            _ragdoll_invalidate_bones(changed_bones)
            for bone in bones:
                # Invalidation also reaches connected ancestors/descendants.
                # Reseed their Start states if cleared, preserving idle siblings.
                if (bone not in changed_bones and _ragdoll_state_key(owner, bone)
                        in _state.get("ragdoll_states", {})):
                    continue
                head, tail = _ragdoll_matrix_world_points(owner, bone)
                state = {"frame": frame, "anchor": head.copy(), "position": tail.copy(),
                         "orientation": (owner.matrix_world @ bone.matrix).to_quaternion(),
                         "anchor_previous": head.copy(), "previous": tail.copy(),
                         "velocity": Vector((0.0, 0.0, 0.0)),
                         "free": _ragdoll_free(owner, bone, frame),
                         "seeded": True, "start_authoritative": True}
                key = _ragdoll_state_key(owner, bone)
                _state.setdefault("ragdoll_states", {})[key] = state
                _state.setdefault("ragdoll_frame_cache", {})[key] = {frame: dict(state)}
            if not transforming:
                _ragdoll_finish_modal_start_poses(owner)
    finally:
        _state["ragdoll_syncing"] = previous
    return True


def _ragdoll_transform_edits_keys(context):
    """Bind editor ownership to this operator, not to a later redraw area."""
    if not _pin_active_transform_operator(context):
        _state.pop("ragdoll_transform_scope", None)
        return False
    token = _pin_transform_operator_token(context)
    scope = _state.get("ragdoll_transform_scope")
    if token is not None and scope is not None and scope[0] == token:
        return scope[1]
    for operator in getattr(getattr(context, "window", None), "modal_operators", ()):
        identifier = str(getattr(operator, "bl_idname", ""))
        if not identifier.startswith("TRANSFORM_OT_"):
            continue
        mode = str(getattr(getattr(operator, "properties", operator), "mode", ""))
        if mode.startswith("TIME_") or identifier.startswith("TRANSFORM_OT_time_"):
            if token is not None:
                _state["ragdoll_transform_scope"] = (token, True)
            return True
    area_type = getattr(getattr(context, "area", None), "type", "")
    edits_keys = area_type in {"DOPESHEET_EDITOR", "GRAPH_EDITOR", "NLA_EDITOR"}
    if token is not None and (edits_keys or area_type == "VIEW_3D"):
        _state["ragdoll_transform_scope"] = (token, edits_keys)
    return edits_keys


def _ragdoll_depsgraph_update_post(scene, _depsgraph=None):
    if _state.get("ragdoll_driver_autokeying", False):
        return
    if _state.get("ragdoll_history_restoring", False):
        # Undo/redo can run another native Action evaluation after undo_post.
        # Reassert the atomic cached ragdoll snapshot on every such pass so
        # that authored/init matrices never reach a viewport draw.
        if not _state.get("ragdoll_syncing", False):
            _ragdoll_restore_cached_frame(scene)
            _ragdoll_debug_event(
                "history_depsgraph_hold", frame=int(scene.frame_current)
            )
        return
    if (
        _state.get("ragdoll_syncing", False)
        or _state.get("surface_contact_solver_syncing", False)
        or _state.get("pin_snap_syncing", False)
        or _state.get("pin_snap_sample_syncing", False)
        or _state.get("pin_selection_syncing", False)
        or extension_update_guard_active()
    ):
        _ragdoll_debug_event(
            "depsgraph_blocked",
            frame=int(getattr(scene, "frame_current", 0)),
            syncing=bool(_state.get("ragdoll_syncing", False)),
            history=False,
            update_guard=bool(extension_update_guard_active()),
        )
        return
    context = bpy.context
    if getattr(context, "scene", None) != scene:
        return
    if not _ragdoll_scene_has_data(scene):
        return
    if _state.get("ragdoll_scrub_job"):
        if _pin_active_transform_operator(context):
            _state.pop("ragdoll_scrub_job", None)
        else:
            _ragdoll_hold_scrub_pose(scene)
            return
    action_updated = _depsgraph_has_action_update(_depsgraph)
    key_transform = _ragdoll_transform_edits_keys(context)
    if key_transform:
        _state["ragdoll_key_transform_active"] = True
        _ragdoll_reconcile_marker_edits(scene)
        previous_sparse = _state.get('ragdoll_native_sparse_replay', False)
        _state['ragdoll_native_sparse_replay'] = True
        try:
            if _ragdoll_native_scene(scene):
                return
            _ragdoll_frame_change_post(scene, _depsgraph)
        finally:
            _state['ragdoll_native_sparse_replay'] = previous_sparse
        return
    if action_updated and _ragdoll_reconcile_marker_edits(scene):
        _ragdoll_debug_event(
            "depsgraph_marker_reconcile",
            frame=int(scene.frame_current),
        )
        return
    if (action_updated and not _pin_active_transform_operator(context)
            and not _state.get("ragdoll_driver_modal_sessions")
            and _ragdoll_native_scene(scene)):
        # A deleted driving key changes incoming velocity even when the torso
        # itself is orange. Validate and publish the whole coupled island now.
        return
    if _animation_playback_active(context):
        # Blender can evaluate the native Action once more after the frame
        # handler. Reapply the already-computed cached hierarchy in the final
        # depsgraph phase so backward playback never draws the authored/init
        # pose for one frame before the next playback callback repairs it.
        # Another dependency evaluation can overwrite Action channels again
        # within this same frame. The hold is idempotent, so verify each pass
        # instead of allowing only one repair per frame-handler invocation.
        _ragdoll_playback_post(scene, _depsgraph)
        return
    if _ragdoll_capture_start_edits(context):
        return
    if _pin_active_transform_operator(context):
        protected = []
        for owner, bones in _selected_pose_bones_by_owner(context).items():
            selected = tuple(bone for bone in bones if _ragdoll_active(bone, scene.frame_current))
            if selected:
                protected.append((owner, selected))
        if protected:
            _state["ragdoll_syncing"] = True
            try:
                for owner, bones in protected:
                    _ragdoll_restore_applied_states(owner, bones, scene.frame_current)
            finally:
                _state["ragdoll_syncing"] = False
            if all(_ragdoll_active(bone, scene.frame_current)
                   for bones in _selected_pose_bones_by_owner(context).values()
                   for bone in bones):
                return
    snapshots = _state.setdefault("ragdoll_armature_world_matrices", {})
    remapped_object = False
    for armature in tuple(scene.objects):
        if armature.type != "ARMATURE" or getattr(armature, "pose", None) is None:
            continue
        previous_world = snapshots.get(str(armature.name_full))
        if previous_world is not None:
            remapped_object = (
                _ragdoll_remap_armature_world_states(armature, previous_world)
                or remapped_object
            )
        snapshots[str(armature.name_full)] = armature.matrix_world.copy()
    if remapped_object:
        _ragdoll_frame_change_post(scene, _depsgraph)
        return
    active_pose_bone = getattr(context, "active_pose_bone", None)
    if not any(
        _ragdoll_active(pose_bone, int(scene.frame_current))
        for armature in tuple(scene.objects)
        if armature.type == "ARMATURE" and getattr(armature, "pose", None) is not None
        for pose_bone in armature.pose.bones
    ):
        return
    frame = int(scene.frame_current)
    boundary_samples = _state.setdefault(
        "ragdoll_boundary_pose_samples", {}
    )
    for armature in tuple(scene.objects):
        if armature.type != "ARMATURE" or getattr(armature, "pose", None) is None:
            continue
        for candidate in armature.pose.bones:
            if not _ragdoll_active(candidate, frame):
                continue
            key = _ragdoll_state_key(armature, candidate)
            if _state.get("ragdoll_states", {}).get(key, {}).get("start_authoritative"):
                continue
            cache = _state.setdefault("ragdoll_frame_cache", {}).get(key, {})
            start = _ragdoll_active_start_frame(armature, candidate, frame)
            cached_boundary = min(cache, default=None)
            if not (
                (start is not None and frame == int(round(float(start))))
                or (
                    cached_boundary is not None
                    and frame == int(cached_boundary)
                )
            ):
                continue
            boundary_free = _ragdoll_free(
                armature, candidate, frame
            )
            anchor, tail = _ragdoll_matrix_world_points(
                armature, candidate, connected=not boundary_free
            )
            boundary_samples[key] = {
                "frame": frame,
                "anchor": anchor.copy(),
                "position": tail.copy(),
                "free": boundary_free,
            }
    now = time.monotonic()
    armature = getattr(context, "active_object", None)
    pose_bone = getattr(context, "active_pose_bone", None)
    if (
        armature is not None
        and armature.type == "ARMATURE"
        and pose_bone is not None
        and bool(getattr(pose_bone, "select", False))
        and _ragdoll_active(pose_bone, int(scene.frame_current))
    ):
        key = _ragdoll_state_key(armature, pose_bone)
        state = _state.setdefault("ragdoll_states", {}).get(key)
        if state is not None and int(state.get("frame", -1)) == int(scene.frame_current):
            current_free = _ragdoll_free(
                armature, pose_bone, int(scene.frame_current)
            )
            if bool(state.get("free", False)) != current_free:
                # A newly keyed Unparent changes the solver mode on this
                # exact frame. Convert it before the helper constraint's
                # evaluated matrix can be mistaken for a manual bone edit.
                cache = _state.setdefault("ragdoll_frame_cache", {}).setdefault(
                    key, {}
                )
                converted = {
                    name: value.copy() if hasattr(value, "copy") else value
                    for name, value in state.items()
                }
                converted["free"] = current_free
                converted["velocity"] = Vector((0.0, 0.0, 0.0))
                converted["previous"] = Vector(converted["position"]).copy()
                converted["anchor_previous"] = Vector(converted["anchor"]).copy()
                converted["contact_normal"] = None
                converted["contact_point"] = None
                _state["ragdoll_states"][key] = converted
                for cached_frame in tuple(cache):
                    if int(cached_frame) >= int(scene.frame_current):
                        cache.pop(cached_frame, None)
                cache[int(scene.frame_current)] = {
                    name: value.copy() if hasattr(value, "copy") else value
                    for name, value in converted.items()
                }
                _ragdoll_apply_tail(
                    armature,
                    pose_bone,
                    Vector(converted["anchor"]),
                    Vector(converted["position"]),
                    free=current_free,
                )
                _state["ragdoll_last_live_update"] = now
                _ragdoll_refresh_descendants(
                    context, armature, pose_bone, scene.frame_current
                )
                return
            anchor, tail = _ragdoll_matrix_world_points(
                armature, pose_bone, connected=not current_free
            )
            if (tail - Vector(state["position"])).length > max(
                1.0e-5,
                float(pose_bone.bone.length) * 1.0e-4,
            ) and _ragdoll_active_start_frame(armature, pose_bone, frame) != frame:
                # Instant native clears (Alt+G/R/S) have no modal operator.
                # The orange segment still owns their evaluated transform.
                # An active orange segment owns the bone transform. Native
                # G/R/S and its ordinary pose keys may define the pose after
                # Ragdoll End, but must never teleport or reseed the running
                # simulation. Reassert the current atomic state immediately.
                _ragdoll_apply_tail(
                    armature,
                    pose_bone,
                    Vector(state["anchor"]),
                    Vector(state["position"]),
                    free=bool(state.get("free", False)),
                    orientation=state.get("orientation"),
                )
                _state["ragdoll_last_live_update"] = now
                _ragdoll_debug_event(
                    "active_pose_edit_rejected",
                    bone=pose_bone.name,
                    frame=int(scene.frame_current),
                )
                return
    fps = max(
        1.0,
        float(scene.render.fps) / max(1.0e-6, float(scene.render.fps_base)),
    )
    hierarchy_driver_edit = bool(
        armature is not None
        and armature.type == "ARMATURE"
        and pose_bone is not None
        and not _ragdoll_active(pose_bone, frame)
        and (any(
            _ragdoll_is_ancestor(armature, pose_bone, candidate)
            for candidate in armature.pose.bones
            if _ragdoll_active(candidate, frame)
        ) or _ragdoll_native_grab_islands(armature, pose_bone, frame))
    )
    if hierarchy_driver_edit:
        # Timeline dragging also holds LMB. Only a native bone transform
        # owns a driver-edit session; a scrub must never create Auto Keys.
        modal_transform = bool(_pin_active_transform_operator(context))
        signature_key = (
            armature.name_full,
            pose_bone.name,
            int(frame),
        )
        current_pose_signature = _ragdoll_driver_pose_signature(
            pose_bone, frame
        )
        published_pose_signature = _state.setdefault(
            "ragdoll_driver_preview_signatures", {}
        ).get(signature_key)
        curve_key = (armature.name_full, pose_bone.name)
        curve_signatures = _state.setdefault(
            "ragdoll_driver_curve_signatures", {}
        )
        current_curve_signature = _ragdoll_driver_curve_signature(
            armature, pose_bone
        )
        previous_curve_signature = curve_signatures.get(curve_key)
        curve_signatures[curve_key] = current_curve_signature
        if (
            previous_curve_signature is not None
            and previous_curve_signature != current_curve_signature
            and not modal_transform
        ):
            # X/Delete or channel edits change the entire socket trajectory,
            # not merely the current evaluated matrix. Discard every affected
            # descendant generation before the first scrub can reuse its old
            # high velocity/contact state.
            removed_key = (
                _ragdoll_curve_signature_point_count(current_curve_signature)
                < _ragdoll_curve_signature_point_count(previous_curve_signature)
            )
            _ragdoll_debug_event(
                "driver_curve_invalidated",
                driver=pose_bone.name,
                frame=int(frame),
            )
            # Auto Key can publish its curve before Blender exposes the modal
            # transform operator. Never run 0->target scene.frame_set replay
            # from this depsgraph callback: that froze at G press and replayed
            # again after confirm. Debounce one update while the coherent old
            # cache stays visible. Deletion still requests canonical replay;
            # insertion and pose edits use the connected cache remap.
            _ragdoll_schedule_resimulation(
                armature,
                pose_bone,
                int(frame),
                force_full=removed_key,
            )
            return
        modal_sessions = _state.setdefault(
            "ragdoll_driver_modal_sessions", {}
        )
        if modal_transform:
            # Capture the native transform result without mutating its Action.
            # Inserting a visual key on every mouse sample caused 33 full
            # Action evaluations in one recorded drag and 5-11 unit flicker.
            previous_session = modal_sessions.get(signature_key)
            start_poses = (previous_session["start_poses"] if previous_session else {
                child.name: child.get(_RAGDOLL_START_POSES_PROPERTY)
                for child in armature.pose.bones
                if _ragdoll_is_ancestor(armature, pose_bone, child)
                and _ragdoll_active(child, frame)
            })
            modal_sessions[signature_key] = {
                "operator_token": _pin_transform_operator_token(context),
                "start_basis": (previous_session.get("start_basis") if previous_session else
                    (published_pose_signature[1] if published_pose_signature else None)),
                "start_poses": start_poses,
                "armature": armature.name_full,
                "bone": pose_bone.name,
                "frame": int(frame),
                "matrix_basis": pose_bone.matrix_basis.copy(),
                "autokey": bool(
                    getattr(
                        context.scene.tool_settings,
                        "use_keyframe_insert_auto",
                        False,
                    )
                ),
            }
            if not bpy.app.timers.is_registered(
                _ragdoll_driver_modal_commit_timer
            ):
                register_owned_timer(
                    _ragdoll_driver_modal_commit_timer,
                    first_interval=0.0,
                )
        else:
            # The frame-independent timer owns the commit. A depsgraph pass
            # may not occur until a later scrub; consuming the session here
            # caused a frame-60 key to appear only when returning to frame 60.
            if signature_key in modal_sessions:
                return
        same_start_rebased = _ragdoll_rebase_start_branch(
            armature, pose_bone, frame
        )
        _ragdoll_debug_event(
            "hierarchy_driver_edit",
            driver=pose_bone.name,
            frame=int(frame),
            same_start_rebased=bool(same_start_rebased),
            deferred_replay=not bool(same_start_rebased),
        )
        if same_start_rebased:
            _state["ragdoll_last_live_update"] = now
            return
        if modal_transform:
            # G, R and gizmos share the native transform transaction. Solve
            # once per changed input, then restore that same pose on depsgraph
            # echoes; never let a throttled callback expose authored channels.
            previews = _state.setdefault("ragdoll_modal_preview_inputs", {})
            if (previews.get(signature_key) != current_pose_signature
                    and _ragdoll_preview_branch(armature, pose_bone, int(frame))):
                previews[signature_key] = current_pose_signature
            else:
                _ragdoll_restore_applied_states(armature,
                    _ragdoll_active_bones_hierarchy_order(armature, frame), frame)
        elif (
            not modal_transform
            and current_pose_signature != published_pose_signature
        ):
            # Non-modal changes wait for the exact debounced replay while the
            # last published generation remains visible and coherent.
            _ragdoll_schedule_resimulation(
                armature, pose_bone, scene.frame_current
            )
            _ragdoll_restore_applied_states(
                armature,
                _ragdoll_active_bones_hierarchy_order(armature, frame),
                frame,
            )
        elif not modal_transform:
            # This is the normal depsgraph echo of our own atomic confirmation
            # or an unrelated scene update. The published pose/cache pair is
            # already current; scheduling it again caused repeated 305-frame
            # remaps, frame-0 drift, and post-LMB stalls in the trace.
            _ragdoll_restore_applied_states(
                armature,
                _ragdoll_active_bones_hierarchy_order(armature, frame),
                frame,
            )
        return
    if (
        not hierarchy_driver_edit
        and now - float(_state.get("ragdoll_last_live_update", 0.0)) < 1.0 / fps
    ):
        # Throttle simulation work, never ownership: an unrelated native
        # evaluation can republish Action channels between two callbacks.
        _ragdoll_restore_cached_frame(scene)
        return
    _state["ragdoll_last_live_update"] = now
    _ragdoll_frame_change_post(scene, _depsgraph)


def _ragdoll_insert_marker_point(curve, frame, value):
    point = curve.keyframe_points.insert(float(frame), float(value))
    point.interpolation = "CONSTANT"
    point.type = "KEYFRAME" if float(value) >= 0.5 else "GENERATED"
    curve.update()
    return point


def _ragdoll_new_run_curve(armature, pose_bone):
    action = _ragdoll_action(armature)
    curves = _ragdoll_curves(armature, pose_bone)
    used = {int(getattr(curve, "array_index", 0)) for curve in curves}
    index = next(index for index in range(len(used) + 1) if index not in used)
    return _action_new_fcurve(
        action,
        _ragdoll_path(pose_bone),
        animated_id=armature,
        index=index,
        group_name=f"Ragdoll ({pose_bone.name})",
    )


def _ragdoll_set_key(armature, pose_bone, frame, value):
    pose_bone[RAGDOLL_ENABLED_PROPERTY] = float(value)
    curves = _ragdoll_curves(armature, pose_bone)
    curve = next(
        (
            candidate
            for candidate in curves
            if _ragdoll_curve_active_at(candidate, frame)
        ),
        None,
    )
    if curve is None and float(value) < 0.5 and curves:
        earliest_curve = min(
            curves,
            key=lambda candidate: min(
                (float(point.co[0]) for point in candidate.keyframe_points),
                default=float("inf"),
            ),
        )
        earliest_frame = min(
            (float(point.co[0]) for point in earliest_curve.keyframe_points),
            default=float("inf"),
        )
        if float(frame) < earliest_frame - 1.0e-4:
            curve = earliest_curve
    if curve is None and float(value) >= 0.5 and curves:
        curve = _ragdoll_new_run_curve(armature, pose_bone)
        _ragdoll_insert_marker_point(curve, frame, value)
        return curve
    if curve is None and not curves:
        armature.keyframe_insert(
            data_path=_ragdoll_path(pose_bone),
            frame=float(frame),
            group=f"Ragdoll ({pose_bone.name})",
        )
        curve = _ragdoll_curve(armature, pose_bone)
    elif curve is not None:
        existing = next(
            (
                point for point in curve.keyframe_points
                if abs(float(point.co[0]) - float(frame)) <= 1.0e-4
            ),
            None,
        )
        if existing is None:
            _ragdoll_insert_marker_point(curve, frame, value)
        else:
            existing.co[1] = float(value)
    if curve is not None:
        for point in curve.keyframe_points:
            if abs(float(point.co[0]) - float(frame)) <= 1.0e-4:
                point.interpolation = "CONSTANT"
                point.type = "KEYFRAME" if float(value) >= 0.5 else "GENERATED"
        curve.update()
    return curve


def _ragdoll_split_at(armature, pose_bone, frame):
    curve = next(
        (
            candidate
            for candidate in _ragdoll_curves(armature, pose_bone)
            if _ragdoll_curve_active_at(candidate, frame)
        ),
        None,
    )
    if curve is None:
        return False
    future_end = next(
        (
            point for point in sorted(
                curve.keyframe_points, key=lambda item: float(item.co[0])
            )
            if float(point.co[0]) > float(frame) + 1.0 + 1.0e-4
            and float(point.co[1]) < 0.5
        ),
        None,
    )
    if future_end is None:
        return False
    end_frame = float(future_end.co[0])
    curve.keyframe_points.remove(future_end)
    _ragdoll_insert_marker_point(curve, frame, 0.0)
    next_curve = _ragdoll_new_run_curve(armature, pose_bone)
    _ragdoll_insert_marker_point(next_curve, float(frame) + 1.0, 1.0)
    _ragdoll_insert_marker_point(next_curve, end_frame, 0.0)
    return True


def _ragdoll_key_pose(pose_bone, frame, key_type="KEYFRAME"):
    for data_path in ("location", "scale"):
        pose_bone.keyframe_insert(data_path=data_path, frame=float(frame), group=f"Ragdoll ({pose_bone.name})")
    rotation_path = {
        "QUATERNION": "rotation_quaternion",
        "AXIS_ANGLE": "rotation_axis_angle",
    }.get(pose_bone.rotation_mode, "rotation_euler")
    pose_bone.keyframe_insert(data_path=rotation_path, frame=float(frame), group=f"Ragdoll ({pose_bone.name})")
    armature = pose_bone.id_data
    prefix = f"pose.bones[{json.dumps(pose_bone.name)}]."
    valid_paths = {prefix + suffix for suffix in _RAGDOLL_TRANSFORM_SUFFIXES}
    for curve in _action_fcurves(_ragdoll_action(armature), armature):
        if str(getattr(curve, "data_path", "")) not in valid_paths:
            continue
        for point in curve.keyframe_points:
            if abs(float(point.co[0]) - float(frame)) <= 1.0e-4:
                point.type = str(key_type)


def _ragdoll_selected(context):
    if getattr(context, "mode", "") != "POSE":
        return ()
    return tuple(_selected_pose_bones_only(context))


def _ragdoll_propagate_selected_config(source, context, property_name):
    """Apply an N-panel ragdoll config edit to every selected pose bone."""
    if _state.get("ragdoll_config_syncing", False):
        return
    context = context or bpy.context
    selected = tuple(_selected_pose_bones_only(context))
    if source not in selected:
        selected = (source,)
    value = getattr(source, property_name)
    _state["ragdoll_config_syncing"] = True
    try:
        for pose_bone in selected:
            if pose_bone != source:
                setattr(pose_bone, property_name, value)
        displayed = {key: {name: value.copy() if hasattr(value, 'copy') else value
                           for name, value in state.items()}
                     for key, state in _state.get("ragdoll_states", {}).items()}
        owners = {bone.id_data.name_full: bone.id_data for bone in selected}
        for owner in owners.values():
            _ragdoll_invalidate_bones(tuple(_ragdoll_active_bones_hierarchy_order(
                owner, context.scene.frame_current)))
        _state.pop("ragdoll_scrub_job", None)
        _state.pop("ragdoll_modal_preview_inputs", None)
        _ragdoll_frame_change_post(context.scene)
        if _state.get("ragdoll_scrub_job"):
            _state["ragdoll_scrub_hold"] = displayed
            _ragdoll_hold_scrub_pose(context.scene)
    finally:
        _state["ragdoll_config_syncing"] = False


def _ragdoll_gravity_axis_update(source, context):
    _ragdoll_propagate_selected_config(
        source, context, RAGDOLL_GRAVITY_AXIS_RNA
    )


def _ragdoll_weight_update(source, context):
    _ragdoll_propagate_selected_config(
        source, context, RAGDOLL_ACCELERATION_RNA
    )


def _ragdoll_default(pose_bone, name, value):
    if name not in pose_bone:
        pose_bone[name] = value


def _ragdoll_ui_state(context):
    selected = _ragdoll_selected(context)
    frame = int(context.scene.frame_current) if getattr(context, "scene", None) else 0
    active = tuple(pb for pb in selected if _ragdoll_active(pb, frame))
    has_data = tuple(pb for pb in selected if _ragdoll_curve(pb.id_data, pb) is not None)
    return bool(selected), bool(active), bool(has_data)


def _ragdoll_can_split_bone(pose_bone, frame):
    frame = float(frame)
    return any(
        _ragdoll_curve_active_at(curve, frame)
        and any(
            float(point.co[0]) > frame + 1.0 + 1.0e-4
            and float(point.co[1]) < 0.5
            for point in curve.keyframe_points
        )
        for curve in _ragdoll_curves(pose_bone.id_data, pose_bone)
    )


def _ragdoll_can_split(context):
    if getattr(context, "mode", "") != "POSE":
        return False
    frame = float(context.scene.frame_current)
    return any(
        _ragdoll_can_split_bone(pose_bone, frame)
        for pose_bone in _ragdoll_selected(context)
    )


def _ragdoll_prepare_launch(pose_bone, frame):
    """Use Vector handles on the final automatic launch key.

    This is an explicit authoring operation, never an evaluation-time override.
    The visible animation and physics must sample the same edited curve. Keep
    interior keys, holds, stepped motion and manually authored handles intact.
    """
    owner = pose_bone.id_data
    if not _ragdoll_free(owner, pose_bone, frame):
        return
    animation = owner.animation_data
    if animation is None or animation.action is None:
        return
    path = pose_bone.path_from_id() + '.location'
    changed = False
    for curve in _action_fcurves(animation.action, owner):
        if curve.data_path != path or len(curve.keyframe_points) < 2:
            continue
        previous, endpoint = curve.keyframe_points[-2:]
        if (abs(endpoint.co.x - frame) > 1e-4
                or previous.interpolation != 'BEZIER'
                or endpoint.handle_left_type not in {'AUTO', 'AUTO_CLAMPED'}
                or abs(endpoint.co.y - previous.co.y) < 1e-7):
            continue
        endpoint.handle_left_type = 'VECTOR'
        endpoint.handle_right_type = 'VECTOR'
        curve.update()
        changed = True
    return changed


class ANIMATOR_UTILS_OT_ragdoll_clear_initial_transform(bpy.types.Operator):
    bl_idname = "staticaliza.ragdoll_clear_initial_transform"
    bl_label = "Clear Ragdoll Initial Transform"
    bl_options = {"REGISTER", "UNDO"}

    channel: bpy.props.EnumProperty(items=(
        ("LOCATION", "Location", ""),
        ("ROTATION", "Rotation", ""),
        ("SCALE", "Scale", ""),
    ))

    @classmethod
    def poll(cls, context):
        if getattr(context, "mode", "") != "POSE":
            return False
        frame = int(context.scene.frame_current)
        return any(_ragdoll_active(bone, frame)
                   and _ragdoll_active_start_frame(owner, bone, frame) == frame
                   for owner, bones in _selected_pose_bones_by_owner(context).items()
                   for bone in bones)

    def execute(self, context):
        frame = int(context.scene.frame_current)
        selected = _selected_pose_bones_by_owner(context)
        starts = [(owner, bone) for owner, bones in selected.items() for bone in bones
                  if _ragdoll_active(bone, frame)
                  and _ragdoll_active_start_frame(owner, bone, frame) == frame]
        protected = [(bone, bone.matrix_basis.copy())
                     for owner, bones in selected.items() for bone in bones
                     if _ragdoll_active(bone, frame) and (owner, bone) not in starts]
        guards = {name: _state.get(name, False) for name in (
            "ragdoll_syncing", "surface_contact_solver_syncing", "surface_contact_reconciling")}
        _state.update({name: True for name in guards})
        try:
            operator = {"LOCATION": bpy.ops.pose.loc_clear,
                        "ROTATION": bpy.ops.pose.rot_clear,
                        "SCALE": bpy.ops.pose.scale_clear}[self.channel]
            result = operator()
            if "FINISHED" not in result:
                return result
            for bone, basis in protected:
                bone.matrix_basis = basis
            context.view_layer.update()
            for owner, bone in starts:
                _ragdoll_capture_start_edits(context, contact_bone=bone)
            _surface_contact_seed_runtime_signatures(context)
            _pin_cache_idle_transform_poses(context)
        finally:
            _state.update(guards)
        return {"FINISHED"}


class ANIMATOR_UTILS_OT_ragdoll_action(bpy.types.Operator):
    bl_idname = "staticaliza.ragdoll_action"
    bl_label = "Ragdoll"
    bl_description = "Key, clear, or bake orange-pin pose-bone ragdoll motion"
    bl_options = {"REGISTER", "UNDO"}

    action: bpy.props.EnumProperty(
        items=(
            ("START", "Key Start", "Start gravity simulation here"),
            ("END", "Key End", "End gravity simulation here"),
            ("SPLIT", "Keyframe Split", "Split this Ragdoll segment here"),
            ("INSERT_POSE", "Insert Current Pose Key", "Key the current simulated pose without changing it"),
            ("CLEAR", "Clear", "Remove ragdoll activation from selected bones"),
            ("BAKE", "Bake for Export", "Bake the active ragdoll range to ordinary pose keys"),
        ),
        default="START",
        options={"HIDDEN"},
    )
    gravity_axis: bpy.props.EnumProperty(
        name="Axis",
        description="World-space direction used by orange-pin gravity",
        items=(
            ("X_POS", "+X", "Gravity toward world +X"),
            ("X_NEG", "-X", "Gravity toward world -X"),
            ("Y_POS", "+Y", "Gravity toward world +Y"),
            ("Y_NEG", "-Y", "Gravity toward world -Y"),
            ("Z_POS", "+Z", "Gravity toward world +Z"),
            ("Z_NEG", "-Z", "Gravity toward world -Z (down)"),
        ),
        default="Z_NEG",
    )
    acceleration: bpy.props.FloatProperty(
        name="Weight",
        description="Gravity strength: 100 normal, 50 half, 200 double",
        default=_RAGDOLL_DEFAULT_WEIGHT,
        soft_min=-500.0,
        soft_max=500.0,
        precision=2,
    )
    carry_launch_speed: bpy.props.BoolProperty(
        name="Carry Launch Speed",
        description="Convert the final automatic location key to Vector handles when starting free ragdoll; custom handles remain unchanged",
        default=True,
    )

    @classmethod
    def poll(cls, context):
        return bool(_ragdoll_selected(context))

    def invoke(self, context, event):
        if self.action == "BAKE":
            return context.window_manager.invoke_confirm(
                self,
                event,
                title="Bake Ragdoll for Export?",
                message="This writes pose keys on every simulated frame and disables live ragdoll for the baked bones.",
                confirm_text="Bake",
            )
        return self.execute(context)

    def draw(self, _context):
        if self.action == "START":
            self.layout.prop(self, "gravity_axis", text="Axis")
            self.layout.prop(self, "acceleration", text="Weight")
            self.layout.prop(self, "carry_launch_speed")

    def execute(self, context):
        previous_syncing = bool(_state.get("ragdoll_syncing", False))
        try:
            return self._execute(context)
        finally:
            _state["ragdoll_syncing"] = previous_syncing

    def _execute(self, context):
        selected = _ragdoll_selected(context)
        frame = int(context.scene.frame_current)
        start_poses = set()
        launch_edits = []
        end_poses = {}
        previous_syncing = bool(_state.get("ragdoll_syncing", False))
        if self.action in {"END", "SPLIT"}:
            _state["ragdoll_syncing"] = True
        if self.action == "START":
            # Marker insertion and captured-pose publication are one atomic
            # state transition. This prevents the newly active FCurve from
            # evaluating gravity/rest pose before frame-zero state exists.
            _state["ragdoll_syncing"] = True
            if selected:
                source = selected[-1]
                if not self.properties.is_property_set("gravity_axis"):
                    self.gravity_axis = str(
                        getattr(source, RAGDOLL_GRAVITY_AXIS_RNA, "Z_NEG")
                    )
                if not self.properties.is_property_set("acceleration"):
                    self.acceleration = float(
                        getattr(
                            source,
                            RAGDOLL_ACCELERATION_RNA,
                            _RAGDOLL_DEFAULT_WEIGHT,
                        )
                    )
            for pose_bone in selected:
                if _ragdoll_active(pose_bone, frame) or any(
                    abs(float(point.co[0]) - float(frame)) <= 1.0e-4
                    for curve in _ragdoll_curves(pose_bone.id_data, pose_bone)
                    for point in curve.keyframe_points
                ):
                    continue
                armature = pose_bone.id_data
                start_poses.add(_ragdoll_state_key(armature, pose_bone))
                if self.carry_launch_speed and _ragdoll_prepare_launch(pose_bone, frame):
                    launch_edits.append(pose_bone)
                _ragdoll_store_start_pose(pose_bone, frame)
                # The visible pose is the initial condition, including a
                # translated contact/grab. Keep its actual socket offset.
                poses = _ragdoll_start_poses(pose_bone)
                poses[str(frame)]["editable_socket"] = True
                _ragdoll_write_start_poses(pose_bone, poses)
                setattr(
                    pose_bone,
                    RAGDOLL_GRAVITY_AXIS_RNA,
                    self.gravity_axis,
                )
                setattr(
                    pose_bone,
                    RAGDOLL_ACCELERATION_RNA,
                    self.acceleration,
                )
                _ragdoll_default(
                    pose_bone,
                    RAGDOLL_DAMPING_PROPERTY,
                    _RAGDOLL_CHAIN_DAMPING,
                )
                _ragdoll_default(pose_bone, RAGDOLL_BOUNCE_PROPERTY, 0.0)
                _ragdoll_default(pose_bone, RAGDOLL_FRICTION_PROPERTY, 0.35)
                _ragdoll_default(
                    pose_bone,
                    RAGDOLL_RADIUS_PROPERTY,
                    max(0.02, pose_bone.bone.length * 0.08),
                )
                _ragdoll_default(
                    pose_bone,
                    RAGDOLL_COLLISION_STRETCH_PROPERTY,
                    0.2,
                )
                # Ordinary keys remain editable, but the marker owns the
                # entire active interval. Animation resumes exactly at End.
                _ragdoll_store_transform_baseline(pose_bone.id_data, pose_bone)
                pose_bone[_RAGDOLL_AUTHORED_FRAMES_PROPERTY] = "[]"
                _ragdoll_set_key(pose_bone.id_data, pose_bone, frame, 1.0)
            if not start_poses:
                # A repeated Start is not an edit and must not add an undo step.
                return {"CANCELLED"}
        elif self.action == "END":
            for pose_bone in selected:
                if _ragdoll_active(pose_bone, frame):
                    if _ragdoll_can_split_bone(pose_bone, frame):
                        end_poses[_ragdoll_state_key(
                            pose_bone.id_data, pose_bone
                        )] = pose_bone.matrix.copy()
                        _ragdoll_split_at(
                            pose_bone.id_data, pose_bone, frame
                        )
                        continue
                    # The last simulated matrix is the handoff pose. Capture
                    # it before disabling the marker so a following ordinary
                    # I key starts from exactly what the animator saw.
                    end_poses[_ragdoll_state_key(
                        pose_bone.id_data, pose_bone
                    )] = pose_bone.matrix.copy()
                    _ragdoll_remove_generated_pose_keys(
                        pose_bone.id_data, pose_bone, frame
                    )
                    _ragdoll_set_key(pose_bone.id_data, pose_bone, frame, 0.0)
        elif self.action == "SPLIT":
            for pose_bone in selected:
                if _ragdoll_can_split_bone(pose_bone, frame):
                    end_poses[_ragdoll_state_key(
                        pose_bone.id_data, pose_bone
                    )] = pose_bone.matrix.copy()
                    _ragdoll_split_at(
                        pose_bone.id_data, pose_bone, frame
                    )
        elif self.action == "INSERT_POSE":
            for pose_bone in selected:
                if _ragdoll_active(pose_bone, frame):
                    _ragdoll_key_pose(pose_bone, frame)
        elif self.action == "CLEAR":
            for pose_bone in selected:
                for curve in _ragdoll_curves(pose_bone.id_data, pose_bone):
                    _action_remove_fcurve(_ragdoll_action(pose_bone.id_data), curve)
                if RAGDOLL_ENABLED_PROPERTY in pose_bone:
                    del pose_bone[RAGDOLL_ENABLED_PROPERTY]
                if _RAGDOLL_BASELINE_KEYS_PROPERTY in pose_bone:
                    del pose_bone[_RAGDOLL_BASELINE_KEYS_PROPERTY]
                if _RAGDOLL_AUTHORED_FRAMES_PROPERTY in pose_bone:
                    del pose_bone[_RAGDOLL_AUTHORED_FRAMES_PROPERTY]
                if _RAGDOLL_START_POSES_PROPERTY in pose_bone:
                    del pose_bone[_RAGDOLL_START_POSES_PROPERTY]
        elif self.action == "BAKE":
            start = int(context.scene.frame_start)
            end = int(context.scene.frame_end)
            original = frame
            _state["ragdoll_baking"] = True
            try:
                for bake_frame in range(start, end + 1):
                    context.scene.frame_set(bake_frame)
                    for pose_bone in selected:
                        if _ragdoll_active(pose_bone, bake_frame):
                            _ragdoll_key_pose(pose_bone, bake_frame)
                for pose_bone in selected:
                    for curve in _ragdoll_curves(pose_bone.id_data, pose_bone):
                        _action_remove_fcurve(_ragdoll_action(pose_bone.id_data), curve)
                    pose_bone[RAGDOLL_ENABLED_PROPERTY] = 0.0
                    if _RAGDOLL_BASELINE_KEYS_PROPERTY in pose_bone:
                        del pose_bone[_RAGDOLL_BASELINE_KEYS_PROPERTY]
                    if _RAGDOLL_AUTHORED_FRAMES_PROPERTY in pose_bone:
                        del pose_bone[_RAGDOLL_AUTHORED_FRAMES_PROPERTY]
                    if _RAGDOLL_START_POSES_PROPERTY in pose_bone:
                        del pose_bone[_RAGDOLL_START_POSES_PROPERTY]
            finally:
                _state["ragdoll_baking"] = False
                context.scene.frame_set(original)
        # A Ragdoll operation owns only the selected bones. Clearing every
        # simulation made adding or editing an unrelated orange bone teleport
        # all existing ragdolls back to their authored pose.
        if self.action == "START":
            # Adding a Start owns only its selected bones. Expanding normal
            # invalidation across the now-active connected hierarchy erased
            # existing orange states, briefly exposing every initial pose.
            states = _state.setdefault("ragdoll_states", {})
            caches = _state.setdefault("ragdoll_frame_cache", {})
            samples = _state.setdefault("ragdoll_boundary_pose_samples", {})
            for pose_bone in selected:
                key = _ragdoll_state_key(pose_bone.id_data, pose_bone)
                if key not in start_poses:
                    continue
                states.pop(key, None)
                caches.pop(key, None)
                samples.pop(key, None)
                # The new parent body changes descendant socket trajectories
                # after Start. Retain the displayed boundary but never replay
                # a future limb cache made while that parent was kinematic.
                for child in pose_bone.children_recursive:
                    child_key = _ragdoll_state_key(pose_bone.id_data, child)
                    child_cache = caches.get(child_key, {})
                    for cached_frame in tuple(child_cache):
                        if cached_frame > frame:
                            child_cache.pop(cached_frame, None)
                    child_state = states.get(child_key)
                    if child_state and int(child_state.get("frame", frame)) > frame:
                        states.pop(child_key, None)
            _state.setdefault("ragdoll_collision_bounds", {}).clear()
        else:
            _ragdoll_invalidate_bones(selected)
        if self.action == "START":
            collision_shapes = _state.setdefault("ragdoll_collision_shapes", {})
            # Publish parents before calculating child sockets. All captured
            # rotations remain unchanged; only head translation is constrained.
            context.view_layer.update()
            ordered = sorted(selected, key=lambda bone: (
                bone.id_data.name_full,
                _ragdoll_hierarchy_depth(bone.id_data, bone),
                bone.name,
            ))
            previous_level = None
            for pose_bone in ordered:
                armature = pose_bone.id_data
                key = _ragdoll_state_key(armature, pose_bone)
                if key not in start_poses:
                    continue
                level = (armature.name_full, _ragdoll_hierarchy_depth(armature, pose_bone))
                if previous_level is not None and level != previous_level:
                    context.view_layer.update()
                previous_level = level
                collision_shapes.pop(key, None)
                free = _ragdoll_free(armature, pose_bone, frame)
                anchor, tail = _ragdoll_matrix_world_points(
                    armature, pose_bone, connected=not free, authored=True
                )
                initial = {
                    "frame": frame,
                    "position": tail.copy(),
                    "previous": tail.copy(),
                    "velocity": Vector((0.0, 0.0, 0.0)),
                    "anchor": anchor.copy(),
                    "anchor_previous": anchor.copy(),
                    "free": free,
                    "seeded": True,
                    "start_authoritative": True,
                }
                _state["ragdoll_states"][key] = initial
                _state["ragdoll_frame_cache"][key] = {
                    frame: {
                        name: value.copy() if hasattr(value, "copy") else value
                        for name, value in initial.items()
                    }
                }
                _ragdoll_apply_tail(armature, pose_bone, anchor, tail, free=free)
            context.view_layer.update()
            _state["ragdoll_syncing"] = previous_syncing
        context.view_layer.update()
        if self.action in {"END", "SPLIT"}:
            _ragdoll_reconcile_marker_edits(context.scene)
            for pose_bone in selected:
                matrix = end_poses.get(
                    _ragdoll_state_key(pose_bone.id_data, pose_bone)
                )
                if matrix is not None:
                    _set_pose_bone_constrained_output_matrix(
                        context, pose_bone.id_data, pose_bone, matrix, atomic=True
                    )
            context.view_layer.update()
        _state["ragdoll_syncing"] = previous_syncing
        # An edited incoming tangent also changes already-ragdolled children
        # before this Start. Publish that trajectory now, not on a later scrub.
        for pose_bone in launch_edits:
            _ragdoll_resimulate_branch(pose_bone.id_data, pose_bone, frame, defer=True)
        _sync_all_dynamic_pose_bone_colors(frame)
        return {"FINISHED"}
