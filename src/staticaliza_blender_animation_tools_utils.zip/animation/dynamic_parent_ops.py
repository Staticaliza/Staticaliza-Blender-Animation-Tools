"""Dynamic Parent target selection, segment operations, and public commands."""

from ..core.runtime import *  # noqa: F403

def get_selected_objects(context):
    if context.mode not in ("OBJECT", "POSE"):
        return

    if context.mode == "OBJECT":
        active = context.active_object
        selected = [obj for obj in context.selected_objects if obj != active]

    if context.mode == "POSE":
        active = context.active_pose_bone
        selected = [bone for bone in context.selected_pose_bones if bone != active]

    selected.append(active)
    return selected

def _dynamic_parent_pose_target(context, armature, child_bone):
    # context.selected_pose_bones includes every selected armature in
    # multi-object Pose mode. A valid cross-rig pair therefore looks like two
    # selected "children" unless selection is scoped to the child owner.
    selected_children = tuple(
        pose_bone
        for pose_bone in getattr(getattr(armature, "pose", None), "bones", ())
        if _pose_bone_selected(pose_bone)
    )
    if child_bone is None or child_bone not in selected_children:
        return (None, "", "Select the child bone")

    selected_objects = tuple(context.selected_objects or ())
    other_objects = tuple(obj for obj in selected_objects if obj != armature)
    if other_objects:
        if len(selected_children) != 1 or len(other_objects) != 1:
            return (None, "", "Select one child bone and one target object")
        target = other_objects[0]
        subtarget = ""
        if target.type == "ARMATURE":
            selected_targets = tuple(
                pose_bone
                for pose_bone in target.pose.bones
                if bool(
                    getattr(
                        pose_bone,
                        "select",
                        getattr(pose_bone.bone, "select", False),
                    )
                )
            )
            if len(selected_targets) != 1:
                return (None, "", "Select exactly one target bone")
            subtarget = selected_targets[0].name
        return (target, subtarget, "")

    active_parent = context.active_pose_bone
    if active_parent is None or active_parent not in selected_children:
        return (None, "", "Select the parent bone last")
    if child_bone == active_parent:
        return (None, "", "Select at least one child before the active parent")
    return (armature, active_parent.name, "")


def _track_dynamic_parent_selection_order(context):
    """Preserve click order so the first selected bone remains the parent."""
    records = _state.setdefault("dynamic_parent_selection_order", {})
    active_owners = set()
    for armature in _pose_scope_armatures(context):
        owner_uid = _armature_session_uid(armature)
        if not owner_uid:
            continue
        active_owners.add(owner_uid)
        selected = tuple(
            pose_bone
            for pose_bone in armature.pose.bones
            if _pose_bone_selected(pose_bone)
        )
        selected_names = tuple(pose_bone.name for pose_bone in selected)
        selected_set = set(selected_names)
        previous = [
            name for name in records.get(owner_uid, ()) if name in selected_set
        ]
        added = [name for name in selected_names if name not in previous]
        if not previous and len(added) > 1:
            active = context.active_pose_bone
            active_name = active.name if active in selected else ""
            added = [name for name in added if name != active_name]
            if active_name:
                added.append(active_name)
        records[owner_uid] = tuple(previous + added)
    for owner_uid in tuple(records):
        if owner_uid not in active_owners:
            records.pop(owner_uid, None)
    return records


def _dynamic_parent_ordered_selection(context, armature):
    records = _track_dynamic_parent_selection_order(context)
    selected = {
        pose_bone.name: pose_bone
        for pose_bone in getattr(getattr(armature, "pose", None), "bones", ())
        if _pose_bone_selected(pose_bone)
    }
    order = records.get(_armature_session_uid(armature), ())
    return tuple(selected[name] for name in order if name in selected)


def _dynamic_parent_pose_create_plan(context, armature):
    """Return child/target pairs with the first-selected bone as parent."""
    selected_objects = tuple(context.selected_objects or ())
    other_objects = tuple(obj for obj in selected_objects if obj != armature)
    selected_children = tuple(
        pose_bone
        for pose_bone in getattr(getattr(armature, "pose", None), "bones", ())
        if _pose_bone_selected(pose_bone)
    )
    child_bone = context.active_pose_bone
    # A freshly loaded template can leave ordinary scene objects selected
    # while the imported armature enters Pose Mode. Treat another selected
    # object as an intentional cross-object target only for the unambiguous
    # one-active-bone case. Multi-bone box selection remains bone-to-bone.
    if other_objects and child_bone is not None and len(selected_children) == 1:
        target, subtarget, error = _dynamic_parent_pose_target(
            context,
            armature,
            child_bone,
        )
        return (() if error else ((child_bone, target, subtarget),)), error

    ordered = _dynamic_parent_ordered_selection(context, armature)
    if not ordered:
        return (), "Select the parent bone first"
    first_parent, *child_bones = ordered
    if not child_bones:
        return (), "Select the parent first, then at least one child"
    return tuple(
        (child_bone, armature, first_parent.name)
        for child_bone in child_bones
    ), ""


def _dynamic_parent_child_can_create(child_bone, frame):
    return bool(
        child_bone is not None
        and not _dynamic_parent_has_marker_at(child_bone, int(frame))
        and get_last_dynamic_parent_constraint(child_bone, int(frame)) is None
    )


def _create_pose_dynamic_parent(
    context,
    armature,
    pose_bone,
    target,
    subtarget,
    frame,
):
    desired_output = _pose_space_output_matrix(
        context,
        armature,
        pose_bone,
    )
    pose_bone = _ensure_pose_space_system(
        context,
        armature,
        pose_bone,
        frame,
    )
    if pose_bone is None:
        return None
    desired_factor = desired_output @ _pose_space_input_matrix(
        pose_bone
    ).inverted_safe()
    target_matrix = _pose_space_target_matrix(
        context,
        armature,
        target,
        subtarget,
    )
    constraint = pose_bone.constraints.new("CHILD_OF")
    _dynamic_space_invalidate_runtime_cache()
    _show_dynamic_pose_bone_native_color(pose_bone)
    target_label = target.name if target is not None else "Target"
    constraint.name = (
        f"DP_{target_label}.{subtarget}" if subtarget else f"DP_{target_label}"
    )
    constraint.target = target
    constraint.subtarget = subtarget
    # The managed pose-space factor is already in armature space. Setting the
    # inverse directly preserves the boundary pose and then inherits exactly
    # the target's later motion. Blender's childof_set_inverse operator applies
    # an extra pose-bone conversion here and causes a visible start teleport.
    constraint.inverse_matrix = target_matrix.inverted_safe() @ desired_factor
    # Persist the grab frame in the same undo step as Dynamic Parent. Physics
    # must never derive this from channels it has overwritten during playback.
    offsets = json.loads(pose_bone.get('_staticaliza_ragdoll_grab_offsets', '{}'))
    offset = target_matrix.inverted_safe() @ desired_output
    offsets[constraint.name] = [v for row in offset for v in row]
    pose_bone['_staticaliza_ragdoll_grab_offsets'] = json.dumps(offsets)

    context.view_layer.update()
    _store_dynamic_parent_constraint_segment(
        pose_bone,
        constraint,
        int(frame),
    )
    _store_dynamic_parent_constraint_target(pose_bone, constraint)
    _mark_dynamic_parent_boundary_calibrated(
        pose_bone,
        constraint,
        int(frame),
    )
    constraint.influence = 1.0
    constraint.mute = False
    insert_keyframe_constraint(constraint, int(frame), pose_bone)
    _sync_dynamic_parent_constraints(int(frame), armature)
    context.view_layer.update()
    _accept_authored_dynamic_space_state()
    _store_dynamic_parent_animation_signature()
    return constraint


def _end_pose_dynamic_parent(
    context,
    armature,
    pose_bone,
    constraint,
    frame,
    allow_split = True,
):
    if pose_bone is None or constraint is None:
        return False
    start_frame, existing_end = _dynamic_parent_constraint_segment(
        pose_bone,

        constraint,
    )
    start_frame = int(start_frame) if start_frame is not None else int(frame)
    existing_end = int(existing_end) if existing_end is not None else None
    if (
        allow_split
        and existing_end is not None
        and int(frame) + 1 < existing_end
    ):
        return _split_pose_dynamic_parent_segment(
            context,
            armature,
            pose_bone,
            constraint,
            int(frame),
            existing_end,
        )

    source = _space_constraint_source_for_dynamic_parent(
        constraint,
        start_frame,
    )
    replacing_existing_end = bool(
        existing_end is not None and int(frame) < existing_end
    )
    if replacing_existing_end:
        _remove_future_space_constraints(
            pose_bone,
            source,
            int(frame),
        )
    desired_output = _pose_space_output_matrix(
        context,
        armature,
        pose_bone,
    )
    desired_factor = desired_output @ _pose_space_input_matrix(
        pose_bone
    ).inverted_safe()
    _store_dynamic_parent_constraint_target(pose_bone, constraint)
    _store_dynamic_parent_constraint_segment(
        pose_bone,
        constraint,
        start_frame,
        int(frame),
    )
    constraint.influence = 0.0
    insert_keyframe_constraint(constraint, int(frame), pose_bone)
    if replacing_existing_end:
        action = armature.animation_data.action if armature.animation_data else None
        influence_path = _dynamic_parent_marker_data_path(constraint)
        if influence_path:
            _fcurve_remove_key_all(action, influence_path, existing_end)

    action = armature.animation_data.action if armature.animation_data else None
    unparented = _unparent_eval(
        action,
        pose_bone.name,
        int(frame),
        pb_default = _pb_prop_get(pose_bone, UNP_PROP, 0.0),
    ) >= 0.5
    parent_name = str(pose_bone.bone.get(REL_K_PARENT, ""))
    role = (
        SPACE_ROLE_UNPARENT
        if unparented
        else (SPACE_ROLE_NORMAL if parent_name else SPACE_ROLE_WORLD)
    )
    underlying = _switch_pose_underlying_space(
        context,
        armature,
        pose_bone,
        role,
        int(frame),
        desired_factor,
        source,
    )
    _sync_dynamic_parent_constraints(int(frame), armature)
    context.view_layer.update()
    _accept_authored_dynamic_space_state()
    _store_dynamic_parent_animation_signature()
    return True


def _split_pose_dynamic_parent_segment(
    context,
    armature,
    pose_bone,
    constraint,
    split_frame,
    original_end,
):
    scene = context.scene
    saved_frame = int(scene.frame_current)
    previous_mute = bool(_state.get("unparent_handler_mute", False))
    target = _dynamic_parent_constraint_target(pose_bone, constraint)
    subtarget = str(constraint.subtarget)
    if target is None:
        return False

    _state["unparent_handler_mute"] = True
    try:
        if not _end_pose_dynamic_parent(
            context,
            armature,
            pose_bone,
            constraint,
            int(split_frame),
            allow_split = False,
        ):
            return False

        second_start = int(split_frame) + 1
        scene.frame_set(second_start)
        _sync_dynamic_parent_constraints(second_start, armature)
        context.view_layer.update()
        pose_bone = armature.pose.bones.get(pose_bone.name)
        second_constraint = _create_pose_dynamic_parent(
            context,
            armature,
            pose_bone,
            target,
            subtarget,
            second_start,
        )
        if second_constraint is None:
            return False

        scene.frame_set(int(original_end))
        _sync_dynamic_parent_constraints(int(original_end), armature)
        context.view_layer.update()
        pose_bone = armature.pose.bones.get(pose_bone.name)
        return _end_pose_dynamic_parent(
            context,
            armature,
            pose_bone,
            second_constraint,
            int(original_end),
            allow_split = False,
        )
    finally:
        scene.frame_set(saved_frame)
        _sync_dynamic_parent_constraints(saved_frame, armature)
        context.view_layer.update()
        _state["unparent_handler_mute"] = previous_mute

def dp_create_dynamic_parent_obj(op):
    obj = bpy.context.active_object
    scn = bpy.context.scene
    list_selected_obj = bpy.context.selected_objects

    if len(list_selected_obj) == 2:
        i = list_selected_obj.index(obj)
        list_selected_obj.pop(i)
        parent_obj = list_selected_obj[0]

        dp_keyframe_insert_obj(obj)
        bpy.ops.object.constraint_add_with_targets(type = "CHILD_OF")
        last_constraint = obj.constraints[-1]

        if parent_obj.type == "ARMATURE":
            last_constraint.subtarget = parent_obj.data.bones.active.name
            last_constraint.name = "DP_" + last_constraint.target.name + "." + last_constraint.subtarget
        else:
            last_constraint.name = "DP_" + last_constraint.target.name

        C = bpy.context.copy()
        C["constraint"] = last_constraint
        bpy.ops.constraint.childof_set_inverse(
            constraint = last_constraint.name,
            owner = "OBJECT"
        )

        current_frame = int(scn.frame_current)
        _store_dynamic_parent_constraint_segment(
            obj,
            last_constraint,
            current_frame,
        )
        _store_dynamic_parent_constraint_target(obj, last_constraint)
        obj.constraints[last_constraint.name].influence = 1
        last_constraint.mute = False
        insert_keyframe_constraint(last_constraint, current_frame, obj)

        for ob in list_selected_obj:
            ob.select_set(False)

        obj.select_set(True)
    else:
        op.report({"ERROR"}, "Two objects must be selected")

def dp_create_dynamic_parent_pbone(op):
    arm = bpy.context.active_object
    pbone = bpy.context.active_pose_bone
    scn = bpy.context.scene
    list_selected_obj = bpy.context.selected_objects

    if len(list_selected_obj) == 2 or len(list_selected_obj) == 1:
        if len(list_selected_obj) == 2:
            i = list_selected_obj.index(arm)
            list_selected_obj.pop(i)
            parent_obj = list_selected_obj[0]
            if parent_obj.type == "ARMATURE":
                parent_obj_pbone = parent_obj.data.bones.active
                parent_pose_bone = (
                    parent_obj.pose.bones.get(parent_obj_pbone.name)
                    if parent_obj_pbone is not None
                    else None
                )
                parent_selected = bool(
                    getattr(
                        parent_obj_pbone,
                        "select",
                        getattr(parent_pose_bone, "select", False),
                    )
                )
                if not parent_selected:
                    op.report({"ERROR"}, "At least two bones must be selected")
                    return
        else:
            parent_obj = arm
            selected_bones = bpy.context.selected_pose_bones
            selected_bones.remove(pbone)
            if not selected_bones:
                op.report({"ERROR"}, "At least two bones must be selected")
                return
            parent_obj_pbone = selected_bones[0]

        dp_keyframe_insert_pbone(arm, pbone)
        bpy.ops.pose.constraint_add_with_targets(type = "CHILD_OF")
        last_constraint = pbone.constraints[-1]

        if parent_obj.type == "ARMATURE":
            last_constraint.subtarget = parent_obj_pbone.name
            last_constraint.name = "DP_" + last_constraint.target.name + "." + last_constraint.subtarget
        else:
            last_constraint.name = "DP_" + last_constraint.target.name

        C = bpy.context.copy()
        C["constraint"] = last_constraint
        bpy.ops.constraint.childof_set_inverse(
            constraint = last_constraint.name,
            owner = "BONE"
        )

        current_frame = int(scn.frame_current)
        _store_dynamic_parent_constraint_segment(
            pbone,
            last_constraint,
            current_frame,
        )
        _store_dynamic_parent_constraint_target(pbone, last_constraint)
        pbone.constraints[last_constraint.name].influence = 1
        last_constraint.mute = False
        insert_keyframe_constraint(last_constraint, current_frame, pbone)
    else:
        op.report({"ERROR"}, "Two objects must be selected")

def disable_constraint(obj, const, frame):
    if isinstance(obj, bpy.types.PoseBone):
        matrix_final = obj.matrix.copy()
    else:
        matrix_final = obj.matrix_world.copy()

    frame = int(frame)
    start_frame, _end_frame = _dynamic_parent_constraint_segment(obj, const)

    _store_dynamic_parent_constraint_segment(
        obj,
        const,
        start_frame if start_frame is not None else frame,
        frame,
    )
    const.influence = 0
    if isinstance(obj, bpy.types.PoseBone):
        obj.matrix = matrix_final
    else:
        obj.matrix_world = matrix_final

    insert_keyframe(obj, frame)
    insert_keyframe_constraint(const, frame, obj)
    const.mute = True
    return



def dp_clear(obj, pbone):
    if not obj:
        return False

    target = pbone if pbone else obj
    frame = int(bpy.context.scene.frame_current)
    constraint = get_last_dynamic_parent_constraint(target, frame)
    if constraint is None:
        return False

    action = obj.animation_data.action if obj.animation_data else None
    start_frame, end_frame = _dynamic_parent_constraint_segment(target, constraint)
    start_frame = int(start_frame) if start_frame is not None else frame

    if pbone is not None and _pose_space_managed(pbone):
        removed = _remove_pose_dynamic_parent_segment(
            bpy.context,
            obj,
            pbone,
            constraint,
        )
        pbone = obj.pose.bones.get(pbone.name)
        has_unparent = bool(
            pbone is not None and _managed_unparent_segments(pbone)
        )
        has_dynamic_parent = bool(
            pbone is not None
            and any(
                current.name.startswith("DP_")
                for current in pbone.constraints
            )
        )
        if pbone is not None and not has_unparent and not has_dynamic_parent:
            _teardown_pose_space_system(bpy.context, obj, pbone)
        _sync_dynamic_parent_constraints(frame, obj)
        bpy.context.view_layer.update()
        return bool(removed)

    auto_unparent_start = _dp_auto_unparent_start(pbone, constraint)
    auto_unparent_properties = (
        _dp_auto_unparent_property_names(constraint)
        if auto_unparent_start is not None
        else ()
    )
    object_matrix = target.matrix_world.copy() if pbone is None else None

    captured = None
    if pbone is not None and action is not None:
        captured = _capture_pose_world_matrices_with_arm_mw(
            bpy.context,
            obj,
            pbone.name,
            _transition_key_frames(
                action,
                pbone.name,
                start_frame,
                end_exclusive = end_frame,
            ),
        )

    fcurve = None
    if action is not None:
        marker_path = _dynamic_parent_marker_data_path(constraint)
        fcurve = _fcurve_find(action, marker_path) if marker_path else None
    if fcurve is not None:
        _action_remove_fcurve(action, fcurve)

    _remove_dynamic_parent_constraint_metadata(target, constraint)
    target.constraints.remove(constraint)
    _dynamic_space_invalidate_runtime_cache()

    if pbone is None and object_matrix is not None:
        target.matrix_world = object_matrix
        insert_keyframe(target, frame)

    if pbone is not None and auto_unparent_start is not None and action is not None:
        auto_unparent_end = _unparent_find_end_frame(
            action,
            pbone.name,
            int(auto_unparent_start),
        )
        _unparent_delete_segment_markers(
            action,
            pbone.name,
            int(auto_unparent_start),
            auto_unparent_end,
        )
        for property_name in auto_unparent_properties:
            if property_name in pbone:
                del pbone[property_name]

    if pbone is not None and captured:
        current_bone = obj.pose.bones.get(pbone.name)
        if current_bone is not None:
            has_markers = _unparent_has_marker_keys(action, current_bone.name)
            _pb_prop_set(
                current_bone,
                UNP_PROP,
                _unparent_eval(
                    action,
                    current_bone.name,
                    frame,
                    0.0,
                ) if has_markers else 0.0,
            )
        _restore_pose_world_span(bpy.context, obj, pbone.name, captured)
        current_bone = obj.pose.bones.get(pbone.name)
        if current_bone is not None and not _unparent_has_marker_keys(
            action,
            current_bone.name,
        ):
            _unparent_remove_visual_constraint(current_bone)
            if UNP_PROP in current_bone:
                del current_bone[UNP_PROP]
            _unparent_clear_start_frame(current_bone)
    return True
