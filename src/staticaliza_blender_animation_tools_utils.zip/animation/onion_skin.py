"""Onion-skin and yellow-pin operators and menus."""

from ..core.runtime import *  # noqa: F403

class ONION_SKIN_OT_ghost_toggle(bpy.types.Operator):
    bl_idname = "onion_skin.ghost_toggle"
    bl_label = "Toggle Ghost"
    bl_description = "Toggle Onion Skin previews for the active Pose Mode armatures"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def execute(self, context):
        wm = context.window_manager
        scope = _pose_scope_armatures(context)
        if not scope:
            return {"CANCELLED"}
        enabling = any(not _onion_owner_enabled(armature) for armature in scope)

        if enabling:
            wm.onion_skin_include_meshes = True
            wm.onion_skin_include_bones = False

        _capture_or_clear(context, enabling, armatures = scope)

        return {"FINISHED"}

def _pose_bone_selected(pose_bone):
    if pose_bone is None:
        return False
    try:
        if hasattr(pose_bone, "select"):
            return bool(pose_bone.select)
    except (AttributeError, ReferenceError, RuntimeError):
        pass
    try:
        bone = pose_bone.bone
        return bool(bone.select or bone.select_head or bone.select_tail)
    except (AttributeError, ReferenceError, RuntimeError):
        return False


def _selected_pose_bones_only(context):
    selected = []
    seen = set()
    for armature in _pose_scope_armatures(context):
        for pose_bone in getattr(getattr(armature, "pose", None), "bones", ()):
            if not _pose_bone_selected(pose_bone):
                continue
            try:
                pointer = int(pose_bone.as_pointer())
            except (AttributeError, ReferenceError, TypeError, ValueError):
                pointer = id(pose_bone)
            if pointer in seen:
                continue
            seen.add(pointer)
            selected.append(pose_bone)
    if selected:
        return selected
    try:
        return [
            pose_bone
            for pose_bone in tuple(context.selected_pose_bones or ())
            if pose_bone is not None
        ]
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        return []


def _selected_pose_bones_by_owner(
    context,
    include_active_fallback = False,
    include_virtual_pin = False,
):
    armatures = _pose_scope_armatures(context)
    grouped = {}
    for armature in armatures:
        selected = tuple(
            pose_bone
            for pose_bone in getattr(
                getattr(armature, "pose", None),
                "bones",
                (),
            )
            if _pose_bone_selected(pose_bone)
        )
        if selected:
            grouped[armature] = list(selected)
    if not grouped and include_active_fallback:
        active_bone = getattr(context, "active_pose_bone", None)
        active_armature = _pose_bone_owner(context, active_bone, armatures)
        if active_armature is not None and active_bone is not None:
            grouped[active_armature] = [active_bone]
    if include_virtual_pin:
        selected_pin = _pin_virtual_selected_target_data(context)
        if selected_pin is not None:
            pose_bones = grouped.setdefault(selected_pin[1], [])
            if selected_pin[2] not in pose_bones:
                pose_bones.append(selected_pin[2])
    return grouped


def _selected_owner_bone_keys(context, include_virtual_pin = False):
    return {
        _owner_bone_key(armature, pose_bone.name)
        for armature, pose_bones in _selected_pose_bones_by_owner(
            context,
            include_virtual_pin=include_virtual_pin,
        ).items()
        for pose_bone in pose_bones
    }


def _single_active_pose_bone(context):
    selected = _selected_pose_bones_only(context)
    if len(selected) != 1:
        return None
    active = context.active_pose_bone
    return active if active in selected else selected[0]


def _yellow_resync_armature(context, armature):
    pins = _yellow_owner_map("yellow_modes", armature)
    if not pins:
        return 0
    depsgraph = context.evaluated_depsgraph_get()
    evaluated_armature = armature.evaluated_get(depsgraph)
    objects, _active = _targets(context, armature)
    need_bounds = {
        name for name, mode in pins.items() if int(mode) in (2, 3)
    }
    bounds_world = {}
    if need_bounds:
        bounds_world = _collect_world_shape_from_largest_components(
            context,
            depsgraph,
            armature,
            evaluated_armature,
            need_bounds,
            objs = objects,
        )
    fixed = {}
    for bone_name, mode in pins.items():
        captured = _yellow_capture(
            context,
            depsgraph,
            armature,
            evaluated_armature,
            objects,
            bone_name,
            int(mode),
            bounds_world,
            axis=str(
                armature.pose.bones[bone_name].get(
                    YELLOW_PIN_AXIS_PROPERTY,
                    "Y_NEG",
                )
            ),
        )
        if captured:
            fixed[bone_name] = captured
            _yellow_store_target_property(
                armature,
                bone_name,
                captured[0],
            )
    _yellow_replace_owner_map("yellow_fixed", armature, fixed)
    _yellow_set_owner_hidden(armature, False)
    return len(fixed)

class ANIMATOR_UTILS_OT_yellow_resync_all(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_resync_all"
    bl_label = "Update Pins"
    bl_description = "Recalculate all Onion Pin targets from their current bones"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE" and any(
            _yellow_owner_map("yellow_modes", armature)
            for armature in _pose_scope_armatures(context)
        )

    def execute(self, context):
        if not _state["yellow_modes"]:
            return {"CANCELLED"}
        updated = sum(
            _yellow_resync_armature(context, armature)
            for armature in _pose_scope_armatures(context)
        )
        if not updated:
            return {"CANCELLED"}
        _yellow_refresh_runtime(context)
        return {"FINISHED"}

class ANIMATOR_UTILS_OT_yellow_hide_all(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_hide_all"
    bl_label = "Hide Pins"
    bl_description = "Hide Onion Pins for the active Pose Mode armatures"
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def execute(self, context):
        for armature in _pose_scope_armatures(context):
            _yellow_set_owner_hidden(armature, True)
        _yellow_refresh_runtime(context)
        return {"FINISHED"}

class ANIMATOR_UTILS_OT_yellow_show(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_show"
    bl_label = "Show Pins"
    bl_description = "Show Onion Pins for the active Pose Mode armatures"
    bl_options = {"REGISTER"}

    resync: bpy.props.BoolProperty(default = False)

    @classmethod
    def description(cls, _context, properties):
        if bool(getattr(properties, "resync", False)):
            return "Show Onion Pins and recalculate their targets from the current bones"
        return cls.bl_description

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def execute(self, context):
        for armature in _pose_scope_armatures(context):
            _yellow_set_owner_hidden(armature, False)
            if self.resync:
                _yellow_resync_armature(context, armature)

        _yellow_refresh_runtime(context)
        return {"FINISHED"}


def _set_pose_bone_constrained_output_matrix(
    context,
    armature,
    pose_bone,
    output_matrix,
    atomic=False,
):
    """Set an evaluated pose matrix without applying Child Of twice."""
    frame = int(context.scene.frame_current)
    constraint = _chosen_dynamic_parent_constraint(pose_bone, frame)
    input_matrix = _dynamic_parent_input_matrix(
        context,
        armature,
        constraint,
        output_matrix,
    )
    constraint_mute = (
        bool(getattr(constraint, "mute", False))
        if constraint is not None else False
    )
    try:
        if constraint is not None:
            constraint.mute = True
            if not atomic:
                context.view_layer.update()
        pose_bone = armature.pose.bones.get(pose_bone.name)
        if pose_bone is None:
            return False
        pose_bone.matrix = input_matrix
        if not atomic:
            context.view_layer.update()
    finally:
        if constraint is not None:
            constraint.mute = constraint_mute
        if atomic or constraint is not None:
            context.view_layer.update()
    return True


def _yellow_apply_to_armature(
    context, armature, bones, action, pin_axis=None,
):
    pins = _yellow_owner_map("yellow_modes", armature)
    fixed = _yellow_owner_map("yellow_fixed", armature)
    selected_names = {bone.name for bone in bones if bone is not None}
    if not selected_names:
        return 0, 0

    if action in {"PIVOT", "PIVOT_FROM_START"}:
        depsgraph = context.evaluated_depsgraph_get()
        evaluated_armature = armature.evaluated_get(depsgraph)
        frame = int(context.scene.frame_current)
        changed = 0
        unreachable = 0
        for bone_name in selected_names:
            packed = fixed.get(bone_name)
            evaluated_bone = evaluated_armature.pose.bones.get(bone_name)
            pose_bone = armature.pose.bones.get(bone_name)
            if not packed or evaluated_bone is None or pose_bone is None:
                continue
            current = _yellow_current_world_point(
                depsgraph,
                evaluated_armature,
                evaluated_bone,
                packed,
            )
            if current is None:
                continue
            fixed_point = Vector(packed[0])
            if action == "PIVOT_FROM_START":
                armature_world = evaluated_armature.matrix_world.copy()
                head_world = armature_world @ evaluated_bone.head
                current_vector = current - head_world
                target_vector = fixed_point - head_world
                if (
                    current_vector.length <= 1.0e-8
                    or target_vector.length <= 1.0e-8
                ):
                    continue
                rotation = current_vector.rotation_difference(target_vector)
                pivot_matrix = (
                    Matrix.Translation(head_world)
                    @ rotation.to_matrix().to_4x4()
                    @ Matrix.Translation(-head_world)
                )
                bone_world = (
                    evaluated_armature.matrix_world @ evaluated_bone.matrix
                )
                desired_output = (
                    armature.matrix_world.inverted_safe()
                    @ (pivot_matrix @ bone_world)
                )
                if not _set_pose_bone_constrained_output_matrix(
                    context,
                    armature,
                    pose_bone,
                    desired_output,
                ):
                    continue

                solved = None
                for _attempt in range(3):
                    depsgraph = context.evaluated_depsgraph_get()
                    evaluated_armature = armature.evaluated_get(depsgraph)
                    evaluated_bone = evaluated_armature.pose.bones.get(bone_name)
                    if evaluated_bone is None:
                        break
                    solved = _yellow_current_world_point(
                        depsgraph,
                        evaluated_armature,
                        evaluated_bone,
                        packed,
                    )
                    if solved is None:
                        break
                    correction = fixed_point - solved
                    if correction.length <= 1.0e-5:
                        break
                    correction_armature = (
                        evaluated_armature.matrix_world.inverted_safe().to_3x3()
                        @ correction
                    )
                    corrected = evaluated_bone.matrix.copy()
                    corrected.translation += correction_armature
                    if not _set_pose_bone_constrained_output_matrix(
                        context,
                        armature,
                        pose_bone,
                        corrected,
                    ):
                        break
                depsgraph = context.evaluated_depsgraph_get()
                evaluated_armature = armature.evaluated_get(depsgraph)
                evaluated_bone = evaluated_armature.pose.bones.get(bone_name)
                if evaluated_bone is not None:
                    solved = _yellow_current_world_point(
                        depsgraph,
                        evaluated_armature,
                        evaluated_bone,
                        packed,
                    )
                if solved is None or (fixed_point - solved).length > 0.05:
                    unreachable += 1
            else:
                delta = fixed_point - current
                try:
                    delta_armature = (
                        evaluated_armature.matrix_world.inverted().to_3x3()
                        @ delta
                    )
                except (ValueError, ZeroDivisionError):
                    delta_armature = Vector((0.0, 0.0, 0.0))
                matrix = evaluated_bone.matrix.copy()
                matrix.translation += delta_armature
                if not _set_pose_bone_constrained_output_matrix(
                    context,
                    armature,
                    pose_bone,
                    matrix,
                ):
                    continue
            _insert_bone_keys(pose_bone, frame)
            changed += 1
        return changed, unreachable

    if action == "REMOVE":
        removed = 0
        for bone_name in selected_names:
            if bone_name in pins:
                removed += 1
            pins.pop(bone_name, None)
            fixed.pop(bone_name, None)
            _yellow_clear_target_property(armature, bone_name)
        _yellow_replace_owner_map("yellow_modes", armature, pins)
        _yellow_replace_owner_map("yellow_fixed", armature, fixed)
        return removed, 0

    mode = 1
    mode = {
        "MODE_1": 1,
        "MODE_2": 2,
        "MODE_3": 3,
        "MODE_4": 4,
    }.get(action, 1)
    depsgraph = context.evaluated_depsgraph_get()
    evaluated_armature = armature.evaluated_get(depsgraph)
    objects, _active = _targets(context, armature)
    need_bounds = selected_names if mode in (2, 3) else set()
    bounds_world = {}
    if need_bounds:
        bounds_world = _collect_world_shape_from_largest_components(
            context,
            depsgraph,
            armature,
            evaluated_armature,
            need_bounds,
            objs = objects,
        )
    captured_count = 0
    for bone_name in selected_names:
        pins[bone_name] = int(mode)
        pose_bone = armature.pose.bones.get(bone_name)
        if pose_bone is not None:
            pose_bone[YELLOW_PIN_MODE_PROPERTY] = int(mode)
            axis = str(
                pin_axis
                or pose_bone.get(YELLOW_PIN_AXIS_PROPERTY, "Y_NEG")
            )
            pose_bone[YELLOW_PIN_AXIS_PROPERTY] = axis
        else:
            axis = str(pin_axis or "Y_NEG")
        captured = _yellow_capture(
            context,
            depsgraph,
            armature,
            evaluated_armature,
            objects,
            bone_name,
            int(mode),
            bounds_world,
            axis=axis,
        )
        if captured:
            fixed[bone_name] = captured
            _yellow_store_target_property(
                armature,
                bone_name,
                captured[0],
            )
            pose_bone[YELLOW_PIN_INITIAL_TARGET_PROPERTY] = tuple(
                float(value) for value in Vector(captured[0])
            )
            captured_count += 1
    fixed = {name: value for name, value in fixed.items() if name in pins}
    _yellow_replace_owner_map("yellow_modes", armature, pins)
    _yellow_replace_owner_map("yellow_fixed", armature, fixed)
    return captured_count, 0

class ANIMATOR_UTILS_OT_yellow_apply(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_apply"
    bl_label = "Onion Pin"
    bl_description = "Create or update Onion Pins for the selected bones"
    bl_options = {"REGISTER", "UNDO"}

    action: bpy.props.EnumProperty(
        items = (
            ("MODE_3", "Smart", ""),
            ("MODE_4", "Bone Start", ""),
            ("MODE_2", "Bone Center", ""),
            ("MODE_1", "Bone End", ""),
        ),
        options = {"HIDDEN", "SKIP_SAVE"},
    )

    position_mode: bpy.props.EnumProperty(
        name = "Pin Position",
        description = "Choose where this Onion Pin is placed",
        items = (
            ("MODE_3", "Smart", "Use the selected welded-object face"),
            ("MODE_4", "Bone Start", "Use the bone head"),
            ("MODE_2", "Bone Center", "Use the center of the weighted geometry"),
            ("MODE_1", "Bone End", "Use the bone tail"),
        ),
        default = "MODE_3",
    )
    pin_axis: bpy.props.EnumProperty(
        name = "Axis",
        description = "Choose the welded-object face used by Smart",
        items = PIN_AXIS_ITEMS,
        default = "Y_NEG",
    )

    @classmethod
    def description(cls, _context, properties):
        descriptions = {
            "MODE_3": "Create or update Onion Pins at the selected bones' Smart positions",
            "MODE_4": "Create or update Onion Pins at the selected bones' starts",
            "MODE_2": "Create or update Onion Pins at the selected bones' centers",
            "MODE_1": "Create or update Onion Pins at the selected bones' ends",
        }
        return descriptions.get(getattr(properties, "action", ""), cls.bl_description)

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def draw(self, context):
        if self.action.startswith("MODE_"):
            self.layout.prop(self, "position_mode", text = "Position")
            if self.position_mode == "MODE_3":
                self.layout.prop(self, "pin_axis", text = "Axis")
            else:
                axis_row = self.layout.row()
                axis_row.enabled = False
                axis_row.label(text = "Axis: N/A")

    def execute(self, context):
        grouped = _selected_pose_bones_by_owner(
            context,
            include_active_fallback = True,
            include_virtual_pin = True,
        )
        if not grouped:
            return {"CANCELLED"}
        action = self.action
        if action.startswith("MODE_"):
            if not self.properties.is_property_set("position_mode"):
                self.position_mode = action
            action = self.position_mode
        changed = 0
        unreachable = 0
        for armature, bones in grouped.items():
            owner_changed, owner_unreachable = _yellow_apply_to_armature(
                context,
                armature,
                bones,
                action,
                pin_axis=self.pin_axis,
            )
            changed += owner_changed
            unreachable += owner_unreachable
        if unreachable:
            self.report(
                {"WARNING"},
                f"{unreachable} pin(s) could not be rotated and aligned.",
            )
        if not changed:
            return {"CANCELLED"}
        _yellow_refresh_runtime(context)
        return {"FINISHED"}


class ANIMATOR_UTILS_OT_yellow_pivot(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_pivot"
    bl_label = "Pivot Onion Pin"
    bl_description = "Move the selected bones onto their Onion Pin targets"
    bl_options = {"REGISTER", "UNDO"}

    initial_state_json: bpy.props.StringProperty(options = {"HIDDEN"})
    pivot_method: bpy.props.EnumProperty(
        name = "Pivot Method",
        description = "Choose how the bone reaches its Onion Pin",
        items = (
            (
                "DIRECT",
                "Direct",
                "Move the pinned point directly onto the Onion Pin",
            ),
            (
                "FROM_BONE_START",
                "Align",
                "Rotate the bone toward the Onion Pin, then align the pinned point",
            ),
            (
                "INVERSE",
                "Inverse",
                "Move only the active Onion Pin onto its connected bone or object point",
            ),
        ),
        default = "DIRECT",
    )

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def draw(self, context):
        self.layout.prop(self, "pivot_method", text = "Method")

    def invoke(self, context, _event):
        self.initial_state_json = _pin_pivot_capture_initial(
            context,
            "YELLOW",
        )
        return self.execute(context)

    def execute(self, context):
        if not self.initial_state_json:
            self.initial_state_json = _pin_pivot_capture_initial(
                context,
                "YELLOW",
            )
        else:
            _pin_pivot_restore_initial(context, self.initial_state_json)
        if self.pivot_method == "INVERSE":
            target_data = _yellow_inverse_pivot_target(
                context,
                self.initial_state_json,
            )
            if target_data is None:
                self.report(
                    {"WARNING"},
                    "Select a bone with an Onion Pin or its dragger.",
                )
                return {"CANCELLED"}
            if not _yellow_inverse_pivot(context, target_data):
                return {"CANCELLED"}
            _yellow_refresh_runtime(context)
            return {"FINISHED"}
        grouped = _selected_pose_bones_by_owner(
            context,
            include_active_fallback = True,
            include_virtual_pin = True,
        )
        if not grouped:
            return {"CANCELLED"}
        changed = 0
        unreachable = 0
        action = (
            "PIVOT_FROM_START"
            if self.pivot_method == "FROM_BONE_START"
            else "PIVOT"
        )
        for armature, bones in grouped.items():
            owner_changed, owner_unreachable = _yellow_apply_to_armature(
                context,
                armature,
                bones,
                action,
            )
            changed += owner_changed
            unreachable += owner_unreachable
        if unreachable:
            self.report(
                {"WARNING"},
                f"{unreachable} pin(s) could not be aligned.",
            )
        if not changed:
            return {"CANCELLED"}
        _yellow_refresh_runtime(context)
        return {"FINISHED"}


class ANIMATOR_UTILS_MT_yellow_pin_menu(bpy.types.Menu):
    bl_label = "Onion Pin"

    def draw(self, context):
        sel_set = _selected_owner_bone_keys(
            context,
            include_virtual_pin=True,
        )
        pinned = set(_state.get("yellow_modes", {}).keys())

        selected_pinned = sel_set.intersection(pinned)
        any_pinned = bool(selected_pinned)
        selected_pin_count = len(selected_pinned)

        layout = self.layout
        mode = getattr(context.window_manager, "yellow_pin_mode", "MODE_3")
        if not any_pinned:
            create_pin = layout.operator(
                "staticaliza.yellow_apply",
                text = "Create Pin",
                icon = "ADD",
            )
            create_pin.action = mode
            create_pin.position_mode = mode
            create_pin.pin_axis = str(
                getattr(context.window_manager, "yellow_pin_axis", "Y_NEG")
            )

        if any_pinned:
            layout.separator()
            txt_piv = (
                "Pivot Pin" if selected_pin_count == 1 else "Pivot Pins"
            )
            layout.operator_context = "INVOKE_DEFAULT"
            layout.operator(
                "staticaliza.yellow_pivot",
                text = txt_piv,
                icon = "PIVOT_CURSOR",
            )

            layout.separator()
            txt_rem = (
                "Remove Pin" if selected_pin_count == 1 else "Remove Pins"
            )
            layout.operator(
                "staticaliza.yellow_remove",
                text = txt_rem,
                icon = "X",
            )
