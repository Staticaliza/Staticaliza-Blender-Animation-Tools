"""Articulated ragdoll integration and contact resolution."""

from ..core.runtime import *  # noqa: F403


def _ragdoll_integrate_impl(
    context,
    armature,
    pose_bone,
    state,
    anchor,
    evaluated_tail,
    length,
    *,
    collision_enabled=True,
    collision_setup=None,
):
    fps = max(
        1.0,
        float(context.scene.render.fps)
        / max(1.0e-6, float(context.scene.render.fps_base)),
    )
    dt = 1.0 / fps
    # Connected rods use swept welded-boundary CCD over the complete frame,
    # so subdividing the same segment performs the expensive object ray casts
    # twice without improving tunnelling protection. Free rigid bodies retain
    # the two-step rotational solver below. This makes connected multi-ragdoll
    # playback scale once per bone/frame instead of twice.
    solver_substeps = 1
    sub_dt = dt / float(solver_substeps)
    damping = min(
        0.999,
        max(0.0, float(pose_bone.get(RAGDOLL_DAMPING_PROPERTY, 0.94))),
    )
    # Treat the UI value as retention per 24-fps reference frame so one
    # second of motion damps equally at 24, 30, 60, or custom scene FPS.
    substep_damping = damping ** (
        24.0 / (fps * float(solver_substeps))
    )
    # Weight 100 is intentionally a fast artist-facing acceleration. Apply
    # length-aware underdamped angular decay so that stronger/shorter hinges
    # do not complete a hidden full phase and make one mirrored limb lead the
    # moving socket.  This damps velocity, not gravity, so the drop/swing
    # remains immediate rather than the sluggish weakened-gravity regression.
    angular_frequency = math.sqrt(
        max(
            0.0,
            _RAGDOLL_UNIFORM_ROD_GRAVITY_FACTOR
            * _ragdoll_hinge_gravity(pose_bone).length
            / max(1.0e-5, float(length)),
        )
    )
    substep_damping *= math.exp(-0.35 * angular_frequency * sub_dt)
    bounce = min(
        1.0,
        max(0.0, float(pose_bone.get(RAGDOLL_BOUNCE_PROPERTY, 0.0))),
    )
    friction = min(
        1.0,
        max(0.0, float(pose_bone.get(RAGDOLL_FRICTION_PROPERTY, 0.35))),
    )
    radius = max(
        0.001,
        float(
            pose_bone.get(
                RAGDOLL_RADIUS_PROPERTY,
                max(0.02, pose_bone.length * 0.08),
            )
        ),
    )
    if collision_enabled and collision_setup is not None:
        (
            radius,
            excluded,
            collision_samples,
            _collision_normals,
            collision_surfaces,
        ) = collision_setup
    elif collision_enabled:
        (
            radius,
            excluded,
            collision_samples,
            _collision_normals,
            collision_surfaces,
        ) = _ragdoll_collision_setup(
            context, armature, pose_bone, radius
        )
    else:
        excluded = {armature}
        collision_samples = ()
        collision_surfaces = ()
    collision_stretch = min(
        1.0,
        max(
            0.01,
            float(
                pose_bone.get(RAGDOLL_COLLISION_STRETCH_PROPERTY, 0.2)
            ),
        ),
    )
    compact_collision_samples = _ragdoll_compact_collision_samples(
        collision_samples, collision_stretch
    )
    self_collision_scale = 0.94
    compact_self_collision_samples = _ragdoll_scaled_collision_samples(
        compact_collision_samples or collision_samples,
        self_collision_scale,
    )
    maximum_contact_correction = max(radius * 0.5, length * collision_stretch)
    joint_clearance_radius = max(
        radius * 0.45,
        min(length * 0.32, radius * (0.55 + collision_stretch)),
    )
    # About 70 degrees of parent-relative rotation is a ball-socket rest slot.
    # Beyond it the parent body becomes a normal collision barrier again.
    joint_slot_cosine = math.cos(math.radians(70.0))
    position = Vector(state["position"])
    previous = Vector(state["previous"])
    previous_anchor = Vector(state.get("anchor", anchor))
    joint_rest_direction = _ragdoll_state_joint_rest_direction(
        state, armature, pose_bone, previous_anchor, evaluated_tail
    )
    anchor_delta = anchor - previous_anchor
    velocity = Vector(
        state.get("velocity", (position - previous) * fps)
    )
    anchor_velocity = anchor_delta / dt
    previous_anchor_velocity = Vector(
        state.get("anchor_velocity", (0.0, 0.0, 0.0))
    )
    base_gravity = _ragdoll_hinge_gravity(pose_bone)
    # Integrate the tail in world space and let the moving hinge constraint
    # transfer the socket motion.  Translating the tail by anchor_delta *and*
    # applying -socket_acceleration double-counted parent motion, producing
    # the recorded side-dependent overshoot.  The 3/2 term is the uniform
    # rod angular-gravity response; mass cancels for a prescribed hinge.
    effective_acceleration = (
        base_gravity * _RAGDOLL_UNIFORM_ROD_GRAVITY_FACTOR
    )
    equilibrium_released = bool(state.get("equilibrium_released", False))
    if not equilibrium_released and velocity.length <= 1.0e-5:
        equilibrium_impulse = _ragdoll_unstable_equilibrium_impulse(
            armature,
            pose_bone,
            position,
            previous_anchor,
            effective_acceleration,
            length,
        )
        if equilibrium_impulse.length > 0.0:
            velocity += equilibrium_impulse
            equilibrium_released = True
            _ragdoll_debug_event(
                "unstable_equilibrium_release",
                frame=int(state.get("frame", -1)) + 1,
                bone=str(pose_bone.name),
                impulse=tuple(float(value) for value in equilibrium_impulse),
            )
    reference_world = armature.matrix_world @ pose_bone.matrix
    collision_surfaces = _ragdoll_filter_initial_overlap_surfaces(
        context,
        armature,
        pose_bone,
        int(context.scene.frame_current),
        state,
        compact_collision_samples or collision_samples,
        reference_world,
        collision_surfaces,
    )
    contact_normal = (
        Vector(state["contact_normal"])
        if state.get("contact_normal") is not None
        else None
    )
    contact_point = (
        Vector(state["contact_point"])
        if state.get("contact_point") is not None
        else None
    )
    contact_self = bool(state.get("contact_self", False))
    previous_contact_surface = str(state.get("contact_surface", ""))
    contact_steps = int(state.get("contact_steps", 0))
    contact_surface = str(state.get("contact_surface", ""))
    contact_point_local = state.get("contact_point_local")
    contact_normal_local = state.get("contact_normal_local")
    if contact_self:
        moving_contact = _ragdoll_contact_surface_world_frame(context, state)
        if moving_contact is not None:
            contact_point, contact_normal, _surface = moving_contact
        else:
            contact_normal = None
            contact_point = None
            contact_self = False
            contact_surface = ""
            contact_point_local = None
            contact_normal_local = None
    if (
        contact_self
        and contact_surface
        and joint_rest_direction is not None
        and (contact_object := bpy.data.objects.get(contact_surface)) is not None
        and _ragdoll_direct_joint_surface(
            contact_object, armature, pose_bone
        )
        and _ragdoll_joint_slot_contains(
            position - previous_anchor,
            joint_rest_direction,
            joint_slot_cosine,
        )
    ):
        # Do not warm-start a parent-body manifold after the limb returns to
        # its natural socket cone. Retaining that old face is the other half
        # of the recorded push-out/flicker loop.
        contact_normal = None
        contact_point = None
        contact_self = False
        contact_surface = ""
        contact_point_local = None
        contact_normal_local = None
    predicted = position.copy()
    current_anchor = previous_anchor.copy()
    for substep in range(1, solver_substeps + 1):
        factor = float(substep) / float(solver_substeps)
        step_anchor = previous_anchor.lerp(anchor, factor)
        velocity *= substep_damping
        velocity += effective_acceleration * sub_dt
        predicted = position + velocity * sub_dt
        offset = predicted - step_anchor
        if offset.length <= 1.0e-8:
            offset = evaluated_tail - anchor
        if offset.length <= 1.0e-8:
            offset = Vector((0.0, -1.0, 0.0))
        predicted = step_anchor + offset.normalized() * length
        collision_velocity = None
        collision_normal = None
        welded_collision = False
        corrected = predicted
        if collision_samples:
            old_matrix = _ragdoll_tail_world_matrix(
                reference_world, current_anchor, position
            )
            new_matrix = _ragdoll_tail_world_matrix(
                reference_world, step_anchor, predicted
            )
            # Warm-start a still-valid contact plane before doing any scene
            # ray casts.  Resting limbs therefore need only cheap signed-
            # distance tests, while a stale/deep contact is discarded once
            # its correction exceeds the configured fraction of limb length.
            # This prevents old surfaces from stretching/trapping the rod.
            persistent_contact = False
            if (
                contact_normal is not None
                and contact_point is not None
            ):
                active_contact_samples = (
                    compact_self_collision_samples
                    if contact_self else collision_samples
                )
                signed_distances = tuple(
                    ((new_matrix @ sample) - contact_point).dot(contact_normal)
                    for sample in active_contact_samples
                )
                minimum_index = min(
                    range(len(signed_distances)),
                    key=signed_distances.__getitem__,
                    default=0,
                )
                minimum_distance = (
                    signed_distances[minimum_index]
                    if signed_distances
                    else 0.0
                )
                penetration = max(0.0, -minimum_distance)
                contact_slop = max(0.002, min(0.01, radius * 0.02))
                separating_speed = velocity.dot(contact_normal)
                supporting_acceleration = effective_acceleration.dot(
                    contact_normal
                )
                # A moving same-rig surface needs a release *distance*, not
                # one tiny numerical slop. Otherwise a supported limb clears
                # the manifold for one frame, re-enters the torso from inside,
                # and alternates between a face and corner normal—the recorded
                # idle right-arm teleport. Keep the collider-local plane while
                # gravity still presses toward it; real outward motion still
                # releases immediately through the separating-speed test.
                retention_slop = contact_slop
                if contact_self and supporting_acceleration < -0.05:
                    retention_slop = max(
                        contact_slop,
                        min(radius * 0.08, length * 0.04),
                    )
                if (
                    minimum_distance <= retention_slop
                    and penetration <= maximum_contact_correction
                    and not (
                        separating_speed > max(0.03, radius * 0.05)
                        and supporting_acceleration >= -0.05
                    )
                ):
                    persistent_contact = True
                    welded_collision = True
                    collision_normal = contact_normal.copy()
                    if signed_distances:
                        support_band = max(
                            1.0e-4, min(0.02, radius * 0.02)
                        )
                        support_points = tuple(
                            (new_matrix @ active_contact_samples[index])
                            - collision_normal * distance
                            for index, distance in enumerate(signed_distances)
                            if distance <= minimum_distance + support_band
                        )
                        if not contact_self:
                            contact_point = sum(
                                support_points, Vector((0.0, 0.0, 0.0))
                            ) / float(len(support_points))
                    corrected = predicted + collision_normal * penetration
                    if penetration > 0.0:
                        corrected += collision_normal * 1.0e-5
                    normal_velocity = collision_normal * velocity.dot(
                        collision_normal
                    )
                    tangent_velocity = velocity - normal_velocity
                    collision_velocity = (
                        tangent_velocity * max(0.0, 1.0 - friction)
                    ) * sub_dt
                elif (
                    minimum_distance > retention_slop
                    or penetration > maximum_contact_correction
                    or (
                        separating_speed > max(0.03, radius * 0.05)
                        and supporting_acceleration >= -0.05
                    )
                ):
                    contact_normal = None
                    contact_point = None
                    contact_self = False
                    contact_surface = ""
                    contact_point_local = None
                    contact_normal_local = None

            welded_hit = None
            if not persistent_contact:
                welded_hit = _ragdoll_welded_sweep(
                    context,
                    collision_surfaces,
                    collision_samples,
                    old_matrix,
                    new_matrix,
                    armature=armature,
                    pose_bone=pose_bone,
                    compact_samples=compact_collision_samples,
                    joint_clearance_radius=joint_clearance_radius,
                    joint_rest_direction=joint_rest_direction,
                    joint_slot_cosine=joint_slot_cosine,
                    joint_direction=predicted - step_anchor,
                    self_collision_scale=self_collision_scale,
                )
            if welded_hit is not None:
                welded_collision = True
                hit_fraction, collision_normal, hit_point, hit_surface = welded_hit
                contact_self = _ragdoll_self_collision_surface(
                    hit_surface, armature
                )
                collision_frame = int(state.get("frame", -1)) + 1
                collision_key = (str(pose_bone.name), collision_frame)
                if _state.get("ragdoll_debug_last_collision") != collision_key:
                    _state["ragdoll_debug_last_collision"] = collision_key
                    _ragdoll_debug_event(
                        "welded_collision",
                        frame=collision_frame,
                        bone=str(pose_bone.name),
                        substep=int(substep),
                        hit_fraction=float(hit_fraction),
                        normal=tuple(float(value) for value in collision_normal),
                        point=tuple(float(value) for value in hit_point),
                        surface=str(getattr(hit_surface, "name_full", "")),
                        self_collision=bool(contact_self),
                    )
                contact_normal = collision_normal.copy()
                contact_point = hit_point.copy()
                if contact_self:
                    local_frame = _ragdoll_contact_surface_local_frame(
                        context, hit_surface, hit_point, collision_normal
                    )
                    if local_frame is not None:
                        (
                            contact_surface,
                            contact_point_local,
                            contact_normal_local,
                        ) = local_frame
                    else:
                        contact_surface = ""
                        contact_point_local = None
                        contact_normal_local = None
                else:
                    contact_surface = ""
                    contact_point_local = None
                    contact_normal_local = None
                corrected = position.lerp(predicted, hit_fraction)
                corrected += collision_normal * 1.0e-5
                normal_velocity = collision_normal * velocity.dot(
                    collision_normal
                )
                tangent_velocity = velocity - normal_velocity
                collision_velocity = (
                    tangent_velocity * max(0.0, 1.0 - friction)
                    - normal_velocity * bounce
                ) * sub_dt
        else:
            # Bone-only fallback when no visible welded mesh exists.
            for fraction in (1.0, 0.75, 0.5, 0.25):
                old_sample = previous_anchor.lerp(position, fraction)
                new_sample = step_anchor.lerp(predicted, fraction)
                sample_corrected, sample_velocity, sample_normal = _ragdoll_collision(
                    context,
                    excluded,
                    old_sample,
                    new_sample,
                    radius,
                    bounce,
                    friction,
                )
                if sample_normal is None:
                    continue
                corrected = predicted + (
                    (sample_corrected - new_sample) / max(0.25, fraction)
                )
                collision_velocity = sample_velocity / max(0.25, fraction)
                collision_normal = sample_normal
                break
        if collision_normal is not None:
            if welded_collision:
                active_collision_samples = (
                    compact_self_collision_samples
                    if contact_self else collision_samples
                )
                predicted = _ragdoll_project_welded_contact(
                    reference_world,
                    step_anchor,
                    corrected,
                    length,
                    active_collision_samples,
                    contact_point,
                    collision_normal,
                )
            else:
                predicted = _ragdoll_project_contact(
                    step_anchor,
                    corrected,
                    length,
                    corrected,
                    collision_normal,
                )
            # Depenetration is a positional correction, not momentum.  Use
            # only the bounded reflected incoming displacement for velocity.
            velocity = Vector(collision_velocity) / sub_dt
            if velocity.length < 0.03:
                velocity.zero()
        else:
            predicted = corrected
            constrained = predicted - step_anchor
            if constrained.length > 1.0e-8:
                predicted = step_anchor + constrained.normalized() * length
            velocity = (predicted - position) / sub_dt
        radial = predicted - step_anchor
        if radial.length > 1.0e-8:
            radial.normalize()
            relative_velocity = velocity - anchor_velocity
            relative_velocity -= radial * relative_velocity.dot(radial)
            velocity = relative_velocity + anchor_velocity
            tangent_gravity = effective_acceleration - radial * effective_acceleration.dot(radial)
            if (
                velocity.length < 0.025
                and tangent_gravity.length < 0.1
            ):
                velocity.zero()
        if collision_normal is not None and contact_self:
            same_surface = bool(
                contact_surface
                and contact_surface == previous_contact_surface
            )
            settled_motion = (predicted - position).length <= max(
                1.0e-4, length * 0.003
            )
            stationary_socket = anchor_delta.length <= max(
                1.0e-5, length * 1.0e-5
            )
            contact_steps = (
                contact_steps + 1
                if same_surface and settled_motion and stationary_socket
                else 1
            )
            if contact_steps >= 2:
                # Collision projection is positional correction. Once the
                # same unmoving same-rig surface holds the same pose for two
                # frames, residual tangent velocity is solver noise, not real
                # motion. Clearing it prevents the recorded edge re-impact
                # loop while any socket/surface movement wakes it naturally.
                velocity.zero()
        else:
            contact_steps = 0
        position = predicted.copy()
        current_anchor = step_anchor.copy()
    return {
        "position": predicted.copy(),
        "previous": (predicted - velocity * dt).copy(),
        "velocity": velocity.copy(),
        "anchor": anchor.copy(),
        "anchor_previous": anchor.copy(),
        "anchor_delta": anchor_delta.copy(),
        "anchor_velocity": anchor_velocity.copy(),
        "contact_normal": (
            contact_normal.copy() if contact_normal is not None else None
        ),
        "contact_point": (
            contact_point.copy() if contact_point is not None else None
        ),
        "contact_self": contact_self,
        "contact_surface": contact_surface,
        "contact_point_local": (
            Vector(contact_point_local).copy()
            if contact_point_local is not None else None
        ),
        "contact_normal_local": (
            Vector(contact_normal_local).copy()
            if contact_normal_local is not None else None
        ),
        "contact_steps": contact_steps,
        "joint_rest_direction": (
            joint_rest_direction.copy()
            if joint_rest_direction is not None else None
        ),
        "free": False,
        "seeded": True,
        "equilibrium_released": equilibrium_released,
    }


