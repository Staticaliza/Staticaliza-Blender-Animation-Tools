"""Native held-span display with discrete, independently decoded events."""

from ..core.runtime import *  # noqa: F403


_SPECIAL_EVENT_ENCODING = "_staticaliza_special_event_encoding"


def _special_read_begin():
    """Share read indexes within one synchronous evaluation, never across edits."""
    if 'special_event_reads' in _state:return False
    _state['special_event_reads']={}
    return True


def _special_read_end(owned):
    if owned:_state.pop('special_event_reads',None)


def _special_event_points(curves):
    cache=_state.get('special_event_reads')
    key=('points',tuple(int(c.as_pointer()) for c in curves))
    if cache is not None and key in cache:return cache[key]
    result=tuple(sorted((float(p.co.x),_special_event_value(c,p))
                        for c in curves for p in c.keyframe_points))
    if cache is not None:cache[key]=result
    return result


def _special_event_curve_key(curve):
    name = str(curve.data_path) + ":" + str(curve.array_index)
    # IDProperty names are limited to 63 UTF-8 bytes, unlike FCurve paths.
    return name if len(name.encode("utf-8")) <= 63 else hashlib.sha256(name.encode("utf-8")).hexdigest()[:48]


def _special_event_encoded(curve):
    cache=_state.get('special_event_reads')
    key=('encoded',int(curve.as_pointer()))
    if cache is not None and key in cache:return cache[key]
    result=bool(curve.id_data.get(_SPECIAL_EVENT_ENCODING, {}).get(
        _special_event_curve_key(curve), False))
    if cache is not None:cache[key]=result
    return result


def _special_event_value(curve, key):
    if not _special_event_encoded(curve):
        return float(key.co.y)
    if key.type == "GENERATED":
        return 0.0
    return UNP_SPLIT_VALUE if key.type == "EXTREME" else 1.0


def _special_event_set_value(curve, key, value):
    """Changing an event never replaces its authored interpolation/handles."""
    key.co.y = float(value)
    key.type = ("GENERATED" if value < .5 else
                "EXTREME" if value >= UNP_SPLIT_VALUE - .5 else "KEYFRAME")


def _special_event_migrate_key_style(curve):
    """Only old add-on-forced Constant keys need a one-time default style."""
    action = curve.id_data
    property_name = "_staticaliza_special_event_styles"
    name = _special_event_curve_key(curve)
    if action.get(property_name, {}).get(name, False):
        return False
    changed = False
    for key in curve.keyframe_points:
        if key.interpolation == "CONSTANT":
            _apply_new_motion_key_style(key)
            changed = True
    if property_name not in action:
        action[property_name] = {}
    action[property_name][name] = True
    return changed


def _special_event_display(curve, values=None):
    """Equal state/target IDs draw Blender holds with normal Bézier easing.

    End uses GENERATED and split uses EXTREME, so retiming and deleting native
    keys retain their roles. An inactive gap always starts a new identity.
    Existing legacy Constant styles migrate once; subsequent user edits win.
    """
    encoded = _special_event_encoded(curve)
    events = [(key, _special_event_value(curve, key))
              for key in curve.keyframe_points]
    changed = _special_event_migrate_key_style(curve)
    identities, next_id, current = [], 1, None
    for key, event in events:
        if not encoded:
            desired = ("GENERATED" if event < .5 else
                       "EXTREME" if event >= UNP_SPLIT_VALUE - .5 else
                       "MOVING_HOLD" if key.type == "MOVING_HOLD" else "KEYFRAME")
            if key.type != desired:
                key.type = desired
                changed = True
        target = tuple(values(float(key.co.x))) if values is not None else ()
        if event >= UNP_SPLIT_VALUE - .5:
            identities.clear()
            current = None
        if values is not None:
            identity = next((ident for ident, previous in identities
                             if target and len(previous) == len(target)
                             and all(abs(a-b) < 1.e-6 for a,b in zip(previous,target))), None)
        else:
            identity = current
        if identity is None:
            identity = float(next_id)
            next_id += 1
            if target:
                identities.append((identity, target))
        delta = identity - key.co.y
        if abs(delta) > 1.e-7:
            key.co.y += delta
            key.handle_left.y += delta
            key.handle_right.y += delta
            changed = True
        current = identity
        if event < .5:
            identities.clear()
            current = None
    if not encoded:
        action = curve.id_data
        if _SPECIAL_EVENT_ENCODING not in action:
            action[_SPECIAL_EVENT_ENCODING] = {}
        action[_SPECIAL_EVENT_ENCODING][_special_event_curve_key(curve)] = True
        changed = True
    if changed:
        if (cache:=_state.get('special_event_reads')) is not None:cache.clear()
        curve.update()
    return changed
