"""Rigid scene inputs, completed-pose cache validation and collider edit replay."""
from ..core.runtime import *  # noqa: F403


def _ragdoll_native_collider_edit():
    context=bpy.context;obj=context.active_object
    return bool(context.mode=='OBJECT'
        and obj is not None and obj.type=='MESH' and _pin_active_transform_operator(context)
        and not any(getattr(co,'target',None) and co.target.type=='ARMATURE' for co in obj.constraints))


def _ragdoll_native_collider_reconcile():
    request=_state.get('ragdoll_native_collider_pending')
    if request is None:return None
    scene=bpy.context.scene
    if scene.name_full!=request[0]:
        _state.pop('ragdoll_native_collider_pending',None);return None
    owner=scene.objects.get(request[1]);driver=owner.pose.bones.get(request[2]) if owner and owner.pose else None
    if driver is None:
        _state.pop('ragdoll_native_collider_pending',None);return None
    _ragdoll_native_branch(owner,driver,int(scene.frame_current))
    if not _state.get('ragdoll_native_job'):_state.pop('ragdoll_native_collider_pending',None)
    return None


def _ragdoll_native_collider_completed(job,cached):
    """Publish a completed drag sample; coalesce intervening mouse events."""
    if not job.get('collider_edit'):return False
    request=(job['scene'],*job['key'],job['end'])
    _ragdoll_native_remember_cache(job,cached)
    _ragdoll_native_cancel_job()
    scene=bpy.context.scene
    owner=scene.objects.get(job['key'][0]) if scene.name_full==job['scene'] else None
    target=int(scene.frame_current)
    if owner is None:return True
    previous=_state.get('ragdoll_syncing',False);_state['ragdoll_syncing']=True
    try:
        bones=[]
        for name,states in cached['output'].items():
            bone=owner.pose.bones.get(name)
            if bone is not None and target in states:
                state=states[target]
                _state.setdefault('ragdoll_states',{})[_ragdoll_state_key(owner,bone)]={
                    k:v.copy() if hasattr(v,'copy') else v for k,v in state.items()}
                bones.append(bone)
        _ragdoll_restore_applied_states(owner,tuple(bones),target)
    finally:_state['ragdoll_syncing']=previous
    _state['ragdoll_native_collider_pending']=request
    _state['ragdoll_native_collider_publications']=_state.get('ragdoll_native_collider_publications',0)+1
    register_owned_timer(_ragdoll_native_collider_reconcile,first_interval=.001)
    _tag_redraw_all_view3d()
    return True


def _ragdoll_native_mesh_fingerprint(mesh):
    """Exact bulk RNA reads avoid a Python call for every mesh corner."""
    from array import array
    points=array('f',[0.])*(len(mesh.vertices)*3)
    indices=array('i',[0])*len(mesh.loops)
    counts=array('i',[0])*len(mesh.polygons)
    mesh.vertices.foreach_get('co',points)
    mesh.loops.foreach_get('vertex_index',indices)
    mesh.polygons.foreach_get('loop_total',counts)
    return points.tobytes(),indices.tobytes(),counts.tobytes()


def _ragdoll_native_fast_inputs(armature, driver, *, frame=None):
    """Fingerprint authored rigid inputs, without walking their frame history.

    Complex constraints/deforming surfaces keep the full evaluated planner.
    This cache contains only math and a completed math-only native solution.
    """
    # Removing a body can sample a space's incoming side to recapture its
    # anchor. That temporary counterfactual is not the editor's input context.
    if _state.get('ragdoll_native_capture_before'):return None
    scene=bpy.context.scene
    frame=scene.frame_current if frame is None else int(frame)
    contact_guides=tuple(_surface_contact_guides())
    gyro_guides=tuple(_gyro_guides(scene))
    gyro_constraints={}
    for guide in gyro_guides:
        owner,bone=_gyro_owner(guide)
        if owner==armature and bone is not None:
            gyro_constraints[bone.name]={str(guide.get(key,''))
                for key in ('gyro_stable_constraint','gyro_aim_constraint')}
            for key,target_key in (('gyro_stable_constraint','gyro_reference'),
                                   ('gyro_aim_constraint','gyro_aim_output')):
                co=bone.constraints.get(str(guide.get(key,'')))
                if co is not None and (co.type!='COPY_ROTATION' or co.target!=guide.get(target_key)
                        or co.owner_space!='WORLD' or co.target_space!='WORLD'
                        or co.mix_mode!='REPLACE' or not all((co.use_x,co.use_y,co.use_z))
                        or any((co.invert_x,co.invert_y,co.invert_z))):
                    return None
    owners=tuple(o for o in scene.objects if o.type in {'ARMATURE','MESH'})
    if any(o.parent or o.modifiers or (o.type=='ARMATURE' and (o!=armature or o.constraints
            or any(any(co.name not in gyro_constraints.get(b.name,set()) and not _is_dynamic_state_constraint(co)
                       for co in b.constraints) for b in o.pose.bones)))
            or (o.animation_data and ((_ragdoll_native_unhandled_drivers(o) if o.type=='ARMATURE' else bool(o.animation_data.drivers))
                or any(t.strips for t in o.animation_data.nla_tracks)))
            for o in owners):return None
    def curves(owner):
        return tuple(_action_fcurves(_ragdoll_action(owner),owner))
    def keys(items):
        return tuple((fc.data_path,fc.array_index,fc.mute,fc.extrapolation,_ragdoll_modifier_signature(fc),
            tuple((tuple(p.co),tuple(p.handle_left),tuple(p.handle_right),p.interpolation,p.easing,
                   p.back,p.amplitude,p.period) for p in fc.keyframe_points)) for fc in items)
    def channels(item,paths,prefix='',defaults=None):
        rotation='rotation_quaternion' if item.rotation_mode=='QUATERNION' else 'rotation_axis_angle' if item.rotation_mode=='AXIS_ANGLE' else 'rotation_euler'
        properties=('location','scale',rotation,'delta_location','delta_scale',
                    'delta_rotation_quaternion' if item.rotation_mode=='QUATERNION' else 'delta_rotation_euler')
        return (item.rotation_mode,tuple((prop,tuple(None if (prefix+prop,i) in paths else float(v)
            for i,v in enumerate(defaults[prop] if defaults and prop in defaults else getattr(item,prop)))) for prop in properties
                if hasattr(item,prop)))
    contact_bones={b.name for g in contact_guides if (owner_bone:=_surface_contact_pose_bone(g))[0]==armature and (b:=owner_bone[1]) is not None}
    def bone_channels(b):
        if _ragdoll_active(b,frame) or b.bone.get(_SPACE_CARRIER_OWNER):return ()
        defaults=None
        if b.name in contact_bones:
            starts=_ragdoll_start_poses(b)
            defaults=next((starts[k].get('channel_source') for k in sorted(starts,key=lambda v:float(v),reverse=True)
                           if float(k)<=frame and starts[k].get('channel_source')),None)
        return channels(b,paths,b.path_from_id()+'.',defaults)
    action_curves=curves(armature);paths={(fc.data_path,fc.array_index) for fc in action_curves}
    # Simulation owns orange channels. Every other unkeyed channel remains
    # authored input; keyed channels are represented by their curve above.
    def constraint_input(b,co):
        managed=_is_dynamic_state_constraint(co)
        gated=managed or co.name in gyro_constraints.get(b.name,set())
        target=_dynamic_parent_constraint_target(b,co) if managed else getattr(co,'target',None)
        subtarget=_dynamic_parent_constraint_subtarget(b,co) if managed else getattr(co,'subtarget','')
        return (co.name,co.type,False if gated else co.mute,1. if gated else co.influence,
                target.as_pointer() if target else 0,subtarget,
                getattr(co,'owner_space',''),getattr(co,'target_space',''),
                tuple(tuple(row) for row in co.inverse_matrix) if co.type=='CHILD_OF' else ())
    bones=tuple((b.name,b.parent.name if b.parent else '',tuple(tuple(row) for row in b.bone.matrix_local),
        b.bone.inherit_scale,b.bone.use_inherit_rotation,b.bone.use_local_location,
        # Gyro's generated pair exists only during authored intervals. Its
        # stable semantic inputs/targets are fingerprinted in guide_inputs;
        # native evaluation topology is not another authored animation input.
        tuple(constraint_input(b,co) for co in b.constraints
              if co.name not in gyro_constraints.get(b.name,set())),
        str(b.get(_RAGDOLL_START_POSES_PROPERTY,'')),str(b.get(_SPECIAL_END_INPUTS,'')),
        str(b.get('_staticaliza_ragdoll_grab_offsets','')),
        str(getattr(b,RAGDOLL_GRAVITY_AXIS_RNA,'Z_NEG')),
        float(getattr(b,RAGDOLL_ACCELERATION_RNA,_RAGDOLL_DEFAULT_WEIGHT)),
        tuple(float(b.get(prop,default)) for prop,default in ((RAGDOLL_DAMPING_PROPERTY,_RAGDOLL_CHAIN_DAMPING),
            (RAGDOLL_BOUNCE_PROPERTY,0.),(RAGDOLL_FRICTION_PROPERTY,.35),(RAGDOLL_RADIUS_PROPERTY,.02),
            (RAGDOLL_COLLISION_STRETCH_PROPERTY,.2))),
        bone_channels(b),
        tuple((prop,tuple(None if (b.path_from_id(f'["{prop}"]'),i) in paths else float(v)
            for i,v in enumerate(b.get(prop,())))) for prop in (GYRO_TARGET_PROPERTY,GYRO_TILT_PROPERTY))) for b in armature.pose.bones)
    def packed(value):
        if isinstance(value,bpy.types.ID):return value.name_full,value.as_pointer()
        if isinstance(value,(str,int,float,bool)) or value is None:return value
        if hasattr(value,'to_dict'):return tuple((k,packed(v)) for k,v in sorted(value.to_dict().items()))
        return tuple(packed(v) for v in value)
    def guide_properties(g):
        # Keyed properties are evaluated outputs; their complete curves are
        # fingerprinted below with the control's Action. The saved pose is a
        # reload/history snapshot of a Contact solve, never a physics input.
        # Including either makes an unchanged cached loop look like an edit.
        animated_paths={fc.data_path for fc in curves(g)}
        return tuple((k,packed(v)) for k,v in sorted(g.items())
            if k != SURFACE_CONTACT_SAVED_POSE_PROPERTY
            and g.path_from_id(f'["{bpy.utils.escape_identifier(k)}"]') not in animated_paths)
    guide_inputs=tuple((g.name_full,guide_properties(g),
        tuple(g.location) if g in gyro_guides and (bone:=_gyro_owner(g)[1]) is not None
            and GYRO_TARGET_PROPERTY not in bone else ()) for g in (*contact_guides,*gyro_guides))
    controls={}
    space_helpers={target.name_full:target for bone in armature.pose.bones
                   for co in _dynamic_constraints(bone)
                   if (target:=_dynamic_parent_constraint_target(bone,co)) is not None
                   and target.get(SPACE_HELPER_PROPERTY)}
    for guide in (*contact_guides,*space_helpers.values()):
        item=guide
        while item is not None and item.name_full not in controls:
            # The armature's object channels and complete Action already
            # participate above. Its simulated pose channels are outputs.
            if item==armature:break
            if (item.parent_type=='BONE' or item.constraints or (item.animation_data
                    and (item.animation_data.drivers or any(t.strips for t in item.animation_data.nla_tracks)))):return None
            items=curves(item);item_paths={(fc.data_path,fc.array_index) for fc in items}
            controls[item.name_full]=(item.name_full,item.parent.name_full if item.parent else '',
                tuple(tuple(row) for row in item.matrix_parent_inverse),channels(item,item_paths),keys(items))
            item=item.parent
    meshes=[]
    for obj in owners:
        if obj.type!='MESH':continue
        if obj.data.shape_keys or any(co.type!='CHILD_OF' or co.target!=armature for co in obj.constraints):return None
        items=curves(obj);object_paths={(fc.data_path,fc.array_index) for fc in items}
        meshes.append((obj.name_full,obj.as_pointer(),obj.hide_viewport,obj.hide_render,obj.hide_get(),
            channels(obj,object_paths),keys(items),
            tuple((co.name,co.subtarget,co.mute,co.influence,tuple(tuple(row) for row in co.inverse_matrix)) for co in obj.constraints),
            _ragdoll_native_mesh_fingerprint(obj.data),
            (obj.rigid_body.friction,obj.rigid_body.restitution) if obj.rigid_body else (1.,0.)))
    return (_RAGDOLL_NATIVE_REVISION,scene.name_full,scene.render.fps,scene.render.fps_base,
        tuple(tuple(row) for row in armature.matrix_world),keys(action_curves),bones,tuple(meshes),
        guide_inputs,tuple(controls.values()))


def _ragdoll_native_fast_store(armature,driver,inputs,cached,*,validated_samples=None,validated_signature=None):
    key=(armature.name_full,driver.name)
    bank=_state.setdefault('ragdoll_native_playback_fast',{})
    previous=bank.get(key)
    target=int(bpy.context.scene.frame_current)
    through=int(cached['signature'][2])+len(cached['samples'])-1
    job=_state.get('ragdoll_native_job')
    streaming=bool(job and job.get('key')==key and job.get('cached') is cached
                   and not job.get('preview') and job.get('samples') and job.get('plan_signature'))
    proof_samples=job['samples'] if streaming else cached['samples']
    proof_through=int(job['end']) if streaming else through
    # A prefix cache hit only proves the requested frames. A changed future
    # Parent/Unparent/Contact key can leave the candidate's lookahead obsolete.
    # Never pair today's complete input fingerprint with that unverified tail.
    if (previous is not None and len(previous)>2 and previous[0]==inputs
            and previous[1] is cached and previous[2]>=proof_through):
        validated=previous[2]
    elif proof_through<=target:
        validated=proof_through
    elif (validated_samples is not None and _ragdoll_native_equal(validated_samples,proof_samples)
            and (not streaming or (validated_signature is not None and
                _ragdoll_native_equal(validated_signature,job['plan_signature'])))):
        validated=proof_through
    else:
        # A worker's frozen plan is immutable while its output prefix grows.
        # Validate that whole plan once for these exact authored inputs, not
        # the entire historical prefix again every time Bullet emits a frame.
        plan=_ragdoll_native_plan(armature,driver,proof_through,False)
        samples=_ragdoll_native_samples(plan) if plan is not None else None
        fps=bpy.context.scene.render.fps/max(1.e-6,bpy.context.scene.render.fps_base)
        structure_matches=(not streaming or (plan is not None and
            _ragdoll_native_equal(_ragdoll_native_plan_signature(plan,fps),job['plan_signature'])))
        validated=(proof_through if structure_matches and samples is not None and
            _ragdoll_native_equal(samples,proof_samples) else target)
    entry=(inputs,cached,validated)
    if validated<through:
        caches=_state.get('ragdoll_frame_cache',{})
        for name,published in cached.get('published',{}).items():
            bone=armature.pose.bones.get(name)
            if bone is None:continue
            identity=_ragdoll_state_key(armature,bone)
            if caches.get(identity) is published:
                caches[identity]={f:row for f,row in published.items() if f<=validated}
    bank[key]=entry
    history=_state.setdefault('ragdoll_native_fast_history',{})
    previous=history.get(key,())
    history[key]=(entry,*(item for item in previous if item[0]!=inputs))[:4]
    while len(bank)>32:
        removed=next(iter(bank));bank.pop(removed);history.pop(removed,None)


def _ragdoll_native_fast_restore(armature, driver, target, inputs, *, publish=True):
    key=(armature.name_full,driver.name)
    bank=_state.setdefault('ragdoll_native_playback_fast',{})
    entry=bank.get(key)
    if entry is None or inputs!=entry[0]:
        entry=next((item for item in _state.get('ragdoll_native_fast_history',{}).get(key,()) if inputs==item[0]),None)
    if entry is None:return False
    if len(entry)<3 or int(target)>entry[2]:return False
    cached=entry[1];output=cached['output']
    active=tuple(_ragdoll_active_bones_hierarchy_order(armature,target))
    if not {b.name for b in active}.issubset(output):return False
    if any(target not in output[b.name] for b in active):
        job=_state.get('ragdoll_native_job')
        if (not publish or job is None or job.get('key')!=key
                or job.get('cached') is not cached or target>int(job['end'])):
            return False
        # The exact current inputs already validate this worker's full frozen
        # trajectory. New physical frames can advance in that same world;
        # rebuilding motion history cannot add any new validation here.
        cached=_ragdoll_native_advance_job(job,int(target));output=cached['output']
        if any(target not in output[b.name] for b in active):return False
    caches=_state.setdefault('ragdoll_frame_cache',{})
    if not publish:return True
    bank[key]=entry
    latest=cached.get('through')
    if latest is None:
        latest=max(next(iter(output.values())))
        cached['through']=latest
    for bone in active:
        published=cached.setdefault('published',{}).setdefault(bone.name,{})
        caches[_ragdoll_state_key(armature,bone)]=(published if entry[2]>=latest
            else {f:row for f,row in published.items() if f<=entry[2]})
    latest=min(latest,entry[2])
    for bone in active:
        state=output[bone.name][target]
        identity=_ragdoll_state_key(armature,bone)
        # A streaming worker can extend the same validated generation between
        # display frames. Publish its newly solved prefix for onion/export reads.
        until=cached.setdefault('published_until',{})
        previous=until.get(bone.name)
        if previous is None:previous=min(output[bone.name])-1
        for frame in range(previous+1,latest+1):
            value=output[bone.name].get(frame)
            if value is not None:caches[identity][frame]={k:v.copy() if hasattr(v,'copy') else v for k,v in value.items()}
        until[bone.name]=latest
        _state.setdefault('ragdoll_states',{})[identity]={
            k:v.copy() if hasattr(v,'copy') else v for k,v in state.items()}
    _ragdoll_restore_applied_states(armature,active,target)
    _state['ragdoll_native_fast_hits']=_state.get('ragdoll_native_fast_hits',0)+1
    return True



def _ragdoll_native_fast_resume(armature,driver,target,inputs):
    """Continue a freshly planned worker without planning its history again."""
    job=_state.get('ragdoll_native_job')
    if (job is None or job.get('preview') or job.get('sparse') or job.get('key')!=(armature.name_full,driver.name)
            or job.get('frozen_inputs') is None or job['frozen_inputs']!=inputs
            or not job.get('plan_signature') or target>job['end'] or target<job['start']):
        return False
    # The queue transaction planned these exact authored inputs, including
    # future topology. This proof belongs to this worker, never a replaced job.
    cached=_ragdoll_native_advance_job(job,int(target))
    _ragdoll_native_fast_store(armature,driver,inputs,cached,
        validated_samples=job['samples'],validated_signature=job['plan_signature'])
    return _ragdoll_native_fast_restore(armature,driver,target,inputs)
