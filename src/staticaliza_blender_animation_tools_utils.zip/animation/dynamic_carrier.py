"""Native pose-space evaluation on hidden carriers, separate from display bones."""
from ..core.runtime import *  # noqa: F403

_SPACE_CARRIER = "_staticaliza_space_carrier"
_SPACE_CARRIER_OWNER = "_staticaliza_space_owner"


def _dynamic_carrier(owner):
    if not isinstance(owner,bpy.types.PoseBone):return None
    name=owner.bone.get(_SPACE_CARRIER,"")
    return owner.id_data.pose.bones.get(name) if name else None


def _dynamic_constraints(owner):
    cache=_state.get('special_event_reads')
    key=('constraints',int(owner.as_pointer()))
    if cache is not None and key in cache:return cache[key]
    # Carriers are implementation nodes, never independent marker owners.
    if isinstance(owner,bpy.types.PoseBone) and owner.bone.get(_SPACE_CARRIER_OWNER):return {}
    carrier=_dynamic_carrier(owner)
    result=carrier.constraints if carrier is not None else owner.constraints
    if cache is not None:cache[key]=result
    return result


def _dynamic_constraint_display_owner(constraint):
    armature=constraint.id_data
    path=constraint.path_from_id().split('.constraints[',1)[0]
    if not path.startswith('pose.bones['):return armature
    host=armature.path_resolve(path)
    return armature.pose.bones.get(host.bone.get(_SPACE_CARRIER_OWNER,"")) or host


def _dynamic_carrier_ensure(context,armature,bone):
    existing=_dynamic_carrier(bone)
    if existing is not None:return existing
    bone_name=bone.name
    selected=_capture_relation_selection_state(armature)
    active=context.view_layer.objects.active;saved_mode=context.mode
    bases={b.name:b.matrix_basis.copy() for b in armature.pose.bones}
    name=".Utils Space "+hashlib.sha1(bone_name.encode()).hexdigest()[:16]
    guards={key:_state.get(key,False) for key in ('unparent_handler_mute','ragdoll_syncing','surface_contact_solver_syncing','gyro_syncing')}
    _state.update({key:True for key in guards})
    try:
        context.view_layer.objects.active=armature
        if not _safe_mode_set('EDIT'):raise RuntimeError('Cannot create the pose-space carrier')
        edit=armature.data.edit_bones.new(name)
        edit.head=(0,0,0);edit.tail=(0,.01,0);edit.use_deform=False
        visible=armature.data.edit_bones[bone_name]
        visible.parent=edit;visible.use_connect=False
        _safe_mode_set('POSE' if saved_mode.startswith('POSE') else 'OBJECT')
        bone=armature.pose.bones[bone_name];carrier=armature.pose.bones[name]
        bone.bone[_SPACE_CARRIER]=carrier.name
        carrier.bone[_SPACE_CARRIER_OWNER]=bone_name
        carrier.bone.hide=True;carrier.bone.hide_select=True;carrier.bone.use_deform=False
        for constraint in tuple(bone.constraints):
            if not _is_dynamic_state_constraint(constraint):continue
            new=carrier.constraints.new(constraint.type)
            for prop in constraint.bl_rna.properties:
                if prop.is_readonly or prop.identifier in {'rna_type','type','name','is_override_data'}:continue
                try:setattr(new,prop.identifier,getattr(constraint,prop.identifier))
                except (AttributeError,TypeError,ValueError):pass
            new.name=constraint.name
            bone.constraints.remove(constraint)
        for basis_name,basis in bases.items():
            if (pb:=armature.pose.bones.get(basis_name)) is not None:pb.matrix_basis=basis
        _dynamic_space_invalidate_runtime_cache()
        return carrier
    finally:
        if context.mode=='EDIT_ARMATURE':_safe_mode_set('POSE' if saved_mode.startswith('POSE') else 'OBJECT')
        _restore_relation_selection_state(armature,selected)
        if (carrier:=armature.pose.bones.get(name)) is not None and carrier.bone.get(_SPACE_CARRIER_OWNER):
            (carrier if hasattr(carrier,'select') else carrier.bone).select=False
        if active is not None:context.view_layer.objects.active=active
        _state.update(guards)


def _dynamic_carrier_remove(context,armature,bone):
    carrier=_dynamic_carrier(bone)
    if carrier is None:return False
    name=carrier.name;bone_name=bone.name
    selected=_capture_relation_selection_state(armature);saved_mode=context.mode
    active=context.view_layer.objects.active
    removed=False
    guards={key:_state.get(key,False) for key in ('unparent_handler_mute','ragdoll_syncing','surface_contact_solver_syncing','gyro_syncing')}
    _state.update({key:True for key in guards})
    try:
        context.view_layer.objects.active=armature
        if not _safe_mode_set('EDIT'):return False
        edit=armature.data.edit_bones[bone_name]
        edit.parent=armature.data.edit_bones.get(str(edit.get(REL_K_PARENT,'')))
        edit.use_connect=bool(edit.get(REL_K_CONNECT,False))
        armature.data.edit_bones.remove(armature.data.edit_bones[name])
        removed=True
        return True
    finally:
        _safe_mode_set('POSE' if saved_mode.startswith('POSE') else 'OBJECT')
        bone=armature.pose.bones.get(bone_name)
        if removed and bone is not None and _SPACE_CARRIER in bone.bone:del bone.bone[_SPACE_CARRIER]
        _restore_relation_selection_state(armature,selected)
        if active is not None:context.view_layer.objects.active=active
        _dynamic_space_invalidate_runtime_cache()
        _state.update(guards)


def _dynamic_carrier_migrate_all(context):
    if _state.get('space_carrier_migrating'):return
    _state['space_carrier_migrating']=True
    try:
        for armature in tuple(context.scene.objects):
            if armature.type!='ARMATURE':continue
            names=[bone.name for bone in armature.pose.bones if not bone.bone.get(_SPACE_CARRIER_OWNER)
                   and _dynamic_carrier(bone) is None and any(_is_dynamic_state_constraint(c) for c in bone.constraints)]
            for name in names:_dynamic_carrier_ensure(context,armature,armature.pose.bones[name])
    finally:_state['space_carrier_migrating']=False
