"""Managed dynamic-space helpers, constraints, switching, and teardown."""

from ..core.runtime import *  # noqa: F403

def _matrices_nearly_equal(first, second, tolerance = 1.0e-6):
    return all(
        abs(float(first[row][column]) - float(second[row][column])) <= tolerance
        for row in range(4)
        for column in range(4)
    )


def _calibrate_pose_dynamic_boundary(context, armature, pose_bone, frame):
    if pose_bone is None or int(frame) <= SPACE_MIN_FRAME:
        return False
    if _ragdoll_active(pose_bone,int(frame)):
        # The authored grip already captured this relationship. Recalibrating
        # from a physics-driven helper feeds solved output back into its input.
        return False

    incoming = _chosen_dynamic_parent_constraint(pose_bone, int(frame))
    outgoing = _chosen_dynamic_parent_constraint(pose_bone, int(frame) - 1)
    if incoming is None or outgoing is None or incoming == outgoing:
        return False

    incoming_start, _incoming_end = _dynamic_parent_constraint_segment(
        pose_bone,
        incoming,
    )
    if _special_end_space_is_explicit(pose_bone, incoming):
        # Explicit End pose keys own the handoff. Later edits must not replace
        # ordinary parenting with a newly calculated outgoing-pose offset.
        return False
    if _dynamic_space_role(pose_bone, incoming) == SPACE_ROLE_UNPARENT:
        # The helper is the authored world-space anchor captured by Key Start.
        # Rebuilding its inverse after a later parent transform makes the
        # detached bone inherit that parent again and snap on the next scrub.
        # End boundaries may still calibrate the incoming NORMAL space.
        return False

    outgoing_target = _dynamic_parent_constraint_target(pose_bone, outgoing)
    incoming_target = _dynamic_parent_constraint_target(pose_bone, incoming)
    if outgoing_target is None or incoming_target is None:
        return False

    incoming_target_matrix = _pose_space_target_matrix(
        context,
        armature,
        incoming_target,
        _dynamic_parent_constraint_subtarget(pose_bone, incoming),
    )
    outgoing_target_matrix = _pose_space_target_matrix(
        context,
        armature,
        outgoing_target,
        _dynamic_parent_constraint_subtarget(pose_bone, outgoing),
    )
    desired_factor = outgoing_target_matrix @ outgoing.inverse_matrix
    inverse_matrix = incoming_target_matrix.inverted_safe() @ desired_factor
    regular_parent_boundary = bool(
        incoming.name.startswith("DP_")
        or outgoing.name.startswith("DP_")
        or _dynamic_space_source(pose_bone, incoming).startswith(
            SPACE_SOURCE_DYNAMIC_PARENT_PREFIX
        )
    )
    changed = not _matrices_nearly_equal(
        incoming.inverse_matrix,
        inverse_matrix,
        tolerance=1.0e-8 if regular_parent_boundary else 1.0e-6,
    )
    if changed:
        incoming.inverse_matrix = inverse_matrix
    _mark_dynamic_parent_boundary_calibrated(
        pose_bone,
        incoming,
        incoming_start,
    )
    return changed


def _calibrate_dynamic_space_boundaries(context, frame, armature = None):
    scene = getattr(context, "scene", None)
    if (
        _state.get("dynamic_space_calibrating", False)
        or _state.get("dynamic_space_export_sampling", False)
        or abs(float(getattr(scene, "frame_subframe", 0.0))) > 1.0e-7
    ):
        return False

    _state["dynamic_space_calibrating"] = True
    changed = False
    try:
        armatures = (
            (armature,)
            if armature is not None
            else tuple(
                obj
                for obj in bpy.data.objects
                if obj.type == "ARMATURE" and getattr(obj, "pose", None) is not None
            )
        )
        for current_armature in armatures:
            if current_armature is None or getattr(current_armature, "pose", None) is None:
                continue
            pose_bones = tuple(
                pose_bone
                for pose_bone in current_armature.pose.bones
                if any(
                    _is_dynamic_state_constraint(constraint)
                    for constraint in _dynamic_constraints(pose_bone)
                )
            )
            for _pass in range(3):
                pass_changed = False
                for pose_bone in pose_bones:
                    bone_changed = _calibrate_pose_dynamic_boundary(
                        context,
                        current_armature,
                        pose_bone,
                        int(frame),
                    )
                    pass_changed = bone_changed or pass_changed
                    if bone_changed:
                        context.view_layer.update()
                changed = pass_changed or changed
                if not pass_changed:
                    break
        return changed
    finally:
        _state["dynamic_space_calibrating"] = False


def _sync_dynamic_parent_constraints(frame, armature = None):
    read_scope=_special_read_begin()
    indexes=_state.get('ragdoll_native_channel_indexes')
    if indexes is None:_state['ragdoll_native_channel_indexes']={}
    try:
        changed = False
        for owner in _dynamic_space_constraint_owners(armature):
            changed = _sync_dynamic_parent_owner(owner, frame) or changed
        return changed
    finally:
        _special_read_end(read_scope)
        if indexes is None:_state.pop('ragdoll_native_channel_indexes',None)


def _internal_space_constraints(owner):
    return tuple(

        constraint
        for constraint in _dynamic_constraints(owner)
        if constraint.name.startswith(SPACE_CONSTRAINT_PREFIX)
    )


def _pose_space_managed(pose_bone):
    return bool(pose_bone and _internal_space_constraints(pose_bone))


def _pose_space_input_matrix(pose_bone):
    return pose_bone.bone.matrix_local @ pose_bone.matrix_basis


def _pose_space_output_matrix(context, armature, pose_bone):
    simulated=_ragdoll_cached_pose_matrix(armature,pose_bone,int(context.scene.frame_current))
    if simulated is not None:return simulated
    context.view_layer.update()
    try:
        evaluated_armature = armature.evaluated_get(
            context.evaluated_depsgraph_get()
        )
        evaluated_bone = evaluated_armature.pose.bones.get(pose_bone.name)
        if evaluated_bone is not None:
            return evaluated_bone.matrix.copy()
    except (AttributeError, ReferenceError, RuntimeError):
        pass
    return pose_bone.matrix.copy()


def _pose_space_factor(context, armature, pose_bone):
    output_matrix = _pose_space_output_matrix(
        context,
        armature,
        pose_bone,
    )
    return output_matrix @ _pose_space_input_matrix(pose_bone).inverted_safe()


def _pose_space_target_matrix(context, armature, target, subtarget = ""):
    if target is None:
        return Matrix.Identity(4)
    if target.type=='ARMATURE' and subtarget and (bone:=target.pose.bones.get(subtarget)) is not None:
        simulated=_ragdoll_cached_pose_matrix(target,bone,int(context.scene.frame_current))
        if simulated is not None:return armature.matrix_world.inverted_safe()@target.matrix_world@simulated

    context.view_layer.update()
    depsgraph = context.evaluated_depsgraph_get()
    evaluated_armature = armature.evaluated_get(depsgraph)
    evaluated_target = target.evaluated_get(depsgraph)
    target_world = evaluated_target.matrix_world.copy()
    if evaluated_target.type == "ARMATURE" and subtarget:
        target_bone = evaluated_target.pose.bones.get(subtarget)
        if target_bone is None:
            raise ValueError(f'Bone "{subtarget}" is not available on the target rig.')
        target_world = target_world @ target_bone.matrix
    return evaluated_armature.matrix_world.inverted_safe() @ target_world


def _ensure_space_helper_collection(context, armature = None):
    owner_uid = _armature_session_uid(armature) if armature is not None else 0
    collection = next(
        (
            candidate
            for candidate in bpy.data.collections
            if int(candidate.get(SPACE_HELPER_OWNER_UID_PROPERTY, 0) or 0)
            == int(owner_uid)
            and owner_uid
        ),
        None,
    )
    if collection is None:
        collection = bpy.data.collections.new(SPACE_HELPER_COLLECTION)
        if owner_uid:
            collection[SPACE_HELPER_OWNER_UID_PROPERTY] = int(owner_uid)

    if _strip_blender_numeric_suffix(collection.name) != SPACE_HELPER_COLLECTION:
        collection.name = SPACE_HELPER_COLLECTION
    parent_collection = None
    if armature is not None:
        try:
            bundle = _rig_delete_bundle(armature)
            parent_collection = bundle["master"] if bundle is not None else None
        except (AttributeError, KeyError, ReferenceError, RuntimeError):
            parent_collection = None
    if parent_collection is None:
        parent_collection = context.scene.collection

    if not any(child == collection for child in parent_collection.children):
        try:
            parent_collection.children.link(collection)
        except RuntimeError:
            pass
    # Keep helper collections nested only under their owning rig instead of
    # exposing one global collection beside every imported RIG collection.
    for scene in bpy.data.scenes:
        if scene.collection == parent_collection:
            continue
        try:
            if any(child == collection for child in scene.collection.children):
                scene.collection.children.unlink(collection)
        except (ReferenceError, RuntimeError):
            pass
    for candidate_parent in bpy.data.collections:
        if candidate_parent == parent_collection:
            continue
        try:
            if any(child == collection for child in candidate_parent.children):
                candidate_parent.children.unlink(collection)
        except (ReferenceError, RuntimeError):
            pass
    if not collection.hide_render:
        collection.hide_render = True
    try:
        if not collection.hide_select:
            collection.hide_select = True
    except AttributeError:
        pass
    _order_rig_internal_collections(context, parent_collection, collection)
    return collection


def _order_rig_internal_collections(context, parent, internal):
    """Keep Parts, Cameras, Helpers together without losing layer flags."""
    children = tuple(parent.children)
    parts = [child for child in children
             if _strip_blender_numeric_suffix(child.name).casefold() == 'parts']
    cameras = [child for child in children
               if _strip_blender_numeric_suffix(child.name).casefold() in {'camera', 'cameras'}]
    block = [*parts, *cameras, internal]
    insertion = min(children.index(child) for child in block)
    order = [child for child in children if child not in block]
    order[insertion:insertion] = block
    if tuple(order) == children:
        return False
    flags = {}; active = {}
    def walk(layer, path, visit):
        path = (*path, int(layer.collection.session_uid))
        visit(layer, path)
        for child in layer.children:
            walk(child, path, visit)
    for scene in bpy.data.scenes:
        for view in scene.view_layers:
            key = (scene.name, view.name)
            def capture(layer, path):
                flags[key, path] = tuple(getattr(layer, name) for name in (
                    'exclude', 'hide_viewport', 'holdout', 'indirect_only'))
                if layer == view.active_layer_collection:
                    active[key] = path
            walk(view.layer_collection, (), capture)
    links = {child: getattr(getattr(link, 'light_linking', None), 'link_state', None)
             for child, link in zip(children, getattr(parent, 'collection_children', ()))}
    guards = {name: _state.get(name, False) for name in (
        'ragdoll_syncing', 'surface_contact_solver_syncing', 'dynamic_space_depsgraph_syncing')}
    _state.update({name: True for name in guards})
    try:
        for child in children:
            parent.children.unlink(child)
        for child in order:
            parent.children.link(child)
        for child, link in zip(parent.children, getattr(parent, 'collection_children', ())):
            value = links.get(child)
            if value is not None:
                link.light_linking.link_state = value
        context.view_layer.update()
        for scene in bpy.data.scenes:
            for view in scene.view_layers:
                key = (scene.name, view.name)
                def restore(layer, path):
                    row = flags.get((key, path))
                    if row is not None:
                        for name, value in zip(('exclude', 'hide_viewport', 'holdout', 'indirect_only'), row):
                            if getattr(layer, name) != value:
                                setattr(layer, name, value)
                walk(view.layer_collection, (), restore)
        context.view_layer.update()
        for scene in bpy.data.scenes:
            for view in scene.view_layers:
                key = (scene.name, view.name)
                def restore_active(layer, path):
                    if path == active.get(key):
                        view.active_layer_collection = layer
                walk(view.layer_collection, (), restore_active)
    finally:
        _state.update(guards)
    return True


def _helper_object_armature(helper):
    if helper is None:
        return None
    if helper.type == 'EMPTY' and 'RigMeta' in helper:
        owner = helper.get('_staticaliza_metadata_owner')
        if getattr(owner, 'type', '') == 'ARMATURE':
            return owner
        for obj in bpy.data.objects:
            if obj.type != 'ARMATURE':
                continue
            bundle = _rig_delete_bundle(obj)
            if bundle is not None and bundle['meta'] == helper:
                return obj
        return None
    gyro_owner = helper.get("gyro_armature")
    if helper.type == 'EMPTY' and getattr(gyro_owner, 'type', '') == 'ARMATURE':
        return gyro_owner
    if bool(helper.get(SPACE_HELPER_PROPERTY, False)):
        parent = getattr(helper, "parent", None)
        return parent if getattr(parent, "type", "") == "ARMATURE" else None
    if bool(helper.get(SURFACE_CONTACT_GUIDE_PROPERTY, False)):
        return bpy.data.objects.get(
            str(helper.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
        )
    if bool(helper.get(SURFACE_CONTACT_SOLVER_PROPERTY, False)):
        return _helper_object_armature(getattr(helper, "parent", None))
    return None

def _animation_helpers_hide_native(context):
    """Native empties and relationship lines are not the editable pin overlay."""
    for helper in context.scene.objects:
        if helper.type != 'EMPTY' or _helper_object_armature(helper) is None:
            continue
        if not helper.hide_get():
            helper.hide_set(True)
        if not helper.hide_select:
            helper.hide_select = True
        if not helper.hide_render:
            helper.hide_render = True


def _organize_helper_collections(context):
    if context is None or getattr(context, "scene", None) is None:
        return False
    changed = False
    helpers = tuple(
        obj
        for obj in bpy.data.objects
        if (
            bool(obj.get(SPACE_HELPER_PROPERTY, False))
            or bool(obj.get(SURFACE_CONTACT_GUIDE_PROPERTY, False))
            or bool(obj.get(SURFACE_CONTACT_SOLVER_PROPERTY, False))
            or (obj.type == 'EMPTY' and getattr(obj.get('gyro_armature'), 'type', '') == 'ARMATURE')
            or (obj.type == 'EMPTY' and 'RigMeta' in obj)
        )
    )
    for helper in helpers:
        armature = _helper_object_armature(helper)
        if armature is None:
            continue
        if 'RigMeta' in helper and helper.get('_staticaliza_metadata_owner') != armature:
            helper['_staticaliza_metadata_owner'] = armature
        target = _ensure_space_helper_collection(context, armature)
        if target not in tuple(helper.users_collection):
            target.objects.link(helper)
            changed = True
        for collection in tuple(helper.users_collection):
            if collection == target:
                continue
            try:
                collection.objects.unlink(helper)
                changed = True
            except (ReferenceError, RuntimeError):
                pass
    for collection in tuple(bpy.data.collections):
        if (
            _strip_blender_numeric_suffix(collection.name) not in {'Helpers', 'Animation Helpers'}
            and SPACE_HELPER_OWNER_UID_PROPERTY not in collection
        ):
            continue
        if tuple(collection.objects) or tuple(collection.children):
            continue
        try:
            bpy.data.collections.remove(collection)
            changed = True
        except (ReferenceError, RuntimeError):
            pass
    _animation_helpers_hide_native(context)
    return changed


def _create_space_helper(context, armature, pose_bone, role, frame, factor):
    collection = _ensure_space_helper_collection(context, armature)
    helper = bpy.data.objects.new(
        f"{SPACE_HELPER_OBJECT_PREFIX}{pose_bone.name}_{role}_{int(frame)}",
        None,
    )
    collection.objects.link(helper)
    helper[SPACE_HELPER_PROPERTY] = True
    helper.empty_display_type = "PLAIN_AXES"
    helper.empty_display_size = 0.01
    helper.hide_render = True
    helper.hide_select = True
    helper.parent = armature
    helper.matrix_parent_inverse = Matrix.Identity(4)
    helper.matrix_basis = factor
    try:
        helper.hide_set(True)
    except RuntimeError:
        pass
    context.view_layer.update()
    return helper


def _remove_space_constraint(owner, constraint):
    if owner is None or constraint is None:
        return False
    target = _dynamic_parent_constraint_target(owner, constraint)
    is_helper = bool(
        target is not None
        and bool(target.get(SPACE_HELPER_PROPERTY, False))
    )
    _remove_dynamic_parent_constraint_metadata(owner, constraint)
    try:
        _dynamic_constraints(owner).remove(constraint)
    except (ReferenceError, RuntimeError, ValueError):
        return False
    _dynamic_space_invalidate_runtime_cache()
    if is_helper and target.name in bpy.data.objects:
        bpy.data.objects.remove(target, do_unlink = True)
    return True


def _space_constraint_source_for_unparent(start_frame):
    return f"{SPACE_SOURCE_UNPARENT_PREFIX}{int(start_frame)}"


def _space_constraint_source_for_dynamic_parent(constraint, start_frame):
    identity = f"{constraint.name}:{int(start_frame)}"
    digest = hashlib.sha1(identity.encode("utf-8")).hexdigest()[:16]
    return f"{SPACE_SOURCE_DYNAMIC_PARENT_PREFIX}{digest}"


def _create_pose_space_constraint(
    context,
    armature,
    pose_bone,
    role,
    start_frame,
    end_frame = None,
    desired_factor = None,
    source = SPACE_SOURCE_BASE,
):
    if desired_factor is None:
        desired_factor = _pose_space_factor(
            context,
            armature,
            pose_bone,
        )

    parent_name = str(pose_bone.bone.get(REL_K_PARENT, ""))
    if role == SPACE_ROLE_NORMAL and not parent_name:
        role = SPACE_ROLE_WORLD

    constraint = _dynamic_constraints(pose_bone).new("CHILD_OF")
    _dynamic_space_invalidate_runtime_cache()
    _show_dynamic_pose_bone_native_color(pose_bone)
    constraint.name = f"{SPACE_CONSTRAINT_PREFIX}{role}_{int(start_frame)}"
    if role == SPACE_ROLE_NORMAL:
        constraint.target = armature
        constraint.subtarget = parent_name

        target_matrix = _pose_space_target_matrix(
            context,
            armature,
            armature,
            parent_name,
        )
        constraint.inverse_matrix = target_matrix.inverted_safe() @ desired_factor
    else:
        helper = _create_space_helper(
            context,
            armature,
            pose_bone,
            role,
            start_frame,
            desired_factor,
        )
        constraint.target = helper
        constraint.subtarget = ""
        constraint.inverse_matrix = Matrix.Identity(4)
        if role == SPACE_ROLE_UNPARENT:
            # This is a generated capture of a simulated output, rather than
            # an independently authored world-space input. Removing Orange
            # must recapture it from the surviving animation/physical island.
            helper['_staticaliza_ragdoll_capture'] = (
                [v for row in desired_factor for v in row]
                if _ragdoll_active(pose_bone, int(start_frame)) else [])

    _store_dynamic_space_role(pose_bone, constraint, role)
    _store_dynamic_space_source(pose_bone, constraint, source)
    _store_dynamic_parent_constraint_segment(
        pose_bone,
        constraint,
        int(start_frame),
        int(end_frame) if end_frame is not None else None,
    )
    _store_dynamic_parent_constraint_target(pose_bone, constraint)
    _mark_dynamic_parent_boundary_calibrated(
        pose_bone,
        constraint,
        int(start_frame),
    )
    constraint.influence = 0.0
    constraint.mute = True
    return constraint


def _active_internal_space_constraint(pose_bone, frame):
    active = [
        constraint
        for constraint in _internal_space_constraints(pose_bone)
        if _dynamic_parent_constraint_active_at(pose_bone, constraint, frame)
    ]
    return active[-1] if active else None


def _ensure_pose_space_system(context, armature, pose_bone, frame):
    if pose_bone is None:
        return None
    bone_name = pose_bone.name
    if _pose_space_managed(pose_bone):
        if pose_bone.parent is not None and _dynamic_carrier(pose_bone) is None:
            _rel_saved_parent(pose_bone)
            if not _unparent_apply_relation(
                context,
                armature,
                bone_name,
                True,
            ):
                return None
        _dynamic_carrier_ensure(context,armature,pose_bone)
        _sync_dynamic_parent_constraints(int(frame), armature)
        # The current Action or a preceding simulated body may still have
        # pending pose writes even when the relationship itself is unchanged.
        # Flush those before sampling a new body's initial state.
        context.view_layer.update()
        return armature.pose.bones.get(bone_name)

    desired_factor = _pose_space_factor(
        context,
        armature,
        pose_bone,
    )
    parent_name = _rel_saved_parent(pose_bone)
    if pose_bone.parent is not None and not _unparent_apply_relation(
        context,
        armature,
        bone_name,
        True,
    ):
        return None

    context.view_layer.update()
    pose_bone = armature.pose.bones.get(bone_name)
    if pose_bone is None:
        return None
    role = SPACE_ROLE_NORMAL if parent_name else SPACE_ROLE_WORLD
    _dynamic_carrier_ensure(context,armature,pose_bone)
    _create_pose_space_constraint(
        context,
        armature,
        pose_bone,
        role,
        SPACE_MIN_FRAME,
        desired_factor = desired_factor,
        source = SPACE_SOURCE_BASE,
    )
    _sync_dynamic_parent_constraints(int(frame), armature)
    context.view_layer.update()
    return armature.pose.bones.get(bone_name)


def _switch_pose_underlying_space(
    context,
    armature,
    pose_bone,
    role,
    frame,
    desired_factor,
    source,
    explicit_end=False,
):
    pose_bone = _ensure_pose_space_system(
        context,
        armature,
        pose_bone,
        frame,
    )
    if pose_bone is None:
        return None

    current = _active_internal_space_constraint(pose_bone, int(frame))
    if current is not None:
        start_frame, _end_frame = _dynamic_parent_constraint_segment(
            pose_bone,
            current,
        )
        if start_frame is not None and int(start_frame) == int(frame):
            _remove_space_constraint(pose_bone, current)
        else:
            _store_dynamic_parent_constraint_segment(
                pose_bone,
                current,
                int(start_frame) if start_frame is not None else SPACE_MIN_FRAME,

                int(frame),
            )

    constraint = _create_pose_space_constraint(
        context,
        armature,
        pose_bone,
        role,
        int(frame),
        desired_factor = desired_factor,
        source = source,
    )
    if explicit_end:
        if "_staticaliza_explicit_end_spaces" not in pose_bone:
            pose_bone["_staticaliza_explicit_end_spaces"] = {}
        pose_bone["_staticaliza_explicit_end_spaces"][_special_end_space_key(constraint)] = True
    _sync_dynamic_parent_constraints(int(frame), armature)
    context.view_layer.update()
    return constraint


def _remove_future_space_constraints(owner, source, after_frame):
    removed = False
    for constraint in list(_internal_space_constraints(owner)):
        if _dynamic_space_source(owner, constraint) != source:
            continue
        start_frame, _end_frame = _dynamic_parent_constraint_segment(
            owner,
            constraint,
        )
        if start_frame is None or int(start_frame) <= int(after_frame):
            continue
        removed = _remove_space_constraint(owner, constraint) or removed
    return removed


def _space_constraints_with_source(owner, source):
    return tuple(
        constraint
        for constraint in _internal_space_constraints(owner)
        if _dynamic_space_source(owner, constraint) == source
    )


def _remove_pose_space_source(owner, source):
    matching = _space_constraints_with_source(owner, source)
    if not matching:
        return False

    matching_pointers = {int(constraint.as_pointer()) for constraint in matching}
    remaining = [
        constraint
        for constraint in _internal_space_constraints(owner)
        if int(constraint.as_pointer()) not in matching_pointers
    ]
    matching_starts = [
        start
        for constraint in matching
        for start, _end in (
            _stored_dynamic_parent_constraint_segment(owner, constraint),
        )
        if start is not None
    ]
    boundary = min(matching_starts) if matching_starts else SPACE_MIN_FRAME

    fallback = next(
        (
            constraint
            for constraint in reversed(remaining)
            if _dynamic_parent_constraint_active_at(owner, constraint, boundary)
        ),
        None,
    )
    previous = next(
        (
            constraint
            for constraint in reversed(remaining)
            if _dynamic_parent_constraint_active_at(
                owner,
                constraint,
                boundary - 1,
            )
        ),
        None,
    )
    next_starts = [
        start
        for constraint in remaining
        for start, _end in (
            _stored_dynamic_parent_constraint_segment(owner, constraint),
        )
        if start is not None and int(start) > int(boundary)
    ]

    removed = False
    for constraint in matching:
        removed = _remove_space_constraint(owner, constraint) or removed

    if fallback is None and previous is not None:
        previous_start, _previous_end = (
            _stored_dynamic_parent_constraint_segment(owner, previous)
        )
        _store_dynamic_parent_constraint_segment(
            owner,
            previous,
            int(previous_start) if previous_start is not None else SPACE_MIN_FRAME,
            min(next_starts) if next_starts else None,
        )
    return removed


def _teardown_pose_space_system(context, armature, pose_bone):
    if pose_bone is None or not _pose_space_managed(pose_bone):
        return False

    bone_name = pose_bone.name
    previous_autokey = _autokey_push(context)
    try:
        if _dynamic_carrier(pose_bone) is None and pose_bone.parent is None and str(
            pose_bone.bone.get(REL_K_PARENT, "")
        ):
            if not _unparent_apply_relation(
                context,
                armature,
                bone_name,
                False,
            ):
                return False

        context.view_layer.update()
        pose_bone = armature.pose.bones.get(bone_name)
        if pose_bone is None:
            return False
        for constraint in list(_internal_space_constraints(pose_bone)):
            _remove_space_constraint(pose_bone, constraint)
        _dynamic_carrier_remove(context,armature,pose_bone)
        _unparent_remove_visual_constraint(pose_bone)
        context.view_layer.update()
        pose_bone = armature.pose.bones.get(bone_name)
        if pose_bone is None:
            return False
        # Clearing the last dynamic marker restores the native relation and
        # its keyed/local pose. Reapplying the helper-space output here baked
        # a phantom offset even when the bone had no transform keys.
        context.view_layer.update()
        if UNP_PROP in pose_bone:
            del pose_bone[UNP_PROP]
        _unparent_clear_start_frame(pose_bone)
        _unparent_rel_set_cached(armature.name, bone_name, False)
        context.view_layer.update()
        return True
    finally:
        _autokey_pop(context, previous_autokey)
