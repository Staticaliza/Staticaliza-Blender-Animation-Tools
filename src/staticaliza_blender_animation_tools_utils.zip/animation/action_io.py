"""Blender action/F-curve compatibility and keyframe insertion helpers."""

from ..core.runtime import *  # noqa: F403

def get_rotation_mode(obj):
    if obj.rotation_mode in ("QUATERNION", "AXIS_ANGLE"):
        return obj.rotation_mode.lower()
    return "euler"

def _action_channelbags(action, animated_id = None):
    if action is None or hasattr(action, "fcurves"):
        return ()

    target_handle = None
    animation_data = getattr(animated_id, "animation_data", None)
    if animation_data is not None and animation_data.action is action:
        target_handle = int(getattr(animation_data, "action_slot_handle", 0) or 0)

    channelbags = []
    for layer in getattr(action, "layers", ()):
        for strip in getattr(layer, "strips", ()):
            if getattr(strip, "type", "") != "KEYFRAME":
                continue
            for channelbag in getattr(strip, "channelbags", ()):
                if (
                    target_handle
                    and int(getattr(channelbag, "slot_handle", 0)) != target_handle
                ):
                    continue
                channelbags.append(channelbag)

    if target_handle and not channelbags:
        return _action_channelbags(action)
    return tuple(channelbags)


def _action_fcurves(action, animated_id = None):
    if action is None:
        return ()
    legacy_fcurves = getattr(action, "fcurves", None)
    if legacy_fcurves is not None:
        return tuple(legacy_fcurves)
    return tuple(
        fcurve
        for channelbag in _action_channelbags(action, animated_id)
        for fcurve in channelbag.fcurves
    )


def _action_remove_fcurve(action, fcurve):
    if action is None or fcurve is None:
        return False
    legacy_fcurves = getattr(action, "fcurves", None)
    if legacy_fcurves is not None:
        try:
            legacy_fcurves.remove(fcurve)
            return True
        except (RuntimeError, ValueError):
            return False

    for channelbag in _action_channelbags(action):
        channel_curves = tuple(channelbag.fcurves)
        try:
            target_pointer = int(fcurve.as_pointer())
        except (AttributeError, ReferenceError):
            target_pointer = 0
        candidate = next(
            (
                curve
                for curve in channel_curves
                if curve is fcurve
                or (
                    target_pointer
                    and int(curve.as_pointer()) == target_pointer
                )
            ),
            None,
        )
        if candidate is None:
            continue
        channelbag.fcurves.remove(candidate)
        return True
    return False


def _action_group_owners(action, animated_id = None):
    if action is None:
        return ()
    legacy_groups = getattr(action, "groups", None)
    if legacy_groups is not None:
        return (legacy_groups,)
    return tuple(
        channelbag.groups
        for channelbag in _action_channelbags(action, animated_id)
    )


def _action_ensure_channelbag(action, animated_id):
    if action is None or animated_id is None or hasattr(action, "fcurves"):
        return None

    animation_data = getattr(animated_id, "animation_data", None)
    if animation_data is None:
        animation_data = animated_id.animation_data_create()

    slot = None
    if animation_data.action is action:
        slot = getattr(animation_data, "action_slot", None)
    if slot is None:
        suitable_slots = tuple(getattr(animation_data, "action_suitable_slots", ()))
        slot = suitable_slots[0] if suitable_slots else None
    if slot is None:
        slot = action.slots.new(animated_id.id_type, animated_id.name)
    if animation_data.action is action and animation_data.action_slot is not slot:
        animation_data.action_slot = slot

    for layer in action.layers:
        for strip in layer.strips:
            if getattr(strip, "type", "") != "KEYFRAME":
                continue
            channelbag = strip.channelbag(slot)
            if channelbag is not None:
                return channelbag

    layer = action.layers[0] if action.layers else action.layers.new("Layer")
    strip = next(
        (
            candidate
            for candidate in layer.strips
            if getattr(candidate, "type", "") == "KEYFRAME"
        ),
        None,
    )
    if strip is None:
        strip = layer.strips.new(type = "KEYFRAME")
    return strip.channelbag(slot, ensure = True)

def _action_new_fcurve(
    action,
    data_path,
    animated_id=None,
    index=0,
    group_name="",
):
    legacy_fcurves = getattr(action, "fcurves", None)
    if legacy_fcurves is not None:
        return legacy_fcurves.new(
            data_path,
            index=int(index),
            action_group=str(group_name or ""),
        )

    channelbag = _action_ensure_channelbag(action, animated_id)
    if channelbag is None:
        raise RuntimeError("Unable to create an animation channel for this Action.")
    group_name = str(group_name or "")
    if group_name and channelbag.groups.get(group_name) is None:
        channelbag.groups.new(group_name)
    return channelbag.fcurves.new(
        data_path=data_path,
        index=int(index),
        group_name=group_name,
    )


KEYFRAME_HANDLE_MODE_PROPERTY = "staticaliza_keyframe_handle_mode"
KEYFRAME_HANDLE_MODE_ITEMS = (
    (
        "DEFAULT",
        "Default",
        "Spawn native transform keys with Auto Clamped handles",
        0,
        0,
    ),
    (
        "DYNAMIC",
        "Dynamic",
        "Spawn native transform keys with Auto handles",
        0,
        1,
    ),
)


def _animation_ids_in_scene(context):
    scene = getattr(context, "scene", None)
    candidates = [scene]
    for obj in getattr(scene, "objects", ()) if scene is not None else ():
        candidates.append(obj)
        candidates.append(getattr(obj, "data", None))

    seen = set()
    for animated_id in candidates:
        if animated_id is None:
            continue
        try:
            pointer = int(animated_id.as_pointer())
        except (AttributeError, ReferenceError, TypeError, ValueError):
            continue
        if pointer in seen:
            continue
        seen.add(pointer)
        yield animated_id


def _selected_keyframe_points(context):
    """Return selected keys from Actions used by IDs in the current scene."""
    selected = []
    seen = set()
    for animated_id in _animation_ids_in_scene(context):
        action = getattr(
            getattr(animated_id, "animation_data", None), "action", None
        )
        if action is None:
            continue
        for fcurve in _action_fcurves(action, animated_id):
            for key in fcurve.keyframe_points:
                try:
                    is_selected = bool(
                        key.select_control_point
                        or key.select_left_handle
                        or key.select_right_handle
                    )
                    pointer = int(key.as_pointer())
                except (AttributeError, ReferenceError, TypeError, ValueError):
                    continue
                if not is_selected or pointer in seen:
                    continue
                seen.add(pointer)
                selected.append((fcurve, key))
    return tuple(selected)


def _selected_keyframe_handle_mode(context):
    entries = _selected_keyframe_points(context)
    if not entries:
        return ""
    modes = {
        (
            str(key.handle_left_type),
            str(key.handle_right_type),
        )
        for _fcurve, key in entries
    }
    if modes == {("AUTO_CLAMPED", "AUTO_CLAMPED")}:
        return "DEFAULT"
    if modes == {("AUTO", "AUTO")}:
        return "DYNAMIC"
    return ""


def _redraw_keyframe_editors():
    window_manager = getattr(bpy.context, "window_manager", None)
    for window in getattr(window_manager, "windows", ()):
        screen = getattr(window, "screen", None)
        for area in getattr(screen, "areas", ()):
            if getattr(area, "type", "") in {
                "DOPESHEET_EDITOR",
                "GRAPH_EDITOR",
                "NLA_EDITOR",
                "VIEW_3D",
            }:
                area.tag_redraw()


class ANIMATOR_UTILS_OT_set_selected_keyframe_type(bpy.types.Operator):
    bl_idname = "staticaliza.set_selected_keyframe_type"
    bl_label = "Set Selected Keyframe Type"
    bl_description = "Change the handle type of every selected keyframe"
    bl_options = {"REGISTER", "UNDO"}

    mode: bpy.props.EnumProperty(
        name = "Type",
        items = KEYFRAME_HANDLE_MODE_ITEMS,
        default = "DEFAULT",
    )

    @classmethod
    def poll(cls, context):
        return bool(_selected_keyframe_points(context))

    def execute(self, context):
        handle_type = "AUTO" if self.mode == "DYNAMIC" else "AUTO_CLAMPED"
        entries = _selected_keyframe_points(context)
        if not entries:
            self.report({"WARNING"}, "Select one or more keyframes.")
            return {"CANCELLED"}

        changed_curves = set()
        changed_keys = 0
        for fcurve, key in entries:
            if (
                str(key.handle_left_type) == handle_type
                and str(key.handle_right_type) == handle_type
            ):
                continue
            key.handle_left_type = handle_type
            key.handle_right_type = handle_type
            changed_curves.add(fcurve)
            changed_keys += 1
        for fcurve in changed_curves:
            fcurve.update()
        _redraw_keyframe_editors()
        self.report(
            {"INFO"},
            f"Changed {changed_keys} selected keyframe"
            f"{'s' if changed_keys != 1 else ''} to "
            f"{'Dynamic' if self.mode == 'DYNAMIC' else 'Default'}.",
        )
        return {"FINISHED"}


def _keyframe_handle_preference():
    try:
        return str(bpy.context.preferences.edit.keyframe_new_handle_type)
    except (AttributeError, ReferenceError, RuntimeError):
        return "AUTO_CLAMPED"


def _set_native_keyframe_handles_clamped():
    try:
        bpy.context.preferences.edit.keyframe_new_handle_type = "AUTO_CLAMPED"
        return True
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return False


def _activate_pose_autokey_channel_policy(context=None):
    """Allow Auto Key to create missing pose transform channels reliably."""
    preferences = getattr(
        getattr(getattr(bpy, "context", None), "preferences", None),
        "edit",
        None,
    )
    if preferences is not None and hasattr(
        preferences, "use_keyframe_insert_available"
    ):
        _state.setdefault(
            "keyframe_insert_available_before",
            bool(preferences.use_keyframe_insert_available),
        )
        preferences.use_keyframe_insert_available = False

    context = context or getattr(bpy, "context", None)
    tool_settings = getattr(
        getattr(context, "scene", None), "tool_settings", None
    )
    if tool_settings is not None and hasattr(
        tool_settings, "use_keyframe_insert_keyingset"
    ):
        scene_pointer = int(context.scene.as_pointer())
        saved = _state.setdefault("autokey_keyingset_before", {})
        saved.setdefault(
            scene_pointer,
            bool(tool_settings.use_keyframe_insert_keyingset),
        )
        tool_settings.use_keyframe_insert_keyingset = False


def _restore_pose_autokey_channel_policy():
    preferences = getattr(
        getattr(getattr(bpy, "context", None), "preferences", None),
        "edit",
        None,
    )
    previous_available = _state.pop(
        "keyframe_insert_available_before", None
    )
    if preferences is not None and previous_available is not None:
        try:
            preferences.use_keyframe_insert_available = bool(
                previous_available
            )
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            pass

    saved = _state.pop("autokey_keyingset_before", {})
    for scene in tuple(getattr(bpy.data, "scenes", ())):
        try:
            pointer = int(scene.as_pointer())
            if pointer in saved:
                scene.tool_settings.use_keyframe_insert_keyingset = bool(
                    saved[pointer]
                )
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            continue


def _activate_keyframe_handle_policy():
    _state.setdefault(
        "keyframe_handle_preference_before",
        _keyframe_handle_preference(),
    )
    _set_native_keyframe_handles_clamped()
    _activate_pose_autokey_channel_policy()
    _apply_keyframe_handle_mode_to_new_pose_keys(seed=True)


def _restore_keyframe_handle_preference():
    previous = _state.pop("keyframe_handle_preference_before", None)
    if previous in {"AUTO", "AUTO_CLAMPED", "VECTOR", "ALIGNED", "FREE"}:
        try:
            bpy.context.preferences.edit.keyframe_new_handle_type = previous
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            pass
    _restore_pose_autokey_channel_policy()


def _on_keyframe_handle_mode_change(_window_manager, _context):
    # Keep Blender's global default clamped. Dynamic mode is deliberately
    # scoped to newly authored transforms on selected Pose bones, so Impact
    # and unrelated animated properties never inherit AUTO handles.
    _set_native_keyframe_handles_clamped()
    _apply_keyframe_handle_mode_to_new_pose_keys(seed=True)


def _selected_pose_transform_curves(context):
    if context is None or str(getattr(context, "mode", "")) != "POSE":
        return (), ()
    try:
        armatures = tuple(context.objects_in_mode or ())
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        armatures = ()
    entries = []
    signature = []
    transform_suffixes = (
        ".location",
        ".scale",
        ".rotation_euler",
        ".rotation_quaternion",
        ".rotation_axis_angle",
    )
    for armature in armatures:
        if getattr(armature, "type", "") != "ARMATURE":
            continue
        selected_paths = set()
        for pose_bone in getattr(getattr(armature, "pose", None), "bones", ()):
            try:
                bone = pose_bone.bone
                selected = bool(
                    getattr(pose_bone, "select", False)
                    or getattr(bone, "select", False)
                    or getattr(bone, "select_head", False)
                    or getattr(bone, "select_tail", False)
                )
            except (AttributeError, ReferenceError):
                selected = False
            if not selected:
                continue
            try:
                selected_paths.add(str(pose_bone.path_from_id()))
                signature.append(
                    (int(armature.as_pointer()), int(pose_bone.as_pointer()))
                )
            except (AttributeError, ReferenceError, TypeError, ValueError):
                continue
        if not selected_paths:
            continue
        action = getattr(
            getattr(armature, "animation_data", None), "action", None
        )
        if action is None:
            continue
        for fcurve in _action_fcurves(action, armature):
            data_path = str(getattr(fcurve, "data_path", ""))
            if not data_path.endswith(transform_suffixes):
                continue
            if any(
                data_path.startswith(path + ".")
                for path in selected_paths
            ):
                entries.append(fcurve)
    return tuple(entries), tuple(sorted(signature))


def _apply_keyframe_handle_mode_to_new_pose_keys(seed=False):
    context = getattr(bpy, "context", None)
    curves, selection_signature = _selected_pose_transform_curves(context)
    previous_signature = _state.get("keyframe_handle_selection_signature")
    seen = _state.setdefault("keyframe_handle_seen_pose_keys", set())
    if seed or selection_signature != previous_signature:
        _state["keyframe_handle_selection_signature"] = selection_signature
        _state["keyframe_handle_seen_pose_keys"] = {
            int(key.as_pointer())
            for fcurve in curves
            for key in fcurve.keyframe_points
        }
        return 0
    if not curves:
        return 0
    frame = float(getattr(getattr(context, "scene", None), "frame_current", 0.0))
    new_keys = []
    for fcurve in curves:
        for key in fcurve.keyframe_points:
            if abs(float(key.co.x) - frame) > 1.0e-5:
                continue
            pointer = int(key.as_pointer())
            if pointer in seen:
                continue
            seen.add(pointer)
            new_keys.append((fcurve, key))
    mode = str(
        getattr(
            getattr(context, "window_manager", None),
            KEYFRAME_HANDLE_MODE_PROPERTY,
            "DEFAULT",
        )
    )
    if mode != "DYNAMIC":
        return 0
    changed = 0
    changed_curves = set()
    for fcurve, key in new_keys:
        if str(key.handle_left_type) != "AUTO":
            key.handle_left_type = "AUTO"
            changed += 1
            changed_curves.add(fcurve)
        if str(key.handle_right_type) != "AUTO":
            key.handle_right_type = "AUTO"
            changed += 1
            changed_curves.add(fcurve)
    for fcurve in changed_curves:
        fcurve.update()
    return changed


def _set_fcurve_key_interpolation(target, data_path, frame, interpolation):
    id_data = getattr(target, "id_data", None) or target
    animation_data = getattr(id_data, "animation_data", None)
    action = getattr(animation_data, "action", None)
    if action is None:
        return 0

    changed = 0
    target_frame = float(frame)
    for fcurve in _action_fcurves(action, id_data):
        if fcurve.data_path != data_path:
            continue
        for key in fcurve.keyframe_points:
            if abs(float(key.co.x) - target_frame) > 1.0e-5:
                continue
            key.interpolation = interpolation
            changed += 1
        fcurve.update()
    return changed


def insert_keyframe(obj, frame):
    rotation_mode = get_rotation_mode(obj)
    data_paths = (
        "location",
        f"rotation_{rotation_mode}",
        "scale",
    )
    for data_path in data_paths:
        obj.keyframe_insert(data_path = data_path, frame = frame)


def insert_keyframe_constraint(constraint, frame, owner = None):
    if owner is None:
        return
    marker_property = _dynamic_parent_marker_property_name(constraint)
    marker_path = _dynamic_parent_marker_data_path(constraint)
    owner[marker_property] = float(constraint.influence)
    animated_id = getattr(owner, "id_data", None) or owner
    animated_id.keyframe_insert(
        data_path=marker_path,
        frame=frame,
        group=f"Dynamic Parent ({owner.name})",
    )
    _set_fcurve_key_interpolation(
        owner,
        marker_path,
        frame,
        "CONSTANT",
    )
    action = _dynamic_parent_owner_action(owner)
    animated_id = getattr(owner, "id_data", None) or owner
    for fcurve in _fcurves_find_all(action, marker_path, animated_id):
        for key in fcurve.keyframe_points:
            if abs(float(key.co.x) - float(frame)) <= 1.0e-5:
                key.type = (
                    "GENERATED"
                    if float(constraint.influence) < 0.5
                    else "KEYFRAME"
                )
        fcurve.update()
    if owner is not None:
        _set_dynamic_parent_fcurve_group(owner, constraint)

def dp_keyframe_insert_obj(obj):
    obj.keyframe_insert(data_path = "location")
    if obj.rotation_mode == "QUATERNION":
        obj.keyframe_insert(data_path = "rotation_quaternion")
    elif obj.rotation_mode == "AXIS_ANGLE":
        obj.keyframe_insert(data_path = "rotation_axis_angle")
    else:
        obj.keyframe_insert(data_path = "rotation_euler")
    obj.keyframe_insert(data_path = "scale")

def dp_keyframe_insert_pbone(arm, pbone):
    arm.keyframe_insert(data_path = 'pose.bones["' + pbone.name + '"].location')
    if pbone.rotation_mode == "QUATERNION":
        arm.keyframe_insert(
            data_path = 'pose.bones["' + pbone.name + '"].rotation_quaternion'
        )
    elif pbone.rotation_mode == "AXIS_ANGLE":
        arm.keyframe_insert(
            data_path = 'pose.bones["' + pbone.name + '"].rotation_axis_angle'
        )
    else:
        arm.keyframe_insert(data_path = 'pose.bones["' + pbone.name + '"].rotation_euler')
    arm.keyframe_insert(data_path = 'pose.bones["' + pbone.name + '"].scale')
