"""Scene frame-rate changes that preserve authored animation time."""
from ..core.runtime import *  # noqa: F403


ANIMATION_FPS_PROPERTY = "staticaliza_animation_fps"


def _animation_fps_scene_key(scene):
    return (scene.name_full, int(getattr(scene, "session_uid", scene.as_pointer())))


def _get_animation_fps(scene):
    pending = _state.get("animation_fps_pending")
    if pending and pending["scene"] == _animation_fps_scene_key(scene):
        return int(pending["fps"])
    return int(scene.render.fps)


def _commit_animation_fps(scene, value):
    try:
        return _retime_scene_fps(scene, int(value))
    except (ValueError, RuntimeError) as exc:
        _state["last_error"] = str(exc)
        return False
    finally:
        _tag_redraw_all_view3d()


def _finish_animation_fps_edit():
    pending = _state.get("animation_fps_pending")
    if not pending:
        return None
    if _pin_primary_mouse_pressed():
        return 0.02
    _state.pop("animation_fps_pending", None)
    scene = bpy.data.scenes.get(pending["scene"][0])
    if (scene is None or _animation_fps_scene_key(scene) != pending["scene"]
            or _animation_playback_active(bpy.context)):
        _tag_redraw_all_view3d()
        return None
    if _commit_animation_fps(scene, pending["fps"]) and not bpy.app.background:
        # The numeric gesture is already confirmed. Timer-originated edits
        # need an explicit native undo checkpoint after their single retime.
        bpy.ops.ed.undo_push(message="Animation FPS")
    return None


def _set_animation_fps(scene, value):
    if _animation_playback_active(bpy.context):
        _state["last_error"] = "Stop playback before changing animation FPS."
        return
    if _pin_primary_mouse_pressed():
        # Preview the number during a drag; round discrete events only once
        # at confirmation, so repeated slider ticks cannot shift Start/End.
        _state["animation_fps_pending"] = {
            "scene": _animation_fps_scene_key(scene), "fps": int(value),
        }
        register_owned_timer(_finish_animation_fps_edit, first_interval=0.02)
    else:
        _state.pop("animation_fps_pending", None)
        _commit_animation_fps(scene, value)


def _retime_scene_ids(scene):
    pending = [scene, scene.world, *scene.objects]
    seen = set()
    while pending:
        owner = pending.pop()
        if owner is None or not isinstance(owner, bpy.types.ID) or owner in seen:
            continue
        seen.add(owner)
        for name in ("data", "shape_keys", "node_tree"):
            pending.append(getattr(owner, name, None))
        pending.extend(getattr(owner, "materials", ()))
    return seen


def _retime_nla_strips(strips):
    for strip in strips:
        yield strip
        yield from _retime_nla_strips(getattr(strip, "strips", ()))


def _retime_curve_owner_path(path):
    if path.startswith("pose.bones["):
        _name, length = json.JSONDecoder().raw_decode(path[len("pose.bones["):])
        return path[:len("pose.bones[")+length+1]
    return ""


def _retime_metadata_owner_path(owner):
    return "" if isinstance(owner, bpy.types.ID) else owner.path_from_id()


def _retime_discrete_boundaries(action, ids):
    result = {}
    for curve in _action_fcurves(action):
        if _special_event_encoded(curve):
            result.setdefault(_retime_curve_owner_path(curve.data_path), set()).update(float(p.co.x) for p in curve.keyframe_points)
    for owner in ids:
        if getattr(getattr(owner, "animation_data", None), "action", None) != action:
            continue
        items = (owner, *owner.pose.bones) if isinstance(owner, bpy.types.Object) and owner.type == "ARMATURE" and owner.pose else (owner,)
        for item in items:
            frames = list(item.get(SURFACE_CONTACT_TARGET_FRAMES_PROPERTY, ()))
            try:
                frames.extend(json.loads(item.get(_RAGDOLL_AUTHORED_FRAMES_PROPERTY, "[]")))
            except (TypeError, ValueError):
                pass
            if frames:
                result.setdefault(_retime_metadata_owner_path(item), set()).update(float(frame) for frame in frames)
    return result


def _retime_special_metadata(owner, scale, origin, boundaries=()):
    """Return edits to known timing fields; matrices and channel values stay intact."""
    transform = lambda value: origin + (float(value) - origin) * scale
    point_time = lambda value: round(transform(value)) if float(value) in boundaries else transform(value)
    result = {}
    for name in owner.keys():
        value = owner[name]
        if name.startswith(DP_SEGMENT_PROPERTY_PREFIX):
            result[name] = [round(transform(v)) if float(v) != SPACE_MIN_FRAME and (i == 0 or float(v) >= 0) else v for i, v in enumerate(value)]
        elif name.startswith(DP_BOUNDARY_CALIBRATED_PROPERTY_PREFIX):
            result[name] = round(transform(value))
        elif name.startswith(SPACE_SOURCE_PROPERTY_PREFIX) and isinstance(value, str) and value.startswith(SPACE_SOURCE_UNPARENT_PREFIX):
            result[name] = SPACE_SOURCE_UNPARENT_PREFIX + str(round(transform(value.split(":", 1)[1])))
        elif name in (SURFACE_CONTACT_START_PROPERTY, SURFACE_CONTACT_END_PROPERTY, DP_AUTO_UNPARENT_START_KEY) and isinstance(value, (int, float)):
            result[name] = round(transform(value)) if float(value) >= 0 else value
        elif name == SURFACE_CONTACT_TARGET_FRAMES_PROPERTY:
            result[name] = [round(transform(v)) for v in value]
        elif name in (_RAGDOLL_AUTHORED_FRAMES_PROPERTY, _RAGDOLL_BASELINE_KEYS_PROPERTY,
                      _RAGDOLL_START_POSES_PROPERTY, _SPECIAL_END_INPUTS, CONSTRAINT_END_KEYS_PROPERTY):
            try:
                records = json.loads(str(value))
            except (TypeError, ValueError):
                continue
            if name == _RAGDOLL_AUTHORED_FRAMES_PROPERTY:
                records = [point_time(v) for v in records]
            elif name == _RAGDOLL_BASELINE_KEYS_PROPERTY:
                for row in records:
                    row[2] = point_time(row[2])
            elif name == _RAGDOLL_START_POSES_PROPERTY:
                moved = {}
                for frame, pose in records.items():
                    key = str(round(transform(frame)))
                    if key in moved:
                        raise ValueError("This FPS merges two Ragdoll Start poses. Choose a higher FPS.")
                    moved[key] = pose
                records = moved
            elif name == _SPECIAL_END_INPUTS:
                for row in records:
                    row["frame"] = round(transform(row["frame"]))
                    for points in row.get("curves", {}).values():
                        for point in points:
                            old_frame = point[0]
                            new_frame = point_time(old_frame)
                            offset = new_frame-transform(old_frame)
                            point[0] = new_frame
                            for index in (5, 7):
                                point[index] = transform(point[index]) + offset
            else:
                for row in records:
                    row[2] = point_time(row[2])
            result[name] = json.dumps(records, separators=(",", ":"))
    return result


def _retime_scene_fps(scene, new_fps):
    """Plan once, retime all scene animation, then invalidate derived simulation."""
    new_fps = int(new_fps)
    if not 1 <= new_fps <= 32767:
        raise ValueError("FPS must be between 1 and 32767.")
    old_rate = float(scene.render.fps) / max(1.e-8, float(scene.render.fps_base))
    scale = new_fps / old_rate
    if abs(scale - 1.0) < 1.e-10 and scene.render.fps_base == 1.0:
        return False
    origin = float(scene.frame_start)
    transform = lambda value: origin + (float(value) - origin) * scale
    ids = _retime_scene_ids(scene)
    # Shared Actions may be local to distinct objects; isolate this scene's copy.
    actions = set()
    slots = []
    nla = []
    for owner in ids:
        animation = getattr(owner, "animation_data", None)
        if animation is None:
            continue
        if animation.action is not None:
            actions.add(animation.action)
            slots.append((animation, animation.action, getattr(animation, "action_slot", None)))
        for track in animation.nla_tracks:
            for strip in _retime_nla_strips(track.strips):
                nla.append(strip)
                if strip.action is not None:
                    actions.add(strip.action)
                    slots.append((strip, strip.action, getattr(strip, "action_slot", None)))
    for action in actions:
        if not action.is_editable:
            raise ValueError("Make linked animation local before changing FPS.")
    # Do not alter a shared animated ID in another scene behind its own clock.
    for other in bpy.data.scenes:
        if other == scene or other.get("_staticaliza_physics_scratch", False):
            continue
        if any(getattr(o, "animation_data", None) is not None for o in ids.intersection(_retime_scene_ids(other)) if o != scene):
            raise ValueError("This scene shares animated data with another scene. Make that data single-user before changing FPS.")
    user_map = bpy.data.user_map(subset=actions) if actions else {}
    boundaries = {action: _retime_discrete_boundaries(action, ids) for action in actions}
    impact = bpy.app.driver_namespace.get("staticaliza_prepare_impact_retime")
    impact_plan = impact(scene, scale, origin) if callable(impact) else None
    impact_paths = impact_plan["marker_paths"] if impact_plan else set()
    copies = {}
    targets = {}
    bulk = []
    attributes = []
    properties = []
    changed_curves = []
    def attr(owner, name, value):
        attributes.append((owner, name, getattr(owner, name), value))
    try:
        for action in actions:
            if any(user not in ids for user in user_map.get(action, ())):
                copies[action] = action.copy()
            targets[action] = copies.get(action, action)
        for original, action in targets.items():
            for curve in _action_fcurves(action):
                bound = boundaries[original].get(_retime_curve_owner_path(curve.data_path), set())
                if _special_event_encoded(curve):
                    moved = [round(transform(p.co.x)) for p in curve.keyframe_points]
                    if len(set(moved)) != len(moved):
                        raise ValueError("This FPS merges two special key events. Choose a higher FPS.")
                changed_curves.append(curve)
                for collection, fields in ((curve.keyframe_points, ("co", "handle_left", "handle_right")), (curve.sampled_points, ("co",))):
                    for field in fields:
                        if not collection:
                            continue
                        old = [0.0] * (len(collection) * 2)
                        collection.foreach_get(field, old)
                        new = list(old)
                        if field == "co":
                            new[::2] = [round(transform(x)) if curve.data_path in impact_paths or float(x) in bound else transform(x) for x in old[::2]]
                        else:
                            # Move the handles with a snapped event/pose boundary.
                            co = [0.0] * len(old)
                            collection.foreach_get("co", co)
                            new[::2] = [transform(x) + (round(transform(at))-transform(at) if curve.data_path in impact_paths or float(at) in bound else 0.0) for x, at in zip(old[::2], co[::2])]
                        bulk.append((collection, field, old, new))
                for modifier in curve.modifiers:
                    for name in ("frame_start", "frame_end"):
                        attr(modifier, name, transform(getattr(modifier, name)))
                    for name in ("blend_in", "blend_out"):
                        attr(modifier, name, float(getattr(modifier, name)) * scale)
                    if modifier.type == "NOISE":
                        attr(modifier, "scale", modifier.scale * scale)
                        attr(modifier, "offset", transform(modifier.offset))
                    elif modifier.type == "ENVELOPE":
                        for point in modifier.control_points:
                            attr(point, "frame", transform(point.frame))
                    elif modifier.type == "STEPPED":
                        attr(modifier, "frame_step", modifier.frame_step * scale)
                        attr(modifier, "frame_offset", transform(modifier.frame_offset))
                    elif modifier.type == "LIMITS":
                        for name in ("min_x", "max_x"):
                            attr(modifier, name, transform(getattr(modifier, name)))
                    elif modifier.type == "GENERATOR":
                        old = list(modifier.coefficients)
                        if modifier.mode == "POLYNOMIAL":
                            offset = origin * (1.0 - 1.0 / scale)
                            new = [sum(old[j] * math.comb(j, k) * offset ** (j-k) / scale ** k for j in range(k, len(old))) for k in range(len(old))]
                        else:
                            new = list(old)
                            for i in range(0, len(old), 2):
                                new[i] = old[i] / scale
                                new[i+1] = old[i+1] + old[i] * origin * (1.0 - 1.0 / scale)
                        attributes.append((modifier, "coefficients", old, new))
                    elif modifier.type == "FNGENERATOR":
                        attr(modifier, "phase_offset", modifier.phase_offset + modifier.phase_multiplier * origin * (1.0 - 1.0 / scale))
                        attr(modifier, "phase_multiplier", modifier.phase_multiplier / scale)
        for owner in ids:
            owners = (owner, *owner.pose.bones) if isinstance(owner, bpy.types.Object) and owner.type == "ARMATURE" and owner.pose else (owner,)
            for item in owners:
                for name, value in _retime_special_metadata(item, scale, origin, boundaries.get(getattr(getattr(owner, "animation_data", None), "action", None), {}).get(_retime_metadata_owner_path(item), set())).items():
                    old = item[name]
                    old = old.to_list() if hasattr(old, "to_list") else old
                    properties.append((item, name, old, value))
        for strip in nla:
            for pair in (("frame_start_raw", "frame_end_raw"), ("action_frame_start", "action_frame_end")):
                ordered = tuple(reversed(pair)) if transform(getattr(strip, pair[0])) > getattr(strip, pair[0]) else pair
                for name in ordered:
                    attr(strip, name, transform(getattr(strip, name)))
            for name in ("blend_in", "blend_out"):
                attr(strip, name, getattr(strip, name) * scale)
        for marker in scene.timeline_markers:
            attr(marker, "frame", round(transform(marker.frame)))
        attr(scene, "frame_end", max(scene.frame_start, round(transform(scene.frame_end))))
        attr(scene, "frame_preview_start", round(transform(scene.frame_preview_start)))
        attr(scene, "frame_preview_end", round(transform(scene.frame_preview_end)))
        for name in ("rigidbody_world",):
            world = getattr(scene, name, None)
            cache = getattr(world, "point_cache", None)
            if cache is not None:
                attr(cache, "frame_start", round(transform(cache.frame_start)))
                attr(cache, "frame_end", round(transform(cache.frame_end)))
    except Exception:
        for action in copies.values():
            bpy.data.actions.remove(action)
        raise
    guards = {name: _state.get(name, False) for name in ("ragdoll_syncing", "unparent_handler_mute", "surface_contact_solver_syncing")}
    frame = scene.frame_current_final
    old_fps, old_base = scene.render.fps, scene.render.fps_base
    assigned = []
    completed = False
    _state.update({name: True for name in guards})
    try:
        for container, original, slot in slots:
            if original not in copies:
                continue
            container.action = copies[original]
            if slot is not None:
                match = next((s for s in copies[original].slots if s.identifier == slot.identifier), None)
                if match is not None:
                    container.action_slot = match
            assigned.append((container, original, slot))
        for collection, name, old, new in bulk:
            collection.foreach_set(name, new)
        for owner, name, old, new in attributes:
            setattr(owner, name, new)
        for owner, name, old, new in properties:
            owner[name] = new
        for curve in changed_curves:
            curve.update()
        scene.render.fps = new_fps
        scene.render.fps_base = 1.0
        if impact_plan is not None:
            impact_plan["apply"]()
        completed = True
    finally:
        if not completed:
            for owner, name, old, new in reversed(properties):
                owner[name] = old
            for owner, name, old, new in reversed(attributes):
                setattr(owner, name, old)
            for collection, name, old, new in bulk:
                collection.foreach_set(name, old)
            for curve in changed_curves:
                curve.update()
            for container, original, slot in assigned:
                container.action = original
                if slot is not None:
                    container.action_slot = slot
            for action in copies.values():
                if not action.users:
                    bpy.data.actions.remove(action)
            scene.render.fps, scene.render.fps_base = old_fps, old_base
            if impact_plan is not None:
                impact_plan["rollback"]()
        _state.update(guards)
    _special_end_clear_input_cache()
    _ragdoll_native_cancel_job()
    for key in tuple(_state):
        if key.startswith("ragdoll_") and key not in {"ragdoll_baking", "ragdoll_syncing"}:
            _state.pop(key, None)
    _dynamic_space_invalidate_runtime_cache()
    _surface_contact_clear_derived_caches()
    _state["dynamic_space_marker_signature"] = None
    target = transform(frame)
    scene.frame_set(math.floor(target), subframe=target-math.floor(target))
    _capture_animation_channel_baseline()
    _tag_redraw_all_view3d()
    return True


class ANIMATOR_UTILS_OT_set_animation_fps(bpy.types.Operator):
    bl_idname = "staticaliza.set_animation_fps"
    bl_label = "Animation FPS"
    bl_description = "Change FPS and retime this scene's keys to preserve animation duration"
    bl_options = {"REGISTER", "UNDO"}

    fps: bpy.props.IntProperty(name="FPS", default=24, min=1, max=32767)

    def invoke(self, context, event):
        self.fps = context.scene.render.fps
        return context.window_manager.invoke_props_dialog(self, width=260)

    def draw(self, context):
        self.layout.prop(self, "fps")

    def execute(self, context):
        if _animation_playback_active(context):
            self.report({"WARNING"}, "Stop playback before changing animation FPS.")
            return {"CANCELLED"}
        try:
            _retime_scene_fps(context.scene, self.fps)
        except (ValueError, RuntimeError) as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        return {"FINISHED"}
