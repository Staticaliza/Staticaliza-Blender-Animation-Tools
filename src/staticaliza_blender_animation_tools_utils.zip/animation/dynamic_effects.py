"""Dynamic bone colors, labels, and combined animation-state effects."""

from ..core.runtime import *  # noqa: F403

def _restore_dynamic_pose_bone_color(pose_bone):
    if pose_bone is None or DYNAMIC_COLOR_PALETTE_KEY not in pose_bone:
        return False

    color = getattr(pose_bone, "color", None)
    if color is None:
        return False
    palette = str(pose_bone.get(DYNAMIC_COLOR_PALETTE_KEY, "DEFAULT"))
    custom_values = tuple(pose_bone.get(DYNAMIC_COLOR_CUSTOM_KEY, ()))
    try:
        if len(custom_values) >= 10:
            color.palette = "CUSTOM"
            color.custom.normal = tuple(custom_values[0:3])
            color.custom.select = tuple(custom_values[3:6])
            color.custom.active = tuple(custom_values[6:9])
            color.custom.show_colored_constraints = bool(custom_values[9])
        color.palette = palette
    except (AttributeError, TypeError, ValueError):
        return False
    finally:
        for property_name in (
            DYNAMIC_COLOR_PALETTE_KEY,
            DYNAMIC_COLOR_CUSTOM_KEY,
        ):
            if property_name in pose_bone:
                del pose_bone[property_name]
    return True


def _restore_all_dynamic_pose_bone_colors():
    changed = False
    for obj in tuple(bpy.data.objects):
        if obj.type != "ARMATURE" or getattr(obj, "pose", None) is None:
            continue
        for pose_bone in obj.pose.bones:
            changed = _restore_dynamic_pose_bone_color(pose_bone) or changed
    return changed


def _dynamic_pose_bone_uses_managed_constraints(pose_bone):
    """Return whether Blender's native constraint tint must stay disabled."""

    if any(
        _is_dynamic_state_constraint(constraint)
        for constraint in _dynamic_constraints(pose_bone)
    ):
        return True

    if GYRO_MARKER in pose_bone:
        return True
    armature = getattr(pose_bone, "id_data", None)
    armature_name = str(getattr(armature, "name", ""))
    if not armature_name:
        return False
    bone_properties = (
        SURFACE_CONTACT_BONE_PROPERTY,
        SURFACE_CONTACT_CONTROL_BONE_PROPERTY,
        SURFACE_CONTACT_FOLLOW_BONE_PROPERTY,
        SURFACE_CONTACT_GEOMETRY_BONE_PROPERTY,
        SURFACE_CONTACT_CONSTRAINT_BONE_PROPERTY,
        SURFACE_CONTACT_RELEASE_BONE_PROPERTY,
    )
    return any(
        str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
        == armature_name
        and pose_bone.name
        in {
            str(guide.get(property_name, ""))
            for property_name in bone_properties
        }
        for guide in _surface_contact_guides()
    )


def _capture_dynamic_pose_bone_color(pose_bone):
    color = getattr(pose_bone, "color", None)
    if color is None or DYNAMIC_COLOR_PALETTE_KEY in pose_bone:
        return False
    custom = color.custom
    pose_bone[DYNAMIC_COLOR_PALETTE_KEY] = str(color.palette)
    pose_bone[DYNAMIC_COLOR_CUSTOM_KEY] = [
        *tuple(custom.normal),
        *tuple(custom.select),
        *tuple(custom.active),
        1.0 if custom.show_colored_constraints else 0.0,
    ]
    return True


def _dynamic_pose_bone_native_triplet(pose_bone):
    """Resolve the visible palette into explicit colors without constraint tint."""

    color = getattr(pose_bone, "color", None)
    if color is None:
        return None
    palette = str(pose_bone.get(DYNAMIC_COLOR_PALETTE_KEY, color.palette))
    custom_values = tuple(pose_bone.get(DYNAMIC_COLOR_CUSTOM_KEY, ()))
    if palette == "CUSTOM" and len(custom_values) >= 9:
        return (
            tuple(custom_values[0:3]),
            tuple(custom_values[3:6]),
            tuple(custom_values[6:9]),
        )
    try:
        theme = bpy.context.preferences.themes[0]
        if palette.startswith("THEME"):
            palette_index = int(palette[5:]) - 1
            palette_colors = theme.bone_color_sets[palette_index]
            return (
                tuple(palette_colors.normal),
                tuple(palette_colors.select),
                tuple(palette_colors.active),
            )
        view_colors = theme.view_3d
        return (
            tuple(view_colors.bone_solid),
            tuple(view_colors.bone_pose),
            tuple(view_colors.bone_pose_active),
        )
    except (AttributeError, IndexError, TypeError, ValueError):
        return (
            tuple(color.custom.normal),
            tuple(color.custom.select),
            tuple(color.custom.active),
        )


def _show_dynamic_pose_bone_native_color(pose_bone):
    """Restore the actual palette; never substitute a gray CUSTOM palette."""
    return _restore_dynamic_pose_bone_color(pose_bone)


def _surface_contact_guides_for_pose_bone(pose_bone, frame = None, *, authored=False):
    armature = getattr(pose_bone, "id_data", None)
    armature_name = str(getattr(armature, "name", ""))
    if not armature_name:
        return ()
    guides = tuple(
        guide
        for guide in _surface_contact_guides()
        if (
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
            == armature_name
            and str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
            == pose_bone.name
            and (
                frame is None
                or (_surface_contact_guide_interval_active_at(guide, int(frame))
                    and not _constraint_pin_gyro_blocks_contact(guide, frame)
                    if authored else _surface_contact_guide_active_at(guide, int(frame)))
            )
        )
    )
    return tuple(
        sorted(
            guides,
            key = lambda guide: int(
                guide.get(SURFACE_CONTACT_START_PROPERTY, SPACE_MIN_FRAME)
            ),
        )
    )



def _active_dynamic_parent_constraint(pose_bone, frame, chosen = None):
    if (
        chosen is not None
        and chosen.name.startswith("DP_")
        and _dynamic_parent_constraint_active_at(pose_bone, chosen, frame)
    ):
        return chosen
    candidates = tuple(
        constraint
        for constraint in _dynamic_constraints(pose_bone)
        if (
            constraint.name.startswith("DP_")
            and _dynamic_parent_constraint_active_at(
                pose_bone,
                constraint,
                int(frame),
            )
        )
    )
    return max(
        candidates,
        key = lambda constraint: _constraint_segment_start(
            pose_bone,
            constraint,
        ),
        default = None,
    )


def _dynamic_parent_constraint_visibly_active(
    pose_bone,
    constraint,
    frame,
):
    """Return whether a Dynamic Parent is both scheduled and applied now."""

    if (
        constraint is None
        or not constraint.name.startswith("DP_")
        or not _dynamic_parent_constraint_active_at(
            pose_bone,
            constraint,
            int(frame),
        )
    ):
        return False
    return bool(
        getattr(constraint, "target", None) is not None
        and not bool(getattr(constraint, "mute", False))
        and float(getattr(constraint, "influence", 0.0)) > 0.5
    )


def _surface_contact_target_effects(pose_bone, frame):
    armature = getattr(pose_bone, "id_data", None)
    if armature is None:
        return ()
    effects = []
    for guide in _surface_contact_guides():
        if not _surface_contact_guide_active_at(guide, int(frame)):
            continue
        if (
            str(guide.get(SURFACE_CONTACT_FOLLOW_OBJECT_PROPERTY, ""))
            != armature.name
            or str(guide.get(SURFACE_CONTACT_FOLLOW_BONE_PROPERTY, ""))
            != pose_bone.name
        ):
            continue
        source_name = str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
        if source_name and source_name != pose_bone.name:
            effects.append(
                (
                    "CONTACT_TARGET",
                    "Contacted by "
                    + json.dumps(source_name, ensure_ascii = False),
                    DYNAMIC_CONTACT_COLOR,
                )
            )
    return tuple(effects)


def _constraint_direction_label(axis):
    return next((label for key, label, _ in PIN_AXIS_ITEMS if key == axis), str(axis))


def _contact_bone_label(guide):
    return ("Contact with " + json.dumps(_surface_contact_guide_surface_label(guide), ensure_ascii=False)
            + " · " + _constraint_direction_label(str(guide.get(SURFACE_CONTACT_CAST_AXIS_PROPERTY, "Y_NEG"))))


def _onion_pin_bone_label(pose_bone):
    mode = int(pose_bone.get(YELLOW_PIN_MODE_PROPERTY, 3))
    if mode in (3, 5):
        axis = str(pose_bone.get(YELLOW_PIN_AXIS_PROPERTY, "Y_NEG"))
        return "Onion Pinned · " + _constraint_direction_label(axis)
    return "Onion Pinned"


def _dynamic_pose_bone_effects(pose_bone, frame, chosen = None):
    effects = []
    parent_constraint = _active_dynamic_parent_constraint(
        pose_bone,
        int(frame),
        chosen,
    )
    if not _dynamic_parent_constraint_visibly_active(
        pose_bone,
        parent_constraint,
        int(frame),
    ):
        parent_constraint = None
    if parent_constraint is not None:
        target = _dynamic_parent_constraint_target(
            pose_bone,
            parent_constraint,
        )
        target_name = _dynamic_parent_constraint_subtarget(
            pose_bone,
            parent_constraint,
        )
        if not target_name:
            target_name = str(getattr(target, "name", "")) or "World"
        effects.append(
            (
                "PARENT",
                f"Parented to {json.dumps(target_name, ensure_ascii = False)}",
                DYNAMIC_PARENT_COLOR,
            )

        )

    action = _dynamic_parent_owner_action(pose_bone)
    if (
        _unparent_points(action, pose_bone.name)
        and _unparent_eval(
            action,
            pose_bone.name,
            int(frame),
            pb_default = 0.0,
        ) >= 0.5
    ):
        original_parent = str(
            pose_bone.bone.get(REL_K_PARENT, "")
        ) or str(getattr(getattr(pose_bone, "parent", None), "name", ""))
        effects.append(
            (
                "UNPARENT",
                "Unparented from "
                + json.dumps(
                    original_parent or "original parent",
                    ensure_ascii = False,
                ),
                DYNAMIC_UNPARENT_COLOR,
            )
        )

    if _gyro_bone_active_at(pose_bone.id_data, pose_bone, frame):
        guide = _gyro_find(bpy.context, pose_bone.id_data, pose_bone)
        axis = str(guide.get("gyro_axis", "Z_NEG")) if guide is not None else "Z_NEG"
        effects.append(("GYRO", "Gyro · " + _constraint_direction_label(axis), GYRO_COLOR[:3]))

    active_contacts = _surface_contact_guides_for_pose_bone(
        pose_bone,
        int(frame),
        authored=True,
    )
    if active_contacts:
        effects.append(
            (
                "CONTACT",
                _contact_bone_label(active_contacts[-1]),
                DYNAMIC_CONTACT_COLOR,
            )
        )
    if _ragdoll_active(pose_bone, int(frame)):
        effects.append(
            ("RAGDOLL", _ragdoll_label(pose_bone), DYNAMIC_RAGDOLL_COLOR)
        )
    effects.extend(_surface_contact_target_effects(pose_bone, int(frame)))

    pin_owner = _pose_bone_owner(bpy.context, pose_bone)
    if (
        pin_owner is not None
        and _owner_bone_key(pin_owner, pose_bone.name)
        in _state.get("yellow_modes", {})
    ):
        effects.append(("PIN", _onion_pin_bone_label(pose_bone), ONION_PIN_COLOR[:3]))
    return tuple(effects)


def _dynamic_pose_bone_native_effect(pose_bone, native_color = None):
    name = str(getattr(pose_bone, "name", ""))
    joint_type = str(getattr(pose_bone, "bone", {}).get("rbx_joint_type", ""))
    if name.endswith("-IKTarget"):
        label = "IK Target"
    elif name.endswith("-IKPole"):
        label = "IK Pole"
    elif joint_type in {"Weld", "WeldConstraint"}:
        label = "Weld Bone"
    else:
        return None
    return (
        "NATIVE",
        label,
        tuple(native_color or (0.65, 0.65, 0.65)),
    )


def _dynamic_pose_bone_base_color(pose_bone):
    color = getattr(pose_bone, "color", None)
    if color is None:
        return None
    palette = str(
        pose_bone.get(DYNAMIC_COLOR_PALETTE_KEY, str(color.palette))
    )
    custom_values = tuple(pose_bone.get(DYNAMIC_COLOR_CUSTOM_KEY, ()))
    if palette == "CUSTOM":
        values = custom_values[0:3] if len(custom_values) >= 3 else color.custom.normal
        return tuple(float(value) for value in values)
    if not palette.startswith("THEME"):
        return None
    try:
        palette_index = int(palette[5:]) - 1
        theme = bpy.context.preferences.themes[0]
        return tuple(
            float(value)
            for value in theme.bone_color_sets[palette_index].normal
        )
    except (AttributeError, IndexError, TypeError, ValueError):
        return None


def _blend_bone_effect_colors(colors):
    colors = tuple(tuple(float(value) for value in color[:3]) for color in colors)
    if not colors:
        return None
    return tuple(
        min(
            1.0,
            math.sqrt(
                sum(max(0.0, color[channel]) ** 2 for color in colors)
                / len(colors)
            ),
        )
        for channel in range(3)
    )


def _dynamic_pose_bone_label_effects(pose_bone, frame, chosen = None):
    effects = list(_dynamic_pose_bone_effects(pose_bone, frame, chosen))
    if (not any(effect[0] == "GYRO" for effect in effects)
            and _pin_marker_value(pose_bone, GYRO_MARKER, frame) > .5):
        guide = _gyro_find(bpy.context, pose_bone.id_data, pose_bone)
        if guide is not None:
            effects.append(("GYRO", "Gyro · " + _constraint_direction_label(
                str(guide.get("gyro_axis", "Z_NEG"))), GYRO_COLOR[:3]))
    # Authored Contact remains discoverable while Orange temporarily owns motion.
    if not any(effect[0] == "CONTACT" for effect in effects):
        contacts = tuple(guide for guide in _surface_contact_guides_for_pose_bone(pose_bone)
                         if _surface_contact_guide_interval_active_at(guide, int(frame))
                         and not _constraint_pin_gyro_blocks_contact(guide, frame))
        if contacts:
            effects.append(("CONTACT", _contact_bone_label(contacts[-1]),
                DYNAMIC_CONTACT_COLOR))
    armature = getattr(pose_bone, "id_data", None)
    scene = getattr(bpy.context, "scene", None)
    if armature is not None and scene is not None:
        try:
            camera = _camera_for_bone(scene, armature, pose_bone.name)
        except (AttributeError, NameError, ReferenceError, RuntimeError):
            camera = None
        if camera is not None:
            effects.append(("CAMERA", "Camera attached", DYNAMIC_CAMERA_COLOR))
    native_color = _dynamic_pose_bone_base_color(pose_bone)
    native_effect = _dynamic_pose_bone_native_effect(pose_bone, native_color)
    if native_effect is not None:
        effects.append(native_effect)
    order = {
        "CAMERA": 0,
        "PIN": 1,
        "PARENT": 2,
        "UNPARENT": 3,
        "CONTACT": 4,
        "CONTACT_TARGET": 4,
        "GYRO": 5,
        "RAGDOLL": 5,
        "NATIVE": 6,
    }
    return tuple(
        effect
        for _index, effect in sorted(
            enumerate(effects),
            key = lambda item: (order.get(item[1][0], 99), item[0]),
        )
    )


def _sync_dynamic_pose_bone_color(pose_bone, chosen, frame):
    effects = _dynamic_pose_bone_label_effects(pose_bone, frame, chosen)
    color_effects = tuple(
        effect
        for effect in effects
        if effect[0] not in {"PIN", "NATIVE"}
    )
    if not color_effects:
        if _dynamic_pose_bone_uses_managed_constraints(pose_bone):
            return _show_dynamic_pose_bone_native_color(pose_bone)
        return _restore_dynamic_pose_bone_color(pose_bone)
    color = getattr(pose_bone, "color", None)
    if color is None:
        return False
    native_color = _dynamic_pose_bone_base_color(pose_bone)
    changed = False
    changed = _capture_dynamic_pose_bone_color(pose_bone) or changed

    effect_colors = [effect[2] for effect in color_effects]
    if native_color is not None:
        effect_colors.append(native_color)
    desired_normal = _blend_bone_effect_colors(effect_colors)
    desired_select = tuple(min(1.0, component * 1.2 + 0.08) for component in desired_normal)
    desired_active = tuple(min(1.0, component * 1.35 + 0.12) for component in desired_normal)
    try:
        if color.palette != "CUSTOM":
            color.palette = "CUSTOM"
            changed = True
        for attribute, desired in (
            ("normal", desired_normal),
            ("select", desired_select),
            ("active", desired_active),
        ):
            # Blender stores these theme colors as bytes. Compare the value
            # it can actually retain, otherwise every unchanged mixed color
            # writes RNA again and invalidates dependency/gizmo state.
            desired=tuple(math.floor(component*255.+.5)/255. for component in desired)
            current = tuple(getattr(color.custom, attribute))
            if any(
                abs(float(a) - float(b)) > 1.0e-6
                for a, b in zip(current, desired)
            ):
                setattr(color.custom, attribute, desired)
                changed = True
        if bool(color.custom.show_colored_constraints):
            color.custom.show_colored_constraints = False
            changed = True
    except (AttributeError, IndexError, TypeError, ValueError):
        return False
    return changed


def _sync_all_dynamic_pose_bone_colors(frame, armature = None):
    read_scope = _special_read_begin()
    previous = _state.get("ragdoll_marker_curve_indexes")
    previous_channels = _state.get("ragdoll_native_channel_indexes")
    if previous is None:
        _state["ragdoll_marker_curve_indexes"] = {}
    if previous_channels is None:
        _state["ragdoll_native_channel_indexes"] = {}
    try:
        return _sync_all_dynamic_pose_bone_colors_impl(frame, armature)
    finally:
        _special_read_end(read_scope)
        if previous is None:
            _state.pop("ragdoll_marker_curve_indexes", None)
        if previous_channels is None:
            _state.pop("ragdoll_native_channel_indexes", None)


def _sync_all_dynamic_pose_bone_colors_impl(frame, armature = None):
    changed = False
    armatures = (
        (armature,)
        if armature is not None
        else tuple(
            obj
            for obj in bpy.data.objects
            if obj.type == "ARMATURE" and getattr(obj, "pose", None) is not None
        )
    )
    for current_armature in armatures:
        if current_armature is None or getattr(current_armature, "pose", None) is None:
            continue
        armature_changed = False
        # Most imported rigs contain unanimated weld/controller bones. They
        # cannot acquire a tool color unless one of these sources exists.
        contact_names=set()
        for guide in _surface_contact_guides():
            if str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY,'')) == current_armature.name:
                contact_names.update(str(guide.get(prop,'')) for prop in (
                    SURFACE_CONTACT_BONE_PROPERTY,SURFACE_CONTACT_CONTROL_BONE_PROPERTY,
                    SURFACE_CONTACT_GEOMETRY_BONE_PROPERTY,SURFACE_CONTACT_CONSTRAINT_BONE_PROPERTY,
                    SURFACE_CONTACT_RELEASE_BONE_PROPERTY))
            if str(guide.get(SURFACE_CONTACT_FOLLOW_OBJECT_PROPERTY,'')) == current_armature.name:
                contact_names.add(str(guide.get(SURFACE_CONTACT_FOLLOW_BONE_PROPERTY,'')))
        camera_names={name for obj in bpy.context.scene.objects if obj.type=='CAMERA'
                      for owner,name in (_camera_bone_binding(obj),) if owner==current_armature}
        for pose_bone in current_armature.pose.bones:
            if pose_bone.bone.get(_SPACE_CARRIER_OWNER):
                continue
            if pose_bone.name not in contact_names and pose_bone.name not in camera_names and not (
                DYNAMIC_COLOR_PALETTE_KEY in pose_bone or UNP_PROP in pose_bone
                or GYRO_MARKER in pose_bone or RAGDOLL_ENABLED_PROPERTY in pose_bone
                or any(_is_dynamic_state_constraint(c) for c in _dynamic_constraints(pose_bone))
            ):
                continue
            chosen = _chosen_dynamic_parent_constraint(pose_bone, int(frame))
            armature_changed = (
                _sync_dynamic_pose_bone_color(
                    pose_bone,
                    chosen,
                    int(frame),
                )
                or armature_changed
            )
        changed = changed or armature_changed
        if armature_changed:
            try:
                current_armature.data.update_tag()
                current_armature.update_tag(refresh = {"DATA"})
            except (AttributeError, ReferenceError, RuntimeError, TypeError):
                pass
    return changed


def _sync_dynamic_parent_owner(owner, frame):
    chosen = _chosen_dynamic_parent_constraint(owner, frame)
    changed = _set_dynamic_parent_owner_constraint(owner, chosen)
    if isinstance(owner, bpy.types.PoseBone):
        changed = _sync_dynamic_pose_bone_color(owner, chosen, frame) or changed
    return changed
