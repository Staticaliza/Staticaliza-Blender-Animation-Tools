"""Dynamic-unparent autokey, F-curve cleanup, snapshots, and handle utilities."""

from ..core.runtime import *  # noqa: F403

def _autokey_push(context):
    ts = getattr(getattr(context, "scene", None), "tool_settings", None)
    if not ts:
        return None

    prev_auto = getattr(ts, "use_keyframe_insert_auto", None)
    prev_ks = getattr(ts, "use_keyframe_insert_keyingset", None)

    if prev_auto is not None:
        ts.use_keyframe_insert_auto = False

    if prev_ks is not None:
        ts.use_keyframe_insert_keyingset = False

    return (prev_auto, prev_ks)

def _autokey_pop(context, prev):
    ts = getattr(getattr(context, "scene", None), "tool_settings", None)
    if not ts or prev is None:
        return

    prev_auto, prev_ks = prev

    if prev_auto is not None:
        ts.use_keyframe_insert_auto = bool(prev_auto)

    if prev_ks is not None:
        ts.use_keyframe_insert_keyingset = bool(prev_ks)

def _obj_transform_dps():
    return (
        "location",
        "scale",
        "rotation_euler",
        "rotation_quaternion",
        "rotation_axis_angle",
        "delta_location",
        "delta_scale",
        "delta_rotation_euler",
        "delta_rotation_quaternion"
    )

def _snapshot_object_keys_all(action):
    out = {}
    if not action:
        return out
    for prop in _obj_transform_dps():
        keys = set()
        for fc in _fcurves_find_all(action, prop):
            idx = int(getattr(fc, "array_index", 0))
            for kp in fc.keyframe_points:
                keys.add((prop, idx, int(round(float(kp.co.x)))))
        out[prop] = keys
    return out

def _cleanup_new_object_keys_all(action, snap):
    if not action:
        return
    for prop in _obj_transform_dps():
        before = snap.get(prop, set()) if snap else set()
        for fc in list(_fcurves_find_all(action, prop)):
            idx = int(getattr(fc, "array_index", 0))
            removed_any = False
            for kp in list(fc.keyframe_points):
                x = int(round(float(kp.co.x)))
                key_id = (prop, idx, x)
                if key_id in before:
                    continue
                fc.keyframe_points.remove(kp)
                removed_any = True
            if removed_any:
                if not fc.keyframe_points:
                    try:
                        _action_remove_fcurve(action, fc)
                    except Exception:
                        pass
                else:
                    try:
                        fc.update()
                    except Exception:
                        pass
    for group_owner in _action_group_owners(action):
        for group in list(group_owner):
            if group.name != "Object Transforms":
                continue
            if len(group.channels) == 0:
                try:
                    group_owner.remove(group)
                except Exception:
                    pass


def _cleanup_object_transform_fcurves(animated_object):
    """Remove top-level transforms from one imported rig object or armature."""
    animation_data = getattr(animated_object, "animation_data", None)
    action = getattr(animation_data, "action", None)
    if action is None:
        return False
    changed = False
    for data_path in _obj_transform_dps():
        for fcurve in tuple(
            _fcurves_find_all(action, data_path, animated_object)
        ):
            changed = _action_remove_fcurve(action, fcurve) or changed
    for groups in _action_group_owners(action, animated_object):
        for group in tuple(groups):
            if str(getattr(group, "name", "")) != "Object Transforms":
                continue
            try:
                if not tuple(group.channels):
                    groups.remove(group)
                    changed = True
            except (AttributeError, ReferenceError, RuntimeError, ValueError):
                pass
    if changed and not _action_fcurves(action, animated_object):
        try:
            animation_data.action = None
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            pass
    return changed


def _cleanup_armature_object_transform_fcurves(armature):
    """Compatibility wrapper for the original armature-only cleanup name."""
    return _cleanup_object_transform_fcurves(armature)


def _is_internal_transform_animation_object(obj):
    """Return whether object transforms are intentional animator runtime data."""
    if obj is None:
        return False
    return any(
        bool(obj.get(property_name, False))
        for property_name in (
            SPACE_HELPER_PROPERTY,
            SURFACE_CONTACT_GUIDE_PROPERTY,
            SURFACE_CONTACT_SOLVER_PROPERTY,
        )
    )


def _rig_object_transform_targets(context):
    targets = []
    seen = set()

    def add(obj):
        if obj is None:
            return
        try:
            object_name = str(obj.name)
        except (AttributeError, ReferenceError, RuntimeError):
            return
        # Reacquire from the current Main database before any ID-property
        # access. Undo replaces object wrappers even when their names remain.
        obj = bpy.data.objects.get(object_name)
        if obj is None or _is_internal_transform_animation_object(obj):
            return
        try:
            pointer = int(obj.as_pointer())
        except (AttributeError, ReferenceError):
            return
        if pointer not in seen:
            seen.add(pointer)
            targets.append(obj)

    for master, armature, _meta in _iter_roblox_rigs():
        add(armature)
        # Imported rigs can put generated meshes or helper objects in nested
        # collections other than Parts.  Keep the cleanup confined to this
        # rig, but cover its complete collection tree.  Do not iterate
        # Collection.all_objects from this app-timer path: Undo/Redo can
        # replace those RNA element wrappers before the timer resumes, which
        # crashes Blender inside obj.get() before Python can raise an error.
        # Snapshot names through freshly reacquired collections instead.
        for obj in _collection_objects_snapshot(master):
            add(obj)
    for armature in _pose_panel_armatures(context):
        add(armature)
    return tuple(targets)


def _maintain_armature_action_channels(
    context,
    force = False,
    sort_only = False,
):
    history_busy = bool(
        _state.get("pin_history_active", False)
        or _state.get("pin_history_syncing", False)
        or bool(_state.get("pin_history_direction", ""))
    )
    if (
        context is None
        or _state.get("animation_channel_maintenance_syncing", False)
        # Structure-only ordering neither authors animation data nor creates
        # an Undo checkpoint. Let it finish on the same depsgraph pass even
        # while Blender is rebuilding an Undo/Redo side; otherwise a newly
        # restored/created group sits below the special channels until the
        # 0.2-second idle maintenance pass.
        or (history_busy and not sort_only)
    ):
        return False
    now = time.perf_counter()
    if (
        not force
        and now
        - float(_state.get("animation_channel_maintenance_last_time", 0.0))
        < 0.2
    ):
        return False
    _state["animation_channel_maintenance_last_time"] = now

    changed = False
    window_manager = getattr(context, "window_manager", None)
    _state["animation_channel_maintenance_syncing"] = True
    try:
        if (
            not sort_only
            and bool(
                getattr(
                    window_manager,
                    "auto_clear_object_transforms_enabled",
                    True,
                )
            )
        ):
            for animated_object in _rig_object_transform_targets(context):
                changed = (
                    _cleanup_object_transform_fcurves(animated_object)
                    or changed
                )

        structure_cache = _state.setdefault(
            "animation_channel_structure_signatures", {}
        )
        refreshed_cache = {}
        for armature in _pose_panel_armatures(context):
            animation_data = getattr(armature, "animation_data", None)
            action = getattr(animation_data, "action", None)
            if action is None:
                continue
            try:
                cache_key = (
                    int(action.as_pointer()),
                    int(armature.as_pointer()),
                )
            except (AttributeError, ReferenceError, RuntimeError, TypeError):
                continue
            structure = _action_channel_structure_signature(
                action,
                armature,
            )
            if sort_only and structure_cache.get(cache_key) == structure:
                refreshed_cache[cache_key] = structure
                continue
            changed = _order_special_action_groups(
                context,
                action,
                armature,
            ) or changed
            refreshed_cache[cache_key] = _action_channel_structure_signature(
                action,
                armature,
            )
        _state["animation_channel_structure_signatures"] = refreshed_cache
    finally:
        _state["animation_channel_maintenance_syncing"] = False
    if changed:
        for window in getattr(window_manager, "windows", ()) if window_manager else ():
            for area in getattr(getattr(window, "screen", None), "areas", ()):
                if area.type in {"DOPESHEET_EDITOR", "GRAPH_EDITOR", "NLA_EDITOR"}:

                    area.tag_redraw()
    return changed


def _snapshot_bone_pose_keys(action, bone_name):
    out = set()
    if not action:
        return out

    for dp in (
        _pose_dp(bone_name, "location"),
        _pose_dp(bone_name, "scale"),
        _pose_dp(bone_name, "rotation_euler"),
        _pose_dp(bone_name, "rotation_quaternion"),
        _pose_dp(bone_name, "rotation_axis_angle")
    ):
        for fc in _fcurves_find_all(action, dp):
            idx = int(getattr(fc, "array_index", 0))
            for kp in fc.keyframe_points:
                out.add((dp, idx, int(round(float(kp.co.x)))))

    return out

def _set_pose_keys_vector_handles_new_only(action, bone_name, frame, snap):
    if not action:
        return

    frame = int(frame)

    for dp in (
        _pose_dp(bone_name, "location"),
        _pose_dp(bone_name, "scale"),
        _pose_dp(bone_name, "rotation_euler"),
        _pose_dp(bone_name, "rotation_quaternion"),
        _pose_dp(bone_name, "rotation_axis_angle")
    ):
        for fc in _fcurves_find_all(action, dp):
            idx = int(getattr(fc, "array_index", 0))

            if snap and (dp, idx, frame) in snap:
                continue

            kp = _fcurve_key_at(fc, frame)
            if not kp:
                continue

            try:
                kp.interpolation = "BEZIER"
            except Exception:
                pass

            try:
                fc.update()
            except Exception:
                pass

def _unparent_has_marker_keys(action, bone_name):
    if not action:
        return False
    dp = _unparent_dp(bone_name)
    for fc in _fcurves_find_all(action, dp):
        try:
            if fc.keyframe_points and len(fc.keyframe_points) > 0:
                return True
        except Exception:
            pass
    return False

def _unparent_segment_at_frame(action, bone_name, frame):
    if not action:
        return (None, None, None, False)

    f = int(frame)
    start_f = _unparent_find_active_start_frame(action, bone_name, f)
    if start_f is None:
        return (None, None, None, False)

    start_f = int(start_f)
    end_f = _unparent_find_end_frame(action, bone_name, start_f)
    end_f = int(end_f) if end_f is not None else None

    next_start = _unparent_find_next_start_frame_from_points(action, bone_name, start_f)
    next_start = int(next_start) if next_start is not None else None

    conjoined = False
    if end_f is not None and next_start is not None:
        conjoined = int(end_f) == int(next_start)

    return (start_f, end_f, next_start, bool(conjoined))


def _unparent_nearest_segment(action, bone_name, frame, excluded_starts = None):
    points = _unparent_points(action, bone_name)
    if not points:
        return (None, None)

    excluded_starts = set(excluded_starts or ())
    segments = []
    active = False
    start_frame = None
    for point_frame, value in points:
        next_active = float(value) >= 0.5
        is_split = float(value) >= UNP_SPLIT_VALUE - 0.5
        if next_active and active and is_split and start_frame is not None:
            if int(start_frame) not in excluded_starts:
                segments.append((int(start_frame), int(point_frame)))
            start_frame = int(point_frame)
        elif next_active and not active:
            start_frame = int(point_frame)
        elif active and not next_active and start_frame is not None:
            if int(start_frame) not in excluded_starts:
                segments.append((int(start_frame), int(point_frame)))
            start_frame = None
        active = next_active

    if (
        active
        and start_frame is not None
        and int(start_frame) not in excluded_starts
    ):
        segments.append((int(start_frame), None))
    if not segments:
        return (None, None)

    current_frame = int(frame)

    def distance(segment):
        segment_start, segment_end = segment
        effective_end = segment_end if segment_end is not None else segment_start
        if segment_end is not None and segment_start <= current_frame <= segment_end:
            return 0
        return min(
            abs(current_frame - segment_start),
            abs(current_frame - effective_end),
        )

    return min(segments, key = lambda segment: (distance(segment), segment[0]))


def _fcurve_prev_next_keyframes(fc, frame):
    prev_kp = None
    next_kp = None
    f = float(frame)

    for kp in fc.keyframe_points:
        x = float(kp.co.x)
        if x < f and (prev_kp is None or x > float(prev_kp.co.x)):
            prev_kp = kp
        if x > f and (next_kp is None or x < float(next_kp.co.x)):
            next_kp = kp

    return prev_kp, next_kp

def _lock_pose_key_handles(action, bone_name, frame):
    if not action:
        return

    frame = int(frame)

    for dp in (
        _pose_dp(bone_name, "location"),
        _pose_dp(bone_name, "scale"),
        _pose_dp(bone_name, "rotation_euler"),
        _pose_dp(bone_name, "rotation_quaternion"),
        _pose_dp(bone_name, "rotation_axis_angle")
    ):
        for fc in _fcurves_find_all(action, dp):
            kp = _fcurve_key_at(fc, frame)
            for k in (kp,):
                if not k:
                    continue

                try:
                    k.interpolation = "BEZIER"
                except Exception:
                    pass

            try:
                fc.update()
            except Exception:
                pass
