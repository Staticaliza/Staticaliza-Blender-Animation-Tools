"""Animation action channels, ordering, migration, and expansion."""

from ..core.runtime import *  # noqa: F403

def _ensure_object_action(obj):
    if not obj.animation_data:
        obj.animation_data_create()
    if not obj.animation_data.action:
        obj.animation_data.action = bpy.data.actions.new(name = f"{obj.name}Action")
    _action_ensure_channelbag(obj.animation_data.action, obj)
    return obj.animation_data.action

def _fcurve_find(action, data_path):
    if not action:
        return None
    for fc in _action_fcurves(action):
        if fc.data_path == data_path:
            return fc
    return None

def _fcurves_find_all(action, data_path, animated_id = None):
    if not action:
        return []
    indexes = _state.get("ragdoll_native_channel_indexes")
    if indexes is not None:
        key = (action.as_pointer(), animated_id.as_pointer() if animated_id else 0)
        if key not in indexes:
            index = {}
            for curve in _action_fcurves(action, animated_id):
                index.setdefault(curve.data_path, []).append(curve)
            indexes[key] = index
        return list(indexes[key].get(data_path, ()))
    return [
        fc
        for fc in _action_fcurves(action, animated_id)
        if fc.data_path == data_path
    ]


def _fcurve_group_collection(action, fcurve):
    legacy_fcurves = getattr(action, "fcurves", None)
    if legacy_fcurves is not None:
        return action.groups

    try:
        target_pointer = int(fcurve.as_pointer())
    except (AttributeError, ReferenceError):
        target_pointer = 0
    for channelbag in _action_channelbags(action):
        if any(
            candidate is fcurve
            or (
                target_pointer
                and int(candidate.as_pointer()) == target_pointer
            )
            for candidate in channelbag.fcurves
        ):
            return channelbag.groups
    return None


def _action_group_alphanumeric_key(value):
    """Case-insensitive natural order shared by every channel category."""
    text = str(value)
    parts = []
    start = 0
    digits = bool(text[:1].isdigit())
    for index in range(1, len(text) + 1):
        current_digits = bool(index < len(text) and text[index].isdigit())
        if index < len(text) and current_digits == digits:
            continue
        token = text[start:index]
        parts.append(
            (0, int(token), token)
            if digits
            else (1, token.casefold(), token)
        )
        start = index
        digits = current_digits
    return tuple(parts), text.casefold(), text


def _special_action_group_sort_key(group):
    name = str(getattr(group, "name", ""))
    special_prefixes = (
        "Dynamic Parent (",
        "Dynamic Unparent (",
        "Surface Contact (",
        "Surface Contact Target (",
        "Surface Contact State (",
        "Ragdoll (",
    )
    for priority, prefix in enumerate(special_prefixes):
        if name.startswith(prefix):
            return priority, _action_group_alphanumeric_key(name)
    # Impaction intentionally writes this shared marker group. Keep it after
    # every relationship/contact channel even when this extension's periodic
    # maintenance runs after Impaction has already placed it at the bottom.
    if (
        name == "Impact Frames"
        or name.startswith("Impact Frame (")
        or name.startswith("Impact Frames (")
    ):
        return len(special_prefixes), _action_group_alphanumeric_key(name)
    return None


def _ordinary_action_group_sort_key(group):
    name = str(getattr(group, "name", ""))
    return _action_group_alphanumeric_key(name)


def _attached_camera_action_group_names(animated_id):
    if getattr(animated_id, "type", "") != "ARMATURE":
        return frozenset()
    names = set()
    for camera in getattr(bpy.data, "objects", ()):
        if getattr(camera, "type", "") != "CAMERA":
            continue
        armature = None
        bone_name = ""
        if (
            getattr(camera, "parent", None) == animated_id
            and getattr(camera, "parent_type", "") == "BONE"
        ):
            armature = animated_id
            bone_name = str(getattr(camera, "parent_bone", ""))
        if armature is None:
            for constraint in getattr(camera, "constraints", ()):
                if (
                    getattr(constraint, "type", "") == "CHILD_OF"
                    and getattr(constraint, "target", None) == animated_id
                    and getattr(constraint, "subtarget", "")
                ):
                    armature = animated_id
                    bone_name = str(constraint.subtarget)
                    break
        if armature is None:
            stored_bone = str(
                camera.get(ATTACHED_CAMERA_BONE_PROPERTY, "")
            )
            stored_owner = str(
                camera.get(ATTACHED_CAMERA_OWNER_NAME_PROPERTY, "")
            )
            if stored_bone and stored_owner == animated_id.name:
                armature = animated_id
                bone_name = stored_bone
        if armature is animated_id and bone_name:
            names.add(str(bone_name))
    return frozenset(names)


def _desired_action_groups(groups, animated_id = None):
    current = list(groups)
    camera_names = _attached_camera_action_group_names(animated_id)
    by_name = {str(getattr(group, "name", "")): group for group in current}
    cameras = []
    fov_names = {f"{name} - FOV" for name in camera_names}
    for camera_name in sorted(camera_names, key = _action_group_alphanumeric_key):
        camera_group = by_name.get(camera_name)
        fov_group = by_name.get(f"{camera_name} - FOV")
        if camera_group is not None:
            cameras.append(camera_group)
        if fov_group is not None:
            cameras.append(fov_group)
    ordinary = sorted(
        (
            group
            for group in current
            if str(getattr(group, "name", "")) not in camera_names | fov_names
            if _special_action_group_sort_key(group) is None
        ),
        key = _ordinary_action_group_sort_key,
    )
    special = sorted(
        (
            group
            for group in current
            if str(getattr(group, "name", "")) not in camera_names
            if _special_action_group_sort_key(group) is not None
        ),
        key = _special_action_group_sort_key,
    )
    return cameras + ordinary + special


def _special_action_groups_ordered(action, animated_id = None):
    for groups in _action_group_owners(action, animated_id):
        current = list(groups)
        if current != _desired_action_groups(groups, animated_id):
            return False
    return True


def _hide_special_action_curves_from_graph(action, animated_id=None):
    """Hide marker-only channels from Graph Editor curves, not Dope Sheet."""
    if action is None:
        return False
    changed = False
    for groups in _action_group_owners(action, animated_id):
        for group in groups:
            # Surface Contact channels contain the animated guide position
            # and rotation. They are real editable motion data, unlike the
            # marker-only special channels hidden below.
            if str(getattr(group, "name", "")).startswith(
                ("Surface Contact", "Ragdoll (")
            ):
                try:
                    action_key = (
                        int(action.as_pointer()),
                        str(getattr(group, "name", "")),
                    )
                    initialized = _state.setdefault(
                        "contact_graph_group_initialized", set()
                    )
                    if action_key not in initialized:
                        group.show_expanded_graph = False
                        initialized.add(action_key)
                        changed = True
                    for fcurve in tuple(getattr(group, "channels", ())):
                        if bool(fcurve.hide):
                            fcurve.hide = False
                            changed = True
                except (
                    AttributeError,
                    ReferenceError,
                    RuntimeError,
                    TypeError,
                    ValueError,
                ):
                    pass
                continue
            if _special_action_group_sort_key(group) is None:
                continue
            try:
                if bool(group.show_expanded_graph):
                    group.show_expanded_graph = False
                    changed = True
            except (AttributeError, ReferenceError, TypeError, ValueError):
                pass
            for fcurve in tuple(getattr(group, "channels", ())):
                try:
                    if not bool(fcurve.hide):
                        # FCurve.hide is explicitly Graph-Editor-only in
                        # Blender. Marker keys therefore remain visible and
                        # editable in the Dope Sheet.
                        fcurve.hide = True
                        changed = True
                except (
                    AttributeError,
                    ReferenceError,
                    RuntimeError,
                    TypeError,
                    ValueError,
                ):
                    pass
    return changed


def _action_group_settings(group):
    values = {}
    for name in (
        "select",
        "lock",
        "mute",
        "show_expanded",
        "show_expanded_graph",
        "use_pin",
        "color_set",
    ):
        try:
            values[name] = getattr(group, name)
        except (AttributeError, ReferenceError):
            pass
    colors = getattr(group, "colors", None)
    if colors is not None:
        color_values = {}
        for name in (
            "normal",
            "select",
            "active",
            "show_colored_constraints",
        ):
            try:
                value = getattr(colors, name)
                color_values[name] = (
                    tuple(value)
                    if name != "show_colored_constraints"
                    else bool(value)
                )
            except (AttributeError, ReferenceError, TypeError):
                pass
        values["colors"] = color_values
    return values


def _restore_action_group_settings(group, values):
    for name in (
        "select",
        "lock",
        "mute",
        "show_expanded",
        "show_expanded_graph",
        "use_pin",
        "color_set",
    ):
        if name not in values:
            continue
        try:
            setattr(group, name, values[name])
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            pass
    colors = getattr(group, "colors", None)
    for name, value in values.get("colors", {}).items():
        if colors is None:
            break
        try:
            setattr(colors, name, value)
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            pass


def _temporary_action_group_name(groups, owner_index, group_index):
    stem = f"__ACTION_GROUP_ORDER_{owner_index:03d}_{group_index:03d}"
    candidate = stem
    suffix = 0
    while groups.get(candidate) is not None:
        suffix += 1
        candidate = f"{stem}_{suffix:03d}"
    return candidate


def _rebuild_action_group_order(action, animated_id = None):
    """Rebuild only group membership when Blender cannot move layered groups."""
    if action is None or getattr(action, "library", None) is not None:
        return False
    try:
        if not bool(getattr(action, "is_editable", True)):
            return False
    except (AttributeError, ReferenceError):
        return False

    changed = False
    for owner_index, groups in enumerate(
        _action_group_owners(action, animated_id)
    ):
        current = list(groups)
        desired = _desired_action_groups(groups, animated_id)
        if current == desired:
            continue

        records = []
        seen_curve_pointers = set()
        valid = True
        for group_index, group in enumerate(desired):
            try:
                curves = tuple(group.channels)
                curve_pointers = tuple(
                    int(fcurve.as_pointer())
                    for fcurve in curves
                )
            except (AttributeError, ReferenceError, RuntimeError):
                valid = False
                break
            if seen_curve_pointers.intersection(curve_pointers):
                valid = False
                break
            seen_curve_pointers.update(curve_pointers)
            records.append({
                "name": str(group.name),
                "curves": curves,
                "curve_pointers": curve_pointers,
                "settings": _action_group_settings(group),
                "temporary_name": _temporary_action_group_name(
                    groups,
                    owner_index,
                    group_index,
                ),
            })
        if not valid:
            continue

        created = []
        try:
            # Create every destination first. Never mutate a collection while
            # iterating its live group.channels view.
            for record in records:
                temporary = groups.new(record["temporary_name"])
                record["temporary"] = temporary
                created.append(temporary)
                _restore_action_group_settings(
                    temporary,
                    record["settings"],
                )

            for record in records:
                temporary = record["temporary"]
                for fcurve in record["curves"]:
                    fcurve.group = temporary

            # Blender normally deletes a group as its final FCurve leaves it.
            # Explicitly remove only an empty survivor (including an originally
            # empty group) before restoring its name.
            for record in records:
                original = groups.get(record["name"])
                if original is None:
                    continue
                if tuple(original.channels):
                    raise RuntimeError("Action group transfer was incomplete")
                groups.remove(original)

            for record in records:
                temporary = record["temporary"]
                temporary.name = record["name"]
                _restore_action_group_settings(
                    temporary,
                    record["settings"],
                )

            ordered_names = tuple(record["name"] for record in records)
            if tuple(str(group.name) for group in groups) != ordered_names:
                raise RuntimeError("Action groups did not retain requested order")
            for record in records:
                restored = groups.get(record["name"])
                restored_pointers = tuple(
                    int(fcurve.as_pointer())
                    for fcurve in restored.channels
                )
                if restored_pointers != record["curve_pointers"]:
                    raise RuntimeError("Action group FCurve membership changed")
            changed = True
        except (
            AttributeError,
            ReferenceError,
            RuntimeError,
            TypeError,
            ValueError,
        ):
            # Best-effort atomic rollback: recover every snapshotted FCurve in
            # its original named group without detaching or replacing Action.
            for record in records:
                try:
                    original = groups.get(record["name"])
                    if original is None:
                        original = groups.new(record["name"])
                    _restore_action_group_settings(
                        original,
                        record["settings"],
                    )
                    for fcurve in record["curves"]:
                        fcurve.group = original
                except (
                    AttributeError,
                    ReferenceError,
                    RuntimeError,
                    TypeError,
                    ValueError,
                ):
                    pass
            for temporary in created:
                try:
                    if not tuple(temporary.channels):
                        groups.remove(temporary)
                except (
                    AttributeError,
                    ReferenceError,
                    RuntimeError,
                    TypeError,
                    ValueError,
                ):
                    pass
    return changed


def _action_group_order_signature(action, animated_id = None):
    try:
        return tuple(
            tuple(str(group.name) for group in groups)
            for groups in _action_group_owners(action, animated_id)
        )
    except (AttributeError, ReferenceError):
        return ()


def _action_channel_structure_signature(action, animated_id=None):
    """Cheap structural fingerprint; keyframe edits leave it unchanged."""
    try:
        return tuple(
            tuple(
                (
                    str(group.name),
                    tuple(int(fcurve.as_pointer()) for fcurve in group.channels),
                )
                for group in groups
            )
            for groups in _action_group_owners(action, animated_id)
        )
    except (
        AttributeError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ):
        return ()


def _order_special_action_groups(context, action, armature):
    """Keep cameras first, ordinary bones alphabetical, and markers last."""
    del context
    if action is None or armature is None:
        return False
    visibility_changed = _hide_special_action_curves_from_graph(
        action,
        armature,
    )
    if _special_action_groups_ordered(action, armature):
        return visibility_changed

    before_signature = _action_group_order_signature(action, armature)
    # ``bpy.ops.anim.channels_move`` is a user-facing operator: invoking it
    # from depsgraph maintenance selects channels, emits undo bookkeeping,
    # and visibly walks groups through intermediate positions. Rebuild the
    # layered Action's group membership directly in its final order instead.
    _rebuild_action_group_order(action, armature)

    after_signature = _action_group_order_signature(action, armature)
    return bool(visibility_changed or before_signature != after_signature)
