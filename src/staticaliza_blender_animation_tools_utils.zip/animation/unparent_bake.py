"""Dynamic-unparent baking, stability keys, and pose-span restoration."""

from ..core.runtime import *  # noqa: F403

def _unparent_bake_window(context, arm, pb, start_frame, end_frame):
    scn = context.scene
    action = _ensure_object_action(arm)

    start_f = int(start_frame)
    end_f = int(end_frame)
    if end_f < start_f:
        start_f, end_f = end_f, start_f

    nxt_s = _unparent_find_next_start_frame_from_points(action, pb.name, start_f)

    is_abutting = False
    if nxt_s is not None:
        if int(end_f) >= int(nxt_s):
            end_f = int(nxt_s) - 1
            is_abutting = True
        elif int(end_f) == int(nxt_s) - 1:
            is_abutting = True

    obj_action = arm.animation_data.action if arm.animation_data else None
    obj_snap_all = _snapshot_object_keys_all(obj_action)

    if start_f < int(scn.frame_start) or start_f > int(scn.frame_end):
        return False

    end_f = max(int(scn.frame_start), min(int(end_f), int(scn.frame_end)))
    if end_f <= start_f:
        return False

    end_is_off = False
    if not is_abutting:
        try:
            end_is_off = _unparent_eval(action, pb.name, int(end_f), pb_default = 0.0) < 0.5
        except Exception:
            end_is_off = False

    baseline_f = int(start_f)
    bake_first = int(start_f + 1)
    bake_last = int(end_f - 1) if end_is_off else int(end_f)

    if bake_last < bake_first:
        bake_first = int(baseline_f)
        bake_last = int(baseline_f)

    snap_pose_before = _snapshot_bone_pose_keys(action, pb.name)
    had_end_plus_1 = any(int(fr) == int(end_f + 1) for _dp, _idx, fr in snap_pose_before)

    saved_frame = int(scn.frame_current)

    write_frames = {int(baseline_f)}
    if bake_last >= bake_first:
        write_frames.update(set(range(int(bake_first), int(bake_last) + 1)))
    if end_is_off:
        write_frames.add(int(end_f))

    capture_frames_list = sorted(list(write_frames))
    mats = {}

    _state["unparent_handler_mute"] = False

    try:
        pre_warm_f = int(capture_frames_list[0] - 1)
        if pre_warm_f >= int(scn.frame_start):
            scn.frame_set(pre_warm_f)
            context.view_layer.update()

        for f in capture_frames_list:
            scn.frame_set(int(f))
            context.view_layer.update()

            depsgraph = context.evaluated_depsgraph_get()
            eval_arm = arm.evaluated_get(depsgraph)
            pb_eval = eval_arm.pose.bones.get(pb.name)

            if pb_eval:
                try:
                    arm_mw = eval_arm.matrix_world.copy()
                    world_m = (arm_mw @ pb_eval.matrix).copy()
                    mats[int(f)] = (arm_mw, world_m)
                except Exception:
                    pass

    finally:
        try:
            scn.frame_set(int(saved_frame))
        except Exception:
            pass
        context.view_layer.update()

    if not mats:
        return False

    if end_is_off:
        last_on = int(end_f - 1)
        if int(last_on) in mats and int(end_f) in mats:
            mats[int(end_f)] = mats[int(last_on)]

    _state["unparent_handler_mute"] = True

    try:
        _fcurve_remove_key_all(action, _unparent_dp(pb.name), int(start_f))

        _unparent_remove_window_keys_only(action, pb.name, int(start_f) + 1, int(end_f))

        for fr in sorted(write_frames):
            _unparent_remove_pose_keys_at(action, pb.name, int(fr))

        context.view_layer.update()

        if not _unparent_switch_preserve_pose(context, arm, pb, False):
            return False

        _unparent_rel_set_cached(arm.name, pb.name, False)
        _unparent_remove_visual_constraint(pb)
        _unparent_clear_start_frame(pb)

        if action and (not _unparent_has_marker_keys(action, pb.name)):
            if UNP_PROP in pb:

                try:
                    del pb[UNP_PROP]
                except Exception:
                    pass

        context.view_layer.update()

        snap_pose = _snapshot_bone_pose_keys(action, pb.name)

        for fr in sorted(write_frames):
            if int(fr) not in mats:
                continue

            arm_mw, world_m = mats[int(fr)]

            scn.frame_set(int(fr))
            context.view_layer.update()

            pb2 = arm.pose.bones.get(pb.name)
            if not pb2:
                continue

            try:
                inv = arm_mw.inverted()
            except Exception:
                inv = Matrix.Identity(4)

            try:
                pb2.matrix = inv @ world_m
            except Exception:
                continue

            context.view_layer.update()

            _insert_bone_keys(pb2, int(fr))

            if int(fr) == int(baseline_f):
                _lock_pose_key_handles(action, pb.name, int(fr))
            elif end_is_off and int(fr) == int(end_f):
                _lock_pose_key_handles(action, pb.name, int(fr))
            else:
                _set_pose_keys_vector_handles_new_only(action, pb.name, int(fr), snap_pose)

        if (not had_end_plus_1) and int(end_f + 1) <= int(scn.frame_end):
            if not is_abutting:
                if not _unparent_is_active_at(context, arm, pb, int(end_f + 1)):
                    _unparent_remove_pose_keys_at(action, pb.name, int(end_f + 1))

        a0 = max(int(start_f), int(baseline_f - 2))
        a1 = min(int(end_f), int(baseline_f + 2))
        for lf in range(int(a0), int(a1) + 1):
            _lock_pose_key_handles(action, pb.name, int(lf))

        if bake_last >= bake_first:
            b0 = max(int(start_f), int(bake_last - 2))
            b1 = min(int(end_f), int(bake_last + 2))
            for lf in range(int(b0), int(b1) + 1):
                _lock_pose_key_handles(action, pb.name, int(lf))

        context.view_layer.update()
        _cleanup_new_object_keys_all(obj_action, obj_snap_all)

    finally:
        _state["unparent_handler_mute"] = False
        try:
            scn.frame_set(int(saved_frame))
        except Exception:
            pass
        context.view_layer.update()

    f_now = int(scn.frame_current)
    want_detached = _unparent_is_active_at(context, arm, pb, int(f_now))
    have_detached = _unparent_relation_is_detached(pb)

    _state["unparent_handler_mute"] = True
    try:
        if bool(want_detached) != bool(have_detached):
            if _unparent_switch_preserve_pose(context, arm, pb, bool(want_detached)):
                _unparent_rel_set_cached(arm.name, pb.name, bool(want_detached))

        if want_detached:
            _unparent_ensure_visual_constraint(arm, pb)
        else:
            _unparent_remove_visual_constraint(pb)

    finally:
        _state["unparent_handler_mute"] = False
        context.view_layer.update()
        _cleanup_new_object_keys_all(obj_action, obj_snap_all)

    return True

def _ddm_ensure_fcurve(action, data_path, animated_id = None):
    unparent_bone_name = ""
    if (
        animated_id is not None
        and getattr(animated_id, "type", None) == "ARMATURE"
        and getattr(animated_id, "pose", None) is not None
    ):
        unparent_bone_name = next((
            pose_bone.name
            for pose_bone in animated_id.pose.bones
            if data_path == _unparent_dp(pose_bone.name)
        ), "")
    fc = _fcurve_find(action, data_path)
    if not fc:
        fc = _action_new_fcurve(
            action,
            data_path,
            animated_id,
            group_name=(
                f"Dynamic Unparent ({unparent_bone_name})"
                if unparent_bone_name else ""
            ),
        )
    if unparent_bone_name:
        _set_dynamic_unparent_fcurve_group(
            animated_id,
            unparent_bone_name,
        )
        fc = _fcurve_find(action, data_path) or fc
    return fc

def _ddm_insert_key(fc, frame, value):
    for kp in fc.keyframe_points:
        if abs(kp.co.x - frame) < 0.001:
            try:
                fc.keyframe_points.remove(kp)
            except:
                pass
            break
    kp = fc.keyframe_points.insert(frame, value)
    kp.interpolation = "CONSTANT"
    kp.type = "GENERATED" if float(value) < 0.5 else "KEYFRAME"
    return kp

def _unparent_inject_end_before_start(context, arm, pb, new_start_frame):
    action = arm.animation_data.action if arm.animation_data else None
    if not action:
        return
    dp = _unparent_dp(pb.name)
    fc = _ddm_ensure_fcurve(action, dp, arm)

    s_next = None
    sorted_pts = sorted(fc.keyframe_points, key = lambda k: k.co.x)

    for kp in sorted_pts:
        if kp.co.x > float(new_start_frame) + 0.1 and float(kp.co.y) > 0.5:
            s_next = int(round(float(kp.co.x)))
            break

    if s_next is None:
        return

    if int(s_next) <= int(new_start_frame) + 1:
        return

    mats = _capture_pose_matrices(context, arm, pb.name, {int(new_start_frame)})
    m_hold = mats.get(int(new_start_frame))
    if m_hold is None:
        return

    end_frame = int(s_next) - 1

    _unparent_remove_window_keys_only(action, pb.name, int(new_start_frame) + 1, end_frame)

    for fr in range(int(new_start_frame) + 1, end_frame + 1):
        _unparent_remove_pose_keys_at(action, pb.name, int(fr))

    snap_pose = _snapshot_bone_pose_keys(action, pb.name)
    _unparent_insert_hold_keys(context, arm, action, pb.name, end_frame, m_hold, snap_pose, allow_next = False)

    _lock_pose_key_handles(action, pb.name, end_frame)

    try:
        fc.update()
    except Exception:
        pass

def _capture_pose_world_matrices_with_arm_mw(context, arm, bone_name, frames):
    scn = context.scene
    saved_frame = int(scn.frame_current)
    mats = {}
    action = arm.animation_data.action if arm.animation_data else None

    try:
        for f in sorted({int(x) for x in frames}):
            scn.frame_set(int(f))
            _sync_dynamic_parent_constraints(int(f), arm)
            _set_unparent_relation_for_frame(
                context,
                arm,
                bone_name,
                action,
                int(f),
            )
            context.view_layer.update()

            depsgraph = context.evaluated_depsgraph_get()
            eval_arm = arm.evaluated_get(depsgraph)
            pb_eval = eval_arm.pose.bones.get(bone_name)
            if not pb_eval:
                continue

            try:
                arm_mw = eval_arm.matrix_world.copy()
                world_m = (arm_mw @ pb_eval.matrix).copy()
                source_bone = arm.pose.bones.get(bone_name)
                channels = None
                if source_bone is not None:
                    rotation_mode = source_bone.rotation_mode
                    rotation_property = get_rotation_mode(source_bone)
                    channels = {
                        "location": tuple(source_bone.location),
                        "scale": tuple(source_bone.scale),
                        "rotation_mode": rotation_mode,
                        "rotation_property": rotation_property,
                        "rotation": tuple(
                            getattr(source_bone, f"rotation_{rotation_property}")
                        ),
                    }
                mats[int(f)] = (arm_mw, world_m, channels)
            except Exception:
                pass

    finally:
        scn.frame_set(saved_frame)
        _sync_dynamic_parent_constraints(saved_frame, arm)
        _set_unparent_relation_for_frame(
            context,
            arm,

            bone_name,
            action,
            saved_frame,
        )
        context.view_layer.update()

    return mats

def _unparent_rel_scan_arm(arm):
    out = set()
    if not arm or arm.type != "ARMATURE":
        return out

    if getattr(arm, "pose", None) is not None:
        out.update(
            pose_bone.name
            for pose_bone in arm.pose.bones
            if _pose_space_managed(pose_bone)
        )

    action = arm.animation_data.action if arm.animation_data else None
    if not action:
        return out

    needle = f'["{UNP_PROP}"]'

    for fc in _action_fcurves(action, arm):
        dp = str(getattr(fc, "data_path", ""))
        if not dp or needle not in dp:
            continue
        if not dp.startswith('pose.bones["'):
            continue

        try:
            name = dp.split('pose.bones["', 1)[1].split('"]', 1)[0]
        except Exception:
            name = ""

        if name:
            out.add(name)

    return out

def _eval_pose_matrix_at_frame(context, arm, bone_name, frame):
    scn = context.scene
    saved = int(scn.frame_current)

    try:
        scn.frame_set(int(frame))
        context.view_layer.update()

        depsgraph = context.evaluated_depsgraph_get()
        eval_arm = arm.evaluated_get(depsgraph)
        pb_eval = eval_arm.pose.bones.get(bone_name)
        if not pb_eval:
            return None

        try:
            return pb_eval.matrix.copy()
        except Exception:
            return None

    finally:
        scn.frame_set(saved)
        context.view_layer.update()

def _insert_stability_keys(context, arm, bone_name, frame, matrix_value):
    if matrix_value is None:
        return

    scn = context.scene
    saved_frame = int(scn.frame_current)
    saved_mtx = _arm_pose_mtx_eval(context, arm, bone_name)

    try:
        scn.frame_set(int(frame))
        context.view_layer.update()

        pb = arm.pose.bones.get(bone_name)
        if not pb:
            return

        try:
            pb.matrix = matrix_value
        except Exception:
            return

        context.view_layer.update()
        _insert_bone_keys(pb, int(frame))

    finally:
        scn.frame_set(saved_frame)
        context.view_layer.update()

        if saved_mtx is not None:
            pb2 = arm.pose.bones.get(bone_name)
            if pb2:
                try:
                    pb2.matrix = saved_mtx
                except Exception:
                    pass

        context.view_layer.update()


def _pose_transform_key_frames(action, bone_name):
    frames = set()
    for data_path in (
        _pose_dp(bone_name, "location"),
        _pose_dp(bone_name, "scale"),
        _pose_dp(bone_name, "rotation_euler"),
        _pose_dp(bone_name, "rotation_quaternion"),
        _pose_dp(bone_name, "rotation_axis_angle"),
    ):
        for fcurve in _fcurves_find_all(action, data_path):
            frames.update(
                int(round(float(key.co.x)))
                for key in fcurve.keyframe_points
            )
    return frames



def _transition_key_frames(action, bone_name, frame, end_exclusive = None):
    frame = int(frame)
    frames = {frame}
    for key_frame in _pose_transform_key_frames(action, bone_name):
        if int(key_frame) < frame:
            continue
        if end_exclusive is not None and int(key_frame) >= int(end_exclusive):
            continue
        frames.add(int(key_frame))
    return frames

def _set_unparent_relation_for_frame(context, arm, bone_name, action, frame):
    pose_bone = arm.pose.bones.get(bone_name)
    if pose_bone is None:
        return None

    if _pose_space_managed(pose_bone):
        pose_bone = _ensure_pose_space_system(
            context,
            arm,
            pose_bone,
            int(frame),
        )
        if pose_bone is not None:
            _unparent_remove_visual_constraint(pose_bone)
            _unparent_rel_set_cached(arm.name, bone_name, True)
        return pose_bone

    want_detached = _unparent_eval(
        action,
        bone_name,
        int(frame),
        pb_default = _pb_prop_get(pose_bone, UNP_PROP, 0.0),
    ) >= 0.5
    have_detached = _unparent_relation_is_detached(pose_bone)
    if bool(want_detached) != bool(have_detached):
        _rel_saved_parent(pose_bone)
        if not _unparent_apply_relation(
            context,
            arm,
            bone_name,
            bool(want_detached),
        ):
            return None
        context.view_layer.update()
        pose_bone = arm.pose.bones.get(bone_name)

    if pose_bone is None:
        return None
    if want_detached:
        _unparent_ensure_visual_constraint(arm, pose_bone)
    else:
        _unparent_remove_visual_constraint(pose_bone)
    _unparent_rel_set_cached(arm.name, bone_name, bool(want_detached))
    return pose_bone


def _dynamic_parent_input_matrix(context, arm, constraint, output_matrix):
    if (
        constraint is None
        or constraint.type != "CHILD_OF"
        or constraint.target is None
        or float(constraint.influence) <= 0.5
    ):
        return output_matrix

    depsgraph = context.evaluated_depsgraph_get()
    target = constraint.target.evaluated_get(depsgraph)
    if target.type == "ARMATURE" and constraint.subtarget:
        target_bone = target.pose.bones.get(constraint.subtarget)
        if target_bone is None:
            return output_matrix
        target_world = target.matrix_world @ target_bone.matrix
    else:
        target_world = target.matrix_world.copy()

    try:
        target_in_armature_space = arm.matrix_world.inverted() @ target_world
        child_of_matrix = target_in_armature_space @ constraint.inverse_matrix
        return child_of_matrix.inverted_safe() @ output_matrix
    except Exception:
        return output_matrix


def _restore_pose_world_span(context, arm, bone_name, captured_matrices):
    if not captured_matrices:
        return False

    scene = context.scene
    saved_frame = int(scene.frame_current)
    action = arm.animation_data.action if arm.animation_data else None
    object_keys_before = _snapshot_object_keys_all(action)
    previous_mute = bool(_state.get("unparent_handler_mute", False))
    _state["unparent_handler_mute"] = True
    restored = False
    try:
        for frame in sorted(captured_matrices):
            scene.frame_set(int(frame))
            _sync_dynamic_parent_constraints(int(frame), arm)
            context.view_layer.update()
            pose_bone = _set_unparent_relation_for_frame(
                context,
                arm,
                bone_name,
                action,
                int(frame),
            )
            if pose_bone is None:
                continue

            capture = captured_matrices[int(frame)]
            _captured_arm_world, world_matrix = capture[:2]
            try:
                armature_inverse = arm.matrix_world.inverted()
            except Exception:
                armature_inverse = Matrix.Identity(4)
            output_matrix = armature_inverse @ world_matrix
            dynamic_constraint = get_last_dynamic_parent_constraint(
                pose_bone,
                int(frame),
            )
            input_matrix = _dynamic_parent_input_matrix(
                context,
                arm,
                dynamic_constraint,
                output_matrix,

            )
            constraint_was_muted = bool(
                getattr(dynamic_constraint, "mute", False)
            ) if dynamic_constraint is not None else False
            try:
                if dynamic_constraint is not None:
                    dynamic_constraint.mute = True
                    context.view_layer.update()
                    pose_bone = arm.pose.bones.get(bone_name)
                pose_bone.matrix = input_matrix
            except Exception:
                if dynamic_constraint is not None:
                    dynamic_constraint.mute = constraint_was_muted
                    context.view_layer.update()
                continue

            context.view_layer.update()
            _insert_bone_keys(pose_bone, int(frame), visual = False)
            if dynamic_constraint is not None:
                dynamic_constraint.mute = constraint_was_muted
                context.view_layer.update()
            restored = True
    finally:
        scene.frame_set(saved_frame)
        _sync_dynamic_parent_constraints(saved_frame, arm)
        context.view_layer.update()
        _set_unparent_relation_for_frame(
            context,
            arm,
            bone_name,
            action,
            saved_frame,
        )
        _state["unparent_handler_mute"] = previous_mute
        _cleanup_new_object_keys_all(action, object_keys_before)
        context.view_layer.update()

    return restored


def _split_pose_unparent_segment(
    context,
    arm,
    pb,
    action,
    active_start,
    split_frame,
    original_end,
    split_factor,
):
    scene = context.scene
    saved_frame = int(scene.frame_current)
    previous_mute = bool(_state.get("unparent_handler_mute", False))
    first_source = _space_constraint_source_for_unparent(active_start)
    second_start = int(split_frame) + 1
    second_source = _space_constraint_source_for_unparent(second_start)
    parent_name = str(pb.bone.get(REL_K_PARENT, ""))
    normal_role = SPACE_ROLE_NORMAL if parent_name else SPACE_ROLE_WORLD
    marker_curve = (
        _unparent_run_curve_at(action, pb.name, int(split_frame))
        or _ddm_ensure_fcurve(action, _unparent_dp(pb.name), arm)
    )

    _state["unparent_handler_mute"] = True
    try:
        _remove_future_space_constraints(pb, first_source, int(split_frame))
        # Store adjacent runs on separate curves. This preserves the semantic
        # End+Start at one frame while preventing Dope Sheet connector lines
        # from spanning later inactive gaps.
        for point in tuple(marker_curve.keyframe_points):
            if (
                abs(float(point.co[0]) - float(original_end)) <= 1.0e-4
                and float(point.co[1]) < 0.5
            ):
                marker_curve.keyframe_points.remove(point)
        _ddm_insert_key(marker_curve, int(split_frame), 0.0)
        curves = _fcurves_find_all(action, _unparent_dp(pb.name))
        used = {int(getattr(curve, "array_index", 0)) for curve in curves}
        index = next(index for index in range(len(used) + 1) if index not in used)
        second_curve = _action_new_fcurve(
            action,
            _unparent_dp(pb.name),
            animated_id=arm,
            index=index,
            group_name=f"Dynamic Unparent ({pb.name})",
        )
        _ddm_insert_key(second_curve, second_start, 1.0)
        _ddm_insert_key(second_curve, int(original_end), 0.0)
        _set_dynamic_unparent_fcurve_group(arm, pb.name)
        if _switch_pose_underlying_space(
            context,
            arm,
            pb,
            normal_role,
            int(split_frame),
            split_factor,
            first_source,
        ) is None:
            return False

        scene.frame_set(second_start)
        _sync_dynamic_parent_constraints(second_start, arm)
        context.view_layer.update()
        pb = arm.pose.bones.get(pb.name)
        second_factor = _pose_space_factor(context, arm, pb)
        if _create_pose_space_constraint(
            context,
            arm,
            pb,
            SPACE_ROLE_UNPARENT,
            second_start,
            desired_factor = second_factor,
            source = second_source,
        ) is None:
            return False

        scene.frame_set(int(original_end))
        _sync_dynamic_parent_constraints(int(original_end), arm)
        context.view_layer.update()
        pb = arm.pose.bones.get(pb.name)
        end_factor = _pose_space_factor(context, arm, pb)
        if _switch_pose_underlying_space(
            context,
            arm,
            pb,
            normal_role,
            int(original_end),
            end_factor,
            second_source,
        ) is None:
            return False
        marker_curve.update()
        second_curve.update()
        return True
    finally:
        scene.frame_set(saved_frame)
        _sync_dynamic_parent_constraints(saved_frame, arm)
        context.view_layer.update()
        pb = arm.pose.bones.get(pb.name)
        if pb is not None:
            _pb_prop_set(
                pb,
                UNP_PROP,
                _unparent_eval(action, pb.name, saved_frame, 0.0),
            )
        _state["unparent_handler_mute"] = previous_mute
