"""Onion-skin capture, clear, and settings update callbacks."""

from ..core.runtime import *  # noqa: F403
import bisect
import time


def _pin_virtual_selected_target_data(context):
    key = str(_state.get("pin_gizmo_selected_key", ""))
    if not key:
        return None
    for guide in _surface_contact_guides():
        if _surface_contact_snap_key(guide) != key:
            continue
        armature = bpy.data.objects.get(
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
        )
        pose_bone = (
            armature.pose.bones.get(
                str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
            )
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        return ("CONTACT", armature, pose_bone, guide) if pose_bone else None
    for armature in _pose_scope_armatures(context):
        for bone_name, packed in _yellow_owner_map(
            "yellow_fixed",
            armature,
        ).items():
            pose_bone = armature.pose.bones.get(str(bone_name))
            if (
                pose_bone is not None
                and key
                == f"YELLOW:{_armature_session_uid(armature)}:{pose_bone.name}"
            ):
                return ("YELLOW", armature, pose_bone, packed)
    return None

def _capture_or_clear(context, enable_ghost, armatures = None):
    _state["last_error"] = ""
    scope = tuple(armatures or _pose_scope_armatures(context))
    if not scope:
        active = _active_armature(context)
        scope = (active,) if active is not None else ()

    enabled_owners = set(_state.get("onion_enabled_owners", set()))
    mesh_batches_by_owner = dict(_state.get("mesh_batches", {}))
    raycast_by_owner = dict(_state.get("raycast_fixed", {}))

    if enable_ghost:
        _enable_runtime()
        for armature in scope:
            uid = _armature_session_uid(armature)
            try:
                bpy.context.view_layer.update()
                mesh_batches, raycast_fixed = _build_snapshot_data(
                    context,
                    armature,
                )
                mesh_batches_by_owner[uid] = mesh_batches
                raycast_by_owner[uid] = raycast_fixed
                enabled_owners.add(uid)
                _store_onion_snapshot(context, armature)
            except Exception as exc:
                _state["last_error"] = str(exc)
                mesh_batches_by_owner.pop(uid, None)
                raycast_by_owner.pop(uid, None)
                enabled_owners.discard(uid)
                _clear_onion_snapshot(armature)
    else:
        for armature in scope:
            uid = _armature_session_uid(armature)
            mesh_batches_by_owner.pop(uid, None)
            raycast_by_owner.pop(uid, None)
            enabled_owners.discard(uid)
            _clear_onion_snapshot(armature)

    _state["mesh_batches"] = mesh_batches_by_owner
    _state["raycast_fixed"] = raycast_by_owner
    _state["onion_enabled_owners"] = enabled_owners
    _store_onion_settings(context)
    _set_onion_property(context.window_manager, bool(enabled_owners))

    if not _runtime_needed(context):
        _disable_runtime()

    if enable_ghost and str(
        getattr(context.window_manager, "onion_skin_mode", "SINGLE")
    ) == "MULTIPLE":
        _refresh_multiple_onion_skin(context, force=True)
    elif not enable_ghost:
        multiple_batches = dict(
            _state.get("onion_multiple_mesh_batches", {})
        )
        multiple_raycast = dict(
            _state.get("onion_multiple_raycast_fixed", {})
        )
        multiple_signatures = dict(
            _state.get("onion_multiple_signatures", {})
        )
        multiple_side_signatures = dict(
            _state.get("onion_multiple_side_signatures", {})
        )
        for armature in scope:
            uid = _armature_session_uid(armature)
            multiple_batches.pop(uid, None)
            multiple_raycast.pop(uid, None)
            multiple_signatures.pop(uid, None)
            multiple_side_signatures.pop(uid, None)
        _state["onion_multiple_mesh_batches"] = multiple_batches
        _state["onion_multiple_raycast_fixed"] = multiple_raycast
        _state["onion_multiple_signatures"] = multiple_signatures
        _state["onion_multiple_side_signatures"] = (
            multiple_side_signatures
        )

    _tag_redraw_all_view3d()

def _on_enabled_toggle(self, context):
    if _state.get("onion_property_syncing", False):
        return
    _capture_or_clear(
        context,
        self.onion_skin_enabled,
        armatures = _pose_scope_armatures(context),
    )

def _on_setting_change(self, context):
    scope = tuple(
        armature
        for armature in _pose_scope_armatures(context)
        if _onion_owner_enabled(armature)
    )
    if not scope:
        return
    _capture_or_clear(context, True, armatures = scope)


def _on_onion_mode_change(self, context):
    _store_onion_settings(context)
    # WindowManager properties are session-owned and deliberately SKIP_SAVE.
    # Mirror the choice into the current Scene immediately so a normal .blend
    # save preserves Single/Multiple even if save_pre is bypassed by a host.
    _animator_utils_store_file_defaults()
    _state["onion_multiple_signatures"] = {}
    _state["onion_multiple_side_signatures"] = {}
    _state["onion_multiple_pending_refresh"] = False
    if str(getattr(self, "onion_skin_mode", "SINGLE")) == "MULTIPLE":
        _refresh_multiple_onion_skin(context, force=True)
    else:
        scope = tuple(
            armature
            for armature in _pose_scope_armatures(context)
            if _onion_owner_enabled(armature)
        )
        if scope:
            _capture_or_clear(context, True, armatures=scope)
    _tag_redraw_all_view3d()


def _onion_pose_keyframes(armature):
    animation_data = getattr(armature, "animation_data", None)
    action = getattr(animation_data, "action", None)
    if action is None:
        return None, ()
    frames = {
        round(float(point.co.x), 6)
        for fcurve in _action_fcurves(action, armature)
        if str(getattr(fcurve, "data_path", "")).startswith('pose.bones["')
        for point in fcurve.keyframe_points
    }
    return action, tuple(sorted(frames))


def _onion_neighbor_frames(frames, current_frame):
    left = bisect.bisect_left(frames, float(current_frame))
    right = bisect.bisect_right(frames, float(current_frame))
    previous_frame = frames[left - 1] if left else None
    next_frame = frames[right] if right < len(frames) else None
    return previous_frame, next_frame


def _onion_neighbor_pose_signature(action, armature, neighbor_frames):
    """Compact evaluated-pose signature for the two displayed ghost frames."""
    if action is None:
        return ()
    frames = tuple(
        float(frame) for frame in neighbor_frames if frame is not None
    )
    if not frames:
        return ()
    signature = []
    for fcurve in _action_fcurves(action, armature):
        data_path = str(getattr(fcurve, "data_path", ""))
        if not data_path.startswith('pose.bones["'):
            continue
        try:
            values = tuple(
                round(float(fcurve.evaluate(frame)), 6) for frame in frames
            )
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            continue
        signature.append((
            data_path,
            int(getattr(fcurve, "array_index", 0)),
            values,
        ))
    return tuple(signature)


def _onion_snapshot_at_frame(context, armature, frame, color):
    scene = context.scene
    current_frame = float(scene.frame_current_final)
    try:
        scene.frame_set(int(frame), subframe=float(frame) % 1.0)
        context.view_layer.update()
        return _build_snapshot_data(context, armature, mesh_color=color)
    finally:
        scene.frame_set(
            int(current_frame),
            subframe=float(current_frame) % 1.0,
        )
        context.view_layer.update()


def _onion_multiple_owner_armatures(context, owner_uids):
    """Resolve enabled owners independently of the currently focused editor."""
    resolved = []
    seen = set()
    for armature in (
        *tuple(_pose_scope_armatures(context)),
        *tuple(bpy.data.objects),
    ):
        if (
            getattr(armature, "type", None) != "ARMATURE"
            or getattr(armature, "pose", None) is None
        ):
            continue
        uid = _armature_session_uid(armature)
        if uid not in owner_uids or uid in seen:
            continue
        seen.add(uid)
        resolved.append(armature)
    return tuple(resolved)


def _refresh_multiple_onion_skin(context, force=False, capture_budget=None):
    if (
        context is None
        or getattr(context, "scene", None) is None
        or getattr(context, "window_manager", None) is None
        or str(getattr(context.window_manager, "onion_skin_mode", "SINGLE"))
        != "MULTIPLE"
        or _state.get("onion_multiple_updating", False)
    ):
        return False
    owners = set(_state.get("onion_enabled_owners", set()))
    if not owners:
        return False
    owner_armatures = _onion_multiple_owner_armatures(context, owners)
    if not owner_armatures:
        # Do not consume the cursor-frame invalidation from a context that
        # cannot resolve the enabled rigs. The timer will retry from bpy.data.
        return False
    signatures = dict(_state.get("onion_multiple_signatures", {}))
    side_signatures = {
        uid: dict(sides)
        for uid, sides in dict(
            _state.get("onion_multiple_side_signatures", {})
        ).items()
    }
    batches_by_owner = dict(_state.get("onion_multiple_mesh_batches", {}))
    raycast_by_owner = dict(_state.get("onion_multiple_raycast_fixed", {}))
    current_frame = float(context.scene.frame_current_final)
    previous_display_frame = _state.get("onion_multiple_display_frame")
    cursor_changed = (
        previous_display_frame is None
        or abs(float(previous_display_frame) - current_frame) > 1.0e-6
    )
    _state["onion_multiple_display_frame"] = current_frame
    changed = False
    captures_used = 0
    pending_refresh = False
    _state["onion_multiple_updating"] = True
    try:
        for armature in owner_armatures:
            uid = _armature_session_uid(armature)
            if uid not in owners:
                continue
            action, frames = _onion_pose_keyframes(armature)
            previous_frame, next_frame = _onion_neighbor_frames(
                frames, current_frame
            )
            pose_signature = _onion_neighbor_pose_signature(
                action,
                armature,
                (previous_frame, next_frame),
            )
            signature = (
                int(action.as_pointer()) if action is not None else 0,
                frames,
                previous_frame,
                next_frame,
                pose_signature,
                bool(context.window_manager.onion_skin_include_meshes),
                bool(context.window_manager.onion_skin_include_bones),
                bool(context.window_manager.onion_skin_raycast),
                bool(context.window_manager.onion_skin_skip_hidden),
                round(float(context.window_manager.onion_skin_opacity), 4),
            )
            owner_batches = dict(batches_by_owner.get(uid, {}))
            owner_raycast = dict(raycast_by_owner.get(uid, {}))
            owner_side_signatures = dict(side_signatures.get(uid, {}))
            for side, frame, color in (
                ("PREVIOUS", previous_frame, (1.0, 0.0, 0.0, context.window_manager.onion_skin_opacity)),
                ("NEXT", next_frame, (0.0, 1.0, 0.0, context.window_manager.onion_skin_opacity)),
            ):
                if frame is None:
                    if side in owner_batches or side in owner_side_signatures:
                        owner_batches.pop(side, None)
                        owner_raycast.pop(side, None)
                        owner_side_signatures.pop(side, None)
                        changed = True
                    continue
                side_signature = (
                    int(action.as_pointer()) if action is not None else 0,
                    frame,
                    _onion_neighbor_pose_signature(
                        action,
                        armature,
                        (frame,),
                    ),
                    signature[5:],
                )
                if not force and owner_side_signatures.get(side) == side_signature:
                    continue
                if (
                    capture_budget is not None
                    and captures_used >= max(1, int(capture_budget))
                ):
                    pending_refresh = True
                    continue
                batches, raycast = _onion_snapshot_at_frame(
                    context, armature, frame, color
                )
                owner_batches[side] = batches
                owner_raycast[side] = raycast
                owner_side_signatures[side] = side_signature
                captures_used += 1
                changed = True
            batches_by_owner[uid] = owner_batches
            raycast_by_owner[uid] = owner_raycast
            side_signatures[uid] = owner_side_signatures
            signatures[uid] = signature
    finally:
        _state["onion_multiple_updating"] = False
    _state["onion_multiple_signatures"] = signatures
    _state["onion_multiple_side_signatures"] = side_signatures
    _state["onion_multiple_mesh_batches"] = batches_by_owner
    _state["onion_multiple_raycast_fixed"] = raycast_by_owner
    _state["onion_multiple_pending_refresh"] = pending_refresh
    # Crossing a keyed-pose boundary rebuilds the cached previews. Moving the
    # timeline cursor inside the same neighboring-key interval only needs a
    # redraw; rebuilding meshes there makes live scrubbing unnecessarily slow.
    if changed or cursor_changed:
        _tag_redraw_all_view3d()
    return changed


def _onion_multiple_frame_change_post(scene, _depsgraph=None):
    context = bpy.context
    if (
        getattr(context, "scene", None) == scene
        and not _state.get("onion_multiple_updating", False)
    ):
        # Queue only. Seeking to two keyed poses from inside frame_change_post
        # blocks the active timeline modal operator until the mouse is released.
        _state["onion_multiple_pending_frame"] = float(
            scene.frame_current_final
        )
        if _animation_playback_active(context):
            _state["onion_multiple_refresh_after_playback"] = True


def _onion_multiple_depsgraph_update_post(scene, depsgraph=None):
    """Mark Multiple ghosts dirty without rebuilding inside depsgraph update."""
    context = bpy.context
    window_manager = getattr(context, "window_manager", None)
    if (
        getattr(context, "scene", None) != scene
        or window_manager is None
        or str(getattr(window_manager, "onion_skin_mode", "SINGLE"))
        != "MULTIPLE"
        or not _state.get("onion_enabled_owners", set())
        or _state.get("onion_multiple_updating", False)
    ):
        return
    for update in tuple(getattr(depsgraph, "updates", ())):
        updated_id = getattr(update, "id", None)
        if isinstance(updated_id, bpy.types.Action) or (
            isinstance(updated_id, bpy.types.Object)
            and getattr(updated_id, "type", "") == "ARMATURE"
        ) or isinstance(updated_id, bpy.types.Armature):
            _state["onion_multiple_pose_dirty"] = True
            return


def _onion_multiple_playback_pair_change(context):
    """Return whether a new neighbor pair has meaningful pose-channel motion."""
    owners = set(_state.get("onion_enabled_owners", set()))
    armatures = _onion_multiple_owner_armatures(context, owners)
    signature = []
    meaningful = False
    for armature in armatures:
        action, frames = _onion_pose_keyframes(armature)
        previous_frame, next_frame = _onion_neighbor_frames(
            frames,
            float(context.scene.frame_current_final),
        )
        signature.append((
            _armature_session_uid(armature),
            int(action.as_pointer()) if action is not None else 0,
            previous_frame,
            next_frame,
        ))
        if previous_frame is None or next_frame is None:
            meaningful = True
            continue
        if action is None:
            continue
        for fcurve in _action_fcurves(action, armature):
            if not str(getattr(fcurve, "data_path", "")).startswith(
                'pose.bones["'
            ):
                continue
            if abs(
                float(fcurve.evaluate(float(next_frame)))
                - float(fcurve.evaluate(float(previous_frame)))
            ) > 1.0e-4:
                meaningful = True
                break
    signature = tuple(signature)
    previous = _state.get("onion_multiple_playback_pair_signature")
    _state["onion_multiple_playback_pair_signature"] = signature
    return previous is not None and signature != previous and meaningful


def _onion_multiple_frame_poll():
    """Catch timeline drags whose editor does not dispatch a usable post hook."""
    if bpy.app.background:
        return 0.2
    context = bpy.context
    scene = getattr(context, "scene", None)
    window_manager = getattr(context, "window_manager", None)
    enabled = bool(_state.get("onion_enabled_owners", set()))
    multiple = bool(
        window_manager is not None
        and str(getattr(window_manager, "onion_skin_mode", "SINGLE"))
        == "MULTIPLE"
    )
    if scene is None or not enabled or not multiple:
        return 0.2
    current_frame = float(scene.frame_current_final)
    displayed_frame = _state.get("onion_multiple_display_frame")
    pose_dirty = bool(_state.get("onion_multiple_pose_dirty", False))
    pending_refresh = bool(
        _state.get("onion_multiple_pending_refresh", False)
    )
    if (
        displayed_frame is None
        or abs(float(displayed_frame) - current_frame) > 1.0e-6
        or pose_dirty
        or pending_refresh
    ):
        playing = _animation_playback_active(context)
        if playing:
            _state["onion_multiple_refresh_after_playback"] = True
            _state["onion_multiple_display_frame"] = current_frame
            _state["onion_multiple_pose_dirty"] = False
            should_refresh = pending_refresh or (
                _onion_multiple_playback_pair_change(context)
            )
            if should_refresh and not _state.get(
                "onion_multiple_updating", False
            ):
                # Rebuild at most one changed side per timer pass. This keeps
                # Multiple Onion current during playback without issuing two
                # or more temporary frame seeks in the same UI event.
                _refresh_multiple_onion_skin(context, capture_budget=1)
            return 0.05
        now = time.monotonic()
        minimum_interval = 0.08
        last_refresh = float(
            _state.get("onion_multiple_live_refresh_time", 0.0)
        )
        if now - last_refresh < minimum_interval:
            return 0.04
        if not _state.get("onion_multiple_updating", False):
            _state["onion_multiple_live_refresh_time"] = now
            _state["onion_multiple_pose_dirty"] = False
            _refresh_multiple_onion_skin(context)
    return 0.08


def _onion_multiple_playback_post(scene, _depsgraph=None):
    """Refresh the deferred Multiple Onion preview after playback stops."""
    context = bpy.context
    if (
        getattr(context, "scene", None) != scene
        or not _state.get("onion_multiple_refresh_after_playback", False)
    ):
        return
    _state["onion_multiple_refresh_after_playback"] = False
    _state.pop("onion_multiple_playback_pair_signature", None)
    _state.pop("onion_multiple_pending_frame", None)
    _state["onion_multiple_pending_refresh"] = False
    _refresh_multiple_onion_skin(context)


def _on_yellow_pin_mode_change(self, context):
    """Treat the N-panel position selector as a live selected-pin config."""
    if (
        context is None
        or context.mode != "POSE"
        or _state.get("yellow_pin_mode_syncing", False)
    ):
        return
    mode = str(getattr(self, "yellow_pin_mode", "MODE_3"))
    pinned = set(_state.get("yellow_modes", {}))
    grouped = {}
    for armature, pose_bones in _selected_pose_bones_by_owner(
        context,
        include_active_fallback=True,
        include_virtual_pin=True,
    ).items():
        selected_pins = tuple(
            pose_bone
            for pose_bone in pose_bones
            if _owner_bone_key(armature, pose_bone.name) in pinned
        )
        if selected_pins:
            grouped[armature] = selected_pins
    if not grouped:
        return
    _state["yellow_pin_mode_syncing"] = True
    try:
        for armature, pose_bones in grouped.items():
            _yellow_apply_to_armature(
                context,
                armature,
                pose_bones,
                mode,
            )
        _yellow_refresh_runtime(context)
        _tag_redraw_all_view3d()
    finally:
        _state["yellow_pin_mode_syncing"] = False


def _on_yellow_pin_axis_change(self, context):
    if (
        context is None
        or context.mode != "POSE"
        or str(getattr(self, "yellow_pin_mode", "MODE_3")) != "MODE_3"
        or _state.get("yellow_pin_axis_syncing", False)
    ):
        return
    grouped = _selected_pose_bones_by_owner(
        context,
        include_active_fallback=True,
        include_virtual_pin=True,
    )
    _state["yellow_pin_axis_syncing"] = True
    try:
        for armature, pose_bones in grouped.items():
            for pose_bone in pose_bones:
                if YELLOW_PIN_TARGET_PROPERTY not in pose_bone:
                    continue
                mode = int(pose_bone.get(YELLOW_PIN_MODE_PROPERTY, 3))
                if mode == 5:
                    mode = 3
                _yellow_apply_to_armature(
                    context,
                    armature,
                    (pose_bone,),
                    f"MODE_{mode}",
                    pin_axis=str(getattr(self, "yellow_pin_axis", "Y_NEG")),
                )
        _yellow_refresh_runtime(context)
        _tag_redraw_all_view3d()
    finally:
        _state["yellow_pin_axis_syncing"] = False


class ANIMATOR_UTILS_OT_yellow_remove(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_remove"
    bl_label = "Remove Onion Pin"
    bl_description = "Remove Onion Pins from the selected bones"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def execute(self, context):
        grouped = _selected_pose_bones_by_owner(
            context,
            include_active_fallback=True,
        )
        removed = 0
        for armature, pose_bones in grouped.items():
            owner_removed, _unreachable = _yellow_apply_to_armature(
                context,
                armature,
                pose_bones,
                "REMOVE",
            )
            removed += owner_removed
        if not removed:
            return {"CANCELLED"}
        _yellow_refresh_runtime(context)
        return {"FINISHED"}


class ANIMATOR_UTILS_OT_yellow_clear_all(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_clear_all"
    bl_label = "Remove Onion Pin"
    bl_description = "Remove selected Onion Pins or every Onion Pin"
    bl_options = {"REGISTER", "UNDO"}

    clear_scope: bpy.props.EnumProperty(
        name = "Clear Scope",
        description = "Choose which Onion Pins to remove",
        items = (
            ("SELECTED", "Selected Pin", "Remove only the selected Onion Pin"),
            ("ALL", "All Pins", "Remove every Onion Pin in the current pose scope"),
        ),
        default = "SELECTED",
    )

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE" and any(
            _yellow_owner_map("yellow_modes", armature)
            for armature in _pose_scope_armatures(context)
        )

    def draw(self, context):
        self.layout.prop(self, "clear_scope", text = "Scope")

    def execute(self, context):
        selected_keys = set(_selected_owner_bone_keys(context))
        _selected_pin_key, selected_pin = _pin_selected_target_data(context)
        if selected_pin is not None and selected_pin[0] == "YELLOW":
            selected_keys.add(
                _owner_bone_key(selected_pin[1], selected_pin[2].name)
            )
        removed = 0
        for armature in _pose_scope_armatures(context):
            pins = _yellow_owner_map("yellow_modes", armature)
            bone_names = tuple(
                bone_name
                for bone_name in pins
                if (
                    self.clear_scope == "ALL"
                    or _owner_bone_key(armature, bone_name) in selected_keys
                )
            )
            for bone_name in bone_names:
                _yellow_clear_target_property(armature, bone_name)
            if not bone_names:
                continue
            removed += len(bone_names)
            _yellow_replace_owner_map(
                "yellow_modes",
                armature,
                {
                    bone_name: mode
                    for bone_name, mode in pins.items()
                    if bone_name not in bone_names
                },
            )
            fixed = _yellow_owner_map("yellow_fixed", armature)
            _yellow_replace_owner_map(
                "yellow_fixed",
                armature,
                {
                    bone_name: packed
                    for bone_name, packed in fixed.items()
                    if bone_name not in bone_names
                },
            )
            if self.clear_scope == "ALL":
                _yellow_set_owner_hidden(armature, False)
        if not removed:
            self.report({"WARNING"}, "No selected Onion Pin to remove.")
            return {"CANCELLED"}
        _yellow_refresh_runtime(context)
        self.report({"INFO"}, f"Removed {removed} Onion Pin(s).")
        return {"FINISHED"}


class ANIMATOR_UTILS_OT_yellow_menu(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_menu"
    bl_label = "Onion Pin"
    bl_description = "Open Onion Pin actions for the current Pose Mode selection"
    bl_options = {"REGISTER", "UNDO"}

    position_mode: bpy.props.EnumProperty(
        name = "Pin Position",
        description = "Choose where this Onion Pin is placed",
        items = (
            ("MODE_3", "Smart", "Use the selected welded-object face"),
            ("MODE_4", "Bone Start", "Use the bone head"),
            ("MODE_2", "Bone Center", "Use the center of the weighted geometry"),
            ("MODE_1", "Bone End", "Use the bone tail"),
        ),
        default = "MODE_3",
    )
    pin_axis: bpy.props.EnumProperty(
        name = "Axis",
        description = "Choose the welded-object face used by Smart",
        items = PIN_AXIS_ITEMS,
        default = "Y_NEG",
    )

    def draw(self, context):
        self.layout.prop(self, "position_mode", text = "Position")
        if self.position_mode == "MODE_3":
            self.layout.prop(self, "pin_axis", text = "Axis")
        else:
            axis_row = self.layout.row()
            axis_row.enabled = False
            axis_row.label(text = "Axis: N/A")

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def invoke(self, context, event):
        selected_pin = _pin_virtual_selected_target_data(context)
        bones = _selected_pose_bones_only(context)
        if not bones and selected_pin is None:
            return {"CANCELLED"}
        pinned = set(_state.get("yellow_modes", {}).keys())
        selected_keys = _selected_owner_bone_keys(
            context,
            include_virtual_pin=True,
        )
        if selected_keys.intersection(pinned):
            bpy.ops.wm.call_menu(name = "ANIMATOR_UTILS_MT_yellow_pin_menu")
            return {"CANCELLED"}
        self.position_mode = str(
            getattr(context.window_manager, "yellow_pin_mode", "MODE_3")
        )
        self.pin_axis = str(
            getattr(context.window_manager, "yellow_pin_axis", "Y_NEG")
        )
        return self.execute(context)

    def execute(self, context):
        grouped = _selected_pose_bones_by_owner(
            context,
            include_active_fallback=True,
        )
        if not grouped:
            return {"CANCELLED"}
        changed = 0
        for armature, pose_bones in grouped.items():
            owner_changed, _unreachable = _yellow_apply_to_armature(
                context,
                armature,
                pose_bones,
                self.position_mode,
                pin_axis=self.pin_axis,
            )
            changed += owner_changed
        if not changed:
            return {"CANCELLED"}
        _yellow_refresh_runtime(context)
        return {"FINISHED"}
