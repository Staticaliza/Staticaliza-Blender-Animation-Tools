"""Onion-skin capture, clear, and settings update callbacks."""

from ..core.runtime import *  # noqa: F403
import bisect
import time


def _pin_virtual_selected_target_data(context):
    key = str(_state.get("pin_gizmo_selected_key", ""))
    if not key:
        return None
    for guide in _surface_contact_guides():
        if _surface_contact_snap_key(guide) != key:
            continue
        armature = bpy.data.objects.get(
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
        )
        pose_bone = (
            armature.pose.bones.get(
                str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
            )
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        return ("CONTACT", armature, pose_bone, guide) if pose_bone else None
    for armature in _pose_scope_armatures(context):
        for bone_name, packed in _yellow_owner_map(
            "yellow_fixed",
            armature,
        ).items():
            pose_bone = armature.pose.bones.get(str(bone_name))
            if (
                pose_bone is not None
                and key
                == f"YELLOW:{_armature_session_uid(armature)}:{pose_bone.name}"
            ):
                return ("YELLOW", armature, pose_bone, packed)
    return None

def _capture_or_clear(context, enable_ghost, armatures = None):
    _state["last_error"] = ""
    scope = tuple(armatures or _pose_scope_armatures(context))
    if not scope:
        active = _active_armature(context)
        scope = (active,) if active is not None else ()

    enabled_owners = set(_state.get("onion_enabled_owners", set()))
    mesh_batches_by_owner = dict(_state.get("mesh_batches", {}))
    raycast_by_owner = dict(_state.get("raycast_fixed", {}))

    if enable_ghost:
        _enable_runtime()
        if not _animation_playback_active(context) and _ragdoll_scene_has_data(context.scene):
            previous_baking = bool(_state.get('ragdoll_baking'))
            _state['ragdoll_baking'] = True
            try:
                _ragdoll_frame_change_post(context.scene)
            finally:
                _state['ragdoll_baking'] = previous_baking
        for armature in scope:
            uid = _armature_session_uid(armature)
            try:
                bpy.context.view_layer.update()
                # Multiple captures only its neighbor poses, not a discarded
                # full current-pose mesh capture before those two seeks.
                mesh_batches, raycast_fixed = (([],{}) if str(
                    context.window_manager.onion_skin_mode)=='MULTIPLE' else
                    _build_snapshot_data(context,armature))
                mesh_batches_by_owner[uid] = mesh_batches
                raycast_by_owner[uid] = raycast_fixed
                enabled_owners.add(uid)
                _store_onion_snapshot(context, armature)
            except Exception as exc:
                _state["last_error"] = str(exc)
                mesh_batches_by_owner.pop(uid, None)
                raycast_by_owner.pop(uid, None)
                enabled_owners.discard(uid)
                _clear_onion_snapshot(armature)
    else:
        for armature in scope:
            uid = _armature_session_uid(armature)
            mesh_batches_by_owner.pop(uid, None)
            raycast_by_owner.pop(uid, None)
            enabled_owners.discard(uid)
            _clear_onion_snapshot(armature)

    _state["mesh_batches"] = mesh_batches_by_owner
    _state["raycast_fixed"] = raycast_by_owner
    _state["onion_enabled_owners"] = enabled_owners
    _store_onion_settings(context)
    _set_onion_property(context.window_manager, bool(enabled_owners))

    if not _runtime_needed(context):
        _disable_runtime()

    if enable_ghost and str(
        getattr(context.window_manager, "onion_skin_mode", "SINGLE")
    ) == "MULTIPLE":
        _refresh_multiple_onion_skin(context, force=True, capture_budget=1)
    elif not enable_ghost:
        multiple_batches = dict(
            _state.get("onion_multiple_mesh_batches", {})
        )
        multiple_raycast = dict(
            _state.get("onion_multiple_raycast_fixed", {})
        )
        multiple_signatures = dict(
            _state.get("onion_multiple_signatures", {})
        )
        multiple_side_signatures = dict(
            _state.get("onion_multiple_side_signatures", {})
        )
        for armature in scope:
            uid = _armature_session_uid(armature)
            multiple_batches.pop(uid, None)
            multiple_raycast.pop(uid, None)
            multiple_signatures.pop(uid, None)
            multiple_side_signatures.pop(uid, None)
        _state["onion_multiple_mesh_batches"] = multiple_batches
        _state["onion_multiple_raycast_fixed"] = multiple_raycast
        _state["onion_multiple_signatures"] = multiple_signatures
        _state["onion_multiple_side_signatures"] = (
            multiple_side_signatures
        )

    _tag_redraw_all_view3d()

def _on_enabled_toggle(self, context):
    if _state.get("onion_property_syncing", False):
        return
    _capture_or_clear(
        context,
        self.onion_skin_enabled,
        armatures = _pose_scope_armatures(context),
    )

def _on_setting_change(self, context):
    scope = tuple(
        armature
        for armature in _pose_scope_armatures(context)
        if _onion_owner_enabled(armature)
    )
    if not scope:
        return
    _capture_or_clear(context, True, armatures = scope)


def _on_onion_mode_change(self, context):
    if _state.get("onion_mode_selecting",False):
        return
    _store_onion_settings(context)
    # WindowManager properties are session-owned and deliberately SKIP_SAVE.
    # Mirror the choice into the current Scene immediately so a normal .blend
    # save preserves Single/Multiple even if save_pre is bypassed by a host.
    _animator_utils_store_file_defaults()
    _state["onion_multiple_signatures"] = {}
    _state["onion_multiple_side_signatures"] = {}
    _state["onion_multiple_pending_refresh"] = False
    if str(getattr(self, "onion_skin_mode", "SINGLE")) == "MULTIPLE":
        _refresh_multiple_onion_skin(context, force=True, capture_budget=1)
    else:
        scope = tuple(
            armature
            for armature in _pose_scope_armatures(context)
            if _onion_owner_enabled(armature)
        )
        if scope:
            _capture_or_clear(context, True, armatures=scope)
    _tag_redraw_all_view3d()


def _on_onion_step_change(self,context):
    if _state.get('onion_mode_selecting') or _state.get('animator_utils_file_defaults_syncing'):return
    _store_onion_settings(context)
    _state['onion_multiple_pending_refresh']=True
    if str(self.onion_skin_mode)=='MULTIPLE':
        _refresh_multiple_onion_skin(context,capture_budget=1)
    _tag_redraw_all_view3d()


def _draw_onion_step_settings(layout,settings):
    row=layout.row(align=True)
    row.prop(settings,'onion_skin_past_step',text='Step -')
    row.prop(settings,'onion_skin_future_step',text='Step +')


def _onion_publish_constraints(context):
    # Cached physics suppresses its depsgraph callbacks, including Gyro's.
    # Publish the same derived constraints before reading evaluated meshes.
    previous=_state.get('surface_contact_solver_syncing',False)
    physics=_state.get('ragdoll_syncing',False)
    _state['surface_contact_solver_syncing']=True
    _state['ragdoll_syncing']=False
    try:
        _gyro_update_aims(context)
        _contact_chain_sync_all(context)
        context.view_layer.update()
    finally:
        _state['ragdoll_syncing']=physics
        _state['surface_contact_solver_syncing']=previous


def _onion_pose_keyframes(armature):
    animation_data = getattr(armature, "animation_data", None)
    action = getattr(animation_data, "action", None)
    if action is None:
        return None, ()
    frames = {
        round(float(point.co.x), 6)
        for fcurve in _action_fcurves(action, armature)
        if str(getattr(fcurve, "data_path", "")).startswith('pose.bones["')
        for point in fcurve.keyframe_points
    }
    return action, tuple(sorted(frames))


def _onion_neighbor_frames(frames, current_frame, past_step=1, future_step=1):
    """Nearest keyed poses; increasing ghost count never skips a closer key."""
    left=bisect.bisect_left(frames,float(current_frame))
    right=bisect.bisect_right(frames,float(current_frame))
    return (frames[left-1] if left else None,frames[right] if right<len(frames) else None)


def _onion_neighbor_frame_groups(frames,current_frame,past_count=1,future_count=1):
    """Reveal more of the existing keyed-pose neighbors, nearest first."""
    left=bisect.bisect_left(frames,float(current_frame))
    right=bisect.bisect_right(frames,float(current_frame))
    return (tuple(reversed(frames[max(0,left-max(1,int(past_count))):left])),
            tuple(frames[right:right+max(1,int(future_count))]))


def _onion_layer_side(layer):
    return str(layer).split(':',1)[0]


def _onion_neighbor_pose_signature(action, armature, neighbor_frames):
    """Compact evaluated-pose signature for the two displayed ghost frames."""
    if action is None:
        return ()
    frames = tuple(
        float(frame) for frame in neighbor_frames if frame is not None
    )
    if not frames:
        return ()
    signature = []
    curves=tuple(_action_fcurves(action, armature))
    for fcurve in curves:
        data_path = str(getattr(fcurve, "data_path", ""))
        try:
            values = tuple(
                round(float(fcurve.evaluate(frame)), 6) for frame in frames
            )
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            continue
        signature.append((
            data_path,
            int(getattr(fcurve, "array_index", 0)),
            values,
        ))
    name=getattr(armature,'name',None)
    if name:
        keyed={(fc.data_path,fc.array_index) for fc in curves}
        for bone in armature.pose.bones:
            rotation=('rotation_quaternion' if bone.rotation_mode=='QUATERNION' else
                      'rotation_axis_angle' if bone.rotation_mode=='AXIS_ANGLE' else 'rotation_euler')
            for prop in ('location',rotation,'scale'):
                path=bone.path_from_id(prop)
                signature.extend(('STATIC',bone.name,prop,i,round(float(value),6))
                    for i,value in enumerate(getattr(bone,prop)) if (path,i) not in keyed)
        rotation=('rotation_quaternion' if armature.rotation_mode=='QUATERNION' else
                  'rotation_axis_angle' if armature.rotation_mode=='AXIS_ANGLE' else 'rotation_euler')
        for prop in ('location',rotation,'scale'):
            signature.extend(('STATIC_OBJECT',prop,i,round(float(value),6))
                for i,value in enumerate(getattr(armature,prop)) if (prop,i) not in keyed)
        for guide in (*_surface_contact_guides(),*_gyro_guides(bpy.context.scene)):
            owner=(_gyro_owner(guide)[0] if guide.get('gyro_reference') is not None
                   else _surface_contact_pose_bone(guide)[0])
            if owner!=armature:continue
            guide_action=_dynamic_parent_owner_action(guide)
            signature.extend(('PIN',guide.name,fc.data_path,fc.array_index,
                tuple(round(float(fc.evaluate(frame)),6) for frame in frames))
                for fc in _action_fcurves(guide_action,guide))
    return tuple(signature)


def _onion_snapshot_at_frame(context, armature, frame, color):
    scene = context.scene
    current_frame = float(scene.frame_current_final)
    source_bases=_pin_capture_action_pose_bases(tuple(o for o in scene.objects
        if o.type=='ARMATURE' and o.pose))
    # Matrices alone lose authored Euler/quaternion components through LRS
    # decomposition. A ghost seek must return the exact source channels,
    # including non-active rotation representations and connected locations.
    source_channels={(owner.name,bone.name):_pin_effect_input_channels(bone)
        for owner in scene.objects if owner.type=='ARMATURE' and owner.pose
        for bone in owner.pose.bones}
    guide_bases={g.name:g.matrix_basis.copy() for g in
        (*_surface_contact_guides(),*_gyro_guides(scene)) if g.name in scene.objects}
    playing = _animation_playback_active(context)
    caches = _state.get('ragdoll_frame_cache', {})
    cached = all(int(at) in caches.get(_ragdoll_state_key(owner, bone), {})
                 for at in (frame, current_frame) for owner in scene.objects if owner.type == 'ARMATURE'
                 for bone in _ragdoll_active_bones_hierarchy_order(owner, int(at)))
    if playing and not cached:
        # Never advance the live physics worker to a distant onion frame.
        # Keep this side pending until its exact sample has been computed.
        return None
    previous_syncing = bool(_state.get('ragdoll_syncing'))
    previous_baking = bool(_state.get('ragdoll_baking'))
    _state['ragdoll_baking'] = True
    if cached:
        _state['ragdoll_syncing'] = True
    try:
        scene.frame_set(int(frame), subframe=float(frame) % 1.0)
        if cached:
            _ragdoll_restore_cached_frame(scene)
        _onion_publish_constraints(context)
        return _build_snapshot_data(context, armature, mesh_color=color)
    finally:
        try:
            scene.frame_set(int(current_frame), subframe=float(current_frame) % 1.0)
            if cached:
                _ragdoll_restore_cached_frame(scene)
            _pin_restore_action_pose_bases(context,source_bases)
            previous_inputs=_state.get('contact_chain_input_editing',False)
            _state['contact_chain_input_editing']=True
            try:
                for (owner_name,bone_name),channels in source_channels.items():
                    bone=bpy.data.objects[owner_name].pose.bones[bone_name]
                    for prop,values in channels.items():
                        if tuple(getattr(bone,prop))!=tuple(values):setattr(bone,prop,values)
            finally:_state['contact_chain_input_editing']=previous_inputs
            for name,basis in guide_bases.items():
                guide=bpy.data.objects.get(name)
                if guide is not None and _pin_keyboard_matrices_differ(guide.matrix_basis,basis):
                    guide.matrix_basis=basis
            _onion_publish_constraints(context)
        finally:
            _state['ragdoll_syncing'] = previous_syncing
            _state['ragdoll_baking'] = previous_baking


def _onion_simulation_signature(armature, action):
    """Earlier trajectory edits and physics settings affect future ghosts."""
    bones = tuple(b for b in armature.pose.bones if _ragdoll_curves(armature,b))
    if not bones:
        return ()
    return (tuple((fc.data_path, fc.array_index, tuple((tuple(p.co),tuple(p.handle_left),
                    tuple(p.handle_right),p.interpolation,p.easing) for p in fc.keyframe_points))
                  for fc in _action_fcurves(action,armature)),
            tuple((b.name, tuple(sorted((k,str(v)) for k,v in b.items()))) for b in bones))


def _onion_multiple_owner_armatures(context, owner_uids):
    """Resolve enabled owners independently of the currently focused editor."""
    resolved = []
    seen = set()
    for armature in (
        *tuple(_pose_scope_armatures(context)),
        *tuple(bpy.data.objects),
    ):
        if (
            getattr(armature, "type", None) != "ARMATURE"
            or getattr(armature, "pose", None) is None
        ):
            continue
        uid = _armature_session_uid(armature)
        if uid not in owner_uids or uid in seen:
            continue
        seen.add(uid)
        resolved.append(armature)
    return tuple(resolved)


def _onion_edit_gesture_active(context):
    """Protect pose edits while allowing timeline scrubbing to update ghosts."""
    scrubbing = any(bool(getattr(window.screen, "is_scrubbing", False))
                    for window in getattr(context.window_manager, "windows", ()))
    return bool(any(_state.get(k) for k in ('pin_history_active','pin_history_syncing',
                    'pin_history_pose_release_pending','ragdoll_history_restoring'))
                or _pin_active_transform_operator(context)
                or (_pin_primary_mouse_pressed() and not scrubbing
                    and _state.get('onion_multiple_pending_frame') is None)
                or _state.get("pin_target_dragging")
                or _state.get("pin_keyboard_transform_active"))


def _refresh_multiple_onion_skin(context, force=False, capture_budget=None):
    if context is not None and _onion_edit_gesture_active(context):
        _state['onion_multiple_pending_refresh']=True
        return False
    if (context is None or getattr(context,'scene',None) is None
            or getattr(context,'window_manager',None) is None
            or context.window_manager.onion_skin_mode!='MULTIPLE'
            or _state.get('onion_multiple_updating')):return False
    owners=set(_state.get('onion_enabled_owners',()))
    rigs=_onion_multiple_owner_armatures(context,owners) if owners else ()
    if not rigs:return False
    wm=context.window_manager;current=float(context.scene.frame_current_final)
    cursor_changed=_state.get('onion_multiple_display_frame')!=current
    _state['onion_multiple_display_frame']=current
    batches_by_owner=dict(_state.get('onion_multiple_mesh_batches',{}))
    raycast_by_owner=dict(_state.get('onion_multiple_raycast_fixed',{}))
    signatures=dict(_state.get('onion_multiple_signatures',{}))
    side_signatures={uid:dict(sides) for uid,sides in _state.get('onion_multiple_side_signatures',{}).items()}
    settings=(bool(wm.onion_skin_include_meshes),bool(wm.onion_skin_include_bones),
        bool(wm.onion_skin_raycast),bool(wm.onion_skin_skip_hidden),round(float(wm.onion_skin_opacity),4))
    captures_used=0;pending=False;changed=False
    _state['onion_multiple_updating']=True
    try:
        for rig in rigs:
            uid=_armature_session_uid(rig);action,frames=_onion_pose_keyframes(rig)
            groups=_onion_neighbor_frame_groups(frames,current,wm.onion_skin_past_step,wm.onion_skin_future_step)
            wanted={}
            for side,neighbors in zip(('PREVIOUS','NEXT'),groups):
                for index,frame in enumerate(neighbors):
                    wanted[side if index==0 else side+':'+str(index)]=(side,frame)
            old_batches=dict(batches_by_owner.get(uid,{}));old_raycast=dict(raycast_by_owner.get(uid,{}))
            old_signatures=dict(side_signatures.get(uid,{}))
            for key in set(old_batches)|set(old_signatures):
                if key not in wanted:
                    old_batches.pop(key,None);old_raycast.pop(key,None);old_signatures.pop(key,None);changed=True
            simulation=_onion_simulation_signature(rig,action)
            pointer=int(action.as_pointer()) if action is not None else 0
            for key,(side,frame) in wanted.items():
                signature=(pointer,frame,_onion_neighbor_pose_signature(action,rig,(frame,)),settings,simulation)
                if not force and old_signatures.get(key)==signature:continue
                snapshots=_state.setdefault('onion_frame_snapshots',{})
                cache_key=(uid,side,signature)
                snapshot=None if force else snapshots.get(cache_key)
                if snapshot is None:
                    if capture_budget is not None and captures_used>=max(1,int(capture_budget)):
                        pending=True;continue
                    color=(0.,1.,0.,wm.onion_skin_opacity) if side=='NEXT' else (1.,0.,0.,wm.onion_skin_opacity)
                    snapshot=_onion_snapshot_at_frame(context,rig,frame,color)
                    if snapshot is None:pending=True;continue
                    captures_used+=1;snapshots[cache_key]=snapshot
                    while len(snapshots)>8:snapshots.pop(next(iter(snapshots)))
                old_batches[key],old_raycast[key]=snapshot
                old_signatures[key]=signature;changed=True
            batches_by_owner[uid]=old_batches;raycast_by_owner[uid]=old_raycast
            side_signatures[uid]=old_signatures;signatures[uid]=(pointer,groups,settings)
    finally:_state['onion_multiple_updating']=False
    _state['onion_multiple_signatures']=signatures
    _state['onion_multiple_side_signatures']=side_signatures
    _state['onion_multiple_mesh_batches']=batches_by_owner
    _state['onion_multiple_raycast_fixed']=raycast_by_owner
    _state['onion_multiple_pending_refresh']=pending
    if not pending:_state.pop('onion_multiple_pending_frame',None)
    if changed or cursor_changed:_tag_redraw_all_view3d()
    return changed


def _onion_multiple_frame_change_post(scene, _depsgraph=None):
    context = bpy.context
    if (
        getattr(context, "scene", None) == scene
        and not _state.get("onion_multiple_updating", False)
    ):
        if (not scene.get('_staticaliza_physics_scratch', False)
                and not _state.get('ragdoll_native_evaluating')):
            _yellow_sync_targets_from_properties(context, refresh=False)
        # Queue only. Seeking to two keyed poses from inside frame_change_post
        # blocks the active timeline modal operator until the mouse is released.
        _state["onion_multiple_pending_frame"] = float(
            scene.frame_current_final
        )
        if _animation_playback_active(context):
            _state["onion_multiple_refresh_after_playback"] = True


def _onion_multiple_depsgraph_update_post(scene, depsgraph=None):
    """Mark Multiple ghosts dirty without rebuilding inside depsgraph update."""
    for update in tuple(getattr(depsgraph, 'updates', ())):
        updated_id=getattr(update,'id',None)
        if isinstance(updated_id,bpy.types.Mesh):
            uid=int(updated_id.original.session_uid)
            cache=_state.get('onion_rigid_mesh_batches',{})
            for key in tuple(cache):
                if key[0]==uid:cache.pop(key,None)
            _state.pop('onion_frame_snapshots',None)
            _state['onion_multiple_side_signatures']={}
            _state['onion_multiple_pose_dirty']=True
    context = bpy.context
    window_manager = getattr(context, "window_manager", None)
    if (
        getattr(context, "scene", None) != scene
        or window_manager is None
        or str(getattr(window_manager, "onion_skin_mode", "SINGLE"))
        != "MULTIPLE"
        or not _state.get("onion_enabled_owners", set())
        or _state.get("onion_multiple_updating", False)
    ):
        return
    for update in tuple(getattr(depsgraph, "updates", ())):
        updated_id = getattr(update, "id", None)
        if isinstance(updated_id, bpy.types.Action) or (
            isinstance(updated_id, bpy.types.Object)
            and getattr(updated_id, "type", "") == "ARMATURE"
        ) or isinstance(updated_id, bpy.types.Armature):
            _state["onion_multiple_pose_dirty"] = True


def _onion_multiple_playback_pair_change(context):
    """Keep all revealed keyed neighbors current as the cursor crosses keys."""
    wm=context.window_manager
    signature=[]
    for owner in _onion_multiple_owner_armatures(context,set(_state.get('onion_enabled_owners',()))):
        action,frames=_onion_pose_keyframes(owner)
        groups=_onion_neighbor_frame_groups(frames,context.scene.frame_current_final,
            wm.onion_skin_past_step,wm.onion_skin_future_step)
        signature.append((_armature_session_uid(owner),int(action.as_pointer()) if action else 0,groups))
    signature=tuple(signature);previous=_state.get('onion_multiple_playback_pair_signature')
    _state['onion_multiple_playback_pair_signature']=signature
    return signature!=previous


def _onion_multiple_frame_poll():
    """Catch timeline drags whose editor does not dispatch a usable post hook."""
    if bpy.app.background:
        return 0.2
    context = bpy.context
    if _onion_edit_gesture_active(context):
        return .1
    scene = getattr(context, "scene", None)
    window_manager = getattr(context, "window_manager", None)
    enabled = bool(_state.get("onion_enabled_owners", set()))
    multiple = bool(
        window_manager is not None
        and str(getattr(window_manager, "onion_skin_mode", "SINGLE"))
        == "MULTIPLE"
    )
    if scene is None or not enabled or not multiple:
        return 0.2
    current_frame = float(scene.frame_current_final)
    displayed_frame = _state.get("onion_multiple_display_frame")
    pose_dirty = bool(_state.get("onion_multiple_pose_dirty", False))
    pending_refresh = bool(
        _state.get("onion_multiple_pending_refresh", False)
    )
    if (
        displayed_frame is None
        or abs(float(displayed_frame) - current_frame) > 1.0e-6
        or pose_dirty
        or pending_refresh
    ):
        playing = _animation_playback_active(context)
        if playing:
            _state["onion_multiple_refresh_after_playback"] = True
            _state["onion_multiple_display_frame"] = current_frame
            _state["onion_multiple_pose_dirty"] = False
            pair_changed=_onion_multiple_playback_pair_change(context)
            should_refresh = pending_refresh or pair_changed or pose_dirty
            if should_refresh and not _state.get(
                "onion_multiple_updating", False
            ):
                # Rebuild at most one changed side per timer pass. This keeps
                # Multiple Onion current during playback without issuing two
                # or more temporary frame seeks in the same UI event.
                _refresh_multiple_onion_skin(context, capture_budget=1)
            return 0.05
        now = time.monotonic()
        minimum_interval = 1./60.
        last_refresh = float(
            _state.get("onion_multiple_live_refresh_time", 0.0)
        )
        if now - last_refresh < minimum_interval:
            return 0.04
        if not _state.get("onion_multiple_updating", False):
            _state["onion_multiple_live_refresh_time"] = now
            _state["onion_multiple_pose_dirty"] = False
            _refresh_multiple_onion_skin(context, capture_budget=1)
    return 1./60.


def _onion_multiple_playback_post(scene, _depsgraph=None):
    """Refresh the deferred Multiple Onion preview after playback stops."""
    context = bpy.context
    if (
        getattr(context, "scene", None) != scene
        or not _state.get("onion_multiple_refresh_after_playback", False)
    ):
        return
    _state["onion_multiple_refresh_after_playback"] = False
    _state.pop("onion_multiple_playback_pair_signature", None)
    _state.pop("onion_multiple_pending_frame", None)
    # Stop owns the final pose and gizmos. Let the existing idle poll refresh
    # at most one ghost side after that event instead of seeking/rendering
    # neighboring frames from inside Blender's playback-stop callback.
    _state["onion_multiple_pending_refresh"] = True
    _state["onion_multiple_pose_dirty"] = True
    _state["onion_multiple_display_frame"] = None
    _state["onion_multiple_live_refresh_time"] = time.monotonic()


def _on_yellow_pin_mode_change(self, context):
    """Treat the N-panel position selector as a live selected-pin config."""
    if (
        context is None
        or context.mode != "POSE"
        or _state.get("yellow_pin_mode_syncing", False)
    ):
        return
    mode = str(getattr(self, "yellow_pin_mode", "MODE_3"))
    pinned = set(_state.get("yellow_modes", {}))
    grouped = {}
    for armature, pose_bones in _selected_pose_bones_by_owner(
        context,
        include_active_fallback=True,
        include_virtual_pin=True,
    ).items():
        selected_pins = tuple(
            pose_bone
            for pose_bone in pose_bones
            if _owner_bone_key(armature, pose_bone.name) in pinned
        )
        if selected_pins:
            grouped[armature] = selected_pins
    if not grouped:
        return
    _state["yellow_pin_mode_syncing"] = True
    try:
        for armature, pose_bones in grouped.items():
            _yellow_apply_to_armature(
                context,
                armature,
                pose_bones,
                mode,
            )
        _yellow_refresh_runtime(context)
        _tag_redraw_all_view3d()
    finally:
        _state["yellow_pin_mode_syncing"] = False


def _on_yellow_pin_axis_change(self, context):
    if (
        context is None
        or context.mode != "POSE"
        or str(getattr(self, "yellow_pin_mode", "MODE_3")) != "MODE_3"
        or _state.get("yellow_pin_axis_syncing", False)
    ):
        return
    grouped = _selected_pose_bones_by_owner(
        context,
        include_active_fallback=True,
        include_virtual_pin=True,
    )
    _state["yellow_pin_axis_syncing"] = True
    try:
        for armature, pose_bones in grouped.items():
            for pose_bone in pose_bones:
                if YELLOW_PIN_TARGET_PROPERTY not in pose_bone:
                    continue
                mode = int(pose_bone.get(YELLOW_PIN_MODE_PROPERTY, 3))
                if mode == 5:
                    mode = 3
                _yellow_apply_to_armature(
                    context,
                    armature,
                    (pose_bone,),
                    f"MODE_{mode}",
                    pin_axis=str(getattr(self, "yellow_pin_axis", "Y_NEG")),
                )
        _yellow_refresh_runtime(context)
        _tag_redraw_all_view3d()
    finally:
        _state["yellow_pin_axis_syncing"] = False


class ANIMATOR_UTILS_OT_yellow_remove(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_remove"
    bl_label = "Remove Onion Pin"
    bl_description = "Remove Onion Pins from the selected bones"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def execute(self, context):
        grouped = _selected_pose_bones_by_owner(
            context,
            include_active_fallback=True,
        )
        removed = 0
        for armature, pose_bones in grouped.items():
            owner_removed, _unreachable = _yellow_apply_to_armature(
                context,
                armature,
                pose_bones,
                "REMOVE",
            )
            removed += owner_removed
        if not removed:
            return {"CANCELLED"}
        _yellow_refresh_runtime(context)
        return {"FINISHED"}


class ANIMATOR_UTILS_OT_yellow_clear_all(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_clear_all"
    bl_label = "Remove Onion Pin"
    bl_description = "Remove selected Onion Pins or every Onion Pin"
    bl_options = {"REGISTER", "UNDO"}

    clear_scope: bpy.props.EnumProperty(
        name = "Clear Scope",
        description = "Choose which Onion Pins to remove",
        items = (
            ("SELECTED", "Selected Pin", "Remove only the selected Onion Pin"),
            ("ALL", "All Pins", "Remove every Onion Pin in the current pose scope"),
        ),
        default = "SELECTED",
    )

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE" and any(
            _yellow_owner_map("yellow_modes", armature)
            for armature in _pose_scope_armatures(context)
        )

    def draw(self, context):
        self.layout.prop(self, "clear_scope", text = "Scope")

    def execute(self, context):
        selected_keys = set(_selected_owner_bone_keys(context))
        _selected_pin_key, selected_pin = _pin_selected_target_data(context)
        if selected_pin is not None and selected_pin[0] == "YELLOW":
            selected_keys.add(
                _owner_bone_key(selected_pin[1], selected_pin[2].name)
            )
        removed = 0
        for armature in _pose_scope_armatures(context):
            pins = _yellow_owner_map("yellow_modes", armature)
            bone_names = tuple(
                bone_name
                for bone_name in pins
                if (
                    self.clear_scope == "ALL"
                    or _owner_bone_key(armature, bone_name) in selected_keys
                )
            )
            for bone_name in bone_names:
                _yellow_clear_target_property(armature, bone_name)
            if not bone_names:
                continue
            removed += len(bone_names)
            _yellow_replace_owner_map(
                "yellow_modes",
                armature,
                {
                    bone_name: mode
                    for bone_name, mode in pins.items()
                    if bone_name not in bone_names
                },
            )
            fixed = _yellow_owner_map("yellow_fixed", armature)
            _yellow_replace_owner_map(
                "yellow_fixed",
                armature,
                {
                    bone_name: packed
                    for bone_name, packed in fixed.items()
                    if bone_name not in bone_names
                },
            )
            if self.clear_scope == "ALL":
                _yellow_set_owner_hidden(armature, False)
        if not removed:
            self.report({"WARNING"}, "No selected Onion Pin to remove.")
            return {"CANCELLED"}
        _yellow_refresh_runtime(context)
        self.report({"INFO"}, f"Removed {removed} Onion Pin(s).")
        return {"FINISHED"}


class ANIMATOR_UTILS_OT_yellow_menu(bpy.types.Operator):
    bl_idname = "staticaliza.yellow_menu"
    bl_label = "Onion Pin"
    bl_description = 'Open Onion Pin actions for the selected bones'
    bl_options = {"REGISTER", "UNDO"}

    position_mode: bpy.props.EnumProperty(
        name = "Pin Position",
        description = "Choose where this Onion Pin is placed",
        items = (
            ("MODE_3", "Smart", "Use the selected welded-object face"),
            ("MODE_4", "Bone Start", "Use the bone head"),
            ("MODE_2", "Bone Center", "Use the center of the weighted geometry"),
            ("MODE_1", "Bone End", "Use the bone tail"),
        ),
        default = "MODE_3",
    )
    pin_axis: bpy.props.EnumProperty(
        name = "Axis",
        description = 'Choose the mesh face used for Smart placement',
        items = PIN_AXIS_ITEMS,
        default = "Y_NEG",
    )

    def draw(self, context):
        self.layout.prop(self, "position_mode", text = "Position")
        if self.position_mode == "MODE_3":
            self.layout.prop(self, "pin_axis", text = "Axis")

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def invoke(self, context, event):
        selected_pin = _pin_virtual_selected_target_data(context)
        bones = _selected_pose_bones_only(context)
        if not bones and selected_pin is None:
            return {"CANCELLED"}
        pinned = set(_state.get("yellow_modes", {}).keys())
        selected_keys = _selected_owner_bone_keys(
            context,
            include_virtual_pin=True,
        )
        if selected_keys.intersection(pinned):
            bpy.ops.wm.call_menu(name = "ANIMATOR_UTILS_MT_yellow_pin_menu")
            return {"CANCELLED"}
        self.position_mode = str(
            getattr(context.window_manager, "yellow_pin_mode", "MODE_3")
        )
        self.pin_axis = str(
            getattr(context.window_manager, "yellow_pin_axis", "Y_NEG")
        )
        return self.execute(context)

    def execute(self, context):
        grouped = _selected_pose_bones_by_owner(
            context,
            include_active_fallback=True,
        )
        if not grouped:
            return {"CANCELLED"}
        changed = 0
        for armature, pose_bones in grouped.items():
            owner_changed, _unreachable = _yellow_apply_to_armature(
                context,
                armature,
                pose_bones,
                self.position_mode,
                pin_axis=self.pin_axis,
            )
            changed += owner_changed
        if not changed:
            return {"CANCELLED"}
        _yellow_refresh_runtime(context)
        return {"FINISHED"}
