"""Roblox export discovery, keyed-bone filtering, and patch metadata helpers."""

from ..core.runtime import *  # noqa: F403
from ..rig.discovery import _rig_display_name

ROBLOX_UTILS_PATCH_KIND_ATTR = "_roblox_animator_utils_patch_kind"
ROBLOX_UTILS_PATCH_ORIGINAL_ATTR = "_roblox_animator_utils_original"
ROBLOX_UTILS_EXPORT_DEPTH_ATTR = "_roblox_animator_utils_export_depth"
DYNAMIC_EXPORT_TARGET_FPS = 240.0
DYNAMIC_EXPORT_MAX_SAMPLE_FACTOR = 16
ROBLOX_ANIMATION_LOOP_METADATA_KEYS = (
    # Canonical custom-payload spelling used by Animator Utils.
    "loop",
    # Roblox exposes AnimationClip/KeyframeSequence.Loop, while some importer
    # adapters serialize the property name without changing its case.
    "Loop",
    # AnimationTrack uses Looped; keep both JSON naming conventions so an
    # importer can consume the metadata without requiring a Blender re-export.
    "looped",
    "Looped",
)


def _apply_roblox_animation_metadata(result, scene, armature_obj=None):
    """Attach compatible animation-level loop metadata to an export."""
    if not isinstance(result, dict):
        return result
    loop = bool(getattr(scene, ROBLOX_ANIMATION_LOOP_PROPERTY, False))
    export_info = result.get("export_info")
    if not isinstance(export_info, dict):
        export_info = {}
        result["export_info"] = export_info
    for key in ROBLOX_ANIMATION_LOOP_METADATA_KEYS:
        result[key] = loop
        export_info[key] = loop
    priority = str(
        getattr(scene, ROBLOX_ANIMATION_PRIORITY_PROPERTY, "Action")
    )
    result["priority"] = priority
    export_info["priority"] = priority
    if armature_obj is not None:
        result["rig"] = _rig_display_name(armature_obj.name)
        pose_bones = getattr(getattr(armature_obj, "pose", None), "bones", None)
        if pose_bones is not None:
            all_pose_bones = tuple(
                pose_bones.values()
                if hasattr(pose_bones, "values")
                else pose_bones
            )
            root_candidates = [
                pose_bone
                for pose_bone in all_pose_bones
                if getattr(pose_bone, "parent", None) is None
                and not bool(pose_bone.bone.get("worldspace_bone", False))
            ]
            root_pose_bone = max(
                root_candidates,
                key = lambda pose_bone: len(getattr(pose_bone, "children", ())),
                default = None,
            )
            pose_parents = {}
            for keyframe in result.get("kfs", ()):
                state = keyframe.get("kf", {}) if isinstance(keyframe, dict) else {}
                for source_name in state:
                    pose_bone = pose_bones.get(str(source_name))
                    parent = getattr(pose_bone, "parent", None)
                    if pose_bone is not None:
                        saved_parent_name = str(
                            pose_bone.bone.get(REL_K_PARENT, "")
                            or pose_bone.bone.get(
                                "worldspace_original_parent", ""
                            )
                        )
                        if saved_parent_name:
                            pose_parents[str(source_name)] = saved_parent_name
                        else:
                            if (
                                parent is None
                                and root_pose_bone is not None
                                and pose_bone is not root_pose_bone
                            ):
                                parent = root_pose_bone
                            pose_parents[str(source_name)] = (
                                str(parent.name) if parent is not None else ""
                            )
            if pose_parents:
                result["pose_parents"] = pose_parents
    return result


def _apply_roblox_camera_fov_metadata(result, scene, armature_obj):
    """Add dense, optional camera FOV data without changing Roblox pose JSON."""
    if not isinstance(result, dict) or armature_obj is None:
        return result
    fps = float(getattr(getattr(scene, "render", None), "fps", 60.0) or 60.0)
    fps_base = float(getattr(getattr(scene, "render", None), "fps_base", 1.0) or 1.0)
    fps /= fps_base
    duration = max(0.0, float(result.get("t", 0.0) or 0.0))
    frame_count = max(1, int(round(duration * fps)))
    start = float(getattr(scene, "frame_start", 0.0))
    actions = _roblox_export_source_actions(armature_obj)
    tracks = []
    for camera in tuple(getattr(scene, "objects", ())):
        if getattr(camera, "type", "") != "CAMERA":
            continue
        owner, bone_name = _camera_bone_binding(camera)
        if owner is not armature_obj or not bone_name:
            continue
        pose_bone = armature_obj.pose.bones.get(bone_name)
        if pose_bone is None:
            continue
        data_path = _camera_fov_data_path(pose_bone)
        curve = next(
            (
                fcurve
                for action in actions
                for fcurve in _action_fcurves(action, armature_obj)
                if str(getattr(fcurve, "data_path", "")) == data_path
            ),
            None,
        )
        default = float(pose_bone.get(ATTACHED_CAMERA_FOV_PROPERTY, 35.0))
        values = [
            round(min(120.0, max(1.0, float(curve.evaluate(start + frame)) if curve else default)), 4)
            for frame in range(frame_count)
        ]
        tracks.append({
            "bone": bone_name,
            "camera": f"{bone_name} - Camera",
            "channel": f"{bone_name} - FOV",
            "values": values,
        })
    if tracks:
        result["camera_fov"] = {
            "format": "staticaliza.camera-fov.v1",
            "rig": _rig_display_name(armature_obj.name),
            "fps": fps,
            "frame_count": frame_count,
            "tracks": tracks,
        }
    return result


def _ragdoll_export_bones(armature_obj):
    """Orange markers author evaluated motion without transform FCurves."""
    if armature_obj is None or getattr(armature_obj, 'pose', None) is None:
        return set()
    return {bone.name for bone in armature_obj.pose.bones
            if _ragdoll_curves(armature_obj, bone)
            or bool(bone.get(RAGDOLL_ENABLED_PROPERTY, False))}


def _surface_contact_export_bones(armature_obj):
    if armature_obj is None or getattr(armature_obj, "pose", None) is None:
        return set()
    bone_names = set()
    for guide in _surface_contact_guides():
        if str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, "")) != armature_obj.name:
            continue
        effector = armature_obj.pose.bones.get(
            str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
        )
        if effector is None:
            continue
        chain_count = int(guide.get(SURFACE_CONTACT_CHAIN_PROPERTY, 1))
        bone_names.update(
            pose_bone.name
            for pose_bone in _surface_contact_chain(effector, chain_count)
        )
    return bone_names


def _roblox_export_source_actions(armature_obj):
    """Return only actions that contribute to the armature's current export."""
    animation_data = getattr(armature_obj, "animation_data", None)
    if animation_data is None:
        return ()

    actions = []
    seen = set()

    def add_action(action):
        if action is None:
            return
        try:
            key = int(action.as_pointer())
        except (AttributeError, ReferenceError, TypeError, ValueError):
            key = id(action)
        if key in seen:
            return
        seen.add(key)
        actions.append(action)

    add_action(getattr(animation_data, "action", None))
    if bool(getattr(animation_data, "use_nla", False)):
        for track in getattr(animation_data, "nla_tracks", ()):
            if bool(getattr(track, "mute", False)):
                continue
            for strip in getattr(track, "strips", ()):
                if bool(getattr(strip, "mute", False)):
                    continue
                add_action(getattr(strip, "action", None))
    return tuple(actions)


def _pose_bone_name_from_animation_path(data_path):
    """Extract and unescape the leading pose-bone name in an RNA path."""
    prefix = 'pose.bones["'
    data_path = str(data_path or "")
    if not data_path.startswith(prefix):
        return ""

    encoded = data_path[len(prefix):]
    characters = []
    escaped = False
    for index, character in enumerate(encoded):
        if escaped:
            characters.append(character)
            escaped = False
            continue
        if character == "\\":
            escaped = True
            continue
        if character == '"' and encoded[index:index + 2] == '"]':
            return "".join(characters)
        characters.append(character)
    return ""


def _roblox_export_keyed_pose_bones(armature_obj):
    """Find bones with at least one authored key in current source actions."""
    keyed_bones = set()
    for action in _roblox_export_source_actions(armature_obj):
        for fcurve in _action_fcurves(action, armature_obj):
            try:
                if len(fcurve.keyframe_points) < 1:
                    continue
            except (AttributeError, ReferenceError, TypeError):
                continue
            bone_name = _pose_bone_name_from_animation_path(
                getattr(fcurve, "data_path", "")
            )
            if bone_name:
                keyed_bones.add(bone_name)
    return keyed_bones


def _filter_unkeyed_bones_from_roblox_export(result, authored_bones):
    """Remove pose payloads that have no authored animation source."""
    if not isinstance(result, dict):
        return result

    authored_bones = set(authored_bones or ())
    filtered_keyframes = []
    for keyframe in result.get("kfs", ()):
        if not isinstance(keyframe, dict):
            continue
        states = keyframe.get("kf")
        if isinstance(states, dict):
            for bone_name in tuple(states):
                if bone_name not in authored_bones:
                    states.pop(bone_name, None)
        if states or keyframe.get("fc"):
            filtered_keyframes.append(keyframe)
    result["kfs"] = filtered_keyframes
    return result


def _unwrap_animator_utils_patch(
    function,
    patch_kind,
    legacy_code_names = (),
    legacy_original_names = (),
):
    current = function
    visited = set()
    while callable(current) and id(current) not in visited:
        visited.add(id(current))
        candidate = None
        if getattr(current, ROBLOX_UTILS_PATCH_KIND_ATTR, "") == patch_kind:
            candidate = getattr(current, ROBLOX_UTILS_PATCH_ORIGINAL_ATTR, None)
        else:
            code = getattr(current, "__code__", None)
            if code is not None and code.co_name in legacy_code_names:
                closure = getattr(current, "__closure__", None) or ()
                for name, cell in zip(code.co_freevars, closure):
                    if name not in legacy_original_names:
                        continue
                    try:
                        value = cell.cell_contents
                    except ValueError:
                        continue
                    if callable(value):
                        candidate = value
                        break
        if not callable(candidate) or candidate is current:
            break
        current = candidate
    return current


def _tag_animator_utils_patch(function, original, patch_kind):
    setattr(function, ROBLOX_UTILS_PATCH_KIND_ATTR, patch_kind)
    setattr(function, ROBLOX_UTILS_PATCH_ORIGINAL_ATTR, original)
    return function
