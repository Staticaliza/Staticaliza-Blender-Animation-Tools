"""Roblox panel layout adapters and drawing helpers."""

from ..core.runtime import *  # noqa: F403

def _roblox_operator_ui_kwargs(operator_id, kwargs):
    updated = dict(kwargs)
    if operator_id == "object.rbxanims_bake":
        updated["text"] = "Export"
    elif operator_id == "object.rbxanims_importmodel":
        updated["text"] = "Import Rig"
    return updated


def _normalize_roblox_operator_layout(layout, operator_id):
    if operator_id == "object.rbxanims_importmodel":
        try:
            layout.scale_y = 1.0
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            pass


def _draw_roblox_label_override(layout, args, kwargs):
    """Return (handled, result) for standardized external empty-state labels."""
    text = kwargs.get("text", args[0] if args else "")
    version_parts = str(text).strip().lstrip("vV").split(".")
    if (
        str(text).strip()[:1].lower() == "v"
        and len(version_parts) >= 2
        and all(part.isdigit() for part in version_parts)
    ):
        return True, None
    if text in _SUPPRESSED_ROBLOX_LABELS:
        return True, None

    updated = dict(kwargs)
    if text in _ROBLOX_HEADER_ICONS:
        updated["icon"] = _ROBLOX_HEADER_ICONS[text]
        remaining_args = args[1:] if args else args
        return True, layout.label(*remaining_args, **updated)
    if text in _EMPTY_ARMATURE_ROBLOX_LABELS:
        updated["text"] = "No armatures in this scene."
    elif updated.get("icon") != "INFO":
        return False, None

    updated.pop("icon", None)
    remaining_args = args[1:] if args else args
    hint = layout.row(align = True)
    hint.active = False
    return True, hint.label(*remaining_args, **updated)


def _draw_roblox_loop_setting(layout, operator_id):
    """Place playback settings immediately above Cautioned's Export."""
    if operator_id != "object.rbxanims_bake":
        return
    scene = getattr(bpy.context, "scene", None)
    if scene is None or not hasattr(scene, ROBLOX_ANIMATION_LOOP_PROPERTY):
        return
    layout.prop(scene, ROBLOX_ANIMATION_LOOP_PROPERTY, text = "Loop (Tab)")
    if hasattr(scene, ROBLOX_ANIMATION_LENGTH_PROPERTY):
        length = _animation_length_frames(scene)
        timecode = _get_roblox_animation_length(scene)
        split = layout.split(factor = 0.3, align = True)
        split.label(text = "Length:")
        split.operator(
            "roblox_animator_utils.edit_animation_length",
            text = f"{timecode} ({length}f)",
        )
        fps_split = layout.split(factor = 0.3, align = True)
        fps_split.label(text = "FPS:")
        fps_split.prop(scene.render, "fps", text = "")
        if hasattr(scene, ROBLOX_ANIMATION_PRIORITY_PROPERTY):
            priority_split = layout.split(factor = 0.3, align = True)
            priority_split.label(text = "Priority:")
            priority_split.prop(
                scene,
                ROBLOX_ANIMATION_PRIORITY_PROPERTY,
                text = "",
            )


def _draw_roblox_import_export_row(layout, args, kwargs):
    """Draw the sole animation Import/Export pair at the panel bottom."""
    row = layout.row(align = True)
    row.operator(
        "roblox_animator_utils.import_animation_clipboard",
        text = "Import",
        icon = "IMPORT",
    )
    updated = _roblox_operator_ui_kwargs("object.rbxanims_bake", kwargs)
    return row.operator(*args, **updated)


class _NullOperatorProperties:
    def __setattr__(self, name, value):
        pass


class _NullUILayout:
    def __setattr__(self, name, value):
        pass

    def row(self, *args, **kwargs):
        return self

    def column(self, *args, **kwargs):
        return self

    def column_flow(self, *args, **kwargs):
        return self

    def grid_flow(self, *args, **kwargs):
        return self

    def split(self, *args, **kwargs):
        return self

    def box(self, *args, **kwargs):
        return self

    def operator(self, *args, **kwargs):
        return _NullOperatorProperties()

    def __getattr__(self, name):
        return lambda *args, **kwargs: None


_NULL_UI_LAYOUT = _NullUILayout()
_UI_CONTAINER_METHODS = frozenset({"row", "column", "column_flow", "grid_flow", "split"})


class _UILayoutProxy:
    __slots__ = (
        "_layout",
        "_hidden_headers",
        "_hide_advanced",
        "_suppress_separators",
    )

    def __init__(
        self,
        layout,
        hidden_headers,
        hide_advanced = False,
        suppress_separators = True,
    ):
        object.__setattr__(self, "_layout", layout)
        object.__setattr__(self, "_hidden_headers", hidden_headers)
        object.__setattr__(self, "_hide_advanced", hide_advanced)
        object.__setattr__(self, "_suppress_separators", suppress_separators)

    def box(self, *args, **kwargs):
        return _LazyBoxProxy(
            self._layout,
            self._hidden_headers,
            self._hide_advanced,
            args,
            kwargs,
        )

    def label(self, *args, **kwargs):
        text = kwargs.get("text", args[0] if args else "")
        if self._hide_advanced and text in _ADVANCED_ROBLOX_LABELS:
            return None
        handled, result = _draw_roblox_label_override(self._layout, args, kwargs)
        if handled:
            return result
        return self._layout.label(*args, **kwargs)

    def separator(self, *args, **kwargs):
        """Discard only external top-level spacers between boxed sections."""
        if self._suppress_separators:
            return None
        return self._layout.separator(*args, **kwargs)

    def operator(self, *args, **kwargs):
        operator_id = args[0] if args else kwargs.get("operator", "")
        if self._hide_advanced and operator_id in _ADVANCED_ROBLOX_OPERATORS:
            return _NullOperatorProperties()
        _draw_roblox_loop_setting(self._layout, operator_id)
        if operator_id == "object.rbxanims_bake":
            return _draw_roblox_import_export_row(
                self._layout,
                args,
                kwargs,
            )
        if operator_id == "object.rbxanims_importmodel" and self._hide_advanced:
            # Cautioned's empty-scene branch enlarges the Setup container
            # itself.  A child scale does not reliably cancel that inherited
            # value after a fresh file load or a hot reload, so normalize the
            # real container before drawing our compact two-row replacement.
            try:
                self._layout.scale_y = 1.0
            except (AttributeError, ReferenceError, RuntimeError, TypeError):
                pass
            import_column = self._layout.column(align = True)
            import_column.scale_y = 1.0
            import_column.prop(
                bpy.context.window_manager,
                "roblox_import_rigging_type",
                text = "Rigging",
            )
            _normalize_roblox_operator_layout(import_column, operator_id)
            kwargs = _roblox_operator_ui_kwargs(operator_id, kwargs)
            return import_column.operator(*args, **kwargs)
        _normalize_roblox_operator_layout(self._layout, operator_id)
        kwargs = _roblox_operator_ui_kwargs(operator_id, kwargs)
        return self._layout.operator(*args, **kwargs)

    def prop(self, *args, **kwargs):
        property_name = args[1] if len(args) > 1 else kwargs.get("property", "")
        if self._hide_advanced and property_name in _ADVANCED_ROBLOX_PROPERTIES:
            return None
        return self._layout.prop(*args, **kwargs)

    def __getattr__(self, name):
        attribute = getattr(self._layout, name)
        if not callable(attribute) or name not in _UI_CONTAINER_METHODS:
            return attribute

        def call_container(*args, **kwargs):
            return _UILayoutProxy(
                attribute(*args, **kwargs),
                self._hidden_headers,
                self._hide_advanced,
                suppress_separators = False,
            )

        return call_container

    def __setattr__(self, name, value):
        setattr(self._layout, name, value)


class _HeaderOnlyUILayoutProxy:
    """Draw only a named top-level box from an external panel."""

    __slots__ = ("_layout", "_visible_headers", "_hide_advanced")

    def __init__(self, layout, visible_headers, hide_advanced = False):
        object.__setattr__(self, "_layout", layout)
        object.__setattr__(self, "_visible_headers", visible_headers)
        object.__setattr__(self, "_hide_advanced", hide_advanced)

    def box(self, *args, **kwargs):
        return _LazyBoxProxy(
            self._layout,
            frozenset(),
            self._hide_advanced,
            args,
            kwargs,
            visible_headers = self._visible_headers,
        )

    def separator(self, *_args, **_kwargs):
        return None

    def __getattr__(self, name):
        attribute = getattr(self._layout, name)
        if callable(attribute):
            return lambda *args, **kwargs: getattr(_NULL_UI_LAYOUT, name)(
                *args,
                **kwargs,
            )
        return attribute

    def __setattr__(self, name, value):
        pass


class _LazyBoxProxy:
    __slots__ = (
        "_parent_layout",
        "_hidden_headers",
        "_hide_advanced",
        "_box_args",
        "_box_kwargs",
        "_layout_proxy",
        "_suppressed",
        "_visible_headers",
        "_accepted",
        "_header_text",
    )

    def __init__(
        self,
        parent_layout,
        hidden_headers,
        hide_advanced,
        box_args,
        box_kwargs,
        visible_headers = None,
    ):
        object.__setattr__(self, "_parent_layout", parent_layout)
        object.__setattr__(self, "_hidden_headers", hidden_headers)
        object.__setattr__(self, "_hide_advanced", hide_advanced)
        object.__setattr__(self, "_box_args", box_args)
        object.__setattr__(self, "_box_kwargs", box_kwargs)
        object.__setattr__(self, "_layout_proxy", None)
        object.__setattr__(self, "_suppressed", False)
        object.__setattr__(self, "_visible_headers", visible_headers)
        object.__setattr__(self, "_accepted", visible_headers is None)
        object.__setattr__(self, "_header_text", "")

    def _normalize_materialized_box(self, layout):
        """Cancel Cautioned's empty-scene Setup enlargement at its owner.

        The external panel assigns ``scale_y`` to the box before drawing its
        header.  Normalizing only the later operator column therefore leaves
        both Setup rows enlarged until a rig changes the external draw branch.
        Once the lazy proxy has identified the Setup box, keep the real box at
        Blender's native scale for the rest of that draw pass.
        """
        if self._header_text == "Setup":
            try:
                layout.scale_y = 1.0
            except (AttributeError, ReferenceError, RuntimeError, TypeError):
                pass
        return layout

    def _header_is_suppressed(self, text):
        if self._suppressed:
            return True
        if not self._accepted:
            if text in self._visible_headers:
                object.__setattr__(self, "_accepted", True)
                return False
            object.__setattr__(self, "_suppressed", True)
            return True
        if text in self._hidden_headers:
            object.__setattr__(self, "_suppressed", True)
            return True
        return False

    def _materialize(self):
        if self._layout_proxy is None:
            layout = self._parent_layout.box(*self._box_args, **self._box_kwargs)
            object.__setattr__(
                self,
                "_layout_proxy",
                _UILayoutProxy(
                    layout,
                    self._hidden_headers,
                    self._hide_advanced,
                    suppress_separators = False,
                ),
            )
        self._normalize_materialized_box(self._layout_proxy)
        return self._layout_proxy

    def label(self, *args, **kwargs):
        if self._suppressed:
            return None
        text = kwargs.get("text", args[0] if args else "")
        if self._header_is_suppressed(text):
            return None
        object.__setattr__(self, "_header_text", str(text))
        if self._hide_advanced and text in _ADVANCED_ROBLOX_LABELS:
            return None
        return self._materialize().label(*args, **kwargs)

    def __getattr__(self, name):
        if self._suppressed:
            return getattr(_NULL_UI_LAYOUT, name)
        if name in _UI_CONTAINER_METHODS:
            def call_container(*args, **kwargs):
                return _DeferredLayoutProxy(self, name, args, kwargs)

            return call_container
        return getattr(self._materialize(), name)

    def __setattr__(self, name, value):
        if not self._suppressed:
            if name == "scale_y" and self._header_text == "Setup":
                value = 1.0
            setattr(self._materialize(), name, value)


class _DeferredLayoutProxy:
    __slots__ = ("_root", "_parent", "_method", "_args", "_kwargs", "_layout")

    def __init__(self, root, method, args, kwargs, parent = None):
        object.__setattr__(self, "_root", root)
        object.__setattr__(self, "_parent", parent)
        object.__setattr__(self, "_method", method)
        object.__setattr__(self, "_args", args)
        object.__setattr__(self, "_kwargs", kwargs)
        object.__setattr__(self, "_layout", None)

    def _materialize(self):
        if self._layout is None:
            parent_layout = self._parent._materialize() if self._parent else self._root._materialize()
            layout = getattr(parent_layout, self._method)(*self._args, **self._kwargs)
            object.__setattr__(self, "_layout", layout)
        return self._layout

    def _hide_if_needed(self, args, kwargs):
        text = kwargs.get("text", args[0] if args else "")
        return self._root._header_is_suppressed(text)

    def label(self, *args, **kwargs):
        if self._root._suppressed:
            return None
        if self._hide_if_needed(args, kwargs):
            return None
        text = kwargs.get("text", args[0] if args else "")
        if self._root._hide_advanced and text in _ADVANCED_ROBLOX_LABELS:
            return None
        return self._materialize().label(*args, **kwargs)

    def prop(self, *args, **kwargs):
        if self._root._suppressed:
            return None
        if self._hide_if_needed((), kwargs):
            return None
        property_name = args[1] if len(args) > 1 else kwargs.get("property", "")
        if (
            self._root._hide_advanced
            and property_name in _ADVANCED_ROBLOX_PROPERTIES
        ):
            return None
        return self._materialize().prop(*args, **kwargs)

    def operator(self, *args, **kwargs):
        if self._root._suppressed:
            return _NullOperatorProperties()
        if self._hide_if_needed(args, kwargs):
            return _NullOperatorProperties()
        operator_id = args[0] if args else kwargs.get("operator", "")
        if self._root._hide_advanced and operator_id in _ADVANCED_ROBLOX_OPERATORS:
            return _NullOperatorProperties()
        layout = self._materialize()
        kwargs = _roblox_operator_ui_kwargs(operator_id, kwargs)
        return layout.operator(*args, **kwargs)

    def __getattr__(self, name):
        if self._root._suppressed:
            return getattr(_NULL_UI_LAYOUT, name)
        if name in _UI_CONTAINER_METHODS:
            def call_container(*args, **kwargs):
                return _DeferredLayoutProxy(
                    self._root,
                    name,
                    args,
                    kwargs,
                    parent = self,
                )

            return call_container
        return getattr(self._materialize(), name)

    def __setattr__(self, name, value):
        if not self._root._suppressed:
            if name == "scale_y" and self._root._header_text == "Setup":
                value = 1.0
            setattr(self._materialize(), name, value)


class _PanelDrawProxy:
    __slots__ = ("_panel", "layout")

    def __init__(self, panel, layout):
        object.__setattr__(self, "_panel", panel)
        object.__setattr__(self, "layout", layout)

    def __getattr__(self, name):
        return getattr(self._panel, name)


def _draw_roblox_animator_footer(layout, context):
    """Append Utils-owned setup and extension controls to Roblox Animator."""
    scene_setup = layout.box()
    scene_setup.label(text = "Scene", icon = "VIEW3D")
    scene_setup.operator_context = "INVOKE_DEFAULT"
    scene_setup.operator("staticaliza.load_template", text = "Load Template")

    extension = layout.box()
    extension.label(text = "Configuration", icon = "PREFERENCES")
    if (
        _state.get("extension_update_running", False)
        or extension_update_guard_active()
    ):
        extension.label(text = "Updating extensions...")
        return
    extension.operator(
        "staticaliza.install_roblox_animations",
        text = "Install Latest Extensions",
        icon = "FILE_REFRESH",
    )
    extension.operator(
        "staticaliza.open_roblox_plugins",
        text = "Install Roblox Plugins",
        icon = "URL",
    )
    extension.prop(
        context.window_manager,
        "roblox_compat_advanced_mode",
        text = "Advanced Mode",
    )


