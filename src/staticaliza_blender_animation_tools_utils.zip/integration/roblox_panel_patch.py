"""Install and restore Roblox Animator panel integration patches."""

from ..core.runtime import *  # noqa: F403
from pathlib import Path
import json
import re
from mathutils import Vector
from ..rig.materials import (
    _smart_material_import_scan,
    _smart_part_aux_matches,
    _smart_remove_invisible_host_faces,
)

from bpy_extras.io_utils import ImportHelper


def _correct_named_imported_parts(meta, meshes):
    """Restore the exported Part identities before creating animation bones."""
    try:
        metadata = json.loads(meta["RigMeta"])
    except (KeyError, TypeError, ValueError):
        return
    expected = sorted(
        {entry.get("name") for entry in metadata.get("partAux", [])
         if isinstance(entry, dict) and isinstance(entry.get("name"), str)},
        key=len,
        reverse=True,
    )
    if not expected:
        return

    spatial = _smart_part_aux_matches(meshes, metadata)
    assignments = {
        obj: spatial[obj.as_pointer()]["name"]
        for obj in meshes if obj.as_pointer() in spatial
    }
    used_names = set(assignments.values())
    for obj in meshes:
        if obj in assignments:
            continue
        # Cautioned renames the Object during fingerprint matching, but its
        # Mesh datablock retains the native OBJ group name.
        group = obj.data.name.split(".", 1)[0].lower()
        target = next(
            (name for name in expected
             if name not in used_names and group == (name + "1").lower()),
            None,
        )
        if target is not None:
            assignments[obj] = target
            used_names.add(target)
    renamed = [(obj, target) for obj, target in assignments.items() if obj.name != target]
    for index, (obj, _) in enumerate(renamed):
        obj.name = f"__rbx_named_import_swap_{index}__"
    for obj, target in renamed:
        obj.name = target


def _clean_imported_armature_names(armatures):
    """Show the rig's own name in RBXMonkey's Target armature selector."""
    for armature in armatures:
        match = re.fullmatch(r"__(.+)_Armature(?:\.\d{3})?", armature.name)
        if match:
            armature.name = match.group(1)


def _process_imported_rig_materials(context, imported_objects):
    """Run material normalization after RBXMonkey's final import metadata pass."""
    imported_ids = {
        obj.as_pointer() for obj in imported_objects
        if obj is not None
    }
    if not imported_ids:
        return

    processed = _state.setdefault("smart_material_processed_rigs", set())
    for collection in tuple(bpy.data.collections):
        if not collection.name.startswith("RIG: "):
            continue
        if any(obj.as_pointer() in imported_ids for obj in collection.all_objects):
            # RBXMonkey's inner import callback can scan before the outer OBJ
            # wrapper restores final Part names and decal metadata. Revisit
            # just these newly imported rigs after that normalization.
            processed.discard(collection.as_pointer())
    _smart_material_import_scan(context.scene)


def _world_bounds(obj):
    corners = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
    return (
        tuple(min(point[axis] for point in corners) for axis in range(3)),
        tuple(max(point[axis] for point in corners) for axis in range(3)),
    )


def _apply_overlay_to_host_face(host, overlay):
    """Use a full-face decal's UVs on the Part face instead of overlapping it."""
    if len(overlay.data.materials) != 1 or overlay.data.uv_layers.active is None:
        return False
    if host.data.users > 1:
        host.data = host.data.copy()
    host_uv = host.data.uv_layers.active or host.data.uv_layers.new(name="UVMap")
    overlay_uv = overlay.data.uv_layers.active
    source_loops = []
    for poly in overlay.data.polygons:
        for loop_index in poly.loop_indices:
            vertex = overlay.data.vertices[overlay.data.loops[loop_index].vertex_index]
            source_loops.append((overlay.matrix_world @ vertex.co, overlay_uv.data[loop_index].uv.copy()))
    if not source_loops:
        return False
    matches = []
    for poly in host.data.polygons:
        loop_matches = []
        for loop_index in poly.loop_indices:
            vertex = host.data.vertices[host.data.loops[loop_index].vertex_index]
            world = host.matrix_world @ vertex.co
            nearest = min(source_loops, key=lambda item: (item[0] - world).length_squared)
            if (nearest[0] - world).length > 0.05:
                break
            loop_matches.append((loop_index, nearest[1]))
        if len(loop_matches) == len(poly.loop_indices):
            matches.append((poly, loop_matches))
    if len(matches) != len(overlay.data.polygons):
        return False
    host_area = sum(poly.area for poly, _ in matches)
    overlay_area = sum(poly.area for poly in overlay.data.polygons)
    if overlay_area <= 0 or abs(host_area - overlay_area) / overlay_area > 0.05:
        return False
    material = overlay.material_slots[0].material
    if material is None:
        return False
    if "_staticaliza_decal_material_start" not in host:
        host["_staticaliza_decal_material_start"] = len(host.data.materials)
    material_index = len(host.data.materials)
    host.data.materials.append(material)
    for poly, loop_matches in matches:
        poly.material_index = material_index
        for loop_index, uv in loop_matches:
            host_uv.data[loop_index].uv = uv
    bpy.data.objects.remove(overlay, do_unlink=True)
    return True


def _merge_imported_decal_faces(imported_meshes):
    """Join Studio's separately exported textured face planes to their Part."""
    meshes = [obj for obj in imported_meshes if obj.type == "MESH"]
    bounds = {obj.as_pointer(): _world_bounds(obj) for obj in meshes}
    hosts = []
    overlays = []
    for obj in meshes:
        low, high = bounds[obj.as_pointer()]
        extent = [high[axis] - low[axis] for axis in range(3)]
        if min(extent) > 0.001:
            hosts.append(obj)
        elif (len(obj.data.polygons) <= 2 and max(extent) > 0.05
              and any(mat and mat.use_nodes and any(
                  node.type == "TEX_IMAGE" and node.image is not None
                  for node in mat.node_tree.nodes
              ) for mat in obj.data.materials)):
            overlays.append(obj)

    grouped = {}
    for overlay in overlays:
        low, high = bounds[overlay.as_pointer()]
        extent = [high[axis] - low[axis] for axis in range(3)]
        face_axis = min(range(3), key=lambda axis: extent[axis])
        candidates = []
        for host in hosts:
            host_low, host_high = bounds[host.as_pointer()]
            if any(
                low[axis] < host_low[axis] - 0.05
                or high[axis] > host_high[axis] + 0.05
                for axis in range(3) if axis != face_axis
            ):
                continue
            face_gap = min(
                abs(low[face_axis] - host_low[face_axis]),
                abs(high[face_axis] - host_high[face_axis]),
            )
            if face_gap > 0.05:
                continue
            face_size_error = sum(
                abs(extent[axis] - (host_high[axis] - host_low[axis]))
                / max(host_high[axis] - host_low[axis], 0.001)
                for axis in range(3) if axis != face_axis
            )
            candidates.append((face_size_error, face_gap, host.name, host))
        if candidates:
            host = min(candidates, key=lambda entry: entry[:3])[3]
            grouped.setdefault(host, []).append(overlay)

    if not grouped:
        return 0
    selected_names = tuple(obj.name for obj in bpy.context.selected_objects)
    active_obj = bpy.context.view_layer.objects.active
    active_name = active_obj.name if active_obj is not None else None
    merged = 0
    try:
        if bpy.context.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        for host, overlays_for_host in grouped.items():
            remaining = []
            for overlay in overlays_for_host:
                if _apply_overlay_to_host_face(host, overlay):
                    merged += 1
                else:
                    remaining.append(overlay)
            if not remaining:
                continue
            bpy.ops.object.select_all(action="DESELECT")
            if "_staticaliza_decal_material_start" not in host:
                host["_staticaliza_decal_material_start"] = len(host.data.materials)
            host.select_set(True)
            for overlay in remaining:
                overlay.select_set(True)
            bpy.context.view_layer.objects.active = host
            if "FINISHED" in bpy.ops.object.join():
                merged += len(remaining)
    finally:
        bpy.ops.object.select_all(action="DESELECT")
        for name in selected_names:
            obj = bpy.data.objects.get(name)
            if obj is not None:
                obj.select_set(True)
        if active_name:
            active_obj = bpy.data.objects.get(active_name)
            if active_obj is not None:
                bpy.context.view_layer.objects.active = active_obj
    return merged


class ANIMATOR_UTILS_OT_import_rigs_obj(bpy.types.Operator, ImportHelper):
    """Import one or more Studio rig OBJs as separate Blender rigs."""

    bl_idname = "animator_utils.import_rigs_obj"
    bl_label = "Import Rig"
    bl_options = {"REGISTER", "UNDO"}

    filename_ext = ".obj"
    filter_glob: bpy.props.StringProperty(default="*.obj", options={"HIDDEN"})
    filepath: bpy.props.StringProperty(subtype="FILE_PATH")
    directory: bpy.props.StringProperty(subtype="DIR_PATH")
    files: bpy.props.CollectionProperty(type=bpy.types.OperatorFileListElement)

    def execute(self, context):
        selected_paths = (
            [Path(self.directory) / item.name for item in self.files]
            if self.files else [Path(self.filepath)]
        )
        paths = tuple(dict.fromkeys(path.resolve() for path in selected_paths))
        if not paths:
            self.report({"ERROR"}, "Select at least one OBJ rig file.")
            return {"CANCELLED"}

        armatures_before = {
            obj.as_pointer() for obj in context.scene.objects
            if obj.type == "ARMATURE"
        }
        imported = 0
        imported_objects = []
        for path in paths:
            if path.suffix.lower() != ".obj" or not path.is_file():
                self.report({"WARNING"}, f"Skipped invalid OBJ: {path.name}")
                continue
            # The Roblox Animations importer leaves ordinary OBJ meshes behind
            # on its no-metadata error path. Check before invoking it.
            with path.open("r", encoding="utf-8", errors="replace") as source:
                has_metadata = any(
                    line[:2].lower() in {"g ", "o "}
                    and line[2:6].lower() == "meta"
                    for line in source
                )
            if not has_metadata:
                self.report({"WARNING"}, f"Skipped {path.name}: no rig metadata")
                continue
            objects_before = {obj.as_pointer() for obj in context.scene.objects}
            previous_import_active = _state.get("staticaliza_multi_obj_import_active", False)
            _state["staticaliza_multi_obj_import_active"] = True
            try:
                result = bpy.ops.object.rbxanims_importmodel(filepath=str(path))
            finally:
                _state["staticaliza_multi_obj_import_active"] = previous_import_active
            if "FINISHED" in result:
                new_objects = [
                    obj for obj in context.scene.objects
                    if obj.as_pointer() not in objects_before
                ]
                imported_objects.extend(new_objects)
                new_metas = [
                    obj for obj in new_objects
                    if obj.type == "EMPTY" and "RigMeta" in obj
                ]
                new_meshes = [obj for obj in new_objects if obj.type == "MESH"]
                if len(new_metas) == 1:
                    _correct_named_imported_parts(new_metas[0], new_meshes)
                imported += 1

        if not imported:
            self.report({"ERROR"}, "No rigs were imported.")
            return {"CANCELLED"}

        _process_imported_rig_materials(context, imported_objects)

        attempts = 0
        def select_imported_armatures():
            nonlocal attempts
            attempts += 1
            armatures = [
                obj for obj in bpy.context.scene.objects
                if obj.type == "ARMATURE"
                and obj.as_pointer() not in armatures_before
            ]
            if len(armatures) < imported and attempts < 30:
                return 0.1
            if armatures:
                _clean_imported_armature_names(armatures)
                try:
                    if bpy.context.mode != "OBJECT":
                        bpy.ops.object.mode_set(mode="OBJECT")
                    bpy.ops.object.select_all(action="DESELECT")
                    for armature in armatures:
                        armature.select_set(True)
                    bpy.context.view_layer.objects.active = armatures[-1]
                    bpy.ops.object.mode_set(mode="POSE")
                except (RuntimeError, ReferenceError):
                    pass
            return None

        if select_imported_armatures() is not None:
            register_owned_timer(select_imported_armatures, first_interval=0.1)
        imported_armatures = [
            obj for obj in context.scene.objects
            if obj.type == "ARMATURE" and obj.as_pointer() not in armatures_before
        ]
        if imported_armatures:
            _schedule_imported_rig_framing(imported_armatures, context)
            _schedule_rig_collection_collapse()
        self.report({"INFO"}, f"Imported {imported} rig{'s' if imported != 1 else ''}.")
        return {"FINISHED"}

def _restore_roblox_advanced_panel_filter():
    patches = _state.pop("roblox_advanced_panel_patch", None)
    if patches is None:
        return
    if isinstance(patches, tuple) and len(patches) == 3:
        patches = (patches,)
    for panel_class, original_draw, patched_draw in tuple(patches):
        if getattr(panel_class, "draw", None) is patched_draw:
            panel_class.draw = original_draw


def _restore_roblox_clipboard_endpoint_patch():
    patch = _state.pop("roblox_clipboard_endpoint_patch", None)
    if patch is None:
        return
    handler_class, original_do_post, patched_do_post = patch
    if getattr(handler_class, "do_POST", None) is patched_do_post:
        handler_class.do_POST = original_do_post


def _patch_roblox_clipboard_endpoint():
    module_name = _roblox_addon_module_name()
    if module_name is None:
        return False
    try:
        handler_module = importlib.import_module(f"{module_name}.server.handler")
        handler_class = handler_module.AnimationHandler
    except (AttributeError, ImportError):
        return False

    existing = _state.get("roblox_clipboard_endpoint_patch")
    if existing is not None:
        if existing[0] is handler_class and handler_class.do_POST is existing[2]:
            return True
        _restore_roblox_clipboard_endpoint_patch()

    original_do_post = handler_class.do_POST

    def do_post_with_clipboard(self):
        if str(getattr(self, "path", "")).split("?", 1)[0] != "/staticaliza_clipboard":
            return original_do_post(self)
        try:
            content_length = int(self.headers.get("Content-Length", "0"))
            if content_length <= 0 or content_length > 16 * 1024 * 1024:
                raise ValueError("Clipboard animation payload has an invalid size.")
            clipboard_text = self.rfile.read(content_length).decode("utf-8")
            payload = _decode_roblox_animation_clipboard(clipboard_text)
            if not isinstance(payload, dict) or not (
                isinstance(payload.get("kfs"), list)
                or isinstance(payload.get("camera_fov"), dict)
            ):
                raise ValueError("Clipboard payload contains no supported animation or camera FOV data.")

            completed = threading.Event()
            result = {"error": None}

            def copy_on_main_thread():
                try:
                    bpy.context.window_manager.clipboard = clipboard_text
                except Exception as exc:
                    result["error"] = str(exc)
                finally:
                    completed.set()
                return None

            bpy.app.timers.register(copy_on_main_thread, first_interval = 0.0)
            if not completed.wait(5.0):
                raise TimeoutError("Blender did not update the clipboard in time.")
            if result["error"]:
                raise RuntimeError(result["error"])
            response = b'{"success":true}'
            self.send_response(200)
        except Exception as exc:
            response = json.dumps({"success": False, "error": str(exc)}).encode("utf-8")
            self.send_response(400)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(response)))
        self.end_headers()
        self.wfile.write(response)

    handler_class.do_POST = do_post_with_clipboard
    _state["roblox_clipboard_endpoint_patch"] = (
        handler_class,
        original_do_post,
        do_post_with_clipboard,
    )
    return True


def _patch_roblox_advanced_panels():
    _patch_roblox_clipboard_endpoint()
    panel_classes = tuple(
        panel_class
        for panel_name in (
            "OBJECT_PT_RbxAnimations",
            "OBJECT_PT_RbxAnimations_Tool",
        )
        if (panel_class := getattr(bpy.types, panel_name, None)) is not None
    )
    if not panel_classes:
        return False

    existing = _state.get("roblox_advanced_panel_patch")
    if existing is not None:
        existing_records = (
            (existing,)
            if isinstance(existing, tuple) and len(existing) == 3
            else tuple(existing)
        )
        if (
            len(existing_records) == len(panel_classes)
            and all(
                panel_class is record[0]
                and panel_class.draw is record[2]
                for panel_class, record in zip(panel_classes, existing_records)
            )
        ):
            return True
        _restore_roblox_advanced_panel_filter()

    patches = []
    for panel_class in panel_classes:
        original_draw = panel_class.draw

        def make_filtered_draw(draw_function, relocate_footer):
            def draw_with_advanced_panel_filter(self, context):
                if (
                    _state.get("extension_update_running", False)
                    or extension_update_guard_active()
                ):
                    update_box = self.layout.box()
                    update_box.label(
                        text = "Extension Update",
                        icon = "FILE_REFRESH",
                    )
                    update_box.label(
                        text = "Updating extensions...",
                    )
                    return
                advanced_mode = getattr(
                    context.window_manager,
                    "roblox_compat_advanced_mode",
                    False,
                )
                hide_advanced = not advanced_mode
                hide_face_controls = not advanced_mode
                hidden_headers = set()
                if hide_advanced:
                    hidden_headers.update(_ADVANCED_ROBLOX_PANEL_HEADERS)
                if hide_face_controls:
                    hidden_headers.update(_FACE_ROBLOX_PANEL_HEADERS)
                if relocate_footer:
                    hidden_headers.update(_RELOCATED_ROBLOX_PANEL_HEADERS)
                layout = _UILayoutProxy(
                    self.layout,
                    frozenset(hidden_headers),
                    hide_advanced = hide_advanced,
                )
                result = draw_function(_PanelDrawProxy(self, layout), context)
                if relocate_footer:
                    connection_layout = _HeaderOnlyUILayoutProxy(
                        self.layout,
                        _RELOCATED_ROBLOX_PANEL_HEADERS,
                        hide_advanced = hide_advanced,
                    )
                    draw_function(
                        _PanelDrawProxy(self, connection_layout),
                        context,
                    )
                    _draw_roblox_animator_footer(self.layout, context)
                return result

            draw_with_advanced_panel_filter.__name__ = draw_function.__name__
            draw_with_advanced_panel_filter.__doc__ = draw_function.__doc__
            draw_with_advanced_panel_filter.__module__ = draw_function.__module__
            draw_with_advanced_panel_filter.__qualname__ = draw_function.__qualname__
            return draw_with_advanced_panel_filter

        patched_draw = make_filtered_draw(
            original_draw,
            panel_class.__name__ == "OBJECT_PT_RbxAnimations",
        )
        panel_class.draw = patched_draw
        patches.append((panel_class, original_draw, patched_draw))

    _state["roblox_advanced_panel_patch"] = tuple(patches)
    return True


def _restore_roblox_nodes_only_default():
    invoke_patch = _state.pop("roblox_genrig_invoke_patch", None)
    if invoke_patch is not None:
        operator_class, original_invoke, patched_invoke = invoke_patch
        if getattr(operator_class, "invoke", None) is patched_invoke:
            operator_class.invoke = original_invoke

    execute_patch = _state.pop("roblox_genrig_execute_patch", None)
    if execute_patch is not None:
        operator_class, original_execute, patched_execute = execute_patch
        if getattr(operator_class, "execute", None) is patched_execute:
            operator_class.execute = original_execute


def _restore_roblox_import_patch():
    metadata_patch = _state.pop("roblox_obj_metadata_decode_patch", None)
    if metadata_patch is not None:
        import_ops, original_base64, proxy = metadata_patch
        if getattr(import_ops, "base64", None) is proxy:
            import_ops.base64 = original_base64

    patch = _state.pop("roblox_import_execute_patch", None)
    if patch is not None:
        operator_class, original_execute, patched_execute = patch
        if getattr(operator_class, "execute", None) is patched_execute:
            operator_class.execute = original_execute

    rbxm_patch = _state.pop("roblox_rbxm_import_execute_patch", None)
    if rbxm_patch is not None:
        rbxm_class, rbxm_original, rbxm_patched = rbxm_patch
        if getattr(rbxm_class, "execute", None) is rbxm_patched:
            rbxm_class.execute = rbxm_original


def _decode_compact_obj_rig_metadata(payload):
    if payload.startswith(b"SL0:"):
        return payload[4:]
    if not payload.startswith(b"SL1:"):
        return payload
    decoded = bytearray()
    position = 4
    while position < len(payload):
        token = payload[position]
        position += 1
        if token < 128:
            count = token + 1
            if position + count > len(payload):
                raise ValueError("Truncated OBJ rig metadata literal")
            decoded.extend(payload[position:position + count])
            position += count
        else:
            if position + 2 > len(payload):
                raise ValueError("Truncated OBJ rig metadata match")
            offset = (payload[position] << 8) | payload[position + 1]
            position += 2
            if offset <= 0 or offset > len(decoded):
                raise ValueError("Invalid OBJ rig metadata match offset")
            for _ in range((token - 128) + 4):
                decoded.append(decoded[-offset])
        if len(decoded) > 16 * 1024 * 1024:
            raise ValueError("OBJ rig metadata exceeds 16 MiB")
    return bytes(decoded)


def _patch_roblox_obj_metadata_decode(import_ops):
    original_base64 = import_ops.base64

    class Base64Proxy:
        def __getattr__(self, name):
            return getattr(original_base64, name)

        def b32decode(self, encoded, casefold=False, map01=None):
            decoded = original_base64.b32decode(encoded, casefold, map01)
            return _decode_compact_obj_rig_metadata(decoded)

    proxy = Base64Proxy()
    import_ops.base64 = proxy
    _state["roblox_obj_metadata_decode_patch"] = (
        import_ops, original_base64, proxy,
    )


def _missing_rbxm_mesh_names(filepath, imported_meshes, module_name):
    """Find external meshes skipped by a completed single-model import."""
    if not filepath or not str(filepath).lower().endswith(".rbxm"):
        return ()
    try:
        from pathlib import Path

        rbxm = importlib.import_module(f"{module_name}.core.rbxm")
        entries = rbxm.parse_rbxm(Path(filepath).read_bytes()).get("partAux") or ()
        imported_refs = {
            str(obj.get("RBXInstRef"))
            for obj in imported_meshes
            if obj.type == "MESH"
            and obj.get("RBXInstRef") is not None
            and len(obj.data.vertices) > 0
            and len(obj.data.polygons) > 0
        }
        return tuple(
            f"{entry.get('name') or entry.get('inst_ref')} [{entry.get('mesh_id')}]"
            for entry in entries
            if entry.get("mesh_id")
            and str(entry.get("inst_ref")) not in imported_refs
        )
    except (AttributeError, ImportError, OSError, RuntimeError, ValueError):
        return ()


def _restore_rbxm_obj_sidecar(filepath, imported_meshes, armatures, module_name, context):
    """Fill unavailable RBXM MeshParts from a matching Studio OBJ/MTL export."""
    from pathlib import Path

    if not filepath or len(armatures) != 1:
        return 0
    sidecar = Path(filepath).with_suffix(".obj")
    if not sidecar.is_file():
        return 0
    try:
        rbxm = importlib.import_module(f"{module_name}.core.rbxm")
        entries = rbxm.parse_rbxm(Path(filepath).read_bytes()).get("partAux") or ()
        available_refs = {
            str(obj.get("RBXInstRef")) for obj in imported_meshes
            if obj.type == "MESH" and obj.get("RBXInstRef") is not None
            and obj.data.polygons
        }
        missing = [entry for entry in entries if entry.get("mesh_id")
                   and str(entry.get("inst_ref")) not in available_refs
                   and entry.get("name") in armatures[0].pose.bones]
        if not missing:
            return 0

        before = {obj.as_pointer() for obj in context.scene.objects}
        selected = tuple(context.selected_objects)
        active = context.view_layer.objects.active
        try:
            bpy.ops.wm.obj_import(
                filepath=str(sidecar), use_split_groups=True,
                forward_axis="NEGATIVE_Z", up_axis="Y",
            )
        except Exception:
            for obj in tuple(context.scene.objects):
                if obj.as_pointer() not in before:
                    bpy.data.objects.remove(obj, do_unlink=True)
            raise
        imported = [obj for obj in context.scene.objects
                    if obj.as_pointer() not in before]
        # Cautioned's OBJ also contains hundreds of Meta cubes. Match only
        # geometry centered on a RBXM part; discard every unmatched object.
        candidates = []
        for obj in imported:
            if obj.type != "MESH" or not obj.data.polygons or obj.name.startswith("Meta"):
                continue
            corners = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
            low = Vector(tuple(min(v[i] for v in corners) for i in range(3)))
            high = Vector(tuple(max(v[i] for v in corners) for i in range(3)))
            candidates.append((obj, (low + high) * 0.5, high - low))

        pairs = []
        for obj, center, size in candidates:
            for entry in missing:
                cf = entry.get("part_cf")
                dims = entry.get("part_size")
                if not cf or not dims:
                    continue
                target = Vector((cf[0], -cf[2], cf[1]))
                distance = (center - target).length
                if distance > 0.12:
                    continue
                expected = Vector((dims[0], dims[2], dims[1]))
                size_error = sum(abs(size[i] - expected[i]) /
                                 max(expected[i], 0.1) for i in range(3))
                pairs.append((distance * 20.0 + size_error, obj, entry))

        rig = armatures[0]
        used_objects, used_refs = set(), set()
        restored = 0
        for _, obj, entry in sorted(pairs, key=lambda item: item[0]):
            ref = str(entry.get("inst_ref"))
            if obj in used_objects or ref in used_refs:
                continue
            used_objects.add(obj)
            used_refs.add(ref)
            obj["RBXOBJGroup"] = obj.name
            obj.name = entry["name"]
            obj["RBXInstRef"] = entry["inst_ref"]
            obj["RBXPartIdx"] = entry.get("part_idx", -1)
            for material in obj.data.materials:
                if material is None or not material.use_nodes:
                    continue
                for node in material.node_tree.nodes:
                    if node.type != "TEX_IMAGE" or node.image is None:
                        continue
                    image = node.image
                    if image.source == "FILE" and image.packed_file is None:
                        image_path = Path(bpy.path.abspath(image.filepath))
                        if image_path.is_file():
                            image.pack()
            if rig.users_collection:
                rig_collection = rig.users_collection[0]
                if obj.name not in rig_collection.objects:
                    rig_collection.objects.link(obj)
                for collection in tuple(obj.users_collection):
                    if collection != rig_collection:
                        collection.objects.unlink(obj)
            world = obj.matrix_world.copy()
            bone = rig.pose.bones[entry["name"]]
            constraint = obj.constraints.new("CHILD_OF")
            constraint.target = rig
            constraint.subtarget = bone.name
            constraint.inverse_matrix = (rig.matrix_world @ bone.matrix).inverted()
            obj.matrix_world = world
            restored += 1
        for obj in imported:
            if obj not in used_objects:
                bpy.data.objects.remove(obj, do_unlink=True)
        bpy.ops.object.select_all(action="DESELECT")
        for obj in selected:
            if obj.name in bpy.data.objects:
                obj.select_set(True)
        if active is not None and active.name in bpy.data.objects:
            context.view_layer.objects.active = active
        context.view_layer.update()
        return restored
    except Exception as exc:
        print(f"[Roblox Animator Utils] OBJ sidecar import failed: {exc}")
        return 0


def _remove_template_environment_after_place_import(
    scene, template_baseplate, template_world, template_sun, template_workspace,
):
    """Discard bundled scenery after a successful place import."""
    if template_baseplate is not None and template_baseplate.name in bpy.data.objects:
        floor_mesh = template_baseplate.data
        bpy.data.objects.remove(template_baseplate, do_unlink=True)
        if floor_mesh.users == 0:
            bpy.data.meshes.remove(floor_mesh)
    if template_sun is not None and template_sun.name in bpy.data.objects:
        sun_data = template_sun.data
        bpy.data.objects.remove(template_sun, do_unlink=True)
        if sun_data.users == 0:
            bpy.data.lights.remove(sun_data)
    if template_world is not None and template_world.name in bpy.data.worlds:
        if scene.world == template_world:
            scene.world = None
        if template_world.users == 0:
            bpy.data.worlds.remove(template_world)
    if (template_workspace is not None
            and template_workspace.name in bpy.data.collections
            and not template_workspace.objects
            and not template_workspace.children):
        bpy.data.collections.remove(template_workspace)
    for material in tuple(bpy.data.materials):
        if material.name in {"Baseplate", "Baseplate Sides"} and material.users == 0:
            bpy.data.materials.remove(material)
    for image in tuple(bpy.data.images):
        if image.name in {"Baseplate.png", "Sky.exr"} and image.users == 0:
            bpy.data.images.remove(image)


def _patch_roblox_rbxm_import_postprocessing():
    """Finish Utils setup after RBXMonkey's new RBXM importer returns."""
    module_name = _roblox_addon_module_name()
    if module_name is None:
        return False
    try:
        import_ops = importlib.import_module(f"{module_name}.operators.import_ops")
        operator_class = import_ops.OBJECT_OT_ImportRbxm
    except (AttributeError, ImportError):
        return False

    existing = _state.get("roblox_rbxm_import_execute_patch")
    if existing is not None:
        if existing[0] is operator_class and operator_class.execute is existing[2]:
            return True
        previous_class, original_execute, patched_execute = existing
        if getattr(previous_class, "execute", None) is patched_execute:
            previous_class.execute = original_execute

    original_execute = operator_class.execute

    def execute_with_rbxm_setup(self, context):
        # Capture bundled scene assets before import so the place's own assets
        # remain untouched even if Blender gives them similar names.
        template_baseplate = context.scene.objects.get("Baseplate")
        if template_baseplate is not None and (
            template_baseplate.type != "MESH"
            or not any(
                _is_bundled_template_baseplate_material(slot.material)
                for slot in template_baseplate.material_slots
                if slot.material is not None
            )
        ):
            template_baseplate = None
        template_workspace = (
            next(iter(template_baseplate.users_collection), None)
            if template_baseplate is not None else None
        )
        template_world = context.scene.world
        if template_world is not None and not (
            template_world.name == "Sky"
            and template_world.node_tree is not None
            and any(
                node.type == "TEX_ENVIRONMENT"
                and getattr(getattr(node, "image", None), "name", "") == "Sky.exr"
                for node in template_world.node_tree.nodes
            )
        ):
            template_world = None
        template_sun = context.scene.objects.get("Sun")
        if template_sun is not None and not (
            template_world is not None and template_sun.type == "LIGHT"
        ):
            template_sun = None
        is_place_import = str(getattr(self, "filepath", "")).lower().endswith(".rbxl")
        if not is_place_import:
            is_place_import = any(
                str(getattr(item, "name", "")).lower().endswith(".rbxl")
                for item in getattr(self, "files", ())
            )
        previous_armatures = {
            obj.as_pointer() for obj in context.scene.objects if obj.type == "ARMATURE"
        }
        previous_objects = {
            obj.as_pointer() for obj in context.scene.objects
        }
        previous_meshes = {
            obj.as_pointer() for obj in context.scene.objects if obj.type == "MESH"
        }
        previous_worlds = {world.as_pointer() for world in bpy.data.worlds}
        result = original_execute(self, context)
        if "FINISHED" not in result:
            return result
        if is_place_import:
            if template_world is not None and context.scene.world == template_world:
                imported_worlds = tuple(
                    world for world in bpy.data.worlds
                    if world.as_pointer() not in previous_worlds
                )
                if imported_worlds:
                    context.scene.world = imported_worlds[-1]
            _remove_template_environment_after_place_import(
                context.scene, template_baseplate, template_world,
                template_sun, template_workspace,
            )
        new_armatures = tuple(
            obj for obj in context.scene.objects
            if obj.type == "ARMATURE" and obj.as_pointer() not in previous_armatures
        )
        _clean_imported_armature_names(new_armatures)
        _refresh_roblox_armature_list(context, force = True)
        # The RBXM operator returns with face and weld helper bones visible.
        # Apply compatibility before the next viewport draw, so selecting or
        # framing the rig never shows those helpers in simple mode.
        _apply_roblox_compatibility(context.scene, ignore_update_guard=True)
        _schedule_roblox_compatibility_scan(delay = 0.05)
        new_meshes = tuple(
            obj for obj in context.scene.objects
            if obj.type == "MESH" and obj.as_pointer() not in previous_meshes
        )
        restored = _restore_rbxm_obj_sidecar(
            getattr(self, "filepath", ""), new_meshes,
            new_armatures, module_name, context,
        )
        if restored:
            print(f"[Roblox Animator Utils] Restored {restored} mesh(es) from matching OBJ sidecar.")
            new_meshes = tuple(
                obj for obj in context.scene.objects
                if obj.type == "MESH" and obj.as_pointer() not in previous_meshes
            )
        _process_imported_rig_materials(
            context,
            (obj for obj in context.scene.objects
             if obj.as_pointer() not in previous_objects),
        )
        missing = _missing_rbxm_mesh_names(
            getattr(self, "filepath", ""), new_meshes, module_name
        )
        if missing:
            print("[Roblox Animator Utils] RBXM meshes unavailable:", *missing, sep="\n  ")
            try:
                auth = importlib.import_module(f"{module_name}.core.auth")
                if not auth.is_online_access_allowed():
                    guidance = "Enable Blender Online Access, then log in under Roblox Account."
                elif not auth.has_saved_login():
                    guidance = "Log in under Roblox Account and import again; some assets also need owner permission."
                else:
                    guidance = "Grant this Roblox account access to the listed mesh assets, then import again."
            except (AttributeError, ImportError, RuntimeError):
                guidance = "Check Roblox asset permissions for the missing meshes."
            self.report(
                {"WARNING"},
                f"RBXM import missing {len(missing)} external MeshPart(s). "
                f"{guidance} Asset IDs are listed in the console. "
                "Place the Studio OBJ and MTL beside the RBXM with the same base name to restore local meshes.",
            )
        if new_armatures:
            if not _state.get("staticaliza_multi_obj_import_active", False):
                _schedule_imported_rig_framing(new_armatures, context)
                _schedule_roblox_rigs_pose_mode(new_armatures)
                _schedule_rig_collection_collapse()
        return result

    operator_class.execute = execute_with_rbxm_setup
    _state["roblox_rbxm_import_execute_patch"] = (
        operator_class, original_execute, execute_with_rbxm_setup,
    )
    return True


def _restore_roblox_unparent_patch():
    stored = _state.pop("roblox_unparent_execute_patch", None)
    if stored is None:
        return
    patches = (
        stored
        if stored and isinstance(stored[0], tuple)
        else (stored,)
    )
    for operator_class, original_execute, patched_execute in patches:
        if getattr(operator_class, "execute", None) is patched_execute:
            operator_class.execute = original_execute


def _patch_roblox_unparent_visibility():
    """Retire legacy operator patches left by an older hot-loaded generation."""
    _restore_roblox_unparent_patch()
    return True


def _patch_roblox_import_auto_generation():
    module_name = _roblox_addon_module_name()
    if module_name is None:
        return False

    try:
        import_ops = importlib.import_module(f"{module_name}.operators.import_ops")
        rig_ops = importlib.import_module(f"{module_name}.operators.rig_ops")
        operator_class = import_ops.OBJECT_OT_ImportModel
    except (AttributeError, ImportError):
        return False

    existing = _state.get("roblox_import_execute_patch")
    if existing is not None:
        if existing[0] is operator_class and operator_class.execute is existing[2]:
            return True
        _restore_roblox_import_patch()

    _patch_roblox_obj_metadata_decode(import_ops)
    original_execute = operator_class.execute

    def execute_with_local_y_auto_generation(self, context):
        hide_advanced = not getattr(
            context.window_manager,
            "roblox_compat_advanced_mode",
            False,
        )
        previous_armatures = {
            obj.as_pointer() for obj in context.scene.objects if obj.type == "ARMATURE"
        }
        previous_meshes = {
            obj.as_pointer() for obj in context.scene.objects if obj.type == "MESH"
        }
        previous_meta = {
            obj.as_pointer()
            for obj in context.scene.objects
            if obj.type == "EMPTY" and "RigMeta" in obj
        }
        previous_collections = {
            collection.as_pointer() for collection in bpy.data.collections
        }
        selected_rigging_type = str(
            getattr(
                context.window_manager,
                "roblox_import_rigging_type",
                "LOCAL_YAXIS_EXTEND",
            )
        )

        original_create_rig = import_ops.create_rig
        if hide_advanced:
            def create_selected_rig(_rigging_type, rig_meta_name):
                return original_create_rig(selected_rigging_type, rig_meta_name)

            import_ops.create_rig = create_selected_rig

        try:
            result = original_execute(self, context)
        finally:
            if hide_advanced:
                import_ops.create_rig = original_create_rig

        if "FINISHED" in result:
            isolated_images, isolated_materials = (
                _isolate_newly_imported_rig_textures(previous_collections)
            )
            if isolated_images:
                print(
                    "[Roblox Animator Utils] Isolated "
                    f"{isolated_images} texture node(s) across "
                    f"{isolated_materials} imported material(s)."
                )

        if "FINISHED" not in result:
            return result

        _merge_imported_decal_faces(
            obj for obj in context.scene.objects
            if obj.type == "MESH" and obj.as_pointer() not in previous_meshes
        )

        for obj in context.scene.objects:
            if (obj.type == "EMPTY" and "RigMeta" in obj
                    and obj.as_pointer() not in previous_meta):
                _hide_roblox_rig_meta(obj)

        # Metadata and face planes are ready here. Prepare materials before
        # control returns to Blender so the user never sees the raw OBJ maps.
        _smart_material_import_scan(context.scene)

        new_armatures = [
            obj
            for obj in context.scene.objects
            if obj.type == "ARMATURE" and obj.as_pointer() not in previous_armatures
        ]
        if new_armatures:
            _clean_imported_armature_names(new_armatures)
            _smart_remove_invisible_host_faces(context.scene)
            _state.setdefault("roblox_constraints_new_rigs", set()).update(
                armature.as_pointer() for armature in new_armatures
            )
            _refresh_roblox_armature_list(context, force = True)
            _schedule_imported_rig_framing(new_armatures, context)
            _schedule_roblox_rigs_pose_mode(new_armatures)
            _schedule_rig_collection_collapse()
        if not hide_advanced:
            return result

        new_meta_names = [
            obj.name
            for obj in context.scene.objects
            if obj.type == "EMPTY"
            and "RigMeta" in obj
            and obj.as_pointer() not in previous_meta
        ]

        if new_armatures or not new_meta_names:
            _schedule_roblox_compatibility_scan(delay = 0.05)
            return result

        scene_name = context.scene.name

        def generate_imported_rig():
            scene = bpy.data.scenes.get(scene_name)
            if scene is None:
                return None

            armatures_before_generation = {
                obj.as_pointer()
                for obj in scene.objects
                if obj.type == "ARMATURE"
            }

            for meta_name in new_meta_names:
                meta = scene.objects.get(meta_name)
                if meta is None or "RigMeta" not in meta:
                    continue
                try:
                    rig_ops.create_rig(selected_rigging_type, meta_name)
                except Exception as exc:
                    print(
                        "[Roblox Animator Utils] Automatic rig generation "
                        f"failed for {selected_rigging_type}: {exc}"
                    )

            generated_armatures = [
                obj
                for obj in scene.objects
                if obj.type == "ARMATURE"
                and obj.as_pointer() not in armatures_before_generation
            ]

            if generated_armatures:
                _clean_imported_armature_names(generated_armatures)
                _smart_remove_invisible_host_faces(scene)
                _refresh_roblox_armature_list(bpy.context, force = True)
                _state.setdefault("roblox_constraints_new_rigs", set()).update(
                    armature.as_pointer() for armature in generated_armatures
                )

            _schedule_roblox_compatibility_scan(delay = 0.05)
            if generated_armatures:
                if not _state.get("staticaliza_multi_obj_import_active", False):
                    _schedule_imported_rig_framing(
                        generated_armatures,
                        bpy.context,
                    )
                    _schedule_roblox_rigs_pose_mode(generated_armatures)
                    _schedule_rig_collection_collapse()
            return None

        # Build the armature in this import transaction. Deferring it to a
        # timer exposes raw OBJ materials and causes a second viewport stall.
        generate_imported_rig()
        return result

    execute_with_local_y_auto_generation.__name__ = original_execute.__name__
    execute_with_local_y_auto_generation.__doc__ = original_execute.__doc__
    execute_with_local_y_auto_generation.__module__ = original_execute.__module__
    execute_with_local_y_auto_generation.__qualname__ = original_execute.__qualname__

    operator_class.execute = execute_with_local_y_auto_generation
    _state["roblox_import_execute_patch"] = (
        operator_class,
        original_execute,
        execute_with_local_y_auto_generation,
    )
    existing_armatures = tuple(
        obj for obj in bpy.context.scene.objects if obj.type == "ARMATURE"
    )
    _clean_imported_armature_names(existing_armatures)
    _refresh_roblox_armature_list(bpy.context, force = True)
    return True
