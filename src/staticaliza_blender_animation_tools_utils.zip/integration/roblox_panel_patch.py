"""Install and restore Roblox Animator panel integration patches."""

from ..core.runtime import *  # noqa: F403

def _restore_roblox_advanced_panel_filter():
    patches = _state.pop("roblox_advanced_panel_patch", None)
    if patches is None:
        return
    if isinstance(patches, tuple) and len(patches) == 3:
        patches = (patches,)
    for panel_class, original_draw, patched_draw in tuple(patches):
        if getattr(panel_class, "draw", None) is patched_draw:
            panel_class.draw = original_draw


def _restore_roblox_clipboard_endpoint_patch():
    patch = _state.pop("roblox_clipboard_endpoint_patch", None)
    if patch is None:
        return
    handler_class, original_do_post, patched_do_post = patch
    if getattr(handler_class, "do_POST", None) is patched_do_post:
        handler_class.do_POST = original_do_post


def _patch_roblox_clipboard_endpoint():
    module_name = _roblox_addon_module_name()
    if module_name is None:
        return False
    try:
        handler_module = importlib.import_module(f"{module_name}.server.handler")
        handler_class = handler_module.AnimationHandler
    except (AttributeError, ImportError):
        return False

    existing = _state.get("roblox_clipboard_endpoint_patch")
    if existing is not None:
        if existing[0] is handler_class and handler_class.do_POST is existing[2]:
            return True
        _restore_roblox_clipboard_endpoint_patch()

    original_do_post = handler_class.do_POST

    def do_post_with_clipboard(self):
        if str(getattr(self, "path", "")).split("?", 1)[0] != "/staticaliza_clipboard":
            return original_do_post(self)
        try:
            content_length = int(self.headers.get("Content-Length", "0"))
            if content_length <= 0 or content_length > 16 * 1024 * 1024:
                raise ValueError("Clipboard animation payload has an invalid size.")
            clipboard_text = self.rfile.read(content_length).decode("utf-8")
            payload = _decode_roblox_animation_clipboard(clipboard_text)
            if not isinstance(payload, dict) or not (
                isinstance(payload.get("kfs"), list)
                or isinstance(payload.get("camera_fov"), dict)
            ):
                raise ValueError("Clipboard payload contains no supported animation or camera FOV data.")

            completed = threading.Event()
            result = {"error": None}

            def copy_on_main_thread():
                try:
                    bpy.context.window_manager.clipboard = clipboard_text
                except Exception as exc:
                    result["error"] = str(exc)
                finally:
                    completed.set()
                return None

            bpy.app.timers.register(copy_on_main_thread, first_interval = 0.0)
            if not completed.wait(5.0):
                raise TimeoutError("Blender did not update the clipboard in time.")
            if result["error"]:
                raise RuntimeError(result["error"])
            response = b'{"success":true}'
            self.send_response(200)
        except Exception as exc:
            response = json.dumps({"success": False, "error": str(exc)}).encode("utf-8")
            self.send_response(400)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(response)))
        self.end_headers()
        self.wfile.write(response)

    handler_class.do_POST = do_post_with_clipboard
    _state["roblox_clipboard_endpoint_patch"] = (
        handler_class,
        original_do_post,
        do_post_with_clipboard,
    )
    return True


def _patch_roblox_advanced_panels():
    _patch_roblox_clipboard_endpoint()
    panel_classes = tuple(
        panel_class
        for panel_name in (
            "OBJECT_PT_RbxAnimations",
            "OBJECT_PT_RbxAnimations_Tool",
        )
        if (panel_class := getattr(bpy.types, panel_name, None)) is not None
    )
    if not panel_classes:
        return False

    existing = _state.get("roblox_advanced_panel_patch")
    if existing is not None:
        existing_records = (
            (existing,)
            if isinstance(existing, tuple) and len(existing) == 3
            else tuple(existing)
        )
        if (
            len(existing_records) == len(panel_classes)
            and all(
                panel_class is record[0]
                and panel_class.draw is record[2]
                for panel_class, record in zip(panel_classes, existing_records)
            )
        ):
            return True
        _restore_roblox_advanced_panel_filter()

    patches = []
    for panel_class in panel_classes:
        original_draw = panel_class.draw

        def make_filtered_draw(draw_function, relocate_footer):
            def draw_with_advanced_panel_filter(self, context):
                if (
                    _state.get("extension_update_running", False)
                    or extension_update_guard_active()
                ):
                    update_box = self.layout.box()
                    update_box.label(
                        text = "Extension Update",
                        icon = "FILE_REFRESH",
                    )
                    update_box.label(
                        text = "Updating extensions...",
                    )
                    return
                advanced_mode = getattr(
                    context.window_manager,
                    "roblox_compat_advanced_mode",
                    False,
                )
                hide_advanced = not advanced_mode
                hide_face_controls = not advanced_mode
                hidden_headers = set()
                if hide_advanced:
                    hidden_headers.update(_ADVANCED_ROBLOX_PANEL_HEADERS)
                if hide_face_controls:
                    hidden_headers.update(_FACE_ROBLOX_PANEL_HEADERS)
                if relocate_footer:
                    hidden_headers.update(_RELOCATED_ROBLOX_PANEL_HEADERS)
                layout = _UILayoutProxy(
                    self.layout,
                    frozenset(hidden_headers),
                    hide_advanced = hide_advanced,
                )
                result = draw_function(_PanelDrawProxy(self, layout), context)
                if relocate_footer:
                    connection_layout = _HeaderOnlyUILayoutProxy(
                        self.layout,
                        _RELOCATED_ROBLOX_PANEL_HEADERS,
                        hide_advanced = hide_advanced,
                    )
                    draw_function(
                        _PanelDrawProxy(self, connection_layout),
                        context,
                    )
                    _draw_roblox_animator_footer(self.layout, context)
                return result

            draw_with_advanced_panel_filter.__name__ = draw_function.__name__
            draw_with_advanced_panel_filter.__doc__ = draw_function.__doc__
            draw_with_advanced_panel_filter.__module__ = draw_function.__module__
            draw_with_advanced_panel_filter.__qualname__ = draw_function.__qualname__
            return draw_with_advanced_panel_filter

        patched_draw = make_filtered_draw(
            original_draw,
            panel_class.__name__ == "OBJECT_PT_RbxAnimations",
        )
        panel_class.draw = patched_draw
        patches.append((panel_class, original_draw, patched_draw))

    _state["roblox_advanced_panel_patch"] = tuple(patches)
    return True


def _restore_roblox_nodes_only_default():
    invoke_patch = _state.pop("roblox_genrig_invoke_patch", None)
    if invoke_patch is not None:
        operator_class, original_invoke, patched_invoke = invoke_patch
        if getattr(operator_class, "invoke", None) is patched_invoke:
            operator_class.invoke = original_invoke

    execute_patch = _state.pop("roblox_genrig_execute_patch", None)
    if execute_patch is not None:
        operator_class, original_execute, patched_execute = execute_patch
        if getattr(operator_class, "execute", None) is patched_execute:
            operator_class.execute = original_execute


def _restore_roblox_import_patch():
    patch = _state.pop("roblox_import_execute_patch", None)
    if patch is not None:
        operator_class, original_execute, patched_execute = patch
        if getattr(operator_class, "execute", None) is patched_execute:
            operator_class.execute = original_execute

    rbxm_patch = _state.pop("roblox_rbxm_import_execute_patch", None)
    if rbxm_patch is not None:
        rbxm_class, rbxm_original, rbxm_patched = rbxm_patch
        if getattr(rbxm_class, "execute", None) is rbxm_patched:
            rbxm_class.execute = rbxm_original


def _missing_rbxm_mesh_names(filepath, imported_meshes, module_name):
    """Find external meshes skipped by a completed single-model import."""
    if not filepath or not str(filepath).lower().endswith(".rbxm"):
        return ()
    try:
        from pathlib import Path

        rbxm = importlib.import_module(f"{module_name}.core.rbxm")
        entries = rbxm.parse_rbxm(Path(filepath).read_bytes()).get("partAux") or ()
        imported_refs = {
            str(obj.get("RBXInstRef"))
            for obj in imported_meshes
            if obj.type == "MESH" and obj.get("RBXInstRef") is not None
        }
        return tuple(
            str(entry.get("name") or entry.get("inst_ref"))
            for entry in entries
            if entry.get("mesh_id")
            and str(entry.get("inst_ref")) not in imported_refs
        )
    except (AttributeError, ImportError, OSError, RuntimeError, ValueError):
        return ()


def _patch_roblox_rbxm_import_postprocessing():
    """Finish Utils setup after RBXMonkey's new RBXM importer returns."""
    module_name = _roblox_addon_module_name()
    if module_name is None:
        return False
    try:
        import_ops = importlib.import_module(f"{module_name}.operators.import_ops")
        operator_class = import_ops.OBJECT_OT_ImportRbxm
    except (AttributeError, ImportError):
        return False

    existing = _state.get("roblox_rbxm_import_execute_patch")
    if existing is not None:
        if existing[0] is operator_class and operator_class.execute is existing[2]:
            return True
        previous_class, original_execute, patched_execute = existing
        if getattr(previous_class, "execute", None) is patched_execute:
            previous_class.execute = original_execute

    original_execute = operator_class.execute

    def execute_with_rbxm_setup(self, context):
        # Keep the stock template floor available for rig-only imports, but
        # remove it from view when importing an entire place with its own
        # ground. Capture the object before import so a place's own Baseplate
        # with the same name can never be hidden by this postprocess.
        template_baseplate = context.scene.objects.get("Baseplate")
        if template_baseplate is not None and (
            template_baseplate.type != "MESH"
            or not any(
                collection.name == "Workspace"
                for collection in template_baseplate.users_collection
            )
        ):
            template_baseplate = None
        is_place_import = str(getattr(self, "filepath", "")).lower().endswith(".rbxl")
        if not is_place_import:
            is_place_import = any(
                str(getattr(item, "name", "")).lower().endswith(".rbxl")
                for item in getattr(self, "files", ())
            )
        previous_armatures = {
            obj.as_pointer() for obj in context.scene.objects if obj.type == "ARMATURE"
        }
        previous_meshes = {
            obj.as_pointer() for obj in context.scene.objects if obj.type == "MESH"
        }
        result = original_execute(self, context)
        if "FINISHED" not in result:
            return result
        if is_place_import and template_baseplate is not None:
            template_baseplate.hide_set(True)
            template_baseplate.hide_render = True
        new_armatures = tuple(
            obj for obj in context.scene.objects
            if obj.type == "ARMATURE" and obj.as_pointer() not in previous_armatures
        )
        _refresh_roblox_armature_list(context, force = True)
        # The RBXM operator returns with face and weld helper bones visible.
        # Apply compatibility before the next viewport draw, so selecting or
        # framing the rig never shows those helpers in simple mode.
        _apply_roblox_compatibility(context.scene, ignore_update_guard=True)
        _schedule_roblox_compatibility_scan(delay = 0.05)
        new_meshes = tuple(
            obj for obj in context.scene.objects
            if obj.type == "MESH" and obj.as_pointer() not in previous_meshes
        )
        missing = _missing_rbxm_mesh_names(
            getattr(self, "filepath", ""), new_meshes, module_name
        )
        if missing:
            self.report(
                {"WARNING"},
                f"RBXM import missing {len(missing)} external MeshPart(s). "
                "See AssetDelivery errors in the console; a Studio OBJ export embeds geometry.",
            )
        if new_armatures:
            _schedule_imported_rig_framing(new_armatures, context)
            _schedule_roblox_rigs_pose_mode(new_armatures)
            _schedule_rig_collection_collapse()
        return result

    operator_class.execute = execute_with_rbxm_setup
    _state["roblox_rbxm_import_execute_patch"] = (
        operator_class, original_execute, execute_with_rbxm_setup,
    )
    return True


def _restore_roblox_unparent_patch():
    stored = _state.pop("roblox_unparent_execute_patch", None)
    if stored is None:
        return
    patches = (
        stored
        if stored and isinstance(stored[0], tuple)
        else (stored,)
    )
    for operator_class, original_execute, patched_execute in patches:
        if getattr(operator_class, "execute", None) is patched_execute:
            operator_class.execute = original_execute


def _patch_roblox_unparent_visibility():
    """Retire legacy operator patches left by an older hot-loaded generation."""
    _restore_roblox_unparent_patch()
    return True


def _patch_roblox_import_auto_generation():
    module_name = _roblox_addon_module_name()
    if module_name is None:
        return False

    try:
        import_ops = importlib.import_module(f"{module_name}.operators.import_ops")
        rig_ops = importlib.import_module(f"{module_name}.operators.rig_ops")
        operator_class = import_ops.OBJECT_OT_ImportModel
    except (AttributeError, ImportError):
        return False

    existing = _state.get("roblox_import_execute_patch")
    if existing is not None:
        if existing[0] is operator_class and operator_class.execute is existing[2]:
            return True
        _restore_roblox_import_patch()

    original_execute = operator_class.execute

    def execute_with_local_y_auto_generation(self, context):
        hide_advanced = not getattr(
            context.window_manager,
            "roblox_compat_advanced_mode",
            False,
        )
        previous_armatures = {
            obj.as_pointer() for obj in context.scene.objects if obj.type == "ARMATURE"
        }
        previous_meta = {
            obj.as_pointer()
            for obj in context.scene.objects
            if obj.type == "EMPTY" and "RigMeta" in obj
        }
        previous_collections = {
            collection.as_pointer() for collection in bpy.data.collections
        }
        selected_rigging_type = str(
            getattr(
                context.window_manager,
                "roblox_import_rigging_type",
                "LOCAL_YAXIS_EXTEND",
            )
        )

        original_create_rig = import_ops.create_rig
        if hide_advanced:
            def create_selected_rig(_rigging_type, rig_meta_name):
                return original_create_rig(selected_rigging_type, rig_meta_name)

            import_ops.create_rig = create_selected_rig

        try:
            result = original_execute(self, context)
        finally:
            if hide_advanced:
                import_ops.create_rig = original_create_rig

        if "FINISHED" in result:
            isolated_images, isolated_materials = (
                _isolate_newly_imported_rig_textures(previous_collections)
            )
            if isolated_images:
                print(
                    "[Roblox Animator Utils] Isolated "
                    f"{isolated_images} texture node(s) across "
                    f"{isolated_materials} imported material(s)."
                )

        if "FINISHED" not in result:
            return result

        new_armatures = [
            obj
            for obj in context.scene.objects
            if obj.type == "ARMATURE" and obj.as_pointer() not in previous_armatures
        ]
        if new_armatures:
            _state.setdefault("roblox_constraints_new_rigs", set()).update(
                armature.as_pointer() for armature in new_armatures
            )
            _refresh_roblox_armature_list(context, force = True)
            _schedule_imported_rig_framing(new_armatures, context)
            _schedule_roblox_rigs_pose_mode(new_armatures)
            _schedule_rig_collection_collapse()
        if not hide_advanced:
            return result

        new_meta_names = [
            obj.name
            for obj in context.scene.objects
            if obj.type == "EMPTY"
            and "RigMeta" in obj
            and obj.as_pointer() not in previous_meta
        ]

        if new_armatures or not new_meta_names:
            _schedule_roblox_compatibility_scan(delay = 0.05)
            _schedule_smart_material_import_scan(delay = 0.05)
            return result

        scene_name = context.scene.name

        def generate_imported_rig():
            scene = bpy.data.scenes.get(scene_name)
            if scene is None:
                return None

            armatures_before_generation = {
                obj.as_pointer()
                for obj in scene.objects
                if obj.type == "ARMATURE"
            }

            for meta_name in new_meta_names:
                meta = scene.objects.get(meta_name)
                if meta is None or "RigMeta" not in meta:
                    continue
                try:
                    rig_ops.create_rig(selected_rigging_type, meta_name)
                except Exception as exc:
                    print(
                        "[Roblox Animator Utils] Automatic rig generation "
                        f"failed for {selected_rigging_type}: {exc}"
                    )

            generated_armatures = [
                obj
                for obj in scene.objects
                if obj.type == "ARMATURE"
                and obj.as_pointer() not in armatures_before_generation
            ]

            if generated_armatures:
                _state.setdefault("roblox_constraints_new_rigs", set()).update(
                    armature.as_pointer() for armature in generated_armatures
                )

            _schedule_roblox_compatibility_scan(delay = 0.05)
            _schedule_smart_material_import_scan(delay = 0.05)
            if generated_armatures:
                _schedule_imported_rig_framing(
                    generated_armatures,
                    bpy.context,
                )
                _schedule_roblox_rigs_pose_mode(generated_armatures)
                _schedule_rig_collection_collapse()
            return None

        register_owned_timer(generate_imported_rig, first_interval = 0.1)
        return result

    execute_with_local_y_auto_generation.__name__ = original_execute.__name__
    execute_with_local_y_auto_generation.__doc__ = original_execute.__doc__
    execute_with_local_y_auto_generation.__module__ = original_execute.__module__
    execute_with_local_y_auto_generation.__qualname__ = original_execute.__qualname__

    operator_class.execute = execute_with_local_y_auto_generation
    _state["roblox_import_execute_patch"] = (
        operator_class,
        original_execute,
        execute_with_local_y_auto_generation,
    )
    return True
