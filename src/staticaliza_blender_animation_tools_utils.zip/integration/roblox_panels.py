"""Non-destructive monkey patches for the external Roblox Animator add-on."""

import base64
import math
import re
import threading
import zlib

from ..core.runtime import *  # noqa: F403

_ADVANCED_ROBLOX_PANEL_HEADERS = frozenset({"Roblox Account", "UGC Emote Validation"})
_FACE_ROBLOX_PANEL_HEADERS = frozenset({"Face Controls"})
_RELOCATED_ROBLOX_PANEL_HEADERS = frozenset({"Connection"})
_ADVANCED_ROBLOX_OPERATORS = frozenset({
    "object.rbxanims_genrig",
    "object.rbxanims_autoconstraint",
    "object.rbxanims_manualconstraint",
    "object.rbxanims_toggle_weld_bones",
    "object.rbxanims_toggle_com",
    "object.rbxanims_toggle_com_grid",
    "object.rbxanims_edit_com_weights",
    "object.rbxanims_mapkeyframes",
    "object.rbxanims_applytransform",
    "object.rbxanims_bake_file",
    "object.rbxanims_importfbxanimation",
})
_ADVANCED_ROBLOX_PROPERTIES = frozenset({
    "rbx_auto_deform_scale",
    "rbx_deform_rig_scale",
    "rbx_full_range_bake",
})
_ADVANCED_ROBLOX_LABELS = frozenset({"Center of Mass:"})
_SUPPRESSED_ROBLOX_LABELS = frozenset({
    "No Roblox Rig Project Found",
    "No Roblox Rig Project Found.",
})
_EMPTY_ARMATURE_ROBLOX_LABELS = frozenset({
    "No Armatures in Scene",
    "No Armatures in Scene.",
    "No Armatures in this Scene",
    "No Armatures in this Scene.",
})
_ROBLOX_HEADER_ICONS = {
    "Armature Operations": "ARMATURE_DATA",
}
ROBLOX_ANIMATION_LOOP_PROPERTY = "roblox_animation_loop"
ROBLOX_ANIMATION_PRIORITY_PROPERTY = "roblox_animation_priority"
ROBLOX_ANIMATION_PRIORITY_ITEMS = (
    ("Core", "Core", "Lowest priority; used by Roblox default animations"),
    ("Idle", "Idle", "Priority for idle animations"),
    ("Movement", "Movement", "Priority for locomotion animations"),
    ("Action", "Action", "Priority for actions that override idle and movement"),
    ("Action2", "Action 2", "Higher priority than Action"),
    ("Action3", "Action 3", "Higher priority than Action 2"),
    ("Action4", "Action 4", "Highest Roblox animation priority"),
)


class ROBLOX_ANIMATOR_UTILS_OT_edit_animation_length(bpy.types.Operator):
    bl_idname = "roblox_animator_utils.edit_animation_length"
    bl_label = "Animation Length"
    bl_description = "Edit animation length as frames or frame-accurate time"
    bl_options = {"REGISTER", "UNDO"}

    value: bpy.props.StringProperty(name = "Time")

    def invoke(self, context, _event):
        self.value = _get_roblox_animation_length(context.scene)
        return context.window_manager.invoke_props_dialog(self, width = 220)

    def draw(self, _context):
        self.layout.prop(self, "value", text = "Time")

    def execute(self, context):
        try:
            _parse_animation_length(
                self.value,
                _scene_nominal_fps(context.scene),
            )
        except (TypeError, ValueError) as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        setattr(context.scene, ROBLOX_ANIMATION_LENGTH_PROPERTY, self.value)
        return {"FINISHED"}


_ROBLOX_INTERPOLATION_MAP = {
    "Linear": "LINEAR", "Constant": "CONSTANT", "Elastic": "ELASTIC",
    "Bounce": "BOUNCE", "Sine": "SINE", "Quad": "QUAD",
    "Cubic": "CUBIC", "CubicV2": "CUBIC", "Quart": "QUART",
    "Quint": "QUINT", "Expo": "EXPO", "Circular": "CIRC", "Back": "BACK",
}
_ROBLOX_EASING_MAP = {
    "In": "EASE_IN", "Out": "EASE_OUT", "InOut": "EASE_IN_OUT",
}


def _decode_roblox_animation_clipboard(text):
    """Decode supported animation and camera-FOV clipboard payloads."""
    text = str(text or "").strip()
    if not text:
        raise ValueError("The clipboard is empty.")
    try:
        payload = json.loads(text)
    except (TypeError, ValueError, json.JSONDecodeError):
        try:
            decoded = zlib.decompress(base64.b64decode(text)).decode("utf-8")
            payload = json.loads(decoded)
        except Exception as exc:
            raise ValueError(
                "Clipboard data is not supported Roblox animation or camera FOV data."
            ) from exc
    if not isinstance(payload, dict) or not (
        isinstance(payload.get("kfs"), list)
        or isinstance(payload.get("camera_fov"), dict)
    ):
        raise ValueError("Clipboard data has no supported animation or camera FOV data.")
    return payload


def _canonical_bone_name(name):
    return re.sub(r"[^a-z0-9]", "", str(name).casefold())


def _roblox_bone_lookup(armature):
    exact = {bone.name: bone for bone in armature.pose.bones}
    folded = {}
    canonical = {}
    ambiguous_folded = set()
    ambiguous_canonical = set()
    for bone in armature.pose.bones:
        folded_name = bone.name.casefold()
        canonical_name = _canonical_bone_name(bone.name)
        if folded_name in folded:
            ambiguous_folded.add(folded_name)
        else:
            folded[folded_name] = bone
        if canonical_name in canonical:
            ambiguous_canonical.add(canonical_name)
        else:
            canonical[canonical_name] = bone
    for name in ambiguous_folded:
        folded.pop(name, None)
    for name in ambiguous_canonical:
        canonical.pop(name, None)

    def resolve(name):
        return (
            exact.get(name)
            or folded.get(str(name).casefold())
            or canonical.get(_canonical_bone_name(name))
        )

    return resolve


def _ensure_roblox_import_action(armature, name):
    animation_data = armature.animation_data_create()
    # A clipboard import is a complete animation destination. Reusing the
    # currently assigned layered action can put keys into a stale slot or
    # leave an NLA strip evaluating instead, making populated channels inert.
    # Keep the old datablock intact for Blender Undo, but bind a fresh action.
    action = bpy.data.actions.new(name = name)
    animation_data.action = action
    if hasattr(animation_data, "use_nla"):
        animation_data.use_nla = False
    slots = getattr(action, "slots", None)
    if slots is not None and hasattr(animation_data, "action_slot"):
        slot = getattr(animation_data, "action_slot", None)
        if slot is None:
            try:
                slot = slots.new(id_type = "OBJECT", name = f"OB{armature.name}")
            except TypeError:
                slot = slots.new(id_type = "OBJECT")
            try:
                animation_data.action_slot = slot
            except (AttributeError, RuntimeError, TypeError):
                pass
    return action


def _roblox_import_action_fcurves(core_utils, action):
    channelbag = core_utils.get_action_channelbag(action)
    if channelbag is not None and hasattr(channelbag, "fcurves"):
        return channelbag.fcurves
    return getattr(action, "fcurves", ())


def _replace_bone_keys(core_utils, action, pose_bone, frame, easing_style, easing_direction):
    escaped = bpy.utils.escape_identifier(pose_bone.name)
    paths = {
        f'pose.bones["{escaped}"].location',
        f'pose.bones["{escaped}"].rotation_quaternion',
        f'pose.bones["{escaped}"].scale',
    }
    for fcurve in _roblox_import_action_fcurves(core_utils, action):
        if fcurve.data_path not in paths:
            continue
        for point in tuple(fcurve.keyframe_points):
            if abs(float(point.co.x) - float(frame)) <= 1e-4:
                fcurve.keyframe_points.remove(point, fast = True)

    pose_bone.keyframe_insert("location", frame = frame, group = pose_bone.name)
    pose_bone.keyframe_insert("rotation_quaternion", frame = frame, group = pose_bone.name)
    pose_bone.keyframe_insert("scale", frame = frame, group = pose_bone.name)

    interpolation = _ROBLOX_INTERPOLATION_MAP.get(easing_style, "LINEAR")
    easing = _ROBLOX_EASING_MAP.get(easing_direction, "EASE_IN")
    for fcurve in _roblox_import_action_fcurves(core_utils, action):
        if fcurve.data_path not in paths:
            continue
        fcurve.update()
        for point in fcurve.keyframe_points:
            if abs(float(point.co.x) - float(frame)) > 1e-4:
                continue
            point.type = "KEYFRAME"
            point.interpolation = interpolation
            if interpolation not in {"LINEAR", "CONSTANT"}:
                try:
                    point.easing = easing
                except (AttributeError, TypeError, ValueError):
                    pass


def _roblox_motor_rest_base(pose_bone, back_trans):
    bone = pose_bone.bone
    if not all(name in bone for name in ("transform", "transform1")):
        return None
    return back_trans @ (Matrix(bone["transform"]) @ Matrix(bone["transform1"]))


def _roblox_pose_world_transform(pose_bone, back_trans):
    nice_transform = Matrix(pose_bone.bone["nicetransform"])
    return back_trans @ (pose_bone.matrix @ nice_transform.inverted())


def _compose_roblox_motor_world(
    original_base,
    bone_transform,
    parent_base = None,
    parent_world = None,
):
    if parent_base is None or parent_world is None:
        # Roblox Pose CFrames are deltas from the Motor6D rest transform. A
        # source-root (including an explicitly unparented Pose) still needs its
        # stored rest position; treating the delta as an absolute transform
        # snaps the bone to the armature origin.
        return original_base @ bone_transform
    return parent_world @ parent_base.inverted() @ original_base @ bone_transform


def _apply_roblox_pose_transform(
    pose_bone,
    bone_transform,
    transform_to_blender,
    source_parent = Ellipsis,
    source_parent_world = None,
):
    bone = pose_bone.bone
    has_motor6d = all(
        property_name in bone
        for property_name in ("nicetransform", "transform", "transform1")
    )
    if not has_motor6d:
        pose_bone.matrix_basis = (
            transform_to_blender @ bone_transform @ transform_to_blender.inverted()
        )
        return

    back_trans = transform_to_blender.inverted()
    nice_transform = Matrix(bone["nicetransform"])
    original_base = _roblox_motor_rest_base(pose_bone, back_trans)
    parent = pose_bone.parent if source_parent is Ellipsis else source_parent
    parent_base = (
        _roblox_motor_rest_base(parent, back_trans)
        if parent is not None
        else None
    )
    if parent is not None and parent_base is not None:
        parent_object = (
            source_parent_world
            if source_parent_world is not None
            else _roblox_pose_world_transform(parent, back_trans)
        )
        current_object = _compose_roblox_motor_world(
            original_base,
            bone_transform,
            parent_base,
            parent_object,
        )
    else:
        current_object = _compose_roblox_motor_world(
            original_base,
            bone_transform,
        )
    pose_bone.matrix = (
        transform_to_blender @ current_object @ nice_transform
    )
    return current_object


def _roblox_state_name_lookup(state):
    exact = dict(state)
    canonical = {}
    ambiguous = set()
    for name, value in state.items():
        key = _canonical_bone_name(name)
        if key in canonical:
            ambiguous.add(key)
        else:
            canonical[key] = (name, value)
    for key in ambiguous:
        canonical.pop(key, None)

    def resolve(name):
        if name in exact:
            return name, exact[name]
        return canonical.get(_canonical_bone_name(name))

    return resolve


def _roblox_import_target_names(payload, resolve_bone):
    """Resolve non-root target bones present anywhere in a clipboard payload."""
    names = set()
    for keyframe in payload.get("kfs", ()):
        for source_name in keyframe.get("kf", {}):
            pose_bone = resolve_bone(source_name)
            if pose_bone is not None and pose_bone.parent is not None:
                names.add(pose_bone.name)
    return names


def _set_imported_ik_chains_fk_preserve_pose(context, armature, imported_names):
    """Disable only IK chains driven by imported bones without popping the rig."""
    controls = set()
    for owner in armature.pose.bones:
        if owner.name not in imported_names:
            continue
        for constraint in owner.constraints:
            if constraint.type != "IK" or constraint.mute or constraint.influence <= 0.0:
                continue
            target = (
                armature.pose.bones.get(constraint.subtarget)
                if constraint.target is armature and constraint.subtarget
                else None
            )
            if target is not None and "IK_FK" in target:
                controls.add(target.name)
            elif "IK_FK" in owner:
                controls.add(owner.name)

    if not controls:
        return ()

    # Changing IK/FK can otherwise move the evaluated rig before any imported
    # transform is applied. Preserve the complete visible pose, including
    # unrelated chains, then restore it parent-first after disabling only the
    # controls that would override imported FK bone transforms.
    pose_matrices = {
        pose_bone.name: pose_bone.matrix.copy()
        for pose_bone in armature.pose.bones
    }
    for name in controls:
        armature.pose.bones[name]["IK_FK"] = 0.0
    context.view_layer.update()
    for pose_bone in sorted(
        armature.pose.bones,
        key = lambda item: len(item.parent_recursive),
    ):
        pose_bone.matrix = pose_matrices[pose_bone.name]
    context.view_layer.update()
    return tuple(sorted(controls))


def _import_roblox_camera_fov_payload(context, armature, payload, start_frame):
    metadata = payload.get("camera_fov") if isinstance(payload, dict) else None
    if not isinstance(metadata, dict):
        return 0, set()
    if metadata.get("format") != "staticaliza.camera-fov.v1":
        raise ValueError("Clipboard camera FOV data uses an unsupported format.")
    tracks = metadata.get("tracks")
    if not isinstance(tracks, list):
        raise ValueError("Clipboard camera FOV data has no usable tracks.")

    scene_fps = float(getattr(context.scene.render, "fps", 60.0) or 60.0)
    scene_fps /= float(getattr(context.scene.render, "fps_base", 1.0) or 1.0)
    source_fps = max(1.0e-6, float(metadata.get("fps", scene_fps) or scene_fps))
    resolve_bone = _roblox_bone_lookup(armature)
    imported = 0
    unmatched = set()
    final_frame = float(start_frame)

    for track in tracks:
        if not isinstance(track, dict) or not isinstance(track.get("values"), list):
            continue
        source_name = str(track.get("bone") or "")
        pose_bone = resolve_bone(source_name)
        if pose_bone is None or _camera_for_bone(context.scene, armature, pose_bone.name) is None:
            unmatched.add(source_name or "<unnamed>")
            continue
        values = track["values"]
        for index, value in enumerate(values):
            frame = float(start_frame) + (float(index) * scene_fps / source_fps)
            _keyframe_attached_camera_fov(
                armature,
                pose_bone,
                math.radians(float(value)),
                frame,
            )
            final_frame = max(final_frame, frame)
        if values:
            imported += 1

    if imported:
        context.scene.frame_end = max(context.scene.frame_end, math.ceil(final_frame))
    return imported, unmatched


class ROBLOX_ANIMATOR_UTILS_OT_import_animation_clipboard(bpy.types.Operator):
    bl_idname = "roblox_animator_utils.import_animation_clipboard"
    bl_label = "Import"
    bl_description = "Import Roblox animation or camera FOV data from the clipboard"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        settings = getattr(getattr(context, "scene", None), "rbx_anim_settings", None)
        armature = bpy.data.objects.get(str(getattr(settings, "rbx_anim_armature", "")))
        return armature is not None and armature.type == "ARMATURE"

    def execute(self, context):
        start_frame = int(context.scene.frame_current)
        try:
            payload = _decode_roblox_animation_clipboard(context.window_manager.clipboard)
            module_name = _roblox_addon_module_name()
            if module_name is None:
                raise RuntimeError("Roblox Animator is not loaded.")
            core_utils = importlib.import_module(f"{module_name}.core.utils")
            constants = importlib.import_module(f"{module_name}.core.constants")
            settings = context.scene.rbx_anim_settings
            armature = bpy.data.objects.get(str(settings.rbx_anim_armature))
            if armature is None or armature.type != "ARMATURE":
                raise RuntimeError("Choose a Roblox armature first.")
            has_animation = isinstance(payload.get("kfs"), list)
            has_camera_fov = isinstance(payload.get("camera_fov"), dict)
            if not has_animation and not has_camera_fov:
                raise ValueError("Clipboard data contains no supported animation or camera FOV data.")
            # The rig-import operator and this animation import must remain two
            # independent undo operations even when run back-to-back.
            if bpy.ops.ed.undo_push.poll():
                bpy.ops.ed.undo_push(message = "Before Import Clipboard Data")
            if not has_animation:
                imported_fov, unmatched_fov = _import_roblox_camera_fov_payload(
                    context, armature, payload, start_frame
                )
                if not imported_fov:
                    raise ValueError("No camera FOV track matched an attached camera.")
                context.scene.frame_set(start_frame)
                message = f"Imported {imported_fov} camera FOV track(s) at frame {start_frame}"
                if unmatched_fov:
                    message += f"; skipped {len(unmatched_fov)} unmatched name(s)"
                self.report({"INFO"}, message)
                return {"FINISHED"}
            fps = float(core_utils.get_scene_fps())
            resolve_bone = _roblox_bone_lookup(armature)
            imported_targets = _roblox_import_target_names(payload, resolve_bone)
            transform_to_blender = constants.get_transform_to_blender()
            action_name = str(payload.get("name") or f"{armature.name}_Animation")
            action = _ensure_roblox_import_action(armature, action_name)
            unmatched = set()
            imported = set()

            def apply_animation():
                for keyframe in sorted(payload["kfs"], key = lambda item: float(item.get("t", 0.0))):
                    frame = start_frame + float(keyframe.get("t", 0.0)) * fps
                    whole_frame = math.floor(frame)
                    context.scene.frame_set(whole_frame, subframe = frame - whole_frame)
                    state = keyframe.get("kf", {})
                    resolve_state = _roblox_state_name_lookup(state)
                    resolved = {}
                    for source_name, pose_data in state.items():
                        pose_bone = resolve_bone(source_name)
                        if pose_bone is None:
                            unmatched.add(str(source_name))
                            continue
                        # Root motion belongs to placement of the rig, not this
                        # clipboard animation. Never assign or key a target root
                        # bone. Parent-relative children still use its unchanged
                        # evaluated transform below.
                        if pose_bone.parent is None:
                            continue
                        resolved[source_name] = (pose_bone, pose_data)

                    applied_world = {}
                    applying = set()

                    def apply_pose(source_name):
                        if source_name in applied_world:
                            return applied_world[source_name]
                        if source_name in applying:
                            raise ValueError(
                                f"Pose hierarchy contains a cycle at {source_name}."
                            )
                        applying.add(source_name)
                        pose_bone, pose_data = resolved[source_name]
                        if isinstance(pose_data, dict):
                            components = pose_data.get("components", ())
                            easing_style = str(pose_data.get("easingStyle", "Linear"))
                            easing_direction = str(pose_data.get("easingDirection", "In"))
                            parent_name = pose_data.get("parent", Ellipsis)
                            weight = float(pose_data.get("weight", 1.0))
                        elif isinstance(pose_data, list) and len(pose_data) == 3 and isinstance(pose_data[0], list):
                            components, easing_style, easing_direction = pose_data
                            parent_name, weight = Ellipsis, 1.0
                        else:
                            components, easing_style, easing_direction = pose_data, "Linear", "In"
                            parent_name, weight = Ellipsis, 1.0
                        if not components:
                            applying.remove(source_name)
                            return None

                        source_parent = Ellipsis
                        source_parent_world = None
                        if parent_name is Ellipsis and pose_bone.parent is not None:
                            parent_entry = resolve_state(pose_bone.parent.name)
                            if parent_entry is not None and parent_entry[0] in resolved:
                                parent_source_name = parent_entry[0]
                                source_parent = resolved[parent_source_name][0]
                                source_parent_world = apply_pose(parent_source_name)
                        elif parent_name is not Ellipsis:
                            source_parent = None
                            if parent_name:
                                parent_entry = resolve_state(parent_name)
                                if parent_entry is not None and parent_entry[0] in resolved:
                                    parent_source_name = parent_entry[0]
                                    source_parent = resolved[parent_source_name][0]
                                    source_parent_world = apply_pose(parent_source_name)
                                else:
                                    source_parent = resolve_bone(parent_name)
                                    if source_parent is None:
                                        unmatched.add(str(parent_name))

                        bone_transform = core_utils.cf_to_mat(components)
                        if weight <= 0.0:
                            bone_transform = Matrix.Identity(4)
                        pose_bone.rotation_mode = "QUATERNION"
                        world_transform = _apply_roblox_pose_transform(
                            pose_bone,
                            bone_transform,
                            transform_to_blender,
                            source_parent = source_parent,
                            source_parent_world = source_parent_world,
                        )
                        _replace_bone_keys(
                            core_utils, action, pose_bone, frame,
                            str(easing_style), str(easing_direction),
                        )
                        # Key the values just assigned before evaluating the
                        # action. Updating first re-applies earlier F-curves and
                        # makes every later key record the frame-zero pose.
                        context.view_layer.update()
                        imported.add(pose_bone.name)
                        applying.remove(source_name)
                        applied_world[source_name] = world_transform
                        return world_transform

                    for source_name in tuple(resolved):
                        apply_pose(source_name)

            import_end = start_frame + math.ceil(float(payload.get("t", 0.0)) * fps)
            context.scene.frame_end = max(context.scene.frame_end, import_end)
            if context.object is not armature or armature.mode != "POSE":
                if context.object is not None and context.object.mode != "OBJECT":
                    bpy.ops.object.mode_set(mode = "OBJECT")
                context.view_layer.objects.active = armature
                armature.select_set(True)
                bpy.ops.object.mode_set(mode = "POSE")

            _set_imported_ik_chains_fk_preserve_pose(
                context,
                armature,
                imported_targets,
            )
            apply_animation()
            if not imported:
                raise ValueError(
                    "No animation bones matched the selected Roblox armature."
                )
            imported_curves = tuple(
                _roblox_import_action_fcurves(core_utils, action)
            )
            if not imported_curves:
                raise RuntimeError(
                    "Animation poses matched, but Blender created no animation channels."
                )
            imported_fov, unmatched_fov = _import_roblox_camera_fov_payload(
                context, armature, payload, start_frame
            )
            context.scene.frame_set(start_frame)
            if hasattr(context.scene, ROBLOX_ANIMATION_LOOP_PROPERTY):
                setattr(context.scene, ROBLOX_ANIMATION_LOOP_PROPERTY, bool(payload.get("loop", False)))
            priority = str(payload.get("priority", "Action"))
            valid_priorities = {item[0] for item in ROBLOX_ANIMATION_PRIORITY_ITEMS}
            if priority not in valid_priorities:
                priority = "Action"
            if hasattr(context.scene, ROBLOX_ANIMATION_PRIORITY_PROPERTY):
                setattr(context.scene, ROBLOX_ANIMATION_PRIORITY_PROPERTY, priority)
            action["roblox_priority"] = priority
            action["roblox_clipboard_import_start"] = start_frame
            for group in getattr(action, "groups", ()):
                if hasattr(group, "show_expanded"):
                    group.show_expanded = True
            for slot in getattr(action, "slots", ()):
                if hasattr(slot, "show_expanded"):
                    slot.show_expanded = True
            # Cautioned's Dope Sheet commonly keeps Only Show Selected enabled.
            # Select every imported pose bone so the populated channels are
            # immediately visible instead of appearing to be an empty action.
            for pose_bone in armature.pose.bones:
                pose_bone.bone.select = pose_bone.name in imported
            first_imported = next(
                (
                    armature.data.bones.get(name)
                    for name in sorted(imported)
                    if armature.data.bones.get(name) is not None
                ),
                None,
            )
            if first_imported is not None:
                armature.data.bones.active = first_imported
            message = f"Imported {len(imported)} bone(s) at frame {start_frame}"
            if unmatched:
                message += f"; skipped {len(unmatched)} unmatched name(s)"
            if imported_fov:
                message += f"; imported {imported_fov} camera FOV track(s)"
            if unmatched_fov:
                message += f"; skipped {len(unmatched_fov)} unmatched FOV name(s)"
            self.report({"INFO"}, message)
            return {"FINISHED"}
        except Exception as exc:
            context.scene.frame_set(start_frame)
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}


