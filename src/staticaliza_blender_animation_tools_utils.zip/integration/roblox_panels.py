"""Non-destructive monkey patches for the external Roblox Animator add-on."""

import base64
import math
import re
import threading
import zlib

from ..core.runtime import *  # noqa: F403

_ADVANCED_ROBLOX_PANEL_HEADERS = frozenset({"Roblox Account", "UGC Emote Validation"})
_FACE_ROBLOX_PANEL_HEADERS = frozenset({"Face Controls"})
_RELOCATED_ROBLOX_PANEL_HEADERS = frozenset({"Connection"})
_ADVANCED_ROBLOX_OPERATORS = frozenset({
    "object.rbxanims_genrig",
    "object.rbxanims_autoconstraint",
    "object.rbxanims_manualconstraint",
    "object.rbxanims_toggle_weld_bones",
    "object.rbxanims_toggle_com",
    "object.rbxanims_toggle_com_grid",
    "object.rbxanims_edit_com_weights",
    "object.rbxanims_mapkeyframes",
    "object.rbxanims_applytransform",
    "object.rbxanims_bake_file",
    "object.rbxanims_importfbxanimation",
})
_ADVANCED_ROBLOX_PROPERTIES = frozenset({
    "rbx_auto_deform_scale",
    "rbx_deform_rig_scale",
    "rbx_full_range_bake",
})
_ADVANCED_ROBLOX_LABELS = frozenset({"Center of Mass:"})
_SUPPRESSED_ROBLOX_LABELS = frozenset({
    "No Roblox Rig Project Found",
    "No Roblox Rig Project Found.",
})
_EMPTY_ARMATURE_ROBLOX_LABELS = frozenset({
    "No Armatures in Scene",
    "No Armatures in Scene.",
    "No Armatures in this Scene",
    "No Armatures in this Scene.",
})
_ROBLOX_HEADER_ICONS = {
    "Armature Operations": "ARMATURE_DATA",
}
ROBLOX_ANIMATION_LOOP_PROPERTY = "roblox_animation_loop"
ROBLOX_ANIMATION_PRIORITY_PROPERTY = "roblox_animation_priority"
ROBLOX_ANIMATION_PRIORITY_ITEMS = (
    ("Core", "Core", "Lowest priority; used by Roblox default animations"),
    ("Idle", "Idle", "Priority for idle animations"),
    ("Movement", "Movement", "Priority for locomotion animations"),
    ("Action", "Action", "Priority for actions that override idle and movement"),
    ("Action2", "Action 2", "Higher priority than Action"),
    ("Action3", "Action 3", "Higher priority than Action 2"),
    ("Action4", "Action 4", "Highest Roblox animation priority"),
)


class ROBLOX_ANIMATOR_UTILS_OT_edit_animation_length(bpy.types.Operator):
    bl_idname = "roblox_animator_utils.edit_animation_length"
    bl_label = "Animation Length"
    bl_description = "Edit animation length as frames or frame-accurate time"
    bl_options = {"REGISTER", "UNDO"}

    value: bpy.props.StringProperty(name = "Time")

    def invoke(self, context, _event):
        self.value = _get_roblox_animation_length(context.scene)
        return context.window_manager.invoke_props_dialog(self, width = 220)

    def draw(self, _context):
        self.layout.prop(self, "value", text = "Time")

    def execute(self, context):
        try:
            _parse_animation_length(
                self.value,
                _scene_nominal_fps(context.scene),
            )
        except (TypeError, ValueError) as exc:
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}
        setattr(context.scene, ROBLOX_ANIMATION_LENGTH_PROPERTY, self.value)
        return {"FINISHED"}


_ROBLOX_INTERPOLATION_MAP = {
    "Linear": "LINEAR", "Constant": "CONSTANT", "Elastic": "ELASTIC",
    "Bounce": "BOUNCE", "Sine": "SINE", "Quad": "QUAD",
    "Cubic": "CUBIC", "CubicV2": "CUBIC", "Quart": "QUART",
    "Quint": "QUINT", "Expo": "EXPO", "Circular": "CIRC", "Back": "BACK",
}
_ROBLOX_EASING_MAP = {
    "In": "EASE_IN", "Out": "EASE_OUT", "InOut": "EASE_IN_OUT",
}


def _decode_roblox_animation_clipboard(text):
    """Decode supported animation and camera-FOV clipboard payloads."""
    text = str(text or "").strip()
    if not text:
        raise ValueError("The clipboard is empty.")
    try:
        payload = json.loads(text)
    except (TypeError, ValueError, json.JSONDecodeError):
        try:
            decoded = zlib.decompress(base64.b64decode(text)).decode("utf-8")
            payload = json.loads(decoded)
        except Exception as exc:
            raise ValueError(
                "Clipboard data is not supported Roblox animation or camera FOV data."
            ) from exc
    if not isinstance(payload, dict) or not (
        isinstance(payload.get("kfs"), list)
        or isinstance(payload.get("camera_fov"), dict)
    ):
        raise ValueError("Clipboard data has no supported animation or camera FOV data.")
    return payload


def _canonical_bone_name(name):
    return re.sub(r"[^a-z0-9]", "", str(name).casefold())


def _roblox_bone_lookup(armature):
    exact = {bone.name: bone for bone in armature.pose.bones}
    folded = {}
    canonical = {}
    ambiguous_folded = set()
    ambiguous_canonical = set()
    for bone in armature.pose.bones:
        folded_name = bone.name.casefold()
        canonical_name = _canonical_bone_name(bone.name)
        if folded_name in folded:
            ambiguous_folded.add(folded_name)
        else:
            folded[folded_name] = bone
        if canonical_name in canonical:
            ambiguous_canonical.add(canonical_name)
        else:
            canonical[canonical_name] = bone
    for name in ambiguous_folded:
        folded.pop(name, None)
    for name in ambiguous_canonical:
        canonical.pop(name, None)

    def resolve(name):
        return (
            exact.get(name)
            or folded.get(str(name).casefold())
            or canonical.get(_canonical_bone_name(name))
        )

    return resolve


def _ensure_roblox_import_action(armature, name):
    animation_data = armature.animation_data_create()
    # A clipboard import is a complete animation destination. Reusing the
    # currently assigned layered action can put keys into a stale slot or
    # leave an NLA strip evaluating instead, making populated channels inert.
    # Keep the old datablock intact for Blender Undo, but bind a fresh action.
    action = bpy.data.actions.new(name = name)
    animation_data.action = action
    if hasattr(animation_data, "use_nla"):
        animation_data.use_nla = False
    slots = getattr(action, "slots", None)
    if slots is not None and hasattr(animation_data, "action_slot"):
        slot = getattr(animation_data, "action_slot", None)
        if slot is None:
            try:
                slot = slots.new(id_type = "OBJECT", name = f"OB{armature.name}")
            except TypeError:
                slot = slots.new(id_type = "OBJECT")
            try:
                animation_data.action_slot = slot
            except (AttributeError, RuntimeError, TypeError):
                pass
    return action


def _roblox_import_action_fcurves(core_utils, action):
    channelbag = core_utils.get_action_channelbag(action)
    if channelbag is not None and hasattr(channelbag, "fcurves"):
        return channelbag.fcurves
    return getattr(action, "fcurves", ())


def _replace_bone_keys(core_utils, action, pose_bone, frame, easing_style, easing_direction):
    escaped = bpy.utils.escape_identifier(pose_bone.name)
    paths = {
        f'pose.bones["{escaped}"].location',
        f'pose.bones["{escaped}"].rotation_quaternion',
        f'pose.bones["{escaped}"].scale',
    }
    for fcurve in _roblox_import_action_fcurves(core_utils, action):
        if fcurve.data_path not in paths:
            continue
        for point in tuple(fcurve.keyframe_points):
            if abs(float(point.co.x) - float(frame)) <= 1e-4:
                fcurve.keyframe_points.remove(point, fast = True)

    pose_bone.keyframe_insert("location", frame = frame, group = pose_bone.name)
    pose_bone.keyframe_insert("rotation_quaternion", frame = frame, group = pose_bone.name)
    pose_bone.keyframe_insert("scale", frame = frame, group = pose_bone.name)

    interpolation = _ROBLOX_INTERPOLATION_MAP.get(easing_style, "LINEAR")
    easing = _ROBLOX_EASING_MAP.get(easing_direction, "EASE_IN")
    for fcurve in _roblox_import_action_fcurves(core_utils, action):
        if fcurve.data_path not in paths:
            continue
        fcurve.update()
        for point in fcurve.keyframe_points:
            if abs(float(point.co.x) - float(frame)) > 1e-4:
                continue
            point.type = "KEYFRAME"
            point.interpolation = interpolation
            if interpolation not in {"LINEAR", "CONSTANT"}:
                try:
                    point.easing = easing
                except (AttributeError, TypeError, ValueError):
                    pass
            point.handle_left_type = "AUTO"
            point.handle_right_type = "AUTO"
    _set_keyframe_handles_auto(pose_bone, frame)


def _roblox_motor_rest_base(pose_bone, back_trans):
    bone = pose_bone.bone
    if not all(name in bone for name in ("transform", "transform1")):
        return None
    return back_trans @ (Matrix(bone["transform"]) @ Matrix(bone["transform1"]))


def _roblox_pose_world_transform(pose_bone, back_trans):
    nice_transform = Matrix(pose_bone.bone["nicetransform"])
    return back_trans @ (pose_bone.matrix @ nice_transform.inverted())


def _compose_roblox_motor_world(
    original_base,
    bone_transform,
    parent_base = None,
    parent_world = None,
):
    if parent_base is None or parent_world is None:
        # Roblox Pose CFrames are deltas from the Motor6D rest transform. A
        # source-root (including an explicitly unparented Pose) still needs its
        # stored rest position; treating the delta as an absolute transform
        # snaps the bone to the armature origin.
        return original_base @ bone_transform
    return parent_world @ parent_base.inverted() @ original_base @ bone_transform


def _apply_roblox_pose_transform(
    pose_bone,
    bone_transform,
    transform_to_blender,
    source_parent = Ellipsis,
    source_parent_world = None,
):
    bone = pose_bone.bone
    has_motor6d = all(
        property_name in bone
        for property_name in ("nicetransform", "transform", "transform1")
    )
    if not has_motor6d:
        pose_bone.matrix_basis = (
            transform_to_blender @ bone_transform @ transform_to_blender.inverted()
        )
        return

    back_trans = transform_to_blender.inverted()
    nice_transform = Matrix(bone["nicetransform"])
    original_base = _roblox_motor_rest_base(pose_bone, back_trans)
    parent = pose_bone.parent if source_parent is Ellipsis else source_parent
    parent_base = (
        _roblox_motor_rest_base(parent, back_trans)
        if parent is not None
        else None
    )
    if parent is not None and parent_base is not None:
        parent_object = (
            source_parent_world
            if source_parent_world is not None
            else _roblox_pose_world_transform(parent, back_trans)
        )
        current_object = _compose_roblox_motor_world(
            original_base,
            bone_transform,
            parent_base,
            parent_object,
        )
    else:
        current_object = _compose_roblox_motor_world(
            original_base,
            bone_transform,
        )
    pose_bone.matrix = (
        transform_to_blender @ current_object @ nice_transform
    )
    return current_object


def _roblox_state_name_lookup(state):
    exact = dict(state)
    canonical = {}
    ambiguous = set()
    for name, value in state.items():
        key = _canonical_bone_name(name)
        if key in canonical:
            ambiguous.add(key)
        else:
            canonical[key] = (name, value)
    for key in ambiguous:
        canonical.pop(key, None)

    def resolve(name):
        if name in exact:
            return name, exact[name]
        return canonical.get(_canonical_bone_name(name))

    return resolve


def _roblox_import_target_names(payload, resolve_bone):
    """Resolve non-root target bones present anywhere in a clipboard payload."""
    names = set()
    for keyframe in payload.get("kfs", ()):
        for source_name in keyframe.get("kf", {}):
            pose_bone = resolve_bone(source_name)
            if pose_bone is not None and pose_bone.parent is not None:
                names.add(pose_bone.name)
    return names


def _set_imported_ik_chains_fk_preserve_pose(context, armature, imported_names):
    """Disable only IK chains driven by imported bones without popping the rig."""
    controls = set()
    for owner in armature.pose.bones:
        if owner.name not in imported_names:
            continue
        for constraint in owner.constraints:
            if constraint.type != "IK" or constraint.mute or constraint.influence <= 0.0:
                continue
            target = (
                armature.pose.bones.get(constraint.subtarget)
                if constraint.target is armature and constraint.subtarget
                else None
            )
            if target is not None and "IK_FK" in target:
                controls.add(target.name)
            elif "IK_FK" in owner:
                controls.add(owner.name)

    if not controls:
        return ()

    # Changing IK/FK can otherwise move the evaluated rig before any imported
    # transform is applied. Preserve the complete visible pose, including
    # unrelated chains, then restore it parent-first after disabling only the
    # controls that would override imported FK bone transforms.
    pose_matrices = {
        pose_bone.name: pose_bone.matrix.copy()
        for pose_bone in armature.pose.bones
    }
    for name in controls:
        armature.pose.bones[name]["IK_FK"] = 0.0
    context.view_layer.update()
    for pose_bone in sorted(
        armature.pose.bones,
        key = lambda item: len(item.parent_recursive),
    ):
        pose_bone.matrix = pose_matrices[pose_bone.name]
    context.view_layer.update()
    return tuple(sorted(controls))


def _import_roblox_camera_fov_payload(context, armature, payload, start_frame):
    metadata = payload.get("camera_fov") if isinstance(payload, dict) else None
    if not isinstance(metadata, dict):
        return 0, set()
    if metadata.get("format") != "staticaliza.camera-fov.v1":
        raise ValueError("Clipboard camera FOV data uses an unsupported format.")
    tracks = metadata.get("tracks")
    if not isinstance(tracks, list):
        raise ValueError("Clipboard camera FOV data has no usable tracks.")

    scene_fps = float(getattr(context.scene.render, "fps", 60.0) or 60.0)
    scene_fps /= float(getattr(context.scene.render, "fps_base", 1.0) or 1.0)
    source_fps = max(1.0e-6, float(metadata.get("fps", scene_fps) or scene_fps))
    resolve_bone = _roblox_bone_lookup(armature)
    imported = 0
    unmatched = set()
    final_frame = float(start_frame)

    for track in tracks:
        if not isinstance(track, dict) or not isinstance(track.get("values"), list):
            continue
        source_name = str(track.get("bone") or "")
        pose_bone = resolve_bone(source_name)
        if pose_bone is None or _camera_for_bone(context.scene, armature, pose_bone.name) is None:
            unmatched.add(source_name or "<unnamed>")
            continue
        values = track["values"]
        for index, value in enumerate(values):
            frame = float(start_frame) + (float(index) * scene_fps / source_fps)
            _keyframe_attached_camera_fov(
                armature,
                pose_bone,
                math.radians(float(value)),
                frame,
            )
            final_frame = max(final_frame, frame)
        if values:
            imported += 1

    if imported:
        context.scene.frame_end = max(context.scene.frame_end, math.ceil(final_frame))
    return imported, unmatched


class ROBLOX_ANIMATOR_UTILS_OT_import_animation_clipboard(bpy.types.Operator):
    bl_idname = "roblox_animator_utils.import_animation_clipboard"
    bl_label = "Import"
    bl_description = "Import Roblox animation or camera FOV data from the clipboard"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        settings = getattr(getattr(context, "scene", None), "rbx_anim_settings", None)
        armature = bpy.data.objects.get(str(getattr(settings, "rbx_anim_armature", "")))
        return armature is not None and armature.type == "ARMATURE"

    def execute(self, context):
        start_frame = int(context.scene.frame_current)
        try:
            payload = _decode_roblox_animation_clipboard(context.window_manager.clipboard)
            module_name = _roblox_addon_module_name()
            if module_name is None:
                raise RuntimeError("Roblox Animator is not loaded.")
            core_utils = importlib.import_module(f"{module_name}.core.utils")
            constants = importlib.import_module(f"{module_name}.core.constants")
            settings = context.scene.rbx_anim_settings
            armature = bpy.data.objects.get(str(settings.rbx_anim_armature))
            if armature is None or armature.type != "ARMATURE":
                raise RuntimeError("Choose a Roblox armature first.")
            has_animation = isinstance(payload.get("kfs"), list)
            has_camera_fov = isinstance(payload.get("camera_fov"), dict)
            if not has_animation and not has_camera_fov:
                raise ValueError("Clipboard data contains no supported animation or camera FOV data.")
            # The rig-import operator and this animation import must remain two
            # independent undo operations even when run back-to-back.
            if bpy.ops.ed.undo_push.poll():
                bpy.ops.ed.undo_push(message = "Before Import Clipboard Data")
            if not has_animation:
                imported_fov, unmatched_fov = _import_roblox_camera_fov_payload(
                    context, armature, payload, start_frame
                )
                if not imported_fov:
                    raise ValueError("No camera FOV track matched an attached camera.")
                context.scene.frame_set(start_frame)
                message = f"Imported {imported_fov} camera FOV track(s) at frame {start_frame}"
                if unmatched_fov:
                    message += f"; skipped {len(unmatched_fov)} unmatched name(s)"
                self.report({"INFO"}, message)
                return {"FINISHED"}
            fps = float(core_utils.get_scene_fps())
            resolve_bone = _roblox_bone_lookup(armature)
            imported_targets = _roblox_import_target_names(payload, resolve_bone)
            transform_to_blender = constants.get_transform_to_blender()
            action_name = str(payload.get("name") or f"{armature.name}_Animation")
            action = _ensure_roblox_import_action(armature, action_name)
            unmatched = set()
            imported = set()

            def apply_animation():
                for keyframe in sorted(payload["kfs"], key = lambda item: float(item.get("t", 0.0))):
                    frame = start_frame + float(keyframe.get("t", 0.0)) * fps
                    whole_frame = math.floor(frame)
                    context.scene.frame_set(whole_frame, subframe = frame - whole_frame)
                    state = keyframe.get("kf", {})
                    resolve_state = _roblox_state_name_lookup(state)
                    resolved = {}
                    for source_name, pose_data in state.items():
                        pose_bone = resolve_bone(source_name)
                        if pose_bone is None:
                            unmatched.add(str(source_name))
                            continue
                        # Root motion belongs to placement of the rig, not this
                        # clipboard animation. Never assign or key a target root
                        # bone. Parent-relative children still use its unchanged
                        # evaluated transform below.
                        if pose_bone.parent is None:
                            continue
                        resolved[source_name] = (pose_bone, pose_data)

                    applied_world = {}
                    applying = set()

                    def apply_pose(source_name):
                        if source_name in applied_world:
                            return applied_world[source_name]
                        if source_name in applying:
                            raise ValueError(
                                f"Pose hierarchy contains a cycle at {source_name}."
                            )
                        applying.add(source_name)
                        pose_bone, pose_data = resolved[source_name]
                        if isinstance(pose_data, dict):
                            components = pose_data.get("components", ())
                            easing_style = str(pose_data.get("easingStyle", "Linear"))
                            easing_direction = str(pose_data.get("easingDirection", "In"))
                            parent_name = pose_data.get("parent", Ellipsis)
                            weight = float(pose_data.get("weight", 1.0))
                        elif isinstance(pose_data, list) and len(pose_data) == 3 and isinstance(pose_data[0], list):
                            components, easing_style, easing_direction = pose_data
                            parent_name, weight = Ellipsis, 1.0
                        else:
                            components, easing_style, easing_direction = pose_data, "Linear", "In"
                            parent_name, weight = Ellipsis, 1.0
                        if not components:
                            applying.remove(source_name)
                            return None

                        source_parent = Ellipsis
                        source_parent_world = None
                        if parent_name is Ellipsis and pose_bone.parent is not None:
                            parent_entry = resolve_state(pose_bone.parent.name)
                            if parent_entry is not None and parent_entry[0] in resolved:
                                parent_source_name = parent_entry[0]
                                source_parent = resolved[parent_source_name][0]
                                source_parent_world = apply_pose(parent_source_name)
                        elif parent_name is not Ellipsis:
                            source_parent = None
                            if parent_name:
                                parent_entry = resolve_state(parent_name)
                                if parent_entry is not None and parent_entry[0] in resolved:
                                    parent_source_name = parent_entry[0]
                                    source_parent = resolved[parent_source_name][0]
                                    source_parent_world = apply_pose(parent_source_name)
                                else:
                                    source_parent = resolve_bone(parent_name)
                                    if source_parent is None:
                                        unmatched.add(str(parent_name))

                        bone_transform = core_utils.cf_to_mat(components)
                        if weight <= 0.0:
                            bone_transform = Matrix.Identity(4)
                        pose_bone.rotation_mode = "QUATERNION"
                        world_transform = _apply_roblox_pose_transform(
                            pose_bone,
                            bone_transform,
                            transform_to_blender,
                            source_parent = source_parent,
                            source_parent_world = source_parent_world,
                        )
                        _replace_bone_keys(
                            core_utils, action, pose_bone, frame,
                            str(easing_style), str(easing_direction),
                        )
                        # Key the values just assigned before evaluating the
                        # action. Updating first re-applies earlier F-curves and
                        # makes every later key record the frame-zero pose.
                        context.view_layer.update()
                        imported.add(pose_bone.name)
                        applying.remove(source_name)
                        applied_world[source_name] = world_transform
                        return world_transform

                    for source_name in tuple(resolved):
                        apply_pose(source_name)

            import_end = start_frame + math.ceil(float(payload.get("t", 0.0)) * fps)
            context.scene.frame_end = max(context.scene.frame_end, import_end)
            if context.object is not armature or armature.mode != "POSE":
                if context.object is not None and context.object.mode != "OBJECT":
                    bpy.ops.object.mode_set(mode = "OBJECT")
                context.view_layer.objects.active = armature
                armature.select_set(True)
                bpy.ops.object.mode_set(mode = "POSE")

            _set_imported_ik_chains_fk_preserve_pose(
                context,
                armature,
                imported_targets,
            )
            apply_animation()
            if not imported:
                raise ValueError(
                    "No animation bones matched the selected Roblox armature."
                )
            imported_curves = tuple(
                _roblox_import_action_fcurves(core_utils, action)
            )
            if not imported_curves:
                raise RuntimeError(
                    "Animation poses matched, but Blender created no animation channels."
                )
            imported_fov, unmatched_fov = _import_roblox_camera_fov_payload(
                context, armature, payload, start_frame
            )
            context.scene.frame_set(start_frame)
            if hasattr(context.scene, ROBLOX_ANIMATION_LOOP_PROPERTY):
                setattr(context.scene, ROBLOX_ANIMATION_LOOP_PROPERTY, bool(payload.get("loop", False)))
            priority = str(payload.get("priority", "Action"))
            valid_priorities = {item[0] for item in ROBLOX_ANIMATION_PRIORITY_ITEMS}
            if priority not in valid_priorities:
                priority = "Action"
            if hasattr(context.scene, ROBLOX_ANIMATION_PRIORITY_PROPERTY):
                setattr(context.scene, ROBLOX_ANIMATION_PRIORITY_PROPERTY, priority)
            action["roblox_priority"] = priority
            action["roblox_clipboard_import_start"] = start_frame
            for group in getattr(action, "groups", ()):
                if hasattr(group, "show_expanded"):
                    group.show_expanded = True
            for slot in getattr(action, "slots", ()):
                if hasattr(slot, "show_expanded"):
                    slot.show_expanded = True
            # Cautioned's Dope Sheet commonly keeps Only Show Selected enabled.
            # Select every imported pose bone so the populated channels are
            # immediately visible instead of appearing to be an empty action.
            for pose_bone in armature.pose.bones:
                pose_bone.bone.select = pose_bone.name in imported
            first_imported = next(
                (
                    armature.data.bones.get(name)
                    for name in sorted(imported)
                    if armature.data.bones.get(name) is not None
                ),
                None,
            )
            if first_imported is not None:
                armature.data.bones.active = first_imported
            message = f"Imported {len(imported)} bone(s) at frame {start_frame}"
            if unmatched:
                message += f"; skipped {len(unmatched)} unmatched name(s)"
            if imported_fov:
                message += f"; imported {imported_fov} camera FOV track(s)"
            if unmatched_fov:
                message += f"; skipped {len(unmatched_fov)} unmatched FOV name(s)"
            self.report({"INFO"}, message)
            return {"FINISHED"}
        except Exception as exc:
            context.scene.frame_set(start_frame)
            self.report({"ERROR"}, str(exc))
            return {"CANCELLED"}


def _roblox_operator_ui_kwargs(operator_id, kwargs):
    updated = dict(kwargs)
    if operator_id == "object.rbxanims_bake":
        updated["text"] = "Export"
    elif operator_id == "object.rbxanims_importmodel":
        updated["text"] = "Import Rig"
    return updated


def _normalize_roblox_operator_layout(layout, operator_id):
    if operator_id == "object.rbxanims_importmodel":
        try:
            layout.scale_y = 1.0
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            pass


def _draw_roblox_label_override(layout, args, kwargs):
    """Return (handled, result) for standardized external empty-state labels."""
    text = kwargs.get("text", args[0] if args else "")
    version_parts = str(text).strip().lstrip("vV").split(".")
    if (
        str(text).strip()[:1].lower() == "v"
        and len(version_parts) >= 2
        and all(part.isdigit() for part in version_parts)
    ):
        return True, None
    if text in _SUPPRESSED_ROBLOX_LABELS:
        return True, None

    updated = dict(kwargs)
    if text in _ROBLOX_HEADER_ICONS:
        updated["icon"] = _ROBLOX_HEADER_ICONS[text]
        remaining_args = args[1:] if args else args
        return True, layout.label(*remaining_args, **updated)
    if text in _EMPTY_ARMATURE_ROBLOX_LABELS:
        updated["text"] = "No armatures in this scene."
    elif updated.get("icon") != "INFO":
        return False, None

    updated.pop("icon", None)
    remaining_args = args[1:] if args else args
    hint = layout.row(align = True)
    hint.active = False
    return True, hint.label(*remaining_args, **updated)


def _draw_roblox_loop_setting(layout, operator_id):
    """Place playback settings immediately above Cautioned's Export."""
    if operator_id != "object.rbxanims_bake":
        return
    scene = getattr(bpy.context, "scene", None)
    if scene is None or not hasattr(scene, ROBLOX_ANIMATION_LOOP_PROPERTY):
        return
    layout.prop(scene, ROBLOX_ANIMATION_LOOP_PROPERTY, text = "Loop (Tab)")
    if hasattr(scene, ROBLOX_ANIMATION_LENGTH_PROPERTY):
        length = _animation_length_frames(scene)
        timecode = _get_roblox_animation_length(scene)
        split = layout.split(factor = 0.3, align = True)
        split.label(text = "Length:")
        split.operator(
            "roblox_animator_utils.edit_animation_length",
            text = f"{timecode} ({length}f)",
        )
        fps_split = layout.split(factor = 0.3, align = True)
        fps_split.label(text = "FPS:")
        fps_split.prop(scene.render, "fps", text = "")
        if hasattr(scene, ROBLOX_ANIMATION_PRIORITY_PROPERTY):
            priority_split = layout.split(factor = 0.3, align = True)
            priority_split.label(text = "Priority:")
            priority_split.prop(
                scene,
                ROBLOX_ANIMATION_PRIORITY_PROPERTY,
                text = "",
            )


def _draw_roblox_import_export_row(layout, args, kwargs):
    """Draw the sole animation Import/Export pair at the panel bottom."""
    row = layout.row(align = True)
    row.operator(
        "roblox_animator_utils.import_animation_clipboard",
        text = "Import",
        icon = "IMPORT",
    )
    updated = _roblox_operator_ui_kwargs("object.rbxanims_bake", kwargs)
    return row.operator(*args, **updated)


class _NullOperatorProperties:
    def __setattr__(self, name, value):
        pass


class _NullUILayout:
    def __setattr__(self, name, value):
        pass

    def row(self, *args, **kwargs):
        return self

    def column(self, *args, **kwargs):
        return self

    def column_flow(self, *args, **kwargs):
        return self

    def grid_flow(self, *args, **kwargs):
        return self

    def split(self, *args, **kwargs):
        return self

    def box(self, *args, **kwargs):
        return self

    def operator(self, *args, **kwargs):
        return _NullOperatorProperties()

    def __getattr__(self, name):
        return lambda *args, **kwargs: None


_NULL_UI_LAYOUT = _NullUILayout()
_UI_CONTAINER_METHODS = frozenset({"row", "column", "column_flow", "grid_flow", "split"})


class _UILayoutProxy:
    __slots__ = (
        "_layout",
        "_hidden_headers",
        "_hide_advanced",
        "_suppress_separators",
    )

    def __init__(
        self,
        layout,
        hidden_headers,
        hide_advanced = False,
        suppress_separators = True,
    ):
        object.__setattr__(self, "_layout", layout)
        object.__setattr__(self, "_hidden_headers", hidden_headers)
        object.__setattr__(self, "_hide_advanced", hide_advanced)
        object.__setattr__(self, "_suppress_separators", suppress_separators)

    def box(self, *args, **kwargs):
        return _LazyBoxProxy(
            self._layout,
            self._hidden_headers,
            self._hide_advanced,
            args,
            kwargs,
        )

    def label(self, *args, **kwargs):
        text = kwargs.get("text", args[0] if args else "")
        if self._hide_advanced and text in _ADVANCED_ROBLOX_LABELS:
            return None
        handled, result = _draw_roblox_label_override(self._layout, args, kwargs)
        if handled:
            return result
        return self._layout.label(*args, **kwargs)

    def separator(self, *args, **kwargs):
        """Discard only external top-level spacers between boxed sections."""
        if self._suppress_separators:
            return None
        return self._layout.separator(*args, **kwargs)

    def operator(self, *args, **kwargs):
        operator_id = args[0] if args else kwargs.get("operator", "")
        if self._hide_advanced and operator_id in _ADVANCED_ROBLOX_OPERATORS:
            return _NullOperatorProperties()
        _draw_roblox_loop_setting(self._layout, operator_id)
        if operator_id == "object.rbxanims_bake":
            return _draw_roblox_import_export_row(
                self._layout,
                args,
                kwargs,
            )
        _normalize_roblox_operator_layout(self._layout, operator_id)
        kwargs = _roblox_operator_ui_kwargs(operator_id, kwargs)
        return self._layout.operator(*args, **kwargs)

    def prop(self, *args, **kwargs):
        property_name = args[1] if len(args) > 1 else kwargs.get("property", "")
        if self._hide_advanced and property_name in _ADVANCED_ROBLOX_PROPERTIES:
            return None
        return self._layout.prop(*args, **kwargs)

    def __getattr__(self, name):
        attribute = getattr(self._layout, name)
        if not callable(attribute) or name not in _UI_CONTAINER_METHODS:
            return attribute

        def call_container(*args, **kwargs):
            return _UILayoutProxy(
                attribute(*args, **kwargs),
                self._hidden_headers,
                self._hide_advanced,
                suppress_separators = False,
            )

        return call_container

    def __setattr__(self, name, value):
        setattr(self._layout, name, value)


class _HeaderOnlyUILayoutProxy:
    """Draw only a named top-level box from an external panel."""

    __slots__ = ("_layout", "_visible_headers", "_hide_advanced")

    def __init__(self, layout, visible_headers, hide_advanced = False):
        object.__setattr__(self, "_layout", layout)
        object.__setattr__(self, "_visible_headers", visible_headers)
        object.__setattr__(self, "_hide_advanced", hide_advanced)

    def box(self, *args, **kwargs):
        return _LazyBoxProxy(
            self._layout,
            frozenset(),
            self._hide_advanced,
            args,
            kwargs,
            visible_headers = self._visible_headers,
        )

    def separator(self, *_args, **_kwargs):
        return None

    def __getattr__(self, name):
        attribute = getattr(self._layout, name)
        if callable(attribute):
            return lambda *args, **kwargs: getattr(_NULL_UI_LAYOUT, name)(
                *args,
                **kwargs,
            )
        return attribute

    def __setattr__(self, name, value):
        pass


class _LazyBoxProxy:
    __slots__ = (
        "_parent_layout",
        "_hidden_headers",
        "_hide_advanced",
        "_box_args",
        "_box_kwargs",
        "_layout_proxy",
        "_suppressed",
        "_visible_headers",
        "_accepted",
    )

    def __init__(
        self,
        parent_layout,
        hidden_headers,
        hide_advanced,
        box_args,
        box_kwargs,
        visible_headers = None,
    ):
        object.__setattr__(self, "_parent_layout", parent_layout)
        object.__setattr__(self, "_hidden_headers", hidden_headers)
        object.__setattr__(self, "_hide_advanced", hide_advanced)
        object.__setattr__(self, "_box_args", box_args)
        object.__setattr__(self, "_box_kwargs", box_kwargs)
        object.__setattr__(self, "_layout_proxy", None)
        object.__setattr__(self, "_suppressed", False)
        object.__setattr__(self, "_visible_headers", visible_headers)
        object.__setattr__(self, "_accepted", visible_headers is None)

    def _header_is_suppressed(self, text):
        if self._suppressed:
            return True
        if not self._accepted:
            if text in self._visible_headers:
                object.__setattr__(self, "_accepted", True)
                return False
            object.__setattr__(self, "_suppressed", True)
            return True
        if text in self._hidden_headers:
            object.__setattr__(self, "_suppressed", True)
            return True
        return False

    def _materialize(self):
        if self._layout_proxy is None:
            layout = self._parent_layout.box(*self._box_args, **self._box_kwargs)
            object.__setattr__(
                self,
                "_layout_proxy",
                _UILayoutProxy(
                    layout,
                    self._hidden_headers,
                    self._hide_advanced,
                    suppress_separators = False,
                ),
            )
        return self._layout_proxy

    def label(self, *args, **kwargs):
        if self._suppressed:
            return None
        text = kwargs.get("text", args[0] if args else "")
        if self._header_is_suppressed(text):
            return None
        if self._hide_advanced and text in _ADVANCED_ROBLOX_LABELS:
            return None
        return self._materialize().label(*args, **kwargs)

    def __getattr__(self, name):
        if self._suppressed:
            return getattr(_NULL_UI_LAYOUT, name)
        if name in _UI_CONTAINER_METHODS:
            def call_container(*args, **kwargs):
                return _DeferredLayoutProxy(self, name, args, kwargs)

            return call_container
        return getattr(self._materialize(), name)

    def __setattr__(self, name, value):
        if not self._suppressed:
            setattr(self._materialize(), name, value)


class _DeferredLayoutProxy:
    __slots__ = ("_root", "_parent", "_method", "_args", "_kwargs", "_layout")

    def __init__(self, root, method, args, kwargs, parent = None):
        object.__setattr__(self, "_root", root)
        object.__setattr__(self, "_parent", parent)
        object.__setattr__(self, "_method", method)
        object.__setattr__(self, "_args", args)
        object.__setattr__(self, "_kwargs", kwargs)
        object.__setattr__(self, "_layout", None)

    def _materialize(self):
        if self._layout is None:
            parent_layout = self._parent._materialize() if self._parent else self._root._materialize()
            layout = getattr(parent_layout, self._method)(*self._args, **self._kwargs)
            object.__setattr__(self, "_layout", layout)
        return self._layout

    def _hide_if_needed(self, args, kwargs):
        text = kwargs.get("text", args[0] if args else "")
        return self._root._header_is_suppressed(text)

    def label(self, *args, **kwargs):
        if self._root._suppressed:
            return None
        if self._hide_if_needed(args, kwargs):
            return None
        text = kwargs.get("text", args[0] if args else "")
        if self._root._hide_advanced and text in _ADVANCED_ROBLOX_LABELS:
            return None
        return self._materialize().label(*args, **kwargs)

    def prop(self, *args, **kwargs):
        if self._root._suppressed:
            return None
        if self._hide_if_needed((), kwargs):
            return None
        property_name = args[1] if len(args) > 1 else kwargs.get("property", "")
        if (
            self._root._hide_advanced
            and property_name in _ADVANCED_ROBLOX_PROPERTIES
        ):
            return None
        return self._materialize().prop(*args, **kwargs)

    def operator(self, *args, **kwargs):
        if self._root._suppressed:
            return _NullOperatorProperties()
        if self._hide_if_needed(args, kwargs):
            return _NullOperatorProperties()
        operator_id = args[0] if args else kwargs.get("operator", "")
        if self._root._hide_advanced and operator_id in _ADVANCED_ROBLOX_OPERATORS:
            return _NullOperatorProperties()
        layout = self._materialize()
        kwargs = _roblox_operator_ui_kwargs(operator_id, kwargs)
        return layout.operator(*args, **kwargs)

    def __getattr__(self, name):
        if self._root._suppressed:
            return getattr(_NULL_UI_LAYOUT, name)
        if name in _UI_CONTAINER_METHODS:
            def call_container(*args, **kwargs):
                return _DeferredLayoutProxy(
                    self._root,
                    name,
                    args,
                    kwargs,
                    parent = self,
                )

            return call_container
        return getattr(self._materialize(), name)

    def __setattr__(self, name, value):
        if not self._root._suppressed:
            setattr(self._materialize(), name, value)


class _PanelDrawProxy:
    __slots__ = ("_panel", "layout")

    def __init__(self, panel, layout):
        object.__setattr__(self, "_panel", panel)
        object.__setattr__(self, "layout", layout)

    def __getattr__(self, name):
        return getattr(self._panel, name)


def _draw_roblox_animator_footer(layout, context):
    """Append Utils-owned setup and extension controls to Roblox Animator."""
    scene_setup = layout.box()
    scene_setup.label(text = "Scene", icon = "VIEW3D")
    scene_setup.operator_context = "INVOKE_DEFAULT"
    scene_setup.operator("staticaliza.load_template", text = "Load Template")

    extension = layout.box()
    extension.label(text = "Configuration", icon = "PREFERENCES")
    if (
        _state.get("extension_update_running", False)
        or extension_update_guard_active()
    ):
        extension.label(text = "Updating extensions...")
        return
    extension.operator(
        "staticaliza.install_roblox_animations",
        text = "Update Extensions",
        icon = "FILE_REFRESH",
    )
    extension.operator(
        "staticaliza.open_roblox_plugins",
        text = "Install Roblox Plugins",
        icon = "URL",
    )
    extension.prop(
        context.window_manager,
        "roblox_compat_advanced_mode",
        text = "Advanced Mode",
    )


def _restore_roblox_advanced_panel_filter():
    patches = _state.pop("roblox_advanced_panel_patch", None)
    if patches is None:
        return
    if isinstance(patches, tuple) and len(patches) == 3:
        patches = (patches,)
    for panel_class, original_draw, patched_draw in tuple(patches):
        if getattr(panel_class, "draw", None) is patched_draw:
            panel_class.draw = original_draw


def _restore_roblox_clipboard_endpoint_patch():
    patch = _state.pop("roblox_clipboard_endpoint_patch", None)
    if patch is None:
        return
    handler_class, original_do_post, patched_do_post = patch
    if getattr(handler_class, "do_POST", None) is patched_do_post:
        handler_class.do_POST = original_do_post


def _patch_roblox_clipboard_endpoint():
    module_name = _roblox_addon_module_name()
    if module_name is None:
        return False
    try:
        handler_module = importlib.import_module(f"{module_name}.server.handler")
        handler_class = handler_module.AnimationHandler
    except (AttributeError, ImportError):
        return False

    existing = _state.get("roblox_clipboard_endpoint_patch")
    if existing is not None:
        if existing[0] is handler_class and handler_class.do_POST is existing[2]:
            return True
        _restore_roblox_clipboard_endpoint_patch()

    original_do_post = handler_class.do_POST

    def do_post_with_clipboard(self):
        if str(getattr(self, "path", "")).split("?", 1)[0] != "/staticaliza_clipboard":
            return original_do_post(self)
        try:
            content_length = int(self.headers.get("Content-Length", "0"))
            if content_length <= 0 or content_length > 16 * 1024 * 1024:
                raise ValueError("Clipboard animation payload has an invalid size.")
            clipboard_text = self.rfile.read(content_length).decode("utf-8")
            payload = _decode_roblox_animation_clipboard(clipboard_text)
            if not isinstance(payload, dict) or not (
                isinstance(payload.get("kfs"), list)
                or isinstance(payload.get("camera_fov"), dict)
            ):
                raise ValueError("Clipboard payload contains no supported animation or camera FOV data.")

            completed = threading.Event()
            result = {"error": None}

            def copy_on_main_thread():
                try:
                    bpy.context.window_manager.clipboard = clipboard_text
                except Exception as exc:
                    result["error"] = str(exc)
                finally:
                    completed.set()
                return None

            bpy.app.timers.register(copy_on_main_thread, first_interval = 0.0)
            if not completed.wait(5.0):
                raise TimeoutError("Blender did not update the clipboard in time.")
            if result["error"]:
                raise RuntimeError(result["error"])
            response = b'{"success":true}'
            self.send_response(200)
        except Exception as exc:
            response = json.dumps({"success": False, "error": str(exc)}).encode("utf-8")
            self.send_response(400)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(response)))
        self.end_headers()
        self.wfile.write(response)

    handler_class.do_POST = do_post_with_clipboard
    _state["roblox_clipboard_endpoint_patch"] = (
        handler_class,
        original_do_post,
        do_post_with_clipboard,
    )
    return True


def _patch_roblox_advanced_panels():
    _patch_roblox_clipboard_endpoint()
    panel_classes = tuple(
        panel_class
        for panel_name in (
            "OBJECT_PT_RbxAnimations",
            "OBJECT_PT_RbxAnimations_Tool",
        )
        if (panel_class := getattr(bpy.types, panel_name, None)) is not None
    )
    if not panel_classes:
        return False

    existing = _state.get("roblox_advanced_panel_patch")
    if existing is not None:
        existing_records = (
            (existing,)
            if isinstance(existing, tuple) and len(existing) == 3
            else tuple(existing)
        )
        if (
            len(existing_records) == len(panel_classes)
            and all(
                panel_class is record[0]
                and panel_class.draw is record[2]
                for panel_class, record in zip(panel_classes, existing_records)
            )
        ):
            return True
        _restore_roblox_advanced_panel_filter()

    patches = []
    for panel_class in panel_classes:
        original_draw = panel_class.draw

        def make_filtered_draw(draw_function, relocate_footer):
            def draw_with_advanced_panel_filter(self, context):
                if (
                    _state.get("extension_update_running", False)
                    or extension_update_guard_active()
                ):
                    update_box = self.layout.box()
                    update_box.label(
                        text = "Extension Update",
                        icon = "FILE_REFRESH",
                    )
                    update_box.label(
                        text = "Updating extensions...",
                    )
                    return
                advanced_mode = getattr(
                    context.window_manager,
                    "roblox_compat_advanced_mode",
                    False,
                )
                hide_advanced = not advanced_mode
                hide_face_controls = not advanced_mode
                hidden_headers = set()
                if hide_advanced:
                    hidden_headers.update(_ADVANCED_ROBLOX_PANEL_HEADERS)
                if hide_face_controls:
                    hidden_headers.update(_FACE_ROBLOX_PANEL_HEADERS)
                if relocate_footer:
                    hidden_headers.update(_RELOCATED_ROBLOX_PANEL_HEADERS)
                layout = _UILayoutProxy(
                    self.layout,
                    frozenset(hidden_headers),
                    hide_advanced = hide_advanced,
                )
                result = draw_function(_PanelDrawProxy(self, layout), context)
                if relocate_footer:
                    connection_layout = _HeaderOnlyUILayoutProxy(
                        self.layout,
                        _RELOCATED_ROBLOX_PANEL_HEADERS,
                        hide_advanced = hide_advanced,
                    )
                    draw_function(
                        _PanelDrawProxy(self, connection_layout),
                        context,
                    )
                    _draw_roblox_animator_footer(self.layout, context)
                return result

            draw_with_advanced_panel_filter.__name__ = draw_function.__name__
            draw_with_advanced_panel_filter.__doc__ = draw_function.__doc__
            draw_with_advanced_panel_filter.__module__ = draw_function.__module__
            draw_with_advanced_panel_filter.__qualname__ = draw_function.__qualname__
            return draw_with_advanced_panel_filter

        patched_draw = make_filtered_draw(
            original_draw,
            panel_class.__name__ == "OBJECT_PT_RbxAnimations",
        )
        panel_class.draw = patched_draw
        patches.append((panel_class, original_draw, patched_draw))

    _state["roblox_advanced_panel_patch"] = tuple(patches)
    return True


def _restore_roblox_nodes_only_default():
    invoke_patch = _state.pop("roblox_genrig_invoke_patch", None)
    if invoke_patch is not None:
        operator_class, original_invoke, patched_invoke = invoke_patch
        if getattr(operator_class, "invoke", None) is patched_invoke:
            operator_class.invoke = original_invoke

    execute_patch = _state.pop("roblox_genrig_execute_patch", None)
    if execute_patch is not None:
        operator_class, original_execute, patched_execute = execute_patch
        if getattr(operator_class, "execute", None) is patched_execute:
            operator_class.execute = original_execute


def _restore_roblox_import_patch():
    patch = _state.pop("roblox_import_execute_patch", None)
    if patch is None:
        return

    operator_class, original_execute, patched_execute = patch
    if getattr(operator_class, "execute", None) is patched_execute:
        operator_class.execute = original_execute


def _restore_roblox_unparent_patch():
    stored = _state.pop("roblox_unparent_execute_patch", None)
    if stored is None:
        return
    patches = (
        stored
        if stored and isinstance(stored[0], tuple)
        else (stored,)
    )
    for operator_class, original_execute, patched_execute in patches:
        if getattr(operator_class, "execute", None) is patched_execute:
            operator_class.execute = original_execute


def _patch_roblox_unparent_visibility():
    """Retire legacy operator patches left by an older hot-loaded generation."""
    _restore_roblox_unparent_patch()
    return True


def _patch_roblox_import_auto_generation():
    module_name = _roblox_addon_module_name()
    if module_name is None:
        return False

    try:
        import_ops = importlib.import_module(f"{module_name}.operators.import_ops")
        rig_ops = importlib.import_module(f"{module_name}.operators.rig_ops")
        operator_class = import_ops.OBJECT_OT_ImportModel
    except (AttributeError, ImportError):
        return False

    existing = _state.get("roblox_import_execute_patch")
    if existing is not None:
        if existing[0] is operator_class and operator_class.execute is existing[2]:
            return True
        _restore_roblox_import_patch()

    original_execute = operator_class.execute

    def execute_with_local_y_auto_generation(self, context):
        hide_advanced = not getattr(
            context.window_manager,
            "roblox_compat_advanced_mode",
            False,
        )
        previous_armatures = {
            obj.as_pointer() for obj in context.scene.objects if obj.type == "ARMATURE"
        }
        previous_meta = {
            obj.as_pointer()
            for obj in context.scene.objects
            if obj.type == "EMPTY" and "RigMeta" in obj
        }
        previous_collections = {
            collection.as_pointer() for collection in bpy.data.collections
        }

        original_create_rig = import_ops.create_rig
        if hide_advanced:
            def create_local_y_rig(_rigging_type, rig_meta_name):
                return original_create_rig("LOCAL_YAXIS_EXTEND", rig_meta_name)

            import_ops.create_rig = create_local_y_rig

        try:
            result = original_execute(self, context)
        finally:
            if hide_advanced:
                import_ops.create_rig = original_create_rig

        if "FINISHED" in result:
            isolated_images, isolated_materials = (
                _isolate_newly_imported_rig_textures(previous_collections)
            )
            if isolated_images:
                print(
                    "[Roblox Animator Utils] Isolated "
                    f"{isolated_images} texture node(s) across "
                    f"{isolated_materials} imported material(s)."
                )

        if "FINISHED" not in result:
            return result

        new_armatures = [
            obj
            for obj in context.scene.objects
            if obj.type == "ARMATURE" and obj.as_pointer() not in previous_armatures
        ]
        if new_armatures:
            _state.setdefault("roblox_constraints_new_rigs", set()).update(
                armature.as_pointer() for armature in new_armatures
            )
            _refresh_roblox_armature_list(context, force = True)
            _schedule_imported_rig_framing(new_armatures, context)
            _schedule_roblox_rigs_pose_mode(new_armatures)
            _schedule_rig_collection_collapse()
        if not hide_advanced:
            return result

        new_meta_names = [
            obj.name
            for obj in context.scene.objects
            if obj.type == "EMPTY"
            and "RigMeta" in obj
            and obj.as_pointer() not in previous_meta
        ]

        if new_armatures or not new_meta_names:
            _schedule_roblox_compatibility_scan(delay = 0.05)
            _schedule_smart_material_import_scan(delay = 0.05)
            return result

        scene_name = context.scene.name

        def generate_imported_rig():
            scene = bpy.data.scenes.get(scene_name)
            if scene is None:
                return None

            armatures_before_generation = {
                obj.as_pointer()
                for obj in scene.objects
                if obj.type == "ARMATURE"
            }

            for meta_name in new_meta_names:
                meta = scene.objects.get(meta_name)
                if meta is None or "RigMeta" not in meta:
                    continue
                try:
                    rig_ops.create_rig("LOCAL_YAXIS_EXTEND", meta_name)
                except Exception as exc:
                    print(
                        f"[Roblox Animator Utils] Automatic Local Y-axis rig generation failed: {exc}"
                    )

            generated_armatures = [
                obj
                for obj in scene.objects
                if obj.type == "ARMATURE"
                and obj.as_pointer() not in armatures_before_generation
            ]

            if generated_armatures:
                _state.setdefault("roblox_constraints_new_rigs", set()).update(
                    armature.as_pointer() for armature in generated_armatures
                )

            _schedule_roblox_compatibility_scan(delay = 0.05)
            _schedule_smart_material_import_scan(delay = 0.05)
            if generated_armatures:
                _schedule_imported_rig_framing(
                    generated_armatures,
                    bpy.context,
                )
                _schedule_roblox_rigs_pose_mode(generated_armatures)
                _schedule_rig_collection_collapse()
            return None

        register_owned_timer(generate_imported_rig, first_interval = 0.1)
        return result

    execute_with_local_y_auto_generation.__name__ = original_execute.__name__
    execute_with_local_y_auto_generation.__doc__ = original_execute.__doc__
    execute_with_local_y_auto_generation.__module__ = original_execute.__module__
    execute_with_local_y_auto_generation.__qualname__ = original_execute.__qualname__

    operator_class.execute = execute_with_local_y_auto_generation
    _state["roblox_import_execute_patch"] = (
        operator_class,
        original_execute,
        execute_with_local_y_auto_generation,
    )
    return True
