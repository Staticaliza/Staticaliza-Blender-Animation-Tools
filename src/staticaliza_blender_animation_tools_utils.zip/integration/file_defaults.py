"""Per-file Utils defaults shared by template loads and ordinary blend files."""

from ..core.runtime import *  # noqa: F403


ANIMATOR_UTILS_FILE_DEFAULTS_PROPERTY = (
    "_staticaliza_animator_utils_file_defaults_v1"
)
ANIMATOR_UTILS_CAMERA_FOV_DEGREES_PROPERTY = (
    "_staticaliza_animator_utils_camera_fov_degrees_v1"
)
ANIMATOR_UTILS_FILE_DEFAULTS = {
    "roblox_compat_advanced_mode": False,
    "show_bone_names_enabled": True,
    "auto_clear_object_transforms_enabled": True,
    "staticaliza_pivot_mode": "BONE",
    "staticaliza_surface_contact_mode": "AUTO",
    "surface_contact_pin_mode": "MODE_3",
    "surface_contact_cast_axis": "Y_NEG",
    "yellow_pin_mode": "MODE_3",
    "yellow_pin_axis": "Y_NEG",
    "staticaliza_camera_fov": 35.0,
    "staticaliza_camera_orientation": "Z_NEG",
    "onion_skin_mode": "SINGLE",
    "onion_skin_opacity": 0.10,
    "onion_skin_include_meshes": True,
    "onion_skin_include_bones": False,
    "onion_skin_raycast": True,
    "onion_skin_skip_hidden": True,
    "smart_material_import_enabled": True,
    "standardize_imported_material_display_enabled": True,
    "prevent_clothing_layer_clipping_enabled": False,
}


def _animator_utils_file_defaults_payload(scene):
    payload = dict(ANIMATOR_UTILS_FILE_DEFAULTS)
    if scene is None:
        return payload
    packed = scene.get(ANIMATOR_UTILS_FILE_DEFAULTS_PROPERTY)
    if packed is None:
        return payload
    try:
        saved = json.loads(str(packed))
    except (TypeError, ValueError):
        return payload
    if isinstance(saved, dict):
        for name, default in ANIMATOR_UTILS_FILE_DEFAULTS.items():
            value = saved.get(name, default)
            if isinstance(default, bool):
                payload[name] = bool(value)
            elif isinstance(default, float):
                try:
                    payload[name] = float(value)
                except (TypeError, ValueError):
                    pass
            else:
                payload[name] = str(value)
    return payload


def _animator_utils_store_file_defaults(*_):
    context = getattr(bpy, "context", None)
    scene = getattr(context, "scene", None)
    window_manager = getattr(context, "window_manager", None)
    if scene is None or window_manager is None:
        return False
    payload = {}
    for name, default in ANIMATOR_UTILS_FILE_DEFAULTS.items():
        value = getattr(window_manager, name, default)
        payload[name] = float(value) if isinstance(default, float) else value
    packed = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    if str(scene.get(ANIMATOR_UTILS_FILE_DEFAULTS_PROPERTY, "")) == packed:
        return False
    scene[ANIMATOR_UTILS_FILE_DEFAULTS_PROPERTY] = packed
    return True


def _animator_utils_apply_file_defaults(context=None, force=False):
    context = context or getattr(bpy, "context", None)
    scene = getattr(context, "scene", None)
    window_manager = getattr(context, "window_manager", None)
    if scene is None or window_manager is None:
        return False
    if force or ANIMATOR_UTILS_FILE_DEFAULTS_PROPERTY not in scene:
        scene[ANIMATOR_UTILS_FILE_DEFAULTS_PROPERTY] = json.dumps(
            ANIMATOR_UTILS_FILE_DEFAULTS,
            sort_keys=True,
            separators=(",", ":"),
        )
    payload = _animator_utils_file_defaults_payload(scene)
    if ANIMATOR_UTILS_CAMERA_FOV_DEGREES_PROPERTY not in scene:
        legacy_fov = float(payload.get("staticaliza_camera_fov", 35.0))
        if 0.0 <= legacy_fov <= math.radians(120.0) + 1.0e-8:
            payload["staticaliza_camera_fov"] = math.degrees(legacy_fov)
            scene[ANIMATOR_UTILS_FILE_DEFAULTS_PROPERTY] = json.dumps(
                payload,
                sort_keys=True,
                separators=(",", ":"),
            )
        scene[ANIMATOR_UTILS_CAMERA_FOV_DEGREES_PROPERTY] = True
    changed = False
    previous_contact_sync = bool(
        _state.get("surface_contact_pin_mode_syncing", False)
    )
    previous_contact_axis_sync = bool(
        _state.get("surface_contact_axis_syncing", False)
    )
    previous_yellow_sync = bool(_state.get("yellow_pin_mode_syncing", False))
    _state["animator_utils_file_defaults_syncing"] = True
    _state["surface_contact_pin_mode_syncing"] = True
    _state["surface_contact_axis_syncing"] = True
    _state["yellow_pin_mode_syncing"] = True
    try:
        for name, value in payload.items():
            if not hasattr(window_manager, name):
                continue
            try:
                current = getattr(window_manager, name)
                if current != value:
                    setattr(window_manager, name, value)
                    changed = True
            except (AttributeError, RuntimeError, TypeError, ValueError):
                continue
    finally:
        _state["surface_contact_pin_mode_syncing"] = previous_contact_sync
        _state["surface_contact_axis_syncing"] = previous_contact_axis_sync
        _state["yellow_pin_mode_syncing"] = previous_yellow_sync
        _state["animator_utils_file_defaults_syncing"] = False
    return changed
