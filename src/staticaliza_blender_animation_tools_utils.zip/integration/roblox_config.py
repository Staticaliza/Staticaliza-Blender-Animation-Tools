"""Roblox default configuration, version metadata, and sidebar integration."""

from ..core.runtime import *  # noqa: F403

def _patch_roblox_nodes_only_default():
    module_name = _roblox_addon_module_name()
    if module_name is None:
        return False

    try:
        rig_ops = importlib.import_module(f"{module_name}.operators.rig_ops")
        operator_class = rig_ops.OBJECT_OT_GenRig
    except (AttributeError, ImportError):
        return False

    invoke_patch = _state.get("roblox_genrig_invoke_patch")
    execute_patch = _state.get("roblox_genrig_execute_patch")
    if invoke_patch is not None or execute_patch is not None:
        invoke_current = (
            invoke_patch is None
            or (invoke_patch[0] is operator_class and operator_class.invoke is invoke_patch[2])
        )
        execute_current = (
            execute_patch is not None
            and execute_patch[0] is operator_class
            and operator_class.execute is execute_patch[2]
        )
        if invoke_current and execute_current:
            return True
        _restore_roblox_nodes_only_default()

    original_execute = operator_class.execute

    def execute_with_animator_utils_compatibility(self, context):
        source = context.scene.objects.get(self.pr_rig_meta_name)
        previous_armatures = {
            obj.as_pointer() for obj in context.scene.objects if obj.type == "ARMATURE"
        }
        result = original_execute(self, context)
        if "FINISHED" not in result:
            return result

        armature = _find_generated_roblox_armature(context, source, previous_armatures)
        if armature is None:
            self.report({"WARNING"}, "Generated armature could not be located for compatibility cleanup.")
            return result

        armature_pointer = armature.as_pointer()
        _state.setdefault("roblox_constraints_new_rigs", set()).add(
            armature_pointer
        )

        def apply_after_native_constraints():
            _state["roblox_constraints_normalized"].discard(armature_pointer)
            _schedule_roblox_compatibility_scan(delay = 0.05)
            _schedule_smart_material_import_scan(delay = 0.05)
            _schedule_roblox_rigs_pose_mode((armature,), delay = 0.05)
            return None

        register_owned_timer(apply_after_native_constraints, first_interval = 0.1)
        return result

    execute_with_animator_utils_compatibility.__name__ = original_execute.__name__
    execute_with_animator_utils_compatibility.__doc__ = original_execute.__doc__
    execute_with_animator_utils_compatibility.__module__ = original_execute.__module__
    execute_with_animator_utils_compatibility.__qualname__ = original_execute.__qualname__

    operator_class.execute = execute_with_animator_utils_compatibility
    _state["roblox_genrig_execute_patch"] = (
        operator_class,
        original_execute,
        execute_with_animator_utils_compatibility,
    )
    return True


def _normalize_version_text(version):
    if isinstance(version, (tuple, list)):
        text = ".".join(str(part) for part in version)
    elif version is None:
        return ""
    else:
        text = str(version).strip()
    return "" if not text or text.lower() == "unknown" else text.lstrip("vV")


def _roblox_version_text(module_name):
    try:
        roblox_module = importlib.import_module(module_name)
    except ImportError:
        return ""

    bl_info_data = getattr(roblox_module, "bl_info", None)
    if isinstance(bl_info_data, dict):
        version_text = _normalize_version_text(bl_info_data.get("version"))
        if version_text:
            return version_text

    try:
        panels_module = importlib.import_module(f"{module_name}.ui.panels")
        version_text = _normalize_version_text(
            getattr(panels_module, "ADDON_VERSION_TEXT", None)
        )
        if version_text:
            return version_text
    except ImportError:
        pass

    module_file = getattr(roblox_module, "__file__", "")
    search_dir = os.path.dirname(os.path.abspath(module_file)) if module_file else ""
    for _ in range(5):
        if not search_dir:
            break
        manifest_path = os.path.join(search_dir, "blender_manifest.toml")
        try:
            with open(manifest_path, "rb") as manifest_file:
                version_text = _normalize_version_text(
                    tomllib.load(manifest_file).get("version")
                )
            if version_text:
                return version_text
        except (OSError, tomllib.TOMLDecodeError):
            pass
        parent_dir = os.path.dirname(search_dir)
        if parent_dir == search_dir:
            break
        search_dir = parent_dir

    return ""


def _configure_roblox_sidebar_tabs():
    if not _roblox_addon_is_enabled():
        return None

    _patch_roblox_nodes_only_default()
    _patch_roblox_import_auto_generation()
    _patch_roblox_advanced_panels()
    _patch_roblox_preview_draw_callbacks()
    _patch_roblox_bone_color_updates()
    _patch_roblox_serializer()
    _patch_roblox_export()

    module_name = _roblox_addon_module_name()
    version_text = ""
    if module_name:
        try:
            roblox_module = importlib.import_module(module_name)
            if isinstance(getattr(roblox_module, "bl_info", None), dict):
                _set_roblox_metadata_item(
                    roblox_module.bl_info,
                    "name",
                    "Roblox Animator",
                )
        except ImportError:
            pass

        version_text = _roblox_version_text(module_name)

        try:
            animation_ops = importlib.import_module(f"{module_name}.operators.animation_ops")
            _set_roblox_metadata_attribute(
                animation_ops.OBJECT_OT_Bake,
                "bl_label",
                "Export",
            )
            _set_roblox_metadata_attribute(
                animation_ops.OBJECT_OT_Bake,
                "bl_description",
                "Export animation to clipboard",
            )
        except (AttributeError, ImportError):
            pass

    animator_panels = []
    for type_name in dir(bpy.types):
        panel = getattr(bpy.types, type_name, None)
        if not isinstance(panel, type):
            continue
        try:
            is_panel = issubclass(panel, bpy.types.Panel)
        except TypeError:
            is_panel = False
        if not is_panel:
            continue
        panel_module = str(getattr(panel, "__module__", ""))
        panel_id = str(getattr(panel, "bl_idname", ""))
        category = str(getattr(panel, "bl_category", ""))
        if (
            (module_name and panel_module.startswith(module_name))
            or panel_id.startswith("OBJECT_PT_RbxAnimations")
        ) and category in {"Rbx Animations", "Roblox Animator"}:
            animator_panels.append(panel)

    # Blender's sidebar-category registry is created when panels register.
    # Re-register the whole external panel family (children first on removal,
    # parents first on addition) so no leftover class can recreate the old
    # Rbx Animations tab after the main panel was patched.
    category_updates = [
        panel
        for panel in animator_panels
        if str(getattr(panel, "bl_category", "")) != "Roblox Animator"
    ]
    for panel in sorted(
        category_updates,
        key=lambda item: bool(str(getattr(item, "bl_parent_id", ""))),
        reverse=True,
    ):
        try:
            bpy.utils.unregister_class(panel)
        except RuntimeError:
            pass
    for panel in category_updates:
        _set_roblox_metadata_attribute(
            panel, "bl_category", "Roblox Animator"
        )
    for panel in sorted(
        category_updates,
        key=lambda item: bool(str(getattr(item, "bl_parent_id", ""))),
    ):
        try:
            bpy.utils.register_class(panel)
        except RuntimeError:
            pass

    roblox_panel = getattr(bpy.types, "OBJECT_PT_RbxAnimations", None)
    if roblox_panel is not None:
        panel_label = "Roblox Animator"
        if version_text:
            panel_label += f" (v{version_text})"
        if roblox_panel.bl_label != panel_label:
            _set_roblox_metadata_attribute(
                roblox_panel,
                "bl_label",
                panel_label,
            )
        if roblox_panel.bl_category != "Roblox Animator":
            _set_roblox_metadata_attribute(
                roblox_panel, "bl_category", "Roblox Animator"
            )

    tool_panel = getattr(bpy.types, "OBJECT_PT_RbxAnimations_Tool", None)
    if tool_panel is not None:
        tool_label = "Roblox Animator"
        if version_text:
            tool_label += f" (v{version_text})"
        _set_roblox_metadata_attribute(tool_panel, "bl_label", tool_label)

    _refresh_roblox_armature_list(bpy.context, force = True)
    return None


def _roblox_metadata_record(kind, target, name):
    for record in _state.setdefault("roblox_metadata_patches", []):
        if record[0] == kind and record[1] is target and record[2] == name:
            return record
    return None


def _set_roblox_metadata_attribute(target, name, value):
    if _roblox_metadata_record("ATTR", target, name) is None:
        _state["roblox_metadata_patches"].append(
            ("ATTR", target, name, getattr(target, name))
        )
    setattr(target, name, value)


def _set_roblox_metadata_item(target, name, value):
    if _roblox_metadata_record("ITEM", target, name) is None:
        _state["roblox_metadata_patches"].append(
            ("ITEM", target, name, name in target, target.get(name))
        )
    target[name] = value


def _restore_roblox_metadata_patches():
    for record in reversed(_state.setdefault("roblox_metadata_patches", [])):
        kind, target, name, *saved = record
        try:
            if kind == "ATTR":
                setattr(target, name, saved[0])
            elif saved[0]:
                target[name] = saved[1]
            else:
                target.pop(name, None)
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            pass
    _state["roblox_metadata_patches"] = []
