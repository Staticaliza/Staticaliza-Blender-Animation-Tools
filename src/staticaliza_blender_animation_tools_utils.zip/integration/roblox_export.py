"""Roblox serializer and dynamic-animation export monkey patches."""

from ..core.runtime import *  # noqa: F403

def _restore_roblox_serializer_patch():
    patch = _state.pop("roblox_serializer_patch", None)
    if patch is None:
        return

    serialization_module, original_function, patched_function = patch[:3]
    if serialization_module.get_all_constrained_bones is patched_function:
        serialization_module.get_all_constrained_bones = original_function
    if len(patch) >= 5:
        original_serialize, patched_serialize = patch[3:5]
        if getattr(serialization_module, "serialize", None) is patched_serialize:
            serialization_module.serialize = original_serialize
        consumer_names = patch[5] if len(patch) >= 6 else ()
        for module_name in consumer_names:
            consumer = sys.modules.get(module_name)
            if consumer is not None and getattr(
                consumer,
                "serialize",
                None,
            ) is patched_serialize:
                consumer.serialize = original_serialize


def _linearize_dynamic_export_samples(result, bone_names):
    if not isinstance(result, dict) or not bone_names:
        return result
    for keyframe in result.get("kfs", ()):
        if not isinstance(keyframe, dict):
            continue
        states = keyframe.get("kf", {})
        if not isinstance(states, dict):
            continue
        for bone_name in bone_names:
            state = states.get(bone_name)
            if not isinstance(state, (list, tuple)) or len(state) < 3:
                continue
            if isinstance(state, tuple):
                state = list(state)
                states[bone_name] = state
            if str(state[1]) == "Constant":
                continue
            state[1] = "Linear"
            state[2] = "Out"
    return result


def _orthonormalize_dynamic_export_cframe(components):
    if not isinstance(components, (list, tuple)) or len(components) != 12:
        return list(components) if isinstance(components, (list, tuple)) else components

    try:
        transform = Matrix.Identity(4)
        transform.translation = (
            float(components[0]),
            float(components[1]),
            float(components[2]),
        )
        transform[0][0:3] = tuple(float(value) for value in components[3:6])
        transform[1][0:3] = tuple(float(value) for value in components[6:9])
        transform[2][0:3] = tuple(float(value) for value in components[9:12])
        location, rotation, _scale = transform.decompose()
        rotation.normalize()
        normalized = rotation.to_matrix().to_4x4()
        normalized.translation = location
        return [
            float(normalized[0][3]),
            float(normalized[1][3]),
            float(normalized[2][3]),
            float(normalized[0][0]),
            float(normalized[0][1]),
            float(normalized[0][2]),
            float(normalized[1][0]),
            float(normalized[1][1]),
            float(normalized[1][2]),
            float(normalized[2][0]),
            float(normalized[2][1]),
            float(normalized[2][2]),
        ]
    except (ArithmeticError, TypeError, ValueError):
        return list(components)


def _snapshot_dynamic_export_constraint_state(armature_obj):
    if armature_obj is None or getattr(armature_obj, "pose", None) is None:
        return []

    owners = [armature_obj]
    owners.extend(armature_obj.pose.bones)
    snapshot = []
    for owner in owners:
        for constraint in getattr(owner, "constraints", ()):
            if not (
                _is_dynamic_state_constraint(constraint)
                or str(getattr(constraint, "name", "")).startswith(
                    SURFACE_CONTACT_CONSTRAINT_PREFIX
                )
            ):
                continue
            inverse_matrix = getattr(constraint, "inverse_matrix", None)
            snapshot.append(
                (
                    constraint,
                    getattr(constraint, "target", None),
                    str(getattr(constraint, "subtarget", "")),
                    float(getattr(constraint, "influence", 0.0)),
                    bool(getattr(constraint, "mute", False)),
                    inverse_matrix.copy() if inverse_matrix is not None else None,
                )
            )
    return snapshot


def _restore_dynamic_export_constraint_state(snapshot):
    for constraint, target, subtarget, influence, mute, inverse_matrix in snapshot:
        try:
            constraint.target = target
            constraint.subtarget = subtarget
            if inverse_matrix is not None and hasattr(constraint, "inverse_matrix"):
                constraint.inverse_matrix = inverse_matrix
            constraint.influence = influence
            constraint.mute = mute
        except (AttributeError, ReferenceError, RuntimeError):
            pass


def _dynamic_export_face_context(serialization_module, armature_obj):
    build_context = getattr(
        serialization_module,
        "_build_face_control_export_context",
        None,
    )
    if not callable(build_context):
        return None

    animation_data = getattr(armature_obj, "animation_data", None)
    action = getattr(animation_data, "action", None)
    actions = {action} if action is not None else set()
    action_slots = {}
    get_slot = getattr(serialization_module, "get_animation_data_action_slot", None)
    if action is not None and callable(get_slot):
        try:
            action_slots[action] = get_slot(animation_data, action = action)
        except Exception:
            pass
    try:
        return build_context(armature_obj, actions, action_slots)
    except Exception:
        return None


def _dense_dynamic_export_samples(
    serialization_module,
    armature_obj,
    result,
    managed_bones,
):
    if not isinstance(result, dict) or not managed_bones:
        return result

    serialize_state = getattr(
        serialization_module,
        "serialize_combined_animation_state",
        None,
    )
    if not callable(serialize_state):
        raise RuntimeError("The Roblox exporter cannot sample evaluated animation; update Roblox Animator")

    original_keyframes = [
        keyframe
        for keyframe in result.get("kfs", ())
        if isinstance(keyframe, dict)
    ]
    export_bones = set(managed_bones)
    for keyframe in original_keyframes:
        states = keyframe.get("kf", {})
        if isinstance(states, dict):
            export_bones.update(states)
    if not export_bones:
        return result

    scene = bpy.context.scene
    export_info = result.get("export_info", {})
    if not isinstance(export_info, dict):
        export_info = {}
        result["export_info"] = export_info

    try:
        fps = float(export_info.get("fps", 0.0))
    except (TypeError, ValueError):
        fps = 0.0
    if fps <= 0.0:
        fps_base = float(getattr(scene.render, "fps_base", 1.0) or 1.0)
        fps = max(float(getattr(scene.render, "fps", 30.0)) / fps_base, 1.0)

    # A dynamically detached bone is still stored below its original Roblox
    # parent. Its inverse-parent compensation is nonlinear between samples, so
    # 60 Hz leaves a small world-space wobble after Roblox interpolates both
    # tracks. Four sub-samples per 60 Hz display interval keeps that residual
    # below visible precision without changing the Blender animation itself.
    sample_factor = max(
        1,
        int(math.ceil(DYNAMIC_EXPORT_TARGET_FPS / (fps * 1.000001))),
    )
    sample_factor = min(sample_factor, DYNAMIC_EXPORT_MAX_SAMPLE_FACTOR)
    frame_start = int(export_info.get("frame_start", scene.frame_start))
    frame_end = int(export_info.get("frame_end", scene.frame_end))
    if frame_end < frame_start:
        return _linearize_dynamic_export_samples(result, managed_bones)

    required_api = (
        "get_transform_to_blender",
        "is_deform_bone_rig",
        "resolve_deform_rig_scale_factor",
        "identity_cf",
    )
    if any(not hasattr(serialization_module, name) for name in required_api):
        raise RuntimeError("The Roblox exporter is missing evaluated animation support; update Roblox Animator")

    settings = getattr(scene, "rbx_anim_settings", None)
    force_deform = bool(
        getattr(settings, "force_deform_bone_serialization", False)
    )
    is_skinned_rig = bool(
        serialization_module.is_deform_bone_rig(armature_obj) or force_deform
    )
    is_face_control_bone = getattr(
        serialization_module,
        "is_face_control_bone",
        lambda _bone: False,
    )
    has_new_bones = any(
        not (
            "transform" in pose_bone.bone
            and "transform1" in pose_bone.bone
            and "nicetransform" in pose_bone.bone
        )
        and not is_face_control_bone(pose_bone)
        for pose_bone in armature_obj.pose.bones
    )
    run_deform_path = is_skinned_rig or has_new_bones

    back_transform = serialization_module.get_transform_to_blender().inverted()
    world_transform = back_transform @ armature_obj.matrix_world
    try:
        scale_factor = float(export_info.get("deform_scale_factor"))
    except (TypeError, ValueError):
        scale_factor = serialization_module.resolve_deform_rig_scale_factor(
            armature_obj,
            settings,
        )

    face_context = _dynamic_export_face_context(
        serialization_module,
        armature_obj,
    )
    excluded_face_bones = set(
        (face_context or {}).get("face_bone_names", ())
    )
    serialize_face = getattr(
        serialization_module,
        "_serialize_face_control_state_for_frame",
        None,
    )

    dense_keyframes = []
    identity_cframe = list(serialization_module.identity_cf)
    static_cache = {}
    motor_state_reuse = {}
    deform_state_reuse = {}
    # Upstream samplers moved depsgraph/cache arguments between releases.
    # Resolve their named contract once, outside the dense sampling loop.
    import inspect
    parameters=inspect.signature(serialize_state).parameters
    options=dict(run_deform_path=run_deform_path,skinned_rig=is_skinned_rig,
        back_trans_cached=back_transform,world_transform_cached=world_transform,
        scale_factor_cached=scale_factor,static_cache=static_cache,
        motor_state_reuse=motor_state_reuse,deform_state_reuse=deform_state_reuse,
        excluded_deform_bones=excluded_face_bones)
    accepts_keywords=any(p.kind==inspect.Parameter.VAR_KEYWORD for p in parameters.values())
    sample_options={name:value for name,value in options.items() if accepts_keywords or name in parameters}
    needs_depsgraph=accepts_keywords or 'depsgraph' in parameters
    last_face_state = None
    saved_frame = int(scene.frame_current)
    saved_subframe = float(getattr(scene, "frame_subframe", 0.0))
    previous_export_sampling = bool(
        _state.get("dynamic_space_export_sampling", False)
    )

    _state["dynamic_space_export_sampling"] = True
    try:
        step_count = (frame_end - frame_start) * sample_factor
        sample_frames = {round(frame_start + step/sample_factor, 7)
                         for step in range(step_count + 1)}
        # Retain exact authored times, including fractional frames that do not
        # fall on the dense grid. Sampling never edits the source F-curves.
        sample_frames.update(round(frame_start + float(key.get("t", 0))*fps, 7)
                             for key in original_keyframes)
        # Dense samples already include native easing. Record dependency key
        # boundaries as well, so discontinuous parent/pin inputs can retain
        # their incoming value immediately before the exact authored time.
        pending=[armature_obj]
        pending.extend(g for g in _surface_contact_guides()
                       if str(g.get(SURFACE_CONTACT_ARMATURE_PROPERTY,''))==armature_obj.name)
        pending.extend(g for b in armature_obj.pose.bones if (g:=_gyro_find(bpy.context,armature_obj,b)) is not None)
        visited=set();boundaries=set()
        while pending:
            owner=pending.pop()
            if owner.as_pointer() in visited:continue
            visited.add(owner.as_pointer())
            action=_dynamic_parent_owner_action(owner)
            boundaries.update(round(float(key.co.x),7)
                for curve in _action_fcurves(action,owner) for key in curve.keyframe_points)
            if owner.parent is not None:pending.append(owner.parent)
            subjects=(owner,*owner.pose.bones) if owner.type=='ARMATURE' else (owner,)
            for subject in subjects:
                for constraint in subject.constraints:
                    target=getattr(constraint,'target',None)
                    if target is not None:pending.append(target)
        sample_frames.update(boundaries)
        # Upstream's visual optimizer can choose Constant for one export and
        # Linear for the next. Its guesses must not control a moving baked
        # interval. Linear samples plus pre-key values preserve the evaluated
        # curve and stepped jumps. Stay outside Blender's 0.0001-frame
        # key-evaluation equality band as well as float32 time precision.
        for at in boundaries:
            before=round(at-max(2.e-4,abs(at)*2.**-22),7)
            if frame_start<=before<at<=frame_end:sample_frames.add(before)
        for frame in sorted(f for f in sample_frames if frame_start <= f <= frame_end):
            frame_int = int(math.floor(frame))
            frame_subframe = float(frame - frame_int)
            reuse=_state.get('dynamic_export_pose_samples')
            current_state=(reuse[1].get(round(frame,7)) if reuse is not None
                           and reuse[0]==armature_obj.as_pointer() and not (face_context or {}).get('enabled') else None)
            if current_state is None:
                scene.frame_set(frame_int, subframe = frame_subframe)

                depsgraph = bpy.context.evaluated_depsgraph_get()
                evaluated_armature = armature_obj.evaluated_get(depsgraph)
                if needs_depsgraph:sample_options['depsgraph']=depsgraph
                current_state = serialize_state(armature_obj,evaluated_armature,**sample_options)
            else:
                _state['dynamic_export_reused_samples']=_state.get('dynamic_export_reused_samples',0)+1

            time_seconds = (frame - frame_start) / fps
            wrapped_state = {}
            for bone_name in sorted(export_bones):
                cframe = current_state.get(bone_name, identity_cframe)
                wrapped_state[bone_name] = [
                    _orthonormalize_dynamic_export_cframe(cframe),
                    "Linear",
                    "Out",
                ]

            keyframe_payload = {
                "t": time_seconds,
                "kf": wrapped_state,
            }
            if callable(serialize_face) and face_context:
                face_state, last_face_state = serialize_face(
                    armature_obj,
                    face_context,
                    float(frame),
                    last_face_state,
                )
                if face_state:
                    for control_name, state in face_state.items():
                        state["easingStyle"] = "Linear"
                        state["easingDirection"] = "Out"
                    keyframe_payload["fc"] = face_state
            dense_keyframes.append(keyframe_payload)
    except Exception as exc:
        raise RuntimeError(f"Could not bake evaluated animation for export: {exc}") from exc
    finally:
        try:
            scene.frame_set(saved_frame, subframe = saved_subframe)
        except Exception:
            pass
        _state["dynamic_space_export_sampling"] = previous_export_sampling

    result["kfs"] = dense_keyframes
    result["t"] = (frame_end - frame_start) / fps
    export_info["dynamic_space_sample_factor"] = sample_factor
    export_info["dynamic_space_sample_fps"] = fps * sample_factor
    return result


def _restore_dynamic_unparent_export_metadata(saved_metadata):
    for bone, had_worldspace, worldspace_value, had_parent, parent_value in saved_metadata:
        try:
            if had_worldspace:
                bone["worldspace_bone"] = worldspace_value
            elif "worldspace_bone" in bone:
                del bone["worldspace_bone"]

            if had_parent:
                bone["worldspace_original_parent"] = parent_value
            elif "worldspace_original_parent" in bone:
                del bone["worldspace_original_parent"]
        except Exception:
            pass


def _apply_dynamic_unparent_export_metadata(armature):
    saved_metadata = []
    if not armature or armature.type != "ARMATURE":
        return saved_metadata

    for bone_name in _unparent_rel_scan_arm(armature):
        bone = armature.data.bones.get(bone_name)
        if bone is None:
            continue
        parent_name = str(bone.get(REL_K_PARENT, ""))
        if not parent_name:
            continue

        had_worldspace = "worldspace_bone" in bone
        worldspace_value = bone.get("worldspace_bone")
        had_parent = "worldspace_original_parent" in bone
        parent_value = bone.get("worldspace_original_parent")
        saved_metadata.append(
            (bone, had_worldspace, worldspace_value, had_parent, parent_value)
        )
        bone["worldspace_bone"] = True
        bone["worldspace_original_parent"] = parent_name

    return saved_metadata


def _restore_roblox_export_patch():
    patches = _state.pop("roblox_export_execute_patch", None)
    if not patches:
        return

    for operator_class, original_execute, patched_execute in patches:
        if getattr(operator_class, "execute", None) is patched_execute:
            operator_class.execute = original_execute


def _patch_roblox_export():
    module_name = _roblox_addon_module_name()
    if module_name is None:
        return False

    try:
        animation_ops = importlib.import_module(f"{module_name}.operators.animation_ops")
    except ImportError:
        return False

    operator_classes = [
        getattr(animation_ops, "OBJECT_OT_Bake", None),
        getattr(animation_ops, "OBJECT_OT_Bake_File", None),
    ]
    operator_classes = [operator_class for operator_class in operator_classes if operator_class]
    if not operator_classes:
        return False

    existing = _state.get("roblox_export_execute_patch")
    if existing and all(
        getattr(operator_class, "execute", None) is patched_execute
        for operator_class, _original_execute, patched_execute in existing
    ):
        return True
    _restore_roblox_export_patch()

    patches = []
    for operator_class in operator_classes:
        original_execute = _unwrap_animator_utils_patch(
            operator_class.execute,
            "roblox_export_execute",
            legacy_code_names = ("execute_with_dynamic_unparent",),
            legacy_original_names = ("execute_function",),
        )

        def make_export_execute(execute_function):
            def execute_with_dynamic_unparent(self, context):
                started = time.perf_counter()
                _state.pop('dynamic_export_last_duration', None)
                settings = getattr(context.scene, "rbx_anim_settings", None)
                armature_name = getattr(settings, "rbx_anim_armature", "") if settings else ""
                armature = context.scene.objects.get(armature_name) if armature_name else None
                if armature is None and armature_name:
                    armature = bpy.data.objects.get(armature_name)

                saved_frame = int(context.scene.frame_current)
                saved_subframe = float(context.scene.frame_subframe)
                previous_export_armature = _state.get("unparent_export_armature")
                previous_handler_mute = bool(
                    _state.get("unparent_handler_mute", False)
                )
                saved_metadata = _apply_dynamic_unparent_export_metadata(armature)
                _state["unparent_export_armature"] = armature
                _state["unparent_handler_mute"] = False

                try:
                    if armature is not None:
                        _unparent_frame_change_post(context.scene, None)
                    outcome = execute_function(self, context)
                finally:
                    try:
                        context.scene.frame_set(saved_frame, subframe=saved_subframe)
                        if armature is not None:
                            _unparent_frame_change_post(context.scene, None)
                    except Exception:
                        pass
                    _state["unparent_export_armature"] = previous_export_armature
                    _state["unparent_handler_mute"] = previous_handler_mute
                    _restore_dynamic_unparent_export_metadata(saved_metadata)
                    try:
                        context.view_layer.update()
                    except Exception:
                        pass
                elapsed = time.perf_counter() - started
                _state['dynamic_export_last_seconds'] = elapsed
                duration = _state.get('dynamic_export_last_duration')
                if outcome == {'FINISHED'} and duration is not None:
                    self.report({'INFO'}, f"Export completed in {elapsed:.2f} s (animation duration: {duration:.2f} s)")
                return outcome

            execute_with_dynamic_unparent.__name__ = execute_function.__name__
            execute_with_dynamic_unparent.__doc__ = execute_function.__doc__
            execute_with_dynamic_unparent.__module__ = execute_function.__module__
            execute_with_dynamic_unparent.__qualname__ = execute_function.__qualname__
            return _tag_animator_utils_patch(
                execute_with_dynamic_unparent,
                execute_function,
                "roblox_export_execute",
            )

        patched_execute = make_export_execute(original_execute)
        operator_class.execute = patched_execute
        patches.append((operator_class, original_execute, patched_execute))

    _state["roblox_export_execute_patch"] = patches
    return True


def _patch_roblox_serializer():
    module_name = _roblox_addon_module_name()
    if module_name is None:
        return False

    try:
        serialization_module = importlib.import_module(
            f"{module_name}.animation.serialization"
        )
    except ImportError:
        return False

    existing = _state.get("roblox_serializer_patch")
    if existing is not None:
        if (
            existing[0] is serialization_module
            and serialization_module.get_all_constrained_bones is existing[2]
            and len(existing) >= 5
            and getattr(serialization_module, "serialize", None) is existing[4]
            and all(
                sys.modules.get(consumer_name) is None
                or getattr(
                    sys.modules[consumer_name],
                    "serialize",
                    None,
                ) is existing[4]
                for consumer_name in (existing[5] if len(existing) >= 6 else ())
            )
        ):
            return True
        _restore_roblox_serializer_patch()

    original_function = _unwrap_animator_utils_patch(
        serialization_module.get_all_constrained_bones,
        "roblox_constrained_bones",
        legacy_code_names = (
            "get_all_constrained_bones_with_dynamic_unparent",
        ),
        legacy_original_names = ("original_function",),
    )
    original_serialize = _unwrap_animator_utils_patch(
        serialization_module.serialize,
        "roblox_serialize",
        legacy_code_names = ("serialize_with_dynamic_spaces",),
        legacy_original_names = ("original_serialize",),
    )

    def get_all_constrained_bones_with_dynamic_unparent(armature_obj):
        constrained = set(original_function(armature_obj))
        constrained.update(_unparent_rel_scan_arm(armature_obj))
        constrained.update(_surface_contact_export_bones(armature_obj))
        constrained.update(_ragdoll_export_bones(armature_obj))
        constrained.update(_gyro_export_bones(armature_obj))
        return constrained

    get_all_constrained_bones_with_dynamic_unparent.__name__ = original_function.__name__
    get_all_constrained_bones_with_dynamic_unparent.__doc__ = original_function.__doc__
    get_all_constrained_bones_with_dynamic_unparent.__module__ = original_function.__module__
    get_all_constrained_bones_with_dynamic_unparent.__qualname__ = original_function.__qualname__
    _tag_animator_utils_patch(
        get_all_constrained_bones_with_dynamic_unparent,
        original_function,
        "roblox_constrained_bones",
    )

    def serialize_with_dynamic_spaces(*args, **kwargs):
        armature_obj = args[0] if args else kwargs.get("ao")
        export_depth = int(
            getattr(serialization_module, ROBLOX_UTILS_EXPORT_DEPTH_ATTR, 0)
            or 0
        )
        if export_depth > 0:
            return original_serialize(*args, **kwargs)

        scene = bpy.context.scene
        saved_frame = int(scene.frame_current)
        saved_subframe = float(getattr(scene, "frame_subframe", 0.0))
        constraint_snapshot = _snapshot_dynamic_export_constraint_state(
            armature_obj
        )
        previous_export_sampling = bool(
            _state.get("dynamic_space_export_sampling", False)
        )
        setattr(
            serialization_module,
            ROBLOX_UTILS_EXPORT_DEPTH_ATTR,
            export_depth + 1,
        )
        _ragdoll_native_cancel_job()
        previous_baking = bool(_state.get('ragdoll_baking', False))
        _state['ragdoll_baking'] = True
        _state["dynamic_space_export_sampling"] = True
        saved_metadata = []
        previous_samples = _state.get('dynamic_export_pose_samples')
        sample_function = getattr(serialization_module,'serialize_combined_animation_state',None)
        samples={}
        def remember_sample(*sample_args,**sample_kwargs):
            output=sample_function(*sample_args,**sample_kwargs)
            owner=sample_args[0] if sample_args else sample_kwargs.get('armature_obj')
            if owner==armature_obj:
                samples[round(scene.frame_current_final,7)]={name:tuple(cf) for name,cf in output.items()}
            return output
        try:
            saved_metadata = _apply_dynamic_unparent_export_metadata(armature_obj)
            keyed_bones = _roblox_export_keyed_pose_bones(armature_obj)
            if callable(sample_function) and armature_obj is not None and _state.get('dynamic_export_reuse_samples',True):
                _state['dynamic_export_pose_samples']=(armature_obj.as_pointer(),samples)
                serialization_module.serialize_combined_animation_state=remember_sample
            try:
                result = original_serialize(*args, **kwargs)
            finally:
                if getattr(serialization_module,'serialize_combined_animation_state',None) is remember_sample:
                    serialization_module.serialize_combined_animation_state=sample_function
            if armature_obj is None or getattr(armature_obj, "pose", None) is None:
                return _apply_roblox_camera_fov_metadata(
                    _apply_roblox_animation_metadata(result, scene, armature_obj),
                    scene,
                    armature_obj,
                )
            managed_bones = {
                pose_bone.name
                for pose_bone in armature_obj.pose.bones
                if _pose_space_managed(pose_bone)
            }
            contact_bones = _surface_contact_export_bones(armature_obj)
            managed_bones.update(contact_bones)
            managed_bones.update(_ragdoll_export_bones(armature_obj))
            managed_bones.update(_gyro_export_bones(armature_obj))
            managed_bones.update(keyed_bones)
            result = _dense_dynamic_export_samples(
                serialization_module,
                armature_obj,
                result,
                managed_bones,
            )
            result = _filter_unkeyed_bones_from_roblox_export(
                result,
                # A keyed Contact control semantically authors its entire
                # evaluated IK chain even when those dependent bones have no
                # direct transform curves of their own.
                keyed_bones | managed_bones,
            )
            _state['dynamic_export_last_duration'] = float(result.get('t', 0.0))
            return _apply_roblox_camera_fov_metadata(
                _apply_roblox_animation_metadata(result, scene, armature_obj),
                scene,
                armature_obj,
            )
        finally:
            if previous_samples is None:_state.pop('dynamic_export_pose_samples',None)
            else:_state['dynamic_export_pose_samples']=previous_samples
            try:
                scene.frame_set(saved_frame, subframe = saved_subframe)
            except Exception:
                pass
            _restore_dynamic_export_constraint_state(constraint_snapshot)
            _restore_dynamic_unparent_export_metadata(saved_metadata)
            _state['ragdoll_baking'] = previous_baking
            _state["dynamic_space_export_sampling"] = previous_export_sampling
            setattr(
                serialization_module,
                ROBLOX_UTILS_EXPORT_DEPTH_ATTR,
                export_depth,
            )
            try:
                bpy.context.view_layer.update()
            except Exception:
                pass

    serialize_with_dynamic_spaces.__name__ = original_serialize.__name__
    serialize_with_dynamic_spaces.__doc__ = original_serialize.__doc__
    serialize_with_dynamic_spaces.__module__ = original_serialize.__module__
    serialize_with_dynamic_spaces.__qualname__ = original_serialize.__qualname__
    _tag_animator_utils_patch(
        serialize_with_dynamic_spaces,
        original_serialize,
        "roblox_serialize",
    )

    serialization_module.get_all_constrained_bones = get_all_constrained_bones_with_dynamic_unparent
    serialization_module.serialize = serialize_with_dynamic_spaces
    serialize_consumer_names = (
        f"{module_name}.animation",
        f"{module_name}.operators.animation_ops",
        f"{module_name}.server.requests",
    )
    try:
        importlib.import_module(f"{module_name}.operators.animation_ops")
    except ImportError:
        pass
    for consumer_name in serialize_consumer_names:
        consumer = sys.modules.get(consumer_name)
        if consumer is None:
            continue
        consumer_serialize = getattr(consumer, "serialize", None)
        consumer_original = _unwrap_animator_utils_patch(
            consumer_serialize,
            "roblox_serialize",
            legacy_code_names = ("serialize_with_dynamic_spaces",),
            legacy_original_names = ("original_serialize",),
        )
        if consumer_original is original_serialize:
            consumer.serialize = serialize_with_dynamic_spaces
    _state["roblox_serializer_patch"] = (
        serialization_module,
        original_function,
        get_all_constrained_bones_with_dynamic_unparent,
        original_serialize,
        serialize_with_dynamic_spaces,
        serialize_consumer_names,
    )
    return True
