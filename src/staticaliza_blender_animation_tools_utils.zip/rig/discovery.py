"""Roblox rig discovery, armature enumeration, and display identity."""

from ..core.runtime import *  # noqa: F403

def _iter_roblox_rigs():
    if extension_update_guard_active():
        return
    seen = set()

    try:
        collections = tuple(bpy.data.collections)
    except (ReferenceError, RuntimeError, UnicodeDecodeError):
        return

    for collection in collections:
        try:
            children = tuple(collection.children)
            parts = next(
                (
                    child for child in children
                    if _strip_blender_numeric_suffix(child.name) == "Parts"
                    or _strip_blender_numeric_suffix(child.name).endswith(" Parts")
                ),
                None,
            )
            if parts is None:
                continue
            rig_children = tuple(
                child for child in children
                if _strip_blender_numeric_suffix(child.name) == "Rig"
                or _strip_blender_numeric_suffix(child.name).endswith(" Rig")
            )
            # Inspect only this scaffold's objects. A .place umbrella can
            # contain several nested .model rigs; all_objects would pair a
            # meta object with an armature from a different child model.
            objects = tuple(collection.objects) + tuple(
                obj for child in rig_children for obj in child.objects
            )
            armatures = {
                _strip_blender_numeric_suffix(obj.name): obj
                for obj in objects if obj.type == "ARMATURE"
            }
            metas = tuple(
                obj for obj in objects
                if obj.type == "EMPTY" and "RigMeta" in obj
            )
        except (AttributeError, ReferenceError, RuntimeError, UnicodeDecodeError):
            continue

        for meta in metas:
            meta_name = _strip_blender_numeric_suffix(meta.name)
            if not (meta_name.startswith("__") and meta_name.endswith("Meta")):
                continue
            rig_name = meta_name[2:-4]
            armature = armatures.get(f"__{rig_name}_Armature")
            if armature is None:
                continue
            try:
                pointer = int(armature.as_pointer())
            except (AttributeError, ReferenceError, RuntimeError):
                continue
            if pointer not in seen:
                seen.add(pointer)
                yield collection, armature, meta


def _iter_roblox_rig_armatures():
    for _collection, armature, _meta in _iter_roblox_rigs():
        yield armature


def _rig_display_name(armature_name):
    name = str(armature_name or "")
    if name.startswith("__"):
        name = name[2:]
    marker = "_Armature"
    marker_index = name.rfind(marker)
    if marker_index >= 0:
        suffix = name[marker_index + len(marker):]
        if not suffix or (
            suffix.startswith(".") and suffix[1:].isdigit()
        ):
            name = name[:marker_index] + suffix
    return name or str(armature_name or "Armature")
