"""Imported rig material, texture, and clothing compatibility helpers."""

import json
import numpy as np

from mathutils import Vector
import bmesh

from ..core.runtime import *  # noqa: F403

def _clear_material_input_links(node_tree, socket_names, visited = None):
    if node_tree is None:
        return 0
    if getattr(node_tree, "library", None) is not None:
        return 0

    if visited is None:
        visited = set()

    tree_id = node_tree.as_pointer()
    if tree_id in visited:
        return 0
    visited.add(tree_id)

    removed = 0

    for node in node_tree.nodes:
        for socket_name in socket_names:
            socket = node.inputs.get(socket_name)
            if not socket or not socket.is_linked:
                continue

            for link in tuple(socket.links):
                node_tree.links.remove(link)
                removed += 1

        if node.type == "GROUP" and getattr(node, "node_tree", None):
            removed += _clear_material_input_links(node.node_tree, socket_names, visited)

    return removed

def dp_clear_material_links():
    removed = 0
    visited = set()

    for material in bpy.data.materials:
        if getattr(material, "library", None) is not None:
            continue
        if _is_bundled_template_baseplate_material(material):
            continue
        node_tree = getattr(material, "node_tree", None)
        if node_tree is None:
            continue
        removed += _clear_material_input_links(node_tree, {"Base Color", "Alpha"}, visited)

    return removed


def _is_bundled_template_baseplate_material(material):
    if material is None or material.name != "Baseplate":
        return False
    node_tree = getattr(material, "node_tree", None)
    if node_tree is None or not any(
        node.type == "TEX_IMAGE"
        and getattr(getattr(node, "image", None), "name", "") == "Baseplate.png"
        for node in node_tree.nodes
    ):
        return False

    baseplate = bpy.data.objects.get("Baseplate")
    if baseplate is None or baseplate.type != "MESH":
        return False
    return any(slot.material == material for slot in baseplate.material_slots)

def _strip_blender_numeric_suffix(name):
    base, separator, suffix = str(name).rpartition(".")
    if separator and suffix.isdigit():
        return base
    return name


def _collection_objects_snapshot(collection):
    """Return current collection objects without holding an RNA iterator.

    Blender 5.2 can invalidate collection element wrappers between an undoable
    operator and an app-timer tick. Iterating ``Collection.all_objects`` then
    asks RNA to create Python wrappers from the invalidated iterator and can
    crash Blender before Python can raise ``ReferenceError``. Snapshot names
    from the freshly reacquired collections first, then resolve each object.
    """

    try:
        pending_collection_names = [str(collection.name)]
    except (AttributeError, ReferenceError):
        return ()
    visited_collections = set()
    object_names = []
    visited_objects = set()
    while pending_collection_names:
        collection_name = pending_collection_names.pop(0)
        if collection_name in visited_collections:
            continue
        visited_collections.add(collection_name)
        current = bpy.data.collections.get(collection_name)
        if current is None:
            continue
        try:
            child_names = tuple(current.children.keys())
            current_object_names = tuple(current.objects.keys())
        except (AttributeError, ReferenceError, RuntimeError):
            continue
        pending_collection_names.extend(
            str(name)
            for name in child_names
            if str(name) not in visited_collections
        )
        for object_name in current_object_names:
            object_name = str(object_name)
            if object_name in visited_objects:
                continue
            visited_objects.add(object_name)
            object_names.append(object_name)

    objects = []
    for object_name in object_names:
        obj = bpy.data.objects.get(object_name)
        if obj is not None:
            objects.append(obj)
    return tuple(objects)


def _find_child_collection_by_base_name(collection, base_name):
    if collection is None:
        return None
    try:
        child_names = tuple(collection.children.keys())
    except (AttributeError, ReferenceError, RuntimeError):
        return None
    for child_name in child_names:
        if _strip_blender_numeric_suffix(child_name) != base_name:
            continue
        child = bpy.data.collections.get(str(child_name))
        if child is not None:
            return child
    return None


def _object_world_bounds_center(obj):
    if not getattr(obj, "bound_box", None):
        return obj.matrix_world.to_translation()
    center = Vector((0.0, 0.0, 0.0))
    for corner in obj.bound_box:
        center += Vector(corner)
    return obj.matrix_world @ (center / 8.0)


def _is_matching_clothing_layer(base_obj, candidate):
    base_dimensions = tuple(abs(float(axis)) for axis in base_obj.dimensions)
    candidate_dimensions = tuple(abs(float(axis)) for axis in candidate.dimensions)
    if min(base_dimensions) <= 1.0e-6 or min(candidate_dimensions) <= 1.0e-6:
        return False

    for base_axis, candidate_axis in zip(base_dimensions, candidate_dimensions):
        if abs(base_axis - candidate_axis) / max(base_axis, candidate_axis) > 0.08:
            return False

    largest_dimension = max(max(base_dimensions), max(candidate_dimensions))
    center_distance = (
        _object_world_bounds_center(base_obj)
        - _object_world_bounds_center(candidate)
    ).length
    return center_distance <= largest_dimension * 0.03


def _set_imported_clothing_layer_offsets(parts_collection, enabled):
    mesh_objects = [
        obj for obj in _collection_objects_snapshot(parts_collection)
        if obj.type == "MESH"
    ]
    if not enabled:
        removed = 0
        for obj in mesh_objects:
            modifier = obj.modifiers.get(CLOTHING_LAYER_OFFSET_MODIFIER)
            if modifier is not None:
                obj.modifiers.remove(modifier)
                removed += 1
        return -removed

    families = {}
    for obj in mesh_objects:
        families.setdefault(_strip_blender_numeric_suffix(obj.name), []).append(obj)

    adjusted = 0
    for canonical_name, family in families.items():
        if len(family) < 2:
            continue

        linked_candidates = [
            obj for obj in family if _object_has_linked_base_color(obj)
        ]
        unlinked_candidates = [
            obj for obj in family if not _object_has_linked_base_color(obj)
        ]
        has_material_signal = bool(linked_candidates and unlinked_candidates)
        body_candidates = unlinked_candidates if has_material_signal else family
        body_candidates.sort(
            key = lambda obj: (
                float(obj.dimensions.x * obj.dimensions.y * obj.dimensions.z),
                obj.name != canonical_name,
                obj.name,
            )
        )
        body_obj = body_candidates[0]
        body_volume = abs(float(
            body_obj.dimensions.x
            * body_obj.dimensions.y
            * body_obj.dimensions.z
        ))

        for obj in family:
            if (
                obj == body_obj
                or (
                    has_material_signal
                    and not _object_has_linked_base_color(obj)
                )
                or not _is_matching_clothing_layer(body_obj, obj)
            ):
                continue
            if not has_material_signal:
                candidate_volume = abs(float(
                    obj.dimensions.x * obj.dimensions.y * obj.dimensions.z
                ))
                if candidate_volume <= body_volume * 1.0001:
                    continue

            modifier = obj.modifiers.get(CLOTHING_LAYER_OFFSET_MODIFIER)
            if modifier is None:
                modifier = obj.modifiers.new(
                    name = CLOTHING_LAYER_OFFSET_MODIFIER,
                    type = "DISPLACE",
                )
                adjusted += 1
            positive_dimensions = [
                abs(float(axis)) for axis in body_obj.dimensions if abs(float(axis)) > 1.0e-6
            ]
            reference_dimension = min(positive_dimensions, default = 1.0)
            modifier.direction = "NORMAL"
            modifier.mid_level = 0.0
            modifier.strength = max(0.001, min(0.02, reference_dimension * 0.005))

    return adjusted

def _get_smart_material_rig(collection):
    if not collection.name.startswith("RIG: "):
        return None

    rig_name = _strip_blender_numeric_suffix(collection.name[5:].strip())
    parts_collection = _find_child_collection_by_base_name(collection, "Parts")
    if not rig_name or parts_collection is None:
        return None

    meta_name = f"__{rig_name}Meta"
    meta = None

    for obj in _collection_objects_snapshot(collection):
        obj_name = _strip_blender_numeric_suffix(obj.name)
        if obj.type == "EMPTY" and obj_name == meta_name:
            meta = obj

    if meta is None:
        return None

    return rig_name, parts_collection


def _image_source_path(image):
    stored_path = str(image.get(RIG_TEXTURE_SOURCE_KEY, "")).strip()
    if stored_path and os.path.isfile(stored_path):
        return os.path.normcase(os.path.realpath(stored_path))

    raw_path = str(getattr(image, "filepath_raw", "") or image.filepath).strip()
    if not raw_path:
        return ""
    try:
        absolute_path = bpy.path.abspath(raw_path, library=image.library)
    except (AttributeError, RuntimeError, TypeError, ValueError):
        absolute_path = bpy.path.abspath(raw_path)
    return os.path.normcase(os.path.realpath(absolute_path))


def _safe_rig_texture_name(name):
    safe_name = "".join(
        character if character.isalnum() or character in {"-", "_", "."} else "_"
        for character in str(name)
    ).strip("._")
    return safe_name or "texture"


def _copy_image_color_settings(source, destination):
    for attribute in ("alpha_mode", "use_view_as_render"):
        try:
            setattr(destination, attribute, getattr(source, attribute))
        except (AttributeError, TypeError, ValueError):
            pass
    try:
        destination.colorspace_settings.name = source.colorspace_settings.name
    except (AttributeError, TypeError, ValueError):
        pass


def _isolated_rig_image(source_image, rig_name, rig_token, image_cache):
    source_path = _image_source_path(source_image)
    cache_key = source_path or f"IMAGE:{source_image.as_pointer()}"
    cached = image_cache.get(cache_key)
    if cached is not None:
        return cached

    # Copy the image that the OBJ importer actually loaded. Reopening its path
    # can replace packed or edited pixels with a different file on disk.
    isolated = source_image.copy()

    _copy_image_color_settings(source_image, isolated)
    source_filename = os.path.basename(source_path) if source_path else source_image.name
    source_filename = _safe_rig_texture_name(source_filename)
    isolated.name = f"{rig_name}::{source_filename}"
    isolated[RIG_TEXTURE_SOURCE_KEY] = source_path
    isolated[RIG_TEXTURE_OWNER_KEY] = rig_name
    if isolated.packed_file is None:
        try:
            isolated.pack()
        except (RuntimeError, OSError):
            pass
    if isolated.packed_file is not None:
        isolated.filepath = (
            f"//.staticaliza_rig_textures/{rig_token}/{source_filename}"
        )
    image_cache[cache_key] = isolated
    return isolated


def _isolate_node_tree_images(
    node_tree,
    rig_name,
    rig_token,
    image_cache,
    group_cache,
    visited=None,
):
    if node_tree is None:
        return 0
    if visited is None:
        visited = set()
    pointer = node_tree.as_pointer()
    if pointer in visited:
        return 0
    visited.add(pointer)

    replaced = 0
    for node in node_tree.nodes:
        if node.type == "TEX_IMAGE" and node.image is not None:
            isolated = _isolated_rig_image(
                node.image,
                rig_name,
                rig_token,
                image_cache,
            )
            if isolated is not node.image:
                node.image = isolated
                replaced += 1
            continue

        if node.type != "GROUP" or getattr(node, "node_tree", None) is None:
            continue
        original_group = node.node_tree
        group_pointer = original_group.as_pointer()
        isolated_group = group_cache.get(group_pointer)
        if isolated_group is None:
            isolated_group = original_group.copy()
            isolated_group.name = f"{rig_name}::{original_group.name}"
            group_cache[group_pointer] = isolated_group
        node.node_tree = isolated_group
        replaced += _isolate_node_tree_images(
            isolated_group,
            rig_name,
            rig_token,
            image_cache,
            group_cache,
            visited,
        )
    return replaced


def _isolate_imported_rig_textures(rig_collection, parts_collection):
    rig_name = _strip_blender_numeric_suffix(rig_collection.name[5:].strip())
    token_source = (
        f"{rig_collection.name}|{rig_collection.as_pointer()}|{time.time_ns()}"
    )
    rig_token = hashlib.sha1(token_source.encode("utf-8")).hexdigest()[:12]
    material_cache = {}
    image_cache = {}
    group_cache = {}
    original_materials = set()
    original_images = set()
    replaced_images = 0

    for obj in _collection_objects_snapshot(parts_collection):
        if obj.type != "MESH":
            continue
        for slot in obj.material_slots:
            source_material = slot.material
            if source_material is None:
                continue
            material_pointer = source_material.as_pointer()
            isolated_material = material_cache.get(material_pointer)
            if isolated_material is None:
                isolated_material = source_material.copy()
                isolated_material.name = f"{rig_name}::{source_material.name}"
                original_materials.add(source_material)
                for node in getattr(
                    getattr(source_material, "node_tree", None),
                    "nodes",
                    (),
                ):
                    if node.type == "TEX_IMAGE" and node.image is not None:
                        original_images.add(node.image)
                replaced_images += _isolate_node_tree_images(
                    isolated_material.node_tree,
                    rig_name,
                    rig_token,
                    image_cache,
                    group_cache,
                )
                material_cache[material_pointer] = isolated_material
            slot.material = isolated_material

    for material in original_materials:
        if material.users == 0:
            bpy.data.materials.remove(material)
    for image in original_images:
        if image.users == 0 and image.name != "Baseplate.png":
            bpy.data.images.remove(image)

    return replaced_images, len(material_cache)


def _isolate_newly_imported_rig_textures(previous_collection_pointers):
    isolated_images = 0
    isolated_materials = 0
    for collection_name in tuple(bpy.data.collections.keys()):
        collection = bpy.data.collections.get(str(collection_name))
        if collection is None:
            continue
        if collection.as_pointer() in previous_collection_pointers:
            continue
        if not collection.name.startswith("RIG: "):
            continue
        parts_collection = _find_child_collection_by_base_name(
            collection,
            "Parts",
        )
        if parts_collection is None:
            continue
        image_count, material_count = _isolate_imported_rig_textures(
            collection,
            parts_collection,
        )
        isolated_images += image_count
        isolated_materials += material_count
    return isolated_images, isolated_materials

def _smart_image_alpha_kind(image):
    """Distinguish opaque atlases and cutouts from fractional transparency."""
    cache = _state.setdefault("smart_image_alpha_kind", {})
    key = (image.as_pointer(), tuple(image.size))
    if key in cache:
        return cache[key]
    kind = "graded"
    try:
        if image.channels >= 4 and image.size[0] and image.size[1]:
            pixels = np.empty(len(image.pixels), dtype=np.float32)
            image.pixels.foreach_get(pixels)
            alpha = pixels[3::image.channels]
            if len(alpha) and float(alpha.min()) >= 254.0 / 255.0:
                kind = "opaque"
            elif len(alpha):
                fractional = np.count_nonzero(
                    (alpha > 1.0 / 255.0) & (alpha < 254.0 / 255.0)
                )
                if fractional <= max(8, len(alpha) // 10000):
                    kind = "cutout"
    except (AttributeError, RuntimeError, ValueError):
        pass
    cache[key] = kind
    return kind


def _smart_prepare_material_alpha(material):
    """Drop Studio's baked stud maps without stripping unbumped image color."""
    node_tree = getattr(material, "node_tree", None)
    if node_tree is None:
        return False
    transparent = (not material.get("_staticaliza_decal_composited")
                   and material.diffuse_color[3] < 0.999)
    cutout = bool(material.get("_staticaliza_cutout_alpha"))
    for node in node_tree.nodes:
        if node.type != "BSDF_PRINCIPLED":
            continue
        normal = node.inputs.get("Normal")
        if normal is not None and any(
            link.from_node.type == "NORMAL_MAP" for link in normal.links
        ):
            if material.get("_staticaliza_decal_composited"):
                for link in tuple(normal.links):
                    node_tree.links.remove(link)
            else:
                for socket in node.inputs:
                    for link in tuple(socket.links):
                        node_tree.links.remove(link)
                # Removing an image link leaves the BSDF's old default value.
                # Use the imported material swatch and dissolve instead.
                base_color = node.inputs.get("Base Color")
                if base_color is not None:
                    base_color.default_value = (*material.diffuse_color[:3], 1.0)
                alpha = node.inputs.get("Alpha")
                if alpha is not None:
                    alpha.default_value = material.diffuse_color[3]
        alpha = node.inputs.get("Alpha")
        if alpha is None:
            continue
        base_color = node.inputs.get("Base Color")
        # An RGB image has no authored alpha channel. Do not let an OBJ/MTL
        # graph use its empty Alpha output to hide the whole part.
        for link in tuple(alpha.links):
            source = link.from_node
            image = getattr(source, "image", None) if source.type == "TEX_IMAGE" else None
            # Studio writes both an MTL dissolve value and map_d pointing at
            # its baked diffuse image. On translucent Parts the baked image's
            # alpha can be zero almost everywhere, which hides the whole Part
            # in Blender. The dissolve value is the authored Part opacity.
            baked_dissolve = (
                alpha.default_value < 0.999
                and image is not None
                and base_color is not None
                and any(
                    color_link.from_node.type == "TEX_IMAGE"
                    and color_link.from_node.image == image
                    for color_link in base_color.links
                )
            )
            if (image is not None and link.from_socket.name == "Alpha"
                    and (image.depth < 32 or baked_dissolve)):
                node_tree.links.remove(link)
                if not baked_dissolve:
                    alpha.default_value = material.diffuse_color[3]
            elif (image is not None and link.from_socket.name == "Alpha"
                  and material.diffuse_color[3] >= 0.999
                  and not material.get("_staticaliza_decal_composited")):
                kind = _smart_image_alpha_kind(image)
                if kind == "opaque":
                    node_tree.links.remove(link)
                    alpha.default_value = 1.0
                elif kind == "cutout":
                    threshold = node_tree.nodes.new("ShaderNodeMath")
                    threshold.name = "Roblox Atlas Alpha Cutout"
                    threshold.operation = "GREATER_THAN"
                    threshold.inputs[1].default_value = 0.5
                    node_tree.links.new(link.from_socket, threshold.inputs[0])
                    node_tree.links.remove(link)
                    node_tree.links.new(threshold.outputs[0], alpha)
                    material["_staticaliza_cutout_alpha"] = True
                    cutout = True
        transparent = transparent or alpha.is_linked or alpha.default_value < 0.999
    if (material.get("_staticaliza_decal_composited")
            and material.get("_staticaliza_decal_base_translucent")
            and hasattr(material, "surface_render_method")):
        # A decal can be opaque over a translucent Part. Keep its face in the
        # depth pass so the glass body cannot sort in front of the image.
        material.surface_render_method = "DITHERED"
        material.use_transparency_overlap = True
    elif cutout and hasattr(material, "surface_render_method"):
        # Binary alpha writes stable depth where the atlas is visible.
        material.surface_render_method = "DITHERED"
        material.use_transparency_overlap = True
        material.use_backface_culling = False
    elif transparent and hasattr(material, "surface_render_method"):
        material.surface_render_method = "BLENDED"
        material.use_transparency_overlap = True
        material.use_backface_culling = False
    elif material.get("_staticaliza_decal_composited") and hasattr(material, "surface_render_method"):
        material.surface_render_method = "DITHERED"
    if material.get("_staticaliza_one_sided_overlay"):
        material.use_backface_culling = True
    return transparent


def _smart_rig_metadata(rig_collection):
    """Read the Studio metadata attached to an imported OBJ rig."""
    for obj in _collection_objects_snapshot(rig_collection):
        if obj.type != "EMPTY" or "RigMeta" not in obj:
            continue
        try:
            metadata = json.loads(obj["RigMeta"])
        except (TypeError, ValueError):
            continue
        return metadata
    return {}


def _smart_plain_part_info(metadata):
    return {
        str(entry["name"]): entry
        for entry in metadata.get("partAux", ())
        if isinstance(entry, dict) and isinstance(entry.get("name"), str)
    }


def _smart_part_aux_matches(objects, metadata):
    """Keep known Part identities; use geometry for still unnamed meshes."""
    entries = _smart_plain_part_info(metadata)
    ranked = []
    meshes = [obj for obj in objects if obj.type == "MESH"]
    assigned = {}
    used_names = set()
    # RBXMonkey already names character parts. A coincident invisible
    # HumanoidRootPart must never take the Torso mesh just because its center
    # is slightly closer to the same metadata position. Raw OBJ groups append
    # "1" to the authored Part name, including names ending in digits.
    group_names = sorted(entries, key=len, reverse=True)
    for obj in meshes:
        group = _strip_blender_numeric_suffix(obj.data.name).casefold()
        name = next((candidate for candidate in group_names
                     if group == (candidate + "1").casefold()), None)
        if name is None:
            name = _strip_blender_numeric_suffix(obj.name)
        if name in entries and name not in used_names:
            assigned[obj.as_pointer()] = entries[name]
            used_names.add(name)
    for obj in meshes:
        if obj.as_pointer() in assigned:
            continue
        corners = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
        low = Vector(tuple(min(point[axis] for point in corners) for axis in range(3)))
        high = Vector(tuple(max(point[axis] for point in corners) for axis in range(3)))
        if min(high - low) <= 0.001:
            continue
        center = (low + high) * 0.5
        for name, entry in entries.items():
            cf = entry.get("part_cf")
            size = entry.get("part_size")
            if not isinstance(cf, (list, tuple)) or len(cf) < 3:
                continue
            if not isinstance(size, (list, tuple)) or len(size) < 3:
                continue
            expected = Vector((cf[0], -cf[2], cf[1]))
            distance = (center - expected).length
            tolerance = max(0.05, min(float(axis) for axis in size[:3]) * 0.25)
            if distance <= tolerance:
                ranked.append((distance, obj.as_pointer(), name))
    ranked.sort()
    for _, pointer, name in ranked:
        if pointer not in assigned and name not in used_names:
            assigned[pointer] = entries[name]
            used_names.add(name)
    for obj in meshes:
        pointer = obj.as_pointer()
        if pointer in assigned:
            continue
        entry = entries.get(_strip_blender_numeric_suffix(obj.name))
        if entry is not None and entry["name"] not in used_names:
            assigned[pointer] = entry
            used_names.add(entry["name"])
    return assigned


def _smart_remove_invisible_host_faces(scene):
    """Keep decal-bearing invisible Parts as face meshes after rig creation."""
    removed = 0
    for collection in bpy.data.collections:
        rig = _get_smart_material_rig(collection)
        if rig is None:
            continue
        if not any(obj.type == "ARMATURE" for obj in _collection_objects_snapshot(collection)):
            continue
        metadata = _smart_rig_metadata(collection)
        parts = _collection_objects_snapshot(rig[1])
        matches = _smart_part_aux_matches(parts, metadata)
        for obj in parts:
            if obj.type != "MESH" or obj.get("_staticaliza_invisible_base_removed"):
                continue
            part_info = matches.get(obj.as_pointer())
            if not part_info or float(part_info.get("transparency", 0.0)) < 1.0:
                continue
            decal_start = int(obj.get("_staticaliza_decal_material_start", 1 << 30))
            if decal_start >= len(obj.material_slots):
                continue
            if not any(poly.material_index >= decal_start for poly in obj.data.polygons):
                continue
            if obj.data.users > 1:
                obj.data = obj.data.copy()
            mesh = obj.data
            bm = bmesh.new()
            try:
                bm.from_mesh(mesh)
                base_faces = [face for face in bm.faces if face.material_index < decal_start]
                if not base_faces:
                    continue
                bmesh.ops.delete(bm, geom=base_faces, context="FACES")
                bm.to_mesh(mesh)
                mesh.update()
            finally:
                bm.free()
            obj["_staticaliza_invisible_base_removed"] = True
            removed += 1
    return removed


def _smart_material_has_normal_map(material):
    tree = getattr(material, "node_tree", None)
    if tree is None:
        return False
    return any(
        node.type == "BSDF_PRINCIPLED"
        and any(link.from_node.type == "NORMAL_MAP" for link in node.inputs["Normal"].links)
        for node in tree.nodes
    )


def _smart_tint_decal_material(material):
    """Apply Studio's decal Color3 (OBJ Kd) to its exported image."""
    if material.get("_staticaliza_decal_tint_applied"):
        return
    tint = tuple(_roblox_srgb_to_scene_linear(value) for value in material.diffuse_color[:3])
    if min(tint) > 0.999:
        return
    tree = getattr(material, "node_tree", None)
    if tree is None:
        return
    for shader in tuple(tree.nodes):
        if shader.type != "BSDF_PRINCIPLED":
            continue
        base = shader.inputs.get("Base Color")
        if base is None:
            continue
        image_link = next(
            (link for link in base.links if link.from_node.type == "TEX_IMAGE"),
            None,
        )
        if image_link is None:
            continue
        source = image_link.from_socket
        tree.links.remove(image_link)
        multiply = tree.nodes.new("ShaderNodeMixRGB")
        multiply.name = "Roblox Decal Tint"
        multiply.blend_type = "MULTIPLY"
        multiply.inputs[0].default_value = 1.0
        multiply.inputs[2].default_value = (*tint, 1.0)
        tree.links.new(source, multiply.inputs[1])
        tree.links.new(multiply.outputs["Color"], base)
        material["_staticaliza_decal_tint_applied"] = True
        break


def _smart_restore_glass_decal_alpha(material):
    """Undo the earlier import rule that multiplied a texture by Part opacity."""
    opacity = material.get("_staticaliza_glass_decal_opacity")
    if opacity is None:
        return
    tree = getattr(material, "node_tree", None)
    if tree is not None:
        for shader in tree.nodes:
            if shader.type != "BSDF_PRINCIPLED":
                continue
            alpha = shader.inputs.get("Alpha")
            if alpha is None:
                continue
            for link in tuple(alpha.links):
                multiply = link.from_node
                if multiply.type != "MATH" or multiply.name != "Roblox Glass Decal Opacity":
                    continue
                source_links = tuple(multiply.inputs[0].links)
                tree.links.remove(link)
                if source_links:
                    tree.links.new(source_links[0].from_socket, alpha)
                tree.nodes.remove(multiply)
            if not alpha.is_linked and float(opacity) > 0:
                alpha.default_value = min(1.0, alpha.default_value / float(opacity))
    del material["_staticaliza_glass_decal_opacity"]


def _smart_overlay_face(obj, slot_index, part_info):
    """Identify a decal's Roblox face from the imported host polygons."""
    cf = part_info.get("part_cf")
    if not isinstance(cf, (list, tuple)) or len(cf) < 12:
        return None
    normals = [obj.matrix_world.to_3x3() @ poly.normal
               for poly in obj.data.polygons if poly.material_index == slot_index]
    if not normals:
        return None
    world = sum(normals, Vector()).normalized()
    roblox = Vector((world.x, world.z, -world.y))
    local = Vector((
        cf[3] * roblox.x + cf[6] * roblox.y + cf[9] * roblox.z,
        cf[4] * roblox.x + cf[7] * roblox.y + cf[10] * roblox.z,
        cf[5] * roblox.x + cf[8] * roblox.y + cf[11] * roblox.z,
    ))
    axis = max(range(3), key=lambda index: abs(local[index]))
    return (("Right", "Top", "Back") if local[axis] >= 0
            else ("Left", "Bottom", "Front"))[axis]


def _smart_overlay_info(obj, slot_index, part_info, face_counts):
    overlays = part_info.get("face_overlays", ())
    if not isinstance(overlays, (list, tuple)):
        return None
    face = _smart_overlay_face(obj, slot_index, part_info)
    if face is None:
        return None
    ordinal = face_counts.get(face, 0)
    face_counts[face] = ordinal + 1
    matches = [entry for entry in overlays
               if isinstance(entry, dict) and entry.get("face") == face]
    return matches[ordinal] if ordinal < len(matches) else None


def _smart_composite_decal_material(material, part_info, overlay_info):
    """Composite each decal over its Part using the decal's own opacity."""
    if material.get("_staticaliza_decal_composited"):
        return
    tree = getattr(material, "node_tree", None)
    if tree is None:
        return
    shader = next((node for node in tree.nodes if node.type == "BSDF_PRINCIPLED"), None)
    if shader is None:
        return
    color_input = shader.inputs.get("Base Color")
    alpha_input = shader.inputs.get("Alpha")
    if color_input is None or alpha_input is None or not color_input.is_linked:
        return
    source_color = color_input.links[0].from_socket
    source_alpha = alpha_input.links[0].from_socket if alpha_input.is_linked else None
    # The OBJ map_d connection may have been discarded before this face was
    # identified as a decal. Recover intrinsic PNG alpha from the image that
    # actually feeds its color, even through the tint node.
    pending = [source_color.node]
    visited = set()
    while pending:
        source_node = pending.pop()
        pointer = source_node.as_pointer()
        if pointer in visited:
            continue
        visited.add(pointer)
        if source_node.type == "TEX_IMAGE" and source_node.image is not None:
            if (source_node.image.channels >= 4
                    and _smart_image_alpha_kind(source_node.image) != "opaque"):
                source_alpha = source_node.outputs.get("Alpha")
            else:
                source_alpha = None
            break
        pending.extend(link.from_node for socket in source_node.inputs for link in socket.links)
    overlay_opacity = max(0.0, min(1.0, 1.0 - float(overlay_info.get("transparency", 0.0))))
    base_opacity = max(0.0, min(1.0, 1.0 - float(part_info.get("transparency", 0.0))))
    material["_staticaliza_decal_base_translucent"] = base_opacity < 0.999
    authored_color = part_info.get("color")
    if not isinstance(authored_color, (list, tuple)) or len(authored_color) < 3:
        return
    base_color = tuple(_roblox_srgb_to_scene_linear(value) for value in authored_color[:3])
    if source_alpha is not None and overlay_opacity < 1.0:
        multiply = tree.nodes.new("ShaderNodeMath")
        multiply.name = "Roblox Overlay Opacity"
        multiply.operation = "MULTIPLY"
        multiply.inputs[1].default_value = overlay_opacity
        tree.links.new(source_alpha, multiply.inputs[0])
        effective_alpha = multiply.outputs[0]
    elif source_alpha is not None:
        effective_alpha = source_alpha
    else:
        effective_alpha = None
    for link in tuple(alpha_input.links):
        tree.links.remove(link)
    combined_alpha = base_opacity + overlay_opacity * (1.0 - base_opacity)
    combined_alpha_socket = None
    if base_opacity >= 1.0:
        alpha_input.default_value = 1.0
    elif effective_alpha is None:
        alpha_input.default_value = combined_alpha
    else:
        alpha_mix = tree.nodes.new("ShaderNodeMath")
        alpha_mix.name = "Roblox Overlay Combined Alpha"
        alpha_mix.operation = "MULTIPLY_ADD"
        alpha_mix.inputs[1].default_value = 1.0 - base_opacity
        alpha_mix.inputs[2].default_value = base_opacity
        tree.links.new(effective_alpha, alpha_mix.inputs[0])
        tree.links.new(alpha_mix.outputs[0], alpha_input)
        combined_alpha_socket = alpha_mix.outputs[0]
    blend = tree.nodes.new("ShaderNodeMixRGB")
    blend.name = "Roblox Decal Over Part"
    blend.blend_type = "MIX"
    blend.inputs[1].default_value = (*base_color, 1.0)
    if base_opacity <= 0.0:
        # The invisible Part contributes no color, even when its decal is faint.
        blend.inputs[0].default_value = 1.0
    elif base_opacity >= 1.0:
        blend.inputs[0].default_value = overlay_opacity
        if effective_alpha is not None:
            tree.links.new(effective_alpha, blend.inputs[0])
    elif effective_alpha is None:
        blend.inputs[0].default_value = (
            overlay_opacity / combined_alpha if combined_alpha > 0.0 else 0.0
        )
    else:
        # Source-over colors must be normalized by the resulting alpha.
        color_factor = tree.nodes.new("ShaderNodeMath")
        color_factor.name = "Roblox Overlay Color Weight"
        color_factor.operation = "DIVIDE"
        tree.links.new(effective_alpha, color_factor.inputs[0])
        tree.links.new(combined_alpha_socket, color_factor.inputs[1])
        tree.links.new(color_factor.outputs[0], blend.inputs[0])
    tree.links.new(source_color, blend.inputs[2])
    tree.links.new(blend.outputs["Color"], color_input)
    for name, value in (
        ("Metallic", 0.0), ("Roughness", 1.0),
        ("Specular IOR Level", 0.0), ("Coat Weight", 0.0),
        ("Sheen Weight", 0.0), ("Transmission Weight", 0.0),
    ):
        socket = shader.inputs.get(name)
        if socket is not None:
            for link in tuple(socket.links):
                tree.links.remove(link)
            socket.default_value = value
    normal = shader.inputs.get("Normal")
    if normal is not None:
        for link in tuple(normal.links):
            tree.links.remove(link)
    material["_staticaliza_decal_composited"] = True


def _smart_has_baked_body_texture(material, part_name):
    """Studio already packs classic clothing into the OBJ diffuse atlas."""
    body_names = {
        "torso", "uppertorso", "lowertorso", "head",
        "left arm", "right arm", "left leg", "right leg",
        "lefthand", "righthand", "leftfoot", "rightfoot",
        "leftupperarm", "rightupperarm", "leftlowerarm", "rightlowerarm",
        "leftupperleg", "rightupperleg", "leftlowerleg", "rightlowerleg",
    }
    if _strip_blender_numeric_suffix(part_name).casefold() not in body_names:
        return False
    tree = getattr(material, "node_tree", None)
    if tree is None:
        return False
    return any(
        node.type == "BSDF_PRINCIPLED"
        and any(
            link.from_node.type == "TEX_IMAGE"
            and getattr(link.from_node, "image", None) is not None
            for link in node.inputs["Base Color"].links
        )
        for node in tree.nodes
    )


def _smart_make_body_atlas_opaque(material):
    """Classic clothing is baked opaque at the body UVs, despite map_d."""
    tree = getattr(material, "node_tree", None)
    if tree is None:
        return
    for node in tree.nodes:
        if node.type != "BSDF_PRINCIPLED":
            continue
        alpha = node.inputs.get("Alpha")
        if alpha is None:
            continue
        for link in tuple(alpha.links):
            tree.links.remove(link)
        alpha.default_value = 1.0
        for output in tree.nodes:
            if output.type != "OUTPUT_MATERIAL":
                continue
            surface = output.inputs.get("Surface")
            if surface is not None and any(
                link.from_node.type == "BSDF_TRANSPARENT"
                and link.from_node.name == "Invisible Roblox Part"
                for link in surface.links
            ):
                for link in tuple(surface.links):
                    tree.links.remove(link)
                tree.links.new(node.outputs["BSDF"], surface)
    material.diffuse_color = (*material.diffuse_color[:3], 1.0)
    material.surface_render_method = "DITHERED"


def _roblox_srgb_to_scene_linear(value):
    """Convert an authored Roblox Color3 channel to Blender shader space."""
    value = max(0.0, min(1.0, float(value)))
    return value / 12.92 if value <= 0.04045 else ((value + 0.055) / 1.055) ** 2.4


def _smart_prepare_plain_part_material(material, part_info):
    """Keep authored BSDF values and discard unrelated OBJ texture maps."""
    node_tree = getattr(material, "node_tree", None)
    if node_tree is None:
        return
    authored_color = part_info.get("color")
    if not isinstance(authored_color, (list, tuple)) or len(authored_color) < 3:
        shader_color = tuple(material.diffuse_color[:3])
    else:
        shader_color = tuple(_roblox_srgb_to_scene_linear(value) for value in authored_color[:3])
    opacity = max(0.0, min(1.0, 1.0 - float(part_info.get("transparency", 0.0))))
    for node in node_tree.nodes:
        if node.type != "BSDF_PRINCIPLED":
            continue
        for socket in node.inputs:
            for link in tuple(socket.links):
                node_tree.links.remove(link)
        node.inputs["Base Color"].default_value = (*shader_color, 1.0)
        node.inputs["Alpha"].default_value = opacity
        if part_info.get("roblox_material") == "Glass":
            roughness = node.inputs.get("Roughness")
            if roughness is not None:
                roughness.default_value = 0.12
        if opacity > 0.0:
            for output in node_tree.nodes:
                if output.type != "OUTPUT_MATERIAL":
                    continue
                surface = output.inputs.get("Surface")
                if surface is not None and any(
                    link.from_node.type == "BSDF_TRANSPARENT"
                    and link.from_node.name == "Invisible Roblox Part"
                    for link in surface.links
                ):
                    for link in tuple(surface.links):
                        node_tree.links.remove(link)
                    node_tree.links.new(node.outputs["BSDF"], surface)
    if opacity <= 0.0:
        transparent = next((node for node in node_tree.nodes if node.type == "BSDF_TRANSPARENT"), None)
        if transparent is None:
            transparent = node_tree.nodes.new("ShaderNodeBsdfTransparent")
            transparent.name = "Invisible Roblox Part"
        for output in node_tree.nodes:
            if output.type != "OUTPUT_MATERIAL":
                continue
            surface = output.inputs.get("Surface")
            if surface is not None:
                for link in tuple(surface.links):
                    node_tree.links.remove(link)
                node_tree.links.new(transparent.outputs["BSDF"], surface)
    for node in tuple(node_tree.nodes):
        if node.type == "TEX_IMAGE":
            node_tree.nodes.remove(node)
    material.diffuse_color = (*shader_color, opacity)


def _capture_material_import_baseline():
    try:
        material_names = tuple(bpy.data.materials.keys())
    except AttributeError:
        return False
    material_pointers = set()
    for material_name in material_names:
        material = bpy.data.materials.get(str(material_name))
        if material is not None:
            material_pointers.add(int(material.as_pointer()))
    _state["material_import_baseline"] = material_pointers
    return True


def _initialize_material_import_tracking():
    return None if _capture_material_import_baseline() else 0.1


def _standardize_imported_material_display(material):
    material.diffuse_color = IMPORTED_MATERIAL_DISPLAY_COLOR

def _smart_mask_transparent_solid_contacts(scene, parts_collection, part_matches):
    """Let opaque box faces win at contact without moving or deleting glass."""
    def bounds(obj):
        corners = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
        return (tuple(min(point[axis] for point in corners) for axis in range(3)),
                tuple(max(point[axis] for point in corners) for axis in range(3)))

    def is_opaque(obj):
        for slot in obj.material_slots:
            material = slot.material
            if material is None:
                continue
            tree = getattr(material, "node_tree", None)
            if tree is None:
                if material.diffuse_color[3] < 0.999:
                    return False
                continue
            if any(node.type == "OUTPUT_MATERIAL"
                   and any(link.from_node.type == "BSDF_TRANSPARENT"
                           for link in node.inputs["Surface"].links)
                   for node in tree.nodes):
                return False
            for node in tree.nodes:
                if node.type != "BSDF_PRINCIPLED":
                    continue
                alpha = node.inputs.get("Alpha")
                if alpha is None:
                    continue
                if alpha.is_linked:
                    source = alpha.links[0].from_socket
                    image = getattr(source.node, "image", None)
                    if (source.node.type != "TEX_IMAGE" or source.name != "Alpha"
                            or image is None or _smart_image_alpha_kind(image) != "opaque"):
                        return False
                elif alpha.default_value < 0.999:
                    return False
        return True

    def box_bounds(obj):
        if any(modifier.type in {"ARMATURE", "LATTICE", "MESH_DEFORM"}
               for modifier in obj.modifiers):
            return None
        vertices = obj.data.vertices
        if not 4 <= len(vertices) <= 64:
            return None
        low = tuple(min(vertex.co[axis] for vertex in vertices) for axis in range(3))
        high = tuple(max(vertex.co[axis] for vertex in vertices) for axis in range(3))
        flat_axes = [axis for axis in range(3)
                     if high[axis] - low[axis] < 1.e-6]
        if len(flat_axes) > 1:
            return None
        corners = set()
        for vertex in vertices:
            sides = []
            for axis in range(3):
                span = high[axis] - low[axis]
                if axis in flat_axes:
                    sides.append(0)
                    continue
                side = int(abs(vertex.co[axis] - high[axis]) < span * 1.e-5)
                if abs(vertex.co[axis] - (high[axis] if side else low[axis])) > span * 1.e-5:
                    return None
                sides.append(side)
            corners.add(tuple(sides))
        expected = 4 if flat_axes else 8
        if len(corners) != expected:
            return None
        return low, high, tuple(flat_axes or range(3))

    def masked_material(source, contacts):
        material = source.copy()
        material.name = f"{source.name} Solid Contact"
        tree = material.node_tree
        shader = next((node for node in tree.nodes if node.type == "BSDF_PRINCIPLED"), None)
        if shader is None:
            bpy.data.materials.remove(material)
            return None
        alpha = shader.inputs.get("Alpha")
        if alpha is None:
            bpy.data.materials.remove(material)
            return None
        previous = alpha.links[0].from_socket if alpha.is_linked else None

        def math(operation, first, second=None):
            node = tree.nodes.new("ShaderNodeMath")
            node.operation = operation
            for socket, value in zip(node.inputs, (first, second)):
                if value is None:
                    continue
                if isinstance(value, (float, int)):
                    socket.default_value = value
                else:
                    tree.links.new(value, socket)
            return node.outputs[0]

        visible = None
        for solid, axis, side, local_low, local_high, local_tolerance in contacts:
            coord = tree.nodes.new("ShaderNodeTexCoord")
            coord.object = solid
            separate = tree.nodes.new("ShaderNodeSeparateXYZ")
            tree.links.new(coord.outputs["Object"], separate.inputs[0])
            axes = (separate.outputs["X"], separate.outputs["Y"], separate.outputs["Z"])
            at_plane = math("LESS_THAN", math("ABSOLUTE", math(
                "SUBTRACT", axes[axis], side)), local_tolerance)
            covered = at_plane
            for other in range(3):
                if other == axis:
                    continue
                lower = math("GREATER_THAN", axes[other], local_low[other] - local_tolerance)
                upper = math("LESS_THAN", axes[other], local_high[other] + local_tolerance)
                covered = math("MULTIPLY", covered, math("MULTIPLY", lower, upper))
            keep = math("SUBTRACT", 1.0, covered)
            visible = keep if visible is None else math("MULTIPLY", visible, keep)
        if previous is not None:
            visible = math("MULTIPLY", previous, visible)
        else:
            visible = math("MULTIPLY", alpha.default_value, visible)
        tree.links.new(visible, alpha)
        material["_staticaliza_solid_contact_mask"] = True
        return material

    solids = [(obj, bounds(obj), box_bounds(obj)) for obj in scene.objects
              if obj.type == "MESH" and is_opaque(obj)]
    solids = [(obj, world_bounds, local_bounds)
              for obj, world_bounds, local_bounds in solids if local_bounds is not None]
    masked = 0
    for obj in _collection_objects_snapshot(parts_collection):
        if obj.type != "MESH" or obj.get("_staticaliza_solid_contact_masked"):
            continue
        info = part_matches.get(obj.as_pointer())
        if not info:
            continue
        opacity = 1.0 - float(info.get("transparency", 0.0))
        if not 0.0 <= opacity < 0.999:
            continue
        decal_start = int(obj.get("_staticaliza_decal_material_start", 1 << 30))
        if opacity <= 0.001 and decal_start >= len(obj.material_slots):
            continue
        low, high = bounds(obj)
        tolerance = 0.002
        candidates = [(solid, local_bounds)
                      for solid, (solid_low, solid_high), local_bounds in solids
                      if solid is not obj and all(
                          high[axis] >= solid_low[axis] - tolerance
                          and low[axis] <= solid_high[axis] + tolerance
                          for axis in range(3))]
        if not candidates:
            continue
        face_contacts = {}
        for face in obj.data.polygons:
            if opacity <= 0.001 and face.material_index < decal_start:
                continue
            normal = (obj.matrix_world.to_3x3().inverted().transposed()
                      @ face.normal).normalized()
            vertices = [obj.matrix_world @ obj.data.vertices[index].co
                        for index in face.vertices]
            contacts = []
            for solid, (local_low, local_high, allowed_axes) in candidates:
                inverse = solid.matrix_world.inverted()
                local = [inverse @ vertex for vertex in vertices]
                for axis in allowed_axes:
                    axis_vector = Vector(tuple(float(index == axis) for index in range(3)))
                    world_normal = (solid.matrix_world.to_3x3().inverted().transposed()
                                    @ axis_vector).normalized()
                    if abs(world_normal.dot(normal)) < 0.99:
                        continue
                    scale = (solid.matrix_world.to_3x3() @ axis_vector).length
                    local_tolerance = tolerance / scale
                    for side in (local_low[axis], local_high[axis]):
                        if any(abs(point[axis] - side) > local_tolerance
                               for point in local):
                            continue
                        if all(
                            min(max(point[other] for point in local), local_high[other])
                            - max(min(point[other] for point in local), local_low[other])
                            > local_tolerance
                            for other in range(3) if other != axis
                        ):
                            contacts.append((solid, axis, side, local_low,
                                             local_high, local_tolerance))
            if contacts:
                face_contacts[face.index] = contacts
        if not face_contacts:
            continue
        if obj.data.users > 1:
            obj.data = obj.data.copy()
        for face_index, contacts in face_contacts.items():
            face = obj.data.polygons[face_index]
            source = obj.material_slots[face.material_index].material
            if source is None:
                continue
            material = masked_material(source, contacts)
            if material is None:
                continue
            obj.data.materials.append(material)
            face.material_index = len(obj.data.materials) - 1
            masked += 1
        obj["_staticaliza_solid_contact_masked"] = True
    return masked


def _smart_material_import_scan(scene):
    context = bpy.context
    wm = getattr(context, "window_manager", None)
    if wm is None:
        return

    smart_enabled = getattr(wm, "smart_material_import_enabled", True)
    display_enabled = getattr(
        wm,
        "standardize_imported_material_display_enabled",
        True,
    )
    clothing_offset_enabled = getattr(
        wm,
        "prevent_clothing_layer_clipping_enabled",
        False,
    )

    processed = _state.setdefault("smart_material_processed_rigs", set())
    material_baseline = _state.get("material_import_baseline")
    if material_baseline is None:
        if not _capture_material_import_baseline():
            return
        material_baseline = _state["material_import_baseline"]
    current_rigs = set()

    for collection_name in tuple(bpy.data.collections.keys()):
        collection = bpy.data.collections.get(str(collection_name))
        if collection is None:
            continue
        rig = _get_smart_material_rig(collection)
        if rig is None:
            continue

        rig_name, parts_collection = rig
        rig_id = collection.as_pointer()
        current_rigs.add(rig_id)
        if rig_id in processed:
            continue

        alpha_prepared = 0
        standardized = 0
        adjusted_layers = 0
        material_ids = set()
        metadata = _smart_rig_metadata(collection)
        part_matches = _smart_part_aux_matches(
            _collection_objects_snapshot(parts_collection), metadata,
        )

        for obj in _collection_objects_snapshot(parts_collection):
            if obj.type != "MESH":
                continue
            plain_info = part_matches.get(obj.as_pointer())
            body_atlas = any(
                _smart_has_baked_body_texture(slot.material, obj.name)
                for slot in obj.material_slots if slot.material is not None
            )
            decal_material_start = int(obj.get("_staticaliza_decal_material_start", 1 << 30))
            overlay_face_counts = {}
            for slot_index, slot in enumerate(obj.material_slots):
                material = slot.material
                if material is None or getattr(material, "library", None) is not None:
                    continue
                decal_slot = slot_index >= decal_material_start
                if smart_enabled and body_atlas:
                    if material.users > 1:
                        material = material.copy()
                        slot.material = material
                    _smart_make_body_atlas_opaque(material)
                elif (smart_enabled and plain_info and not decal_slot
                      and (plain_info.get("plain_part") is True
                           or _smart_material_has_normal_map(material))):
                    if material.users > 1:
                        material = material.copy()
                        slot.material = material
                    _smart_prepare_plain_part_material(material, plain_info)
                    if plain_info.get("roblox_material") == "Glass":
                        material.use_transparency_overlap = True
                        material.use_backface_culling = False
                if smart_enabled and decal_slot:
                    if material.users > 1:
                        material = material.copy()
                        slot.material = material
                    material["_staticaliza_one_sided_overlay"] = True
                    if material.get("_staticaliza_glass_decal_opacity") is not None:
                        _smart_restore_glass_decal_alpha(material)
                    if plain_info and plain_info.get("roblox_material") == "Glass":
                        material.use_transparency_overlap = True
                        material.use_backface_culling = False
                    _smart_tint_decal_material(material)
                    if plain_info:
                        overlay_info = _smart_overlay_info(
                            obj, slot_index, plain_info, overlay_face_counts,
                        )
                        if overlay_info is not None:
                            _smart_composite_decal_material(material, plain_info, overlay_info)
                material_id = material.as_pointer()
                if material_id in material_ids:
                    continue
                material_ids.add(material_id)
                if smart_enabled and _smart_prepare_material_alpha(material):
                    alpha_prepared += 1
                if display_enabled and material_id not in material_baseline:
                    _standardize_imported_material_display(material)
                    standardized += 1

        if smart_enabled:
            _smart_mask_transparent_solid_contacts(scene, parts_collection, part_matches)
        adjusted_layers = _set_imported_clothing_layer_offsets(
            parts_collection,
            clothing_offset_enabled,
        )

        processed.add(rig_id)
        if alpha_prepared:
            print(f"[Smart Material Import] Prepared {alpha_prepared} transparent material(s) on '{rig_name}'.")
        if standardized:
            print(
                f"[Smart Material Import] Standardized {standardized} viewport "
                f"material(s) on '{rig_name}'."
            )
        if adjusted_layers > 0:
            print(
                f"[Smart Material Import] Offset {adjusted_layers} clothing "
                f"layer(s) on '{rig_name}' to prevent clipping."
            )
        elif adjusted_layers < 0:
            print(
                f"[Smart Material Import] Removed {-adjusted_layers} clothing "
                f"layer offset(s) from '{rig_name}'."
            )

    processed.intersection_update(current_rigs)

def _on_smart_material_import_toggle(self, context):
    _state["smart_material_processed_rigs"] = set()
    _smart_material_import_scan(context.scene)

@persistent
def _smart_material_import_depsgraph_update(scene, depsgraph):
    if (
        _state.get("pin_history_active", False)
        or _state.get("pin_history_syncing", False)
        or _state.get("pin_history_direction", "")
    ):
        return
    for update in depsgraph.updates:
        datablock = getattr(update, "id", None)
        if not isinstance(datablock, bpy.types.Object):
            continue
        if datablock.type == "ARMATURE" or (
            datablock.type == "EMPTY"
            and datablock.name.startswith("__")
            and "Meta" in datablock.name
        ):
            _schedule_smart_material_import_scan()
            return


def _run_smart_material_import_scan():
    context = bpy.context
    now = time.perf_counter()
    not_before = float(
        _state.get("smart_material_scan_not_before", 0.0)
    )
    if now < not_before:
        return max(0.01, not_before - now)
    if (
        _state.get("pin_history_active", False)
        or _state.get("pin_history_syncing", False)
        or _state.get("pin_history_direction", "")
        or _pin_primary_mouse_pressed()
        or _window_manager_has_modal_operator(context)
    ):
        # Undo/Redo can invalidate every RNA wrapper while its handlers run.
        # Keep this timer pending and reacquire collections on a later tick.
        return 0.1
    _state["smart_material_scan_pending"] = False
    _state["smart_material_scan_not_before"] = 0.0
    if context and context.scene:
        _smart_material_import_scan(context.scene)
    return None


def _schedule_smart_material_import_scan(delay = 0.15):
    delay = max(0.0, float(delay))
    _state["smart_material_scan_not_before"] = (
        time.perf_counter() + delay
    )
    if _state.get("smart_material_scan_pending", False):
        return
    _state["smart_material_scan_pending"] = True
    try:
        register_owned_timer(
            _run_smart_material_import_scan,
            first_interval = delay,
        )
    except Exception:
        _state["smart_material_scan_pending"] = False
        _state["smart_material_scan_not_before"] = 0.0
