"""Combined extension updater execution and user-facing installer operators."""

from ..core.runtime import *  # noqa: F403

def _show_extension_update_result(message, icon):
    window_manager = getattr(bpy.context, "window_manager", None)
    if window_manager is None:
        print(f"[Roblox Animator Utils] {message}")
        return

    def draw(self, context):
        self.layout.label(text = message)

    window_manager.popup_menu(draw, title = "Extension Update", icon = icon)


def _perform_combined_extension_update():
    handoff_pending = False
    _persist_runtime_session_state(bpy.context)
    bundled_setup = _bundled_setup_module()
    if bundled_setup is None:
        _show_extension_update_result(
            "Install Staticaliza's Blender Animation Tools first.",
            "ERROR",
        )
        _state["extension_update_running"] = False
        _state["extension_update_status"] = ""
        _state["extension_update_lock_waits"] = 0
        try:
            bpy.app.driver_namespace.pop(EXTENSION_UPDATE_GUARD_KEY, None)
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            pass
        _tag_redraw_all_view3d()
        return None

    try:
        _state["extension_update_status"] = "Updating extensions..."
        _tag_redraw_all_view3d()
        result_message = bundled_setup._install_or_update_children()
        handoff_pending = bool(
            getattr(bundled_setup, "_update_handoff_pending", lambda: False)()
        )
        if not handoff_pending:
            _show_extension_update_result(
                str(result_message) if result_message else (
                    "Updated Roblox Animator, Roblox Animator Utils, and "
                    "Roblox Animator Impact."
                ),
                "CHECKMARK",
            )
    except Exception as exc:
        _show_extension_update_result(f"Update failed: {exc}", "ERROR")
    finally:
        _state["extension_update_running"] = False
        _state["extension_update_status"] = ""
        _state["extension_update_lock_waits"] = 0
        try:
            if not handoff_pending:
                bpy.app.driver_namespace.pop(EXTENSION_UPDATE_GUARD_KEY, None)
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            pass
        _tag_redraw_all_view3d()
    return None


class ANIMATOR_UTILS_OT_install_roblox_animations(bpy.types.Operator):
    bl_idname = "staticaliza.install_roblox_animations"
    bl_label = "Update Extensions"
    bl_description = "Update Roblox Animator, Roblox Animator Utils, and Roblox Animator Impact"
    # This operator replaces and reloads the extension that owns its RNA type.
    # Keeping it in Blender's redo/undo history leaves a freed OperatorType
    # pointer behind after that reload; hovering UI can then dereference it
    # while constructing a tooltip. Installation itself is not undoable.
    bl_options = {"INTERNAL"}

    def execute(self, context):
        if not getattr(bpy.app, "online_access", True):
            self.report({"ERROR"}, "Blender online access is disabled in Preferences.")
            return {"CANCELLED"}

        if _state["extension_update_running"]:
            self.report({"WARNING"}, "An extension update is already running.")
            return {"CANCELLED"}

        try:
            bpy.app.driver_namespace[EXTENSION_UPDATE_GUARD_KEY] = True
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            pass
        _state["extension_update_running"] = True
        _state["extension_update_status"] = "Preparing the extension update..."
        _state["extension_update_lock_waits"] = 0
        _tag_redraw_all_view3d()
        try:
            register_owned_timer(_perform_combined_extension_update, first_interval = 0.35)
        except Exception as exc:
            _state["extension_update_running"] = False
            _state["extension_update_status"] = ""
            _tag_redraw_all_view3d()
            self.report({"ERROR"}, f"Could not start extension update: {exc}")
            return {"CANCELLED"}

        self.report({"INFO"}, "Updating extensions.")
        return {"FINISHED"}


class ANIMATOR_UTILS_OT_open_roblox_plugins(bpy.types.Operator):
    bl_idname = "staticaliza.open_roblox_plugins"
    bl_label = "Install Roblox Plugins"
    bl_description = "Open both recommended Roblox animation plugins in the Creator Store"

    def execute(self, context):
        for url in (
            "https://create.roblox.com/store/asset/118148792788940",
            "https://create.roblox.com/store/asset/16708835782",
        ):
            bpy.ops.wm.url_open(url = url)
        return {"FINISHED"}
