"""Imported-rig normalization, pose activation, compatibility, and overlay setup."""

from ..core.runtime import *  # noqa: F403

def _hide_roblox_rig_meta(meta):
    if meta is None:
        return
    meta.hide_viewport = True
    meta.hide_render = True
    meta.hide_select = True
    try:
        meta.hide_set(True)
    except (AttributeError, RuntimeError):
        pass


def _is_roblox_auxiliary_bone_collection(collection):
    base_name = _strip_blender_numeric_suffix(collection.name).casefold()
    compact_name = "".join(character for character in base_name if character.isalnum())
    return any(
        token in compact_name
        for token in ("weldbones", "facebones", "helperbones")
    )


def _set_roblox_auxiliary_bone_collections_visibility(armature, visible):
    changed = 0
    for bone_collection in getattr(armature.data, "collections", ()):
        if not _is_roblox_auxiliary_bone_collection(bone_collection):
            continue
        if bool(bone_collection.is_visible) != bool(visible):
            bone_collection.is_visible = bool(visible)
            changed += 1
    return changed


def _set_roblox_bone_visibility(armature, collection_name, predicate, hidden):
    bones = tuple(bone for bone in armature.data.bones if predicate(bone))
    bone_names = {bone.name for bone in bones}

    try:
        bone_collections = armature.data.collections
        use_collections = True
    except Exception:
        bone_collections = None
        use_collections = False

    if use_collections:
        bone_collection = bone_collections.get(collection_name)
        if bone_collection is None:
            bone_collection = bone_collections.new(collection_name)
        previous_bones = tuple(getattr(bone_collection, "bones", ()))
        for bone in previous_bones:
            if bone.name in bone_names:
                continue
            try:
                bone_collection.unassign(bone)
            except RuntimeError:
                pass
        for bone in bones:
            try:
                bone_collection.assign(bone)
            except RuntimeError:
                pass
        bone_collection.is_visible = not hidden

        # Recompute the explicit hide flag after membership changes. A limb
        # that was temporarily parentless must not remain hidden merely
        # because an earlier compatibility scan classified it as a helper.
        touched = {bone.name: bone for bone in previous_bones}
        touched.update({bone.name: bone for bone in bones})
        for bone in touched.values():
            bone.hide = any(
                _is_roblox_auxiliary_bone_collection(collection)
                and not bool(getattr(collection, "is_visible", True))
                for collection in getattr(bone, "collections", ())
            )
    else:
        for bone in bones:
            bone.hide = hidden
    return len(bones)


def _is_numbered_helper_bone(armature, bone):
    base_name = _strip_blender_numeric_suffix(bone.name)
    return (
        base_name != bone.name
        and armature.data.bones.get(base_name) is not None
    )


def _is_roblox_structural_root_bone(armature, bone):
    """Hide the non-animating root control while preserving rig labels."""
    if bone.parent is not None:
        return False
    # Dynamic Unparent and Cautioned's world-space Unparent intentionally make
    # ordinary controls root-level. Their saved original-parent metadata is a
    # stable signal that they are not the imported rig's structural root.
    if (
        str(bone.get(REL_K_PARENT, ""))
        or str(bone.get("worldspace_original_parent", ""))
        or bool(bone.get("is_transformable", False))
    ):
        return False
    children = tuple(getattr(bone, "children", ()))
    if not children:
        return False
    # A structural root drives the visible animation hierarchy but has no
    # welded visible part of its own. This avoids hardcoding Roblox names and
    # does not affect the separately drawn yellow rig-name overlay.
    # Visible Roblox parts are commonly constrained to an opaque weld child,
    # not to the colored control itself. Include immediate children so a
    # detached limb does not look like an empty structural root.
    visible_driver_names = {bone.name, *(child.name for child in children)}
    has_welded_part = any(
        obj.type == "MESH"
        and any(
            getattr(constraint, "target", None) == armature
            and str(getattr(constraint, "subtarget", ""))
            in visible_driver_names
            for constraint in obj.constraints
        )
        for obj in bpy.data.objects
    )
    return not has_welded_part


def _is_roblox_weld_bone(armature, bone):
    # Roblox's generated helper names are deliberately opaque and can change
    # on every import.  Collection membership is the stable ownership signal:
    # a helper in either weld collection belongs to its nearest non-weld
    # ancestor and must never be treated as an independently animated body.
    weld_collection_names = {"_weldbones", "_staticalizaweldbones"}
    try:
        memberships = {
            str(_strip_blender_numeric_suffix(collection.name)).casefold()
            for collection in bone.collections
        }
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        memberships = set()
    if memberships & weld_collection_names:
        return True

    joint_type = str(bone.get("rbx_joint_type", "")).casefold()
    if joint_type in {"weld", "weldconstraint"}:
        return True

    pose_bone = armature.pose.bones.get(bone.name)
    custom_shape = getattr(pose_bone, "custom_shape", None) if pose_bone else None
    return bool(
        custom_shape
        and _strip_blender_numeric_suffix(custom_shape.name) == "__WeldBoneShape"
    )


def _find_generated_roblox_armature(context, meta, previous_armatures):
    active = context.view_layer.objects.active
    if (
        active is not None
        and active.type == "ARMATURE"
        and active.as_pointer() not in previous_armatures
    ):
        return active

    settings = getattr(context.scene, "rbx_anim_settings", None)
    configured_name = getattr(settings, "rbx_anim_armature", "") if settings else ""
    configured = context.scene.objects.get(configured_name) if configured_name else None
    if (
        configured is not None
        and configured.type == "ARMATURE"
        and configured.as_pointer() not in previous_armatures
    ):
        return configured

    try:
        source_collections = tuple(meta.users_collection) if meta is not None else ()
    except ReferenceError:
        source_collections = ()

    for collection in source_collections:
        for obj in collection.all_objects:
            if obj.type == "ARMATURE" and obj.as_pointer() not in previous_armatures:
                return obj

    for obj in context.scene.objects:
        if obj.type == "ARMATURE" and obj.as_pointer() not in previous_armatures:
            return obj

    return None


def _enter_pending_roblox_rigs_pose_mode():

    pending = _state.setdefault("pose_mode_pending_rigs", set())
    if not pending:
        _state["pose_mode_pending_attempts"] = 0
        return None

    context = bpy.context
    scene = getattr(context, "scene", None)
    view_layer = getattr(context, "view_layer", None)
    if scene is None or view_layer is None:
        _state["pose_mode_pending_attempts"] += 1
        if _state["pose_mode_pending_attempts"] < 20:
            return 0.05
        pending.clear()
        _state["pose_mode_pending_attempts"] = 0
        return None

    armatures = []
    for armature_name in tuple(pending):
        armature = scene.objects.get(armature_name)
        if armature is None or armature.type != "ARMATURE":
            pending.discard(armature_name)
            continue
        try:
            if armature.name not in view_layer.objects:
                continue
        except (AttributeError, ReferenceError):
            continue
        armatures.append(armature)

    if not armatures:
        _state["pose_mode_pending_attempts"] += 1
        if pending and _state["pose_mode_pending_attempts"] < 20:
            return 0.05
        pending.clear()
        _state["pose_mode_pending_attempts"] = 0
        return None

    try:
        if getattr(context, "mode", "OBJECT") != "OBJECT":
            bpy.ops.object.mode_set(mode = "OBJECT")
        for obj in view_layer.objects:
            try:
                obj.select_set(False)
            except (AttributeError, RuntimeError):
                pass
        selectable = []
        for armature in armatures:
            try:
                if (
                    armature.hide_get()
                    or armature.hide_viewport
                    or armature.hide_select
                ):
                    continue
                armature.select_set(True)
                if not armature.select_get():
                    continue
                selectable.append(armature)
            except (AttributeError, ReferenceError, RuntimeError):
                continue
        if not selectable:
            raise RuntimeError("Generated rig is not selectable in this view layer")
        view_layer.objects.active = selectable[0]
        bpy.ops.object.mode_set(mode = "POSE")
    except (AttributeError, ReferenceError, RuntimeError):
        _state["pose_mode_pending_attempts"] += 1
        if _state["pose_mode_pending_attempts"] < 20:
            return 0.05
        pending.clear()
        _state["pose_mode_pending_attempts"] = 0
        return None

    for armature in selectable:
        pending.discard(armature.name)
    _state["pose_mode_pending_attempts"] = 0
    return 0.05 if pending else None


def _schedule_roblox_rigs_pose_mode(armatures, delay = 0.15):
    pending = _state.setdefault("pose_mode_pending_rigs", set())
    for armature in armatures:
        try:
            if armature is not None and armature.type == "ARMATURE":
                pending.add(armature.name)
        except (AttributeError, ReferenceError):
            continue
    if not pending:
        return
    _state["pose_mode_pending_attempts"] = 0
    if not bpy.app.timers.is_registered(_enter_pending_roblox_rigs_pose_mode):
        register_owned_timer(
            _enter_pending_roblox_rigs_pose_mode,
            first_interval = max(0.01, float(delay)),
        )


def _find_roblox_parts_collection(armature):
    visited = set()
    pending = list(armature.users_collection)

    while pending:
        collection = pending.pop(0)
        pointer = collection.as_pointer()
        if pointer in visited:
            continue
        visited.add(pointer)
        collection_name = _strip_blender_numeric_suffix(collection.name)
        if collection_name == "Parts" or collection_name.endswith("_Parts"):
            return collection
        pending.extend(collection.children)

    return None


def _normalize_roblox_part_constraints(armature, preserve_world = True):

    parts_collection = _find_roblox_parts_collection(armature)
    if parts_collection is None:
        return 0

    normalized = 0
    preserved_world = []
    channel_names = (
        "use_location_x",
        "use_location_y",
        "use_location_z",
        "use_rotation_x",
        "use_rotation_y",
        "use_rotation_z",
        "use_scale_x",
        "use_scale_y",
        "use_scale_z",
    )

    for obj in parts_collection.all_objects:
        if obj.type != "MESH":
            continue

        constraints = [
            constraint for constraint in obj.constraints
            if constraint.type == "CHILD_OF" and constraint.target == armature
        ]
        if not constraints:
            continue

        valid_constraints = [
            constraint for constraint in constraints
            if constraint.subtarget and armature.data.bones.get(constraint.subtarget) is not None
        ]
        keep = valid_constraints[0] if valid_constraints else constraints[0]
        needs_change = (
            len(constraints) != 1
            or abs(float(keep.influence) - 1.0) > 1.0e-8
            or any(not getattr(keep, name, True) for name in channel_names)
            or not preserve_world
        )
        if not needs_change:
            # Loading a posed rig can leave a bone update pending. Reassigning
            # its mesh's stale evaluated world matrix would bake the pending
            # pose into the object basis and separate the mesh from its bone.
            normalized += 1
            continue
        if preserve_world:
            try:
                bpy.context.view_layer.update()
                preserved_world.append((obj, obj.matrix_world.copy()))
            except (AttributeError, ReferenceError, RuntimeError):
                pass
        for constraint in constraints:
            if constraint is not keep:
                obj.constraints.remove(constraint)

        keep.influence = 1.0
        for channel_name in channel_names:
            if hasattr(keep, channel_name):
                setattr(keep, channel_name, True)

        bone = armature.data.bones.get(keep.subtarget)
        if bone is not None and not preserve_world:
            # Newly generated rigs are still at their bind transform, so this
            # repairs native constraints that were created without an inverse.
            # Existing constraints already store the armature/bone transform
            # from binding time. Rebuilding that inverse from the armature's
            # *current* world matrix would cancel any later rig relocation and
            # snap the mesh back to its original world-space coordinates.
            bone_matrix = getattr(bone, "matrix_local", None)
            if bone_matrix is None:
                bone_matrix = bone.matrix
            if hasattr(bone_matrix, "to_4x4"):
                bone_matrix = bone_matrix.to_4x4()
            keep.inverse_matrix = (armature.matrix_world @ bone_matrix).inverted()
        normalized += 1

    if preserve_world and preserved_world:
        try:
            bpy.context.view_layer.update()
        except (AttributeError, RuntimeError):
            pass
        restored = False
        for obj, world_matrix in preserved_world:
            try:
                if any(
                    abs(
                        float(obj.matrix_world[row][column])
                        - float(world_matrix[row][column])
                    )
                    > 1.0e-8
                    for row in range(4)
                    for column in range(4)
                ):
                    obj.matrix_world = world_matrix
                    restored = True
            except (AttributeError, ReferenceError, RuntimeError, TypeError):
                pass
        if restored:
            try:
                bpy.context.view_layer.update()
            except (AttributeError, RuntimeError):
                pass

    return normalized


def _sync_armature_debug_overlays(advanced_mode, show_bone_names = None):
    runtime_saved = _state.setdefault("armature_overlay_saved", {})

    for armature_data in bpy.data.armatures:
        pointer = int(armature_data.as_pointer())
        persisted = armature_data.get(ARMATURE_OVERLAY_STATE_KEY)

        if not advanced_mode:
            if persisted is None and pointer not in runtime_saved:
                original = (
                    bool(armature_data.show_axes),
                    bool(armature_data.show_names),
                )
                runtime_saved[pointer] = (armature_data, original)
                try:
                    armature_data[ARMATURE_OVERLAY_STATE_KEY] = list(original)
                except (AttributeError, RuntimeError, TypeError):
                    pass
            try:
                armature_data.show_axes = False

                if show_bone_names is not None:
                    armature_data.show_names = show_bone_names
            except (AttributeError, RuntimeError, TypeError):
                pass
            continue

        original = None
        if persisted is not None and len(persisted) >= 2:
            original = (bool(persisted[0]), bool(persisted[1]))
        elif pointer in runtime_saved:
            original = runtime_saved[pointer][1]

        if original is not None:
            try:
                armature_data.show_axes = original[0]
                if show_bone_names is None:
                    armature_data.show_names = original[1]
            except (AttributeError, RuntimeError, TypeError):
                pass
        if show_bone_names is not None:
            try:
                armature_data.show_names = show_bone_names
            except (AttributeError, RuntimeError, TypeError):
                pass
        try:
            if ARMATURE_OVERLAY_STATE_KEY in armature_data:
                del armature_data[ARMATURE_OVERLAY_STATE_KEY]
        except (AttributeError, RuntimeError, TypeError):
            pass
        runtime_saved.pop(pointer, None)


def _apply_roblox_compatibility(scene):
    wm = getattr(bpy.context, "window_manager", None)
    if wm is None:
        return

    advanced_mode = getattr(wm, "roblox_compat_advanced_mode", False)
    _sync_armature_debug_overlays(advanced_mode, False)

    rigs = tuple(_iter_roblox_rigs())
    for _collection, armature, meta in rigs:
        _hide_roblox_rig_meta(meta)
        _set_roblox_auxiliary_bone_collections_visibility(
            armature,
            advanced_mode,
        )

    if not _roblox_addon_is_enabled():
        return

    _patch_roblox_preview_draw_callbacks()

    hide_welds = not advanced_mode
    hide_face_bones = not advanced_mode
    hide_helper_bones = not advanced_mode

    for _collection, armature, _meta in rigs:
        pointer = armature.as_pointer()
        if pointer not in _state["roblox_constraints_normalized"]:
            new_rigs = _state.setdefault("roblox_constraints_new_rigs", set())
            is_new_rig = pointer in new_rigs
            _normalize_roblox_part_constraints(
                armature,
                preserve_world = not is_new_rig,
            )
            new_rigs.discard(pointer)
            _state["roblox_constraints_normalized"].add(pointer)
        _set_roblox_bone_visibility(
            armature,
            "_StaticalizaWeldBones",
            lambda bone: _is_roblox_weld_bone(armature, bone),
            hide_welds,
        )
        _set_roblox_bone_visibility(
            armature,
            "_StaticalizaFaceBones",
            lambda bone: bool(bone.get("rbx_face_deform_bone")),
            hide_face_bones,
        )
        _set_roblox_bone_visibility(
            armature,
            "_StaticalizaHelperBones",
            lambda bone: (
                _is_numbered_helper_bone(armature, bone)
                or _is_roblox_structural_root_bone(armature, bone)
            ),
            hide_helper_bones,
        )


def _on_roblox_compatibility_setting_change(self, context):
    _apply_roblox_compatibility(context.scene)
    _tag_redraw_all_view3d()


def _on_hide_advanced_panels_change(self, context):
    window_manager = getattr(context, "window_manager", None)
    if window_manager is None:
        return
    for window in window_manager.windows:
        screen = window.screen
        if screen is None:
            continue
        for area in screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


def _sync_view3d_relationship_lines(context):
    window_manager = getattr(context, "window_manager", None)
    if window_manager is None:
        return


    show_lines = bool(
        getattr(window_manager, "roblox_compat_advanced_mode", False)
    )
    for window in window_manager.windows:
        screen = getattr(window, "screen", None)
        if screen is None:
            continue
        for area in screen.areas:
            if area.type != "VIEW_3D":
                continue
            for space in area.spaces:
                if space.type == "VIEW_3D":
                    space.overlay.show_relationship_lines = show_lines
            area.tag_redraw()


def _on_advanced_mode_change(self, context):
    _apply_roblox_compatibility(context.scene)
    _sync_view3d_relationship_lines(context)
    _on_hide_advanced_panels_change(self, context)


@persistent
def _roblox_compatibility_depsgraph_update(scene, depsgraph):
    if scene is not None and scene.get('_staticaliza_physics_scratch', False):
        return
    if (
        _state.get("pin_history_active", False)
        or _state.get("pin_history_syncing", False)
        or _state.get("pin_history_direction", "")
    ):
        return
    normalized = _state.get("roblox_constraints_normalized", set())
    refresh_armature_list = False
    schedule_compatibility = False
    for update in tuple(depsgraph.updates):
        datablock = getattr(update, "id", None)
        if isinstance(datablock, bpy.types.Armature):
            refresh_armature_list = True
            advanced_mode = bool(getattr(
                getattr(bpy.context, "window_manager", None),
                "roblox_compat_advanced_mode",
                False,
            ))
            auxiliary_visibility_changed = any(
                _is_roblox_auxiliary_bone_collection(collection)
                and bool(collection.is_visible) != advanced_mode
                for collection in getattr(datablock, "collections", ())
            )
            if auxiliary_visibility_changed:
                schedule_compatibility = True
            continue
        if not isinstance(datablock, bpy.types.Object):
            continue
        if datablock.type != "ARMATURE":
            continue
        pointer = datablock.as_pointer()
        if pointer not in normalized:
            refresh_armature_list = True
            schedule_compatibility = True

    # Pose/object transforms update the depsgraph for every mouse movement.
    # Do not rescan every scene object unless an armature data-block or a newly
    # discovered armature actually made the list structurally relevant.
    if refresh_armature_list and not _window_manager_has_modal_operator(
        bpy.context
    ):
        _refresh_roblox_armature_list(bpy.context)
    if schedule_compatibility:
        _schedule_roblox_compatibility_scan()


def _run_roblox_compatibility_scan():
    context = bpy.context
    if (
        _state.get("pin_history_active", False)
        or _state.get("pin_history_syncing", False)
        or _state.get("pin_history_direction", "")
        or _pin_primary_mouse_pressed()
        or (
            context is not None
            and _window_manager_has_modal_operator(context)
        )
    ):
        return 0.1
    _state["roblox_compatibility_scan_pending"] = False
    if context and context.scene:
        _apply_roblox_compatibility(context.scene)
    return None


def _schedule_roblox_compatibility_scan(delay = 0.15):
    if _state.get("roblox_compatibility_scan_pending", False):
        return
    _state["roblox_compatibility_scan_pending"] = True
    try:
        register_owned_timer(
            _run_roblox_compatibility_scan,
            first_interval = delay,
        )
    except Exception:
        _state["roblox_compatibility_scan_pending"] = False
