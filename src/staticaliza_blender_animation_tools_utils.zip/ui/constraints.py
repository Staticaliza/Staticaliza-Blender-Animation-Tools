"""One Constraints section for Collision and Gyro pins in the panel and Ctrl+F."""

from ..core.runtime import *  # noqa: F403
from ..pins.gyro import GYRO_POSITION_ITEMS, GYRO_AXIS_ITEMS
from types import SimpleNamespace


def _constraint_button_type(operator, kind):
    """Initialize a button without running an interactive RNA update on draw."""
    # Enum RNA setters with update callbacks notify Blender even when the
    # value is unchanged. Doing that while drawing this panel invalidates the
    # native transform gizmo's hover/selection state before its drag begins.
    # Button properties are new operator inputs, so initialize their backing
    # enum value directly; actual type edits in redo still use the RNA setter.
    operator["constraint_type"] = (
        operator.bl_rna.properties["constraint_type"].enum_items[kind].value
    )


def _constraint_operator_set_axis(operator, axis):
    previous = _state.get("constraint_axis_default_syncing", False)
    _state["constraint_axis_default_syncing"] = True
    try:
        operator.axis = axis
    finally:
        _state["constraint_axis_default_syncing"] = previous


def _constraint_creation_axis_changed(self, context):
    if not _state.get("constraint_axis_default_syncing", False):
        self.axis_edited = True


def _constraint_creation_type_changed(self, context):
    if not self.axis_edited:
        _constraint_operator_set_axis(self, "Z_NEG" if self.constraint_type == "GYRO" else "Y_NEG")


def _constraint_axis_edited(guide, kind):
    key = "gyro_axis" if kind == "GYRO" else SURFACE_CONTACT_CAST_AXIS_PROPERTY
    default = "Z_NEG" if kind == "GYRO" else "Y_NEG"
    return bool(guide.get("_constraint_axis_edited", str(guide.get(key, default)) != default))


def _constraint_settings_changed(self, context, field):
    if (context is None or context.mode != "POSE" or _state.get("constraint_settings_syncing")
            or _state.get("pin_history_syncing") or _state.get("gyro_native_history")):
        return
    state = _constraint_selection_state(context)
    pink = _surface_contact_selected_guides(context, active_only=True)
    cyan = [guide for guide in state["cyan"] if _gyro_authored_active(context, guide)]
    if not pink and not cyan:
        return
    _state["constraint_settings_syncing"] = True
    try:
        settings = SimpleNamespace(surface_contact_pin_mode=self.constraint_pin_position,
                                   surface_contact_cast_axis=self.constraint_pin_axis)
        if field == "POSITION" and pink:
            _surface_contact_apply_pin_mode_change(settings, context, push_history=False)
        elif field == "AXIS":
            for guide in pink:
                guide["_constraint_axis_edited"] = True
                settings.surface_contact_pin_mode = str(guide.get(SURFACE_CONTACT_PIN_MODE_PROPERTY, "MODE_3"))
                _surface_contact_apply_cast_axis_change(settings, context, guide_override=guide, push_history=False)
        for guide in cyan:
            if field == "AXIS":
                guide["_constraint_axis_edited"] = True
            settings.gyro_pin_mode = (self.constraint_pin_position if field == "POSITION"
                                      else str(guide.get("gyro_position", "MODE_3")))
            settings.gyro_facing_axis = (self.constraint_pin_axis if field == "AXIS"
                                        else str(guide.get("gyro_axis", "Z_NEG")))
            settings.gyro_sky_distance = 10.0
            _gyro_apply_settings(settings, context, guides_override=(guide,), push_history=False)
        bpy.ops.ed.undo_push(message="Constraints Settings")
        _tag_redraw_all_view3d()
    finally:
        _state["constraint_settings_syncing"] = False


def _constraint_position_changed(self, context):
    _constraint_settings_changed(self, context, "POSITION")


def _constraint_axis_changed(self, context):
    _constraint_settings_changed(self, context, "AXIS")


def _draw_constraint_settings(layout, context):
    state = _constraint_selection_state(context)
    kind = context.window_manager.constraint_pin_type
    guide = next((g for g in (state["cyan"] if kind == "GYRO" else state["pink"])
                  if (_gyro_authored_active(context, g) if kind == "GYRO" else
                      _surface_contact_guide_interval_active_at(g, context.scene.frame_current))), None)
    if guide is None:
        return
    mode = str(guide.get("gyro_position" if kind == "GYRO" else SURFACE_CONTACT_PIN_MODE_PROPERTY, "MODE_3"))
    axis = str(guide.get("gyro_axis" if kind == "GYRO" else SURFACE_CONTACT_CAST_AXIS_PROPERTY,
                         "Z_NEG" if kind == "GYRO" else "Y_NEG"))
    previous = _state.get("constraint_settings_syncing", False)
    _state["constraint_settings_syncing"] = True
    try:
        wm = context.window_manager
        if wm.constraint_pin_position != mode:
            wm.constraint_pin_position = mode
        if wm.constraint_pin_axis != axis:
            wm.constraint_pin_axis = axis
    finally:
        _state["constraint_settings_syncing"] = previous
    layout.prop(wm, "constraint_pin_position", text="Position")
    layout.prop(wm, "constraint_pin_axis", text="Axis")


def _constraint_selection_state(context):
    subjects = {(arm.name, bone.name): (arm, bone)
                for arm, bones in _selected_pose_bones_by_owner(context).items() for bone in bones}
    for _key, data in _pin_selected_targets_data(context):
        if data[0] in {"CONTACT", "GYRO"}:
            subjects[(data[1].name, data[2].name)] = (data[1], data[2])
    frame = context.scene.frame_current
    missing, pink, cyan, end_pink, end_cyan = [], {}, {}, {}, {}
    clear_pink, clear_cyan = {}, {}
    for armature, bone in subjects.values():
        relation = _surface_contact_ik_relation(armature, bone)
        effector = relation["effector"] if relation is not None else bone
        contacts = _surface_contact_guides_for_effector(armature, effector)
        active_contacts = [guide for guide in contacts
                           if _surface_contact_guide_interval_active_at(guide, frame)]
        selected_contact = max(active_contacts or contacts,
                               key=lambda guide: int(guide.get(SURFACE_CONTACT_START_PROPERTY, 0)),
                               default=None)
        if selected_contact is not None:
            pink[selected_contact.name] = selected_contact
        for guide in contacts:
            if _special_clear_frame_in_range(frame, guide.get(SURFACE_CONTACT_START_PROPERTY),
                                             guide.get(SURFACE_CONTACT_END_PROPERTY)):
                clear_pink[guide.name] = guide
        for guide in active_contacts:
            if (frame > int(guide.get(SURFACE_CONTACT_START_PROPERTY, frame))
                    and frame != guide.get(SURFACE_CONTACT_END_PROPERTY)):
                end_pink[guide.name] = guide
        gyro = _gyro_find(context, armature, bone)
        active_gyro = gyro is not None and _gyro_authored_active(context, gyro)
        if gyro is not None:
            cyan[gyro.name] = gyro
            if _special_clear_marker_range(_pin_marker_points(bone, GYRO_MARKER).items(), frame):
                clear_cyan[gyro.name] = gyro
        if active_gyro:
            enabled, start = False, frame
            for key_frame, value in sorted(_pin_marker_points(bone, GYRO_MARKER).items()):
                if key_frame > frame:
                    break
                if value >= .5 and not enabled:
                    start = key_frame
                enabled = value >= .5
            if frame > start:
                end_cyan[gyro.name] = gyro
        if not active_contacts and not active_gyro:
            missing.append((armature, bone))
    return {"subjects": tuple(subjects.values()), "missing": tuple(missing),
            "pink": tuple(pink.values()), "cyan": tuple(cyan.values()),
            "end_pink": tuple(end_pink.values()), "end_cyan": tuple(end_cyan.values()),
            "clear_pink": tuple(clear_pink.values()), "clear_cyan": tuple(clear_cyan.values())}


def _constraint_creation_subjects(context):
    override = _state.get("constraint_creation_subjects")
    if override is not None:
        return override
    return tuple((arm, bone) for arm, bones in _selected_pose_bones_by_owner(
        context, include_virtual_pin=True).items() for bone in bones)


def _constraint_can_split(context, state=None):
    state = state or _constraint_selection_state(context)
    frame = int(context.scene.frame_current)
    return (_surface_contact_can_split(context) or any(
        value > .5 and start < frame and frame+1 < end < float("inf")
        for guide in state["cyan"]
        for _armature, bone in (_gyro_owner(guide),) if bone is not None
        for start, end, value in _constraint_gyro_intervals(bone)))


def _constraint_gyro_intervals(bone):
    points = sorted(_pin_marker_points(bone, GYRO_MARKER).items())
    return tuple((frame, points[index+1][0] if index+1 < len(points) else float("inf"), value)
                 for index, (frame, value) in enumerate(points))


def _draw_constraint_actions(row, context, state, split=None):
    split = _constraint_can_split(context, state) if split is None else split
    mode = context.window_manager.constraint_pin_type
    if split:
        row.operator("staticaliza.constraint_action", text="Key Split", icon="KEYINGSET").action = "SPLIT"
    else:
        if state["missing"]:
            operator = row.operator("staticaliza.constraint_start", text="Key Start", icon="KEY_HLT")
            _constraint_button_type(operator, mode)
            operator.only_missing = True
        if state["end_pink"] or state["end_cyan"]:
            row.operator("staticaliza.constraint_action", text="Key End", icon="KEY_DEHLT").action = "END"


def _draw_constraint_clear(layout, state):
    if state["clear_pink"] or state["clear_cyan"]:
        layout.operator("staticaliza.constraint_action", text="Clear", icon="X").action = "CLEAR"


def _draw_constraints(layout, context, menu=False):
    _constraints_sync_choice(context)
    if menu:
        layout.label(text="Constraints")
    else:
        layout.label(text="Constraints", icon="CONSTRAINT_BONE")
    if not menu and (_surface_contact_selected_guides(context, active_only=True)
                     or any(guide is not None and _gyro_authored_active(context, guide)
                            for arm, bone in _gyro_subjects(context)
                            for guide in (_gyro_find(context, arm, bone),))):
        choices = layout.row(align=True)
        for kind, label in (("COLLISION", "Collision"), ("GYRO", "Gyro")):
            switch = choices.operator("staticaliza.constraint_start", text=label,
                                      depress=context.window_manager.constraint_pin_type == kind)
            _constraint_button_type(switch, kind)
            switch.switch_existing = True
    if context.window_manager.constraint_pin_type == "GYRO":
        _gyro_draw_ui(layout, context, menu=menu, heading=False)
        return
    wm = context.window_manager
    _create, _release, clear, status = _surface_contact_ui_state(context)
    state = _constraint_selection_state(context)
    split = _constraint_can_split(context, state)
    subjects = bool(state["subjects"])
    if not subjects:
        _draw_selection_hint(layout, "Select a bone.")
        return
    advanced = getattr(wm, "roblox_compat_advanced_mode", False)
    if advanced and status:
        layout.label(text=status)
    if clear and not menu:
        _draw_constraint_settings(layout, context)
    row = layout if menu else layout.row(align=True)
    _draw_constraint_actions(row, context, state, split)
    if clear:
        count = len(_surface_contact_selected_guides(context, active_only=True))
        pivot = layout.row()
        pivot.operator_context = "INVOKE_DEFAULT"
        pivot.operator("staticaliza.surface_contact_pivot",
                       text="Pivot Pin" if count == 1 else "Pivot Pins", icon="PIVOT_CURSOR")
    _draw_constraint_clear(layout, state)
    if advanced and clear:
        layout.prop(wm, "staticaliza_surface_contact_mode", text="Surface")


def _constraints_sync_choice(context):
    owners = _selected_owner_bone_keys(context)
    cyan = _gyro_selected_target(context)
    pink = _surface_contact_selected_guides(context, active_only=True)
    signature = (tuple(sorted(owners)), cyan.name if cyan is not None else "",
                 tuple(sorted(g.name for g in pink)))
    if _state.get("constraints_choice_signature") == signature:
        return
    _state["constraints_choice_signature"] = signature
    if cyan is not None or any(_gyro_authored_active(context, guide)
            for guide in _gyro_guides(context.scene)
            if _owner_bone_key(_gyro_owner(guide)[0], str(guide.get("gyro_bone", ""))) in owners):
        context.window_manager.constraint_pin_type = "GYRO"
    elif pink:
        context.window_manager.constraint_pin_type = "COLLISION"


def _constraint_pin_end_other(context, armature, bone, kind):
    """Switch mode at this authored frame, retaining earlier animation."""
    frame = context.scene.frame_current
    if kind == "GYRO":
        for guide in _surface_contact_guides_for_effector(armature, bone):
            if _surface_contact_guide_interval_active_at(guide, frame):
                target = bpy.data.objects.get(str(guide.get(SURFACE_CONTACT_RELEASE_OBJECT_PROPERTY, "")))
                name = str(guide.get(SURFACE_CONTACT_RELEASE_BONE_PROPERTY, ""))
                world = (_surface_contact_target_world_matrix(context, target, name)
                         if target is not None else None)
                guide[SURFACE_CONTACT_END_PROPERTY] = frame
                _target, owner = _surface_contact_owner_from_guide(guide)
                _surface_contact_insert_marker(owner, bone.name, frame, 0.0)
                _surface_contact_set_constraint_attachment(guide, False)
                _surface_contact_set_snap_detached(guide, True)
        _surface_contact_clear_derived_caches()
    elif GYRO_MARKER in bone and _pin_marker_value(bone, GYRO_MARKER, frame) > .5:
        guide = _gyro_find(context, armature, bone)
        if guide is not None:
            visible = armature.evaluated_get(context.evaluated_depsgraph_get()).pose.bones[bone.name].matrix.copy()
            _gyro_end(context, armature, bone, guide, frame, visible, write_key=False)


def _constraint_pin_gyro_blocks_contact(guide, frame):
    armature, bone = _surface_contact_pose_bone(guide)
    return bool(bone is not None and GYRO_MARKER in bone
                and _pin_marker_value(bone, GYRO_MARKER, frame) > .5)


class ANIMATOR_UTILS_OT_constraint_start(bpy.types.Operator):
    bl_idname = "staticaliza.constraint_start"
    bl_label = "Constraints"
    bl_description = "Add a Collision or Gyro constraint to the selected bones"
    bl_options = {"REGISTER", "UNDO"}

    constraint_type: bpy.props.EnumProperty(name="Type", items=(
        ("COLLISION", "Collision", "Keep the bone in contact with a surface"),
        ("GYRO", "Gyro", "Keep the bone's world rotation stable")), default="COLLISION",
        update=_constraint_creation_type_changed)
    pin_mode: bpy.props.EnumProperty(name="Position", items=GYRO_POSITION_ITEMS, default="MODE_3")
    axis: bpy.props.EnumProperty(name="Axis", items=GYRO_AXIS_ITEMS, default="Y_NEG",
                                update=_constraint_creation_axis_changed, options={"SKIP_SAVE"})
    # These belong to one insertion/redo instance. Native UI dispatch recalls
    # last operator properties unless SKIP_SAVE prevents another insertion
    # inheriting an edited flag or an internally populated legacy axis.
    axis_edited: bpy.props.BoolProperty(default=False, options={"HIDDEN", "SKIP_SAVE"})
    initialized: bpy.props.BoolProperty(default=False, options={"HIDDEN", "SKIP_SAVE"})
    cast_axis: bpy.props.EnumProperty(name="Axis", items=PIN_AXIS_ITEMS, default="Y_NEG", options={"HIDDEN", "SKIP_SAVE"})
    facing_axis: bpy.props.EnumProperty(name="Axis", items=GYRO_AXIS_ITEMS, default="Z_NEG", options={"HIDDEN", "SKIP_SAVE"})
    sky_distance: bpy.props.FloatProperty(default=10.0, min=10.0, max=10.0, options={"HIDDEN"})
    only_missing: bpy.props.BoolProperty(default=False, options={"HIDDEN", "SKIP_SAVE"})
    switch_existing: bpy.props.BoolProperty(default=False, options={"HIDDEN", "SKIP_SAVE"})

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE" and bool(_constraint_selection_state(context)["subjects"])

    def draw(self, context):
        self.layout.row(align=True).prop(self, "constraint_type", expand=True)
        self.layout.prop(self, "pin_mode", text="Position")
        self.layout.prop(self, "axis", text="Axis")

    def execute(self, context):
        # Call the implementations directly: nested bpy.ops would replace the
        # redo panel and split one creation into separate history operations.
        previous = _state.get("constraint_creation_subjects")
        previous_transaction = _state.get('constraint_creation_transaction', False)
        virtual_owners = set()
        conversions = []
        axis_intents = {}
        if self.switch_existing:
            state = _constraint_selection_state(context)
            subjects = []
            for arm, bone in state["subjects"]:
                gyro = _gyro_find(context, arm, bone)
                active_gyro = gyro is not None and _gyro_authored_active(context, gyro)
                active_contact = any(_surface_contact_guide_interval_active_at(
                    guide, context.scene.frame_current)
                    for guide in _surface_contact_guides_for_effector(arm, bone))
                if ((self.constraint_type == "GYRO" and active_contact and not active_gyro)
                        or (self.constraint_type == "COLLISION" and active_gyro)):
                    subjects.append((arm, bone))
                    source = gyro if self.constraint_type == "COLLISION" else max(
                        (g for g in _surface_contact_guides_for_effector(arm, bone)
                         if _surface_contact_guide_interval_active_at(g, context.scene.frame_current)),
                        key=lambda g: int(g.get(SURFACE_CONTACT_START_PROPERTY, 0)))
                    source_kind = "GYRO" if self.constraint_type == "COLLISION" else "COLLISION"
                    edited = _constraint_axis_edited(source, source_kind)
                    conversions.append((arm, bone,
                        str(source.get("gyro_position" if self.constraint_type == "COLLISION" else SURFACE_CONTACT_PIN_MODE_PROPERTY, "MODE_3")),
                        str(source.get("gyro_axis" if self.constraint_type == "COLLISION" else SURFACE_CONTACT_CAST_AXIS_PROPERTY,
                                       "Z_NEG" if self.constraint_type == "COLLISION" else "Y_NEG"))
                            if edited else ("Z_NEG" if self.constraint_type == "GYRO" else "Y_NEG"), edited))
            _state["constraint_creation_subjects"] = tuple(subjects)
            virtual_owners = {(data[1].name, data[2].name)
                              for _key, data in _pin_selected_targets_data(context)
                              if data[0] in {"CONTACT", "GYRO"}}
        elif self.only_missing:
            _state["constraint_creation_subjects"] = _constraint_selection_state(context)["missing"]
        _state['constraint_creation_transaction'] = True
        try:
            if (self.only_missing or self.switch_existing) and not _state["constraint_creation_subjects"]:
                return {"CANCELLED"}
            if self.switch_existing:
                result = {"CANCELLED"}
                for arm, bone, mode, axis, edited in conversions:
                    _state["constraint_creation_subjects"] = ((arm, bone),)
                    self.pin_mode = mode
                    self.axis_edited = edited
                    axis_intents[(arm.name, bone.name)] = edited
                    _constraint_operator_set_axis(self, axis)
                    if self.constraint_type == "GYRO":
                        self.facing_axis = axis
                        outcome = ANIMATOR_UTILS_OT_gyro_start.execute(self, context)
                    else:
                        self.cast_axis = axis
                        outcome = ANIMATOR_UTILS_OT_surface_contact_create.execute(self, context)
                    if outcome == {"FINISHED"}:
                        result = outcome
                _state["constraint_creation_subjects"] = tuple(subjects)
            elif self.constraint_type == "GYRO":
                if not self.properties.is_property_set("pin_mode"):
                    self.pin_mode = "MODE_3"
                if not self.axis_edited:
                    legacy = not self.initialized and self.properties.is_property_set("facing_axis")
                    _constraint_operator_set_axis(self, self.facing_axis if legacy else "Z_NEG")
                    self.axis_edited = legacy
                self.facing_axis = self.axis
                result = ANIMATOR_UTILS_OT_gyro_start.execute(self, context)
            else:
                if not self.properties.is_property_set("pin_mode"):
                    self.pin_mode = "MODE_3"
                if not self.axis_edited:
                    legacy = not self.initialized and self.properties.is_property_set("cast_axis")
                    _constraint_operator_set_axis(self, self.cast_axis if legacy else "Y_NEG")
                    self.axis_edited = legacy
                self.cast_axis = self.axis
                result = ANIMATOR_UTILS_OT_surface_contact_create.execute(self, context)
            if result == {"FINISHED"}:
                for arm, bone in _constraint_creation_subjects(context):
                    guide = (_gyro_find(context, arm, bone) if self.constraint_type == "GYRO" else
                             next((g for g in reversed(_surface_contact_guides_for_effector(arm, bone))
                                   if _surface_contact_guide_interval_active_at(g, context.scene.frame_current)), None))
                    if guide is not None:
                        guide["_constraint_axis_edited"] = axis_intents.get((arm.name, bone.name), self.axis_edited)
                self.initialized = True
            if self.switch_existing and result == {"FINISHED"}:
                # Retain virtual selection on the replacement handle as well
                # as ordinary bone selection. All writes share this operator's undo.
                for arm, bone in _state["constraint_creation_subjects"]:
                    if (arm.name, bone.name) not in virtual_owners:
                        continue
                    if self.constraint_type == "GYRO":
                        guide = _gyro_find(context, arm, bone)
                        key = _gyro_snap_key(guide) if guide is not None else ""
                    else:
                        guide = next((guide for guide in _surface_contact_guides_for_effector(arm, bone)
                                      if _surface_contact_guide_interval_active_at(
                                          guide, context.scene.frame_current)), None)
                        key = _surface_contact_snap_key(guide) if guide is not None else ""
                    if key:
                        _pin_select_target(context, key, extend=True,
                            target_data_override=("GYRO" if self.constraint_type == "GYRO" else "CONTACT",
                                                  arm, bone, guide))
                _state.pop("constraints_choice_signature", None)
            return result
        finally:
            _state['constraint_creation_transaction'] = previous_transaction
            if previous is None:
                _state.pop("constraint_creation_subjects", None)
            else:
                _state["constraint_creation_subjects"] = previous
            if not previous_transaction:
                _schedule_transform_gizmo_refresh()


class ANIMATOR_UTILS_OT_constraint_action(bpy.types.Operator):
    bl_idname = "staticaliza.constraint_action"
    bl_label = "Constraints"
    bl_description = "Manage the selected constraints"
    bl_options = {"REGISTER", "UNDO"}
    action: bpy.props.EnumProperty(items=(("END", "Key End", "End selected constraints and key the ending pose"),
                                         ("SPLIT", "Key Split", "End selected segments here and resume them on the next frame"),
                                         ("CLEAR", "Clear", "Remove the selected constraints")), default="END", options={"HIDDEN"})
    insert_bone_keyframe: bpy.props.BoolProperty(
        name="Insert Keyframe", default=True, options={"SKIP_SAVE"},
        description="Key the ending bone pose unless a bone key already exists at that frame")

    def draw(self, context):
        if self.action in {"END", "SPLIT"}:
            self.layout.prop(self, "insert_bone_keyframe")

    @classmethod
    def description(cls, context, properties):
        return {"END": "End selected constraints and key the ending bone pose",
                "SPLIT": "End selected segments here, key the pose, and resume on the next frame",
                "CLEAR": "Remove selected Collision/Gyro constraints and keep the pose. Available from Key Start through Key End, inclusive"}.get(properties.action, cls.bl_description)

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE" and bool(_constraint_selection_state(context)["subjects"])

    def execute(self, context):
        return _special_end_with_key_option(self, context, self._execute)

    def _execute(self, context):
        return _constraint_apply_action(context, self.action, self)


def _constraint_apply_action(context, action, operator):
    state = _constraint_selection_state(context)
    pink = state["end_pink"] if action in {"END", "SPLIT"} else state["clear_pink"]
    cyan = state["end_cyan"] if action in {"END", "SPLIT"} else state["clear_cyan"]
    if not pink and not cyan:
        return {"CANCELLED"}
    previous = _state.get("gyro_syncing", False)
    _state["gyro_syncing"] = True
    try:
        # Capture every output before any shared Action insertion replays.
        snapshots = []
        for guide in cyan:
            armature, bone = _gyro_owner(guide)
            evaluated = armature.evaluated_get(context.evaluated_depsgraph_get())
            snapshots.append((guide, armature, bone, evaluated.pose.bones[bone.name].matrix.copy()))
        for guide in pink:
            if action == "SPLIT":
                arm, bone = _surface_contact_pose_bone(guide)
                end = guide.get(SURFACE_CONTACT_END_PROPERTY)
                if end is not None and context.scene.frame_current+1 < int(end):
                    settings = SimpleNamespace(pin_mode=str(guide.get(SURFACE_CONTACT_PIN_MODE_PROPERTY, "MODE_3")),
                        cast_axis=str(guide.get(SURFACE_CONTACT_CAST_AXIS_PROPERTY, "Y_NEG")), report=operator.report)
                    ANIMATOR_UTILS_OT_surface_contact_create._execute_bone(settings, context, arm, bone)
                    _constraint_ensure_future_end_pose(context, arm, bone, int(end))
            elif action == "END":
                _surface_contact_release_guide(context, guide, operator)
            else:
                _surface_contact_remove_guide(context, guide, preserve_frame=context.scene.frame_current)
        for guide, armature, bone, visible in snapshots:
            if action == "SPLIT":
                frame = int(context.scene.frame_current)
                end = next((end for start, end, value in _constraint_gyro_intervals(bone)
                            if value > .5 and start < frame and frame+1 < end < float("inf")), None)
                if end is not None:
                    _gyro_end(context, armature, bone, guide, frame, visible)
                    _gyro_key_enabled(armature, bone, frame+1, True)
                    _gyro_key_transform(guide, frame+1)
                    _gyro_key_transform(guide["gyro_reference"], frame+1)
                    _constraint_ensure_future_end_pose(context, armature, bone, int(end))
            elif action == "END":
                _gyro_end(context, armature, bone, guide, context.scene.frame_current, visible)
            else:
                _constraint_remove_gyro(context, guide, visible)
        context.view_layer.update()
        _gyro_seed_baselines(context)
        _sync_all_dynamic_pose_bone_colors(context.scene.frame_current)
        _tag_redraw_all_view3d()
    finally:
        _state["gyro_syncing"] = previous
    return {"FINISHED"}
