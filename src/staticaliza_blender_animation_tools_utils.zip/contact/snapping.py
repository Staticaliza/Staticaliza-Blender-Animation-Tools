"""Surface-contact snapping, projection, and target movement."""

from ..core.runtime import *  # noqa: F403


def _pin_project_world_to_region(context, point):
    """Project a world point through the active 3D transform viewport."""
    area = getattr(context, "area", None) if context is not None else None
    region = getattr(context, "region", None) if context is not None else None
    region_data = (
        getattr(context, "region_data", None)
        if context is not None
        else None
    )
    if not (
        area is not None
        and getattr(area, "type", "") == "VIEW_3D"
        and region is not None
        and getattr(region, "type", "") == "WINDOW"
        and region_data is not None
    ):
        window = getattr(context, "window", None) if context is not None else None
        screen = getattr(window, "screen", None) if window is not None else None
        candidates = []
        for candidate_area in getattr(screen, "areas", ()):
            if getattr(candidate_area, "type", "") != "VIEW_3D":
                continue
            candidate_region = next((
                item
                for item in getattr(candidate_area, "regions", ())
                if getattr(item, "type", "") == "WINDOW"
            ), None)
            candidate_space = getattr(candidate_area, "spaces", None)
            candidate_space = (
                getattr(candidate_space, "active", None)
                if candidate_space is not None
                else None
            )
            candidate_region_data = getattr(
                candidate_space,
                "region_3d",
                None,
            )
            if candidate_region is not None and candidate_region_data is not None:
                candidates.append((
                    int(candidate_region.width) * int(candidate_region.height),
                    candidate_region,
                    candidate_region_data,
                ))
        if not candidates:
            return None
        _size, region, region_data = max(candidates, key=lambda item: item[0])
    try:
        from bpy_extras import view3d_utils

        projected = view3d_utils.location_3d_to_region_2d(
            region,
            region_data,
            Vector(point),
        )
        return Vector(projected) if projected is not None else None
    except (
        AttributeError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ):
        return None


def _pin_points_within_snap_radius(
    context,
    target,
    current,
    pixel_radius = PIN_SNAP_PIXEL_RADIUS,
):
    target_2d = _pin_project_world_to_region(context, target)
    current_2d = _pin_project_world_to_region(context, current)
    if target_2d is not None and current_2d is not None:
        # The user sees and approaches the snap ring in screen space. Using a
        # fixed world radius here made the visible ring lie: zoomed views could
        # show the pink dot inside the advertised radius while admission still
        # failed. This test now uses the same pixel contract as the overlay.
        return (target_2d - current_2d).length <= 1.e-5 + max(
            1.0,
            float(pixel_radius),
        )
    # Headless tests and non-3D callbacks have no projection. Preserve the
    # orientation-neutral world fallback for those contexts.
    radius_scale = max(1.0, float(pixel_radius)) / PIN_SNAP_PIXEL_RADIUS
    world_radius = PIN_SNAP_WORLD_RADIUS * radius_scale
    return (Vector(target) - Vector(current)).length <= world_radius + 1.e-7


def _pin_snap_segment_close(context, target, start, end, *, world_radius=PIN_SNAP_WORLD_RADIUS):
    """Sweep in the entry test's pixel metric, with the same world fallback."""
    projected=tuple(_pin_project_world_to_region(context,p) for p in (target,start,end))
    if all(p is not None for p in projected):
        point,a,b=projected
        radius=PIN_SNAP_PIXEL_RADIUS
    else:
        point,a,b=Vector(target),Vector(start),Vector(end)
        radius=float(world_radius)
    delta=b-a
    if delta.length_squared<1.e-16:return (point-b).length<=radius
    factor=max(0.,min(1.,(point-a).dot(delta)/delta.length_squared))
    return (point-a-delta*factor).length<=radius

def _surface_contact_snap_key(guide):
    armature = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
    )
    return f"CONTACT:{_armature_session_uid(armature)}:{getattr(guide, 'name', '')}"


def _surface_contact_new_snap_allowed(context, guide):
    """Allow entry only during a direct manual pink-bone transform."""
    if (
        context is None
        or _state.get("pin_target_dragging", False)
        or _pin_selected_target_key()
    ):
        return False
    transform_active = bool(
        _state.get("pin_snap_transform_active", False)
        or _state.get("pin_keyboard_transform_active", False)
    )
    if not transform_active:
        try:
            transform_active = bool(_pin_active_transform_operator(context))
        except (
            AttributeError,
            ReferenceError,
            RuntimeError,
            TypeError,
            ValueError,
        ):
            transform_active = False
    if not transform_active:
        return False
    if guide.name in _state.get("pin_snap_direct_transform_guides", set()):
        return True
    if getattr(context, "mode", "") != "POSE":
        return False
    armature = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
    )
    if armature is None:
        return False
    selected_names = {
        pose_bone.name
        for pose_bone in _selected_pose_bones_by_owner(context).get(
            armature,
            (),
        )
    }
    return bool(
        selected_names
        and _surface_contact_direct_bone_names(guide) & selected_names
    )

def _surface_contact_set_snap_detached(guide, detached):
    if (_state.get('pin_snap_transform_active')
            and guide.name not in _state.get('pin_snap_direct_transform_guides',())
            and guide.name in _state.get('pin_snap_parent_attachment_states',{})):
        detached=not _state['pin_snap_parent_attachment_states'][guide.name]
    key = _surface_contact_snap_key(guide)
    detached_keys = _state.setdefault("pin_snap_detached", set())
    if detached:
        detached_keys.add(key)
        _state.setdefault("pin_snap_pressure_active", set()).discard(key)
        # Attached and detached are mutually exclusive semantic states. A
        # stale latch bypasses the detached/new-snap gate and can make the
        # next unrelated or ancestor update force Contact back on.
        _state.setdefault("pin_snap_latches", set()).discard(key)
        _state.setdefault("pin_snap_transform_engaged", set()).discard(key)
        if key not in _state.setdefault(
            "pin_snap_transform_releasing", set()
        ):
            _state.setdefault("pin_snap_engage_translate_origins", {}).pop(
                key, None
            )
            _state.setdefault("pin_snap_engage_anchor_origins", {}).pop(
                key, None
            )
            _state.setdefault("pin_snap_grip_directions", {}).pop(
                key, None
            )
        _state.setdefault("pin_snap_swept_hits", set()).discard(key)
        try:
            if not bool(guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)):
                guide[SURFACE_CONTACT_DETACHED_PROPERTY] = True
        except (ReferenceError, RuntimeError, TypeError):
            pass
    else:
        detached_keys.discard(key)
        try:
            if _surface_contact_detached_fcurves(guide):
                current = guide.get(SURFACE_CONTACT_DETACHED_PROPERTY)
                if current is None or abs(float(current)) > 1.0e-8:
                    guide[SURFACE_CONTACT_DETACHED_PROPERTY] = 0.0
            elif SURFACE_CONTACT_DETACHED_PROPERTY in guide:
                del guide[SURFACE_CONTACT_DETACHED_PROPERTY]
        except (
            KeyError,
            ReferenceError,
            RuntimeError,
            TypeError,
            ValueError,
        ):
            pass

def _surface_contact_restore_snap_detached(
    context,
    infer_missing = True,
    reset_runtime = True,
):
    """Restore the saved/runtime detach latch before contact enforcement."""
    detached_keys = _state.setdefault("pin_snap_detached", set())
    if reset_runtime:
        detached_keys.clear()
    scene = getattr(context, "scene", None) if context is not None else None
    if scene is None:
        return False

    active_guides = set(_surface_contact_active_snap_guides(scene))
    frame = int(scene.frame_current)
    changed = False
    for guide in _surface_contact_guides():
        if not _surface_contact_snap_capable(guide):
            continue
        # Blender evaluates the raw Action pose before Contact is restored on
        # a cold load.  That temporary endpoint gap must not override an
        # authored Contact-state curve: doing so marks an explicitly attached
        # pin detached before the load solver gets a chance to settle it.
        animated = (
            _surface_contact_animated_detached_state(guide, frame)
            if infer_missing
            else None
        )
        if animated is not None:
            key = _surface_contact_snap_key(guide)
            before = bool(
                key in detached_keys
                or bool(guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False))
            )
            _surface_contact_set_snap_detached(guide, bool(animated))
            changed = changed or before != bool(animated)
            continue
        if bool(guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)):
            detached_keys.add(_surface_contact_snap_key(guide))
            continue
        if not infer_missing or guide not in active_guides:
            continue

        target, _normal, anchor = _surface_contact_world_point_normal(
            context,
            guide,
        )
        if target is None or anchor is None:
            continue
        tolerance = _surface_contact_settle_tolerance(guide)
        if (
            (Vector(target) - Vector(anchor)).length > tolerance
            and not _pin_points_within_snap_radius(
                context,
                target,
                anchor,
            )
        ):
            # Older files have no persistent latch. Their keyed guide and
            # endpoint poses still distinguish an engaged contact from a
            # deliberately moved endpoint, so migrate that state on load.
            _surface_contact_set_snap_detached(guide, True)
            changed = True
    return changed


def _surface_contact_pressure_supported_pose(
    context,
    guide,
    target=None,
    normal=None,
    anchor=None,
    depsgraph=None,
):
    """Recognize a saved far-end-supported roll without a runtime cache."""
    if target is None or normal is None or anchor is None:
        target, normal, anchor = _surface_contact_world_point_normal(
            context,
            guide,
            depsgraph,
        )
    opposite = _surface_contact_opposite_anchor_world(context, guide, depsgraph)
    if (
        target is None
        or normal is None
        or anchor is None
        or opposite is None
    ):
        return False
    plane_normal = Vector(normal)
    if plane_normal.length_squared <= 1.0e-12:
        return False
    plane_normal.normalize()
    target = Vector(target)
    anchor = Vector(anchor)
    opposite = Vector(opposite)
    tolerance = max(
        1.0e-6,
        _surface_contact_settle_tolerance(guide) * 4.0,
    )
    return bool(
        (anchor - target).length > PIN_SNAP_WORLD_RADIUS
        and (anchor - target).dot(plane_normal) >= -tolerance
        and abs((opposite - target).dot(plane_normal)) <= tolerance
    )


def _surface_contact_restore_loaded_snap_latches(context):
    """Recreate saved attachment latches after a blend file is evaluated."""
    scene = getattr(context, "scene", None) if context is not None else None
    if scene is None:
        return False
    latches = _state.setdefault("pin_snap_latches", set())
    detached_keys = _state.setdefault("pin_snap_detached", set())
    pressure_active = _state.setdefault("pin_snap_pressure_active", set())
    latches.clear()
    pressure_active.clear()
    for guide in _surface_contact_active_snap_guides(scene):
        key = _surface_contact_snap_key(guide)
        if bool(guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)):
            detached_keys.add(key)
            continue
        target, normal, anchor = _surface_contact_world_point_normal(
            context,
            guide,
        )
        if (
            target is not None
            and anchor is not None
            and (Vector(target) - Vector(anchor)).length
            <= PIN_SNAP_WORLD_RADIUS
        ):
            detached_keys.discard(key)
            latches.add(key)
        elif _surface_contact_pressure_supported_pose(
            context,
            guide,
            target,
            normal,
            anchor,
        ):
            detached_keys.discard(key)
            latches.add(key)
            pressure_active.add(key)
            _surface_contact_set_constraint_attachment(guide, False)
        else:
            # A saved False property cannot create a ring when the actual
            # pink endpoint is spatially separated from the target.
            detached_keys.add(key)
    return bool(latches)


def _surface_contact_recover_saved_attachments(context, guides=None):
    """Project saved attached Contacts back onto their targets after reload."""
    scene = getattr(context, "scene", None) if context is not None else None
    if scene is None:
        return False
    frame = int(scene.frame_current)
    latches = _state.setdefault("pin_snap_latches", set())
    previous_solver_guard = bool(_state.get("surface_contact_solver_syncing", False))
    _state["surface_contact_solver_syncing"] = True
    changed = False
    attached_guides = []
    try:
        for guide in tuple(
            guides if guides is not None
            else _surface_contact_active_snap_guides(scene)
        ):
            key = _surface_contact_snap_key(guide)
            if (
                bool(guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False))
                or _surface_contact_animated_detached_state(guide, frame) is True
            ):
                latches.discard(key)
                continue
            attached_guides.append(guide)
            # The persistent marker says this contact is attached. Re-solve
            # against the current target rather than reusing a saved
            # matrix_basis, which may have been evaluated back to a floating
            # action pose while Blender loaded or reinstalled the extension.
            # Keep the normal bounded iteration count: one pass can leave an
            # evaluated multi-bone chain at that raw pose after file load.
            changed = _surface_contact_enforce_guide(
                context,
                guide,
                force_contact=True,
                allow_snap=True,
                rotate_detached=False,
                rotate_snap=False,
            ) or changed
            latches.add(key)
    finally:
        _state["surface_contact_solver_syncing"] = previous_solver_guard
    if changed:
        context.view_layer.update()
    # Loading can schedule one last Action evaluation after the full solve.
    # Reapply the exact endpoint translation last, mirroring playback, so the
    # saved attached state and the visible bone pose cannot disagree.
    changed = (
        _surface_contact_playback_batch_settle(context, attached_guides)
        or changed
    )
    if changed:
        _tag_redraw_all_view3d()
    return changed


def _surface_contact_restore_saved_attachments(context):
    """Restore exact saved attached poses without recalculating rotation."""
    scene = getattr(context, "scene", None) if context is not None else None
    if scene is None:
        return False
    frame = int(scene.frame_current)
    saved = []
    missing = []
    for guide in _surface_contact_active_snap_guides(scene):
        if (
            bool(guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False))
            or _surface_contact_animated_detached_state(guide, frame) is True
        ):
            continue
        pose_bone = _surface_contact_simulated_pose_bone(guide)
        packed = (
            pose_bone.get(SURFACE_CONTACT_SAVED_POSE_PROPERTY)
            if pose_bone is not None
            else None
        ) or guide.get(SURFACE_CONTACT_SAVED_POSE_PROPERTY)
        if packed is not None and len(packed) == 16:
            saved.append(guide)
        else:
            missing.append(guide)
    changed = _surface_contact_restore_persistent_pose_snapshots(
        context,
        saved,
    )
    # Only legacy contacts lacking an exact saved pose need geometric
    # recovery. Current files and extension updates never recalculate one.
    if missing:
        changed = (
            _surface_contact_recover_saved_attachments(context, missing)
            or changed
        )
    return changed

def _surface_contact_clear_snap_departure(guide, preserve_latch=False):
    key = _surface_contact_snap_key(guide)
    if (
        guide.name
        in _state.get("pin_snap_parent_transform_guides", set())
        and not _state.get("pin_snap_parent_attachment_states", {}).get(
            guide.name,
            False,
        )
    ):
        # Magnetic aim may put detached dots close together during an
        # ancestor transform, but only a direct pink-bone edit may create a
        # new snap. Do not let a later depsgraph callback turn that preview
        # alignment into a latch.
        _surface_contact_set_snap_detached(guide, True)
        _state.setdefault("pin_snap_latches", set()).discard(key)
        return
    _state.setdefault("pin_snap_departing", set()).discard(key)
    _state.setdefault("pin_snap_release_anchor_origins", {}).pop(key, None)
    _surface_contact_set_snap_detached(guide, False)
    if not _state.get("pin_snap_transform_active", False):
        _state.setdefault("pin_snap_transform_seen", set()).discard(key)
    if not preserve_latch:
        # Clearing the free/departing state is an affirmative attachment
        # transition. Publish that semantic latch immediately; otherwise an
        # evaluated anchor gap before the next modal sample makes the contact
        # indistinguishable from a genuinely hovering limb.
        _state.setdefault("pin_snap_latches", set()).add(key)

def _surface_contact_snap_departure_active(
    context,
    guide,
    start_if_close = False,
):
    key = _surface_contact_snap_key(guide)
    if (_state.get('pin_snap_transform_active')
            and guide.name not in _state.get('pin_snap_direct_transform_guides',())
            and guide.name in _state.get('pin_snap_parent_attachment_states',{})):
        return not _state['pin_snap_parent_attachment_states'][guide.name]
    departing = _state.setdefault("pin_snap_departing", set())
    detached = _state.setdefault("pin_snap_detached", set())
    seen = _state.setdefault("pin_snap_transform_seen", set())
    if _pin_yellow_snap_active_for_contact(context, guide):
        detached.add(key)
        return True
    if key in _state.setdefault("pin_snap_transform_releasing", set()):
        return True
    animated_detached = _surface_contact_animated_detached_state(
        guide,
        int(context.scene.frame_current),
    )
    transform_departure_active = bool(
        key in departing
        or key in seen
        or _state.get("pin_snap_transform_active", False)
    )
    frame_state = _state.setdefault(
        "pin_snap_frame_animated_states",
        {},
    ).get(key)
    frame_state_frame = _state.setdefault(
        "pin_snap_frame_animated_state_frames",
        {},
    ).get(key)
    if (
        frame_state is not None
        and frame_state_frame == int(context.scene.frame_current)
        and not start_if_close
        and not transform_departure_active
    ):
        # A frame-boundary override fixes stale runtime state when scrubbing,
        # but manual transforms must remain authoritative once they begin.
        return bool(frame_state)
    if (
        animated_detached is not None
        and frame_state_frame is not None
        and frame_state_frame != int(context.scene.frame_current)
        and not start_if_close
        and not transform_departure_active
    ):
        # The F-curve is the authority outside a live pink-bone transform.
        # This must precede the mutable runtime/property latch: Blender can
        # evaluate the new frame before our frame handler refreshes those
        # transient values, otherwise a visited free frame contaminates an
        # attached key when scrubbing back to it.
        if animated_detached:
            detached.add(key)
            _state.setdefault("pin_snap_latches", set()).discard(key)
        else:
            detached.discard(key)
        return bool(animated_detached)
    if (
        (
            key in detached
            or bool(guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False))
        )
        and not _surface_contact_new_snap_allowed(context, guide)
    ):
        # Runtime/manual detach owns the current frame until the pink bone is
        # directly edited again. An older attached F-curve must not clear this
        # latch during a torso or unrelated-bone update.
        detached.add(key)
        _state.setdefault("pin_snap_latches", set()).discard(key)
        return True
    target, _normal, anchor = _surface_contact_world_point_normal(
        context,
        guide,
    )
    if target is None or anchor is None:
        return key in departing or key in detached

    if key in _state.setdefault("pin_snap_latches", set()):
        # The enforcement pass below owns hysteresis/release debounce. Do not
        # pre-detach the contact before it can confirm a deliberate pull-away.
        return False

    distance = (Vector(target) - Vector(anchor)).length
    swept_close = _pin_snap_sample_with_sweep(
        target,
        anchor,
        key,
        context=context,
    )
    if key in detached:
        if not _surface_contact_new_snap_allowed(context, guide):
            # Only a direct edit of this pink bone may enter Contact. Ancestor,
            # sibling, history, and idle dependency updates must preserve the
            # free pose even if evaluation temporarily places both dots inside
            # the magnetic radius.
            _state.setdefault("pin_snap_latches", set()).discard(key)
            return True
        tolerance = _surface_contact_settle_tolerance(guide)
        if (
            distance <= tolerance
            or swept_close
            or _pin_points_within_snap_radius(context, target, anchor)
        ):
            # A direct pink-bone edit may intentionally re-enter Contact.
            _state.setdefault("pin_snap_initial_detached", {})[key] = bool(
                animated_detached
                if animated_detached is not None
                else guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, True)
            )
            seen.add(key)
            # This direct edit supersedes any completed ancestor transform.
            # Leaving that old scope behind makes clear_snap_departure reject
            # the user's explicit re-entry and immediately restore detached.
            _state.setdefault(
                "pin_snap_parent_transform_guides", set()
            ).discard(guide.name)
            _state.setdefault(
                "pin_snap_parent_attachment_states", {}
            ).pop(guide.name, None)
            _surface_contact_clear_snap_departure(guide)
            _state.setdefault("pin_snap_transform_engaged", set()).add(key)
            return False
        return True
    if start_if_close and key not in seen:
        _state.setdefault("pin_snap_initial_detached", {})[key] = bool(
            animated_detached
            if animated_detached is not None
            else guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)
        )
        seen.add(key)
        if (
            distance <= 1.0e-7
            or swept_close
            or _pin_points_within_snap_radius(
                context,
                target,
                anchor,
                pixel_radius = PIN_SNAP_RELEASE_PIXEL_RADIUS,
            )
        ):
            departing.add(key)
        else:
            # A depsgraph callback may first observe a fast transform only
            # after the endpoint has already crossed the release ring. Treat
            # that first far sample as the same deliberate detach instead of
            # leaving a selection-change window that can force it back.
            _surface_contact_set_snap_detached(guide, True)

    if key in detached:
        return True

    if key not in departing:
        return False
    if distance <= 1.0e-7:
        return False
    if _pin_points_within_snap_radius(
        context,
        target,
        anchor,
        pixel_radius = PIN_SNAP_RELEASE_PIXEL_RADIUS,
    ):
        # Resolve magnetism live; native G/R/S can still pull beyond the ring.
        # Finalization then records the exact pose already shown to the user.
        return False

    # Leaving the wider release ring completes a deliberate detach. A later
    # direct sample inside the smaller entry ring can still reattach during
    # this transform; until then, keep the detached state across selection
    # changes so reconciliation cannot force the cached pose back.
    departing.discard(key)
    _surface_contact_set_snap_detached(guide, True)
    _state.setdefault("pin_snap_latches", set()).discard(key)
    return True

def _surface_contact_enforce_guide(
    context,
    guide,
    force_contact = False,
    insert_keys = False,
    use_snap_hysteresis = False,
    allow_snap = True,
    rotate_detached = False,
    collision_only = False,
    rotate_snap = True,
    allow_collision_roll = True,
    max_iterations = None,
):
    if guide.get(SURFACE_CONTACT_KIND_PROPERTY) == SURFACE_CONTACT_KIND_CHAIN:
        changed = _contact_chain_sync(context, guide)
        if changed:
            context.view_layer.update()
        if (_contact_chain_magnetic_active(context,guide)
                and _contact_chain_enabled(context,guide,_contact_chain_bones(guide))
                and _surface_contact_direct_magnetic_snap_close(context,guide)):
            attached_changed = _contact_chain_sync(context,guide)
            if attached_changed:
                context.view_layer.update()
            changed = attached_changed or changed
        return changed
    if not _surface_contact_has_valid_surface(guide):
        return _surface_contact_disable_missing_surface(guide)
    if _surface_contact_ragdoll_override(guide, context.scene.frame_current):
        return _surface_contact_set_constraint_attachment(guide, False)
    changed = _surface_contact_migrate_legacy_ik_guide(context, guide)
    target, normal, anchor = _surface_contact_world_point_normal(context, guide)
    if target is None or anchor is None or normal is None:
        return changed

    if (
        _surface_contact_snap_capable(guide)
        and not force_contact
        and not _surface_contact_new_snap_allowed(context, guide)
    ):
        allow_snap = False

    snap_close = False
    if not force_contact:
        snap_close = bool(
            allow_snap
            and _pin_snap_should_engage(
                context,
                _surface_contact_snap_key(guide),
                target,
                anchor,
                use_hysteresis = use_snap_hysteresis,
            )
        )
    contact_kind = str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
    detached_contact = bool(
        _surface_contact_snap_capable(guide)
        and not force_contact
        and not snap_close
    )
    changed = (
        _surface_contact_set_constraint_attachment(
            guide,
            bool(force_contact or snap_close),
        )
        or changed
    )
    pose_invalid = False
    if detached_contact:
        pose_invalid = _surface_contact_pose_is_invalid(
            context,
            guide,
            target,
            normal,
            anchor,
        )
        armature = bpy.data.objects.get(
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
        )
        pose_bone = (
            armature.pose.bones.get(
                str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
            )
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        start_world_rotation = (
            (armature.matrix_world @ pose_bone.matrix).to_quaternion()
            if armature is not None and pose_bone is not None
            else None
        )
        if (
            contact_kind == SURFACE_CONTACT_KIND_SIMULATED
            and rotate_detached
            and pose_bone is not None
            and _surface_contact_rotate_simulated_pose_toward(
                context,
                guide,
                armature,
                pose_bone,
                anchor,
                target,
            )
        ):
            changed = True
            target, normal, anchor = _surface_contact_world_point_normal(
                context,
                guide,
            )
            if target is None or anchor is None or normal is None:
                return changed

    if collision_only and not pose_invalid:
        # Collision-only is a guard, not a projection/magnet operation.  A
        # detached endpoint that is touching or still outside the surface is
        # already valid and must retain its inherited parent-transform pose.
        # Solving `desired` here translated it despite no penetration, which
        # looked exactly like an indirect snap.
        if contact_kind == SURFACE_CONTACT_KIND_SIMULATED:
            _surface_contact_store_valid_pose(guide)
        return changed

    collision_target = target
    collision_normal = normal
    if not force_contact and not snap_close:
        endpoint_surface = _surface_contact_bound_surface_point(
            context,
            guide,
            anchor,
        )
        if endpoint_surface is not None:
            collision_target, collision_normal = endpoint_surface

    desired = _surface_contact_endpoint_desired_point(
        guide,
        collision_target,
        collision_normal,
        anchor,
        force_contact = force_contact,
        snap_close = snap_close,
        opposite = _surface_contact_opposite_anchor_world(context, guide),
    )
    if detached_contact and pose_invalid and not collision_only:
        # Outside the entry radius this is collision, not magnetism. Sending
        # the corrected endpoint through the IK target solver can select its
        # mirrored solution and teleport a rolled limb underneath the plane
        # when the cursor reverses. The bounded collision resolver preserves
        # Blender's requested tangent motion and only corrects penetration.
        if contact_kind == SURFACE_CONTACT_KIND_SIMULATED:
            return _surface_contact_resolve_pose_collision(
                context,
                guide,
                target,
                normal,
                anchor,
                allow_planted_roll=allow_collision_roll,
            ) or changed
    if (
        collision_only
        and desired is None
        and pose_invalid
        and contact_kind == SURFACE_CONTACT_KIND_SIMULATED
    ):
        return _surface_contact_resolve_pose_collision(
            context,
            guide,
            target,
            normal,
            anchor,
            allow_planted_roll=allow_collision_roll,
        ) or changed
    if desired is None:
        if (
            detached_contact
            and contact_kind == SURFACE_CONTACT_KIND_SIMULATED
        ):
            _surface_contact_store_valid_pose(guide)
        return changed

    if contact_kind == SURFACE_CONTACT_KIND_SIMULATED:
        solver_kwargs = {}
        if max_iterations is not None:
            solver_kwargs["max_iterations"] = max(1, int(max_iterations))
        solved = _surface_contact_update_simulated_solver(
            context,
            guide,
            desired_point = desired,
            insert_keys = insert_keys,
            rotate_pose = bool(
                rotate_snap
                and (
                    force_contact
                    or snap_close
                    or (
                        pose_invalid
                        and not rotate_detached
                        and not collision_only
                    )
                )
            ),
            exact_target = bool(force_contact or snap_close),
            **solver_kwargs,
        )
        target, normal, anchor = _surface_contact_world_point_normal(
            context,
            guide,
        )
        collision_rollback = bool(
            target is not None
            and normal is not None
            and anchor is not None
            and _surface_contact_resolve_pose_collision(
                context,
                guide,
                target,
                normal,
                anchor,
                allow_planted_roll=allow_collision_roll,
            )
        )
        parallel_settle = bool(
            detached_contact
            and rotate_detached
            and not collision_only
            and start_world_rotation is not None
            and _surface_contact_settle_parallel_collision(
                context,
                guide,
                armature,
                pose_bone,
                start_world_rotation,
            )
        )
        return solved or collision_rollback or parallel_settle or changed
    if contact_kind == SURFACE_CONTACT_KIND_CONTROL:
        return _surface_contact_refine_control_solver(
            context,
            guide,
            desired_point = desired,
        ) or changed
    return _surface_contact_update_fallback_solver(context, guide) or changed


def _surface_contact_bound_surface_point(context, guide, candidate):
    """Project every non-ray target transform onto its bound mesh surface."""
    if not _contact_chain_uses_contact(guide):
        return Vector(candidate), guide.matrix_world.to_3x3().col[2].normalized()
    surface = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_SURFACE_PROPERTY, ""))
    )
    if (
        surface is None
        or surface in _surface_contact_linked_collision_objects(
            context,
            guide,
        )
    ):
        return None
    candidate = Vector(candidate)
    current = guide.matrix_world.translation.copy()
    reference_normal = _surface_contact_reference_normal(guide)
    depsgraph = context.evaluated_depsgraph_get()

    # Cast from the established outside toward the candidate. This selects
    # the contacted sheet first even if the mouse/transform candidate is deep
    # inside a thick mesh or already beyond its opposite face.
    try:
        evaluated_surface = surface.evaluated_get(depsgraph)
        projected_extent = max(
            abs(
                (
                    (evaluated_surface.matrix_world @ Vector(corner))
                    - candidate
                ).dot(reference_normal)
            )
            for corner in evaluated_surface.bound_box
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        projected_extent = (candidate - current).length
    cast_span = max(
        1.0,
        projected_extent + (candidate - current).length + 1.0,
    )
    hit = _surface_contact_object_ray_cast(
        surface,
        candidate + (reference_normal * cast_span),
        -reference_normal,
        cast_span * 2.0,
        depsgraph,
    )
    if hit is not None and Vector(hit[1]).dot(reference_normal) >= -1.0e-6:
        return hit[0], _surface_contact_align_surface_normal(
            guide,
            hit[1],
            reference_normal,
        )

    # Open/concave meshes may not intersect that ray. Clamp an inward request
    # to the previous tangent sheet before the closest-point fallback, and
    # reject any opposite-facing result rather than jumping to the underside.
    safe_candidate = candidate.copy()
    inward_distance = (safe_candidate - current).dot(reference_normal)
    if inward_distance < 0.0:
        safe_candidate -= reference_normal * inward_distance
    closest = _surface_contact_closest_point(
        surface,
        safe_candidate,
        depsgraph,
        max(1.0, (safe_candidate - current).length * 4.0),
    )
    if closest is None:
        return None
    if Vector(closest[1]).dot(reference_normal) < -1.0e-6:
        return current, reference_normal
    return closest[0], _surface_contact_align_surface_normal(
        guide,
        closest[1],
        reference_normal,
    )


def _surface_contact_solve_target(
    context,
    guide,
    solver_matrix = None,
    max_iterations = SURFACE_CONTACT_FINAL_SOLVER_ITERATIONS, rotate_pose = True,
):
    """Settle the driven endpoint to the guide's authoritative target."""
    previous_guard = bool(_state.get("surface_contact_solver_syncing", False))
    _state["surface_contact_solver_syncing"] = True
    try:
        return _surface_contact_solve_target_guarded(
            context,
            guide,
            solver_matrix = solver_matrix,
            max_iterations = max_iterations,
            rotate_pose = rotate_pose,
        )
    finally:
        _state["surface_contact_solver_syncing"] = previous_guard


def _surface_contact_solve_target_guarded(
    context,
    guide,
    solver_matrix = None,
    max_iterations = SURFACE_CONTACT_FINAL_SOLVER_ITERATIONS, rotate_pose = True,
):
    solver = _surface_contact_solver_from_guide(guide)
    contact_kind = str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
    target = guide.matrix_world.translation.copy()
    if contact_kind == SURFACE_CONTACT_KIND_CHAIN:
        changed = _contact_chain_sync(context, guide)
    elif contact_kind == SURFACE_CONTACT_KIND_SIMULATED:
        changed = _surface_contact_update_simulated_solver(
            context,
            guide,
            desired_point = target,
            max_iterations = max_iterations,
            rotate_pose = rotate_pose,
            exact_target = True,
        )
    elif contact_kind == SURFACE_CONTACT_KIND_IK:
        changed = _surface_contact_update_fallback_solver(context, guide)
    else:
        changed = False
        if solver is not None and solver_matrix is not None:
            if any(
                abs(
                    float(solver.matrix_world[row][column])
                    - float(solver_matrix[row][column])
                ) > 1.0e-7
                for row in range(4)
                for column in range(4)
            ):
                solver.matrix_world = solver_matrix.copy()
                context.view_layer.update()
                changed = True
        elif solver is not None:
            changed = _surface_contact_update_control_solver(guide) or changed
            if changed:
                context.view_layer.update()
        changed = _surface_contact_refine_control_solver(
            context,
            guide,
            desired_point = target,
            max_iterations = max_iterations,
        ) or changed
    context.view_layer.update()
    return changed


def _surface_contact_move_guide_to_surface(
    context,
    guide,
    point,
    normal,
    keep_attached = None,
    max_iterations = SURFACE_CONTACT_FINAL_SOLVER_ITERATIONS,
    sweep_collision = True,
):
    frame = int(context.scene.frame_current)
    if _surface_contact_ragdoll_override(guide, frame):
        return False
    owner = bpy.data.objects.get(str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, "")))
    bone = owner.pose.bones.get(str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))) if owner and owner.pose else None
    editing_start = (bone is not None and _ragdoll_active(bone, frame)
                     and _ragdoll_active_start_frame(owner, bone, frame) == frame)
    previous_guard = bool(_state.get("surface_contact_solver_syncing", False))
    previous_ragdoll = bool(_state.get("ragdoll_syncing", False))
    _state["surface_contact_solver_syncing"] = True
    if editing_start:
        _state["ragdoll_syncing"] = True
    try:
        moved = _surface_contact_move_guide_to_surface_guarded(
            context, guide, point, normal,
            keep_attached=keep_attached,
            max_iterations=max_iterations,
            sweep_collision=sweep_collision,
        )
        if moved and editing_start:
            context.view_layer.update()
            if _surface_contact_attached_at_frame(guide, frame):
                _surface_contact_playback_batch_settle(context, (guide,))
                context.view_layer.update()
            _ragdoll_capture_start_edits(context, contact_bone=bone)
        return moved
    finally:
        _state["surface_contact_solver_syncing"] = previous_guard
        _state["ragdoll_syncing"] = previous_ragdoll



def _surface_contact_move_guide_to_surface_guarded(
    context,
    guide,
    point,
    normal,
    keep_attached = None,
    max_iterations = SURFACE_CONTACT_FINAL_SOLVER_ITERATIONS,
    sweep_collision = True,
):
    if guide.get(SURFACE_CONTACT_KIND_PROPERTY) == SURFACE_CONTACT_KIND_CHAIN:
        # Free mouse dragging must use the same FK-independent publication
        # as axis/keyboard dragging. The single-rod detached aim below writes
        # the effector basis, feeding solved output back into the next sample.
        if keep_attached is None:
            keep_attached = _pin_contact_is_attached(context, guide)
        desired = _surface_contact_plane_matrix(Vector(point), Vector(normal), guide.matrix_world)
        return _contact_chain_apply_target_matrix(context, guide, desired, keep_attached)
    # Direct target dragging is the one operation that intentionally turns
    # the limb from its saved opposite/imaginary rod endpoint toward the new
    # pin-facing target. Indirect parent/torso motion must retain the limb's
    # authored orientation offset instead of re-aiming it at every sample.
    rotate_pose = bool(
        _state.get("pin_target_dragging", False)
        or not _surface_contact_preserves_rigid_orientation(guide)
    )
    reachable_target = _surface_contact_project_reachable_target(
        context,
        guide,
        point,
        normal,
    )
    if reachable_target is None:
        return False
    previous_guide_world = guide.matrix_world.copy()
    simulated = (
        str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
        == SURFACE_CONTACT_KIND_SIMULATED
    )
    if keep_attached is None:
        # Saved attachment owns the interaction. A pressure pose may lift
        # the endpoint, so proximity alone cannot decide to detach it.
        keep_attached = _pin_contact_is_attached(context, guide)
    if simulated:
        reachable_target = (
            _surface_contact_clamp_drag_target(
                context,
                guide,
                previous_guide_world.translation,
                reachable_target[0],
                sweep_collision=sweep_collision,
                keep_attached=bool(keep_attached),
            ),
            reachable_target[1],
        )
    if (
        str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
        == SURFACE_CONTACT_KIND_CONTROL
        and SURFACE_CONTACT_SOLVER_LOCAL_MATRIX_PROPERTY not in guide
    ):
        _surface_contact_store_solver_local_matrix(guide)
    previous_normal = previous_guide_world.to_3x3().col[2]
    next_normal = Vector(reachable_target[1])
    if previous_normal.length_squared > 1.0e-12:
        previous_normal.normalize()
    if next_normal.length_squared > 1.0e-12:
        next_normal.normalize()
    point_changed = (
        Vector(reachable_target[0]) - previous_guide_world.translation
    ).length > 1.0e-5
    normal_changed = (
        previous_normal.length_squared > 1.0e-12
        and next_normal.length_squared > 1.0e-12
        and previous_normal.dot(next_normal) < (1.0 - 1.0e-6)
    )
    if not point_changed and not normal_changed:
        if keep_attached:
            return _surface_contact_solve_target(
                context,
                guide,
                max_iterations = max_iterations,
                rotate_pose = rotate_pose,
            )
        smart_changed = _surface_contact_settle_detached_smart(context, guide)
        if smart_changed is not None:
            return smart_changed
        return _surface_contact_enforce_guide(
            context,
            guide,
            force_contact = False,
            allow_snap = False,
            rotate_detached = rotate_pose,
            rotate_snap = rotate_pose,
        )
    if not _surface_contact_set_guide_surface_point(
        context,
        guide,
        reachable_target[0],
        reachable_target[1],
    ):
        return False

    if keep_attached:
        _surface_contact_clear_snap_departure(guide)
        _surface_contact_solve_target(
            context,
            guide,
            max_iterations = max_iterations,
            rotate_pose = rotate_pose,
        )
    else:
        _surface_contact_set_snap_detached(guide, True)
        if _surface_contact_settle_detached_smart(context, guide) is None:
            _surface_contact_enforce_guide(
                context,
                guide,
                force_contact = False,
                allow_snap = False,
                rotate_detached = rotate_pose,
                rotate_snap = rotate_pose,
            )
    _tag_redraw_all_view3d()
    return True


def _surface_contact_move_guide_world(
    context,
    guide,
    point,
    keep_attached = None,
    max_iterations = SURFACE_CONTACT_FINAL_SOLVER_ITERATIONS,
):
    """Move a Contact target while remaining exactly on its bound surface."""
    if not _contact_chain_uses_contact(guide):
        matrix = guide.matrix_world.copy()
        matrix.translation = Vector(point)
        return _contact_chain_apply_target_matrix(context, guide, matrix, True)
    projected = _surface_contact_bound_surface_point(context, guide, point)
    if projected is None:
        return False
    return _surface_contact_move_guide_to_surface(
        context,
        guide,
        projected[0],
        projected[1],
        keep_attached = keep_attached,
        max_iterations = max_iterations,
    )


def _surface_contact_mouse_surface_point(context, guide, mouse_position):
    if not _contact_chain_uses_contact(guide):
        return None
    region = getattr(context, "region", None)
    region_data = getattr(context, "region_data", None)
    if region is None or region_data is None or guide is None:
        return None

    from bpy_extras import view3d_utils

    mouse = Vector(mouse_position)
    origin = view3d_utils.region_2d_to_origin_3d(region, region_data, mouse)
    direction = view3d_utils.region_2d_to_vector_3d(region, region_data, mouse)
    hit = _surface_contact_ray_cast(
        context,
        origin,
        direction,
        1000000.0,
        _surface_contact_linked_collision_objects(context, guide),
    )
    if hit is None:
        return None
    surface, world_point, world_normal, _distance = hit
    return surface, world_point, world_normal
