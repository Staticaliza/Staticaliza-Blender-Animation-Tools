"""Surface-contact detection, solver state, constraints, and operators."""

from ..core.runtime import *  # noqa: F403


def _surface_contact_settle_tolerance(guide):
    """Shared evaluated-pose tolerance for a settled simulated contact."""
    return max(
        1.0e-5,
        float(guide.get(SURFACE_CONTACT_SIZE_PROPERTY, 0.05)) * 1.0e-4,
    )


def _surface_contact_guides_for_effector(armature, effector):
    if armature is None or effector is None:
        return ()
    key = (
        int(_state.get("surface_contact_guide_cache_generation", 0)),
        str(armature.name),
        str(effector.name),
    )
    cache = _state.setdefault("surface_contact_effector_guide_cache", {})
    cached = cache.get(key)
    if cached is not None:
        return tuple(cached)
    guides = tuple(
        guide
        for guide in _surface_contact_guides()
        if (
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
            == key[1]
            and str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
            == key[2]
        )
    )
    cache[key] = guides
    return guides



def _surface_contact_retarget_plan(armature, effector, frame):
    frame = int(frame)
    guides = tuple(
        sorted(
            _surface_contact_guides_for_effector(armature, effector),
            key = lambda guide: int(
                guide.get(SURFACE_CONTACT_START_PROPERTY, SPACE_MIN_FRAME)
            ),
        )
    )
    exact = tuple(
        guide
        for guide in guides
        if int(guide.get(SURFACE_CONTACT_START_PROPERTY, SPACE_MIN_FRAME))
        == frame
    )
    active = tuple(
        guide
        for guide in guides
        if guide not in exact and _surface_contact_guide_active_at(guide, frame)
    )
    previous = active[-1] if active else None
    carried_end = None
    source = exact[-1] if exact else previous
    if source is not None and SURFACE_CONTACT_END_PROPERTY in source:
        carried_end = int(source[SURFACE_CONTACT_END_PROPERTY])
    if carried_end is None:
        future_starts = [
            int(guide.get(SURFACE_CONTACT_START_PROPERTY, SPACE_MIN_FRAME))
            for guide in guides
            if guide not in exact
            and int(guide.get(SURFACE_CONTACT_START_PROPERTY, SPACE_MIN_FRAME))
            > frame
        ]
        carried_end = min(future_starts) if future_starts else None
    return exact, previous, carried_end


def _surface_contact_suspend_guides(guides):
    suspended = []
    for guide in guides:
        for constraint in _surface_contact_constraints(guide):
            if constraint is None:
                continue
            suspended.append((constraint, float(constraint.influence)))
            constraint.influence = 0.0
    try:
        bpy.context.view_layer.update()
    except (AttributeError, RuntimeError):
        pass
    return tuple(suspended)


def _surface_contact_restore_suspended(suspended):
    for constraint, influence in suspended:
        try:
            constraint.influence = float(influence)
        except (AttributeError, ReferenceError):
            pass
    try:
        bpy.context.view_layer.update()
    except (AttributeError, RuntimeError):
        pass


def _surface_contact_ragdoll_override(guide, frame):
    """Orange owns this bone while its authored ragdoll interval is enabled."""
    armature = bpy.data.objects.get(str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, "")))
    if armature is None or armature.type != "ARMATURE" or armature.pose is None:
        return False
    bone = armature.pose.bones.get(str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, "")))
    return bone is not None and _ragdoll_active(bone, int(frame))


def _surface_contact_guide_active_at(guide, frame):
    return (_surface_contact_guide_interval_active_at(guide, frame)
            and not _surface_contact_ragdoll_override(guide, frame))


def _surface_contact_guide_interval_active_at(guide, frame):
    try:
        start = int(guide[SURFACE_CONTACT_START_PROPERTY])
    except (KeyError, TypeError, ValueError):
        return False
    if int(frame) < start:
        return False
    if SURFACE_CONTACT_END_PROPERTY not in guide:
        return True
    try:
        # The authored End key is the final contact frame. A replacement
        # starting on that same frame takes ownership of the shared boundary.
        end = int(guide[SURFACE_CONTACT_END_PROPERTY])
        if int(frame) != end:
            return int(frame) < end
        return not any(
            other != guide
            and int(other.get(SURFACE_CONTACT_START_PROPERTY, SPACE_MIN_FRAME)) == end
            and str(other.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
            == str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
            and str(other.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
            == str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
            for other in _surface_contact_guides()
        )
    except (TypeError, ValueError):
        return True


def _surface_contact_guide_is_open(guide):
    return SURFACE_CONTACT_END_PROPERTY not in guide


def _surface_contact_selected_guides(
    context,
    active_only = False,
    open_only = False,
):
    frame = int(context.scene.frame_current)
    selected_pin_guides = []
    seen = set()
    try:
        for _key, target_data in _pin_selected_targets_data(context):
            if target_data[0] != "CONTACT":
                continue
            guide = target_data[3]
            if guide.name in seen:
                continue
            if (
                active_only
                and not _surface_contact_guide_active_at(guide, frame)
            ):
                continue
            if open_only and not _surface_contact_guide_is_open(guide):
                continue
            seen.add(guide.name)
            selected_pin_guides.append(guide)
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        pass
    selected_guides = list(selected_pin_guides)
    for armature, pose_bones in _selected_pose_bones_by_owner(
        context
    ).items():
        for selected_bone in pose_bones:
            related_names = {selected_bone.name}
            relation = _surface_contact_ik_relation(
                armature,
                selected_bone,
            )
            if relation is not None:
                related_names.add(relation["effector"].name)
            matches = []
            for guide in _surface_contact_guides():
                if (
                    str(guide.get(
                        SURFACE_CONTACT_ARMATURE_PROPERTY,
                        "",
                    ))
                    != armature.name
                    or not (
                        _surface_contact_related_bone_names(guide)
                        & related_names
                    )
                ):
                    continue
                if (
                    active_only
                    and not _surface_contact_guide_active_at(guide, frame)
                ):
                    continue
                if open_only and not _surface_contact_guide_is_open(guide):
                    continue
                matches.append(guide)
            if not matches:
                continue
            guide = max(
                matches,
                key = lambda item: int(
                    item.get(
                        SURFACE_CONTACT_START_PROPERTY,
                        -1048574,
                    )
                ),
            )
            if guide.name not in seen:
                seen.add(guide.name)
                selected_guides.append(guide)
    return tuple(selected_guides)


def _surface_contact_selected_guide(
    context,
    active_only = False,
    open_only = False,
):
    guides = _surface_contact_selected_guides(
        context,
        active_only = active_only,
        open_only = open_only,
    )
    return guides[0] if guides else None


def _surface_contact_chain(ending_bone, chain_count):
    if ending_bone is None:
        return ()
    chain = [ending_bone]
    current = ending_bone.parent
    if int(chain_count) <= 0:
        while current is not None:
            chain.append(current)
            current = current.parent
        return tuple(chain)
    while current is not None and len(chain) < int(chain_count):
        chain.append(current)
        current = current.parent
    return tuple(chain)


def _surface_contact_ik_relation(armature, selected_bone):
    if armature is None or selected_bone is None:
        return None

    candidates = []
    for constrained_bone in armature.pose.bones:
        for constraint in constrained_bone.constraints:
            if (
                constraint.type != "IK"
                or constraint.target is None
                or bool(getattr(constraint, "mute", False))
                or float(getattr(constraint, "influence", 1.0)) <= 1.0e-6
            ):
                continue
            chain = _surface_contact_chain(
                constrained_bone,
                int(getattr(constraint, "chain_count", 0)),
            )
            target_object = constraint.target
            target_bone = None
            if constraint.subtarget and getattr(target_object, "pose", None):
                target_bone = target_object.pose.bones.get(constraint.subtarget)
                if target_bone is None:
                    continue

            score = None
            if selected_bone == constrained_bone:
                score = 0
            elif (
                target_bone is not None
                and target_object == armature
                and selected_bone.name == target_bone.name
            ):
                score = 1
            elif selected_bone in chain:
                score = 2 + chain.index(selected_bone)
            else:
                for selected_constraint in selected_bone.constraints:
                    if (
                        selected_constraint.type in {"COPY_LOCATION", "COPY_ROTATION", "COPY_TRANSFORMS"}
                        and selected_constraint.target == target_object
                        and str(selected_constraint.subtarget) == str(constraint.subtarget)
                    ):
                        score = 1
                        break
            if score is None:
                continue
            candidates.append(
                (
                    score,
                    {
                        "constraint": constraint,
                        "effector": constrained_bone,
                        "chain": chain,
                        "target_object": target_object,
                        "target_bone": target_bone,
                    },
                )
            )

    if not candidates:
        return None
    candidates.sort(key = lambda item: item[0])
    return candidates[0][1]


def _surface_contact_rig_objects(armature):
    objects = {armature}
    for obj in bpy.data.objects:
        if obj == armature or obj.parent == armature:
            objects.add(obj)
            continue
        try:
            if obj.find_armature() == armature:
                objects.add(obj)
                continue
        except (AttributeError, RuntimeError):
            pass
        if any(
            getattr(constraint, "target", None) == armature
            for constraint in getattr(obj, "constraints", ())
        ):
            objects.add(obj)
    return objects


def _surface_contact_object_visible(context, obj):
    if obj is None or bool(getattr(obj, "hide_viewport", False)):
        return False
    try:
        if obj.hide_get(view_layer = context.view_layer):
            return False
    except TypeError:
        if obj.hide_get():
            return False
    except (AttributeError, ReferenceError, RuntimeError):
        return False
    try:
        return bool(obj.visible_get(view_layer = context.view_layer))
    except TypeError:
        try:
            return bool(obj.visible_get())
        except (AttributeError, ReferenceError, RuntimeError):
            return True
    except (AttributeError, ReferenceError, RuntimeError):
        return True


def _surface_contact_ray_cast(context, origin, direction, distance, excluded):
    if direction.length_squared <= 1.0e-12:
        return None
    direction = direction.normalized()
    depsgraph = context.evaluated_depsgraph_get()
    remaining = float(distance)
    cast_origin = origin.copy()
    travelled = 0.0
    # View rays can be a million units long. Scaling the skip by total ray
    # length jumped ten units past a floor after ignoring the linked limb.
    epsilon = max(1.0e-5, min(1.0e-3, float(distance) * 1.0e-7))

    for _attempt in range(16):
        hit, location, normal, _face, hit_object, _matrix = context.scene.ray_cast(
            depsgraph,
            cast_origin,
            direction,
            distance = remaining,
        )
        if not hit or hit_object is None:
            return None
        original_object = getattr(hit_object, "original", hit_object)
        segment = max(0.0, float((location - cast_origin).dot(direction)))
        travelled += segment
        if (
            original_object not in excluded
            and _surface_contact_object_visible(context, original_object)
            and not bool(original_object.get(SURFACE_CONTACT_GUIDE_PROPERTY, False))
        ):
            return (
                original_object,
                location.copy(),
                normal.normalized(),
                travelled,
            )
        advance = segment + epsilon
        remaining -= advance
        if remaining <= epsilon:
            return None
        cast_origin = cast_origin + (direction * advance)
        travelled += epsilon
    return None


def _surface_contact_closest_point(surface, world_point, depsgraph, distance):
    evaluated_surface = surface.evaluated_get(depsgraph)
    local_point = evaluated_surface.matrix_world.inverted_safe() @ world_point
    try:
        hit, point, normal, _face = evaluated_surface.closest_point_on_mesh(
            local_point,
            distance = float(distance),
            depsgraph = depsgraph,
        )
    except TypeError:
        hit, point, normal, _face = evaluated_surface.closest_point_on_mesh(
            local_point,
            distance = float(distance),
        )
    if not hit:
        return None
    point = evaluated_surface.matrix_world @ point
    normal = (
        evaluated_surface.matrix_world.to_3x3().inverted_safe().transposed()
        @ normal
    )
    if normal.length_squared <= 1.0e-12:
        return None
    normal.normalize()
    return point, normal


def _surface_contact_object_ray_cast(
    surface,
    world_origin,
    world_direction,
    world_distance,
    depsgraph,
):
    """Ray-cast one evaluated mesh without other scene objects occluding it."""
    if surface is None or world_direction.length_squared <= 1.0e-12:
        return None
    evaluated_surface = surface.evaluated_get(depsgraph)
    inverse = evaluated_surface.matrix_world.inverted_safe()
    world_direction = Vector(world_direction).normalized()
    world_origin = Vector(world_origin)
    world_end = world_origin + (world_direction * float(world_distance))
    local_origin = inverse @ world_origin
    local_vector = (inverse @ world_end) - local_origin
    local_distance = local_vector.length
    if local_distance <= 1.0e-12:
        return None
    local_direction = local_vector / local_distance
    try:
        hit, point, normal, _face = evaluated_surface.ray_cast(
            local_origin,
            local_direction,
            distance = local_distance,
            depsgraph = depsgraph,
        )
    except TypeError:
        hit, point, normal, _face = evaluated_surface.ray_cast(
            local_origin,
            local_direction,
            distance = local_distance,
        )
    if not hit:
        return None
    point = evaluated_surface.matrix_world @ point
    normal = (
        evaluated_surface.matrix_world.to_3x3().inverted_safe().transposed()
        @ normal
    )
    if normal.length_squared <= 1.0e-12:
        return None
    normal.normalize()
    return point, normal


def _surface_contact_reference_normal(guide):
    """Return the established allowed side of a Contact surface."""
    try:
        guide_normal = guide.matrix_world.to_3x3().col[2].copy()
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        guide_normal = Vector((0.0, 0.0, 1.0))
    if guide_normal.length_squared > 1.0e-12:
        guide_normal.normalize()
    else:
        guide_normal = Vector((0.0, 0.0, 1.0))

    transforming = any(
        bool(_state.get(state_name, False))
        for state_name in (
            "pin_target_dragging",
            "pin_keyboard_transform_active",
            "pin_snap_transform_active",
        )
    )
    if not transforming:
        # During playback the evaluated guide rotation is authoritative. This
        # follows curved and armature-deformed surfaces frame by frame.
        return guide_normal

    try:
        follow_object = bpy.data.objects.get(
            str(guide.get(SURFACE_CONTACT_FOLLOW_OBJECT_PROPERTY, ""))
        )
        follow_bone = str(guide.get(SURFACE_CONTACT_FOLLOW_BONE_PROPERTY, ""))
        local_values = guide.get(SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY)
        if (
            follow_object is not None
            and local_values is not None
            and len(local_values) >= 16
        ):
            depsgraph = bpy.context.evaluated_depsgraph_get()
            evaluated_follow = follow_object.evaluated_get(depsgraph)
            follow_world = evaluated_follow.matrix_world.copy()
            if follow_bone and getattr(evaluated_follow, "pose", None):
                evaluated_bone = evaluated_follow.pose.bones.get(follow_bone)
                if evaluated_bone is not None:
                    follow_world = follow_world @ evaluated_bone.matrix
            local_matrix = Matrix(
                tuple(
                    tuple(
                        float(local_values[(row * 4) + column])
                        for column in range(4)
                    )
                    for row in range(4)
                )
            )
            normal = (follow_world @ local_matrix).to_3x3().col[2]
            if normal.length_squared > 1.0e-12:
                normal.normalize()
                return normal
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        pass

    try:
        surface = bpy.data.objects.get(
            str(guide.get(SURFACE_CONTACT_SURFACE_PROPERTY, ""))
        )
        stored_normal = guide.get(SURFACE_CONTACT_NORMAL_PROPERTY)
        if (
            surface is not None
            and stored_normal is not None
            and len(stored_normal) >= 3
        ):
            normal = (
                surface.matrix_world.to_3x3().inverted_safe().transposed()
                @ Vector(tuple(float(value) for value in stored_normal[:3]))
            )
            if normal.length_squared > 1.0e-12:
                normal.normalize()
                return normal
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        pass
    return guide_normal


def _surface_contact_align_surface_normal(guide, normal, reference = None):
    """Keep surface normals continuous instead of following a crossing limb."""
    normal = Vector(normal)
    if normal.length_squared <= 1.0e-12:
        return _surface_contact_reference_normal(guide)
    normal.normalize()
    reference = (
        Vector(reference)
        if reference is not None
        else _surface_contact_reference_normal(guide)
    )
    if reference.length_squared > 1.0e-12:
        reference.normalize()
        if normal.dot(reference) < 0.0:
            normal.negate()
    return normal


def _surface_contact_endpoint_desired_point(
    guide,
    target,
    normal,
    anchor,
    force_contact = False,
    snap_close = False,
    opposite = None,
):
    """Resolve magnetism and one-sided collision without blocking separation."""
    target = Vector(target)
    normal = Vector(normal)
    anchor = Vector(anchor)
    if force_contact or snap_close:
        return target
    penetration_tolerance = max(
        1.0e-6,
        float(guide.get(SURFACE_CONTACT_SIZE_PROPERTY, 0.05)) * 1.0e-5,
    )
    signed_distance = (anchor - target).dot(normal)
    if opposite is not None:
        signed_distance = min(
            signed_distance,
            (Vector(opposite) - target).dot(normal),
        )
    if signed_distance < -penetration_tolerance:
        # Remove only the inward component. Tangential motion and motion away
        # from the surface remain completely free while detached.
        return anchor - (normal * signed_distance)
    return None


def _surface_contact_bone_family_names(evaluated_armature, pose_bone):
    names = set().union(
        *_pose_bone_numeric_family_levels(evaluated_armature, pose_bone)
    )
    pending = [
        evaluated_armature.pose.bones.get(name)
        for name in tuple(names)
    ]
    while pending:
        parent = pending.pop()
        if parent is None:
            continue
        for child in parent.children:
            source_armature = getattr(
                evaluated_armature,
                "original",
                evaluated_armature,
            )
            source_bone = source_armature.data.bones.get(child.name)
            joint_type = str(
                source_bone.get("rbx_joint_type", "")
                if source_bone is not None
                else ""
            )
            if joint_type not in {"Weld", "WeldConstraint"}:
                continue
            if child.name in names:
                continue
            names.add(child.name)
            pending.append(child)
    return names


def _surface_contact_object_bone_names(obj, armature):
    names = set()
    if (
        obj.parent == armature
        and obj.parent_type == "BONE"
        and getattr(obj, "parent_bone", "")
    ):
        names.add(str(obj.parent_bone))
    for constraint in getattr(obj, "constraints", ()):
        if (
            getattr(constraint, "target", None) == armature
            and getattr(constraint, "subtarget", "")
        ):
            names.add(str(constraint.subtarget))

    uses_armature = False
    try:
        uses_armature = obj.find_armature() == armature
    except (AttributeError, ReferenceError, RuntimeError):
        pass
    if not uses_armature:
        uses_armature = any(
            modifier.type == "ARMATURE"
            and getattr(modifier, "object", None) == armature
            for modifier in getattr(obj, "modifiers", ())
        )
    if uses_armature:
        names.update(group.name for group in getattr(obj, "vertex_groups", ()))
    return names


def _surface_contact_connected_objects(context, armature, family_names):
    visible_objects = tuple(
        obj
        for obj in context.view_layer.objects
        if obj != armature and _surface_contact_object_visible(context, obj)
    )
    connected = {
        obj
        for obj in visible_objects
        if _surface_contact_object_bone_names(obj, armature) & family_names
    }
    if not connected:
        return ()

    # Include visible layers and accessories parented or constrained outward
    # from a directly bone-bound part, without walking upstream into the rig.
    for _depth in range(16):
        additions = set()
        for obj in visible_objects:
            if obj in connected:
                continue
            if obj.parent in connected:
                additions.add(obj)
                continue
            if any(
                getattr(constraint, "target", None) in connected
                for constraint in getattr(obj, "constraints", ())
            ):
                additions.add(obj)
        if not additions:
            break
        connected.update(additions)
    return tuple(connected)


def _surface_contact_linked_collision_objects(context, guide):
    """Objects driven by the contacted bone that a pink target must ignore."""

    excluded = set()
    armature = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
    )
    if armature is None or getattr(armature, "pose", None) is None:
        return excluded
    excluded.add(armature)
    bone_name = str(
        guide.get(
            SURFACE_CONTACT_GEOMETRY_BONE_PROPERTY,
            guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""),
        )
    )
    try:
        evaluated_armature = armature.evaluated_get(
            context.evaluated_depsgraph_get()
        )
        evaluated_bone = evaluated_armature.pose.bones.get(bone_name)
        if evaluated_bone is None:
            return excluded
        family_names = _surface_contact_bone_family_names(
            evaluated_armature,
            evaluated_bone,
        )
        excluded.update(
            _surface_contact_connected_objects(
                context,
                armature,
                family_names,
            )
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        pass
    return excluded
