"""Switch the same Contact chain between a surface target and free IK."""

from ..core.runtime import *  # noqa: F403
from .chains import _contact_settings_properties


def _contact_chain_reset_targets(context,grouped):
    """The main controller owns its active component; drivers stay local."""
    selected={owner.name:{b.name for b in bones} for owner,bones in grouped.items()}
    expanded={owner:{b.name:b for b in bones} for owner,bones in grouped.items()}
    for guide in _surface_contact_guides():
        if (guide.get(SURFACE_CONTACT_KIND_PROPERTY)!=SURFACE_CONTACT_KIND_CHAIN
                or not _surface_contact_guide_active_at(guide,context.scene.frame_current)):continue
        owner,bone=_surface_contact_pose_bone(guide)
        if bone is None or bone.name not in selected.get(owner.name,()):continue
        expanded.setdefault(owner,{}).update((b.name,b) for b in _contact_chain_bones(guide))
    return {owner:tuple(sorted(bones.values(),key=lambda b:len(b.parent_recursive)))
            for owner,bones in expanded.items()}


def _contact_chain_clear_reset_channels(grouped,mode):
    for _owner,bones in grouped.items():
        for bone in bones:
            if mode=='LOCATION':bone.location=(0.,0.,0.)
            elif mode=='SCALE':bone.scale=(1.,1.,1.)
            elif bone.rotation_mode=='QUATERNION':bone.rotation_quaternion=(1.,0.,0.,0.)
            elif bone.rotation_mode=='AXIS_ANGLE':bone.rotation_axis_angle=(0.,0.,1.,0.)
            else:bone.rotation_euler=(0.,0.,0.)


def _contact_chain_reset_begin(context, grouped):
    selected = {owner.name: {b.name for b in bones} for owner, bones in grouped.items()}
    guides = []
    for guide in _surface_contact_guides():
        if not _surface_contact_guide_active_at(guide, context.scene.frame_current):
            continue
        owner, bone = _surface_contact_pose_bone(guide)
        if bone is None:continue
        names = selected.get(owner.name, set())
        affected = _surface_contact_related_bone_names(guide) | {b.name for b in bone.parent_recursive}
        if not names.intersection(affected):
            continue
        _contact_chain_prepare_reset(context,guide)
        if guide.get(SURFACE_CONTACT_KIND_PROPERTY)!=SURFACE_CONTACT_KIND_CHAIN:continue
        guides.append(guide.name)
        for member in _contact_chain_bones(guide):
            _surface_contact_remove_history_pose_lock(owner.name, member.name)
        _state.setdefault('contact_idle_confirmed_poses', {}).pop(guide.name, None)
        _state.setdefault('contact_chain_solutions', {}).pop(guide.name, None)
    return guides


def _contact_chain_prepare_reset(context,guide):
    """Give a legacy single rod the same input/output boundary as a chain.

    This is explicit setup inside the undo transaction. The old single-rod
    path wrote its magnetic/collision output directly over the cleared FK
    channels; the next reset then inherited that correction as fresh input.
    """
    if guide.get(SURFACE_CONTACT_KIND_PROPERTY)!=SURFACE_CONTACT_KIND_SIMULATED:return
    owner,_bone=_surface_contact_pose_bone(guide)
    bases=_pin_capture_action_pose_bases((owner,))
    pending=guide.matrix_basis.copy()
    guide['Contact Authored Pose']=True
    guide['Contact Pose Reference']=(*guide.matrix_world.translation,float(guide.get(CONTACT_CHAIN_BEND,0.)))
    _contact_chain_configure(context,guide,1)
    _pin_restore_action_pose_bases(context,bases)
    guide.matrix_basis=pending


def _contact_chain_reset_finish(context, names):
    guides=sorted((bpy.data.objects[name] for name in names if name in bpy.data.objects),
                  key=lambda guide:len(_contact_chain_bones(guide)[0].parent_recursive)
                  if _contact_chain_bones(guide) else 0)
    # Key insertion can leave the evaluated parent's previous Action sample
    # alive until another ID is dirtied. Flush the reset input before any
    # child solution is converted back into FK channels.
    owners={_surface_contact_pose_bone(guide)[0] for guide in guides}
    for owner in owners:owner.update_tag(refresh={'OBJECT'})
    if owners:context.view_layer.update()
    for guide in guides:
        if not _contact_chain_uses_contact(guide):continue
        world=_contact_chain_target_matrix(guide)
        projected=_surface_contact_bound_surface_point(context,guide,world.translation)
        if projected is None:continue
        point,normal=projected
        if (point-world.translation).length<=_surface_contact_settle_tolerance(guide):continue
        # Recover an old off-surface target during an explicit bone reset.
        # Valid independent pins retain their position and orientation.
        bases=_pin_capture_action_pose_bases(owners)
        world=_surface_contact_plane_matrix(point,normal,world)
        guide.matrix_world=world
        _surface_contact_set_guide_surface_point(context,guide,point,normal,update_view_layer=False)
        pending=guide.matrix_basis.copy()
        _surface_contact_keyframe_guide_transform(guide,context.scene.frame_current,
            str(guide.get(SURFACE_CONTACT_BONE_PROPERTY,'')))
        guide.matrix_basis=pending
        _pin_restore_action_pose_bases(context,bases)
    previous=_state.get('contact_chain_pose_edits',set())
    # Reset native input channels, not the previous solved output. Baking a
    # constraint correction into untouched channels changes the next reset's
    # input and makes repeated Alt-G/R converge through different poses.
    _state['contact_chain_pose_edits']=set(previous)-set(names)
    try:
        for guide in guides:
            _contact_chain_sync(context,guide,force=True)
            # A different Contact branch may own this chain's parent.
            # Publish that reset before solving/converting its descendants.
            context.view_layer.update()
        if guides:
            context.view_layer.update()
            _surface_contact_seed_runtime_signatures(context,guides)
            _tag_redraw_all_view3d()
    finally:_state['contact_chain_pose_edits']=previous


def _contact_chain_uses_contact(guide):
    return bool(guide.get(CONTACT_CHAIN_CONTACT, True))


def _contact_chain_is_planted(guide):
    return bool(guide.get(CONTACT_CHAIN_PLANTED,False) and not (
        not _contact_chain_uses_contact(guide) and guide.get('Contact Clip',False)))


def _contact_chain_set_planted(context,guide,enabled):
    """Change tilt policy without moving the already displayed chain."""
    if bool(guide.get(CONTACT_CHAIN_PLANTED,False))==bool(enabled):return
    owner,_bone=_surface_contact_pose_bone(guide)
    bases=_pin_capture_action_pose_bases((owner,))
    poses=_contact_chain_mode_pose(context,guide)
    for name,_matrix in poses:_surface_contact_remove_history_pose_lock(owner.name,name)
    previous=_state.get('surface_contact_solver_syncing',False)
    previous_edit=_state.get('contact_chain_input_editing',False)
    _state['surface_contact_solver_syncing']=True
    _state['contact_chain_input_editing']=True
    try:
        guide[CONTACT_CHAIN_PLANTED]=bool(enabled)
        _contact_chain_configure(context,guide,int(guide.get(SURFACE_CONTACT_CHAIN_PROPERTY,1)))
        _contact_chain_preserve_mode_pose(context,guide,poses)
        context.view_layer.update()
        _contact_chain_preserve_mode_pose(context,guide,poses)
        bases.update({(owner.name,name):owner.pose.bones[name].matrix_basis.copy() for name,_world in poses})
        _pin_restore_action_pose_bases(context,bases)
        _contact_chain_sync(context,guide,force=True)
        context.view_layer.update()
        _surface_contact_seed_runtime_signatures(context,(guide,))
        _surface_contact_store_owner_pose_base(guide)
        _surface_contact_store_valid_pose(guide)
        _surface_contact_capture_idle_pose(context,guide)
        _pin_cache_idle_transform_poses(context)
    finally:
        _state['surface_contact_solver_syncing']=previous
        _state['contact_chain_input_editing']=previous_edit


def _contact_chain_free_space(guide):
    return bpy.data.objects.get(str(guide.get('Contact Free Target Space', '')))


def _contact_chain_display_point(context,guide,depsgraph=None):
    if not _contact_chain_uses_contact(guide):
        anchor=_surface_contact_bone_anchor_world(context,guide,depsgraph)
        if anchor is not None:return anchor
    lock=_state.get('pin_snap_contact_target_locks',{}).get(guide.name)
    if lock is not None:return lock['matrix_world'].translation.copy()
    depsgraph=depsgraph or context.evaluated_depsgraph_get()
    return guide.evaluated_get(depsgraph).matrix_world.translation.copy()


def _contact_chain_joint_dot(context,guide,depsgraph=None):
    axis=_surface_contact_bone_axis_world(context,guide,depsgraph)
    return axis[1] if axis is not None else _contact_chain_display_point(context,guide,depsgraph)


def _contact_chain_mode_conflict(context, guide, enabled):
    previous = guide.get(CONTACT_CHAIN_CONTACT, True)
    try:
        guide[CONTACT_CHAIN_CONTACT] = bool(enabled)
        bones = _contact_chain_bones(guide)
        return (_contact_chain_conflict(context, guide, bones)
                if len(bones) > 1 and guide.get(SURFACE_CONTACT_KIND_PROPERTY) != SURFACE_CONTACT_KIND_CONTROL
                else '')
    finally:
        guide[CONTACT_CHAIN_CONTACT] = previous


def _contact_chain_set_position(context, guide, mode):
    """Free IK can choose a mesh support or an ordinary bone endpoint."""
    owner, bone = _surface_contact_pose_bone(guide)
    if bone is None:
        return False
    evaluated, geometry, part, points, supports = _surface_contact_part_geometry(context, owner, bone)
    if part is not None and points:
        anchor, name, local = _surface_contact_creation_anchor(context,
            context.evaluated_depsgraph_get(), owner, evaluated, geometry, part, points, supports,
            pin_mode=mode, pin_axis=str(guide.get(SURFACE_CONTACT_CAST_AXIS_PROPERTY, 'Y_NEG')))
        matrix = evaluated.matrix_world @ geometry.matrix
        guide[SURFACE_CONTACT_GEOMETRY_BONE_PROPERTY] = geometry.name
    else:
        evaluated = owner.evaluated_get(context.evaluated_depsgraph_get())
        geometry = evaluated.pose.bones[bone.name]
        head, tail = evaluated.matrix_world @ geometry.head, evaluated.matrix_world @ geometry.tail
        anchor = head if mode == 'MODE_4' else ((head+tail)*.5 if mode == 'MODE_2' else tail)
        matrix = evaluated.matrix_world @ geometry.matrix
        name, local = '', None
    if anchor is None:
        return False
    guide[SURFACE_CONTACT_PIN_MODE_PROPERTY] = mode
    guide[SURFACE_CONTACT_SUPPORT_PROPERTY] = tuple(matrix.inverted_safe() @ anchor)
    guide[SURFACE_CONTACT_SMART_OBJECT_PROPERTY] = name
    if local is not None:
        guide[SURFACE_CONTACT_SMART_LOCAL_PROPERTY] = tuple(local)
    _contact_chain_sync(context, guide, force=True)
    return True


def _contact_chain_mode_pose(context,guide):
    owner,_bone=_surface_contact_pose_bone(guide)
    evaluated=owner.evaluated_get(context.evaluated_depsgraph_get())
    return tuple((b.name,owner.matrix_world@evaluated.pose.bones[b.name].matrix)
                 for b in _contact_chain_bones(guide))


def _contact_chain_preserve_mode_pose(context,guide,poses,*,keyframe=False):
    """Re-express the visible chain as FK inputs to the same bend solver."""
    owner,_bone=_surface_contact_pose_bone(guide)
    matrices=[m.copy() for _name,m in poses]
    if not matrices:return
    authored=bool(guide.get('Contact Authored Pose',False))
    solved=(not authored and (not _contact_chain_uses_contact(guide)
            or ((len(matrices)>1 or _contact_chain_is_planted(guide)) and _surface_contact_has_valid_surface(guide))))
    inverse_follow=(_contact_chain_target_follow_matrix(guide,matrices).inverted_safe()
                    if solved else Matrix.Identity(4))
    matrices=[inverse_follow@matrix for matrix in matrices]
    if not authored and _contact_chain_is_planted(guide):
        position=matrices[-1].translation.copy()
        matrices[-1]=poses[-1][1].copy();matrices[-1].translation=position
    bend=float(guide.get(CONTACT_CHAIN_BEND,0.)) if solved else 0.
    root=matrices[0].translation.copy()
    axis=_contact_chain_unit(matrices[-1].translation-root,(0,1,0))
    unbend=Quaternion(axis,-bend)
    positions=[root+unbend@(m.translation-root) for m in matrices]
    inputs=[]
    for i,matrix in enumerate(matrices):
        if i+1<len(matrices):
            swing=_contact_chain_swing(positions[i+1]-positions[i],
                matrices[i+1].translation-matrix.translation,matrices[0].to_3x3().col[0])
            matrix=swing.conjugated().to_matrix().to_4x4()@matrix
        matrix.translation=positions[i];inputs.append(matrix)
    inverse=owner.matrix_world.inverted_safe();bases={}
    # Original RNA pose matrices may still contain the previous parent's
    # constraint output after Alt-G/R has keyed its new channels. Convert
    # against the same evaluated parent frame used by the forward solver.
    evaluated=owner.evaluated_get(context.evaluated_depsgraph_get())
    for i,((name,_world),matrix) in enumerate(zip(poses,inputs)):
        bone=owner.pose.bones[name];kwargs={}
        if bone.parent is not None:
            parent=inputs[i-1] if i else evaluated.matrix_world@evaluated.pose.bones[bone.parent.name].matrix
            parent=inverse@parent
            if i:parent=_contact_chain_parent_matrix(bone,parent,context.scene.frame_current)
            kwargs=dict(parent_matrix=parent,parent_matrix_local=bone.parent.bone.matrix_local)
        bases[name]=bone.bone.convert_local_to_pose(inverse@matrix,bone.bone.matrix_local,invert=True,**kwargs)
        bone.matrix_basis=bases[name].copy()
    if keyframe and context.scene.tool_settings.use_keyframe_insert_auto:
        for name in bases:_insert_bone_keys(owner.pose.bones[name],context.scene.frame_current,visual=False)
    for name,basis in bases.items():owner.pose.bones[name].matrix_basis=basis.copy()


def _contact_chain_set_count(context, guide, count):
    """An explicit topology edit carries the visible pose into its new inputs."""
    owner,bone=_surface_contact_pose_bone(guide)
    if bone is None:return False,'Missing Contact bone'
    old=_contact_chain_bones(guide)
    new=tuple(reversed(_surface_contact_chain(bone,count)))
    if (guide.get(SURFACE_CONTACT_KIND_PROPERTY)==SURFACE_CONTACT_KIND_CONTROL
            or tuple(b.name for b in old)==tuple(b.name for b in new)):
        return _contact_chain_configure(context,guide,count)
    names={b.name for b in (*old,*new)}
    ordered=sorted((owner.pose.bones[name] for name in names),key=lambda b:len(b.parent_recursive))
    original={b.name:b.matrix_basis.copy() for b in ordered}
    evaluated=owner.evaluated_get(context.evaluated_depsgraph_get())
    visible={b.name:owner.matrix_world@b.matrix for b in evaluated.pose.bones}
    attached=_surface_contact_attached_at_frame(guide,context.scene.frame_current)
    previous=_state.get('contact_chain_input_editing',False)
    _state['contact_chain_input_editing']=True
    try:
        ok,message=_contact_chain_configure(context,guide,count)
        if not ok:return ok,message
        inverse=owner.matrix_world.inverted_safe()
        for member in ordered:
            _surface_contact_remove_history_pose_lock(owner.name,member.name)
            kwargs={} if member.parent is None else dict(parent_matrix=inverse@visible[member.parent.name],
                parent_matrix_local=member.parent.bone.matrix_local)
            member.matrix_basis=member.bone.convert_local_to_pose(inverse@visible[member.name],
                member.bone.matrix_local,invert=True,**kwargs)
        context.view_layer.update()
        if guide.get(SURFACE_CONTACT_KIND_PROPERTY)==SURFACE_CONTACT_KIND_CHAIN:
            # Kept members need the inverse of the new root's follow/Bend;
            # released ancestors now retain their ordinary visible FK pose.
            _contact_chain_preserve_mode_pose(context,guide,tuple((b.name,visible[b.name]) for b in new))
        committed={b.name:b.matrix_basis.copy() for b in ordered}
        for member in ordered:member.matrix_basis=committed[member.name].copy()
        _surface_contact_set_snap_detached(guide,not attached)
        _contact_chain_sync(context,guide,force=True)
        context.view_layer.update()
        _surface_contact_store_owner_pose_base(guide)
        _surface_contact_store_valid_pose(guide)
        _surface_contact_capture_idle_pose(context,guide)
        _surface_contact_seed_runtime_signatures(context,(guide,))
        _pin_cache_idle_transform_poses(context)
        return True,''
    finally:_state['contact_chain_input_editing']=previous


def _contact_chain_set_contact(context, guide, enabled):
    enabled = bool(enabled)
    if _contact_chain_uses_contact(guide) == enabled:
        return True, ''
    conflict = _contact_chain_mode_conflict(context, guide, enabled)
    if conflict:
        return False, conflict
    pose_owner,_pose_bone=_surface_contact_pose_bone(guide)
    source_bases=_pin_capture_action_pose_bases((pose_owner,))
    poses=_contact_chain_mode_pose(context,guide)
    for name,_matrix in poses:
        _surface_contact_remove_history_pose_lock(pose_owner.name,name)
    native_control=None
    if guide.get(SURFACE_CONTACT_KIND_PROPERTY)==SURFACE_CONTACT_KIND_CONTROL:
        target,control=_surface_contact_constraint_owner_from_guide(guide)
        if control is not None:
            native_control=(target,control,control.matrix.copy() if isinstance(control,bpy.types.PoseBone)
                            else control.matrix_world.copy())
    previous = _state.get('contact_chain_input_editing', False)
    previous_solver = _state.get('surface_contact_solver_syncing', False)
    _state['contact_chain_input_editing'] = True
    _state['surface_contact_solver_syncing'] = True
    world, basis = guide.matrix_world.copy(), guide.matrix_basis.copy()
    selected_pin = _surface_contact_snap_key(guide) in _pin_selected_target_keys()
    try:
        if not enabled:
            if guide.parent is not None:
                guide['Contact Bound Parent'] = guide.parent
            guide['Contact Bound Parent Type'] = guide.parent_type
            guide['Contact Bound Parent Bone'] = guide.parent_bone
            guide['Contact Bound Parent Inverse'] = tuple(v for row in guide.matrix_parent_inverse for v in row)
            owner, _bone = _surface_contact_pose_bone(guide)
            space = bpy.data.objects.new('_ContactTargetSpace_' + guide.name.rsplit('_', 1)[-1], None)
            _ensure_space_helper_collection(context, owner).objects.link(space)
            space['Contact Chain Owner'] = guide.name
            # Freeze the effective coordinate frame, not individual keys.
            # Existing keyed local targets retain their coordinates and have
            # no dependency on the moving/deleted surface in free mode.
            space.matrix_world = world @ basis.inverted_safe()
            space.hide_render = space.hide_select = True
            space.hide_set(True)
            guide['Contact Free Target Space'] = space.name
            guide.parent = space
            guide.parent_type, guide.parent_bone = 'OBJECT', ''
            guide.matrix_parent_inverse = Matrix.Identity(4)
            guide.matrix_basis = basis
            guide[CONTACT_CHAIN_CONTACT] = False
        else:
            guide[CONTACT_CHAIN_CONTACT] = True
            parent = guide.get('Contact Bound Parent')
            inverse = tuple(guide.get('Contact Bound Parent Inverse', ()))
            if parent is not None and len(inverse) == 16:
                original_inverse = Matrix(tuple(inverse[i:i+4] for i in range(0,16,4)))
                guide.parent = parent
                guide.parent_type = str(guide.get('Contact Bound Parent Type', 'OBJECT'))
                guide.parent_bone = str(guide.get('Contact Bound Parent Bone', ''))
                guide.matrix_parent_inverse = original_inverse
                guide.matrix_basis = basis
                context.view_layer.update()
                evaluated_world = guide.matrix_world.copy()
                guide.matrix_parent_inverse = (original_inverse @ basis @ evaluated_world.inverted_safe()
                                               @ world @ basis.inverted_safe())
                guide.matrix_basis = basis
            else:
                guide.parent = None
                guide.matrix_parent_inverse = Matrix.Identity(4)
                guide.matrix_world = world
            space = _contact_chain_free_space(guide)
            if space is not None:
                bpy.data.objects.remove(space, do_unlink=True)
            if 'Contact Free Target Space' in guide:
                del guide['Contact Free Target Space']
            context.view_layer.update()
            _contact_chain_resume_surface(context,guide,poses)
        count = int(guide.get(SURFACE_CONTACT_CHAIN_PROPERTY, 1))
        if native_control is None:
            _contact_chain_preserve_mode_pose(context,guide,poses)
        if enabled:
            owner,bone=_surface_contact_pose_bone(guide)
            support=Vector(tuple(guide.get(SURFACE_CONTACT_SUPPORT_PROPERTY,(0,bone.length,0)))[:3])
            anchor=poses[-1][1]@support
            # Changing mode is not a snap gesture. Only an already coincident
            # mesh point may attach; screen-radius capture would pull the
            # whole chain toward a nearby surface merely by toggling IK.
            detached=not _pin_attachment_points_match(_surface_contact_snap_key(guide),
                guide.matrix_world.translation,anchor)
            _surface_contact_set_snap_detached(guide,detached)
        # Existing native rig IK keeps its own controller. Raw hierarchies
        # use our same solver in both modes, including a one-bone free chain.
        if guide.get(SURFACE_CONTACT_KIND_PROPERTY) != SURFACE_CONTACT_KIND_CONTROL:
            ok, message = _contact_chain_configure(context, guide, count)
            if not ok:
                return False, message
        if not enabled:
            if guide.get(SURFACE_CONTACT_KIND_PROPERTY) == SURFACE_CONTACT_KIND_CONTROL:
                _surface_contact_set_constraint_attachment(guide,False)
        if native_control is not None:
            target,control,matrix=native_control
            if isinstance(control,bpy.types.PoseBone):control.matrix=matrix
            else:control.matrix_world=matrix
        context.view_layer.update()
        if native_control is None:
            # Key insertion can replay the source Action in the update above.
            _contact_chain_preserve_mode_pose(context,guide,poses)
            source_bases.update({(pose_owner.name,name):pose_owner.pose.bones[name].matrix_basis.copy() for name,_world in poses})
            _pin_restore_action_pose_bases(context,source_bases)
            _contact_chain_sync(context,guide,force=True)
            context.view_layer.update()
        _surface_contact_invalidate_guide_cache()
        _surface_contact_store_owner_pose_base(guide)
        _surface_contact_store_valid_pose(guide)
        _surface_contact_capture_idle_pose(context,guide)
        _surface_contact_seed_runtime_signatures(context,(guide,))
        _pin_cache_idle_transform_poses(context)
        _sync_all_dynamic_pose_bone_colors(context.scene.frame_current,owner)
        _tag_redraw_all_view3d()
        return True, ''
    finally:
        _state['contact_chain_input_editing'] = previous
        _state['surface_contact_solver_syncing'] = previous_solver


def _contact_chain_find_surface(context, guide):
    owner, bone = _surface_contact_pose_bone(guide)
    if bone is None:
        return False
    matrix = owner.matrix_world @ bone.matrix
    direction = ((matrix@_contact_chain_mesh_frame(context,guide)).to_3x3() @ _surface_contact_axis_vector(
        str(guide.get(SURFACE_CONTACT_CAST_AXIS_PROPERTY, 'Y_NEG')))).normalized()
    point = guide.matrix_world.translation.copy()
    excluded = _surface_contact_linked_collision_objects(context, guide)
    hit = _surface_contact_ray_cast(context, point-direction*.001, direction,
                                  max(100., sum(b.length for b in _contact_chain_bones(guide))*4.), excluded)
    if hit is None:
        guide['Contact Surface Unavailable'] = True
        return False
    surface, point, normal, _distance = hit
    if _surface_contact_bind_guide_surface(context, guide, surface, point):
        return _surface_contact_set_guide_surface_point(context, guide, point, normal)
    return False


class ANIMATOR_UTILS_OT_contact_chain_contact(bpy.types.Operator):
    bl_idname = 'staticaliza.contact_chain_contact'
    bl_label = 'Constraint Settings'
    bl_description = 'Choose IK or Collision and how the mesh interacts with surfaces'
    bl_options = {'REGISTER', 'UNDO', 'UNDO_GROUPED'}
    enabled: bpy.props.BoolProperty(default=True,options={'HIDDEN'})
    __annotations__=_contact_settings_properties() | __annotations__

    def draw(self,context):
        _draw_contact_settings_operator(self,context)

    @classmethod
    def poll(cls, context):
        return context.mode == 'POSE'

    def execute(self, context):
        if self.properties.is_property_set('ik_enabled'):
            self.enabled=not self.ik_enabled
        elif self.properties.is_property_set('enabled'):
            self.ik_enabled=not self.enabled
        return _contact_settings_execute(self,context)


class ANIMATOR_UTILS_OT_contact_chain_planted(bpy.types.Operator):
    bl_idname='staticaliza.contact_chain_planted'
    bl_label='Plant'
    bl_description='Align the mesh face while touching a collision surface during a transform; unavailable with Clip'
    bl_options={'REGISTER','UNDO'}
    __annotations__=_contact_settings_properties()

    def draw(self,context):
        _draw_contact_settings_operator(self,context)

    @classmethod
    def poll(cls,context):
        return context.mode=='POSE'

    def execute(self,context):
        return _contact_settings_execute(self,context)


def _contact_chain_resume_surface(context,guide,poses):
    """Resume collision from the current mesh ray, not a stale hidden IK pin."""
    owner,bone=_surface_contact_pose_bone(guide)
    world=poses[-1][1]
    support=Vector(tuple(guide.get(SURFACE_CONTACT_SUPPORT_PROPERTY,(0,bone.length,0)))[:3])
    anchor=world@support
    opposite=_contact_chain_magnetic_opposite(context,guide,owner,bone)
    direction=anchor-world@Vector(opposite)
    if direction.length_squared<1.e-12:
        direction=(world@_contact_chain_mesh_frame(context,guide)).to_3x3()@_surface_contact_axis_vector(
            str(guide.get(SURFACE_CONTACT_CAST_AXIS_PROPERTY,'Y_NEG')))
    direction.normalize()
    hit=_surface_contact_ray_cast(context,anchor-direction*.001,direction,
        max(100.,sum(b.length for b in _contact_chain_bones(guide))*4.),
        _surface_contact_linked_collision_objects(context,guide))
    if hit is None:
        # A coincident contact can be omitted by the scene ray's near-hit
        # filtering. Query its existing collider along the same forward ray;
        # never reverse the cast or reuse a different hidden target.
        surface=guide.get('Contact Surface Object')
        if (surface is not None and surface.name in context.scene.objects
                and surface not in _surface_contact_linked_collision_objects(context,guide)
                and _surface_contact_object_visible(context,surface)):
            local_hit=_surface_contact_object_ray_cast(surface,anchor-direction*.001,direction,
                max(100.,sum(b.length for b in _contact_chain_bones(guide))*4.),
                context.evaluated_depsgraph_get())
            if local_hit is not None:hit=(surface,*local_hit,0.)
    if hit is None:
        guide['Contact Surface Unavailable']=True
        return False
    surface,point,normal,_distance=hit
    if _surface_contact_bind_guide_surface(context,guide,surface,point):
        # The newly cast face establishes its side at the visible mesh point.
        # A reference at the old hidden pin can choose a different face/side
        # of a closed mesh and project the whole linkage across that surface.
        depth=normal.dot(anchor-point)
        if abs(depth)<_surface_contact_settle_tolerance(guide):
            depth=normal.dot(world@Vector(opposite)-point)
        side=1. if depth>=0. else -1.
        guide['Contact Collision Side']=side
        normal=normal*side
        guide.matrix_world=_surface_contact_plane_matrix(point,normal,guide.matrix_world)
        changed=_surface_contact_set_guide_surface_point(context,guide,point,normal,update_view_layer=False)
        pending=guide.matrix_basis.copy()
        if guide.get('Contact Authored Pose'):
            # The resumed ray changes the pin's coordinate origin, not the
            # already authored FK pose. Pair its existing target key with
            # that same pose reference so idle/history cannot interpret the
            # mode handoff itself as a pin drag and translate the limb.
            guide['Contact Pose Reference']=(*guide.matrix_world.translation,
                                             float(guide.get(CONTACT_CHAIN_BEND,0.)))
            guide.keyframe_insert('["Contact Pose Reference"]',frame=context.scene.frame_current,
                                  group=f'Surface Contact State ({bone.name})')
            guide.matrix_basis=pending
        _surface_contact_keyframe_guide_transform(guide,context.scene.frame_current,bone.name)
        guide.matrix_basis=pending
        return changed
    return False
