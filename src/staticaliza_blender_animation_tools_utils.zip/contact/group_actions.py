"""Multi-selection actions for Surface Contact pins."""

from ..core.runtime import *  # noqa: F403


def _surface_contact_pivot_selected(context, operator = None):
    guides = _constraint_pivot_guides(context)
    if not guides:
        return {"CANCELLED"}
    selection = _pin_selection_runtime_snapshot()
    changed = False
    try:
        for guide in guides:
            _surface_contact_clear_snap_departure(guide)
            chain=guide.get(SURFACE_CONTACT_KIND_PROPERTY)==SURFACE_CONTACT_KIND_CHAIN
            if chain:_state.setdefault('contact_chain_pose_edits',set()).add(guide.name)
            try:
                pivoted = _surface_contact_enforce_guide(
                context,
                guide,
                force_contact = True,
                insert_keys = True,
                allow_snap = True,
                )
                if chain:
                    _contact_chain_commit_pose(context,guide)
                    _contact_chain_key_confirmed_inputs(context,guides=(guide,))
                    _surface_contact_commit_target_key(context,guide,detached=False)
                    pivoted=True
                changed=pivoted or changed
            finally:
                if chain:_state.setdefault('contact_chain_pose_edits',set()).discard(guide.name)
            _surface_contact_store_valid_pose(guide)
            _surface_contact_store_owner_pose_base(guide)
        context.view_layer.update()
        _surface_contact_seed_runtime_signatures(context, guides)
        _yellow_refresh_runtime(context)
        _tag_redraw_all_view3d()
    finally:
        _pin_selection_runtime_restore(context, selection)
    if operator is not None and changed:
        operator.report(
            {"INFO"},
            f"Pivoted {len(guides)} Surface Contact pin(s).",
        )
    return {"FINISHED"} if changed else {"CANCELLED"}


def _surface_contact_inverse_pivot_active(
    context,
    operator = None,
    initial_state_json = "",
):
    """Move only the active pink dragger onto its linked contact point."""
    target_data = _pin_virtual_selected_target_data(context)
    if target_data is None or target_data[0] != "CONTACT":
        guide = _surface_contact_selected_guide(
            context,
            active_only = True,
        )
        if guide is None:
            try:
                active_target = str(
                    json.loads(initial_state_json).get("active_target", "")
                )
            except (TypeError, ValueError):
                active_target = ""
            kind, separator, guide_name = active_target.partition("\n")
            guide = (
                bpy.data.objects.get(guide_name)
                if separator and kind == "CONTACT"
                else None
            )
        if guide is not None:
            armature, pose_bone = _surface_contact_pose_bone(guide)
            target_data = (
                ("CONTACT", armature, pose_bone, guide)
                if armature is not None and pose_bone is not None
                else None
            )
    if target_data is None or target_data[0] != "CONTACT":
        if operator is not None:
            operator.report(
                {"WARNING"},
                "Select a bone with Surface Contact or its dragger.",
            )
        return {"CANCELLED"}
    _kind, _armature, pose_bone, guide = target_data
    anchor = _surface_contact_anchor_world(context, guide)
    if anchor is None:
        if operator is not None:
            operator.report({"WARNING"}, "The connected point is unavailable.")
        return {"CANCELLED"}
    normal = _surface_contact_reference_normal(guide)

    selection = _pin_selection_runtime_snapshot()
    original_basis = pose_bone.matrix_basis.copy()
    original_chain = _contact_chain_mode_pose(context,guide) if (
        guide.get(SURFACE_CONTACT_KIND_PROPERTY)==SURFACE_CONTACT_KIND_CHAIN) else ()
    previous_guard = bool(_state.get("surface_contact_reconciling", False))
    _state["surface_contact_reconciling"] = True
    try:
        moved = _surface_contact_set_guide_surface_point(
            context,
            guide,
            anchor,
            normal,
            preserve_orientation = True,
        )
        if not moved:
            # Released/legacy contacts may no longer have a live surface
            # object. Inverse is still a target-only placement operation.
            world_matrix = guide.matrix_world.copy()
            world_matrix.translation = anchor
            guide.matrix_world = world_matrix
            context.view_layer.update()
        _surface_contact_clear_snap_departure(guide)
        _surface_contact_commit_target_key(context, guide, detached = False)
        if original_chain:
            _contact_chain_preserve_mode_pose(context,guide,original_chain)
            guide['Contact Pose Reference']=(*guide.matrix_world.translation,
                                             float(guide.get(CONTACT_CHAIN_BEND,0.)))
        else:pose_bone.matrix_basis = original_basis
        context.view_layer.update()
        _surface_contact_seed_runtime_signatures(context, (guide,))
    finally:
        _state["surface_contact_reconciling"] = previous_guard
        _pin_selection_runtime_restore(context, selection)
    if operator is not None:
        operator.report({"INFO"}, "Moved the active Surface Contact pin.")
    return {"FINISHED"}


def _surface_contact_clear_selected(context, operator = None):
    state = _constraint_selection_state(context)
    if state["pink"] and state["cyan"]:
        return _constraint_apply_action(context, "CLEAR", operator)
    guides = _surface_contact_selected_guides(
        context,
        active_only = True,
    )
    if not guides:
        return {"CANCELLED"}
    selection = _pin_selection_runtime_snapshot()
    removed_keys = {
        _surface_contact_snap_key(guide)
        for guide in guides
    }
    bone_names = tuple(
        str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, "endpoint"))
        for guide in guides
    )
    for guide in guides:
        _surface_contact_remove_guide(
            context,
            guide,
            preserve_frame = int(context.scene.frame_current),
        )
    remaining = set(selection["selected"]) - removed_keys
    if remaining:
        active = selection["active"]
        if active not in remaining:
            active = next(iter(sorted(remaining)))
        _pin_selection_runtime_restore(
            context,
            {"active": active, "selected": remaining},
        )
    else:
        _pin_deselect_target(push_history = False)
    _yellow_refresh_runtime(context)
    _tag_redraw_all_view3d()
    if operator is not None:
        label = (
            bone_names[0]
            if len(bone_names) == 1
            else f"{len(bone_names)} selected pins"
        )
        operator.report(
            {"INFO"},
            f"Cleared Surface Contact for {label}.",
        )
    return {"FINISHED"}


def _surface_contact_release_guide(context, guide, operator):
    frame = int(context.scene.frame_current)
    start = int(guide.get(SURFACE_CONTACT_START_PROPERTY, frame))
    if frame <= start:
        operator.report({"ERROR"}, "Release must be after the contact start frame.")
        return {"CANCELLED"}

    _marker_object, marker_owner = _surface_contact_owner_from_guide(guide)
    primary, _secondary = _surface_contact_constraints(guide)
    if (
        marker_owner is None
        or (
            primary is None
            and str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
            not in {SURFACE_CONTACT_KIND_SIMULATED, SURFACE_CONTACT_KIND_CHAIN}
        )
    ):
        operator.report({"ERROR"}, "The contact constraint is missing.")
        return {"CANCELLED"}

    chain_poses = (_contact_chain_previous_poses(context,guide,frame)
                   if guide.get(SURFACE_CONTACT_KIND_PROPERTY)==SURFACE_CONTACT_KIND_CHAIN else ())
    effector_name = str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
    target_object = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_RELEASE_OBJECT_PROPERTY, ""))
    )
    target_bone_name = str(
        guide.get(SURFACE_CONTACT_RELEASE_BONE_PROPERTY, "")
    )
    target_world = _surface_contact_target_world_matrix(
        context,
        target_object,
        target_bone_name,
    ) if target_object is not None and not chain_poses else None
    if not chain_poses and target_object is not None and target_object.type == "ARMATURE" and target_bone_name:
        target_bone = target_object.pose.bones.get(target_bone_name)
        if target_bone is not None:
            target_world = target_object.matrix_world @ _special_end_previous_pose(
                context, target_object, target_bone, frame)
    guide[SURFACE_CONTACT_END_PROPERTY] = frame
    _surface_contact_invalidate_guide_cache()
    _surface_contact_rebuild_markers(
        marker_owner,
        effector_name,
    )
    _sync_surface_contact_constraints(
        context.scene,
        solve_simulated = False,
        solve_guides = False,
        sync_dynamic_parent = False,
    )
    if chain_poses:
        armature, _bone = _surface_contact_pose_bone(guide)
        _contact_chain_sync_all(context,force=True)
        context.view_layer.update()
        for name,matrix in chain_poses:
            _constraint_key_end_pose(context,armature,armature.pose.bones[name],matrix,frame)
    elif target_world is not None and target_object is not None:
        _constraint_contact_end_pose(context, guide, frame, target_object, target_bone_name, target_world)
    context.view_layer.update()

    _yellow_refresh_runtime(context)
    _sync_all_dynamic_pose_bone_colors(frame)
    _tag_redraw_all_view3d()
    operator.report({"INFO"}, f"Released {effector_name} at frame {frame}.")
    return {"FINISHED"}
