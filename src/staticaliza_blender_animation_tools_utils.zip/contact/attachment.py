"""Shared attachment state for simulated and existing-IK contacts."""

from ..core.runtime import *  # noqa: F403


def _surface_contact_history_entry_parts(entry):
    values = tuple(entry or ())
    new_format = bool(
        len(values) >= 6
        or len(values) == 5
        and not isinstance(values[0], (tuple, list))
    )
    if new_format:
        armature_name, bone_name, before, native_after, solved_after = values[-5:]
    elif len(values) >= 4:
        armature_name, bone_name, before, native_after = values[-4:]
        solved_after = native_after
    else:
        raise ValueError("Invalid Contact history entry")
    return (
        str(armature_name),
        str(bone_name),
        before,
        native_after,
        solved_after,
    )


def _surface_contact_history_side_matches(entries, index):
    """Match selected or contact history entries against one paired side."""
    index = int(index)
    if index not in (0, 1):
        return False
    for entry in entries:
        armature_name, bone_name, before, native_after, solved_after = (
            _surface_contact_history_entry_parts(entry)
        )
        armature = bpy.data.objects.get(armature_name)
        pose_bone = (
            armature.pose.bones.get(bone_name)
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        expected = (before,) if index == 0 else (native_after, solved_after)
        if pose_bone is None or not any(
            not _pin_keyboard_matrices_differ(
                pose_bone.matrix_basis,
                matrix,
                epsilon=1.0e-5,
            )
            for matrix in expected
        ):
            return False
    return True


def _surface_contact_snap_capable(guide):
    return str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, "")) in {
        SURFACE_CONTACT_KIND_SIMULATED,
        SURFACE_CONTACT_KIND_CONTROL,
    }


def _surface_contact_constraint_history_state(guide):
    """Capture the exact runtime state of Contact-owned constraints."""
    primary, secondary = _surface_contact_constraints(guide)
    entries = []
    for role, constraint in (("PRIMARY", primary), ("SECONDARY", secondary)):
        if constraint is None:
            entries.append((role, "", "", None, None))
            continue
        entries.append((
            role,
            str(getattr(constraint, "name", "")),
            str(getattr(constraint, "type", "")),
            float(getattr(constraint, "influence", 1.0)),
            bool(getattr(constraint, "mute", False)),
        ))
    return tuple(entries)


def _surface_contact_restore_constraint_history_state(guide, snapshot):
    """Restore Contact constraints without reconstructing their state."""
    if guide is None or not snapshot:
        return False
    primary, secondary = _surface_contact_constraints(guide)
    by_role = {"PRIMARY": primary, "SECONDARY": secondary}
    _target_object, owner = _surface_contact_constraint_owner_from_guide(guide)
    constraints = getattr(owner, "constraints", None)
    changed = False
    for role, name, constraint_type, influence, mute in tuple(snapshot):
        constraint = by_role.get(str(role))
        if (
            constraint is None
            or (name and str(getattr(constraint, "name", "")) != str(name))
        ) and constraints is not None and name:
            try:
                constraint = constraints.get(str(name))
            except (AttributeError, ReferenceError, RuntimeError):
                constraint = None
        if constraint is None:
            continue
        if constraint_type and str(getattr(constraint, "type", "")) != str(constraint_type):
            continue
        if influence is not None and abs(
            float(getattr(constraint, "influence", 1.0)) - float(influence)
        ) > 1.0e-8:
            constraint.influence = float(influence)
            changed = True
        if mute is not None and hasattr(constraint, "mute") and bool(constraint.mute) != bool(mute):
            constraint.mute = bool(mute)
            changed = True
    return changed


def _surface_contact_set_constraint_attachment(guide, attached):
    """Enable existing-IK target constraints only while magnetically attached."""

    if (
        str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
        != SURFACE_CONTACT_KIND_CONTROL
    ):
        return False
    primary, secondary = _surface_contact_constraints(guide)
    desired = (
        (primary, 1.0 if attached else 0.0),
        (
            secondary,
            _surface_contact_guide_aim_influence(guide)
            if attached
            else 0.0,
        ),
    )
    changed = False
    for constraint, influence in desired:
        if (
            constraint is not None
            and abs(float(constraint.influence) - influence) > 1.0e-6
        ):
            constraint.influence = influence
            changed = True
    return changed



def _surface_contact_release_channels(owner, frame, curves, prefix="", fallback=None):
    """Read Action channels without changing the scene or entering handlers."""
    values = {}
    for prop in ("location", "scale", "rotation_euler", "rotation_quaternion",
                 "rotation_axis_angle"):
        values[prop] = list(getattr(owner, prop))
    if fallback is not None:
        values["location"] = list(fallback)
    for curve in curves:
        prop = str(curve.data_path).removeprefix(prefix)
        if curve.data_path == prefix + prop and prop in values and not curve.mute:
            index = int(curve.array_index)
            if 0 <= index < len(values[prop]):
                values[prop][index] = float(curve.evaluate(frame))
    mode = owner.rotation_mode
    if mode == "QUATERNION":
        rotation = Quaternion(values["rotation_quaternion"])
        rotation.normalize()
    elif mode == "AXIS_ANGLE":
        angle, *axis = values["rotation_axis_angle"]
        rotation = Quaternion(Vector(axis), angle)
    else:
        rotation = owner.rotation_euler.copy()
        rotation[:] = values["rotation_euler"]
    return Matrix.LocRotScale(Vector(values["location"]), rotation,
                              Vector(values["scale"]))


def _surface_contact_release_object_matrix(obj, frame, memo):
    key = (obj.name, "OBJECT")
    if key in memo:
        return memo[key]
    action = _dynamic_parent_owner_action(obj)
    curves = tuple(_action_fcurves(action, obj)) if action else ()
    matrix = _surface_contact_release_channels(obj, frame, curves)
    if obj.parent is not None:
        # Contact guides normally follow the surface with object parenting.
        parent = _surface_contact_release_object_matrix(obj.parent, frame, memo)
        if obj.parent_type == "BONE" and obj.parent.pose:
            bone = obj.parent.pose.bones.get(obj.parent_bone)
            if bone is not None:
                parent = parent @ _surface_contact_release_bone_matrix(
                    obj.parent, bone, frame, memo)
                parent = parent @ Matrix.Translation((0, bone.length, 0))
        matrix = parent @ obj.matrix_parent_inverse @ matrix
    memo[key] = matrix
    return matrix


def _surface_contact_release_bone_matrix(armature, bone, frame, memo):
    key = (armature.name, bone.name)
    if key in memo:
        return memo[key]
    action = _dynamic_parent_owner_action(armature)
    curves = tuple(_action_fcurves(action, armature)) if action else ()
    basis = _surface_contact_release_channels(
        bone, frame, curves, bone.path_from_id() + ".",
        memo.get((armature.name, bone.name, "BASE")))
    kwargs = {}
    if bone.parent:
        kwargs = dict(parent_matrix=_surface_contact_release_bone_matrix(
            armature, bone.parent, frame, memo),
            parent_matrix_local=bone.parent.bone.matrix_local)
    matrix = bone.bone.convert_local_to_pose(
        basis, bone.bone.matrix_local, **kwargs)
    memo[key] = matrix
    return matrix


def _surface_contact_continue_released_pose(context, *, frame_change=False):
    """Carry a simulated contact's final translation into its parent's space.

    Derive the boundary from authored channels, not the previous visited frame.
    Only location is corrected: rotation/scale remain native animation. Each
    axis hands back to the next authored location key without adding bone keys.
    """
    if (context is None or context.scene is None
            or _state.get("pin_history_active", False)
            or _state.get("pin_history_syncing", False)
            or _state.get("surface_contact_creation_active", False)
            or _state.get("surface_contact_load_restoring", False)
            or _state.get("pin_target_dragging", False)
            or _state.get("pin_snap_transform_active", False)
            or _pin_active_transform_operator(context)):
        return False
    frame = float(context.scene.frame_current) + context.scene.frame_subframe
    latest = {}
    for guide in _surface_contact_guides():
        start = float(guide.get(SURFACE_CONTACT_START_PROPERTY, SPACE_MIN_FRAME))
        if start > frame:
            continue
        key = (str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, "")),
               str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, "")))
        if key not in latest or start > latest[key][0]:
            latest[key] = (start, guide)
    changed = False
    cache = _state.setdefault("surface_contact_release_locations", {})
    live = {guide.name for _, guide in latest.values()}
    for name in tuple(cache):
        if name not in live:
            cache.pop(name, None)
    for _, guide in latest.values():
        end = guide.get(SURFACE_CONTACT_END_PROPERTY)
        if (end is None or frame <= float(end)
                or guide.get(SURFACE_CONTACT_KIND_PROPERTY) != SURFACE_CONTACT_KIND_SIMULATED
                or not _surface_contact_attached_at_frame(guide, int(end))):
            continue
        resolved = _surface_contact_resolved_playback_guide(guide)
        if resolved is None:
            continue
        armature, bone, geometry, support = resolved
        if _ragdoll_active(bone, int(frame)):
            continue
        action = _dynamic_parent_owner_action(armature)
        curves = tuple(_action_fcurves(action, armature)) if action else ()
        prefix = bone.path_from_id() + "."
        entry = cache.setdefault(guide.name, {"base": tuple(bone.location)})
        raw = _surface_contact_release_channels(
            bone, frame, curves, prefix, entry["base"]).translation
        current = bone.location.copy()
        previous = entry.get("applied")
        if (not frame_change and (current - raw).length > 1e-5
                and (previous is None or (current - Vector(previous)).length > 1e-5)):
            # An unkeyed user edit is newer authority than the release repair.
            continue
        memo = {(armature.name, bone.name, "BASE"): entry["base"]}
        boundary = _surface_contact_release_bone_matrix(armature, bone, float(end), memo)
        geom = _surface_contact_release_bone_matrix(armature, geometry, float(end), memo)
        world = _surface_contact_release_object_matrix(armature, float(end), memo)
        target = _surface_contact_release_object_matrix(guide, float(end), memo).translation
        delta = world.inverted_safe().to_3x3() @ (target - world @ geom @ support)
        kwargs = {}
        if bone.parent:
            kwargs = dict(parent_matrix=_surface_contact_release_bone_matrix(
                armature, bone.parent, float(end), memo),
                parent_matrix_local=bone.parent.bone.matrix_local)
        solved = boundary.copy()
        solved.translation += delta
        local = bone.bone.convert_local_to_pose(
            solved, bone.bone.matrix_local, invert=True, **kwargs)
        original = bone.bone.convert_local_to_pose(
            boundary, bone.bone.matrix_local, invert=True, **kwargs)
        offset = local.translation - original.translation
        for axis in range(3):
            next_keys = [float(k.co.x) for fc in curves
                         if fc.data_path == prefix + "location"
                         and fc.array_index == axis and not fc.mute
                         for k in fc.keyframe_points if k.co.x > float(end)]
            if next_keys:
                offset[axis] *= max(0.0, (min(next_keys) - frame) / (min(next_keys) - float(end)))
        desired = raw + offset
        entry["applied"] = tuple(desired)
        if (current - desired).length > 1e-6:
            bone.location = desired
            changed = True
    return changed



def _surface_contact_settle_animated_detached(context, guides):
    """Aim the animated contact rod and prevent overshooting its surface.

    Reconstruct each sample from the Action, never the last solved frame.
    A free rod pivots about its opposite end; when that pivot comes within
    one rod length, translate only the excess reach so the support meets the
    pin instead of travelling through it. The authored detached state stays
    unchanged, including at a geometrically coincident endpoint.
    """
    if (_state.get("surface_contact_animation_settling", False)
            or _state.get("pin_snap_transform_active", False)
            or _state.get("pin_target_dragging", False)
            or _state.get("pin_history_active", False)
            or _state.get("pin_history_syncing", False)):
        return False
    changed = False
    frame = float(context.scene.frame_current) + context.scene.frame_subframe
    _state["surface_contact_animation_settling"] = True
    try:
        depsgraph = context.view_layer.depsgraph
        for guide in guides:
            if _surface_contact_animated_detached_state(guide, frame) is not True:
                continue
            resolved = _surface_contact_resolved_playback_guide(guide)
            if resolved is None:
                continue
            armature, bone, geometry, support = resolved
            # Existing IK controls have their own solver. This path owns the
            # direct, rigid simulated limb used by pink contact animation.
            if geometry != bone or bone.constraints:
                continue
            smart = bpy.data.objects.get(str(guide.get(SURFACE_CONTACT_SMART_OBJECT_PROPERTY, "")))
            local = guide.get(SURFACE_CONTACT_SMART_LOCAL_PROPERTY)
            if smart is None or local is None or len(local) < 3:
                continue
            evaluated_arm = armature.evaluated_get(depsgraph)
            evaluated_bone = evaluated_arm.pose.bones.get(bone.name)
            evaluated_part = smart.evaluated_get(depsgraph)
            binding = (evaluated_arm.matrix_world @ evaluated_bone.matrix).inverted_safe() @ evaluated_part.matrix_world
            # Rigid Roblox parts are welded by a Child Of constraint. Build
            # that binding from the same Action sample as the limb; evaluated
            # mesh and bone matrices may belong to different update passes.
            welds = [c for c in smart.constraints if c.type == "CHILD_OF"
                     and c.target == armature and c.subtarget in armature.pose.bones]
            memo = {}
            raw_local = _surface_contact_release_bone_matrix(armature, bone, frame, memo)
            if len(welds) == 1 and abs(welds[0].influence - 1.0) < 1e-6:
                weld = welds[0]
                part_pose = _surface_contact_release_bone_matrix(
                    armature, armature.pose.bones[weld.subtarget], frame, memo)
                binding = raw_local.inverted_safe() @ part_pose @ weld.inverse_matrix @ smart.matrix_basis
            opposite = Vector(tuple(float(v) for v in local[:3]))
            axis = {"X": 0, "Y": 1, "Z": 2}.get(str(guide.get(SURFACE_CONTACT_CAST_AXIS_PROPERTY, "Y_NEG"))[0], 1)
            bounds = [float(corner[axis]) for corner in evaluated_part.bound_box]
            opposite[axis] = max((min(bounds), max(bounds)), key=lambda v: abs(v - opposite[axis]))
            opposite_local = binding @ opposite
            raw = armature.matrix_world @ raw_local
            anchor = raw @ support
            pivot = raw @ opposite_local
            rod = anchor - pivot
            length = rod.length
            if length <= 1e-8:
                continue
            target = guide.matrix_world.translation.copy()
            normal = guide.matrix_world.to_3x3().col[2].normalized()
            # Keep the far end on the allowed side before constructing the
            # ray. Both rod endpoints then lie in the same legal half-space.
            pivot_height = (pivot - target).dot(normal)
            legal_pivot = pivot - normal * min(0.0, pivot_height)
            away = legal_pivot - target
            distance = away.length
            if distance <= 1e-8:
                away = normal
            else:
                away /= distance
            final_pivot = target + away * max(distance, length)
            rotation = rod.normalized().rotation_difference(-away)
            solved = (Matrix.Translation(final_pivot)
                      @ rotation.to_matrix().to_4x4()
                      @ Matrix.Translation(-pivot) @ raw)
            desired = armature.matrix_world.inverted_safe() @ solved
            if _pin_keyboard_matrices_differ(bone.matrix, desired, epsilon=1e-6):
                bone.matrix = desired
                armature.update_tag(refresh={"DATA"})
                changed = True
    finally:
        _state["surface_contact_animation_settling"] = False
    return changed



def _surface_contact_magnetic_rod_world(guide, bone_world, target, normal,
                                        anchor, opposite, *, attached=False):
    """Shared rigid contact solve for ancestor motion and temporary draggers.

    Far from contact, aim around the far endpoint. Inside the rod's reach,
    the fixed target owns pressure, including the far-end pivot/bottom lift.
    Always pass the requested raw pose, never the preceding solved pose.
    """
    target, normal = Vector(target), Vector(normal).normalized()
    anchor, opposite = Vector(anchor), Vector(opposite)
    rod = anchor - opposite
    toward = target - opposite
    if rod.length_squared <= 1e-12:
        return Matrix(bone_world)
    if (attached or toward.length <= rod.length
            or (opposite - target).dot(normal) < 0.0):
        solved = _surface_contact_pressure_rod_world(
            guide, bone_world, target, normal, anchor, opposite)
        return solved if solved is not None else Matrix(bone_world)
    rotation = rod.normalized().rotation_difference(toward.normalized())
    return (Matrix.Translation(opposite) @ rotation.to_matrix().to_4x4()
            @ Matrix.Translation(-opposite) @ Matrix(bone_world))
