"""Contact-placement choices and non-destructive creation policy."""

from ..core.runtime import *  # noqa: F403


def _surface_contact_creation_anchor(
    context,
    depsgraph,
    armature,
    evaluated_armature,
    evaluated_bone,
    part,
    geometry_points,
    support_objects,
    pin_mode=None,
    pin_axis="Y_NEG",
):
    """Return the configured limb anchor plus its rigid object-local point."""

    mode = str(
        pin_mode
        if pin_mode is not None
        else getattr(
            context.window_manager,
            "surface_contact_pin_mode",
            "MODE_3",
        )
    )
    if mode == "MODE_3":
        return _yellow_mode3_anchor(
            context,
            depsgraph,
            armature,
            evaluated_armature,
            support_objects,
            evaluated_bone.name,
            axis=pin_axis,
        )

    if mode == "MODE_1":
        anchor = evaluated_armature.matrix_world @ evaluated_bone.tail
    elif mode == "MODE_4":
        anchor = evaluated_armature.matrix_world @ evaluated_bone.head
    else:
        anchor = _surface_contact_geometry_center(geometry_points)
    if anchor is None:
        return None, "", None

    smart_object = part
    if smart_object is None and support_objects:
        smart_object = support_objects[0]
    if smart_object is None:
        return Vector(anchor), "", None
    try:
        evaluated_object = smart_object.evaluated_get(depsgraph)
        local_point = (
            evaluated_object.matrix_world.inverted_safe() @ Vector(anchor)
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        local_point = smart_object.matrix_world.inverted_safe() @ Vector(anchor)
    return Vector(anchor), smart_object.name, local_point


def _on_surface_contact_pin_mode_change(self, context):
    _surface_contact_apply_pin_mode_change(self, context)


def _surface_contact_apply_pin_mode_change(self, context, push_history=True, guide_override=None):
    if (
        context is None
        or context.mode != "POSE"
        or _state.get("surface_contact_pin_mode_syncing", False)
        or _state.get("surface_contact_creation_active", False)
        or _state.get("pin_history_syncing", False)
        or _state.get("gyro_native_history", False)
    ):
        return
    guides = (guide_override,) if guide_override is not None else _surface_contact_selected_guides(context, active_only = True)
    if not guides:
        return
    mode = str(getattr(self, "surface_contact_pin_mode", getattr(self,'pin_mode','MODE_3')))
    axis = str(getattr(self, "surface_contact_cast_axis", getattr(self,'cast_axis','Y_NEG')))
    _state["surface_contact_pin_mode_syncing"] = True
    changed = False
    try:
        for guide in guides:
            if not _contact_chain_uses_contact(guide):
                changed = _contact_chain_set_position(context, guide, mode) or changed
                continue
            axis = str(guide.get(SURFACE_CONTACT_CAST_AXIS_PROPERTY, axis))
            armature = bpy.data.objects.get(
                str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
            )
            geometry_name = str(
                guide.get(
                    SURFACE_CONTACT_GEOMETRY_BONE_PROPERTY,
                    guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""),
                )
            )
            pose_bone = (
                armature.pose.bones.get(geometry_name)
                if armature is not None and getattr(armature, "pose", None)
                else None
            )
            if pose_bone is None:
                continue
            evaluated_armature, evaluated_bone, part, points, supports = (
                _surface_contact_part_geometry(context, armature, pose_bone)
            )
            if evaluated_bone is None or part is None or not points:
                if guide.get(SURFACE_CONTACT_KIND_PROPERTY)==SURFACE_CONTACT_KIND_CHAIN:
                    changed = _contact_chain_set_position(context,guide,mode) or changed
                continue
            anchor, object_name, object_local = _surface_contact_creation_anchor(
                context,
                context.evaluated_depsgraph_get(),
                armature,
                evaluated_armature,
                evaluated_bone,
                part,
                points,
                supports,
                pin_mode = mode,
                pin_axis = axis,
            )
            if anchor is None:
                continue
            geometry_world = evaluated_armature.matrix_world @ evaluated_bone.matrix
            guide[SURFACE_CONTACT_SUPPORT_PROPERTY] = tuple(
                geometry_world.inverted_safe() @ Vector(anchor)
            )
            guide[SURFACE_CONTACT_PIN_MODE_PROPERTY] = mode
            guide[SURFACE_CONTACT_CAST_AXIS_PROPERTY] = axis
            if object_name and object_local is not None:
                guide[SURFACE_CONTACT_SMART_OBJECT_PROPERTY] = object_name
                guide[SURFACE_CONTACT_SMART_LOCAL_PROPERTY] = tuple(
                    float(value) for value in object_local
                )
            changed = bool(
                _surface_contact_enforce_guide(
                    context,
                    guide,
                    force_contact = False,
                    allow_snap = True,
                    rotate_detached = False,
                    rotate_snap = False,
                )
            ) or changed
        if changed:
            context.view_layer.update()
            if push_history:
                try:
                    bpy.ops.ed.undo_push(message = "Surface Contact Position")
                except (AttributeError, RuntimeError):
                    pass
    finally:
        _state["surface_contact_pin_mode_syncing"] = False
        _tag_redraw_all_view3d()


def _on_surface_contact_cast_axis_change(self, context):
    _surface_contact_apply_cast_axis_change(self, context)


def _surface_contact_apply_cast_axis_change(self, context, guide_override=None, push_history=True):
    if (
        context is None
        or context.mode != "POSE"
        or _state.get("surface_contact_load_restoring", False)
        or _state.get("animator_utils_file_defaults_syncing", False)
        or _state.get("surface_contact_axis_syncing", False)
        or _state.get("surface_contact_creation_active", False)
        or _state.get("pin_history_syncing", False)
        or _state.get("gyro_native_history", False)
        or (guide_override is None and _surface_contact_selected_guide(context, active_only=True) is None)
    ):
        return
    previous_solver_guard = bool(
        _state.get("surface_contact_solver_syncing", False)
    )
    _state["surface_contact_axis_syncing"] = True
    _state["surface_contact_solver_syncing"] = True
    try:
        guide = guide_override if guide_override is not None else _surface_contact_selected_guide(context, active_only=True)
        if not _contact_chain_uses_contact(guide):
            guide[SURFACE_CONTACT_CAST_AXIS_PROPERTY]=str(getattr(self,'surface_contact_cast_axis','Y_NEG'))
            _contact_chain_set_position(context,guide,str(guide.get(SURFACE_CONTACT_PIN_MODE_PROPERTY,'MODE_3')))
            _surface_contact_seed_runtime_signatures(context,(guide,))
            if push_history:bpy.ops.ed.undo_push(message='IK Axis')
            return
        armature = bpy.data.objects.get(
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
        )
        pose_bone = (
            armature.pose.bones.get(
                str(guide.get(SURFACE_CONTACT_GEOMETRY_BONE_PROPERTY, ""))
            )
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        effector = (
            armature.pose.bones.get(
                str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
            )
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        if effector is None:
            effector = pose_bone
        initial_effector_matrix = (
            effector.matrix.copy() if effector is not None
            and guide.get(SURFACE_CONTACT_KIND_PROPERTY)!=SURFACE_CONTACT_KIND_CHAIN else None
        )
        (
            evaluated_armature,
            evaluated_bone,
            part,
            points,
            supports,
        ) = _surface_contact_part_geometry(context, armature, pose_bone)
        depsgraph = context.evaluated_depsgraph_get()
        axis = str(getattr(self, "surface_contact_cast_axis", "Y_NEG"))
        if evaluated_bone is None or part is None or not points:
            evaluated_armature = armature.evaluated_get(depsgraph)
            evaluated_bone = evaluated_armature.pose.bones[pose_bone.name]
            geometry_world = evaluated_armature.matrix_world @ evaluated_bone.matrix
            points = (evaluated_armature.matrix_world @ evaluated_bone.head,
                      evaluated_armature.matrix_world @ evaluated_bone.tail)
            supports = ()
            anchor = geometry_world @ Vector(tuple(guide.get(SURFACE_CONTACT_SUPPORT_PROPERTY,
                                                            (0.,pose_bone.length,0.)))[:3])
            object_name,object_local = '',None
        else:
            anchor, object_name, object_local = _surface_contact_creation_anchor(
                context,
                depsgraph,
                armature,
                evaluated_armature,
                evaluated_bone,
                part,
                points,
                supports,
                pin_mode=str(getattr(self, "surface_contact_pin_mode", "MODE_3")),
                pin_axis=axis,
            )
        surface, point, normal, _bone_length = _surface_contact_detect_surface(
            context,
            armature,
            evaluated_armature,
            evaluated_bone,
            points,
            supports,
            anchor,
            object_name,
            cast_axis=axis,
        )
        if surface is None or point is None or normal is None:
            guide[SURFACE_CONTACT_CAST_AXIS_PROPERTY] = axis
            _surface_contact_disable_missing_surface(guide)
            _state["last_error"] = ""
            if push_history:
                try:
                    bpy.ops.ed.undo_push(message="Surface Contact Axis")
                except RuntimeError:
                    pass
            return
        guide[SURFACE_CONTACT_CAST_AXIS_PROPERTY] = axis
        guide[SURFACE_CONTACT_OBJECT_PROPERTY] = part.name if part is not None else ''
        if object_name and object_local is not None:
            guide[SURFACE_CONTACT_SMART_OBJECT_PROPERTY] = object_name
            guide[SURFACE_CONTACT_SMART_LOCAL_PROPERTY] = tuple(
                float(value) for value in object_local
            )
        geometry_world = (
            evaluated_armature.matrix_world @ evaluated_bone.matrix
        )
        guide[SURFACE_CONTACT_SUPPORT_PROPERTY] = tuple(
            geometry_world.inverted_safe() @ Vector(anchor)
        )
        _surface_contact_bind_guide_surface(context, guide, surface, point)
        if not _surface_contact_set_guide_surface_point(
            context,
            guide,
            point,
            normal,
        ):
            raise RuntimeError("Unable to place the contact on the cast surface")
        _surface_contact_set_constraint_attachment(guide, False)
        _surface_contact_set_snap_detached(guide, True)
        if effector is not None and initial_effector_matrix is not None:
            effector.matrix = initial_effector_matrix
            context.view_layer.update()
        _surface_contact_store_valid_pose(guide)
        _surface_contact_store_owner_pose_base(guide)
        _surface_contact_seed_runtime_signatures(context, (guide,))
        _state["last_error"] = ""
    except (AttributeError, RuntimeError, TypeError, ValueError) as exc:
        _state["last_error"] = f"Contact axis update failed: {exc}"
    finally:
        _state["surface_contact_solver_syncing"] = previous_solver_guard
        _state["surface_contact_axis_syncing"] = False
        _tag_redraw_all_view3d()
    if push_history:
        try:
            bpy.ops.ed.undo_push(message = "Surface Contact Axis")
        except (AttributeError, RuntimeError):
            pass


def _surface_contact_creation_is_attached(
    guide,
    anchor,
    surface_point,
    surface_normal,
    bone_length,
):
    """Only settle a limb that already touches or penetrates its target plane."""

    normal = Vector(surface_normal)
    if normal.length_squared <= 1.0e-12:
        return False
    normal.normalize()
    tolerance = max(
        _surface_contact_settle_tolerance(guide),
        float(bone_length) * 1.0e-3,
    )
    signed_separation = (
        Vector(anchor) - Vector(surface_point)
    ).dot(normal)
    return signed_separation <= tolerance


def _surface_contact_publish_creation_attachment(guide, attached):
    """Publish one complete post-creation snap state before keyframing."""
    snap_key = _surface_contact_snap_key(guide)
    if attached:
        _surface_contact_clear_snap_departure(guide)
        _state.setdefault("pin_snap_latches", set()).add(snap_key)
        _state.setdefault("pin_snap_detached", set()).discard(snap_key)
        _surface_contact_set_constraint_attachment(guide, True)
        return True
    _surface_contact_set_constraint_attachment(guide, False)
    _surface_contact_set_snap_detached(guide, True)
    _state.setdefault("pin_snap_latches", set()).discard(snap_key)
    return False


def _surface_contact_project_reachable_target(
    context,
    guide,
    point,
    normal,
    align_initial = False,
):
    point = Vector(point)
    normal = Vector(normal)
    if normal.length_squared <= 1.0e-12:
        return None
    normal.normalize()
    if (
        not align_initial
        or str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
        != SURFACE_CONTACT_KIND_IK
    ):
        return point, normal

    anchor = _surface_contact_stored_anchor_world(context, guide)
    reach_data = _surface_contact_solver_reach(context, guide)
    if anchor is None or reach_data is None:
        return point, normal
    pivot = Vector(reach_data[0])
    support_radius = (anchor - pivot).length
    signed_distance = normal.dot(pivot - point)
    if support_radius <= 1.0e-8 or abs(signed_distance) > support_radius:
        return point, normal

    circle_center = pivot - (normal * signed_distance)
    tangent = point - circle_center
    tangent -= normal * tangent.dot(normal)
    if tangent.length_squared <= 1.0e-12:
        tangent = anchor - circle_center
        tangent -= normal * tangent.dot(normal)
    if tangent.length_squared <= 1.0e-12:
        tangent = normal.orthogonal()
    tangent.normalize()
    circle_radius = math.sqrt(
        max(
            0.0,
            (support_radius * support_radius)
            - (signed_distance * signed_distance),
        )
    )
    reachable = circle_center + (tangent * circle_radius)

    surface = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_SURFACE_PROPERTY, ""))
    )
    if surface is not None:
        closest = _surface_contact_closest_point(
            surface,
            reachable,
            context.evaluated_depsgraph_get(),
            max(1.0, (reachable - point).length * 4.0),
        )
        if closest is not None:
            closest_point, closest_normal = closest
            tolerance = max(
                1.0e-4,
                float(
                    guide.get(SURFACE_CONTACT_SIZE_PROPERTY, 0.05)
                ) * 0.1,
            )
            if (
                abs((closest_point - pivot).length - support_radius)
                <= tolerance
            ):
                return closest_point, closest_normal
    return reachable, normal
