"""Frame-aware free-separation state for simulated surface contacts."""

from bisect import bisect_left

from ..core.runtime import *  # noqa: F403


def _surface_contact_detached_fcurves(guide):
    if guide is None:
        return ()
    action = _dynamic_parent_owner_action(guide)
    if action is None:
        return ()
    # Native Delete can remove an entire FCurve without replacing its Action.
    # Resolve live RNA instead of retaining curve wrappers across native edits.
    data_path = f'["{SURFACE_CONTACT_DETACHED_PROPERTY}"]'
    return tuple(_fcurves_find_all(action, data_path, guide))


def _surface_contact_invalidate_detached_key_cache(guide=None):
    _pin_curve_eval_clear()
    _state["surface_contact_detached_cache_revision"] = int(
        _state.get("surface_contact_detached_cache_revision", 0)
    ) + 1
    cache = _state.setdefault("surface_contact_detached_key_cache", {})
    attached_cache = _state.setdefault("surface_contact_attached_frame_cache", {})
    fcurve_cache = _state.setdefault("surface_contact_detached_fcurve_cache", {})
    frame_states = _state.setdefault("pin_snap_frame_animated_states", {})
    frame_state_frames = _state.setdefault(
        "pin_snap_frame_animated_state_frames", {}
    )
    attached_cache.clear()
    _state["surface_contact_attached_frame_cache_scope"] = None
    if guide is None:
        cache.clear()
        fcurve_cache.clear()
        frame_states.clear()
        frame_state_frames.clear()
        return
    snap_key = _surface_contact_snap_key(guide)
    frame_states.pop(snap_key, None)
    frame_state_frames.pop(snap_key, None)
    pointer = int(guide.as_pointer())
    for key in tuple(cache):
        if key and int(key[0]) == pointer:
            cache.pop(key, None)
    for key in tuple(fcurve_cache):
        if len(key) > 1 and int(key[1]) == pointer:
            fcurve_cache.pop(key, None)


def _surface_contact_cached_detached_keys(guide, fcurve):
    # A single playback callback asks about the same attachment repeatedly.
    # Share its immutable result only within that callback's existing read
    # scope; native edits/Undo and the next callback always reread live keys.
    cache = _state.get('special_event_reads')
    key = ('contact_detached', int(guide.as_pointer()), int(fcurve.as_pointer()),
           _state.get('surface_contact_detached_cache_revision', 0))
    if cache is not None and key in cache:
        return cache[key]
    result = _surface_contact_read_detached_keys(guide, fcurve)
    if cache is not None:
        cache[key] = result
    return result


def _surface_contact_read_detached_keys(guide, fcurve):
    # State keys generated alongside bone poses belong to that pose key.
    # Filter, rather than delete, orphaned states so native Undo restores both.
    start = float(guide.get(SURFACE_CONTACT_START_PROPERTY, SPACE_MIN_FRAME))
    linked = guide.get("Contact Pose Linked State Keys")
    if linked is None:
        # Older files paired non-start snap transitions with pose keys but
        # did not record that relationship explicitly.
        linked = [float(point.co.x) for point in fcurve.keyframe_points
                  if abs(float(point.co.x) - start) > 1e-5]
    linked = set(round(float(frame), 5) for frame in linked)
    _object, marker_owner = _surface_contact_owner_from_guide(guide)
    markers = _surface_contact_marker_points(marker_owner) if marker_owner else {}
    targets = {round(float(frame), 5) for frame in _surface_contact_target_frames(guide)
               if markers.get(frame, 0.0) >= .5}
    pose_frames = set()
    if linked:
        armature, bone = _surface_contact_pose_bone(guide)
        action = _dynamic_parent_owner_action(armature) if armature else None
        if action and bone:
            prefix = bone.path_from_id() + "."
            paths = {prefix + prop for prop in (
                "location", "rotation_euler", "rotation_quaternion",
                "rotation_axis_angle", "scale")}
            pose_frames = {round(float(point.co.x), 5)
                           for curve in _action_fcurves(action, armature)
                           if curve.data_path in paths
                           for point in curve.keyframe_points}
    pairs = sorted((float(point.co.x), float(point.co.y) >= 0.5)
                   for point in fcurve.keyframe_points
                   if round(float(point.co.x), 5) not in linked
                   or round(float(point.co.x), 5) in pose_frames
                   or round(float(point.co.x), 5) in targets
                   or abs(float(point.co.x) - start) <= 1e-5)
    return tuple(item[0] for item in pairs), tuple(item[1] for item in pairs)


def _surface_contact_keyed_detached_state(keys, frame):
    frames, states = keys
    if not frames:
        return None
    frame = float(frame)
    index = bisect_left(frames, frame)
    if index < len(frames) and abs(frames[index] - frame) <= 1.0e-5:
        return bool(states[index])
    if index > 0 and abs(frames[index - 1] - frame) <= 1.0e-5:
        return bool(states[index - 1])
    if index <= 0:
        return bool(states[0])
    if index >= len(frames):
        return bool(states[-1])
    return bool(states[index - 1] or states[index])


def _surface_contact_animated_detached_state(guide, frame):
    """Return keyed free state, anticipating a lift until its landing key."""
    for fcurve in _surface_contact_detached_fcurves(guide):
        policy = _pin_contact_curve_policy(guide)
        if any(not m.mute and m.type not in {'CYCLES', 'STEPPED', 'LIMITS'} for m in fcurve.modifiers):
            return _pin_curve_native_copy(fcurve, policy, logical=True).evaluate(frame) >= .5
        sample_frame = frame
        if policy is not None or _pin_curve_has_policy(fcurve):
            sample_frame = _pin_curve_native_copy(fcurve, policy, phase=True).evaluate(frame)
        state = _surface_contact_keyed_detached_state(
            _surface_contact_cached_detached_keys(guide, fcurve),
            sample_frame,
        )
        if state is not None:
            return state
    return None

def _surface_contact_attached_at_frame(guide, frame):
    """Return whether Contact remains attached at this frame."""
    # Query live authored keys: native edits can happen at the same frame,
    # without changing the guide cache generation or the property value.
    detached = _surface_contact_animated_detached_state(guide, frame)
    return (not detached if detached is not None
            else not bool(guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)))


def _surface_contact_keyframe_detached_state(guide, frame, detached):
    if (
        guide is None
        or not _surface_contact_snap_capable(guide)
    ):
        return False
    frame = int(frame)
    if "Contact Pose Linked State Keys" not in guide:
        start = float(guide.get(SURFACE_CONTACT_START_PROPERTY, frame))
        legacy = [float(point.co.x)
                  for curve in _surface_contact_detached_fcurves(guide)
                  for point in curve.keyframe_points
                  if abs(float(point.co.x) - start) > 1e-5]
        guide["Contact Pose Linked State Keys"] = legacy
    _surface_contact_invalidate_detached_key_cache(guide)
    data_path = f'["{SURFACE_CONTACT_DETACHED_PROPERTY}"]'
    bone_name = str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, "Contact"))
    group_name = f"Surface Contact State ({bone_name})"
    if not _surface_contact_detached_fcurves(guide):
        start = int(guide.get(SURFACE_CONTACT_START_PROPERTY, frame))
        if start != frame:
            guide[SURFACE_CONTACT_DETACHED_PROPERTY] = 0.0
            guide.keyframe_insert(
                data_path=data_path,
                frame=start,
                group=group_name,
            )
    guide[SURFACE_CONTACT_DETACHED_PROPERTY] = 1.0 if detached else 0.0
    guide.keyframe_insert(
        data_path=data_path,
        frame=frame,
        group=group_name,
    )
    action = _dynamic_parent_owner_action(guide)
    if action is None:
        return False
    animated_id = getattr(guide, "id_data", None) or guide
    end_key_type = "GENERATED" if bool(detached) else "KEYFRAME"
    for fcurve in _surface_contact_detached_fcurves(guide):
        _set_fcurve_group(
            fcurve,
            action,
            group_name,
        )
        _special_event_migrate_key_style(fcurve)
        fcurve.update()
    for fcurve in _action_fcurves(action, animated_id):
        if fcurve.data_path not in {
            "location",
            "rotation_euler",
            "rotation_quaternion",
            "rotation_axis_angle",
            data_path,
        }:
            continue
        for key in fcurve.keyframe_points:
            if abs(float(key.co.x) - float(frame)) <= 1.0e-5:
                key.type = end_key_type
        fcurve.update()
    _surface_contact_invalidate_detached_key_cache(guide)
    return True


def _surface_contact_key_live_detached_transition(context, guide):
    """Key a changed snap state while Blender still owns native G/R/S."""
    if context is None or guide is None:
        return False
    snap_key = _surface_contact_snap_key(guide)
    initial = _state.get("pin_snap_initial_attachment_states", {}).get(
        snap_key,
        {},
    )
    if initial.get("had_property", False):
        # The persisted state is the authored transform-start side. A
        # transient missing latch can occur while Blender evaluates the first
        # raw G/R/S sample; treating that as already detached prevents the
        # real pull-out from being keyed and lets the old attached key snap
        # the limb back on the next transform.
        initial_detached = bool(initial.get("property", False))
    else:
        initial_detached = bool(
            initial.get("detached", False)
            or not initial.get("latched", False)
        )
    final_detached = bool(
        snap_key in _state.setdefault("pin_snap_detached", set())
        or snap_key in _state.setdefault(
            "pin_snap_transform_releasing",
            set(),
        )
        or snap_key not in _state.setdefault("pin_snap_latches", set())
        or _surface_contact_pressure_commit_detached(context, guide)
    )
    keyed = _state.setdefault("pin_snap_live_detached_keyed", {})
    previous = keyed.get(snap_key, initial_detached)
    if bool(previous) == final_detached:
        return False
    armature, pose_bone = _surface_contact_pose_bone(guide)
    visible_basis = (
        pose_bone.matrix_basis.copy()
        if pose_bone is not None
        else None
    )
    state_is_animated = bool(_surface_contact_detached_fcurves(guide))
    should_key = bool(
        state_is_animated
        or getattr(
            context.scene.tool_settings,
            "use_keyframe_insert_auto",
            False,
        )
    )
    if should_key:
        _surface_contact_keyframe_detached_state(
            guide,
            int(context.scene.frame_current),
            final_detached,
        )
        # Attachment state and the solved pink-bone pose are one animation
        # transaction. Keying only the state left an older pose at the snapped
        # boundary; playback teleported until the user manually refreshed that
        # bone key. Persist the exact visible basis alongside every animated
        # snap/unsnap transition, independent of global Auto Key.
        _surface_contact_keyframe_simulated_pose(
            guide,
            int(context.scene.frame_current),
        )
        # Inserting the guide's state key can reevaluate a shared Action while
        # native G/R/S is still open. Preserve the already-solved authored
        # pose; otherwise the key insertion itself resets the limb and
        # mouse-up looks like Contact snapped back.
        if pose_bone is not None and visible_basis is not None:
            pose_bone.matrix_basis = visible_basis
            context.view_layer.update()
    else:
        # A previously unanimated Contact follows Blender's normal Auto Key
        # policy. Creating a new Guide Action inside an armature G/R/S causes
        # Blender to reevaluate that separate ID after the mouse sample and
        # restore its old detached property. Keep the modal property/runtime
        # state instead; the paired Contact history transition restores this
        # exact side on Undo/Redo without an invisible Action mutation.
        _surface_contact_set_snap_detached(guide, final_detached)
    keyed[snap_key] = final_detached
    return True


def _surface_contact_pressure_commit_detached(context, guide):
    """Return whether a confirmed top-pivot pose ends away from its pin."""
    if context is None or guide is None:
        return False
    snap_key = _surface_contact_snap_key(guide)
    if snap_key not in _state.setdefault("pin_snap_pressure_active", set()):
        return False
    if not _surface_contact_guide_directly_selected(context, guide):
        return False
    target, _normal, anchor = _surface_contact_world_point_normal(
        context,
        guide,
    )
    return bool(
        target is not None
        and anchor is not None
        and (Vector(anchor) - Vector(target)).length
        > PIN_SNAP_WORLD_RADIUS
        and not _pin_points_within_snap_radius(
            context,
            target,
            anchor,
            pixel_radius=PIN_SNAP_PIXEL_RADIUS,
        )
    )


def _surface_contact_commit_target_key(context, guide, detached = None, *, key_pose=True):
    """Persist the already-previewed target and its attachment state."""
    if not _contact_chain_uses_contact(guide):
        # The purple handle is an IK posing widget. Ordinary FK channels own
        # its result; it has no independent target or special edit key.
        if key_pose:
            _contact_chain_commit_pose(context,guide)
            _contact_chain_key_confirmed_inputs(context,guides=(guide,))
        _surface_contact_seed_runtime_signatures(context,(guide,))
        _tag_redraw_all_view3d()
        return
    pending_basis=guide.matrix_basis.copy()
    if key_pose and guide.get(SURFACE_CONTACT_KIND_PROPERTY)==SURFACE_CONTACT_KIND_CHAIN:
        _contact_chain_commit_pose(context,guide)
        _contact_chain_key_confirmed_inputs(context,guides=(guide,))
        # FK conversion reads evaluated parents and may replay this guide's
        # old Action. Key the pending target, never that intermediate replay.
        guide.matrix_basis=pending_basis.copy()
    armature, _bone = _surface_contact_pose_bone(guide)
    bases = _pin_capture_action_pose_bases((armature,)) if armature is not None else {}
    frame = int(context.scene.frame_current)
    bone_name = str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, "Contact"))
    _surface_contact_keyframe_guide_transform(guide, frame, bone_name)
    if detached is None:
        detached = bool(
            guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)
        )
    _surface_contact_keyframe_detached_state(guide, frame, bool(detached))
    start = int(guide.get(SURFACE_CONTACT_START_PROPERTY, frame))
    if frame != start:
        target_frames = set(_surface_contact_target_frames(guide))
        target_frames.add(frame)
        _surface_contact_set_target_frames(guide, target_frames)
    _marker_object, marker_owner = _surface_contact_owner_from_guide(guide)
    if marker_owner is not None:
        _surface_contact_insert_marker(
            marker_owner,
            bone_name,
            frame,
            1.0,
        )
        _surface_contact_rebuild_markers(marker_owner, bone_name)
    if key_pose and _surface_contact_snap_capable(guide):
        _surface_contact_keyframe_simulated_pose(guide, frame)
        if (
            str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
            == SURFACE_CONTACT_KIND_SIMULATED
        ):
            _surface_contact_store_owner_pose_base(guide)
    # A marker on one limb dirties the whole owning Action. Preserve every
    # already solved limb through that flush, not only the edited pin's bone.
    _pin_restore_action_pose_bases(context, bases)
    guide.matrix_basis=pending_basis.copy()
    if key_pose and _bone is not None:
        _ragdoll_commit_start_transition(context, (_bone,))
    _surface_contact_seed_runtime_signatures(context, (guide,))
    guide.matrix_basis=pending_basis.copy()
    _tag_redraw_all_view3d()


def _surface_contact_finalize_snap_departures(context, *, anchor_overrides=None):
    departing = _state.setdefault("pin_snap_departing", set())
    seen = _state.setdefault("pin_snap_transform_seen", set())
    initial_states = _state.setdefault("pin_snap_initial_detached", {})
    if not departing and not seen:
        return False
    changed = False
    frame = int(context.scene.frame_current)
    for guide in _surface_contact_active_snap_guides(context.scene):
        key = _surface_contact_snap_key(guide)
        if key not in departing and key not in seen:
            continue
        target, _normal, anchor = _surface_contact_world_point_normal(
            context,
            guide,
        )
        anchor = (anchor_overrides or {}).get(guide.name, anchor)
        explicitly_detached = key in _state.setdefault(
            "pin_snap_detached",
            set(),
        )
        directly_engaged = key in _state.setdefault(
            "pin_snap_transform_engaged",
            set(),
        )
        if directly_engaged:
            explicitly_detached = False
        initial_detached = initial_states.pop(
            key,
            _surface_contact_animated_detached_state(guide, frame),
        )
        started_attached = bool(
            key in _state.setdefault("pin_snap_initial_latches", set())
            or _state.get("pin_snap_parent_attachment_states", {}).get(
                guide.name,
                False,
            )
            or initial_detached is False
        )
        explicitly_released = key in _state.setdefault(
            "pin_snap_transform_releasing", set()
        )
        endpoint_distance = (
            (Vector(target) - Vector(anchor)).length
            if target is not None and anchor is not None
            else 0.0
        )
        outside_release_ring = bool(
            target is not None
            and anchor is not None
            and not _pin_points_within_snap_radius(
                context,
                target,
                anchor,
                pixel_radius=PIN_SNAP_RELEASE_PIXEL_RADIUS,
            )
        )
        if (
            not explicitly_released
            and key in seen
            and _surface_contact_guide_directly_selected(context, guide)
            and key not in _state.setdefault("pin_snap_pressure_active", set())
            and outside_release_ring
        ):
            # A native transform callback can occasionally arrive only after
            # Blender has already replaced its raw pose with the last solved
            # one. If confirmation still leaves the real pink endpoint well
            # outside the release band, the visible authored result is an
            # unambiguous pull-out. Do not preserve an outer ring on a limb
            # that is visibly separated from the target.
            explicitly_released = True
            explicitly_detached = True
            _state.setdefault("pin_snap_transform_releasing", set()).add(key)
        if _surface_contact_pressure_commit_detached(context, guide):
            # Keep the pressure arc continuous while G is modal, then publish
            # the lifted final pose as a real detach at confirmation. Leaving
            # it marked attached makes later depsgraph/history evaluation
            # "repair" the bottom endpoint back to the pin and ignore the
            # exact pose Blender just restored.
            explicitly_released = True
            explicitly_detached = True
            _state.setdefault("pin_snap_transform_releasing", set()).add(key)
            _state.setdefault(
                "pin_snap_pressure_committed_detached", set()
            ).add(key)
        geometrically_attached = bool(
            target is not None
            and anchor is not None
            and (
                (Vector(target) - Vector(anchor)).length <= 1.0e-7
                or _pin_points_within_snap_radius(context, target, anchor)
            )
        )
        direct_geometric_engagement = bool(
            geometrically_attached
            and not explicitly_released
            and _surface_contact_guide_directly_selected(context, guide)
        )
        # A transform that began snapped remains snapped unless the directly
        # edited pink bone explicitly pulled out. Pressure can intentionally
        # lift the visible bottom while the imaginary top pivots, so endpoint
        # overlap is not a valid detach test for torso/ancestor movement.
        attached = bool(
            (directly_engaged and not explicitly_released)
            or direct_geometric_engagement
            or (
                started_attached
                and not explicitly_released
                and geometrically_attached
            )
            or (
                not started_attached
                and not explicitly_detached
                and geometrically_attached
            )
        )
        if attached:
            _surface_contact_clear_snap_departure(guide)
            # Clearing departure also clears transient snap state. Restore the
            # confirmed latch so Contact behaves like Onion after mouse-up:
            # the next transform begins snapped instead of requiring a second
            # click to rediscover the entry radius.
            _state.setdefault("pin_snap_latches", set()).add(key)
            if target is not None:
                _state.setdefault("pin_snap_previous_points", {})[key] = (
                    Vector(target).copy()
                )
        else:
            departing.discard(key)
            seen.discard(key)
            _surface_contact_set_snap_detached(guide, True)
            _state.setdefault("pin_snap_latches", set()).discard(key)
        final_detached = not attached
        live_keyed_state = _state.setdefault(
            "pin_snap_live_detached_keyed",
            {},
        ).get(key)
        if (
            live_keyed_state is None
            and (
                initial_detached is None
                or bool(initial_detached) != final_detached
            )
        ) or (
            live_keyed_state is not None
            and bool(live_keyed_state) != final_detached
        ):
            _surface_contact_keyframe_detached_state(
                guide,
                frame,
                final_detached,
            )
            _surface_contact_keyframe_simulated_pose(guide, frame)
        changed = True
    return changed
