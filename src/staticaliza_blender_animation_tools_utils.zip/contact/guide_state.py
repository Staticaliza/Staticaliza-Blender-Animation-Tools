"""Surface-contact guide state, keyframes, and marker maintenance."""

from ..core.runtime import *  # noqa: F403

def _surface_contact_create_guide(
    context,
    armature,
    effector,
    target_object,
    target_bone_name,
    geometry_bone_name,
    anchor_world,
    surface_object,
    surface_point,
    surface_normal,
    bone_length,
    frame,
):
    digest = hashlib.sha1(
        f"{armature.name}:{effector.name}:{int(frame)}:{time.time_ns()}".encode(
            "utf-8"
        )
    ).hexdigest()[:12]
    guide = bpy.data.objects.new(f"_SurfaceContactGuide_{digest}", None)
    _ensure_space_helper_collection(context, armature).objects.link(guide)
    guide[SURFACE_CONTACT_GUIDE_PROPERTY] = True
    guide[SURFACE_CONTACT_ARMATURE_PROPERTY] = armature.name
    guide[SURFACE_CONTACT_BONE_PROPERTY] = effector.name
    guide[SURFACE_CONTACT_CONTROL_OBJECT_PROPERTY] = target_object.name
    guide[SURFACE_CONTACT_CONTROL_BONE_PROPERTY] = target_bone_name
    guide[SURFACE_CONTACT_GEOMETRY_BONE_PROPERTY] = str(geometry_bone_name)
    guide[SURFACE_CONTACT_START_PROPERTY] = int(frame)
    guide[SURFACE_CONTACT_SIZE_PROPERTY] = max(0.04, float(bone_length) * 0.18)
    guide.empty_display_type = "CIRCLE"
    guide.empty_display_size = float(guide[SURFACE_CONTACT_SIZE_PROPERTY])
    guide.color = SURFACE_CONTACT_HOT_PINK
    guide.hide_render = True
    guide.hide_select = True
    guide.rotation_mode = "QUATERNION"

    guide.matrix_world = anchor_world
    if surface_object is not None:
        depsgraph = context.evaluated_depsgraph_get()
        follow_object, follow_bone = _surface_contact_surface_binding(
            surface_object,
            surface_point,
            depsgraph,
        )
        follow_world = surface_object.matrix_world
        if follow_object is not None and follow_bone:
            try:
                evaluated_follow = follow_object.evaluated_get(depsgraph)
                evaluated_bone = evaluated_follow.pose.bones.get(follow_bone)
                if evaluated_bone is not None:
                    follow_world = (
                        evaluated_follow.matrix_world @ evaluated_bone.matrix
                    )
            except (AttributeError, ReferenceError, RuntimeError):
                pass
        elif follow_object is not None:
            try:
                follow_world = follow_object.evaluated_get(depsgraph).matrix_world
            except (AttributeError, ReferenceError, RuntimeError):
                follow_world = follow_object.matrix_world
        local_guide_matrix = follow_world.inverted_safe() @ anchor_world
        guide[SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY] = tuple(
            float(value)
            for row in local_guide_matrix
            for value in row
        )
        guide[SURFACE_CONTACT_SURFACE_PROPERTY] = surface_object.name
        local_point = surface_object.matrix_world.inverted_safe() @ surface_point
        local_normal = surface_object.matrix_world.to_3x3().transposed() @ surface_normal
        if local_normal.length_squared > 1.0e-12:
            local_normal.normalize()
        guide[SURFACE_CONTACT_POINT_PROPERTY] = tuple(local_point)
        guide[SURFACE_CONTACT_NORMAL_PROPERTY] = tuple(local_normal)
        guide[SURFACE_CONTACT_LABEL_PROPERTY] = (
            _surface_contact_surface_display_label(
                surface_object,
                surface_point,
                depsgraph,
            )
        )
        _surface_contact_parent_guide(
            guide,
            follow_object or surface_object,
            follow_bone,
            anchor_world,
        )
    else:
        guide[SURFACE_CONTACT_SURFACE_PROPERTY] = ""
        guide[SURFACE_CONTACT_POINT_PROPERTY] = tuple(surface_point)
        guide[SURFACE_CONTACT_NORMAL_PROPERTY] = tuple(surface_normal)
        guide[SURFACE_CONTACT_FOLLOW_OBJECT_PROPERTY] = ""
        guide[SURFACE_CONTACT_FOLLOW_BONE_PROPERTY] = ""
    try:
        guide.hide_set(True)
    except RuntimeError:
        pass
    _surface_contact_invalidate_guide_cache()
    context.view_layer.update()
    guide[SURFACE_CONTACT_INITIAL_GUIDE_MATRIX_PROPERTY] = tuple(
        float(value)
        for row in guide.matrix_world
        for value in row
    )
    return guide


def _surface_contact_owner_from_guide(guide):
    target_object = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_CONTROL_OBJECT_PROPERTY, ""))
    )
    if target_object is None:
        return None, None
    bone_name = str(guide.get(SURFACE_CONTACT_CONTROL_BONE_PROPERTY, ""))
    if bone_name and getattr(target_object, "pose", None):
        return target_object, target_object.pose.bones.get(bone_name)
    return target_object, target_object


def _surface_contact_constraint_owner_from_guide(guide):
    target_object = bpy.data.objects.get(
        str(
            guide.get(
                SURFACE_CONTACT_CONSTRAINT_OBJECT_PROPERTY,
                guide.get(SURFACE_CONTACT_CONTROL_OBJECT_PROPERTY, ""),
            )
        )
    )
    if target_object is None:
        return None, None
    bone_name = str(
        guide.get(
            SURFACE_CONTACT_CONSTRAINT_BONE_PROPERTY,
            guide.get(SURFACE_CONTACT_CONTROL_BONE_PROPERTY, ""),
        )
    )
    if bone_name and getattr(target_object, "pose", None):
        return target_object, target_object.pose.bones.get(bone_name)
    return target_object, target_object


def _surface_contact_solver_from_guide(guide):
    return bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_SOLVER_OBJECT_PROPERTY, ""))
    )


def _surface_contact_simulated_pose_bone(guide):
    if (
        guide is None
        or str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
        != SURFACE_CONTACT_KIND_SIMULATED
    ):
        return None
    armature = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
    )
    if armature is None or getattr(armature, "pose", None) is None:
        return None
    return armature.pose.bones.get(
        str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
    )


def _surface_contact_simulated_pose_matrix(guide):
    pose_bone = _surface_contact_simulated_pose_bone(guide)
    return pose_bone.matrix.copy() if pose_bone is not None else None


def _surface_contact_keyframe_simulated_pose(guide, frame):
    pose_bone = _surface_contact_simulated_pose_bone(guide)
    if pose_bone is None:
        return False
    # The solver has already authored the exact local basis. Visual keying
    # evaluates the active Contact/parent constraints a second time and can
    # store a different pose that only appears after the history lock clears.
    _insert_bone_keys(pose_bone, int(frame), visual=False)
    linked = set(float(value) for value in guide.get("Contact Pose Linked State Keys", ()))
    linked.add(float(frame))
    guide["Contact Pose Linked State Keys"] = sorted(linked)
    return True


def _surface_contact_restore_simulated_pose(
    context,
    guide,
    matrix,
    update_view_layer = True,
):
    if matrix is None:
        return False
    pose_bone = _surface_contact_simulated_pose_bone(guide)
    if pose_bone is None:
        return False
    pose_bone.matrix = matrix.copy()
    if update_view_layer:
        context.view_layer.update()
    return True


def _surface_contact_store_solver_local_matrix(guide):
    solver = _surface_contact_solver_from_guide(guide)
    if solver is None:
        return False
    local_matrix = guide.matrix_world.inverted_safe() @ solver.matrix_world
    guide[SURFACE_CONTACT_SOLVER_LOCAL_MATRIX_PROPERTY] = tuple(
        float(value)
        for row in local_matrix
        for value in row
    )
    return True


def _surface_contact_update_control_solver(guide):
    if (
        str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
        != SURFACE_CONTACT_KIND_CONTROL
    ):
        return False
    solver = _surface_contact_solver_from_guide(guide)
    values = guide.get(SURFACE_CONTACT_SOLVER_LOCAL_MATRIX_PROPERTY)
    if solver is None:
        return False
    if values is None or len(values) < 16:
        return _surface_contact_store_solver_local_matrix(guide)
    try:
        local_matrix = Matrix(
            tuple(
                tuple(
                    float(values[(row * 4) + column])
                    for column in range(4)
                )
                for row in range(4)
            )
        )
        desired_world = guide.matrix_world @ local_matrix
        current_world = solver.matrix_world
        translation_changed = (
            desired_world.translation - current_world.translation
        ).length > 1.0e-7
        rotation_changed = desired_world.to_quaternion().rotation_difference(
            current_world.to_quaternion()
        ).angle > 1.0e-7
        if not translation_changed and not rotation_changed:
            return False
        solver.matrix_world = desired_world
        return True
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return False


def _surface_contact_constraints(guide):
    _target_object, owner = _surface_contact_constraint_owner_from_guide(guide)
    if owner is None:
        return None, None
    primary = owner.constraints.get(
        str(guide.get(SURFACE_CONTACT_PRIMARY_PROPERTY, ""))
    )
    secondary_name = str(guide.get(SURFACE_CONTACT_SECONDARY_PROPERTY, ""))
    secondary = owner.constraints.get(secondary_name) if secondary_name else None
    return primary, secondary


def _surface_contact_configure_rotation_constraint(constraint, solver):
    if constraint is None or solver is None or constraint.type != "COPY_ROTATION":
        return False
    changed = False
    desired = (
        ("target", solver),
        ("owner_space", "WORLD"),
        ("target_space", "WORLD"),
    )
    for property_name, value in desired:
        if getattr(constraint, property_name, None) != value:
            setattr(constraint, property_name, value)
            changed = True
    if hasattr(constraint, "mix_mode") and constraint.mix_mode != "REPLACE":
        constraint.mix_mode = "REPLACE"
        changed = True
    return changed


def _surface_contact_create_rotation_constraint(owner, solver, name):
    if owner is None or solver is None:
        return None
    constraint = owner.constraints.new("COPY_ROTATION")
    constraint.name = str(name)
    _surface_contact_configure_rotation_constraint(constraint, solver)
    constraint.influence = 0.0
    return constraint


def _surface_contact_ensure_control_rotation_constraint(context, guide):
    if (
        str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
        != SURFACE_CONTACT_KIND_CONTROL
    ):
        return False
    solver = _surface_contact_solver_from_guide(guide)
    target_object, owner = _surface_contact_constraint_owner_from_guide(guide)
    if solver is None or target_object is None or owner is None:
        return False

    bone_name = str(
        guide.get(
            SURFACE_CONTACT_CONSTRAINT_BONE_PROPERTY,
            guide.get(SURFACE_CONTACT_CONTROL_BONE_PROPERTY, ""),
        )
    )
    changed = False
    if int(guide.get(SURFACE_CONTACT_ROTATION_BINDING_PROPERTY, 0)) < 1:
        owner_world = _surface_contact_target_world_matrix(
            context,
            target_object,
            bone_name,
        )
        if owner_world is not None:
            solver_world = owner_world.normalized()
            solver_world.translation = solver.matrix_world.translation.copy()
            solver.matrix_world = solver_world
            context.view_layer.update()
            _surface_contact_store_solver_local_matrix(guide)
            changed = True

    _primary, secondary = _surface_contact_constraints(guide)
    if secondary is not None and secondary.type == "COPY_ROTATION":
        changed = (
            _surface_contact_configure_rotation_constraint(secondary, solver)
            or changed
        )
        guide[SURFACE_CONTACT_ROTATION_BINDING_PROPERTY] = 1
        return changed
    if secondary is not None:
        if not _surface_contact_remove_constraint(owner, secondary):
            return changed
        changed = True

    digest = guide.name.rsplit("_", 1)[-1]
    secondary = _surface_contact_create_rotation_constraint(
        owner,
        solver,
        f"{SURFACE_CONTACT_CONSTRAINT_PREFIX}{digest}_Aim",
    )
    if secondary is None:
        return changed
    guide[SURFACE_CONTACT_SECONDARY_PROPERTY] = secondary.name
    guide[SURFACE_CONTACT_ROTATION_BINDING_PROPERTY] = 1
    return True


def _surface_contact_insert_marker(owner, bone_name, frame, value):
    if owner is None:
        return False
    property_path = f'["{SURFACE_CONTACT_MARKER_PROPERTY}"]'
    target_key = float(value) >= 0.5
    existing_style = _surface_contact_marker_key_style(
        owner,
        frame,
        target_key = target_key,
    )
    owner[SURFACE_CONTACT_MARKER_PROPERTY] = float(value)
    owner.keyframe_insert(data_path = property_path, frame = int(frame))
    action = _dynamic_parent_owner_action(owner)
    animated_id = getattr(owner, "id_data", None) or owner
    if action is not None:
        data_path = owner.path_from_id(property_path)
        for fcurve in _fcurves_find_all(action, data_path, animated_id):
            for key in fcurve.keyframe_points:
                if abs(float(key.co.x) - float(frame)) > 1.0e-5:
                    continue
                style = dict(
                    existing_style
                    or _surface_contact_key_style(
                        None,
                        target_key = target_key,
                    )
                )
                style["type"] = (
                    "KEYFRAME" if target_key else "GENERATED"
                )
                _surface_contact_apply_key_style(key, style)
            _set_fcurve_group(
                fcurve,
                action,
                f"Surface Contact ({bone_name})",
            )
            fcurve.update()
    return True


def _surface_contact_target_frames(guide):
    values = guide.get(SURFACE_CONTACT_TARGET_FRAMES_PROPERTY, ())
    frames = []
    for value in values:
        try:
            frames.append(int(value))
        except (TypeError, ValueError):
            continue
    return tuple(sorted(set(frames)))


def _surface_contact_set_target_frames(guide, frames):
    guide[SURFACE_CONTACT_TARGET_FRAMES_PROPERTY] = sorted(
        {int(frame) for frame in frames}
    )


def _surface_contact_strip_scale_animation(guide):
    action = _dynamic_parent_owner_action(guide)
    if action is None:
        return False
    changed = False
    animated_id = getattr(guide, "id_data", None) or guide
    for fcurve in tuple(_fcurves_find_all(action, "scale", animated_id)):
        changed = _action_remove_fcurve(action, fcurve) or changed
    return changed


def _surface_contact_keyframe_guide_transform(guide, frame, bone_name):
    frame = int(frame)
    _surface_contact_strip_scale_animation(guide)
    rotation_path = (
        "rotation_quaternion"
        if guide.rotation_mode == "QUATERNION"
        else "rotation_axis_angle"
        if guide.rotation_mode == "AXIS_ANGLE"
        else "rotation_euler"
    )
    animated_id = getattr(guide, "id_data", None) or guide
    previous_keys = set()
    previous_action = _dynamic_parent_owner_action(guide)
    if previous_action is not None:
        for data_path in ("location", rotation_path):
            for fcurve in _fcurves_find_all(
                previous_action,
                data_path,
                animated_id,
            ):
                if any(
                    abs(float(key.co.x) - float(frame)) <= 1.0e-5
                    for key in fcurve.keyframe_points
                ):
                    previous_keys.add(
                        (data_path, int(getattr(fcurve, "array_index", 0)))
                    )

    guide.keyframe_insert(data_path = "location", frame = frame)
    guide.keyframe_insert(data_path = rotation_path, frame = frame)

    action = _dynamic_parent_owner_action(guide)
    if action is None:
        return False
    for data_path in ("location", rotation_path):
        for fcurve in _fcurves_find_all(action, data_path, animated_id):
            _set_fcurve_group(
                fcurve,
                action,
                f"Surface Contact Target ({bone_name})",
            )
            for key in fcurve.keyframe_points:
                if abs(float(key.co.x) - float(frame)) > 1.0e-5:
                    continue
                key_id = (
                    data_path,
                    int(getattr(fcurve, "array_index", 0)),
                )
                if key_id in previous_keys:
                    continue
                key.interpolation = "BEZIER"
            fcurve.update()
    return True


def _surface_contact_delete_guide_transform_keys(guide, frame):
    action = _dynamic_parent_owner_action(guide)
    if action is None:
        return False
    changed = False
    animated_id = getattr(guide, "id_data", None) or guide
    paths = ("location", "rotation_euler", "rotation_quaternion", "rotation_axis_angle")
    for data_path in paths:
        for fcurve in tuple(_fcurves_find_all(action, data_path, animated_id)):
            for key in tuple(fcurve.keyframe_points):
                if abs(float(key.co.x) - float(frame)) <= 1.0e-5:
                    fcurve.keyframe_points.remove(key)
                    changed = True
            if not fcurve.keyframe_points:
                _action_remove_fcurve(action, fcurve)
            else:
                fcurve.update()
    return changed


def _surface_contact_marker_points(owner):
    action = _dynamic_parent_owner_action(owner)
    if action is None:
        return {}
    try:
        data_path = (
            owner.path_from_id()
            + f'["{SURFACE_CONTACT_MARKER_PROPERTY}"]'
        )
    except (AttributeError, TypeError, ValueError):
        return {}
    points = {}
    animated_id = getattr(owner, "id_data", None) or owner
    for fcurve in _fcurves_find_all(action, data_path, animated_id):
        for key in fcurve.keyframe_points:
            points[int(round(float(key.co.x)))] = float(key.co.y)
    return points


def _surface_contact_guide_matches_owner(guide, owner):
    animated_id = getattr(owner, "id_data", None) or owner
    return bool(
        str(guide.get(SURFACE_CONTACT_CONTROL_OBJECT_PROPERTY, ""))
        == str(getattr(animated_id, "name", ""))
        and str(guide.get(SURFACE_CONTACT_CONTROL_BONE_PROPERTY, ""))
        == str(getattr(owner, "name", ""))
    )


def _surface_contact_expected_markers(owner, excluded_guide = None):
    expected = {}
    matching_guides = tuple(
        guide
        for guide in _surface_contact_guides()
        if guide != excluded_guide
        and _surface_contact_guide_matches_owner(guide, owner)
    )
    for guide in matching_guides:
        if SURFACE_CONTACT_END_PROPERTY in guide:
            expected[int(guide[SURFACE_CONTACT_END_PROPERTY])] = 0.0
    # A retarget boundary is both an old release and a new contact. One start
    # marker wins so the Dope Sheet contains a single key at that frame.
    for guide in matching_guides:
        expected[int(guide.get(SURFACE_CONTACT_START_PROPERTY, 0))] = 1.0
        for frame in _surface_contact_target_frames(guide):
            expected[int(frame)] = 1.0
    return expected


def _surface_contact_rebuild_markers(owner, bone_name, excluded_guide = None):
    if owner is None:
        return False
    action = _dynamic_parent_owner_action(owner)
    property_path = f'["{SURFACE_CONTACT_MARKER_PROPERTY}"]'
    try:
        data_path = owner.path_from_id() + property_path
    except (AttributeError, TypeError, ValueError):
        return False
    animated_id = getattr(owner, "id_data", None) or owner
    expected = _surface_contact_expected_markers(owner, excluded_guide)
    if not expected:
        changed = False
        if action is not None:
            for fcurve in tuple(
                _fcurves_find_all(action, data_path, animated_id)
            ):
                changed = _action_remove_fcurve(action, fcurve) or changed
        if SURFACE_CONTACT_MARKER_PROPERTY in owner:
            del owner[SURFACE_CONTACT_MARKER_PROPERTY]
            changed = True
        return changed

    if action is None:
        first_frame, first_value = min(expected.items())
        owner[SURFACE_CONTACT_MARKER_PROPERTY] = float(first_value)
        owner.keyframe_insert(
            data_path = property_path,
            frame = int(first_frame),
        )
        action = _dynamic_parent_owner_action(owner)
    if action is None:
        return False

    fcurves = list(_fcurves_find_all(action, data_path, animated_id))
    if fcurves:
        fcurve = fcurves[0]
        for duplicate in fcurves[1:]:
            _action_remove_fcurve(action, duplicate)
    else:
        fcurve = _action_new_fcurve(action, data_path, animated_id)
    styles_by_frame = {
        int(round(float(key.co.x))): (
            float(key.co.y) >= 0.5,
            _surface_contact_key_style(
                key,
                target_key = float(key.co.y) >= 0.5,
            ),
        )
        for key in fcurve.keyframe_points
    }
    while fcurve.keyframe_points:
        fcurve.keyframe_points.remove(fcurve.keyframe_points[-1])
    for frame, value in sorted(expected.items()):
        key = fcurve.keyframe_points.insert(
            float(frame),
            float(value),
            options = {"FAST"},
        )
        target_key = float(value) >= 0.5
        prior = styles_by_frame.get(int(frame))
        style = (
            prior[1]
            if prior is not None and bool(prior[0]) == target_key
            else _surface_contact_key_style(None, target_key = target_key)
        )
        style = dict(style)
        style["type"] = "KEYFRAME" if target_key else "GENERATED"
        _surface_contact_apply_key_style(key, style)
    _set_fcurve_group(
        fcurve,
        action,
        f"Surface Contact ({bone_name})",
    )
    fcurve.update()

    for guide in _surface_contact_guides():
        if (
            guide != excluded_guide
            and _surface_contact_guide_matches_owner(guide, owner)
        ):
            _surface_contact_sync_guide_key_styles(owner, guide)

    current_frame = int(getattr(bpy.context.scene, "frame_current", 0))
    owner[SURFACE_CONTACT_MARKER_PROPERTY] = 1.0 if any(
        _surface_contact_guide_matches_owner(guide, owner)
        and guide != excluded_guide
        and _surface_contact_guide_active_at(guide, current_frame)
        for guide in _surface_contact_guides()
    ) else 0.0
    return True


def _surface_contact_remove_markers(guide, owner):
    if owner is None:
        return False
    return _surface_contact_rebuild_markers(
        owner,
        str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, getattr(owner, "name", ""))),
        excluded_guide = guide,
    )


def _surface_contact_guide_has_transform_animation(guide):
    action = _dynamic_parent_owner_action(guide)
    if action is None:
        return False
    animated_id = getattr(guide, "id_data", None) or guide
    return any(
        fcurve.keyframe_points
        for data_path in (
            "location",
            "rotation_euler",
            "rotation_quaternion",
            "rotation_axis_angle",
        )
        for fcurve in _fcurves_find_all(action, data_path, animated_id)
    )


def _surface_contact_update_guide_transform(guide):
    if getattr(guide, "parent", None) is not None:
        return False
    follow_object = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_FOLLOW_OBJECT_PROPERTY, ""))
    )
    if follow_object is None:
        follow_object = bpy.data.objects.get(
            str(guide.get(SURFACE_CONTACT_SURFACE_PROPERTY, ""))
        )
    follow_bone = str(guide.get(SURFACE_CONTACT_FOLLOW_BONE_PROPERTY, ""))
    values = guide.get(SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY)
    if follow_object is None:
        return False
    world_matrix = guide.matrix_world.copy()
    try:
        animated = _surface_contact_guide_has_transform_animation(guide)
        if animated:
            # Animation curves store the guide's parent-local transform. If a
            # reload/update temporarily loses the parent, retain the evaluated
            # keyed local pose instead of replacing it with the latest static
            # GUIDE_LOCAL_MATRIX value.
            local_matrix = guide.matrix_basis.copy()
        elif values is not None and len(values) >= 16:
            local_matrix = Matrix(
                tuple(
                    tuple(
                        float(values[(row * 4) + column])
                        for column in range(4)
                    )
                    for row in range(4)
                )
            )
        else:
            local_matrix = None
        if local_matrix is not None:
            if follow_bone and getattr(follow_object, "pose", None) is not None:
                follow_pose_bone = follow_object.pose.bones.get(follow_bone)
                if follow_pose_bone is not None:
                    follow_world = follow_object.matrix_world @ follow_pose_bone.matrix
                else:
                    follow_world = follow_object.matrix_world
            else:
                follow_world = follow_object.matrix_world
            world_matrix = follow_world @ local_matrix
        return _surface_contact_parent_guide(
            guide,
            follow_object,
            follow_bone,
            world_matrix,
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return False


def _surface_contact_order_constraints(owner, secondary, primary):
    if owner is None:
        return False
    changed = False
    for constraint in (secondary, primary):
        if constraint is None:
            continue
        try:
            current_index = owner.constraints.find(constraint.name)
            desired_index = len(owner.constraints) - 1
            if current_index >= 0 and current_index != desired_index:
                owner.constraints.move(current_index, desired_index)
                changed = True
        except (AttributeError, ReferenceError, RuntimeError, ValueError):
            pass
    return changed
