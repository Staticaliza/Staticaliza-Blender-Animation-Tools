"""Contact-only chain configuration and one deterministic output publication."""

from ..core.runtime import *  # noqa: F403
from bpy_extras import view3d_utils
from types import SimpleNamespace

CONTACT_SURFACE_ITEMS=(('COLLIDE','On','Prevent penetration without surface alignment'),
    ('PLANT','Aligned','Collision with alignment to the touched surface'),
    ('CLIP','Off','Disable collision and surface alignment'))


def _contact_surface_items(self,_context):
    return CONTACT_SURFACE_ITEMS if self.ik_enabled else CONTACT_SURFACE_ITEMS[:2]


def _contact_surface_get(self):
    return 2 if self.ik_enabled and self.clip else 1 if self.planted else 0


def _contact_surface_set(self,value):
    self.clip=value==2
    self.planted=value==1


def _contact_control_get(self):return int(self.ik_enabled)


def _contact_control_set(self,value):self.ik_enabled=bool(value)


def _contact_chain_color(guide,*,driven=False):
    if not _contact_chain_uses_contact(guide):return IK_CHAIN_COLOR if driven else IK_COLOR
    return CONTACT_CHAIN_COLOR if driven else DYNAMIC_CONTACT_COLOR


def _contact_surface_label(guide):
    index=(2 if not _contact_chain_uses_contact(guide) and guide.get('Contact Clip',False)
           else 1 if _contact_chain_is_planted(guide) else 0)
    return ('Collision','Aligned Collision','No Collision')[index]


def _contact_chain_handle_visible(guide):
    owner,bone=_surface_contact_pose_bone(guide)
    return bool(bone is not None and _pose_bone_is_visible(bone) and
        (getattr(bone,'select',getattr(bone.bone,'select',False))
         or _surface_contact_snap_key(guide) in _pin_selected_target_keys()))


def _draw_constraint_configuration(layout, *, kind, position, axis, chain, bend, ik,
                                   planted=None, clip=None, surface=None, count=0, ik_enabled=False, bend_available=True):
    """Identical ordering and visibility for sidebar and native redo inputs."""
    layout.prop(*position,text='Position')
    layout.prop(*axis,text='Axis')
    if kind!='GYRO':
        row=layout.row(align=True) if count>0 and bend_available else layout
        row.prop(*chain,text='Chain')
        if count>0 and bend_available:row.prop(*bend,text='Bend')
        if surface is not None:
            row=layout.split(factor=.37,align=True)
            row.label(text='Collision')
            row.prop(*surface,text='')


def _contact_chain_records(guide):
    try:
        return tuple(json.loads(str(guide.get(CONTACT_CHAIN_MEMBERS, '[]'))))
    except (TypeError, ValueError):
        return ()


def _contact_chain_records_at(guide,frame,*,include_attachment=False):
    """The effector's connected component in the authored space graph."""
    owner,_bone=_surface_contact_pose_bone(guide)
    if owner is None or _bone is None:return ()
    cache=_state.get('special_event_reads')
    key=('contact_component',int(guide.as_pointer()),int(frame),bool(include_attachment),
         str(guide.get(CONTACT_CHAIN_MEMBERS,'[]')),
         int(_state.get('dynamic_space_runtime_cache_generation',0)))
    if cache is not None and key in cache:return cache[key]
    records=_contact_chain_records(guide)
    result=records
    for index in range(len(records)-1,-1,-1):
        bone=owner.pose.bones.get(records[index][0])
        if bone is None:result=();break
        space=_chosen_dynamic_parent_constraint(bone,int(frame))
        if space is None:continue
        if space.name.startswith('DP_'):result=records[index if include_attachment else index+1:];break
        if _dynamic_space_role(bone,space) in (SPACE_ROLE_UNPARENT,SPACE_ROLE_WORLD):
            result=records[index:];break
    if cache is not None:cache[key]=result
    return result


def _contact_chain_space_parent(bone,frame):
    """Visible dependency parent, including a keyed attachment to another rig."""
    space=_chosen_dynamic_parent_constraint(bone,int(frame))
    if space is not None:
        target=_dynamic_parent_constraint_target(bone,space)
        name=_dynamic_parent_constraint_subtarget(bone,space)
        return (target.pose.bones.get(name) if target is not None
                and getattr(target,'pose',None) and name else None)
    carrier=_dynamic_carrier(bone)
    if carrier is not None:return bone.id_data.pose.bones.get(str(bone.bone.get(REL_K_PARENT,'')))
    return bone.parent


def _contact_chain_ancestors(guide,frame=None):
    if frame is None:frame=bpy.context.scene.frame_current
    bones=_contact_chain_bones(guide,frame)
    bone=bones[0] if bones else None
    seen=set();result=[]
    while bone is not None:
        bone=_contact_chain_space_parent(bone,frame)
        if bone is None:break
        key=(bone.id_data.name,bone.name)
        if key in seen:break
        seen.add(key);result.append(bone)
    return tuple(result)


def _contact_chain_bones(guide,frame=None):
    armature, bone = _surface_contact_pose_bone(guide)
    if bone is None:
        return ()
    if str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, '')) == SURFACE_CONTACT_KIND_CHAIN:
        if frame is None:frame=bpy.context.scene.frame_current
        return tuple(armature.pose.bones[name] for name, _helper, _constraint in _contact_chain_records_at(guide,frame)
                     if name in armature.pose.bones)
    return tuple(reversed(_surface_contact_chain(bone, int(guide.get(SURFACE_CONTACT_CHAIN_PROPERTY, 1)))))


def _contact_chain_parent_count(guide):
    records=_contact_chain_records(guide)
    return max(0,(len(records) if records else len(_contact_chain_bones(guide)))-1)


def _contact_chain_bend_wrap(value):
    value=float(value)
    return (value+math.pi)%math.tau-math.pi if math.isfinite(value) else 0.


def _contact_chain_bend_get(guide):
    return _contact_chain_bend_wrap(guide.get(CONTACT_CHAIN_BEND,0.))


def _contact_chain_bend_edit_matrices(guide,raw):
    """Explicit Bend uses the indicator's zero, never the last solved knee."""
    if len(raw)<2:return raw
    root=raw[0].translation
    reach=raw[-1].translation-root
    if reach.length_squared<1.e-16:return raw
    axis=reach.normalized()
    rest=_contact_chain_bend_rest_matrices(guide)
    zero=_contact_chain_bend_default(guide,rest)
    desired=_contact_chain_bend_indicator(guide,raw,rest=rest,default=zero)
    if desired is None:return raw
    desired=desired-axis*desired.dot(axis)
    if desired.length_squared<1.e-16:return raw
    current=_contact_chain_curve_bend([m.translation.copy() for m in raw],axis)
    if current is None:
        # Near extension, float32 knee residuals cannot measure an angle.
        # Transport the same default reference through the rod's own frame;
        # unlike the fixed foot, that frame actually follows a Bend twist.
        current=raw[0].to_3x3()@rest[0].to_3x3().inverted_safe()@zero
        current-=axis*current.dot(axis)
    if current.length_squared<1.e-16:return raw
    current.normalize();desired.normalize()
    angle=math.atan2(axis.dot(current.cross(desired)),current.dot(desired))
    return _contact_chain_twist_matrices(raw,angle)


def _contact_chain_bend_set(guide,value):
    # Migrate only on explicit editing. Existing keys/handles/modifiers stay
    # native; frame reads and live delivery never rewrite authored curves.
    value=_contact_chain_bend_wrap(value)
    if CONTACT_CHAIN_BEND in guide and float(guide[CONTACT_CHAIN_BEND])==value:
        return
    for curve in _action_fcurves(_dynamic_parent_owner_action(guide),guide):
        if curve.data_path=='["'+CONTACT_CHAIN_BEND+'"]':
            curve.data_path='staticaliza_contact_bend'
    guide[CONTACT_CHAIN_BEND]=value
    if not guide.is_evaluated and not any(_state.get(k) for k in (
            'surface_contact_frame_evaluation_active','contact_chain_input_editing',
            'surface_contact_creation_active','pin_history_active','pin_history_syncing')):
        pending=_state.setdefault('contact_chain_bend_edits',set())
        if len(pending)<128:
            pending.add(guide.name)
            # The custom RNA setter stores an ID property; that write alone
            # does not schedule object evaluation. Queue before tagging so
            # the existing depsgraph edit flush sees this exact slider value.
            guide.update_tag(refresh={'OBJECT'})


def _contact_chain_flush_bend_edits(context, depsgraph):
    """A guide-only Bend edit needs its chain, not a scene-wide action replay."""
    names=_state.pop('contact_chain_bend_edits',set())
    if not names or context is None:return False
    allowed=set(names)
    for name in names:
        guide=bpy.data.objects.get(name)
        if guide is not None:
            solver=_surface_contact_solver_from_guide(guide)
            if solver is not None:allowed.add(solver.name)
            allowed.update(row[1] for row in _contact_chain_records(guide))
    updates=tuple(update.id.original for update in depsgraph.updates)
    previous=_state.get('surface_contact_solver_syncing',False)
    _state['surface_contact_solver_syncing']=True
    try:
        changed=False
        prior_edits=_state.get('contact_chain_pose_edits',set())
        prior_bend_edits=_state.get('contact_chain_bend_pose_edits',set())
        _state['contact_chain_pose_edits']=set(prior_edits)|set(names)
        _state['contact_chain_bend_pose_edits']=set(prior_bend_edits)|set(names)
        for name in names:
            guide=bpy.data.objects.get(name)
            if guide is not None and name in context.scene.objects:
                changed=_contact_chain_sync(context,guide) or changed
                if guide.get(SURFACE_CONTACT_KIND_PROPERTY)==SURFACE_CONTACT_KIND_CHAIN:
                    _contact_chain_commit_pose(context,guide)
                    _contact_chain_key_confirmed_inputs(context,guides=(guide,))
        _state['contact_chain_pose_edits']=prior_edits
        _state['contact_chain_bend_pose_edits']=prior_bend_edits
        if changed:context.view_layer.update()
        _tag_redraw_all_view3d()
        return True
    finally:
        _state['surface_contact_solver_syncing']=previous
        if 'prior_edits' in locals():_state['contact_chain_pose_edits']=prior_edits
        if 'prior_bend_edits' in locals():_state['contact_chain_bend_pose_edits']=prior_bend_edits



def _contact_settings_properties():
    """Native redo owns every setting; no nested settings operators in draw."""
    return dict(
        pin_mode=bpy.props.EnumProperty(name='Position',items=(
            ('MODE_3','Smart','Use the linked mesh face'),('MODE_4','Bone Start','Use the bone head'),
            ('MODE_2','Bone Center','Use the linked geometry center'),('MODE_1','Bone End','Use the bone tail')),
            default='MODE_3',options={'SKIP_SAVE'}),
        cast_axis=bpy.props.EnumProperty(name='Axis',items=PIN_AXIS_ITEMS,default='Y_NEG',options={'SKIP_SAVE'}),
        bend_angle=bpy.props.FloatProperty(name='Bend',subtype='ANGLE',default=0.,options={'SKIP_SAVE'}),
        count=bpy.props.IntProperty(name='Chain',default=0,min=0,max=254,options={'SKIP_SAVE'},
            description='0 = pinned bone only; 1 = add its parent; 2 = add two parents'),
        ik_enabled=bpy.props.BoolProperty(name='IK',default=False,options={'SKIP_SAVE'},
            description='Aim with the attached purple handle; move the bone to offset its position'),
        control_mode=bpy.props.EnumProperty(name='Mode',items=(
            ('IK','IK','Aim with the attached purple handle',0,1),('COLLISION','Collision','Control the surface pin',0,0)),
            get=_contact_control_get,set=_contact_control_set,options={'SKIP_SAVE'}),
        surface_response=bpy.props.EnumProperty(name='Collision',items=_contact_surface_items,
            get=_contact_surface_get,set=_contact_surface_set,options={'SKIP_SAVE'}),
        clip=bpy.props.BoolProperty(name='Clip',default=False,options={'SKIP_SAVE'},
            description='Allow IK to pass through surfaces, without collision or surface alignment'),
        planted=bpy.props.BoolProperty(name='Plant',default=False,options={'SKIP_SAVE'},
            description='Align the mesh face while touching a collision surface during a transform; unavailable with Clip'))


def _draw_contact_settings_operator(operator, context):
    operator.layout.row(align=True).prop(operator,'control_mode',expand=True)
    _draw_constraint_configuration(operator.layout,kind='COLLISION',position=(operator,'pin_mode'),
        axis=(operator,'cast_axis'),chain=(operator,'count'),bend=(operator,'bend_angle'),
        ik=(operator,'ik_enabled'),planted=(operator,'planted'),clip=(operator,'clip'),count=operator.count,ik_enabled=operator.ik_enabled,
        surface=(operator,'surface_response'),
        bend_available=bool(operator.properties.get('_contact_settings_bend_available',True)))


def _contact_chain_settings_warning(context, message):
    """A failed edit has one native popup, never a persistent panel row."""
    def draw(menu, _context):
        menu.layout.label(text=message)
    if not bpy.app.background:
        context.window_manager.popup_menu(draw, title='Chain', icon='ERROR')


def _contact_settings_execute(operator, context):
    fields=('pin_mode','cast_axis','count','bend_angle','ik_enabled','planted','clip')
    if not operator.properties.get('_contact_settings_guides'):
        guides=_surface_contact_selected_guides(context,active_only=True)
        if not guides:return {'CANCELLED'}
        first=guides[0]
        values=(str(first.get(SURFACE_CONTACT_PIN_MODE_PROPERTY,'MODE_3')),
                str(first.get(SURFACE_CONTACT_CAST_AXIS_PROPERTY,'Y_NEG')),
                _contact_chain_parent_count(first),_contact_chain_bend_get(first),not _contact_chain_uses_contact(first),
                bool(first.get(CONTACT_CHAIN_PLANTED,False)),bool(first.get('Contact Clip',False)))
        touched=[name for name in fields if operator.properties.is_property_set(name)
                 and (name!='bend_angle' or math.isfinite(operator.bend_angle))]
        for name,value in zip(fields,values):
            if name not in touched:setattr(operator,name,value)
        operator.properties['_contact_settings_guides']=[g.name for g in guides]
        operator.properties['_contact_settings_touched']=touched
        operator.properties['_contact_settings_baseline']=json.dumps(dict(zip(fields,values)))
    guides=[bpy.data.objects[name] for name in operator.properties['_contact_settings_guides']
            if name in context.scene.objects]
    if not guides:return {'CANCELLED'}
    operator.bend_angle=_contact_chain_bend_wrap(operator.bend_angle)
    baseline=json.loads(operator.properties['_contact_settings_baseline'])
    baseline.setdefault('planted',bool(guides[0].get(CONTACT_CHAIN_PLANTED,False)))
    baseline.setdefault('clip',bool(guides[0].get('Contact Clip',False)))
    touched=set(operator.properties['_contact_settings_touched'])|{name for name in fields
                if getattr(operator,name)!=baseline[name]}
    for guide in guides:
        if 'count' in touched:
            owner,bone=_surface_contact_pose_bone(guide)
            members=tuple(reversed(_surface_contact_chain(bone,operator.count+1)))
            message=(_contact_chain_conflict(context,guide,members)
                     if len(members)>1 and guide.get(SURFACE_CONTACT_KIND_PROPERTY)!=SURFACE_CONTACT_KIND_CONTROL else '')
            if message:
                _contact_chain_settings_warning(context,message)
                return {'CANCELLED'}
        if 'ik_enabled' in touched:
            message=_contact_chain_mode_conflict(context,guide,not operator.ik_enabled)
            if message:
                _contact_chain_settings_warning(context,message);return {'CANCELLED'}
    previous=_state.get('contact_chain_input_editing',False)
    _state['contact_chain_input_editing']=True
    try:
        for guide in guides:
            if 'clip' in touched:
                guide['Contact Clip']=bool(operator.clip)
            settings=SimpleNamespace(surface_contact_pin_mode=operator.pin_mode,
                surface_contact_cast_axis=operator.cast_axis)
            if 'planted' in touched:
                _contact_chain_set_planted(context,guide,operator.planted)
            if 'ik_enabled' in touched and _contact_chain_uses_contact(guide)==operator.ik_enabled:
                ok,message=_contact_chain_set_contact(context,guide,not operator.ik_enabled)
                if not ok:_contact_chain_settings_warning(context,message);return {'CANCELLED'}
            if 'count' in touched:
                ok,message=_contact_chain_set_count(context,guide,operator.count+1)
                if not ok:_contact_chain_settings_warning(context,message);return {'CANCELLED'}
            if 'pin_mode' in touched and guide.get(SURFACE_CONTACT_PIN_MODE_PROPERTY)!=operator.pin_mode:
                _surface_contact_apply_pin_mode_change(settings,context,push_history=False,guide_override=guide)
            if 'cast_axis' in touched and guide.get(SURFACE_CONTACT_CAST_AXIS_PROPERTY)!=operator.cast_axis:
                guide['_constraint_axis_edited']=True
                _surface_contact_apply_cast_axis_change(settings,context,guide_override=guide,push_history=False)
            bend_edit='bend_angle' in touched and guide.get(SURFACE_CONTACT_KIND_PROPERTY)==SURFACE_CONTACT_KIND_CHAIN
            if bend_edit:
                guide.staticaliza_contact_bend=operator.bend_angle
                _state.setdefault('contact_chain_pose_edits',set()).add(guide.name)
                _state.setdefault('contact_chain_bend_pose_edits',set()).add(guide.name)
            try:
                _contact_chain_sync(context,guide)
                if bend_edit:
                    _contact_chain_commit_pose(context,guide)
                    _contact_chain_key_confirmed_inputs(context,guides=(guide,))
            finally:
                if bend_edit:
                    _state.setdefault('contact_chain_pose_edits',set()).discard(guide.name)
                    _state.setdefault('contact_chain_bend_pose_edits',set()).discard(guide.name)
        context.view_layer.update()
        _state.pop('contact_chain_settings_message',None)
        operator.properties['_contact_settings_bend_available']=guides[0].get(SURFACE_CONTACT_KIND_PROPERTY)==SURFACE_CONTACT_KIND_CHAIN
        _tag_redraw_all_view3d()
        return {'FINISHED'}
    finally:_state['contact_chain_input_editing']=previous


def _contact_chain_source_basis(context, armature, bone, source=None):
    """Exclude generated future End keys without replacing a live FK edit."""
    if _SPECIAL_END_INPUTS not in bone:
        return bone.matrix_basis.copy()
    frame = float(context.scene.frame_current_final)
    filtered = _special_end_simulation_inputs(context, armature, bone, frame,
                                              force=True, evaluate_only=True)
    if not isinstance(filtered, bpy.types.Action):
        return bone.matrix_basis.copy()
    records = [r for r in json.loads(bone.get(_SPECIAL_END_INPUTS, '[]')) if r['frame'] > frame]
    if not records:
        return bone.matrix_basis.copy()
    defaults = min(records, key=lambda r:r['frame'])['defaults']
    prefix = bone.path_from_id()+'.'
    if source is None:
        source = {(c.data_path,c.array_index):c
                  for c in _action_fcurves(_dynamic_parent_owner_action(armature),armature)}
    isolated = {(c.data_path,c.array_index):c for c in _action_fcurves(filtered,armature)}
    properties = ('location','scale','rotation_euler','rotation_quaternion','rotation_axis_angle')
    values = {prop:list(getattr(bone,prop)) for prop in properties}
    for prop in properties:
        for i,value in enumerate(values[prop]):
            curve = source.get((prefix+prop,i))
            if curve is None or curve.mute or abs(value-curve.evaluate(frame)) > 2.e-5:
                continue  # A live user transform still owns its changed input.
            clean = isolated.get((prefix+prop,i))
            values[prop][i] = (clean.evaluate(frame) if clean is not None and (clean.keyframe_points or clean.modifiers)
                               else defaults[prop][i])
    return _surface_contact_release_channels(bone,frame,(),defaults=values)


def _contact_chain_raw_matrices(context, armature, bones, solved=None, *, lock_joints=False, basis_overrides=None, live_parent=False):
    """FK inputs exclude our Copy Transforms outputs and preserve native LRS."""
    # An evaluated parent read may flush the Action. Capture native input first.
    bases = [((basis_overrides or {}).get((_armature_session_uid(armature),b.name),b.matrix_basis)).copy()
             for b in bones]
    held=_state.get('contact_chain_held_inputs',{}) if _state.get('pin_snap_transform_active') else {}
    for index,bone in enumerate(bones):
        entry=held.get((_armature_session_uid(armature),bone.name))
        if entry is not None:bases[index]=entry[2].copy()
        elif _state.get('pin_snap_sample_syncing'):
            current=_state.get('contact_chain_selected_native_inputs',{}).get((armature.name,bone.name))
            if current is not None:bases[index]=current.copy()
    parent = bones[0].parent
    parent_matrix = None
    if parent is not None:
        parent_matrix = (solved or {}).get((armature.name, parent.name))
        if parent_matrix is None:
            evaluated = armature if live_parent else armature.evaluated_get(context.evaluated_depsgraph_get())
            parent_matrix = armature.matrix_world @ evaluated.pose.bones[parent.name].matrix
        parent_matrix = armature.matrix_world.inverted_safe() @ parent_matrix
    matrices = []
    source = None
    if any(_SPECIAL_END_INPUTS in bone for bone in bones):
        key = ('CONTACT_CHAIN_ACTION',armature.name,'CURVES')
        source = (solved or {}).get(key)
        if source is None:
            source = {(c.data_path,c.array_index):c
                      for c in _action_fcurves(_dynamic_parent_owner_action(armature),armature)}
            if solved is not None:
                solved[key] = source
    for index, bone in enumerate(bones):
        if index:parent_matrix=_contact_chain_parent_matrix(bone,parent_matrix,context.scene.frame_current)
        kwargs = {} if bone.parent is None else dict(
            parent_matrix=parent_matrix, parent_matrix_local=bone.parent.bone.matrix_local)
        basis = bases[index]
        if _SPECIAL_END_INPUTS in bone and not basis_overrides:
            basis = _contact_chain_source_basis(context,armature,bone,source)
        if bone.bone.use_connect:
            # A child G is an IK goal, never extra length between joints.
            # Native rest offsets/scale remain part of the rigid linkage.
            basis.translation = (0.,0.,0.)
        elif lock_joints and index:
            initial=_state.get('contact_chain_start_inputs',{}).get((armature.name,bone.name))
            if lock_joints=='REST':basis.translation=(0.,0.,0.)
            elif initial is not None:basis.translation=initial.translation
        matrix = bone.bone.convert_local_to_pose(basis,
                                                bone.bone.matrix_local, **kwargs)
        matrices.append(armature.matrix_world @ matrix)
        parent_matrix = matrix
    return matrices


def _contact_chain_parent_matrix(bone,parent_matrix,frame):
    """Convert a visible parent frame into its managed native carrier frame."""
    carrier=_dynamic_carrier(bone)
    if carrier is not None:
        space=_chosen_dynamic_parent_constraint(bone,frame)
        if space is not None and _dynamic_space_role(bone,space)==SPACE_ROLE_NORMAL:
            return parent_matrix@space.inverse_matrix@carrier.bone.matrix_local@carrier.matrix_basis
    return parent_matrix


def _contact_chain_capture_held_inputs(context):
    selected={owner.name:{bone.name for bone in bones}
              for owner,bones in _selected_pose_bones_by_owner(context).items()}
    _contact_chain_capture_edit_snapshot(context, selected)
    held={}
    effectors={}
    translation_frames={}
    rotation_frames={}
    root_frames={}
    starts={}
    idle_bases=(_state.get('pin_snap_idle_transform_poses',{}).get('poses',{})
          if _state.get('pin_snap_transform_baseline_precedes_sample') else {})
    for guide in _surface_contact_guides():
        if (guide.get(SURFACE_CONTACT_KIND_PROPERTY)!=SURFACE_CONTACT_KIND_CHAIN
                or not _surface_contact_guide_active_at(guide,context.scene.frame_current)):
            continue
        owner,_bone=_surface_contact_pose_bone(guide)
        names=selected.get(owner.name,set());bones=_contact_chain_bones(guide)
        ancestors=_contact_chain_ancestors(guide)
        inherited=any(b.name in selected.get(b.id_data.name,set()) for b in ancestors)
        if (not names and not inherited) or not _contact_chain_enabled(context,guide,bones):continue
        uid=_armature_session_uid(owner)
        for bone in bones:
            # The watcher may first run after Blender has moved the selected
            # foot. Its moved location is a goal, never a new joint/rest pose.
            starts[(owner.name,bone.name)]=idle_bases.get((uid,bone.name),
                _pin_authored_pose_basis(bone)).copy()
        direct=bool(names.intersection(b.name for b in bones))
        # Native G starts at the visible constrained mesh, not its hidden FK
        # orientation. Keep that immutable reference across every snap edge.
        affected=direct or inherited
        if affected:
            if (_contact_chain_is_planted(guide) or
                    (not _contact_chain_uses_contact(guide) and not guide.get('Contact Clip',False))):
                support=Vector(tuple(guide.get(SURFACE_CONTACT_SUPPORT_PROPERTY,(0,0,0)))[:3])
                _contact_chain_contact_geometry(context,guide,support)
            driver=(next(b for b in reversed((bones[-1],*bones[-1].parent_recursive)) if b.name in names)
                    if bones[-1].name in names else None)
            driver_basis=(idle_bases.get((uid,driver.name),_pin_authored_pose_basis(driver)).copy()
                          if driver is not None else None)
            evaluated=owner.evaluated_get(context.evaluated_depsgraph_get())
            effectors[guide.name]=owner.matrix_world@evaluated.pose.bones[bones[-1].name].matrix
            parent=bones[0].parent
            if parent is not None:
                parent_world=owner.matrix_world@evaluated.pose.bones[parent.name].matrix
                root_world=owner.matrix_world@evaluated.pose.bones[bones[0].name].matrix
                if _state.get('pin_snap_transform_baseline_precedes_sample'):
                    idle=_state.get('pin_snap_idle_transform_poses',{})
                    parent_world=idle.get('parent_worlds',{}).get((_armature_session_uid(owner),parent.name),parent_world)
                    root_world=idle.get('chain_roots',{}).get(guide.name,root_world)
                root_frames[guide.name]=(parent.name,parent_world.copy(),root_world.copy())
            if bones[-1].name in names:
                parent_kwargs={} if driver.parent is None else dict(
                    parent_matrix=evaluated.pose.bones[driver.parent.name].matrix.copy(),
                    parent_matrix_local=driver.parent.bone.matrix_local.copy())
                start=owner.matrix_world@driver.bone.convert_local_to_pose(
                    driver_basis,driver.bone.matrix_local,**parent_kwargs)
                rotation_frames[guide.name]=(driver.name,parent_kwargs,start.to_quaternion(),effectors[guide.name].copy())
                # Native G expresses location in the displayed parent's axes.
                # Capture that linear map once; solving IK later must not rotate
                # the input plane or feed its own knee swing back into the drag.
                kwargs={} if driver.parent is None else dict(
                    parent_matrix=evaluated.pose.bones[driver.parent.name].matrix.copy(),
                    parent_matrix_local=driver.parent.bone.matrix_local)
                origin=driver.bone.convert_local_to_pose(Matrix.Identity(4),
                    driver.bone.matrix_local,**kwargs).translation
                columns=[]
                for axis in ((1,0,0),(0,1,0),(0,0,1)):
                    point=driver.bone.convert_local_to_pose(Matrix.Translation(axis),
                        driver.bone.matrix_local,**kwargs).translation
                    columns.append(owner.matrix_world.to_3x3()@(point-origin))
                if driver.bone.use_connect and not _contact_chain_uses_contact(guide):
                    parent_world=(owner.matrix_world@evaluated.pose.bones[driver.parent.name].matrix
                                  if driver.parent is not None else None)
                    frame=_contact_chain_location_frame(owner,driver,start,parent_world)
                    translation_frames[guide.name]=(driver.name,frame,driver_basis.translation.copy())
                else:translation_frames[guide.name]=(driver.name,Matrix(columns).transposed())
        # A shared Action may replay other chains on this rig during G/R/S.
        # Hold their inputs too, but only the edited chain may author held keys.
        for bone in bones:
            if bone.name not in names:
                held[(uid,bone.name)]=(owner.name,bone.name,starts[(owner.name,bone.name)].copy(),direct)
    _state['contact_chain_start_inputs']=starts
    _state['contact_chain_held_inputs']=held
    _state['contact_chain_transform_effectors']=effectors
    _state['contact_chain_transform_translation_frames']=translation_frames
    _state['contact_chain_transform_rotation_frames']=rotation_frames
    _state['contact_chain_transform_root_frames']=root_frames


def _contact_chain_capture_edit_snapshot(context, selected):
    """One immutable rollback for native and virtual edits, using stable IDs."""
    # Geometry, approach sides and selection exclusions belong to one gesture.
    # Virtual pin drags must not inherit a prior native gesture's contact side.
    _state.pop('contact_chain_collision_exclusions',None)
    _state.pop('contact_chain_contact_patches',None)
    sources = {}
    objects = {}
    properties = {}
    # The native watcher can first run after Blender has applied its first
    # mouse sample. The idle FK capture already precedes that sample. Using
    # current parents here made Cancel restore the first move, then selection
    # republished children against that wrong parent one update later.
    idle = (_state.get('pin_snap_idle_transform_poses', {}).get('poses', {})
            if _state.get('pin_snap_transform_baseline_precedes_sample')
            and _state.get('pin_snap_transform_active') else {})
    names = (SURFACE_CONTACT_POINT_PROPERTY, SURFACE_CONTACT_NORMAL_PROPERTY,
             SURFACE_CONTACT_GUIDE_LOCAL_MATRIX_PROPERTY, SURFACE_CONTACT_DETACHED_PROPERTY,
             'Contact Collision Side', 'Contact Authored Pose', 'Contact Pose Reference')
    for guide in _surface_contact_guides():
        owner, bone = _surface_contact_pose_bone(guide)
        if owner is None or owner.name not in selected:
            continue
        if owner.name not in sources:
            uid = _armature_session_uid(owner)
            sources[owner.name] = {b.name: idle.get((uid,b.name),
                _pin_authored_pose_basis(b)).copy() for b in owner.pose.bones}
        objects[guide.name] = guide.matrix_world.copy()
        properties[guide.name] = {name: (name in guide,
            tuple(guide[name]) if name in guide and hasattr(guide[name], '__len__')
            and not isinstance(guide[name], str) else guide.get(name)) for name in names}
        for _name, helper, _constraint in _contact_chain_records(guide):
            obj = bpy.data.objects.get(helper)
            if obj is not None: objects[helper] = obj.matrix_world.copy()
    snapshot = dict(sources=sources, objects=objects, properties=properties)
    _state['contact_chain_edit_snapshot'] = snapshot
    return snapshot


def _contact_chain_restore_edit_snapshot(context, snapshot=None):
    """Cancel publishes the captured pose; it never asks IK for a new pose."""
    snapshot = snapshot if snapshot is not None else _state.get('contact_chain_edit_snapshot')
    if not snapshot: return False
    for owner_name, bases in snapshot['sources'].items():
        owner = bpy.data.objects.get(owner_name)
        if owner is not None and owner.pose is not None:
            for name, basis in bases.items():
                bone = owner.pose.bones.get(name)
                if bone is not None and _pin_keyboard_matrices_differ(_pin_authored_pose_basis(bone),basis):
                    bone.matrix_basis = basis.copy()
    for name, values in snapshot['properties'].items():
        guide = bpy.data.objects.get(name)
        if guide is None: continue
        for prop, (exists, value) in values.items():
            current=guide.get(prop)
            if current is not None and hasattr(current,'__len__') and not isinstance(current,str):current=tuple(current)
            if exists and (prop not in guide or current!=value): guide[prop] = value
            elif not exists and prop in guide: del guide[prop]
    for name, matrix in snapshot['objects'].items():
        obj = bpy.data.objects.get(name)
        if obj is not None and _pin_keyboard_matrices_differ(obj.matrix_world,matrix):obj.matrix_world = matrix.copy()
    _state.pop('contact_chain_solutions', None)
    return bool(snapshot['sources'])


def _contact_chain_native_rotation_world(context,guide):
    """Interpret native R in its initial displayed parent frame, like native G."""
    frame=_state.get('contact_chain_transform_rotation_frames',{}).get(guide.name)
    if (frame is None or not _state.get('pin_snap_transform_active')
            or guide.name in _state.get('contact_chain_committed_inputs',())
            or not _pin_transform_is_rotation(_state.get('pin_snap_transform_operator',''))):
        return None
    owner,bone=_surface_contact_pose_bone(guide)
    name,kwargs,start,visible=frame
    bone=owner.pose.bones[name]
    basis=(_state.get('contact_chain_selected_native_inputs',{}).get((owner.name,bone.name),bone.matrix_basis)
           if _state.get('pin_snap_sample_syncing') else bone.matrix_basis)
    current=owner.matrix_world@bone.bone.convert_local_to_pose(
        basis.copy(),bone.bone.matrix_local,**kwargs)
    delta=current.to_quaternion()@start.conjugated()
    return delta.to_matrix().to_4x4()@visible


def _contact_chain_restore_held_inputs(context, *, keyframe=False):
    held=_state.get('contact_chain_held_inputs',{})
    if not held:return False
    owners={entry[0]:bpy.data.objects.get(entry[0]) for entry in held.values()}
    bases=_pin_capture_action_pose_bases(tuple(o for o in owners.values() if o is not None))
    curves={name:tuple(_action_fcurves(_dynamic_parent_owner_action(owner),owner))
            for name,owner in owners.items() if owner is not None}
    previous=_state.get('surface_contact_solver_syncing',False)
    _state['surface_contact_solver_syncing']=True
    changed=False
    try:
        for entry in held.values():
            name,bone_name,basis=entry[:3]
            owner=owners[name];bone=owner.pose.bones.get(bone_name) if owner else None
            if bone is None:continue
            animated=_surface_contact_release_channels(bone,context.scene.frame_current_final,curves[name],
                                                        prefix=bone.path_from_id()+'.')
            if _pin_keyboard_matrices_differ(bone.matrix_basis,basis):
                bone.matrix_basis=basis.copy();changed=True
            if (keyframe and (len(entry)<4 or entry[3])
                    and context.scene.tool_settings.use_keyframe_insert_auto
                    and _pin_keyboard_matrices_differ(animated,basis)):
                _insert_bone_keys(bone,int(context.scene.frame_current),visual=False)
                changed=True
        # Preserve selected inputs as well when an unselected bone's key
        # dirties their shared Action. The held entries own their source bases.
        if changed:
            _pin_restore_action_pose_bases(context,bases)
            for entry in held.values():
                name,bone_name,basis=entry[:3]
                owner=owners[name]
                if owner and bone_name in owner.pose.bones:owner.pose.bones[bone_name].matrix_basis=basis.copy()
        return changed
    finally:_state['surface_contact_solver_syncing']=previous


def _contact_chain_location_frame(owner,bone,world,parent_world):
    inverse=owner.matrix_world.inverted_safe()
    kwargs={} if bone.parent is None else dict(parent_matrix=inverse@parent_world,
                                               parent_matrix_local=bone.parent.bone.matrix_local)
    pose=inverse@world
    origin=bone.bone.convert_local_to_pose(pose,bone.bone.matrix_local,invert=True,**kwargs).translation
    columns=[]
    for axis in ((1,0,0),(0,1,0),(0,0,1)):
        sample=pose.copy();sample.translation+=Vector(axis)
        columns.append(bone.bone.convert_local_to_pose(sample,bone.bone.matrix_local,invert=True,**kwargs).translation-origin)
    return owner.matrix_world.to_3x3()@Matrix(columns).transposed().inverted_safe()


def _contact_chain_raw_anchor(context, guide, *, relative_to_start=False, basis_overrides=None):
    """Read authored input without feeding the IK output back into its goal."""
    armature, bone = _surface_contact_pose_bone(guide)
    bones = _contact_chain_bones(guide)
    if bone is None or not bones:
        return None
    anchor=starts=None
    if relative_to_start:
        key=_surface_contact_snap_key(guide)
        anchor=_state.get('pin_snap_transform_start_anchor_samples',{}).get(key)
        starts=_state.get('pin_snap_transform_start_poses',{})
        native_frame=_state.get('contact_chain_transform_translation_frames',{}).get(guide.name)
        operator=str(_state.get('pin_snap_transform_operator','')).lower()
        if anchor is not None and starts and native_frame is not None and 'translate' in operator:
            name,frame=native_frame[:2];driver=armature.pose.bones.get(name)
            driver_key=(_armature_session_uid(armature),name)
            start_basis=starts.get(driver_key)
            if driver is not None and start_basis is not None:
                basis=(basis_overrides or {}).get(driver_key,driver.matrix_basis)
                delta=(driver.location-native_frame[2] if len(native_frame)>2 else basis.translation-start_basis.translation)
                return Vector(anchor)+frame@delta
    support = Vector(tuple(guide.get(SURFACE_CONTACT_SUPPORT_PROPERTY,(0.,bone.length,0.)))[:3])
    raw = _contact_chain_raw_matrices(context,armature,bones,basis_overrides=basis_overrides,live_parent=relative_to_start)
    point = raw[-1] @ support
    if not _contact_chain_uses_contact(guide) and bone.bone.use_connect:
        key=(_armature_session_uid(armature),bone.name)
        location=(basis_overrides[key].translation if basis_overrides and key in basis_overrides else bone.location)
        if location.length_squared>1.e-18:
            parent=raw[-2] if len(raw)>1 else armature.matrix_world@bone.parent.matrix
            point+=_contact_chain_location_frame(armature,bone,raw[-1],parent)@location
    if anchor is not None and starts:
        baseline_bases = dict(basis_overrides or {})
        baseline_bases.update(starts)
        baseline = _contact_chain_raw_matrices(context,armature,bones,basis_overrides=baseline_bases,live_parent=True)
        point = Vector(anchor) + point - baseline[-1] @ support
    return point


def _contact_chain_native_target(context,guide):
    """Use the same visible transform origin for admission and detached IK."""
    relative = bool(_state.get('pin_snap_transform_active')
                    and guide.name in _state.get('pin_snap_direct_transform_guides',())
                    and guide.name not in _state.get('contact_chain_committed_inputs',()))
    if relative and not _contact_chain_uses_contact(guide):
        owner, bone = _surface_contact_pose_bone(guide)
        selected = _state.get('pin_snap_transform_start_poses', {})
        # An ancestor edits the bend around the planted goal. Selecting the
        # effector explicitly edits that goal, including multi-bone moves.
        bones = _contact_chain_bones(guide)
        outer_parent_selected = any((_armature_session_uid(b.id_data), b.name) in selected
                                    for b in _contact_chain_ancestors(guide))
        member_names={b.name for b in bones}
        branch_parent_selected = ((_armature_session_uid(owner),bones[0].name) in selected
                                  and any(child.name not in member_names for child in bones[0].children))
        if (outer_parent_selected or branch_parent_selected) and (
                _armature_session_uid(owner), bone.name) in selected:
            # An external parent owns hierarchy transport, once. A fixed
            # world IK goal here pins the torso in place during native G.
            return _contact_chain_raw_anchor(context, guide, relative_to_start=False)
        if (_armature_session_uid(owner), bone.name) not in selected:
            start = _state.get('pin_snap_transform_start_anchor_samples', {}).get(
                _surface_contact_snap_key(guide))
            if start is not None:
                return Vector(start).copy()
    if relative and _state.get('pin_snap_sample_syncing'):
        sample = _state.get('pin_snap_raw_anchor_samples',{}).get(_surface_contact_snap_key(guide))
        if sample is not None:
            return Vector(sample).copy()
    return _contact_chain_raw_anchor(context,guide,relative_to_start=relative)


def _contact_chain_transform_guides(scene):
    """Native history owns chain source edits, not the single-rod evaluator."""
    return (*_surface_contact_active_simulated_guides(scene),
            *(g for g in _surface_contact_guides()
              if g.get(SURFACE_CONTACT_KIND_PROPERTY)==SURFACE_CONTACT_KIND_CHAIN
              and _surface_contact_guide_active_at(g,scene.frame_current)))


def _contact_chain_commit_pose(context,guide):
    """Store one solved linkage as ordinary FK, independent of tool settings."""
    if guide.get(SURFACE_CONTACT_KIND_PROPERTY)!=SURFACE_CONTACT_KIND_CHAIN:return False
    owner,_bone=_surface_contact_pose_bone(guide)
    poses=tuple((name,bpy.data.objects[helper].matrix_world.copy())
                for name,helper,_constraint in _contact_chain_records_at(guide,context.scene.frame_current))
    if not poses:return False
    guide['Contact Authored Pose']=True
    guide['Contact Pose Reference']=(*(_contact_chain_target_matrix(guide).translation
        if _contact_chain_uses_contact(guide) else (0.,0.,0.)),float(guide.get(CONTACT_CHAIN_BEND,0.)))
    if any(_state.get(k) for k in ('pin_snap_transform_active','pin_keyboard_transform_active','pin_target_dragging')):
        _state.setdefault('contact_chain_committed_inputs',set()).add(guide.name)
    _contact_chain_preserve_mode_pose(context,guide,poses)
    held=_state.get('contact_chain_held_inputs',{})
    for name,_world in poses:
        key=(_armature_session_uid(owner),name)
        if key in held:
            entry=held[key];held[key]=(*entry[:2],_pin_authored_pose_basis(owner.pose.bones[name]),*entry[3:])
    return True


def _contact_chain_commit_native_inputs(context):
    """All modes and chain lengths share the same complete pose commit."""
    changed=False
    guides=[bpy.data.objects[name] for name in _contact_chain_native_edit_guides() if name in bpy.data.objects]
    guides.sort(key=lambda guide:len(_contact_chain_bones(guide)[0].parent_recursive)
                if _contact_chain_bones(guide) else 0)
    members={(b.id_data.name,b.name) for g in guides for b in _contact_chain_bones(g)}
    owners={_surface_contact_pose_bone(g)[0].name for g in guides}
    parent_inputs={key:basis for key,basis in _state.get('contact_chain_selected_native_inputs',{}).items()
                   if key[0] in owners and key not in members}
    keyed=_state.setdefault('contact_chain_keyed_parents',set())
    # Key source parents before evaluating/converting their child outputs.
    # The child or selected-pin Action can otherwise replay an older parent
    # while the immutable helpers still show the newly confirmed group pose.
    for (owner_name,name),basis in sorted(parent_inputs.items(),key=lambda item:
            len(bpy.data.objects[item[0][0]].pose.bones[item[0][1]].parent_recursive)):
        owner=bpy.data.objects[owner_name];bone=owner.pose.bones[name]
        bone.matrix_basis=basis.copy()
        if context.scene.tool_settings.use_keyframe_insert_auto or _dynamic_parent_owner_action(owner) is not None:
            _insert_bone_keys(bone,context.scene.frame_current,visual=False)
            keyed.add((owner_name,name))
    if parent_inputs:context.view_layer.update()
    for guide in guides:
        if _contact_chain_commit_pose(context,guide):
            changed=True
            context.view_layer.update()
    if changed:
        _contact_chain_sync_all(context,force=True)
        context.view_layer.update()
    return changed


def _contact_chain_key_confirmed_inputs(context, *, guides=None):
    """Key confirmed edits on animated chains, never buttons or settings.

    A keyed Contact owner already participates in animation. Leaving its new
    source pose unkeyed lets Record/save or Play replay the old Action values.
    Keep every source member together and protect shared Actions while keying.
    """
    if guides is None and not _state.get('pin_snap_transform_active'):return False
    grouped={};keyed_guides=[]
    names=tuple(g.name for g in guides) if guides is not None else _contact_chain_native_edit_guides()
    for name in names:
        guide=bpy.data.objects.get(name)
        if guide is None or guide.get(SURFACE_CONTACT_KIND_PROPERTY) not in (SURFACE_CONTACT_KIND_CHAIN,SURFACE_CONTACT_KIND_SIMULATED):continue
        owner,_bone=_surface_contact_pose_bone(guide)
        if not context.scene.tool_settings.use_keyframe_insert_auto and _dynamic_parent_owner_action(owner) is None:continue
        grouped.setdefault(owner,set()).update(b.name for b in _contact_chain_bones(guide))
        if guide.get('Contact Authored Pose'):keyed_guides.append(guide)
    if guides is None and _state.get('pin_snap_transform_active'):
        # A confirmed IK child pose is relative to these native parent inputs.
        # Replaying an older parent key later cannot reproduce that edit.
        starts=_state.get('pin_snap_transform_start_poses',{})
        for owner in grouped:
            uid=_armature_session_uid(owner)
            grouped[owner].update(name for owner_uid,name in starts if owner_uid==uid)
    bases=_pin_capture_action_pose_bases(tuple(grouped))
    targets={guide.name:guide.matrix_basis.copy() for guide in keyed_guides}
    for owner,names in grouped.items():
        for name in sorted(names,key=lambda n:len(owner.pose.bones[n].parent_recursive)):
            if (owner.name,name) in _state.get('contact_chain_keyed_parents',()):continue
            bone=owner.pose.bones[name]
            # A previous member's key can replay this shared Action. Key the
            # immutable confirmed input, not whichever channels it replayed.
            bone.matrix_basis=bases[(owner.name,name)].copy()
            _insert_bone_keys(bone,context.scene.frame_current,visual=False)
    for guide in keyed_guides:
        bone_name=str(guide.get(SURFACE_CONTACT_BONE_PROPERTY,'Contact'))
        if _contact_chain_uses_contact(guide):
            guide.keyframe_insert('["Contact Pose Reference"]',frame=context.scene.frame_current,
                                  group=f'Surface Contact State ({bone_name})')
    if grouped:_pin_restore_action_pose_bases(context,bases)
    # A reference shares the target's Action. Keying the reference can replay
    # yesterday's target before its pending transform has been keyed.
    for guide in keyed_guides:guide.matrix_basis=targets[guide.name]
    return bool(grouped)


def _contact_chain_previous_poses(context, guide, frame):
    """Capture all members in one explicit End-boundary evaluation."""
    armature, _bone = _surface_contact_pose_bone(guide)
    scene = context.scene
    saved_frame, subframe = scene.frame_current, scene.frame_subframe
    bases = _pin_capture_action_pose_bases((armature,))
    try:
        scene.frame_set(int(frame)-1)
        _contact_chain_sync_all(context,force=True)
        context.view_layer.update()
        evaluated = armature.evaluated_get(context.evaluated_depsgraph_get())
        return tuple((bone.name,evaluated.pose.bones[bone.name].matrix.copy())
                     for bone in _contact_chain_bones(guide))
    finally:
        scene.frame_set(saved_frame,subframe=subframe)
        _pin_restore_action_pose_bases(context,bases)


def _contact_chain_conflict(context, guide, bones):
    armature, effector = _surface_contact_pose_bone(guide)
    names = {bone.name for bone in bones}
    # A target parented to its own solved chain creates a feedback cycle.
    if (_contact_chain_uses_contact(guide)
            and str(guide.get(SURFACE_CONTACT_FOLLOW_OBJECT_PROPERTY, '')) == armature.name
            and str(guide.get(SURFACE_CONTACT_FOLLOW_BONE_PROPERTY, '')) in names):
        return 'The contact surface is driven by this chain'
    frame = context.scene.frame_current
    for other in _surface_contact_guides():
        if other == guide or str(other.get(SURFACE_CONTACT_ARMATURE_PROPERTY, '')) != armature.name:
            continue
        if not _surface_contact_guide_interval_active_at(other, frame):
            continue
        if str(other.get(SURFACE_CONTACT_BONE_PROPERTY, '')) == effector.name:
            continue
        overlap=names.intersection(b.name for b in _contact_chain_bones(other))
        if overlap:
            return ('"'+sorted(overlap)[0]+'" is already driven by Contact on "'
                    +str(other.get(SURFACE_CONTACT_BONE_PROPERTY,''))+'". Shorten Chain to keep a separate root.')
    for bone in bones:
        if bone != effector and _gyro_bone_active_at(armature, bone, frame):
            return 'Gyro already controls a bone in this chain'
        if any(c.type == 'IK' and not c.mute and c.influence > 1.e-6 for c in bone.constraints):
            return 'Use the existing rig IK controller for this chain'
    return ''


def _contact_chain_remove(guide):
    armature, _bone = _surface_contact_pose_bone(guide)
    if _bone is not None and 'Contact Original IK Count' in guide:
        constraint = _bone.constraints.get(str(guide.get('Contact Existing IK', '')))
        if constraint is not None and constraint.type == 'IK':
            constraint.chain_count = int(guide['Contact Original IK Count'])
        del guide['Contact Original IK Count']
    for name, helper_name, constraint_name in _contact_chain_records(guide):
        bone = armature.pose.bones.get(name) if armature else None
        constraint = bone.constraints.get(constraint_name) if bone else None
        if constraint is not None:
            _surface_contact_remove_constraint(bone, constraint)
        helper = bpy.data.objects.get(helper_name)
        if helper is not None and helper.get('Contact Chain Owner') == guide.name:
            bpy.data.objects.remove(helper, do_unlink=True)
    if CONTACT_CHAIN_MEMBERS in guide:
        del guide[CONTACT_CHAIN_MEMBERS]
    _state.setdefault('contact_chain_solutions', {}).pop(guide.name, None)


def _contact_chain_configure(context, guide, count):
    """Explicit setup only: never allocate helpers during draw or evaluation."""
    armature, effector = _surface_contact_pose_bone(guide)
    if effector is None:
        return False, 'Missing Contact bone'
    count = max(0, min(255, int(count)))
    kind = str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ''))
    if kind == SURFACE_CONTACT_KIND_CONTROL:
        relation = _surface_contact_ik_relation(armature, effector)
        if relation is None:
            return False, 'The existing IK controller is unavailable'
        constraint = relation['constraint']
        if 'Contact Original IK Count' not in guide:
            guide['Contact Original IK Count'] = int(constraint.chain_count)
            guide['Contact Existing IK'] = constraint.name
        constraint.chain_count = count
        guide[SURFACE_CONTACT_CHAIN_PROPERTY] = count
        return True, ''
    bones = tuple(reversed(_surface_contact_chain(effector, count)))
    if len(bones) > 1:
        conflict = _contact_chain_conflict(context, guide, bones)
        if conflict:
            return False, conflict
    records = _contact_chain_records(guide)
    reusable = {name:(helper, constraint) for name,helper,constraint in records
                if name in armature.pose.bones and bpy.data.objects.get(helper) is not None
                and bpy.data.objects[helper].get('Contact Chain Owner')==guide.name
                and (c:=armature.pose.bones[name].constraints.get(constraint)) is not None
                and c.type=='COPY_TRANSFORMS' and c.target==bpy.data.objects[helper]}
    needs_chain = (len(bones)>1 or not _contact_chain_uses_contact(guide)
                   or _contact_chain_is_planted(guide) or guide.get('Contact Authored Pose',False))
    if (needs_chain and kind==SURFACE_CONTACT_KIND_CHAIN
            and tuple(row[0] for row in records)==tuple(b.name for b in bones)
            and len(reusable)==len(records)):
        if int(guide.get(SURFACE_CONTACT_CHAIN_PROPERTY,1))!=count:
            guide[SURFACE_CONTACT_CHAIN_PROPERTY]=count
        return True, ''
    previous = _state.get('surface_contact_solver_syncing', False)
    _state['surface_contact_solver_syncing'] = True
    try:
        keep={b.name for b in bones} if needs_chain else set()
        for name,helper_name,constraint_name in records:
            if name in keep and name in reusable:continue
            bone=armature.pose.bones.get(name)
            constraint=bone.constraints.get(constraint_name) if bone else None
            if constraint is not None:_surface_contact_remove_constraint(bone,constraint)
            helper=bpy.data.objects.get(helper_name)
            if helper is not None and helper.get('Contact Chain Owner')==guide.name:
                bpy.data.objects.remove(helper,do_unlink=True)
        _state.setdefault('contact_chain_solutions',{}).pop(guide.name,None)
        if CONTACT_CHAIN_MEMBERS in guide:del guide[CONTACT_CHAIN_MEMBERS]
        guide[SURFACE_CONTACT_CHAIN_PROPERTY] = count
        if not needs_chain:
            guide[SURFACE_CONTACT_KIND_PROPERTY] = SURFACE_CONTACT_KIND_SIMULATED
            _surface_contact_invalidate_guide_cache()
            return True, ''
        records = []
        collection = _ensure_space_helper_collection(context, armature)
        for index, bone in enumerate(bones):
            if bone.name in reusable:
                helper_name,constraint_name=reusable[bone.name]
                records.append((bone.name,helper_name,constraint_name))
                continue
            helper = bpy.data.objects.new(f'_ContactChain_{guide.name.rsplit("_", 1)[-1]}_{index}', None)
            collection.objects.link(helper)
            helper['Contact Chain Owner'] = guide.name
            helper.matrix_world = armature.matrix_world @ bone.matrix
            helper.hide_render = helper.hide_select = True
            helper.empty_display_size = .01
            helper.hide_set(True)
            constraint = bone.constraints.new('COPY_TRANSFORMS')
            constraint.name = f'{SURFACE_CONTACT_CONSTRAINT_PREFIX}Chain_{guide.name.rsplit("_", 1)[-1]}'
            constraint.target = helper
            constraint.target_space = constraint.owner_space = 'WORLD'
            constraint.influence = 0.
            records.append((bone.name, helper.name, constraint.name))
        guide[CONTACT_CHAIN_MEMBERS] = json.dumps(records)
        if CONTACT_CHAIN_BEND not in guide:
            guide[CONTACT_CHAIN_BEND] = 0.
            guide.id_properties_ui(CONTACT_CHAIN_BEND).update(
                description='Rotate the chain bend direction around its reach axis',
                min=-math.pi, max=math.pi, subtype='ANGLE')
        guide[SURFACE_CONTACT_KIND_PROPERTY] = SURFACE_CONTACT_KIND_CHAIN
        _surface_contact_invalidate_guide_cache()
        context.view_layer.update()
        _contact_chain_sync(context, guide, force=True)
        context.view_layer.update()
        return True, ''
    finally:
        _state['surface_contact_solver_syncing'] = previous
        # The ordinary single-bone branch returns before helper publication.
        # Restore colors for discarded members there as well as on reductions.
        _sync_all_dynamic_pose_bone_colors(context.scene.frame_current, armature)


def _contact_chain_enabled(context, guide, bones):
    if not bones:return False
    frame = context.scene.frame_current
    if not _surface_contact_guide_active_at(guide, frame):
        return False
    if any(_constraint_bone_ragdoll_override(b.id_data, b, frame) for b in bones):
        return False
    if any(_gyro_bone_active_at(b.id_data, b, frame) for b in bones):
        return False
    return True


def _contact_chain_attached(context, guide):
    if not _contact_chain_uses_contact(guide):
        return True
    native = any(guide.name in _state.get(key,()) for key in (
        'pin_snap_direct_transform_guides','pin_snap_parent_transform_guides',
        'pin_snap_target_transform_guides'))
    target = bool((_state.get('pin_target_dragging') or _state.get('pin_keyboard_transform_active'))
        and _surface_contact_snap_key(guide) in _pin_selected_target_keys())
    if (_state.get('pin_snap_transform_active') and native) or target:
        return not bool(guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False))
    if _state.get('contact_chain_input_editing'):
        return not bool(guide.get(SURFACE_CONTACT_DETACHED_PROPERTY,False))
    entry=_state.get('contact_idle_confirmed_poses',{}).get(guide.name)
    if entry is not None:
        raw=bool(guide.get(SURFACE_CONTACT_DETACHED_PROPERTY,False))
        animated=_surface_contact_animated_detached_state(guide,context.scene.frame_current_final)
        if entry[0][12]==raw and entry[0][13]==animated:
            return not raw
    return _surface_contact_attached_at_frame(guide, context.scene.frame_current)


def _contact_chain_sync(context, guide, *, force=False, solved=None, target_override=None):
    if str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, '')) != SURFACE_CONTACT_KIND_CHAIN:
        return False
    armature, effector = _surface_contact_pose_bone(guide)
    records = _contact_chain_records_at(guide,context.scene.frame_current)
    bones = _contact_chain_bones(guide)
    active = _contact_chain_enabled(context, guide, bones)
    changed = False
    rows = []
    active_names={row[0] for row in records}
    for name, helper_name, constraint_name in _contact_chain_records(guide):
        helper = bpy.data.objects.get(helper_name)
        constraint = armature.pose.bones[name].constraints.get(constraint_name)
        if constraint is None or helper is None:
            active = False
        if name in active_names:rows.append((helper, constraint))
        enabled=active and name in active_names
        if constraint is not None and abs(constraint.influence-float(enabled)) > 1.e-7:
            constraint.influence = float(enabled)
            changed = True
    if not active:
        return changed
    group_outputs=_pin_native_group_chain_outputs(guide,bones)
    if group_outputs is not None:
        for bone,(helper,_constraint),matrix in zip(bones,rows,group_outputs):
            if _pin_keyboard_matrices_differ(helper.matrix_world,matrix,epsilon=1.e-6):
                helper.matrix_world=matrix;changed=True
            if solved is not None:solved[(armature.name,bone.name)]=matrix
        return changed
    if ((_state.get('pin_target_dragging') or _state.get('pin_keyboard_transform_active'))
            and _state.get('pin_transform_waiting_for_motion')
            and _surface_contact_snap_key(guide) in _pin_selected_target_keys()):
        # A handle press is selection. Keep its exact visible pose until a
        # real transform sample arrives, including stale/off-target pins.
        return changed
    target = (Vector(target_override).copy() if target_override is not None else
              _contact_chain_target_matrix(guide).translation.copy())
    attached = _contact_chain_attached(context,guide)
    free = not _contact_chain_uses_contact(guide)
    authored=bool(guide.get('Contact Authored Pose',False))
    edit=_contact_chain_pose_edit_active(context,guide)
    native_rotation=_contact_chain_native_rotation_world(context,guide)
    # Attached animation constrains the joints as well as the surface goal.
    # Some native easing functions add nonzero in-between translations even
    # to almost-flat FK curves. They are not extra lengths between joints.
    joints='REST' if not edit and attached and not free else not authored or edit
    raw = _contact_chain_raw_matrices(context, armature, bones, solved,lock_joints=joints)
    if (not _state.get('pin_snap_transform_active')
            and any(_state.get(k) for k in ('pin_target_dragging','pin_keyboard_transform_active'))
            and _surface_contact_snap_key(guide) in _pin_selected_target_keys()):
        initial=_state.get('contact_chain_edit_snapshot',{}).get('objects',{})
        if all(helper in initial for _name,helper,_constraint in records):
            raw=[initial[helper].copy() for _name,helper,_constraint in records]
    root_frame=_state.get('contact_chain_transform_root_frames',{}).get(guide.name)
    native_move=bool(free and _state.get('pin_snap_transform_active')
        and 'translate' in str(_state.get('pin_snap_transform_operator','')).lower()
        and (_armature_session_uid(armature),effector.name) in _state.get('pin_snap_transform_start_poses',{}))
    if free and edit and root_frame is not None:
        parent_name,parent_start,visible_start=root_frame
        parent_now=armature.matrix_world@armature.pose.bones[parent_name].matrix
        shift=(parent_now@parent_start.inverted_safe()@visible_start).translation-raw[0].translation
        root=bones[0]
        start=_state.get('pin_snap_transform_start_poses',{}).get((_armature_session_uid(armature),root.name))
        space=_chosen_dynamic_parent_constraint(root,context.scene.frame_current)
        movable_root=(native_move or len(bones)>1 or (space is not None
            and _dynamic_space_role(root,space) in (SPACE_ROLE_UNPARENT,SPACE_ROLE_WORLD)))
        if (start is not None and movable_root
                and 'translate' in str(_state.get('pin_snap_transform_operator','')).lower()):
            current=_state.get('contact_chain_selected_native_inputs',{}).get(
                (armature.name,root.name),_pin_authored_pose_basis(root))
            shift+=_contact_chain_location_frame(armature,root,visible_start,parent_start)@(current.translation-start.translation)
        for matrix in raw:matrix.translation+=shift
    if native_rotation is not None:
        position=raw[-1].translation.copy()
        if _contact_chain_uses_contact(guide) and not _contact_chain_is_planted(guide):
            native_rotation=_contact_chain_target_follow_matrix(guide,raw).inverted_safe()@native_rotation
        raw[-1]=native_rotation
        raw[-1].translation=position
    support = Vector(tuple(guide.get(SURFACE_CONTACT_SUPPORT_PROPERTY, (0., effector.length, 0.)))[:3])
    reference=tuple(guide.get('Contact Pose Reference',()))
    bend=float(guide.get(CONTACT_CHAIN_BEND,0.))
    if authored and len(reference)==4:
        animated_bend=any(f.data_path in ('staticaliza_contact_bend','["'+CONTACT_CHAIN_BEND+'"]')
                          for f in _action_fcurves(_dynamic_parent_owner_action(guide),guide))
        bend=_contact_chain_bend_wrap(bend-reference[3]) if edit or animated_bend else 0.
        coincidence=max(1.e-6,max(abs(v) for v in target)*2.**-22)
        native_contact_matches=(free or not attached
            or _state.get('contact_chain_input_editing',False)
            or (_pin_attachment_points_match(_surface_contact_snap_key(guide),target,raw[-1]@support)
                and (target-raw[-1]@support).length_squared<=coincidence*coincidence))
        if not edit and native_contact_matches and (free or (abs(bend)<1.e-8
                and (target-Vector(reference[:3])).length_squared<1.e-12)):
            # Normal pose channels are authoritative. Playback, selection,
            # Record/save and configuration buttons cannot re-solve them.
            for bone,(helper,_constraint),matrix in zip(bones,rows,raw):
                if _pin_keyboard_matrices_differ(helper.matrix_world,matrix,epsilon=1.e-6):
                    helper.matrix_world=matrix;changed=True
                if solved is not None:solved[(armature.name,bone.name)]=matrix
            if attached and not free:
                _contact_chain_verify_attachment(context,guide,tuple(raw),support)
            bias=_contact_chain_bend_bias(raw,support,raw[-1]@support,0.)
            _state.setdefault('contact_chain_solutions',{})[guide.name]=(
                ('FK',tuple(tuple(v for row in m for v in row) for m in raw)),
                tuple(tuple(tuple(v for v in row) for row in m) for m in raw),0.,
                tuple(bias) if bias is not None else None,tuple(raw[-1]@support))
            cache=_state['contact_chain_solutions']
            while len(cache)>128:cache.pop(next(iter(cache)))
            return changed
    magnetic = _contact_chain_magnetic_active(context,guide)
    native_target = (_contact_chain_native_target(context,guide)
                     if free or not attached or magnetic else raw[-1]@support)
    if free and _contact_chain_is_planted(guide) and _state.get('pin_snap_transform_active'):
        owner_selected = (_armature_session_uid(armature), effector.name) in _state.get(
            'pin_snap_transform_start_poses', {})
        baseline = _state.get('contact_chain_transform_effectors', {}).get(guide.name)
        if baseline is not None and not owner_selected and guide.name not in _state.get(
                'contact_chain_committed_inputs', ()):
            joint = raw[-1].translation.copy()
            raw[-1] = baseline.copy()
            # Keep the actual joint input; only the effector tilt is held.
            raw[-1].translation = joint
    if free and len(raw)==1 and _contact_chain_edit_active(context,guide) and not native_move:
        baseline=_state.get('contact_chain_transform_effectors',{}).get(guide.name)
        selected=(_armature_session_uid(armature),effector.name) in _state.get('pin_snap_transform_start_poses',{})
        if baseline is not None and selected:
            # Aim/rotation owns a goal, not a changing rotation frame. Restart
            # every mouse sample from the visible gesture-start orientation.
            parent_selected=any((_armature_session_uid(armature),parent.name) in
                _state.get('pin_snap_transform_start_poses',{}) for parent in effector.parent_recursive)
            joint=raw[0].translation.copy() if parent_selected else baseline.translation.copy()
            if 'translate' in str(_state.get('pin_snap_transform_operator','')).lower():raw[0]=baseline.copy()
            raw[0].translation=joint
    raw, native_target = _contact_chain_target_follow(guide,raw,native_target)
    if guide.name in _state.get('contact_chain_bend_pose_edits',()):
        raw=_contact_chain_bend_edit_matrices(guide,raw)
        bend=0.
    if native_move and len(raw)==1:
        baseline=_state.get('contact_chain_transform_effectors',{}).get(guide.name)
        if baseline is not None:
            position=raw[0].translation.copy();raw[0]=baseline.copy();raw[0].translation=position
            native_target=raw[0]@support
    ik_drag=bool(free and (_state.get('pin_target_dragging') or _state.get('pin_keyboard_transform_active'))
                 and _surface_contact_snap_key(guide) in _pin_selected_target_keys())
    ik_goal=ik_drag
    if ik_goal:native_target=target.copy()
    if free or not attached:
        target = native_target
    if ik_goal and len(raw)==1 and support.length_squared<1.e-12:
        # Bone Start has no lever arm. Use a virtual bone-length aim lever
        # for the same swing solve while displaying the handle at its head.
        support=Vector((0.,max(effector.length,1.e-4),0.))
        target+=raw[-1].to_3x3()@support
    if magnetic:
        raw, magnetic_target = _contact_chain_magnetic_raw(context,guide,raw,support,
            native_target,attached)
        if not attached:
            target = magnetic_target
    planted = bool(attached and not free)
    # Collision/Plant are authoring policies. Running them again while idle
    # feeds deformed sibling geometry back into a previously confirmed pose,
    # causing held-cursor drift and repeated BVH work on every redraw.
    baseline=_state.get('contact_chain_transform_effectors',{}).get(guide.name)
    collision_origin=(baseline@support if baseline is not None else raw[-1]@support)
    collision = (_contact_chain_collision_surface(context,guide,
        target=target,origin=collision_origin,matrices=raw,support=support) if edit else None)
    pressure_target=target.copy()
    if collision is not None:
        # Resolve the support once before Plant reads its contacted face.
        # Solving the same scene ray again inside the joint solver doubled
        # mesh queries on every mouse/slider sample.
        target=_contact_chain_free_target(context,guide,raw,support,target,collision)
    plant_edit=_contact_chain_plant_edit_active(context,guide)
    surface_signature = (() if collision is None else
        (int(collision[0].session_uid), tuple(v for row in collision[2][1] for v in row),
         int(collision[0].data.session_uid), float(context.scene.frame_current_final)))
    signature = (tuple(tuple(v for row in matrix for v in row) for matrix in raw),
                 tuple(target), tuple(pressure_target), tuple(support), bend, tuple(records), planted, surface_signature,
                 plant_edit, free, native_move, ik_goal)
    cache = _state.setdefault('contact_chain_solutions', {})
    cached = cache.get(guide.name)
    if (not force and cached is not None and len(cached)>=5 and cached[0] == signature
            and not (collision is not None and any(update.is_updated_geometry
                and update.id.original in (collision[0],collision[0].data)
                for update in collision[1].updates))):
        outputs, residual = cached[1],cached[2]
    else:
        outputs,residual,target=_contact_chain_solve_pose(context,guide,raw,support,target,bend,
            collision=collision,root_fixed=free and not (native_move and len(raw)==1),
            collision_target_prepared=collision is not None,aim_effector=ik_goal,pressure_target=pressure_target)
        bias=_contact_chain_bend_bias(raw,support,target,bend)
        cache[guide.name] = (signature, tuple(outputs), float(residual),
                            tuple(bias) if bias is not None else None,tuple(target))
        while len(cache) > 128:
            cache.pop(next(iter(cache)))
    if attached and _contact_chain_uses_contact(guide):
        _contact_chain_verify_attachment(context,guide,outputs,support)
    for bone, (helper, _constraint), values in zip(bones, rows, outputs):
        matrix = Matrix(values)
        if _pin_keyboard_matrices_differ(helper.matrix_world, matrix, epsilon=1.e-6):
            helper.matrix_world = matrix
            changed = True
        if solved is not None:
            solved[(armature.name, bone.name)] = matrix
    return changed


def _contact_chain_sync_all(context, *, force=False, guide_names=None):
    if context is None or _state.get('contact_chain_syncing') or _state.get('contact_chain_input_editing') or any(_state.get(k) for k in (
            'pin_history_active', 'pin_history_syncing', 'surface_contact_creation_active',
            'ragdoll_syncing', 'ragdoll_native_evaluating',
            'unparent_handler_mute','dynamic_space_reconciling')):
        return False
    guides = [g for g in _surface_contact_guides() if g.name in context.scene.objects
              and (guide_names is None or g.name in guide_names)
              and (g.get(SURFACE_CONTACT_KIND_PROPERTY) == SURFACE_CONTACT_KIND_CHAIN
                   or (g.get(SURFACE_CONTACT_KIND_PROPERTY) == SURFACE_CONTACT_KIND_CONTROL
                       and not _contact_chain_uses_contact(g)))]
    if not guides:
        return False
    _state['contact_chain_syncing'] = True
    try:
        solved = {}
        # The visible special-channel timing policy also drives chain/IK
        # targets. Legacy single-rod frame settling does not visit chains.
        changed = _pin_sync_contact_curve_policies(context,guides,context.scene.frame_current_final)
        if changed:context.view_layer.update()
        # Parent branches publish before child branches. Overlapping chains
        # are rejected at configuration; no iterative cross-chain feedback.
        guides.sort(key=lambda g: len(_contact_chain_bones(g)[0].parent_recursive)
                    if _contact_chain_bones(g) else 0)
        for guide in guides:
            if guide.get(SURFACE_CONTACT_KIND_PROPERTY) == SURFACE_CONTACT_KIND_CONTROL:
                changed = _surface_contact_set_constraint_attachment(guide,False) or changed
                continue
            changed = _contact_chain_sync(context, guide, force=force, solved=solved) or changed
        return changed
    finally:
        _state['contact_chain_syncing'] = False


def _contact_chain_apply_target_matrix(context, guide, desired, keep_attached):
    """Publish a modal target atomically; native pre-flushes own no new input."""
    previous = _state.get('contact_chain_input_editing', False)
    _state['contact_chain_input_editing'] = True
    try:
        projected = (_surface_contact_bound_surface_point(context, guide, desired.translation)
                     if _contact_chain_uses_contact(guide) else
                     (desired.translation.copy(), desired.to_3x3().col[2].normalized()))
        if projected is None:
            return False
        point, normal = projected
        if _contact_chain_uses_contact(guide):
            if not _surface_contact_set_guide_surface_point(context, guide, point, normal, update_view_layer=False):
                return False
        world = _surface_contact_plane_matrix(point, normal, desired) if _contact_chain_uses_contact(guide) else desired.copy()
        # Evaluating the follow surface can replay this guide's previous key.
        # Commit the pending sample after that read, before solving the chain.
        if _pin_keyboard_matrices_differ(guide.matrix_world,world):guide.matrix_world=world
        if keep_attached or not _contact_chain_uses_contact(guide):
            _surface_contact_clear_snap_departure(guide)
        else:
            _surface_contact_set_snap_detached(guide, True)
        if guide.get(SURFACE_CONTACT_KIND_PROPERTY) == SURFACE_CONTACT_KIND_CONTROL:
            _surface_contact_refine_control_solver(context, guide, desired_point=point)
        else:
            _contact_chain_sync(context, guide, target_override=world.translation)
        context.view_layer.update()
        # IK displays its real mesh attachment, independently of this goal.
        # Keep the requested goal immutable through dependency re-evaluation;
        # replacing a Bone Start goal with its stationary display point would
        # undo the aim on the very next redraw.
        if _pin_keyboard_matrices_differ(guide.matrix_world,world):guide.matrix_world=world
        return True
    finally:
        _state['contact_chain_input_editing'] = previous


def _contact_chain_driver(pose_bone, frame, *, include_suspended=False):
    owner = getattr(pose_bone, 'id_data', None)
    for guide in _surface_contact_guides():
        if (guide.get(SURFACE_CONTACT_KIND_PROPERTY) != SURFACE_CONTACT_KIND_CHAIN
                or str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, '')) != owner.name
                or str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, '')) == pose_bone.name):
            continue
        active=_surface_contact_guide_interval_active_at(guide,int(frame))
        if not include_suspended and _surface_contact_ragdoll_override(guide,frame):continue
        if (active and pose_bone.name in {row[0] for row in _contact_chain_records(guide)}):
            return guide
    return None


def _contact_chain_constraint_message(bone,frame):
    # Physics and an unavailable collider suspend solving, not ownership.
    driver=_contact_chain_driver(bone,frame,include_suspended=True)
    if driver is None:return ''
    return ('Driven by '+json.dumps(str(driver.get(SURFACE_CONTACT_BONE_PROPERTY,'')))
            +'. Edit that bone\'s constraint instead of adding another.')


class ANIMATOR_UTILS_OT_contact_chain_count(bpy.types.Operator):
    bl_idname = 'staticaliza.contact_chain_count'
    bl_label = 'Chain'
    bl_description = 'Parent bones controlled by the pin: 0 = pinned bone only; 1 = add its parent; 2 = add two parents'
    bl_options = {'REGISTER', 'UNDO', 'UNDO_GROUPED'}
    __annotations__=_contact_settings_properties()

    def draw(self, context):
        _draw_contact_settings_operator(self,context)

    @classmethod
    def poll(cls, context):
        return context.mode == 'POSE'

    def execute(self, context):
        return _contact_settings_execute(self,context)


def _contact_chain_bend_rest_matrices(guide):
    """One rig/parent-space angular zero for explicit edits and the indicator."""
    owner,_bone=_surface_contact_pose_bone(guide)
    bones=tuple(owner.pose.bones[row[0]] for row in _contact_chain_records_at(
        guide,bpy.context.scene.frame_current))
    if len(bones)<2:return ()
    parent=bones[0].parent
    frame=owner.matrix_world.copy()
    if parent is not None:
        evaluated=owner.evaluated_get(bpy.context.evaluated_depsgraph_get())
        frame=frame@evaluated.pose.bones[parent.name].matrix@parent.bone.matrix_local.inverted_safe()
    return [frame@b.bone.matrix_local for b in bones]


def _contact_chain_bend_default(guide,rest):
    """Resolve topology and native rig hints in armature-local rest space."""
    owner,_bone=_surface_contact_pose_bone(guide)
    bones=tuple(owner.pose.bones[row[0]] for row in _contact_chain_records_at(
        guide,bpy.context.scene.frame_current))
    if not rest or len(bones)!=len(rest):return None
    local=[b.bone.matrix_local.copy() for b in bones]
    pole=None
    for index,bone in reversed(tuple(enumerate(bones))):
        for constraint in bone.constraints:
            if constraint.type!='IK' or constraint.mute or constraint.pole_target is None:continue
            if constraint.chain_count and constraint.chain_count<index+1:continue
            target=constraint.pole_target
            if target==owner and constraint.pole_subtarget in owner.data.bones:
                pole=owner.data.bones[constraint.pole_subtarget].head_local.copy()
            # Object controls expose their current pose, not a rest-bone
            # alignment. They cannot redefine zero when a chain is created.
            if pole is not None:break
        if pole is not None:break
    hinges=[]
    for index,bone in enumerate(bones[1:-1],1):
        outgoing=local[-1].translation-local[index].translation
        for column,letter in ((0,'x'),(2,'z'),(1,'y')):
            if getattr(bone,'lock_ik_'+letter) or not getattr(bone,'use_ik_limit_'+letter):continue
            low,high=getattr(bone,'ik_min_'+letter),getattr(bone,'ik_max_'+letter)
            sign=1. if low>=-1.e-6 and high>1.e-4 else -1. if high<=1.e-6 and low<-1.e-4 else 0.
            if sign:
                vector=outgoing.cross(local[index].to_3x3().col[column])*sign
                score=(high-low)*vector.length/max(outgoing.length,1.e-12)
                hinges.append((score,vector))
    hinges=[vector for _score,vector in sorted(hinges,key=lambda item:-item[0])]
    continuations=[bones[-1].bone.tail_local-bones[-1].bone.head_local]
    children=bones[-1].children
    # Equal branches describe a fan; average coherent geometry rather than
    # choosing whichever finger happens to be named or enumerated first.
    if children:
        vectors=[b.bone.tail_local-bones[-1].bone.head_local for b in children]
        fan=sum(vectors,Vector())
        if fan.length>sum(v.length for v in vectors)*.1:continuations.append(fan)
    default=_contact_chain_natural_bend(local,pole=pole,hinges=hinges,continuations=continuations)
    frame=rest[0]@local[0].inverted_safe()
    default=frame.to_3x3()@default
    axis=_contact_chain_unit(rest[-1].translation-rest[0].translation,rest[0].to_3x3().col[1])
    return _contact_chain_unit(default-axis*default.dot(axis),_contact_chain_bend_fallback(rest))


def _contact_chain_solver_bend_fallback(guide,raw,bend):
    """Straight solves use the same zero as edits/display, in their input frame."""
    if len(raw)<2:return None
    rest=_contact_chain_bend_rest_matrices(guide)
    default=_contact_chain_bend_default(guide,rest)
    if default is None:return None
    rest_axis=_contact_chain_unit(rest[-1].translation-rest[0].translation,rest[0].to_3x3().col[1])
    # The caller applies its uncommitted delta; do not count that angle twice.
    seed=float(guide.get(CONTACT_CHAIN_BEND,0.))-float(bend)
    default=Quaternion(rest_axis,seed)@default
    return _contact_chain_swing(rest_axis,raw[-1].translation-raw[0].translation,default)@default


def _contact_chain_bend_indicator(guide, worlds, *, rest=None, default=None):
    """The configured bend direction, from rest joints in their parent frame.

    The indicator describes Bend, not the last solver candidate. Reading a
    cached candidate made native G, collision, and Cancel pick different
    reference planes even when the setting had not changed.
    """
    if rest is None:rest=_contact_chain_bend_rest_matrices(guide)
    if not rest or len(worlds)!=len(rest):return None
    # G changes the reach vector, not the configured angular reference.
    # Transporting this frame toward the live foot direction made the marker
    # rotate throughout a drag even though Bend never changed.
    if default is None:default=_contact_chain_bend_default(guide,rest)
    if default is None:return None
    axis=_contact_chain_unit(rest[-1].translation-rest[0].translation,rest[0].to_3x3().col[1])
    return Quaternion(axis,float(guide.get(CONTACT_CHAIN_BEND,0.)))@default


def _contact_chain_bend_arrow_geometry():
    """An unlit eight-sided shaft/cone, matching the former 18px plain arrow."""
    vertices=[]
    sides=8
    for i in range(sides):
        a,b=math.tau*i/sides,math.tau*(i+1)/sides
        x,y=math.cos(a),math.sin(a)
        u,v=math.cos(b),math.sin(b)
        low=(x*.95,y*.95,0.);next_low=(u*.95,v*.95,0.)
        high=(x*.95,y*.95,19.5);next_high=(u*.95,v*.95,19.5)
        rim=(x*2.,y*2.,19.5);next_rim=(u*2.,v*2.,19.5)
        vertices.extend((low,next_low,high,high,next_low,next_high,
                         (0.,0.,0.),next_low,low,
                         rim,next_rim,(0.,0.,27.),
                         (0.,0.,19.5),next_rim,rim))
    return tuple(vertices)


def _contact_chain_bend_arrow_matrix(context,center,direction,reach_axis):
    """World-aligned geometry; only its nominal pixel scale follows the view."""
    forward=Vector(direction)
    if forward.length_squared<1.e-12:return None
    clip=context.region_data.perspective_matrix@Vector((*Vector(center),1.))
    focal=abs(context.region_data.window_matrix[1][1])
    height=context.region.height
    if clip.w<=1.e-8 or focal<=1.e-8 or height<=0:return None
    scale=2.*clip.w/(height*focal)
    forward.normalize()
    side=Vector(reach_axis).cross(forward)
    if side.length_squared<1.e-12:side=forward.orthogonal()
    side.normalize()
    up=forward.cross(side)
    world=Matrix((side*scale,up*scale,forward*scale)).transposed().to_4x4()
    world.translation=Vector(center)
    return world


def _draw_contact_chain_bend_arrows(context,matrices,color=CONTACT_CHAIN_COLOR):
    """Opaque x-ray geometry with exactly the dotted links' color pipeline."""
    if not matrices:return
    cached=_state.get('contact_chain_arrow_batch')
    if cached is None:
        info=gpu.types.GPUShaderCreateInfo()
        info.vertex_in(0,'VEC3','pos')
        info.push_constant('MAT4','mvp')
        info.push_constant('VEC4','color')
        info.fragment_out(0,'VEC4','FragColor')
        info.vertex_source('void main(){gl_Position=mvp*vec4(pos,1.0);}')
        info.fragment_source('void main(){FragColor=color;}')
        shader=gpu.shader.create_from_info(info)
        cached=(shader,batch_for_shader(shader,'TRIS',{'pos':_contact_chain_bend_arrow_geometry()}))
        _state['contact_chain_arrow_batch']=cached
    shader,batch=cached
    depth,blend=gpu.state.depth_test_get(),gpu.state.blend_get()
    try:
        gpu.state.depth_test_set('NONE')
        gpu.state.blend_set('ALPHA')
        shader.bind()
        shader.uniform_float('color',(*color,1.))
        for matrix in matrices:
            shader.uniform_float('mvp',context.region_data.perspective_matrix@matrix)
            batch.draw(shader)
    finally:
        gpu.state.depth_test_set(depth)
        gpu.state.blend_set(blend)



def _draw_contact_chain_links(context, guides):
    """One bounded 2D batch of pale-pink dot/dash/dot joint connections."""
    groups={}
    for guide in guides:groups.setdefault(_contact_chain_uses_contact(guide),[]).append(guide)
    if len(groups)>1:
        for group in groups.values():_draw_contact_chain_links(context,group)
        return
    color=_contact_chain_color(guides[0],driven=True) if guides else CONTACT_CHAIN_COLOR
    line_positions, dots, arrows = [], [], []
    scope = {owner.name for owner in _pose_scope_armatures(context)}
    depsgraph = context.evaluated_depsgraph_get()
    evaluated = {}
    for guide in guides:
        if (guide.get(SURFACE_CONTACT_KIND_PROPERTY) != SURFACE_CONTACT_KIND_CHAIN
                or str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, '')) not in scope
                or not _surface_contact_guide_interval_active_at(guide, context.scene.frame_current)
                or _surface_contact_ragdoll_override(guide,context.scene.frame_current)):
            continue
        owner, _bone = _surface_contact_pose_bone(guide)
        display=_contact_chain_records_at(guide,context.scene.frame_current,include_attachment=True)
        chain=tuple(owner.pose.bones[row[0]] for row in display)
        if _contact_chain_parent_count(guide)<1:
            continue
        if owner.name not in evaluated:
            evaluated[owner.name] = owner.evaluated_get(depsgraph)
        rig = evaluated[owner.name]
        previous = None
        for name, _helper, _constraint in _contact_chain_records(guide):
            bone = rig.pose.bones.get(name)
            if bone is None or not _pose_bone_is_visible(owner.pose.bones.get(name)):
                previous = None
                continue
            head,tail=rig.matrix_world @ bone.head,rig.matrix_world @ bone.tail
            space=_chosen_dynamic_parent_constraint(owner.pose.bones[name],context.scene.frame_current)
            if space is not None and (space.name.startswith('DP_') or
                    _dynamic_space_role(owner.pose.bones[name],space) in (SPACE_ROLE_UNPARENT,SPACE_ROLE_WORLD)):
                previous=None
            spans=[(head,tail)]
            if previous is not None and (previous-head).length_squared>1.e-12:
                spans.insert(0,(previous,head))
            for source,destination in spans:
                segment, start, end = _project_world_segment_2d(context, source, destination)
                if segment is not None:
                    a, b = Vector(segment[0]), Vector(segment[1])
                    length = (b-a).length
                    if length > 1.e-6:
                        direction = (b-a)/length
                        for i in range(min(256, int(length/8.)+1)):
                            distance = i*8.
                            line_positions.extend((a+direction*distance, a+direction*min(length, distance+4.)))
                for point in (start, end):
                    if point is not None:
                        dots.extend(_circle_tris_2d(point, 2.))
            previous = tail
        if len(chain)>1 and any(_pose_bone_is_visible(b) for b in chain):
            joints=[rig.matrix_world@rig.pose.bones[b.name].head for b in chain]
            axis=joints[-1]-joints[0]
            if len(joints)>2 and axis.length_squared>1.e-12:
                # The strongest deviation identifies the actual bend, even
                # for unequal segments and long chains with helper bones.
                center=max(joints[1:-1],key=lambda p:(p-joints[0]).cross(axis).length_squared)
            else:center=joints[-1]
            worlds=[rig.matrix_world@rig.pose.bones[b.name].matrix for b in chain]
            bias=_contact_chain_bend_indicator(guide,worlds)
            if bias is not None:
                reach=(rig.pose.bones[chain[-1].name].head-rig.pose.bones[chain[0].name].head)
                matrix=_contact_chain_bend_arrow_matrix(context,center,bias,rig.matrix_world.to_3x3()@reach)
                if matrix is not None:arrows.append(matrix)
    if not line_positions and not dots:
        _draw_contact_chain_bend_arrows(context,arrows,color)
        return
    shader = _ensure_shader_2d()
    shader.bind()
    shader.uniform_float('u_viewport', (float(context.region.width), float(context.region.height)))
    shader.uniform_float('color', (*color, 1.))
    if line_positions:
        batch_for_shader(shader, 'LINES', {'pos': line_positions}).draw(shader)
    if dots:
        batch_for_shader(shader, 'TRIS', {'pos': dots}).draw(shader)
    _draw_contact_chain_bend_arrows(context,arrows,color)


def _contact_chain_restore_history_inputs(context,transition,index):
    """A verified native history side owns all of its chain source bases."""
    bases={(owner,name):before if index==0 else after
           for owner,name,before,after in transition.get('chain_inputs',())}
    if bases:_pin_restore_action_pose_bases(context,bases)



def _contact_chain_capture_history_inputs(context):
    """Keep restored native FK through the first post-history Action flush.

    Parent inputs matter even when Chain excludes them: they define the
    solved root frame. Snapshot raw bases before any evaluated read.
    """
    entries={}
    for guide in _surface_contact_guides():
        if guide.name not in context.scene.objects:continue
        bones=_contact_chain_bones(guide)
        if guide.get(SURFACE_CONTACT_KIND_PROPERTY)!=SURFACE_CONTACT_KIND_CHAIN or not _contact_chain_enabled(context,guide,bones):continue
        owner,_bone=_surface_contact_pose_bone(guide)
        for bone in (*bones,*bones[0].parent_recursive):
            entries[(owner.name,bone.name)]=(owner.name,bone.name,_pin_authored_pose_basis(bone),None)
    return tuple(entries.values())
