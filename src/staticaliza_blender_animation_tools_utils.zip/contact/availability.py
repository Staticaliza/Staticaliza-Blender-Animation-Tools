"""Dormant contacts retain their settings until a real surface is available."""

from ..core.runtime import *  # noqa: F403


def _surface_contact_has_valid_surface(guide):
    if not _contact_chain_uses_contact(guide):
        return True
    if guide.get("Contact Surface Unavailable", False):
        return False
    surface = guide.get("Contact Surface Object")
    if "Contact Surface Object" not in guide:
        surface = bpy.data.objects.get(str(guide.get(SURFACE_CONTACT_SURFACE_PROPERTY, "")))
    return bool(surface is not None and surface.type == "MESH"
                and any(surface.name in scene.objects for scene in guide.users_scene)
                and len(surface.data.polygons))


def _surface_contact_disable_missing_surface(guide):
    if not _contact_chain_uses_contact(guide):
        return False
    changed = False
    if not bool(guide.get("Contact Surface Unavailable", False)):
        guide["Contact Surface Unavailable"] = True
        changed = True
    for constraint in _surface_contact_constraints(guide):
        if constraint is not None and constraint.influence != 0.0:
            constraint.influence = 0.0
            changed = True
    key = _surface_contact_snap_key(guide)
    _state.setdefault("pin_snap_latches", set()).discard(key)
    _state.setdefault("pin_snap_pressure_active", set()).discard(key)
    if changed:
        _surface_contact_clear_derived_caches()
    return changed


def _surface_contact_retry_surface(context, guide):
    if _surface_contact_has_valid_surface(guide):
        return False
    _surface_contact_disable_missing_surface(guide)
    armature, bone = _surface_contact_pose_bone(guide)
    if bone is None:
        return False
    geometry_name = str(guide.get(SURFACE_CONTACT_GEOMETRY_BONE_PROPERTY, bone.name))
    geometry_bone = armature.pose.bones.get(geometry_name)
    if geometry_bone is None:
        return False
    evaluated, evaluated_bone, part, points, supports = _surface_contact_part_geometry(
        context, armature, geometry_bone)
    if part is None or not points:
        return False
    axis = str(guide.get(SURFACE_CONTACT_CAST_AXIS_PROPERTY, "Y_NEG"))
    anchor, smart_name, smart_local = _surface_contact_creation_anchor(
        context, context.evaluated_depsgraph_get(), armature, evaluated,
        evaluated_bone, part, points, supports,
        pin_mode=str(guide.get(SURFACE_CONTACT_PIN_MODE_PROPERTY, "MODE_3")), pin_axis=axis)
    if anchor is None:
        return False
    surface, point, normal, _length = _surface_contact_detect_surface(
        context, armature, evaluated, evaluated_bone, points, supports,
        anchor, smart_name, cast_axis=axis)
    if surface is None or point is None or normal is None:
        return False
    if not _surface_contact_bind_guide_surface(context, guide, surface, point):
        return False
    _surface_contact_set_guide_surface_point(context, guide, point, normal)
    guide["Contact Surface Unavailable"] = False
    _surface_contact_set_snap_detached(guide, True)
    _surface_contact_seed_runtime_signatures(context, (guide,))
    return True



def _surface_contact_relink_orphaned_guides(context):
    """Restore managed helper membership only while its authored Start exists."""
    changed = False
    for guide in _surface_contact_guides():
        if guide.name in context.scene.objects:
            if not guide.hide_get():
                guide.hide_set(True)
                changed = True
            continue
        armature, bone = _surface_contact_pose_bone(guide)
        if (bone is None or armature.name not in context.scene.objects
                or _surface_contact_marker_points(bone).get(
                    int(guide.get(SURFACE_CONTACT_START_PROPERTY, 0)), 0.0) < .5):
            continue
        collection = _ensure_space_helper_collection(context, armature)
        if guide.name not in collection.objects:
            collection.objects.link(guide)
        solver = _surface_contact_solver_from_guide(guide)
        if (solver is not None and solver != guide
                and solver.name not in collection.objects):
            collection.objects.link(solver)
        guide.hide_set(True)
        if solver is not None and solver != guide:
            solver.hide_set(True)
        surface = guide.get("Contact Surface Object")
        if (surface is not None and surface.type == "MESH"
                and surface.name in context.scene.objects and len(surface.data.polygons)):
            # An orphan has no users_scene, which marks even its existing
            # binding unavailable. Preserve that binding and its authored keys.
            guide["Contact Surface Unavailable"] = False
        changed = True
    if changed:
        _surface_contact_invalidate_guide_cache()
    return changed


def _surface_contact_availability_poll():
    if not _state.get("extension_registered", False):
        return None
    context = bpy.context
    if (context.scene is None or _state.get("surface_contact_availability_syncing")
            or _state.get("pin_history_active") or _state.get("surface_contact_creation_active")
            or _pin_active_transform_operator(context) or _state.get("pin_target_dragging")):
        return 0.25
    stamp = (int(context.scene.as_pointer()), len(context.scene.objects), context.scene.frame_current)
    if (not _state.get("surface_contact_availability_dirty", True)
            and _state.get("surface_contact_availability_stamp") == stamp):
        return 0.25
    _state["surface_contact_availability_dirty"] = False
    _state["surface_contact_availability_stamp"] = stamp
    _state["surface_contact_availability_syncing"] = True
    try:
        changed = _surface_contact_relink_orphaned_guides(context)
        for guide in _surface_contact_guides():
            if guide.name not in context.scene.objects:
                continue
            surface = guide.get("Contact Surface Object")
            old_name = str(guide.get(SURFACE_CONTACT_SURFACE_PROPERTY, ""))
            if surface is not None and old_name != surface.name:
                guide[SURFACE_CONTACT_SURFACE_PROPERTY] = surface.name
                if str(guide.get(SURFACE_CONTACT_FOLLOW_OBJECT_PROPERTY, "")) == old_name:
                    guide[SURFACE_CONTACT_FOLLOW_OBJECT_PROPERTY] = surface.name
                changed = True
            if not _surface_contact_has_valid_surface(guide):
                changed = _surface_contact_disable_missing_surface(guide) or changed
                if _surface_contact_guide_interval_active_at(guide, context.scene.frame_current):
                    changed = _surface_contact_retry_surface(context, guide) or changed
        if changed:
            context.view_layer.update()
            _tag_redraw_all_view3d()
    finally:
        _state["surface_contact_availability_syncing"] = False
    return 0.25
