"""Preserve confirmed Contact solves across unrelated same-frame Action refreshes."""

from ..core.runtime import *  # noqa: F403


def _contact_idle_inputs(context, guide):
    armature, bone = _surface_contact_pose_bone(guide)
    if bone is None:
        return None
    names = set(_surface_contact_related_bone_names(guide))
    names.update(parent.name for parent in bone.parent_recursive)
    prefixes = tuple(armature.pose.bones[name].path_from_id() for name in names
                     if name in armature.pose.bones)
    action = _dynamic_parent_owner_action(armature)
    curves = tuple(sorted((curve.data_path, curve.array_index, curve.mute,
        round(curve.evaluate(context.scene.frame_current_final), 9),
        tuple((tuple(key.co), key.interpolation, key.easing,
               tuple(key.handle_left), tuple(key.handle_right)) for key in curve.keyframe_points))
        for curve in _action_fcurves(action, armature)
        if any(curve.data_path.startswith(prefix+'.') or curve.data_path.startswith(prefix+'[')
               for prefix in prefixes)))
    ancestors = tuple((parent.name, tuple(v for row in parent.matrix_basis for v in row))
                      for parent in bone.parent_recursive)
    surface = guide.get("Contact Surface Object")
    if surface is None:
        surface = bpy.data.objects.get(str(guide.get(SURFACE_CONTACT_SURFACE_PROPERTY, "")))
    surface_matrix = tuple(v for row in surface.matrix_world for v in row) if surface is not None else ()
    constraints = []
    for name in sorted(names):
        if name not in armature.pose.bones:
            continue
        for constraint in armature.pose.bones[name].constraints:
            target = getattr(constraint, "target", None)
            subtarget = str(getattr(constraint, "subtarget", ""))
            target_matrix = target.matrix_world.copy() if target is not None else Matrix.Identity(4)
            if target is not None and getattr(target, "pose", None) and subtarget in target.pose.bones:
                target_matrix @= target.pose.bones[subtarget].matrix
            constraints.append((name, constraint.name, constraint.type, constraint.influence,
                constraint.mute, subtarget, tuple(v for row in target_matrix for v in row)))
    return (int(armature.as_pointer()), int(guide.as_pointer()),
            float(context.scene.frame_current_final), curves, ancestors, tuple(constraints),
            tuple(v for row in armature.matrix_world for v in row),
            tuple(v for row in guide.matrix_world for v in row), surface_matrix,
            tuple(guide.get(SURFACE_CONTACT_POINT_PROPERTY, ())),
            tuple(guide.get(SURFACE_CONTACT_NORMAL_PROPERTY, ())),
            str(guide.get(SURFACE_CONTACT_CAST_AXIS_PROPERTY, "")))


def _surface_contact_capture_idle_pose(context, guide):
    armature, bone = _surface_contact_pose_bone(guide)
    if bone is None:
        return
    names = set(_surface_contact_related_bone_names(guide))
    names.update(parent.name for parent in bone.parent_recursive)
    snapshot = {name: armature.pose.bones[name].matrix_basis.copy()
                for name in names if name in armature.pose.bones}
    _state.setdefault("contact_idle_confirmed_poses", {})[guide.name] = (
        _contact_idle_inputs(context, guide), armature.name, snapshot)


def _contact_idle_raw_action_matches(armature, bone, basis, frame):
    """A direct unkeyed pose edit is not an Action replay."""
    action = _dynamic_parent_owner_action(armature)
    prefix = bone.path_from_id()+'.'
    paths = {prefix+prop: prop for prop in ("location", "rotation_euler",
             "rotation_quaternion", "rotation_axis_angle", "scale")}
    curves = [c for c in _action_fcurves(action, armature) if c.data_path in paths and not c.mute]
    if not curves or not _pin_keyboard_matrices_differ(bone.matrix_basis, basis, epsilon=1.e-6):
        return False
    return all(abs(getattr(bone, paths[c.data_path])[c.array_index]-c.evaluate(frame)) < 1.e-5
               for c in curves)


def _surface_contact_restore_idle_action_pose(context, guides):
    saved = _state.setdefault("contact_idle_confirmed_poses", {})
    restore = {}
    restored = set()
    for guide in guides:
        entry = saved.get(guide.name)
        current_inputs = _contact_idle_inputs(context, guide)
        # Ancestor bases may themselves have been replayed from the unchanged
        # Action. Compare authored inputs first, then validate every changed
        # raw basis below; real parent edits must continue to evaluate normally.
        if (entry is None or current_inputs is None
                or entry[0][:4] + entry[0][5:] != current_inputs[:4] + current_inputs[5:]):
            continue
        armature, bone = _surface_contact_pose_bone(guide)
        if bone is None or armature.name != entry[1]:
            continue
        if (_ragdoll_active(bone, context.scene.frame_current)
                or _constraint_pin_gyro_blocks_contact(guide, context.scene.frame_current)):
            continue
        changed = [(armature.pose.bones[name], basis) for name, basis in entry[2].items()
                   if name in armature.pose.bones and _pin_keyboard_matrices_differ(
                       armature.pose.bones[name].matrix_basis, basis, epsilon=1.e-6)]
        if not changed or not all(_contact_idle_raw_action_matches(armature, current, basis,
                                  context.scene.frame_current_final) for current, basis in changed):
            continue
        restore.update({(armature.name, name): basis for name, basis in entry[2].items()})
        restored.add(guide.name)
    if restore:
        previous = _state.get("surface_contact_action_repair_active", False)
        _state["surface_contact_action_repair_active"] = True
        try:
            _pin_restore_action_pose_bases(context, restore)
        finally:
            _state["surface_contact_action_repair_active"] = previous
    return restored
