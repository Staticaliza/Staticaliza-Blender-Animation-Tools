"""Preserve confirmed Contact solves across unrelated same-frame Action refreshes."""

from ..core.runtime import *  # noqa: F403


def _contact_chain_advance_idle_frame(context):
    """Same-frame replay protection expires on every real timeline seek.

    Returning to an old frame must read its Action, not revive the unkeyed
    source snapshot that happened to be present the last time it was edited.
    Chains do not participate in the legacy single-rod frame settle path.
    """
    if context is None:return
    tag=(int(context.scene.session_uid),float(context.scene.frame_current_final))
    if _state.get('contact_idle_frame')!=tag:
        _state['contact_idle_frame']=tag
        _state.setdefault('contact_idle_confirmed_poses',{}).clear()


def _contact_idle_inputs(context, guide):
    armature, bone = _surface_contact_pose_bone(guide)
    if bone is None:
        return None
    names = set(_surface_contact_related_bone_names(guide))
    names.update(parent.name for parent in bone.parent_recursive)
    prefixes = tuple(armature.pose.bones[name].path_from_id() for name in names
                     if name in armature.pose.bones)
    action = _dynamic_parent_owner_action(armature)
    curves = tuple(sorted((curve.data_path, curve.array_index, curve.mute,
        round(curve.evaluate(context.scene.frame_current_final), 9),
        tuple((tuple(key.co), key.interpolation, key.easing,
               tuple(key.handle_left), tuple(key.handle_right)) for key in curve.keyframe_points))
        for curve in _action_fcurves(action, armature)
        if any(curve.data_path.startswith(prefix+'.') or curve.data_path.startswith(prefix+'[')
               for prefix in prefixes)))
    ancestors = tuple((parent.name, tuple(v for row in parent.matrix_basis for v in row))
                      for parent in bone.parent_recursive)
    surface = guide.get("Contact Surface Object")
    if surface is None:
        surface = bpy.data.objects.get(str(guide.get(SURFACE_CONTACT_SURFACE_PROPERTY, "")))
    surface_matrix = tuple(v for row in surface.matrix_world for v in row) if surface is not None else ()
    constraints = []
    chain_outputs = {row[2] for row in _contact_chain_records(guide)}
    for name in sorted(names):
        if name not in armature.pose.bones:
            continue
        for constraint in armature.pose.bones[name].constraints:
            if constraint.name in chain_outputs:
                continue  # Published output is not a source animation input.
            target = getattr(constraint, "target", None)
            subtarget = str(getattr(constraint, "subtarget", ""))
            target_matrix = target.matrix_world.copy() if target is not None else Matrix.Identity(4)
            if target is not None and getattr(target, "pose", None) and subtarget in target.pose.bones:
                target_matrix @= target.pose.bones[subtarget].matrix
            constraints.append((name, constraint.name, constraint.type, constraint.influence,
                constraint.mute, subtarget, tuple(v for row in target_matrix for v in row)))
    return (int(armature.session_uid), int(guide.session_uid),
            float(context.scene.frame_current_final), curves, ancestors, tuple(constraints),
            tuple(v for row in armature.matrix_world for v in row),
            tuple(v for row in guide.matrix_world for v in row), surface_matrix,
            tuple(guide.get(SURFACE_CONTACT_POINT_PROPERTY, ())),
            tuple(guide.get(SURFACE_CONTACT_NORMAL_PROPERTY, ())),
            str(guide.get(SURFACE_CONTACT_CAST_AXIS_PROPERTY, "")),
            bool(guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)),
            _surface_contact_animated_detached_state(guide, context.scene.frame_current_final),
            # A settings Undo restores a different FK conversion. Its outgoing
            # confirmed pose is not an unchanged Action replay.
            (str(guide.get(SURFACE_CONTACT_KIND_PROPERTY,'')),
             int(guide.get(SURFACE_CONTACT_CHAIN_PROPERTY,1)),
             bool(guide.get(CONTACT_CHAIN_CONTACT,True)),
             bool(guide.get(CONTACT_CHAIN_PLANTED,False)),
             float(guide.get(CONTACT_CHAIN_BEND,0.)),
             tuple(guide.get(SURFACE_CONTACT_SUPPORT_PROPERTY,())))
             + (('CLIP',) if guide.get('Contact Clip',False) else ()))


def _surface_contact_capture_idle_pose(context, guide):
    _contact_chain_advance_idle_frame(context)
    if (guide.get(SURFACE_CONTACT_KIND_PROPERTY)==SURFACE_CONTACT_KIND_CHAIN
            and guide.name in _state.get('contact_idle_confirmed_poses',{})
            and any(_state.get(key) for key in ('surface_contact_creation_active',
                'constraint_creation_transaction','pin_snap_transform_active',
                'pin_target_dragging','pin_keyboard_transform_active',
                'unparent_handler_mute','dynamic_space_reconciling','ragdoll_syncing'))):
        # A shared Action can be between replay and source restoration here.
        # Only the completed transaction may replace a confirmed chain input.
        return
    armature, bone = _surface_contact_pose_bone(guide)
    if bone is None:
        return
    names = set(_surface_contact_related_bone_names(guide))
    names.update(parent.name for parent in bone.parent_recursive)
    snapshot = {name: _pin_authored_pose_basis(armature.pose.bones[name])
                for name in names if name in armature.pose.bones}
    inputs=_contact_idle_inputs(context,guide)
    _state.setdefault("contact_idle_confirmed_poses", {})[guide.name] = (inputs,armature.name,snapshot)
    if not any(_state.get(k) for k in ('pin_history_active','pin_history_syncing',
            'surface_contact_frame_evaluation_active','surface_contact_frame_replay',
            'surface_contact_signature_seeding')):
        _contact_chain_store_history_inputs(guide,inputs,snapshot)


def _contact_idle_raw_action_matches(armature, bone, basis, frame):
    """A direct unkeyed pose edit is not an Action replay."""
    action = _dynamic_parent_owner_action(armature)
    prefix = bone.path_from_id()+'.'
    paths = {prefix+prop: prop for prop in ("location", "rotation_euler",
             "rotation_quaternion", "rotation_axis_angle", "scale")}
    curves = [c for c in _action_fcurves(action, armature) if c.data_path in paths and not c.mute]
    if not curves or not _pin_keyboard_matrices_differ(_pin_authored_pose_basis(bone), basis, epsilon=1.e-6):
        return False
    return all(abs(getattr(bone, paths[c.data_path])[c.array_index]-c.evaluate(frame)) < 1.e-5
               for c in curves)


def _surface_contact_restore_idle_action_pose(context, guides):
    saved = _state.setdefault("contact_idle_confirmed_poses", {})
    restore = {}
    attachments = []
    restored = set()
    for guide in guides:
        entry = saved.get(guide.name)
        if entry is None:
            continue
        armature, bone = _surface_contact_pose_bone(guide)
        if bone is None or armature.name != entry[1]:
            continue
        if (_ragdoll_active(bone, context.scene.frame_current)
                or _constraint_pin_gyro_blocks_contact(guide, context.scene.frame_current)):
            continue
        changed = [(armature.pose.bones[name], basis) for name, basis in entry[2].items()
                   if name in armature.pose.bones and _pin_keyboard_matrices_differ(
                       _pin_authored_pose_basis(armature.pose.bones[name]), basis, epsilon=1.e-6)]
        if not changed or not all(_contact_idle_raw_action_matches(armature, current, basis,
                                  context.scene.frame_current_final) for current, basis in changed):
            continue
        current_inputs = _contact_idle_inputs(context, guide)
        # Ancestor bases can replay too. All authored curves, target and
        # external constraints must still match the confirmed edit's inputs.
        saved_inputs=entry[0]
        replayed_attachment=False
        if (current_inputs is not None and saved_inputs[12]!=current_inputs[12]
                and saved_inputs[13]==current_inputs[13]
                and current_inputs[13] is not None
                and current_inputs[12]==current_inputs[13]):
            # The Action can replay the old latch after an explicit mode
            # handoff without changing its keys. Only that exact replay may
            # recover the handoff's state; a new latch key invalidates proof.
            current_inputs=(*current_inputs[:12],saved_inputs[12],*current_inputs[13:])
            replayed_attachment=True
        if not _contact_chain_uses_contact(guide) and current_inputs is not None:
            # A hidden IK pin has no attached/loose state. History cleanup may
            # reconcile those unused fields; it cannot invalidate its FK proof.
            saved_inputs=(*saved_inputs[:7],(),*saved_inputs[8:12],False,None,*saved_inputs[14:])
            current_inputs=(*current_inputs[:7],(),*current_inputs[8:12],False,None,*current_inputs[14:])
        if (current_inputs is None
                or saved_inputs[:4] + saved_inputs[5:] != current_inputs[:4] + current_inputs[5:]):
            continue
        restore.update({(armature.name, name): basis for name, basis in entry[2].items()})
        if replayed_attachment:attachments.append((guide,entry[0][12]))
        restored.add(guide.name)
    if restore:
        previous = _state.get("surface_contact_action_repair_active", False)
        _state["surface_contact_action_repair_active"] = True
        try:
            for guide,detached in attachments:_surface_contact_set_snap_detached(guide,detached)
            _pin_restore_action_pose_bases(context, restore)
        finally:
            _state["surface_contact_action_repair_active"] = previous
    return restored


def _contact_chain_restore_idle_action_inputs(context, *, history=False):
    """Repair unrelated Action replays before publishing new chain outputs."""
    _contact_chain_advance_idle_frame(context)
    if context is None or any(_state.get(key) for key in (
            'surface_contact_solver_syncing','surface_contact_action_repair_active',
            'surface_contact_creation_active','surface_contact_signature_seeding',
            'contact_chain_input_editing','pin_snap_transform_active',
            'pin_keyboard_transform_active','pin_target_dragging',
            'pin_snap_transform_initializing',
            'surface_contact_frame_evaluation_active','surface_contact_frame_replay',
            'ragdoll_syncing','ragdoll_native_evaluating','surface_contact_load_restoring')):
        return set()
    if not history and (_state.get('pin_history_active') or _state.get('pin_history_syncing')):
        return set()
    if not history and _pin_active_transform_operator(context):return set()
    saved = _state.get('contact_idle_confirmed_poses',{})
    if not saved:
        return set()
    guides = []
    for guide in _surface_contact_guides():
        if (guide.name not in saved or guide.name not in context.scene.objects
                or guide.get(SURFACE_CONTACT_KIND_PROPERTY)!=SURFACE_CONTACT_KIND_CHAIN
                or not _surface_contact_guide_active_at(guide,context.scene.frame_current)):
            continue
        owner,bone = _surface_contact_pose_bone(guide)
        if bone is None:
            continue
        if not _contact_chain_enabled(context,guide,_contact_chain_bones(guide)):
            continue
        # Selection is not an edit. The exact Action/input fingerprint below
        # distinguishes a replay from a new pose; excluding selected chains
        # let ordinary redraws replace their confirmed inputs with old keys.
        guides.append(guide)
    return _surface_contact_restore_idle_action_pose(context,guides) if guides else set()



def _contact_chain_history_input_signature(inputs):
    # Native history reconstructs floats, and session IDs are process-local.
    # Curves/settings/target retain authority; raw FK is the saved payload.
    def normalized(value):
        if isinstance(value,float):return round(value,5)
        if isinstance(value,(tuple,list)):return tuple(normalized(v) for v in value)
        return value
    values=(json.loads(inputs) if isinstance(inputs,str) else
            normalized(inputs[2:4]+inputs[6:]))
    # The same canonical proof is used for a saved checkpoint and live RNA.
    # IK does not consume the hidden pin's attachment flags.
    if len(values)>10 and len(values[10])>2 and not values[10][2]:
        values=list(values);values[3]=[];values[8:10]=[False,None]
    return json.dumps(values,separators=(',',':'))


def _contact_chain_store_history_inputs(guide,inputs,snapshot):
    """Undo-owned source data, written only at a completed explicit edit."""
    prop='Contact Chain Inputs'
    if guide.get(SURFACE_CONTACT_KIND_PROPERTY)!=SURFACE_CONTACT_KIND_CHAIN and prop not in guide:return
    packed=json.dumps(dict(signature=_contact_chain_history_input_signature(inputs),
        bases={name:[list(row) for row in matrix] for name,matrix in snapshot.items()}),separators=(',',':'))
    if guide.get(prop)!=packed:guide[prop]=packed


def _contact_chain_restore_saved_history_inputs(context):
    """Recover the restored checkpoint, never the outgoing runtime snapshot."""
    restore={}
    for guide in _surface_contact_guides():
        packed=guide.get('Contact Chain Inputs')
        if not packed or guide.name not in context.scene.objects:continue
        try:entry=json.loads(packed)
        except (TypeError,ValueError):continue
        owner,bone=_surface_contact_pose_bone(guide)
        if bone is None or _constraint_bone_ragdoll_override(owner,bone,context.scene.frame_current):continue
        inputs=_contact_idle_inputs(context,guide)
        if inputs is None or _contact_chain_history_input_signature(entry.get('signature','[]'))!=_contact_chain_history_input_signature(inputs):continue
        for name,rows in entry.get('bases',{}).items():
            current=owner.pose.bones.get(name)
            if current is None:continue
            basis=Matrix(rows)
            if (not _pin_keyboard_matrices_differ(_pin_authored_pose_basis(current),basis,epsilon=1.e-6)
                    or _contact_idle_raw_action_matches(owner,current,basis,context.scene.frame_current_final)):
                restore[(owner.name,name)]=basis
    if restore:_pin_restore_action_pose_bases(context,restore)
    return restore
