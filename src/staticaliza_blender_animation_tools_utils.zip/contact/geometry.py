"""Surface-contact geometry detection and binding matrices."""

from ..core.runtime import *  # noqa: F403


def _surface_contact_preserves_rigid_orientation(guide):
    """Return whether this contact has a welded-object Smart cast axis."""
    local = guide.get(SURFACE_CONTACT_SMART_LOCAL_PROPERTY)
    return bool(
        str(guide.get(SURFACE_CONTACT_SMART_OBJECT_PROPERTY, ""))
        and local is not None
        and len(local) >= 3
    )


def _surface_contact_part_geometry(context, armature, pose_bone):
    context.view_layer.update()
    depsgraph = context.evaluated_depsgraph_get()
    evaluated_armature = armature.evaluated_get(depsgraph)
    evaluated_bone = evaluated_armature.pose.bones.get(pose_bone.name)
    if evaluated_bone is None:
        return None, None, None, (), ()

    family_names = _surface_contact_bone_family_names(
        evaluated_armature,
        evaluated_bone,
    )
    connected_objects = _surface_contact_connected_objects(
        context,
        armature,
        family_names,
    )
    connected_parts = [
        obj for obj in connected_objects if obj.type == "MESH"
    ]
    if not connected_parts:
        return evaluated_armature, evaluated_bone, None, (), ()

    canonical_name = _strip_blender_numeric_suffix(evaluated_bone.name)
    connected_parts.sort(
        key = lambda obj: (
            0 if obj.name == canonical_name else 1,
            0 if _strip_blender_numeric_suffix(obj.name) == canonical_name else 1,
            1 if _object_has_linked_base_color(obj) else 0,
            obj.name.casefold(),
        )
    )
    part = connected_parts[0]
    points = []
    contributing_parts = []

    for connected_part in connected_parts:
        matching_object_name = (
            _strip_blender_numeric_suffix(connected_part.name) == canonical_name
        )
        rigid_connection = (
            connected_part.parent == armature
            and connected_part.parent_type == "BONE"
            and str(getattr(connected_part, "parent_bone", "")) in family_names
        )
        if not rigid_connection:
            rigid_connection = any(
                getattr(constraint, "target", None) == armature
                and str(getattr(constraint, "subtarget", "")) in family_names
                for constraint in connected_part.constraints
            )
        group_indices = {
            group.index
            for group in connected_part.vertex_groups
            if group.name in family_names
        }
        evaluated_part = connected_part.evaluated_get(depsgraph)
        mesh = None
        part_points = []
        weighted_points = []
        try:
            mesh = evaluated_part.to_mesh(
                preserve_all_data_layers = True,
                depsgraph = depsgraph,
            )
        except TypeError:
            mesh = evaluated_part.to_mesh()

        try:
            if mesh is not None:
                source_vertices = getattr(connected_part.data, "vertices", ())
                same_topology = len(source_vertices) == len(mesh.vertices)
                for index, vertex in enumerate(mesh.vertices):
                    world_point = evaluated_part.matrix_world @ vertex.co
                    if rigid_connection or matching_object_name or not group_indices:
                        part_points.append(world_point.copy())
                        continue

                    weight = 0.0
                    groups = (
                        source_vertices[index].groups
                        if same_topology
                        else getattr(vertex, "groups", ())
                    )
                    for membership in groups:
                        if membership.group in group_indices:
                            weight = max(weight, float(membership.weight))
                    if weight > 0.0:
                        weighted_points.append((weight, world_point.copy()))
        finally:
            if mesh is not None:
                evaluated_part.to_mesh_clear()

        if weighted_points and not part_points:
            peak_weight = max(weight for weight, _point in weighted_points)
            threshold = max(0.05, peak_weight * 0.25)
            part_points = [
                point
                for weight, point in weighted_points
                if weight >= threshold
            ]
        if (
            not part_points
            and connected_part == part
            and (rigid_connection or not group_indices)
        ):
            part_points = [
                evaluated_part.matrix_world @ Vector(corner)
                for corner in evaluated_part.bound_box
            ]
        if part_points:
            contributing_parts.append(connected_part)
        points.extend(part_points)

    # Contact creation is a one-shot operation, but very dense custom meshes
    # should not stall Blender while still retaining a representative hull.
    if len(points) > 20000:
        step = max(1, len(points) // 20000)
        points = points[::step]
    if not points or not contributing_parts:
        return evaluated_armature, evaluated_bone, None, (), ()
    part = contributing_parts[0]
    return (
        evaluated_armature,
        evaluated_bone,
        part,
        tuple(points),
        tuple(contributing_parts),
    )


def _surface_contact_geometry_center(points):
    if not points:
        return None
    center = Vector((0.0, 0.0, 0.0))
    for point in points:
        center += point
    return center / float(len(points))


def _surface_contact_axis_vector(axis):
    return {
        "X_POS": Vector((1.0, 0.0, 0.0)),
        "X_NEG": Vector((-1.0, 0.0, 0.0)),
        "Y_POS": Vector((0.0, 1.0, 0.0)),
        "Y_NEG": Vector((0.0, -1.0, 0.0)),
        "Z_POS": Vector((0.0, 0.0, 1.0)),
        "Z_NEG": Vector((0.0, 0.0, -1.0)),
    }.get(str(axis), Vector((0.0, -1.0, 0.0)))


def _surface_contact_smart_cast_direction_world(context, guide):
    smart_object = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_SMART_OBJECT_PROPERTY, ""))
    )
    if smart_object is None:
        return None
    try:
        evaluated = smart_object.evaluated_get(
            context.evaluated_depsgraph_get()
        )
        direction = (
            evaluated.matrix_world.to_3x3()
            @ _surface_contact_axis_vector(
                guide.get(SURFACE_CONTACT_CAST_AXIS_PROPERTY, "Y_NEG")
            )
        )
        if direction.length_squared <= 1.0e-12:
            return None
        return direction.normalized()
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        return None


def _surface_contact_detect_surface(
    context,
    armature,
    evaluated_armature,
    evaluated_bone,
    geometry_points,
    support_objects = (),
    contact_anchor = None,
    smart_object_name = "",
    cast_axis = "Y_NEG",
):
    if evaluated_armature is None or evaluated_bone is None or not geometry_points:
        return None, None, None, None
    depsgraph = context.evaluated_depsgraph_get()

    head = evaluated_armature.matrix_world @ evaluated_bone.head
    tail = evaluated_armature.matrix_world @ evaluated_bone.tail
    bone_vector = tail - head
    bone_length = max(bone_vector.length, 0.05)
    bone_direction = (
        bone_vector.normalized()
        if bone_vector.length_squared > 1.0e-12
        else Vector((0.0, 0.0, -1.0))
    )
    center = _surface_contact_geometry_center(geometry_points)
    if center is None:
        return None, None, None, bone_length
    anchor = (
        Vector(contact_anchor)
        if contact_anchor is not None
        else center.copy()
    )
    extent = max(
        (point - center).length
        for point in geometry_points
    )
    reach = max(0.5, bone_length * 4.0, extent * 3.0)
    padding = max(0.005, min(bone_length, max(extent, 0.05)) * 0.04)
    axis_direction = _surface_contact_axis_vector(cast_axis)
    smart_object = bpy.data.objects.get(str(smart_object_name))
    if smart_object is not None:
        evaluated_object = smart_object.evaluated_get(depsgraph)
        contact_direction = (
            evaluated_object.matrix_world.to_3x3() @ axis_direction
        )
    else:
        contact_direction = (
            evaluated_armature.matrix_world.to_3x3()
            @ evaluated_bone.matrix.to_3x3()
            @ axis_direction
        )
    if contact_direction is None or contact_direction.length_squared <= 1.0e-12:
        contact_direction = anchor - center
    if contact_direction.length_squared <= 1.0e-12:
        contact_direction = bone_direction.copy()
    contact_direction.normalize()

    directions = [contact_direction]

    surface_mode = str(
        getattr(
            context.window_manager,
            "staticaliza_surface_contact_mode",
            "AUTO",
        )
    )
    # The contacted limb cannot collide with its own hull, but every other
    # visible rig object remains a valid floor, wall, or obstacle.
    excluded = {armature, *support_objects}
    candidates = []
    unique_directions = []
    for direction_index, direction in enumerate(directions):
        if direction.length_squared <= 1.0e-12:
            continue
        direction = direction.normalized()
        if any(abs(direction.dot(existing)) > 0.9999 for existing in unique_directions):
            continue
        unique_directions.append(direction)

        support = anchor
        rod_points = (head, tail, *tuple(Vector(point) for point in geometry_points))
        rod_top = min(
            rod_points,
            key=lambda point: float((Vector(point) - anchor).dot(direction)),
        )
        rod_span = Vector(anchor) - Vector(rod_top)
        sweep_supports = [Vector(anchor)]
        if rod_span.length > padding * 2.0:
            # Probe from the top of the visible limb down toward its endpoint.
            # This recovers a surface that already clips through the lower
            # limb, where an endpoint-only cast would begin below the surface.
            sweep_supports.extend(
                Vector(rod_top).lerp(Vector(anchor), factor)
                for factor in (0.0, 0.2, 0.4, 0.6, 0.8)
            )
        unique_supports = []
        for sweep_support in sweep_supports:
            if any(
                (sweep_support - existing).length_squared <= 1.0e-10
                for existing in unique_supports
            ):
                continue
            unique_supports.append(sweep_support)
        casts = tuple(
            (
                sweep_support - direction * padding,
                direction,
                reach + (padding * 2.0),
                (sweep_support - support).length,
            )
            for sweep_support in unique_supports
        )
        primary_candidates = []
        sweep_candidates = []
        for cast_origin, cast_direction, cast_distance, origin_offset in casts:
            result = _surface_contact_ray_cast(
                context,
                cast_origin,
                cast_direction,
                cast_distance,
                excluded,
            )
            if result is None:
                continue
            surface, point, normal, _travelled = result
            if surface.type != "MESH":
                continue
            if normal.dot(center - point) < 0.0:
                normal.negate()
            if surface_mode == "FLOOR" and normal.z < 0.35:
                continue
            if surface_mode == "WALL" and abs(normal.z) > 0.8:
                continue
            separation = (point - support).length
            candidate = (
                separation
                + (float(direction_index) * reach)
                + (float(origin_offset) * 0.01),
                surface,
                point.copy(),
                normal.copy(),
            )
            if float(origin_offset) <= 1.0e-8:
                primary_candidates.append(candidate)
            else:
                sweep_candidates.append(candidate)
        # A valid endpoint hit always wins. The top-to-bottom rod sweep is
        # used only when the endpoint has already passed through the surface.
        candidates.extend(primary_candidates or sweep_candidates)

    if not candidates:
        return None, None, None, bone_length
    candidates.sort(key = lambda item: item[0])
    _score, surface, point, normal = candidates[0]
    return surface, point, normal, bone_length


def _surface_contact_aim_influence(local_support):
    support = Vector(local_support)
    if support.length_squared <= 1.0e-12:
        return 0.0
    return SURFACE_CONTACT_AIM_INFLUENCE


def _surface_contact_plane_matrix(surface_point, surface_normal, reference_matrix):
    normal = Vector(surface_normal)
    if normal.length_squared <= 1.0e-12:
        normal = Vector((0.0, 0.0, 1.0))
    else:
        normal.normalize()
    reference_axes = (
        reference_matrix.to_3x3().col[0],
        reference_matrix.to_3x3().col[1],
        Vector((1.0, 0.0, 0.0)),
        Vector((0.0, 1.0, 0.0)),
    )
    tangent = None
    for axis in reference_axes:
        projected = axis - (normal * axis.dot(normal))
        if projected.length_squared <= 1.0e-12:
            continue
        tangent = projected.normalized()
        break
    if tangent is None:
        tangent = Vector((1.0, 0.0, 0.0))
    bitangent = normal.cross(tangent).normalized()
    tangent = bitangent.cross(normal).normalized()
    matrix = Matrix((tangent, bitangent, normal)).transposed().to_4x4()
    matrix.translation = surface_point
    return matrix


def _surface_contact_guide_aim_influence(guide):
    support = guide.get(SURFACE_CONTACT_SUPPORT_PROPERTY)
    computed_influence = (
        SURFACE_CONTACT_AIM_INFLUENCE
        if support is None or len(support) < 3
        else _surface_contact_aim_influence(support[:3])
    )
    stored_influence = guide.get(SURFACE_CONTACT_AIM_PROPERTY)
    if stored_influence is None:
        return computed_influence
    # Migrate guides created while the alignment gate could save zero.
    return max(float(stored_influence), computed_influence)


def _surface_contact_target_world_matrix(context, target_object, bone_name = ""):
    context.view_layer.update()
    depsgraph = context.evaluated_depsgraph_get()
    evaluated_object = target_object.evaluated_get(depsgraph)
    if bone_name and getattr(evaluated_object, "pose", None):
        evaluated_bone = evaluated_object.pose.bones.get(bone_name)
        if evaluated_bone is None:
            return None
        return (evaluated_object.matrix_world @ evaluated_bone.matrix).copy()
    return evaluated_object.matrix_world.copy()


def _surface_contact_set_target_world_matrix(
    context,
    target_object,
    bone_name,
    world_matrix,
    frame = None,
    visual_key = False,
):
    if target_object is None or world_matrix is None:
        return False
    if bone_name and getattr(target_object, "pose", None):
        pose_bone = target_object.pose.bones.get(bone_name)
        if pose_bone is None:
            return False
        pose_bone.matrix = target_object.matrix_world.inverted_safe() @ world_matrix
        context.view_layer.update()
        if frame is not None:
            _insert_bone_keys(
                pose_bone,
                int(frame),
                visual = bool(visual_key),
            )
        return True

    target_object.matrix_world = world_matrix
    context.view_layer.update()
    if frame is not None:
        insert_keyframe(target_object, int(frame))
    return True


def _surface_contact_explicit_bone_binding(surface):
    def has_bone(armature, bone_name):
        pose = getattr(armature, "pose", None)
        if pose is not None and pose.bones.get(bone_name) is not None:
            return True
        data = getattr(armature, "data", None)
        return data is not None and data.bones.get(bone_name) is not None

    pending = [surface]
    visited = set()
    for _depth in range(64):
        if not pending:
            break
        current = pending.pop(0)
        if current is None or current in visited:
            continue
        visited.add(current)
        parent = getattr(current, "parent", None)
        if (
            parent is not None
            and parent.type == "ARMATURE"
            and getattr(current, "parent_type", "") == "BONE"
        ):
            bone_name = str(getattr(current, "parent_bone", ""))
            if bone_name and has_bone(parent, bone_name):
                return parent, bone_name
        if parent is not None and parent not in visited:
            pending.append(parent)
        for constraint in getattr(current, "constraints", ()):
            if bool(getattr(constraint, "mute", False)):
                continue
            if float(getattr(constraint, "influence", 1.0)) <= 1.0e-6:
                continue
            target = getattr(constraint, "target", None)
            bone_name = str(getattr(constraint, "subtarget", ""))
            if (
                target is not None
                and target.type == "ARMATURE"
                and bone_name
                and has_bone(target, bone_name)
            ):
                return target, bone_name
            if target is not None and target not in visited:
                pending.append(target)
    return None, ""


def _surface_contact_rig_meta_bone_binding(surface):
    if surface is None:
        return None, ""

    object_name = str(getattr(surface, "name", ""))
    canonical_name = _strip_blender_numeric_suffix(object_name)

    def name_score(candidate):
        candidate = str(candidate or "")
        if candidate.casefold() == object_name.casefold():
            return 0
        if (
            _strip_blender_numeric_suffix(candidate).casefold()
            == canonical_name.casefold()
        ):
            return 1
        return None

    def armature_has_bone(armature, bone_name):
        pose = getattr(armature, "pose", None)
        return bool(
            bone_name
            and pose is not None
            and pose.bones.get(str(bone_name)) is not None
        )

    for collection, armature, meta in _iter_roblox_rigs():
        try:
            if collection.all_objects.get(surface.name) != surface:
                continue
        except (AttributeError, ReferenceError, RuntimeError):
            continue

        candidates = []
        try:
            metadata = json.loads(str(meta.get("RigMeta", "")))
        except (TypeError, ValueError):
            metadata = {}

        mesh_to_bone = metadata.get("meshToBone", {})
        if isinstance(mesh_to_bone, dict):
            for mesh_name, bone_name in mesh_to_bone.items():
                score = name_score(mesh_name)
                if score is not None and armature_has_bone(armature, bone_name):
                    candidates.append((score, 0, str(bone_name)))

        def walk_rig_node(node):
            if not isinstance(node, dict):
                return
            bone_name = str(node.get("jname", ""))
            if armature_has_bone(armature, bone_name):
                linked_names = [node.get("pname"), node.get("jname")]
                linked_names.extend(node.get("aux") or ())
                for linked_name in linked_names:
                    score = name_score(linked_name)
                    if score is not None:
                        candidates.append((score, 1, bone_name))
            for child in node.get("children") or ():
                walk_rig_node(child)

        walk_rig_node(metadata.get("rig"))

        for bone_name in (object_name, canonical_name):
            if armature_has_bone(armature, bone_name):
                candidates.append((name_score(bone_name) or 0, 2, bone_name))

        if candidates:
            _score, _source, bone_name = min(
                candidates,
                key = lambda item: (item[0], item[1], item[2].casefold()),
            )
            return armature, bone_name
    return None, ""


def _surface_contact_normalize_bone_label(armature, bone_name):
    bone_name = str(bone_name or "")
    pose = getattr(armature, "pose", None)
    if not bone_name or pose is None:
        return _strip_blender_numeric_suffix(bone_name)

    pose_bone = pose.bones.get(bone_name)
    visited = set()
    while pose_bone is not None and pose_bone.name not in visited:
        visited.add(pose_bone.name)
        source_bone = getattr(pose_bone, "bone", None)
        joint_type = str(
            source_bone.get("rbx_joint_type", "")
            if source_bone is not None
            else ""
        )
        canonical_name = _strip_blender_numeric_suffix(pose_bone.name)
        canonical_bone = pose.bones.get(canonical_name)
        if (
            canonical_bone is not None
            and canonical_bone != pose_bone
            and str(canonical_bone.bone.get("rbx_joint_type", ""))
            not in {"Weld", "WeldConstraint"}
        ):
            pose_bone = canonical_bone
            continue
        if joint_type not in {"Weld", "WeldConstraint"}:
            return pose_bone.name
        pose_bone = pose_bone.parent

    return _strip_blender_numeric_suffix(bone_name)


def _surface_contact_surface_display_label(surface, world_point, depsgraph):
    if surface is None:
        return "World"
    armature, bone_name = _surface_contact_surface_binding(
        surface,
        Vector(world_point),
        depsgraph,
    )
    if bone_name:
        return _surface_contact_normalize_bone_label(armature, bone_name)
    return _strip_blender_numeric_suffix(str(surface.name)) or "World"


def _surface_contact_guide_surface_label(guide):
    stored_label = str(guide.get(SURFACE_CONTACT_LABEL_PROPERTY, ""))
    if stored_label:
        return stored_label

    follow_object = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_FOLLOW_OBJECT_PROPERTY, ""))
    )
    bone_name = str(guide.get(SURFACE_CONTACT_FOLLOW_BONE_PROPERTY, ""))
    if bone_name:
        return _surface_contact_normalize_bone_label(follow_object, bone_name)
    surface_object = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_SURFACE_PROPERTY, ""))
    )
    if surface_object is not None:
        local_point = guide.get(SURFACE_CONTACT_POINT_PROPERTY)
        world_point = guide.matrix_world.translation.copy()
        if local_point is not None and len(local_point) >= 3:
            try:
                world_point = surface_object.matrix_world @ Vector(local_point[:3])
            except (TypeError, ValueError):
                pass
        try:
            depsgraph = bpy.context.evaluated_depsgraph_get()
            label = _surface_contact_surface_display_label(
                surface_object,
                world_point,
                depsgraph,
            )
            if label:
                return label
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            pass
    return (
        _strip_blender_numeric_suffix(
            str(guide.get(SURFACE_CONTACT_SURFACE_PROPERTY, ""))
        )
        or "World"
    )


def _surface_contact_surface_binding(surface, world_point, depsgraph):
    if surface is None:
        return None, ""

    explicit_armature, explicit_bone = _surface_contact_explicit_bone_binding(
        surface
    )
    if explicit_armature is not None and explicit_bone:
        return explicit_armature, explicit_bone

    armature = None
    try:
        armature = surface.find_armature()
    except (AttributeError, ReferenceError, RuntimeError):
        pass
    if armature is None:
        armature = next(
            (
                modifier.object
                for modifier in getattr(surface, "modifiers", ())
                if modifier.type == "ARMATURE"
                and getattr(modifier, "object", None) is not None
            ),
            None,
        )
    if armature is None or getattr(armature, "pose", None) is None:
        metadata_armature, metadata_bone = (
            _surface_contact_rig_meta_bone_binding(surface)
        )
        if metadata_armature is not None and metadata_bone:
            return metadata_armature, metadata_bone
        return surface, ""

    evaluated_surface = surface.evaluated_get(depsgraph)
    mesh = None
    nearest_index = None
    nearest_distance = float("inf")
    try:
        try:
            mesh = evaluated_surface.to_mesh(
                preserve_all_data_layers = False,
                depsgraph = depsgraph,
            )
        except TypeError:
            mesh = evaluated_surface.to_mesh()
        source_vertices = getattr(getattr(surface, "data", None), "vertices", ())
        if mesh is not None and len(mesh.vertices) == len(source_vertices):
            for vertex in mesh.vertices:
                distance = (
                    evaluated_surface.matrix_world @ vertex.co - world_point
                ).length_squared
                if distance < nearest_distance:
                    nearest_distance = distance
                    nearest_index = int(vertex.index)
    finally:
        if mesh is not None:
            evaluated_surface.to_mesh_clear()

    if nearest_index is not None:
        weighted_bones = []
        source_vertex = surface.data.vertices[nearest_index]
        for membership in source_vertex.groups:
            try:
                group_name = surface.vertex_groups[membership.group].name
            except (IndexError, ReferenceError):
                continue
            if armature.pose.bones.get(group_name) is not None:
                weighted_bones.append((float(membership.weight), group_name))
        if weighted_bones:
            weighted_bones.sort(reverse = True)
            return armature, weighted_bones[0][1]

    metadata_armature, metadata_bone = _surface_contact_rig_meta_bone_binding(
        surface
    )
    if metadata_armature is not None and metadata_bone:
        return metadata_armature, metadata_bone
    return surface, ""


def _surface_contact_parent_guide(guide, follow_object, follow_bone, world_matrix):
    if guide is None or follow_object is None:
        return False
    try:
        guide.parent = follow_object
        if follow_bone:
            guide.parent_type = "BONE"
            guide.parent_bone = str(follow_bone)
        else:
            guide.parent_type = "OBJECT"
            guide.parent_bone = ""
        guide.matrix_world = world_matrix
        guide[SURFACE_CONTACT_FOLLOW_OBJECT_PROPERTY] = follow_object.name
        guide[SURFACE_CONTACT_FOLLOW_BONE_PROPERTY] = str(follow_bone)
        return True
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return False
