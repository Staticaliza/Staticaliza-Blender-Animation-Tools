"""Native Contact mesh aiming, with chain outputs separate from FK inputs."""

from ..core.runtime import *  # noqa: F403


def _contact_chain_target_matrix(guide):
    """Read the same native target snapshot as Contact admission/overlays."""
    locked = _state.get('pin_snap_contact_target_locks', {}).get(guide.name)
    return (locked['matrix_world'] if locked is not None else guide.matrix_world).copy()


def _contact_chain_collision_surface(context, guide, *, target=None, origin=None,matrices=None,support=None):
    """IK disconnects the target, not the collision geometry."""
    if not _contact_chain_uses_contact(guide) and guide.get('Contact Clip',False):
        return None
    cache=(_state.setdefault('contact_chain_collision_exclusions',{})
           if any(_state.get(k) for k in ('pin_snap_transform_active',
               'pin_target_dragging','pin_keyboard_transform_active')) else {})
    excluded=cache.get(guide.name)
    if excluded is None:
        excluded=_surface_contact_linked_collision_objects(context,guide)
        owner,_bone=_surface_contact_pose_bone(guide)
        families={owner:{row[0] for row in _contact_chain_records(guide)}}
        # A moving source or the effector's socket is not an independent
        # obstacle. Other ancestors remain collidable when editing the foot.
        selected=_selected_pose_bones_by_owner(context)
        socket=_contact_chain_space_parent(_bone,context.scene.frame_current)
        for ancestor in _contact_chain_ancestors(guide):
            if ancestor==socket or ancestor in selected.get(ancestor.id_data,()):
                families.setdefault(ancestor.id_data,set()).add(ancestor.name)
        for rig,names in families.items():
            for name in tuple(names):
                member=rig.pose.bones.get(name)
                if member is not None:names.update(_surface_contact_bone_family_names(rig,member))
            excluded.update(_surface_contact_connected_objects(context,rig,names))
        cache[guide.name]=excluded
    # A sweep uses Blender's scene BVH, so another foot/rig is a collider too.
    # Query only while authoring; no per-object nearest-point scene scan and
    # no new surface binding/key writes are needed for transient support.
    if target is not None and origin is not None:
        target,origin=Vector(target),Vector(origin)
        delta=target-origin
        if delta.length_squared>1.e-12:
            hit=_surface_contact_ray_cast(context,origin,delta,delta.length+1.e-5,excluded)
            if hit is not None:
                surface=hit[0]
                depsgraph=context.evaluated_depsgraph_get()
                return surface,depsgraph,_surface_contact_query_matrices(surface,depsgraph)
    surface = guide.get('Contact Surface Object')
    if surface is None:
        surface = bpy.data.objects.get(str(guide.get(SURFACE_CONTACT_SURFACE_PROPERTY, '')))
    if surface is None:
        # IK created directly has no binding. Probe its unchanged reference
        # plane without allocating a target or writing surface metadata.
        reference = guide.matrix_world
        direction = _contact_chain_unit(reference.to_3x3().col[2],(0,0,1))
        hit = _surface_contact_ray_cast(context,reference.translation+direction*.001,
            -direction,1.e4,excluded)
        surface = hit[0] if hit is not None else None
    if surface is None or surface.type != 'MESH' or surface.name not in context.scene.objects:
        return None
    owner, _bone = _surface_contact_pose_bone(guide)
    if surface == owner or surface in excluded:
        return None
    depsgraph = context.evaluated_depsgraph_get()
    collision=(surface,depsgraph,_surface_contact_query_matrices(surface,depsgraph))
    if matrices is not None and support is not None and target is not None:
        # Sweep the actual foot support, not just the central dot. Another
        # foot can touch a toe/edge while the dot still points at the floor.
        normal=_contact_chain_collision_reference(context,guide,collision)
        world=Matrix(matrices[-1]);geometry=_contact_chain_contact_geometry(context,guide,support)
        hull=geometry.get('hull',geometry['points'])
        samples=_contact_chain_collision_samples(context,guide,matrices,support,collision)
        projections=[(world.to_3x3()@p).dot(normal) for p in hull]
        span=max(projections,default=0.)-min(projections,default=0.)
        skin=max(1.e-4,_surface_contact_settle_tolerance(guide))
        best=None
        for local in samples:
            point=Vector(target)+world.to_3x3()@(local-Vector(support))
            hit=_surface_contact_ray_cast(context,point+normal*(span+skin),-normal,span+2.*skin,excluded)
            if hit is None:continue
            foreign=any(getattr(getattr(c,'target',None),'type','')=='ARMATURE'
                        and c.target!=owner for c in hit[0].constraints)
            if foreign:
                escape_cache=_state.setdefault('contact_chain_contact_patches',{})
                escape_key=('ESCAPE',guide.name,int(hit[0].session_uid))
                if escape_key not in escape_cache:
                    baseline=_state.get('contact_chain_transform_effectors',{}).get(guide.name,world)
                    prepared=_surface_contact_query_matrices(hit[0],depsgraph)
                    overlapping=False
                    for p in samples:
                        start=baseline@p
                        prior=_surface_contact_object_ray_cast(hit[0],start+normal*(span+skin),-normal,
                            span+2.*skin,depsgraph,prepared=prepared)
                        if prior is not None and (prior[0]-start).dot(normal)>skin:
                            overlapping=True;break
                    escape_cache[escape_key]=overlapping
                if escape_cache[escape_key]:
                    continue  # Permit escape from an already interpenetrating foreign rig.
            depth=(hit[1]-point).dot(normal)
            if depth>=-skin and (best is None or depth>best[0]):best=(depth,hit[0])
        if best is not None and best[1]!=surface:
            surface=best[1];collision=(surface,depsgraph,_surface_contact_query_matrices(surface,depsgraph))
    return collision


def _contact_chain_pose_edit_active(context,guide):
    if guide.name in _state.get('contact_chain_committed_inputs',()):return False
    if guide.name in _state.get('contact_chain_pose_edits',()):return True
    if _state.get('pin_snap_transform_active') and guide.name in _contact_chain_native_edit_guides():return True
    return bool((_state.get('pin_target_dragging') or _state.get('pin_keyboard_transform_active'))
                and not _state.get('pin_transform_waiting_for_motion')
                and _surface_contact_snap_key(guide) in _pin_selected_target_keys())


def _contact_chain_native_edit_guides():
    """Pose corrections include parents; snap ownership remains direct-only."""
    return (set(_state.get('pin_snap_direct_transform_guides',()))
            |set(_state.get('pin_snap_parent_attachment_states',()))
            |set(_state.get('pin_snap_target_transform_guides',())))


def _contact_chain_edit_active(context,guide):
    return bool(_state.get('pin_snap_transform_active')
                and guide.name in _state.get('pin_snap_direct_transform_guides',())
                and guide.name not in _state.get('contact_chain_committed_inputs',()))


def _contact_chain_plant_edit_active(context,guide):
    return _contact_chain_is_planted(guide) and _contact_chain_pose_edit_active(context,guide)


def _contact_chain_collision_reference(context,guide,collision):
    """Freeze the limb's side of a collider, independently of target tilt.

    A resumed or rotated helper can point through the surface. The visible
    joint at gesture start establishes the physical side; keep that normal
    in collider space so moving the collider does not change the binding.
    """
    surface,depsgraph,prepared=collision
    editing=any(_state.get(k) for k in ('pin_snap_transform_active','pin_target_dragging','pin_keyboard_transform_active'))
    cache=_state.setdefault('contact_chain_contact_patches',{}) if editing else {}
    token=('SIDE',guide.name,int(surface.session_uid))
    if token in cache:return _contact_chain_unit(prepared[3]@cache[token],(0,0,1))
    owner,bone=_surface_contact_pose_bone(guide)
    root_frame=_state.get('contact_chain_transform_root_frames',{}).get(guide.name)
    world=root_frame[2] if root_frame is not None else None
    if world is None:
        bones=_contact_chain_bones(guide)
        root=bones[0] if bones else bone
        world=owner.matrix_world@owner.evaluated_get(depsgraph).pose.bones[root.name].matrix
    closest=_surface_contact_closest_point(surface,world.translation,depsgraph,1.e6,prepared=prepared)
    normal=guide.matrix_world.to_3x3().col[2].copy()
    if closest is not None:
        point,normal=closest
        distance=(world.translation-point).dot(normal)
        if distance<0.:normal=-normal
        if abs(distance)<1.e-5:
            normal=_surface_contact_collision_normal(context,guide,point,normal,depsgraph) or normal
    normal=_contact_chain_unit(normal,(0,0,1))
    cache[token]=prepared[1].to_3x3().transposed()@normal
    return normal


def _contact_chain_query_tolerance(surface):
    # Eight float32 ulps for inverse transform / BVH / world reconstruction.
    scale=max(max(surface.dimensions),max(abs(v) for v in surface.matrix_world.translation))
    return max(1.e-5,math.ldexp(scale,-20))


def _contact_chain_contact_hit(context,guide,point,collision):
    """Signed local contact, with one winding calibration per approach side.

    Do not flip each nearest-face normal toward a root direction: a closed
    mesh's opposite wall would then become an inward-facing false collider.
    """
    surface,depsgraph,prepared=collision
    reference=_contact_chain_collision_reference(context,guide,collision)
    cache=_state.setdefault('contact_chain_contact_patches',{})
    token=('WINDING',guide.name,int(surface.session_uid))
    sign=cache.get(token)
    if sign is None:
        extent=max(abs((prepared[1]@Vector(corner)-point).dot(reference))
                   for corner in prepared[0].bound_box)
        span=max(1.,extent+1.)
        outside=point+reference*span
        hit=_surface_contact_closest_point(surface,outside,depsgraph,1.e6,prepared=prepared)
        sign=-1. if hit is not None and (outside-hit[0]).dot(hit[1])<0. else 1.
        cache[token]=sign
    hit=_surface_contact_closest_point(surface,point,depsgraph,1.e6,prepared=prepared)
    return (hit[0],hit[1]*sign) if hit is not None else None


def _contact_chain_surface_normal(context,guide,target,collision,*,matrices=None,support=None):
    """One actual surface query, shared by IK and ordinary Contact edits."""
    if collision is None:return None
    surface,depsgraph,prepared=collision
    closest=_surface_contact_closest_point(surface,Vector(target),depsgraph,1.e6,prepared=prepared)
    if closest is None:return None
    point,normal=closest
    reference=_contact_chain_collision_reference(context,guide,collision)
    if normal.dot(reference)<0.:normal=-normal
    if matrices is not None and support is not None:
        world=Matrix(matrices[-1])
        samples=_contact_chain_collision_samples(context,guide,matrices,support,collision)
        deepest=min((world@local for local in samples),key=lambda p:(p-point).dot(normal))
        # A tilted sole touches at its edge before the centre dot does. Verify
        # that real edge against the bounded mesh rather than an infinite plane.
        edge=_surface_contact_closest_point(surface,deepest,depsgraph,1.e6,prepared=prepared)
        if edge is None:return None
        point,normal=edge
        if normal.dot(reference)<0.:normal=-normal
        target=deepest
    offset=Vector(target)-point
    depth=offset.dot(normal)
    # Closest-point results use float32 mesh coordinates. A large Baseplate
    # has more roundoff than a foot-sized mesh even at the same contact point.
    # Match collision's numerical tolerance; this is not the snap radius.
    tolerance=max(_surface_contact_settle_tolerance(guide),_contact_chain_query_tolerance(surface))
    if depth>tolerance or (offset-normal*depth).length>tolerance:
        # A nearby floor is not a contact. Floating feet retain their pose;
        # Plant only owns the normal at the actual touching support patch.
        return None
    return normal.normalized()


def _contact_chain_mesh_frame(context,guide):
    """Rigid mesh coordinates in the actual geometry bone, not its cast axes."""
    owner,bone=_surface_contact_pose_bone(guide)
    smart=bpy.data.objects.get(str(guide.get(SURFACE_CONTACT_SMART_OBJECT_PROPERTY,'')))
    if smart is None:return Matrix.Identity(4)
    cache=(_state.setdefault('contact_chain_contact_patches',{})
           if any(_state.get(k) for k in ('pin_snap_transform_active','pin_target_dragging','pin_keyboard_transform_active')) else {})
    token=('FRAME',guide.name,int(smart.session_uid))
    if token in cache:return cache[token].copy()
    depsgraph=context.evaluated_depsgraph_get()
    evaluated=owner.evaluated_get(depsgraph)
    geometry=evaluated.pose.bones.get(str(guide.get(SURFACE_CONTACT_GEOMETRY_BONE_PROPERTY,bone.name)))
    if geometry is None:return Matrix.Identity(4)
    frame=(evaluated.matrix_world@geometry.matrix).inverted_safe()@smart.evaluated_get(depsgraph).matrix_world
    cache[token]=frame.copy()
    return frame


def _contact_chain_mesh_hull(points):
    """One native convex support reduction per gesture; no Blender IDs."""
    import bmesh
    mesh=bmesh.new()
    try:
        vertices=[mesh.verts.new(p) for p in {tuple(p) for p in points}]
        if len(vertices)<4:return tuple(Vector(p) for p in points),()
        result=bmesh.ops.convex_hull(mesh,input=vertices,use_existing_faces=False)
        mesh.normal_update()
        faces=[f for f in result['geom'] if isinstance(f,bmesh.types.BMFace)]
        hull={v for f in faces for v in f.verts}
        normals={}
        for face in faces:
            normal=face.normal.copy();key=tuple(round(v,3) for v in normal)
            area=face.calc_area();entry=normals.get(key)
            normals[key]=(normal,area+(entry[1] if entry else 0.))
        ranked=sorted(normals.values(),key=lambda v:v[1],reverse=True)
        # Bevel strips are not the flat sides a user is trying to plant.
        # Keep the six principal planes (including narrow end caps), plus
        # other substantial faces of irregular rigid parts.
        candidates=[v for i,v in enumerate(ranked) if i<6 or v[1]>=ranked[0][1]*.1][:48]
        flat=[]
        for normal,area in candidates:
            # A narrow bevel between two larger planes is an edge treatment,
            # not the broad mesh side to lay down. Retain narrow end caps and
            # curved/irregular surfaces that have no such enclosing planes.
            neighbors=[n for n,a in candidates if a>area*3.5 and n.dot(normal)>.25]
            bevel=False
            for i,a in enumerate(neighbors):
                for b in neighbors[i+1:]:
                    cosine=a.dot(b)
                    if abs(cosine)>.8:continue
                    denominator=1.-cosine*cosine
                    x=(normal.dot(a)-cosine*normal.dot(b))/denominator
                    y=(normal.dot(b)-cosine*normal.dot(a))/denominator
                    if x>.05 and y>.05 and (normal-a*x-b*y).length_squared<.0025:
                        bevel=True;break
                if bevel:break
            if not bevel:flat.append(normal)
        return tuple(v.co.copy() for v in hull),tuple(flat)
    finally:mesh.free()


def _contact_chain_contact_geometry(context,guide,support):
    """One visible connected-mesh support region, immutable during a gesture."""
    cache=(_state.setdefault('contact_chain_contact_patches',{})
           if any(_state.get(k) for k in ('pin_snap_transform_active','pin_target_dragging','pin_keyboard_transform_active')) else {})
    token=('GEOMETRY',guide.name,tuple(support),str(guide.get(SURFACE_CONTACT_CAST_AXIS_PROPERTY,'')))
    if token in cache:return cache[token]
    axis=_surface_contact_axis_vector(str(guide.get(SURFACE_CONTACT_CAST_AXIS_PROPERTY,'Y_NEG')))
    frame=_contact_chain_mesh_frame(context,guide)
    normal=frame.to_3x3().inverted_safe().transposed()@axis
    normal=_contact_chain_unit(normal,(0,-1,0))
    points=[Vector(support)]
    smart=bpy.data.objects.get(str(guide.get(SURFACE_CONTACT_SMART_OBJECT_PROPERTY,'')))
    if smart is not None and smart.type=='MESH':
        evaluated=smart.evaluated_get(context.evaluated_depsgraph_get())
        local=frame.inverted_safe()@Vector(support)
        hit,point,face_normal,index=evaluated.closest_point_on_mesh(local)
        if hit and 0<=index<len(evaluated.data.polygons):
            polygon=evaluated.data.polygons[index]
            vertices=[evaluated.data.vertices[i].co.copy() for i in polygon.vertices]
            actual=frame.to_3x3().inverted_safe().transposed()@face_normal
            if actual.dot(normal)>.5*actual.length:normal=actual.normalized()
            points.extend(frame@p for p in vertices)
    owner,bone=_surface_contact_pose_bone(guide)
    evaluated,geometry,_part,world_points,parts=_surface_contact_part_geometry(context,owner,bone)
    cloud=list(points)
    if world_points and geometry is not None:
        inverse=(evaluated.matrix_world@geometry.matrix).inverted_safe()
        cloud=[inverse@p for p in world_points]
        extent=max(p.dot(normal) for p in cloud)
        span=max((p-Vector(support)).length for p in cloud)
        band=max(1.e-5,span*1.e-4)
        points.extend(p for p in cloud if p.dot(normal)>=extent-band)
    # Preserve the complete contact region's directional extremes. Query cost
    # is bounded for dense meshes and multipart toes/soles alike.
    axes=(normal,normal.orthogonal(),normal.cross(normal.orthogonal()),
          _contact_chain_unit((1,1,1),(1,0,0)))
    if len(points)>9:
        points=[Vector(support),*(Vector(p) for p in {
            tuple(max(points,key=lambda p:p.dot(axis)*sign))
            for axis in axes for sign in (-1,1)})]
    hull,faces=_contact_chain_mesh_hull(cloud)
    result=dict(points=tuple(points),normal=normal,hull=hull,faces=faces,
                parts=tuple(p.name for p in parts))
    cache[token]=result
    return result


def _contact_chain_contact_patch(context,guide,support):
    return _contact_chain_contact_geometry(context,guide,support)['points']


def _contact_chain_plant_pressure(context,guide,raw,support,collision,*,target=None,fixed_head=False):
    """Geometric pressure from immutable input, with no temporal relaxation.

    First touch has zero alignment torque. Pressing by the tilted face's
    height progressively lays it down; lifting follows the same curve back.
    Collision clearance is independent and remains hard at every weight.
    """
    surface,depsgraph,prepared=collision
    reference=_contact_chain_collision_reference(context,guide,collision)
    world=Matrix(raw[-1]).copy()
    if target is not None:
        free=not _contact_chain_uses_contact(guide)
        handle=any(_state.get(k) for k in ('pin_target_dragging','pin_keyboard_transform_active')) and _surface_contact_snap_key(guide) in _pin_selected_target_keys()
        if free or handle:
            desired=(_contact_chain_reachable_target(raw,support,target)
                     if free and len(raw)>1 else Vector(target))
            if fixed_head and handle:
                lever=world.to_3x3()@Vector(support)
                toward=desired-world.translation
                if lever.length_squared>1.e-16 and toward.length_squared>1.e-16:
                    position=world.translation.copy()
                    world=_contact_chain_swing(lever,toward,world.to_3x3().col[0]).to_matrix().to_4x4()@world
                    world.translation=position
            elif not fixed_head:
                # The chain's immutable effector joint stays at the gesture
                # baseline while G changes its goal. Measure the requested
                # reachable pose before collision clamps that goal; reading
                # the baseline here makes every native foot drag weigh zero.
                world.translation+=desired-world@Vector(support)
    samples=_contact_chain_collision_samples(context,guide,(world,),support,collision)
    contact=None
    normal_sum=Vector()
    tolerance=max(_surface_contact_settle_tolerance(guide),_contact_chain_query_tolerance(surface))
    for local in samples:
        point=world@local
        hit=_contact_chain_contact_hit(context,guide,point,collision)
        if hit is None:continue
        location,normal=hit
        offset=point-location;depth=offset.dot(normal)
        if depth>tolerance:continue
        # Deep interior nearest faces change at the medial axis. Torque uses
        # the approached wall, while signed distance supplies continuous
        # pressure that vanishes at the actual closed-mesh boundary.
        span=max(1.,max(abs((prepared[1]@Vector(corner)-point).dot(reference))
                       for corner in prepared[0].bound_box)+1.)
        approach=_surface_contact_object_ray_cast(surface,point+reference*span,
            -reference,span*2.,depsgraph,prepared=prepared)
        if approach is not None:normal=approach[1]
        if normal.dot(reference)<0.:normal=-normal
        normal_sum+=normal*max(0.,-depth)
        if contact is None or depth<contact[0]:contact=(depth,normal.normalized())
    if contact is None:return None,0.
    depth,normal=contact
    if normal_sum.length_squared>1.e-16:normal=normal_sum.normalized()
    geometry=_contact_chain_contact_geometry(context,guide,support)
    hull=geometry.get('hull',geometry['points'])
    inverse_normal=world.to_3x3().inverted_safe().transposed()
    face=geometry['normal']
    if not _contact_chain_uses_contact(guide) and geometry.get('faces'):
        face=min(geometry['faces'],key=lambda n:(inverse_normal@n).normalized().dot(normal))
    extreme=max(p.dot(face) for p in hull)
    local_radius=max((p-Vector(support)).length for p in hull)
    radius=max((world.to_3x3()@(p-Vector(support))).length for p in hull)
    band=max(1.e-5,local_radius*1.e-4)
    heights=[(world.to_3x3()@p).dot(normal) for p in hull if extreme-p.dot(face)<=band]
    travel=max(max(heights,default=0.)-min(heights,default=0.),radius*.15,1.e-5)
    pressure=max(0.,min(1.,-depth/travel))
    weight=pressure*pressure*(3.-2.*pressure)
    return normal,weight


def _contact_chain_plant_orientation(guide,raw,normal,target,fixed_head=False,*,context=None):
    """Shortest-arc face alignment retains heading and authored scale.

    Only an explicit pose or pin edit applies Plant. Idle/record/playback evaluation
    consumes the committed orientation, not the current configuration flag.
    """
    result=[m.copy() for m in raw]
    world=result[-1];position=world.translation.copy()
    support=Vector(tuple(guide.get(SURFACE_CONTACT_SUPPORT_PROPERTY,(0,0,0)))[:3])
    local_face=_contact_chain_contact_geometry(context or bpy.context,guide,support)['normal']
    if not _contact_chain_uses_contact(guide):
        faces=_contact_chain_contact_geometry(context or bpy.context,guide,support).get('faces',())
        if faces:
            inverse_normal=world.to_3x3().inverted_safe().transposed()
            local_face=min(faces,key=lambda n:(inverse_normal@n).normalized().dot(normal))
    face=world.to_3x3().inverted_safe().transposed()@local_face
    rotation=_contact_chain_swing(face,-Vector(normal),world.to_3x3().col[0])
    world=rotation.to_matrix().to_4x4()@world;world.translation=position
    # Preserve heading. A nearly vertical head-to-support vector has no yaw
    # information; using its tiny tangent projection made G flip 180 degrees.
    result[-1]=world
    return result


def _contact_chain_solve_pose(context,guide,raw,support,target,bend,*,collision=None,root_fixed=False,plant_normal=None,collision_target_prepared=False,aim_effector=False,pressure_target=None):
    """One joint/mesh solve; settings only choose constraints on that solve."""
    target=Vector(target).copy()
    if aim_effector and len(raw)>1 and not _contact_chain_is_planted(guide):
        raw=[m.copy() for m in raw]
        world=raw[-1];position=world.translation.copy()
        lever=world.to_3x3()@Vector(support)
        toward=target-position
        if lever.length_squared>1.e-12 and toward.length_squared>1.e-12:
            world=_contact_chain_swing(lever,toward,world.to_3x3().col[0]).to_matrix().to_4x4()@world
            world.translation=position;raw[-1]=world
    if collision is not None and not collision_target_prepared:
        target=_contact_chain_free_target(context,guide,raw,support,target,collision)
    # Fixed-root IK needs the same reach easing as loose Contact. Clamping
    # first hits the fully straight singularity and makes a tiny goal move
    # unfold/refold a knee sharply. Ease the original request before solving.
    goal=_contact_chain_soft_target(raw,support,target)
    authoring=bool(guide.get('Contact Authored Pose') or _contact_chain_pose_edit_active(context,guide))
    single_pivot=root_fixed and len(raw)==1 and authoring
    bend_fallback=_contact_chain_solver_bend_fallback(guide,raw,bend)
    outputs,residual=_contact_chain_solve_matrices(raw,support,goal,bend,
        fixed_head=single_pivot,align_support=aim_effector,bend_fallback=bend_fallback)
    collisions=[collision] if collision is not None else []
    bound=guide.get('Contact Surface Object')
    if collision is not None and bound is not None and bound!=collision[0] and bound.type=='MESH':
        collisions.append((bound,collision[1],_surface_contact_query_matrices(bound,collision[1])))
    plant_weight=1.
    if (plant_normal is None and collision is not None
            and _contact_chain_plant_edit_active(context,guide)):
        contacts=[];plant_weight=0.
        for candidate in collisions:
            normal,weight=_contact_chain_plant_pressure(context,guide,raw,support,
                candidate,target=pressure_target,fixed_head=single_pivot)
            if normal is not None and weight>0.:
                contacts.append((weight,normal))
        if contacts:
            # Conflicting floor/wall normals do not describe a real face.
            # Align to the strongest support; only neighboring normals on
            # that same side contribute a smooth local surface average.
            plant_weight,primary=max(contacts,key=lambda item:item[0])
            normal_sum=sum((normal*weight for weight,normal in contacts
                            if normal.dot(primary)>.95),Vector())
            plant_normal=normal_sum.normalized()
            rival=max((weight for weight,normal in contacts
                       if normal.dot(primary)<=.95),default=0.)
            if rival:
                # Equal opposing pressures supply no preferred alignment.
                # Let the torque vanish continuously at that geometric tie
                # instead of flipping between two incompatible faces.
                dominance=min(1.,max(0.,(plant_weight-rival)/(plant_weight*.2)))
                plant_weight*=dominance*dominance*(3.-2.*dominance)
    if plant_normal is not None:
        facing=[Matrix(m).copy() for m in outputs]
        # Apply a face-normal torque to the requested pose. Interpolating
        # toward an unrelated authored heading crosses quaternion's 180-degree
        # branch cut during an ordinary arc and can flip the limb in one step.
        aligned=_contact_chain_plant_orientation(guide,facing,plant_normal,target,
            single_pivot,context=context)
        # Start at the unconstrained candidate, not the original FK tilt.
        # Both must meet exactly at zero pressure; otherwise entering the
        # contact branch itself introduces an angular/positional jump.
        if plant_weight<1.:
            position,rotation,scale=aligned[-1].decompose()
            rotation=Matrix(outputs[-1]).to_quaternion().slerp(rotation,plant_weight)
            aligned[-1]=Matrix.LocRotScale(position,rotation,scale)
        goal=_contact_chain_soft_target(aligned,support,target)
        outputs,residual=_contact_chain_solve_matrices(aligned,support,goal,bend,
            fixed_head=single_pivot,align_support=False,bend_fallback=bend_fallback)
        # Aligned owns the touched-face orientation. Collision below supplies
        # the normal contact offset when that face cannot fit at a fixed head.
        # Re-aiming at the old mouse goal would erase that orientation.
    if not root_fixed:
        shift=target-Matrix(outputs[-1])@support
        shifted=[]
        for values in outputs:
            matrix=Matrix(values);matrix.translation+=shift
            shifted.append(tuple(tuple(float(v) for v in row) for row in matrix))
        outputs=tuple(shifted);residual=0.
        if (not _contact_chain_attached(context,guide) and not _contact_chain_is_planted(guide)
                and _surface_contact_has_valid_surface(guide)):
            owner,bone=_surface_contact_pose_bone(guide)
            opposite=_state.get('contact_chain_magnetic_opposites',{}).get(guide.name)
            if opposite is None:opposite=_contact_chain_magnetic_opposite(context,guide,owner,bone)
            outputs=_contact_chain_aim_solved_mesh(outputs,support,opposite,
                _contact_chain_target_matrix(guide).translation)
    if collision is not None and (root_fixed or not _contact_chain_uses_contact(guide)
            or _contact_chain_is_planted(guide)):
        for candidate in collisions:
            outputs=_contact_chain_free_collision(context,guide,outputs,support,candidate,
                fixed_head=root_fixed and len(raw)==1 and authoring,
                root_fixed=root_fixed,
                pivot_direction=target-raw[0].translation if plant_normal is not None else None,
                chain_raw=aligned if plant_normal is not None else raw,bend=bend,bend_fallback=bend_fallback)
    return outputs,residual,target


def _contact_chain_free_target(context,guide,raw,support,target,collision):
    """Slide the rigid foot goal along the surface before solving its joints.

    Feeding a deep below-floor goal to IK first exhausts reach in an unseen
    direction. Its later collision translation leaves the foot stuck while
    input accumulates, and makes the joint solve differ on confirmation.
    """
    surface,depsgraph,prepared=collision
    target=Vector(target).copy()
    bound=guide.get('Contact Surface Object')
    if bound is None:bound=bpy.data.objects.get(str(guide.get(SURFACE_CONTACT_SURFACE_PROPERTY,'')))
    if surface!=bound:
        # A sibling part is a finite obstacle, not a new infinite floor.
        # Clip the real requested travel against its entry wall. Projecting
        # from a root-side direction jumps across its silhouette even while
        # the requested point is outside the collider.
        origin=raw[-1]@Vector(support)
        delta=target-origin
        if delta.length_squared<1.e-16:return target
        hit=_surface_contact_object_ray_cast(surface,origin,delta,delta.length,
            depsgraph,prepared=prepared)
        if hit is None:return target
        point,normal=hit
        if normal.dot(delta)>0.:normal=-normal
        depth=(target-point).dot(normal)
        if depth<0.:target-=normal*depth
        return target
    reference=_contact_chain_collision_reference(context,guide,collision)
    if reference.length_squared<1.e-12:return target
    # Cast from the bound side, including when the raw goal has already gone
    # through a thick floor. Nearest-point alone then finds its underside.
    extent=max(abs((prepared[1]@Vector(corner)-target).dot(reference))
               for corner in prepared[0].bound_box)
    span=max(1.,extent+1.)
    hit=_surface_contact_object_ray_cast(surface,target+reference*span,-reference,span*2.,
        depsgraph,prepared=prepared)
    if hit is None:return target
    contact,normal=hit
    if normal.dot(reference)<0.:normal=-normal
    depth=(target-contact).dot(normal)
    if depth<0.:target-=normal*depth
    return target


def _contact_chain_collision_samples(context,guide,matrices,support,collision):
    """Collision belongs to the chosen contact patch, not every chain joint.

    Collision pins use their configured support. IK and Aligned use the actual
    rigid effector mesh; upstream knees/limbs never become its contact patch.
    """
    if _contact_chain_uses_contact(guide) and not _contact_chain_is_planted(guide):return (Vector(support),)
    geometry=_contact_chain_contact_geometry(context,guide,support)
    hull=geometry.get('hull',geometry['points'])
    if len(hull)<=9:return hull
    world=Matrix(matrices[-1])
    normal=_contact_chain_collision_reference(context,guide,collision)
    down=-(world.to_3x3().transposed()@normal).normalized()
    cached=geometry.get('collision_samples')
    direction=tuple(down)
    if cached is not None and cached[0]==direction:return cached[1]
    tangent=down.orthogonal().normalized();other=down.cross(tangent)
    axes=(down,down+tangent*.2,down-tangent*.2,down+other*.2,down-other*.2,
          down+(tangent+other)*.2,down+(tangent-other)*.2,
          down+(-tangent+other)*.2,down-(tangent+other)*.2)
    result=tuple(Vector(p) for p in {tuple(max(hull,key=lambda p:p.dot(axis))) for axis in axes})
    # Geometry already has gesture-local ownership. Retain only the latest
    # exact local direction and plain support points, never RNA or history.
    geometry['collision_samples']=(direction,result)
    return result


def _contact_chain_pivot_clearance(matrix,local,contact,normal,direction):
    """Nearest feasible hinge angle for the entire sole, retaining its joint.

    Each vertex supplies A*cos(t)+B*sin(t)+C >= 0. Their boundary angles
    partition the feasible interval exactly; no deepest-corner iteration or
    frame-to-frame output is used as the next input.
    """
    root=matrix.translation.copy();normal=Vector(normal).normalized()
    tangent=Vector(direction)-normal*Vector(direction).dot(normal)
    if tangent.length_squared<1.e-10:
        tangent=matrix.to_3x3().col[0]
        tangent-=normal*tangent.dot(normal)
    axis=_contact_chain_unit(tangent.cross(normal),normal.orthogonal())
    height=(root-Vector(contact)).dot(normal)
    coefficients=[];angles=[0.,math.pi,-math.pi]
    for point in local:
        lever=matrix.to_3x3()@point
        constant=normal.dot(axis)*axis.dot(lever)
        a=normal.dot(lever)-constant;b=normal.dot(axis.cross(lever));c=height+constant
        coefficients.append((a,b,c))
        radius=math.hypot(a,b)
        if radius<1.e-12 or abs(c)>radius:continue
        phase=math.atan2(b,a);offset=math.acos(max(-1.,min(1.,-c/radius)))
        for value in (phase-offset,phase+offset):
            angles.append((value+math.pi)%math.tau-math.pi)
    for angle in sorted(angles,key=lambda a:(abs(a),a)):
        # A tiny angular inset keeps float32 pose matrices outside the plane.
        value=math.copysign(min(math.pi,abs(angle)+1.e-6),angle) if angle else 0.
        cosine,sine=math.cos(value),math.sin(value)
        if min(a*cosine+b*sine+c for a,b,c in coefficients)<-1.e-6:continue
        result=Quaternion(axis,value).to_matrix().to_4x4()@matrix
        result.translation=root
        return result
    return matrix


def _contact_chain_free_collision(context, guide, outputs, support, collision, *, fixed_head=False,root_fixed=False,pivot_direction=None,chain_raw=None,bend=0.,bend_fallback=None):
    """One bounded mesh/joint projection, with the selected root constraint.

    On prefers pivoting a hanging bone. Aligned preserves its touching face.
    Fixed-root chains correct the foot goal; loose/single rigid bones retain
    the existing minimum surface-normal translation policy.
    """
    surface,depsgraph,prepared=collision
    matrices=[Matrix(values) for values in outputs]
    local=_contact_chain_collision_samples(context,guide,matrices,support,collision)
    reference=_contact_chain_collision_reference(context,guide,collision)
    tolerance=max(1.e-4,_contact_chain_query_tolerance(surface))
    for _pass in range(4 if fixed_head or chain_raw is not None else 2):
        local=_contact_chain_collision_samples(context,guide,matrices,support,collision)
        samples=[matrices[-1]@point for point in local]
        deepest=None
        for point in samples:
            closest=_contact_chain_contact_hit(context,guide,point,collision)
            if closest is None:continue
            contact,normal=closest
            offset=point-contact;depth=offset.dot(normal)
            if depth < -1.e-6:
                if deepest is None or depth<deepest[0]:deepest=(depth,normal,point)
        if deepest is None:break
        depth,normal,point=deepest
        if _contact_chain_is_planted(guide):
            contact=point-normal*depth
            # Orientation was computed once from unconstrained pressure.
            # Re-aligning here would snap a partial roll to full alignment
            # on the first penetrating corner, defeating the pressure curve.
            local=_contact_chain_collision_samples(context,guide,matrices,support,collision)
            depth=min((matrices[-1]@p-contact).dot(normal) for p in local)
            if root_fixed and chain_raw is not None and len(chain_raw)>1:
                # A foot edit may bend its parents, not translate the hip.
                # Correct the effector goal and solve from the immutable
                # current parent frame; preserve its aligned mesh rotation.
                target=matrices[-1]@support-normal*(depth-2.e-5)
                goal=_contact_chain_soft_target(chain_raw,support,target)
                projected,_residual=_contact_chain_solve_matrices(chain_raw,support,goal,bend,
                    align_support=False,bend_fallback=bend_fallback)
                matrices=[Matrix(values) for values in projected]
            else:
                # A loose contact chain or a single rigid aligned bone may
                # use the existing surface-normal translation policy.
                for matrix in matrices:matrix.translation-=normal*(depth-2.e-5)
        elif fixed_head:
            matrix=matrices[0];root=matrix.translation.copy();lever=point-root
            hull=(_contact_chain_contact_geometry(context,guide,support).get('hull',local)
                  if _contact_chain_is_planted(guide) or not _contact_chain_uses_contact(guide) else local)
            matrices[0]=_contact_chain_pivot_clearance(matrix,hull,
                point-normal*depth,normal,pivot_direction if pivot_direction is not None else lever)
            if not _pin_keyboard_matrices_differ(matrix,matrices[0],epsilon=1.e-7):
                # No pivot can clear a contact whose socket is already below
                # the surface. Allow only the remaining normal offset; never
                # silently turn collision off or modify the source parent.
                for matrix in matrices:matrix.translation-=normal*(depth-2.e-5)
        elif chain_raw is not None and len(chain_raw)>1:
            # Collision changes the effector goal, never the chain's root.
            # Reuse the same fixed-length solver and immutable FK input.
            target=matrices[-1]@support-normal*depth
            goal=_contact_chain_soft_target(chain_raw,support,target) if root_fixed else target
            projected,_residual=_contact_chain_solve_matrices(chain_raw,support,goal,bend,
                align_support=False,bend_fallback=bend_fallback)
            matrices=[Matrix(values) for values in projected]
        else:
            for matrix in matrices:matrix.translation-=normal*depth
    return tuple(tuple(tuple(float(v) for v in row) for row in matrix) for matrix in matrices)


def _contact_chain_target_follow_matrix(guide, raw):
    """Follow the pin's angular travel around the root without a time filter."""
    packed = guide.get(SURFACE_CONTACT_INITIAL_GUIDE_MATRIX_PROPERTY)
    if not _contact_chain_uses_contact(guide) or packed is None or len(packed) != 16:
        return Matrix.Identity(4)
    root = raw[0].translation
    reference=tuple(guide.get('Contact Pose Reference',()))
    source = (Vector(reference[:3]) if guide.get('Contact Authored Pose') and len(reference)==4
              else Vector((packed[3], packed[7], packed[11]))) - root
    destination = _contact_chain_target_matrix(guide).translation - root
    if source.length_squared < 1.e-12 or destination.length_squared < 1.e-12:
        return Matrix.Identity(4)
    rotation = _contact_chain_swing(source, destination, raw[0].to_3x3().col[0])
    return Matrix.Translation(root) @ rotation.to_matrix().to_4x4() @ Matrix.Translation(-root)


def _contact_chain_target_follow(guide, raw, native_target):
    if guide.get('Contact Authored Pose') and not _contact_chain_pose_edit_active(bpy.context,guide):
        # Playback consumes the keyed FK orientation. Current Plant/IK tool
        # settings cannot add a new angular interpretation to earlier keys.
        return raw,Vector(native_target).copy()
    follow = _contact_chain_target_follow_matrix(guide, raw)
    relative = bool(_state.get('pin_snap_transform_active')
                    and guide.name in _state.get('pin_snap_direct_transform_guides', ())
                    and guide.name not in _state.get('contact_chain_committed_inputs', ()))
    goal = Vector(native_target) if relative else follow @ Vector(native_target)
    if _contact_chain_is_planted(guide) and not relative:
        # The endpoint keeps its world tilt below. Transport its joint goal,
        # then restore that unchanged rigid mesh offset; rotating the support
        # offset as well solves toward a different point on mode handoff.
        support=Vector(tuple(guide.get(SURFACE_CONTACT_SUPPORT_PROPERTY,(0.,0.,0.)))[:3])
        offset=raw[-1].to_3x3()@support
        goal=follow@(Vector(native_target)-offset)+offset
    result = [follow @ matrix for matrix in raw]
    if _contact_chain_is_planted(guide):
        # Turning the linkage toward a translated pin must not tip its rigid
        # foot with it. Retain the endpoint's authored world orientation and
        # scale; the joints still follow the target around their root.
        position=result[-1].translation.copy()
        result[-1]=raw[-1].copy()
        result[-1].translation=position
    # Collision is resolved against the actual mesh in solve_pose. The pin's
    # tangent plane is not an infinite collider beyond that mesh's edges.
    return result, goal


def _contact_chain_verify_attachment(context, guide, outputs, support):
    key = _surface_contact_snap_key(guide)
    actual = Matrix(outputs[-1]) @ support
    if _pin_attachment_points_match(key, _contact_chain_target_matrix(guide).translation, actual):
        return True
    # A reach-limited solve is a valid closest pose, not a completed snap.
    # Evaluation never rewrites the user's keyed attachment request.
    for name in ('pin_snap_latches', 'pin_snap_initial_latches', 'pin_snap_transform_engaged'):
        _state.setdefault(name, set()).discard(key)
    _state.setdefault('pin_snap_detached', set()).add(key)
    if (guide.name in _state.get('pin_snap_direct_transform_guides', ())
            and _state.get('pin_snap_transform_active')
            and not _state.get('pin_target_dragging')):
        _surface_contact_set_snap_detached(guide, True)
    return False


def _contact_chain_magnetic_opposite(context, guide, owner, bone):
    smart = bpy.data.objects.get(str(guide.get(SURFACE_CONTACT_SMART_OBJECT_PROPERTY, '')))
    if smart is not None and not any(c.type == 'CHILD_OF' and c.target == owner
                                    and c.subtarget == bone.name for c in smart.constraints):
        # Bone parenting and skinned custom meshes have no welded-object
        # inverse. Resolve their actual mesh rod once at this gesture's pose.
        point = _surface_contact_opposite_anchor_world(context, guide)
        if point is not None:
            return (owner.matrix_world @ bone.matrix).inverted_safe() @ point
    return _surface_contact_opposite_local(guide, owner, bone,
        context.scene.frame_current_final, {})


def _contact_chain_magnetic_active(context, guide):
    if (not _contact_chain_uses_contact(guide)
            or not _surface_contact_has_valid_surface(guide)
            or not _state.get('pin_snap_transform_active')
            or guide.name in _state.get('contact_chain_committed_inputs', ())
            or guide.name not in _state.get('pin_snap_direct_transform_guides', ())
            or 'translate' not in str(_state.get('pin_snap_transform_operator', '')).lower()):
        return False
    owner, bone = _surface_contact_pose_bone(guide)
    names = _surface_contact_direct_bone_names(guide)
    return bone is not None and any(b.name in names for b in
        _selected_pose_bones_by_owner(context).get(owner, ()))


def _contact_chain_magnetic_raw(context, guide, raw, support, native_target, attached):
    if not _contact_chain_magnetic_active(context, guide):
        return raw, native_target
    sessions = _state.setdefault('contact_chain_magnetic_guides', set())
    sessions.add(guide.name)
    key = _surface_contact_snap_key(guide)
    _state.setdefault('pin_snap_pre_solve_anchor_samples', {})[key] = Vector(native_target).copy()
    target_matrix = _contact_chain_target_matrix(guide)
    target = target_matrix.translation.copy()
    if not _surface_contact_direct_magnetic_aim_allowed(context, key, target, native_target):
        return raw, native_target
    if attached:
        native_target = target.copy()
    if _contact_chain_is_planted(guide):
        # Plant owns face orientation. Aiming this same foot toward the pin
        # first moves its support goal, then Plant undoes that rotation. The
        # resulting translation accumulates again at every new G gesture.
        return raw, Vector(native_target).copy()
    owner, bone = _surface_contact_pose_bone(guide)
    opposite_cache = _state.setdefault('contact_chain_magnetic_opposites', {})
    opposite = opposite_cache.get(guide.name)
    if opposite is None:
        opposite = _contact_chain_magnetic_opposite(context, guide, owner, bone)
        opposite_cache[guide.name] = Vector(opposite).copy()
    baseline = _state.get('contact_chain_transform_effectors', {}).get(guide.name)
    world = (baseline if baseline is not None else raw[-1]).copy()
    world.translation += Vector(native_target) - world @ support
    anchor, pivot = world @ support, world @ opposite
    source, destination = anchor - pivot, target - pivot
    if source.length_squared > 1.e-12 and destination.length_squared > 1.e-12:
        rotation = _contact_chain_swing(source, destination, world.to_3x3().col[0])
        world = (Matrix.Translation(pivot) @ rotation.to_matrix().to_4x4()
                 @ Matrix.Translation(-pivot) @ world)
    aimed = world @ support
    _state.setdefault('pin_snap_magnetic_aim_anchor_samples', {})[key] = aimed.copy()
    # The shared mesh collision pass owns penetration of the contact patch.
    # The opposite mesh endpoint and the pin's infinite plane own no barrier.
    result = list(raw)
    result[-1] = world.copy()
    # Requested G displacement is a goal, never an extra joint length.
    result[-1].translation = raw[-1].translation.copy()
    return result, world @ support


def _contact_chain_aim_solved_mesh(outputs, support, opposite, target):
    """Aim from the solved joint, preserving linkage and rigid mesh offsets.

    Intersect the infinite mesh rod with the target-distance sphere centered
    on the joint. One shortest-arc turn aligns that local point to the pin;
    unlike aiming before IK, this remains exact after reach clamping.
    """
    world=Matrix(outputs[-1]);head=world.translation.copy()
    toward=Vector(target)-head
    a=world.to_3x3()@Vector(opposite)
    rod=world.to_3x3()@(Vector(support)-Vector(opposite))
    length2=rod.length_squared
    if length2<1.e-16 or toward.length_squared<1.e-16:return outputs
    middle=-a.dot(rod)/length2
    minimum=a+rod*middle
    reach2=toward.length_squared-minimum.length_squared
    # The positive root places the target beyond the mesh contact endpoint,
    # rather than turning the visible dot away from the pin.
    parameter=middle+math.sqrt(max(0.,reach2)/length2)
    reference=a+rod*parameter
    rotation=_contact_chain_swing(reference,toward,world.to_3x3().col[0])
    result=rotation.to_matrix().to_4x4()@world
    result.translation=head
    return (*outputs[:-1],tuple(tuple(float(v) for v in row) for row in result))


def _contact_chain_commit_magnetic_pose(context, guide, raw, desired):
    """Only a confirmed native edit may bake its magnetic output to source."""
    owner, bone = _surface_contact_pose_bone(guide)
    helper = bpy.data.objects.get(_contact_chain_records(guide)[-1][1])
    inverse_follow = _contact_chain_target_follow_matrix(guide,raw).inverted_safe()
    world = inverse_follow @ helper.matrix_world if helper is not None else raw[-1].copy()
    if helper is not None and _contact_chain_is_planted(guide):
        position=world.translation.copy()
        world=helper.matrix_world.copy();world.translation=position
    support = Vector(tuple(guide.get(SURFACE_CONTACT_SUPPORT_PROPERTY, (0., bone.length, 0.)))[:3])
    world.translation = raw[-1].translation.copy()
    world.translation += inverse_follow @ Vector(desired) - world @ support
    kwargs = {} if bone.parent is None else dict(
        parent_matrix=owner.matrix_world.inverted_safe() @ (raw[-2] if len(raw)>1 else owner.matrix_world@bone.parent.matrix),
        parent_matrix_local=bone.parent.bone.matrix_local)
    basis = bone.bone.convert_local_to_pose(owner.matrix_world.inverted_safe() @ world,
        bone.bone.matrix_local, invert=True, **kwargs)
    changed = _pin_keyboard_matrices_differ(bone.matrix_basis, basis, epsilon=1.e-7)
    if changed:
        bone.matrix_basis = basis
        held_key = (_armature_session_uid(owner),bone.name)
        held = _state.get('contact_chain_held_inputs',{})
        if held_key in held:
            held[held_key] = (owner.name,bone.name,basis.copy())
        if context.scene.tool_settings.use_keyframe_insert_auto:
            _insert_bone_keys(bone, context.scene.frame_current, visual=False)
    return changed
