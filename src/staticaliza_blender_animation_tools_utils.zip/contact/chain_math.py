"""Deterministic fixed-length Contact chains; no Blender data mutation."""

from ..core.runtime import *  # noqa: F403


def _contact_chain_unit(value, fallback):
    value = Vector(value)
    if value.length_squared < 1.e-18:
        value = Vector(fallback)
    return value.normalized() if value.length_squared > 1.e-18 else Vector((0, 1, 0))


def _contact_chain_swing(source, destination, perpendicular):
    a = _contact_chain_unit(source, (0, 1, 0))
    b = _contact_chain_unit(destination, a)
    if a.dot(b) < -1. + 1.e-7:
        axis = Vector(perpendicular) - a * Vector(perpendicular).dot(a)
        return Quaternion(_contact_chain_unit(axis, a.orthogonal()), math.pi)
    return a.rotation_difference(b)


def _contact_chain_bend_fallback(raw):
    """The solver and indicator share the same authored foot/toe reference."""
    fallback = raw[0].to_3x3().col[0]
    if len(raw)>1:
        reach=_contact_chain_unit(raw[-1].translation-raw[0].translation,(0,1,0))
        forward=raw[-1].to_3x3().col[1]
        transverse=forward-reach*forward.dot(reach)
        # A straight leg has no authored knee plane. A nonparallel foot/toe
        # axis supplies a meaningful default, independent of thigh roll.
        if transverse.length_squared>forward.length_squared*1.e-6:
            fallback=transverse
    return fallback


def _contact_chain_curve_bend(points,axis):
    """The strongest coherent curvature; opposing lobes cannot cancel it."""
    total=sum((b-a).length for a,b in zip(points,points[1:]))
    residuals=[(p-points[0])-axis*(p-points[0]).dot(axis) for p in points[1:-1]]
    largest=max((p.length_squared for p in residuals),default=0.)
    if largest<=max(1.e-24,total*total*1.e-6):return None
    # Near ties choose the proximal joint, independent of float32 noise.
    primary=next(p for p in residuals if p.length_squared>=largest*.98)
    coherent=sum((p*(max(0.,p.dot(primary))/primary.length_squared) for p in residuals),Vector())
    return coherent.normalized()


def _contact_chain_natural_bend(raw, *, pole=None, hinges=(), continuations=()):
    """Infer a signed default from rig-local definitions, without pose history.

    Authored poles win; otherwise a meaningful rest bend wins over hinge and
    terminal clues. Opposing curves cannot cancel the plane of an S chain.
    Names, cameras, previous outputs and world-axis conventions are absent.
    """
    points=[m.translation.copy() for m in raw]
    axis=_contact_chain_unit(points[-1]-points[0],raw[0].to_3x3().col[1])
    def project(value):
        value=Vector(value)
        if not all(math.isfinite(v) for v in value):return None
        result=value-axis*value.dot(axis)
        return result.normalized() if result.length_squared>max(1.e-24,value.length_squared*1.e-8) else None
    if pole is not None:
        candidate=project(Vector(pole)-points[0])
        if candidate is not None:return candidate
    curve=_contact_chain_curve_bend(points,axis)
    if curve is not None:return curve
    for vector in hinges:
        candidate=project(vector)
        if candidate is not None:return candidate
    # A nearly parallel toe/hand is weak evidence, not a noisy bend plane.
    for vector in continuations:
        value=Vector(vector);projected=value-axis*value.dot(axis)
        if projected.length_squared>max(1.e-24,value.length_squared*.04):
            return projected.normalized()
    for column in (0,2,1):
        candidate=project(raw[0].to_3x3().col[column])
        if candidate is not None:return candidate
    return axis.orthogonal().normalized()


def _contact_chain_bend_bias(raw,support,target,bend=0.):
    """World-space bend preference from the exact input used by the solver."""
    points=[m.translation.copy() for m in raw]
    lengths=[(b-a).length for a,b in zip(points,points[1:])]
    epsilon=max(1.e-8,sum(lengths)*1.e-8)
    compact=[points[0]]+[points[i+1] for i,size in enumerate(lengths) if size>epsilon]
    if len(compact)<2:return None
    goal=Vector(target)-raw[-1].to_3x3()@Vector(support)
    return _contact_chain_bend_frame(compact,goal,_contact_chain_bend_fallback(raw),bend)[2]


def _contact_chain_reachable_target(raw,support,target):
    """Expose the same reachable goal the fixed-length IK actually solves."""
    target=Vector(target).copy()
    if len(raw)<2:return target
    sizes=[(b.translation-a.translation).length for a,b in zip(raw,raw[1:])]
    total=sum(sizes)
    if total<1.e-8:return target
    offset=raw[-1].to_3x3()@Vector(support)
    root=raw[0].translation;delta=target-offset-root;distance=delta.length
    minimum=max(0.,2.*max(sizes)-total)
    reach=max(minimum,min(total,distance))
    if abs(reach-distance)<1.e-8:return target
    return root+_contact_chain_unit(delta,raw[-1].translation-root)*reach+offset


def _contact_chain_twist_matrices(raw, bend):
    """Change only the chain's angular coordinate, retaining both end joints.

    Re-solving an unchanged goal chooses a new near-straight knee plane and
    accumulates bone roll through repeated shortest-arc swings. A rigid twist
    is the exact fixed-length solution for an explicit Bend-only edit.
    The rigid effector keeps its authored orientation and mesh support.
    """
    if len(raw)<2 or abs(bend)<1.e-12:return raw
    root=raw[0].translation
    axis=raw[-1].translation-root
    if axis.length_squared<1.e-16:return raw
    rotation=Quaternion(axis.normalized(),bend).to_matrix().to_4x4()
    transform=Matrix.Translation(root)@rotation@Matrix.Translation(-root)
    return [transform@matrix for matrix in raw[:-1]]+[raw[-1].copy()]


def _contact_chain_solve_matrices(raw, support, target, bend=0., *, fixed_head=False, align_support=True, bend_fallback=None):
    """Solve real joints, retaining the endpoint's authored orientation/scale.

    A mesh support is a rigid effector offset, never an additional bendable
    limb. In particular a foot/toe offset must not become a third leg joint.
    """
    target = Vector(target)
    offset = raw[-1].to_3x3() @ Vector(support)
    goal = target-offset
    points = [m.translation.copy() for m in raw]
    # World matrices and support products are float32. Subtracting the same
    # rigid support can leave a one-ULP residual (1.19e-7 in Recording 2).
    tolerance=max(1.e-8,max(abs(v) for p in (goal,points[-1]) for v in p)*2.**-22)
    if len(raw)>1 and abs(bend)<1.e-12 and (goal-points[-1]).length_squared<=tolerance*tolerance:
        # An already satisfied chain is an exact solution. Keep authored roll
        # and tiny knee offsets instead of re-seeding a numerical singularity.
        return tuple(tuple(tuple(float(v) for v in row) for row in m) for m in raw),float((goal-points[-1]).length)
    fallback=(_contact_chain_bend_fallback(raw) if bend_fallback is None else Vector(bend_fallback))
    if len(raw)==1 and fixed_head:
        result=raw[0].copy()
        root=result.translation.copy()
        if align_support and offset.length_squared>1.e-16 and (target-root).length_squared>1.e-16:
            swing=_contact_chain_swing(offset,target-root,fallback)
            result=swing.to_matrix().to_4x4()@result
        result.translation=root
        residual=(result@Vector(support)-target).length
        return (tuple(tuple(float(v) for v in row) for row in result),),float(residual)
    if len(raw)==1:
        positions,residual = [goal],0.
    else:
        positions,residual = _contact_chain_positions(points,goal,fallback,bend)
    outputs=[]
    for i,matrix in enumerate(raw):
        result=matrix.copy()
        if i+1<len(raw):
            delta=_contact_chain_swing(points[i+1]-points[i],positions[i+1]-positions[i],fallback)
            result=delta.to_matrix().to_4x4() @ matrix
        result.translation=positions[i]
        outputs.append(tuple(tuple(float(v) for v in row) for row in result))
    return tuple(outputs),float(residual)


def _contact_chain_solve_planted(raw, support, target, bend=0.):
    """A planted Contact may move its whole chain without stretching links."""
    outputs, _residual = _contact_chain_solve_matrices(
        raw, support, _contact_chain_soft_target(raw,support,target), bend)
    correction = Vector(target) - Matrix(outputs[-1]) @ Vector(support)
    if correction.length_squared <= 1.e-16:
        return outputs, 0.
    shifted = []
    for values in outputs:
        matrix = Matrix(values)
        matrix.translation += correction
        shifted.append(tuple(tuple(float(v) for v in row) for row in matrix))
    return tuple(shifted), 0.


def _contact_chain_soft_target(raw, support, target):
    """Ease the full-extension singularity, then plant the real endpoint.

    Exact fixed-length IK has an infinite knee velocity at full extension.
    A short exponential reach band avoids that catch without time filtering,
    stretching, or writing FK inputs. Already matching authored poses remain
    exact, including the visible-pose handoff when Chain or IK changes.
    """
    target=Vector(target)
    if len(raw)<3:return target
    total=sum((b.translation-a.translation).length for a,b in zip(raw,raw[1:]))
    if total<1.e-8:return target
    mismatch=(target-raw[-1]@Vector(support)).length
    weight=min(1.,mismatch/(total*.1))
    weight=weight*weight*(3.-2.*weight)
    softness=total*.05*weight
    if softness<total*1.e-7:return target
    offset=raw[-1].to_3x3()@Vector(support)
    reach=target-offset-raw[0].translation
    distance=reach.length
    start=total-softness
    if distance<=start:return target
    eased=start-softness*math.expm1(-(distance-start)/softness)
    return target-reach*((distance-eased)/distance)


def _contact_chain_bend_frame(points, target, fallback, bend=0.):
    """One bend plane shared by the solver and its viewport indicator."""
    root = points[0]
    direction = _contact_chain_unit(Vector(target)-root, points[-1]-root)
    travel = _contact_chain_swing(points[-1]-root,direction,fallback)
    preference = [root + travel @ (point-root) for point in points]
    bias = _contact_chain_curve_bend(preference,direction)
    reference = travel @ Vector(fallback)
    reference -= direction*reference.dot(direction)
    # A nearly straight authored chain has no reliable knee plane. Its tiny
    # transverse residual changes under float32 pose conversion/history and
    # must not choose a different bend side after an otherwise identical G.
    # Use the existing bone/toe reference inside 0.1% of the chain's length.
    if bias is None:bias=reference
    bias -= direction*bias.dot(direction)
    bias = _contact_chain_unit(bias,_contact_chain_unit(reference,direction.orthogonal()))
    twist = Quaternion(direction,float(bend))
    return direction,[root+twist@(point-root) for point in preference],twist@bias


def _contact_chain_positions(points, target, fallback, bend=0., iterations=32):
    """Return joints and residual. Restart from authored input, never last output.

    The terminal segment ends at the actual bone-local mesh support. Zero
    segments collapse before solving and expand afterward. The two-segment
    case uses the cosine law; longer chains use bounded FABRIK projections.
    """
    original = [Vector(p) for p in points]
    target = Vector(target)
    lengths = [(b-a).length for a, b in zip(original, original[1:])]
    total = sum(lengths)
    epsilon = max(1.e-8, total * 1.e-8)
    active = [i for i, length in enumerate(lengths) if length > epsilon]
    if not active:
        return [original[0].copy() for _ in original], (target-original[0]).length
    compact = [original[0].copy()] + [original[i+1].copy() for i in active]
    sizes = [lengths[i] for i in active]
    root = compact[0].copy()
    # Parallel-transport the authored bend plane. A stable bone-local fallback
    # resolves a straight or folded chain without consulting previous frames.
    direction, preference, bias = _contact_chain_bend_frame(compact,target,fallback,bend)
    distance = (target-root).length
    minimum = max(0., 2.*max(sizes)-sum(sizes))
    reachable_distance = max(minimum, min(sum(sizes), distance))
    goal = root + direction*reachable_distance
    if len(sizes) == 1:
        solved = [root, root + direction*sizes[0]]
    elif len(sizes) == 2:
        a, b = sizes
        if reachable_distance <= epsilon:
            joint = root + bias*a
        else:
            along = (a*a-b*b+reachable_distance*reachable_distance)/(2.*reachable_distance)
            height = math.sqrt(max(0., a*a-along*along))
            joint = root + direction*along + bias*height
        solved = [root, joint, goal]
    elif distance >= total-epsilon:
        solved = [root]
        for length in sizes:
            solved.append(solved[-1] + direction*length)
    elif minimum > 0 and distance <= minimum+epsilon:
        longest = sizes.index(max(sizes))
        solved = [root]
        for i, length in enumerate(sizes):
            solved.append(solved[-1] + direction*length*(1. if i == longest else -1.))
    else:
        solved = [point.copy() for point in preference]
        # Collinear in-reach targets are a stationary point of plain FABRIK.
        # A deterministic, scale-relative arc supplies the missing bend side.
        spread = max(((point-root).cross(direction).length for point in solved[1:-1]), default=0.)
        if spread < max(epsilon, total*1.e-5):
            # Match the seed's slack to the requested reach. A fixed 10%
            # bulge converges slowly near full extension, leaving visible
            # pin gaps in long, initially straight chains.
            amplitude = math.sqrt(2.*max(0.,total*total-reachable_distance*reachable_distance))/math.pi
            cumulative = 0.
            for i in range(1, len(solved)-1):
                cumulative += sizes[i-1]
                fraction = cumulative/total
                solved[i] = (root + direction*(reachable_distance*fraction)
                             + bias*(amplitude*math.sin(math.pi*fraction)))
        tolerance = max(2.e-6, total*2.e-6)
        for _ in range(max(1, min(64, int(iterations)))):
            solved[-1] = goal.copy()
            for i in range(len(sizes)-1, -1, -1):
                solved[i] = solved[i+1] + _contact_chain_unit(
                    solved[i]-solved[i+1], preference[i]-preference[i+1])*sizes[i]
            solved[0] = root.copy()
            for i, length in enumerate(sizes):
                solved[i+1] = solved[i] + _contact_chain_unit(
                    solved[i+1]-solved[i], preference[i+1]-preference[i])*length
            if (solved[-1]-goal).length <= tolerance:
                break
    expanded = [root.copy()]
    cursor = 0
    active_indices = set(active)
    for i in range(len(lengths)):
        if i in active_indices:
            cursor += 1
        expanded.append(solved[cursor].copy())
    return expanded, (expanded[-1]-target).length
