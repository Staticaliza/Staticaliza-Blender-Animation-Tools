"""Generation-based caches shared by Surface Contact runtime paths."""

from ..core.runtime import *  # noqa: F403


def _surface_contact_clear_derived_caches(*, advance_generation=True):
    if advance_generation:
        _state["surface_contact_guide_cache_generation"] = int(
            _state.get("surface_contact_guide_cache_generation", 0)
        ) + 1
    _state["surface_contact_release_locations"] = {}
    _state["surface_contact_active_guide_cache"] = {}
    _state["surface_contact_effector_guide_cache"] = {}
    _state["surface_contact_pose_bone_cache"] = {}
    _state["surface_contact_resolved_guide_cache"] = {}
    _state["surface_contact_attached_frame_cache"] = {}
    _state["surface_contact_attached_frame_cache_scope"] = None
    _state["surface_contact_detached_fcurve_cache"] = {}
    _state["surface_contact_detached_key_cache"] = {}
    _state["surface_contact_depsgraph_guide_index"] = None
    _state["surface_contact_playback_settle_signature"] = None


def _surface_contact_guide_cache_hot(now=None):
    now = time.perf_counter() if now is None else float(now)
    context = getattr(bpy, "context", None)
    return bool(
        context is not None
        and (
            _animation_playback_active(context)
            or now < float(
                _state.get("dynamic_space_frame_evaluation_until", 0.0)
            )
        )
    )


def _surface_contact_guides():
    object_count = len(bpy.data.objects)
    cached_names = tuple(_state.get("surface_contact_guide_cache", ()))
    cached_count = int(
        _state.get("surface_contact_guide_cache_object_count", -1)
    )
    now = time.perf_counter()
    deadline = float(
        _state.get("surface_contact_guide_cache_validation_deadline", 0.0)
    )
    hot = _surface_contact_guide_cache_hot(now)
    cached_hot = bool(_state.get("surface_contact_guide_cache_hot", False))
    if (
        cached_count == object_count
        and hot == cached_hot
        and now < deadline
    ):
        return tuple(
            guide
            for name in cached_names
            if (guide := bpy.data.objects.get(str(name))) is not None
            and bool(guide.get(SURFACE_CONTACT_GUIDE_PROPERTY, False))
        )
    guides = tuple(
        obj
        for obj in bpy.data.objects
        if bool(obj.get(SURFACE_CONTACT_GUIDE_PROPERTY, False))
    )
    identity = tuple(sorted(str(obj.name) for obj in guides))
    if identity != tuple(_state.get("surface_contact_guide_cache_identity", ())):
        _surface_contact_clear_derived_caches(advance_generation=True)
    _state["surface_contact_guide_cache"] = tuple(
        str(guide.name) for guide in guides
    )
    _state["surface_contact_guide_cache_object_count"] = object_count
    _state["surface_contact_guide_cache_identity"] = identity
    _state["surface_contact_guide_cache_validation_deadline"] = now + (
        2.0 if hot else 0.5
    )
    _state["surface_contact_guide_cache_hot"] = hot
    return guides


def _surface_contact_invalidate_guide_cache():
    _state["surface_contact_guide_cache"] = ()
    _state["surface_contact_guide_cache_object_count"] = -1
    _state["surface_contact_guide_cache_identity"] = ()
    _state["surface_contact_guide_cache_validation_deadline"] = 0.0
    _state["surface_contact_guide_cache_hot"] = False
    _surface_contact_clear_derived_caches(advance_generation=True)
