"""Surface-contact creation, release, and clear operators."""

from ..core.runtime import *  # noqa: F403
def _reconcile_surface_contact_markers(context, armature = None):
    if _state.get("surface_contact_reconciling", False):
        return False
    _state["surface_contact_reconciling"] = True
    try:
        _surface_contact_invalidate_detached_key_cache()
        changed = False
        guide_names = tuple(guide.name for guide in _surface_contact_guides())
        for guide_name in guide_names:
            guide = bpy.data.objects.get(guide_name)
            if guide is None:
                continue
            if (
                armature is not None
                and str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
                != armature.name
            ):
                continue
            _target_object, owner = _surface_contact_owner_from_guide(guide)
            if owner is None:
                _surface_contact_remove_guide(
                    context,
                    guide,
                    preserve_frame = int(context.scene.frame_current),
                )
                changed = True
                continue
            changed = _surface_contact_strip_scale_animation(guide) or changed
            marker_points = _surface_contact_marker_points(owner)
            start = int(guide.get(SURFACE_CONTACT_START_PROPERTY, 0))
            start_value = marker_points.get(start)
            if start_value is None or float(start_value) < 0.5:
                _surface_contact_remove_guide(
                    context,
                    guide,
                    preserve_frame = int(context.scene.frame_current),
                )
                changed = True
                continue
            next_starts = tuple(
                int(other.get(SURFACE_CONTACT_START_PROPERTY, 0))
                for other_name in guide_names
                for other in (bpy.data.objects.get(other_name),)
                if other is not None and other != guide
                and _surface_contact_guide_matches_owner(other, owner)
                and int(other.get(SURFACE_CONTACT_START_PROPERTY, 0)) > start
            )
            next_start = min(next_starts) if next_starts else None
            release_frames = tuple(sorted(
                frame
                for frame, value in marker_points.items()
                if frame > start
                and float(value) < 0.5
                and (next_start is None or frame < next_start)
            ))
            # A replacement Start also closes the preceding guide. A shared
            # marker cannot hold both OFF and ON at that same frame; dropping
            # this boundary reopened old pink guides during mode round trips.
            marker_end = release_frames[0] if release_frames else next_start
            stored_end = (
                int(guide[SURFACE_CONTACT_END_PROPERTY])
                if SURFACE_CONTACT_END_PROPERTY in guide
                else None
            )
            if stored_end is not None and stored_end != marker_end:
                _constraint_reconcile_end_keys(
                    guide, owner.id_data,
                    {stored_end: marker_end} if marker_end is not None else {},
                    () if marker_end is not None else (stored_end,))
            if marker_end is None:
                if stored_end is not None:
                    del guide[SURFACE_CONTACT_END_PROPERTY]
                    changed = True
            elif stored_end != marker_end:
                guide[SURFACE_CONTACT_END_PROPERTY] = marker_end
                changed = True
            target_frames = _surface_contact_target_frames(guide)
            retained_target_frames = tuple(
                frame
                for frame in target_frames
                if frame in marker_points and float(marker_points[frame]) >= 0.5
            )
            if retained_target_frames != target_frames:
                for removed_frame in set(target_frames) - set(retained_target_frames):
                    _surface_contact_delete_guide_transform_keys(
                        guide,
                        removed_frame,
                    )
                _surface_contact_set_target_frames(
                    guide,
                    retained_target_frames,
                )
                changed = True
            changed = (
                _surface_contact_sync_guide_key_styles(owner, guide)
                or changed
            )

        armatures = (
            (armature,)
            if armature is not None
            else tuple(
                obj
                for obj in bpy.data.objects
                if obj.type == "ARMATURE" and getattr(obj, "pose", None)
            )
        )
        for current_armature in armatures:
            if current_armature is None or getattr(current_armature, "pose", None) is None:
                continue
            for pose_bone in current_armature.pose.bones:
                if SURFACE_CONTACT_MARKER_PROPERTY not in pose_bone:
                    continue
                if _surface_contact_expected_markers(pose_bone):
                    continue
                changed = _surface_contact_rebuild_markers(
                    pose_bone,
                    pose_bone.name,
                ) or changed

        if changed:
            _surface_contact_invalidate_guide_cache()
            context.view_layer.update()
            _sync_surface_contact_constraints(
                context.scene,
                respect_selected = True,
                force_unselected = False,
                solve_simulated = False,
                solve_guides = False,
                sync_dynamic_parent = False,
            )
            # Flush metadata/constraint dirtiness while reconciliation guards
            # are still active, so no queued next-tick depsgraph event can
            # become a delayed SIMULATED pose correction.
            context.view_layer.update()
            _tag_redraw_all_view3d()
        return changed
    finally:
        _state["surface_contact_reconciling"] = False


def _surface_contact_geometry_bone_candidates(selected_bone, relation):
    ordered = []
    if selected_bone is not None:
        ordered.append(selected_bone)
    if relation is not None:
        ordered.append(relation.get("effector"))
        ordered.extend(relation.get("chain", ()))

    seen = set()
    result = []
    for pose_bone in ordered:
        if pose_bone is None or pose_bone.name in seen:
            continue
        seen.add(pose_bone.name)
        result.append(pose_bone)
    return tuple(result)


def _surface_contact_smart_anchor_world(
    context,
    armature,
    bone_name,
    support_objects,
):
    context.view_layer.update()
    depsgraph = context.evaluated_depsgraph_get()
    evaluated_armature = armature.evaluated_get(depsgraph)
    evaluated_bone = evaluated_armature.pose.bones.get(bone_name)
    if evaluated_bone is None:
        return evaluated_armature, None, None
    anchor, _object_name, _object_local = _yellow_mode3_anchor(
        context,
        depsgraph,
        armature,
        evaluated_armature,
        support_objects,
        bone_name,
    )
    return evaluated_armature, evaluated_bone, anchor


def _surface_contact_control_target(relation, armature, effector):
    if relation is not None:
        target_object = relation.get("target_object")
        target_bone = relation.get("target_bone")
        if target_object is not None and target_bone is not None:
            return target_object, target_bone.name, True
        if (
            target_object is not None
            and getattr(target_object, "type", "") != "ARMATURE"
        ):
            return target_object, "", True
    return armature, effector.name, False

class ANIMATOR_UTILS_OT_surface_contact_create(bpy.types.Operator):
    bl_idname = "staticaliza.surface_contact_create"
    bl_label = "Surface Contact"
    bl_description = (
        'Add a collision constraint at the nearest surface'
    )
    bl_options = {"REGISTER", "UNDO"}

    pin_mode: bpy.props.EnumProperty(
        name = "Pin Position",
        description = 'Choose the bone attachment point',
        items = (
            ("MODE_3", "Smart", "Use the selected welded-object face"),
            ("MODE_4", "Bone Start", "Use the selected contact bone's head"),
            ("MODE_2", "Bone Center", "Use the center of the linked weighted geometry"),
            ("MODE_1", "Bone End", "Use the selected contact bone's tail"),
        ),
        default = "MODE_3",
    )
    cast_axis: bpy.props.EnumProperty(
        name = "Axis",
        description = 'Choose the direction used to find a surface',
        items = PIN_AXIS_ITEMS,
        default = "Y_NEG",
    )
    @classmethod
    def poll(cls, context):
        return bool(
            context.mode == "POSE"
            and _selected_pose_bones_by_owner(context, include_virtual_pin=True)
        )
    def draw(self, context):
        self.layout.prop(self, "pin_mode", text = "Position")
        self.layout.prop(self, "cast_axis", text = "Axis")
    def execute(self, context):
        if not self.properties.is_property_set("pin_mode"):
            self.pin_mode = str(
                getattr(
                    context.window_manager,
                    "surface_contact_pin_mode",
                    "MODE_3",
                )
            )
        if not self.properties.is_property_set("cast_axis"):
            self.cast_axis = str(
                getattr(
                    context.window_manager,
                    "surface_contact_cast_axis",
                    "Y_NEG",
                )
            )
        if _state.get("surface_contact_creation_active", False):
            return {"CANCELLED"}
        previous_solver_guard = bool(
            _state.get("surface_contact_solver_syncing", False)
        )
        _state["surface_contact_creation_active"] = True
        _state["surface_contact_solver_syncing"] = True
        try:
            # Publishing redo options is UI synchronization, not a second
            # user axis edit. Its RNA callback must not push native history.
            context.window_manager.surface_contact_cast_axis = self.cast_axis
            context.window_manager.surface_contact_pin_mode = self.pin_mode
            return ANIMATOR_UTILS_OT_surface_contact_create._execute_guarded(self, context)
        finally:
            _state["surface_contact_solver_syncing"] = previous_solver_guard
            _state["surface_contact_creation_active"] = False
    def _execute_guarded(self, context):
        targets = _constraint_creation_subjects(context)
        if not targets:
            return {"CANCELLED"}
        completed = 0
        for armature, selected_bone in targets:
            result = ANIMATOR_UTILS_OT_surface_contact_create._execute_bone(
                self,
                context,
                armature,
                selected_bone,
            )
            if result == {"FINISHED"}:
                completed += 1
        if completed > 1:
            self.report(
                {"INFO"},
                f"Contact enabled for {completed} selected bones.",
            )
        return {"FINISHED"} if completed else {"CANCELLED"}

    def _execute_bone(self, context, armature, selected_bone):
        relation = _surface_contact_ik_relation(armature, selected_bone)
        effector = relation["effector"] if relation is not None else selected_bone
        _constraint_pin_end_other(context, armature, effector, "COLLISION")
        context.window_manager.constraint_pin_type = "COLLISION"
        initial_effector_matrix = effector.matrix.copy()
        frame = int(context.scene.frame_current)
        exact_guides, previous_guide, carried_end = (
            _surface_contact_retarget_plan(armature, effector, frame)
        )
        split_start_frame = (
            frame + 1
            if (
                previous_guide is not None
                and carried_end is not None
                and frame + 1 < int(carried_end)
            )
            else frame
        )
        split_pose = (_special_end_previous_pose(context, armature, effector, frame)
                      if split_start_frame > frame else None)

        evaluated_armature = None
        evaluated_geometry_bone = None
        part = None
        geometry_points = ()
        support_objects = ()
        for geometry_bone in _surface_contact_geometry_bone_candidates(
            selected_bone,
            relation,
        ):
            (
                evaluated_armature,
                evaluated_geometry_bone,
                part,
                geometry_points,
                support_objects,
            ) = _surface_contact_part_geometry(
                context,
                armature,
                geometry_bone,
            )
            if part is not None and geometry_points:
                break
        if part is None or not geometry_points:
            self.report(
                {"ERROR"},
                "No connected mesh object was found for the selected endpoint.",
            )
            return {"CANCELLED"}
        geometry_bone_name = evaluated_geometry_bone.name
        depsgraph = context.evaluated_depsgraph_get()
        contact_anchor, smart_object_name, smart_object_local = (
            _surface_contact_creation_anchor(
                context,
                depsgraph,
                armature,
                evaluated_armature,
                evaluated_geometry_bone,
                part,
                geometry_points,
                support_objects,
                pin_mode=self.pin_mode,
                pin_axis=self.cast_axis,
            )
        )
        if contact_anchor is None:
            self.report(
                {"ERROR"},
                "Unable to find the connected object's Smart Pin contact point.",
            )
            return {"CANCELLED"}
        surface, surface_point, surface_normal, bone_length = (
            _surface_contact_detect_surface(
                context,
                armature,
                evaluated_armature,
                evaluated_geometry_bone,
                geometry_points,
                support_objects,
                contact_anchor,
                smart_object_name,
                cast_axis=self.cast_axis,
            )
        )
        surface_valid = surface is not None and surface_point is not None and surface_normal is not None
        if not surface_valid:
            surface = None
            surface_point = Vector(contact_anchor)
            surface_normal = Vector((0.0, 0.0, 1.0))
            bone_length = max(0.05, float(effector.length))

        # Helper creation can rebuild the depsgraph. Retain math values, never
        # evaluated PoseBone/Object RNA wrappers across that boundary.
        geometry_world = (evaluated_armature.matrix_world @ evaluated_geometry_bone.matrix).copy()

        transition_guides = list(exact_guides)
        if previous_guide is not None and previous_guide not in transition_guides:
            transition_guides.append(previous_guide)
        suspended = _surface_contact_suspend_guides(transition_guides)
        plane_world = _surface_contact_plane_matrix(
            surface_point,
            surface_normal,
            _surface_contact_target_world_matrix(
                context,
                armature,
                effector.name,
            ),
        )

        guide = _surface_contact_create_guide(
            context,
            armature,
            effector,
            armature,
            effector.name,
            geometry_bone_name,
            plane_world,
            surface,
            surface_point,
            surface_normal,
            bone_length,
            split_start_frame,
        )
        guide[SURFACE_CONTACT_PIN_MODE_PROPERTY] = self.pin_mode
        guide[SURFACE_CONTACT_OBJECT_PROPERTY] = part.name
        guide[SURFACE_CONTACT_CAST_AXIS_PROPERTY] = self.cast_axis
        if smart_object_name and smart_object_local is not None:
            guide[SURFACE_CONTACT_SMART_OBJECT_PROPERTY] = smart_object_name
            guide[SURFACE_CONTACT_SMART_LOCAL_PROPERTY] = tuple(
                float(value) for value in smart_object_local
            )
        guide[SURFACE_CONTACT_SUPPORT_PROPERTY] = tuple(
            geometry_world.inverted_safe() @ contact_anchor
        )
        try:
            primary, _solver = _surface_contact_add_dot_constraint(
                context,
                guide,
                armature,
                effector,
                relation,
            )
        except Exception:
            _surface_contact_remove_guide(context, guide)
            _surface_contact_restore_suspended(suspended)
            raise

        if _solver is None or (
            primary is None
            and str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
            != SURFACE_CONTACT_KIND_SIMULATED
        ):
            _surface_contact_remove_guide(context, guide)
            _surface_contact_restore_suspended(suspended)
            self.report({"ERROR"}, "Unable to create the contact target constraint.")
            return {"CANCELLED"}
        initially_attached = surface_valid and _surface_contact_creation_is_attached(
            guide,
            contact_anchor,
            surface_point,
            surface_normal,
            bone_length,
        )
        if initially_attached:
            reachable_target = _surface_contact_project_reachable_target(
                context,
                guide,
                surface_point,
                surface_normal,
                align_initial = True,
            )
            if reachable_target is not None:
                _surface_contact_set_guide_surface_point(
                    context,
                    guide,
                    reachable_target[0],
                    reachable_target[1],
                )
            solved_anchor, final_support = _surface_contact_align_solver(
                context,
                guide,
                armature,
                geometry_bone_name,
                support_objects,
            )
            if solved_anchor is None or final_support is None:
                effector.matrix = initial_effector_matrix
                context.view_layer.update()
                _surface_contact_remove_guide(context, guide)
                _surface_contact_restore_suspended(suspended)
                self.report(
                    {"ERROR"},
                    "Unable to align the contact dots for this bone.",
                )
                return {"CANCELLED"}
        else:
            # Creating a target across an air gap must never author movement
            # into the selected limb or an unrelated regular control bone.
            effector.matrix = initial_effector_matrix
        # Creation has already decided and, when applicable, solved the
        # endpoint dot-to-dot. Publish that complete state before any
        # keyframe/depsgraph callback can observe an in-between contact.
        _surface_contact_publish_creation_attachment(
            guide,
            initially_attached,
        )

        solved_bases = _pin_capture_action_pose_bases((armature,))
        _surface_contact_insert_marker(
            effector,
            effector.name,
            split_start_frame,
            1.0,
        )
        _surface_contact_keyframe_guide_transform(
            guide,
            split_start_frame,
            effector.name,
        )
        _surface_contact_keyframe_detached_state(
            guide,
            split_start_frame,
            not initially_attached,
        )
        # Start/End author the Contact channel, not bone transform keys.
        # Preserve the solved pose through the existing guide/runtime state.
        if previous_guide is not None:
            previous_guide[SURFACE_CONTACT_END_PROPERTY] = int(frame)
        for existing_guide in exact_guides:
            _surface_contact_remove_guide(
                context,
                existing_guide,
            )
        if carried_end is not None and int(carried_end) > split_start_frame:
            guide[SURFACE_CONTACT_END_PROPERTY] = int(carried_end)
        _surface_contact_rebuild_markers(
            effector,
            effector.name,
        )
        _sync_surface_contact_constraints(
            context.scene,
            solve_simulated = False,
            solve_guides = False,
            sync_dynamic_parent = False,
        )
        context.view_layer.update()
        _pin_restore_action_pose_bases(context, solved_bases)
        if split_pose is not None:
            _constraint_key_end_pose(context, armature, effector, split_pose, frame, previous_guide)
        # The freshly aligned pose is the collision rollback baseline. Seed
        # it before the user's first transform so a single large mouse sample
        # cannot enter the linked mesh or pass through the contacted surface.
        _surface_contact_store_valid_pose(guide)
        _surface_contact_store_owner_pose_base(guide)
        _surface_contact_seed_runtime_signatures(context, (guide,))
        _accept_authored_dynamic_space_state()

        _sync_all_dynamic_pose_bone_colors(frame, armature=armature)

        _yellow_refresh_runtime(context)
        _tag_redraw_all_view3d()
        if surface is None:
            _state["last_error"] = ""
            return {"FINISHED"}
        self.report(
            {"INFO"},
            (
                f"Contact enabled for {part.name} against {surface.name}."
                if initially_attached
                else (
                    f"Contact target placed on {surface.name}; "
                    "move the limb to attach."
                )
            ),
        )
        return {"FINISHED"}


class ANIMATOR_UTILS_OT_surface_contact_release(bpy.types.Operator):
    bl_idname = "staticaliza.surface_contact_release"
    bl_label = "Constraints"
    bl_description = 'End the selected collision constraints and key the ending pose'
    bl_options = {"REGISTER", "UNDO"}
    insert_bone_keyframe: bpy.props.BoolProperty(
        name="Insert Keyframe", default=True, options={"SKIP_SAVE"},
        description="Key the ending bone pose unless a bone key already exists at that frame")

    def draw(self, context):
        self.layout.prop(self, "insert_bone_keyframe")

    @classmethod
    def poll(cls, context):
        guide = _surface_contact_selected_guide(context, active_only = True)
        if guide is None:
            return False
        frame = int(context.scene.frame_current)
        return (
            frame > int(guide.get(SURFACE_CONTACT_START_PROPERTY, frame))
            and frame != guide.get(SURFACE_CONTACT_END_PROPERTY)
        )

    def execute(self, context):
        return _special_end_with_key_option(self, context, self._execute)

    def _execute(self, context):
        state = _constraint_selection_state(context)
        if state["pink"] and state["cyan"]:
            return _constraint_apply_action(context, "END", self)
        guide = _surface_contact_selected_guide(context, active_only=True)
        if guide is None:
            return {"CANCELLED"}
        result = _surface_contact_release_guide(context, guide, self)
        return result


class ANIMATOR_UTILS_OT_surface_contact_pivot(bpy.types.Operator):
    bl_idname = "staticaliza.surface_contact_pivot"
    bl_label = "Pivot Surface Contact Pin"
    bl_description = 'Move the selected bones onto their collision pins'
    bl_options = {"REGISTER", "UNDO"}

    initial_state_json: bpy.props.StringProperty(options = {"HIDDEN"})
    pivot_method: bpy.props.EnumProperty(
        name = "Pivot Method",
        description = 'Choose whether to move the bone or its pin',
        items = (
            (
                "DIRECT",
                "Direct",
                "Move the linked bone onto the Surface Contact pin",
            ),
            (
                "INVERSE",
                "Inverse",
                "Move only the active Surface Contact pin onto its connected point",
            ),
        ),
        default = "DIRECT",
    )

    @classmethod
    def poll(cls, context):
        return (
            context.mode == "POSE"
            and bool(_surface_contact_selected_guides(
                context,
                active_only=True,
            ))
        )

    def draw(self, _context):
        self.layout.prop(self, "pivot_method", text = "Method")

    def invoke(self, context, _event):
        self.initial_state_json = _pin_pivot_capture_initial(
            context,
            "CONTACT",
        )
        return self.execute(context)

    def execute(self, context):
        if not self.initial_state_json:
            self.initial_state_json = _pin_pivot_capture_initial(
                context,
                "CONTACT",
            )
        if self.pivot_method == "INVERSE":
            previous_guard = bool(_state.get("surface_contact_reconciling", False))
            _state["surface_contact_reconciling"] = True
            try:
                _pin_pivot_restore_initial(context, self.initial_state_json)
                return _surface_contact_inverse_pivot_active(
                    context, self, self.initial_state_json,
                )
            finally:
                _state["surface_contact_reconciling"] = previous_guard
        _pin_pivot_restore_initial(context, self.initial_state_json)
        return _surface_contact_pivot_selected(context, self)


class ANIMATOR_UTILS_OT_surface_contact_clear(bpy.types.Operator):
    bl_idname = "staticaliza.surface_contact_clear"
    bl_label = "Clear Surface Contact"
    bl_description = 'Remove the selected collision constraints and keep the current pose'
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return bool(_surface_contact_selected_guides(
            context,
            active_only = True,
        ))

    def execute(self, context):
        return _surface_contact_clear_selected(context, self)


def _surface_contact_finish_clear_history():
    try:
        bpy.ops.ed.undo_push(message="Clear Pose Transform")
    except (AttributeError, RuntimeError):
        pass
    return {"FINISHED"}


class ANIMATOR_UTILS_OT_clear_contact_pose_transform(bpy.types.Operator):
    """Atomically clear a pose transform and settle any selected Contact."""

    bl_idname = "staticaliza.clear_contact_pose_transform"
    bl_label = "Clear Pose Transform"
    bl_description = (
        'Reset the selected transforms'
    )
    # Blender does not reliably create a distinct undo checkpoint for an
    # INTERNAL operator dispatched from an add-on Pose keymap, especially
    # when it also edits Action FCurves. The operator pushes one explicit
    # post-commit checkpoint through the module helper instead.
    bl_options = {"REGISTER", "INTERNAL"}

    reset_mode: bpy.props.EnumProperty(
        items = (
            ("LOCATION", "Location", "Clear selected pose-bone locations"),
            ("ROTATION", "Rotation", "Clear selected pose-bone rotations"),
            ("SCALE", "Scale", "Clear selected pose-bone scales"),
        ),
        options = {"HIDDEN", "SKIP_SAVE"},
    )

    @classmethod
    def poll(cls, context):
        return bool(
            getattr(context, "mode", "") == "POSE"
            and (
                _pin_selected_target_key(context, validate=True)
                or int(_state.get("smart_dragger_selected_side", -1))
                in (0, 1)
                or _selected_pose_bones_by_owner(context)
                or _gyro_selected_target(context) is not None
            )
        )

    def execute(self, context):
        if _gyro_reset_selected_target(context, self.reset_mode):
            return _surface_contact_finish_clear_history()
        smart_side = int(_state.get("smart_dragger_selected_side", -1))
        if smart_side in (0, 1):
            # A selected Smart Dragger role owns Alt-G/Alt-R even if Blender's
            # previous virtual pin selection has not been cleared yet.
            selected_key, selected_target = "", None
        else:
            selected_key, selected_target = _pin_selected_target_data(context)
        if selected_key and selected_target is not None:
            kind, armature, pose_bone, payload = selected_target
            if kind == "YELLOW":
                if self.reset_mode == "LOCATION":
                    initial = (
                        pose_bone.get(YELLOW_PIN_INITIAL_TARGET_PROPERTY)
                        if pose_bone is not None else None
                    )
                    if initial is None or len(initial) < 3:
                        return {"CANCELLED"}
                    fixed = dict(_state.get("yellow_fixed", {}))
                    packed = fixed.get(_owner_bone_key(
                        armature, pose_bone.name
                    ))
                    if not packed:
                        return {"CANCELLED"}
                    values = list(packed)
                    values[0] = Vector(tuple(float(v) for v in initial[:3]))
                    fixed[_owner_bone_key(armature, pose_bone.name)] = tuple(
                        values
                    )
                    _state["yellow_fixed"] = fixed
                    _yellow_store_target_property(
                        armature, pose_bone.name, values[0]
                    )
                    context.view_layer.update()
                    _tag_redraw_all_view3d()
                # Onion pins have no independent rotation or scale.
                return (
                    _surface_contact_finish_clear_history()
                    if self.reset_mode == "LOCATION"
                    else {"FINISHED"}
                )
            if kind == "CONTACT" and payload is not None:
                packed = payload.get(
                    SURFACE_CONTACT_INITIAL_GUIDE_MATRIX_PROPERTY
                )
                if packed is None or len(packed) < 16:
                    # Existing pre-reset pins have no recoverable creation
                    # transform. Seed once without moving them; subsequent
                    # resets remain persistent across file reloads.
                    payload[SURFACE_CONTACT_INITIAL_GUIDE_MATRIX_PROPERTY] = (
                        tuple(
                            float(value)
                            for row in payload.matrix_world
                            for value in row
                        )
                    )
                    return _surface_contact_finish_clear_history()
                initial = Matrix((
                    packed[0:4], packed[4:8], packed[8:12], packed[12:16]
                ))
                current_location, current_rotation, current_scale = (
                    payload.matrix_world.decompose()
                )
                initial_location, initial_rotation, initial_scale = (
                    initial.decompose()
                )
                if self.reset_mode == "LOCATION":
                    current_location = initial_location
                elif self.reset_mode == "ROTATION":
                    current_rotation = initial_rotation
                else:
                    current_scale = initial_scale
                payload.matrix_world = Matrix.LocRotScale(
                    current_location, current_rotation, current_scale
                )
                surface = bpy.data.objects.get(str(payload.get(
                    SURFACE_CONTACT_SURFACE_PROPERTY, ""
                )))
                if surface is not None:
                    _surface_contact_bind_guide_surface(
                        context, payload, surface,
                        payload.matrix_world.translation,
                    )
                context.view_layer.update()
                # Resetting a Contact handle is also a request to restore its
                # linked pink limb to that handle. The old path only moved
                # the guide, leaving the limb in its previous pose until a
                # later unrelated update (or never solving it at all).
                previous_solver_guard = bool(
                    _state.get("surface_contact_solver_syncing", False)
                )
                previous_snap_guard = bool(
                    _state.get("pin_snap_syncing", False)
                )
                _state["surface_contact_solver_syncing"] = True
                _state["pin_snap_syncing"] = True
                try:
                    snap_key = _surface_contact_snap_key(payload)
                    _state.setdefault(
                        "pin_snap_pressure_active", set()
                    ).discard(snap_key)
                    _state.setdefault(
                        "pin_snap_pressure_tangents", {}
                    ).pop(snap_key, None)
                    _state.setdefault(
                        "pin_snap_pressure_release_session", set()
                    ).discard(snap_key)
                    _state.setdefault(
                        "pin_snap_pressure_release_origins", {}
                    ).pop(snap_key, None)
                    _state.setdefault(
                        "pin_snap_pressure_release_pose_matrices", {}
                    ).pop(snap_key, None)
                    _state.setdefault(
                        "pin_snap_pressure_release_raw_translations", {}
                    ).pop(snap_key, None)
                    _state.setdefault(
                        "pin_snap_transform_releasing", set()
                    ).discard(snap_key)
                    _surface_contact_clear_snap_departure(payload)
                    _surface_contact_enforce_guide(
                        context,
                        payload,
                        force_contact = True,
                        allow_snap = True,
                        rotate_detached = False,
                        rotate_snap = True,
                    )
                    context.view_layer.update()
                    _surface_contact_seed_runtime_signatures(context, (payload,))
                finally:
                    _state["surface_contact_solver_syncing"] = previous_solver_guard
                    _state["pin_snap_syncing"] = previous_snap_guard
                _tag_redraw_all_view3d()
                return _surface_contact_finish_clear_history()

        if int(_state.get("smart_dragger_selected_side", -1)) in (0, 1):
            smart_data = _smart_dragger_data(context)
            owner = _state.get("smart_dragger_owner")
            armature = bpy.data.objects.get(str(owner[0])) if owner else None
            pose_bone = (
                armature.pose.bones.get(str(owner[1]))
                if armature is not None and owner else None
            )
            packed = (
                pose_bone.get(SMART_DRAGGER_INITIAL_BASIS_PROPERTY)
                if pose_bone is not None else None
            )
            if packed is None or len(packed) < 16:
                return {"CANCELLED"}
            if smart_side == 1 and smart_data is None:
                return {"CANCELLED"}
            if smart_side == 1:
                before_world = armature.matrix_world @ pose_bone.matrix
                inverse = before_world.inverted_safe()
                anchor_local = inverse @ Vector(smart_data["anchor_point"])
                opposite_local = inverse @ Vector(smart_data["points"][1])
            initial = Matrix((
                packed[0:4], packed[4:8], packed[8:12], packed[12:16]
            ))
            location, rotation, scale = pose_bone.matrix_basis.decompose()
            initial_location, initial_rotation, initial_scale = (
                initial.decompose()
            )
            if self.reset_mode == "LOCATION":
                location = initial_location
            elif self.reset_mode == "ROTATION":
                rotation = initial_rotation
            else:
                scale = initial_scale
            pose_bone.matrix_basis = Matrix.LocRotScale(
                location, rotation, scale
            )
            _pin_restore_action_pose_bases(context, _pin_capture_action_pose_bases((armature,)))
            if smart_side == 1:
                _smart_dragger_apply_green_world(context, armature, pose_bone,
                    armature.matrix_world @ pose_bone.matrix, anchor_local, opposite_local,
                    Vector(smart_data["target_point"]), Vector(smart_data["target_normal"]),
                    smart_data["target_key"], hold_attachment=self.reset_mode == "ROTATION")
                if context.scene.tool_settings.use_keyframe_insert_auto:
                    bases = _pin_capture_action_pose_bases((armature,))
                    _insert_bone_keys(pose_bone, context.scene.frame_current)
                    _pin_restore_action_pose_bases(context, bases)
            _state["smart_dragger_cache"] = {}
            _tag_redraw_all_view3d()
            return _surface_contact_finish_clear_history()

        grouped = _selected_pose_bones_by_owner(context)
        if not grouped:
            return {"CANCELLED"}

        gyro_resets = _gyro_reset_capture(context, grouped)
        frame = int(context.scene.frame_current)
        attachment_states = {}
        for guide in _surface_contact_guides():
            if (
                str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
                != SURFACE_CONTACT_KIND_SIMULATED
                or not _surface_contact_guide_active_at(guide, frame)
            ):
                continue
            snap_key = _surface_contact_snap_key(guide)
            animated_detached = _surface_contact_animated_detached_state(
                guide,
                frame,
            )
            runtime_detached = bool(
                snap_key in _state.setdefault("pin_snap_detached", set())
                or guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)
            )
            attachment_states[guide.name] = bool(
                animated_detached is False
                or (
                    animated_detached is None
                    and not runtime_detached
                    and _pin_contact_is_attached(context, guide)
                )
            )

        previous_solver_guard = bool(
            _state.get("surface_contact_solver_syncing", False)
        )
        previous_snap_guard = bool(_state.get("pin_snap_syncing", False))
        _state["surface_contact_solver_syncing"] = True
        _state["pin_snap_syncing"] = True
        try:
            selected_by_armature = {}
            for armature, pose_bones in grouped.items():
                selected_by_armature[armature.name] = {
                    pose_bone.name for pose_bone in pose_bones
                }
                for pose_bone in pose_bones:
                    if self.reset_mode == "LOCATION":
                        pose_bone.location = (0.0, 0.0, 0.0)
                    elif self.reset_mode == "SCALE":
                        pose_bone.scale = (1.0, 1.0, 1.0)
                    elif pose_bone.rotation_mode == "QUATERNION":
                        pose_bone.rotation_quaternion = (1.0, 0.0, 0.0, 0.0)
                    elif pose_bone.rotation_mode == "AXIS_ANGLE":
                        pose_bone.rotation_axis_angle = (0.0, 0.0, 1.0, 0.0)
                    else:
                        pose_bone.rotation_euler = (0.0, 0.0, 0.0)
            if gyro_resets:
                _pin_restore_action_pose_bases(context, _pin_capture_action_pose_bases(grouped))
                _gyro_reset_finish(context, gyro_resets, self.reset_mode)
            else:
                context.view_layer.update()
            affected = []
            for guide in _surface_contact_guides():
                if (
                    str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
                    != SURFACE_CONTACT_KIND_SIMULATED
                    or not _surface_contact_guide_active_at(guide, frame)
                ):
                    continue
                selected_names = selected_by_armature.get(
                    str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
                )
                armature = bpy.data.objects.get(str(guide.get(
                    SURFACE_CONTACT_ARMATURE_PROPERTY,
                    "",
                )))
                if not selected_names or not (
                    _surface_contact_related_bone_names(guide) & selected_names
                    or _surface_contact_selected_bones_drive_guide(
                        armature,
                        guide,
                        selected_names,
                    )
                ):
                    continue
                affected.append(guide)
                snap_key = _surface_contact_snap_key(guide)
                _state.setdefault(
                    "pin_snap_parent_transform_guides", set()
                ).discard(guide.name)
                _state.setdefault(
                    "pin_snap_parent_attachment_states", {}
                ).pop(guide.name, None)
                if attachment_states.get(guide.name, False):
                    _state.setdefault(
                        "pin_snap_pressure_active", set()
                    ).discard(snap_key)
                    _state.setdefault(
                        "pin_snap_pressure_tangents", {}
                    ).pop(snap_key, None)
                    _state.setdefault(
                        "pin_snap_pressure_release_session", set()
                    ).discard(snap_key)
                    _state.setdefault(
                        "pin_snap_pressure_release_origins", {}
                    ).pop(snap_key, None)
                    _state.setdefault(
                        "pin_snap_pressure_release_pose_matrices", {}
                    ).pop(snap_key, None)
                    _state.setdefault(
                        "pin_snap_pressure_release_raw_translations", {}
                    ).pop(snap_key, None)
                    _state.setdefault(
                        "pin_snap_transform_releasing", set()
                    ).discard(snap_key)
                    _surface_contact_set_snap_detached(guide, False)
                    _state.setdefault("pin_snap_latches", set()).add(snap_key)
                else:
                    _surface_contact_set_snap_detached(guide, True)
                    _state.setdefault("pin_snap_latches", set()).discard(
                        snap_key
                    )
                was_attached = attachment_states.get(guide.name, False)
                if was_attached:
                    _surface_contact_enforce_guide(
                        context,
                        guide,
                        # A clear changes pose channels, not Contact mode. An
                        # attached pink limb must return to its fixed socket.
                        force_contact=True,
                        allow_snap=True,
                        rotate_detached=False,
                        rotate_snap=False,
                    )
                else:
                    # Alt-G/Alt-R is a direct pink-limb pose edit. A detached
                    # limb stays detached, but its magnetic orientation and
                    # collision barrier must be recomputed immediately rather
                    # than leaving the reset/rest pose and a stale ring until
                    # the next G/R operation.
                    hard_barriers = _state.setdefault(
                        "pin_snap_hard_barrier_guides", set()
                    )
                    hard_barriers.add(snap_key)
                    try:
                        # A welded Smart support point moves after Blender
                        # evaluates each bone correction. Finish that bounded
                        # evaluated aim now; one pass can leave the limb axis
                        # visibly different from its magnetic guide line.
                        # The strict barrier treats exact surface-parallel
                        # alignment as valid instead of replacing it with a
                        # pressure projection on the final pass.
                        for _correction in range(
                            SURFACE_CONTACT_FINAL_SOLVER_ITERATIONS
                        ):
                            if not _surface_contact_solve_detached_target_motion(
                                context,
                                guide,
                                resolve_collision=True,
                                aim_pose=True,
                            ):
                                break
                    finally:
                        hard_barriers.discard(snap_key)
            context.view_layer.update()
            pose_keyed = False
            reset_data_path = {
                "LOCATION": "location",
                "ROTATION": None,
                "SCALE": "scale",
            }[self.reset_mode]
            for armature, pose_bones in grouped.items():
                for pose_bone in pose_bones:
                    data_path = reset_data_path
                    if data_path is None:
                        if pose_bone.rotation_mode == "QUATERNION":
                            data_path = "rotation_quaternion"
                        elif pose_bone.rotation_mode == "AXIS_ANGLE":
                            data_path = "rotation_axis_angle"
                        else:
                            data_path = "rotation_euler"
                    # Alt-G/R/S is an authored animation edit, independent of
                    # Auto Key and of whether this bone already owns curves.
                    # Key the selected channel before the explicit post-commit
                    # checkpoint so a following native transform has its own
                    # history boundary.
                    pose_keyed = bool(pose_bone.keyframe_insert(
                        data_path=data_path,
                        frame=frame,
                        group=pose_bone.name,
                    )) or pose_keyed
            if affected:
                for guide in affected:
                    armature, pose_bone = _surface_contact_pose_bone(guide)
                    if armature is not None and pose_bone is not None:
                        # Coupled Contact correction belongs to the same Alt
                        # reset transaction. Persist the final solved basis so
                        # Action evaluation cannot replay an older pink pose.
                        _surface_contact_keyframe_simulated_pose(guide, frame)
                        pose_keyed = True
                if pose_keyed:
                    context.view_layer.update()
                _surface_contact_seed_runtime_signatures(context, affected)
                for guide in affected:
                    _surface_contact_store_valid_pose(guide)
                    _surface_contact_store_owner_pose_base(guide)
                    _surface_contact_capture_live_pose(guide)
                _surface_contact_store_persistent_pose_snapshots(affected)
                _tag_redraw_all_view3d()
            elif pose_keyed:
                context.view_layer.update()
            # At Orange Start this same Pink reset owns the complete solve,
            # including detached magnetic aim and collision. Save its final
            # pose before the Orange cache can reassert the previous boundary.
            for armature, pose_bones in grouped.items():
                for pose_bone in pose_bones:
                    if (_ragdoll_active(pose_bone, frame)
                            and _ragdoll_active_start_frame(armature, pose_bone, frame) == frame):
                        _ragdoll_capture_start_edits(context, contact_bone=pose_bone)
            # Alt-G/R/S on a hierarchy driver is also a ragdoll boundary edit.
            # The pose key above is not enough: frame-zero Start states and
            # every later descendant cache still contain the old parent
            # relationship unless the branch is rebased/invalidated now.
            for armature, pose_bones in grouped.items():
                for pose_bone in pose_bones:
                    if not any(
                        _ragdoll_is_ancestor(armature, pose_bone, candidate)
                        for candidate in armature.pose.bones
                        if _ragdoll_active(candidate, frame)
                    ):
                        continue
                    if not _ragdoll_rebase_start_branch(
                        armature, pose_bone, frame
                    ):
                        _ragdoll_schedule_resimulation(
                            armature, pose_bone, frame
                        )
                    _state.setdefault(
                        "ragdoll_driver_preview_signatures", {}
                    )[(armature.name_full, pose_bone.name, frame)] = (
                        _ragdoll_driver_pose_signature(pose_bone, frame)
                    )
            return _surface_contact_finish_clear_history()
        finally:
            _state["surface_contact_solver_syncing"] = previous_solver_guard
            _state["pin_snap_syncing"] = previous_snap_guard
