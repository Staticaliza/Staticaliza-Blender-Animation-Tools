"""Surface-contact viewport drawing and shared contact-point queries."""

from ..core.runtime import *  # noqa: F403

def _capture_gpu_draw_state():
    return (
        gpu.state.depth_test_get(),
        gpu.state.depth_mask_get(),
        gpu.state.blend_get(),
        gpu.state.line_width_get(),
    )


def _restore_gpu_draw_state(state):
    depth_test, depth_mask, blend, line_width = state
    gpu.state.depth_test_set(depth_test)
    gpu.state.depth_mask_set(depth_mask)
    gpu.state.blend_set(blend)
    gpu.state.line_width_set(line_width)


def _surface_contact_bone_anchor_world(
    context,
    guide,
    depsgraph = None,
    live_pose = False,
):
    """Resolve the saved support point from its authoritative pose bone."""
    armature = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
    )
    support_data = guide.get(SURFACE_CONTACT_SUPPORT_PROPERTY)
    geometry_bone_name = str(
        guide.get(
            SURFACE_CONTACT_GEOMETRY_BONE_PROPERTY,
            guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""),
        )
    )
    if armature is None or support_data is None or len(support_data) < 3:
        return None
    try:
        anchor_armature = armature
        if not live_pose:
            depsgraph = depsgraph or context.evaluated_depsgraph_get()
            anchor_armature = armature.evaluated_get(depsgraph)
        anchor_bone = anchor_armature.pose.bones.get(geometry_bone_name)
        if anchor_bone is None:
            return None
        return (
            anchor_armature.matrix_world
            @ anchor_bone.matrix
            @ Vector(tuple(float(value) for value in support_data[:3]))
        )
    except (
        AttributeError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ):
        return None


def _surface_contact_bone_axis_world(
    context,
    guide,
    depsgraph = None,
    live_pose = False,
):
    """Return the opposite pivot and contact end of the thin collision rod."""
    armature = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
    )
    support_data = guide.get(SURFACE_CONTACT_SUPPORT_PROPERTY)
    geometry_bone_name = str(
        guide.get(
            SURFACE_CONTACT_GEOMETRY_BONE_PROPERTY,
            guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""),
        )
    )
    if armature is None or support_data is None or len(support_data) < 3:
        return None
    try:
        axis_armature = armature
        if not live_pose:
            depsgraph = depsgraph or context.evaluated_depsgraph_get()
            axis_armature = armature.evaluated_get(depsgraph)
        axis_bone = axis_armature.pose.bones.get(geometry_bone_name)
        if axis_bone is None:
            return None
        bone_world = axis_armature.matrix_world @ axis_bone.matrix
        length = max(1.0e-8, float(axis_bone.length))
        support_y = float(support_data[1])
        contact_at_start = abs(support_y) <= abs(support_y - length)
        contact_y = 0.0 if contact_at_start else length
        opposite_y = length if contact_at_start else 0.0
        return (
            bone_world @ Vector((0.0, opposite_y, 0.0)),
            bone_world @ Vector((0.0, contact_y, 0.0)),
        )
    except (
        AttributeError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ):
        return None


def _surface_contact_anchor_world(context, guide, depsgraph = None):
    depsgraph = depsgraph or context.evaluated_depsgraph_get()
    # A simulated contact's saved support is bone-local and therefore is the
    # authoritative endpoint. The welded mesh can evaluate one dependency-
    # graph step behind a modal pose edit, which made the limb aim toward a
    # stale point and visibly lean away from its target. During our own G/R/S
    # modal use the just-authored live pose; otherwise use Blender's evaluated
    # pose so playback and scrubbing retain their normal dependency behavior.
    direct_live_transform = bool(
        _state.get("pin_snap_transform_active")
        and _surface_contact_guide_directly_selected(context, guide)
    )
    if (
        str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
        == SURFACE_CONTACT_KIND_SIMULATED
        or direct_live_transform
    ):
        bone_anchor = _surface_contact_bone_anchor_world(
            context,
            guide,
            depsgraph,
            live_pose = bool(
                _state.get("pin_keyboard_transform_active")
                or _state.get("pin_snap_transform_active")
            ),
        )
        if bone_anchor is not None:
            return bone_anchor

    smart_object = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_SMART_OBJECT_PROPERTY, ""))
    )
    smart_local = guide.get(SURFACE_CONTACT_SMART_LOCAL_PROPERTY)
    if smart_object is not None and smart_local is not None and len(smart_local) >= 3:
        try:
            evaluated_object = smart_object.evaluated_get(depsgraph)
            local_point = Vector(
                (
                    float(smart_local[0]),
                    float(smart_local[1]),
                    float(smart_local[2]),
                    1.0,
                )
            )
            current = evaluated_object.matrix_world @ local_point
            return Vector(
                (float(current.x), float(current.y), float(current.z))
            )
        except (
            AttributeError,
            ReferenceError,
            RuntimeError,
            TypeError,
            ValueError,
        ):
            pass

    return _surface_contact_bone_anchor_world(
        context,
        guide,
        depsgraph,
    )


def _surface_contact_opposite_anchor_world(context, guide, depsgraph = None):
    """Return the opposite side of the Smart Pin object's thin collision rod."""
    depsgraph = depsgraph or context.evaluated_depsgraph_get()
    smart_object = bpy.data.objects.get(
        str(guide.get(SURFACE_CONTACT_SMART_OBJECT_PROPERTY, ""))
    )
    smart_local = guide.get(SURFACE_CONTACT_SMART_LOCAL_PROPERTY)
    direct_live_transform = bool(
        _state.get("pin_snap_transform_active")
        and _surface_contact_guide_directly_selected(context, guide)
    )
    if (
        direct_live_transform
        and smart_object is not None
        and smart_local is not None
        and len(smart_local) >= 3
    ):
        try:
            evaluated_object = smart_object.evaluated_get(depsgraph)
            local_point = Vector(
                tuple(float(value) for value in smart_local[:3])
            )
            axis_index = {
                "X_POS": 0,
                "X_NEG": 0,
                "Y_POS": 1,
                "Y_NEG": 1,
                "Z_POS": 2,
                "Z_NEG": 2,
            }.get(
                str(guide.get(SURFACE_CONTACT_CAST_AXIS_PROPERTY, "Y_NEG")),
                1,
            )
            axis_bounds = tuple(
                float(corner[axis_index])
                for corner in evaluated_object.bound_box
            )
            local_point[axis_index] = max(
                (min(axis_bounds), max(axis_bounds)),
                key=lambda value: abs(value - local_point[axis_index]),
            )
            armature = bpy.data.objects.get(str(
                guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, "")
            ))
            geometry_name = str(guide.get(
                SURFACE_CONTACT_GEOMETRY_BONE_PROPERTY,
                guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""),
            ))
            evaluated_armature = armature.evaluated_get(depsgraph)
            live_bone = armature.pose.bones.get(geometry_name)
            evaluated_bone = evaluated_armature.pose.bones.get(geometry_name)
            if live_bone is not None and evaluated_bone is not None:
                live_bone_world = armature.matrix_world @ live_bone.matrix
                evaluated_bone_world = (
                    evaluated_armature.matrix_world @ evaluated_bone.matrix
                )
                object_from_bone = (
                    evaluated_bone_world.inverted_safe()
                    @ evaluated_object.matrix_world
                )
                return live_bone_world @ object_from_bone @ local_point
        except (
            AttributeError,
            ReferenceError,
            RuntimeError,
            TypeError,
            ValueError,
        ):
            pass
    if direct_live_transform:
        # Fallback for contacts without a welded object. A bone-axis endpoint
        # is still preferable to mixing one live and one stale sample.
        axis = _surface_contact_bone_axis_world(
            context,
            guide,
            depsgraph,
            live_pose=True,
        )
        if axis is not None:
            return axis[0]
    if smart_object is None or smart_local is None or len(smart_local) < 3:
        axis = _surface_contact_bone_axis_world(
            context,
            guide,
            depsgraph,
            live_pose = bool(
                _state.get("pin_keyboard_transform_active")
                or _state.get("pin_snap_transform_active")
            ),
        )
        return axis[0] if axis is not None else None
    try:
        evaluated_object = smart_object.evaluated_get(depsgraph)
        local_point = Vector(tuple(float(value) for value in smart_local[:3]))
        axis_index = {
            "X_POS": 0,
            "X_NEG": 0,
            "Y_POS": 1,
            "Y_NEG": 1,
            "Z_POS": 2,
            "Z_NEG": 2,
        }.get(
            str(guide.get(SURFACE_CONTACT_CAST_AXIS_PROPERTY, "Y_NEG")),
            1,
        )
        axis_bounds = tuple(
            float(corner[axis_index])
            for corner in evaluated_object.bound_box
        )
        local_point[axis_index] = max(
            (min(axis_bounds), max(axis_bounds)),
            key=lambda value: abs(value - local_point[axis_index]),
        )
        return evaluated_object.matrix_world @ local_point
    except (
        AttributeError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ):
        return None


def _surface_contact_world_point_normal(context, guide, depsgraph = None):
    target_lock = _state.get("pin_snap_contact_target_locks", {}).get(
        getattr(guide, "name", "")
    )
    if target_lock is not None:
        # A pose-bone transform may update the guide's evaluated parent before
        # Blender reports that the modal transform has started. The contact
        # target itself is not part of a bone-only G/R/S operation, so every
        # live solver pass must read the same pre-transform world matrix.
        guide_world = target_lock["matrix_world"].copy()
    else:
        depsgraph = depsgraph or context.evaluated_depsgraph_get()
        try:
            evaluated_guide = guide.evaluated_get(depsgraph)
            guide_world = evaluated_guide.matrix_world.copy()
        except (AttributeError, ReferenceError, RuntimeError):
            guide_world = guide.matrix_world.copy()
    point = guide_world.translation.copy()
    normal = guide_world.to_3x3().col[2]
    if normal.length_squared <= 1.0e-12:
        normal = Vector((0.0, 0.0, 1.0))
    else:
        normal.normalize()
    anchor = _surface_contact_anchor_world(context, guide, depsgraph)
    if anchor is None:
        anchor = guide_world.translation.copy()
    return point, normal, anchor


def _draw_surface_contact_guides(
    context,
    guides = None,
    draw_lines = True,
    draw_endpoints = True,
    draw_targets = True,
    draw_target_dots = True,
    draw_snap_rings = True,
):
    region = getattr(context, "region", None)
    rv3d = getattr(context, "region_data", None)
    if region is None or rv3d is None:
        return

    frame = int(context.scene.frame_current)
    line_positions = []
    overlap_line_positions = []
    endpoint_dot_positions = []
    target_dot_positions = []
    snap_rings = []
    circle_base = PIN_DOT_PIXEL_RADIUS
    depsgraph = context.evaluated_depsgraph_get()
    evaluated_armatures = {}
    pose_scope_names = {
        armature.name for armature in _pose_scope_armatures(context)
    }
    for guide in tuple(
        guides if guides is not None else _surface_contact_guides()
    ):
        guide_armature_name = str(
            guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, "")
        )
        if (
            guide_armature_name not in pose_scope_names
            or not _surface_contact_guide_interval_active_at(guide, frame)
        ):
            continue
        point, _normal, anchor = _surface_contact_world_point_normal(
            context,
            guide,
            depsgraph,
        )
        # Render against the same evaluated pose as Blender's visible bone.
        # The solver's live RNA pose may be one evaluation ahead during G/R/S.
        drawn_anchor = _surface_contact_bone_anchor_world(
            context, guide, depsgraph, live_pose=False,
        )
        if drawn_anchor is not None:
            anchor = drawn_anchor
        if point is None or anchor is None:
            continue

        line_segment, fixed, current = _project_world_segment_2d(
            context,
            point,
            anchor,
        )
        if line_segment is None and fixed is None and current is None:
            continue
        distance_world = (Vector(point) - Vector(anchor)).length
        snapped = _pin_snap_ring_visible(
            _surface_contact_snap_key(guide),
            point,
            anchor,
        )
        current_radius = (
            circle_base
            if snapped
            else circle_base * _circle_scale_from_dist(distance_world)
        )
        onion_fixed = None
        onion_current = None
        bone_name = str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
        guide_armature = bpy.data.objects.get(guide_armature_name)
        owner_uid = _armature_session_uid(guide_armature)
        packed = _state["yellow_fixed"].get((owner_uid, bone_name))
        evaluated_armature = evaluated_armatures.get(owner_uid)
        if evaluated_armature is None and guide_armature is not None:
            evaluated_armature = guide_armature.evaluated_get(depsgraph)
            evaluated_armatures[owner_uid] = evaluated_armature
        if (
            packed
            and len(packed) >= 2
            and guide_armature is not None
            and evaluated_armature is not None
        ):
            onion_bone = evaluated_armature.pose.bones.get(bone_name)
            if onion_bone is not None:
                onion_fixed = Vector(packed[0])
                onion_current = _yellow_current_world_point(
                    depsgraph,
                    evaluated_armature,
                    onion_bone,
                    packed,
                )

        fixed_overlap = bool(
            onion_fixed is not None and (point - onion_fixed).length <= 0.025
        )
        current_overlap = bool(
            onion_current is not None and (anchor - onion_current).length <= 0.025
        )
        target_lines = (
            overlap_line_positions
            if fixed_overlap and current_overlap
            else line_positions
        )
        if line_segment is not None:
            target_lines.extend(line_segment)
        if draw_targets and draw_target_dots and fixed is not None:
            target_dot_positions.extend(_circle_tris_2d(fixed, circle_base))
        if draw_endpoints and current is not None:
            endpoint_dot_positions.extend(
                _circle_tris_2d(current, current_radius)
            )
        if draw_targets and draw_snap_rings and snapped and fixed is not None:
            snap_rings.extend(
                _circle_lines_2d(fixed, PIN_SNAP_RING_PIXEL_RADIUS)
            )

    if not (
        line_positions
        or overlap_line_positions
        or endpoint_dot_positions
        or target_dot_positions
        or snap_rings
    ):
        return

    shader = _ensure_shader_2d()
    shader.bind()
    shader.uniform_float(
        "u_viewport",
        (float(region.width), float(region.height)),
    )
    shader.uniform_float("color", SURFACE_CONTACT_HOT_PINK)
    if draw_lines and line_positions:
        batch_for_shader(
            shader,
            "LINES",
            {"pos": line_positions},
        ).draw(shader)
    if draw_lines and overlap_line_positions:
        shader.uniform_float("color", SURFACE_CONTACT_OVERLAP_COLOR)
        batch_for_shader(
            shader,
            "LINES",
            {"pos": overlap_line_positions},
        ).draw(shader)
        shader.uniform_float("color", SURFACE_CONTACT_HOT_PINK)
    if endpoint_dot_positions:
        batch_for_shader(
            shader,
            "TRIS",
            {"pos": endpoint_dot_positions},
        ).draw(shader)
    if target_dot_positions:
        batch_for_shader(
            shader,
            "TRIS",
            {"pos": target_dot_positions},
        ).draw(shader)
    if snap_rings:
        gpu.state.line_width_set(1.25)
        shader.uniform_float("color", SURFACE_CONTACT_HOT_PINK)
        batch_for_shader(
            shader,
            "LINES",
            {"pos": snap_rings},
        ).draw(shader)
    if snap_rings:
        gpu.state.line_width_set(4.0)
