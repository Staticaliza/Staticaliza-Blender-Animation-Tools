"""Attachment indicators remain visible when a virtual pin owns selection."""

from ..core.runtime import *  # noqa: F403


def _selected_pin_attachment_points(context):
    depsgraph = context.evaluated_depsgraph_get()
    for _key, (kind, armature, bone, payload) in _pin_selected_targets_data(context):
        if kind == "CONTACT":
            if not _surface_contact_guide_active_at(payload, context.scene.frame_current):
                continue
            point = _surface_contact_bone_anchor_world(context, payload, depsgraph, live_pose=False)
            target = payload.matrix_world.translation
            color = SURFACE_CONTACT_HOT_PINK
        elif kind == "GYRO":
            if not _gyro_active(context, payload):
                continue
            point, target, color = _gyro_anchor(context, payload), payload.location, GYRO_COLOR
        else:
            evaluated = armature.evaluated_get(depsgraph)
            point = _yellow_current_world_point(depsgraph, evaluated, evaluated.pose.bones[bone.name], payload)
            target = Vector(payload[0])
            color = ONION_PIN_COLOR
        if point is not None:
            yield Vector(point), Vector(target), color


def _draw_selected_pin_attachment_dots(context):
    if _pin_animation_hidden(context):
        return
    region, view = getattr(context, "region", None), getattr(context, "region_data", None)
    if region is None or view is None:
        return
    from bpy_extras import view3d_utils
    for anchor, target, color in _selected_pin_attachment_points(context):
        if not _pin_gizmo_center_in_front(context, anchor):
            continue
        projected = view3d_utils.location_3d_to_region_2d(region, view, anchor)
        target_projected = view3d_utils.location_3d_to_region_2d(region, view, target)
        if projected is None or (target_projected is not None
                and (projected-target_projected).length < PIN_DOT_PIXEL_RADIUS):
            # The diamond already covers coincident endpoints.
            continue
        shader = _ensure_shader_2d()
        shader.bind()
        shader.uniform_float("u_viewport", (float(region.width), float(region.height)))
        shader.uniform_float("color", color)
        batch_for_shader(shader, "TRIS", {"pos": _circle_tris_2d(projected, PIN_DOT_PIXEL_RADIUS)}).draw(shader)
