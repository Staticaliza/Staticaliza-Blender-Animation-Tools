"""Bone/object pivot selection and transform-orientation controls."""

from ..core.runtime import *  # noqa: F403
def _part_pivot_selected_bone(context):
    selected = _selected_pose_bones_only(context)
    active_bone = context.active_pose_bone
    if active_bone not in selected:
        active_bone = selected[0] if selected else None
    if active_bone is None:
        # A virtual pin owns an active bone even though its normal-click
        # selection intentionally leaves every Pose selection flag clear.
        # Keep Object-pivot matching alive for that pin-only state.
        try:
            _pin_key, pin_target = _pin_selected_target_data(context)
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            pin_target = None
        if pin_target is not None:
            active_bone = pin_target[2]
    return active_bone


def _part_pivot_connected_object(
    context,
    armature,
    eval_armature,
    objects,
    pose_bone,
    include_hidden = False,
):
    canonical_name = _strip_blender_numeric_suffix(pose_bone.name)
    candidates = {}

    family_levels = list(
        _pose_bone_numeric_family_levels(eval_armature, pose_bone)
    )
    numbered_names = set().union(*family_levels)
    family_names = _surface_contact_bone_family_names(
        eval_armature,
        pose_bone,
    )
    weld_names = family_names - numbered_names
    if weld_names:
        family_levels.append(weld_names)

    target_objects = set(objects or ())
    target_objects.update(_surface_contact_rig_objects(armature))
    parts_collection = _find_roblox_parts_collection(armature)
    if parts_collection is not None:
        target_objects.update(parts_collection.all_objects)
    connected_objects = set(
        _surface_contact_connected_objects(
            context,
            armature,
            family_names,
        )
    )
    target_objects.update(connected_objects)
    search_objects = tuple(
        obj
        for obj in context.view_layer.objects
        if obj in target_objects and obj != armature
    )

    for level_index, level_names in enumerate(family_levels):
        for obj in search_objects:
            if (
                obj.type != "MESH"
                or (
                    not include_hidden
                    and not _is_object_visible(obj, context)
                )
            ):
                continue

            exact_name = obj.name == canonical_name
            matching_name = _strip_blender_numeric_suffix(obj.name) == canonical_name
            object_bone_names = _surface_contact_object_bone_names(
                obj,
                armature,
            )
            directly_connected = bool(object_bone_names & level_names)
            family_connected = bool(object_bone_names & family_names)
            belongs_to_family = (
                directly_connected
                or family_connected
                or obj in connected_objects
            )
            if not (exact_name or matching_name or directly_connected):
                continue
            if not belongs_to_family and obj not in target_objects:
                continue

            score = (
                0
                if directly_connected
                else 1
                if family_connected or obj in connected_objects
                else 2,
                0 if exact_name else 1 if matching_name else 2,
                level_index,
                1 if _object_has_linked_base_color(obj) else 0,
                obj.name.casefold(),
            )
            previous = candidates.get(obj.name)
            if previous is None or score < previous[0]:
                candidates[obj.name] = (score, obj)

    if not candidates:
        return None
    return min(candidates.values(), key = lambda item: item[0])[1]


def _part_pivot_object_local_center(evaluated_part):
    local_bounds = None
    for corner in evaluated_part.bound_box:
        point = Vector(corner)
        if local_bounds is None:
            local_bounds = _bounds_init(point)
        else:
            _bounds_add(local_bounds, point)
    if local_bounds is None:
        return None
    return Vector((
        (float(local_bounds[0]) + float(local_bounds[3])) * 0.5,
        (float(local_bounds[1]) + float(local_bounds[4])) * 0.5,
        (float(local_bounds[2]) + float(local_bounds[5])) * 0.5,
        1.0,
    ))


def _part_pivot_bone_object_target(context, armature, pose_bone):
    """Resolve only this bone's welded object, never another family fallback."""
    if armature is None or pose_bone is None:
        return None
    depsgraph = context.evaluated_depsgraph_get()
    eval_armature = armature.evaluated_get(depsgraph)
    eval_pose_bone = eval_armature.pose.bones.get(pose_bone.name)
    if eval_pose_bone is None:
        return None
    objects, _target_armature = _targets(context, armature)
    part = _part_pivot_connected_object(
        context,
        armature,
        eval_armature,
        objects,
        eval_pose_bone,
    )
    if part is None:
        return None
    local_center = _part_pivot_object_local_center(
        part.evaluated_get(depsgraph)
    )
    if local_center is None:
        return None
    return part, local_center


def _part_pivot_bone_object_world_center(context, armature, pose_bone):
    target = _part_pivot_bone_object_target(context, armature, pose_bone)
    if target is None:
        return None
    part, local_center = target
    evaluated_part = part.evaluated_get(context.evaluated_depsgraph_get())
    return Vector((evaluated_part.matrix_world @ _as_p4(local_center))[:3])


def _part_pivot_selection_targets(context):
    """Return every explicitly selected bone, including virtual pin owners."""
    candidates = []
    for armature, pose_bones in _selected_pose_bones_by_owner(context).items():
        candidates.extend((armature, pose_bone) for pose_bone in pose_bones)
    try:
        candidates.extend(
            (target_data[1], target_data[2])
            for _key, target_data in _pin_selected_targets_data(context)
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        pass
    active_bone = (
        _part_pivot_selected_bone(context)
        if context.mode == "POSE"
        else None
    )
    active_armature = _pose_bone_owner(context, active_bone)
    if active_armature is not None and active_bone is not None:
        candidates.insert(0, (active_armature, active_bone))
    seen = set()
    ordered = []
    for armature, pose_bone in candidates:
        if armature is None or pose_bone is None:
            continue
        key = _owner_bone_key(armature, pose_bone.name)
        if key in seen:
            continue
        seen.add(key)
        ordered.append((armature, pose_bone))
    return tuple(ordered)


def _part_pivot_selection_signature(context):
    return tuple(
        _owner_bone_key(armature, pose_bone.name)
        for armature, pose_bone in _part_pivot_selection_targets(context)
    )


def _part_pivot_target(context):
    if context.mode != "POSE":
        return None

    matches = []
    seen_objects = set()
    for armature, pose_bone in _part_pivot_selection_targets(context):
        target = _part_pivot_bone_object_target(
            context,
            armature,
            pose_bone,
        )
        if target is not None:
            part, local_center = target
            if part.name in seen_objects:
                continue
            seen_objects.add(part.name)
            matches.append(
                (armature, pose_bone, part, local_center.copy())
            )
    if not matches:
        return None
    armature, active_bone, part, local_center = matches[0]
    object_targets = tuple(
        (matched_part.name, matched_center.copy())
        for _owner, _bone, matched_part, matched_center in matches
    )
    return (
        int(armature.as_pointer()),
        active_bone.name,
        part.name,
        local_center,
        object_targets,
    )


def _view3d_spaces(context):
    window_manager = getattr(context, "window_manager", None)
    for window in getattr(window_manager, "windows", ()) if window_manager else ():
        screen = getattr(window, "screen", None)
        for area in getattr(screen, "areas", ()) if screen else ():
            if area.type != "VIEW_3D":
                continue
            for space in area.spaces:
                if space.type == "VIEW_3D":
                    yield space


def _hide_part_pivot_cursor(context):
    visibility = _state.setdefault("part_pivot_cursor_visibility", {})
    for space in _view3d_spaces(context):
        pointer = int(space.as_pointer())
        if pointer not in visibility:
            visibility[pointer] = bool(space.overlay.show_cursor)
        if space.overlay.show_cursor:
            space.overlay.show_cursor = False


def _restore_part_pivot_cursor(context):
    visibility = _state.get("part_pivot_cursor_visibility", {})
    for space in _view3d_spaces(context):
        pointer = int(space.as_pointer())
        if pointer in visibility:
            space.overlay.show_cursor = bool(visibility[pointer])
    _state["part_pivot_cursor_visibility"] = {}


def _part_pivot_native_mode(context):
    saved = _state.get("part_pivot_saved") or {}
    point = saved.get("pivot_point", "")
    if not point:
        point = context.scene.tool_settings.transform_pivot_point
    if not point or point == "CURSOR":
        point = context.scene.get("_staticaliza_object_pivot_native", "MEDIAN_POINT")
    return point if point in {"MEDIAN_POINT", "ACTIVE_ELEMENT", "INDIVIDUAL_ORIGINS", "BOUNDING_BOX_CENTER"} else "MEDIAN_POINT"


def _part_pivot_native_fallback(context):
    point = _part_pivot_native_mode(context)
    if context.scene.tool_settings.transform_pivot_point != point:
        context.scene.tool_settings.transform_pivot_point = point
    slot = context.scene.transform_orientation_slots[0]
    if (slot.type == "CURSOR" and
            getattr(context.window_manager, "staticaliza_pivot_mode", "BONE") != "PART"):
        slot.type = "LOCAL"


def _part_pivot_transform_complete(context):
    """Recognize an observed native transform after all pose owners commit."""
    return bool(
        _state.get("part_pivot_transform_token")
        and _state.get("part_pivot_transform_selection") == _part_pivot_selection_signature(context)
        and not _pin_active_transform_operator(context)
        and not _window_manager_has_modal_operator(context)
        and not any(_state.get(key) for key in (
            "pin_snap_transform_active", "pin_keyboard_transform_active", "pin_target_dragging",
            "surface_contact_reconciling", "ragdoll_syncing", "ragdoll_native_evaluating",
            "ragdoll_frame_publication", "constraint_creation_transaction"))
    )


def _sync_part_pivot(context, rematch = False, depsgraph=None):
    window_manager = getattr(context, "window_manager", None)
    if window_manager is None:
        return False
    if getattr(window_manager, "staticaliza_pivot_mode", "BONE") != "PART":
        return False
    if _state.get('constraint_creation_transaction'):
        # Mode conversion has intermediate constraint/selection states. Keep
        # the last committed mesh pivot until its replacement is complete.
        return bool(_state.get('part_pivot_objects'))
    if not rematch and (_pin_active_transform_operator(context) or (
            _pin_primary_mouse_pressed() and not _part_pivot_transform_complete(context))):
        # Never invalidate Blender's native gizmo hit map during a press or
        # rewrite its captured center during a transform.
        return bool(_state.get("part_pivot_objects"))
    if _state.get("part_pivot_syncing", False):
        return True

    _state["part_pivot_syncing"] = True
    try:
        active_bone = _part_pivot_selected_bone(context) if context.mode == "POSE" else None
        armature = (
            _pose_bone_owner(context, active_bone) or _active_armature(context)
            if active_bone is not None
            else _active_armature(context)
        )
        armature_pointer = int(armature.as_pointer()) if armature else 0
        bone_name = active_bone.name if active_bone else ""
        selection_signature = _part_pivot_selection_signature(context)
        if (active_bone is None and context.mode == 'POSE'
                and _state.get('part_pivot_objects')
                and all(bpy.data.objects.get(name) is not None for name,_ in _state['part_pivot_objects'])):
            # Creation/conversion temporarily clears native selection while
            # transferring ownership to its pin. Retain the last mesh frame;
            # the next real selection rematches it without a fallback flash.
            return True
        if (
            rematch
            or armature_pointer != _state.get("part_pivot_armature", 0)
            or bone_name != _state.get("part_pivot_bone", "")
            or selection_signature
            != _state.get("part_pivot_selection_signature", ())
            or not _state.get("part_pivot_object", "")
        ):
            _state["part_pivot_armature"] = armature_pointer
            _state["part_pivot_bone"] = bone_name
            _state["part_pivot_object"] = ""
            _state["part_pivot_object_local"] = None
            _state["part_pivot_objects"] = ()
            _state["part_pivot_selection_signature"] = selection_signature
            _state["part_pivot_last_signature"] = None
            target = _part_pivot_target(context)
            if target is None:
                _part_pivot_native_fallback(context)
                return False
            (
                armature_pointer,
                bone_name,
                object_name,
                local_center,
                object_targets,
            ) = target
            _state["part_pivot_armature"] = armature_pointer
            _state["part_pivot_bone"] = bone_name
            _state["part_pivot_object"] = object_name
            _state["part_pivot_object_local"] = local_center.copy()
            _state["part_pivot_objects"] = object_targets
            _state["part_pivot_last_signature"] = None
            _state["part_pivot_last_armature"] = armature_pointer
            _state["part_pivot_last_bone"] = bone_name

        object_targets = tuple(_state.get("part_pivot_objects", ()))
        if not object_targets:
            return False

        depsgraph = depsgraph if depsgraph is not None else context.evaluated_depsgraph_get()
        published = _state.get('ragdoll_published_poses', {})
        if published:
            for owner, bone in _part_pivot_selection_targets(context):
                visited = set()
                while bone is not None and bone.name not in visited:
                    visited.add(bone.name)
                    pose = published.get(_ragdoll_state_key(owner, bone))
                    if (pose is not None and pose[0] == context.scene.frame_current
                            and _ragdoll_active(bone, context.scene.frame_current)):
                        evaluated_bone = owner.evaluated_get(depsgraph).pose.bones.get(bone.name)
                        if evaluated_bone is None or max(
                                abs(evaluated_bone.matrix[r][j] - pose[1][r][j])
                                for r in range(4) for j in range(4)) > 1.e-4:
                            # Native Action evaluation can expose its input
                            # pose after creation/redo but before Orange's
                            # final dependency publication. That mesh frame
                            # cannot own the cursor, even outside the operator.
                            _schedule_transform_gizmo_refresh()
                            return bool(object_targets)
                        break
                    relation=_chosen_dynamic_parent_constraint(bone,context.scene.frame_current)
                    if relation is not None and _dynamic_space_role(bone,relation) in {
                            SPACE_ROLE_UNPARENT,SPACE_ROLE_WORLD}:
                        # A released limb no longer depends on its old torso's
                        # evaluation. Do not hold its independent cursor for it.
                        break
                    bone = _ragdoll_parent(owner, bone)
        evaluated_targets = []
        for object_name, target_center in object_targets:
            target_part = bpy.data.objects.get(str(object_name))
            if target_part is None:
                continue
            evaluated = target_part.evaluated_get(depsgraph)
            center = _part_pivot_object_local_center(evaluated)
            evaluated_targets.append((evaluated, center if center is not None else target_center))
        if not evaluated_targets:
            _part_pivot_native_fallback(context)
            return False
        part = evaluated_targets[0][0]
        eval_part = part.evaluated_get(depsgraph)
        matrix_signature = tuple(
            (
                evaluated_part.name,
                tuple(
                    float(value)
                    for row in evaluated_part.matrix_world
                    for value in row
                ),
            )
            for evaluated_part, _center in evaluated_targets
        )
        signature = (
            armature_pointer,
            bone_name,
            selection_signature,
            matrix_signature,
        )
        _hide_part_pivot_cursor(context)
        world_points = tuple(
            Vector((
                evaluated_part.matrix_world @ _as_p4(target_center)
            )[:3])
            for evaluated_part, target_center in evaluated_targets
        )
        world_location = (
            sum(world_points, Vector((0.0, 0.0, 0.0)))
            / len(world_points)
        )
        world_rotation = eval_part.matrix_world.to_quaternion().normalized()
        cursor = context.scene.cursor
        same_location = (cursor.location - world_location).length_squared <= 1.0e-12
        same_rotation = (
            cursor.rotation_mode == "QUATERNION"
            and min(sum((cursor.rotation_quaternion[i]-world_rotation[i])**2 for i in range(4)),
                    sum((cursor.rotation_quaternion[i]+world_rotation[i])**2 for i in range(4))) <= 1.0e-12
        )
        if context.scene.tool_settings.transform_pivot_point != "CURSOR":
            context.scene.tool_settings.transform_pivot_point = "CURSOR"
        slot = context.scene.transform_orientation_slots[0]
        if slot.type == "LOCAL":
            slot.type = "CURSOR"
        _state["part_pivot_last_signature"] = signature
        if same_location and same_rotation:
            return True

        if not same_location:
            cursor.location = world_location
        if not same_rotation:
            if cursor.rotation_mode != "QUATERNION":
                cursor.rotation_mode = "QUATERNION"
            cursor.rotation_quaternion = world_rotation
        # Native transform groups subscribe to cursor changes through Blender's
        # message bus. Publish Python-driven cursor changes as well, so their
        # selection geometry is refreshed along with the visible object pivot.
        # Blender's native transform group subscribes to this cursor instance,
        # with no individual property. A type-only publication does not notify
        # instance subscriptions, leaving its drawn center/hit map stale.
        bpy.msgbus.publish_rna(key=cursor)
        return True
    finally:
        _state["part_pivot_syncing"] = False


def _disable_part_pivot(context):
    _restore_part_pivot_cursor(context)
    _part_pivot_native_fallback(context)
    saved = _state.get("part_pivot_saved")
    if saved is not None:
        cursor = context.scene.cursor
        cursor.location = saved["cursor_location"]
        cursor.rotation_mode = "QUATERNION"
        cursor.rotation_quaternion = saved["cursor_rotation"]
        cursor.rotation_mode = saved["cursor_rotation_mode"]

    slot = context.scene.transform_orientation_slots[0]
    if slot.type == "CURSOR":
        slot.type = "LOCAL"

    window_manager = getattr(context, "window_manager", None)
    if window_manager is not None:
        window_manager.staticaliza_pivot_mode = "BONE"
    _state["part_pivot_bone"] = ""
    _state["part_pivot_armature"] = 0
    _state["part_pivot_object"] = ""
    _state["part_pivot_object_local"] = None
    _state["part_pivot_objects"] = ()
    _state["part_pivot_selection_signature"] = ()
    _state["part_pivot_saved"] = None
    _state["part_pivot_last_signature"] = None
    _state["transform_gizmo_refresh_pending"] = False
    _state.pop("part_pivot_transform_token", None)
    _state.pop("part_pivot_transform_selection", None)
    _tag_redraw_all_view3d()


def _finish_transform_gizmo_refresh(context, *, update_view_layer=False, depsgraph=None):
    window_manager = getattr(context, "window_manager", None)
    if window_manager is None:
        _state["transform_gizmo_refresh_pending"] = False
        _state.pop("part_pivot_transform_token", None)
        _state.pop("part_pivot_transform_selection", None)
        _state.setdefault("owned_timers", set()).discard(
            _transform_gizmo_refresh_timer
        )
        return False
    _state["transform_gizmo_refresh_pending"] = False
    try:
        if update_view_layer:
            context.view_layer.update()
        if (
            getattr(window_manager, "staticaliza_pivot_mode", "BONE")
            == "PART"
        ):
            _sync_part_pivot(context, depsgraph=depsgraph or context.view_layer.depsgraph)
        # Bone pivot uses Blender's native center, while Smart Draggers and
        # other extension gizmos use evaluated matrices. Invalidate their
        # cached geometry in the same post-modal event-loop turn.
        _state["smart_dragger_cache"] = {}
        # Refresh native transform bounds after procedural pose publication.
        bpy.msgbus.publish_rna(key=context.scene.tool_settings.path_resolve(
            "transform_pivot_point", False))
        _tag_redraw_all_view3d()
    except (
        AttributeError,
        ReferenceError,
        RuntimeError,
        TypeError,
        ValueError,
    ):
        pass
    finally:
        if (not _state.get("transform_gizmo_refresh_pending", False)
                and not (_pin_primary_mouse_pressed() and _part_pivot_transform_complete(context))):
            _state.pop("part_pivot_transform_token", None)
            _state.pop("part_pivot_transform_selection", None)
            _state.setdefault("owned_timers", set()).discard(
                _transform_gizmo_refresh_timer
            )
    return True


def _transform_gizmo_refresh_timer():
    context = bpy.context
    if not _state.get("transform_gizmo_refresh_pending", False):
        if _state.get("part_pivot_transform_token"):
            if _pin_primary_mouse_pressed() and _part_pivot_transform_complete(context):
                # Keep ownership of this confirmation press through late graph
                # echoes. No polling solve, redraw or message publication.
                return 0.005
            _state.pop("part_pivot_transform_token", None)
            _state.pop("part_pivot_transform_selection", None)
        _state.setdefault("owned_timers", set()).discard(_transform_gizmo_refresh_timer)
        return None
    if (
        (_pin_primary_mouse_pressed() and not _part_pivot_transform_complete(context))
        or _window_manager_has_modal_operator(context)
        or _pin_active_transform_operator(context)
        or _state.get("pin_snap_transform_active", False)
        or _state.get("pin_keyboard_transform_active", False)
        or _state.get("pin_target_dragging", False)
    ):
        return 0.005
    # The native event has already committed its dependency graph. Forcing
    # another evaluation here re-enters physics and constraint handlers before
    # Blender can draw the released handle.
    _finish_transform_gizmo_refresh(context)
    # A still-incoming evaluated mesh can request another refresh from inside
    # _sync_part_pivot. The executing timer is already registered, so retain
    # that request instead of returning None and dropping its only wakeup.
    return 0.005 if (_state.get("transform_gizmo_refresh_pending", False)
                     or _state.get("part_pivot_transform_token")) else None


def _schedule_transform_gizmo_refresh():
    _state["transform_gizmo_refresh_pending"] = True
    try:
        if bpy.app.timers.is_registered(
            _transform_gizmo_refresh_timer
        ):
            return
        register_owned_timer(
            _transform_gizmo_refresh_timer,
            first_interval = 0.0,
        )
    except (RuntimeError, ValueError):
        _state["transform_gizmo_refresh_pending"] = False


@persistent
def _part_pivot_depsgraph_update(_scene, _depsgraph):
    if _scene.get('_staticaliza_physics_scratch', False):
        return
    context = bpy.context
    window_manager = getattr(context, "window_manager", None)
    if window_manager is None:
        return
    if getattr(window_manager, "staticaliza_pivot_mode", "BONE") != "PART":
        # Native bone selection, pivot calculation and hit testing own this mode.
        return
    native_transform = bool(_pin_active_transform_operator(context))
    if native_transform:
        # Keep a math-only identity through confirmation. The physical LMB can
        # remain down after Blender has removed the completed G/R/S operator.
        token = _pin_transform_operator_token(context)
        if token != _state.get("part_pivot_transform_token"):
            _state["part_pivot_transform_token"] = token
            _state["part_pivot_transform_selection"] = _part_pivot_selection_signature(context)
    if (_state.get("ragdoll_syncing") or _state.get("ragdoll_native_evaluating")
            or _state.get("ragdoll_frame_publication")):
        # A frame callback has written the solved bones, but their connected
        # mesh evaluations can still belong to the incoming Action pose. Read
        # them only after the outer dependency transaction has completed.
        _schedule_transform_gizmo_refresh()
        return
    pending = bool(_state.get("transform_gizmo_refresh_pending", False))
    if native_transform or (_pin_primary_mouse_pressed() and not pending
                            and not _part_pivot_transform_complete(context)):
        _schedule_transform_gizmo_refresh()
        return
    if pending:
        if (
            (_pin_primary_mouse_pressed() and not _part_pivot_transform_complete(context))
            or _window_manager_has_modal_operator(context)
            or _state.get("pin_snap_transform_active", False)
            or _state.get("pin_keyboard_transform_active", False)
            or _state.get("pin_target_dragging", False)
        ):
            return
        # depsgraph_update_post already observes Blender's committed pose.
        # Finish synchronously here so Bone-mode G/R/S never displays the
        # previous gizmo center for one timer/redraw tick.
        _finish_transform_gizmo_refresh(
            context,
            update_view_layer=False,
            depsgraph=_depsgraph,
        )
        return
    if (
        getattr(window_manager, "staticaliza_pivot_mode", "BONE")
        == "PART"
    ):
        _sync_part_pivot(context, depsgraph=_depsgraph)


@persistent
def _part_pivot_frame_change_post(_scene, _depsgraph):
    _part_pivot_depsgraph_update(_scene, _depsgraph)


def _part_pivot_selection_timer():
    context = bpy.context
    window_manager = getattr(context, "window_manager", None)
    if (
        window_manager is None
        or getattr(window_manager, "staticaliza_pivot_mode", "BONE") != "PART"
    ):
        return 0.2
    if (
        _pin_primary_mouse_pressed()
        or _window_manager_has_modal_operator(context)
    ):
        return 0.05

    active_bone = _part_pivot_selected_bone(context) if context.mode == "POSE" else None
    armature = (
        _pose_bone_owner(context, active_bone) or _active_armature(context)
        if active_bone is not None
        else _active_armature(context)
    )
    armature_pointer = int(armature.as_pointer()) if armature else 0
    bone_name = active_bone.name if active_bone else ""
    selection_signature = _part_pivot_selection_signature(context)
    changed = (
        armature_pointer != _state.get("part_pivot_armature", 0)
        or bone_name != _state.get("part_pivot_bone", "")
        or selection_signature
        != _state.get("part_pivot_selection_signature", ())
    )
    if changed:
        if active_bone is None:
            _state["part_pivot_armature"] = armature_pointer
            _state["part_pivot_bone"] = ""
            _state["part_pivot_object"] = ""
            _state["part_pivot_object_local"] = None
            _state["part_pivot_objects"] = ()
            _state["part_pivot_selection_signature"] = ()
            _state["part_pivot_last_signature"] = None
        else:
            _sync_part_pivot(context, rematch = True)
        _tag_redraw_all_view3d()
    elif not _pin_animation_hidden(context):
        # A procedural pose can finish after its frame/dependency callback.
        # Re-read the completed mesh without rewriting an unchanged cursor.
        _sync_part_pivot(context)
    return 0.05


def _bone_label_selection_timer():
    context = bpy.context
    window_manager = getattr(context, "window_manager", None)
    if window_manager is None:
        return 0.1
    if (
        _state.get("pin_history_active", False)
        or _state.get("pin_history_syncing", False)
        or _state.get("pin_history_direction", "")
    ):
        return 0.05
    if getattr(context, "mode", "") == "POSE":
        _track_dynamic_parent_selection_order(context)
    if _pin_primary_mouse_pressed():
        # Native gizmo transforms begin while LMB is held. Capture Dynamic
        # Parent/Unparent baselines as soon as Blender exposes that modal so
        # confirmation commits the same world pose shown by live preview.
        if _pin_active_transform_operator(context):
            if _dynamic_parent_commit_active_transform_sample(context):
                _tag_redraw_all_view3d()
        return 0.05
    if _window_manager_has_modal_operator(context):
        # Dynamic Parent's dual-selection lock is the only maintenance that
        # must follow an established transform modal. It does not run in the
        # physical press gap above.
        if _dynamic_parent_commit_active_transform_sample(context):
            _tag_redraw_all_view3d()
        return 0.05

    _sync_animation_editors_pose_mode(context)

    panel_armatures = _pose_panel_armatures(context)
    if not panel_armatures:
        _state["rig_hover_available"] = False
        _state["pin_gizmo_available_kinds"] = frozenset()
        _poll_rig_hover_targets(context)
        _state["bone_label_selection_signature"] = (
            bool(getattr(window_manager, "show_bone_names_enabled", True)),
            str(getattr(context, "mode", "")),
            0,
            "",
            0,
            (),
        )
        if _state.get("enabled", False):
            _disable_runtime()
        return 0.25

    if getattr(context, "mode", "") == "POSE":
        active_uids = {
            _armature_session_uid(armature)
            for armature in _pose_scope_armatures(context)
        }
        _state["rig_hover_available"] = any(
            _armature_session_uid(armature) not in active_uids
            for armature in panel_armatures
        )
    else:
        _state["rig_hover_available"] = False
    # Keep timer-driven maintenance out of Blender's native modal event path.
    # Dynamic Parent's dual-selection lock is the sole transform-time task;
    # everything that can reorder channels, alter visibility, or refresh draw
    # state waits until the user's interaction is finished.
    _poll_rig_hover_targets(context)
    _pin_gizmo_refresh_availability(context)

    _ensure_persistent_pose_runtime(context)
    presentation_visibility_changed = _sync_presentation_viewport_overlays(
        context
    )
    if not _animation_playback_active(context):
        _maintain_armature_action_channels(context)
    visibility_changed = _sync_pose_session_armature_visibility(context)
    _sync_selected_camera_as_active(context)
    if _sync_dynamic_parent_dual_selection_locks(context):
        _tag_redraw_all_view3d()

    if _pin_gizmo_track_selection(context):
        _tag_redraw_all_view3d()

    armature, pose_bone = _selected_bone_label_target(context)
    active_object = getattr(context, "active_object", None)
    selected_keys = tuple(sorted(_selected_owner_bone_keys(context)))
    signature = (
        bool(getattr(window_manager, "show_bone_names_enabled", True)),
        str(getattr(context, "mode", "")),
        _armature_session_uid(armature),
        pose_bone.name if pose_bone is not None else "",
        int(active_object.as_pointer()) if active_object is not None else 0,
        selected_keys,
    )
    if signature == _state.get("bone_label_selection_signature"):
        if (
            not _state.get("enabled", False)
            and (
                _custom_bone_label_targets(context)[1]
                or _dynamic_parent_visible_relationships(context)
            )
        ):
            _yellow_refresh_runtime(context)
        if visibility_changed or presentation_visibility_changed:
            _yellow_refresh_runtime(context)
        return 0.1

    _state["bone_label_selection_signature"] = signature
    advanced_mode = bool(
        getattr(window_manager, "roblox_compat_advanced_mode", False)
    )
    _sync_armature_debug_overlays(advanced_mode, False)
    _yellow_refresh_runtime(context)
    return 0.1


class ANIMATOR_UTILS_OT_set_transform_orientation(bpy.types.Operator):
    bl_idname = "staticaliza.set_transform_orientation"
    bl_label = "Set Transform Orientation"
    bl_description = "Set or toggle the 3D View transform orientation between Global and Local"
    bl_options = {"REGISTER"}

    orientation: bpy.props.EnumProperty(
        items = (
            ("TOGGLE", "Toggle", "Toggle between Global and Local"),
            ("GLOBAL", "Global", "Use Global transform orientation"),
            ("LOCAL", "Local", "Use Local transform orientation"),
        ),
        default = "TOGGLE",
        options = {"SKIP_SAVE"},
    )

    def execute(self, context):
        pin_selection = _pin_selection_runtime_snapshot()
        slot = context.scene.transform_orientation_slots[0]
        target = self.orientation
        part_mode = (
            getattr(context.window_manager, "staticaliza_pivot_mode", "BONE")
            == "PART"
        )
        if target == "TOGGLE":
            local_types = {"CURSOR", "LOCAL"} if part_mode else {"LOCAL"}
            target = "GLOBAL" if slot.type in local_types else "LOCAL"

        if target == "LOCAL" and part_mode:
            _sync_part_pivot(context)
            slot.type = "CURSOR"
        else:
            slot.type = target
        _pin_selection_runtime_restore(context, pin_selection)
        self.report({"INFO"}, f"Transform orientation: {target.title()}")
        return {"FINISHED"}
class ANIMATOR_UTILS_OT_set_pivot_mode(bpy.types.Operator):
    bl_idname = "staticaliza.set_pivot_mode"
    bl_label = "Set Pivot Mode"
    bl_description = "Toggle between the normal bone pivot and the connected object pivot"
    bl_options = {"REGISTER"}

    pivot_mode: bpy.props.EnumProperty(
        items = (
            ("TOGGLE", "Toggle", "Toggle between Bone and Object pivot modes"),
            ("BONE", "Bone", "Use Blender's normal bone pivot"),
            ("PART", "Object", "Use the midpoint of all selected bones' and pins' connected rig objects"),
        ),
        default = "TOGGLE",
        options = {"SKIP_SAVE"},
    )

    def execute(self, context):
        pin_selection = _pin_selection_runtime_snapshot()
        window_manager = context.window_manager
        current = getattr(window_manager, "staticaliza_pivot_mode", "BONE")
        target = self.pivot_mode
        if target == "TOGGLE":
            target = "PART" if current == "BONE" else "BONE"

        if target == "BONE":
            _disable_part_pivot(context)
            _pin_selection_runtime_restore(context, pin_selection)
            self.report({"INFO"}, "Pivot mode: Bone")
            return {"FINISHED"}
        if current != "PART":
            cursor = context.scene.cursor
            original_rotation_mode = cursor.rotation_mode
            cursor.rotation_mode = "QUATERNION"
            original_rotation = cursor.rotation_quaternion.copy()
            cursor.rotation_mode = original_rotation_mode
            _state["part_pivot_saved"] = {
                "pivot_point": _part_pivot_native_mode(context) if context.scene.tool_settings.transform_pivot_point == "CURSOR" else context.scene.tool_settings.transform_pivot_point,
                "cursor_location": cursor.location.copy(),
                "cursor_rotation": original_rotation,
                "cursor_rotation_mode": original_rotation_mode,
            }
            context.scene["_staticaliza_object_pivot_native"] = _state["part_pivot_saved"]["pivot_point"]
        window_manager.staticaliza_pivot_mode = "PART"
        matched = _sync_part_pivot(context, rematch = True)

        slot = context.scene.transform_orientation_slots[0]
        if matched and slot.type == "LOCAL":
            slot.type = "CURSOR"
        _pin_selection_runtime_restore(context, pin_selection)
        self.report({"INFO"}, "Pivot mode: Object")
        _tag_redraw_all_view3d()
        return {"FINISHED"}
