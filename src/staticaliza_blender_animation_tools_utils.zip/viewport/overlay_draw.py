"""Viewport 3D and pixel overlay draw callbacks."""

from ..core.runtime import *  # noqa: F403

def _draw_view():
    context = bpy.context
    if _context_is_presentation_view(context):
        return
    wm = getattr(context, "window_manager", None)
    contact_guides = tuple(_surface_contact_guides())
    pose_scope_uids = {
        _armature_session_uid(armature)
        for armature in _pose_scope_armatures(context)
    }
    draw_onion = bool(
        wm
        and pose_scope_uids
        and _state.get("onion_enabled_owners", set())
        and (
            _state["mesh_batches"]
            or _state.get("onion_multiple_mesh_batches", {})
        )
    )
    draw_pin_guides = bool(
        pose_scope_uids
        and (
            _state.get("yellow_modes", {})
            or contact_guides
        )
    )
    if not draw_onion and not draw_pin_guides:
        return

    previous_state = _capture_gpu_draw_state()
    try:
        gpu.state.depth_mask_set(False)
        gpu.state.blend_set("ALPHA")
        if draw_onion:
            gpu.state.depth_test_set("LESS_EQUAL")
            shader = _ensure_shader_3d()
            multiple = str(getattr(wm, "onion_skin_mode", "SINGLE")) == "MULTIPLE"
            source = (
                _state.get("onion_multiple_mesh_batches", {})
                if multiple else _state["mesh_batches"]
            )
            for owner_uid, owner_batches in source.items():
                if (
                    owner_uid not in pose_scope_uids
                    or owner_uid not in _state.get("onion_enabled_owners", set())
                ):
                    continue
                layers = (
                    owner_batches.items()
                    if multiple else (("PREVIOUS", owner_batches),)
                )
                for side, batches in layers:
                    if _state["shader_3d_mode"] == "UNIFORM":
                        shader.bind()
                        shader.uniform_float(
                            "color",
                            (
                                (0.0, 1.0, 0.0, wm.onion_skin_opacity)
                                if side == "NEXT"
                                else (1.0, 0.0, 0.0, wm.onion_skin_opacity)
                            ),
                        )
                    for batch in batches:
                        batch.draw(shader)
        if draw_pin_guides:
            # POST_VIEW runs before Blender's native gizmo pass. Every pin
            # line and circle therefore stays below every pin handle/diamond,
            # including overlapping guides belonging to another pin type.
            gpu.state.depth_test_set("NONE")
            _draw_depth_sorted_pin_guides(
                context,
                contact_guides,
                pose_scope_uids,
            )

    finally:
        _restore_gpu_draw_state(previous_state)
def _yellow_current_world_point(depsgraph, eval_arm, pose_bone, packed):
    # Capture already stores the chosen Smart/object endpoint in bone-local
    # space. Reading the welded mesh again during G/R/S introduces a one-step
    # depsgraph delay and can briefly pull an Onion Pin bone to a stale pose.
    # The saved local point is rigid, immediate, and works for every pin mode.
    try:
        return _bone_local_to_world(eval_arm, pose_bone, packed[1])
    except Exception:
        return eval_arm.matrix_world @ pose_bone.tail
def _draw_raycast_layer(
    context,
    fixed_map,
    color_rgba,
    armature = None,
    draw_lines = True,
    draw_endpoints = True,
    draw_targets = True,
    draw_target_dots = True,
    draw_snap_rings = True,
):
    if not fixed_map:
        return

    region = getattr(context, "region", None)
    rv3d = getattr(context, "region_data", None)
    if not region or not rv3d:
        return

    arm = armature or _active_armature(context)
    if not arm:
        return

    depsgraph = context.evaluated_depsgraph_get()
    eval_arm = (
        arm
        if (
            _state.get("pin_snap_transform_active")
            or _state.get("pin_keyboard_transform_active")
        )
        else arm.evaluated_get(depsgraph)
    )

    shader2d = _ensure_shader_2d()
    shader2d.bind()
    shader2d.uniform_float("u_viewport", (float(region.width), float(region.height)))

    line_pos = []
    endpoint_tri_pos = []
    target_tri_pos = []
    snap_rings = []

    circle_base = PIN_DOT_PIXEL_RADIUS
    for name, packed in fixed_map.items():
        if not packed or len(packed) < 2:
            continue

        fixed3d = packed[0]
        draw_dots = bool(packed[2]) if len(packed) >= 3 else True

        pb = eval_arm.pose.bones.get(name)
        if not pb:
            continue

        current3d = _yellow_current_world_point(depsgraph, eval_arm, pb, packed)

        line_segment, a, b = _project_world_segment_2d(
            context,
            fixed3d,
            current3d,
        )
        if line_segment is None and a is None and b is None:
            continue
        distance_world = (
            Vector(fixed3d) - Vector(current3d)
        ).length

        snapped = _pin_snap_ring_visible(
            f"YELLOW:{_armature_session_uid(arm)}:{name}",
            fixed3d,
            current3d,
        )

        if line_segment is not None:
            line_pos.extend(line_segment)

        if draw_dots:
            radius = (
                circle_base
                if snapped
                else circle_base * _circle_scale_from_dist(distance_world)
            )
            if draw_targets and draw_target_dots and a is not None:
                target_tri_pos.extend(_circle_tris_2d(a, circle_base))
            if draw_endpoints and b is not None:
                endpoint_tri_pos.extend(_circle_tris_2d(b, radius))
            if draw_targets and draw_snap_rings and snapped and a is not None:
                snap_rings.extend(
                    _circle_lines_2d(a, PIN_SNAP_RING_PIXEL_RADIUS)
                )

    if draw_lines and line_pos:
        shader2d.uniform_float("color", color_rgba)
        batch_for_shader(shader2d, "LINES", {"pos": line_pos}).draw(shader2d)

    if endpoint_tri_pos:
        shader2d.uniform_float("color", color_rgba)
        batch_for_shader(
            shader2d,
            "TRIS",
            {"pos": endpoint_tri_pos},
        ).draw(shader2d)

    if target_tri_pos:
        shader2d.uniform_float("color", color_rgba)
        batch_for_shader(
            shader2d,
            "TRIS",
            {"pos": target_tri_pos},
        ).draw(shader2d)

    if snap_rings:
        gpu.state.line_width_set(1.25)
        shader2d.uniform_float("color", color_rgba)
        batch_for_shader(shader2d, "LINES", {"pos": snap_rings}).draw(shader2d)
        gpu.state.line_width_set(4.0)


def _pin_guide_view_depth(context, first, second):
    """Return midpoint depth so always-visible 2D guides still layer in 3D."""
    rv3d = getattr(context, "region_data", None)
    if rv3d is None:
        return 0.0
    midpoint = (Vector(first) + Vector(second)) * 0.5
    return -float((rv3d.view_matrix @ midpoint.to_4d()).z)


def _draw_depth_sorted_pin_lines(context, pin_lines):
    """Subdivide crossing guides so front ownership can change along a line."""
    region = getattr(context, "region", None)
    if region is None or not pin_lines:
        return
    segments = []
    segment_count = 16
    for first, second, color, tie_order in pin_lines:
        first = Vector(first)
        second = Vector(second)
        for index in range(segment_count):
            start = first.lerp(second, index / segment_count)
            end = first.lerp(second, (index + 1) / segment_count)
            projected, _start_2d, _end_2d = _project_world_segment_2d(
                context,
                start,
                end,
            )
            if projected is not None:
                segments.append((
                    _pin_guide_view_depth(context, start, end),
                    tie_order,
                    tuple(color),
                    projected,
                ))
    if not segments:
        return
    segments.sort(key = lambda item: (item[0], item[1]), reverse = True)
    draw_batches = []
    for _depth, _tie, color, projected in segments:
        if not draw_batches or draw_batches[-1][0] != color:
            draw_batches.append((color, list(projected)))
        else:
            draw_batches[-1][1].extend(projected)
    shader = _ensure_shader_2d()
    shader.bind()
    shader.uniform_float(
        "u_viewport",
        (float(region.width), float(region.height)),
    )
    gpu.state.line_width_set(4.0)
    for color, positions in draw_batches:
        shader.uniform_float("color", color)
        batch_for_shader(
            shader,
            "LINES",
            {"pos": positions},
        ).draw(shader)


def _draw_depth_sorted_pin_guides(context, contact_guides, pose_scope_uids):
    """Draw far pin guides first while keeping them visible through geometry."""
    depsgraph = context.evaluated_depsgraph_get()
    frame = int(context.scene.frame_current)
    layers = []
    pin_lines = []
    yellow_points = {}
    for owner_uid in {
        int(key[0]) for key in _state.get("yellow_modes", {})
    }:
        if owner_uid not in pose_scope_uids:
            continue
        armature = _armature_from_session_uid(owner_uid)
        fixed_map = (
            _yellow_owner_map("yellow_fixed", armature)
            if armature is not None
            else {}
        )
        if armature is None or not fixed_map or _yellow_owner_hidden(armature):
            continue
        evaluated = (
            armature
            if (
                _state.get("pin_snap_transform_active")
                or _state.get("pin_keyboard_transform_active")
            )
            else armature.evaluated_get(depsgraph)
        )
        for bone_name, packed in fixed_map.items():
            pose_bone = evaluated.pose.bones.get(bone_name)
            if pose_bone is None or not packed or len(packed) < 2:
                continue
            current = _yellow_current_world_point(
                depsgraph,
                evaluated,
                pose_bone,
                packed,
            )
            yellow_points[(owner_uid, bone_name)] = (
                Vector(packed[0]),
                Vector(current),
            )
            yellow_distance = (Vector(packed[0]) - Vector(current)).length
            yellow_radius = (
                PIN_DOT_PIXEL_RADIUS
                if _pin_snap_ring_visible(
                    f"YELLOW:{owner_uid}:{bone_name}",
                    packed[0],
                    current,
                )
                else PIN_DOT_PIXEL_RADIUS
                * _circle_scale_from_dist(yellow_distance)
            )
            pin_lines.append((
                packed[0],
                current,
                ONION_PIN_COLOR,
                1,
            ))
            layers.append((
                _pin_guide_view_depth(context, packed[0], current),
                1,
                "YELLOW",
                armature,
                bone_name,
                packed,
                yellow_radius,
            ))
    pose_scope_names = {
        armature.name for armature in _pose_scope_armatures(context)
    }
    for guide in contact_guides:
        if (
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
            not in pose_scope_names
            or not _surface_contact_guide_interval_active_at(guide, frame)
        ):
            continue
        point, _normal, anchor = _surface_contact_world_point_normal(
            context,
            guide,
            depsgraph,
        )
        if point is None or anchor is None:
            continue
        guide_armature = bpy.data.objects.get(
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
        )
        overlap = yellow_points.get((
            _armature_session_uid(guide_armature),
            str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, "")),
        ))
        line_color = SURFACE_CONTACT_HOT_PINK
        if (
            overlap is not None
            and (Vector(point) - overlap[0]).length <= 0.025
            and (Vector(anchor) - overlap[1]).length <= 0.025
        ):
            line_color = SURFACE_CONTACT_OVERLAP_COLOR
        contact_distance = (Vector(point) - Vector(anchor)).length
        contact_radius = (
            PIN_DOT_PIXEL_RADIUS
            if _pin_snap_ring_visible(
                _surface_contact_snap_key(guide),
                point,
                anchor,
            )
            else PIN_DOT_PIXEL_RADIUS
            * _circle_scale_from_dist(contact_distance)
        )
        pin_lines.append((point, anchor, line_color, 0))
        layers.append((
            _pin_guide_view_depth(context, point, anchor),
            0,
            "CONTACT",
            None,
            guide.name,
            guide,
            contact_radius,
        ))
    _draw_depth_sorted_pin_lines(context, pin_lines)
    ordered_layers = sorted(
        layers,
        # Larger endpoint circles draw first. The smaller indicator and its
        # ring therefore remain visible on top. Equal circles keep yellow last.
        key = lambda item: (
            -float(item[6]),
            item[2] == "YELLOW",
            -float(item[0]),
        ),
    )
    def draw_layer(layer, *, endpoints, targets):
        _depth, _tie, kind, armature, name, data, _radius = layer
        if kind == "YELLOW":
            _draw_raycast_layer(
                context,
                {name: data},
                ONION_PIN_COLOR,
                armature = armature,
                draw_lines = False,
                draw_endpoints = endpoints,
                draw_targets = targets,
                draw_snap_rings = False,
            )
        else:
            _draw_surface_contact_guides(
                context,
                (data,),
                draw_lines = False,
                draw_endpoints = endpoints,
                draw_targets = targets,
                draw_snap_rings = False,
            )

    # Endpoint indicators draw first. Every selectable target dot and snap
    # ring then draws as one final overlay layer, matching the diamond gizmo.
    for layer in ordered_layers:
        draw_layer(layer, endpoints = True, targets = False)
    selected_keys = _pin_selected_target_keys()
    target_layers = sorted(
        ordered_layers,
        key = lambda item: bool(
            (
                item[2] == "YELLOW"
                and (
                    f"YELLOW:{_armature_session_uid(item[3])}:"
                    f"{item[4]}"
                ) in selected_keys
            )
            or (
                item[2] == "CONTACT"
                and _surface_contact_snap_key(item[5]) in selected_keys
            )
        ),
    )
    for layer in target_layers:
        draw_layer(layer, endpoints = False, targets = True)


def _draw_pin_snap_rings_top(context, contact_guides, pose_scope_uids):
    """Draw snap rings last, above resizing circles and selected diamonds."""
    scissor_rect = _camera_frame_scissor_rect(context)
    previous_scissor = None
    if scissor_rect is not None:
        try:
            previous_scissor = gpu.state.scissor_get()
            gpu.state.scissor_set(*scissor_rect)
            gpu.state.scissor_test_set(True)
        except (AttributeError, RuntimeError, TypeError, ValueError):
            previous_scissor = None
    try:
        for owner_uid in {
            int(key[0]) for key in _state.get("yellow_modes", {})
        }:
            if owner_uid not in pose_scope_uids:
                continue
            armature = _armature_from_session_uid(owner_uid)
            fixed_map = (
                _yellow_owner_map("yellow_fixed", armature)
                if armature is not None
                else {}
            )
            if (
                armature is None
                or not fixed_map
                or _yellow_owner_hidden(armature)
            ):
                continue
            _draw_raycast_layer(
                context,
                fixed_map,
                ONION_PIN_COLOR,
                armature = armature,
                draw_lines = False,
                draw_endpoints = False,
                draw_targets = True,
                draw_target_dots = False,
                draw_snap_rings = True,
            )
        _draw_surface_contact_guides(
            context,
            contact_guides,
            draw_lines = False,
            draw_endpoints = False,
            draw_targets = True,
            draw_target_dots = False,
            draw_snap_rings = True,
        )
    finally:
        if scissor_rect is not None:
            try:
                gpu.state.scissor_test_set(False)
                if previous_scissor is not None:
                    gpu.state.scissor_set(*previous_scissor)
            except (AttributeError, RuntimeError, TypeError, ValueError):
                pass


def _camera_frame_scissor_rect(context, opaque_only = True):
    """Return the camera image rectangle in region-local pixels."""
    region = getattr(context, "region", None)
    region_data = getattr(context, "region_data", None)
    space = getattr(context, "space_data", None)
    if (
        region is None
        or region_data is None
        or str(getattr(region_data, "view_perspective", "")) != "CAMERA"
    ):
        return None
    camera = getattr(space, "camera", None) or getattr(
        getattr(context, "scene", None),
        "camera",
        None,
    )
    if camera is None or getattr(camera, "type", "") != "CAMERA":
        return None
    # Passepartout transparency is an intentional presentation choice. Only
    # the opaque mode needs a hard GPU clip; with a transparent frame, labels
    # and pin rings must remain visible in the surrounding viewport.
    if (
        opaque_only
        and not bool(getattr(camera, "staticaliza_camera_opaque_frame", True))
    ):
        return None
    from bpy_extras import view3d_utils
    projected = []
    try:
        for corner in camera.data.view_frame(scene=context.scene):
            point = view3d_utils.location_3d_to_region_2d(
                region,
                region_data,
                camera.matrix_world @ Vector(corner),
            )
            if point is None:
                return None
            projected.append(Vector(point))
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return None
    minimum_x = max(0, int(math.floor(min(point.x for point in projected))))
    minimum_y = max(0, int(math.floor(min(point.y for point in projected))))
    maximum_x = min(
        int(region.width),
        int(math.ceil(max(point.x for point in projected))),
    )
    maximum_y = min(
        int(region.height),
        int(math.ceil(max(point.y for point in projected))),
    )
    width = maximum_x - minimum_x
    height = maximum_y - minimum_y
    return (
        (minimum_x, minimum_y, width, height)
        if width > 0 and height > 0
        else None
    )


def _draw_bone_labels_and_rig_label(
    context,
    selected_label_armature,
    label_targets,
    opacity_override = None,
):
    gpu.state.depth_test_set("NONE")
    for label_armature, label_bone in label_targets:
        _draw_bone_label(
            context,
            label_armature,
            label_bone,
            opacity_override = opacity_override,
        )
    _draw_rig_labels(
        context,
        selected_label_armature,
        opacity_override = opacity_override,
    )


def _draw_labels_with_camera_coverage(
    context,
    selected_label_armature,
    label_targets,
):
    impact_query = bpy.app.driver_namespace.get(
        "staticaliza_blender_animation_tools.impact_hides_viewport_labels"
    )
    if callable(impact_query):
        try:
            if impact_query(context):
                return
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            pass
    rect = _camera_frame_scissor_rect(context, opaque_only = False)
    if rect is None:
        _draw_bone_labels_and_rig_label(
            context,
            selected_label_armature,
            label_targets,
        )
        return

    camera = getattr(context.space_data, "camera", None) or context.scene.camera
    opaque = bool(getattr(camera, "staticaliza_camera_opaque_frame", True))
    region = context.region
    previous_scissor = None
    try:
        previous_scissor = gpu.state.scissor_get()
    except (AttributeError, RuntimeError, TypeError, ValueError):
        pass

    def draw_clipped(x, y, width, height, opacity):
        if width <= 0 or height <= 0:
            return
        gpu.state.scissor_set(int(x), int(y), int(width), int(height))
        gpu.state.scissor_test_set(True)
        _draw_bone_labels_and_rig_label(
            context,
            selected_label_armature,
            label_targets,
            opacity_override = opacity,
        )

    try:
        x, y, width, height = rect
        draw_clipped(x, y, width, height, 1.0)
        if not opaque:
            passepartout_alpha = float(
                getattr(camera.data, "passepartout_alpha", 0.5)
            )
            outside_opacity = max(0.0, min(1.0, 1.0 - passepartout_alpha))
            right = x + width
            top = y + height
            draw_clipped(0, 0, x, region.height, outside_opacity)
            draw_clipped(right, 0, region.width - right, region.height, outside_opacity)
            draw_clipped(x, 0, width, y, outside_opacity)
            draw_clipped(x, top, width, region.height - top, outside_opacity)
    finally:
        try:
            gpu.state.scissor_test_set(False)
            if previous_scissor is not None:
                gpu.state.scissor_set(*previous_scissor)
        except (AttributeError, RuntimeError, TypeError, ValueError):
            pass


def _draw_selected_pin_target_diamond(context):
    """Draw selected diamonds above native handles and below snap rings."""
    selected_targets = _pin_selected_targets_data(context)
    if not selected_targets:
        return
    region = getattr(context, "region", None)
    region_data = getattr(context, "region_data", None)
    if region is None or region_data is None:
        return
    from bpy_extras import view3d_utils

    shader = _ensure_shader_2d()
    shader.bind()
    shader.uniform_float(
        "u_viewport",
        (float(region.width), float(region.height)),
    )
    radius = PIN_DOT_PIXEL_RADIUS * 1.35
    for _selected_key, target_data in selected_targets:
        kind, _armature, _pose_bone, payload = target_data
        point = (
            Vector(payload[0])
            if kind == "YELLOW"
            else payload.matrix_world.translation.copy()
        )
        if not _pin_gizmo_center_in_front(context, point):
            continue
        projected = view3d_utils.location_3d_to_region_2d(
            region,
            region_data,
            point,
        )
        if projected is None:
            continue
        cx, cy = float(projected.x), float(projected.y)
        diamond = (
            (cx, cy + radius),
            (cx + radius, cy),
            (cx, cy - radius),
            (cx, cy + radius),
            (cx, cy - radius),
            (cx - radius, cy),
        )
        shader.uniform_float(
            "color",
            ONION_PIN_COLOR if kind == "YELLOW" else SURFACE_CONTACT_HOT_PINK,
        )
        batch_for_shader(
            shader,
            "TRIS",
            {"pos": diamond},
        ).draw(shader)


def _draw_dynamic_parent_relationships(context, relationships):
    if not relationships:
        return

    region = getattr(context, "region", None)
    region_data = getattr(context, "region_data", None)
    if region is None or region_data is None:
        return

    from bpy_extras import view3d_utils

    draw_cache = {
        "depsgraph": context.evaluated_depsgraph_get(),
        "objects": tuple(context.view_layer.objects),
        "points": {},
    }
    line_positions = []
    dot_positions = []
    dot_radius = 5.0
    for child_armature, child_name, target, subtarget in relationships:
        child_world = _dynamic_parent_bone_pivot_world(
            context,
            child_armature,
            child_name,
            draw_cache,
        )
        target_world = _dynamic_parent_target_pivot_world(
            context,
            target,
            subtarget,
            draw_cache,
        )
        if child_world is None or target_world is None:
            continue
        child_2d = view3d_utils.location_3d_to_region_2d(
            region,
            region_data,
            child_world,
        )
        target_2d = view3d_utils.location_3d_to_region_2d(
            region,
            region_data,
            target_world,
        )
        if child_2d is None or target_2d is None:
            continue
        child_point = (float(child_2d.x), float(child_2d.y))
        target_point = (float(target_2d.x), float(target_2d.y))
        line_positions.extend((target_point, child_point))
        dot_positions.extend(_circle_tris_2d(target_point, dot_radius))
        dot_positions.extend(_circle_tris_2d(child_point, dot_radius))

    if not line_positions and not dot_positions:
        return
    shader = _ensure_shader_2d()
    shader.bind()
    shader.uniform_float(
        "u_viewport",
        (float(region.width), float(region.height)),
    )
    color = (*DYNAMIC_PARENT_COLOR, 1.0)
    shader.uniform_float("color", color)
    if line_positions:
        gpu.state.line_width_set(2.0)
        batch_for_shader(
            shader,
            "LINES",
            {"pos": line_positions},
        ).draw(shader)
    if dot_positions:
        batch_for_shader(
            shader,
            "TRIS",
            {"pos": dot_positions},
        ).draw(shader)
    gpu.state.line_width_set(4.0)


def _draw_pose_timecode(context):
    if getattr(context, "mode", "") != "POSE":
        return
    scene = getattr(context, "scene", None)
    region = getattr(context, "region", None)
    if scene is None or region is None:
        return
    try:
        font_size = float(context.preferences.ui_styles[0].widget.points) + 3.0
    except (AttributeError, IndexError, TypeError, ValueError):
        font_size = 14.0
    full_text = _pose_timecode_text(scene)
    prefix, value = full_text.rsplit(" ", 1)
    prefix += " "
    looped = bool(getattr(scene, ROBLOX_ANIMATION_LOOP_PROPERTY, False))
    left_x = 8.0
    bottom_y = 8.0
    _draw_outlined_bone_text(
        0,
        prefix,
        0.0,
        0.0,
        font_size,
        (1.0, 1.0, 1.0, 1.0),
        outline_color = (0.0, 0.0, 0.0),
        left_position = (left_x, bottom_y),
    )
    blf.size(0, float(font_size))
    prefix_width = float(blf.dimensions(0, prefix)[0])
    _draw_outlined_bone_text(
        0,
        value,
        0.0,
        0.0,
        font_size,
        (0.0, 1.0, 0.0, 1.0) if looped else (1.0, 0.0, 0.0, 1.0),
        outline_color = (0.0, 0.0, 0.0),
        left_position = (left_x + prefix_width, bottom_y),
    )


def _draw_smart_dragger_dots(context):
    data = _smart_dragger_data(context)
    region = getattr(context, "region", None)
    region_data = getattr(context, "region_data", None)
    if data is None or region is None or region_data is None:
        return
    target = Vector(data["target_point"])
    anchor = Vector(data["anchor_point"])
    line_segment, target_2d, anchor_2d = _project_world_segment_2d(
        context,
        target,
        anchor,
    )
    if line_segment is None and target_2d is None and anchor_2d is None:
        return
    shader = _ensure_shader_2d()
    shader.bind()
    shader.uniform_float(
        "u_viewport",
        (float(region.width), float(region.height)),
    )
    shader.uniform_float("color", (*SMART_DRAGGER_RED, 1.0))
    if line_segment is not None:
        batch_for_shader(
            shader,
            "LINES",
            {"pos": line_segment},
        ).draw(shader)
    distance_world = (target - anchor).length
    anchor_radius = PIN_DOT_PIXEL_RADIUS * _circle_scale_from_dist(
        distance_world
    )
    if anchor_2d is not None:
        batch_for_shader(
            shader,
            "TRIS",
            {"pos": _circle_tris_2d(anchor_2d, anchor_radius)},
        ).draw(shader)
    if target_2d is not None:
        batch_for_shader(
            shader,
            "TRIS",
            {"pos": _circle_tris_2d(target_2d, PIN_DOT_PIXEL_RADIUS)},
        ).draw(shader)
    if bool(data.get("attached", False)) and target_2d is not None:
        gpu.state.line_width_set(1.25)
        batch_for_shader(
            shader,
            "LINES",
            {
                "pos": _circle_lines_2d(
                    target_2d,
                    PIN_SNAP_RING_PIXEL_RADIUS,
                )
            },
        ).draw(shader)
        gpu.state.line_width_set(4.0)


def _draw_pixel():
    # One read-only draw needs one Action index. Discard RNA references before
    # returning so key edits and undo are visible on the very next draw.
    owned = []
    for key in ("ragdoll_native_channel_indexes", "ragdoll_evaluation_curves"):
        if key not in _state:
            _state[key] = {}
            owned.append(key)
    try:
        return _draw_pixel_impl()
    finally:
        for key in owned:
            _state.pop(key, None)


def _draw_pixel_impl():
    context = bpy.context
    if _context_is_presentation_view(context):
        return
    wm = getattr(context, "window_manager", None)
    if not wm:
        return
    selected_label_armature, label_targets = _custom_bone_label_targets(context)
    parent_relationships = _dynamic_parent_visible_relationships(context)
    contact_guides = tuple(_surface_contact_guides())
    pose_scope_uids = {
        _armature_session_uid(armature)
        for armature in _pose_scope_armatures(context)
    }
    draw_non_pose_rig_labels = bool(
        getattr(context, "mode", "") != "POSE"
        and getattr(wm, "show_bone_names_enabled", True)
        and _pose_panel_armatures(context)
    )
    if (
        (not _state.get("onion_enabled_owners", set()))
        and (not _state["yellow_modes"])
        and not label_targets
        and not contact_guides
        and not parent_relationships
        and not draw_non_pose_rig_labels
        and getattr(context, "mode", "") != "POSE"
    ):
        return

    previous_state = _capture_gpu_draw_state()
    try:
        gpu.state.depth_test_set("NONE")
        gpu.state.depth_mask_set(False)
        gpu.state.blend_set("ALPHA")
        gpu.state.line_width_set(4.0)

        if wm.onion_skin_include_bones and wm.onion_skin_raycast:
            for owner_uid in tuple(_state.get("onion_enabled_owners", set())):
                if owner_uid not in pose_scope_uids:
                    continue
                armature = _armature_from_session_uid(owner_uid)
                multiple = str(getattr(wm, "onion_skin_mode", "SINGLE")) == "MULTIPLE"
                fixed_source = (
                    _state.get("onion_multiple_raycast_fixed", {}).get(owner_uid, {})
                    if multiple
                    else {"PREVIOUS": _state.get("raycast_fixed", {}).get(owner_uid, {})}
                )
                if armature is not None:
                    for side, fixed_map in fixed_source.items():
                        if fixed_map:
                            _draw_raycast_layer(
                                context,
                                fixed_map,
                                (0.0, 1.0, 0.0, 1.0) if side == "NEXT" else (1.0, 0.0, 0.0, 1.0),
                                armature=armature,
                            )

        _draw_pin_transform_constraint(context)

        if parent_relationships:
            _draw_dynamic_parent_relationships(
                context,
                parent_relationships,
            )

        selected_label_armature, label_targets = _custom_bone_label_targets(context)
        label_scissor = _camera_frame_scissor_rect(context)
        previous_label_scissor = None
        label_scissor_enabled = False
        if label_scissor is not None:
            try:
                previous_label_scissor = gpu.state.scissor_get()
                gpu.state.scissor_set(*label_scissor)
                gpu.state.scissor_test_set(True)
                label_scissor_enabled = True
            except (AttributeError, RuntimeError, TypeError, ValueError):
                previous_label_scissor = None
        try:
            _draw_labels_with_camera_coverage(
                context,
                selected_label_armature,
                label_targets,
            )
        finally:
            if label_scissor_enabled:
                try:
                    gpu.state.scissor_test_set(False)
                    if previous_label_scissor is not None:
                        gpu.state.scissor_set(*previous_label_scissor)
                except (AttributeError, RuntimeError, TypeError, ValueError):
                    pass
        _draw_pose_timecode(context)
        _draw_selected_pin_target_diamond(context)
        _draw_smart_dragger_dots(context)
        # Snap rings remain the final layer above diamonds and native gizmos.
        _draw_pin_snap_rings_top(
            context,
            contact_guides,
            pose_scope_uids,
        )
    finally:
        _restore_gpu_draw_state(previous_state)
