"""Operators for attached bone cameras and camera-view keyframing."""

from ..core.runtime import *  # noqa: F403
from .camera import (
    CAMERA_ORIENTATION_ITEMS,
    _arm_camera_lock_navigation,
)


def _camera_collection_for_armature(context, armature):
    """Return this rig's Cameras collection, creating it when necessary."""
    rig_collection = next(
        (
            collection
            for collection in tuple(bpy.data.collections)
            if str(collection.name).startswith("RIG: ")
            and armature in tuple(collection.all_objects)
        ),
        None,
    )
    if rig_collection is None:
        return context.collection
    cameras = next(
        (
            child
            for child in rig_collection.children
            if _strip_blender_numeric_suffix(str(child.name)) == "Cameras"
        ),
        None,
    )
    if cameras is None:
        cameras = bpy.data.collections.new("Cameras")
        rig_collection.children.link(cameras)
    return cameras


def _collapse_rig_collections_in_outliners():
    """Return Outliners to Blender's compact collection-focused hierarchy."""
    for window in tuple(bpy.context.window_manager.windows):
        screen = getattr(window, "screen", None)
        if screen is None:
            continue
        for area in screen.areas:
            if area.type != "OUTLINER":
                continue
            region = next(
                (candidate for candidate in area.regions if candidate.type == "WINDOW"),
                None,
            )
            if region is None:
                continue
            try:
                with bpy.context.temp_override(
                    window=window,
                    screen=screen,
                    area=area,
                    region=region,
                ):
                    # This official operator opens collection hierarchy but
                    # closes object entries, including the newly populated
                    # Cameras child. It avoids cursor-coordinate hacks and
                    # leaves the rig visible/selectable.
                    bpy.ops.outliner.show_hierarchy()
            except (AttributeError, RuntimeError):
                continue
    return None


def _schedule_rig_collection_collapse():
    if not bpy.app.timers.is_registered(_collapse_rig_collections_in_outliners):
        register_owned_timer(
            _collapse_rig_collections_in_outliners,
            first_interval=0.0,
        )


class ANIMATOR_UTILS_OT_add_bone_camera(bpy.types.Operator):
    bl_idname = "staticaliza.add_bone_camera"
    bl_label = "Create Camera"
    bl_description = "Create or remove cameras rigidly attached to the selected pose bones"
    bl_options = {"REGISTER", "UNDO"}

    fov: bpy.props.FloatProperty(
        name = "FOV",
        description = "Horizontal field of view for a custom camera preset",
        subtype = "ANGLE",
        default = math.radians(35.0),
        min = math.radians(1.0),
        max = math.radians(120.0),
        precision = 2,
    )
    orientation: bpy.props.EnumProperty(
        name = "Axis",
        description = "Choose the attached object's local axis the camera points along",
        items = CAMERA_ORIENTATION_ITEMS,
        default = "Z_NEG",
    )
    hide_attached_object: bpy.props.BoolProperty(
        name = "Hide Object",
        description = "Hide mesh objects driven by the camera bone in the viewport and render",
        default = True,
    )
    opaque_frame: bpy.props.BoolProperty(
        name = "Opaque Frame",
        description = "Fill every area outside the camera frame with pure black",
        default = True,
    )
    composition_thirds: bpy.props.BoolProperty(
        name = "Composition Thirds",
        description = "Show the rule-of-thirds composition guide in camera view",
        default = False,
    )
    removed_existing: bpy.props.BoolProperty(
        default = False,
        options = {"HIDDEN", "SKIP_SAVE"},
    )

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE" and bool(_camera_panel_bones(context))

    def draw(self, _context):
        layout = self.layout
        if self.removed_existing:
            layout.label(text = "Selected cameras removed.")
            return
        layout.prop(self, "fov", slider = True)
        layout.prop(self, "orientation")
        layout.prop(self, "hide_attached_object")
        layout.prop(self, "opaque_frame")
        layout.prop(self, "composition_thirds")

    def invoke(self, context, _event):
        self.removed_existing = _selected_camera_batch_removes(context)
        if not self.removed_existing:
            window_manager = context.window_manager
            self.fov = math.radians(window_manager.staticaliza_camera_fov)
            self.orientation = window_manager.staticaliza_camera_orientation
            self.hide_attached_object = True
            self.opaque_frame = True
            self.composition_thirds = False
        return self.execute(context)

    def execute(self, context):
        selected = _camera_panel_bones(context)
        if not selected:
            return {"CANCELLED"}

        remove_all = all(camera is not None for _, _, camera in selected)
        if remove_all:
            self.removed_existing = True
            removed = 0
            affected_armatures = set()
            for armature, pose_bone, camera in selected:
                if camera is None:
                    continue
                affected_armatures.add(armature)
                _remove_attached_camera_fov(armature, pose_bone)
                _set_attached_camera_object_visibility(
                    context.scene,
                    camera,
                    False,
                )
                camera_data = camera.data
                if context.scene.camera == camera:
                    context.scene.camera = None
                bpy.data.objects.remove(camera, do_unlink = True)
                if camera_data.users == 0:
                    bpy.data.cameras.remove(camera_data)
                removed += 1
            context.view_layer.update()
            frame = int(context.scene.frame_current)
            for armature in affected_armatures:
                _sync_all_dynamic_pose_bone_colors(frame, armature)
            context.view_layer.update()
            _tag_redraw_all_view3d()
            noun = "camera" if removed == 1 else "cameras"
            self.report({"INFO"}, f"Removed {removed} selected {noun}.")
            return {"FINISHED"}

        self.removed_existing = False
        affected_armatures = {armature for armature, _bone, _camera in selected}
        camera_angle = math.radians(35.0)
        _state["camera_fov_syncing"] = True
        try:
            context.window_manager.staticaliza_camera_fov = math.degrees(camera_angle)
            context.window_manager.staticaliza_camera_orientation = self.orientation
        finally:
            _state["camera_fov_syncing"] = False

        created = 0
        preferred_camera = selected[0][2]
        for armature, pose_bone, existing_camera in selected:
            if existing_camera is not None:
                if preferred_camera is None:
                    preferred_camera = existing_camera
                continue

            camera_name = f"{pose_bone.name} - Camera"
            camera_data = bpy.data.cameras.new(camera_name)
            camera_data.type = "PERSP"
            camera_data.sensor_fit = "HORIZONTAL"
            camera_data.angle = camera_angle
            camera_data.show_composition_thirds = bool(
                self.composition_thirds
            )

            camera = bpy.data.objects.new(camera_data.name, camera_data)
            _camera_collection_for_armature(
                context, armature
            ).objects.link(camera)
            camera[ATTACHED_CAMERA_OWNER_NAME_PROPERTY] = armature.name
            camera[ATTACHED_CAMERA_OWNER_UID_PROPERTY] = str(
                _armature_session_uid(armature)
            )
            camera[ATTACHED_CAMERA_BONE_PROPERTY] = pose_bone.name
            previous_batch_sync = bool(
                _state.get("camera_batch_property_syncing", False)
            )
            _state["camera_batch_property_syncing"] = True
            try:
                # Object-property callbacks normally push their own Camera
                # FOV/Axis history. During creation those are initialization,
                # not separate user edits; letting them push creates the two
                # blank steps before the camera operator's own Undo boundary.
                camera.staticaliza_camera_orientation = self.orientation
                camera.staticaliza_camera_hide_attached_object = (
                    self.hide_attached_object
                )
                camera.staticaliza_camera_opaque_frame = self.opaque_frame
            finally:
                _state["camera_batch_property_syncing"] = previous_batch_sync
            camera_world = _camera_world_at_bone_tip(
                armature,
                pose_bone,
                camera.staticaliza_camera_orientation,
                context = context,
            )
            camera.parent = armature
            camera.parent_type = "BONE"
            camera.parent_bone = pose_bone.name
            camera.matrix_parent_inverse = Matrix.Identity(4)
            camera.matrix_world = camera_world
            bone_world = armature.matrix_world @ pose_bone.matrix
            local_matrix = bone_world.inverted_safe() @ camera_world
            camera[ATTACHED_CAMERA_LOCAL_MATRIX_PROPERTY] = tuple(
                float(value) for row in local_matrix for value in row
            )
            _apply_camera_passepartout(camera)
            _set_attached_camera_object_visibility(
                context.scene,
                camera,
                self.hide_attached_object,
            )
            if preferred_camera is None:
                preferred_camera = camera
            created += 1

        if created:
            _schedule_rig_collection_collapse()

        context.scene.render.resolution_x = 1920
        context.scene.render.resolution_y = 1080
        context.scene.render.resolution_percentage = 100
        if preferred_camera is not None:
            context.scene.camera = preferred_camera
            _remember_attached_camera(preferred_camera)
        context.view_layer.update()
        frame = int(context.scene.frame_current)
        for armature in affected_armatures:
            _sync_all_dynamic_pose_bone_colors(frame, armature)
        context.view_layer.update()
        _tag_redraw_all_view3d()
        noun = "camera" if created == 1 else "cameras"
        self.report({"INFO"}, f"Added {created} selected {noun}.")
        return {"FINISHED"}


class ANIMATOR_UTILS_OT_toggle_attached_camera_view(bpy.types.Operator):
    bl_idname = "staticaliza.toggle_attached_camera_view"
    bl_label = "Toggle attached camera view"
    bl_description = 'Toggle the selected camera view'
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        return (
            getattr(getattr(context, "area", None), "type", "")
            == "VIEW_3D"
        )

    def execute(self, context):
        area = context.area
        space = context.space_data
        if getattr(space, "type", "") != "VIEW_3D":
            space = area.spaces.active
        region_data = getattr(space, "region_3d", None)
        if region_data is None:
            return {"FINISHED"}

        if _presentation_camera_navigation_locked(context):
            # Preview and Audio are presentation outputs, not free 3D
            # viewports. Numpad-0 must not toggle them out of their camera.
            return {"FINISHED"}

        if region_data.view_perspective == "CAMERA":
            _finish_attached_camera_exit(
                context,
                area,
                space,
                region_data,
            )
            _sync_free_viewports(
                context,
                source_region_data = region_data,
                source_space = space,
            )
            _sync_animation_camera_views(context, source_space=space)
            return {"FINISHED"}

        camera = _attached_camera_for_view(context)
        if camera is None:
            # Consume Numpad-0 so Blender cannot silently pick scene.camera
            # when no camera, or multiple unselected cameras, are attached.
            return {"FINISHED"}

        snapshot = _free_view_snapshot(region_data)
        try:
            space_pointer = int(space.as_pointer())
            region_pointer = int(region_data.as_pointer())
        except (AttributeError, ReferenceError):
            return {"FINISHED"}
        state = _camera_view_state(
            _state.setdefault("camera_view_spaces", {}).get(
                space_pointer
            )
        )
        state["return_view"] = snapshot
        state["pending_level"] = False
        state["last_rotation"] = None
        state["stable_ticks"] = 0
        state["entering"] = True
        state["enter_started"] = time.monotonic()
        state["camera_pointer"] = int(camera.as_pointer())
        state["camera_name"] = camera.name
        if snapshot is not None:
            _state["free_view_master"] = snapshot
            _state.setdefault("free_view_space_states", {})[
                region_pointer
            ] = snapshot

        context.scene.camera = camera
        try:
            space.camera = camera
        except (AttributeError, ReferenceError, TypeError):
            pass
        _select_attached_camera_bone(context, camera)
        _set_attached_camera_preview_visibility(context.scene, camera, True)
        window_region = next(
            (region for region in area.regions if region.type == "WINDOW"),
            None,
        )
        invoked_view_camera = False
        if window_region is not None:
            try:
                with context.temp_override(
                    area = area,
                    region = window_region,
                    space_data = space,
                ):
                    if bpy.ops.view3d.view_camera.poll():
                        bpy.ops.view3d.view_camera("INVOKE_DEFAULT")
                        invoked_view_camera = True
            except (AttributeError, ReferenceError, RuntimeError):
                pass
        # When Blender accepted view_camera it may be in smooth-view and
        # still report PERSP briefly. Do not force CAMERA here: that was the
        # instant snap that made Numpad-0 differ from the navigation button.
        if not invoked_view_camera and region_data.view_perspective != "CAMERA":
            try:
                region_data.view_perspective = "CAMERA"
            except (
                AttributeError,
                ReferenceError,
                RuntimeError,
                TypeError,
                ValueError,
            ):
                pass
        state["attached"] = region_data.view_perspective == "CAMERA"
        if state["attached"]:
            state["entering"] = False
            state["enter_started"] = 0.0
        _state["camera_view_spaces"][space_pointer] = state
        _sync_animation_camera_views(context, source_space=space)
        area.tag_redraw()
        return {"FINISHED"}


def _presentation_camera_navigation_locked(context):
    """True only for the dedicated Preview/Audio camera output area."""
    area = getattr(context, "area", None)
    space = getattr(context, "space_data", None)
    if getattr(area, "type", "") != "VIEW_3D":
        return False
    if getattr(space, "type", "") != "VIEW_3D":
        space = getattr(getattr(area, "spaces", None), "active", None)
    region_data = getattr(space, "region_3d", None)
    if (
        region_data is None
        or str(getattr(region_data, "view_perspective", "")) != "CAMERA"
    ):
        return False
    workspace = getattr(context, "workspace", None)
    if workspace is None:
        workspace = getattr(getattr(context, "window", None), "workspace", None)
    return str(getattr(workspace, "name", "")).strip().casefold() in {
        "preview",
        "audio",
    }


class ANIMATOR_UTILS_OT_attached_camera_wheel_exit(bpy.types.Operator):
    bl_idname = "staticaliza.attached_camera_wheel_exit"
    bl_label = "Exit attached camera view"
    bl_description = (
        'Leave camera view'
    )
    bl_options = {"INTERNAL"}

    begin_orbit: bpy.props.BoolProperty(
        default = False,
        options = {"SKIP_SAVE"},
    )

    @staticmethod
    def _attached_camera_view_active(context):
        area = getattr(context, "area", None)
        space = getattr(context, "space_data", None)
        region_data = getattr(space, "region_3d", None)
        camera = getattr(space, "camera", None) or getattr(
            getattr(context, "scene", None),
            "camera",
            None,
        )
        armature, bone_name = _camera_bone_binding(camera)
        return bool(
            area is not None
            and getattr(area, "type", "") == "VIEW_3D"
            and region_data is not None
            and str(getattr(region_data, "view_perspective", "")) == "CAMERA"
            and armature is not None
            and bone_name
        )

    def _exit_camera(self, context):
        area = getattr(context, "area", None)
        space = getattr(context, "space_data", None)
        region_data = getattr(space, "region_3d", None)
        camera = getattr(space, "camera", None) or context.scene.camera
        armature, bone_name = _camera_bone_binding(camera)
        if (
            area is None
            or area.type != "VIEW_3D"
            or region_data is None
            or region_data.view_perspective != "CAMERA"
            or armature is None
            or not bone_name
        ):
            return None
        _finish_attached_camera_exit(context, area, space, region_data)
        _sync_free_viewports(
            context,
            source_region_data = region_data,
            source_space = space,
        )
        _sync_animation_camera_views(context, source_space=space)
        return region_data

    def execute(self, context):
        if not self._attached_camera_view_active(context):
            return {"PASS_THROUGH"}
        if _presentation_camera_navigation_locked(context):
            return {"FINISHED"}
        if self._exit_camera(context) is None:
            return {"PASS_THROUGH"}
        return {"FINISHED"}

    def invoke(self, context, event):
        if not self._attached_camera_view_active(context):
            # This operator is bound ahead of Blender's native MMB/wheel
            # navigation. Never consume those events in an ordinary viewport.
            return {"PASS_THROUGH"}
        if _presentation_camera_navigation_locked(context):
            return {"FINISHED"}
        space = getattr(context, "space_data", None)
        timeline_active = _camera_view_navigation_suspended(context, space)
        # Blender owns MMB navigation while Lock Camera to View is enabled.
        # Passing through keeps the view in CAMERA perspective and lets the
        # native navigation operator move the attached camera.
        if bool(getattr(space, "lock_camera", False)) and not timeline_active:
            _arm_camera_lock_navigation(context, space)
            fade = bpy.app.driver_namespace.get("impaction_begin_camera_navigation")
            if callable(fade):
                fade(context, event)
            return {"PASS_THROUGH"}
        if not self.begin_orbit:
            return self.execute(context)
        region_data = self._exit_camera(context)
        if region_data is None:
            return {"PASS_THROUGH"}
        self._region_data = region_data
        self._last_mouse_x = int(event.mouse_x)
        self._last_mouse_y = int(event.mouse_y)
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}
    def modal(self, context, event):
        if event.type == "MIDDLEMOUSE" and event.value == "RELEASE":
            return {"FINISHED"}
        if event.type == "ESC":
            return {"FINISHED"}
        if event.type != "MOUSEMOVE":
            return {"RUNNING_MODAL"}

        region_data = getattr(self, "_region_data", None)
        if region_data is None:
            return {"CANCELLED"}
        mouse_x = int(event.mouse_x)
        mouse_y = int(event.mouse_y)
        delta_x = mouse_x - int(self._last_mouse_x)
        delta_y = mouse_y - int(self._last_mouse_y)
        self._last_mouse_x = mouse_x
        self._last_mouse_y = mouse_y
        if not delta_x and not delta_y:
            return {"RUNNING_MODAL"}

        # Initialize this one transition gesture entirely from the restored
        # free-view quaternion. Blender's native camera-exit orbit caches the
        # upside-down camera basis before Python can replace RegionView3D,
        # reversing horizontal input until MMB is released.
        sensitivity = 0.005
        rotation = region_data.view_rotation.copy()
        world_up = Vector((0.0, 0.0, 1.0))
        yaw = Quaternion(world_up, -float(delta_x) * sensitivity)
        rotation = yaw @ rotation
        right = rotation @ Vector((1.0, 0.0, 0.0))
        if right.length_squared > 1.0e-12:
            pitch = Quaternion(
                right.normalized(),
                -float(delta_y) * sensitivity,
            )
            candidate = pitch @ rotation
            direction = candidate @ Vector((0.0, 0.0, -1.0))
            if abs(direction.dot(world_up)) < 1.0 - 1.0e-5:
                rotation = candidate
        rotation.normalize()
        region_data.view_rotation = rotation
        snapshot = _free_view_snapshot(region_data)
        if snapshot is not None:
            _state["free_view_master"] = snapshot
        _sync_free_viewports(
            context,
            source_region_data = region_data,
            source_space = context.space_data,
        )
        try:
            context.area.tag_redraw()
        except (AttributeError, ReferenceError):
            pass
        return {"RUNNING_MODAL"}


class ANIMATOR_UTILS_OT_keyframe_camera_view(bpy.types.Operator):
    bl_idname = "staticaliza.keyframe_camera_view"
    bl_label = "Keyframe View"
    bl_description = 'Align the selected camera to the current view and insert a keyframe'
    bl_options = {"REGISTER", "UNDO"}

    @staticmethod
    def _enter_camera_view(context, camera):
        if camera is None:
            return False
        context.scene.camera = camera
        area = getattr(context, "area", None)
        if getattr(area, "type", "") != "VIEW_3D":
            return False
        space = getattr(context, "space_data", None)
        if getattr(space, "type", "") != "VIEW_3D":
            space = area.spaces.active
        try:
            space.camera = camera
        except (AttributeError, ReferenceError, TypeError):
            pass
        region_data = getattr(space, "region_3d", None)
        if (
            region_data is not None
            and region_data.view_perspective == "CAMERA"
        ):
            _sync_animation_camera_views(context, source_space=space)
            return True
        window_region = next(
            (region for region in area.regions if region.type == "WINDOW"),
            None,
        )
        if window_region is None:
            return False
        try:
            with context.temp_override(
                area = area,
                region = window_region,
                space_data = space,
            ):
                if bpy.ops.view3d.view_camera.poll():
                    bpy.ops.view3d.view_camera()
        except (AttributeError, RuntimeError):
            return False
        entered = bool(
            region_data is not None
            and region_data.view_perspective == "CAMERA"
        )
        if entered:
            _sync_animation_camera_views(context, source_space=space)
        return entered

    def execute(self, context):
        attached_cameras = _attached_bone_cameras(context.scene)
        armature, pose_bone, camera = _attached_camera_bone_for_keyframe(
            context
        )
        if camera is not None:
            # Native Lock Camera to View moves the camera object itself. Use
            # that exact result instead of the viewport framing matrix, then
            # bake it into the attached bone at the current timeline cursor.
            camera_world = (
                camera.matrix_world.copy()
                if _camera_is_view_locked(camera)
                else _view_camera_matrix(context)
            )
            if camera_world is None:
                return {"FINISHED"}
            if _keyframe_camera_bone(context, armature, pose_bone, camera, camera_world):
                context.scene.camera = camera
                _remember_attached_camera(camera)
                context.view_layer.update()
                self._enter_camera_view(context, camera)
                self.report({"INFO"}, f"Keyframed camera bone {pose_bone.name}.")
            return {"FINISHED"}

        # Bone-attached cameras take priority. If multiple exist without a
        # selected, active, or remembered choice, do nothing instead of
        # accidentally keyframing an unrelated standalone camera.
        if attached_cameras:
            return {"FINISHED"}

        camera = _standalone_camera(context)
        if camera is None:
            return {"FINISHED"}
        camera_world = (
            camera.matrix_world.copy()
            if _camera_is_view_locked(camera)
            else _view_camera_matrix(context)
        )
        if camera_world is None:
            return {"FINISHED"}
        _keyframe_standalone_camera(camera, context.scene.frame_current, camera_world)
        context.scene.camera = camera
        context.view_layer.update()
        self._enter_camera_view(context, camera)
        self.report({"INFO"}, f"Keyframed camera {camera.name}.")
        return {"FINISHED"}
