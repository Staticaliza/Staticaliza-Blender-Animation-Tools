"""Keyed world-rotation holds with editable cyan aim targets.

Constraints own evaluation. Runtime observation only authors an aim edit during
a native rotation gesture; history restores only explicitly saved pending edits.
"""

from ..core.runtime import *  # noqa: F403
from bpy_extras import view3d_utils


GYRO_COLOR = (0.0, 1.0, 1.0, 1.0)
GYRO_MARKER = "Gyro"
GYRO_TARGET_PROPERTY = "Gyro Target"
GYRO_TILT_PROPERTY = "Gyro Tilt"
GYRO_START_PROPERTY = "Gyro Start"
GYRO_POSITION_ITEMS = (
    ("MODE_3", "Smart", "Use the bone's linked geometry, with a bone-center fallback"),
    ("MODE_4", "Bone Start", "Use the bone head"),
    ("MODE_2", "Bone Center", "Use the center of the linked geometry or bone"),
    ("MODE_1", "Bone End", "Use the bone tail"),
)
GYRO_AXIS_ITEMS = tuple((key, label, f"Aim along the bone's local {label} axis")
                        for key, label, _description in PIN_AXIS_ITEMS)


def _gyro_guides(scene=None):
    return tuple(obj for obj in (scene or bpy.context.scene).objects
                 if obj.type == "EMPTY" and obj.get("gyro_pin", False))


def _gyro_owner(guide):
    armature = guide.get("gyro_armature")
    if armature is None or armature.type != "ARMATURE" or armature.pose is None:
        return None, None
    return armature, armature.pose.bones.get(str(guide.get("gyro_bone", "")))


def _gyro_active(context, guide):
    armature, bone = _gyro_owner(guide)
    if bone is None:
        return False
    return _gyro_bone_active_at(armature, bone, context.scene.frame_current_final)


def _gyro_authored_active(context, guide):
    _armature, bone = _gyro_owner(guide)
    return bool(bone is not None and GYRO_MARKER in bone
                and _pin_marker_value(bone, GYRO_MARKER, context.scene.frame_current_final) > .5)


def _gyro_bone_active_at(armature, bone, frame):
    if GYRO_MARKER not in bone or _constraint_bone_ragdoll_override(armature, bone, frame):
        return False
    return _pin_marker_value(bone, GYRO_MARKER, frame) > .5

def _gyro_selected_target(context=None):
    context = context or bpy.context
    key = _pin_selected_target_key()
    guide = bpy.data.objects.get(key[5:]) if key.startswith("GYRO:") else None
    if (guide is None or not guide.get("gyro_pin", False)
            or not _gyro_active(context, guide)):
        return None
    return guide


def _gyro_subjects(context):
    selected = [(armature, bone)
                for armature, bones in _selected_pose_bones_by_owner(context).items()
                for bone in bones] if context.mode == "POSE" else []
    for _key, data in _pin_selected_targets_data(context):
        if data[0] == "GYRO" and (owner := (data[1], data[2])) not in selected:
            selected.append(owner)
    return selected


def _gyro_find(context, armature, bone):
    return next((guide for guide in _gyro_guides(context.scene)
                 if guide.get("gyro_armature") == armature
                 and str(guide.get("gyro_bone", "")) == bone.name), None)


def _gyro_visible(context):
    if context.mode != "POSE" or _context_is_presentation_view(context) or _pin_animation_hidden(context):
        return ()
    return tuple(data[3] for data in _pin_available_target_data(context).values()
                 if data[0] == "GYRO")


def _gyro_excluded(context, armature):
    excluded = {armature}
    for obj in context.scene.objects:
        parent = obj.parent
        while parent is not None and parent != armature:
            parent = parent.parent
        if parent == armature or any(
            getattr(modifier, "object", None) == armature for modifier in obj.modifiers
        ) or any(getattr(constraint, "target", None) == armature
                 for constraint in obj.constraints):
            excluded.add(obj)
    return excluded


def _gyro_cast(context, armature, origin, direction, fallback):
    direction = Vector(direction)
    if direction.length_squared < 1.e-12:
        return Vector(origin)
    direction.normalize()
    # Use Contact's capture radius so a Smart box face already touching or
    # slightly inside a surface does not cast from below that surface.
    hit = _surface_contact_ray_cast(context, Vector(origin) - direction * PIN_SNAP_WORLD_RADIUS,
        direction, max(10000.0, fallback) + PIN_SNAP_WORLD_RADIUS, _gyro_excluded(context, armature))
    return hit[1] if hit is not None else Vector(origin) + direction * fallback


def _gyro_axis(axis):
    result = Vector((0.0, 0.0, 0.0))
    result["XYZ".index(axis[0])] = -1.0 if axis.endswith("NEG") else 1.0
    return result


def _gyro_anchor_and_axis(context, armature, bone, mode, axis):
    anchor, _direction = _gyro_geometry(context, armature, bone, mode, axis)
    return anchor, axis

def _gyro_anchor(context, guide):
    armature, bone = _gyro_owner(guide)
    if bone is None:
        return None
    return (armature.matrix_world @ bone.matrix).translation + guide["gyro_aim_output"].rotation_quaternion.normalized() @ Vector(
        guide.get("gyro_anchor", (0, bone.length * .5, 0)))

def _gyro_animation_binding(obj):
    armature, bone = _gyro_owner(obj)
    property_name = GYRO_TILT_PROPERTY if obj.get("gyro_reference_pin") else GYRO_TARGET_PROPERTY
    return armature, bone, property_name


def _gyro_sync_transform_property(obj):
    armature, bone, property_name = _gyro_animation_binding(obj)
    if bone is None:
        return
    value = obj.rotation_quaternion if property_name == GYRO_TILT_PROPERTY else obj.location
    bone[property_name] = tuple(value)
    armature.update_tag(refresh={"OBJECT"})


def _gyro_key_transform(obj, frame, rotation=False):
    armature, bone, property_name = _gyro_animation_binding(obj)
    if bone is None:
        return
    _gyro_sync_transform_property(obj)
    path = bone.path_from_id(f'["{property_name}"]')
    action = getattr(getattr(armature, "animation_data", None), "action", None)
    existing = {curve.array_index for curve in _action_fcurves(action, armature)
                if curve.data_path == path and _fcurve_key_at(curve, frame) is not None}
    bone.keyframe_insert(data_path=f'["{property_name}"]', frame=frame,
                         group=_constraint_channel_name(bone.name))
    if _pin_marker_value(bone, GYRO_MARKER, frame) > .5:
        _pin_insert_marker_key(bone, GYRO_MARKER, frame, 1.0,
                               group=_constraint_channel_name(bone.name))
    action = getattr(getattr(armature, "animation_data", None), "action", None)
    for curve in _action_fcurves(action, armature):
        if curve.data_path != path:
            continue
        for point in curve.keyframe_points:
            if abs(point.co.x - frame) < 1.e-4 and curve.array_index not in existing:
                _apply_new_motion_key_style(point)
        curve.update()
    guide = _gyro_find(bpy.context, armature, bone)
    if guide is not None:
        _constraint_remember_gyro_markers(guide, bone)


def _gyro_transform_drivers(obj):
    armature, bone, property_name = _gyro_animation_binding(obj)
    rotation = property_name == GYRO_TILT_PROPERTY
    for index in range(4 if rotation else 3):
        driver = obj.driver_add("rotation_quaternion" if rotation else "location", index).driver
        driver.type = "AVERAGE"
        variable = driver.variables.new()
        variable.name = "gyro"
        variable.type = "SINGLE_PROP"
        variable.targets[0].id = armature
        variable.targets[0].data_path = bone.path_from_id(f'["{property_name}"]') + f"[{index}]"


def _gyro_key_enabled(armature, bone, frame, enabled):
    _pin_insert_marker_key(bone, GYRO_MARKER, frame, float(enabled),
                           group=_constraint_channel_name(bone.name))
    _gyro_sync_start_frame(armature, bone)
    guide = _gyro_find(bpy.context, armature, bone)
    if guide is not None:
        _constraint_remember_gyro_markers(guide, bone)


def _gyro_sync_start_frame(armature, bone):
    points = _pin_marker_points(bone, GYRO_MARKER)
    # Remove only the obsolete leading pre-roll sentinel from older Gyro data.
    frames = sorted(points)
    if len(frames) > 1 and points[frames[0]] < .5 and points[frames[1]] > .5 and frames[1]-frames[0] == 1:
        path = bone.path_from_id(f'["{GYRO_MARKER}"]')
        for curve in _action_fcurves(armature.animation_data.action, armature):
            if curve.data_path == path:
                key = _fcurve_key_at(curve, frames[0])
                if key is not None:
                    curve.keyframe_points.remove(key)
                    curve.update()
        points.pop(frames[0])
    start = min(points, default=1048574)
    if bone.get(GYRO_START_PROPERTY) != start:
        bone[GYRO_START_PROPERTY] = start

def _gyro_constraint_driver(constraint, armature, bone):
    # Native evaluation must already be off at End, before frame_post removes
    # the constraint. Display values can be Bézier/target IDs; time bounds are
    # decoded from discrete events and never consume those interpolated values.
    intervals, start = [], None
    for frame, value in sorted(_pin_marker_points(bone, GYRO_MARKER).items()):
        if value >= .5 and start is None:
            start = frame
        elif value < .5 and start is not None:
            intervals.append((start, frame))
            start = None
    if start is not None:
        intervals.append((start, 1048575))
    frame = bpy.context.scene.frame_current_final
    bounds = next((pair for pair in intervals if pair[0] <= frame < pair[1]), None)
    if bounds is None:
        bounds = next((pair for pair in reversed(intervals) if pair[0] <= frame),
                      intervals[0] if intervals else (0, 0))
    expression = f"1.0 if {bounds[0]} <= frame < {bounds[1]} else 0.0"
    animation = getattr(armature, "animation_data", None)
    path = constraint.path_from_id("influence")
    curve = next((c for c in getattr(animation, "drivers", ()) if c.data_path == path), None)
    driver = curve.driver if curve is not None else constraint.driver_add("influence").driver
    if driver.type == "SCRIPTED" and driver.expression == expression:
        return False
    driver.type, driver.expression = "SCRIPTED", expression
    for variable in tuple(driver.variables):
        driver.variables.remove(variable)
    return True

def _gyro_configure(context, guide, mode, axis, distance, recast=True):
    distance = 10.0
    armature, bone = _gyro_owner(guide)
    reference = guide.get("gyro_reference")
    if bone is None or reference is None:
        return
    world = armature.matrix_world @ bone.matrix
    anchor, local_axis = _gyro_geometry(context, armature, bone, mode, axis)
    track_axis = axis
    guide["gyro_local_axis"] = tuple(local_axis)
    guide["gyro_anchor"] = tuple(anchor)
    guide["gyro_position"] = mode
    guide["gyro_axis"] = axis
    guide["gyro_track_axis"] = track_axis
    guide["gyro_distance"] = float(distance)
    constraint = bone.constraints.get(str(guide.get("gyro_aim_constraint", "")))
    if constraint is not None and constraint.type == "DAMPED_TRACK":
        constraint.track_axis = "TRACK_" + ("NEGATIVE_" if track_axis.endswith("NEG") else "") + track_axis[0]
    reference.rotation_quaternion = world.to_quaternion()
    _gyro_sync_transform_property(reference)
    if recast:
        direction = world.to_quaternion() @ local_axis
        origin = world @ anchor
        guide.location = _gyro_cast(context, armature, origin, direction, distance)
    frame = context.scene.frame_current
    _gyro_key_transform(guide, frame)
    _gyro_key_transform(reference, frame, rotation=True)


def _gyro_create(context, armature, bone, mode, axis, distance):
    _constraint_pin_end_other(context, armature, bone, "GYRO")
    guide = _gyro_find(context, armature, bone)
    if guide is None:
        collection = _ensure_space_helper_collection(context, armature)
        digest = hashlib.sha1(f"{armature.name}:{bone.name}:{time.time_ns()}".encode()).hexdigest()[:12]
        guide = bpy.data.objects.new(f"_GyroGuide_{digest}", None)
        reference = bpy.data.objects.new(f"_GyroReference_{digest}", None)
        output = bpy.data.objects.new(f"_GyroSolver_{digest}", None)
        for obj in (guide, reference, output):
            collection.objects.link(obj)
            obj.empty_display_size = 0.0
            obj.hide_render = True
            obj.hide_select = True
            obj.rotation_mode = "QUATERNION"
            obj["gyro_armature"] = armature
            obj["gyro_bone"] = bone.name
            obj.hide_set(True)
        reference["gyro_reference_pin"] = True
        guide["gyro_pin"] = True
        guide["gyro_armature"] = armature
        guide["gyro_bone"] = bone.name
        guide["gyro_reference"] = reference
        guide["gyro_aim_output"] = output
        if GYRO_MARKER not in bone:
            bone[GYRO_MARKER] = 0.0
        bone[GYRO_START_PROPERTY] = context.scene.frame_current
        _gyro_configure(context, guide, mode, axis, distance)
        _gyro_transform_drivers(guide)
        _gyro_transform_drivers(reference)
        stable = bone.constraints.new("COPY_ROTATION")
        stable.name = f"Gyro Stable {guide.name}"
        stable.target = reference
        stable.owner_space = stable.target_space = "WORLD"
        _gyro_constraint_driver(stable, armature, bone)
        aim = bone.constraints.new("COPY_ROTATION")
        aim.name = f"Gyro Aim {guide.name}"
        aim.target = output
        aim.owner_space = aim.target_space = "WORLD"
        _gyro_constraint_driver(aim, armature, bone)
        guide["gyro_stable_constraint"] = stable.name
        guide["gyro_aim_constraint"] = aim.name
        guide["gyro_initial_target"] = tuple(guide.location)
        guide["gyro_initial_tilt"] = tuple(reference.rotation_quaternion)
    else:
        _gyro_configure(context, guide, mode, axis, distance)
    _gyro_key_enabled(armature, bone, context.scene.frame_current, True)
    _gyro_update_aim(context, guide)
    return guide


def _gyro_settings_changed(self, context):
    _gyro_apply_settings(self, context)


def _gyro_apply_settings(self, context, guides_override=None, push_history=True):
    if (_state.get("gyro_syncing") or _state.get("gyro_history")
            or _state.get("gyro_native_history") or context is None):
        return
    selected = _gyro_selected_target(context)
    guides = [selected] if selected is not None else [
        _gyro_find(context, armature, bone) for armature, bone in _gyro_subjects(context)]
    if guides_override is not None:
        guides = guides_override
    changed = False
    bases = _gyro_capture_pose_bases(context)
    _state["gyro_syncing"] = True
    try:
        for guide in guides:
            if guide is not None and _gyro_active(context, guide):
                _gyro_configure(context, guide, self.gyro_pin_mode,
                                self.gyro_facing_axis, self.gyro_sky_distance)
                changed = True
        context.view_layer.update()
        _gyro_restore_pose_bases(context, bases)
        _gyro_seed_baselines(context)
    finally:
        _state["gyro_syncing"] = False
    if changed and push_history:
        try:
            bpy.ops.ed.undo_push(message="Gyro Settings")
        except RuntimeError:
            pass
    _tag_redraw_all_view3d()


def _gyro_draw_ui(layout, context, menu=False, heading=True):
    subjects = _gyro_subjects(context)
    guides = [_gyro_find(context, armature, bone) for armature, bone in subjects]
    active = any(guide is not None and _gyro_authored_active(context, guide) for guide in guides)
    if heading:
        layout.label(text="Gyro", icon="ORIENTATION_GIMBAL")
    if not subjects:
        _draw_selection_hint(layout, "Select a bone.")
        return
    if active and not menu:
        _draw_constraint_settings(layout, context)
    row = layout if menu else layout.row(align=True)
    state = _constraint_selection_state(context)
    _draw_constraint_actions(row, context, state)
    _draw_constraint_clear(layout, state)


class ANIMATOR_UTILS_OT_gyro_start(bpy.types.Operator):
    bl_idname = "staticaliza.gyro_start"
    bl_label = "Gyro"
    bl_description = 'Hold the selected bones in world rotation using directional targets'
    bl_options = {"REGISTER", "UNDO"}

    pin_mode: bpy.props.EnumProperty(name="Start Position", items=GYRO_POSITION_ITEMS, default="MODE_3")
    facing_axis: bpy.props.EnumProperty(name="Axis", items=GYRO_AXIS_ITEMS, default="Z_NEG")
    sky_distance: bpy.props.FloatProperty(default=10.0, min=10.0, max=10.0, options={"HIDDEN"})

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE" and bool(_gyro_subjects(context))

    def draw(self, context):
        self.layout.prop(self, "pin_mode", text="Position")
        self.layout.prop(self, "facing_axis", text="Axis")

    def execute(self, context):
        wm = context.window_manager
        bases = _gyro_capture_pose_bases(context)
        for own, setting in (("pin_mode", "gyro_pin_mode"),
                             ("facing_axis", "gyro_facing_axis")):
            if not self.properties.is_property_set(own):
                setattr(self, own, getattr(wm, setting))
        _state["gyro_syncing"] = True
        try:
            for armature, bone in _constraint_creation_subjects(context):
                _gyro_create(context, armature, bone, self.pin_mode, self.facing_axis, 10.0)
            wm.constraint_pin_type = "GYRO"
            wm.gyro_pin_mode = self.pin_mode
            wm.gyro_facing_axis = self.facing_axis
            wm.gyro_sky_distance = 10.0
            context.view_layer.update()
            _gyro_restore_pose_bases(context, bases)
            _gyro_seed_baselines(context)
            _yellow_refresh_runtime(context)
            _sync_all_dynamic_pose_bone_colors(context.scene.frame_current)
        finally:
            _state["gyro_syncing"] = False
        _tag_redraw_all_view3d()
        return {"FINISHED"}


class ANIMATOR_UTILS_OT_gyro_action(bpy.types.Operator):
    bl_idname = "staticaliza.gyro_action"
    bl_label = "Constraints"
    bl_description = 'Manage the selected Gyro constraints'
    bl_options = {"REGISTER", "UNDO"}
    action: bpy.props.EnumProperty(items=(("END", "Key End", "End the Gyro hold"),
                                         ("CLEAR", "Clear", "Remove Gyro and its keys")), default="END", options={"HIDDEN"})
    insert_bone_keyframe: bpy.props.BoolProperty(
        name="Insert Keyframe", default=True, options={"SKIP_SAVE"},
        description="Key the ending bone pose unless a bone key already exists at that frame")

    def draw(self, context):
        if self.action == "END":
            self.layout.prop(self, "insert_bone_keyframe")

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE" and any(
            _gyro_find(context, armature, bone) is not None
            for armature, bone in _gyro_subjects(context))

    def execute(self, context):
        return _special_end_with_key_option(self, context, self._execute)

    def _execute(self, context):
        state = _constraint_selection_state(context)
        if state["pink"] and state["cyan"]:
            return _constraint_apply_action(context, self.action, self)
        frame = context.scene.frame_current
        _state["gyro_syncing"] = True
        try:
            for armature, bone in _gyro_subjects(context):
                guide = _gyro_find(context, armature, bone)
                if guide is None:
                    continue
                reference = guide.get("gyro_reference")
                visible = armature.evaluated_get(context.evaluated_depsgraph_get()).pose.bones[bone.name].matrix.copy()
                if self.action == "END":
                    _gyro_end(context, armature, bone, guide, frame, visible)
                else:
                    _constraint_remove_gyro(context, guide, visible)
            context.view_layer.update()
            _gyro_seed_baselines(context)
        finally:
            _state["gyro_syncing"] = False
        _tag_redraw_all_view3d()
        return {"FINISHED"}


def _gyro_snap_key(guide):
    return "GYRO:" + guide.name


def _gyro_select(context, guide, extend=False):
    return _pin_select_target(context, _gyro_snap_key(guide), extend=extend)


def _gyro_sync_selection_settings(context, guide):
    _state["gyro_syncing"] = True
    try:
        context.window_manager.constraint_pin_type = "GYRO"
        context.window_manager.gyro_pin_mode = str(guide.get("gyro_position", "MODE_3"))
        context.window_manager.gyro_facing_axis = str(guide.get("gyro_axis", "Z_NEG"))
        context.window_manager.gyro_sky_distance = 10.0
    finally:
        _state["gyro_syncing"] = False
    _tag_redraw_all_view3d()


def _gyro_mouse_target(context, guide, mouse):
    armature, bone = _gyro_owner(guide)
    origin = view3d_utils.region_2d_to_origin_3d(context.region, context.region_data, mouse)
    direction = view3d_utils.region_2d_to_vector_3d(context.region, context.region_data, mouse)
    hit = _surface_contact_ray_cast(context, origin, direction, 100000.0, _gyro_excluded(context, armature))
    if hit is not None:
        return hit[1]
    center = armature.matrix_world @ bone.head
    radius = 10.0
    offset = origin - center
    along = offset.dot(direction)
    discriminant = along * along - offset.length_squared + radius * radius
    if discriminant >= 0.0:
        distance = -along + math.sqrt(discriminant)
        if distance > 0.0:
            return origin + direction * distance
    closest = origin + direction * max(0.0, -along)
    aim = closest - center
    if aim.length_squared < 1.e-10:
        aim = direction
    return center + aim.normalized() * radius


class ANIMATOR_UTILS_OT_gyro_move(bpy.types.Operator):
    bl_idname = "staticaliza.gyro_move"
    bl_label = "Move Gyro Target"
    bl_description = 'Move the directional target'
    bl_options = {"REGISTER", "UNDO", "BLOCKING"}
    initial_axis: bpy.props.IntProperty(default=-1, min=-1, max=2, options={"HIDDEN", "SKIP_SAVE"})
    initial_plane_axis: bpy.props.IntProperty(default=-1, min=-1, max=2, options={"HIDDEN", "SKIP_SAVE"})
    guide_name: bpy.props.StringProperty(options={"HIDDEN", "SKIP_SAVE"})
    location: bpy.props.FloatVectorProperty(name="Target", size=3, subtype="TRANSLATION")
    finish_on_release: bpy.props.BoolProperty(default=False, options={"HIDDEN"})
    transform_mode: bpy.props.EnumProperty(items=(("TRANSLATE", "Move", "Move the target"),
        ("ROTATE", "Rotate", "Rotate the target and tilt around its bone")), default="TRANSLATE",
        options={"HIDDEN", "SKIP_SAVE"})

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE" and bool(_gyro_visible(context))

    def execute(self, context):
        guide = bpy.data.objects.get(self.guide_name)
        if guide is None or not guide.get("gyro_pin", False):
            return {"CANCELLED"}
        bases = _gyro_capture_pose_bases(context)
        guide.location = self.location
        _gyro_key_transform(guide, context.scene.frame_current)
        context.view_layer.update()
        _gyro_restore_pose_bases(context, bases)
        _gyro_seed_baselines(context)
        return {"FINISHED"}

    def invoke(self, context, event):
        guide = bpy.data.objects.get(self.guide_name) if self.guide_name else _gyro_selected_target(context)
        if event.type == "LEFTMOUSE" and not self.guide_name and guide is None:
            guide = _gyro_target_at_mouse(context, (event.mouse_region_x, event.mouse_region_y))
        if guide is None:
            return {"PASS_THROUGH"}
        self.guide_name = guide.name
        self.initial = tuple(guide.location)
        self.initial_mouse = (event.mouse_region_x, event.mouse_region_y)
        self.moved = False
        _gyro_begin_target_transform(self, context, guide, event)
        self.axis_index = self.initial_axis
        self.plane_axis_index = self.initial_plane_axis
        _pin_transform_update_constraint_overlay(self, context)
        _gyro_select(context, guide)
        _state["gyro_dragging"] = True
        _state["gyro_drag_frame"] = context.scene.frame_current
        _state["pin_target_dragging"] = True
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        guide = bpy.data.objects.get(self.guide_name)
        if guide is None:
            self._finish(context)
            return {"CANCELLED"}
        if event.type in {"ESC", "RIGHTMOUSE"}:
            guide.location = self.initial
            guide["gyro_reference"].rotation_quaternion = self.initial_tilt
            self._finish(context)
            return {"CANCELLED"}
        if event.type in {"X", "Y", "Z"} and event.value == "PRESS":
            axis = "XYZ".index(event.type)
            self.axis_index = -1 if self.axis_index == axis else axis
            self.plane_axis_index = -1
            _pin_transform_update_constraint_overlay(self, context)
            return {"RUNNING_MODAL"}
        if event.type == "MOUSEMOVE":
            mouse = (event.mouse_region_x, event.mouse_region_y)
            if (Vector(mouse) - Vector(self.initial_mouse)).length > 3.0:
                self.moved = True
            if self.moved:
                _gyro_apply_target_transform(self, context, guide, event)
                _pin_transform_update_constraint_overlay(self, context)
                context.view_layer.update()
                _tag_redraw_all_view3d()
        if ((event.type == "LEFTMOUSE" and event.value == ("RELEASE" if self.finish_on_release else "PRESS"))
                or event.type in {"RET", "NUMPAD_ENTER"}):
            bases = _gyro_capture_pose_bases(context)
            self.location = guide.location
            if self.moved:
                _gyro_key_transform(guide, context.scene.frame_current)
                if self.transform_mode == "ROTATE":
                    _gyro_key_transform(guide["gyro_reference"], context.scene.frame_current)
            self._finish(context, bases)
            return {"FINISHED"}
        return {"RUNNING_MODAL"}

    def _finish(self, context, bases=None):
        guide = bpy.data.objects.get(self.guide_name)
        if guide is not None:
            _gyro_preview_drivers(guide, False)
            _gyro_update_aim(context, guide)
        _state["pin_transform_constraint"] = None
        _state["gyro_dragging"] = False
        _state.pop("gyro_drag_frame", None)
        _state["pin_target_dragging"] = False
        context.view_layer.update()
        if bases is not None:
            _gyro_restore_pose_bases(context, bases)
        _gyro_seed_baselines(context)
        _tag_redraw_all_view3d()


class ANIMATOR_UTILS_OT_gyro_key_target(bpy.types.Operator):
    bl_idname = "staticaliza.gyro_key_target"
    bl_label = "Insert Keyframe"
    bl_description = "Insert animation keys for the selected Gyro target and tilt"
    bl_options = {"REGISTER", "UNDO", "INTERNAL"}

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE" and _gyro_selected_target(context) is not None

    def execute(self, context):
        bases = _gyro_capture_pose_bases(context)
        guide = _gyro_selected_target(context)
        _gyro_key_transform(guide, context.scene.frame_current)
        reference = guide.get("gyro_reference")
        if reference is not None:
            _gyro_key_transform(reference, context.scene.frame_current, rotation=True)
        _gyro_restore_pose_bases(context, bases)
        return {"FINISHED"}


class ANIMATOR_UTILS_GT_gyro_target(bpy.types.Gizmo):
    bl_idname = "ANIMATOR_UTILS_GT_gyro_target"
    __slots__ = ("diamond", "guide_name", "target_key", "extend_selection",
                 "axis_index", "initial_mouse", "drag_started", "axes_were_visible")

    def setup(self):
        self.diamond = self.new_custom_shape("TRIS", _PIN_GIZMO_DIAMOND_VERTICES)
        self.guide_name = ""
        self.axis_index = -1

    def draw(self, context):
        _pin_gizmo_update_hover_cursor(context, self)
        matrix = _gyro_target_draw_matrix(self)
        if matrix is not None:
            self.draw_custom_shape(self.diamond, matrix=matrix)

    def draw_select(self, context, select_id):
        matrix = _gyro_target_draw_matrix(self)
        if matrix is not None:
            self.draw_custom_shape(self.diamond, matrix=matrix, select_id=select_id)

    def test_select(self, context, location):
        guide = _gyro_target_at_mouse(context, location)
        return 0 if guide is not None and guide.name == self.guide_name else -1

    def invoke(self, context, event):
        guide = bpy.data.objects.get(self.guide_name)
        if guide is None or not _gyro_active(context, guide):
            return {"CANCELLED"}
        self.target_key = _gyro_snap_key(guide)
        was_selected = self.target_key in _pin_selected_target_keys()
        _pin_gizmo_begin_interaction(self, event, context)
        if event.shift:
            _pin_gizmo_finish_interaction(self, False)
            return {"FINISHED"}
        _pin_deselect_pose_bones(context)
        _state["pin_gizmo_selection_keys"] = _pin_pose_selection_signature(context)
        result = bpy.ops.staticaliza.transform_selected_pin(
            "INVOKE_DEFAULT", transform_mode="TRANSLATE", finish_on_release=True,
            exclusive_pin_selection=not was_selected)
        return {"FINISHED"} if "RUNNING_MODAL" in result else {"CANCELLED"}

    def modal(self, context, event, tweak):
        # A tweak callback makes Blender route this custom center through
        # invoke; the registered shared operator owns every actual drag.
        return {"CANCELLED"}


class ANIMATOR_UTILS_GGT_gyro_target(bpy.types.GizmoGroup):
    bl_idname = "ANIMATOR_UTILS_GGT_gyro_target"
    bl_label = "Gyro Target"
    bl_space_type = "VIEW_3D"
    bl_region_type = "WINDOW"
    bl_options = {"3D", "SELECT", "PERSISTENT"}

    @classmethod
    def poll(cls, context):
        return context.mode == "POSE"

    def setup(self, context):
        self.targets = {}

    def draw_prepare(self, context):
        if _pin_gizmo_hide_for_animation(self, context):
            return
        keyboard = (_state.get("pin_keyboard_transform_active", False)
                    and not _state.get("pin_transform_from_gizmo", False))
        if keyboard:
            for gizmo in self.targets.values():
                _pin_gizmo_set_if_changed(gizmo, "hide", True)
                _pin_gizmo_set_if_changed(gizmo, "hide_select", True)
            return
        if (not _state.get("pin_target_dragging", False)
                and (_pin_primary_mouse_pressed() or _window_manager_has_modal_operator(context))):
            return
        visible = {guide.name: guide for guide in _gyro_visible(context)}
        for name, gizmo in self.targets.items():
            _pin_gizmo_set_if_changed(gizmo, "hide", name not in visible)
            _pin_gizmo_set_if_changed(gizmo, "hide_select", name not in visible)
        for name, guide in visible.items():
            gizmo = self.targets.get(name)
            if gizmo is None:
                gizmo = self.gizmos.new(ANIMATOR_UTILS_GT_gyro_target.bl_idname)
                gizmo.guide_name = name
                gizmo.color = GYRO_COLOR[:3]
                gizmo.color_highlight = (0.6, 1.0, 1.0)
                gizmo.alpha = 0.9
                gizmo.alpha_highlight = 1.0
                gizmo.scale_basis = PIN_GIZMO_DIAMOND_SCALE
                gizmo.use_draw_modal = True
                gizmo.use_event_handle_all = False
                _pin_gizmo_configure_undo(gizmo, False)
                gizmo.select_bias = PIN_GIZMO_CENTER_SELECT_BIAS
                self.targets[name] = gizmo
            _pin_gizmo_set_if_changed(gizmo, "matrix_basis", Matrix.Translation(guide.location))
            _pin_gizmo_set_if_changed(gizmo, "alpha",
                1.0 if _gyro_snap_key(guide) in _pin_selected_target_keys() else 0.36)


def _draw_gyro_pins(context):
    # Drawing does not confer selection or transform access. Keep the normal
    # selected-bone/pin visibility scope while editable gizmos remain hidden.
    guides = (() if context.mode != "POSE" or _context_is_presentation_view(context)
              else tuple(data[3] for data in _pin_available_target_data(context).values()
                         if data[0] == "GYRO" and (
                             not _constraint_bone_ragdoll_override(data[1], data[2], context.scene.frame_current)) and (
                             _owner_bone_key(data[1], data[2].name) in _selected_owner_bone_keys(context)
                             or _gyro_snap_key(data[3]) in _pin_selected_target_keys())))
    if not guides:
        return
    lines = []
    circles = []
    for guide in guides:
        start = _gyro_anchor(context, guide)
        end = guide.location.copy()
        if start is None:
            continue
        lines.append((start, end, GYRO_COLOR, 2))
        for point in (start, end):
            screen = view3d_utils.location_3d_to_region_2d(context.region, context.region_data, point)
            if screen is not None:
                circles.extend(_circle_tris_2d(screen, PIN_DOT_PIXEL_RADIUS))
    _draw_depth_sorted_pin_lines(context, lines)
    if circles:
        shader = _ensure_shader_2d()
        shader.bind()
        shader.uniform_float("u_viewport", (float(context.region.width), float(context.region.height)))
        shader.uniform_float("color", GYRO_COLOR)
        gpu.state.line_width_set(2.0)
        batch_for_shader(shader, "TRIS", {"pos": circles}).draw(shader)


def _gyro_export_bones(armature):
    return {str(guide.get("gyro_bone", "")) for guide in _gyro_guides()
            if guide.get("gyro_armature") == armature}
