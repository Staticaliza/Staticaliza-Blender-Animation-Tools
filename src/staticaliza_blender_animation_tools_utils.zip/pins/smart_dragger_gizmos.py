"""Selection and live display of paired Smart Dragger handles."""

from ..core.runtime import *  # noqa: F403

class ANIMATOR_UTILS_GT_smart_dragger(bpy.types.Gizmo):
    bl_idname = "ANIMATOR_UTILS_GT_smart_dragger"

    __slots__ = (
        "diamond_shape",
        "side",
    )

    def setup(self):
        if not hasattr(self, "diamond_shape"):
            self.diamond_shape = self.new_custom_shape(
                "TRIS",
                _PIN_GIZMO_DIAMOND_VERTICES,
            )

    def draw(self, context):
        _pin_gizmo_update_hover_cursor(context, self)
        self.draw_custom_shape(self.diamond_shape)

    def draw_select(self, _context, select_id):
        self.draw_custom_shape(self.diamond_shape, select_id=select_id)
class ANIMATOR_UTILS_GGT_smart_draggers(bpy.types.GizmoGroup):
    bl_idname = "ANIMATOR_UTILS_GGT_smart_draggers"
    bl_label = "Smart Dragger"
    bl_space_type = "VIEW_3D"
    bl_region_type = "WINDOW"
    bl_options = {"3D", "SELECT", "PERSISTENT"}

    @classmethod
    def poll(cls, context):
        return getattr(context, "mode", "") == "POSE"

    def setup(self, context):
        self.draggers = []
        for side, color in ((0, SMART_DRAGGER_RED), (1, SMART_DRAGGER_GREEN)):
            gizmo = self.gizmos.new(ANIMATOR_UTILS_GT_smart_dragger.bl_idname)
            gizmo.side = side
            gizmo.color = color
            gizmo.color_highlight = color
            gizmo.alpha = 1.0
            gizmo.alpha_highlight = 1.0
            gizmo.scale_basis = PIN_GIZMO_DIAMOND_SCALE
            gizmo.line_width = 2.5
            gizmo.select_bias = PIN_GIZMO_CENTER_SELECT_BIAS
            gizmo.use_draw_modal = True
            gizmo.use_event_handle_all = False
            gizmo.hide = True
            gizmo.hide_select = True
            operator = gizmo.target_set_operator(
                "staticaliza.smart_dragger_transform"
            )
            operator.transform_mode = "TRANSLATE"
            operator.initial_axis = -1
            operator.dragger_side = side
            operator.finish_on_release = True
            self.draggers.append(gizmo)

    def draw_prepare(self, context):
        if _pin_gizmo_hide_for_animation(self, context):
            return
        armature, bone = _smart_dragger_active_pose(context)
        if (armature is None or bone is None
                or _smart_dragger_contact_owned(context, armature, bone)):
            for gizmo in self.draggers:
                _pin_gizmo_set_if_changed(gizmo, "hide", True)
                _pin_gizmo_set_if_changed(gizmo, "hide_select", True)
                _pin_gizmo_set_if_changed(gizmo, "select", False)
            return
        if not getattr(
            getattr(context, "window_manager", None),
            "smart_draggers_enabled",
            False,
        ):
            # A native G/R/S press can arrive before this persistent gizmo
            # group receives its normal disabled draw pass. Hide first so a
            # stale/default red or green diamond cannot flash at the moving
            # bone endpoint for the duration of Blender's modal interaction.
            for gizmo in self.draggers:
                _pin_gizmo_set_if_changed(gizmo, "hide", True)
                _pin_gizmo_set_if_changed(gizmo, "hide_select", True)
                _pin_gizmo_set_if_changed(gizmo, "select", False)
            return
        if (
            _state.get("smart_dragger_transform_active", False)
            and not _state.get("smart_dragger_target_drag_active", False)
            and not _smart_dragger_modal_is_running(context)
        ):
            # Blender can terminate a gizmo modal without returning through
            # our finish path (workspace/file changes and interrupted clicks
            # are common examples). Recover immediately so the persistent
            # red diamond does not remain hidden behind stale runtime state.
            _state["smart_dragger_transform_active"] = False
            _state["smart_dragger_from_gizmo"] = False
            _state["smart_dragger_target_drag_active"] = False
        if (
            _state.get("smart_dragger_transform_active", False)
            and not _state.get("smart_dragger_target_drag_active", False)
            and not _state.get("smart_dragger_from_gizmo", False)
        ):
            for gizmo in self.draggers:
                _pin_gizmo_set_if_changed(gizmo, "hide", True)
                _pin_gizmo_set_if_changed(gizmo, "hide_select", True)
                _pin_gizmo_set_if_changed(gizmo, "select", False)
            return
        if not _state.get("smart_dragger_transform_active", False):
            transform_operator = _pin_active_transform_operator(context)
            if transform_operator:
                # Keep drawing state and hit-test flags untouched while
                # Blender owns the native modal interaction, but refresh the
                # evaluated matrices on every draw so the diamonds follow
                # their moving welded owner instead of jumping on confirm.
                if not _smart_dragger_refresh_live_gizmos(
                    context,
                    self.draggers,
                ):
                    for gizmo in self.draggers:
                        _pin_gizmo_set_if_changed(gizmo, "hide", True)
                        _pin_gizmo_set_if_changed(gizmo, "hide_select", True)
                return
            if _window_manager_has_modal_operator(context) or _pin_primary_mouse_pressed():
                return
        data = _smart_dragger_data(context)
        if data is None:
            for gizmo in self.draggers:
                _pin_gizmo_set_if_changed(gizmo, "hide", True)
                _pin_gizmo_set_if_changed(gizmo, "hide_select", True)
                _pin_gizmo_set_if_changed(gizmo, "select", False)
            return
        selected_sides = _smart_dragger_selected_sides()
        transform_active = bool(_state.get("smart_dragger_transform_active", False))
        red_contact_plane = _smart_dragger_red_contact_plane(context, data)
        for side, gizmo in enumerate(self.draggers):
            matrix = data["matrices"][side]
            if side == 0 and red_contact_plane is not None:
                matrix = _smart_dragger_surface_contact_matrix(
                    matrix,
                    red_contact_plane,
                )
            _pin_gizmo_set_if_changed(gizmo, "matrix_basis", matrix)
            _pin_gizmo_set_if_changed(
                gizmo,
                "alpha",
                1.0 if side in selected_sides else 0.36,
            )
            _pin_gizmo_set_if_changed(gizmo, "hide", False)
            _pin_gizmo_set_if_changed(
                gizmo,
                "hide_select",
                transform_active,
            )
            _pin_gizmo_set_if_changed(
                gizmo,
                "select",
                False,
            )
            _pin_gizmo_set_if_changed(
                gizmo,
                "scale_basis",
                PIN_GIZMO_DIAMOND_SCALE,
            )
