"""Blender-library plane and view-ring widgets for virtual pin transforms."""

from ..core.runtime import *  # noqa: F403


def _pin_native_extra_widgets(group, operator_id, moves, rotations, colors):
    for axis, color in enumerate(colors):
        plane = group.gizmos.new("GIZMO_GT_primitive_3d")
        plane.draw_style = "PLANE"
        plane.color = plane.color_highlight = color
        plane.alpha, plane.alpha_highlight = .35, .8
        plane.scale_basis = PIN_GIZMO_AXIS_SCALE * .15
        plane.use_draw_offset_scale = True
        plane.matrix_offset = Matrix.Translation((2.5, 2.5, 0))
        plane.use_draw_modal = True
        plane.use_event_handle_all = False
        plane.hide = plane.hide_select = True
        plane.select_bias = 1.0
        operator = plane.target_set_operator(operator_id)
        operator.transform_mode = "TRANSLATE"
        operator.initial_plane_axis = axis
        operator.finish_on_release = True
        moves.append(plane)
    ring = group.gizmos.new("GIZMO_GT_dial_3d")
    ring.color = ring.color_highlight = (.8, .8, .8)
    ring.alpha, ring.alpha_highlight = .5, 1.0
    ring.scale_basis = PIN_GIZMO_AXIS_SCALE * 1.2
    ring.line_width = 2.5
    ring.select_bias = 1.0
    ring.use_draw_modal = ring.use_draw_value = True
    ring.use_event_handle_all = False
    ring.hide = ring.hide_select = True
    operator = ring.target_set_operator(operator_id)
    operator.transform_mode = "ROTATE"
    operator.initial_axis = -1
    operator.finish_on_release = True
    rotations.append(ring)


def _pin_native_widget_matrix(context, point, orientation, index, rotation=False):
    if rotation and index == 3:
        return _pin_gizmo_axis_matrix(point, _pin_keyboard_view_axis(context))
    if index < 3:
        return _pin_gizmo_axis_matrix(point, orientation.col[index])
    normal = index-3
    matrix = Matrix.Identity(4)
    matrix.col[0][:3] = orientation.col[(normal+1) % 3]
    matrix.col[1][:3] = orientation.col[(normal+2) % 3]
    matrix.col[2][:3] = orientation.col[normal]
    matrix.translation = point
    return matrix
