"""Reversible routing of standard animation menu clipboard actions."""

from ..core.runtime import *  # noqa: F403


class _MirrorMenuProperties:
    def __init__(self, properties):
        object.__setattr__(self, '_properties', properties)

    def __getattr__(self, name):
        if name == 'flipped':
            return self._properties.action == 'PASTE_FLIPPED'
        return getattr(self._properties, name)

    def __setattr__(self, name, value):
        if name == 'flipped':
            self._properties.action = 'PASTE_FLIPPED' if value else 'PASTE'
        else:
            setattr(self._properties, name, value)


def _mirror_menu_operator(layout, context, operator, *args, **kwargs):
    try:
        enabled = bpy.ops.staticaliza.pose_pin_clipboard.poll()
    except (AttributeError, RuntimeError):
        enabled = False
    if not enabled:
        return layout.operator(operator, *args, **kwargs)
    native = getattr(getattr(bpy.ops, operator.split('.')[0]), operator.split('.')[1])
    kwargs.setdefault('text', native.get_rna_type().name)
    properties = layout.operator('staticaliza.pose_pin_clipboard', *args, **kwargs)
    properties.action = 'COPY' if operator.endswith('.copy') else 'PASTE'
    return _MirrorMenuProperties(properties)


def _mirror_install_menu_actions():
    """Patch native draw functions in place, preserving appended menu callbacks."""
    if _state.get('mirror_menu_patches'):
        return
    import ast
    import inspect
    import textwrap
    names = ('VIEW3D_MT_pose', 'VIEW3D_MT_pose_context_menu',
             'DOPESHEET_MT_key', 'DOPESHEET_MT_context_menu',
             'GRAPH_MT_key', 'GRAPH_MT_context_menu')
    operators = {'pose.copy', 'pose.paste', 'action.copy', 'action.paste', 'graph.copy', 'graph.paste'}
    helper = '_staticaliza_mirror_menu_operator'
    patches, namespaces = [], {}
    context_parameter = 'context'
    class Redirect(ast.NodeTransformer):
        def visit_Call(self, node):
            self.generic_visit(node)
            if (isinstance(node.func, ast.Attribute) and node.func.attr == 'operator'
                    and node.args and isinstance(node.args[0], ast.Constant)
                    and node.args[0].value in operators):
                return ast.copy_location(ast.Call(func=ast.Name(id=helper, ctx=ast.Load()),
                    args=[node.func.value, ast.Name(id=context_parameter, ctx=ast.Load()), *node.args],
                    keywords=node.keywords), node)
            return node
    for name in names:
        menu = getattr(bpy.types, name, None)
        draw = getattr(menu, 'draw', None)
        for function in getattr(draw, '_draw_funcs', (draw,)):
            if function is None or not getattr(function, '__module__', '').startswith('bl_ui.'):
                continue
            if any(p[0] is function for p in patches) or function.__code__.co_freevars:
                continue
            try:
                source = textwrap.dedent(inspect.getsource(function))
                tree = ast.parse(source)
                node = next(n for n in tree.body if isinstance(n, ast.FunctionDef))
                context_parameter = node.args.args[1].arg
                node.decorator_list = []
                tree = ast.fix_missing_locations(Redirect().visit(tree))
                if not any(isinstance(n, ast.Name) and n.id == helper for n in ast.walk(tree)):
                    continue
                namespace = function.__globals__
                prepared = dict(namespace)
                exec(compile(tree, function.__code__.co_filename, 'exec'), prepared)
                replacement = prepared[node.name].__code__
                namespaces.setdefault(id(namespace), (namespace, namespace.get(helper)))
                namespace[helper] = _mirror_menu_operator
                original = function.__code__
                function.__code__ = replacement
                patches.append((function, original, replacement))
            except (OSError, TypeError, ValueError, SyntaxError, StopIteration):
                continue
    _state['mirror_menu_patches'] = patches
    _state['mirror_menu_namespaces'] = tuple(namespaces.values())


def _mirror_restore_menu_actions():
    for key in ('mirror_rig_rest_cache', 'mirror_operation_rest',
                'mirror_curve_sample_budget', 'mirror_unmatched_bones',
                'mirror_missing_pins', 'mirror_pasted_rows', 'mirror_curve_limited'):
        _state.pop(key, None)
    patches = _state.pop('mirror_menu_patches', ())
    for function, original, replacement in patches:
        if function.__code__ is replacement:
            function.__code__ = original
    helper = '_staticaliza_mirror_menu_operator'
    for namespace, previous in _state.pop('mirror_menu_namespaces', ()):
        if namespace.get(helper) is not _mirror_menu_operator:
            continue
        if any(function.__globals__ is namespace and helper in function.__code__.co_names
               for function, _original, _replacement in patches):
            continue
        if previous is None:
            namespace.pop(helper, None)
        else:
            namespace[helper] = previous
