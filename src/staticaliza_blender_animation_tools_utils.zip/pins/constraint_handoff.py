"""One-time retirement of the old procedural End-pose runtime."""
from ..core.runtime import *  # noqa: F403


def _special_end_underlying_factor(context, armature, bone, frame, role):
    """Return the ordinary relationship, without an outgoing-pose offset."""
    constraints = _internal_space_constraints(bone)
    underlying = next((c for c in constraints
                       if _dynamic_space_source(bone, c) == SPACE_SOURCE_BASE), None)
    if role == SPACE_ROLE_UNPARENT:
        underlying = _marker_aware_internal_constraint(bone, constraints, frame)
    if underlying is None:
        return Matrix.Identity(4)
    target = _dynamic_parent_constraint_target(bone, underlying)
    factor = _pose_space_target_matrix(context, armature, target,
        _dynamic_parent_constraint_subtarget(bone, underlying)) @ underlying.inverse_matrix
    return factor


def _special_end_space_key(constraint):
    return hashlib.sha256(constraint.name.encode("utf-8")).hexdigest()[:48]


def _special_end_space_is_explicit(bone, constraint):
    return bool(bone.get("_staticaliza_explicit_end_spaces", {}).get(_special_end_space_key(constraint), False))


def _special_end_previous_pose(context, armature, bone, frame):
    """Sample the last active frame only during an explicit End operation."""
    scene = context.scene
    saved_frame, subframe = scene.frame_current, scene.frame_subframe
    bases = _pin_capture_action_pose_bases((armature,))
    previous = _state.get("ragdoll_syncing", False)
    previous_baking = _state.get("ragdoll_baking", False)
    try:
        # Permit the normal solver to evaluate the last active sample.
        _state["ragdoll_syncing"] = False
        _state["ragdoll_baking"] = True
        scene.frame_set(int(frame)-1)
        _sync_dynamic_parent_constraints(int(frame)-1, armature)
        published=_state.get('ragdoll_published_poses',{}).get(_ragdoll_state_key(armature,bone))
        if (_ragdoll_active(bone,int(frame)-1) and published is not None
                and int(published[0])==int(frame)-1):
            # Orange owns this pose. Replaying ordinary channel isolation after
            # its publication can move a managed carrier under an already
            # solved body. Capture the solver's exact output at the boundary.
            world=armature.matrix_world@published[1]
            return armature.matrix_world.inverted_safe()@world
        _special_end_restore_simulation_inputs(context, int(frame)-1)
        context.view_layer.update()
        evaluated = armature.evaluated_get(context.evaluated_depsgraph_get())
        world = evaluated.matrix_world @ evaluated.pose.bones[bone.name].matrix
    finally:
        scene.frame_set(saved_frame, subframe=subframe)
        _sync_dynamic_parent_constraints(saved_frame, armature)
        _state["ragdoll_syncing"] = previous
        _state["ragdoll_baking"] = previous_baking
        _pin_restore_action_pose_bases(context, bases)
    return armature.matrix_world.inverted_safe() @ world


def _constraint_handoff_start(context):
    """Keep existing normal keys; discard only obsolete hidden release data."""
    for name in ("constraint_release_cache", "constraint_release_published_inputs",
                 "constraint_release_ragdoll_samples"):
        _state.pop(name, None)
    for obj in tuple(context.scene.objects):
        owners = (obj, *tuple(obj.pose.bones)) if obj.type == "ARMATURE" and obj.pose else (obj,)
        for owner in owners:
            for prop in ("_constraint_release_inputs", "_staticaliza_constraint_end_keys",
                         "_staticaliza_handoff_sources"):
                if prop in owner:
                    del owner[prop]
            if isinstance(owner, bpy.types.PoseBone):
                constraints = _internal_space_constraints(owner)
                base = next((c for c in constraints if _dynamic_space_source(owner,c)==SPACE_SOURCE_BASE),None)
                if base is None:
                    continue
                for constraint in constraints:
                    if constraint==base or _special_end_space_is_explicit(owner,constraint):
                        continue
                    role=_dynamic_space_role(owner,constraint)
                    if role not in {SPACE_ROLE_NORMAL,SPACE_ROLE_WORLD}:
                        continue
                    # Old End spaces encoded the outgoing pose in their inverse.
                    # Retire that hidden hold without inserting any new keys.
                    if role==SPACE_ROLE_NORMAL:
                        constraint.inverse_matrix=base.inverse_matrix.copy()
                    else:
                        target=_dynamic_parent_constraint_target(owner,constraint)
                        base_target=_dynamic_parent_constraint_target(owner,base)
                        if target is not None and base_target is not None:
                            target.matrix_basis=base_target.matrix_basis.copy()
                    if "_staticaliza_explicit_end_spaces" not in owner:
                        owner["_staticaliza_explicit_end_spaces"]={}
                    owner["_staticaliza_explicit_end_spaces"][_special_end_space_key(constraint)]=True


@persistent
def _special_end_load_post(*args):
    _constraint_handoff_start(bpy.context)
