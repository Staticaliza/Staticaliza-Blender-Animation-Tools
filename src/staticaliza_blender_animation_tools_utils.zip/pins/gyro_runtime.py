"""Native Gyro previews, release commits, and exact pending-edit history recovery."""

from ..core.runtime import *  # noqa: F403

def _gyro_capture_pose_bases(context):
    """Plain values only: an Action refresh also evaluates unrelated bones."""
    owners = {armature for guide in _gyro_guides(context.scene)
              if (armature := _gyro_owner(guide)[0]) is not None}
    if context.mode == "POSE":
        owners.update(armature for armature, _bone in _gyro_subjects(context))
    return _pin_capture_action_pose_bases(owners)


def _gyro_restore_pose_bases(context, bases):
    # Only Gyro custom channels were keyed. Native pose channels, including
    # Contact's solved pink limbs, remain authoritative through that refresh.
    _pin_restore_action_pose_bases(context, bases)

def _gyro_seed_baselines(context):
    baselines = {}
    world_baselines = {}
    for guide in _gyro_guides(context.scene):
        armature, bone = _gyro_owner(guide)
        if bone is None:
            continue
        baselines[guide.name] = bone.matrix_basis.copy()
        world_baselines[guide.name] = _gyro_raw_world(armature, bone).copy()
    _state["gyro_baselines"] = baselines
    _state["gyro_world_baselines"] = world_baselines


def _gyro_key_snapshot(obj, frame):
    armature, bone, property_name = _gyro_animation_binding(obj)
    action = getattr(getattr(armature, "animation_data", None), "action", None)
    path = bone.path_from_id(f'["{property_name}"]')
    return {(curve.data_path, curve.array_index): tuple(
        (tuple(point.co), point.interpolation, point.handle_left_type, point.handle_right_type)
        for point in curve.keyframe_points if abs(point.co.x - frame) < 1.e-4
    ) for curve in _action_fcurves(action, armature) if curve.data_path == path}


def _gyro_restore_keys(obj, frame, snapshot):
    armature, bone, property_name = _gyro_animation_binding(obj)
    action = getattr(getattr(armature, "animation_data", None), "action", None)
    path = bone.path_from_id(f'["{property_name}"]')
    for curve in _action_fcurves(action, armature):
        if curve.data_path != path:
            continue
        for point in tuple(curve.keyframe_points):
            if abs(point.co.x - frame) < 1.e-4:
                curve.keyframe_points.remove(point, fast=True)
        for co, interpolation, left, right in snapshot.get((curve.data_path, curve.array_index), ()):
            point = curve.keyframe_points.insert(*co)
            point.interpolation = interpolation
            point.handle_left_type = left
            point.handle_right_type = right
        curve.update()


def _gyro_preview_drivers(guide, preview):
    for obj in (guide, guide.get("gyro_reference")):
        animation = getattr(obj, "animation_data", None)
        for curve in getattr(animation, "drivers", ()):
            if curve.data_path in {"location", "rotation_quaternion"}:
                curve.mute = preview


def _gyro_clear_preview(guide):
    for key in ("gyro_preview_frame", "gyro_preview_target", "gyro_preview_tilt"):
        if key in guide:
            del guide[key]


def _gyro_apply_native_rotation(context, guide, snapshot):
    armature, bone = _gyro_owner(guide)
    reference = guide.get("gyro_reference")
    if bone is None or reference is None:
        return
    old_world = snapshot.get("world", _gyro_raw_world(armature, bone, snapshot["basis"]))
    world = _gyro_raw_world(armature, bone)
    world_delta = world.to_quaternion() @ old_world.to_quaternion().inverted()
    old_rotation = snapshot["reference"].to_quaternion()
    orientation = world_delta @ old_rotation
    orientation.make_compatible(old_rotation)
    reference.rotation_quaternion = orientation
    if "translate" in snapshot.get("operator", "").lower():
        guide.location = snapshot["target"].translation + world.translation - snapshot["pivot"]
    else:
        local_anchor = Vector(guide.get("gyro_anchor", (0, 0, 0)))
        old_aim = snapshot.get("aim_rotation", old_rotation)
        old_anchor = snapshot["pivot"] + old_aim @ local_anchor
        anchor = world.translation + (world_delta @ old_aim) @ local_anchor
        direction = world_delta @ (snapshot["target"].translation - old_anchor)
        guide.location = _gyro_cast(context, armature, anchor, direction, max(direction.length, .001))
    _gyro_update_aim(context, guide)
    # Never dirty the owning action during a native transform. It replays keyed
    # pose channels over Blender's in-progress mouse sample, causing stutter.
    snapshot["changed"] = True
    # Native Undo may capture the last preview before our release poll commits
    # its action keys. Keep that explicit authored sample with the undo data.
    guide["gyro_preview_frame"] = int(snapshot["frame"])
    guide["gyro_preview_target"] = tuple(guide.location)
    guide["gyro_preview_tilt"] = tuple(reference.rotation_quaternion)


def _gyro_observe_rotation(context):
    if (_state.get("gyro_syncing") or _state.get("gyro_history")
            or context.mode != "POSE" or _animation_playback_active(context)):
        return
    identifier = _pin_active_transform_operator(context)
    rotating = any(kind in identifier.lower() for kind in ("rotate", "trackball", "translate"))
    session = _state.get("gyro_native_session")
    frame = context.scene.frame_current
    if session is not None and (not rotating or session["frame"] != frame):
        _state["gyro_native_session"] = None
        confirmed = (session["frame"] == frame
                     and _pin_transform_operator_finished(context, session["token"]))
        _state["gyro_syncing"] = True
        try:
            bases = _gyro_capture_pose_bases(context)
            for name, snapshot in session["guides"].items():
                guide = bpy.data.objects.get(name)
                reference = guide.get("gyro_reference") if guide is not None else None
                if reference is not None:
                    if confirmed and snapshot.get("changed"):
                        owner, bone = _gyro_owner(guide)
                        bases[(owner.name, bone.name)] = bone.matrix_basis.copy()
                        _gyro_key_transform(guide, frame)
                        _gyro_key_transform(reference, frame, rotation=True)
                    else:
                        guide.matrix_world = snapshot["target"]
                        reference.matrix_world = snapshot["reference"]
                    _gyro_preview_drivers(guide, False)
                    _gyro_clear_preview(guide)
            _gyro_restore_pose_bases(context, bases)
            _gyro_update_aims(context)
            context.view_layer.update()
        finally:
            _state["gyro_syncing"] = False
        _gyro_seed_baselines(context)
        _tag_redraw_all_view3d()
        return
    if not rotating:
        _gyro_seed_baselines(context)
        return
    if session is None:
        session = {"frame": frame, "token": _pin_transform_operator_token(context), "guides": {}}
        baselines = _state.get("gyro_baselines", {})
        for armature, bone in _gyro_subjects(context):
            guide = _gyro_find(context, armature, bone)
            if (guide is None or not getattr(bone, "select", getattr(bone.bone, "select", False))
                    or not _gyro_active(context, guide)):
                continue
            reference = guide.get("gyro_reference")
            if reference is None:
                continue
            snapshot = _gyro_transform_snapshot(context, guide,
                basis=baselines.get(guide.name, bone.matrix_basis),
                world=_state.get("gyro_world_baselines", {}).get(guide.name))
            snapshot["operator"] = identifier
            session["guides"][guide.name] = snapshot
            _gyro_preview_drivers(guide, True)
        _state["gyro_native_session"] = session
    _state["gyro_syncing"] = True
    try:
        for name, snapshot in session["guides"].items():
            guide = bpy.data.objects.get(name)
            bone = _gyro_owner(guide)[1] if guide is not None else None
            if bone is None:
                continue
            signature = tuple(round(value, 8) for row in bone.matrix_basis for value in row)
            if signature == snapshot["last_basis"]:
                continue
            snapshot["last_basis"] = signature
            _gyro_apply_native_rotation(context, guide, snapshot)
    finally:
        _state["gyro_syncing"] = False


@persistent
def _gyro_depsgraph_post(scene, depsgraph=None):
    if (_gyro_private_physics_event(scene) or _state.get("ragdoll_syncing")
            or _state.get("gyro_syncing") or _state.get("gyro_history")
            or _state.get("gyro_native_history")):
        return
    _constraint_reconcile_gyro(bpy.context)
    for guide in _gyro_guides(scene):
        armature, bone = _gyro_owner(guide)
        if bone is not None:
            _gyro_sync_start_frame(armature, bone)
    _gyro_observe_rotation(bpy.context)
    _gyro_update_aims(bpy.context)


@persistent
def _gyro_history_pre(*args):
    if _gyro_private_physics_event(args[0] if args else None):
        return
    if (_state.get("gyro_dragging") and not _state.get("gyro_native_history")
            and _state.get("gyro_drag_frame") == bpy.context.scene.frame_current):
        return
    _state["gyro_history"] = True
    session = _state.get("gyro_native_session")
    if session is not None:
        for name, snapshot in session["guides"].items():
            guide = bpy.data.objects.get(name)
            reference = guide.get("gyro_reference") if guide is not None else None
            if reference is not None:
                guide.matrix_world = snapshot["target"]
                reference.matrix_world = snapshot["reference"]
                _gyro_clear_preview(guide)
                _gyro_preview_drivers(guide, False)
    _state["gyro_native_session"] = None
    _state["gyro_baselines"] = {}


@persistent
def _gyro_history_post(*args):
    if _gyro_private_physics_event(args[0] if args else None):
        # Private Bullet time samples are not editor frame/history events.
        # They must not rebuild cyan constraints or consume a user's pending
        # native-transform preview on the visible armature.
        return
    read_scope=_special_read_begin()
    marker_index=_state.get('ragdoll_marker_curve_indexes')
    channel_index=_state.get('ragdoll_native_channel_indexes')
    if marker_index is None:_state['ragdoll_marker_curve_indexes']={}
    if channel_index is None:_state['ragdoll_native_channel_indexes']={}
    try:
        return _gyro_history_post_impl(*args)
    finally:
        _special_read_end(read_scope)
        if marker_index is None:_state.pop('ragdoll_marker_curve_indexes',None)
        if channel_index is None:_state.pop('ragdoll_native_channel_indexes',None)


def _gyro_private_physics_event(scene=None):
    return bool(_state.get('ragdoll_native_evaluating') or
                (isinstance(scene,bpy.types.Scene) and scene.get('_staticaliza_physics_scratch',False)))


def _gyro_history_post_impl(*args):
    if _state.get("gyro_native_history"):
        return
    if (_state.get("gyro_dragging")
            and _state.get("gyro_drag_frame") == bpy.context.scene.frame_current):
        return
    _state["gyro_history"] = True
    _state["gyro_native_session"] = None
    guides = _gyro_guides()
    bases = (_gyro_capture_pose_bases(bpy.context)
             if any("gyro_preview_frame" in guide for guide in guides) else {})
    authored = False
    for guide in guides:
        _gyro_upgrade(bpy.context, guide)
        if "gyro_preview_frame" in guide:
            reference = guide.get("gyro_reference")
            if reference is not None:
                guide.location = guide["gyro_preview_target"]
                reference.rotation_quaternion = guide["gyro_preview_tilt"]
                _gyro_key_transform(guide, int(guide["gyro_preview_frame"]))
                _gyro_key_transform(reference, int(guide["gyro_preview_frame"]))
                authored = True
            _gyro_clear_preview(guide)
        _gyro_preview_drivers(guide, False)
    if _gyro_update_aims(bpy.context):
        bpy.context.view_layer.update()
    if authored:
        _gyro_restore_pose_bases(bpy.context, bases)
    _state["gyro_history"] = False
    # Gyro owners need not have Parent/Unparent constraints, so that system's
    # cached owner list cannot publish their frame-dependent bone colors.
    colors_changed = False
    for guide in guides:
        armature, bone = _gyro_owner(guide)
        if bone is not None:
            colors_changed = _sync_dynamic_pose_bone_color(
                bone, _chosen_dynamic_parent_constraint(bone, bpy.context.scene.frame_current),
                bpy.context.scene.frame_current) or colors_changed
    if colors_changed:
        _tag_redraw_all_view3d()
    _gyro_seed_baselines(bpy.context)


@persistent
def _gyro_undo_pre(*args):
    _state["gyro_native_history"] = True
    if _state.pop("gyro_dragging", False):
        _state.pop("gyro_drag_frame", None)
        _state["pin_target_dragging"] = False
    _state["gyro_history_contacts"] = _gyro_capture_contact_history(bpy.context)
    _gyro_history_pre(*args)


@persistent
def _gyro_undo_post(*args):
    _state["gyro_native_history"] = False
    _gyro_history_post(*args)
    _gyro_restore_contact_history(bpy.context)


def _gyro_history_channels(armature, bone):
    action = _dynamic_parent_owner_action(armature)
    prefix = bone.path_from_id()
    return tuple(sorted((curve.data_path, curve.array_index,
        tuple((tuple(key.co), key.interpolation, tuple(key.handle_left), tuple(key.handle_right))
              for key in curve.keyframe_points))
        for curve in _action_fcurves(action, armature)
        if curve.data_path.startswith(prefix + ".")))


def _gyro_history_signature(guide):
    reference = guide.get("gyro_reference")
    if reference is None:
        return None
    frame = bpy.context.scene.frame_current
    return (_gyro_key_snapshot(guide, frame), _gyro_key_snapshot(reference, frame),
            tuple(guide.location), tuple(reference.rotation_quaternion),
            tuple(guide.get("gyro_preview_target", ())), tuple(guide.get("gyro_preview_tilt", ())))


def _gyro_capture_contact_history(context):
    # Scope recovery to cyan-only edits. Never keep a broad pose lock across
    # a genuine pink move, a parent transform, or a Contact replacement.
    subjects = _gyro_subjects(context) if context.mode == "POSE" else ()
    if not subjects or any(_gyro_find(context, arm, bone) is None for arm, bone in subjects):
        return None
    gyros = {(arm.name, bone.name): (_gyro_find(context, arm, bone).name,
              _gyro_history_signature(_gyro_find(context, arm, bone))) for arm, bone in subjects}
    contacts = {}
    for guide in _surface_contact_active_simulated_guides(context.scene):
        arm, bone = _surface_contact_pose_bone(guide)
        if bone is None:
            continue
        while bone is not None:
            related = any(owner == arm.name and (bone.name == name
                or bone.name in {p.name for p in arm.pose.bones[name].parent_recursive}
                or name in {p.name for p in bone.parent_recursive}) for owner, name in gyros)
            if related:
                break
            contacts[(arm.name, bone.name)] = (bone.matrix_basis.copy(),
                                              _gyro_history_channels(arm, bone), guide.name)
            bone = bone.parent
    return context.scene.frame_current, gyros, contacts


def _gyro_restore_contact_history(context):
    captured = _state.pop("gyro_history_contacts", None)
    if captured is None or captured[0] != context.scene.frame_current:
        return
    _, gyros, contacts = captured
    changed = False
    for _owner, (name, signature) in gyros.items():
        guide = bpy.data.objects.get(name)
        if guide is None:
            return
        changed = changed or _gyro_history_signature(guide) != signature
    if not changed:
        return
    bases = {}
    for (owner, name), (basis, channels, guide_name) in contacts.items():
        arm = bpy.data.objects.get(owner)
        bone = arm.pose.bones.get(name) if arm is not None else None
        if (bone is not None and bpy.data.objects.get(guide_name) is not None
                and _gyro_history_channels(arm, bone) == channels):
            bases[(owner, name)] = basis
    if bases:
        _gyro_restore_pose_bases(context, bases)
        _surface_contact_seed_runtime_signatures(context)


def _gyro_poll():
    if not _state.get("extension_registered", False):
        return None
    if _state.get("gyro_native_history"):
        return 0.02
    try:
        _constraint_reconcile_gyro(bpy.context)
        _constraint_sync_timeline(bpy.context)
        _gyro_observe_rotation(bpy.context)
        if _gyro_update_aims(bpy.context):
            bpy.context.view_layer.update()
    except (AttributeError, ReferenceError, RuntimeError):
        _state["gyro_native_session"] = None
    return 0.02 if _state.get("gyro_native_session") else 0.08


