"""Native modifier evaluation for logical pin events and hidden target curves."""

from ..core.runtime import *  # noqa: F403
import sys


def _pin_curve_readonly_context():
    frame = sys._getframe(1)
    while frame is not None:
        name = frame.f_code.co_name
        if name == 'poll' or name.startswith(('draw', '_draw')):
            return True
        frame = frame.f_back
    return False


def _pin_curve_pending_phase(curve, frame):
    """Read-only first-draw fallback; the queued native evaluator owns output."""
    if not curve.keyframe_points:
        return frame
    first, last = float(curve.keyframe_points[0].co.x), float(curve.keyframe_points[-1].co.x)
    period = last-first
    sample = float(frame)
    for m in _pin_time_modifiers(curve):
        if m.type == 'CYCLES' and period > 1.e-8 and (sample < first or sample > last):
            before = sample < first
            mode, count = (m.mode_before, m.cycles_before) if before else (m.mode_after, m.cycles_after)
            laps = math.ceil((first-sample if before else sample-last)/period)
            if mode != 'NONE' and (not count or laps <= count):
                sample += (laps*period if before else -laps*period)
                if mode == 'MIRROR' and laps % 2: sample = first+last-sample
        elif m.type == 'STEPPED' and m.frame_step > 0:
            sample = math.floor((sample-m.frame_offset)/m.frame_step)*m.frame_step+m.frame_offset
    return sample


class _PinCurvePending:
    def __init__(self, curve, policy, logical, phase):
        self.curve, self.policy, self.logical, self.phase = curve, policy, logical, phase

    def evaluate(self, frame):
        sample = _pin_curve_pending_phase(self.policy or self.curve, frame)
        if self.phase: return sample
        if self.logical:
            events = [(float(k.co.x), _special_event_value(self.curve, k)) for k in self.curve.keyframe_points]
            return next((value for time, value in reversed(events) if time <= sample), 0.)
        return float(self.curve.evaluate(sample))


def _pin_curve_prepare_pending():
    requests = _state.get('pin_curve_eval_pending', {})
    for _index in range(min(12, len(requests))):
        _key, (action_uid, pointer, policy_uid, policy_pointer, logical, phase) = requests.popitem()
        action = next((a for a in bpy.data.actions if int(a.session_uid) == action_uid), None)
        policy_action = next((a for a in bpy.data.actions if int(a.session_uid) == policy_uid), None)
        curve = next((c for c in _action_fcurves(action) if int(c.as_pointer()) == pointer), None)
        policy = next((c for c in _action_fcurves(policy_action) if int(c.as_pointer()) == policy_pointer), None)
        if curve is not None:
            _pin_curve_native_copy(curve, policy, logical=logical, phase=phase)
    _tag_redraw_all_view3d()
    return .01 if requests else None


def _pin_modifier_data(modifier):
    values = {}
    for prop in modifier.bl_rna.properties:
        name = prop.identifier
        if prop.is_readonly or name in {'rna_type', 'name', 'show_expanded', 'active'}:
            continue
        if prop.type not in {'BOOLEAN', 'INT', 'FLOAT', 'ENUM', 'STRING'}:
            continue
        value = getattr(modifier, name)
        values[name] = tuple(value) if getattr(prop, 'is_array', False) else value
    envelope = tuple((p.frame, p.min, p.max) for p in getattr(modifier, 'control_points', ()))
    return modifier.type, values, envelope


def _pin_time_modifiers(curve):
    return tuple(m for m in curve.modifiers if not m.mute and (
        m.type in {'CYCLES', 'STEPPED'} or (m.type == 'LIMITS' and (m.use_min_x or m.use_max_x))))


def _pin_curve_has_policy(curve):
    return curve is not None and not curve.mute and (
        curve.extrapolation == 'LINEAR' or bool(_pin_time_modifiers(curve)))


def _pin_contact_curve_policy(guide):
    scope = _state.get('special_event_reads')
    key = ('pin_contact_policy', int(guide.as_pointer()))
    if scope is not None and key in scope:
        return scope[key]
    _object, owner = _surface_contact_owner_from_guide(guide)
    if owner is None:
        return None
    action = _dynamic_parent_owner_action(owner)
    # During creation a custom rig may already have an Action, while this
    # particular bone has not received its Contact marker property yet.
    path = owner.path_from_id() + f'["{SURFACE_CONTACT_MARKER_PROPERTY}"]'
    result = next((c for c in _fcurves_find_all(action, path, owner.id_data)
                   if _pin_curve_has_policy(c)), None)
    if scope is not None: scope[key] = result
    return result


def _pin_curve_eval_clear(preserve_pending=False):
    if not preserve_pending:
        _state.pop('pin_curve_eval_pending', None)
    _state.pop('pin_curve_eval_entries', None)
    action = _state.pop('pin_curve_eval_action', None)
    scope = _state.get('special_event_reads', {})
    for key in tuple(scope):
        if key and key[0] == 'pin_curve_copy': scope.pop(key, None)
    if action is not None:
        try:
            bpy.data.actions.remove(action)
        except (ReferenceError, RuntimeError):
            pass
    for orphan in tuple(bpy.data.actions):
        if orphan.get('_staticaliza_pin_curve_eval', False) and not orphan.users:
            bpy.data.actions.remove(orphan)


def _pin_eval_curve_collection(action):
    if hasattr(action, 'fcurves'):
        return action.fcurves
    bags = _action_channelbags(action)
    if bags:
        return bags[0].fcurves
    slot = action.slots.new('OBJECT', '_PinCurveEvaluation')
    layer = action.layers.new('Evaluation')
    return layer.strips.new(type='KEYFRAME').channelbag(slot, ensure=True).fcurves


def _pin_copy_modifier(collection, data, *, phase=False, logical=False):
    kind, values, envelope = data
    modifier = collection.new(type=kind)
    values = dict(values)
    if (phase or logical) and kind == 'CYCLES':
        for name in ('mode_before', 'mode_after'):
            if values.get(name) == 'REPEAT_OFFSET':
                values[name] = 'REPEAT'
    if phase and kind == 'LIMITS':
        values['use_min_y'] = values['use_max_y'] = False
    # Generator array size is configured before copying its coefficients.
    for name in ('mode', 'poly_order'):
        if name in values:
            setattr(modifier, name, values.pop(name))
    for name, value in values.items():
        setattr(modifier, name, value)
    for frame, minimum, maximum in envelope:
        point = modifier.control_points.add(frame)
        point.min, point.max = minimum, maximum
    return modifier


def _pin_curve_native_copy(curve, policy=None, *, logical=False, phase=False):
    """One bounded unbound Action; no scene seeks or authored-curve mutation."""
    scope = _state.get('special_event_reads')
    scope_key = ('pin_curve_copy', int(curve.as_pointer()),
                 int(policy.as_pointer()) if policy else 0, logical, phase)
    if scope is not None and scope_key in scope:
        try:
            if scope[scope_key].id_data is not None: return scope[scope_key]
        except ReferenceError:
            scope.pop(scope_key, None)
    keys = tuple((tuple(k.co), tuple(k.handle_left), tuple(k.handle_right),
                  _surface_contact_key_style(k), _special_event_value(curve, k) if logical else k.co.y)
                 for k in curve.keyframe_points)
    own = tuple(_pin_modifier_data(m) for m in curve.modifiers)
    inherited = ()
    bounds = ()
    extrapolation = curve.extrapolation
    if policy is not None:
        existing = {m.type for m in curve.modifiers if not m.mute}
        inherited = tuple(_pin_modifier_data(m) for m in _pin_time_modifiers(policy)
                          if m.type not in existing)
        inherited = tuple((kind, dict(values, use_min_y=False, use_max_y=False), envelope)
                          if kind == 'LIMITS' else (kind, values, envelope)
                          for kind, values, envelope in inherited)
        extrapolation = policy.extrapolation
        if policy.keyframe_points:
            bounds = (float(policy.keyframe_points[0].co.x), float(policy.keyframe_points[-1].co.x))
    if phase:
        bounds = (float(curve.keyframe_points[0].co.x), float(curve.keyframe_points[-1].co.x))
        keys = tuple(((f, f), (f, f), (f, f), {'interpolation': 'LINEAR'}, f) for f in bounds)
        own = tuple(_pin_modifier_data(m) for m in _pin_time_modifiers(curve))
        extrapolation = 'LINEAR'
    signature = repr((keys, own, inherited, bounds, extrapolation, logical, phase))
    identity = (int(curve.id_data.session_uid), int(curve.as_pointer()), curve.data_path, int(curve.array_index),
                int(policy.id_data.session_uid) if policy else 0,
                int(policy.as_pointer()) if policy else 0, logical, phase)
    entries = _state.setdefault('pin_curve_eval_entries', {})
    old = entries.get(identity)
    if old is not None and old[0] == signature:
        try:
            if old[1].id_data is not None:
                if scope is not None: scope[scope_key] = old[1]
                return old[1]
        except ReferenceError:
            pass
    if _pin_curve_readonly_context():
        requests = _state.setdefault('pin_curve_eval_pending', {})
        requests[identity] = (int(curve.id_data.session_uid), int(curve.as_pointer()),
            int(policy.id_data.session_uid) if policy else 0, int(policy.as_pointer()) if policy else 0, logical, phase)
        while len(requests) > 128: requests.pop(next(iter(requests)))
        if not bpy.app.timers.is_registered(_pin_curve_prepare_pending):
            register_owned_timer(_pin_curve_prepare_pending, first_interval=0.)
        return _PinCurvePending(curve, policy, logical, phase)
    action = _state.get('pin_curve_eval_action')
    try:
        valid = action is not None and action.name in bpy.data.actions
    except ReferenceError:
        valid = False
    if not valid:
        _pin_curve_eval_clear(preserve_pending=True)
        entries = _state.setdefault('pin_curve_eval_entries', {})
        entries.clear()
        action = bpy.data.actions.new('_PinCurveEvaluation')
        action['_staticaliza_pin_curve_eval'] = True
        _state['pin_curve_eval_action'] = action
    if old is not None:
        try: _action_remove_fcurve(action, old[1])
        except (ReferenceError, RuntimeError): pass
    copy = _pin_eval_curve_collection(action).new(data_path='_pin_sample_'+str(time.time_ns()))
    try:
        copy.extrapolation = extrapolation
        for co, left, right, style, value in keys:
            point = copy.keyframe_points.insert(float(co[0]), float(value))
            _surface_contact_apply_key_style(point, style)
            point.handle_left, point.handle_right = left, right
            if logical:
                point.interpolation = 'CONSTANT'
        copy.update()
        # A visible channel's full span owns a hidden target's cycle period.
        # Padding preserves the native target's extrapolated endpoint values.
        if inherited and any(data[0] == 'CYCLES' for data in inherited) and len(bounds) == 2:
            for frame in bounds:
                if copy.keyframe_points and not _fcurve_key_at(copy, frame):
                    value = copy.evaluate(frame)
                    point = copy.keyframe_points.insert(frame, value)
                    point.interpolation = 'CONSTANT' if logical else 'LINEAR'
                    point.handle_left_type = point.handle_right_type = 'VECTOR'
            copy.update()
        for data in (*inherited, *own):
            _pin_copy_modifier(copy.modifiers, data, phase=phase, logical=logical)
        copy.update()
        entries[identity] = (signature, copy)
        while len(entries) > 128:
            expired = entries.pop(next(iter(entries)))
            try: _action_remove_fcurve(action, expired[1])
            except (ReferenceError, RuntimeError): pass
        if scope is not None: scope[scope_key] = copy
        return copy
    except Exception:
        _action_remove_fcurve(action, copy)
        raise


def _pin_curve_value(curve, frame, policy=None):
    if policy is None or not _pin_curve_has_policy(policy):
        return float(curve.evaluate(frame))
    return float(_pin_curve_native_copy(curve, policy).evaluate(frame))


def _pin_curve_phase(curve, frame):
    if not _pin_curve_has_policy(curve) or len(curve.keyframe_points) < 2:
        return float(frame)
    return float(_pin_curve_native_copy(curve, phase=True).evaluate(frame))


def _pin_contact_policy_basis(guide, frame):
    policy = _pin_contact_curve_policy(guide)
    if policy is None:
        return None
    curves = _action_fcurves(_dynamic_parent_owner_action(guide), guide)
    return _surface_contact_release_channels(guide, frame, curves, policy=policy)


def _pin_contact_policy_history_signature(guide):
    policy = _pin_contact_curve_policy(guide)
    return (policy.extrapolation, tuple(_pin_modifier_data(m) for m in policy.modifiers)) if policy else None


def _pin_sync_contact_curve_policies(context, guides, frame):
    if any(_state.get(k) for k in ('pin_target_dragging', 'pin_keyboard_transform_active', 'pin_snap_transform_active',
                                  'surface_contact_creation_active', 'pin_history_syncing')):
        return False
    changed = False
    applied = _state.setdefault('pin_contact_policy_applied', set())
    for guide in guides:
        basis = _pin_contact_policy_basis(guide, frame)
        # Native Undo can replace the RNA ID/session UID while preserving the
        # guide identity. Retire the applied policy through that replacement.
        identity = guide.name
        if basis is not None:
            applied.add(identity)
        elif identity in applied:
            # Keep the recovery identity through repeated Undo/Redo. Redo
            # can restore the evaluated matrix before its normal frame hook
            # runs, so the next Undo still needs a native-input restoration.
            basis = _surface_contact_release_channels(guide, frame,
                _action_fcurves(_dynamic_parent_owner_action(guide), guide))
        if basis is not None and _pin_keyboard_matrices_differ(guide.matrix_basis, basis, epsilon=1.e-7):
            guide.matrix_basis = basis
            changed = True
    return changed
