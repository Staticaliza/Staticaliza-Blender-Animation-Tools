"""An already snapped Onion Pin keeps its limb still during ancestor edits."""
from ..core.runtime import *  # noqa: F403


def _yellow_direct_edit_allowed(context, armature, bone):
    return _pose_bone_selected(bone) or any(
        data[0] in {"YELLOW", "CONTACT"} and data[1] == armature and data[2] == bone
        for _key, data in _pin_selected_targets_data(context))


def _yellow_parent_candidates(context):
    for armature, selected in _selected_pose_bones_by_owner(context).items():
        selected_names = {bone.name for bone in selected}
        for name in _yellow_owner_map("yellow_fixed", armature):
            bone = armature.pose.bones.get(name)
            if bone is None or name in selected_names:
                continue
            if any(_ragdoll_is_ancestor(armature, parent, bone) for parent in selected):
                yield armature, bone


def _yellow_parent_idle_snapshot(context):
    result = {}
    for (uid, name), packed in _state.get("yellow_fixed", {}).items():
        armature = _armature_from_session_uid(uid)
        bone = armature.pose.bones.get(name) if armature is not None else None
        if bone is not None:
            result[(uid, name)] = (armature.matrix_world @ bone.matrix,
                                   bone.matrix_basis.copy())
    return result


def _yellow_capture_parent_holds(context):
    holds = []
    cached = _state.get("pin_snap_idle_transform_poses", {}).get("yellow", {})
    use_idle = _state.get("pin_snap_transform_baseline_precedes_sample", False)
    latches = _state.setdefault("pin_snap_latches", set())
    for armature, bone in _yellow_parent_candidates(context):
        owner = _owner_bone_key(armature, bone.name)
        key = f"YELLOW:{owner[0]}:{bone.name}"
        if key not in latches or _ragdoll_active(bone, context.scene.frame_current):
            continue
        world, basis = cached.get(owner, (armature.matrix_world @ bone.matrix,
                                         bone.matrix_basis.copy())) if use_idle else (
                                             armature.matrix_world @ bone.matrix,
                                             bone.matrix_basis.copy())
        holds.append((armature.name, bone.name, world.copy(), basis.copy()))
    _state["yellow_parent_holds"] = holds
    return bool(holds)


def _yellow_apply_parent_holds(context, restore=False):
    changed = False
    for owner, name, world, basis in _state.get("yellow_parent_holds", ()):
        armature = bpy.data.objects.get(owner)
        bone = armature.pose.bones.get(name) if armature is not None else None
        if bone is None or _ragdoll_active(bone, context.scene.frame_current):
            continue
        if restore:
            if _pin_keyboard_matrices_differ(bone.matrix_basis, basis):
                bone.matrix_basis = basis.copy()
                changed = True
        elif _pin_keyboard_matrices_differ(armature.matrix_world @ bone.matrix, world):
            _set_pose_bone_constrained_output_matrix(context, armature, bone,
                armature.matrix_world.inverted_safe() @ world, atomic=True)
            changed = True
            if context.scene.tool_settings.use_keyframe_insert_auto:
                _insert_bone_keys(bone, context.scene.frame_current)
    if changed:
        owners = {bpy.data.objects.get(owner) for owner, _name, _world, _basis
                  in _state.get("yellow_parent_holds", ())}
        _pin_restore_action_pose_bases(context, _pin_capture_action_pose_bases(
            owner for owner in owners if owner is not None))
    return changed
