"""Geometry, Smart orientation, and collision math for pose draggers."""

from ..core.runtime import *  # noqa: F403


SMART_DRAGGER_RED = (1.0, 0.0, 0.0)
SMART_DRAGGER_RING_SEGMENTS = 32
SMART_DRAGGER_RING_VERTICES = tuple(
    vertex
    for index in range(SMART_DRAGGER_RING_SEGMENTS)
    for vertex in (
        (
            math.cos((index / SMART_DRAGGER_RING_SEGMENTS) * math.tau) * 2.25,
            math.sin((index / SMART_DRAGGER_RING_SEGMENTS) * math.tau) * 2.25,
            0.0,
        ),
        (
            math.cos(((index + 1) / SMART_DRAGGER_RING_SEGMENTS) * math.tau)
            * 2.25,
            math.sin(((index + 1) / SMART_DRAGGER_RING_SEGMENTS) * math.tau)
            * 2.25,
            0.0,
        ),
        (
            math.cos((index / SMART_DRAGGER_RING_SEGMENTS) * math.tau) * 1.65,
            math.sin((index / SMART_DRAGGER_RING_SEGMENTS) * math.tau) * 1.65,
            0.0,
        ),
        (
            math.cos(((index + 1) / SMART_DRAGGER_RING_SEGMENTS) * math.tau)
            * 2.25,
            math.sin(((index + 1) / SMART_DRAGGER_RING_SEGMENTS) * math.tau)
            * 2.25,
            0.0,
        ),
        (
            math.cos(((index + 1) / SMART_DRAGGER_RING_SEGMENTS) * math.tau)
            * 1.65,
            math.sin(((index + 1) / SMART_DRAGGER_RING_SEGMENTS) * math.tau)
            * 1.65,
            0.0,
        ),
        (
            math.cos((index / SMART_DRAGGER_RING_SEGMENTS) * math.tau) * 1.65,
            math.sin((index / SMART_DRAGGER_RING_SEGMENTS) * math.tau) * 1.65,
            0.0,
        ),
    )
)

SMART_DRAGGER_RING_LINE_VERTICES = tuple(
    vertex
    for index in range(SMART_DRAGGER_RING_SEGMENTS)
    for vertex in (
        (
            math.cos((index / SMART_DRAGGER_RING_SEGMENTS) * math.tau) * 2.25,
            math.sin((index / SMART_DRAGGER_RING_SEGMENTS) * math.tau) * 2.25,
            0.0,
        ),
        (
            math.cos(((index + 1) / SMART_DRAGGER_RING_SEGMENTS) * math.tau)
            * 2.25,
            math.sin(((index + 1) / SMART_DRAGGER_RING_SEGMENTS) * math.tau)
            * 2.25,
            0.0,
        ),
    )
)


def _smart_dragger_surface_contact_matrix(base_matrix, plane):
    """Keep the ring tangent frame while aligning it to a hit surface."""
    point, normal = plane
    normal = Vector(normal)
    if normal.length_squared <= 1.0e-12:
        return Matrix(base_matrix)
    normal.normalize()
    base = Matrix(base_matrix).to_3x3().normalized()
    tangent = base.col[0] - normal * base.col[0].dot(normal)
    if tangent.length_squared <= 1.0e-12:
        tangent = normal.orthogonal()
    tangent.normalize()
    bitangent = normal.cross(tangent).normalized()
    matrix = Matrix.Identity(4)
    matrix.col[0][:3] = tangent
    matrix.col[1][:3] = bitangent
    matrix.col[2][:3] = normal
    matrix.translation = Vector(point)
    return matrix


def _smart_dragger_refresh_live_gizmos(context, draggers):
    """Update only matrices while Blender owns a native modal transform."""
    data = _smart_dragger_data(context)
    if data is None:
        return False
    for side, gizmo in enumerate(draggers):
        _pin_gizmo_set_if_changed(
            gizmo,
            "matrix_basis",
            data["matrices"][side],
        )
    return True


def _smart_dragger_opposite_axis(axis):
    return {
        "X_POS": "X_NEG",
        "X_NEG": "X_POS",
        "Y_POS": "Y_NEG",
        "Y_NEG": "Y_POS",
        "Z_POS": "Z_NEG",
        "Z_NEG": "Z_POS",
    }.get(str(axis), "Y_POS")


def _smart_dragger_axis_vector(axis):
    return {
        "X_POS": Vector((1.0, 0.0, 0.0)),
        "X_NEG": Vector((-1.0, 0.0, 0.0)),
        "Y_POS": Vector((0.0, 1.0, 0.0)),
        "Y_NEG": Vector((0.0, -1.0, 0.0)),
        "Z_POS": Vector((0.0, 0.0, 1.0)),
        "Z_NEG": Vector((0.0, 0.0, -1.0)),
    }.get(str(axis), Vector((0.0, -1.0, 0.0)))


def _smart_dragger_surface_normal(
    context,
    packed,
    axis,
    fallback,
):
    """Use the captured welded object's axes for Smart surface handles."""
    if packed is not None and len(packed) >= 6:
        smart_object = bpy.data.objects.get(str(packed[4]))
        if smart_object is not None:
            try:
                evaluated = smart_object.evaluated_get(
                    context.evaluated_depsgraph_get()
                )
                normal = (
                    evaluated.matrix_world.to_3x3()
                    @ _smart_dragger_axis_vector(axis)
                )
                if normal.length_squared > 1.0e-12:
                    return normal.normalized()
            except (
                AttributeError,
                ReferenceError,
                RuntimeError,
                TypeError,
            ):
                pass
    fallback = Vector(fallback)
    return (
        fallback.normalized()
        if fallback.length_squared > 1.0e-12
        else Vector((0.0, 0.0, 1.0))
    )


def _smart_dragger_surface_matrix(context, point, packed, axis, fallback_basis):
    """Orient the diamond from the complete welded face, including roll."""
    basis = Matrix(fallback_basis).to_3x3().normalized()
    if packed is not None and len(packed) >= 5:
        smart_object = bpy.data.objects.get(str(packed[4]))
        if smart_object is not None:
            try:
                basis = (
                    smart_object.evaluated_get(
                        context.evaluated_depsgraph_get()
                    ).matrix_world.to_3x3().normalized()
                )
            except (
                AttributeError,
                ReferenceError,
                RuntimeError,
                TypeError,
            ):
                pass
    local_normal = _smart_dragger_axis_vector(axis)
    local_tangent = next(
        candidate
        for candidate in (
            Vector((1.0, 0.0, 0.0)),
            Vector((0.0, 1.0, 0.0)),
            Vector((0.0, 0.0, 1.0)),
        )
        if abs(candidate.dot(local_normal)) < 0.5
    )
    normal = (basis @ local_normal).normalized()
    tangent = basis @ local_tangent
    tangent -= normal * tangent.dot(normal)
    if tangent.length_squared <= 1.0e-12:
        tangent = normal.orthogonal()
    tangent.normalize()
    bitangent = normal.cross(tangent).normalized()
    matrix = Matrix.Identity(4)
    matrix.col[0][:3] = tangent
    matrix.col[1][:3] = bitangent
    matrix.col[2][:3] = normal
    matrix.translation = Vector(point)
    return matrix


def _smart_dragger_collision_planes(
    context,
    points,
    normals,
    excluded,
    cast_distance,
):
    """Capture surfaces seen by the red/green Smart cast axes."""
    planes = []
    distance = max(0.25, float(cast_distance))
    for point, normal in zip(points, normals):
        point = Vector(point)
        normal = Vector(normal)
        if normal.length_squared <= 1.0e-12:
            planes.append(None)
            continue
        normal.normalize()
        epsilon = min(1.0e-4, distance * 1.0e-4)
        # Preserve the original cast from the stored outward axis first.
        hit = _surface_contact_ray_cast(
            context,
            point + (normal * epsilon),
            normal,
            distance,
            excluded,
        )
        if hit is None:
            # A Smart Dragger red pin is also a surface point for walls and
            # ceilings. Probe the opposite side only when the normal-side
            # cast misses, so reverse-facing surfaces become collidable
            # without changing existing forward collision selection.
            hit = _surface_contact_ray_cast(
                context,
                point - (normal * distance) + (normal * epsilon),
                normal,
                (distance * 2.0) - epsilon,
                excluded,
            )
        if hit is None:
            planes.append(None)
            continue
        _surface, hit_point, hit_normal, _travelled = hit
        hit_normal = Vector(hit_normal)
        if hit_normal.length_squared <= 1.0e-12:
            hit_normal = -normal
        else:
            hit_normal.normalize()
        if (point - Vector(hit_point)).dot(hit_normal) < 0.0:
            hit_normal.negate()
        planes.append((Vector(hit_point).copy(), hit_normal.copy()))
    return tuple(planes)


def _smart_dragger_plane_collision_fraction(starts, ends, planes):
    """Clamp motion before either Smart surface point crosses its hit plane."""
    fraction = 1.0
    tolerance = 1.0e-5
    for start, end, plane in zip(starts, ends, planes):
        if plane is None:
            continue
        point, normal = plane
        start_distance = (Vector(start) - point).dot(normal)
        end_distance = (Vector(end) - point).dot(normal)
        if end_distance >= tolerance or end_distance >= start_distance:
            continue
        denominator = start_distance - end_distance
        if denominator <= 1.0e-12:
            continue
        allowed = max(0.0, start_distance - tolerance) / denominator
        fraction = min(fraction, max(0.0, min(1.0, allowed)))
    return fraction


def _smart_dragger_plane_touching(point, plane):
    if plane is None:
        return False
    plane_point, plane_normal = plane
    distance = (
        Vector(point) - Vector(plane_point)
    ).dot(Vector(plane_normal).normalized())
    return -1.0e-5 <= distance <= PIN_SNAP_WORLD_RADIUS


def _smart_dragger_active_collision_planes(
    red_contact_active,
    red_plane,
    collision_planes,
):
    """A planted red endpoint owns grounding; green remains a loose handle."""
    if red_contact_active and red_plane is not None:
        return (red_plane,)
    return tuple(collision_planes)


def _smart_dragger_red_contact_point(
    context,
    start,
    desired,
    plane,
    excluded,
    hold_contact=False,
):
    """Prevent red from entering a surface without magnetizing it back."""
    start = Vector(start)
    desired = Vector(desired)
    tolerance = 1.0e-5
    if plane is not None:
        point, normal = plane
        normal = Vector(normal).normalized()
        distance = (desired - Vector(point)).dot(normal)
        if distance >= tolerance and not hold_contact:
            return desired
        return desired + (normal * (tolerance - distance))
    delta = desired - start
    distance = delta.length
    if distance <= 1.0e-8:
        return desired
    hit = _surface_contact_ray_cast(
        context,
        start,
        delta / distance,
        distance,
        excluded,
    )
    if hit is None:
        return desired
    _surface, hit_point, hit_normal, _travelled = hit
    hit_normal = Vector(hit_normal)
    if hit_normal.length_squared <= 1.0e-12:
        hit_normal = -(delta / distance)
    else:
        hit_normal.normalize()
    if (start - Vector(hit_point)).dot(hit_normal) < 0.0:
        hit_normal.negate()
    return Vector(hit_point) + (hit_normal * tolerance)


def _smart_dragger_swept_red_plane(context, start, desired, excluded):
    """Return the first collider crossed by the red endpoint's drag path."""
    start = Vector(start)
    desired = Vector(desired)
    delta = desired - start
    distance = delta.length
    if distance <= 1.0e-8:
        return None
    direction = delta / distance
    epsilon = min(1.0e-4, distance * 0.05)
    hit = _surface_contact_ray_cast(
        context,
        start + (direction * epsilon),
        direction,
        max(0.0, distance - epsilon),
        excluded,
    )
    if hit is None:
        return None
    _surface, hit_point, hit_normal, _travelled = hit
    normal = Vector(hit_normal)
    if normal.length_squared <= 1.0e-12:
        normal = -direction
    else:
        normal.normalize()
    if (start - Vector(hit_point)).dot(normal) < 0.0:
        normal.negate()
    return Vector(hit_point).copy(), normal.copy()


def _smart_dragger_orient_red_plane(plane, cast_direction):
    """Make the red cast direction consistently point into the collider."""
    if plane is None:
        return None
    point, normal = plane
    normal = Vector(normal)
    cast_direction = Vector(cast_direction)
    if normal.length_squared <= 1.0e-12:
        return None
    normal.normalize()
    if cast_direction.length_squared > 1.0e-12:
        cast_direction.normalize()
        if normal.dot(cast_direction) > 0.0:
            normal.negate()
    return Vector(point).copy(), normal.copy()


def _smart_dragger_live_red_plane(
    context,
    desired,
    fallback_plane,
    excluded,
    cast_distance,
    fallback_normal=None,
):
    """Find the actual surface under red without assuming a floor plane."""
    if fallback_plane is not None:
        _fallback_point, fallback_normal = fallback_plane
    normal = Vector(fallback_normal) if fallback_normal is not None else Vector()
    if normal.length_squared <= 1.0e-12:
        return None
    normal.normalize()
    desired = Vector(desired)
    distance = max(PIN_SNAP_WORLD_RADIUS * 1.25, float(cast_distance))
    candidates = []
    for direction in (-normal, normal):
        origin = desired - (direction * distance)
        hit = _surface_contact_ray_cast(
            context,
            origin,
            direction,
            distance * 2.0,
            excluded,
        )
        if hit is None:
            continue
        _surface, hit_point, hit_normal, _travelled = hit
        hit_normal = Vector(hit_normal)
        if hit_normal.length_squared <= 1.0e-12:
            hit_normal = -direction
        else:
            hit_normal.normalize()
        if (desired - Vector(hit_point)).dot(hit_normal) < 0.0:
            hit_normal.negate()
        candidates.append((
            abs((desired - Vector(hit_point)).dot(hit_normal)),
            (Vector(hit_point).copy(), hit_normal.copy()),
        ))
    return min(candidates, key=lambda item: item[0])[1] if candidates else fallback_plane


def _smart_dragger_green_rod_delta(points, desired, red_plane=None):
    """Aim the rigid red-green rod at a freely moved green handle."""
    del red_plane
    red, green = (Vector(point) for point in points)
    desired = Vector(desired)
    initial_vector = green - red
    desired_vector = desired - red
    if (
        initial_vector.length_squared <= 1.0e-12
        or desired_vector.length_squared <= 1.0e-12
    ):
        return Matrix.Identity(4)
    rotation = initial_vector.rotation_difference(desired_vector)
    return (
        Matrix.Translation(red)
        @ rotation.to_matrix().to_4x4()
        @ Matrix.Translation(-red)
    )


def _smart_dragger_grounded_red_delta(points, desired):
    """Place red exactly while the upper green area follows with lag."""
    red, green = (Vector(point) for point in points)
    desired = Vector(desired)
    delta = desired - red
    lagged_green = green + (delta * 0.25)
    initial_vector = green - red
    desired_vector = lagged_green - desired
    if (
        initial_vector.length_squared <= 1.0e-12
        or desired_vector.length_squared <= 1.0e-12
    ):
        return Matrix.Translation(delta)
    rotation = initial_vector.rotation_difference(desired_vector)
    return (
        Matrix.Translation(desired)
        @ rotation.to_matrix().to_4x4()
        @ Matrix.Translation(-red)
    )


def _smart_dragger_free_rod_delta(points, moving_side, desired):
    """Rotate either free endpoint around the opposite endpoint."""
    moving_side = int(moving_side)
    fixed_side = 1 - moving_side
    fixed = Vector(points[fixed_side])
    moving = Vector(points[moving_side])
    requested = Vector(desired)
    initial_vector = moving - fixed
    desired_vector = requested - fixed
    if (
        initial_vector.length_squared <= 1.0e-12
        or desired_vector.length_squared <= 1.0e-12
    ):
        return Matrix.Identity(4)
    rotation = initial_vector.rotation_difference(desired_vector)
    return (
        Matrix.Translation(fixed)
        @ rotation.to_matrix().to_4x4()
        @ Matrix.Translation(-fixed)
    )


def _smart_dragger_welded_support_points(context, packed_pair):
    points = []
    seen = set()
    depsgraph = context.evaluated_depsgraph_get()
    for packed in packed_pair:
        object_name = str(packed[4]) if len(packed) >= 5 else ""
        if not object_name or object_name in seen:
            continue
        seen.add(object_name)
        obj = bpy.data.objects.get(object_name)
        if obj is None:
            continue
        evaluated = obj.evaluated_get(depsgraph)
        points.extend(
            evaluated.matrix_world @ Vector(corner)
            for corner in evaluated.bound_box
        )
    return tuple(points)


def _smart_dragger_collision_clamped_delta(
    points,
    world_delta,
    planes,
    support_points=(),
):
    ends = tuple(world_delta @ Vector(point) for point in points)
    fraction = _smart_dragger_plane_collision_fraction(
        points,
        ends,
        planes,
    )
    for plane in planes:
        if plane is None or not support_points:
            continue
        support_ends = tuple(
            world_delta @ Vector(point) for point in support_points
        )
        fraction = min(
            fraction,
            _smart_dragger_plane_collision_fraction(
                support_points,
                support_ends,
                (plane,) * len(support_points),
            ),
        )
    if fraction >= 1.0 - 1.0e-8:
        return world_delta
    if fraction <= 1.0e-8:
        return Matrix.Identity(4)
    stationary = next(
        (
            Vector(point)
            for point in points
            if (world_delta @ Vector(point) - Vector(point)).length
            <= 1.0e-7
        ),
        None,
    )
    _location, rotation, _scale = world_delta.decompose()
    partial_rotation = Quaternion().slerp(rotation, fraction)
    if stationary is not None:
        return (
            Matrix.Translation(stationary)
            @ partial_rotation.to_matrix().to_4x4()
            @ Matrix.Translation(-stationary)
        )
    anchor = Vector(points[0])
    anchor_end = world_delta @ anchor
    partial_anchor = anchor.lerp(anchor_end, fraction)
    return (
        Matrix.Translation(partial_anchor)
        @ partial_rotation.to_matrix().to_4x4()
        @ Matrix.Translation(-anchor)
    )
