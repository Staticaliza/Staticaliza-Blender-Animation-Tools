"""Temporary red surface handle for quick limb posing with native bone keys."""

from ..core.runtime import *  # noqa: F403

class _SmartDraggerContactGuide(dict):
    """Python-only pressure identity; never a Blender object or keyed channel."""
    def __init__(self, armature, bone):
        super().__init__({SURFACE_CONTACT_ARMATURE_PROPERTY: armature.name})
        self.name = "SmartDragger:" + bone.name
        _smart_dragger_clear_pressure(self)


def _smart_dragger_clear_pressure(guide):
    if guide is None:
        return
    key = _surface_contact_snap_key(guide)
    for name in ("pin_snap_pressure_active", "pin_snap_pressure_pivot_active"):
        _state.setdefault(name, set()).discard(key)
    for name in ("pin_snap_pressure_tangents", "pin_snap_pressure_raw_tangents",
                 "pin_snap_pressure_tangent_crossings"):
        _state.setdefault(name, {}).pop(key, None)


def _on_smart_dragger_setting_change(_owner, context):
    _state["smart_dragger_cache"] = {}
    _state["smart_dragger_targets"] = {}
    _state["smart_dragger_attached_keys"] = set()
    if not getattr(context.window_manager, "smart_draggers_enabled", False):
        _state["smart_dragger_selected_side"] = -1
        _state["smart_dragger_owner"] = None
        _state["smart_dragger_selection_keys"] = ()
        _state["smart_dragger_extend_selection_until"] = 0.0
    else:
        _armature, pose_bone = _smart_dragger_active_pose(context)
        if pose_bone is not None:
            _smart_dragger_ensure_initial_basis(pose_bone)
        try:
            context.window_manager.gizmo_group_type_ensure(
                "ANIMATOR_UTILS_GGT_smart_draggers"
            )
        except (AttributeError, RuntimeError, TypeError, ValueError):
            pass
    _tag_redraw_all_view3d()

def _register_smart_dragger_properties():
    bpy.types.WindowManager.smart_draggers_enabled = bpy.props.BoolProperty(
        name = "Smart Dragger",
        description = "Show a temporary red surface pin for quick limb posing",
        default = False,
        update = _on_smart_dragger_setting_change,
    )
    bpy.types.WindowManager.smart_dragger_mode = bpy.props.EnumProperty(
        name = "Position",
        description = "Choose where the primary Smart Dragger is placed",
        items = (
            ("MODE_3", "Smart", "Use the selected welded-object face"),
            ("MODE_4", "Bone Start", "Use the active bone head"),
            ("MODE_2", "Bone Center", "Use the center of the weighted geometry"),
            ("MODE_1", "Bone End", "Use the active bone tail"),
        ),
        default = "MODE_3",
        update = _on_smart_dragger_setting_change,
    )
    bpy.types.WindowManager.smart_dragger_axis = bpy.props.EnumProperty(
        name = "Axis",
        description = "Choose the red handle's welded-object face",
        items = PIN_AXIS_ITEMS,
        default = "Y_NEG",
        update = _on_smart_dragger_setting_change,
    )
    # Remove the retired opt-out when hot-loading over an older DEV runtime.
    if hasattr(bpy.types.WindowManager, "smart_dragger_collision"):
        delattr(bpy.types.WindowManager, "smart_dragger_collision")

def _unregister_smart_dragger_properties():
    for name in (
        "smart_draggers_enabled",
        "smart_dragger_mode",
        "smart_dragger_axis",
    ):
        if hasattr(bpy.types.WindowManager, name):
            delattr(bpy.types.WindowManager, name)

def _reset_smart_dragger_runtime():
    _state["smart_dragger_selected_side"] = -1
    _state["smart_dragger_owner"] = None
    _state["smart_dragger_transform_active"] = False
    _state["smart_dragger_target_drag_active"] = False
    _state["smart_dragger_cache"] = {}
    _state["smart_dragger_targets"] = {}
    _state["smart_dragger_attached_keys"] = set()
    _state["smart_dragger_selection_keys"] = ()
    _state["smart_dragger_extend_selection_until"] = 0.0


def _smart_dragger_modal_is_running(context):
    """Return whether this add-on's Smart Dragger modal is still alive."""
    window_manager = getattr(context, "window_manager", None)
    for window in tuple(getattr(window_manager, "windows", ())):
        try:
            operators = tuple(window.modal_operators)
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            continue
        for operator in operators:
            operator_id = str(getattr(operator, "bl_idname", "")).casefold()
            if operator_id == "staticaliza.smart_dragger_transform":
                return True
    return False

def _smart_dragger_active_pose(context):
    if (
        context is None
        or getattr(context, "mode", "") != "POSE"
        or not getattr(
            getattr(context, "window_manager", None),
            "smart_draggers_enabled",
            False,
        )
    ):
        return None, None
    pose_bone = getattr(context, "active_pose_bone", None)
    armature = _pose_bone_owner(
        context,
        pose_bone,
        _pose_scope_armatures(context),
    )
    selected_side = int(_state.get("smart_dragger_selected_side", -1))
    owner = _state.get("smart_dragger_owner")
    if selected_side in (0, 1) and owner:
        owner_armature = bpy.data.objects.get(str(owner[0]))
        owner_bone = (
            owner_armature.pose.bones.get(str(owner[1]))
            if owner_armature is not None
            and getattr(owner_armature, "pose", None)
            else None
        )
        # Use the same exclusive/extended selection contract as pink pins.
        # A normal bone click transfers ownership away from the red target,
        # including when the clicked bone is the target's own linked bone.
        # Shift-click keeps both selections active.
        current_signature = _pin_pose_selection_signature(context)
        saved_signature = _state.get(
            "smart_dragger_selection_keys", current_signature,
        )
        selection_changed = current_signature != saved_signature
        extend_selection = bool(
            _pin_shift_modifier_pressed()
            or time.perf_counter() < float(
                _state.get("smart_dragger_extend_selection_until", 0.0)
            )
        )
        if selection_changed and not extend_selection:
            _state["smart_dragger_selected_side"] = -1
            _state["smart_dragger_owner"] = None
            _state["smart_dragger_selection_keys"] = ()
            _state["smart_dragger_extend_selection_until"] = 0.0
        else:
            if selection_changed:
                _state["smart_dragger_selection_keys"] = current_signature
            return owner_armature, owner_bone
    if armature is None or pose_bone is None or not _pose_bone_selected(pose_bone):
        return None, None
    return armature, pose_bone


def _smart_dragger_ensure_initial_basis(pose_bone):
    """Persist reset data only from operators/property updates, never draw."""
    if pose_bone is None:
        return False
    if SMART_DRAGGER_INITIAL_BASIS_PROPERTY in pose_bone:
        return True
    try:
        pose_bone[SMART_DRAGGER_INITIAL_BASIS_PROPERTY] = tuple(
            float(value)
            for row in pose_bone.matrix_basis
            for value in row
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        return False
    return True


def _smart_dragger_current_world_point(
    depsgraph,
    evaluated_armature,
    evaluated_bone,
    packed,
):
    """Resolve mode-3 anchors from the evaluated welded mesh like Contact."""
    if (
        not _state.get("smart_dragger_transform_active", False)
        and len(packed) >= 6
        and packed[4]
    ):
        source_object = bpy.data.objects.get(str(packed[4]))
        if source_object is not None:
            try:
                evaluated_object = source_object.evaluated_get(depsgraph)
                return evaluated_object.matrix_world @ Vector(packed[5][:3])
            except (
                AttributeError,
                ReferenceError,
                RuntimeError,
                TypeError,
                ValueError,
            ):
                pass
    # During a modal transform, the bone-local capture updates immediately;
    # querying the evaluated mesh can trail by one depsgraph step.
    return Vector(
        _yellow_current_world_point(
            depsgraph,
            evaluated_armature,
            evaluated_bone,
            packed,
        )
    )


def _smart_dragger_capture_pair(context, armature, pose_bone, mode, axis):
    depsgraph = context.evaluated_depsgraph_get()
    evaluated_armature = armature.evaluated_get(depsgraph)
    objects, _active = _targets(context, armature)
    bounds = {}
    if int(mode) == 2:
        bounds = _collect_world_shape_from_largest_components(
            context,
            depsgraph,
            armature,
            evaluated_armature,
            {pose_bone.name},
            objs = objects,
        )
    primary = _yellow_capture(
        context,
        depsgraph,
        armature,
        evaluated_armature,
        objects,
        pose_bone.name,
        int(mode),
        bounds,
        axis = axis,
    )
    opposite_axis = _smart_dragger_opposite_axis(axis)
    opposite_mode = {
        1: 4,
        4: 1,
        2: 3,
    }.get(int(mode), 3)
    secondary = _yellow_capture(
        context,
        depsgraph,
        armature,
        evaluated_armature,
        objects,
        pose_bone.name,
        opposite_mode,
        bounds,
        axis = opposite_axis,
    )
    return primary, secondary


def _smart_dragger_contact_owned(context, armature, pose_bone):
    return bool(armature is not None and pose_bone is not None and any(
        str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, "")) == armature.name
        and pose_bone.name in _surface_contact_direct_bone_names(guide)
        for guide in _surface_contact_active_snap_guides(context.scene)
    ))


def _smart_dragger_data(context):
    armature, pose_bone = _smart_dragger_active_pose(context)
    if armature is None or pose_bone is None:
        return None
    # Pink already owns this effector/control at the current frame.
    if _smart_dragger_contact_owned(context, armature, pose_bone):
        return None
    timeline = (int(context.scene.frame_current), float(context.scene.frame_subframe))
    if _state.get("smart_dragger_timeline") != timeline:
        _state["smart_dragger_targets"] = {}
        _state["smart_dragger_attached_keys"] = set()
        _state["smart_dragger_timeline"] = timeline
    viewed_armature, viewed_bone, _viewed_camera = (
        _viewed_attached_camera_bone(context)
    )
    if viewed_armature == armature and viewed_bone == pose_bone:
        # Camera-bone controls must never be composited into their own camera
        # output. The camera panel remains available through viewed-camera
        # resolution even though this viewport gizmo is suppressed.
        return None
    wm = context.window_manager
    mode_name = str(getattr(wm, "smart_dragger_mode", "MODE_3"))
    mode = {
        "MODE_1": 1,
        "MODE_2": 2,
        "MODE_3": 3,
        "MODE_4": 4,
    }.get(mode_name, 3)
    axis = str(getattr(wm, "smart_dragger_axis", "Y_NEG"))
    depsgraph = context.evaluated_depsgraph_get()
    evaluated_armature = armature.evaluated_get(depsgraph)
    evaluated_bone = evaluated_armature.pose.bones.get(pose_bone.name)
    if evaluated_bone is None:
        return None
    # Capture a stable pair in bone/mesh local space. Recasting the support
    # face for each interpolated pose changes the handle during animation.
    cache_key = (_armature_session_uid(armature), pose_bone.name, mode, axis)
    cache = _state.setdefault("smart_dragger_cache", {})
    packed_pair = cache.get(cache_key)
    if packed_pair is None:
        packed_pair = _smart_dragger_capture_pair(
            context,
            armature,
            pose_bone,
            mode,
            axis,
        )
        if not all(packed_pair):
            return None
        cache.clear()
        cache[cache_key] = packed_pair
    points = tuple(
        _smart_dragger_current_world_point(
            depsgraph,
            evaluated_armature,
            evaluated_bone,
            packed,
        )
        for packed in packed_pair
    )
    bone_axes = (
        evaluated_armature.matrix_world.to_3x3()
        @ evaluated_bone.matrix.to_3x3()
    )
    surface_axes = (axis, _smart_dragger_opposite_axis(axis))
    matrices = tuple(
        _smart_dragger_surface_matrix(
            context,
            point,
            packed,
            surface_axis,
            bone_axes,
        )
        for point, packed, surface_axis in zip(
            points,
            packed_pair,
            surface_axes,
        )
    )
    normals = tuple(matrix.to_3x3().col[2].normalized() for matrix in matrices)
    target_key = (
        _armature_session_uid(armature),
        pose_bone.name,
        int(context.scene.frame_current),
        mode,
        axis,
    )
    targets = _state.setdefault("smart_dragger_targets", {})
    target_state = targets.get(target_key)
    target_point = points[0].copy()
    target_normal = normals[0].copy()
    if target_state is not None:
        target_point = Vector(target_state[0])
        target_normal = Vector(target_state[1])
        if target_normal.length_squared <= 1.0e-12:
            target_normal = normals[0].copy()
        else:
            target_normal.normalize()
    result = {
        "armature": armature,
        "pose_bone": pose_bone,
        "points": points,
        "dragger_points": (target_point, points[1]),
        "anchor_point": points[0],
        "target_point": target_point,
        "target_normal": target_normal,
        "target_key": target_key,
        "normals": normals,
        "matrices": (
            _smart_dragger_surface_contact_matrix(
                matrices[0],
                (target_point, target_normal),
            ),
            matrices[1],
        ),
        "packed": packed_pair,
        "cache_key": cache_key,
    }
    if target_state is None:
        # Match creation of a pink Contact pin: cast from the configured limb
        # face and show the surface target before the limb is touching it.
        # Requiring contact here collapsed target and anchor into one point,
        # which hid both the magnetic guide line and the target endpoint.
        objects, _active = _targets(context, armature)
        contact_planes = _smart_dragger_collision_planes(
            context,
            points[:1],
            normals[:1],
            set(objects) | {armature},
            max(
                1.0,
                float(pose_bone.length) * 20.0,
                (points[0] - points[1]).length * 10.0,
            ),
        )
        contact_plane = contact_planes[0] if contact_planes else None
        contact_plane = _smart_dragger_orient_red_plane(
            contact_plane,
            normals[0],
        )
        if contact_plane is not None:
            target_matrix = _smart_dragger_surface_contact_matrix(
                matrices[0],
                contact_plane,
            )
            result["target_point"] = target_matrix.translation.copy()
            result["target_normal"] = Vector(contact_plane[1]).normalized()
            result["dragger_points"] = (result["target_point"], points[1])
            result["matrices"] = (target_matrix, matrices[1])
            # Freeze the inferred target immediately. Without this transient
            # state, every evaluated redraw re-cast from the moving limb, so
            # native gizmo movement dragged the red target along with the bone
            # and made detaching from the apparent snap impossible.
            targets[target_key] = (
                tuple(float(value) for value in result["target_point"]),
                tuple(float(value) for value in result["target_normal"]),
            )
    geometrically_attached = bool(
        (Vector(result["anchor_point"]) - Vector(result["target_point"])).length
        <= PIN_SNAP_WORLD_RADIUS
        or _pin_points_within_snap_radius(
            context,
            result["target_point"],
            result["anchor_point"],
            pixel_radius=PIN_SNAP_PIXEL_RADIUS,
        )
    )
    attached_keys = _state.setdefault("smart_dragger_attached_keys", set())
    if geometrically_attached and not _state.get(
        "smart_dragger_transform_active", False,
    ):
        attached_keys.add(target_key)
    result["attached"] = target_key in attached_keys
    return result


def _smart_dragger_collision_fraction(context, starts, ends, excluded):
    fraction = 1.0
    for start, end in zip(starts, ends):
        delta = Vector(end) - Vector(start)
        distance = delta.length
        if distance <= 1.0e-8:
            continue
        direction = delta / distance
        epsilon = min(1.0e-4, distance * 0.05)
        hit = _surface_contact_ray_cast(
            context,
            Vector(start) + (direction * epsilon),
            direction,
            max(0.0, distance - epsilon),
            excluded,
        )
        if hit is None:
            continue
        hit_fraction = max(
            0.0,
            min(1.0, (float(hit[3]) + epsilon - 1.0e-4) / distance),
        )
        fraction = min(fraction, hit_fraction)
    return fraction


def _smart_dragger_apply_world_delta(context, data, world_delta):
    armature = data["armature"]
    pose_bone = data["pose_bone"]
    initial_world = data["initial_world"]
    desired_world = world_delta @ initial_world
    desired_output = armature.matrix_world.inverted_safe() @ desired_world
    return _set_pose_bone_constrained_output_matrix(
        context,
        armature,
        pose_bone,
        desired_output,
        atomic=True,
    )


def _smart_dragger_apply_world_target(
    context,
    data,
    world_delta,
    target_point,
):
    """Move the captured limb point onto the temporary target without lag."""
    changed = _smart_dragger_apply_world_delta(context, data, world_delta)
    packed = data.get("packed")
    armature = data.get("armature")
    pose_bone = data.get("pose_bone")
    if packed is None or armature is None or pose_bone is None:
        return changed

    target_point = Vector(target_point)
    for _iteration in range(3):
        context.view_layer.update()
        depsgraph = context.evaluated_depsgraph_get()
        evaluated_armature = armature.evaluated_get(depsgraph)
        evaluated_bone = evaluated_armature.pose.bones.get(pose_bone.name)
        if evaluated_bone is None:
            break
        current_point = Vector(
            _yellow_current_world_point(
                depsgraph,
                evaluated_armature,
                evaluated_bone,
                packed,
            )
        )
        correction = target_point - current_point
        if correction.length_squared <= 1.0e-10:
            break
        current_world = evaluated_armature.matrix_world @ evaluated_bone.matrix
        desired_world = Matrix.Translation(correction) @ current_world
        desired_output = armature.matrix_world.inverted_safe() @ desired_world
        corrected = _set_pose_bone_constrained_output_matrix(
            context,
            armature,
            pose_bone,
            desired_output,
            atomic=True,
        )
        changed = bool(corrected) or changed
        if not corrected:
            break
    return changed


def _smart_dragger_apply_world_matrix(context, armature, pose_bone, world_matrix):
    return _set_pose_bone_constrained_output_matrix(
        context,
        armature,
        pose_bone,
        armature.matrix_world.inverted_safe() @ Matrix(world_matrix),
        atomic=True,
    )


def _smart_dragger_rotated_world(initial_world, pivot, source, requested):
    """Rotate one rigid limb around the opposite planted endpoint."""
    pivot = Vector(pivot)
    source_vector = Vector(source) - pivot
    requested_vector = Vector(requested) - pivot
    if (
        source_vector.length_squared <= 1.0e-12
        or requested_vector.length_squared <= 1.0e-12
    ):
        return Matrix(initial_world).copy()
    rotation = source_vector.normalized().rotation_difference(
        requested_vector.normalized()
    )
    return (
        Matrix.Translation(pivot)
        @ rotation.to_matrix().to_4x4()
        @ Matrix.Translation(-pivot)
        @ Matrix(initial_world)
    )


def _smart_dragger_project_2d(context, point):
    try:
        from bpy_extras import view3d_utils

        return view3d_utils.location_3d_to_region_2d(
            context.region,
            context.region_data,
            point,
        )
    except (AttributeError, RuntimeError, TypeError, ValueError):
        return None


def _smart_dragger_magnetic_snap_point(context, start, desired, target):
    """Admit endpoint and swept crossings with the pink pin snap radius."""
    start = Vector(start)
    desired = Vector(desired)
    target = Vector(target)
    if (
        (desired - target).length <= PIN_SNAP_WORLD_RADIUS
        or _pin_points_within_snap_radius(
            context,
            target,
            desired,
            pixel_radius=PIN_SNAP_PIXEL_RADIUS,
        )
    ):
        return target.copy(), True
    movement = desired - start
    if movement.length_squared <= 1.0e-12:
        return desired, False
    factor = max(
        0.0,
        min(1.0, (target - start).dot(movement) / movement.length_squared),
    )
    swept = start.lerp(desired, factor)
    crossed = bool(
        factor < 1.0
        and (
            (swept - target).length <= PIN_SNAP_WORLD_RADIUS
            or _pin_points_within_snap_radius(
                context,
                target,
                swept,
                pixel_radius=PIN_SNAP_PIXEL_RADIUS,
            )
        )
    )
    return (target.copy(), True) if crossed else (desired, False)


def _smart_dragger_red_contact_plane(context, data):
    if not data or data.get("armature") is None:
        return None
    objects, _active = _targets(context, data["armature"])
    planes = _smart_dragger_collision_planes(
        context,
        data["points"][:1],
        data["normals"][:1],
        set(objects) | {data["armature"]},
        PIN_SNAP_WORLD_RADIUS * 1.05,
    )
    fallback = planes[0] if planes else None
    plane = _smart_dragger_live_red_plane(
        context,
        data["points"][0],
        fallback,
        set(objects) | {data["armature"]},
        PIN_SNAP_WORLD_RADIUS * 1.5,
        data["normals"][0],
    )
    if plane is None or not _smart_dragger_plane_touching(
        data["points"][0], plane
    ):
        return None
    return plane


def _smart_dragger_red_contact_visible(context, data):
    return _smart_dragger_red_contact_plane(context, data) is not None


def _smart_dragger_contact_surface(
    context,
    armature,
    target_point,
    excluded,
):
    """Resolve the mesh owning a Smart target already cast onto a surface."""
    depsgraph = context.evaluated_depsgraph_get()
    target_point = Vector(target_point)
    best = None
    for surface in getattr(context.scene, "objects", ()):
        if surface in excluded or getattr(surface, "type", "") != "MESH":
            continue
        try:
            if not surface.visible_get():
                continue
        except (AttributeError, RuntimeError):
            pass
        closest = _surface_contact_closest_point(
            surface,
            target_point,
            depsgraph,
            max(0.25, PIN_SNAP_WORLD_RADIUS * 4.0),
        )
        if closest is None:
            continue
        point, normal = closest
        distance = (Vector(point) - target_point).length
        if best is None or distance < best[0]:
            best = (distance, surface, Vector(point), Vector(normal))
    return best[1:] if best is not None else (None, None, None)


def _smart_dragger_contact_geometry(context, armature, selected_bone):
    """Resolve the same effector and support geometry used by pink Contact."""
    relation = _surface_contact_ik_relation(armature, selected_bone)
    effector = relation["effector"] if relation is not None else selected_bone
    for geometry_bone in _surface_contact_geometry_bone_candidates(
        selected_bone,
        relation,
    ):
        geometry = _surface_contact_part_geometry(
            context,
            armature,
            geometry_bone,
        )
        if geometry[2] is not None and geometry[3]:
            return relation, effector, geometry
    return relation, effector, None


def _smart_dragger_apply_contact_target(
    context,
    data,
    target_point,
    target_normal,
):
    """Solve one temporary target through the real pink Contact pipeline."""
    armature = data.get("armature")
    selected_bone = data.get("pose_bone")
    if armature is None or selected_bone is None:
        return ()
    relation, effector, geometry = _smart_dragger_contact_geometry(
        context,
        armature,
        selected_bone,
    )
    if geometry is None:
        return ()
    (
        evaluated_armature,
        evaluated_geometry_bone,
        part,
        _geometry_points,
        support_objects,
    ) = geometry
    objects, _active = _targets(context, armature)
    surface, surface_point, surface_normal = _smart_dragger_contact_surface(
        context,
        armature,
        target_point,
        set(objects) | {armature},
    )
    if surface is None:
        return ()
    if Vector(target_normal).length_squared > 1.0e-12:
        surface_normal = Vector(target_normal).normalized()
    frame = int(context.scene.frame_current)
    before = {
        pose_bone.name: pose_bone.matrix.copy()
        for pose_bone in armature.pose.bones
    }
    if relation is None and not effector.constraints:
        raw_world = Matrix(data.get("initial_world", armature.matrix_world @ effector.matrix))
        support = data.get("support_local")
        anchor = (raw_world @ Vector(support) if support
                  else Vector(data["anchor_point"]))
        opposite = Vector(data.get("opposite_point", raw_world @ Vector((0, effector.length, 0))))
        identity = data.get("pressure_guide") or _SmartDraggerContactGuide(armature, effector)
        solved = _surface_contact_magnetic_rod_world(
            identity, raw_world, surface_point, surface_normal,
            anchor, opposite, attached=True)
        changed = _smart_dragger_apply_world_matrix(context, armature, effector, solved)
        return (effector.name,) if changed else ()
    guide = None
    suspended = _surface_contact_suspend_guides(
        _surface_contact_guides_for_effector(armature, effector)
    )
    try:
        target_world = _surface_contact_plane_matrix(
            surface_point,
            surface_normal,
            _surface_contact_target_world_matrix(
                context,
                armature,
                effector.name,
            ),
        )
        guide = _surface_contact_create_guide(
            context,
            armature,
            effector,
            armature,
            effector.name,
            evaluated_geometry_bone.name,
            target_world,
            surface,
            surface_point,
            surface_normal,
            max(float(effector.length), 0.05),
            frame,
        )
        guide[SURFACE_CONTACT_PIN_MODE_PROPERTY] = str(
            getattr(context.window_manager, "smart_dragger_mode", "MODE_3")
        )
        guide[SURFACE_CONTACT_OBJECT_PROPERTY] = part.name
        guide[SURFACE_CONTACT_CAST_AXIS_PROPERTY] = str(
            getattr(context.window_manager, "smart_dragger_axis", "Y_NEG")
        )
        support_local = data.get("support_local")
        support_geometry_name = str(data.get("support_geometry_name", ""))
        if (
            support_local is not None
            and len(support_local) >= 3
            and support_geometry_name == evaluated_geometry_bone.name
        ):
            guide[SURFACE_CONTACT_SUPPORT_PROPERTY] = tuple(
                float(value) for value in support_local[:3]
            )
        else:
            geometry_world = (
                evaluated_armature.matrix_world @ evaluated_geometry_bone.matrix
            )
            guide[SURFACE_CONTACT_SUPPORT_PROPERTY] = tuple(
                geometry_world.inverted_safe() @ Vector(data["anchor_point"])
            )
        primary, solver = _surface_contact_add_dot_constraint(
            context,
            guide,
            armature,
            effector,
            relation,
        )
        if solver is None or (
            primary is None
            and str(guide.get(SURFACE_CONTACT_KIND_PROPERTY, ""))
            != SURFACE_CONTACT_KIND_SIMULATED
        ):
            return ()
        _surface_contact_publish_creation_attachment(guide, True)
        solved_anchor, _final_support = _surface_contact_align_solver(
            context,
            guide,
            armature,
            evaluated_geometry_bone.name,
            support_objects,
        )
        if solved_anchor is None:
            return ()
        context.view_layer.update()
        solved = {
            pose_bone.name: pose_bone.matrix.copy()
            for pose_bone in armature.pose.bones
        }
    finally:
        if guide is not None and guide.name in bpy.data.objects:
            _surface_contact_remove_guide(context, guide)
        _surface_contact_restore_suspended(suspended)
    changed_names = tuple(
        name
        for name, matrix in solved.items()
        if any(
            abs(float(matrix[row][column]) - float(before[name][row][column]))
            > 1.0e-7
            for row in range(4)
            for column in range(4)
        )
    )
    for name in changed_names:
        pose_bone = armature.pose.bones.get(name)
        if pose_bone is not None:
            pose_bone.matrix = solved[name]
    context.view_layer.update()
    return changed_names


class ANIMATOR_UTILS_OT_smart_dragger_transform(bpy.types.Operator):
    bl_idname = "staticaliza.smart_dragger_transform"
    bl_label = "Transform Smart Dragger"
    bl_description = "Pose the active limb from its selected Smart Dragger"
    bl_options = {"REGISTER", "UNDO", "BLOCKING"}

    transform_mode: bpy.props.EnumProperty(
        items = (
            ("TRANSLATE", "Move", ""),
            ("ROTATE", "Rotate", ""),
        ),
        options = {"HIDDEN", "SKIP_SAVE"},
    )
    initial_axis: bpy.props.IntProperty(
        default = -1,
        min = -1,
        max = 2,
        options = {"HIDDEN", "SKIP_SAVE"},
    )
    dragger_side: bpy.props.IntProperty(
        default = -1,
        min = -1,
        max = 1,
        options = {"HIDDEN", "SKIP_SAVE"},
    )
    finish_on_release: bpy.props.BoolProperty(
        default = False,
        options = {"HIDDEN", "SKIP_SAVE"},
    )

    @classmethod
    def poll(cls, context):
        return getattr(context, "mode", "") == "POSE" and getattr(
            getattr(context, "area", None), "type", ""
        ) == "VIEW_3D"

    def invoke(self, context, event):
        side = int(self.dragger_side)
        self.bone_drag = False
        if side not in (0, 1):
            active_bone = getattr(context, "active_pose_bone", None)
            if active_bone is not None and _pose_bone_selected(active_bone):
                side = 0
                self.bone_drag = True
            else:
                side = int(_state.get("smart_dragger_selected_side", -1))
        if side not in (0, 1):
            # G/R on the selected bone uses the red surface target exactly as
            # a pink Contact bone does: move the bone freely, then admit a
            # magnetic snap only when its real endpoint reaches the target.
            if not getattr(
                context.window_manager,
                "smart_draggers_enabled",
                False,
            ):
                return {"PASS_THROUGH"}
            side = 0
            self.bone_drag = True
        dragger = _smart_dragger_data(context)
        if dragger is None:
            return {"PASS_THROUGH"}
        self.target_only_drag = bool(not self.bone_drag and side == 0)
        if int(self.dragger_side) in (0, 1):
            _pin_gizmo_claim_pointer(event)
            _pin_deselect_target(push_history = False)
            _state["smart_dragger_selected_side"] = side
            _state["smart_dragger_owner"] = (
                dragger["armature"].name,
                dragger["pose_bone"].name,
            )
            # Clear Blender's active pose-bone pointer after preserving the
            # owner above. Otherwise its native transform gizmo remains at the
            # limb endpoint and steals pointer ownership from the red target.
            _pin_deselect_pose_bones(context)
            _state["smart_dragger_selection_keys"] = (
                _pin_pose_selection_signature(context)
            )
            _state["smart_dragger_extend_selection_until"] = 0.0
        armature = dragger["armature"]
        pose_bone = dragger["pose_bone"]
        _smart_dragger_ensure_initial_basis(pose_bone)
        evaluated = armature.evaluated_get(
            context.evaluated_depsgraph_get()
        ).pose.bones.get(pose_bone.name)
        if evaluated is None:
            return {"PASS_THROUGH"}
        self.armature_name = armature.name
        self.bone_name = pose_bone.name
        self.side = side
        self.axis_index = int(self.initial_axis)
        self.initial_basis = pose_bone.matrix_basis.copy()
        self.initial_pose_bases = {
            bone.name: bone.matrix_basis.copy()
            for bone in armature.pose.bones
        }
        self.changed_bone_names = set()
        self.magnetic_snapped = False
        self.initial_world = armature.matrix_world @ evaluated.matrix
        source_points = (
            (dragger["anchor_point"], dragger["points"][1])
            if self.bone_drag
            else dragger["dragger_points"]
        )
        self.initial_points = tuple(point.copy() for point in source_points)
        self.initial_normals = tuple(
            normal.copy() for normal in dragger["normals"]
        )
        self.initial_point = self.initial_points[side].copy()
        self.magnetic_target_point = Vector(dragger["target_point"])
        self.magnetic_target_normal = Vector(dragger["target_normal"])
        self.anchor_point = Vector(dragger["anchor_point"])
        self.contact_released = False
        self.anchor_local = self.initial_world.inverted_safe() @ self.anchor_point
        head_local = Vector((0.0, 0.0, 0.0))
        tail_local = Vector((0.0, max(float(pose_bone.length), 1.0e-8), 0.0))
        self.opposite_local = max(
            (head_local, tail_local),
            key=lambda point: (
                (self.initial_world @ point) - self.anchor_point
            ).length_squared,
        )
        self.opposite_point = Vector(dragger["points"][1])
        self.opposite_local = self.initial_world.inverted_safe() @ self.opposite_point
        self.pressure_guide = _SmartDraggerContactGuide(armature, pose_bone)
        self.support_geometry_name = ""
        self.support_local = ()
        _relation, _effector, contact_geometry = (
            _smart_dragger_contact_geometry(context, armature, pose_bone)
        )
        if contact_geometry is not None:
            support_armature, support_bone = contact_geometry[:2]
            support_world = support_armature.matrix_world @ support_bone.matrix
            self.support_geometry_name = support_bone.name
            self.support_local = tuple(
                support_world.inverted_safe() @ self.anchor_point
            )
        self.packed_capture = dragger["packed"][side]
        self.target_key = tuple(dragger["target_key"])
        attached_keys = _state.setdefault("smart_dragger_attached_keys", set())
        self.initial_attached = self.target_key in attached_keys
        self.contact_keep_attached = bool(
            self.initial_attached or dragger.get("attached", False)
        )
        self.initial_target_state = _state.setdefault(
            "smart_dragger_targets",
            {},
        ).get(self.target_key)
        self.surface_query_guide = {
            SURFACE_CONTACT_ARMATURE_PROPERTY: armature.name,
            SURFACE_CONTACT_BONE_PROPERTY: pose_bone.name,
            SURFACE_CONTACT_GEOMETRY_BONE_PROPERTY: pose_bone.name,
        }
        self.bound_surface_name = ""
        self.initial_mouse = Vector((
            float(event.mouse_region_x),
            float(event.mouse_region_y),
        ))
        self.orientation = _pin_transform_orientation_matrix(
            context,
            ("YELLOW", armature, pose_bone, dragger["packed"][side]),
        )
        self.plane_axis_index = -1
        self.axis_offset = Vector((0.0, 0.0, 0.0))
        if self.axis_index >= 0:
            axis = self.orientation.col[self.axis_index]
            axis_point = _pin_gizmo_axis_mouse_point(
                context,
                self.initial_point,
                axis,
                self.initial_mouse,
            )
            if axis_point is not None:
                self.axis_offset = self.initial_point - axis_point
        else:
            plane_point = _pin_gizmo_mouse_plane_point(
                context,
                self.initial_point,
                self.initial_mouse,
            )
            if plane_point is not None:
                self.axis_offset = self.initial_point - plane_point
        objects, _active = _targets(context, armature)
        self.excluded = set(objects)
        self.excluded.add(armature)
        self.collision_planes = _smart_dragger_collision_planes(
            context,
            self.initial_points,
            dragger["normals"],
            self.excluded,
            max(
                1.0,
                float(pose_bone.length) * 20.0,
                (self.initial_points[0] - self.initial_points[1]).length
                * 10.0,
            ),
        )
        if self.collision_planes and self.collision_planes[0] is not None:
            self.collision_planes = (
                _smart_dragger_orient_red_plane(
                    self.collision_planes[0],
                    self.initial_normals[0],
                ),
                *self.collision_planes[1:],
            )
        self.collision_support_points = (
            _smart_dragger_welded_support_points(
                context,
                dragger["packed"],
            )
        )
        collision_enabled = True
        initial_red_plane = (
            self.collision_planes[0] if self.collision_planes else None
        )
        self.red_contact_active = False
        if collision_enabled and initial_red_plane is not None:
            plane_point, plane_normal = initial_red_plane
            self.red_contact_active = bool(
                (self.initial_points[0] - Vector(plane_point)).dot(
                    Vector(plane_normal).normalized()
                ) <= PIN_SNAP_WORLD_RADIUS
            )
        if collision_enabled:
            initial_surface = _surface_contact_mouse_surface_point(
                context,
                self.surface_query_guide,
                self.initial_mouse,
            )
            if initial_surface is not None:
                self.bound_surface_name = initial_surface[0].name
        self.pivot_world = self.initial_points[0].copy()
        self.pivot_2d = _smart_dragger_project_2d(context, self.pivot_world)
        self.moved = False
        _state["smart_dragger_transform_active"] = True
        _state["smart_dragger_target_drag_active"] = bool(
            self.target_only_drag
        )
        _pin_transform_begin_keyboard_presentation(self, context)
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def _translation_delta(self, context, event):
        mouse = (event.mouse_region_x, event.mouse_region_y)
        if self.plane_axis_index >= 0:
            normal = self.orientation.col[self.plane_axis_index].normalized()
            start = _pin_gizmo_oriented_plane_point(
                context,
                self.initial_point,
                normal,
                self.initial_mouse,
            )
            point = _pin_gizmo_oriented_plane_point(
                context,
                self.initial_point,
                normal,
                mouse,
            )
            if start is None or point is None:
                return None
            return point - start
        if self.axis_index >= 0:
            axis = self.orientation.col[self.axis_index]
            point = _pin_gizmo_axis_mouse_point(
                context,
                self.initial_point,
                axis,
                mouse,
            )
        else:
            point = _pin_gizmo_mouse_plane_point(
                context,
                self.initial_point,
                mouse,
            )
        return (
            (point + self.axis_offset - self.initial_point)
            if point is not None
            else None
        )

    def _rotation_angle(self, event):
        if self.pivot_2d is None:
            return 0.0
        before = self.initial_mouse - Vector(self.pivot_2d)
        after = Vector((
            float(event.mouse_region_x),
            float(event.mouse_region_y),
        )) - Vector(self.pivot_2d)
        if before.length_squared <= 1.0e-8 or after.length_squared <= 1.0e-8:
            return 0.0
        before.normalize()
        after.normalize()
        return math.atan2(
            (before.x * after.y) - (before.y * after.x),
            before.dot(after),
        )

    def _apply_event(self, context, event):
        collision_enabled = True
        red_plane = (
            self.collision_planes[0]
            if collision_enabled and self.collision_planes
            else None
        )
        if self.transform_mode == "ROTATE":
            angle = self._rotation_angle(event)
            axis = (
                self.orientation.col[self.axis_index].normalized()
                if self.axis_index >= 0
                else _pin_keyboard_view_axis(context)
            )
            world_delta = (
                Matrix.Translation(self.pivot_world)
                @ Matrix.Rotation(angle, 4, axis)
                @ Matrix.Translation(-self.pivot_world)
            )
        else:
            delta = self._translation_delta(context, event)
            if delta is None:
                return False
            desired_point = self.initial_point + delta
            if self.side == 0:
                if self.bone_drag:
                    # Keep the mouse's raw pose intact. The shared contact
                    # solver owns attraction and pressure in one pass.
                    world_delta = Matrix.Translation(
                        desired_point - self.initial_point
                    )
                else:
                    bound_surface_drag = False
                    free_surface_drag = bool(
                        collision_enabled
                        and self.axis_index < 0
                        and self.plane_axis_index < 0
                    )
                if not self.bone_drag and free_surface_drag:
                    # Match the pink Contact target's cursor raycast and limb
                    # exclusion exactly; the Smart target remains transient.
                    surface_hit = _surface_contact_mouse_surface_point(
                        context,
                        self.surface_query_guide,
                        (event.mouse_region_x, event.mouse_region_y),
                    )
                    if surface_hit is None:
                        return False
                    surface, surface_point, _surface_normal = surface_hit
                    closest = _surface_contact_closest_point(
                        surface,
                        surface_point,
                        context.evaluated_depsgraph_get(),
                        max(
                            1.0,
                            (Vector(surface_point) - desired_point).length
                            * 4.0,
                        ),
                    )
                    if closest is None:
                        return False
                    desired_point, surface_normal = closest
                    self.bound_surface_name = surface.name
                    red_plane = (
                        Vector(desired_point),
                        Vector(surface_normal).normalized(),
                    )
                    self.red_contact_active = True
                elif (
                    not self.bone_drag
                    and collision_enabled
                    and self.bound_surface_name
                ):
                    # Axis-constrained movement stays on the initially bound
                    # surface, like the axis handles of a selected pink pin.
                    surface = bpy.data.objects.get(self.bound_surface_name)
                    closest = (
                        _surface_contact_closest_point(
                            surface,
                            desired_point,
                            context.evaluated_depsgraph_get(),
                            max(
                                1.0,
                                (desired_point - self.initial_point).length
                                * 4.0,
                            ),
                        )
                        if surface is not None
                        else None
                    )
                    if closest is not None:
                        desired_point, surface_normal = closest
                        red_plane = (
                            Vector(desired_point),
                            Vector(surface_normal).normalized(),
                        )
                        self.red_contact_active = True
                        bound_surface_drag = True
                if (
                    not self.bone_drag
                    and
                    collision_enabled
                    and not free_surface_drag
                    and not bound_surface_drag
                    and self.red_contact_active
                    and red_plane is not None
                ):
                    live_plane = _smart_dragger_live_red_plane(
                        context,
                        desired_point,
                        red_plane,
                        self.excluded,
                        PIN_SNAP_WORLD_RADIUS * 2.0,
                        self.initial_normals[0],
                    )
                    live_plane = _smart_dragger_orient_red_plane(
                        live_plane,
                        self.initial_normals[0],
                    )
                    if live_plane is not None:
                        red_plane = live_plane
                        if self.collision_planes:
                            self.collision_planes = (
                                red_plane,
                                *self.collision_planes[1:],
                            )
                if (
                    not self.bone_drag
                    and
                    collision_enabled
                    and not free_surface_drag
                    and not bound_surface_drag
                ):
                    if not self.red_contact_active or red_plane is None:
                        # Use the complete drag segment, not only the surface
                        # that happened to be near red at mouse-down.  This
                        # is the same no-tunnelling rule used by Contact pins.
                        red_plane = _smart_dragger_swept_red_plane(
                            context,
                            self.initial_point,
                            desired_point,
                            self.excluded,
                        )
                        if red_plane is None:
                            red_plane = _smart_dragger_live_red_plane(
                                context,
                                desired_point,
                                self.collision_planes[0]
                                if self.collision_planes else None,
                                self.excluded,
                                PIN_SNAP_WORLD_RADIUS * 1.5,
                                self.initial_normals[0],
                            )
                        red_plane = _smart_dragger_orient_red_plane(
                            red_plane,
                            self.initial_normals[0],
                        )
                        if red_plane is not None and _smart_dragger_plane_touching(
                            desired_point, red_plane
                        ):
                            self.red_contact_active = True
                        if red_plane is not None and self.collision_planes:
                            self.collision_planes = (
                                red_plane,
                                *self.collision_planes[1:],
                            )
                if (
                    not self.bone_drag
                    and
                    collision_enabled
                    and not free_surface_drag
                    and not bound_surface_drag
                    and self.red_contact_active
                    and red_plane is not None
                ):
                    plane_point, plane_normal = red_plane
                    signed_separation = (
                        desired_point - Vector(plane_point)
                    ).dot(Vector(plane_normal).normalized())
                    release_distance = max(
                        PIN_SNAP_WORLD_RADIUS * 1.5,
                        (self.initial_points[1] - self.initial_points[0]).length
                        * 0.08,
                    )
                    if signed_separation > release_distance:
                        self.red_contact_active = False
                if (
                    not self.bone_drag
                    and
                    collision_enabled
                    and not free_surface_drag
                    and not bound_surface_drag
                    and self.red_contact_active
                    and red_plane is not None
                ):
                    desired_point = _smart_dragger_red_contact_point(
                        context,
                        self.initial_point,
                        desired_point,
                        red_plane,
                        self.excluded,
                        hold_contact=True,
                    )
                # The old paired red/green rod intentionally lagged the upper
                # endpoint and resisted oblique mouse motion. A temporary pin
                # should instead follow the requested point exactly, like the
                # pink Contact target, while surface projection owns sliding.
                if not self.bone_drag:
                    world_delta = Matrix.Translation(
                        desired_point - self.initial_point
                    )
            else:
                world_delta = _smart_dragger_green_rod_delta(
                    self.initial_points,
                    desired_point,
                    red_plane,
                )
        if (
            collision_enabled
            and self.side == 0
            and red_plane is not None
            and not self.red_contact_active
        ):
            active_planes = (red_plane,)
            world_delta = _smart_dragger_collision_clamped_delta(
                self.initial_points,
                world_delta,
                active_planes,
                (),
            )
        data = {
            "armature": bpy.data.objects.get(self.armature_name),
            "pose_bone": None,
            "initial_world": self.initial_world,
            "packed": self.packed_capture,
            "anchor_point": self.anchor_point,
            "support_geometry_name": self.support_geometry_name,
            "support_local": self.support_local,
            "opposite_point": self.opposite_point,
            "pressure_guide": self.pressure_guide,
        }
        armature = data["armature"]
        if armature is None:
            return False
        data["pose_bone"] = armature.pose.bones.get(self.bone_name)
        if data["pose_bone"] is None:
            return False
        if (
            self.transform_mode == "TRANSLATE"
            and self.side == 0
            and self.target_only_drag
        ):
            target_normal = (
                Vector(red_plane[1]).normalized()
                if red_plane is not None
                else self.initial_normals[0].copy()
            )
            # A red target drag is the transient form of dragging a pink
            # Contact target: the target owns the requested surface point and
            # the Contact solver carries the limb toward it. Never overwrite
            # the target with the solved endpoint; doing so glued the red pin
            # to the leg and made surface sliding impossible.
            for bone_name, matrix_basis in self.initial_pose_bases.items():
                restored_bone = armature.pose.bones.get(bone_name)
                if restored_bone is not None:
                    restored_bone.matrix_basis = matrix_basis.copy()
            context.view_layer.update()
            changed_names = _smart_dragger_apply_contact_target(
                context,
                data,
                desired_point,
                target_normal,
            )
            contact_changed = bool(changed_names)
            targets = _state.setdefault("smart_dragger_targets", {})
            targets[self.target_key] = (
                tuple(float(value) for value in desired_point),
                tuple(float(value) for value in target_normal),
            )
            target_changed = bool(
                (desired_point - self.initial_point).length_squared > 1.0e-12
            )
            self.contact_keep_attached = bool(
                self.contact_keep_attached or contact_changed
            )
            if self.contact_keep_attached:
                _state.setdefault("smart_dragger_attached_keys", set()).add(
                    self.target_key
                )
            self.changed_bone_names.update(changed_names)
            changed = bool(target_changed or contact_changed)
        elif self.transform_mode == "TRANSLATE" and self.side == 0:
            raw_world = world_delta @ self.initial_world
            raw_anchor = raw_world @ self.anchor_local
            raw_opposite = raw_world @ self.opposite_local
            normal = Vector(self.magnetic_target_normal).normalized()
            within_release_ring = _pin_points_within_snap_radius(
                context, self.magnetic_target_point, raw_anchor,
                pixel_radius=PIN_SNAP_RELEASE_PIXEL_RADIUS)
            hold = bool(self.contact_keep_attached and within_release_ring)
            solved = _surface_contact_magnetic_rod_world(
                self.pressure_guide, raw_world, self.magnetic_target_point,
                normal, raw_anchor, raw_opposite, attached=hold)
            changed = _smart_dragger_apply_world_matrix(
                context, armature, data["pose_bone"], solved)
            solved_anchor = solved @ self.anchor_local
            self.contact_keep_attached = _pin_points_within_snap_radius(
                context, self.magnetic_target_point, solved_anchor)
            self.magnetic_snapped = self.contact_keep_attached
            self.contact_released = not self.contact_keep_attached
            attached_keys = _state.setdefault("smart_dragger_attached_keys", set())
            if self.contact_keep_attached:
                attached_keys.add(self.target_key)
            else:
                attached_keys.discard(self.target_key)
            if changed:
                self.changed_bone_names.add(self.bone_name)
        else:
            changed = _smart_dragger_apply_world_delta(
                context,
                data,
                world_delta,
            )
            if changed:
                self.changed_bone_names.add(self.bone_name)
        self.moved = bool(changed) or self.moved
        _tag_redraw_all_view3d()
        return bool(changed)

    def _finish(self, context, cancel):
        armature = bpy.data.objects.get(str(getattr(self, "armature_name", "")))
        pose_bone = (
            armature.pose.bones.get(str(getattr(self, "bone_name", "")))
            if armature is not None and getattr(armature, "pose", None)
            else None
        )
        try:
            if cancel and pose_bone is not None:
                for bone_name, matrix_basis in getattr(
                    self,
                    "initial_pose_bases",
                    {pose_bone.name: self.initial_basis},
                ).items():
                    restored_bone = armature.pose.bones.get(bone_name)
                    if restored_bone is not None:
                        restored_bone.matrix_basis = matrix_basis.copy()
                context.view_layer.update()
                targets = _state.setdefault("smart_dragger_targets", {})
                if self.initial_target_state is None:
                    targets.pop(self.target_key, None)
                else:
                    targets[self.target_key] = self.initial_target_state
                attached_keys = _state.setdefault(
                    "smart_dragger_attached_keys", set(),
                )
                if bool(getattr(self, "initial_attached", False)):
                    attached_keys.add(self.target_key)
                else:
                    attached_keys.discard(self.target_key)
            elif (
                self.moved
                and pose_bone is not None
                and (
                    not bool(getattr(self, "target_only_drag", False))
                    or bool(getattr(self, "changed_bone_names", None))
                )
            ):
                keyed_names = set(
                    getattr(self, "changed_bone_names", ())
                ) or {pose_bone.name}
                for bone_name in keyed_names:
                    keyed_bone = armature.pose.bones.get(bone_name)
                    if keyed_bone is not None:
                        _insert_bone_keys(
                            keyed_bone,
                            int(context.scene.frame_current),
                        )
        finally:
            _smart_dragger_clear_pressure(getattr(self, "pressure_guide", None))
            _pin_transform_end_keyboard_presentation(self, context)
            if not cancel:
                _state["smart_dragger_preserve_until"] = (
                    time.perf_counter() + 0.35
                )
            _state["smart_dragger_transform_active"] = False
            _state["smart_dragger_target_drag_active"] = False
            _state["smart_dragger_cache"] = {}
            _tag_redraw_all_view3d()

    def modal(self, context, event):
        if event.type == "MIDDLEMOUSE":
            if event.value == "PRESS":
                _state["pin_shared_transform_resync_pending"] = True
                self._finish(context, True)
                return {"CANCELLED"}
            return {"RUNNING_MODAL"}
        if event.type in {
            "WHEELUPMOUSE", "WHEELDOWNMOUSE",
            "WHEELINMOUSE", "WHEELOUTMOUSE",
        }:
            return {"RUNNING_MODAL"}
        if event.type in {"ESC", "RIGHTMOUSE"} and event.value == "PRESS":
            self._finish(context, True)
            return {"CANCELLED"}
        release_confirm = bool(self.finish_on_release) and (
            event.type == "LEFTMOUSE" and event.value == "RELEASE"
        )
        keyboard_confirm = not bool(self.finish_on_release) and (
            event.type in {"LEFTMOUSE", "RET", "NUMPAD_ENTER"}
            and event.value == "PRESS"
        )
        if release_confirm or keyboard_confirm:
            # Claim both mouse-up gizmo confirms and keyboard-G confirms.
            # Otherwise the confirming click is treated as an empty viewport
            # click and clears the active red/green pin.
            _pin_gizmo_claim_pointer(event)
            self._finish(context, False)
            return {"FINISHED"}
        if event.value == "PRESS" and event.type in {"X", "Y", "Z"}:
            axis_index = {"X": 0, "Y": 1, "Z": 2}[event.type]
            if event.shift and self.transform_mode == "TRANSLATE":
                self.plane_axis_index = (
                    -1
                    if self.plane_axis_index == axis_index
                    else axis_index
                )
                self.axis_index = -1
            else:
                self.axis_index = (
                    -1 if self.axis_index == axis_index else axis_index
                )
                self.plane_axis_index = -1
            self._apply_event(context, event)
            return {"RUNNING_MODAL"}
        if event.type == "MOUSEMOVE":
            self._apply_event(context, event)
        return {"RUNNING_MODAL"}

class ANIMATOR_UTILS_GT_smart_dragger(bpy.types.Gizmo):
    bl_idname = "ANIMATOR_UTILS_GT_smart_dragger"

    __slots__ = (
        "diamond_shape",
        "side",
    )

    def setup(self):
        if not hasattr(self, "diamond_shape"):
            self.diamond_shape = self.new_custom_shape(
                "TRIS",
                _PIN_GIZMO_DIAMOND_VERTICES,
            )

    def draw(self, context):
        _pin_gizmo_update_hover_cursor(context, self)
        self.draw_custom_shape(self.diamond_shape)

    def draw_select(self, _context, select_id):
        self.draw_custom_shape(self.diamond_shape, select_id=select_id)
class ANIMATOR_UTILS_GGT_smart_draggers(bpy.types.GizmoGroup):
    bl_idname = "ANIMATOR_UTILS_GGT_smart_draggers"
    bl_label = "Smart Dragger"
    bl_space_type = "VIEW_3D"
    bl_region_type = "WINDOW"
    bl_options = {"3D", "SELECT", "PERSISTENT"}

    @classmethod
    def poll(cls, context):
        return getattr(context, "mode", "") == "POSE"

    def setup(self, context):
        self.draggers = []
        for side, color in ((0, SMART_DRAGGER_RED),):
            gizmo = self.gizmos.new(ANIMATOR_UTILS_GT_smart_dragger.bl_idname)
            gizmo.side = side
            gizmo.color = color
            gizmo.color_highlight = color
            gizmo.alpha = 1.0
            gizmo.alpha_highlight = 1.0
            gizmo.scale_basis = PIN_GIZMO_DIAMOND_SCALE
            gizmo.line_width = 2.5
            gizmo.select_bias = PIN_GIZMO_CENTER_SELECT_BIAS
            gizmo.use_draw_modal = True
            gizmo.use_event_handle_all = False
            gizmo.hide = True
            gizmo.hide_select = True
            operator = gizmo.target_set_operator(
                "staticaliza.smart_dragger_transform"
            )
            operator.transform_mode = "TRANSLATE"
            operator.initial_axis = -1
            operator.dragger_side = side
            operator.finish_on_release = True
            self.draggers.append(gizmo)

    def draw_prepare(self, context):
        armature, bone = _smart_dragger_active_pose(context)
        if _smart_dragger_contact_owned(context, armature, bone):
            for gizmo in self.draggers:
                gizmo.hide = gizmo.hide_select = True
                gizmo.select = False
            return
        if not getattr(
            getattr(context, "window_manager", None),
            "smart_draggers_enabled",
            False,
        ):
            # A native G/R/S press can arrive before this persistent gizmo
            # group receives its normal disabled draw pass. Hide first so a
            # stale/default red or green diamond cannot flash at the moving
            # bone endpoint for the duration of Blender's modal interaction.
            for gizmo in self.draggers:
                _pin_gizmo_set_if_changed(gizmo, "hide", True)
                _pin_gizmo_set_if_changed(gizmo, "hide_select", True)
                _pin_gizmo_set_if_changed(gizmo, "select", False)
            return
        if (
            _state.get("smart_dragger_transform_active", False)
            and not _state.get("smart_dragger_target_drag_active", False)
            and not _smart_dragger_modal_is_running(context)
        ):
            # Blender can terminate a gizmo modal without returning through
            # our finish path (workspace/file changes and interrupted clicks
            # are common examples). Recover immediately so the persistent
            # red diamond does not remain hidden behind stale runtime state.
            _state["smart_dragger_transform_active"] = False
            _state["smart_dragger_target_drag_active"] = False
        if (
            _state.get("smart_dragger_transform_active", False)
            and not _state.get("smart_dragger_target_drag_active", False)
        ):
            for gizmo in self.draggers:
                _pin_gizmo_set_if_changed(gizmo, "hide", True)
                _pin_gizmo_set_if_changed(gizmo, "hide_select", True)
                _pin_gizmo_set_if_changed(gizmo, "select", False)
            return
        if not _state.get("smart_dragger_transform_active", False):
            transform_operator = _pin_active_transform_operator(context)
            if transform_operator:
                # Keep drawing state and hit-test flags untouched while
                # Blender owns the native modal interaction, but refresh the
                # evaluated matrices on every draw so the diamonds follow
                # their moving welded owner instead of jumping on confirm.
                if not _smart_dragger_refresh_live_gizmos(
                    context,
                    self.draggers,
                ):
                    for gizmo in self.draggers:
                        _pin_gizmo_set_if_changed(gizmo, "hide", True)
                        _pin_gizmo_set_if_changed(gizmo, "hide_select", True)
                return
            if _pin_primary_mouse_pressed():
                return
        data = _smart_dragger_data(context)
        if data is None:
            for gizmo in self.draggers:
                gizmo.hide = gizmo.hide_select = True
                gizmo.select = False
            return
        selected_side = int(_state.get("smart_dragger_selected_side", -1))
        transform_active = bool(_state.get("smart_dragger_transform_active", False))
        red_contact_plane = _smart_dragger_red_contact_plane(context, data)
        for side, gizmo in enumerate(self.draggers):
            matrix = data["matrices"][side]
            if side == 0 and red_contact_plane is not None:
                matrix = _smart_dragger_surface_contact_matrix(
                    matrix,
                    red_contact_plane,
                )
            _pin_gizmo_set_if_changed(gizmo, "matrix_basis", matrix)
            _pin_gizmo_set_if_changed(
                gizmo,
                "alpha",
                1.0 if side == selected_side else 0.36,
            )
            _pin_gizmo_set_if_changed(gizmo, "hide", False)
            _pin_gizmo_set_if_changed(
                gizmo,
                "hide_select",
                transform_active,
            )
            _pin_gizmo_set_if_changed(
                gizmo,
                "select",
                side == selected_side,
            )
            _pin_gizmo_set_if_changed(
                gizmo,
                "scale_basis",
                PIN_GIZMO_DIAMOND_SCALE,
            )
