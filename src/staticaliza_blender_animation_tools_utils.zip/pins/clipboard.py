"""Pose and pin clipboard and mirrored paste support."""

from ..core.runtime import *  # noqa: F403


def _pin_clipboard_key_at_frame(fcurve, frame):
    for point in getattr(fcurve, "keyframe_points", ()):
        if abs(float(point.co.x) - float(frame)) <= 1.0e-4:
            return {
                "value": _special_event_value(fcurve, point),
                "interpolation": str(point.interpolation),
            }
    return None


def _pin_clipboard_special_keys(armature, pose_bone, frame):
    action = _dynamic_parent_owner_action(armature)
    if action is None:
        return []
    result = []
    unparent_path = _unparent_dp(pose_bone.name)
    for fcurve in _fcurves_find_all(action, unparent_path, armature):
        key = _pin_clipboard_key_at_frame(fcurve, frame)
        if key is not None:
            result.append({"kind": "UNPARENT", "bone_name": pose_bone.name, **key})
            break
    constraints = tuple(
        constraint
        for constraint in pose_bone.constraints
        if _is_dynamic_state_constraint(constraint)
    )
    for index, constraint in enumerate(constraints):
        marker_path = _dynamic_parent_marker_data_path(constraint)
        for fcurve in _fcurves_find_all(action, marker_path, armature):
            key = _pin_clipboard_key_at_frame(fcurve, frame)
            if key is not None:
                result.append({
                    "kind": "DYNAMIC_PARENT",
                    "bone_name": pose_bone.name,
                    "constraint_name": constraint.name,
                    "constraint_index": index,
                    **key,
                })
                break
    return result


def _pin_clipboard_insert_special_key(
    armature,
    pose_bone,
    entry,
    frame,
):
    action = _dynamic_parent_owner_action(armature)
    if action is None:
        return False
    kind = str(entry.get("kind", ""))
    if kind == "UNPARENT":
        data_path = _unparent_dp(pose_bone.name)
    elif kind == "DYNAMIC_PARENT":
        constraints = tuple(
            constraint
            for constraint in pose_bone.constraints
            if _is_dynamic_state_constraint(constraint)
        )
        constraint = next((
            item
            for item in constraints
            if item.name == str(entry.get("constraint_name", ""))
        ), None)
        if constraint is None:
            index = int(entry.get("constraint_index", -1))
            constraint = constraints[index] if 0 <= index < len(constraints) else None
        if constraint is None:
            return False
        data_path = _dynamic_parent_marker_data_path(constraint)
    else:
        return False
    curves = tuple(_fcurves_find_all(action, data_path, armature))
    fcurve = curves[0] if curves else _action_new_fcurve(
        action,
        data_path,
        armature,
    )
    point = fcurve.keyframe_points.insert(
        float(frame),
        float(entry.get("value", 0.0)),
        options=set(),
    )
    _apply_new_motion_key_style(point)
    _special_event_set_value(fcurve, point, float(entry.get("value", 0.0)))
    try:
        point.interpolation = str(entry.get("interpolation", point.interpolation))
    except (TypeError, ValueError):
        pass
    _special_event_display(fcurve)
    fcurve.update()
    return True

def _pin_parent_world_matrix(armature, pose_bone):
    if armature is None:
        return Matrix.Identity(4)
    if pose_bone is not None and pose_bone.parent is not None:
        return armature.matrix_world @ pose_bone.parent.matrix
    return armature.matrix_world.copy()


def _pin_mirror_world_matrix(
    armature,
    source_pose_bone = None,
    target_pose_bone = None,
    frame = None,
):
    """Follow the rest-derived bilateral plane with the rig's root motion."""
    rest = _mirror_rig_rest(armature)
    plane = _mirror_rest_plane(armature)
    root = armature.pose.bones.get(rest['root'])
    if root is not None:
        posed = (root.matrix.copy() if frame is None else
                 _surface_contact_release_bone_matrix(armature, root, frame, {}))
        plane = posed @ root.bone.matrix_local.inverted_safe() @ plane
    world = (armature.matrix_world if frame is None else
             _surface_contact_release_object_matrix(armature, frame, {}))
    return world @ plane



def _pin_clipboard_capture(context):
    _selected_key, selected_target = _pin_selected_target_data(context)
    # A selected virtual target is its own component, even when Blender also
    # highlights its owning bone. Bone transforms require an explicit copy.
    pin_only = selected_target is not None
    pose_grouped = {} if pin_only else _selected_pose_bones_by_owner(context)
    grouped = {
        armature: list(pose_bones)
        for armature, pose_bones in pose_grouped.items()
    }

    # A pin is a virtual selection and deliberately may be selected without
    # its pose bone. Include its associated bone for pin capture without
    # pretending that Blender's pose itself was selected for copying.
    if selected_target is not None:
        _kind, armature, pose_bone, _payload = selected_target
        if armature is not None and pose_bone is not None:
            owner_bones = grouped.setdefault(armature, [])
            if all(item.name != pose_bone.name for item in owner_bones):
                owner_bones.append(pose_bone)
    if not grouped:
        return None
    frame = int(context.scene.frame_current)
    owners = []
    for armature, pose_bones in grouped.items():
        entries = []
        special_keys = []
        for pose_bone in (pose_bones if pin_only else ()):
            opposite_bone = armature.pose.bones.get(
                _mirror_counterpart_name(armature, pose_bone.name)
            )
            mirror_inverse = _pin_mirror_world_matrix(
                armature,
                pose_bone,
                opposite_bone,
            ).inverted_safe()
            parent_world = _pin_parent_world_matrix(armature, pose_bone)
            parent_inverse = parent_world.inverted_safe()
            packed = _state.get("yellow_fixed", {}).get(
                _owner_bone_key(armature, pose_bone.name)
            )
            if packed and pin_only and selected_target[0] == 'YELLOW':
                target_world = Vector(packed[0])
                entries.append({
                    "kind": "YELLOW",
                    "bone_name": pose_bone.name,
                    "parent_name": (
                        pose_bone.parent.name if pose_bone.parent else ""
                    ),
                    "local_offset": tuple(parent_inverse @ target_world),
                    "armature_offset": tuple(
                        armature.matrix_world.inverted_safe() @ target_world
                    ),
                    "mirror_offset": tuple(mirror_inverse @ target_world),
                })
            contact_guides = _surface_contact_guides_for_selected_bone(
                armature,
                pose_bone,
                frame,
            )
            if not pin_only or selected_target[0] != 'CONTACT':
                contact_guides = ()
            if (pin_only and selected_target[0] == "CONTACT"
                    and selected_target[1] == armature
                    and selected_target[2] == pose_bone):
                contact_guides = (selected_target[3],)
            if contact_guides:
                guide = max(
                    contact_guides,
                    key = lambda item: int(
                        item.get(
                            SURFACE_CONTACT_START_PROPERTY,
                            SPACE_MIN_FRAME,
                        )
                    ),
                )
                target_world = guide.matrix_world.translation.copy()
                entries.append({
                    "kind": "CONTACT",
                    "world_target": tuple(target_world),
                    "bone_name": pose_bone.name,
                    "parent_name": (
                        pose_bone.parent.name if pose_bone.parent else ""
                    ),
                    "local_offset": tuple(
                        parent_inverse @ target_world
                    ),
                    "armature_offset": tuple(
                        armature.matrix_world.inverted_safe() @ target_world
                    ),
                    "mirror_offset": tuple(mirror_inverse @ target_world),
                    "detached": bool(
                        _surface_contact_animated_detached_state(guide, frame)
                        if _surface_contact_animated_detached_state(guide, frame)
                        is not None
                        else guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)
                    ),
                })
            if pin_only and selected_target[0] == 'GYRO':
                guide = selected_target[3]
                target_world = Vector(guide.location)
                entries.append({'kind': 'GYRO', 'bone_name': pose_bone.name,
                    'world_target': tuple(target_world),
                    'local_offset': tuple(parent_inverse @ target_world),
                    'armature_offset': tuple(armature.matrix_world.inverted_safe() @ target_world),
                    'mirror_offset': tuple(mirror_inverse @ target_world)})
        owners.append({
            "session_uid": _armature_session_uid(armature),
            "armature_name": armature.name,
            "entries": entries,
            "special_keys": special_keys,
            "pose_entries": [dict(bone_name=bone.name, basis=tuple(v for row in bone.matrix_basis for v in row)) for bone in pose_grouped.get(armature, ())],
        })
    return {
        "owners": owners,
        "has_pose": bool(pose_grouped),
        "pin_only": pin_only,
    }


def _pin_clipboard_animation_values(owner, frame, paths=None):
    action = _dynamic_parent_owner_action(owner)
    result = []
    for curve in _action_fcurves(action, owner):
        if paths is not None and curve.data_path not in paths:
            continue
        if paths is None and curve.data_path not in {
                "location", "rotation_quaternion", "rotation_euler", "rotation_axis_angle", "scale"}:
            continue
        point = _fcurve_key_at(curve, frame)
        result.append({"path": curve.data_path, "index": curve.array_index,
                       "value": float(curve.evaluate(frame)),
                       "style": _surface_contact_key_style(point)})
    return result



def _pin_clipboard_hold_equal_auto_values(owner, frame, paths):
    """Keep all equal spans flat, including ones preceding the pasted key."""
    return _surface_contact_hold_equal_auto_values(owner, paths)



def _pin_clipboard_paste_animation_values(owner, frame, values):
    action = _dynamic_parent_owner_action(owner)
    if action is None:
        return False
    for row in values:
        curves = _fcurves_find_all(action, row["path"], owner)
        curve = next((item for item in curves if item.array_index == row["index"]), None)
        if curve is None:
            curve = _action_new_fcurve(action, row["path"], owner, index=row["index"])
        point = curve.keyframe_points.insert(float(frame), row["value"], options=set())
        _surface_contact_apply_key_style(point, row.get("style"))
        curve.update()
    action.update_tag()
    return bool(values)



def _pin_clipboard_selected_curve_keys(action, armature):
    rows = []
    for curve in _action_fcurves(action, armature):
        if not curve.data_path.startswith('pose.bones['):
            continue
        keys = [{"co": tuple(key.co), "left": tuple(key.handle_left),
                 "right": tuple(key.handle_right),
                 "style": _surface_contact_key_style(key)}
                for key in curve.keyframe_points if key.select_control_point]
        if keys:
            rows.append({"path": curve.data_path, "index": curve.array_index,
                         "group": curve.group.name if curve.group else "", "keys": keys,
                         "rotation_mode": next((b.rotation_mode for b in armature.pose.bones if curve.data_path.startswith(b.path_from_id())), "QUATERNION")})
    return rows


def _pin_clipboard_complete_pose_key(bone, frame, rows):
    """A partial channel copy must never become an implicit full-pose copy."""
    prefix = bone.path_from_id()+"."
    selected = {(row["path"], int(row["index"])) for row in rows
                if any(abs(float(key["co"][0])-float(frame)) <= 1.e-5 for key in row["keys"])}
    rotation = ("rotation_quaternion", 4) if bone.rotation_mode == "QUATERNION" else (
        ("rotation_axis_angle", 4) if bone.rotation_mode == "AXIS_ANGLE" else ("rotation_euler", 3))
    return all((prefix+prop, i) in selected
               for prop, size in (("location", 3), rotation) for i in range(size))


def _pin_clipboard_has_pose_keys(bone, frame, rows):
    """Only explicitly selected ordinary transform keys authorize pose data."""
    if bone is None:
        return False
    paths = {bone.path_from_id()+'.'+prop for prop in (
        'location', 'rotation_quaternion', 'rotation_euler', 'rotation_axis_angle', 'scale')}
    return any(row['path'] in paths and any(abs(float(k['co'][0])-float(frame)) <= 1.e-5
               for k in row['keys']) for row in rows)


def _pin_clipboard_contact_pose_reference(armature, bone, guide, frame):
    memo = {}
    arm_world = _surface_contact_release_object_matrix(armature, frame, memo)
    raw = arm_world @ _surface_contact_release_bone_matrix(armature, bone, frame, memo)
    support = Vector(tuple(guide.get(SURFACE_CONTACT_SUPPORT_PROPERTY, (0, 0, 0)))[:3])
    opposite = _surface_contact_opposite_local(guide, armature, bone, frame, memo)
    target_world = _surface_contact_release_object_matrix(guide, frame, memo)
    target = target_world.translation
    if _surface_contact_animated_detached_state(guide, frame) is True:
        raw = _surface_contact_detached_rod_world(raw, raw@support, raw@opposite,
            target, target_world.to_3x3().col[2].normalized())
    else:
        raw = _surface_contact_attached_rod_world(raw, support, opposite, target)
    return tuple(value for row in raw for value in row)


def _pin_clipboard_paste_contact_pose_reference(armature, bone, frame, packed, rows, source_frame):
    """Compensate the copied whole pose for the destination parent space."""
    if not packed or not _pin_clipboard_complete_pose_key(bone, source_frame, rows):
        return
    world = Matrix(tuple(tuple(packed[r*4+c] for c in range(4)) for r in range(4)))
    memo = {}
    parent = {} if bone.parent is None else dict(
        parent_matrix=_surface_contact_release_bone_matrix(armature, bone.parent, frame, memo),
        parent_matrix_local=bone.parent.bone.matrix_local)
    desired = _surface_contact_release_object_matrix(armature, frame, memo).inverted_safe() @ world
    basis = bone.bone.convert_local_to_pose(desired, bone.bone.matrix_local, invert=True, **parent)
    location, rotation, scale = basis.decompose()
    prefix = bone.path_from_id()+"."
    copied_rotation = {int(row["index"]): float(key["co"][1]) for row in rows
                       if row["path"] == prefix+"rotation_quaternion"
                       for key in row["keys"] if abs(float(key["co"][0])-source_frame) <= 1.e-5}
    if len(copied_rotation) == 4 and rotation.dot(Quaternion(tuple(copied_rotation[i] for i in range(4)))) < 0:
        rotation.negate()
    axis, angle = rotation.to_axis_angle()
    values = {"location": location, "rotation_quaternion": rotation, "scale": scale,
              "rotation_axis_angle": (angle, *axis),
              "rotation_euler": rotation.to_euler(bone.rotation_mode if bone.rotation_mode not in {"QUATERNION", "AXIS_ANGLE"} else "XYZ")}
    action = _dynamic_parent_owner_action(armature)
    for row in rows:
        prop = row["path"].removeprefix(prefix)
        if prop not in values or not any(abs(float(k["co"][0])-source_frame) <= 1.e-5 for k in row["keys"]):
            continue
        for curve in _fcurves_find_all(action, row["path"], armature):
            if curve.array_index != row["index"]:
                continue
            point = _fcurve_key_at(curve, frame)
            if point is None:
                continue
            difference = float(values[prop][curve.array_index])-point.co.y
            point.co.y += difference
            point.handle_left.y += difference
            point.handle_right.y += difference
            curve.update()
    action.update_tag()


def _pin_clipboard_paste_curve_keys(armature, offset, rows):
    action = _dynamic_parent_owner_action(armature)
    if action is None:
        return 0
    count = 0
    for row in rows:
        curve = next((c for c in _fcurves_find_all(action, row["path"], armature)
                      if c.array_index == row["index"]), None)
        if curve is None:
            curve = _action_new_fcurve(action, row["path"], armature, index=row["index"])
            if row.get("group"):
                _set_fcurve_group(curve, action, row["group"])
        for key in row["keys"]:
            point = curve.keyframe_points.insert(key["co"][0] + offset, key["co"][1])
            _surface_contact_apply_key_style(point, key.get("style"))
            point.handle_left = (key["left"][0] + offset, key["left"][1])
            point.handle_right = (key["right"][0] + offset, key["right"][1])
            count += 1
        curve.update()
    if count:
        action.update_tag()
    return count


def _pin_clipboard_mirror_curve_keys(armature, rows, offset=0.):
    return _mirror_transfer_curve_rows(armature, rows, offset)


def _pin_clipboard_unpack_matrix(packed):
    return Matrix(tuple(tuple(packed[r*4+c] for c in range(4)) for r in range(4)))


def _pin_clipboard_mirror_transform(armature, frame, entry):
    source = _pin_clipboard_unpack_matrix(entry['mirror_frame'])
    destination = _pin_mirror_world_matrix(armature, frame=frame)
    name = str(entry.get('bone_name', ''))
    target = _mirror_counterpart_name(armature, name)
    return _mirror_pin_transform(armature, name, target, source, destination)


def _pin_clipboard_mirror_contact_values(armature, guide, frame, entry, position_only=False):
    """Convert a reflected world target into the destination guide's binding."""
    reflect = Matrix.Diagonal((-1., 1., 1., 1.))
    desired = (_pin_clipboard_mirror_transform(armature, frame, entry)
               @ _pin_clipboard_unpack_matrix(entry['world_matrix']) @ reflect)
    projected = _mirror_project_contact_target(bpy.context, guide, frame, desired.translation)
    if projected is None:
        return None
    desired.translation = projected
    memo = {}
    world = _surface_contact_release_object_matrix(guide, frame, memo)
    basis = _surface_contact_release_channels(guide, frame,
        _action_fcurves(_dynamic_parent_owner_action(guide), guide))
    local = (world @ basis.inverted_safe()).inverted_safe() @ desired
    location, rotation, scale = local.decompose()
    axis, angle = rotation.to_axis_angle()
    values = {'location': location, 'rotation_quaternion': rotation, 'scale': scale,
              'rotation_axis_angle': (angle, *axis),
              'rotation_euler': rotation.to_euler(guide.rotation_mode
                  if guide.rotation_mode not in {'QUATERNION', 'AXIS_ANGLE'} else 'XYZ')}
    return [dict(row, value=float(values[row['path']][row['index']]))
            if row['path'] in values else dict(row) for row in entry.get('guide_values', ())
            if not position_only or row['path'] == 'location']


def _pin_clipboard_select_pasted_keys(context, flipped=False):
    """Select the pasted payload, never source keys or rebuilt channel spans."""
    data = (_state.get("pin_clipboard") or {}).get("editor_snap_keys") or {}
    if data.get("source_start") is None:
        return
    scope = tuple(_pose_scope_armatures(context))
    by_uid = {_armature_session_uid(owner): owner for owner in scope}
    by_name = {owner.name: owner for owner in scope}
    offset = float(context.scene.frame_current_final) - float(data["source_start"])
    wanted = {}
    for entry in data.get("owners", ()):
        owner = by_uid.get(int(entry.get("session_uid", 0))) or by_name.get(entry.get("armature_name", ""))
        if owner is None:
            continue
        keys = wanted.setdefault(owner.name, {})
        def add(path, index, frame):
            keys.setdefault((path, int(index)), set()).add(round(float(frame), 5))
        transferred = _state.get('mirror_pasted_rows', {}).get(_armature_session_uid(owner)) if flipped else None
        for row in (transferred if transferred is not None else entry.get("curve_keys", ())):
            path = row["path"]
            if flipped and transferred is None:
                for bone in owner.pose.bones:
                    prefix = bone.path_from_id()
                    if path.startswith(prefix):
                        target = owner.pose.bones.get(_mirror_counterpart_name(owner, bone.name))
                        if target is not None:
                            path = target.path_from_id() + path[len(prefix):]
                        break
            for key in row["keys"]:
                add(path, row["index"], key["co"][0] + offset)
        for pin in entry.get("entries", ()):
            name = str(pin.get("bone_name", ""))
            bone = owner.pose.bones.get(_mirror_counterpart_name(owner, name) if flipped else name)
            if bone is None:
                continue
            prop = GYRO_MARKER if pin.get("kind") == "GYRO" else SURFACE_CONTACT_MARKER_PROPERTY
            frame = float(pin["source_frame"]) + offset
            # A counterpart without this constraint has no ID property to
            # resolve. Selection only matches existing curves; construct its
            # path without requiring the optional property to exist.
            add(bone.path_from_id() + f'["{prop}"]', 0, frame)
            if pin.get("kind") == "GYRO":
                prefix = 'pose.bones["' + bpy.utils.escape_identifier(name) + '"]'
                for row in pin.get("guide_values", ()):
                    path = row["path"]
                    if path.startswith(prefix):
                        mapped = bone.path_from_id() + path[len(prefix):]
                        applied = _state.get('pin_clipboard_gyro_pasted', {}).get(
                            (_armature_session_uid(owner), bone.name, round(frame, 5)))
                        if applied is None or (mapped, int(row['index'])) in applied:
                            add(mapped, row["index"], frame)
    for owner in scope:
        action = _dynamic_parent_owner_action(owner)
        selected_groups = set()
        for curve in _action_fcurves(action, owner):
            frames = wanted.get(owner.name, {}).get((curve.data_path, curve.array_index), ())
            selected = False
            for key in curve.keyframe_points:
                match = round(float(key.co.x), 5) in frames
                key.select_control_point = key.select_left_handle = key.select_right_handle = match
                selected = selected or match
            curve.select = selected
            if selected and curve.group is not None:
                selected_groups.add(curve.group.name)
        for groups in _action_group_owners(action, owner):
            for group in groups:
                group.select = group.name in selected_groups
    _redraw_keyframe_editors()


def _pin_clipboard_capture_editor_snap_keys(context):
    captured = []
    source_frames = []
    for armature in _pose_scope_armatures(context):
        action = _dynamic_parent_owner_action(armature)
        if action is None or getattr(armature, "pose", None) is None:
            continue
        selected_by_bone = {}
        curve_keys = _pin_clipboard_selected_curve_keys(action, armature)
        curves = tuple(_action_fcurves(action, armature))
        for pose_bone in armature.pose.bones:
            escaped_name = bpy.utils.escape_identifier(pose_bone.name)
            prefix = f'pose.bones["{escaped_name}"]'
            selected_frames = {}
            for fcurve in curves:
                if not (fcurve.data_path.startswith(prefix + ".")
                        or fcurve.data_path.startswith(prefix + "[")):
                    continue
                frames = {float(key.co.x) for key in fcurve.keyframe_points
                          if bool(getattr(key, "select_control_point", False))}
                source_frames.extend(frames)
                if fcurve.data_path.startswith(prefix + "."):
                    # A bone key is not an implicit copy of its pin channel.
                    kinds = ()
                elif fcurve.data_path == prefix + f'["{SURFACE_CONTACT_MARKER_PROPERTY}"]':
                    kinds = ("CONTACT",)
                elif fcurve.data_path in {prefix + f'["{name}"]'
                                         for name in (GYRO_MARKER, GYRO_TARGET_PROPERTY, GYRO_TILT_PROPERTY)}:
                    kinds = ("GYRO",)
                else:
                    kinds = ()
                for frame in frames:
                    selected_frames.setdefault(frame, set()).update(kinds)
            if selected_frames:
                selected_by_bone[pose_bone.name] = selected_frames
        if not selected_by_bone:
            continue
        entries = []
        for bone_name, frames in selected_by_bone.items():
            pose_bone = armature.pose.bones.get(bone_name)
            for source_frame in sorted(frames):
                if "GYRO" in frames[source_frame] and GYRO_MARKER in pose_bone and _gyro_bone_active_at(armature, pose_bone, source_frame):
                    paths = {pose_bone.path_from_id(f'["{name}"]')
                             for name in (GYRO_TARGET_PROPERTY, GYRO_TILT_PROPERTY)}
                    entries.append({
                        "kind": "GYRO", "bone_name": bone_name,
                        "source_frame": source_frame,
                        "mirror_frame": tuple(v for row in _pin_mirror_world_matrix(
                            armature, frame=source_frame) for v in row),
                        "guide_values": _pin_clipboard_animation_values(armature, source_frame, paths),
                    })
                if "CONTACT" not in frames[source_frame]:
                    continue
                contact_events = _surface_contact_marker_points(pose_bone)
                if source_frame in contact_events and contact_events[source_frame] < .5:
                    # End is an activation event, not another target key.
                    # Let native paste retain its exact inactive event.
                    continue
                guides = _surface_contact_guides_for_selected_bone(
                    armature,
                    pose_bone,
                    source_frame,
                )
                if not guides:
                    continue
                guide = max(
                    guides,
                    key=lambda item: int(item.get(
                        SURFACE_CONTACT_START_PROPERTY,
                        SPACE_MIN_FRAME,
                    )),
                )
                detached = _surface_contact_animated_detached_state(
                    guide,
                    source_frame,
                )
                if detached is None:
                    detached = bool(
                        guide.get(SURFACE_CONTACT_DETACHED_PROPERTY, False)
                    )
                entries.append({
                    "bone_name": bone_name,
                    "source_frame": source_frame,
                    "detached": bool(detached),
                    "mirror_frame": tuple(v for row in _pin_mirror_world_matrix(
                        armature, frame=source_frame) for v in row),
                    "world_matrix": tuple(v for row in _surface_contact_release_object_matrix(
                        guide, source_frame, {}) for v in row),
                    "guide_values": _pin_clipboard_animation_values(guide, source_frame),
                    "pose_reference": (_pin_clipboard_contact_pose_reference(
                        armature, pose_bone, guide, source_frame)
                        if _pin_clipboard_complete_pose_key(pose_bone, source_frame, curve_keys) else None),
                })
        if entries or curve_keys:
            captured.append({
                "session_uid": _armature_session_uid(armature),
                "armature_name": armature.name,
                "entries": entries,
                "curve_keys": curve_keys,
            })
    return {
        "source_start": min(source_frames) if source_frames else None,
        "owners": captured,
    }


def _pin_clipboard_apply_editor_snap_keys(context, flipped=False):
    clipboard = _state.get("pin_clipboard") or {}
    editor_data = clipboard.get("editor_snap_keys") or {}
    source_start = editor_data.get("source_start")
    scope = tuple(_pose_scope_armatures(context))
    if source_start is None or not scope:
        return 0
    scope_by_uid = {
        _armature_session_uid(armature): armature for armature in scope
    }
    scope_by_name = {armature.name: armature for armature in scope}
    destination_start = float(context.scene.frame_current_final)
    changed = 0
    changed_guides = []
    for owner_entry in editor_data.get("owners", ()):
        armature = scope_by_uid.get(int(owner_entry.get("session_uid", 0)))
        if armature is None:
            armature = scope_by_name.get(str(owner_entry.get("armature_name", "")))
        if armature is None:
            continue
        curve_keys = owner_entry.get('curve_keys', ())
        if flipped:
            curve_keys = _pin_clipboard_mirror_curve_keys(armature, curve_keys, destination_start-float(source_start))
            _state.setdefault('mirror_pasted_rows', {})[_armature_session_uid(armature)] = curve_keys
        changed += _pin_clipboard_paste_curve_keys(
            armature, destination_start - float(source_start), curve_keys)
        for entry in owner_entry.get("entries", ()):
            source_name = str(entry.get("bone_name", ""))
            target_name = _mirror_counterpart_name(armature, source_name) if flipped else source_name
            pose_bone = armature.pose.bones.get(target_name)
            if pose_bone is None:
                continue
            destination_frame = destination_start + (
                float(entry.get("source_frame", source_start)) - float(source_start)
            )
            pose_keys = _pin_clipboard_has_pose_keys(
                armature.pose.bones.get(source_name), entry.get('source_frame', source_start),
                owner_entry.get('curve_keys', ()))
            if entry.get("kind") == "GYRO":
                if flipped and _gyro_find(context, armature, pose_bone) is None:
                    _state.setdefault('mirror_missing_pins', set()).add((armature.name, target_name))
                    continue
                values = []
                old_prefix = 'pose.bones["' + bpy.utils.escape_identifier(source_name) + '"]'
                new_prefix = pose_bone.path_from_id()
                for original in entry.get("guide_values", ()):
                    row = dict(original)
                    if row["path"].startswith(old_prefix):
                        row["path"] = new_prefix + row["path"][len(old_prefix):]
                    values.append(row)
                if flipped and entry.get('mirror_frame'):
                    target_path = pose_bone.path_from_id(f'["{GYRO_TARGET_PROPERTY}"]')
                    tilt_path = pose_bone.path_from_id(f'["{GYRO_TILT_PROPERTY}"]')
                    components = {(row['path'], row['index']): row['value'] for row in values}
                    reflect = _pin_clipboard_mirror_transform(armature, destination_frame, entry)
                    target = reflect @ Vector(tuple(components.get((target_path, i), 0.) for i in range(3)))
                    tilt = Quaternion(tuple(components.get((tilt_path, i), 1. if i == 0 else 0.)
                                            for i in range(4))).normalized()
                    tilt = (_mirror_orthogonal(reflect) @ tilt.to_matrix()
                            @ Matrix.Diagonal((-1., 1., 1.))).to_quaternion().normalized()
                    values = [dict(row, value=float((target if row['path'] == target_path else tilt)[row['index']]))
                              if row['path'] in {target_path, tilt_path} else row for row in values]
                tilt_path = pose_bone.path_from_id(f'["{GYRO_TILT_PROPERTY}"]')
                tilt_selected = any(row['path'] == old_prefix + f'["{GYRO_TILT_PROPERTY}"]'
                    and any(abs(float(k['co'][0])-float(entry['source_frame'])) <= 1.e-5
                            for k in row['keys']) for row in owner_entry.get('curve_keys', ()))
                if not pose_keys and not tilt_selected:
                    values = [row for row in values if row['path'] != tilt_path]
                if _pin_clipboard_paste_animation_values(armature, destination_frame, values):
                    _state.setdefault('pin_clipboard_gyro_pasted', {})[
                        (_armature_session_uid(armature), pose_bone.name, round(destination_frame, 5))
                    ] = {(row['path'], int(row['index'])) for row in values}
                    _pin_clipboard_hold_equal_auto_values(
                        armature, destination_frame, {row["path"] for row in values})
                    changed += 1
                continue
            guides = _surface_contact_guides_for_selected_bone(
                armature,
                pose_bone,
                destination_frame,
            )
            if not guides:
                if flipped:
                    _state.setdefault('mirror_missing_pins', set()).add((armature.name, target_name))
                continue
            guide = max(
                guides,
                key=lambda item: int(item.get(
                    SURFACE_CONTACT_START_PROPERTY,
                    SPACE_MIN_FRAME,
                )),
            )
            guide_values = entry.get('guide_values', ())
            detached = bool(entry.get('detached', False))
            pose_reference = entry.get('pose_reference') if pose_keys else None
            if flipped and entry.get('mirror_frame') and entry.get('world_matrix'):
                guide_values = _pin_clipboard_mirror_contact_values(
                    armature, guide, destination_frame, entry, position_only=not pose_keys)
                if guide_values is None:
                    continue
                if pose_reference:
                    mirrored = _mirror_visual_pose(armature, source_name, pose_bone.name,
                        _pin_clipboard_unpack_matrix(entry['mirror_frame']),
                        _pin_mirror_world_matrix(armature, frame=destination_frame),
                        _pin_clipboard_unpack_matrix(pose_reference))
                    pose_reference = tuple(v for row in mirrored for v in row)
            if pose_reference:
                _pin_clipboard_paste_contact_pose_reference(
                    armature, pose_bone, destination_frame, pose_reference,
                    curve_keys, float(entry["source_frame"]))
            _pin_clipboard_paste_animation_values(
                guide, destination_frame, guide_values,
            )
            targets = set(_surface_contact_target_frames(guide))
            targets.add(destination_frame)
            _surface_contact_set_target_frames(guide, targets)
            if _surface_contact_keyframe_detached_state(
                guide,
                destination_frame,
                detached,
            ):
                changed += 1
                changed_guides.append((
                    guide,
                    pose_bone,
                    destination_frame,
                    detached,
                ))
                _surface_contact_rebuild_markers(
                    pose_bone,
                    pose_bone.name,
                )
    if changed:
        _constraint_sync_timeline(context)
        for guide, bone, destination_frame, _detached in changed_guides:
            _surface_contact_sync_guide_key_styles(bone, guide)
            _pin_clipboard_hold_equal_auto_values(
                guide, destination_frame, {"location", "rotation_quaternion", "rotation_euler", "rotation_axis_angle"})
        context.view_layer.update()
        _surface_contact_apply_animated_snap_state(context.scene)
        settle = []
        for guide, _pose_bone, destination_frame, detached in changed_guides:
            if detached or destination_frame != destination_start:
                continue
            _surface_contact_clear_snap_departure(guide)
            settle.append(guide)
        # Keyed paste and subsequent scrubbing must publish the same Action-
        # based Contact pose, rather than preserving a pre-paste solved basis.
        if settle and _surface_contact_playback_batch_settle(context, settle):
            context.view_layer.update()
        _tag_redraw_all_view3d()
    return changed


def _pin_flipped_name(name):
    name = str(name)
    try:
        flipped = bpy.utils.flip_name(name, strip_digits = False)
    except (AttributeError, TypeError):
        flipped = name
    if flipped != name:
        return flipped

    # Roblox rigs commonly use full-word side names. Keep these working even
    # if Blender changes which naming conventions flip_name recognizes.
    for left, right in (
        ("Left", "Right"),
        ("left", "right"),
        ("LEFT", "RIGHT"),
    ):
        if left in name:
            return name.replace(left, right, 1)
        if right in name:
            return name.replace(right, left, 1)
    return name


def _pin_clipboard_apply(context, flipped = False):
    clipboard = _state.get("pin_clipboard")
    scope = _pose_scope_armatures(context)
    if not clipboard or not scope:
        return 0
    frame = int(context.scene.frame_current)
    changed = 0
    owner_entries = tuple(clipboard.get("owners", ()))
    if not owner_entries and "entries" in clipboard:
        owner_entries = ({
            "session_uid": 0,
            "armature_name": str(clipboard.get("armature_name", "")),
            "entries": tuple(clipboard.get("entries", ())),
        },)
    scope_by_uid = {
        _armature_session_uid(armature): armature for armature in scope
    }
    scope_by_name = {armature.name: armature for armature in scope}
    for owner_entry in owner_entries:
        armature = scope_by_uid.get(int(owner_entry.get("session_uid", 0)))
        if armature is None:
            armature = scope_by_name.get(str(owner_entry.get("armature_name", "")))
        if armature is None:
            continue
        for special_entry in owner_entry.get("special_keys", ()):
            source_name = str(special_entry.get("bone_name", ""))
            target_name = _mirror_counterpart_name(armature, source_name) if flipped else source_name
            pose_bone = armature.pose.bones.get(target_name)
            if pose_bone is not None and _pin_clipboard_insert_special_key(
                armature,
                pose_bone,
                special_entry,
                frame,
            ):
                changed += 1
        for entry in owner_entry.get("entries", ()):
            source_name = str(entry.get("bone_name", ""))
            # The copied owner and bone identify the destination. Selecting
            # another pin never retargets the clipboard to it.
            target_name = _mirror_counterpart_name(armature, source_name) if flipped else source_name
            pose_bone = armature.pose.bones.get(target_name)
            if pose_bone is None:
                continue
            if flipped:
                source_pose_bone = armature.pose.bones.get(source_name)
                mirror_world = _pin_mirror_world_matrix(
                    armature,
                    source_pose_bone,
                    pose_bone,
                )
                mirror_offset_data = entry.get("mirror_offset")
                if mirror_offset_data is not None:
                    mirror_offset = Vector(tuple(mirror_offset_data))
                    target = _mirror_pin_transform(armature, source_name, target_name,
                        Matrix.Identity(4), mirror_world) @ mirror_offset
                else:
                    # Compatibility with clipboards captured before v1.6.55.
                    armature_offset = Vector(tuple(entry.get(
                        "armature_offset",
                        entry.get("local_offset", (0.0, 0.0, 0.0)),
                    )))
                    armature_offset.x = -armature_offset.x
                    target = armature.matrix_world @ armature_offset
            else:
                if str(entry.get("kind", "")) == "CONTACT":
                    armature_offset = Vector(tuple(entry.get(
                        "armature_offset",
                        entry.get("local_offset", (0.0, 0.0, 0.0)),
                    )))
                    target = armature.matrix_world @ armature_offset
                else:
                    local_offset = Vector(tuple(
                        entry.get("local_offset", (0.0, 0.0, 0.0))
                    ))
                    target = (
                        _pin_parent_world_matrix(armature, pose_bone)
                        @ local_offset
                    )

            if str(entry.get("kind", "")) == "YELLOW":
                packed = _state.get("yellow_fixed", {}).get(
                    _owner_bone_key(armature, target_name)
                )
                if not packed:
                    if flipped:
                        _state.setdefault('mirror_missing_pins', set()).add((armature.name, target_name))
                    continue
                if _yellow_set_pin_target(armature, target_name, target):
                    _yellow_store_target_property(armature, target_name, target)
                    changed += 1
                continue

            if str(entry.get('kind', '')) == 'GYRO':
                gyro = _gyro_find(context, armature, pose_bone)
                if gyro is not None:
                    gyro.location = target
                    _gyro_key_transform(gyro, frame)
                    changed += 1
                elif flipped:
                    _state.setdefault('mirror_missing_pins', set()).add((armature.name, target_name))
                continue

            guides = _surface_contact_guides_for_selected_bone(
                armature,
                pose_bone,
                frame,
            )
            if not guides:
                if flipped:
                    _state.setdefault('mirror_missing_pins', set()).add((armature.name, target_name))
                continue
            guide = max(
                guides,
                key = lambda item: int(
                    item.get(SURFACE_CONTACT_START_PROPERTY, SPACE_MIN_FRAME)
                ),
            )
            previous_dragging = _state.get("pin_target_dragging", False)
            references = _state.get("pin_target_drag_references")
            _state["pin_target_drag_references"] = dict(references or {})
            _surface_contact_capture_target_reference(context, guide)
            _state["pin_target_dragging"] = True
            try:
                projected = _surface_contact_bound_surface_point(context, guide, target)
                if projected is None:
                    continue
                point, normal = projected
                _surface_contact_set_guide_surface_point(
                    context, guide, point, normal, update_view_layer=False,
                    preserve_orientation=bool(clipboard.get('pin_only')),
                )
                if not bool(entry.get("detached", False)) and not clipboard.get('pin_only'):
                    _surface_contact_solve_target(
                        context, guide, rotate_pose=True,
                        max_iterations=SURFACE_CONTACT_FINAL_SOLVER_ITERATIONS,
                    )
            finally:
                _state["pin_target_dragging"] = previous_dragging
                if references is None:
                    _state.pop("pin_target_drag_references", None)
                else:
                    _state["pin_target_drag_references"] = references
            _surface_contact_commit_target_key(
                context,
                guide,
                detached=bool(entry.get("detached", False)),
                key_pose=not clipboard.get('pin_only'),
            )
            changed += 1
            continue
    if changed:
        _yellow_refresh_runtime(context)
        context.view_layer.update()
        _tag_redraw_all_view3d()
    return changed



def _pin_clipboard_editor_route(context, action):
    """Keep a timeline-key clipboard usable when the pointer crosses editors."""
    area_type = getattr(getattr(context, "area", None), "type", "")
    clipboard = _state.get('pin_clipboard') or {}
    if (action != 'COPY' and area_type in {'DOPESHEET_EDITOR', 'GRAPH_EDITOR'}
            and clipboard and 'editor_snap_keys' not in clipboard):
        for area in getattr(context.screen, 'areas', ()):
            if area.type == 'VIEW_3D':
                region = next((r for r in area.regions if r.type == 'WINDOW'), None)
                if region is not None:
                    return area, region
        return None
    if area_type != "VIEW_3D":
        return None
    if action == "COPY":
        # A viewport selection is an explicit component copy. Timeline keys
        # often remain selected after clicking a pin or its bone; importing
        # those stale selections here silently copies both components.
        _key, target = _pin_selected_target_data(context)
        if target is not None or _selected_pose_bones_by_owner(context):
            return None
        if _pin_clipboard_capture_editor_snap_keys(context).get("source_start") is None:
            return None
    elif "editor_snap_keys" not in (_state.get("pin_clipboard") or {}):
        return None
    preferred = _state.get("pin_clipboard_editor_type", "DOPESHEET_EDITOR")
    areas = tuple(getattr(getattr(context, "screen", None), "areas", ()))
    for kind in dict.fromkeys((preferred, "DOPESHEET_EDITOR", "GRAPH_EDITOR")):
        for area in areas:
            if area.type != kind:
                continue
            region = next((r for r in area.regions if r.type == "WINDOW"), None)
            if region is not None:
                return area, region
    return None


def _pin_clipboard_record_target_history(context, snapshots):
    """Keep all pasted Contact dependencies in one native history step."""
    transitions = []
    stack = _state.setdefault("pin_snap_native_history_transitions", [])
    for guide_name, before in snapshots.items():
        guide = bpy.data.objects.get(guide_name)
        if guide is None:
            continue
        transition = _pin_record_target_history_transition(context, guide, before)
        if transition is not None:
            transitions.append(transition)
            stack.pop()
    if not transitions:
        return
    combined = dict(transitions[0])
    combined["clipboard"] = True
    for key in ("selected", "contacts", "attachments", "detached_key_states",
                "guide_matrices", "guide_local_matrices", "constraint_states",
                "visual_poses", "action_keys", "history_tokens"):
        combined[key] = tuple(entry for transition in transitions
                              for entry in transition.get(key, ()))
    tokens = []
    for armature_name in sorted({entry[0] for entry in combined["selected"]}):
        armature = bpy.data.objects.get(armature_name)
        if armature is None:
            continue
        before_token = next((snapshot["clipboard_token"] for snapshot in snapshots.values()
                             if snapshot and snapshot["armature"] == armature_name), -1)
        serial = max(int(_state.get("pin_clipboard_history_serial", 0)),
                     int(armature.get(SURFACE_CONTACT_HISTORY_TOKEN_PROPERTY, -1))) + 1
        _state["pin_clipboard_history_serial"] = serial
        armature[SURFACE_CONTACT_HISTORY_TOKEN_PROPERTY] = serial
        tokens.append((armature_name, before_token, serial))
    combined["history_tokens"] = tuple(tokens)
    combined["clipboard_markers"] = tuple(
        (snapshot["armature"], str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, "")),
         snapshot.get("clipboard_markers", ()),
         tuple(sorted(_surface_contact_marker_points(bone).items())))
        for name, snapshot in snapshots.items() if snapshot
        for guide in (bpy.data.objects.get(name),) if guide is not None
        for owner, bone in (_surface_contact_pose_bone(guide),) if bone is not None)
    stack.append(combined)
    _state["pin_snap_native_history_transition"] = combined
    _state["pin_snap_native_history_transition_backup"] = combined



class ANIMATOR_UTILS_OT_pose_pin_clipboard(bpy.types.Operator):
    bl_idname = "staticaliza.pose_pin_clipboard"
    bl_label = "Pose and Pin Clipboard"
    bl_description = "Copy or paste the pose and its pin targets"
    bl_options = {"REGISTER", "UNDO"}

    action: bpy.props.EnumProperty(
        items = (
            ("COPY", "Copy", ""),
            ("PASTE", "Paste", ""),
            ("PASTE_FLIPPED", "Paste Flipped", ""),
        ),
        options = {"HIDDEN", "SKIP_SAVE"},
    )

    @classmethod
    def poll(cls, context):
        return (getattr(getattr(context, 'area', None), 'type', '')
                in {'VIEW_3D', 'DOPESHEET_EDITOR', 'GRAPH_EDITOR'}
                and context.mode == "POSE" and _active_armature(context) is not None)

    def execute(self, context):
        _mirror_operation_begin()
        try:
            result = _pin_clipboard_execute(self, context)
            if self.action == 'PASTE_FLIPPED' and _state.get('mirror_operation_depth') == 1:
                unmatched = len(_state.get('mirror_unmatched_bones', ()))
                pins = len(_state.get('mirror_missing_pins', ()))
                if unmatched:
                    self.report({'INFO'}, f'Skipped {unmatched} bone(s) without a confident mirror match')
                if pins:
                    self.report({'INFO'}, f'Set up the corresponding pin on {pins} matched bone(s) to paste its target')
                if _state.get('mirror_curve_limited'):
                    self.report({'INFO'}, 'Mirror curve sampling reached its limit; check complex rotation segments')
            return result
        finally:
            _mirror_operation_end()


def _pin_clipboard_execute(self, context):
    route = _pin_clipboard_editor_route(context, self.action)
    if route is not None:
        with context.temp_override(area=route[0], region=route[1]):
            return self.execute(context)
    editor_type = getattr(getattr(context, "area", None), "type", "")
    if self.action == "COPY":
        native_copy_ok = False
        editable_curves = getattr(context, "editable_fcurves", None)
        native_copy_possible = editable_curves is None or any(
            key.select_control_point for curve in editable_curves
            for key in curve.keyframe_points)
        if editor_type == "DOPESHEET_EDITOR" and native_copy_possible:
            try:
                native_copy_ok = 'FINISHED' in bpy.ops.action.copy()
            except RuntimeError:
                pass
        elif editor_type == "GRAPH_EDITOR" and native_copy_possible:
            try:
                native_copy_ok = 'FINISHED' in bpy.ops.graph.copy()
            except RuntimeError:
                pass
        clipboard = ({"owners": [], "has_pose": False}
                     if editor_type in {"DOPESHEET_EDITOR", "GRAPH_EDITOR"}
                     else _pin_clipboard_capture(context))
        if editor_type in {"DOPESHEET_EDITOR", "GRAPH_EDITOR"}:
            if clipboard is None:
                clipboard = {"owners": [], "has_pose": False}
            clipboard["editor_snap_keys"] = (
                _pin_clipboard_capture_editor_snap_keys(context)
            )
            clipboard["native_editor_keys"] = native_copy_ok
        if (
            editor_type not in {"DOPESHEET_EDITOR", "GRAPH_EDITOR"}
            and clipboard is not None
            and clipboard.get("has_pose", False)
        ):
            try:
                bpy.ops.pose.copy()
            except RuntimeError:
                pass
        empty = clipboard is None or (
            editor_type in {"DOPESHEET_EDITOR", "GRAPH_EDITOR"}
            and not native_copy_ok
            and not clipboard.get("editor_snap_keys", {}).get("owners"))
        _state["pin_clipboard_copy_empty"] = empty
        _state["pin_clipboard"] = None if empty else clipboard
        if empty:
            return {"CANCELLED"}
        if editor_type in {"DOPESHEET_EDITOR", "GRAPH_EDITOR"}:
            _state["pin_clipboard_editor_type"] = editor_type
        return {"FINISHED"}

    if _state.get("pin_clipboard_copy_empty", False):
        return {"CANCELLED"}
    _state['mirror_pasted_rows'] = {}
    _state['pin_clipboard_gyro_pasted'] = {}
    target_history = {
        guide.name: _pin_target_history_snapshot(context, guide)
        for guide in _surface_contact_active_simulated_guides(context.scene)
    }
    for guide_name, snapshot in target_history.items():
        if snapshot:
            owner = bpy.data.objects[snapshot["armature"]].pose.bones.get(
                str(bpy.data.objects[guide_name].get(SURFACE_CONTACT_BONE_PROPERTY, "")))
            snapshot["clipboard_markers"] = tuple(sorted(_surface_contact_marker_points(owner).items()))
            snapshot["clipboard_token"] = int(bpy.data.objects[snapshot["armature"]].get(
                SURFACE_CONTACT_HISTORY_TOKEN_PROPERTY, -1))
            # A keyed guide's persisted edit matrix may describe a later
            # authored key. History needs the evaluated local target here.
            snapshot["guide_local"] = tuple(
                value for row in bpy.data.objects[guide_name].matrix_basis for value in row)
    flipped = self.action == "PASTE_FLIPPED"
    clipboard = _state.get("pin_clipboard")
    keyed_clipboard = 'editor_snap_keys' in (clipboard or {})
    scope = tuple(_pose_scope_armatures(context))
    object_key_snapshots = {
        _armature_session_uid(armature): (
            armature.animation_data.action
            if armature.animation_data else None,
            _snapshot_object_keys_all(
                armature.animation_data.action
                if armature.animation_data else None
            ),
        )
        for armature in scope
    }
    authored_keys = bool(any(owner.get("curve_keys")
        for owner in (clipboard or {}).get("editor_snap_keys", {}).get("owners", ())))
    if target_history and clipboard:
        # This explicit edit supersedes Undo's temporary late-evaluation
        # pose lock. Keep its captured before-side, but never let that
        # lock overwrite the newly pasted target's solved pose.
        _surface_contact_clear_history_pose_lock()
        _state.pop("surface_contact_selection_history_guard_until", None)
    if keyed_clipboard and editor_type == "DOPESHEET_EDITOR" and not authored_keys and (clipboard or {}).get("native_editor_keys", True):
        try:
            bpy.ops.action.paste(flipped=flipped)
        except RuntimeError:
            pass
    elif keyed_clipboard and editor_type == "GRAPH_EDITOR" and not authored_keys and (clipboard or {}).get("native_editor_keys", True):
        try:
            bpy.ops.graph.paste(flipped=flipped)
        except RuntimeError:
            pass
    elif (not keyed_clipboard and (clipboard is None or clipboard.get("has_pose", True))):
        try:
            if flipped and clipboard and any(o.get('pose_entries') for o in clipboard.get('owners', ())):
                _mirror_pose_entries(context, clipboard)
            else:
                bpy.ops.pose.paste(flipped = flipped, selected_mask = False)
        except RuntimeError:
            pass
    context.view_layer.update()
    if keyed_clipboard:
        applied_keys = _pin_clipboard_apply_editor_snap_keys(context, flipped=flipped)
    else:
        applied_keys = _pin_clipboard_apply(context, flipped = flipped)
    for armature in scope:
        _reconcile_dynamic_space_markers(context, armature)
    _surface_contact_apply_animated_snap_state(context.scene)
    contact_edit = clipboard and any(
        entry.get('kind', 'CONTACT') == 'CONTACT'
        for owner in (*clipboard.get('owners', ()),
                      *clipboard.get('editor_snap_keys', {}).get('owners', ()))
        for entry in owner.get('entries', ()))
    if applied_keys and contact_edit and not clipboard.get('has_pose', False):
        guides = _surface_contact_active_simulated_guides(context.scene)
        settled = _surface_contact_settle_animated_detached(context, guides)
        settled = (_surface_contact_playback_batch_settle(context, tuple(g for g in guides
            if _surface_contact_attached_at_frame(g, context.scene.frame_current)))
            or settled)
        if settled:
            context.view_layer.update()
    for armature in scope:
        _previous_action, snapshot = object_key_snapshots.get(
            _armature_session_uid(armature),
            (None, {}),
        )
        current_action = (
            armature.animation_data.action
            if armature.animation_data else None
        )
        _cleanup_new_object_keys_all(current_action, snapshot)
    _pin_clipboard_record_target_history(context, target_history)
    # Publish the completed edit's marker baseline synchronously. A native
    # Delete immediately after Paste can otherwise coalesce both Action
    # notifications and hide the removed key from the watcher.
    _state["dynamic_space_marker_signature"] = _dynamic_space_marker_signature()
    for guide in _surface_contact_active_simulated_guides(context.scene):
        _surface_contact_capture_idle_pose(context, guide)
    if keyed_clipboard:
        _pin_clipboard_select_pasted_keys(context, flipped=flipped)
    return {"FINISHED"}
