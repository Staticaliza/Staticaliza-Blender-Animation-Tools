"""Virtual pin selection and gizmo interaction state."""

from ..core.runtime import *  # noqa: F403

def _pin_gizmo_group(gizmo):
    try:
        return gizmo.group
    except (AttributeError, ReferenceError, RuntimeError):
        return None

def _pin_gizmo_set_if_changed(gizmo, property_name, value):
    """Avoid dirtying Blender's shared gizmo map with identical RNA writes."""
    try:
        current = getattr(gizmo, property_name)
        if isinstance(value, Matrix):
            unchanged = all(
                abs(float(current[row][column]) - float(value[row][column]))
                <= max(1.0e-6, abs(float(value[row][column])) * 2.0e-7)
                for row in range(4)
                for column in range(4)
            )
        elif isinstance(value, float):
            # Gizmo RNA stores float32. Comparing its rounded readback to a
            # Python float at 1e-10 rewrites alpha/scale on every hover draw,
            # invalidating the shared gizmo map and its click highlight.
            unchanged = abs(float(current) - value) <= max(
                1.0e-7, abs(value) * 1.0e-7,
            )
        elif isinstance(value, (tuple, list)) and all(isinstance(v, (int, float)) for v in value):
            # RNA color arrays do not compare equal to an equivalent tuple.
            # Rewriting RGB every draw invalidates native handle picking too.
            unchanged = len(current) == len(value) and all(
                abs(float(a) - float(b)) <= max(1.e-7, abs(float(b)) * 1.e-7)
                for a, b in zip(current, value))
        else:
            unchanged = current == value
        if unchanged:
            return False
        setattr(gizmo, property_name, value)
        return True
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        return False


def _pin_gizmo_hide_for_animation(group, context):
    if not _pin_animation_hidden(context):
        return False
    for gizmo in group.gizmos:
        _pin_gizmo_set_if_changed(gizmo, "hide", True)
        _pin_gizmo_set_if_changed(gizmo, "hide_select", True)
        _pin_gizmo_set_if_changed(gizmo, "select", False)
    return True


def _pin_gizmo_update_hover_cursor(context, gizmo):
    """Use the move cursor while a visible pin diamond is highlighted."""
    if gizmo is not None:
        target_key=str(getattr(gizmo,'target_key',''))
        selected=(target_key in _pin_selected_target_keys() if target_key else
                  int(gizmo.side) in _smart_dragger_selected_sides() if hasattr(gizmo,'side') else None)
        if selected is not None:
            # Native draw_prepare can pause during a modal drag. Selection
            # changes opacity only; the regular hue remains untouched and
            # Blender's highlight color is reserved for hover.
            _pin_gizmo_set_if_changed(gizmo,'alpha',1.0 if selected else .36)
            _pin_gizmo_set_if_changed(gizmo,'alpha_highlight',1.0)
    now = time.perf_counter()
    hovered = bool(
        gizmo is not None
        and getattr(gizmo, "is_highlight", False)
        and not getattr(gizmo, "hide", True)
        and not getattr(gizmo, "hide_select", True)
    )
    hover_map = _state.setdefault("pin_gizmo_hover_cursor", {})
    key = id(gizmo) if gizmo is not None else 0
    if hovered:
        hover_map[key] = now + 0.12
    else:
        hover_map.pop(key, None)
    for stale_key, expires in tuple(hover_map.items()):
        if float(expires) < now:
            hover_map.pop(stale_key, None)
    active = bool(hover_map)
    if bool(_state.get("pin_gizmo_hover_cursor_active", False)) == active:
        return active
    window = getattr(context, "window", None)
    if window is None:
        return active
    try:
        window.cursor_set("SCROLL_XY" if active else "DEFAULT")
        _state["pin_gizmo_hover_cursor_active"] = active
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        pass
    return active

def _pin_gizmo_stable_target_mapping(group, target_keys):
    """Keep each live pin bound to the same pooled Gizmo across redraws."""
    target_keys = {str(key) for key in target_keys}
    pool = tuple(getattr(group, "target_gizmo_pool", ()))
    pool_ids = {id(gizmo) for gizmo in pool}
    retained = {
        str(key): gizmo
        for key, gizmo in dict(
            getattr(group, "target_gizmos", {})
        ).items()
        if str(key) in target_keys and id(gizmo) in pool_ids
    }
    used_ids = {id(gizmo) for gizmo in retained.values()}
    free_gizmos = [gizmo for gizmo in pool if id(gizmo) not in used_ids]
    for target_key in sorted(target_keys):
        if target_key in retained or not free_gizmos:
            continue
        retained[target_key] = free_gizmos.pop(0)
    group.target_gizmos = retained
    return retained

def _pin_gizmo_ensure_target_pool(
    group,
    required_count,
    gizmo_type,
    color,
    color_highlight,
):
    """Grow a center-gizmo pool on demand without rebinding live targets."""
    pool = group.target_gizmo_pool
    target_size = max(PIN_GIZMO_TARGET_POOL_SIZE, int(required_count))
    while len(pool) < target_size:
        gizmo = group.gizmos.new(gizmo_type)
        gizmo.axis_index = -1
        gizmo.color = color
        gizmo.color_highlight = color_highlight
        # Make the center visibly light up both while hovered and throughout
        # its modal drag; normal pin transparency remains unchanged.
        gizmo.alpha_highlight = 1.0
        # The diamond shares its origin with all three arrows. A small positive
        # depth bias makes an exact-center hit choose free drag while leaving
        # the surrounding arrow shafts fully selectable.
        gizmo.select_bias = PIN_GIZMO_CENTER_SELECT_BIAS
        gizmo.use_draw_modal = True
        # Passive centers must not retain stale ownership over native events.
        gizmo.use_event_handle_all = False
        gizmo.hide = True
        gizmo.hide_select = True
        pool.append(gizmo)
    return pool


def _pin_available_target_data(context):
    cache = _state.get("pin_draw_target_cache")
    if cache is None or context is None:
        return _pin_available_target_data_impl(context)
    key = (context.scene.as_pointer(), context.view_layer.as_pointer(),
           str(getattr(context, "mode", "")), _pin_selected_target_keys())
    if key not in cache:
        cache[key] = _pin_available_target_data_impl(context)
    return cache[key]


def _pin_available_target_data_impl(context, include_unselected=False):
    """Return every pin that can be selected in the current Pose viewport."""
    if context is None or getattr(context, "mode", "") != "POSE":
        return {}
    armatures = _pose_scope_armatures(context)
    if not armatures:
        return {}

    targets = {}
    frame = int(context.scene.frame_current)
    armatures_by_name = {armature.name: armature for armature in armatures}
    selected_owner_bones = _selected_owner_bone_keys(context)
    selected_pin_keys = _pin_selected_target_keys()
    for guide in _surface_contact_guides():
        armature = armatures_by_name.get(
            str(guide.get(SURFACE_CONTACT_ARMATURE_PROPERTY, ""))
        )
        if armature is None or not _surface_contact_guide_active_at(guide, frame):
            continue
        pose_bone = armature.pose.bones.get(
            str(guide.get(SURFACE_CONTACT_BONE_PROPERTY, ""))
        )
        if pose_bone is None or not _pose_bone_is_visible(pose_bone) or (_contact_chain_uses_contact(guide) and not _surface_contact_has_valid_surface(guide)):
            continue
        if _constraint_bone_ragdoll_override(armature, pose_bone, frame):
            continue
        key = _surface_contact_snap_key(guide)
        if not _contact_chain_uses_contact(guide) and not _contact_chain_handle_visible(guide):continue
        targets[key] = ("CONTACT", armature, pose_bone, guide)

    for guide in _gyro_guides(context.scene):
        armature, pose_bone = _gyro_owner(guide)
        if (armature in armatures and pose_bone is not None and _pose_bone_is_visible(pose_bone) and _gyro_active(context, guide)
                and not _constraint_bone_ragdoll_override(armature, pose_bone, frame)):
            targets[_gyro_snap_key(guide)] = ("GYRO", armature, pose_bone, guide)

    for armature in armatures:
        if _yellow_owner_hidden(armature):
            continue
        for bone_name, packed in _yellow_owner_map(
            "yellow_fixed",
            armature,
        ).items():
            pose_bone = armature.pose.bones.get(str(bone_name))
            if pose_bone is None or not packed or not _pose_bone_is_visible(pose_bone):
                continue
            key = (
                f"YELLOW:{_armature_session_uid(armature)}:"
                f"{pose_bone.name}"
            )
            targets[key] = ("YELLOW", armature, pose_bone, packed)
    # One selected pin opens the complete cross-color pin selection scope.
    # The scope closes only when the selected-pin set becomes empty.
    if selected_pin_keys or include_unselected:
        return targets
    allowed_owner_bones = set(selected_owner_bones)
    for data in targets.values():
        if data[0]=='CONTACT' and any(_owner_bone_key(data[1],name) in selected_owner_bones
                                     for name,_helper,_constraint in _contact_chain_records(data[3])):
            allowed_owner_bones.add(_owner_bone_key(data[1],data[2].name))
    return {
        key: data
        for key, data in targets.items()
        if _owner_bone_key(data[1], data[2].name) in allowed_owner_bones
    }


def _pin_gizmo_refresh_availability(context):
    try:
        kinds = frozenset(
            target_data[0]
            for target_data in _pin_available_target_data(context).values()
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        kinds = frozenset()
    _state["pin_gizmo_available_kinds"] = kinds
    return kinds


def _pin_selected_constraint_channels(context):
    """Read native channel selection without changing keys or bone selection."""
    return frozenset(
        (_armature_session_uid(armature), str(group.name))
        for armature in _pose_scope_armatures(context)
        for groups in _action_group_owners(
            getattr(getattr(armature, "animation_data", None), "action", None), armature)
        for group in groups
        if group.select and str(group.name).startswith(
            ("Constraint (", "Surface Contact (", "Gyro ("))
    )


def _pin_channel_selection_finish():
    pending = _state.pop("pin_channel_selection_pending", None)
    if pending is None or _state.get("pin_history_active"):
        return None
    window_pointer, area_pointer, before, *pose_owner = pending
    window = next((w for w in bpy.context.window_manager.windows
                   if w.as_pointer() == window_pointer), None)
    area = next((a for a in getattr(getattr(window, "screen", None), "areas", ())
                 if a.as_pointer() == area_pointer), None)
    if area is None or area.type not in {"DOPESHEET_EDITOR", "GRAPH_EDITOR"}:
        return None
    with bpy.context.temp_override(window=window, area=area):
        context = bpy.context
        active = context.view_layer.objects.active
        if pose_owner and active is not None and active.get('impaction_marker_host', False):
            armature = _armature_from_session_uid(pose_owner[0])
            if armature is not None and armature.mode == 'POSE':
                context.view_layer.objects.active = armature
                _restore_animation_editor_pose_states()
            return None
        after = _pin_selected_constraint_channels(context)
        added = after - before
        if not after:
            # Channel selection owns only the matching virtual pins. Clearing
            # those state fields must not call viewport deselection, which
            # writes the native channel selection back during its own click.
            for name, value in (('pin_gizmo_selected_key', ''),
                                ('pin_gizmo_selected_keys', set()),
                                ('pin_gizmo_selected_keys_active', ''),
                                ('pin_selected_target_data', {}), ('gyro_selected', '')):
                _state[name] = value
            _state['pin_gizmo_axes_visible'] = {}
            _state['pin_gizmo_selection_keys'] = _pin_pose_selection_signature(context)
            _state['pin_gizmo_selection_epoch'] = int(_state.get('pin_gizmo_selection_epoch', 0))+1
            return None
        candidates = []
        for key, data in _pin_available_target_data_impl(context, include_unselected=True).items():
            kind, armature, bone, _payload = data
            if kind not in {"CONTACT", "GYRO"}:
                continue
            uid = _armature_session_uid(armature)
            if any((uid, f"{prefix} ({bone.name})") in after
                   for prefix in ("Constraint", "Surface Contact", "Gyro")):
                candidates.append((key, data))
        candidates.sort(key=lambda item: any(
            (_armature_session_uid(item[1][1]), f'{prefix} ({item[1][2].name})') in added
            for prefix in ('Constraint', 'Surface Contact', 'Gyro')))
        previous = bool(_state.get("pin_selection_from_channels"))
        _state["pin_selection_from_channels"] = True
        try:
            for index, (key, data) in enumerate(candidates):
                _pin_select_target(context, key, extend=index > 0,
                                   defer_pose_selection=True,
                                   target_data_override=data)
        finally:
            _state["pin_selection_from_channels"] = previous
    return None


def _pin_observe_channel_click(context, area, event):
    if (event.type != "LEFTMOUSE" or area.type not in {"DOPESHEET_EDITOR", "GRAPH_EDITOR"}
            or context.mode != "POSE" or not any(
                r.type == "CHANNELS" and r.x <= event.mouse_x < r.x + r.width
                and r.y <= event.mouse_y < r.y + r.height for r in area.regions)):
        return
    _state["pin_channel_selection_pending"] = (
        context.window.as_pointer(), area.as_pointer(),
        _pin_selected_constraint_channels(context),
        _armature_session_uid(context.active_object))
    if not bpy.app.timers.is_registered(_pin_channel_selection_finish):
        register_owned_timer(_pin_channel_selection_finish, first_interval=0.0)


def _pin_observe_pose_click(context, area, event):
    """Observe native selection without taking ownership of gizmo input."""
    if (event.type != "LEFTMOUSE" or area.type != "VIEW_3D"
            or context.mode != 'POSE' or not any(
                r.type == "WINDOW" and r.x <= event.mouse_x < r.x+r.width
                and r.y <= event.mouse_y < r.y+r.height for r in area.regions)):
        return
    _state["pin_native_pose_click_pending"] = (
        context.window.as_pointer(), _pin_pose_selection_signature(context),
        bool(event.shift), int(_state.get("pin_gizmo_claim_serial", 0)),
        time.perf_counter()+2.0,
        tuple(_owner_bone_key(data[1],data[2].name)
              for key in _pin_selected_target_keys()
              if (data:=_state.get('pin_selected_target_data',{}).get(key)) is not None))
    if not bpy.app.timers.is_registered(_pin_native_pose_click_finish):
        register_owned_timer(_pin_native_pose_click_finish, first_interval=0.0)


def _pin_clear_deselected_active_bones(context):
    """Retire a managed bone's active outline after native deselection."""
    if (context is None or context.mode!='POSE' or _pin_primary_mouse_pressed()
            or any(_state.get(k) for k in ('pin_history_active','pin_history_syncing',
                'pin_snap_transform_active','pin_target_dragging','pin_keyboard_transform_active'))
            or _window_manager_has_modal_operator(context)):
        return False
    changed=False
    for owner in _pose_scope_armatures(context):
        active=owner.data.bones.active
        bone=owner.pose.bones.get(active.name) if active is not None else None
        if (bone is not None and not _pose_bone_selected(bone)
                and (DYNAMIC_COLOR_PALETTE_KEY in bone
                     or _dynamic_pose_bone_uses_managed_constraints(bone))):
            owner.data.bones.active=None
            changed=True
    return changed


def _pin_native_pose_click_finish():
    if _state.get('pin_shape_selection_pending'):
        return .02
    pending = _state.get("pin_native_pose_click_pending")
    if not pending:
        return None
    window_pointer, before, extend, claim, deadline, *_previous_pins = pending
    window = next((w for w in bpy.context.window_manager.windows
                   if w.as_pointer() == window_pointer), None)
    if (window is None or _state.get("pin_history_active")
            or _state.get("pin_target_dragging")
            or _state.get("pin_keyboard_transform_active")
            or claim != int(_state.get("pin_gizmo_claim_serial", 0))):
        _state.pop("pin_native_pose_click_pending", None)
        return None
    with bpy.context.temp_override(window=window):
        context = bpy.context
        _pin_clear_deselected_active_bones(context)
        after = _pin_pose_selection_signature(context)
        if (not extend and not after[1] and _pin_primary_mouse_pressed()
                and time.perf_counter()<deadline):
            # Changing the active rig can clear its bone selection before
            # native picking completes. Keep this one click open until a
            # bone is selected or the empty click is actually released.
            return 0.01
        if after != before:
            _state.pop("pin_native_pose_click_pending", None)
            if extend:
                _state["pin_gizmo_selection_keys"] = after
            else:
                _state["pin_gizmo_extend_selection_until"] = 0.0
                if _pin_selected_target_key():
                    _pin_deselect_target(push_history=False)
            _animation_reveal_selected_bone_channels(context)
            _tag_redraw_all_view3d()
            return None
        if _pin_primary_mouse_pressed() and time.perf_counter() < deadline:
            return 0.01
    _state.pop("pin_native_pose_click_pending", None)
    _tag_redraw_all_view3d()
    return None


def _pin_shape_contains(point, shape, values):
    """Region-space native gesture tests; no geometry/depsgraph work."""
    x,y=point
    if shape=='BOX':
        a,b,c,d=values
        return min(a,b)<=x<=max(a,b) and min(c,d)<=y<=max(c,d)
    if shape=='CIRCLE':
        a,b,r=values
        return (x-a)**2+(y-b)**2<=r*r
    inside=False
    if len(values)<3:return False
    previous=values[-1]
    for current in values:
        ax,ay=previous;bx,by=current
        if (ay>y)!=(by>y) and x<(bx-ax)*(y-ay)/(by-ay)+ax:inside=not inside
        previous=current
    return inside


def _pin_shape_selection_set(initial, hits, mode):
    selected=set(initial)
    if mode=='SET':selected=set(hits)
    elif mode=='SUB':selected.difference_update(hits)
    elif mode=='XOR':selected.symmetric_difference_update(hits)
    elif mode=='AND':selected.intersection_update(hits)
    else:selected.update(hits)
    return selected


def _pin_shape_apply(context, targets, hits, mode, initial=None):
    """Native selection changes UI state only, including hidden-pin filtering."""
    selected=_pin_shape_selection_set(_pin_selected_target_keys() if initial is None else initial,hits,mode)
    cached=_state.setdefault('pin_selected_target_data',{})
    cached.update({key:targets[key] for key in selected if key in targets})
    active=_pin_selected_target_key()
    _pin_selection_runtime_restore(context,dict(selected=selected,active=active if active in selected else next(iter(sorted(selected)),'')))
    _state['pin_gizmo_selection_keys']=_pin_pose_selection_signature(context)
    _state.pop('pin_native_pose_click_pending',None)
    _animation_reveal_selected_bone_channels(context)
    _tag_redraw_all_view3d()


def _pin_observe_shape_selection(context, area, event):
    """Observe native box/lasso/circle/all selection, without consuming input."""
    if (context.mode!='POSE' or area.type!='VIEW_3D' or _pin_animation_hidden(context) or event.type not in {'A','I','B','C','LEFTMOUSE','RIGHTMOUSE'}
            or event.value!='PRESS' or _pin_active_transform_operator(context)):
        return
    region=next((r for r in area.regions if r.type=='WINDOW'
        and r.x<=event.mouse_x<r.x+r.width and r.y<=event.mouse_y<r.y+r.height),None)
    if region is None:return
    if _state.get('pin_shape_selection_pending'):return
    from bpy_extras.view3d_utils import location_3d_to_region_2d
    with context.temp_override(area=area,region=region):
        targets=_pin_available_target_data(context)
        points={}
        for key,data in targets.items():
            matrix=_pin_keyboard_target_matrix(data)
            point=location_3d_to_region_2d(region,area.spaces.active.region_3d,matrix.translation) if matrix is not None else None
            if point is not None:points[key]=tuple(point)
        smart=_smart_dragger_data(context)
        smart_points={}
        if smart is not None and not _smart_dragger_contact_owned(context,smart['armature'],smart['pose_bone']):
            for side in (0,1):
                if side==0 and not smart.get('surface_hit',True):continue
                point=location_3d_to_region_2d(region,area.spaces.active.region_3d,smart['dragger_points'][side])
                if point is not None:smart_points[side]=tuple(point)
    operators=tuple(context.window_manager.operators)
    action=''
    for config in (context.window_manager.keyconfigs.user,context.window_manager.keyconfigs.default):
        keymap=config.keymaps.get('Pose') if config else None
        for item in keymap.keymap_items if keymap else ():
            if (item.active and item.idname=='pose.select_all' and item.type==event.type
                    and item.value in {event.value,'ANY'} and (item.any or all(
                        bool(getattr(event,k,False))==bool(getattr(item,k)) for k in ('ctrl','shift','alt','oskey')))):
                action=str(item.properties.action);break
        if action:break
    _state['pin_shape_selection_pending']=dict(window=context.window.as_pointer(),area=area.as_pointer(),
        region=region.as_pointer(),targets=targets,points=points,initial=set(_pin_selected_target_keys()),
        last=operators[-1].as_pointer() if operators else 0,
        deadline=time.perf_counter()+(120. if event.type in {'B','C'} else 1.5),circle_started=False,
        smart_owner=(smart['armature'].name,smart['pose_bone'].name) if smart_points else None,
        smart_points=smart_points,smart_initial=_smart_dragger_selected_sides(),action=action,
        gesture_key=event.type in {'B','C'},claim=int(_state.get('pin_gizmo_claim_serial',0)),
        input_time=time.perf_counter(),
        start=(float(event.mouse_x-region.x),float(event.mouse_y-region.y)) if event.type in {'LEFTMOUSE','RIGHTMOUSE'} else None)
    if not bpy.app.timers.is_registered(_pin_shape_selection_finish):
        register_owned_timer(_pin_shape_selection_finish,first_interval=0.)


def _pin_shape_publish(context,pending,shape,values,mode):
    targets=pending['targets']
    if shape=='ALL':
        targets=_pin_available_target_data_impl(context,include_unselected=True)
        hits=set(targets) if values!='DESELECT' else set()
        mode='XOR' if values=='INVERT' else 'SET'
    else:
        hits={key for key,point in pending['points'].items() if _pin_shape_contains(point,shape,values)}
    _pin_shape_apply(context,targets,hits,mode,None if shape=='CIRCLE' else pending['initial'])
    smart_hits=({side for side,point in pending['smart_points'].items() if _pin_shape_contains(point,shape,values)}
                if shape!='ALL' else set())
    sides=_pin_shape_selection_set(_smart_dragger_selected_sides() if shape=='CIRCLE' else pending['smart_initial'],smart_hits,mode)
    if shape=='ALL':sides=set()
    _state['smart_dragger_selected_sides']=sides
    _state['smart_dragger_selected_side']=next(iter(sorted(sides)),-1)
    _state['smart_dragger_owner']=pending['smart_owner'] if sides else None
    _state['smart_dragger_selection_keys']=_pin_pose_selection_signature(context)


def _pin_shape_selection_finish():
    pending=_state.get('pin_shape_selection_pending')
    if pending is None:return None
    window=next((w for w in bpy.context.window_manager.windows if w.as_pointer()==pending['window']),None)
    area=next((a for a in window.screen.areas if a.as_pointer()==pending['area']),None) if window else None
    region=next((r for r in area.regions if r.as_pointer()==pending['region']),None) if area else None
    if (region is None or (not pending.get('observing') and time.perf_counter()>pending['deadline']) or _state.get('pin_history_active')
            or _state.get('pin_target_dragging') or _state.get('pin_keyboard_transform_active') or _state.get('pin_snap_transform_active')):
        _state.pop('pin_shape_selection_pending',None);return None
    with bpy.context.temp_override(window=window,area=area,region=region):
        context=bpy.context
        completed=pending.pop('completed',None)
        if completed:
            _pin_shape_publish(context,pending,*completed)
            _state.pop('pin_shape_selection_pending',None);return None
        if pending['action']:
            action=pending['action']
            if action=='TOGGLE':action='SELECT' if _selected_owner_bone_keys(context) else 'DESELECT'
            _pin_shape_publish(context,pending,'ALL',action,'SET')
            _state.pop('pin_shape_selection_pending',None);return None
        if pending.get('observing'):return .02
        names={'VIEW3D_OT_select_box':'BOX','VIEW3D_OT_select_lasso':'LASSO','VIEW3D_OT_select_circle':'CIRCLE'}
        native=next((op for op in window.modal_operators if op.bl_idname in names),None)
        if native is not None:
            pending['native']=native.as_pointer();pending['shape']=names[native.bl_idname]
            pending['mode']=str(getattr(native,'mode','SET'));pending['radius']=float(getattr(native,'radius',25))
            bpy.ops.staticaliza.pin_native_shape_observer('INVOKE_DEFAULT')
        elif (pending['claim']!=int(_state.get('pin_gizmo_claim_serial',0)) or (
                not pending['gesture_key'] and not _pin_primary_mouse_pressed()
                ) or (pending['gesture_key'] and time.perf_counter()-pending['input_time']>.2)):
            _state.pop('pin_shape_selection_pending',None);return None
    return .02


class ANIMATOR_UTILS_OT_pin_native_shape_observer(bpy.types.Operator):
    """Read the native gesture after it starts, passing every event through.

    Blender does not retain selection operators in wm.operators. This small
    passive observer is installed after the native gesture so it sees the
    same region-space mouse path; it never starts a competing select tool.
    """
    bl_idname='staticaliza.pin_native_shape_observer'
    bl_label='Observe Pin Selection'
    bl_options={'INTERNAL'}
    staticaliza_passive_modal=True

    def invoke(self,context,event):
        pending=_state.get('pin_shape_selection_pending')
        if not pending:return {'CANCELLED'}
        pending['observing']=True
        self.pending=pending
        self.path=[] if pending['start'] is None else [pending['start']]
        self.button=''
        self.timer=context.window_manager.event_timer_add(.025,window=context.window)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def finish(self,context,cancel=False):
        context.window_manager.event_timer_remove(self.timer)
        if cancel and _state.get('pin_shape_selection_pending') is self.pending:
            _state.pop('pin_shape_selection_pending',None)
        return {'FINISHED','PASS_THROUGH'}

    def cancel(self,context):
        self.finish(context,cancel=True)

    def modal(self,context,event):
        pending=self.pending
        if _state.get('pin_shape_selection_pending') is not pending:return self.finish(context)
        native=next((op for op in context.window.modal_operators if op.as_pointer()==pending['native']),None)
        if native is None:return self.finish(context,cancel=True)
        if event.type=='ESC' and event.value=='PRESS':return self.finish(context,cancel=True)
        shape=pending['shape'];mode=pending['mode']
        point=(float(event.mouse_x-context.region.x),float(event.mouse_y-context.region.y))
        if shape=='CIRCLE':
            if event.type in {'LEFTMOUSE','MIDDLEMOUSE'}:
                self.button=event.type if event.value=='PRESS' else ''
            if self.button and event.type in {'MOUSEMOVE','LEFTMOUSE','MIDDLEMOUSE'}:
                mode='SUB' if self.button=='MIDDLEMOUSE' else ('ADD' if pending['circle_started'] else mode)
                pending['circle_started']=True
                _pin_shape_publish(context,pending,shape,(*point,float(native.radius)),mode)
            if event.type in {'RIGHTMOUSE','RET','NUMPAD_ENTER'} and event.value=='PRESS':
                _state.pop('pin_shape_selection_pending',None);return self.finish(context)
            return {'PASS_THROUGH'}
        if event.type in {'LEFTMOUSE','RIGHTMOUSE','MIDDLEMOUSE'} and event.value=='PRESS':
            pending['start']=point;self.path=[point];self.button=event.type
            if event.type=='MIDDLEMOUSE':pending['mode']='SUB'
        elif event.type=='MOUSEMOVE':self.path.append(point)
        if event.type in {'LEFTMOUSE','RIGHTMOUSE','MIDDLEMOUSE'} and event.value=='RELEASE' and pending['start'] is not None:
            if shape=='BOX':
                a,b=pending['start'];values=(a,point[0],b,point[1])
            else:
                self.path.append(point);values=tuple(self.path)
            pending['completed']=(shape,values,pending['mode'])
            return self.finish(context)
        return {'PASS_THROUGH'}


def _pin_sync_contact_graph_filter(context, _wanted_by_armature=None, *, restore=False):
    return _animation_sync_graph_selection(context, restore=restore)


def _pin_select_contact_action_groups(
    context,
    defer = False,
    exclusive = False,
):
    if _state.get("pin_channel_selection_pending"):
        # Let Blender complete its native channel click before mirroring any
        # previous virtual selection back into those same channels.
        return False
    previous_syncing = bool(_state.get("pin_selection_syncing", False))
    _state["pin_selection_syncing"] = True
    try:
        return _pin_select_contact_action_groups_impl(
            context,
            defer = defer,
            exclusive = exclusive,
        )
    finally:
        _state["pin_selection_syncing"] = previous_syncing


def _pin_select_contact_action_groups_impl(
    context,
    defer = False,
    exclusive = False,
):
    """Mirror selected Collision/Gyro pins into their Constraint channels."""
    del defer
    wanted_by_armature = {}
    for _target_key, target_data in _pin_selected_targets_data(context):
        if target_data[0] not in {"CONTACT", "GYRO"}:
            continue
        armature = target_data[1]
        guide = target_data[3]
        bone_name = target_data[2].name
        wanted_by_armature.setdefault(armature, set()).add(
            f"Constraint ({bone_name})"
        )
    changed = False
    armatures = list(_pose_scope_armatures(context))
    for armature in wanted_by_armature:
        if armature not in armatures:
            armatures.append(armature)
    for armature in armatures:
        wanted_names = wanted_by_armature.get(armature, set())
        action = getattr(
            getattr(armature, "animation_data", None),
            "action",
            None,
        )
        for groups in _action_group_owners(action, armature):
            for group in groups:
                is_contact_group = str(group.name).startswith(("Constraint (", "Surface Contact (", "Gyro ("))
                if not exclusive and not is_contact_group:
                    continue
                selected = str(group.name) in wanted_names
                if bool(group.select) != selected:
                    group.select = selected
                    changed = True
                if is_contact_group and selected:
                    try:
                        if bool(group.show_expanded):
                            group.show_expanded = False
                            changed = True
                        if bool(group.show_expanded_graph):
                            group.show_expanded_graph = False
                            changed = True
                    except (
                        AttributeError,
                        ReferenceError,
                        RuntimeError,
                        TypeError,
                        ValueError,
                    ):
                        pass
                for fcurve in group.channels:
                    curve_selected = selected if (exclusive or is_contact_group) else bool(fcurve.select)
                    if is_contact_group and selected and bool(fcurve.hide):
                        fcurve.hide = False
                        changed = True
                    if bool(fcurve.select) != curve_selected:
                        fcurve.select = curve_selected
                        changed = True
    _pin_sync_contact_graph_filter(context, wanted_by_armature)
    if changed:
        window_manager = getattr(context, "window_manager", None)
        for window in getattr(window_manager, "windows", ()):
            for area in getattr(window.screen, "areas", ()):
                if area.type in {"DOPESHEET_EDITOR", "GRAPH_EDITOR"}:
                    area.tag_redraw()
    return changed


def _pin_selected_target_key(context = None, validate = False):
    key = str(_state.get("pin_gizmo_selected_key", ""))
    if key and validate and key not in _pin_available_target_data(context):
        return ""
    return key


def _pin_selected_target_keys():
    """Return the selected-pin set while honoring legacy active-key writes."""
    active_key = str(_state.get("pin_gizmo_selected_key", ""))
    recorded_active = str(
        _state.get("pin_gizmo_selected_keys_active", "")
    )
    selected_keys = {
        str(key)
        for key in _state.get("pin_gizmo_selected_keys", set())
        if str(key)
    }
    if active_key != recorded_active:
        # Tests, reload migration, and older runtime paths may still write the
        # singular key directly. Treat that as an intentional replacement.
        selected_keys = {active_key} if active_key else set()
        _state["pin_gizmo_selected_keys"] = selected_keys
        _state["pin_gizmo_selected_keys_active"] = active_key
    elif active_key:
        selected_keys.add(active_key)
    else:
        selected_keys.clear()
    if active_key and active_key not in selected_keys:
        active_key = next(iter(sorted(selected_keys)), '')
        _state['pin_gizmo_selected_key'] = active_key
        _state['pin_gizmo_selected_keys_active'] = active_key
    _state["pin_gizmo_selected_keys"] = set(selected_keys)
    return frozenset(selected_keys)
def _pin_live_selected_target(key, targets, cached):
    """History/conversion may delete a cached helper before the next redraw."""
    for data in (targets.get(key), cached.get(key)):
        if data is None:
            continue
        try:
            kind, armature, bone, payload = data
            if (bpy.data.objects.get(armature.name) != armature
                    or armature.pose.bones.get(bone.name) != bone):
                continue
            if kind in {"CONTACT", "GYRO"} and bpy.data.objects.get(payload.name) != payload:
                continue
            if not _pose_bone_is_visible(bone):
                continue
            if kind == 'CONTACT' and _contact_chain_uses_contact(payload) and not _surface_contact_has_valid_surface(payload):
                continue
            if kind == 'GYRO' and not _gyro_active(bpy.context,payload):
                continue
            if kind == 'YELLOW' and _yellow_owner_hidden(armature):
                continue
            return data
        except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
            continue
    cached.pop(key, None)
    return None


def _pin_selected_target_data(context):
    key = _pin_selected_target_key()
    targets = _pin_available_target_data(context)
    cached = _state.setdefault("pin_selected_target_data", {})
    return key, _pin_live_selected_target(key, targets, cached)
def _pin_selected_targets_data(context):
    targets = _pin_available_target_data(context)
    cached = _state.setdefault("pin_selected_target_data", {})
    selected_keys = _pin_selected_target_keys()
    active_key = _pin_selected_target_key()
    ordered_keys = (
        ((active_key,) if active_key in selected_keys else ())
        + tuple(sorted(selected_keys - {active_key}))
    )
    return tuple((key, data) for key in ordered_keys
                 if (data := _pin_live_selected_target(key, targets, cached)) is not None)


def _pin_selection_runtime_snapshot():
    return {
        "active": _pin_selected_target_key(),
        "selected": set(_pin_selected_target_keys()),
    }


def _pin_selection_history_store(context = None, snapshot = None, push = False):
    context = context or bpy.context
    snapshot = snapshot or _pin_selection_runtime_snapshot()
    snapshot = {
        "active": str(snapshot.get("active", "")),
        "selected": {
            str(key) for key in snapshot.get("selected", set())
        },
    }
    previous = _state.get("pin_selection_runtime_history")
    _state["pin_selection_runtime_history"] = snapshot
    # Virtual pin selection is transient UI state. Writing it onto Scene
    # creates an undoable ID-property edit even without undo_push(), leaving a
    # phantom Ctrl+Z between ordinary pose transforms.
    del context, push
    return previous != snapshot


def _pin_selection_history_load(context):
    scene = getattr(context, "scene", None)
    packed = (
        scene.get(PIN_SELECTION_HISTORY_PROPERTY)
        if scene is not None
        else None
    )
    if packed is None:
        return None
    try:
        snapshot = json.loads(str(packed))
    except (TypeError, ValueError):
        return None
    return {
        "active": str(snapshot.get("active", "")),
        "selected": set(
            str(key) for key in snapshot.get("selected", ())
        ),
    }


def _pin_selection_runtime_restore(context, snapshot):
    """Restore virtual selection after a non-selection UI operation."""
    selected_keys = set((snapshot or {}).get("selected", set()))
    active_key = str((snapshot or {}).get("active", ""))
    if not selected_keys:
        _state["pin_gizmo_selected_key"] = ""
        _state["pin_gizmo_selected_keys"] = set()
        _state["pin_gizmo_selected_keys_active"] = ""
        _state["pin_gizmo_axes_visible"] = {}
        _state["pin_gizmo_selection_keys"] = ()
        _state["pin_gizmo_pending_click"] = None
        _state["pin_pointer_pending_click"] = None
        _pin_selection_history_store(
            context,
            {"active": "", "selected": set()},
        )
        _tag_redraw_all_view3d()
        return frozenset()
    _state["pin_gizmo_selected_key"] = active_key
    _state["pin_gizmo_selected_keys"] = selected_keys
    _state["pin_gizmo_selected_keys_active"] = active_key
    available_keys = set(_pin_available_target_data(context))
    selected_keys &= available_keys
    if active_key not in selected_keys:
        active_key = next(iter(sorted(selected_keys)), "")
    _state["pin_gizmo_selected_key"] = active_key
    _state["pin_gizmo_selected_keys"] = selected_keys
    _state["pin_gizmo_selected_keys_active"] = active_key
    _state["pin_gizmo_pending_click"] = None
    _state["pin_pointer_pending_click"] = None
    _state["pin_gizmo_selection_keys"] = (
        _pin_pose_selection_signature(context) if active_key else ()
    )
    _state["pin_gizmo_extend_selection_until"] = (
        time.perf_counter() + 0.25 if active_key else 0.0
    )
    _pin_selection_history_store(context)
    _tag_redraw_all_view3d()
    return frozenset(selected_keys)


def _pin_modal_target_data(operator, context):
    """Reuse stable pin references for one modal transform interaction."""
    cached = getattr(operator, "_target_data_cache", None)
    if cached is not None:
        try:
            kind, armature, pose_bone, payload = cached
            valid = bool(
                armature is not None
                and armature.name
                == str(getattr(operator, "armature_name", ""))
                and (
                    (
                        kind == "YELLOW"
                        and pose_bone is not None
                        and pose_bone.name
                        == str(getattr(operator, "target_bone_name", ""))
                    )
                    or (
                        kind in {"CONTACT", "GYRO"}
                        and payload is not None
                        and payload.name
                        == str(getattr(operator, "contact_guide_name", ""))
                    )
                )
            )
            if valid:
                return cached
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            pass

    target_data = _pin_available_target_data(context).get(operator.target_key)
    operator._target_data_cache = target_data
    return target_data


def _pin_target_locked_axes(target_data):
    # Onion targets are independent markers. Bone locks (including the
    # temporary locks applied by Ragdoll) constrain poses, not these targets.
    if target_data and target_data[0] == 'YELLOW':
        return (False, False, False)
    pose_bone = target_data[2] if target_data else None
    if pose_bone is None:
        return (False, False, False)
    try:
        return tuple(bool(value) for value in pose_bone.lock_location[:3])
    except (AttributeError, ReferenceError, TypeError, ValueError):
        return (False, False, False)


def _pin_pose_selection_signature(context):
    armatures = _pose_scope_armatures(context)
    if not armatures:
        return ((), (), (0, ""))
    selected_names = tuple(sorted(_selected_owner_bone_keys(context)))
    active = getattr(context, "active_pose_bone", None)
    active_armature = _pose_bone_owner(context, active, armatures)
    active_key = (
        _owner_bone_key(active_armature, active.name)
        if active is not None and active_armature is not None
        else (0, "")
    )
    return (
        tuple(sorted(_armature_session_uid(armature) for armature in armatures)),
        selected_names,
        active_key,
    )


def _pin_shift_modifier_pressed():
    """Read Shift without putting a Python operator on Blender's mouse path.

    Blender does not expose the current modifier state outside an event
    callback. On Windows, GetAsyncKeyState also reports a Shift press that
    happened since the preceding call, so a quick Shift-click is still seen
    when the selection timer runs after Blender finishes selecting the bone.
    """
    if os.name != "nt":
        return False
    try:
        import ctypes

        state = int(ctypes.windll.user32.GetAsyncKeyState(0x10))
    except (AttributeError, OSError, TypeError, ValueError):
        return False
    return bool(state & 0x8001)


def _pin_primary_mouse_pressed():
    """Read LMB without adding a Python operator to Blender's press keymap."""
    if os.name != "nt":
        return False
    try:
        import ctypes

        return bool(int(ctypes.windll.user32.GetAsyncKeyState(0x01)) & 0x8000)
    except (AttributeError, OSError, TypeError, ValueError):
        return False


def _pin_preserve_extended_pose_selection(
    saved_signature,
    current_signature,
    shift_pressed,
):
    """Keep a virtual pin selected while Shift changes bone selection."""
    return bool(
        saved_signature
        and current_signature != saved_signature
        and shift_pressed
    )


def _pin_deselect_pose_bones(context):
    """Clear native pose selection and its active-bone hover/gizmo context."""
    changed = False
    for armature in _pose_scope_armatures(context):
        armature_data = getattr(armature, "data", None)
        pose = getattr(armature, "pose", None)
        for pose_bone in getattr(pose, "bones", ()):
            bone = getattr(pose_bone, "bone", None)
            try:
                if hasattr(pose_bone, "select"):
                    if pose_bone.select:
                        changed = True
                        pose_bone.select = False
                elif bone is not None:
                    if bone.select or bone.select_head or bone.select_tail:
                        changed = True
                        bone.select = False
                        bone.select_head = False
                        bone.select_tail = False
            except (AttributeError, ReferenceError, RuntimeError):
                pass
        try:
            if armature_data is not None and armature_data.bones.active is not None:
                armature_data.bones.active = None
                changed = True
        except (AttributeError, ReferenceError, RuntimeError):
            pass
    # Selection flags are consumed directly by Blender's next draw. Flushing
    # the dependency graph inside Gizmo.invoke can destroy its current group
    # before the click handler finishes; there is no pose change to evaluate.
    return changed


def _pin_select_target(
    context,
    target_key,
    extend = False,
    defer_pose_selection = False,
    target_data_override = None,
):
    previous = bool(_state.get("pin_selection_syncing", False))
    _state["pin_selection_syncing"] = True
    try:
        return _pin_select_target_guarded(
            context, target_key, extend=extend,
            defer_pose_selection=defer_pose_selection,
            target_data_override=target_data_override,
        )
    finally:
        _state["pin_selection_syncing"] = previous


def _pin_select_target_guarded(
    context, target_key, extend=False, defer_pose_selection=False,
    target_data_override=None,
):
    target_key = str(target_key)
    target_data = _pin_available_target_data(context).get(target_key)
    if target_data is None and target_data_override is not None:
        # The passive pixel-overlay picker snapshots its target before
        # Blender's underlying click selection runs. A background click can
        # deselect the owner bone before mouse release, but the pin click must
        # still win. The selected key immediately restores normal validation.
        target_data = target_data_override
    if target_data is None:
        return False
    _state["smart_dragger_selected_side"] = -1
    _state["smart_dragger_selected_sides"] = set()
    _state["smart_dragger_owner"] = None
    _state["smart_dragger_selection_keys"] = ()
    _state["gyro_selected"] = ""
    if target_data[0] == "YELLOW":
        _state.setdefault("pin_yellow_history_fallbacks", {})[
            _owner_bone_key(target_data[1], target_data[2].name)
        ] = tuple(float(value) for value in Vector(target_data[3][0]))
        try:
            yellow_mode = int(
                target_data[2].get(YELLOW_PIN_MODE_PROPERTY, 3)
            )
        except (TypeError, ValueError):
            yellow_mode = 3
        yellow_mode = 3 if yellow_mode == 5 else max(1, min(4, yellow_mode))
        _state["yellow_pin_mode_syncing"] = True
        try:
            desired_mode = f"MODE_{yellow_mode}"
            if context.window_manager.yellow_pin_mode != desired_mode:
                context.window_manager.yellow_pin_mode = desired_mode
        finally:
            _state["yellow_pin_mode_syncing"] = False
        _state["yellow_pin_axis_syncing"] = True
        try:
            desired_axis = str(
                target_data[2].get(YELLOW_PIN_AXIS_PROPERTY, "Y_NEG")
            )
            if context.window_manager.yellow_pin_axis != desired_axis:
                context.window_manager.yellow_pin_axis = desired_axis
        finally:
            _state["yellow_pin_axis_syncing"] = False
    elif target_data[0] == "CONTACT":
        _state["surface_contact_axis_syncing"] = True
        try:
            desired_axis = str(
                target_data[3].get(
                    SURFACE_CONTACT_CAST_AXIS_PROPERTY,
                    "Y_NEG",
                )
            )
            if context.window_manager.surface_contact_cast_axis != desired_axis:
                context.window_manager.surface_contact_cast_axis = desired_axis
        finally:
            _state["surface_contact_axis_syncing"] = False
    elif target_data[0] == "GYRO":
        _gyro_sync_selection_settings(context, target_data[3])
    previous_active = str(_state.get("pin_gizmo_selected_key", ""))
    previous_keys = _pin_selected_target_keys()
    selected_keys = (
        set(previous_keys) | {target_key}
        if extend
        else {target_key}
    )
    changed = (
        target_key != previous_active
        or selected_keys != set(previous_keys)
    )
    _state["pin_gizmo_selected_key"] = target_key
    _state["pin_gizmo_selected_keys"] = selected_keys
    _state["pin_gizmo_selected_keys_active"] = target_key
    selected_cache = _state.setdefault("pin_selected_target_data", {})
    if not extend:
        selected_cache.clear()
    selected_cache[target_key] = target_data
    if changed:
        _state["pin_gizmo_selection_epoch"] = int(
            _state.get("pin_gizmo_selection_epoch", 0)
        ) + 1
    # Discard an older modifier transition when a new virtual-pin selection
    # begins. The next asynchronous Shift press then belongs unambiguously to
    # the bone-selection change that follows this pin click.
    _pin_shift_modifier_pressed()
    _state["pin_gizmo_pending_click"] = None
    _state["pin_gizmo_axes_visible"] = {target_key: True}
    if not extend and not defer_pose_selection:
        # A normal click selects the virtual pin exclusively. Set the pin key
        # first so contact reconciliation continues treating its guide as the
        # actively manipulated target while Blender clears the Pose selection.
        # The virtual pin key owns the linked-bone UI context. Blender's
        # native active-bone pointer must also be cleared or a bone behind the
        # diamond can flash and expose its transform gizmo during pin drags.
        _pin_deselect_pose_bones(context)
    _state["pin_gizmo_selection_keys"] = _pin_pose_selection_signature(context)
    if changed and not _state.get("pin_selection_from_channels"):
        _pin_selection_history_store(context, push=True)
        _pin_select_contact_action_groups(
            context,
            # A timer that re-selects Action channels after the pin click
            # mutates Blender data outside the click/transform operator. That
            # delayed write becomes a pose-invisible Undo/Redo checkpoint.
            defer=False,
            exclusive=target_data[0] == "CONTACT" and not extend,
        )
        _tag_redraw_all_view3d()
    return True


def _pin_deselect_target(push_history=True, store_history=True, redraw=True):
    if not _pin_selected_target_keys():
        _state["pin_gizmo_pending_click"] = None
        if store_history:
            _pin_selection_history_store(
                bpy.context, {"active": "", "selected": set()}
            )
        _pin_select_contact_action_groups(bpy.context, defer = False)
        return False
    _state["pin_gizmo_selected_key"] = ""
    _state["pin_gizmo_selected_keys"] = set()
    _state["pin_gizmo_selected_keys_active"] = ""
    _state["pin_selected_target_data"] = {}
    _pin_select_contact_action_groups(bpy.context, defer = False)
    _state["pin_gizmo_pending_click"] = None
    _state["pin_gizmo_selection_epoch"] = int(
        _state.get("pin_gizmo_selection_epoch", 0)
    ) + 1
    _state["pin_gizmo_axes_visible"] = {}
    _state["pin_gizmo_selection_keys"] = ()
    _state["pin_gizmo_extend_selection_until"] = 0.0
    if store_history:
        _pin_selection_history_store(bpy.context, push = push_history)
    if redraw:
        _tag_redraw_all_view3d()
    return True

def _pin_finish_exclusive_selection(context, target_key, exclusive):
    if not bool(exclusive):
        return
    target_data = _pin_available_target_data(context).get(str(target_key))
    if target_data is None:
        return
    _pin_deselect_pose_bones(context)
    _state["pin_gizmo_selection_keys"] = _pin_pose_selection_signature(context)


def _pin_gizmo_claim_pointer(event):
    _state["pin_gizmo_claim_serial"] = int(
        _state.get("pin_gizmo_claim_serial", 0)
    ) + 1
    _state["pin_gizmo_pending_click"] = None
    _state["pin_pointer_pending_click"] = None
    _state["pin_gizmo_last_claim"] = (
        int(getattr(getattr(bpy.context, "window", None), "as_pointer", lambda: 0)()),
        int(getattr(event, "mouse_x", -2147483648)),
        int(getattr(event, "mouse_y", -2147483648)),
        float(time.perf_counter()),
    )


def _pin_preserve_after_transform(context, target_key, event = None):
    """Keep a confirmed/cancelled pin transform from becoming click-away."""
    target_key = str(target_key)
    if (
        event is not None
        and str(getattr(event, "type", "")) == "LEFTMOUSE"
    ):
        _pin_gizmo_claim_pointer(event)
    _state["pin_gizmo_pending_click"] = None
    _state["pin_pointer_pending_click"] = None
    if target_key != _pin_selected_target_key():
        return False
    _state["pin_gizmo_axes_visible"] = {target_key: True}
    _state["pin_gizmo_selection_keys"] = _pin_pose_selection_signature(
        context
    )
    _state["pin_gizmo_extend_selection_until"] = (
        time.perf_counter() + 0.25
    )
    _tag_redraw_all_view3d()
    return True


def _pin_gizmo_saved_axes_visible(group, target_key = None):
    key = str(
        target_key
        if target_key is not None
        else getattr(group, "active_target_key", "")
    )
    if not key:
        return bool(getattr(group, "axes_visible", False))
    if key != _pin_selected_target_key():
        return False
    return bool(_state.setdefault("pin_gizmo_axes_visible", {}).get(key, True))


def _pin_gizmo_set_axes_visible(group, visible):
    if group is None:
        return
    visible = bool(visible)
    group.axes_visible = visible
    key = str(getattr(group, "active_target_key", ""))
    if key:
        _state.setdefault("pin_gizmo_axes_visible", {})[key] = visible



def _pin_gizmo_track_selection(context, preserve_visibility = False):
    if (
        preserve_visibility
        or _state.get("pin_history_active", False)
        or _state.get("pin_target_dragging", False)
        or _state.get("pin_keyboard_transform_active", False)
    ):
        # History evaluation and undoable gizmo commits can expose a transient
        # empty context. Do not consume the uninterrupted-selection baseline.
        return False
    selected = _pin_selected_target_key()
    if not selected:
        _state["pin_gizmo_selection_keys"] = ()
        return False
    # Pin/channel synchronization belongs to explicit selection changes.
    # Rewriting it here scans every Action on idle ticks and can fight a
    # native channel click before its completion callback has run.
    extend_until = float(
        _state.get("pin_gizmo_extend_selection_until", 0.0)
    )
    if extend_until > 0.0:
        # Shift-click selection is completed by Blender after our pass-through
        # keymap item. Accept each intermediate signature until it settles.
        _state["pin_gizmo_selection_keys"] = _pin_pose_selection_signature(
            context
        )
        if time.perf_counter() < extend_until:
            return False
        _state["pin_gizmo_extend_selection_until"] = 0.0
    try:
        valid = bool(
            selected in _pin_available_target_data(context)
            or selected in _state.setdefault("pin_selected_target_data", {})
        )
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        valid = False
    if valid:
        current_signature = _pin_pose_selection_signature(context)
        saved_signature = _state.get("pin_gizmo_selection_keys", ())
        if saved_signature and current_signature != saved_signature:
            if _pin_preserve_extended_pose_selection(
                saved_signature,
                current_signature,
                _pin_shift_modifier_pressed(),
            ):
                _state["pin_gizmo_selection_keys"] = current_signature
                _pin_select_contact_action_groups(context, defer = False)
                return False
            return _pin_deselect_target()
        _state["pin_gizmo_selection_keys"] = current_signature
        return False
    return _pin_deselect_target()


def _pin_gizmo_begin_interaction(
    gizmo,
    event,
    context=None,
    target_data_override=None,
):
    group = _pin_gizmo_group(gizmo)
    _pin_gizmo_claim_pointer(event)
    target_key = str(getattr(gizmo, "target_key", ""))
    gizmo.extend_selection = bool(getattr(event, "shift", False))
    axis_index = int(getattr(gizmo, "axis_index", -1))
    preserve_group = target_key in _pin_selected_target_keys()
    center_exclusive = bool(
        axis_index < 0
        and not gizmo.extend_selection
        and not preserve_group
    )
    pin_only_axis = bool(
        axis_index >= 0
        and not gizmo.extend_selection
        and context is not None
        and not _selected_owner_bone_keys(context)
    )
    if target_key and context is not None:
        # Blender may clear the pose-bone selection between Gizmo.invoke and
        # the zero-delay post-modal finalizer. Accept that transient signature
        # for both normal and Shift clicks so the just-selected virtual pin is
        # not mistaken for a click-away.
        _state["pin_gizmo_extend_selection_until"] = (
            time.perf_counter() + 0.75
        )
        _state["pin_gizmo_selection_keys"] = ()
        _pin_select_target(
            context,
            target_key,
            extend = gizmo.extend_selection or preserve_group,
            # A normal center press and a pin-only axis drag both clear stale
            # native active-bone state before the next redraw. Shift
            # multi-selection retains its actual pose-bone selection.
            defer_pose_selection = (
                bool(gizmo.extend_selection)
                or not target_key.startswith("CONTACT:")
            ),
            target_data_override=target_data_override,
        )
    if group is not None and target_key:
        group.active_target_key = target_key
        _pin_gizmo_set_axes_visible(group, True)
    gizmo.initial_mouse = (
        float(event.mouse_region_x),
        float(event.mouse_region_y),
    )
    gizmo.drag_started = False
    gizmo.axes_were_visible = _pin_gizmo_saved_axes_visible(group)
    if group is None:
        return
    _state["pin_gizmo_active_axis_index"] = axis_index
    group.center_dragging = False
    if axis_index >= 0:
        group.active_axis_index = axis_index
    else:
        group.active_axis_index = -1


def _pin_gizmo_drag_ready(gizmo, event):
    if bool(getattr(gizmo, "drag_started", False)):
        return True
    initial_mouse = Vector(getattr(gizmo, "initial_mouse", (0.0, 0.0)))
    current_mouse = Vector(
        (float(event.mouse_region_x), float(event.mouse_region_y))
    )
    if (current_mouse - initial_mouse).length < PIN_GIZMO_DRAG_PIXEL_THRESHOLD:
        return False
    gizmo.drag_started = True
    group = _pin_gizmo_group(gizmo)
    if group is not None:
        axis_index = int(getattr(gizmo, "axis_index", -1))
        if axis_index >= 0:
            group.active_axis_index = axis_index
        else:
            group.center_dragging = True
    _tag_redraw_all_view3d()
    return True


def _pin_gizmo_finish_interaction(gizmo, cancel):
    _state["pin_gizmo_active_axis_index"] = -1
    group = _pin_gizmo_group(gizmo)
    if group is None:
        return
    axis_index = int(getattr(gizmo, "axis_index", -1))
    group.active_axis_index = -1
    group.center_dragging = False
    if str(getattr(group, "active_target_key", "")) == _pin_selected_target_key():
        _pin_gizmo_set_axes_visible(group, True)

def _pin_gizmo_configure_undo(gizmo, enabled, legacy_message = ""):
    """Use native Gizmo undo when available, otherwise request safe fallback."""
    enabled = bool(enabled)
    try:
        gizmo.use_undo = enabled
        return ""
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        # Blender 4.2-4.3 do not expose Gizmo.use_undo to Python. Their undo
        # step is pushed by our zero-delay post-modal timer instead.
        return str(legacy_message) if enabled else ""
