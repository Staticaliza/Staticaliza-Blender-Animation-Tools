"""Rest-geometry and hierarchy correspondence for explicit mirror operations."""

from ..core.runtime import *  # noqa: F403


def _mirror_operation_begin():
    depth = int(_state.get('mirror_operation_depth', 0))
    if not depth:
        _state['mirror_operation_rest'] = {}
        _state['mirror_curve_sample_budget'] = 16384
        _state['mirror_curve_limited'] = False
        _state['mirror_unmatched_bones'] = set()
        _state['mirror_missing_pins'] = set()
    _state['mirror_operation_depth'] = depth+1


def _mirror_operation_end():
    depth = max(0, int(_state.get('mirror_operation_depth', 1))-1)
    _state['mirror_operation_depth'] = depth
    if not depth:
        _state.pop('mirror_operation_rest', None)
        _state.pop('mirror_curve_sample_budget', None)
        _state.pop('mirror_unmatched_bones', None)
        _state.pop('mirror_missing_pins', None)


def _mirror_assignment(costs):
    """Minimum-cost rectangular assignment, including caller-supplied gaps."""
    n = len(costs)
    m = len(costs[0]) if n else 0
    u, v, p, way = [0.]*(n+1), [0.]*(m+1), [0]*(m+1), [0]*(m+1)
    for i in range(1, n+1):
        p[0] = i
        j0 = 0
        minimum, used = [float('inf')]*(m+1), [False]*(m+1)
        while True:
            used[j0] = True
            i0, delta, j1 = p[j0], float('inf'), 0
            for j in range(1, m+1):
                if used[j]:
                    continue
                current = costs[i0-1][j-1]-u[i0]-v[j]
                if current < minimum[j]:
                    minimum[j], way[j] = current, j0
                if minimum[j] < delta:
                    delta, j1 = minimum[j], j
            for j in range(m+1):
                if used[j]:
                    u[p[j]] += delta
                    v[j] -= delta
                else:
                    minimum[j] -= delta
            j0 = j1
            if not p[j0]:
                break
        while j0:
            j1 = way[j0]
            p[j0], j0 = p[j1], j1
    return {p[j]-1: j-1 for j in range(1, m+1) if p[j]}


def _mirror_rest_pair_cost(a, b, normal, origin, scale):
    length = max(a['length'], b['length'], scale*.055, 1.e-7)
    geometry = ((a['_ref_head']-b['_head']).length + (a['_ref_tail']-b['_tail']).length)/(2.*length)
    if geometry > 1.5:
        return 1.5
    ratio = abs(a['_log_length']-b['_log_length'])
    direction = 0.
    if a['length'] > 1.e-7 and b['length'] > 1.e-7:
        direction = .18*(1.-max(-1., min(1., a['_ref_direction'].dot(b['_direction']))))
    topology = .065*min(4, abs(a['branch_depth']-b['branch_depth']))
    topology += .07*min(3, abs(a['branches']-b['branches']))
    topology += .32*bool(a['deform'] != b['deform'])
    named = a['_flipped'] == b['name'] and a['name'] != b['name']
    return max(0., geometry + .10*ratio + direction + topology - (.18 if named else 0.))


def _mirror_rig_rest(armature):
    """Bounded plain-data cache; rest edits, renames and history change its key."""
    operation = _state.get('mirror_operation_rest')
    pointer = int(armature.data.as_pointer())
    if operation is not None and pointer in operation:
        return operation[pointer]
    bones = tuple(armature.data.bones)
    signature = tuple((b.name, b.parent.name if b.parent else '', bool(b.use_deform),
                       tuple(float(v) for row in b.matrix_local for v in row),
                       tuple(b.head_local), tuple(b.tail_local)) for b in bones)
    digest = hashlib.blake2b(repr(signature).encode(), digest_size=16).digest()
    key = (int(armature.data.as_pointer()), digest)
    cache = _state.setdefault('mirror_rig_rest_cache', {})
    if key in cache:
        if operation is not None:
            operation[pointer] = cache[key]
        return cache[key]
    features = []
    for bone in bones:
        branch_depth, parent = 0, bone.parent
        while parent:
            branch_depth += int(len(parent.children) != 1)
            parent = parent.parent
        features.append(dict(name=bone.name, head=tuple(bone.head_local),
            tail=tuple(bone.tail_local), length=float(bone.length),
            parent=bone.parent.name if bone.parent else '', deform=bool(bone.use_deform),
            branch_depth=branch_depth, branches=len(bone.children)))
    roots = [b for b in bones if b.parent is None]
    def root_score(bone):
        compact = ''.join(c for c in _strip_blender_numeric_suffix(bone.name).casefold() if c.isalnum())
        return (compact in {'humanoidrootpart', 'rootpart', 'root'},
                len(bone.children_recursive), -bone.length, bone.name)
    root = max(roots or bones, key=root_score) if bones else None
    origin = root.head_local.copy() if root else Vector((0., 0., 0.))
    if len(roots) > 1:
        coordinates = [sorted(float(b.head_local[i]) for b in roots) for i in range(3)]
        origin = Vector(tuple((axis[(len(axis)-1)//2]+axis[len(axis)//2])*.5 for axis in coordinates))
    points = [Vector(f[part]) for f in features for part in ('head', 'tail')]
    scale = max(((p-origin).length for p in points), default=1.)
    scale = max(scale, 1.e-6)
    for feature in features:
        feature['_head'], feature['_tail'] = Vector(feature['head']), Vector(feature['tail'])
        feature['_direction'] = (feature['_tail']-feature['_head']).normalized()
        feature['_log_length'] = math.log(max(feature['length'], scale*.005))
        feature['_flipped'] = _pin_flipped_name(feature['name'])
    def prepare(normal):
        for feature in features:
            for part in ('head', 'tail'):
                point = feature['_'+part]
                feature['_ref_'+part] = point-2.*normal*(point-origin).dot(normal)
            direction = feature['_direction']
            feature['_ref_direction'] = direction-2.*normal*direction.dot(normal)
    normals = [Vector((1., 0., 0.)), Vector((0., 1., 0.)), Vector((0., 0., 1.))]
    if root is not None:
        normals.extend(root.matrix_local.to_3x3().col[i].copy() for i in range(3))
    # Rest skeletons need not face a Blender axis. Comparable sibling sockets
    # supply additional bilateral candidates independently of names and rolls.
    sockets = sorted(features, key=lambda f: (-f['length'], f['name']))[:24]
    socket_pairs = []
    for i, a in enumerate(sockets):
        for b in sockets[i+1:]:
            delta = a['_head']-b['_head']
            if (a['parent'] != b['parent'] or a['deform'] != b['deform']
                    or delta.length < scale*.1):
                continue
            socket_pairs.append((abs(a['_log_length']-b['_log_length']), delta.normalized()))
    normals.extend(normal for _score, normal in sorted(socket_pairs, key=lambda p: p[0])[:8])
    if len(points) >= 3:
        import numpy as np
        data = np.asarray([tuple(p-origin) for p in points], dtype=float)
        _values, axes = np.linalg.eigh(data.T @ data)
        normals.extend(Vector(tuple(axes[:, i])) for i in range(3))
    epsilon = scale*.012
    best = None
    checked = []
    probe = sorted(features, key=lambda f: (-f['length'], f['name']))[:128]
    for normal in normals:
        normal.normalize()
        if any(abs(normal.dot(other)) > 1.-1.e-6 for other in checked):
            continue
        checked.append(normal.copy())
        prepare(normal)
        sides = {f['name']: (Vector(f['head'])+Vector(f['tail']))*.5-origin for f in features}
        left = [f for f in probe if sides[f['name']].dot(normal) > epsilon]
        right = [f for f in probe if sides[f['name']].dot(normal) < -epsilon]
        if not left or not right:
            continue
        nearest = []
        for one, other in ((left, right), (right, left)):
            nearest.extend(min(_mirror_rest_pair_cost(a, b, normal, origin, scale)
                               for b in other) for a in one)
        coverage = sum(c < .85 for c in nearest)/len(nearest)
        score = sum(min(c, 1.5) for c in nearest)/len(nearest) + .35*(1.-coverage)
        # A depth plane through an almost planar skeleton is not a bilateral axis.
        score += .04/(.04+sum(abs(v.dot(normal)) for v in sides.values())/(len(features)*scale))
        if best is None or score < best[0]-1.e-8:
            best = (score, normal.copy(), left, right)
    normal = best[1] if best else Vector((1., 0., 0.))
    prepare(normal)
    if root is not None and len(roots) > 1:
        descendants = (root, *root.children_recursive)
        signed = [(((b.head_local+b.tail_local)*.5)-origin).dot(normal) for b in descendants]
        if not (min(signed) < -epsilon and max(signed) > epsilon):
            root = None
    up = Vector((0., 0., 1.)) if abs(normal.z) < .9 else Vector((0., 1., 0.))
    y = up.cross(normal).normalized()
    plane = Matrix((normal, y, normal.cross(y))).transposed().to_4x4()
    plane.translation = origin
    mapping, confidence = {}, {}
    if best:
        left = [f for f in features if (((f['_head']+f['_tail'])*.5)-origin).dot(normal) > epsilon]
        right = [f for f in features if (((f['_head']+f['_tail'])*.5)-origin).dot(normal) < -epsilon]
        trees = None
        if len(right) > 64:
            from mathutils.kdtree import KDTree
            trees = []
            for deform in (False, True):
                members = [(j, b) for j, b in enumerate(right) if b['deform'] == deform]
                if not members:
                    continue
                tree = KDTree(len(members))
                for j, b in members:
                    tree.insert((b['_head']+b['_tail'])*.5, j)
                tree.balance()
                trees.append((tree, min(24, len(members))))
        names = {b['name']: j for j, b in enumerate(right)}
        costs = []
        for a in left:
            candidates = set(range(len(right))) if trees is None else {
                j for tree, count in trees
                for _point, j, _distance in tree.find_n((a['_ref_head']+a['_ref_tail'])*.5, count)}
            if a['_flipped'] in names:
                candidates.add(names[a['_flipped']])
            row = [1.5]*len(right)
            for j in candidates:
                row[j] = _mirror_rest_pair_cost(a, right[j], normal, origin, scale)
            costs.append(row)
        # Solve independent sparse candidate components instead of a dense rig-wide cubic problem.
        edges = {i: {j for j, cost in enumerate(row) if cost < .85}
                 for i, row in enumerate(costs)}
        pending = {i for i, links in edges.items() if links}
        while pending:
            rows, columns = {min(pending)}, set()
            while True:
                new_columns = set().union(*(edges[i] for i in rows))
                new_rows = {i for i in pending if edges[i] & new_columns}
                if new_rows == rows and new_columns == columns:
                    break
                rows, columns = new_rows, new_columns
            pending -= rows
            ri, ci = sorted(rows), sorted(columns)
            matrix = [[costs[i][j] for j in ci]+[.85]*len(ri) for i in ri]
            for local_i, local_j in _mirror_assignment(matrix).items():
                if local_j >= len(ci):
                    continue
                i, j = ri[local_i], ci[local_j]
                cost = costs[i][j]
                if cost >= .85:
                    continue
                named = _pin_flipped_name(left[i]['name']) == right[j]['name']
                alternative_row = min((c for k, c in enumerate(costs[i]) if k != j), default=2.)
                alternative_col = min((row[j] for k, row in enumerate(costs) if k != i), default=2.)
                if not named and alternative_row-cost < .025 and alternative_col-cost < .025:
                    continue
                a, b = left[i]['name'], right[j]['name']
                mapping[a], mapping[b] = b, a
                confidence[a] = confidence[b] = max(0., 1.-cost/.85)
    by_name = {f['name']: f for f in features}
    for feature in features:
        name = feature['name']
        if name in mapping:
            continue
        other = _pin_flipped_name(name)
        if other != name and other in by_name and other not in mapping:
            a, b = Vector(feature['head']), Vector(by_name[other]['head'])
            if abs((a-origin).dot(normal)) <= epsilon and abs((b-origin).dot(normal)) <= epsilon:
                mapping[name], mapping[other] = other, name
                confidence[name] = confidence[other] = .5
        center = (Vector(feature['head'])+Vector(feature['tail']))*.5
        if name not in mapping and abs((center-origin).dot(normal)) <= epsilon:
            mapping[name], confidence[name] = name, 1.
    result = dict(mapping=mapping, confidence=confidence, plane=tuple(v for row in plane for v in row),
                  root=root.name if root else '', scale=scale)
    cache[key] = result
    if operation is not None:
        operation[pointer] = result
    while len(cache) > 8:
        cache.pop(next(iter(cache)))
    return result


def _mirror_counterpart_name(armature, name, allow_center=True):
    result = _mirror_rig_rest(armature)['mapping'].get(str(name), '')
    if not result and name and 'mirror_unmatched_bones' in _state:
        _state['mirror_unmatched_bones'].add((armature.name, str(name)))
    return result if allow_center or result != name else ''


def _mirror_rest_plane(armature):
    packed = _mirror_rig_rest(armature)['plane']
    return Matrix(tuple(tuple(packed[r*4+c] for c in range(4)) for r in range(4)))


def _mirror_basis_map(armature, source, target):
    plane = _mirror_rest_plane(armature).to_3x3()
    reflection = plane @ Matrix.Diagonal((-1., 1., 1.)) @ plane.transposed()
    transform = target.bone.matrix_local.to_3x3().normalized().transposed() @ reflection
    transform = transform @ source.bone.matrix_local.to_3x3().normalized()
    source_end, target_end = _mirror_chain_endpoints(armature, source, target)
    source_length = (source_end-source.bone.head_local).length
    ratio = (target_end-target.bone.head_local).length/source_length if source_length > 1.e-7 else 1.
    return transform, max(.1, min(10., ratio))


def _mirror_chain_endpoints(armature, source, target):
    """Allow a rigid segment to correspond to a short unmatched joint chain."""
    mapping = _mirror_rig_rest(armature)['mapping']
    def endpoint(one, other):
        result = one.bone.tail_local.copy()
        if other.children:
            return result
        current = one
        for _ in range(32):
            if len(current.children) != 1:
                break
            child = current.children[0]
            if mapping.get(child.name) not in {None, '', child.name}:
                break
            result, current = child.bone.tail_local.copy(), child
        return result
    return endpoint(source, target), endpoint(target, source)

def _mirror_pin_transform(armature, source_name, target_name, source_plane, destination_plane):
    source, target = armature.pose.bones.get(source_name), armature.pose.bones.get(target_name)
    if source is None or target is None:
        return destination_plane @ Matrix.Diagonal((-1., 1., 1., 1.)) @ source_plane.inverted_safe()
    rest_plane = _mirror_rest_plane(armature)
    source_end, target_end = _mirror_chain_endpoints(armature, source, target)
    inverse = rest_plane.inverted_safe()
    s, t = inverse @ source.bone.head_local, inverse @ target.bone.head_local
    source_ray, target_ray = inverse @ source_end-s, inverse @ target_end-t
    source_length = source_ray.length
    ratio = max(.1, min(10., target_ray.length/source_length)) if source_length > 1.e-7 else 1.
    direction = source_ray.normalized() if source_length > 1.e-7 else Vector((0., 1., 0.))
    reflected = Matrix.Diagonal((-1., 1., 1.))
    swing = ((reflected @ direction).rotation_difference(target_ray.normalized()).to_matrix()
             if target_ray.length > 1.e-7 else Matrix.Identity(3))
    stretch = Matrix.Identity(3)
    for i in range(3):
        for j in range(3):
            stretch[i][j] += (ratio-1.)*direction[i]*direction[j]
    linear = swing @ reflected @ stretch
    local = linear.to_4x4()
    local.translation = t-linear @ s
    return destination_plane @ local @ source_plane.inverted_safe()


def _mirror_visual_pose(armature, source_name, target_name, source_plane, destination_plane, source_world):
    source, target = armature.pose.bones[source_name], armature.pose.bones[target_name]
    rest = _mirror_rest_plane(armature).inverted_safe()
    s, t = rest @ source.bone.matrix_local, rest @ target.bone.matrix_local
    pose = source_plane.inverted_safe() @ source_world
    flip = Matrix.Diagonal((-1., 1., 1.))
    rotation = flip @ pose.to_quaternion().to_matrix() @ s.to_quaternion().to_matrix().transposed() @ flip @ t.to_quaternion().to_matrix()
    translation = t.translation + flip @ (pose.translation-s.translation)
    return destination_plane @ Matrix.LocRotScale(translation, rotation.to_quaternion(), pose.to_scale())
