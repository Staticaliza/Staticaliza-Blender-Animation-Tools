"""Gyro geometry uses Contact's Smart anchors and exact offset-ray aim solve."""

from ..core.runtime import *  # noqa: F403


def _gyro_raw_world(armature, bone, basis=None):
    return armature.convert_space(pose_bone=bone,
        matrix=bone.matrix_basis if basis is None else basis,
        from_space="LOCAL", to_space="WORLD")


def _gyro_geometry(context, armature, bone, mode, axis):
    evaluated, evaluated_bone, part, points, supports = _surface_contact_part_geometry(
        context, armature, bone)
    world = armature.matrix_world @ bone.matrix
    anchor = world @ Vector((0, bone.length * .5, 0))
    direction = world.to_quaternion() @ _gyro_axis(axis)
    if evaluated_bone is not None and points:
        point, object_name, _local = _surface_contact_creation_anchor(
            context, context.evaluated_depsgraph_get(), armature, evaluated,
            evaluated_bone, part, points, supports, pin_mode=mode, pin_axis=axis)
        if point is not None:
            anchor = point
        smart = bpy.data.objects.get(object_name)
        if smart is not None:
            direction = smart.evaluated_get(context.evaluated_depsgraph_get()).matrix_world.to_3x3() @ _gyro_axis(axis)
    elif mode == "MODE_4":
        anchor = world.translation.copy()
    elif mode == "MODE_1":
        anchor = world @ Vector((0, bone.length, 0))
    return world.inverted_safe() @ anchor, world.to_quaternion().inverted() @ direction.normalized()


def _gyro_aim_rotation(guide, pivot, rotation, target):
    """Shared directional solve for the viewport and kinematic collision samples."""
    rotation = Quaternion(rotation).normalized()
    anchor = pivot + rotation @ Vector(guide.get("gyro_anchor", (0, 0, 0)))
    axis = rotation @ Vector(guide.get("gyro_local_axis", _gyro_axis(str(guide.get("gyro_axis", "Z_NEG")))))
    if axis.length_squared < 1.e-12 or (target - pivot).length_squared < 1.e-12:
        return rotation
    if (target-anchor).length <= PIN_SNAP_WORLD_RADIUS:
        return rotation
    pair = _surface_contact_smart_aim_vectors(pivot, anchor, target, axis)
    source, destination = pair if pair is not None else (axis.normalized(), (target-anchor).normalized())
    return source.rotation_difference(destination) @ rotation


def _gyro_update_aim(context, guide):
    """Evaluate a pose from authored inputs; never insert keys or edit a bone."""
    armature, bone = _gyro_owner(guide)
    reference, output = guide.get("gyro_reference"), guide.get("gyro_aim_output")
    if bone is None or reference is None or output is None:
        return False
    # Relationship constraints establish the input pose. Gyro changes only its
    # final rotation, after both Parent and Unparent have evaluated.
    names = [str(guide.get(key, "")) for key in ("gyro_stable_constraint", "gyro_aim_constraint")]
    if [c.name for c in bone.constraints][-2:] != names:
        for name in names:
            index = bone.constraints.find(name)
            if index >= 0:
                bone.constraints.move(index, len(bone.constraints)-1)
    masked = _gyro_sync_constraint_mask(context, guide)
    if not _gyro_active(context, guide):
        return masked
    pivot = (armature.matrix_world @ bone.matrix).translation
    rotation = reference.rotation_quaternion.copy()
    target = guide.location.copy()
    if (not _pin_active_transform_operator(context) and not _state.get('constraint_creation_transaction')
            and any(_constraint_bone_ragdoll_override(armature,b,context.scene.frame_current)
                    for b in armature.pose.bones)):
        frame=float(context.scene.frame_current)+context.scene.frame_subframe
        pivot=(armature.matrix_world@_surface_contact_release_bone_matrix(armature,bone,frame,{})).translation
        curves={(fc.data_path,fc.array_index):fc for fc in _action_fcurves(_ragdoll_action(armature),armature)}
        def keyed(prop,default):
            path=bone.path_from_id(f'["{prop}"]')
            return tuple(float(curves[(path,i)].evaluate(frame)) if (path,i) in curves else float(v)
                         for i,v in enumerate(bone.get(prop,default)))
        rotation=Quaternion(keyed(GYRO_TILT_PROPERTY,rotation)).normalized()
        target=Vector(keyed(GYRO_TARGET_PROPERTY,target))
    desired = _gyro_aim_rotation(guide, pivot, rotation, target).normalized()
    # Quaternions q and -q describe the same rotation. Preserve the nearest
    # sign without copying the previous helper's accumulated magnitude error.
    if desired.dot(output.rotation_quaternion) < 0.0:
        desired.negate()
    if sum((a-b)**2 for a, b in zip(desired, output.rotation_quaternion)) < 1.e-12:
        return masked
    output.rotation_quaternion = desired
    return True


def _gyro_sync_constraint_mask(context, guide):
    _armature, bone = _gyro_owner(guide)
    if bone is None:
        return False
    disabled = not _gyro_active(context, guide)
    changed = False
    if not _gyro_authored_active(context, guide):
        # Blender's generic constraint flag includes muted/zero-weight entries.
        # Outside the authored interval there is no Gyro output to evaluate;
        # retaining these derived constraints turns DEFAULT bones green.
        for key in ("gyro_stable_constraint", "gyro_aim_constraint"):
            constraint = bone.constraints.get(str(guide.get(key, "")))
            if constraint is not None:
                constraint.driver_remove("influence")
                bone.constraints.remove(constraint)
                changed = True
        return changed
    if not guide.get("gyro_discrete_influence", False):
        for key in ("gyro_stable_constraint", "gyro_aim_constraint"):
            constraint = bone.constraints.get(str(guide.get(key, "")))
            if constraint is not None:
                _gyro_constraint_driver(constraint, bone.id_data, bone)
                changed = True
        guide["gyro_discrete_influence"] = True
    for key, target_key in (("gyro_stable_constraint", "gyro_reference"),
                            ("gyro_aim_constraint", "gyro_aim_output")):
        if not guide.get(key):continue
        constraint = bone.constraints.get(str(guide.get(key, "")))
        if constraint is None:
            constraint = bone.constraints.new("COPY_ROTATION")
            constraint.name = str(guide.get(key, "")) or f"Gyro {key} {bone.name}"
            constraint.target = guide.get(target_key)
            constraint.owner_space = constraint.target_space = "WORLD"
            guide[key] = constraint.name
            _gyro_constraint_driver(constraint, bone.id_data, bone)
            changed = True
        if constraint is not None and constraint.mute!=disabled:
            constraint.mute = disabled
            changed = True
    return changed


def _gyro_upgrade(context, guide):
    """Upgrade saved Gyro pins without authoring additional timeline keys."""
    if guide.get("gyro_distance") != 10.0:
        guide["gyro_distance"] = 10.0
    armature, bone = _gyro_owner(guide)
    if bone is None:
        return
    _gyro_sync_start_frame(armature, bone)
    if guide.get("gyro_aim_output") is not None:
        return
    output = bpy.data.objects.new(f"Gyro Aim {bone.name}", None)
    (guide.users_collection[0] if guide.users_collection else context.scene.collection).objects.link(output)
    output.empty_display_size = 0
    output.hide_select = output.hide_render = True
    output.rotation_mode = "QUATERNION"
    output["gyro_armature"], output["gyro_bone"] = armature, bone.name
    guide["gyro_aim_output"] = output
    _anchor, axis = _gyro_geometry(context, armature, bone,
        str(guide.get("gyro_position", "MODE_3")), str(guide.get("gyro_axis", "Z_NEG")))
    guide["gyro_local_axis"] = tuple(axis)
    name = str(guide.get("gyro_aim_constraint", ""))
    previous = bone.constraints.get(name)
    if previous is not None:
        previous.driver_remove("influence")
        bone.constraints.remove(previous)
    constraint = bone.constraints.new("COPY_ROTATION")
    constraint.name = name or f"Gyro Aim {bone.name}"
    constraint.owner_space = constraint.target_space = "WORLD"
    constraint.target = output
    guide["gyro_aim_constraint"] = constraint.name
    for key in ("gyro_stable_constraint", "gyro_aim_constraint"):
        constraint = bone.constraints.get(str(guide.get(key, "")))
        if constraint is not None:
            constraint.driver_remove("influence")
            _gyro_constraint_driver(constraint, armature, bone)
    guide["gyro_initial_target"] = tuple(guide.location)
    guide["gyro_initial_tilt"] = tuple(guide["gyro_reference"].rotation_quaternion)


def _gyro_update_aims(context):
    read_scope=_special_read_begin()
    marker_index=_state.get('ragdoll_marker_curve_indexes')
    channel_index=_state.get('ragdoll_native_channel_indexes')
    if marker_index is None:_state['ragdoll_marker_curve_indexes']={}
    if channel_index is None:_state['ragdoll_native_channel_indexes']={}
    try:
        return _gyro_update_aims_impl(context)
    finally:
        _special_read_end(read_scope)
        if marker_index is None:_state.pop('ragdoll_marker_curve_indexes',None)
        if channel_index is None:_state.pop('ragdoll_native_channel_indexes',None)


def _gyro_update_aims_impl(context):
    return any(tuple(_gyro_update_aim(context, guide) for guide in _gyro_guides(context.scene)))


def _gyro_transform_snapshot(context, guide, basis=None, world=None):
    armature, bone = _gyro_owner(guide)
    basis = (bone.matrix_basis if basis is None else basis).copy()
    world = _gyro_raw_world(armature, bone, basis) if world is None else world
    return {"basis": basis, "world": world.copy(), "pivot": world.translation.copy(),
            "aim_rotation": guide["gyro_aim_output"].rotation_quaternion.normalized(),
            "reference": guide["gyro_reference"].matrix_world.copy(),
            "target": guide.matrix_world.copy(), "frame": context.scene.frame_current,
            "last_basis": tuple(round(v, 8) for row in basis for v in row)}


def _gyro_reset_selected_target(context, mode):
    guide = _gyro_selected_target(context)
    if guide is None:
        return False
    armature, bone = _gyro_owner(guide)
    frame = int(context.scene.frame_current)
    start_edit = (_ragdoll_active(bone, frame)
                  and _ragdoll_active_start_frame(armature, bone, frame) == frame)
    previous = bool(_state.get('ragdoll_syncing'))
    if start_edit:
        _state['ragdoll_syncing'] = True
    try:
        snapshots = {guide.name: _gyro_transform_snapshot(context, guide)}
        snapshots[guide.name]["pivot"] = (armature.matrix_world @ bone.matrix).translation.copy()
        if mode == "LOCATION":
            bone.location = (0, 0, 0)
        elif mode == "ROTATION":
            if bone.rotation_mode == "QUATERNION":
                bone.rotation_quaternion = Quaternion()
            elif bone.rotation_mode == "AXIS_ANGLE":
                bone.rotation_axis_angle = (0, 0, 1, 0)
            else:
                bone.rotation_euler = (0, 0, 0)
        else:
            bone.scale = (1, 1, 1)
        _gyro_reset_finish(context, snapshots, mode)
        path = "location" if mode == "LOCATION" else "scale" if mode == "SCALE" else (
            "rotation_quaternion" if bone.rotation_mode == "QUATERNION" else
            "rotation_axis_angle" if bone.rotation_mode == "AXIS_ANGLE" else "rotation_euler")
        bone.keyframe_insert(data_path=path, frame=context.scene.frame_current, group=bone.name)
        if start_edit:
            _ragdoll_capture_start_edits(context, contact_bone=bone)
        _tag_redraw_all_view3d()
        return True
    finally:
        _state['ragdoll_syncing'] = previous


def _gyro_reset_capture(context, grouped):
    snapshots = {guide.name: _gyro_transform_snapshot(context, guide)
            for armature, bones in grouped.items() for bone in bones
            if (guide := _gyro_find(context, armature, bone)) is not None
            and _gyro_active(context, guide)}
    for name, snapshot in snapshots.items():
        armature, bone = _gyro_owner(bpy.data.objects[name])
        snapshot["pivot"] = (armature.matrix_world @ bone.matrix).translation.copy()
    return snapshots


def _gyro_reset_finish(context, snapshots, mode):
    previous = _state.get("gyro_syncing", False)
    _state["gyro_syncing"] = True
    try:
        bases = _gyro_capture_pose_bases(context)
        # Evaluate Blender's cleared pose through Parent/Unparent, without the
        # two Gyro rotations concealing it. Preserve the just-cleared channels
        # across Action refreshes before reading that evaluated world pose.
        for name in snapshots:
            guide = bpy.data.objects.get(name)
            if guide is not None:
                armature, bone = _gyro_owner(guide)
                for key in ("gyro_stable_constraint", "gyro_aim_constraint"):
                    constraint = bone.constraints.get(str(guide.get(key, "")))
                    if constraint is not None:
                        constraint.mute = True
        _gyro_restore_pose_bases(context, bases)
        desired = {}
        for name in snapshots:
            guide = bpy.data.objects.get(name)
            if guide is not None:
                armature, bone = _gyro_owner(guide)
                evaluated = armature.evaluated_get(context.evaluated_depsgraph_get())
                desired[name] = evaluated.matrix_world @ evaluated.pose.bones[bone.name].matrix
        for name, snapshot in snapshots.items():
            guide = bpy.data.objects.get(name)
            if guide is None:
                continue
            _gyro_preview_drivers(guide, True)
            reference = guide["gyro_reference"]
            old_rotation = snapshot["aim_rotation"].normalized()
            rotation = desired[name].to_quaternion() if mode == "ROTATION" else old_rotation
            pivot = desired[name].translation
            delta = rotation @ old_rotation.inverted()
            reference.rotation_quaternion = (delta @ snapshot["reference"].to_quaternion()).normalized()
            guide.location = pivot + delta @ (snapshot["target"].translation - snapshot["pivot"])
            _gyro_key_transform(guide, context.scene.frame_current)
            _gyro_key_transform(reference, context.scene.frame_current)
            _gyro_preview_drivers(guide, False)
            _gyro_clear_preview(guide)
            _gyro_sync_constraint_mask(context, guide)
            _gyro_update_aim(context, guide)
        _gyro_restore_pose_bases(context, bases)
        _gyro_seed_baselines(context)
    finally:
        _state["gyro_syncing"] = previous


def _gyro_target_orientation(context, guide):
    armature, bone = _gyro_owner(guide)
    return _pin_transform_orientation_matrix(context,
        ("YELLOW", armature, bone, (tuple(guide.location), (0, 0, 0, 1))))


def _gyro_begin_target_transform(operator, context, guide, event):
    operator.initial_tilt = tuple(guide["gyro_reference"].rotation_quaternion)
    armature, bone = _gyro_owner(guide)
    operator.pivot = (armature.matrix_world @ bone.matrix).translation.copy()
    operator.orientation = _gyro_target_orientation(context, guide)
    operator.axis_index = operator.plane_axis_index = -1
    operator.initial_pin_matrix = guide.matrix_world.copy()
    operator.target_kind = "GYRO"
    operator.contact_guide_name = ""
    operator.mouse_started_at_pivot = False
    _gyro_preview_drivers(guide, True)


def _gyro_target_at_mouse(context, mouse):
    """Match the visible endpoint using the shared pin hit radius."""
    nearest, distance = None, PIN_GIZMO_CENTER_HIT_RADIUS ** 2
    for guide in _gyro_visible(context):
        if not _pin_gizmo_center_in_front(context, guide.location):
            continue
        point = view3d_utils.location_3d_to_region_2d(context.region, context.region_data, guide.location)
        if point is not None:
            delta = (Vector(point) - Vector(mouse)).length_squared
            if delta <= distance:
                nearest, distance = guide, delta
    return nearest


def _gyro_target_draw_matrix(gizmo):
    """Keep the visible/hittable shape on its endpoint during native G/R.

    draw_prepare retains the gizmo map while Blender owns a modal transform.
    Override only the drawing matrix, preserving native pixel scale and the
    active C-side gizmo; rebuilding or rebinding the map would lose clicks.
    """
    guide = bpy.data.objects.get(gizmo.guide_name)
    if guide is None:
        return None
    matrix = gizmo.matrix_world.copy()
    matrix.translation = guide.location
    return matrix


def _gyro_apply_target_transform(operator, context, guide, event):
    if operator.transform_mode == "TRANSLATE" and operator.axis_index < 0 and operator.plane_axis_index < 0:
        guide.location = _gyro_mouse_target(context, guide,
            (event.mouse_region_x, event.mouse_region_y))
    else:
        delta = _pin_transform_mouse_matrix(operator, context, event)
        if operator.transform_mode == "ROTATE":
            guide.location = operator.pivot + delta.to_quaternion() @ (Vector(operator.initial) - operator.pivot)
            guide["gyro_reference"].rotation_quaternion = delta.to_quaternion() @ Quaternion(operator.initial_tilt)
        else:
            guide.location = Vector(operator.initial) + delta.translation
    _gyro_update_aim(context, guide)


def _pin_gyro_apply_matrix(context, guide, matrix, update=True):
    changed = (guide.location - matrix.translation).length > 1.e-8
    _gyro_preview_drivers(guide, True)
    guide.location = matrix.translation
    _gyro_update_aim(context, guide)
    if update:
        context.view_layer.update()
        _armature, bone = _gyro_owner(guide)
        if bone is not None:
            _ragdoll_capture_start_edits(context, contact_bone=bone)
    return changed


def _pin_gyro_restore_matrix(context, guide, matrix):
    _pin_gyro_apply_matrix(context, guide, matrix)


def _pin_gyro_commit_targets(context, guides):
    if not guides:
        return
    bases = _gyro_capture_pose_bases(context)
    previous = _state.get("gyro_syncing", False)
    _state["gyro_syncing"] = True
    try:
        for guide in guides:
            _gyro_key_transform(guide, context.scene.frame_current)
            _gyro_preview_drivers(guide, False)
        _gyro_restore_pose_bases(context, bases)
        _gyro_update_aims(context)
        context.view_layer.update()
        for guide in guides:
            _armature, bone = _gyro_owner(guide)
            if bone is not None:
                _ragdoll_capture_start_edits(context, contact_bone=bone)
                _ragdoll_commit_start_transition(context, (bone,))
    finally:
        _state["gyro_syncing"] = previous
    _gyro_seed_baselines(context)
