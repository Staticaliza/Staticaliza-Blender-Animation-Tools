"""Pin click-away and post-history visibility behavior."""

from ..core.runtime import *  # noqa: F403


def _pin_point_inside_region(region, x, y):
    return bool(
        int(getattr(region, "width", 0)) > 1
        and int(getattr(region, "height", 0)) > 1
        and int(getattr(region, "x", 0)) <= int(x)
        < int(getattr(region, "x", 0)) + int(region.width)
        and int(getattr(region, "y", 0)) <= int(y)
        < int(getattr(region, "y", 0)) + int(region.height)
    )


def _pin_point_over_view3d_ui(area, x, y):
    """Keep toolbar/sidebar clicks out of virtual-pin deselection."""
    return any(
        region.type != "WINDOW" and _pin_point_inside_region(region, x, y)
        for region in getattr(area, "regions", ())
    )


def _pin_workspace_tool_id(context):
    try:
        tool = context.workspace.tools.from_space_view3d_mode(
            "POSE",
            create=False,
        )
        return str(getattr(tool, "idname", ""))
    except (AttributeError, RuntimeError, TypeError):
        return ""


def _pin_pointer_over_view3d_window():
    """Return whether the physical pointer is over a 3D viewport WINDOW.

    Timers normally have no area/region context. On Windows, translate the
    physical cursor into Blender client coordinates and resolve it against
    Blender's own screen regions. False deliberately covers toolbars, sidebars,
    headers, and other editors so changing tools never clears a virtual pin.
    """
    if os.name != "nt":
        return None
    try:
        import ctypes
        from ctypes import wintypes

        user32 = ctypes.windll.user32
        hwnd = user32.GetForegroundWindow()
        if not hwnd:
            return None
        process_id = wintypes.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(process_id))
        if int(process_id.value) != int(os.getpid()):
            return False
        point = wintypes.POINT()
        if not user32.GetCursorPos(ctypes.byref(point)):
            return None
        if not user32.ScreenToClient(hwnd, ctypes.byref(point)):
            return None
        client_rect = wintypes.RECT()
        if not user32.GetClientRect(hwnd, ctypes.byref(client_rect)):
            return None
        client_width = int(client_rect.right - client_rect.left)
        client_height = int(client_rect.bottom - client_rect.top)
        cursor_x = int(point.x)
        cursor_y = client_height - 1 - int(point.y)
    except (AttributeError, OSError, TypeError, ValueError):
        return None

    windows = tuple(getattr(bpy.context.window_manager, "windows", ()))
    size_matches = [
        window
        for window in windows
        if abs(int(getattr(window, "width", 0)) - client_width) <= 2
        and abs(int(getattr(window, "height", 0)) - client_height) <= 2
    ]
    candidates = size_matches or windows
    for window in candidates:
        screen = getattr(window, "screen", None)
        for area in getattr(screen, "areas", ()):
            for region in getattr(area, "regions", ()):
                if not _pin_point_inside_region(region, cursor_x, cursor_y):
                    continue
                return bool(
                    getattr(area, "type", "") == "VIEW_3D"
                    and getattr(region, "type", "") == "WINDOW"
                )
    return False


def _pin_reset_pointer_tool_state():
    _state["pin_pointer_was_pressed"] = False
    _state["pin_pointer_pressed_tool_id"] = ""
    _state["pin_workspace_tool_id"] = ""
    _state["pin_pointer_pending_click"] = None


def _pin_pointer_selection_active():
    return bool(
        _pin_selected_target_key()
        or int(_state.get("smart_dragger_selected_side", -1)) in (0, 1)
    )


def _pin_pointer_pose_matrix_signature(context):
    """Snapshot selected bones without changing Blender's selection state."""
    signature = []
    try:
        grouped = _selected_pose_bones_by_owner(context)
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        grouped = {}
    for owner, pose_bones in grouped.items():
        try:
            owner_key = int(owner.as_pointer())
        except (AttributeError, ReferenceError, RuntimeError, TypeError):
            owner_key = str(getattr(owner, "name_full", getattr(owner, "name", "")))
        for pose_bone in pose_bones:
            try:
                matrix = tuple(
                    round(float(value), 9)
                    for row in pose_bone.matrix_basis
                    for value in row
                )
            except (AttributeError, ReferenceError, RuntimeError, TypeError):
                matrix = ()
            signature.append(
                (owner_key, str(getattr(pose_bone, "name", "")), matrix)
            )
    return tuple(sorted(signature, key=lambda item: (str(item[0]), item[1])))


def _pin_pointer_transform_active(context):
    return bool(
        _pin_active_transform_operator(context)
        or _state.get("pin_target_dragging", False)
        or _state.get("pin_keyboard_transform_active", False)
        or _state.get("pin_snap_transform_active", False)
        or _state.get("smart_dragger_transform_active", False)
    )


def _pin_clear_virtual_selection():
    changed = False
    if _pin_selected_target_key():
        changed = bool(_pin_deselect_target()) or changed
    if int(_state.get("smart_dragger_selected_side", -1)) in (0, 1):
        _state["smart_dragger_selected_side"] = -1
        _state["smart_dragger_owner"] = None
        _state["smart_dragger_cache"] = {}
        _state["smart_dragger_selection_keys"] = ()
        _state["smart_dragger_extend_selection_until"] = 0.0
        changed = True
    if changed:
        _tag_redraw_all_view3d()
    return changed


def _pin_pointer_click_away_timer():
    """Observe a full click without installing a competing mouse keymap.

    Blender's active selection tool can consume CLICK and RELEASE keymap
    events. Polling the physical button leaves native gizmo hit-testing alone
    while still giving virtual pins reliable single-click empty-space
    deselection.
    """
    context = bpy.context
    pressed = bool(_pin_primary_mouse_pressed())
    was_pressed = bool(_state.get("pin_pointer_was_pressed", False))
    tool_id = _pin_workspace_tool_id(context)

    if not pressed and not was_pressed:
        # Keep this cache current between interactions. A toolbar click can
        # then be distinguished from the first viewport click after a tool
        # change, avoiding the old two-click deselection behavior.
        _state["pin_workspace_tool_id"] = tool_id
        if _pin_pointer_selection_active():
            return 0.01
        return 0.02 if _pin_pose_selection_history_enabled(context) else 0.1

    if pressed and not was_pressed:
        previous_tool = str(_state.get("pin_workspace_tool_id", ""))
        explicit_viewport = _pin_pointer_over_view3d_window()
        _state["pin_pointer_was_pressed"] = True
        _state["pin_pointer_pressed_tool_id"] = tool_id
        _state["pin_pointer_pending_click"] = {
            "key": str(_pin_selected_target_key() or ""),
            "epoch": int(_state.get("pin_gizmo_selection_epoch", 0)),
            "claim_serial": int(_state.get("pin_gizmo_claim_serial", 0)),
            "smart_side": int(
                _state.get("smart_dragger_selected_side", -1)
            ),
            "smart_owner": _state.get("smart_dragger_owner"),
            "pose_matrices": _pin_pointer_pose_matrix_signature(context),
            "pose_selection": _pin_pose_selection_signature(context),
            "track_pose_history": _pin_pose_selection_history_enabled(
                context
            ),
            "tool_changed": bool(
                previous_tool and tool_id and previous_tool != tool_id
            ),
            "explicit_viewport": explicit_viewport,
            "transform_seen": _pin_pointer_transform_active(context),
            "shift_pressed": _pin_shift_modifier_pressed(),
        }
        _state["pin_workspace_tool_id"] = tool_id
        return 0.01

    pending = _state.get("pin_pointer_pending_click")
    if pressed:
        if pending is not None and _pin_pointer_transform_active(context):
            pending["transform_seen"] = True
        return 0.01

    _state["pin_pointer_was_pressed"] = False
    _state["pin_pointer_pressed_tool_id"] = ""
    _state["pin_pointer_pending_click"] = None
    _state["pin_workspace_tool_id"] = tool_id
    if (
        pending
        and bool(pending.get("track_pose_history", False))
        and pending.get("explicit_viewport") is True
        and not pending.get("tool_changed", False)
        and not pending.get("transform_seen", False)
    ):
        _pin_pose_selection_history_checkpoint(
            context,
            pending.get("pose_selection"),
            _pin_pose_selection_signature(context),
        )
    if not pending or not _pin_pointer_selection_active():
        if _pin_pointer_selection_active():
            return 0.01
        return 0.02 if _pin_pose_selection_history_enabled(context) else 0.1

    preserve = bool(
        pending.get("shift_pressed", False)
        or time.perf_counter() < float(
            _state.get("smart_dragger_preserve_until", 0.0)
        )
        or pending.get("explicit_viewport") is False
        or pending.get("tool_changed", False)
        or pending.get("transform_seen", False)
        or str(_pin_selected_target_key() or "") != pending.get("key", "")
        or int(_state.get("pin_gizmo_selection_epoch", 0))
        != int(pending.get("epoch", 0))
        or int(_state.get("pin_gizmo_claim_serial", 0))
        != int(pending.get("claim_serial", 0))
        or int(_state.get("smart_dragger_selected_side", -1))
        != int(pending.get("smart_side", -1))
        or _state.get("smart_dragger_owner") != pending.get("smart_owner")
        or _pin_pointer_pose_matrix_signature(context)
        != pending.get("pose_matrices")
    )
    if not preserve:
        _pin_clear_virtual_selection()
    return 0.01 if _pin_pointer_selection_active() else 0.1


def _clear_pin_history_visibility():
    context = bpy.context
    selection_only = bool(
        _state.pop("pin_history_selection_only", False)
        or _state.get("pin_history_selection_only_step", False)
    )
    if (
        _pin_primary_mouse_pressed()
        or _window_manager_has_modal_operator(context)
    ):
        # Undo/redo schedules this callback 100 ms after its synchronous
        # handlers finish. A new native gizmo press can therefore already be
        # in flight when the callback runs, before Blender has necessarily
        # published gizmo_tweak in window.modal_operators. Changing pose
        # selection or tagging a redraw in that press-to-modal gap invalidates
        # Blender's highlighted C gizmo and lets the active Select Box tool
        # receive the drag. The new interaction supersedes the temporary
        # history lock, but all selection/gizmo-map work must wait for release.
        # "Any modal operator" is not proof that a new transform owns the
        # pose. Blender can retain a transient modal UI owner while rapid
        # Undo/Redo is settling; clearing here intermittently exposed the raw
        # Action pose before the late dependency evaluation. End the history
        # visibility phase but keep its exact Contact lock. The native/custom
        # transform detector clears it synchronously when a real G/R/S begins.
        _state["pin_history_active"] = False
        _surface_contact_begin_history_pose_release(
            context,
            minimum_duration=0.35 if selection_only else 0.04,
            deadline_duration=0.80 if selection_only else 0.60,
            require_update=True,
        )
        _state["pin_history_selection_only_step"] = False
        return None
    try:
        _yellow_sync_targets_from_properties(context)
    except (AttributeError, ReferenceError, RuntimeError, TypeError, ValueError):
        pass
    # Undo and redo are allowed to restore Blender's pose selection without
    # treating that history-owned change as a click away from the virtual pin.
    # Native Gizmo undo is pushed before our post-modal selection timer runs,
    # so re-apply pin-only selection when that was the saved runtime state.
    selected_key = _pin_selected_target_key()
    saved_signature = _state.get("pin_gizmo_selection_keys", ())
    exclusive_pin = bool(
        selected_key
        and len(saved_signature) >= 2
        and not tuple(saved_signature[1])
    )
    if exclusive_pin and context is not None:
        target_data = _pin_available_target_data(context).get(selected_key)
        if target_data is not None:
            _pin_deselect_pose_bones(context)
    if selected_key:
        _state["pin_gizmo_selection_keys"] = _pin_pose_selection_signature(
            context
        )
    _state["pin_history_active"] = False
    _surface_contact_begin_history_pose_release(
        context,
        minimum_duration=0.35 if selection_only else 0.04,
        deadline_duration=0.80 if selection_only else 0.60,
        # Native Undo/Redo can publish one final Action/dependency evaluation
        # after the post handler and the first stable timer samples. Releasing
        # a transform lock before observing that update lets the keyed/natural
        # pose replace the exact Contact side a few milliseconds later.
        require_update=True,
    )
    _state["pin_history_selection_only_step"] = False
    if context is not None and _pin_gizmo_track_selection(context):
        _tag_redraw_all_view3d()
    return None


def _schedule_pin_history_visibility_clear():
    if bpy.app.timers.is_registered(_clear_pin_history_visibility):
        bpy.app.timers.unregister(_clear_pin_history_visibility)
    try:
        register_owned_timer(
            _clear_pin_history_visibility,
            first_interval = 0.0,
        )
    except (RuntimeError, ValueError):
        _state["pin_history_active"] = False


def _pin_click_away_timer():
    pending = _state.get("pin_gizmo_pending_click")
    if not pending:
        return None
    if isinstance(pending, (tuple, list)):
        # Accept the compact snapshot used by older live sessions/tests while
        # an extension update is replacing runtime state in place.
        pending = {
            "key": pending[0] if len(pending) > 0 else "",
            "epoch": pending[1] if len(pending) > 1 else 0,
            "claim_serial": pending[2] if len(pending) > 2 else 0,
            "pose_selection": None,
            "smart_side": -1,
            "smart_owner": None,
        }
    if (
        _state.get("pin_history_active", False)
        or _pin_primary_mouse_pressed()
        or _window_manager_has_modal_operator(bpy.context)
    ):
        return 0.05
    if time.perf_counter() < float(
        _state.get("smart_dragger_preserve_until", 0.0)
    ):
        _state["pin_gizmo_pending_click"] = None
        return None
    _state["pin_gizmo_pending_click"] = None
    if (
        _state.get("pin_target_dragging", False)
        or _state.get("pin_keyboard_transform_active", False)
    ):
        return None
    key = str(pending.get("key", ""))
    epoch = int(pending.get("epoch", 0))
    claim_serial = int(pending.get("claim_serial", 0))
    current_pose_selection = _pin_pose_selection_signature(bpy.context)
    previous_pose_selection = pending.get("pose_selection")
    if current_pose_selection == previous_pose_selection:
        # A native move/rotate gizmo release keeps the same selection. Only a
        # real viewport click-away changes Blender's pose selection.
        return None
    if bool(pending.get("track_pose_history", False)):
        _pin_pose_selection_history_checkpoint(
            bpy.context,
            previous_pose_selection,
            current_pose_selection,
        )
    if (
        str(_state.get("pin_gizmo_selected_key", "")) == str(key)
        and int(_state.get("pin_gizmo_selection_epoch", 0)) == int(epoch)
        and int(_state.get("pin_gizmo_claim_serial", 0)) == int(claim_serial)
    ):
        _pin_deselect_target()
    if (
        int(_state.get("smart_dragger_selected_side", -1))
        == int(pending.get("smart_side", -1))
        and _state.get("smart_dragger_owner")
        == pending.get("smart_owner")
    ):
        _state["smart_dragger_selected_side"] = -1
        _state["smart_dragger_owner"] = None
        _state["smart_dragger_cache"] = {}
        _state["smart_dragger_selection_keys"] = ()
        _state["smart_dragger_extend_selection_until"] = 0.0
        _tag_redraw_all_view3d()
    return None


def _pin_pose_selection_history_enabled(context):
    """Limit native selection checkpoints to scenes that own Contact pins."""
    scene = getattr(context, "scene", None) if context is not None else None
    return bool(
        scene is not None
        and getattr(context, "mode", "") == "POSE"
        and tuple(_surface_contact_active_simulated_guides(scene))
    )


def _pin_pose_selection_history_checkpoint(
    context,
    previous_signature,
    current_signature,
):
    """Observe one native pose-selection step without adding another one."""
    checkpoint_pair = (previous_signature, current_signature)
    if (
        context is None
        or previous_signature is None
        or previous_signature == current_signature
        or not _pin_pose_selection_history_enabled(context)
        or _state.get("pin_history_active", False)
        or _state.get("pin_history_syncing", False)
        or _state.get("pin_snap_transform_active", False)
        or _state.get("pin_keyboard_transform_active", False)
        or _state.get("pin_target_dragging", False)
        or _state.get("pin_pose_selection_checkpoint_active", False)
        or (
            checkpoint_pair
            == _state.get("pin_pose_selection_checkpoint_pair")
            and time.perf_counter()
            < float(_state.get(
                "pin_pose_selection_checkpoint_guard_until",
                0.0,
            ))
        )
    ):
        return False
    _state["pin_pose_selection_checkpoint_active"] = True
    try:
        # Blender's Pose select operator already owns this checkpoint. An
        # explicit undo_push (or undoable Scene marker) after mouse-up records
        # the same settled selection twice, producing one blank Ctrl+Z. Keep
        # only this runtime de-duplication guard and let undo_post classify
        # Blender's existing checkpoint as selection-only.
        _state["pin_pose_selection_checkpoint_pair"] = checkpoint_pair
        _state["pin_pose_selection_checkpoint_guard_until"] = (
            time.perf_counter() + 0.1
        )
        return True
    except (AttributeError, RuntimeError, TypeError, ValueError):
        return False
    finally:
        _state["pin_pose_selection_checkpoint_active"] = False


def _pin_schedule_click_away(context, selected_key):
    _state["pin_gizmo_pending_click"] = {
        "key": str(selected_key or ""),
        "epoch": int(_state.get("pin_gizmo_selection_epoch", 0)),
        "claim_serial": int(_state.get("pin_gizmo_claim_serial", 0)),
        "pose_selection": _pin_pose_selection_signature(context),
        "track_pose_history": _pin_pose_selection_history_enabled(context),
        "smart_side": int(
            _state.get("smart_dragger_selected_side", -1)
        ),
        "smart_owner": _state.get("smart_dragger_owner"),
    }
    try:
        if bpy.app.timers.is_registered(_pin_click_away_timer):
            bpy.app.timers.unregister(_pin_click_away_timer)
    except (ReferenceError, RuntimeError, ValueError):
        pass
    register_owned_timer(_pin_click_away_timer, first_interval=0.01)


class ANIMATOR_UTILS_OT_pin_click_away(bpy.types.Operator):
    bl_idname = "staticaliza.pin_click_away"
    bl_label = "Select or Deselect Pin"
    bl_description = "Resolve pin selection after Blender's normal click action"
    bl_options = {"INTERNAL"}

    @classmethod
    def poll(cls, context):
        return (
            getattr(getattr(context, "area", None), "type", "") == "VIEW_3D"
            and getattr(getattr(context, "region", None), "type", "") == "WINDOW"
            and bool(
                _pin_selected_target_key()
                or int(_state.get("smart_dragger_selected_side", -1))
                in (0, 1)
                or _pin_pose_selection_history_enabled(context)
            )
            and not _state.get("pin_history_active", False)
            and not _state.get("pin_target_dragging", False)
            and not _state.get("pin_keyboard_transform_active", False)
            and not _state.get("pin_snap_transform_active", False)
        )

    def invoke(self, context, event):
        selected_key = _pin_selected_target_key()
        window_pointer = int(context.window.as_pointer()) if context.window else 0
        mouse_x = int(getattr(event, "mouse_x", -2147483648))
        mouse_y = int(getattr(event, "mouse_y", -2147483648))
        if _pin_point_over_view3d_ui(context.area, mouse_x, mouse_y):
            return {"PASS_THROUGH"}
        if time.perf_counter() < float(
            _state.get("smart_dragger_preserve_until", 0.0)
        ):
            return {"FINISHED"}
        tool_id = _pin_workspace_tool_id(context)
        previous_tool_id = str(_state.get("pin_workspace_tool_id", ""))
        _state["pin_workspace_tool_id"] = tool_id
        if tool_id and previous_tool_id and tool_id != previous_tool_id:
            # The toolbar/sidebar click itself was already excluded above.
            # Reaching this branch means this is the user's next actual
            # viewport click, so it must still perform click-away in one pass.
            _state["pin_gizmo_selection_keys"] = (
                _pin_pose_selection_signature(context)
            )
        last_claim = _state.get("pin_gizmo_last_claim")
        if (
            last_claim
            and int(last_claim[0]) == window_pointer
            and int(last_claim[1]) == mouse_x
            and int(last_claim[2]) == mouse_y
            and time.perf_counter() - float(last_claim[3]) <= 0.5
        ):
            # Consume the matching release as well as the gizmo press so
            # Blender cannot select a bone hidden directly behind the pin.
            return {"FINISHED"}
        shift_pressed = bool(getattr(event, "shift", False))
        if shift_pressed:
            smart_selected = int(
                _state.get("smart_dragger_selected_side", -1)
            ) in (0, 1)
            if not selected_key and not smart_selected:
                _state["smart_dragger_selected_side"] = -1
                _state["smart_dragger_owner"] = None
                _state["smart_dragger_cache"] = {}
                _state["smart_dragger_selection_keys"] = ()
                _state["smart_dragger_extend_selection_until"] = 0.0
                _tag_redraw_all_view3d()
            elif smart_selected:
                _state["smart_dragger_extend_selection_until"] = (
                    time.perf_counter() + 0.25
                )
            # Let Blender add/toggle bones without consuming a selected pin.
            _state["pin_gizmo_extend_selection_until"] = (
                time.perf_counter() + 0.25
            )
            _state["pin_gizmo_selection_keys"] = ()
            if _pin_pose_selection_history_enabled(context):
                _pin_schedule_click_away(context, selected_key)
            return {"PASS_THROUGH"}
        if (
            _pin_transform_group_has_selected_bones(context)
            or _pin_pose_selection_history_enabled(context)
        ):
            # Blender resolves an empty-space click after this head-priority
            # RELEASE item. Defer until its pose selection changes, while a
            # native gizmo release (unchanged selection) remains untouched.
            _pin_schedule_click_away(context, selected_key)
            return {"PASS_THROUGH"}
        if selected_key:
            _pin_deselect_target()
        _state["smart_dragger_selected_side"] = -1
        _state["smart_dragger_owner"] = None
        _state["smart_dragger_cache"] = {}
        _state["smart_dragger_selection_keys"] = ()
        _state["smart_dragger_extend_selection_until"] = 0.0
        _tag_redraw_all_view3d()
        return {"PASS_THROUGH"}
