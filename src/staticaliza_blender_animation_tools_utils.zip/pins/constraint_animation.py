"""Shared Constraint timeline groups, held spans and native key deletion."""

from ..core.runtime import *  # noqa: F403


def _constraint_channel_name(bone_name):
    return f"Constraint ({bone_name})"


def _constraint_migrate_channels(action, armature):
    """Move existing curves, retaining keys, handles and their Action slot."""
    if armature.type != "ARMATURE" or armature.pose is None:
        return
    paths = {bone.path_from_id(f'["{prop}"]'): bone.name
             for bone in armature.pose.bones
             for prop in (SURFACE_CONTACT_MARKER_PROPERTY, GYRO_MARKER,
                          GYRO_TARGET_PROPERTY, GYRO_TILT_PROPERTY) if prop in bone}
    for curve in _action_fcurves(action, armature):
        name = paths.get(curve.data_path)
        if name and (curve.group is None or curve.group.name != _constraint_channel_name(name)):
            _set_fcurve_group(curve, action, _constraint_channel_name(name))


def _constraint_remember_gyro_markers(guide, bone):
    signature = json.dumps(_pin_marker_points(bone, GYRO_MARKER), sort_keys=True)
    if guide.get("gyro_marker_frames") != signature:
        guide["gyro_marker_frames"] = signature
        for name in ("gyro_stable_constraint", "gyro_aim_constraint"):
            constraint = bone.constraints.get(str(guide.get(name, "")))
            if constraint is not None:
                _gyro_constraint_driver(constraint, bone.id_data, bone)


def _constraint_remove_gyro(context, guide, visible=None):
    """Same teardown for Clear, X/Delete and deleting the timeline channel."""
    armature, bone = _gyro_owner(guide)
    selection = _pin_selection_runtime_snapshot()
    key = _gyro_snap_key(guide)
    selection["selected"].discard(key)
    if selection["active"] == key:
        selection["active"] = next(iter(sorted(selection["selected"])), "")
    _state.setdefault("pin_selected_target_data", {}).pop(key, None)
    helpers = (guide.get("gyro_reference"), guide.get("gyro_aim_output"), guide)
    if bone is not None:
        _constraint_reconcile_end_keys(guide, armature, removed={
            record[2] for record in json.loads(guide.get(CONSTRAINT_END_KEYS_PROPERTY, "[]"))})
        visible = bone.matrix.copy() if visible is None else visible
        for key in ("gyro_stable_constraint", "gyro_aim_constraint"):
            constraint = bone.constraints.get(str(guide.get(key, "")))
            if constraint is not None:
                constraint.driver_remove("influence")
                bone.constraints.remove(constraint)
        action = _dynamic_parent_owner_action(armature)
        properties = (GYRO_MARKER, GYRO_TARGET_PROPERTY, GYRO_TILT_PROPERTY, GYRO_START_PROPERTY)
        paths = {bone.path_from_id(f'["{name}"]') for name in properties if name in bone}
        for curve in _action_fcurves(action, armature):
            if curve.data_path in paths:
                _action_remove_fcurve(action, curve)
        for name in properties:
            if name in bone:
                del bone[name]
        bone.matrix = visible
    if _state.get("gyro_selected") == guide.name:
        _state["gyro_selected"] = ""
    for obj in helpers:
        if obj is not None:
            bpy.data.objects.remove(obj, do_unlink=True)
    _pin_selection_runtime_restore(context, selection)
    if bone is not None:
        _sync_dynamic_pose_bone_color(bone, _chosen_dynamic_parent_constraint(
            bone, context.scene.frame_current), context.scene.frame_current)
    _tag_redraw_all_view3d()


def _constraint_reconcile_gyro(context):
    if (_state.get("gyro_syncing") or _state.get("gyro_history")
            or _state.get("gyro_native_history") or _state.get("pin_history_active")
            or _pin_active_transform_operator(context) or _state.get("gyro_dragging")):
        return False
    changed = False
    _state["gyro_syncing"] = True
    try:
        for guide in _gyro_guides(context.scene):
            armature, bone = _gyro_owner(guide)
            if bone is None:
                _constraint_remove_gyro(context, guide)
                changed = True
                continue
            points = _pin_marker_points(bone, GYRO_MARKER)
            old = {int(k): v for k, v in json.loads(guide.get("gyro_marker_frames", "{}")).items()}
            # Removing an interval's Start removes that interval, including
            # its target keys; removing End extends it, as Contact already does.
            removed = set(old) - set(points)
            added = set(points) - set(old)
            retimed = {}
            for enabled in (False, True):
                missing = sorted(f for f in removed if (old[f] >= .5) == enabled)
                inserted = sorted(f for f in added if (points[f] >= .5) == enabled)
                if len(missing) == len(inserted):
                    retimed.update(zip(missing, inserted))
            removed -= retimed.keys()
            frames = sorted(old)
            deleted_ranges = []
            for i, frame in enumerate(frames):
                if frame not in removed or old[frame] < .5 or (i and old[frames[i-1]] >= .5):
                    continue
                end = next((f for f in frames[i+1:] if old[f] < .5), float("inf"))
                deleted_ranges.append((frame, end))
            deleted_ends = {record[2] for record in json.loads(guide.get(CONSTRAINT_END_KEYS_PROPERTY, "[]"))
                            if any(start <= record[2] <= end for start, end in deleted_ranges)}
            _constraint_reconcile_end_keys(guide, armature, retimed, removed | deleted_ends)
            action = _dynamic_parent_owner_action(armature)
            paths = {bone.path_from_id(f'["{name}"]') for name in (
                GYRO_MARKER, GYRO_TARGET_PROPERTY, GYRO_TILT_PROPERTY)}
            for curve in _action_fcurves(action, armature):
                if curve.data_path not in paths:
                    continue
                curve_changed = False
                # A whole-channel drag already moved its transform keys.
                # Moving only the activation channel carries its data too.
                if curve.data_path != bone.path_from_id(f'["{GYRO_MARKER}"]'):
                    for before, after in retimed.items():
                        key = _fcurve_key_at(curve, before)
                        if key is not None and _fcurve_key_at(curve, after) is None:
                            delta = after-before
                            key.co.x += delta
                            key.handle_left.x += delta
                            key.handle_right.x += delta
                            curve_changed = True
                            changed = True
                for key in tuple(curve.keyframe_points):
                    frame = int(round(key.co.x))
                    if (any(start <= frame <= end for start, end in deleted_ranges)
                            or frame in removed):
                        curve.keyframe_points.remove(key, fast=True)
                        changed = True
                        curve_changed = True
                if curve_changed:
                    curve.update()
            points = _pin_marker_points(bone, GYRO_MARKER)
            if not any(value >= .5 for value in points.values()):
                _constraint_remove_gyro(context, guide)
                changed = True
                continue
            _gyro_sync_start_frame(armature, bone)
            _constraint_remember_gyro_markers(guide, bone)
            _constraint_migrate_channels(action, armature)
        if changed:
            context.view_layer.update()
            _sync_all_dynamic_pose_bone_colors(context.scene.frame_current)
            _tag_redraw_all_view3d()
    finally:
        _state["gyro_syncing"] = False
    return changed


def _constraint_curve_values(curves, frame):
    return tuple(curve.evaluate(frame) for curve in curves)


def _constraint_update_hold_types(marker, values, events=None):
    """Native moving holds link equal target data across an ON/OFF boundary.

    Logical activation remains independent 1/0 switches. No extra frame columns
    or display-only proxy keys are inserted, and deleting them stays native.
    """
    points = list(marker.keyframe_points)
    held = set()
    for left, right in zip(points, points[1:]):
        if (events.get(int(round(left.co.x)), 0.0) if events is not None else left.co.y) < .5:
            continue
        first, last = values(int(round(left.co.x))), values(int(round(right.co.x)))
        if first and len(first) == len(last) and all(abs(a-b) < 1.e-6 for a,b in zip(first,last)):
            held.update((int(round(left.co.x)), int(round(right.co.x))))
    for key in points:
        frame = int(round(key.co.x))
        enabled = events.get(frame, 0.0) >= .5 if events is not None else key.co.y >= .5
        if not enabled:
            if key.type != "GENERATED":
                key.type = "GENERATED"
        elif frame in held:
            if key.type != "MOVING_HOLD":
                key.type = "MOVING_HOLD"
        elif key.type == "MOVING_HOLD":
            key.type = "KEYFRAME" if enabled else "GENERATED"


def _constraint_contact_event_display(owner, marker, values):
    """Encode target identity in the existing native event curve.

    GENERATED remains the exclusive End event; positive target identities let
    Blender draw real flat holds without extra channels or keyframe columns.
    Runtime consumers read normalized Start/End events, never these IDs.
    """
    identities = []
    next_value = 1
    changed = False
    for key in marker.keyframe_points:
        frame = int(round(key.co.x))
        target = values(frame)
        value = next((identity for identity, previous in identities
                      if target and len(previous) == len(target)
                      and all(abs(a-b) < 1.e-6 for a,b in zip(previous,target))), None)
        if value is None:
            value = float(next_value)
            next_value += 1
            if target:
                identities.append((value, target))
        delta = value - key.co.y
        if abs(delta) > 1.e-7:
            key.co.y = value
            key.handle_left.y += delta
            key.handle_right.y += delta
            changed = True
        if key.type == "GENERATED":
            # An inactive gap is never a hold, even at the same target.
            identities.clear()
    if not owner.get(SURFACE_CONTACT_EVENT_ENCODING_PROPERTY, False):
        owner[SURFACE_CONTACT_EVENT_ENCODING_PROPERTY] = True
    if changed:
        marker.update()


def _constraint_sync_timeline(context):
    """Keep both modes visible through the same grouped native channels."""
    contacts = {}
    for guide in _surface_contact_guides():
        _target, owner = _surface_contact_owner_from_guide(guide)
        if owner is None:
            continue
        contacts.setdefault(owner, []).append(guide)
    for owner, guides in contacts.items():
        action = _dynamic_parent_owner_action(owner)
        _constraint_migrate_channels(action, owner.id_data)
        intervals = []
        for guide in guides:
            curves = [c for c in _action_fcurves(_dynamic_parent_owner_action(guide), guide)
                      if c.data_path in {"location", "rotation_quaternion", "rotation_euler"}]
            intervals.append((int(guide.get(SURFACE_CONTACT_START_PROPERTY, 0)),
                              guide.get(SURFACE_CONTACT_END_PROPERTY, float("inf")), curves))
        intervals.sort(key=lambda interval: interval[0])
        def contact_values(frame):
            return next((_constraint_curve_values(curves, frame) for start, end, curves in reversed(intervals)
                         if start <= frame <= end), ())
        events = _surface_contact_marker_points(owner)
        for marker in _surface_contact_marker_fcurves(owner):
            _special_event_migrate_key_style(marker)
            _constraint_update_hold_types(marker, contact_values, events)
            _constraint_contact_event_display(owner, marker, contact_values)
    for guide in _gyro_guides(context.scene):
        armature, bone = _gyro_owner(guide)
        if bone is None:
            continue
        action = _dynamic_parent_owner_action(armature)
        _constraint_migrate_channels(action, armature)
        paths = {bone.path_from_id(f'["{name}"]') for name in (GYRO_TARGET_PROPERTY, GYRO_TILT_PROPERTY)}
        curves = [c for c in _action_fcurves(action, armature) if c.data_path in paths]
        for marker in _fcurves_find_all(action, bone.path_from_id(f'["{GYRO_MARKER}"]'), armature):
            events = _pin_marker_points(bone, GYRO_MARKER)
            _constraint_update_hold_types(marker, lambda frame: _constraint_curve_values(curves, frame), events)
            _special_event_display(marker, lambda frame: _constraint_curve_values(curves, frame))
            ends = {frame for frame, value in events.items() if value < .5}
            for curve in curves:
                for frame in ends:
                    key = _fcurve_key_at(curve, frame)
                    if key is not None and key.type != "GENERATED":
                        key.type = "GENERATED"

