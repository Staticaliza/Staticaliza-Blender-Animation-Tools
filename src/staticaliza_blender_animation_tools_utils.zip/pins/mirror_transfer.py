"""Rest-axis motion transfer for mirrored poses and serialized selected keys."""

from ..core.runtime import *  # noqa: F403
from mathutils import Euler


def _mirror_orthogonal(matrix):
    import numpy as np
    u, _singular, vt = np.linalg.svd(np.asarray([tuple(row) for row in matrix.to_3x3()], dtype=float))
    return Matrix((u @ vt).tolist())


def _mirror_project_contact_target(context, guide, frame, point):
    surface = bpy.data.objects.get(str(guide.get(SURFACE_CONTACT_SURFACE_PROPERTY, '')))
    if surface is None:
        return None
    current = surface.evaluated_get(context.evaluated_depsgraph_get()).matrix_world.copy()
    sampled = _surface_contact_release_object_matrix(surface, frame, {})
    candidate = current @ sampled.inverted_safe() @ Vector(point)
    hit = _surface_contact_bound_surface_point(context, guide, candidate)
    if hit is None:
        return None
    return sampled @ current.inverted_safe() @ Vector(hit[0])


def _mirror_quaternion(rotation, axes):
    vector = -(axes @ Vector((rotation.x, rotation.y, rotation.z)))
    return Quaternion((rotation.w, *vector)).normalized()


def _mirror_rotation_property(mode):
    return ('rotation_quaternion' if mode == 'QUATERNION' else
            'rotation_axis_angle' if mode == 'AXIS_ANGLE' else 'rotation_euler')


def _mirror_rotation_value(values, mode):
    if mode == 'QUATERNION':
        q = Quaternion(values)
        return q.normalized() if q.magnitude > 1.e-10 else Quaternion()
    if mode == 'AXIS_ANGLE':
        axis = Vector(values[1:])
        return Quaternion(axis.normalized(), values[0]) if axis.length > 1.e-10 else Quaternion()
    return Euler(values, mode).to_quaternion()


def _mirror_rotation_components(rotation, mode, reference=None):
    if mode == 'QUATERNION':
        return tuple(rotation)
    if mode == 'AXIS_ANGLE':
        axis, angle = rotation.to_axis_angle()
        return (angle, *axis)
    return tuple(rotation.to_euler(mode, Euler(reference, mode)) if reference is not None else rotation.to_euler(mode))


def _mirror_pose_entries(context, clipboard):
    """Transfer only explicit copied bone transforms; never touch pin data."""
    scope = tuple(_pose_scope_armatures(context))
    by_uid = {_armature_session_uid(a): a for a in scope}
    by_name = {a.name: a for a in scope}
    changed = 0
    for owner in clipboard.get('owners', ()):
        armature = by_uid.get(int(owner.get('session_uid', 0))) or by_name.get(owner.get('armature_name', ''))
        if armature is None:
            continue
        for entry in owner.get('pose_entries', ()):
            source = armature.pose.bones.get(entry['bone_name'])
            name = _mirror_counterpart_name(armature, entry['bone_name'])
            target = armature.pose.bones.get(name)
            if source is None or target is None:
                continue
            axes, ratio = _mirror_basis_map(armature, source, target)
            basis = _pin_clipboard_unpack_matrix(entry['basis'])
            location, rotation, scale = basis.decompose()
            target.matrix_basis = Matrix.LocRotScale(axes @ location * ratio,
                                                    _mirror_quaternion(rotation, axes), scale)
            if context.scene.tool_settings.use_keyframe_insert_auto:
                _insert_bone_keys(target, context.scene.frame_current, visual=False)
            changed += 1
    if changed:
        context.view_layer.update()
    return changed


def _mirror_snapshot_curves(rows):
    """Use Blender's interpolation on a disposable, unbound Action."""
    action = bpy.data.actions.new('_MirrorInterpolation')
    try:
        if hasattr(action, 'fcurves'):
            collection = action.fcurves
        else:
            slot = action.slots.new('OBJECT', '_MirrorInterpolation')
            layer = action.layers.new('Interpolation')
            strip = layer.strips.new(type='KEYFRAME')
            collection = strip.channelbag(slot, ensure=True).fcurves
        result = {}
        for row in rows:
            curve = collection.new(data_path=row['path'], index=int(row['index']))
            for key in row['keys']:
                point = curve.keyframe_points.insert(*key['co'])
                _surface_contact_apply_key_style(point, key.get('style'))
                point.handle_left, point.handle_right = key['left'], key['right']
            curve.update()
            result[(row['path'], int(row['index']))] = curve
        return action, result
    except Exception:
        bpy.data.actions.remove(action)
        raise


def _mirror_target_components(armature, bone, prop, frame):
    defaults = tuple(getattr(bone, prop))
    action = _dynamic_parent_owner_action(armature)
    path = bone.path_from_id()+'.'+prop
    curves = {c.array_index: c for c in _fcurves_find_all(action, path, armature)}
    return tuple(float(curves[i].evaluate(frame)) if i in curves else float(value)
                 for i, value in enumerate(defaults))


def _mirror_sample_property(armature, source, target, prop, mode, axes, ratio,
                            group, curves, frame, offset):
    if prop in {'location', 'scale'}:
        baseline = Vector(_mirror_target_components(armature, target, prop, frame+offset))
        if prop == 'location':
            value = axes.transposed() @ baseline / ratio
            for row in group:
                value[row['index']] = curves[(row['path'], row['index'])].evaluate(frame)
            return tuple(axes @ value * ratio)
        value = list(baseline)
        for row in group:
            value[row['index']] = curves[(row['path'], row['index'])].evaluate(frame)
        return tuple(value)
    target_mode = target.rotation_mode
    target_prop = _mirror_rotation_property(target_mode)
    baseline = _mirror_target_components(armature, target, target_prop, frame+offset)
    inverse = _mirror_quaternion(_mirror_rotation_value(baseline, target_mode), axes.transposed())
    value = list(_mirror_rotation_components(inverse, mode))
    for row in group:
        value[row['index']] = curves[(row['path'], row['index'])].evaluate(frame)
    result = _mirror_quaternion(_mirror_rotation_value(value, mode), axes)
    return _mirror_rotation_components(result, target_mode,
        baseline if target_prop == 'rotation_euler' else None)


def _mirror_adaptive_property(armature, source, target, prop, mode, axes, ratio,
                              group, curves, offset, extra_budget=4096):
    target_prop = prop if prop in {'location', 'scale'} else _mirror_rotation_property(target.rotation_mode)
    times = sorted({float(key['co'][0]) for row in group for key in row['keys']})
    values = {}
    extra_budget = min(extra_budget, int(_state.get('mirror_curve_sample_budget', extra_budget)))
    full = {int(row['index']) for row in group} == set(range(4 if mode in {'QUATERNION', 'AXIS_ANGLE'}
                                                             and prop.startswith('rotation_') else 3))
    def constant(frame):
        if not full:
            return False
        for row in group:
            previous = next((key for key in reversed(row['keys']) if key['co'][0] <= frame+1.e-7), None)
            if previous is None or (previous.get('style') or {}).get('interpolation') != 'CONSTANT':
                return False
        return True
    def sample(frame):
        if frame not in values:
            values[frame] = _mirror_sample_property(armature, source, target, prop, mode,
                axes, ratio, group, curves, frame, offset)
        return values[frame]
    def error(a, b, t, actual):
        if target_prop == 'rotation_quaternion':
            qa, qb = _mirror_rotation_value(a, 'QUATERNION'), _mirror_rotation_value(b, 'QUATERNION')
            if qa.dot(qb) < 0:
                qb.negate()
            interpolated = tuple((1.-t)*qa[i]+t*qb[i] for i in range(4))
        elif target_prop == 'rotation_euler':
            ea, eb = Euler(a, target.rotation_mode), Euler(b, target.rotation_mode)
            eb.make_compatible(ea)
            interpolated = tuple((1.-t)*ea[i]+t*eb[i] for i in range(3))
        else:
            interpolated = tuple((1.-t)*a[i]+t*b[i] for i in range(len(a)))
        if prop.startswith('rotation_'):
            q = _mirror_rotation_value(interpolated, target.rotation_mode)
            desired = _mirror_rotation_value(actual, target.rotation_mode)
            return 2.*math.acos(min(1., abs(q.dot(desired))))/.0015
        tolerance = max(target.bone.length, .1)*1.e-4 if prop == 'location' else 1.e-4
        return (Vector(interpolated)-Vector(actual)).length/tolerance
    kept = set(times)
    def refine(start, end, depth):
        if constant(start):
            return
        if depth >= 10 or len(kept)-len(times) >= extra_budget or end-start < 1.e-4:
            _state['mirror_curve_limited'] = True
            return
        a, b = sample(start), sample(end)
        probes = [start+(end-start)*t for t in (.25, .5, .75)]
        turns = (prop == 'rotation_euler' or prop == 'rotation_axis_angle') and any(
            abs(curves[(row['path'], row['index'])].evaluate(end)-
                curves[(row['path'], row['index'])].evaluate(start)) > math.pi*.5
            for row in group if prop != 'rotation_axis_angle' or row['index'] == 0)
        if not turns and max(error(a, b, t, sample(frame)) for t, frame in zip((.25, .5, .75), probes)) <= 1.:
            return
        mid = probes[1]
        kept.add(mid)
        refine(start, mid, depth+1)
        refine(mid, end, depth+1)
    for start, end in zip(times, times[1:]):
        refine(start, end, 0)
    samples = [list(sample(frame)) for frame in sorted(kept)]
    if target_prop == 'rotation_quaternion':
        for previous, current in zip(samples, samples[1:]):
            if sum(a*b for a, b in zip(previous, current)) < 0:
                current[:] = [-v for v in current]
    elif target_prop == 'rotation_euler':
        for previous, current in zip(samples, samples[1:]):
            angle = Euler(current, target.rotation_mode)
            angle.make_compatible(Euler(previous, target.rotation_mode))
            current[:] = angle
    output = []
    style = dict(group[0]['keys'][0].get('style') or {})
    style.update(interpolation='LINEAR', handle_left_type='VECTOR', handle_right_type='VECTOR')
    for index in range(len(samples[0])):
        keys = [dict(co=(frame, value[index]), left=(frame, value[index]),
                     right=(frame, value[index]), style=dict(style,
                         interpolation='CONSTANT' if constant(frame) else 'LINEAR'))
                for frame, value in zip(sorted(kept), samples)]
        output.append(dict(path=target.path_from_id()+'.'+target_prop, index=index,
                           group=target.name, keys=keys))
    if 'mirror_curve_sample_budget' in _state:
        _state['mirror_curve_sample_budget'] -= len(kept)-len(times)
    return output


def _mirror_exact_curve_group(target, prop, mode, axes, ratio, group):
    """Linear basis changes preserve synchronized curves without baking."""
    if prop == 'location':
        size, transform = 3, axes*ratio
    elif prop in {'rotation_quaternion', 'rotation_axis_angle'} and mode == target.rotation_mode:
        size, transform = 4, Matrix.Identity(4)
        for i in range(3):
            for j in range(3):
                transform[i+1][j+1] = -axes[i][j]
    else:
        return None
    by_index = {int(row['index']): row for row in group}
    if set(by_index) != set(range(size)):
        return None
    reference = by_index[0]['keys']
    for row in group:
        if len(row['keys']) != len(reference):
            return None
        for key, base in zip(row['keys'], reference):
            if any(abs(float(key[n][0])-float(base[n][0])) > 1.e-5 for n in ('co', 'left', 'right')):
                return None
            if any((key.get('style') or {}).get(n) != (base.get('style') or {}).get(n)
                   for n in ('interpolation', 'easing', 'amplitude', 'back', 'period')):
                return None
    output = []
    for index in range(size):
        keys = []
        for k, base in enumerate(reference):
            coordinates = {n: (base[n][0], (transform @ Vector(tuple(
                by_index[j]['keys'][k][n][1] for j in range(size))))[index]) for n in ('co', 'left', 'right')}
            style = dict(by_index[index]['keys'][k].get('style') or {})
            if style.get('interpolation') == 'BEZIER':
                style.update(handle_left_type='FREE', handle_right_type='FREE')
            keys.append(dict(base, **coordinates, style=style))
        output.append(dict(by_index[index], path=target.path_from_id()+'.'+prop,
                           index=index, group=target.name, keys=keys))
    return output


def _mirror_transfer_curve_rows(armature, rows, offset=0.):
    """Exact native signs on symmetric bases; sampled transfer only when needed."""
    output, groups = [], {}
    for row in rows:
        source = next((b for b in armature.pose.bones
            if row['path'].startswith((b.path_from_id()+'.', b.path_from_id()+'['))), None)
        name = _mirror_counterpart_name(armature, source.name) if source else ''
        target = armature.pose.bones.get(name)
        if target is None:
            continue
        prop = row['path'][len(source.path_from_id()):]
        if prop.startswith('['):
            # An activation curve alone cannot construct the receiving pin's
            # surface/solver binding. Never leave a ghost special channel.
            contact = prop == f'["{SURFACE_CONTACT_MARKER_PROPERTY}"]'
            gyro = prop in {f'["{name}"]' for name in
                           (GYRO_MARKER, GYRO_TARGET_PROPERTY, GYRO_TILT_PROPERTY)}
            if ((contact and not _surface_contact_guides_for_effector(armature, target))
                    or (gyro and _gyro_find(bpy.context, armature, target) is None)):
                _state.setdefault('mirror_missing_pins', set()).add((armature.name, target.name))
                continue
            output.append(dict(row, path=target.path_from_id()+prop,
                group=str(row.get('group', '')).replace(source.name, target.name, 1)))
            continue
        axes, ratio = _mirror_basis_map(armature, source, target)
        mode = row.get('rotation_mode', source.rotation_mode)
        # Inactive rotation representations are data, not the source pose.
        # Preserve their native mirrored channels without activating another
        # representation on the destination.
        inactive_rotation = (prop.startswith('.rotation_')
            and prop[1:] != _mirror_rotation_property(mode))
        if prop == '.scale':
            output.append(dict(row, path=target.path_from_id()+prop,
                group=str(row.get('group', '')).replace(source.name, target.name, 1)))
            continue
        canonical = max(abs(axes[i][j]-(-1. if i == j == 0 else 1. if i == j else 0.))
                        for i in range(3) for j in range(3)) < 2.e-5
        compatible = not prop.startswith('.rotation_') or mode == target.rotation_mode
        if (canonical and compatible) or inactive_rotation:
            index = int(row['index'])
            negative = ((prop == '.location' and index == 0)
                or (prop in {'.rotation_quaternion', '.rotation_axis_angle'} and index in {2, 3})
                or (prop == '.rotation_euler' and index in {1, 2}))
            factor = (-1. if negative else 1.)*(ratio if prop == '.location' else 1.)
            copied = dict(row, path=target.path_from_id()+prop,
                group=str(row.get('group', '')).replace(source.name, target.name, 1))
            copied['keys'] = [dict(key, **{n: (key[n][0], factor*key[n][1])
                                         for n in ('co', 'left', 'right')}) for key in row['keys']]
            output.append(copied)
        elif prop[1:] in {'location', 'scale', 'rotation_quaternion', 'rotation_euler', 'rotation_axis_angle'}:
            groups.setdefault((source.name, target.name, prop[1:], mode), []).append(row)
        else:
            output.append(dict(row, path=target.path_from_id()+prop,
                group=str(row.get('group', '')).replace(source.name, target.name, 1)))
    for key, group in tuple(groups.items()):
        s, t, prop, mode = key
        source, target = armature.pose.bones[s], armature.pose.bones[t]
        axes, ratio = _mirror_basis_map(armature, source, target)
        exact = _mirror_exact_curve_group(target, prop, mode, axes, ratio, group)
        if exact is not None:
            output.extend(exact)
            del groups[key]
    if not groups:
        return output
    action, curves = _mirror_snapshot_curves([row for group in groups.values() for row in group])
    try:
        for (s, t, prop, mode), group in groups.items():
            source, target = armature.pose.bones[s], armature.pose.bones[t]
            axes, ratio = _mirror_basis_map(armature, source, target)
            output.extend(_mirror_adaptive_property(armature, source, target, prop, mode,
                                                    axes, ratio, group, curves, offset))
    finally:
        bpy.data.actions.remove(action)
    return output
