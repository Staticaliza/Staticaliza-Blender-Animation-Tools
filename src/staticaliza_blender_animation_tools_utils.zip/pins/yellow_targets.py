"""Yellow onion-pin target persistence and synchronization."""

from ..core.runtime import *  # noqa: F403


def _yellow_drag_target_point(armature, bone_name, point):
    """Snap the dragged target to its endpoint without moving the bone."""
    point = Vector(point)
    if not _state.get("pin_target_dragging", False):
        return point
    pose_bone = (
        armature.pose.bones.get(str(bone_name))
        if armature is not None and getattr(armature, "pose", None)
        else None
    )
    packed = _state.get("yellow_fixed", {}).get(
        _owner_bone_key(armature, bone_name)
    )
    if pose_bone is None or not packed:
        return point
    context = bpy.context
    depsgraph = context.evaluated_depsgraph_get()
    endpoint = _yellow_current_world_point(
        depsgraph,
        armature,
        pose_bone,
        packed,
    )
    snap_key = (
        f"YELLOW:{_armature_session_uid(armature)}:{pose_bone.name}"
    )
    if _pin_snap_should_engage(
        context,
        snap_key,
        endpoint,
        point,
        use_hysteresis = True,
    ):
        return Vector(endpoint)
    return point


def _yellow_set_pin_target(armature, bone_name, point):
    fixed = dict(_state.get("yellow_fixed", {}))
    key = _owner_bone_key(armature, bone_name)
    packed = fixed.get(key)
    if not packed:
        return False
    point = _yellow_drag_target_point(armature, bone_name, point)
    if (point - Vector(packed[0])).length <= 1.0e-8:
        return False
    values = list(packed)
    values[0] = point.copy()
    fixed[key] = tuple(values)
    _state["yellow_fixed"] = fixed
    return True


def _yellow_store_target_property(armature, bone_name, point):
    pose_bone = (
        armature.pose.bones.get(str(bone_name))
        if armature is not None and getattr(armature, "pose", None)
        else None
    )
    if pose_bone is None:
        return False
    pose_bone[YELLOW_PIN_TARGET_PROPERTY] = tuple(
        float(value) for value in Vector(point)
    )
    return True


def _yellow_clear_target_property(armature, bone_name):
    pose_bone = (
        armature.pose.bones.get(str(bone_name))
        if armature is not None and getattr(armature, "pose", None)
        else None
    )
    if pose_bone is None:
        return False
    removed = False
    try:
        for property_name in (
            YELLOW_PIN_TARGET_PROPERTY,
            YELLOW_PIN_MODE_PROPERTY,
            YELLOW_PIN_AXIS_PROPERTY,
            YELLOW_PIN_INITIAL_TARGET_PROPERTY,
            'Pin Reset Local Matrix',
            'Pin Reset Parent',
        ):
            if property_name in pose_bone:
                del pose_bone[property_name]
                removed = True
        return removed
    except (KeyError, TypeError):
        return False


def _yellow_sync_targets_from_properties(context, refresh=True):
    if not _state.get("yellow_fixed") or any(_state.get(name) for name in (
            'pin_target_dragging', 'pin_keyboard_transform_active', 'pin_history_syncing')):
        return False
    fixed = dict(_state.get("yellow_fixed", {}))
    changed = False
    for key, packed in tuple(fixed.items()):
        owner_uid, bone_name = key
        armature = _armature_from_session_uid(owner_uid)
        if armature is None or getattr(armature, "pose", None) is None:
            continue
        pose_bone = armature.pose.bones.get(str(bone_name))
        stored = (
            pose_bone.get(YELLOW_PIN_TARGET_PROPERTY)
            if pose_bone is not None
            else None
        )
        if stored is None:
            stored = _state.setdefault(
                "pin_yellow_history_fallbacks",
                {},
            ).get(key)
        if stored is None or len(stored) < 3:
            continue
        if pose_bone is not None:
            curves = _fcurves_find_all(_dynamic_parent_owner_action(armature),
                pose_bone.path_from_id(f'["{YELLOW_PIN_TARGET_PROPERTY}"]'), armature)
            values = list(stored[:3])
            for curve in curves:
                if not curve.mute and 0 <= curve.array_index < 3:
                    values[curve.array_index] = curve.evaluate(context.scene.frame_current_final)
            stored = values
        point = Vector(tuple(float(value) for value in stored[:3]))
        if (point - Vector(packed[0])).length <= 1.0e-8:
            continue
        values = list(packed)
        values[0] = point
        fixed[key] = tuple(values)
        changed = True
    if changed:
        _state["yellow_fixed"] = fixed
        if refresh:
            _yellow_refresh_runtime(context)
    return changed
