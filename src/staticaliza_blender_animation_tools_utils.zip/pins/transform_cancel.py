"""Shared snap-state rollback for cancelled native and virtual pin edits."""
from ..core.runtime import *  # noqa: F403


_PIN_CANCEL_SNAP_SETS = (
    "pin_snap_latches", "pin_snap_detached", "pin_snap_pressure_active",
    "pin_snap_departing", "pin_snap_transform_engaged", "pin_snap_transform_releasing",
    "smart_dragger_attached_keys",
)


def _pin_capture_cancel_snap_state():
    return {name: frozenset(_state.get(name, ())) for name in _PIN_CANCEL_SNAP_SETS}


def _pin_restore_cancel_snap_state(snapshot):
    if snapshot is not None:
        for name, values in snapshot.items():
            _state[name] = set(values)


def _pin_capture_cancel_action_keys(context, grouped):
    """Only Contact/Onion preview solvers can key before native confirmation."""
    keys = dict(_state.get("pin_snap_contact_start_action_keys", {}))
    for armature in grouped:
        for name in _yellow_owner_map("yellow_fixed", armature):
            bone = armature.pose.bones.get(name)
            if bone is not None:
                keys.setdefault((armature.name, name),
                    _surface_contact_pose_action_key_snapshot(
                        armature, bone, context.scene.frame_current))
    return keys


def _pin_restore_cancel_action_keys(context):
    bases = _pin_capture_action_pose_bases(_selected_pose_bones_by_owner(context))
    for (owner, name), snapshot in _state.get("pin_snap_cancel_action_keys", {}).items():
        armature = bpy.data.objects.get(owner)
        bone = armature.pose.bones.get(name) if armature is not None else None
        if bone is not None:
            _surface_contact_restore_action_key_snapshot(
                armature, bone, context.scene.frame_current, snapshot)
    _pin_restore_action_pose_bases(context, bases)
