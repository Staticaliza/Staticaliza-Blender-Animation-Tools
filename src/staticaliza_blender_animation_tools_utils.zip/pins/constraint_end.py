"""Explicit editable pose keys at authored special-animation End boundaries."""

from ..core.runtime import *  # noqa: F403

CONSTRAINT_END_KEYS_PROPERTY = "_staticaliza_constraint_end_keys"
_SPECIAL_END_INPUTS = "_staticaliza_end_pose_inputs"


def _special_end_curve_points(curve):
    return [[*p.co, p.interpolation, p.handle_left_type, p.handle_right_type,
             *p.handle_left, *p.handle_right, p.easing,p.back,p.amplitude,p.period] for p in curve.keyframe_points]


def _special_end_note_action_updates(depsgraph):
    if depsgraph is None:return
    revisions=_state.setdefault("special_end_action_revisions",{})
    for update in depsgraph.updates:
        action=update.id
        if isinstance(action,bpy.types.Action):
            pointer=int(action.as_pointer());revisions[pointer]=revisions.get(pointer,0)+1
    while len(revisions)>64:revisions.pop(next(iter(revisions)))


def _special_end_modifier_values(curve):
    return tuple((modifier.type,tuple((prop.identifier,
                  tuple(value) if prop.is_array else value)
                  for prop in modifier.bl_rna.properties
                  if not prop.is_readonly and prop.type in {"BOOLEAN","INT","FLOAT","STRING","ENUM"}
                  for value in (getattr(modifier,prop.identifier),))) for modifier in curve.modifiers)


def _special_end_capture_inputs(context, armature, bone, frame):
    """Keep the pre-insertion animation input, not a procedurally held End pose."""
    paths = {bone.path_from_id(p): p for p in
             ("location", "rotation_euler", "rotation_quaternion", "rotation_axis_angle", "scale")}
    action = _dynamic_parent_owner_action(armature)
    source = _special_end_simulation_inputs(context,armature,bone,float(frame),force=True)
    if isinstance(source,bpy.types.Action):action=source
    outgoing = _chosen_dynamic_parent_constraint(bone,int(frame)-1)
    outgoing_end=_dynamic_parent_constraint_segment(bone,outgoing)[1] if outgoing is not None else None
    return {"frame": int(frame), "source": outgoing.name if outgoing_end==int(frame) else "",
            "defaults": {p: list(getattr(bone,p)) for p in paths.values()},
            "curves": {str(c.array_index)+":"+paths[c.data_path]: _special_end_curve_points(c)
                       for c in _action_fcurves(action,armature) if c.data_path in paths}}


def _special_end_clear_input_cache(*_args):
    _state.pop('special_end_decoded_inputs',None)
    _state.pop("special_end_action_revisions",None)
    for entry in _state.pop("special_end_input_actions", {}).values():
        action = bpy.data.actions.get(entry[0])
        if action is not None and not action.users:
            bpy.data.actions.remove(action)


def _special_end_simulation_inputs(context, armature, bone, frame, *, force=False, evaluate_only=False):
    """Exclude generated future End keys while the special interval is active.

    Ordinary curves remain editable and unchanged. A disposable curve copy is
    rebuilt only after actual input edits; Blender evaluates its interpolation.
    """
    packed=bone.get(_SPECIAL_END_INPUTS, "[]")
    decoded=_state.setdefault('special_end_decoded_inputs',{})
    if packed not in decoded:
        if len(decoded)>=32:decoded.clear()
        decoded[packed]=json.loads(packed)
    records=decoded[packed]
    retained=[]
    holding_deleted_start=False
    for record in records:
        source_name=record.get("source", "")
        if source_name:
            source=_dynamic_constraints(bone).get(source_name)
            if source is None:continue
            _start,end=_dynamic_parent_constraint_segment(bone,source)
            if end is None:
                # Parent Start deletion briefly keeps its native relation
                # alive until safe structural cleanup. Preserve the same
                # filtered FK input during that hold; otherwise the future
                # release key leaks into one transient, visibly wrong pose.
                stored_start,stored_end=_stored_dynamic_parent_constraint_segment(bone,source)
                points=_special_event_points(_dynamic_parent_marker_fcurves(bone,source))
                holding=(stored_start is not None and stored_end is not None
                    and not any(abs(at-stored_start)<1.e-5 for at,_value in points)
                    and any(abs(at-stored_end)<1.e-5 and value<.5 for at,value in points)
                    and stored_start<=frame<stored_end)
                if not holding:continue
                end=stored_end;holding_deleted_start=True
            record=dict(record,frame=int(end))
        retained.append(record)
    records=retained
    records = [r for r in records if float(r["frame"]) > frame]
    if not records:
        return False
    constraint = _chosen_dynamic_parent_constraint(bone, int(frame))
    active = (holding_deleted_start or (constraint is not None and
              (constraint.name.startswith("DP_") or _dynamic_space_role(bone,constraint)==SPACE_ROLE_UNPARENT)))
    if not active and not force:
        return False
    action = _dynamic_parent_owner_action(armature)
    if action is None:
        return False
    rotation = {"QUATERNION":"rotation_quaternion", "AXIS_ANGLE":"rotation_axis_angle"}.get(bone.rotation_mode,"rotation_euler")
    properties = ("location",rotation,"scale")
    paths = {bone.path_from_id(p):p for p in properties}
    curves = [c for c in _action_fcurves(action,armature) if c.data_path in paths]
    # Deleted/moved End keys immediately relinquish their input isolation.
    records = [r for r in records if any(abs(p.co.x-r["frame"])<1.e-5
               for c in curves for p in c.keyframe_points)]
    if not records:
        return False
    key = (armature.name_full,bone.name)
    pointer=int(action.as_pointer())
    signature = (pointer,_state.get("special_end_action_revisions",{}).get(pointer,0),
                 packed,tuple((r.get('source',''),r['frame']) for r in records),
                 tuple((c.data_path,c.array_index,c.extrapolation,c.mute,_special_end_modifier_values(c),
                        len(c.keyframe_points)) for c in curves))
    cache = _state.setdefault("special_end_input_actions",{})
    entry = cache.get(key)
    if entry is None or entry[1] != signature or bpy.data.actions.get(entry[0]) is None:
        if entry and (old:=bpy.data.actions.get(entry[0])) is not None and not old.users:
            bpy.data.actions.remove(old)
        filtered = action.copy();filtered.name=".Utils Simulation Input"
        for curve in tuple(_action_fcurves(filtered)):
            if curve.data_path not in paths:
                _action_remove_fcurve(filtered,curve);continue
            prop = paths[curve.data_path]
            for record in records:
                point = _fcurve_key_at(curve,record["frame"])
                if point is not None:
                    curve.keyframe_points.remove(point,fast=True)
            curve.update()
            # Inserting End can also change an existing AUTO handle. Restore
            # its exact pre-insertion handles while the original keys match.
            earliest = min(records,key=lambda r:r["frame"])
            saved = earliest["curves"].get(str(curve.array_index)+":"+prop,[])
            if len(saved)==len(curve.keyframe_points) and all(
                    abs(p.co.x-row[0])<1.e-5 and abs(p.co.y-row[1])<1.e-5
                    for p,row in zip(curve.keyframe_points,saved)):
                for p,row in zip(curve.keyframe_points,saved):
                    p.handle_left_type=p.handle_right_type="FREE"
                    p.handle_left=row[5:7];p.handle_right=row[7:9]
            # A channel first created by End has no earlier animation input.
            # Keeping an empty scale/quaternion curve makes evaluate() return
            # zero instead of the captured default, collapsing a native body.
            if not curve.keyframe_points and not curve.modifiers:
                _action_remove_fcurve(filtered,curve)
        cache[key]=(filtered.name,signature)
        if len(cache)>32:
            old_key=next(k for k in cache if k!=key);old_name=cache.pop(old_key)[0]
            if (old:=bpy.data.actions.get(old_name)) is not None and not old.users:bpy.data.actions.remove(old)
    filtered = bpy.data.actions[cache[key][0]]
    if evaluate_only:return filtered
    filtered_curves = {(c.data_path,c.array_index):c for c in _action_fcurves(filtered)}
    defaults = min(records,key=lambda r:r["frame"])["defaults"]
    changed = False
    for prop in properties:
        value = getattr(bone,prop)
        for index in range(len(value)):
            source = next((c for c in curves if c.data_path==bone.path_from_id(prop) and c.array_index==index),None)
            if source is None or source.mute:continue
            raw = source.evaluate(frame)
            curve = filtered_curves.get((source.data_path,index))
            desired = curve.evaluate(frame) if curve and curve.keyframe_points else defaults[prop][index]
            # A live manual transform owns its edited value; only repair the
            # native Action replay, never a user's in-progress movement.
            if abs(value[index]-raw)<2.e-5 and abs(value[index]-desired)>1.e-7:
                value[index]=desired;changed=True
    return filtered if force else changed


def _special_end_restore_simulation_inputs(context, frame):
    if _state.get("special_end_input_syncing") or _pin_active_transform_operator(context):
        return False
    _state["special_end_input_syncing"] = True
    try:
        changed = False
        for armature in _dynamic_space_unparent_armatures():
            for bone in armature.pose.bones:
                if _SPECIAL_END_INPUTS in bone and not _ragdoll_active(bone,int(frame)):
                    changed = _special_end_simulation_inputs(context,armature,bone,float(frame)) or changed
        if changed:context.view_layer.update()
        return changed
    finally:
        _state["special_end_input_syncing"] = False


def _special_end_with_key_option(operator, context, callback):
    """Scope the explicit End/Split option to this one undoable operation."""
    previous = _state.get("special_end_insert_key", True)
    _state["special_end_insert_key"] = bool(operator.insert_bone_keyframe)
    try:
        return callback(context)
    finally:
        _state["special_end_insert_key"] = previous


def _special_end_insert_pose_key(context, armature, bone, world, frame):
    output = armature.matrix_world.inverted_safe() @ world
    _set_pose_bone_constrained_output_matrix(context, armature, bone, output, atomic=True)
    basis = bone.matrix_basis.copy()
    rotation = {"QUATERNION": "rotation_quaternion", "AXIS_ANGLE": "rotation_axis_angle"}.get(
        bone.rotation_mode, "rotation_euler")
    for prop in ("location", rotation, "scale"):
        curves = _fcurves_find_all(_dynamic_parent_owner_action(armature), bone.path_from_id(prop), armature)
        existing = {c.array_index for c in curves if _fcurve_key_at(c, frame) is not None}
        bone.matrix_basis = basis
        bone.keyframe_insert(data_path=prop, frame=frame, group=bone.name)
        for curve in _fcurves_find_all(_dynamic_parent_owner_action(armature), bone.path_from_id(prop), armature):
            key = _fcurve_key_at(curve, frame)
            if key is not None and curve.array_index not in existing:
                _apply_new_motion_key_style(key)
                key.type = "KEYFRAME"
    return basis


def _constraint_bone_has_pose_key(armature, bone, frame):
    paths = {bone.path_from_id(prop) for prop in (
        "location", "rotation_euler", "rotation_quaternion", "rotation_axis_angle", "scale")}
    return any(curve.data_path in paths and _fcurve_key_at(curve, frame) is not None
               for curve in _action_fcurves(_dynamic_parent_owner_action(armature), armature))


def _constraint_ensure_future_end_pose(context, armature, bone, frame):
    """Explicit Split repairs a legacy missing End key; existing keys win."""
    if not _state.get("special_end_insert_key", True):
        return False
    if _constraint_bone_has_pose_key(armature, bone, frame):
        # Split keeps an existing ordinary End key, but its outgoing interval
        # now belongs to the resumed segment. Carry provenance without key edits.
        records=json.loads(bone.get(_SPECIAL_END_INPUTS,"[]"))
        outgoing=_chosen_dynamic_parent_constraint(bone,int(frame)-1)
        changed=False
        for record in records:
            if (record["frame"]==int(frame) and outgoing is not None
                    and _dynamic_parent_constraint_segment(bone,outgoing)[1]==int(frame)
                    and record.get("source")!=outgoing.name):
                record["source"]=outgoing.name;changed=True
        if changed:bone[_SPECIAL_END_INPUTS]=json.dumps(records)
        return False
    pose = _special_end_previous_pose(context, armature, bone, frame)
    return _constraint_key_end_pose(context, armature, bone, pose, frame)


def _constraint_key_end_pose(context, armature, bone, matrix, frame, guide=None, constraints=()):
    """Add one ordinary End pose key, unless the bone is already keyed there."""
    if not _state.get("special_end_insert_key", True):
        return False
    if guide is not None:
        for prop in ("_constraint_release_inputs", CONSTRAINT_END_KEYS_PROPERTY):
            if prop in guide:
                del guide[prop]
    if _constraint_bone_has_pose_key(armature, bone, frame):
        _constraint_ensure_future_end_pose(context,armature,bone,frame)
        return False
    scene = context.scene
    saved_frame, subframe = scene.frame_current, scene.frame_subframe
    bases = _pin_capture_action_pose_bases((armature,))
    world = armature.matrix_world @ matrix
    guards = {name: _state.get(name, False) for name in (
        "ragdoll_syncing", "gyro_syncing", "surface_contact_solver_syncing", "unparent_handler_mute")}
    try:
        _state.update({name: True for name in guards})
        scene.frame_set(int(frame))
        _sync_dynamic_parent_constraints(int(frame), armature)
        # frame_set replays the raw Action while these solver guards are held.
        # The boundary key belongs in the solved parent's space, not in its
        # pre-physics Action pose. Restore already solved reference bodies only;
        # this operation never seeks or reruns physics under the key writer.
        references=tuple(b for b in _ragdoll_active_bones_hierarchy_order(armature,int(frame)) if b!=bone)
        if references:
            _ragdoll_restore_applied_states(armature,references,int(frame))
            for reference in references:bases[(armature.name,reference.name)]=reference.matrix_basis.copy()
        # A space switch changes the hidden parent's matrix. Resolve it before
        # converting the boundary world pose into the bone's ordinary channels.
        # Using its outgoing matrix applies the old space factor a second time.
        context.view_layer.update()
        inputs = _special_end_capture_inputs(context,armature,bone,frame)
        basis = _special_end_insert_pose_key(context, armature, bone, world, int(frame))
        records = json.loads(bone.get(_SPECIAL_END_INPUTS,"[]"))
        records = [r for r in records if r["frame"]!=int(frame)]
        records.append(inputs)
        bone[_SPECIAL_END_INPUTS] = json.dumps(records)
        bases[(armature.name, bone.name)] = basis
        _pin_restore_action_pose_bases(context, bases)
    finally:
        if scene.frame_current != saved_frame or scene.frame_subframe != subframe:
            scene.frame_set(saved_frame, subframe=subframe)
        _state.update(guards)
    return True


def _constraint_reconcile_end_keys(guide, armature, retimed=None, removed=()):
    """Carry only our untouched generated release keys with native End edits."""
    records = json.loads(guide.get(CONSTRAINT_END_KEYS_PROPERTY, "[]"))
    if not records or armature is None:
        return
    retimed = retimed or {}
    retained = []
    action = _dynamic_parent_owner_action(armature)
    for record in records:
        path, index, frame, value = record[:4]
        key_type = record[4] if len(record) > 4 else "GENERATED"
        curve = next((curve for curve in _action_fcurves(action, armature)
                      if curve.data_path == path and curve.array_index == index), None)
        key = _fcurve_key_at(curve, frame) if curve is not None else None
        after = retimed.get(frame, frame)
        if key is None and curve is not None and after != frame:
            # Dragging the whole Action already carried the native pose keys.
            moved = _fcurve_key_at(curve, after)
            if moved is not None and moved.type == key_type and abs(moved.co.y-value) <= 1.e-5:
                retained.append([path, index, after, value, key_type])
            continue
        if key is None or key.type != key_type or abs(key.co.y-value) > 1.e-5:
            continue
        if frame in removed:
            curve.keyframe_points.remove(key, fast=True)
            curve.update()
            continue
        if after != frame:
            if _fcurve_key_at(curve, after) is not None:
                curve.keyframe_points.remove(key, fast=True)
                curve.update()
                continue
            delta = after-frame
            key.co.x += delta
            key.handle_left.x += delta
            key.handle_right.x += delta
            curve.update()
        retained.append([path, index, after, value, key_type])
    if retained != records:
        guide[CONSTRAINT_END_KEYS_PROPERTY] = json.dumps(retained)


def _gyro_end(context, armature, bone, guide, frame, visible, write_key=True):
    # Keying off the only Start (switching back on the same frame) makes
    # the guide eligible for deletion. Depsgraph callbacks may run inside the
    # pose flush below, so retain ownership until all release data is stored.
    previous = _state.get("gyro_syncing", False)
    _state["gyro_syncing"] = True
    try:
        if write_key:
            visible = _special_end_previous_pose(context, armature, bone, frame)
        bases = _pin_capture_action_pose_bases((armature,))
        _gyro_key_transform(guide, frame)
        _gyro_key_transform(guide["gyro_reference"], frame)
        _gyro_key_enabled(armature, bone, frame, False)
        paths = {bone.path_from_id(f'["{name}"]') for name in
                 (GYRO_MARKER, GYRO_TARGET_PROPERTY, GYRO_TILT_PROPERTY)}
        for curve in _action_fcurves(_dynamic_parent_owner_action(armature), armature):
            if curve.data_path in paths and (key := _fcurve_key_at(curve, frame)) is not None:
                key.type = "GENERATED"
        _gyro_sync_constraint_mask(context, guide)
        _pin_restore_action_pose_bases(context, bases)
        if write_key:
            _constraint_key_end_pose(context, armature, bone, visible, frame, guide)
        else:
            _set_pose_bone_constrained_output_matrix(context, armature, bone, visible, atomic=True)
    finally:
        _state["gyro_syncing"] = previous


def _constraint_contact_end_pose(context, guide, frame, target_object, bone_name, world):
    if target_object is None or world is None:
        return
    bone = (target_object.pose.bones.get(bone_name)
            if target_object.type == "ARMATURE" else None)
    if bone is not None:
        _constraint_key_end_pose(context, target_object, bone,
            target_object.matrix_world.inverted_safe() @ world, frame, guide,
            _surface_contact_constraints(guide))
    else:
        _surface_contact_set_target_world_matrix(context, target_object, bone_name, world, frame=frame)

