"""Single Blender extension hosting the three animation-tool N-panels."""

from __future__ import annotations

from . import unified_host


bl_info = {
    "name": "Staticaliza's Blender Animation Tools",
    "author": "Staticaliza",
    "version": (1, 0, 0),
    "blender": (4, 2, 0),
    "location": "3D View > Sidebar",
    "description": "One extension providing RBXMonkey, Utils, and Impact",
    "category": "Animation",
}


# Utils calls this compatibility entry point from its existing update button.
_install_or_update_children = unified_host.install_or_update
_update_handoff_pending = unified_host.update_handoff_pending
_update_in_progress = unified_host.update_in_progress
_update_progress = unified_host.update_progress
register = unified_host.register
unregister = unified_host.unregister
