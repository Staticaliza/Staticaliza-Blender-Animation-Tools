"""Lightweight host for three privately downloaded Blender tool runtimes."""

from __future__ import annotations

import addon_utils
import bpy
import importlib
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import sys
import tempfile
import time
import urllib.request
import zipfile


HOST_PACKAGE = __package__
HOST_ID = "staticaliza_blender_animation_tools"
HOST_UPDATE_REVISION = 4
LEGACY_HOST_ID = "staticaliza_blender_animation_tools_setup"
LEGACY_IMPACT_ID = "impaction_impact_frames"
ROBLOX_RELEASE_API = (
    "https://api.github.com/repos/Cautioned/"
    "Blender-Animations-Plugin/releases/latest"
)
SETUP_RELEASE_API = (
    "https://api.github.com/repos/Staticaliza/"
    "Staticaliza-Blender-Animation-Tools/releases/latest"
)
SETUP_ASSET_NAME = "staticaliza_blender_animation_tools.zip"
SOURCE_ROOT = (
    "https://raw.githubusercontent.com/Staticaliza/"
    "Staticaliza-Blender-Animation-Tools/main/src"
)
CHILDREN = (
    (
        "Roblox Animator",
        "roblox_animations_importer_exporter",
        "roblox_animations_importer_exporter",
    ),
    (
        "Roblox Animator Utils",
        "staticaliza_blender_animation_tools",
        "staticaliza_blender_animation_tools_utils",
    ),
    (
        "Roblox Animator Impact",
        "staticaliza_blender_animation_tools_impact",
        "staticaliza_blender_animation_tools_impact",
    ),
)
SOURCE_PACKAGES = {
    "staticaliza_blender_animation_tools": (
        f"{SOURCE_ROOT}/staticaliza_blender_animation_tools_utils.zip"
    ),
    "staticaliza_blender_animation_tools_impact": (
        f"{SOURCE_ROOT}/staticaliza_blender_animation_tools_impact.zip"
    ),
}
DEV_PACKAGES = {
    "roblox_animations_importer_exporter": (
        "roblox_animations_importer_exporter.zip",
        "roblox_animations_importer_exporter",
    ),
    "staticaliza_blender_animation_tools": (
        "staticaliza_blender_animation_tools_utils.zip",
        "staticaliza_blender_animation_tools_utils",
    ),
    "staticaliza_blender_animation_tools_impact": (
        "staticaliza_blender_animation_tools_impact.zip",
        "staticaliza_blender_animation_tools_impact",
    ),
}
DEV_SOURCE_CONFIG = Path(__file__).with_name(".staticaliza_dev_sources.json")
DEV_BUILD_MARKER = ".staticaliza_dev_build"
PREPARED_UPDATE_KEY = "__staticaliza_prepared_host_update"
UTILS_UPDATE_GUARD_KEY = "__staticaliza_utils_extension_update_guard"

_modules = []
_runtime_module_prefix = None
_pending_generation = None
_pending_host_archive = None
_prepared_activation = None
_cleanup_attempts = 0
_update_running = False
_status = "Preparing the latest animation tools."


def _github_request(url, accept="application/octet-stream"):
    separator = "&" if "?" in url else "?"
    return urllib.request.Request(
        f"{url}{separator}_cache_bust={time.time_ns()}",
        headers={
            "Accept": accept,
            "Cache-Control": "no-cache, no-store, max-age=0",
            "Pragma": "no-cache",
            "User-Agent": "Staticaliza-Blender-Animation-Tools",
            "X-GitHub-Api-Version": "2022-11-28",
        },
    )


def _runtime_root():
    extension_path_user = getattr(bpy.utils, "extension_path_user", None)
    if extension_path_user is None:
        raise RuntimeError("This Blender build has no extension user-storage API.")
    return Path(
        extension_path_user(HOST_PACKAGE, path="runtime", create=True)
    )


def _read_json(path, fallback=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, ValueError, TypeError):
        return fallback


def _write_json_atomic(path, value):
    path = Path(path)
    temporary = path.with_suffix(f"{path.suffix}.tmp")
    temporary.write_text(
        json.dumps(value, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    os.replace(temporary, path)


def _current_generation():
    root = _runtime_root()
    metadata = _read_json(root / "current.json", {})
    generation = str(metadata.get("generation", ""))
    try:
        generation_ready = bool(
            generation
            and (root / generation / "bundled" / "__init__.py").is_file()
        )
    except OSError:
        # A second Blender/update process can briefly retain or replace a
        # generation directory on Windows.  Registration must still finish;
        # the deferred bootstrap path can retry or report the repository lock.
        generation_ready = False
    if generation_ready:
        return (
            generation,
            dict(metadata.get("versions", {})),
            dict(metadata.get("hashes", {})),
        )
    return None, {}, {}


def _latest_roblox_download():
    with urllib.request.urlopen(
        _github_request(ROBLOX_RELEASE_API, "application/vnd.github+json"),
        timeout=30,
    ) as response:
        release = json.load(response)
    candidates = []
    for asset in release.get("assets", ()):
        name = str(asset.get("name", ""))
        lowered = name.casefold()
        url = asset.get("browser_download_url")
        if url and lowered.endswith(".zip") and "legacy" not in lowered:
            candidates.append((not lowered.startswith("rbx_anims_"), name, url))
    if not candidates:
        raise RuntimeError("Latest Roblox Animator release has no regular ZIP asset.")
    _rank, _name, url = min(candidates)
    return str(release.get("tag_name") or "latest"), str(url)


def _download_zip(url, destination):
    with urllib.request.urlopen(_github_request(url), timeout=60) as response:
        with open(destination, "wb") as output:
            while chunk := response.read(1024 * 1024):
                output.write(chunk)
    with zipfile.ZipFile(destination) as archive:
        failed_member = archive.testzip()
        if failed_member is not None:
            raise RuntimeError(f"Downloaded ZIP failed integrity check: {failed_member}")
    digest = hashlib.sha256()
    with open(destination, "rb") as source:
        while chunk := source.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _host_payload_hash_from_archive(path):
    expected = ("__init__.py", "unified_host.py", "blender_manifest.toml")
    digest = hashlib.sha256()
    try:
        import tomllib
        with zipfile.ZipFile(path) as archive:
            if archive.testzip() is not None:
                return None
            names = {
                name.replace("\\", "/").lstrip("/"): name
                for name in archive.namelist()
                if not name.endswith("/")
            }
            roots = {
                normalized[:-len("blender_manifest.toml")]
                for normalized in names
                if normalized.endswith("blender_manifest.toml")
            }
            for root in sorted(roots, key=len):
                manifest_name = names.get(f"{root}blender_manifest.toml")
                if manifest_name is None:
                    continue
                manifest = tomllib.loads(archive.read(manifest_name).decode("utf-8"))
                if (
                    str(manifest.get("id", "")) != HOST_ID
                    or str(manifest.get("version", "")) != "1.0.0"
                ):
                    continue
                for filename in expected:
                    member = names.get(f"{root}{filename}")
                    if member is None:
                        return None
                    digest.update(filename.encode("utf-8"))
                    digest.update(archive.read(member))
                return digest.hexdigest()
    except (ImportError, OSError, UnicodeDecodeError, ValueError, zipfile.BadZipFile):
        return None
    return None


def _installed_host_payload_hash():
    digest = hashlib.sha256()
    root = Path(__file__).resolve().parent
    for filename in ("__init__.py", "unified_host.py", "blender_manifest.toml"):
        path = root / filename
        if not path.is_file():
            return None
        digest.update(filename.encode("utf-8"))
        digest.update(path.read_bytes())
    return digest.hexdigest()


def _host_revision_from_archive(path):
    try:
        with zipfile.ZipFile(path) as archive:
            names = [
                name for name in archive.namelist()
                if name.replace("\\", "/").endswith("unified_host.py")
            ]
            if not names:
                return 0
            source = archive.read(min(names, key=lambda name: name.count("/"))).decode(
                "utf-8"
            )
    except (OSError, UnicodeDecodeError, zipfile.BadZipFile):
        return 0
    for line in source.splitlines():
        key, separator, value = line.partition("=")
        if separator and key.strip() == "HOST_UPDATE_REVISION":
            try:
                return int(value.strip())
            except ValueError:
                return 0
    return 0


def _hash_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as source:
        while chunk := source.read(1024 * 1024):
            digest.update(chunk)
    return digest.hexdigest()


def _archive_package_prefix(archive):
    files = []
    for info in archive.infolist():
        if info.is_dir():
            continue
        path = PurePosixPath(info.filename.replace("\\", "/").lstrip("/"))
        if path.is_absolute() or ".." in path.parts:
            raise RuntimeError(f"Downloaded ZIP contains unsafe path: {info.filename}")
        files.append((info, path))
    init_paths = [path for _info, path in files if path.name == "__init__.py"]
    if not init_paths:
        raise RuntimeError("Downloaded package has no __init__.py.")
    package_init = min(init_paths, key=lambda path: len(path.parts))
    return files, package_init.parent


def _extract_package(archive_path, destination):
    destination = Path(destination)
    destination.mkdir(parents=True, exist_ok=False)
    with zipfile.ZipFile(archive_path) as archive:
        files, prefix = _archive_package_prefix(archive)
        for info, path in files:
            if prefix.parts and path.parts[:len(prefix.parts)] != prefix.parts:
                continue
            relative = PurePosixPath(*path.parts[len(prefix.parts):])
            if not relative.parts:
                continue
            target = destination.joinpath(*relative.parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info) as source, open(target, "wb") as output:
                shutil.copyfileobj(source, output)
    if not (destination / "__init__.py").is_file():
        raise RuntimeError("Downloaded package root could not be normalized.")


def _manifest_version(package_root):
    manifest_path = Path(package_root) / "blender_manifest.toml"
    try:
        import tomllib
        manifest = tomllib.loads(manifest_path.read_text(encoding="utf-8"))
        return str(manifest.get("version") or "latest")
    except (ImportError, OSError, UnicodeDecodeError, ValueError):
        return "latest"


def _version_key(version):
    values = []
    for token in str(version).strip().split("."):
        digits = ""
        for character in token:
            if not character.isdigit():
                break
            digits += character
        if not digits:
            break
        values.append(int(digits))
    return tuple(values) if values else (-1,)


def _dev_source_directories():
    directories = []
    configured = os.environ.get("STATICALIZA_DEV_PACKAGE_DIR", "")
    directories.extend(Path(value) for value in configured.split(os.pathsep) if value)
    config = _read_json(DEV_SOURCE_CONFIG, {})
    configured_directory = str(config.get("package_directory", "")).strip()
    if configured_directory:
        directories.append(Path(configured_directory))
    directories.append(
        Path.home()
        / "Documents"
        / "_Blender"
        / "ExtensionsDev"
        / "Staticaliza-Blender-Animation-Tools"
        / "src"
    )
    for parent in Path(__file__).resolve().parents:
        source = parent / "src"
        if source.is_dir():
            directories.append(source)
    unique = []
    seen = set()
    for directory in directories:
        resolved = directory.expanduser().resolve()
        key = os.path.normcase(str(resolved))
        if key not in seen and resolved.is_dir():
            seen.add(key)
            unique.append(resolved)
    return tuple(unique)


def _dev_setup_archive():
    config = _read_json(DEV_SOURCE_CONFIG, {})
    configured = str(config.get("setup_archive", "")).strip()
    candidates = [Path(configured)] if configured else []
    package_directory = str(config.get("package_directory", "")).strip()
    if package_directory:
        candidates.append(
            Path(package_directory).expanduser().resolve().parent
            / SETUP_ASSET_NAME
        )
    for directory in _dev_source_directories():
        candidates.append(directory.parent / SETUP_ASSET_NAME)
    for candidate in candidates:
        resolved = candidate.expanduser().resolve()
        if resolved.is_file() and _host_payload_hash_from_archive(resolved):
            return resolved
    return None


def _latest_setup_archive():
    developer = _dev_setup_archive()
    if developer is not None:
        return developer, True

    try:
        with urllib.request.urlopen(
            _github_request(SETUP_RELEASE_API, "application/vnd.github+json"),
            timeout=30,
        ) as response:
            release = json.load(response)
        asset_url = next(
            str(asset.get("browser_download_url"))
            for asset in release.get("assets", ())
            if str(asset.get("name", "")).casefold()
            == SETUP_ASSET_NAME.casefold()
            and asset.get("browser_download_url")
        )
    except (OSError, StopIteration, TypeError, ValueError):
        return None, False

    destination = _runtime_root() / f".setup-update-{time.time_ns()}.zip"
    try:
        _download_zip(asset_url, destination)
        if _host_payload_hash_from_archive(destination) is None:
            raise RuntimeError("Latest Setup archive is not a valid 1.0.0 host package.")
        return destination, False
    except Exception:
        destination.unlink(missing_ok=True)
        raise


def _pending_setup_update():
    archive, developer = _latest_setup_archive()
    if archive is None:
        return None
    same_payload = (
        _host_payload_hash_from_archive(archive) == _installed_host_payload_hash()
    )
    public_not_newer = (
        not developer
        and _host_revision_from_archive(archive) <= HOST_UPDATE_REVISION
    )
    if same_payload or public_not_newer:
        if archive.parent == _runtime_root() and archive.name.startswith(".setup-update-"):
            archive.unlink(missing_ok=True)
        return None
    return archive


def _dev_archive_version(path, expected_id):
    try:
        import tomllib
        with zipfile.ZipFile(path) as archive:
            if archive.testzip() is not None:
                return None
            names = [name.replace("\\", "/") for name in archive.namelist()]
            if not any(
                name == DEV_BUILD_MARKER or name.endswith(f"/{DEV_BUILD_MARKER}")
                for name in names
            ):
                return None
            manifests = [name for name in names if name.endswith("blender_manifest.toml")]
            if not manifests:
                return None
            manifest_name = min(manifests, key=lambda name: name.count("/"))
            manifest = tomllib.loads(archive.read(manifest_name).decode("utf-8"))
            if str(manifest.get("id", "")) != expected_id:
                return None
            return str(manifest.get("version") or "latest")
    except (ImportError, OSError, UnicodeDecodeError, ValueError, zipfile.BadZipFile):
        return None


def _archive_version(path):
    try:
        import tomllib
        with zipfile.ZipFile(path) as archive:
            if archive.testzip() is not None:
                return "latest"
            manifests = [
                name for name in archive.namelist()
                if name.replace("\\", "/").endswith("blender_manifest.toml")
            ]
            if not manifests:
                return "latest"
            manifest_name = min(manifests, key=lambda name: name.count("/"))
            manifest = tomllib.loads(archive.read(manifest_name).decode("utf-8"))
            return str(manifest.get("version") or "latest")
    except (ImportError, OSError, UnicodeDecodeError, ValueError, zipfile.BadZipFile):
        return "latest"


def _dev_package_candidate(module_id):
    filename, expected_id = DEV_PACKAGES[module_id]
    candidates = []
    for directory in _dev_source_directories():
        path = directory / filename
        version = _dev_archive_version(path, expected_id) if path.is_file() else None
        if version is not None:
            candidates.append((version, 1, path, None))
    if candidates:
        version, _priority, path, source_hash = max(
            candidates,
            key=lambda item: (_version_key(item[0]), str(item[2])),
        )
        return version, path, source_hash

    # A configured local archive is the development source of truth even when
    # its fixed product version is lower than a stale installed DEV generation.
    # Reuse the installed generation only when no local DEV archive is present.
    current_name, _versions, current_hashes = _current_generation()
    if current_name:
        package_root = _runtime_root() / current_name / "bundled" / module_id
        if (package_root / DEV_BUILD_MARKER).is_file():
            label = next(
                child_label
                for child_label, child_module_id, _legacy_id in CHILDREN
                if child_module_id == module_id
            )
            candidates.append((
                _manifest_version(package_root),
                0,
                package_root,
                current_hashes.get(label),
            ))
    if not candidates:
        return None
    version, _priority, path, source_hash = max(
        candidates,
        key=lambda item: (_version_key(item[0]), item[1], str(item[2])),
    )
    return version, path, source_hash


def _install_package_source(source, destination):
    source = Path(source)
    if source.is_dir():
        shutil.copytree(source, destination)
    else:
        _extract_package(source, destination)


def _hash_package_source(source):
    source = Path(source)
    if source.is_file():
        return _hash_file(source)
    digest = hashlib.sha256()
    for path in sorted(item for item in source.rglob("*") if item.is_file()):
        digest.update(path.relative_to(source).as_posix().encode("utf-8"))
        digest.update(path.read_bytes())
    return digest.hexdigest()


def _patch_roblox_package(package_root, developer=False):
    version = _manifest_version(package_root)
    panel_label = f"RBXMonkey (v{version})" + (" (DEV)" if developer else "")
    for source in Path(package_root).rglob("*.py"):
        try:
            text = source.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        patched = text.replace("Rbx Animations", "RBXMonkey")
        if source.as_posix().endswith("/ui/panels.py"):
            patched = patched.replace(
                'bl_label = "RBXMonkey"',
                f'bl_label = "{panel_label}"',
            )
            patched = patched.replace(
                "bl_label = 'RBXMonkey'",
                f'bl_label = "{panel_label}"',
            )
        elif source.as_posix().endswith("/server/requests.py"):
            patched = patched.replace(
                "return 0.01  # Run every 10ms for good balance",
                "server_module = sys.modules.get(f\"{__package__}.server\")\n"
                "    server_active = bool(\n"
                "        getattr(server_module, \"server_should_run\", False)\n"
                "        and getattr(server_module, \"server_instance\", None) is not None\n"
                "    )\n"
                "    return 0.01 if pending_requests or server_active else 0.25",
            )
            if "server_module = sys.modules.get" in patched:
                patched = patched.replace(
                    "import json\n",
                    "import json\nimport sys\n",
                    1,
                )
        if patched != text:
            source.write_text(patched, encoding="utf-8", newline="\n")


def _prepare_latest_generation():
    if not getattr(bpy.app, "online_access", True):
        raise RuntimeError("Blender online access is disabled in Preferences.")
    root = _runtime_root()
    root.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=".staging-", dir=root))
    generation = f"runtime_{time.time_ns()}"
    downloads = staging / ".downloads"
    bundled = staging / "bundled"
    downloads.mkdir()
    bundled.mkdir()
    (staging / "__init__.py").write_text("", encoding="utf-8")
    (bundled / "__init__.py").write_text("", encoding="utf-8")
    versions = {}
    hashes = {}
    try:
        roblox_version, roblox_url = _latest_roblox_download()
        jobs = (
            ("Roblox Animator", "roblox_animations_importer_exporter", roblox_url),
            (
                "Roblox Animator Utils",
                "staticaliza_blender_animation_tools",
                SOURCE_PACKAGES["staticaliza_blender_animation_tools"],
            ),
            (
                "Roblox Animator Impact",
                "staticaliza_blender_animation_tools_impact",
                SOURCE_PACKAGES["staticaliza_blender_animation_tools_impact"],
            ),
        )
        developer_modules = set()
        for label, module_id, url in jobs:
            archive_path = downloads / f"{module_id}.zip"
            remote_hash = _download_zip(url, archive_path)
            remote_version = _archive_version(archive_path)

            developer = _dev_package_candidate(module_id)
            use_developer = bool(
                developer
                and _version_key(developer[0]) >= _version_key(remote_version)
            )
            package_root = bundled / module_id
            if use_developer:
                developer_version, developer_source, developer_hash = developer
                _install_package_source(developer_source, package_root)
                versions[label] = f"{developer_version} (DEV)"
                hashes[label] = developer_hash or _hash_package_source(developer_source)
                developer_modules.add(module_id)
            else:
                _extract_package(archive_path, package_root)
                versions[label] = (
                    roblox_version
                    if module_id == "roblox_animations_importer_exporter"
                    else remote_version
                )
                hashes[label] = remote_hash
        _patch_roblox_package(
            bundled / "roblox_animations_importer_exporter",
            developer="roblox_animations_importer_exporter" in developer_modules,
        )
        shutil.rmtree(downloads)
        _write_json_atomic(
            staging / "versions.json",
            {"versions": versions, "hashes": hashes},
        )
        destination = root / generation
        os.replace(staging, destination)
        return generation, versions, hashes
    except Exception:
        shutil.rmtree(staging, ignore_errors=True)
        raise


def _purge_runtime_modules(prefix):
    if not prefix:
        return
    for module_name in tuple(sys.modules):
        if module_name == prefix or module_name.startswith(f"{prefix}."):
            sys.modules.pop(module_name, None)


def _unregister_children():
    for module in reversed(_modules):
        callback = getattr(module, "unregister", None)
        if callable(callback):
            try:
                callback()
            except Exception as exc:
                print(f"[Staticaliza's Blender Animation Tools] Unregister warning: {exc}")
    _modules.clear()


def _import_generation(generation):
    global _runtime_module_prefix
    root = _runtime_root()
    root_text = str(root)
    if root_text not in sys.path:
        sys.path.insert(0, root_text)
    registered = []
    try:
        for _label, module_id, _legacy_id in CHILDREN:
            module = importlib.import_module(f"{generation}.bundled.{module_id}")
            callback = getattr(module, "register", None)
            if not callable(callback):
                raise RuntimeError(f"Downloaded runtime has no register(): {module_id}")
            callback()
            registered.append(module)
    except Exception:
        for module in reversed(registered):
            try:
                module.unregister()
            except Exception:
                pass
        _purge_runtime_modules(generation)
        raise
    _modules[:] = registered
    _runtime_module_prefix = generation


def _activate_generation(generation):
    old_generation = _runtime_module_prefix
    _unregister_children()
    _purge_runtime_modules(old_generation)
    try:
        _import_generation(generation)
    except Exception:
        if old_generation and old_generation != generation:
            _import_generation(old_generation)
        raise


def _version_log(versions):
    return ", ".join(
        f"{label} {versions.get(label, 'latest')}"
        for label, _module_id, _legacy_id in CHILDREN
    )


def _record_current(generation, versions, hashes):
    _write_json_atomic(
        _runtime_root() / "current.json",
        {"generation": generation, "versions": versions, "hashes": hashes},
    )


def _activate_pending_generation():
    global _pending_generation, _status, _update_running
    pending = _pending_generation
    _pending_generation = None
    if pending is None:
        _update_running = False
        return None
    generation, versions, hashes, message = pending
    try:
        _activate_generation(generation)
        _record_current(generation, versions, hashes)
        _status = message
        print(f"[Staticaliza's Blender Animation Tools] {message}")
    except Exception as exc:
        _status = f"Update failed: {exc}"
        print(f"[Staticaliza's Blender Animation Tools] {_status}")
    finally:
        _update_running = False
    return None


def _activate_prepared_generation():
    """Activate files prepared before a Setup self-reload, without downloading again."""
    global _prepared_activation, _status, _update_running
    pending = _prepared_activation
    _prepared_activation = None
    if pending is None:
        return None
    generation, message = pending
    _update_running = True
    try:
        _activate_generation(generation)
        _status = message
        print(f"[Staticaliza's Blender Animation Tools] {message}")
        _finish_prepared_update_ui(message, "CHECKMARK")
    except Exception as exc:
        _status = f"Prepared update activation failed: {exc}"
        print(f"[Staticaliza's Blender Animation Tools] {_status}")
        _finish_prepared_update_ui(_status, "ERROR")
    finally:
        _update_running = False
    return None


def _finish_prepared_update_ui(message, icon):
    """Finish the single update pass after Setup has reloaded itself."""
    try:
        bpy.app.driver_namespace.pop(UTILS_UPDATE_GUARD_KEY, None)
    except (AttributeError, ReferenceError, RuntimeError, TypeError):
        pass
    window_manager = getattr(bpy.context, "window_manager", None)
    if window_manager is not None and not bpy.app.background:
        def draw(self, _context):
            self.layout.label(text=str(message))

        window_manager.popup_menu(draw, title="Extension Update", icon=icon)
    for window in tuple(getattr(window_manager, "windows", ()) if window_manager else ()):
        screen = getattr(window, "screen", None)
        for area in tuple(getattr(screen, "areas", ()) if screen else ()):
            if area.type == "VIEW_3D":
                area.tag_redraw()


def _install_pending_host():
    global _pending_host_archive, _status, _update_running
    archive = _pending_host_archive
    _pending_host_archive = None
    if archive is None:
        _update_running = False
        return None
    archive = Path(archive)
    temporary_download = (
        archive.parent == _runtime_root()
        and archive.name.startswith(".setup-update-")
    )
    try:
        install = getattr(getattr(bpy.ops, "extensions", None), "package_install_files", None)
        if install is None:
            raise RuntimeError("This Blender build has no extension installer API.")
        try:
            result = install(
                "EXEC_DEFAULT",
                filepath=str(archive),
                repo="user_default",
                enable_on_install=True,
                overwrite=True,
            )
        except TypeError:
            result = install(
                "EXEC_DEFAULT",
                filepath=str(archive),
                repo="user_default",
            )
        if "FINISHED" not in result:
            raise RuntimeError("Blender did not finish updating the Setup host.")
        print("[Staticaliza's Blender Animation Tools] Updated Setup host; refreshing runtimes.")
    except Exception as exc:
        _status = f"Update failed: {exc}"
        _update_running = False
        print(f"[Staticaliza's Blender Animation Tools] {_status}")
    finally:
        if temporary_download:
            archive.unlink(missing_ok=True)
    return None


def install_or_update():
    """Download all three latest runtimes and hot-swap them after this callback."""
    global _pending_generation, _pending_host_archive, _status, _update_running
    if _update_running:
        raise RuntimeError("An animation-tools update is already running.")
    _update_running = True
    try:
        setup_archive = _pending_setup_update()
        if setup_archive is not None:
            generation, versions, hashes = _prepare_latest_generation()
            message = f"Updated {_version_log(versions)}."
            _current_name, _current_versions, current_hashes = _current_generation()
            if current_hashes and hashes == current_hashes:
                shutil.rmtree(_runtime_root() / generation, ignore_errors=True)
            else:
                _record_current(generation, versions, hashes)
            bpy.app.driver_namespace[PREPARED_UPDATE_KEY] = message
            _pending_host_archive = setup_archive
            _status = message
            if not bpy.app.timers.is_registered(_install_pending_host):
                bpy.app.timers.register(_install_pending_host, first_interval=0.05)
            return _status
        generation, versions, hashes = _prepare_latest_generation()
        message = f"Updated {_version_log(versions)}."
        _current_name, _current_versions, current_hashes = _current_generation()
        if current_hashes and hashes == current_hashes:
            shutil.rmtree(_runtime_root() / generation, ignore_errors=True)
            _status = message
            _update_running = False
            print(f"[Staticaliza's Blender Animation Tools] {message}")
            return message
        _pending_generation = (generation, versions, hashes, message)
        _status = message
        if not bpy.app.timers.is_registered(_activate_pending_generation):
            bpy.app.timers.register(_activate_pending_generation, first_interval=0.05)
        return message
    except Exception:
        _update_running = False
        raise


def update_handoff_pending():
    """Report whether a prepared runtime generation awaits a host reload."""
    return _pending_host_archive is not None


def _bootstrap_latest():
    global _status, _update_running
    if _update_running:
        return None
    _update_running = True
    try:
        current_name, _current_versions, current_hashes = _current_generation()
        _disable_external(LEGACY_HOST_ID)
        for _label, _module_id, legacy_id in CHILDREN:
            _disable_external(legacy_id)
        _disable_legacy_impact()
        if current_name and not _modules:
            _import_generation(current_name)
        generation, versions, hashes = _prepare_latest_generation()
        if current_name and current_hashes and hashes == current_hashes:
            shutil.rmtree(_runtime_root() / generation, ignore_errors=True)
        else:
            _activate_generation(generation)
            _record_current(generation, versions, hashes)
        _status = f"Updated {_version_log(versions)}."
        print(f"[Staticaliza's Blender Animation Tools] {_status}")
    except Exception as exc:
        if _modules:
            _status = f"Using cached tools; refresh failed: {exc}"
        else:
            _status = f"Setup failed: {exc}"
        print(f"[Staticaliza's Blender Animation Tools] {_status}")
    finally:
        _update_running = False
    return None


def _version_text(module):
    version = getattr(module, "ADDON_VERSION", None)
    if version is None:
        version = getattr(module, "bl_info", {}).get("version")
    if isinstance(version, (tuple, list)):
        return ".".join(str(value) for value in version)
    return str(version or "latest")


def _disable_external(addon_id):
    for module in tuple(addon_utils.modules(refresh=True)):
        name = str(getattr(module, "__name__", ""))
        if name != addon_id and not name.endswith(f".{addon_id}"):
            continue
        if _runtime_module_prefix and name.startswith(f"{_runtime_module_prefix}."):
            continue
        try:
            if addon_utils.check(name)[1]:
                addon_utils.disable(name, default_set=True)
        except (AttributeError, RuntimeError, TypeError):
            pass


def _disable_legacy_impact():
    _disable_external(LEGACY_IMPACT_ID)
    try:
        callback = bpy.app.driver_namespace.pop(
            "impaction_impact_frames.self_update_timer", None
        )
        if callback is not None and bpy.app.timers.is_registered(callback):
            bpy.app.timers.unregister(callback)
    except (AttributeError, RuntimeError, ValueError):
        pass


def _repository():
    repositories = getattr(
        getattr(bpy.context.preferences, "extensions", None), "repos", ()
    )
    return next(
        (repo for repo in repositories if repo.module == "user_default"), None
    )


def _repository_locked():
    try:
        from bl_pkg import cookie_from_session
        from bl_pkg.bl_extension_utils import repo_lock_directory_query
    except ImportError:
        return False
    repository = _repository()
    return bool(
        repository
        and repo_lock_directory_query(repository.directory, cookie_from_session())
        is not None
    )


def _remove_old_package_rows():
    global _cleanup_attempts
    if _repository_locked():
        _cleanup_attempts += 1
        return 0.5 if _cleanup_attempts <= 40 else None
    repository = _repository()
    if repository is None:
        return None
    _cleanup_attempts = 0
    installed_ids = {
        path.name
        for path in Path(repository.directory).iterdir()
        if path.is_dir() and (path / "blender_manifest.toml").is_file()
    }
    for package_id in (
        LEGACY_HOST_ID,
        *(legacy_id for _label, _module_id, legacy_id in CHILDREN),
    ):
        if package_id not in installed_ids:
            continue
        _disable_external(package_id)
        try:
            bpy.ops.extensions.package_uninstall(
                "EXEC_DEFAULT",
                repo_directory=repository.directory,
                pkg_id=package_id,
            )
        except (AttributeError, RuntimeError, TypeError):
            pass
    return None


class STATICALIZA_SETUP_OT_update_latest(bpy.types.Operator):
    bl_idname = "staticaliza_setup.update_latest_extensions"
    bl_label = "Install Latest Extensions"
    bl_description = "Install the latest RBXMonkey, Utils, and Impact runtimes"

    def execute(self, context):
        del context
        global _status
        try:
            message = install_or_update()
        except Exception as exc:
            _status = f"Update failed: {exc}"
            self.report({"ERROR"}, _status)
            return {"CANCELLED"}
        self.report({"INFO"}, message)
        return {"FINISHED"}


class STATICALIZA_SETUP_preferences(bpy.types.AddonPreferences):
    bl_idname = HOST_PACKAGE

    def draw(self, context):
        del context
        layout = self.layout
        layout.label(text="One extension; three automatically updated N-panels")
        for (label, _module_id, _legacy_id), module in zip(CHILDREN, _modules):
            display_label = "RBXMonkey" if label == "Roblox Animator" else label
            layout.label(text=f"{display_label}: {_version_text(module)}")
        layout.label(text=_status)
        layout.operator(STATICALIZA_SETUP_OT_update_latest.bl_idname)


CLASSES = (
    STATICALIZA_SETUP_OT_update_latest,
    STATICALIZA_SETUP_preferences,
)


def register():
    global _prepared_activation
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    prepared_message = bpy.app.driver_namespace.pop(PREPARED_UPDATE_KEY, None)
    generation, versions, _hashes = _current_generation()
    if generation:
        global _status
        if prepared_message:
            _prepared_activation = (generation, str(prepared_message))
            _status = "Activating prepared extension update."
        else:
            _status = f"Loading cached {_version_log(versions)}."
    if not bpy.app.timers.is_registered(_remove_old_package_rows):
        bpy.app.timers.register(_remove_old_package_rows, first_interval=0.5)
    if _prepared_activation is not None:
        if not bpy.app.timers.is_registered(_activate_prepared_generation):
            bpy.app.timers.register(_activate_prepared_generation, first_interval=0.0)
    elif not _modules and not bpy.app.timers.is_registered(_bootstrap_latest):
        bpy.app.timers.register(_bootstrap_latest, first_interval=0.1)


def unregister():
    for timer in (
        _bootstrap_latest,
        _activate_prepared_generation,
        _activate_pending_generation,
        _install_pending_host,
        _remove_old_package_rows,
    ):
        if bpy.app.timers.is_registered(timer):
            bpy.app.timers.unregister(timer)
    _unregister_children()
    _purge_runtime_modules(_runtime_module_prefix)
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
